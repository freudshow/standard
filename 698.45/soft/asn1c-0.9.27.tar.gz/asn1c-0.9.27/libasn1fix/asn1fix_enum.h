#ifndef	_ASN1FIX_ENUM_H_
#define	_ASN1FIX_ENUM_H_

int asn1f_fix_enum(arg_t *);	/* Enumeration ::= ENUMERATED { a(1), b(2) } */

#endif	/* _ASN1FIX_ENUM_H_ */
