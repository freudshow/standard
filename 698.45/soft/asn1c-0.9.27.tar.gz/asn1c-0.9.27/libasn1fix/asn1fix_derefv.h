#ifndef	_ASN1FIX_DEREFV_H_
#define	_ASN1FIX_DEREFV_H_

int asn1f_fix_dereference_values(arg_t *);

int asn1f_fix_dereference_defaults(arg_t *);

#endif	/* _ASN1FIX_DEREFV_H_ */
