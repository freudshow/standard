#ifndef	_ASN1FIX_PARAMETERIZATION_H_
#define	_ASN1FIX_PARAMETERIZATION_H_

asn1p_expr_t *asn1f_parameterization_fork(arg_t *arg, asn1p_expr_t *expr, asn1p_expr_t *rhs_pspecs);

#endif	/* _ASN1FIX_PARAMETERIZATION_H_ */
