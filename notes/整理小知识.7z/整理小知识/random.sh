#/bin/bash
r2=0
echo "enter a number:"
read $r1
r2=$(($r1*123+59))
echo "random 0-65535 number is:$r2"
