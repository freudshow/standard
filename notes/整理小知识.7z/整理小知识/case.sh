#/bin/bash
clear
echo "enter you choose 0-9:"
read chose
case $chose in
   0|o) echo "you choose number is 0"
    ;;  
   1|i|I) echo "you choose number is 1"
    ;;
   2) echo "you choose number is 2"
    ;;
   3) echo "you choose number is 3"
    ;;
   4) echo "you choose number is 4"
    ;;
   5) echo "you choose number is 5"
    ;;
   6) echo "you choose number is 6"
    ;;
   7) echo "you choose number is 7"
    ;;
   8) echo "you choose number is 8"
    ;;
   9) echo "you choose number is 9"
    ;;
   *) echo "you choose number is erro!"
    ;;
esac



