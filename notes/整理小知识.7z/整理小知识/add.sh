#/bin/bash
clear
echo "enter you want print:"
read a

    a=$(($a*$a+1))
 
echo "the output number is: $a"
