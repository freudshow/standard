#/bin/bash
a=1
while :
do
    a=$(($a+1))
    if test $a -gt 255
    then break
    else
    echo "the number of $a computer is "
    ping -c 1 192.168.0.$a
    fi
done
