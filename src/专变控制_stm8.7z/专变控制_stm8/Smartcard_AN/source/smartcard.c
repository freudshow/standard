/* Includes ------------------------------------------------------------------*/
#include "smartcard.h"
#include "stm8s_gpio.h"
#include "stm8s_uart1.h"
#include "stm8s_clk.h"
#include "mysmartcard.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Global variables definition and initialization ----------------------------*/
SC_ATR SC_A2R;
u8 SC_ATR_Table[40];
static u8 SCData = 0;
const u32 F_Table[16] = {0, 372, 558, 744, 1116, 1488, 1860, 0,
                           0, 512, 768, 1024, 1536, 2048, 0, 0};
const u32 D_Table[8] = {0, 1, 2, 4, 8, 16, 0, 0};

extern count;
/* Private function prototypes -----------------------------------------------*/
/* Transport Layer -----------------------------------------------------------*/
/*--------------APDU-----------*/
void SC_SendData(SC_ADPU_Commands *SC_ADPU, SC_ADPU_Responce *SC_ResponceStatus);

/*------------ ATR ------------*/
static void SC_AnswerReq(SC_State *SCState, u8 *card, u8 length);  /* Ask ATR */
static u8 SC_decode_Answer2reset(u8 *card);  /* Decode ATR */

/* Physical Port Layer -------------------------------------------------------*/
static void SC_Init(void);
static void SC_DeInit(void);
static void SC_VoltageConfig(u32 SC_Voltage);
void SC_SendDataCard(u8 SCData);
static u8 SC_Detect(void);
static ErrorStatus UART1_ByteReceive(u8 *Data, u32 TimeOut);

/* Private functions ---------------------------------------------------------*/
extern u8 data_begin_process_ok;
extern u8 mysc_adpu_body_index;
extern @near u8 spi_rx_buf[BUFLEN];
extern u8 spi_rx_head; 
extern u8 spi_rx_tail;
extern void spi_send(u8 c);
extern void spi_rx_init(void);
void MYSC_SendDataCard(u8 SCData);
extern void delay_loop(u16 wt);
extern @near SC_ADPU_Commands MYSC_ADPU;
extern @near SC_ADPU_Responce MYSC_Responce;

/**
  * @brief Handles all Smartcard states and serves to send and receive all
  * communication data between Smartcard and reader.
  * @param[in]
	* - SCState: pointer to an SC_State enumeration that will containthe Smartcard state.
	* - SC_ADPU: pointer to an SC_ADPU_Commands structure that will be initialized.
  * - SC_Response: pointer to a SC_ADPU_Responce structure which will be initialized.
  * @retval
	* None
  */
void SC_Handler(SC_State *SCState, SC_ADPU_Commands *SC_ADPU, SC_ADPU_Responce *SC_Response)
{
    u32 i = 0;

    switch (*SCState)
    {
    case SC_POWER_ON:
        if (SC_ADPU->Header.INS == SC_GET_A2R)
        {

            /* Reset Data from SC buffer -----------------------------------------*/
            for (i = 0; i < 40; i++)
            {
                SC_ATR_Table[i] = (u8)0;
            }

            /* Reset SC_A2R Structure --------------------------------------------*/
            SC_A2R.TS = (u8)0;
            SC_A2R.T0 = (u8)0;
            for (i = 0; i < SETUP_LENGTH; i++)
            {
                SC_A2R.T[i] = (u8)0;
            }
            for (i = 0; i < HIST_LENGTH; i++)
            {
                SC_A2R.H[i] = (u8)0;
            }
            SC_A2R.Tlength = (u8)0;
            SC_A2R.Hlength = (u8)0;

            /* Smartcard intialization ------------------------------------------*/
            SC_Init();
            
            /* Next State --------------------------------------------------------*/
            *SCState = (SC_State)SC_RESET_LOW;
        }
        break;
    case SC_RESET_LOW:
        if (SC_ADPU->Header.INS == SC_GET_A2R)
        {
            /* If card is detected then Power ON, Card Reset and wait for an answer) */
            if (SC_Detect())
            {
                while (((*SCState) != SC_POWER_OFF) && ((*SCState) != SC_ACTIVE))
                {
                    SC_AnswerReq(SCState, &SC_ATR_Table[0],(u8)40); /* Check for answer to reset */
                }
            }
            else
            {
                (*SCState) = (SC_State)SC_POWER_OFF;
            }
        }
        break;

    case SC_ACTIVE:
        if (SC_ADPU->Header.INS == SC_GET_A2R)
        {
            if (SC_decode_Answer2reset(&SC_ATR_Table[0]) == T0_PROTOCOL)
            {
                (*SCState) = (SC_State)SC_ACTIVE_ON_T0;
            }
            else
            {
                (*SCState) = (SC_State)SC_POWER_OFF;
            }
        }
        break;

    case SC_ACTIVE_ON_T0:
        SC_SendData(SC_ADPU, SC_Response);
        break;

    case SC_POWER_OFF:
        SC_DeInit(); /* Disable Smartcard interface */
        break;

    default:
        (*SCState) = (SC_State)SC_POWER_OFF;
    }
}

/**
  * @brief Sets or clears the Smartcard reset pin.
  * @param[in]
	* - ResetState: this parameter specifies the state of the Smartcard reset pin.
	* @retval
	* None
  */

void SC_Reset(BitAction ResetState)
{
    if (ResetState != Bit_RESET)
    {
        GPIO_WriteHigh(GPIOD, SC_RESET);
    }
    else
    {
        GPIO_WriteLow(GPIOD, SC_RESET);
    }
}

/**
  * @brief Resends the byte that failed to be received (by the Smartcard)correctly.
  * @param[in]
	* - None
  * @retval
	* None
  */

void SC_ParityErrorHandler(void)
{
    UART1_SendData9(SCData);
    while (UART1_GetFlagStatus(UART1_FLAG_TC) == RESET)
	  {
		}
}

/**
  * @brief Configures the IO speed (BaudRate) communication.
  * @param[in]
	* - None
  * @retval 
	* None
  */

void SC_PTSConfig(void)
{

    u32 workingbaudrate = 0;
    u32 apbclock = 0;
    u8 locData = 0, PTSConfirmStatus = 1;
    /* Reconfigure the UART1 Baud Rate -------------------------------------------*/
    apbclock = (u32)CLK_GetClockFreq();
    apbclock /= (UART1->PSCR * 2);

    if ((SC_A2R.T0 & (u8)0x10) == (u8)0x10) //have TA
    {
        if (SC_A2R.T[0] != (u8)0x11) //TA
        {
            /* Send PTSS */
            SCData = (u8)0xFF;
            SC_SendDataCard(SCData);

            /* Send PTS0 */
            SCData = (u8)0x10;
            SC_SendDataCard(SCData);

            /* Send PTS1 */
            SCData = SC_A2R.T[0];
            SC_SendDataCard(SCData);

            /* Send PCK */
            SCData = (u8)0xFF^(u8)0x10^(u8)SC_A2R.T[0];
            SC_SendDataCard(SCData);

            /* Flush the UART1 DR */
            (void)UART1_ReceiveData8();

            if ((UART1_ByteReceive(&locData, SC_Receive_Timeout)) == SUCCESS)
            {
                if (locData != (u8)0xFF)
                {
                    PTSConfirmStatus = (u8)0x00;
                }
            }
            if ((UART1_ByteReceive(&locData, SC_Receive_Timeout)) == SUCCESS)
            {
                if (locData != (u8)0x10)
                {
                    PTSConfirmStatus = (u8)0x00;
                }
            }
            if ((UART1_ByteReceive(&locData, SC_Receive_Timeout)) == SUCCESS)
            {
                if (locData != SC_A2R.T[0])
                {
                    PTSConfirmStatus = (u8)0x00;
                }
            }
            if ((UART1_ByteReceive(&locData, SC_Receive_Timeout)) == SUCCESS)
            {
                if (locData != ((u8)0xFF^(u8)0x10^(u8)SC_A2R.T[0]))
                {
                    PTSConfirmStatus = (u8)0x00;
                }
            }
            else
            {
                PTSConfirmStatus = (u8)0x00;
            }
            /* PTS Confirm */
            if (PTSConfirmStatus == (u8)0x01)
            {
                workingbaudrate = apbclock * D_Table[(SC_A2R.T[0] & (u8)0x0F)];
                workingbaudrate /= F_Table[((SC_A2R.T[0] >> 4) & (u8)0x0F)];

                /* UART1 configuration ----------------------------------------------------*/
                /* UART1 configured as follow:
                      - Word Length = 9 Bits
                      - 0.5/1.5 Stop Bit
                      - Even parity
                      - BaudRate = ---- baud
                      - Tx and Rx enabled
                      - UART1 Clock enabled
                */
				UART1_Init((u32)workingbaudrate, UART1_WORDLENGTH_9D, UART1_STOPBITS_1_5, UART1_PARITY_EVEN, UART1_SYNCMODE_CLOCK_ENABLE, UART1_MODE_TXRX_ENABLE);

            }
        }
    }
}

/**
  * @brief Manages the Smartcard transport layer: send APDU commands and receives the APDU responce.
  * @param[in]
  * - SC_ADPU: pointer to a SC_ADPU_Commands structure which will be initialized.
  * - SC_Response: pointer to a SC_ADPU_Responce structure which will be initialized.
  * @retval 
	* None
  */
void SC_SendData(SC_ADPU_Commands *SC_ADPU, SC_ADPU_Responce *SC_ResponceStatus)
{
    u32 i = 0;
    u8 locData = 0;
    /* Reset responce buffer ---------------------------------------------------*/
    for (i = 0; i < LCmax; i++)
    {
        SC_ResponceStatus->Data[i] = (u8)0;
    }

    SC_ResponceStatus->SW1 = (u8)0;
    SC_ResponceStatus->SW2 = (u8)0;

    /* Send header -------------------------------------------------------------*/
    SCData = SC_ADPU->Header.CLA;
    SC_SendDataCard(SCData);
		
    SCData = SC_ADPU->Header.INS;
    SC_SendDataCard(SCData);

    SCData = SC_ADPU->Header.P1;
    SC_SendDataCard(SCData);

    SCData = SC_ADPU->Header.P2;
    SC_SendDataCard(SCData);

    /* Send body length to/from SC ---------------------------------------------*/

    if (SC_ADPU->Body.LC)
    {
        SCData = SC_ADPU->Body.LC;
        SC_SendDataCard(SCData);
    }

    else if (SC_ADPU->Body.LE)
    {
        SCData = SC_ADPU->Body.LE;
        SC_SendDataCard(SCData);
    }
    /* Flush the UART1 DR */
    (void)UART1_ReceiveData8();

    /* --------------------------------------------------------
      Wait Procedure byte from card:
      1 - ACK
      2 - NULL
      3 - SW1; SW2
     -------------------------------------------------------- */

    if ((UART1_ByteReceive(&locData, SC_Receive_Timeout)) == SUCCESS)
    {
        if (((locData & (u8)0xF0) == (u8)0x60) || ((locData & (u8)0xF0) == (u8)0x90))
        {
            /* SW1 received */
            SC_ResponceStatus->SW1 = locData;

            if ((UART1_ByteReceive(&locData, SC_Receive_Timeout)) == SUCCESS)
            {
                /* SW2 received */
                SC_ResponceStatus->SW2 = locData;
            }
        }
        else if (((locData & (u8)0xFE) == (((u8)~(SC_ADPU->Header.INS)) & (u8)0xFE))||((locData & (u8)0xFE) == (SC_ADPU->Header.INS & (u8)0xFE)))
        {
            SC_ResponceStatus->Data[0] = locData;/* ACK received */
        }
    }

    /* If no status bytes received ---------------------------------------------*/
    if (SC_ResponceStatus->SW1 == (u8)0x00)
    {
        /* Send body data to SC--------------------------------------------------*/
        if (SC_ADPU->Body.LC)
        {
            for (i = 0; i < SC_ADPU->Body.LC; i++)
            {
                SCData = SC_ADPU->Body.Data[i];

                SC_SendDataCard(SCData);
            }
            /* Flush the UART1 DR */
            (void)UART1_ReceiveData8();
        }

        /* Or receive body data from SC ------------------------------------------*/
        else if (SC_ADPU->Body.LE)
        {
            for (i = 0; i < SC_ADPU->Body.LE; i++)
            {
                if (UART1_ByteReceive(&locData, SC_Receive_Timeout) == SUCCESS)
                {
                    SC_ResponceStatus->Data[i] = locData;
                }
            }
        }
				
			if(MYSC_ADPU.Header.CLA==0x90 && MYSC_ADPU.Header.INS==0x40)
			{
			 i = 0;
       while (i < 300)
        {
            if (UART1_ByteReceive(&locData, SC_Receive_Timeout) == SUCCESS)
            {
                SC_ResponceStatus->SW1 = locData;
                i = 301;
            }else
            {
                i++;
								if(i==9)
								{
  								UART1_SendData9(0);
									UART1_SendData9(0);
									UART1_SendData9(0);
									UART1_SendData9(0);
									UART1_SendData9(0);	
								}
            }
        }
			}
        /* Wait SW1 --------------------------------------------------------------*/
       i = 0;
       while (i < 300)
        {
					if(i>100)
						delay_loop(0xffff);//40ms
            if (UART1_ByteReceive(&locData, SC_Receive_Timeout) == SUCCESS)
            {
								if(locData == 0x60)  //dealing...
									continue;
                SC_ResponceStatus->SW1 = locData;
                i = 301;
            }
            else
            {
                i++;
								if(MYSC_ADPU.Header.CLA==0x90 && MYSC_ADPU.Header.INS==0x40)
								{
									if(i==9)
									{
										UART1_SendData9(0);
										UART1_SendData9(0);
										UART1_SendData9(0);
										UART1_SendData9(0);
										UART1_SendData9(0);
									}
								}
            }
        }

        /* Wait SW2 ------------------------------------------------------------*/
        i = 0;
        while (i < 300)
        {
						if(i>100)
							delay_loop(0xffff);//40ms
			
            if (UART1_ByteReceive(&locData, SC_Receive_Timeout) == SUCCESS)
            {
							//	if(locData == 0x60)
								//	continue;
                SC_ResponceStatus->SW2 = locData;
                i = 301;
            }
            else
            {
                i++;
								if(MYSC_ADPU.Header.CLA==0x90 && MYSC_ADPU.Header.INS==0x40)
								{
									if(i==9)
									{
										UART1_SendData9(0);
										UART1_SendData9(0);
										UART1_SendData9(0);
										UART1_SendData9(0);
										UART1_SendData9(0);
									}
								}
            }
        }
    }
}
/**
  * @brief Requests the reset answer from card.
  * @param[in]
	* - SCState: pointer to an SC_State enumeration that will contain the Smartcard state.
  *                  - card: pointer to a buffer which will contain the card ATR.
  *                  - length: maximum ATR length
  * @retval 
	* None
  */

static void SC_AnswerReq(SC_State *SCstate, u8 *card, u8 length)
{
    u8 Data = 0;
    u32 i = 0;

    switch (*SCstate)
    {
    case SC_RESET_LOW:
        /* Check responce with reset low ---------------------------------------*/

        for (i = 0; i < length; i++)
        {
            if ((UART1_ByteReceive(&Data, SC_Receive_Timeout)) == SUCCESS)
            {
                card[i] = Data;
            }
        }
        if (card[0])
        {
            (*SCstate) = SC_ACTIVE;
            SC_Reset(Bit_SET);
        }
        else
        {
            (*SCstate) = SC_RESET_HIGH;
        }
        break;

    case SC_RESET_HIGH:
        /* Check responce with reset high --------------------------------------*/
        SC_Reset(Bit_SET); /* Reset High */

        while (length--)
        {
            if ((UART1_ByteReceive(&Data, SC_Receive_Timeout)) == SUCCESS)
            {
                *card++ = Data; /* Receive data for timeout = SC_Receive_Timeout */
            }
        }
        if (card[0])
        {
            (*SCstate) = SC_ACTIVE;
        }
        else
        {
            (*SCstate) = SC_POWER_OFF;
        }
        break;

    case SC_ACTIVE:
        break;

    case SC_POWER_OFF:
        /* Close Connection if no answer received ------------------------------*/
        SC_Reset(Bit_SET); /* reset high - a bit is used as level shifter from 3.3 to 5 V */
        break;

    default:
        (*SCstate) = SC_RESET_LOW;
    }
}
/**
  * @brief Decodes the Answer to reset received from card.
  * @param[in]
	* - Card: pointer to the buffer containing the card ATR.
  * @retval
	* None
  */

static u8 SC_decode_Answer2reset(u8 *card)
{
    u32 i = 0, flag = 0, buf = 0, protocol = 0;

    SC_A2R.TS = card[0];  /* Initial character */
    SC_A2R.T0 = card[1];  /* Format character */

    SC_A2R.Hlength = SC_A2R.T0 & (u8)0x0F;

    if ((SC_A2R.T0 & (u8)0x80) == (u8)0x80)
    {
        flag = 1;
    }

    for (i = 0; i < 4; i++)
    {
        SC_A2R.Tlength = SC_A2R.Tlength + (((SC_A2R.T0 & (u8)0xF0) >> ((u8)4 + i)) & (u8)0x1);
    }

    for (i = 0; i < SC_A2R.Tlength; i++)
    {
        SC_A2R.T[i] = card[i + (u8)2];
    }

    protocol = SC_A2R.T[SC_A2R.Tlength - (u8)1] & (u8)0x0F;

    while (flag)
    {
        if ((SC_A2R.T[SC_A2R.Tlength - (u8)1] & (u8)0x80) == (u8)0x80)
        {
            flag = 1;
        }
        else
        {
            flag = 0;
        }

        buf = SC_A2R.Tlength;
        SC_A2R.Tlength = 0;

        for (i = 0; i < 4; i++)
        {
            SC_A2R.Tlength = SC_A2R.Tlength + (((SC_A2R.T[buf - (u8)1] & (u8)0xF0) >> ((u8)4 + i)) & (u8)0x1);
        }

        for (i = 0;i < SC_A2R.Tlength; i++)
        {
            SC_A2R.T[buf + i] = card[i + (u8)2 + buf];
        }
        SC_A2R.Tlength += (u8)buf;
    }

    for (i = 0; i < SC_A2R.Hlength; i++)
    {
        SC_A2R.H[i] = card[i + (u8)2 + SC_A2R.Tlength];
    }

    return (u8)protocol;
}
/**
  * @brief Initializes all peripheral used for Smartcard interface.
  * @param[in]
	* - None
  * @retval 
	* None
  */

static void SC_Init(void)
{
    u32 i =0;
    u32 workingbaudrate = 2688;//10752;

    /* Set PD5 as Output open-drain high-impedance level - SmartCard_IO(UART1_Tx) */
		GPIO_Init(GPIOD, GPIO_PIN_5, GPIO_MODE_OUT_OD_HIZ_FAST);

    /* Set PA3 as Output push-pull low level - SmartCard_RESET */
		GPIO_Init(GPIOD, GPIO_PIN_3, GPIO_MODE_OUT_PP_LOW_FAST);

    /* Set PD4 as Output push-pull low level - SmartCard_CLK */
		GPIO_Init(GPIOD, GPIO_PIN_4, GPIO_MODE_OUT_PP_LOW_FAST);

    /* Set PG4 as Output push-pull low level - SmartCard_5V/3V */
//		GPIO_Init(GPIOG, GPIO_PIN_4, GPIO_MODE_OUT_PP_LOW_FAST);

    /* Set PG7 as Output push-pull high level (inactive state) - SmartCard_CMDVCC */
//		GPIO_Init(GPIOG, GPIO_PIN_7, GPIO_MODE_OUT_PP_HIGH_FAST);

    /*High speed internal clock prescaler: 1*/
    CLK_SYSCLKConfig(CLK_PRESCALER_HSIDIV1);

    /* Set RSTIN HIGH */
    SC_Reset(Bit_SET);


    /* Select 5 V */
    SC_VoltageConfig(SC_Voltage_5V);

    UART1_DeInit();
    /* UART1 configuration ----------------------------------------------------*/
    /* UART1 configured as follow:
          - Word Length = 9 Bits
          - 0.5/1.5 Stop Bit
          - Even parity
          - BaudRate = 10752 baud
          - Tx and Rx enabled
          - UART1 Clock enabled
    */
    UART1_Init((u32)workingbaudrate, UART1_WORDLENGTH_9D, UART1_STOPBITS_1_5, UART1_PARITY_EVEN, UART1_SYNCMODE_CLOCK_ENABLE, UART1_MODE_TXRX_ENABLE);


    /* UART1 Clock set to 1 MHz (frequencemaster (16 MHZ) / 16) */
    UART1_SetPrescaler(0x08);//0x02

    /* UART1 Guard Time set to 16 Bit */
    UART1_SetGuardTime(0x02);
    /* Enable the UART1 Parity Error Interrupt */
//    UART1_ITConfig(UART1_IT_PE, ENABLE);

    /* Enable UART1 */
    UART1_Cmd(ENABLE);

    /* Enable the NACK Transmission */
    UART1_SmartCardNACKCmd(ENABLE);

    /* Enable the Smartcard Interface */
    UART1_SmartCardCmd(ENABLE);


    /* Set RSTIN HIGH */
    SC_Reset(Bit_RESET);

    for (i = 0; i < 6000; i++)
    {
    }
    /* Set RSTIN HIGH */
    SC_Reset(Bit_SET);
}
/**
  * @brief Deinitializes all ressources used by the Smartcard interface.
  * @param[in]
	* - None
  * @retval 
	* None
  */
static void SC_DeInit(void)
{

    /* Deinitializes the UART1 */
    UART1_DeInit();

    /* Deinitializes the GPIOG */
    GPIO_DeInit(GPIOA);

    /* Deinitializes the GPIOE */
//    GPIO_DeInit(GPIOE);
}

/**
  * @brief Configures the card power voltage.
  * @param[in]
	* - SC_Voltage: specifies the card power voltage.
  *       This parameter can be one of the following values:
  *                        - SC_Voltage_5V: 5V cards.
  *                        - SC_Voltage_3V: 3V cards.
  * @retval 
	* None
  */

static void SC_VoltageConfig(u32 SC_Voltage)
{
    if (SC_Voltage == SC_Voltage_5V)
    {
        /* Select Smartcard 5V */
//        GPIO_WriteHigh(GPIOG, SC_3_5V);
    }
    else
    {
        /* Select Smartcard 3V */
//        GPIO_WriteLow(GPIOG, SC_3_5V);
    }
}
/**
  * @brief Detects whether the Smartcard is present or not.
  * @param[in]
	* - None
  * @retval
	*  0 - Smartcard inserted
  *  1 - Smartcard not inserted
  */
static u8 SC_Detect(void)
{
    u8 bitstatus = 0x01;
    return bitstatus;//linong
#if 0
    if ((GPIOE->IDR & SC_OFF) != (u32)Bit_RESET)
    {
        bitstatus = (u8)Bit_SET;
    }
    else
    {
        bitstatus = (u8)Bit_RESET;
    }
    return bitstatus;
#endif    
}

/**
  * @brief Transmits 9 bit data through the UART1 peripheral and check if the data transmit correctly.
  * @param[in]
	* - SCData: the data to transmit.
  * @retval 
	* None
  */
void SC_SendDataCard(u8 SCData)
{
    UART1_SendData9(SCData);
		
		while (UART1_GetFlagStatus(UART1_FLAG_TC) == RESET)
    {
    }
//delay_loop(1000);
    /* If a Frame error is signaled by the card */
    while (UART1_GetFlagStatus(UART1_FLAG_FE) != RESET)
    {
        /* Clear the UART1 Frame error flags */
				
      UART1_ReceiveData8();
//delay_loop(100);

        /* Resend the byte that failed to be received (by the Smartcard) correctly */
			SC_ParityErrorHandler();
    }

    /* If a Noise error is signaled by the card */
    while (UART1_GetFlagStatus(UART1_FLAG_NF) != RESET)
    {
        /* Clear the UART1 Frame noise flag */
        UART1_ReceiveData8();
    }
    while (UART1_GetFlagStatus(UART1_FLAG_OR) != RESET)
    {
        /* Clear the UART1 Frame error flag */
        UART1_ReceiveData8();
    }
		
}
/**
  * @brief Receives a new data while the time out not elapsed.
  * @param[in]
	* - None
  * @retval
	* - ErrorStatus enumuration value:
  *       SUCCESS: New data has been received
  *       ERROR: time out was elapsed and no further data is received
  */
static ErrorStatus UART1_ByteReceive(u8 *Data, u32 TimeOut)
{
    u32 Counter = 0;

    while ((UART1_GetFlagStatus(UART1_FLAG_RXNE) == RESET) && (Counter != TimeOut))
    {
        Counter++;
    }

    if (Counter != TimeOut)
    {
        *Data = (u8)UART1_ReceiveData8();

        return SUCCESS;
    }
    else
    {
        return ERROR;
    }

}

/******************* (C) COPYRIGHT 2009 STMicroelectronics *****END OF FILE****/
