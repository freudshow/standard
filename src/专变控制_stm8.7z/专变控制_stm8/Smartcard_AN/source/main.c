/**
  ******************************************************************************
  * @file main.c
  * @brief This file contains the main function for UART1 Smartcard Application note.
  * @author STMicroelectronics
  * @version V1.0.2
  * @date 05/06/2009
  *
  * modify by Li Nong
  * 2012-3-23
  * 
  *
  *
  */

/* Includes ------------------------------------------------------------------*/
#include "stm8s.h"
#include "stm8s_conf.h"
#include "def.h"


//u16 TimeAdd;
extern u8  uart_rx_buf[64];
extern u8  uart_rx_head,uart_rx_tail;
u16 rx_data;
#define CODE 		0xa001
u8 crcbuf[6];
extern void Real_USART_Init(void);
extern void Real_UartSendByte(u8 data);

u8  duan_en1,duan_en2;
u16 duanxian1,duanxian2;

void CommDate(void);
/* Private function prototypes -----------------------------------------------*/
/**
  * @brief Programable loop delay
  * @par Parameters:
  * wt: number of loops
  * @retval None
  */
void delay_loop(u16 wt) {
	while(wt--);
}

/*******************************************************************************
  *                         ==ʱ�ӳ�ʼ������==
  * CLK_DeInit();                                   --> ��λʱ�ӼĴ���
  * CLK_HSICmd(ENABLE);                             --> ʹ���ڲ�����ʱ��
  * CLK_HSIPrescalerConfig(CLK_PRESCALER_CPUDIV8); --> �����ڲ�����ʱ��(cpu��Ƶ��Ƶ��:8��Ƶ)
  * CLK_ClockSecuritySystemEnable();                --> ����ʱ�Ӱ�ȫϵͳ
*******************************************************************************/
void CLK_INIT(void)                
{
  CLK_DeInit();
  CLK_HSICmd(ENABLE);
	/*High speed internal clock prescaler: 1*/
	CLK_SYSCLKConfig(CLK_PRESCALER_HSIDIV2);
	
 // CLK_HSIPrescalerConfig(CLK_PRESCALER_CPUDIV1);
  CLK_ClockSecuritySystemEnable();
}
/*******************************************************************************
  *                         ==I/O�ڳ�ʼ������==
  * GPIO_DeInit();                                   --> ��λI/O�˿� D
  * GPIO_Init(GPIOD , GPIO_PIN_0 , GPIO_MODE_OUT_PP_LOW_SLOW);                      
                                                       -->  ʹ��PORTD_0 ����Ϊ ���������ʽ ���͵�ƽ ��������
*******************************************************************************/
void GPIO_INIT(void)
{
  GPIO_DeInit(GPIOC);
  GPIO_Init(GPIOC , GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7 , GPIO_MODE_OUT_PP_LOW_SLOW);
	GPIO_DeInit(GPIOD);
  GPIO_Init(GPIOD , GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_4, GPIO_MODE_OUT_PP_LOW_SLOW);	
	GPIO_DeInit(GPIOA);
  GPIO_Init(GPIOA , GPIO_PIN_1|GPIO_PIN_2, GPIO_MODE_OUT_PP_LOW_SLOW);		
	GPIO_DeInit(GPIOB);
	GPIO_Init(GPIOB , GPIO_PIN_4|GPIO_PIN_5, GPIO_MODE_IN_PU_NO_IT);		//PB4  PB5
	
	
}
/*******************************************************************************
  *                         ==��ʱ��4��ʼ������==
  * TIM4_DeInit();                                   -->  ��λ��ʱ��4�Ĵ���
  * TIM4_TimeBaseInit(TIM4_PRESCALER_64,0x02 );      -->   128��Ƶ �� ����������ֵ
  * TIM4_ITConfig(TIM4_IT_UPDATE, ENABLE);           -->  �ж����� �������ж�ʹ�� ������ж�
  * TIM4_Cmd(ENABLE);                                -->  ��ʱ��4ʹ��
*******************************************************************************/
void TIMER2_INIT(void)
{
  TIM2_DeInit();
  TIM2_TimeBaseInit(TIM2_PRESCALER_32,500);   //1ms==125//4ms==500
  TIM2_ITConfig(TIM2_IT_UPDATE, ENABLE);
  TIM2_Cmd(ENABLE);
  
}
/*******************************************************************************
  *                           ==MAIN ����==
  * ��ʼ�� ʱ��
  * ��ʼ�� �˿�
  * ��ʼ�� ��ʱ��4
  * ʹ��ȫ���ж�
*******************************************************************************/
//extern void testvcom(void);
//extern u8   VCom1RXD(void); 
//extern void RealCommTest(void);
void main(void)
{

    rx_data=0;
		duanxian1=0;
		duanxian2=0;
		duan_en1=1;
		duan_en2=1;
		
	  CLK_INIT();
    GPIO_INIT();
    TIMER2_INIT();
	
	  Real_USART_Init();
    enableInterrupts();
    
  while(1)
	{
	 	
	 CommDate();
	 
	}
}

/***************************************/
typedef unsigned short WORD;
typedef unsigned char  BYTE;
//**************************************//
void ShujuDO(u16 data)
{
	u8 i=0;
	for(i=0;i<10;i++)
	{
	 if((data&(1<<i))!=0)
	 {
		 switch(i)
		 {
			 case 0: GPIO_WriteHigh(GPIOA, GPIO_PIN_2); duan_en1=0;break;  //��һ·ң��
			 case 1: GPIO_WriteHigh(GPIOC, GPIO_PIN_4); break;  //1 �ֺ�
			 case 2: GPIO_WriteHigh(GPIOC, GPIO_PIN_3); break;  //1 ����
			 case 3: GPIO_WriteHigh(GPIOA, GPIO_PIN_1); duan_en2=0;break;  //�ڶ�·ң��
			 case 4: GPIO_WriteHigh(GPIOC, GPIO_PIN_6); break;  //2�ֺ�
			 case 5: GPIO_WriteHigh(GPIOC, GPIO_PIN_5); break;  //2����
			 
			 case 6: GPIO_WriteHigh(GPIOC, GPIO_PIN_7); break;  //GONGKONG ����
			 case 7: GPIO_WriteHigh(GPIOD, GPIO_PIN_2); break;  //DIANKONG ���
			
   		 case 8: GPIO_WriteHigh(GPIOD, GPIO_PIN_4); break;  //�澯
		   case 9: GPIO_WriteHigh(GPIOD, GPIO_PIN_3); break;  //BAODIAN ����

		 }
	 }
	 else
	 {
		 switch(i)
		 {
			 case 0: GPIO_WriteLow(GPIOA, GPIO_PIN_2); duan_en1=1; break;
			 case 1: GPIO_WriteLow(GPIOC, GPIO_PIN_4); break;  //1 red
			 case 2: GPIO_WriteLow(GPIOC, GPIO_PIN_3); break;  //1 green
			 case 3: GPIO_WriteLow(GPIOA, GPIO_PIN_1); duan_en2=1;break;  //
			 case 4: GPIO_WriteLow(GPIOC, GPIO_PIN_6); break;  //2 red
			 case 5: GPIO_WriteLow(GPIOC, GPIO_PIN_5); break;  //2 green
			 
			 case 6: GPIO_WriteLow(GPIOC, GPIO_PIN_7); break;  //GONGKONG 
			 case 7: GPIO_WriteLow(GPIOD, GPIO_PIN_2); break;  //DIANKONG 
			
   		 case 8: GPIO_WriteLow(GPIOD, GPIO_PIN_4); break;  //Gaojing 
		   case 9: GPIO_WriteLow(GPIOD, GPIO_PIN_3); break;  //BAODIAN 
		 }
		 
	 }
	 
  }
	
}
//==========================================
/***********************crc16У��***************************************/
unsigned int CRC(unsigned int Data)

{

	unsigned char n;

	unsigned int Parity;

	Parity=Data;

	for(n=0;n<8;n++)	{

		if ((Parity&0x1)==0x1)	{

			Parity=Parity>>1;
			Parity=Parity^CODE;
		} else {

			Parity=Parity>>1;

		}

	}

	return(Parity);

}
void MakeParity(unsigned char Num)
{
	unsigned int m,Parity=0xffff;
    for (m=0;m<Num;m++)
	{
		Parity=Parity^crcbuf[m];//ǰһ�������һ���������
		Parity=CRC(Parity);                                                                                                                                                             
	}
  crcbuf[Num]=(Parity&0xff00)>>8;
	crcbuf[Num+1]=Parity&0x00ff;
}
//==========================================
void UsartSend(u16 data)
{
	u8 i,tem[7];
	
	
	tem[0]=0x68;
	tem[1]=0x3a;
	tem[2]=(data&0xff00)>>8;
	tem[3]=(data&0xff);
	
	//sum = crcCreate(4,tem,0xFFFF);
	for(i=0;i<4;i++)
		 {
			 crcbuf[i]=tem[i];
		 }		 
		 MakeParity(4);//����crc16�����ֽڷŽ�crcbuf[4]���ֽڷ�crcbuf[5]
	
	tem[4]=crcbuf[4];
	tem[5]=crcbuf[5];
	tem[6]=0x16;
	
	for(i=0;i<7;i++)
	Real_UartSendByte(tem[i]);
	
}

/************************************************************/
void DuanStat(void)
{
		u8 i,tem[7];
	  u8 dtmp1,dtmp2; 
	
	tem[0]=0x68;
	tem[1]=0x9c;
	tem[2]=0;  //���ֽ�
	if(duan_en1)
	{
		if(duanxian1==0xffff)dtmp1=1;//����
		else dtmp1=0;
	}
	if(duan_en2)
	{
		if(duanxian2==0xffff)dtmp2=1;//����
		else dtmp2=0;
	}
	tem[3]=dtmp2*2+dtmp1;
	
	for(i=0;i<4;i++)
		 {
			 crcbuf[i]=tem[i];
		 }		 
		 MakeParity(4);//����crc16�����ֽڷŽ�crcbuf[4]���ֽڷ�crcbuf[5]
	
	tem[4]=crcbuf[4];
	tem[5]=crcbuf[5];
	tem[6]=0x16;
	
	for(i=0;i<7;i++)
	Real_UartSendByte(tem[i]);
	
	
}



/****************************/
void CommDate(void)
{
	u8 temp,i,j;
	//u8 crcbuf[6];
	u16 sum;
	temp = uart_rx_tail;     //�Ҿ�����仰���ԣ�Ӧ����temp=uart_rx_head;
	                         //�������uart_rx_tail���������
													 //����ͷ����uart_rx_head�������
													 //����β�Ļ�������ȷ��
	
	if(((uart_rx_head - uart_rx_tail + 0x40)&0x3f) >= 7) //��  ��  �յ�7���ֽ�
	{
	 if((uart_rx_buf[temp]==0x68)&&(uart_rx_buf[(temp+6)&0x3f]==0x16))//(temp+7)&0x3f
	 {
		 j=temp;
		 for(i=0;i<4;i++)
		 {
			 crcbuf[i]=uart_rx_buf[j];
			 
			 j=(j+1)&0x3f;
		 }		 
		 MakeParity(4);//����crc16�����ֽڷŽ�crcbuf[4]���ֽڷ�crcbuf[5]
	   if((uart_rx_buf[(temp+4)&0x3f]==crcbuf[4])&&(uart_rx_buf[(temp+5)&0x3f]==crcbuf[5]))
       { 
		   
				uart_rx_tail = (uart_rx_tail + 7)&0x3f;  //7 ge bytes suan shi chuli wan bi //����ط�����ҲӦ����uart_rx_head
				switch(uart_rx_buf[(temp+1)&0x3f])
					{
					case 0xa3:
					rx_data = uart_rx_buf[(temp+2)&0x3f];
					rx_data = rx_data * 256 + uart_rx_buf[(temp+3)&0x3f];
					//shi fou bao cun rx_data??
					ShujuDO(rx_data);
					break;
					case 0x3a:
					UsartSend(rx_data);//��������rx_data��
												     //�ǲ���Ӧ�ü���rx_data = uart_rx_buf[(temp+2)&0x3f];
												     //rx_data = rx_data * 256 + uart_rx_buf[(temp+3)&0x3f];
					break;
					case 0x9c:
					DuanStat();
					break;
					default:
					break;				 
					}
			 
			 
				}		 
     
		}
	 else
	 uart_rx_tail=(uart_rx_tail+1)&0x3f;    
  }
	
}











#ifdef USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *   where the assert_param error has occurred.
  * @param file: pointer to the source file name
  * @param line: assert_param error line source number
  * @retval : None
  */
void assert_failed(u8* file, u32 line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif
/**
  * @}
  */

/******************* (C) COPYRIGHT 2009 STMicroelectronics *****END OF FILE****/
