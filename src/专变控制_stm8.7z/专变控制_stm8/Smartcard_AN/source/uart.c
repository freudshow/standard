/**
  ******************************************************************************
  * @file uart.c
  * @brief This file contains all functions for uart control.
  * @author STMicroelectronics - MCD Application Team
  * @version V1.0.0
  * @date 10/13/2008
  ******************************************************************************
  *
  * THE PRESENT SOFTWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH SOFTWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2008 STMicroelectronics</center></h2>
  * @image html logo.bmp
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/


/******************* (C) COPYRIGHT 2008 STMicroelectronics *****END OF FILE****/
#include <string.h>
#include "def.h"
#include "stm8s.h"
#include "stm8s_conf.h"
#include "stm8s_gpio.h"


////////////////////////////////////////////////////////////////////////
////
////��ʵ���ڵĳ�ʼ������
////
////////////////////////////////////////////////////////////////////////
u8  uart_rx_head,uart_rx_tail;
u8  uart_rx_buf[64];

void uart_rx_init(void)
{
	uart_rx_head = uart_rx_tail = 0;
	memset(uart_rx_buf,0,sizeof(uart_rx_buf));
}

void uart_rx_irq_handler(void)
{
	if (UART1_GetITStatus(UART1_IT_RXNE) == SET) {
		UART1_ClearITPendingBit(UART1_IT_RXNE);
		uart_rx_buf[uart_rx_head] = UART1_ReceiveData8();
		uart_rx_head++;
		uart_rx_head &= 0x3f;
	}
}


void Real_UartSendByte(u8 data)
{
	UART1_SendData8(data);
	while(UART1_GetFlagStatus(UART1_FLAG_TXE)==RESET);

}



void Real_USART_Init(void)
{
    uart_rx_init();
    /* Set PD5 as Output open-drain high-impedance level - (UART1_Tx) */
		GPIO_Init(GPIOD, GPIO_PIN_5, GPIO_MODE_OUT_PP_HIGH_FAST); 
		GPIO_Init(GPIOD, GPIO_PIN_6, GPIO_MODE_IN_PU_NO_IT); //(UART1_Rx)

    UART1_DeInit();
    /* UART1 configuration ----------------------------------------------------*/
    /* UART1 configured as follow:
          - Word Length = 9 Bits
          - 0.5/1.5 Stop Bit
          - Even parity
          - BaudRate = 10752 baud
          - Tx and Rx enabled
          - UART1 Clock enabled
    */
    UART1_Init((u32)19200, UART1_WORDLENGTH_9D, UART1_STOPBITS_1, UART1_PARITY_EVEN,   UART1_SYNCMODE_CLOCK_DISABLE, UART1_MODE_TXRX_ENABLE);

    /* Enable the UART1 Parity Error Interrupt */
   UART1_ITConfig(UART1_IT_RXNE, ENABLE);

    /* Enable UART1 */
    UART1_Cmd(ENABLE);
}




