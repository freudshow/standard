/**
  ******************************************************************************
  * @file spi.c
  * @brief This file contains all functions for spi control.
  * @author STMicroelectronics - MCD Application Team
  * @version V1.0.0
  * @date 10/13/2008
  ******************************************************************************
  *
  * THE PRESENT SOFTWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH SOFTWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2008 STMicroelectronics</center></h2>
  * @image html logo.bmp
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/

#include "stm8s.h"
#include "stm8s_spi.h"
#include "smartcard.h"
#include "mysmartcard.h"
u8 spi_rx_begin[3],spi_rx_begin_index,spi_rx_begin_ok, spi_tx_begin_ok;//���Ŀ�ͷ3��fe
u8 data_begin_process_ok; //���ݿ�ʼ������־ main��MYSC_SendData
u32 spi_rx_index,spi_rx_len;
u8 mysc_adpu_body_index;
extern @near SC_ADPU_Commands MYSC_ADPU;
extern @near SC_ADPU_Responce MYSC_Responce;
extern u32 spi_tx_begin_ok_num;
u8 ef_num;
u32 spi_tx_index;
u8 count=0;
void spi_tx_init(void)
{
	spi_tx_begin_ok = 0;
	spi_tx_index = 0;
}

//˼·��fe fe fe len [spi_data] ���ж�fe fe feȻ���ж�����
//�ı��ĳ���len
void spi_rx_init(void)
{
	spi_rx_len = 0;
	spi_rx_index = 0;	
	data_begin_process_ok = 0;
	spi_rx_begin_ok = 0;
}

void spi_rx_head_init(void)
{
	u8 i;
	for(i=0; i<3; i++)
		spi_rx_begin[i] = 0xff;
	spi_rx_begin_index = 0;
}
void spi_send(u8 c)
{
		//if (uart_rx_head != uart_rx_tail) {
			//SPI_SendData(uart_rx_buf[uart_rx_tail]);
			SPI_SendData(c);
			//uart_rx_tail++;
		//	uart_rx_tail &= 15;
    	//}
}
void spi_irq_handler(void)
{
	//MYPB5=GPIO_ReadInputPin(GPIOB,  GPIO_PIN_5);
	u8 spi_rx_c;
	u32 i = 0;
	if (SPI_GetITStatus(SPI_IT_RXNE) == SET) 
	{
		SPI_ClearFlag(SPI_IT_RXNE);
		spi_rx_c = SPI_ReceiveData();

		// spi recv head deal: fe fe fe
		if(spi_rx_begin[0]==0xfe && 
				spi_rx_begin[1]==0xfe && 
				spi_rx_begin[2]==0xfe)
		{//�ж�ʱ���б���ͷ ��3��fe
			spi_rx_begin_ok = 1;
			spi_rx_len = spi_rx_c;
			if(spi_rx_begin_index == 0x03)
				spi_rx_head_init();
			return;
		}
		//spi����
		if(spi_rx_begin_ok == 1)
		{
			if(spi_rx_index == 0)
					MYSC_ADPU.Header.CLA = spi_rx_c;
			if(spi_rx_index == 1)
					MYSC_ADPU.Header.INS = spi_rx_c;
			if(spi_rx_index == 2)
					MYSC_ADPU.Header.P1 = spi_rx_c;
			if(spi_rx_index == 3)
					MYSC_ADPU.Header.P2 = spi_rx_c;
			if(spi_rx_index == 4)
			{
				if(MYSC_ADPU.Header.INS == 0xc0 || 
						MYSC_ADPU.Header.INS == 0x84	||
						MYSC_ADPU.Header.INS == 0xB0)
					{
						MYSC_ADPU.Body.LC = 0;
						MYSC_ADPU.Body.LE = spi_rx_c;
					}
				else
					{
						MYSC_ADPU.Body.LE = 0;
						MYSC_ADPU.Body.LC = spi_rx_c;
					}
			}
			if(spi_rx_index >= 5)//���body���׵�ַ
			{
				MYSC_ADPU.Body.Data[spi_rx_index-5] = spi_rx_c; 
			}
			spi_rx_index++;
			
			if(spi_rx_index >= spi_rx_len && spi_rx_index!=0)
			{
				spi_rx_index = 0;
				spi_rx_len= 0;
				spi_rx_begin_ok = 0;
				data_begin_process_ok = 1;
				spi_rx_begin[0]=0xff;
				spi_rx_begin[1]=0xff;
				spi_rx_begin[2]=0xff;
				//for(i=0;i<BUFLEN; i++)
				//	spi_rx_buf[i]=0xff;
			}
		}else
		{
			if(spi_rx_c == 0xfe)
			{
				spi_rx_begin[spi_rx_begin_index] = 0xfe;
				spi_rx_begin_index++;
			}
			else
				spi_rx_head_init();
		}		
		
		if(spi_tx_begin_ok == 1)
		{
			//���ʹ���  spi_tx_index
			if(spi_tx_begin_ok_num == 1)
				ef_num = 3;
			else
				ef_num = 4;
			if(spi_tx_index < ef_num)
				SPI_SendData(0xef);
			if(spi_tx_index == ef_num)
				SPI_SendData(MYSC_ADPU.Body.LE + 2); //sw1 sw2
			if (MYSC_ADPU.Body.LE)
			{
				if(spi_tx_index < MYSC_ADPU.Body.LE + ef_num + 1  && spi_tx_index >= ef_num + 1)
				{
					SPI_SendData(MYSC_Responce.Data[spi_tx_index-ef_num - 1]);
					//SPI_SendData(spi_tx_index);
				}
			}
			
			if(spi_tx_index == MYSC_ADPU.Body.LE + ef_num + 1)
				SPI_SendData(MYSC_Responce.SW1);
				//SPI_SendData(spi_tx_index);
			if(spi_tx_index == MYSC_ADPU.Body.LE + 1 + ef_num + 1)
				SPI_SendData(MYSC_Responce.SW2);
				//SPI_SendData(spi_tx_index);
			
			if(spi_tx_index > MYSC_ADPU.Body.LE + ef_num + 2 && spi_tx_index != 0)
			{
				count++;
				spi_tx_index = 0;
				spi_tx_begin_ok = 0;
				//if(count==1)
				/*
				{
					MYSC_ADPU.Header.CLA = 0;
					MYSC_ADPU.Header.INS = 0;
					MYSC_ADPU.Header.P1 = 0;
					MYSC_ADPU.Header.P2 = 0;
					MYSC_ADPU.Body.LC = 0;
					MYSC_ADPU.Body.LE = 0;
					for(i=0; i<LCmax; i++)
						MYSC_ADPU.Body.Data[i] = 0;
					
					for(i=0; i<LCmax; i++)
						MYSC_Responce.Data[i] = 0;				
					MYSC_Responce.SW1 = 0;
					MYSC_Responce.SW2 = 0;
				}*/
			}
			spi_tx_index++;			
		}
	}
}
/******************* (C) COPYRIGHT 2008 STMicroelectronics *****END OF FILE****/
