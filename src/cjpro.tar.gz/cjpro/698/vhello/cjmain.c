﻿#include <stdlib.h>
#include <stdio.h>
#include <StdDataType.h>

int main(int argc, char *argv[])
{
	INT8U	u8;
	INT16U	u16 = 0xabcd;

	u8 = u16;
	fprintf(stderr, "%02X\n", u8);
	fprintf(stderr, "hello world\n");
	return EXIT_SUCCESS;//退出
}
