#ifndef CJMAIN_H_
#define CJMAIN_H_

#include "PublicFunction.h"

ProgramInfo* JProgramInfo=NULL;
int ProIndex=0;

extern void DealState(ProgramInfo* prginfo);
extern void read_oif203_para();
#endif
