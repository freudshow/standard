#ifndef CJMAIN_H_
#define CJMAIN_H_

#include <stdlib.h>
#include <stdio.h>
#include <sys/mman.h>
#include <string.h>
#include <fcntl.h>
#include "PublicFunction.h"

ProgramInfo* JProgramInfo=NULL;

extern void InitClass4300();

#endif
