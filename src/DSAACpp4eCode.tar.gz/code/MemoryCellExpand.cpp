#include "MemoryCell.cpp"
#include <string>
using std::string;

template class MemoryCell<int>;
template class MemoryCell<string>;
