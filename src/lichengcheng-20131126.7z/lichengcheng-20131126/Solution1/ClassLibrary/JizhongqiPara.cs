﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassLibrary
{
    public  class JizhongqiPara
    {
        #region 属性设置
        public int Id
        {
            get { return this.Id; }
            set { this.Id = value; }
        }
        public char[] IdAdr{
            get { return this.IdAdr; }
            set { this.IdAdr = value; }
        }
        public bool IsReg {
            get { return this.IsReg; }
            set { this.IsReg = value; }
            
        }
        public bool IsPara
        {
            get { return this.IsPara; }
            set { this.IsPara = value; }

        }
        public bool IsZB
        {
            get { return this.IsZB; }
            set { this.IsZB = value; }

        }
        public bool Is485I
        {
            get { return this.Is485I; }
            set { this.Is485I = value; }

        }
        public bool Is485II
        {
            get { return this.Is485II; }
            set { this.Is485II = value; }

        }

        public bool IsOnLine
        {
            get { return this.IsOnLine; }
            set { this.IsOnLine = value; }

        }
        public bool IsESAM
        {
            get { return this.IsESAM; }
            set { this.IsESAM = value; }

        }
        public bool IsYaoX
        {
            get { return this.IsYaoX; }
            set { this.IsYaoX = value; }

        }
        #endregion


    }
}
