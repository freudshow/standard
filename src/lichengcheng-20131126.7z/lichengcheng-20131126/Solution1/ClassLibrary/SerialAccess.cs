﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO.Ports;
using System.Threading;

namespace ClassLibrary
{
  public  class SerialAccess
    {
        /// <summary>
        /// 返回一个串口连接对象
        /// </summary>
        /// <returns>串口连接对象</returns>
      //private static SerialPort GetCom()
      //{
      //    SerialPort com = new SerialPort(GetConnString());
      //    return com;
      //}
     
      //private static string GetConnString()
      //{
          
      //    //return Connstr;
      //}
        // 定义SerialPort类实例

        //private SerialPort SpCom2 = new SpCom("COM2", 9600, Parity.None, 8, StopBits.One);

        //SerialPort SpCom = new SerialPort();


        //设置通讯端口号及波特率、数据位、停止位和校验位。

        //SpCom.PortName = "COM1";

        //SpCom.BaudRate = 9600;

        //SpCom.Parity = IO.Ports.Parity.None;

        //SpCom.DataBits = 8;

        //SpCom.StopBits = IO.Ports.StopBits.One;

        //        或是定义时直接初始化

        //         private SerialPort SpCom2 = new SpCom ("COM2", 9600,Parity.None, 8, StopBits.One);

        //4)         发送数据

        //     SpCom.Write(TextSendData.Text);

        //5)         添加接受事件

        //a)        在运行时将事件与事件处理程序相关联（通过委托实现）

        //SpCom.DataReceived += new SerialDataReceivedEventHandler(SpCom2_DataReceived);

        //说明：

        //SerialDataReceivedEventHandler 委托 表示将处理 SerialPort 对象的 DataReceived 事件的方法

        //b)        添加事件处理程序（签名一定要一致）

        //              private void SpCom_DataReceived(object sender, SerialDataReceivedEventArgs e)

        //6)         读取数据

        //        string data = SpCom .ReadExisting();


        //Thread _readThread;
       
        //bool _keepReading;
        
        
        #region 读取串口
      private void ReadPort(SerialPort SpCom, bool _keepReading)
        {
            //SerialPort SpCom = new SerialPort();
            while (_keepReading)
            {
                if (SpCom.IsOpen)
                {
                    byte[] readBuffer = new byte[SpCom.ReadBufferSize + 1];
                    try
                    {

                        int count = SpCom.Read(readBuffer, 0, SpCom.ReadBufferSize);
                        String SerialIn = System.Text.Encoding.ASCII.GetString(readBuffer, 0, count);
                        //if (count != 0)
                        //    byteToHexStr(readBuffer);   
                        //Thread(byteToHexStr(readBuffer, count));
                    }
                    catch (TimeoutException)
                    {
                    }
                }
                else
                {
                    TimeSpan waitTime = new TimeSpan(0, 0, 0, 0, 50);
                    Thread.Sleep(waitTime);
                }
            }
        }
        #endregion


    }
}
