﻿namespace Demo_Error
{
    partial class Demo_Error
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
            
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.RadBtn_Mult = new System.Windows.Forms.RadioButton();
            this.RadBtn_WVar = new System.Windows.Forms.RadioButton();
            this.RadBtn_Standard = new System.Windows.Forms.RadioButton();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.Btn_Stop = new System.Windows.Forms.Button();
            this.Btn_Start = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.Cbo_I_2 = new System.Windows.Forms.ComboBox();
            this.Cbo_I_1 = new System.Windows.Forms.ComboBox();
            this.Cbo_U_2 = new System.Windows.Forms.ComboBox();
            this.Cbo_U_1 = new System.Windows.Forms.ComboBox();
            this.Cbo_I = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Cbo_U = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.ListData = new System.Windows.Forms.ListBox();
            this.groupBox1.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.groupBox7);
            this.groupBox1.Controls.Add(this.groupBox6);
            this.groupBox1.Controls.Add(this.Btn_Stop);
            this.groupBox1.Controls.Add(this.Btn_Start);
            this.groupBox1.Controls.Add(this.groupBox4);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Location = new System.Drawing.Point(3, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(530, 178);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "测试流程中被检表设置";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(433, 142);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(61, 25);
            this.button1.TabIndex = 7;
            this.button1.Text = "读取误差";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.RadBtn_Mult);
            this.groupBox7.Controls.Add(this.RadBtn_WVar);
            this.groupBox7.Controls.Add(this.RadBtn_Standard);
            this.groupBox7.Location = new System.Drawing.Point(221, 70);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(175, 90);
            this.groupBox7.TabIndex = 6;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "脉冲通道切换";
            // 
            // RadBtn_Mult
            // 
            this.RadBtn_Mult.AutoSize = true;
            this.RadBtn_Mult.Location = new System.Drawing.Point(12, 60);
            this.RadBtn_Mult.Name = "RadBtn_Mult";
            this.RadBtn_Mult.Size = new System.Drawing.Size(155, 16);
            this.RadBtn_Mult.TabIndex = 2;
            this.RadBtn_Mult.TabStop = true;
            this.RadBtn_Mult.Text = "Usb(或7星)多功能脉冲线";
            this.RadBtn_Mult.UseVisualStyleBackColor = true;
            // 
            // RadBtn_WVar
            // 
            this.RadBtn_WVar.AutoSize = true;
            this.RadBtn_WVar.Location = new System.Drawing.Point(12, 38);
            this.RadBtn_WVar.Name = "RadBtn_WVar";
            this.RadBtn_WVar.Size = new System.Drawing.Size(161, 16);
            this.RadBtn_WVar.TabIndex = 1;
            this.RadBtn_WVar.TabStop = true;
            this.RadBtn_WVar.Text = "带有无功切换的5星脉冲线";
            this.RadBtn_WVar.UseVisualStyleBackColor = true;
            // 
            // RadBtn_Standard
            // 
            this.RadBtn_Standard.AutoSize = true;
            this.RadBtn_Standard.Checked = true;
            this.RadBtn_Standard.Location = new System.Drawing.Point(12, 17);
            this.RadBtn_Standard.Name = "RadBtn_Standard";
            this.RadBtn_Standard.Size = new System.Drawing.Size(101, 16);
            this.RadBtn_Standard.TabIndex = 0;
            this.RadBtn_Standard.TabStop = true;
            this.RadBtn_Standard.Text = "普通5星脉冲线";
            this.RadBtn_Standard.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.comboBox3);
            this.groupBox6.Location = new System.Drawing.Point(401, 70);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(121, 41);
            this.groupBox6.TabIndex = 5;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "电表测试状态";
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "正向有功",
            "正向无功",
            "反向有功",
            "反向无功"});
            this.comboBox3.Location = new System.Drawing.Point(9, 16);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(106, 20);
            this.comboBox3.TabIndex = 0;
            this.comboBox3.Text = "正向有功";
            // 
            // Btn_Stop
            // 
            this.Btn_Stop.Location = new System.Drawing.Point(461, 113);
            this.Btn_Stop.Name = "Btn_Stop";
            this.Btn_Stop.Size = new System.Drawing.Size(61, 25);
            this.Btn_Stop.TabIndex = 4;
            this.Btn_Stop.Text = "测试停止";
            this.Btn_Stop.UseVisualStyleBackColor = true;
            // 
            // Btn_Start
            // 
            this.Btn_Start.Location = new System.Drawing.Point(401, 113);
            this.Btn_Start.Name = "Btn_Start";
            this.Btn_Start.Size = new System.Drawing.Size(61, 25);
            this.Btn_Start.TabIndex = 3;
            this.Btn_Start.Text = "测试开始";
            this.Btn_Start.UseVisualStyleBackColor = true;
            this.Btn_Start.Click += new System.EventHandler(this.Btn_Start_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.comboBox2);
            this.groupBox4.Controls.Add(this.comboBox1);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Location = new System.Drawing.Point(313, 20);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(211, 44);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "误差测试圈数及采样次数设置";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "1",
            "2",
            "4"});
            this.comboBox2.Location = new System.Drawing.Point(161, 17);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(42, 20);
            this.comboBox2.TabIndex = 3;
            this.comboBox2.Text = "2";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "1",
            "2",
            "4",
            "6",
            "8"});
            this.comboBox1.Location = new System.Drawing.Point(70, 17);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(33, 20);
            this.comboBox1.TabIndex = 2;
            this.comboBox1.Text = "4";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(109, 22);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 1;
            this.label4.Text = "采样次数";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 0;
            this.label3.Text = "测试圈数";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.Cbo_I_2);
            this.groupBox3.Controls.Add(this.Cbo_I_1);
            this.groupBox3.Controls.Add(this.Cbo_U_2);
            this.groupBox3.Controls.Add(this.Cbo_U_1);
            this.groupBox3.Controls.Add(this.Cbo_I);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.Cbo_U);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Location = new System.Drawing.Point(9, 70);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(206, 89);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "误差负载点设置(%)";
            // 
            // Cbo_I_2
            // 
            this.Cbo_I_2.Enabled = false;
            this.Cbo_I_2.FormattingEnabled = true;
            this.Cbo_I_2.Items.AddRange(new object[] {
            "1",
            "2",
            "5",
            "10",
            "20",
            "50",
            "100",
            "200"});
            this.Cbo_I_2.Location = new System.Drawing.Point(157, 58);
            this.Cbo_I_2.Name = "Cbo_I_2";
            this.Cbo_I_2.Size = new System.Drawing.Size(43, 20);
            this.Cbo_I_2.TabIndex = 7;
            this.Cbo_I_2.Text = "100";
            // 
            // Cbo_I_1
            // 
            this.Cbo_I_1.Enabled = false;
            this.Cbo_I_1.FormattingEnabled = true;
            this.Cbo_I_1.Items.AddRange(new object[] {
            "1",
            "2",
            "5",
            "10",
            "20",
            "50",
            "100",
            "200"});
            this.Cbo_I_1.Location = new System.Drawing.Point(108, 58);
            this.Cbo_I_1.Name = "Cbo_I_1";
            this.Cbo_I_1.Size = new System.Drawing.Size(43, 20);
            this.Cbo_I_1.TabIndex = 6;
            this.Cbo_I_1.Text = "100";
            // 
            // Cbo_U_2
            // 
            this.Cbo_U_2.Enabled = false;
            this.Cbo_U_2.FormattingEnabled = true;
            this.Cbo_U_2.Items.AddRange(new object[] {
            "80",
            "90",
            "100",
            "110",
            "120"});
            this.Cbo_U_2.Location = new System.Drawing.Point(157, 27);
            this.Cbo_U_2.Name = "Cbo_U_2";
            this.Cbo_U_2.Size = new System.Drawing.Size(43, 20);
            this.Cbo_U_2.TabIndex = 5;
            this.Cbo_U_2.Text = "100";
            // 
            // Cbo_U_1
            // 
            this.Cbo_U_1.Enabled = false;
            this.Cbo_U_1.FormattingEnabled = true;
            this.Cbo_U_1.Items.AddRange(new object[] {
            "80",
            "90",
            "100",
            "110",
            "120"});
            this.Cbo_U_1.Location = new System.Drawing.Point(108, 27);
            this.Cbo_U_1.Name = "Cbo_U_1";
            this.Cbo_U_1.Size = new System.Drawing.Size(43, 20);
            this.Cbo_U_1.TabIndex = 4;
            this.Cbo_U_1.Text = "100";
            // 
            // Cbo_I
            // 
            this.Cbo_I.FormattingEnabled = true;
            this.Cbo_I.Items.AddRange(new object[] {
            "1",
            "2",
            "5",
            "10",
            "20",
            "50",
            "100",
            "200"});
            this.Cbo_I.Location = new System.Drawing.Point(59, 58);
            this.Cbo_I.Name = "Cbo_I";
            this.Cbo_I.Size = new System.Drawing.Size(43, 20);
            this.Cbo_I.TabIndex = 3;
            this.Cbo_I.Text = "100";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "电流负载";
            // 
            // Cbo_U
            // 
            this.Cbo_U.FormattingEnabled = true;
            this.Cbo_U.Items.AddRange(new object[] {
            "80",
            "90",
            "100",
            "110",
            "120"});
            this.Cbo_U.Location = new System.Drawing.Point(59, 27);
            this.Cbo_U.Name = "Cbo_U";
            this.Cbo_U.Size = new System.Drawing.Size(43, 20);
            this.Cbo_U.TabIndex = 1;
            this.Cbo_U.Text = "100";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "电压负载";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radioButton5);
            this.groupBox2.Controls.Add(this.radioButton4);
            this.groupBox2.Controls.Add(this.radioButton3);
            this.groupBox2.Controls.Add(this.radioButton2);
            this.groupBox2.Controls.Add(this.radioButton1);
            this.groupBox2.Location = new System.Drawing.Point(9, 20);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(298, 44);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "相别设置";
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Enabled = false;
            this.radioButton5.Location = new System.Drawing.Point(8, 20);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(59, 16);
            this.radioButton5.TabIndex = 4;
            this.radioButton5.Text = "不平衡";
            this.radioButton5.UseVisualStyleBackColor = true;
            this.radioButton5.CheckedChanged += new System.EventHandler(this.radioButton5_CheckedChanged);
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(239, 20);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(53, 16);
            this.radioButton4.TabIndex = 3;
            this.radioButton4.Text = "分元C";
            this.radioButton4.UseVisualStyleBackColor = true;
            this.radioButton4.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(180, 20);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(53, 16);
            this.radioButton3.TabIndex = 2;
            this.radioButton3.Text = "分元B";
            this.radioButton3.UseVisualStyleBackColor = true;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(121, 20);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(53, 16);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.Text = "分元A";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Location = new System.Drawing.Point(68, 20);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(47, 16);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "合元";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.ListData);
            this.groupBox5.Location = new System.Drawing.Point(3, 186);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(530, 146);
            this.groupBox5.TabIndex = 2;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "误差显示界面";
            // 
            // ListData
            // 
            this.ListData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ListData.FormattingEnabled = true;
            this.ListData.ItemHeight = 12;
            this.ListData.Location = new System.Drawing.Point(3, 17);
            this.ListData.Name = "ListData";
            this.ListData.Size = new System.Drawing.Size(524, 124);
            this.ListData.TabIndex = 0;
            // 
            // Demo_Error
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(535, 333);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox1);
            this.Name = "Demo_Error";
            this.Text = "测试误差流程";
            this.Load += new System.EventHandler(this.Demo_Error_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.ComboBox Cbo_I;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox Cbo_U;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button Btn_Stop;
        private System.Windows.Forms.Button Btn_Start;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.RadioButton RadBtn_Mult;
        private System.Windows.Forms.RadioButton RadBtn_WVar;
        private System.Windows.Forms.RadioButton RadBtn_Standard;
        private System.Windows.Forms.ListBox ListData;
        private System.Windows.Forms.ComboBox Cbo_I_2;
        private System.Windows.Forms.ComboBox Cbo_I_1;
        private System.Windows.Forms.ComboBox Cbo_U_2;
        private System.Windows.Forms.ComboBox Cbo_U_1;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.Button button1;

    }
}