﻿namespace Demo_CNet_DLL7000
{
    partial class Demo_CNet_DLL7000
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.Cbo_AdjustTime = new System.Windows.Forms.ComboBox();
            this.Cbo_SteadyTime = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.Cbo_Port = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.Grp_Test = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.Btn_TestCom485 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.Btn_TestError = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.Btn_SetPar = new System.Windows.Forms.Button();
            this.MeterTree = new System.Windows.Forms.TreeView();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.Cbo_GL = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.Cbo_Class_Var = new System.Windows.Forms.ComboBox();
            this.Cbo_Class_Watt = new System.Windows.Forms.ComboBox();
            this.Cbo_Const_Var = new System.Windows.Forms.ComboBox();
            this.Cbo_Const_Watt = new System.Windows.Forms.ComboBox();
            this.Cbo_Fre = new System.Windows.Forms.ComboBox();
            this.Cbo_MaxCurrent = new System.Windows.Forms.ComboBox();
            this.Cbo_Current = new System.Windows.Forms.ComboBox();
            this.Cbo_Voltage = new System.Windows.Forms.ComboBox();
            this.Cbo_Phase = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lab_U = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.RadBtn_Dsp = new System.Windows.Forms.RadioButton();
            this.RadBtn_D = new System.Windows.Forms.RadioButton();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.Grp_Test.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.groupBox6);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.groupBox7);
            this.groupBox1.Controls.Add(this.Grp_Test);
            this.groupBox1.Controls.Add(this.groupBox5);
            this.groupBox1.Controls.Add(this.MeterTree);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Location = new System.Drawing.Point(3, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(564, 419);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "动态库控制函数调用";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(469, 260);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(73, 31);
            this.button2.TabIndex = 5;
            this.button2.Text = "打开串口";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.Cbo_AdjustTime);
            this.groupBox7.Controls.Add(this.Cbo_SteadyTime);
            this.groupBox7.Controls.Add(this.label11);
            this.groupBox7.Controls.Add(this.label10);
            this.groupBox7.Controls.Add(this.Cbo_Port);
            this.groupBox7.Controls.Add(this.label9);
            this.groupBox7.Location = new System.Drawing.Point(387, 12);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(168, 91);
            this.groupBox7.TabIndex = 4;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "串口及通讯延时设置";
            // 
            // Cbo_AdjustTime
            // 
            this.Cbo_AdjustTime.FormattingEnabled = true;
            this.Cbo_AdjustTime.Items.AddRange(new object[] {
            "5",
            "6",
            "7"});
            this.Cbo_AdjustTime.Location = new System.Drawing.Point(71, 63);
            this.Cbo_AdjustTime.Name = "Cbo_AdjustTime";
            this.Cbo_AdjustTime.Size = new System.Drawing.Size(84, 20);
            this.Cbo_AdjustTime.TabIndex = 5;
            this.Cbo_AdjustTime.Text = "6";
            // 
            // Cbo_SteadyTime
            // 
            this.Cbo_SteadyTime.FormattingEnabled = true;
            this.Cbo_SteadyTime.Items.AddRange(new object[] {
            "8",
            "9",
            "10"});
            this.Cbo_SteadyTime.Location = new System.Drawing.Point(71, 39);
            this.Cbo_SteadyTime.Name = "Cbo_SteadyTime";
            this.Cbo_SteadyTime.Size = new System.Drawing.Size(84, 20);
            this.Cbo_SteadyTime.TabIndex = 4;
            this.Cbo_SteadyTime.Text = "8";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(10, 68);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 12);
            this.label11.TabIndex = 3;
            this.label11.Text = "调整延时";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(10, 45);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 12);
            this.label10.TabIndex = 2;
            this.label10.Text = "升源延时";
            // 
            // Cbo_Port
            // 
            this.Cbo_Port.FormattingEnabled = true;
            this.Cbo_Port.Items.AddRange(new object[] {
            "COM1",
            "COM2",
            "COM3",
            "COM4",
            "COM5",
            "COM6",
            "COM7",
            "COM8"});
            this.Cbo_Port.Location = new System.Drawing.Point(71, 16);
            this.Cbo_Port.Name = "Cbo_Port";
            this.Cbo_Port.Size = new System.Drawing.Size(84, 20);
            this.Cbo_Port.TabIndex = 1;
            this.Cbo_Port.Text = "COM1";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(10, 22);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 12);
            this.label9.TabIndex = 0;
            this.label9.Text = "串口设置";
            // 
            // Grp_Test
            // 
            this.Grp_Test.Controls.Add(this.button3);
            this.Grp_Test.Controls.Add(this.Btn_TestCom485);
            this.Grp_Test.Controls.Add(this.button1);
            this.Grp_Test.Controls.Add(this.Btn_TestError);
            this.Grp_Test.Enabled = false;
            this.Grp_Test.Location = new System.Drawing.Point(387, 106);
            this.Grp_Test.Name = "Grp_Test";
            this.Grp_Test.Size = new System.Drawing.Size(169, 155);
            this.Grp_Test.TabIndex = 3;
            this.Grp_Test.TabStop = false;
            this.Grp_Test.Text = "调用动态实现的流程";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(17, 121);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(137, 31);
            this.button3.TabIndex = 3;
            this.button3.Text = "动态库函数调用";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Btn_TestCom485
            // 
            this.Btn_TestCom485.Location = new System.Drawing.Point(17, 87);
            this.Btn_TestCom485.Name = "Btn_TestCom485";
            this.Btn_TestCom485.Size = new System.Drawing.Size(137, 31);
            this.Btn_TestCom485.TabIndex = 2;
            this.Btn_TestCom485.Text = "测试校表流程";
            this.Btn_TestCom485.UseVisualStyleBackColor = true;
            this.Btn_TestCom485.Click += new System.EventHandler(this.Btn_TestCom485_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(17, 53);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(137, 31);
            this.button1.TabIndex = 1;
            this.button1.Text = "测试秒脉冲流程";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // Btn_TestError
            // 
            this.Btn_TestError.Location = new System.Drawing.Point(17, 19);
            this.Btn_TestError.Name = "Btn_TestError";
            this.Btn_TestError.Size = new System.Drawing.Size(137, 31);
            this.Btn_TestError.TabIndex = 0;
            this.Btn_TestError.Text = "测试误差流程";
            this.Btn_TestError.UseVisualStyleBackColor = true;
            this.Btn_TestError.Click += new System.EventHandler(this.Btn_TestError_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.Btn_SetPar);
            this.groupBox5.Location = new System.Drawing.Point(146, 371);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(235, 43);
            this.groupBox5.TabIndex = 2;
            this.groupBox5.TabStop = false;
            // 
            // Btn_SetPar
            // 
            this.Btn_SetPar.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Btn_SetPar.Location = new System.Drawing.Point(17, 11);
            this.Btn_SetPar.Name = "Btn_SetPar";
            this.Btn_SetPar.Size = new System.Drawing.Size(206, 30);
            this.Btn_SetPar.TabIndex = 0;
            this.Btn_SetPar.Text = "参数设置完成";
            this.Btn_SetPar.UseVisualStyleBackColor = true;
            this.Btn_SetPar.Click += new System.EventHandler(this.btn_SetPar_Click);
            // 
            // MeterTree
            // 
            this.MeterTree.CheckBoxes = true;
            this.MeterTree.Location = new System.Drawing.Point(6, 18);
            this.MeterTree.Name = "MeterTree";
            this.MeterTree.Size = new System.Drawing.Size(134, 394);
            this.MeterTree.TabIndex = 1;
            this.MeterTree.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.MeterTree_AfterSelect);
            this.MeterTree.Click += new System.EventHandler(this.MeterTree_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.groupBox4);
            this.groupBox2.Controls.Add(this.groupBox3);
            this.groupBox2.Location = new System.Drawing.Point(146, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(235, 356);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "参数设置";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.Cbo_GL);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.Cbo_Class_Var);
            this.groupBox4.Controls.Add(this.Cbo_Class_Watt);
            this.groupBox4.Controls.Add(this.Cbo_Const_Var);
            this.groupBox4.Controls.Add(this.Cbo_Const_Watt);
            this.groupBox4.Controls.Add(this.Cbo_Fre);
            this.groupBox4.Controls.Add(this.Cbo_MaxCurrent);
            this.groupBox4.Controls.Add(this.Cbo_Current);
            this.groupBox4.Controls.Add(this.Cbo_Voltage);
            this.groupBox4.Controls.Add(this.Cbo_Phase);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Controls.Add(this.lab_U);
            this.groupBox4.Location = new System.Drawing.Point(6, 71);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(224, 278);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "升源参数设置";
            // 
            // Cbo_GL
            // 
            this.Cbo_GL.FormattingEnabled = true;
            this.Cbo_GL.Items.AddRange(new object[] {
            "1.0",
            "0.5L",
            "0.5C",
            "0.8L",
            "0.8C"});
            this.Cbo_GL.Location = new System.Drawing.Point(68, 149);
            this.Cbo_GL.Name = "Cbo_GL";
            this.Cbo_GL.Size = new System.Drawing.Size(149, 20);
            this.Cbo_GL.TabIndex = 21;
            this.Cbo_GL.Text = "1.0";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(9, 152);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(53, 12);
            this.label12.TabIndex = 20;
            this.label12.Text = "功率因数";
            // 
            // Cbo_Class_Var
            // 
            this.Cbo_Class_Var.FormattingEnabled = true;
            this.Cbo_Class_Var.Items.AddRange(new object[] {
            "0.5",
            "1.0",
            "2.0"});
            this.Cbo_Class_Var.Location = new System.Drawing.Point(68, 252);
            this.Cbo_Class_Var.Name = "Cbo_Class_Var";
            this.Cbo_Class_Var.Size = new System.Drawing.Size(149, 20);
            this.Cbo_Class_Var.TabIndex = 19;
            this.Cbo_Class_Var.Text = "2";
            // 
            // Cbo_Class_Watt
            // 
            this.Cbo_Class_Watt.FormattingEnabled = true;
            this.Cbo_Class_Watt.Items.AddRange(new object[] {
            "0.5",
            "1.0",
            "2.0"});
            this.Cbo_Class_Watt.Location = new System.Drawing.Point(68, 226);
            this.Cbo_Class_Watt.Name = "Cbo_Class_Watt";
            this.Cbo_Class_Watt.Size = new System.Drawing.Size(149, 20);
            this.Cbo_Class_Watt.TabIndex = 18;
            this.Cbo_Class_Watt.Text = "0.5";
            // 
            // Cbo_Const_Var
            // 
            this.Cbo_Const_Var.FormattingEnabled = true;
            this.Cbo_Const_Var.Items.AddRange(new object[] {
            "1200",
            "1600",
            "2400",
            "3200",
            "6400",
            "8000",
            "10000"});
            this.Cbo_Const_Var.Location = new System.Drawing.Point(68, 200);
            this.Cbo_Const_Var.Name = "Cbo_Const_Var";
            this.Cbo_Const_Var.Size = new System.Drawing.Size(149, 20);
            this.Cbo_Const_Var.TabIndex = 17;
            this.Cbo_Const_Var.Text = "1600";
            // 
            // Cbo_Const_Watt
            // 
            this.Cbo_Const_Watt.FormattingEnabled = true;
            this.Cbo_Const_Watt.Items.AddRange(new object[] {
            "1200",
            "1600",
            "2400",
            "3200",
            "6400",
            "8000",
            "10000"});
            this.Cbo_Const_Watt.Location = new System.Drawing.Point(68, 174);
            this.Cbo_Const_Watt.Name = "Cbo_Const_Watt";
            this.Cbo_Const_Watt.Size = new System.Drawing.Size(149, 20);
            this.Cbo_Const_Watt.TabIndex = 16;
            this.Cbo_Const_Watt.Text = "1600";
            // 
            // Cbo_Fre
            // 
            this.Cbo_Fre.FormattingEnabled = true;
            this.Cbo_Fre.Items.AddRange(new object[] {
            "50"});
            this.Cbo_Fre.Location = new System.Drawing.Point(68, 123);
            this.Cbo_Fre.Name = "Cbo_Fre";
            this.Cbo_Fre.Size = new System.Drawing.Size(149, 20);
            this.Cbo_Fre.TabIndex = 15;
            this.Cbo_Fre.Text = "50";
            // 
            // Cbo_MaxCurrent
            // 
            this.Cbo_MaxCurrent.FormattingEnabled = true;
            this.Cbo_MaxCurrent.Items.AddRange(new object[] {
            "1.2",
            "2",
            "6",
            "10",
            "20"});
            this.Cbo_MaxCurrent.Location = new System.Drawing.Point(68, 97);
            this.Cbo_MaxCurrent.Name = "Cbo_MaxCurrent";
            this.Cbo_MaxCurrent.Size = new System.Drawing.Size(149, 20);
            this.Cbo_MaxCurrent.TabIndex = 14;
            this.Cbo_MaxCurrent.Text = "6";
            // 
            // Cbo_Current
            // 
            this.Cbo_Current.FormattingEnabled = true;
            this.Cbo_Current.Items.AddRange(new object[] {
            "0.3",
            "1",
            "1.2",
            "1.5",
            "5",
            "10"});
            this.Cbo_Current.Location = new System.Drawing.Point(68, 73);
            this.Cbo_Current.Name = "Cbo_Current";
            this.Cbo_Current.Size = new System.Drawing.Size(149, 20);
            this.Cbo_Current.TabIndex = 13;
            this.Cbo_Current.Text = "1.5";
            // 
            // Cbo_Voltage
            // 
            this.Cbo_Voltage.FormattingEnabled = true;
            this.Cbo_Voltage.Items.AddRange(new object[] {
            "57.7",
            "100",
            "220",
            "380"});
            this.Cbo_Voltage.Location = new System.Drawing.Point(68, 48);
            this.Cbo_Voltage.Name = "Cbo_Voltage";
            this.Cbo_Voltage.Size = new System.Drawing.Size(149, 20);
            this.Cbo_Voltage.TabIndex = 12;
            this.Cbo_Voltage.Text = "200";
            // 
            // Cbo_Phase
            // 
            this.Cbo_Phase.FormattingEnabled = true;
            this.Cbo_Phase.Items.AddRange(new object[] {
            "三相四线有功/正弦无功",
            "三相三线有功/正弦无功"});
            this.Cbo_Phase.Location = new System.Drawing.Point(68, 23);
            this.Cbo_Phase.Name = "Cbo_Phase";
            this.Cbo_Phase.Size = new System.Drawing.Size(149, 20);
            this.Cbo_Phase.TabIndex = 11;
            this.Cbo_Phase.Text = "三相四线有功/正弦无功";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(9, 203);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 12);
            this.label8.TabIndex = 10;
            this.label8.Text = "无功常数";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(9, 255);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 12);
            this.label7.TabIndex = 9;
            this.label7.Text = "无功等级";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(9, 177);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 12);
            this.label6.TabIndex = 8;
            this.label6.Text = "有功常数";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(9, 229);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 7;
            this.label5.Text = "有功等级";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 126);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 6;
            this.label4.Text = "电表频率";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 100);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 5;
            this.label3.Text = "最大电流";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 4;
            this.label2.Text = "相    线";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 76);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 3;
            this.label1.Text = "额定电流";
            // 
            // lab_U
            // 
            this.lab_U.AutoSize = true;
            this.lab_U.Location = new System.Drawing.Point(9, 51);
            this.lab_U.Name = "lab_U";
            this.lab_U.Size = new System.Drawing.Size(53, 12);
            this.lab_U.TabIndex = 2;
            this.lab_U.Text = "额定电压";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.RadBtn_Dsp);
            this.groupBox3.Controls.Add(this.RadBtn_D);
            this.groupBox3.Location = new System.Drawing.Point(6, 20);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(224, 45);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "信号源类型";
            // 
            // RadBtn_Dsp
            // 
            this.RadBtn_Dsp.AutoSize = true;
            this.RadBtn_Dsp.Location = new System.Drawing.Point(82, 20);
            this.RadBtn_Dsp.Name = "RadBtn_Dsp";
            this.RadBtn_Dsp.Size = new System.Drawing.Size(65, 16);
            this.RadBtn_Dsp.TabIndex = 1;
            this.RadBtn_Dsp.TabStop = true;
            this.RadBtn_Dsp.Text = "新DSP型";
            this.RadBtn_Dsp.UseVisualStyleBackColor = true;
            // 
            // RadBtn_D
            // 
            this.RadBtn_D.AutoSize = true;
            this.RadBtn_D.Location = new System.Drawing.Point(11, 20);
            this.RadBtn_D.Name = "RadBtn_D";
            this.RadBtn_D.Size = new System.Drawing.Size(65, 16);
            this.RadBtn_D.TabIndex = 0;
            this.RadBtn_D.TabStop = true;
            this.RadBtn_D.Text = "普通D型";
            this.RadBtn_D.UseVisualStyleBackColor = true;
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 12;
            this.listBox1.Location = new System.Drawing.Point(6, 23);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(157, 112);
            this.listBox1.TabIndex = 6;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.listBox1);
            this.groupBox6.Location = new System.Drawing.Point(387, 297);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(169, 122);
            this.groupBox6.TabIndex = 6;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "显示实时数据";
            // 
            // Demo_CNet_DLL7000
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(570, 431);
            this.Controls.Add(this.groupBox1);
            this.Name = "Demo_CNet_DLL7000";
            this.Text = "C#动态库调用例程";
            this.Load += new System.EventHandler(this.Demo_CNet_DLL7000_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.Grp_Test.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TreeView MeterTree;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lab_U;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton RadBtn_Dsp;
        private System.Windows.Forms.RadioButton RadBtn_D;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox Cbo_Phase;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox Cbo_Voltage;
        private System.Windows.Forms.ComboBox Cbo_Class_Var;
        private System.Windows.Forms.ComboBox Cbo_Class_Watt;
        private System.Windows.Forms.ComboBox Cbo_Const_Var;
        private System.Windows.Forms.ComboBox Cbo_Const_Watt;
        private System.Windows.Forms.ComboBox Cbo_Fre;
        private System.Windows.Forms.ComboBox Cbo_MaxCurrent;
        private System.Windows.Forms.ComboBox Cbo_Current;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button Btn_SetPar;
        private System.Windows.Forms.GroupBox Grp_Test;
        private System.Windows.Forms.Button Btn_TestError;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.ComboBox Cbo_Port;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox Cbo_AdjustTime;
        private System.Windows.Forms.ComboBox Cbo_SteadyTime;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button Btn_TestCom485;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox Cbo_GL;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.GroupBox groupBox6;
    }
}

