using System;
using System.Collections.Generic;
using System.Text;

namespace SetParClass
{
    class SetParClass
    {
        public static Boolean[] mAryMeterNO = new Boolean[16];
        public static int mIntComPort;
        public static int mIntSourceType;
        public static int SteadyTime;
        public static int AdjustTime;
        public static String mStrPhase;

        private static int mIntMeters;
        public static int MeterNo
            {
                get
                {
                    return mIntMeters;
                }
                set
                {
                    mIntMeters=value;
                }
            }

        private static Single mSngVoltage;
        public static Single Voltage   //��ѹ
        {
            get
            {
                return mSngVoltage;
            }
            set
            {
                mSngVoltage = value;
            }
        }

        private static Single mSngCurrent;  //����
        public static Single Current
        {
            get
            {
                return mSngCurrent;
            }
            set
            {
                mSngCurrent = value;
            }
        }

        private static Single mMaxCurrent;    //������
        public static Single MaxCurrent
        {
            get
            {
                return mMaxCurrent;
            }
            set
            {
                mMaxCurrent = value;
            }
        }

        private static Single mSngFrequency;  //Ƶ��
        public static Single Frequency
        {
            get
            {
                return mSngFrequency;
            }
            set
            {
                mSngFrequency = value;
            }
        }

        private static int mIntConst_Watt;   //�й�����
        public static int Const_Watt
        {
            get
            {
                return mIntConst_Watt;
            }
            set
            {
                mIntConst_Watt = value;
            }
        }

        private static int mIntConst_Var;   //�޹�����
        public static int Const_Var
        {
            get
            {
                return mIntConst_Var;
            }
            set
            {
                mIntConst_Var = value;
            }
        }

        private static Single mSngClass_Watt; //�й��ȼ�
        public static Single Class_Watt
        {
            get
            {
                return mSngClass_Watt;
            }
            set
            {
                mSngClass_Watt = value;
            }
        }

        private static Single mSngClass_Var;  //�޹��ȼ�
        public static Single Class_Var
        {
            get
            {
                return mSngClass_Var;
            }
            set
            {
                mSngClass_Var = value;
            }
        }

        private static String mStrGL;
        public static String GL
        {
            get
            {
                return mStrGL;
            }
            set
            {
                mStrGL = value;
            }
        }
    }
}
