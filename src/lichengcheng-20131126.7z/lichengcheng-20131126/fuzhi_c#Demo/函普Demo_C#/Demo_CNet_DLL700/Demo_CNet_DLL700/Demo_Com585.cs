using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Demo_CNet_DLL700
{
    public partial class Demo_Com585 : Form
    {
        public Demo_Com585()
        {
            InitializeComponent();
        }
    }
}