using System;
using System.Threading;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using SetParClass;
using Demo_Class;
using Demo_CNet_DLL7000;

namespace Demo_Error
{
    public partial class Demo_Error : Form
    {
        private Single Ua,Ub,Uc;
        private Single Ia,Ib,Ic;
        private Single UMax, IMax;
        private Single Frequency;
        private Int32 Const_Watt, Const_Var;
        private Single Class_Watt, Class_Var;
        private Single U;
        private Single I;
        private Single DUab,DUac;
        private Single DUIa,DUIb,DUIc;

        private int lIntPulesCurrent, lIntDispCurrent;
       
        public Demo_Error()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Demo_Error_Load(object sender, EventArgs e)
        {
            U = SetParClass.SetParClass.Voltage;
            I = SetParClass.SetParClass.Current;
            //IMax = SetParClass.SetParClass.MaxCurrent;
            Const_Watt = SetParClass.SetParClass.Const_Watt; 
            Const_Var =SetParClass.SetParClass.Const_Var;
            Class_Var = SetParClass.SetParClass.Class_Var;
            Class_Watt = SetParClass.SetParClass.Class_Watt;
            Frequency = SetParClass.SetParClass.Frequency;
        }

        private void Btn_Start_Click(object sender, EventArgs e)
        {
            int IntResult = 0;
            int IntStatus = 0;
            int IntWVar;
            int IntPhase;         //��������
            Double lDblHCConst;
            Int32 StandConst;
            int IABC = 0;

            MeterClass.Answer StrData=new MeterClass.Answer();
            MeterClass.Standard StrStandard= new MeterClass.Standard();
            MeterClass.DelayTime StrDeleyTime = new MeterClass.DelayTime();
            MeterClass.Pules StrPules = new MeterClass.Pules();

            StrDeleyTime.AdjustTime = SetParClass.SetParClass.AdjustTime;
            StrDeleyTime.SteadyTime =SetParClass.SetParClass.SteadyTime;

            if ((comboBox3.Text =="�����й�") && (comboBox3.Text =="�����й�"))
            {
                if (comboBox3.Text  =="�����й�")
                {
                    IntStatus = 0;
                }
                else if (comboBox3.Text  =="�����й�")
                {
                    IntStatus = 1;
                }
                IntWVar = 4;
                StandConst = Const_Watt;
            }
            else
            {
                if (comboBox3.Text  =="�����޹�")
                {
                    IntStatus = 2;
                }
                else if (comboBox3.Text  =="�����޹�")
                {
                    IntStatus = 3;
                }
                IntWVar = 5;
                StandConst = Const_Var;
            }

            //����ͨ��
            for (int i = 0; i < SetParClass.SetParClass.MeterNo; i++)
            {
                if (SetParClass.SetParClass.mAryMeterNO[i])
                {
                    //��ͨͨ��
                    if (RadBtn_Standard.Checked)
                    {
                        //����Ҫ����
                    }
                    else if (RadBtn_WVar.Checked)
                    {
                        if (IntStatus <= 1)
                        {
                            IntResult = MeterClass.ErrorOrder_gFun(SetParClass.SetParClass.mIntComPort, 13, i + 1, 0, ref StrData);
                        }
                        else
                        {
                            IntResult = MeterClass.ErrorOrder_gFun(SetParClass.SetParClass.mIntComPort, 14, i + 1, 0, ref StrData);
                        }
                    }
                    else if (RadBtn_Mult.Checked)
                    {
                        if (IntStatus <= 1)
                        {
                            IntResult = MeterClass.ErrorOrder_gFun(SetParClass.SetParClass.mIntComPort, 16, i + 1, 0, ref StrData);
                        }
                        else
                        {
                            IntResult = MeterClass.ErrorOrder_gFun(SetParClass.SetParClass.mIntComPort, 14, i + 1, 0, ref StrData);
                        }
                    }
                    //IntResult = MeterClass.ErrorOrder_gFun(SetParClass.SetParClass.mIntComPort, 13, i + 1, 0, ref StrData);
                }
            }

            //���ñ�׼��
            if (radioButton1.Checked == true)
            {
                UMax = U * Convert.ToSingle(Cbo_U.Text) / 100;
                IMax = I * Convert.ToSingle(Cbo_I.Text) / 100;
                Ua = U * Convert.ToSingle(Cbo_U.Text) / 100;
                Ub = U * Convert.ToSingle(Cbo_U.Text) / 100;
                Uc = U * Convert.ToSingle(Cbo_U.Text) / 100;
                Ia = I * Convert.ToSingle(Cbo_I.Text) / 100;
                Ib = I * Convert.ToSingle(Cbo_I.Text) / 100;
                Ic = I * Convert.ToSingle(Cbo_I.Text) / 100;
                //���������Ϊ120��240 �����������෴
                DUab = 120;
                DUac = 240;

                DUIa = MeterClass.LCtoDegree_gFun(IntStatus, SetParClass.SetParClass.GL);
                DUIb = DUIa;
                DUIc = DUIa;

                IABC = 0;
            }
            else if ((radioButton2.Checked == true) || (radioButton3.Checked == true) || (radioButton4.Checked == true))
            {
                UMax = U * Convert.ToSingle(Cbo_U.Text) / 100;
                IMax = I * Convert.ToSingle(Cbo_I.Text) / 100;
                if (radioButton2.Checked == true)
                {
                    Ua = U * Convert.ToSingle(Cbo_U.Text) / 100;
                    Ia = I * Convert.ToSingle(Cbo_I.Text) / 100;
                    IABC = 1;
                }
                else if (radioButton3.Checked == true)
                {
                    Ub = U * Convert.ToSingle(Cbo_U_1.Text) / 100;
                    Ib = I * Convert.ToSingle(Cbo_I_1.Text) / 100;
                    IABC = 2;
                }
                else if (radioButton4.Checked == true)
                {
                    Uc = U * Convert.ToSingle(Cbo_U_2.Text) / 100;
                    Ic = I * Convert.ToSingle(Cbo_I_2.Text) / 100;
                    IABC = 3;
                }
                //���������Ϊ120��240 �����������෴
                DUab = 120;
                DUac = 240;

                DUIa = MeterClass.LCtoDegree_gFun(IntStatus, SetParClass.SetParClass.GL);
                DUIb = DUIa;
                DUIc = DUIa;
            }
            else if (radioButton5.Checked == true)
            {
                IABC = 0;
            }

            lIntPulesCurrent = MeterClass.HCARange_gFun(1,IMax);
            lIntDispCurrent = MeterClass.HCARange_gFun(2, IMax);

            //*********************************����ע��***************************************
            //���ñ�׼�����޹���������õ�������ʱ��ֻ���ڲ��Ե�����޹�״̬�ı���ߵ������̸ı�ʱ���Ž�������
            //�����������У�ͬ�����״̬�£������޹�ֻ��Ҫ����һ������
            //                ��ͬ�����Ե��£�ֻ�е����Ե�ĵ������̸ı����Ҫ���õ�����λ��
            //*********************************����ע��***************************************
            //���ñ�׼���й�/�޹��������
            IntResult = MeterClass.OperationHC_Fun(SetParClass.SetParClass.mIntSourceType, SetParClass.SetParClass.mIntComPort, 55, IntWVar, lIntPulesCurrent, ref StrStandard);

            if (SetParClass.SetParClass.mIntSourceType == 4)
            {
                Thread.Sleep(500);
            }
            //���ñ�׼����������
            IntResult = MeterClass.OperationHC_Fun(SetParClass.SetParClass.mIntSourceType, SetParClass.SetParClass.mIntComPort, 55, 9, lIntDispCurrent, ref StrStandard);
            //���ñ�׼�� end 

            //�����ź�Դ����״̬ begin
            if (SetParClass.SetParClass.mStrPhase == "���������й�/�����޹�")
            {   //�Ա�׼��ֻ�������������߻����������ߣ����ź�Դ��Ҫ�������޹���
                if (IntStatus <= 1)
                {
                    IntPhase = 5;    //�й�
                }
                else
                {
                    IntPhase = 7;    //�޹�
                }  
            }
            else if (SetParClass.SetParClass.mStrPhase == "���������й�/�����޹�")
            {    //ͬ��
                if (IntStatus <= 1)
                {
                    IntPhase = 1;    //�й�
                }
                else
                {
                    IntPhase = 4;    //�޹�
                }
            }
            else
            {    //ͬ��
                if (IntStatus <= 1)
                {
                    IntPhase = 5;
                }
                else
                {
                    IntPhase = 7;
                }
            }
            //�����ź�Դ����״̬ end

            //��Դ����  begin
            if (SetParClass.SetParClass.mIntSourceType == 3)
            {
                //��ͨD���ź�Դ��Դ����
                int lIntLC = 0;
                String lStrLC;
                lStrLC = SetParClass.SetParClass.GL;
                if (lStrLC.Contains("L"))
                {
                    lStrLC=lStrLC.Remove(lStrLC.Length - 1);
                    lIntLC = Convert.ToInt32(Convert.ToSingle(lStrLC) * 10 * 1000 + 1);
                }
                else if (lStrLC.Contains("C"))
                {
                    lIntLC = Convert.ToInt32(Convert.ToSingle(lStrLC.Remove(lStrLC.Length - 1)) * 10 * 1000 + 2);
                }
                else
                {
                    lIntLC = Convert.ToInt32(Convert.ToSingle(lStrLC) * 10 * 1000 + 1);
                }
                IntResult = MeterClass.OutPutData_gSub(1, SetParClass.SetParClass.mIntSourceType, 
                                                       SetParClass.SetParClass.mIntComPort, IntPhase, IntStatus, 1, U, I, 
                                                       Frequency, IABC, Convert.ToInt16(Cbo_I.Text), lIntLC, 0, 0, 0, 0, 
                                                       ref StrDeleyTime);
            }
            else
            {
                //Dsp�ź�Դ��Դ����
               IntResult = MeterClass.DSPOutput(1,SetParClass.SetParClass.mIntComPort,
                                                 1, IntPhase, Frequency, Ua, Ub, Uc, Ia, Ib, Ic, DUab, DUac, DUIa, DUIb, DUIc,
                                                 1, ref StrDeleyTime);
            }

            //����Ȧ��
            if (IntResult == -1)
            {
                //��Դ�ɹ������������
                Int32 lLngPules;
                lDblHCConst = MeterClass.StandardConst_gFun(lIntPulesCurrent, lIntDispCurrent,UMax);
                lLngPules =Convert.ToInt32(lDblHCConst /StandConst * Convert.ToInt32(comboBox1.Text));

                for (int i = 0; i < SetParClass.SetParClass.MeterNo; i++)
                {
                    if (SetParClass.SetParClass.mAryMeterNO[i])
                    {
                        //����Ȧ��
                        IntResult = MeterClass.ErrorCircles_gFun(SetParClass.SetParClass.mIntComPort, i + 1, Convert.ToInt32(comboBox1.Text), lLngPules, 1, ref StrData, ref StrPules);
                    }
                }

            }
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            Cbo_U_1.Enabled = true;
            Cbo_U_2.Enabled = true;
            Cbo_I_1.Enabled = true;
            Cbo_I_2.Enabled = true;
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            Cbo_U_1.Enabled = false;
            Cbo_U_2.Enabled = false;
            Cbo_I_1.Enabled = false;
            Cbo_I_2.Enabled = false;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            Cbo_U_1.Enabled = false;
            Cbo_U_2.Enabled = false;
            Cbo_I_1.Enabled = false;
            Cbo_I_2.Enabled = false;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            Cbo_U_1.Enabled = false;
            Cbo_U_2.Enabled = false;
            Cbo_I_1.Enabled = false;
            Cbo_I_2.Enabled = false;
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            Cbo_U_1.Enabled = false;
            Cbo_U_2.Enabled = false;
            Cbo_I_1.Enabled = false;
            Cbo_I_2.Enabled = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Int32 IntResult;
            MeterClass.Answer StrData = new MeterClass.Answer();

            for (int i = 0; i < SetParClass.SetParClass.MeterNo; i++)
            {
                if (SetParClass.SetParClass.mAryMeterNO[i])
                {
                    //��ȡ���
                    IntResult = MeterClass.ErrorOrder_gFun(SetParClass.SetParClass.mIntComPort,2,i+1,2,ref StrData);
                    if (IntResult == -1)
                    {
                        if (StrData.SngAnswer > 0)
                        {
                            ListData.Items.Add("��" + Convert.ToString(i + 1) + "��λ�ĵ�[ " + Convert.ToInt32(StrData.SngTimes) + " ]�����Ϊ��" + Convert.ToString(StrData.SngAnswer));
                        }
                    }
                    else
                    {
                        ListData.Items.Add("��ȡ���ʧ�ܣ�");
                    }
                }
            }
        }
    }
}