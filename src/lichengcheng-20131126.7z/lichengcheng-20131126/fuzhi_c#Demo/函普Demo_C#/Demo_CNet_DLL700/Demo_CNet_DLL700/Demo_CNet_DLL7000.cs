using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Demo_Class;
using SetParClass;
using Demo_CNet_DLL7000;
using System.IO.Ports;

namespace Demo_CNet_DLL7000
{
    public partial class Demo_CNet_DLL7000 : Form
    {
        bool mBlnChecked;
        //public Boolean[] mAryMeterNO = new Boolean[16];
        public Demo_CNet_DLL7000()
        {
            InitializeComponent();
            Grp_Test.Enabled = true;//oo
        }

        private void Btn_TestError_Click(object sender, EventArgs e)
        {
            Demo_Error.Demo_Error  TestError = new Demo_Error.Demo_Error();
            TestError.Show();
        }

        private void btn_SetPar_Click(object sender, EventArgs e)
        {
            String StrPhase;
            int IntPhase=1;
            int IntResult=2;
            int SourceType=3;
            int hcAddress = 55;   //��׼����ַ
            int IntCommandID;
            int IntComPort;
            MeterClass.DelayTime IntTime = new MeterClass.DelayTime();
            MeterClass.Standard StrData = new MeterClass.Standard();
            
            if (RadBtn_D.Checked == true)
            {
                SourceType = 3;
            }
            else if (RadBtn_Dsp.Checked == true)
            {
                SourceType = 4;
            }
            else
            {
                SourceType = 3;
            }

            SetParClass.SetParClass.Voltage = Convert.ToSingle(Cbo_Voltage.Text);
            SetParClass.SetParClass.Current = Convert.ToSingle(Cbo_Current.Text);
            SetParClass.SetParClass.MaxCurrent = Convert.ToSingle(Cbo_MaxCurrent.Text);
            SetParClass.SetParClass.Frequency = Convert.ToSingle(Cbo_Fre.Text);
            SetParClass.SetParClass.Class_Watt = Convert.ToSingle(Cbo_Class_Watt.Text);
            SetParClass.SetParClass.Class_Var = Convert.ToSingle(Cbo_Class_Var.Text);
            SetParClass.SetParClass.Const_Watt = Convert.ToInt16(Cbo_Const_Watt.Text);
            SetParClass.SetParClass.Const_Var = Convert.ToInt16(Cbo_Const_Var.Text);
            SetParClass.SetParClass.GL = Convert.ToString(Cbo_GL.Text);
            SetParClass.SetParClass.mStrPhase = Convert.ToString(Cbo_Phase.Text);

            SetParClass.SetParClass.mIntComPort = Convert.ToInt16(Cbo_Port.Text.Remove(0, 3));
            SetParClass.SetParClass.SteadyTime = Convert.ToInt16(Cbo_SteadyTime.Text);
            SetParClass.SetParClass.AdjustTime = Convert.ToInt16(Cbo_AdjustTime.Text);

            SetParClass.SetParClass.mIntSourceType = SourceType;

            //ȷ�϶��ٱ�λ��Ч
            for (int i = 1; i < SetParClass.SetParClass.MeterNo; i++)
            {
                int str;
                str = MeterTree.Nodes[0].Nodes.Count;
                if (MeterTree.Nodes[0].Nodes[i-1].Checked)
                {
                    SetParClass.SetParClass.mAryMeterNO[i- 1] = true;
                }
            }



            //���ñ�׼�����ߣ�ÿ�β��Թ��̣�ֻ��Ҫ����һ�Ρ�
            StrPhase = Cbo_Phase.Text;
            if (StrPhase == "���������й�/�����޹�")
            {
                IntPhase = 1;
            }
            else if (StrPhase == "���������й�/�����޹�")
            {
                IntPhase = 2;
            }
            else
            {
                IntPhase = 1;
            }
            IntCommandID = 6;//���ñ�׼������
            IntTime.SteadyTime = Convert.ToInt16(Cbo_SteadyTime.Text);
            IntTime.AdjustTime = Convert.ToInt16(Cbo_AdjustTime.Text);
            IntComPort = Convert.ToInt16(Cbo_Port.Text.Remove(0,3));
            Grp_Test.Enabled = true;
            //��һ�������ݵ�����õ�ǰ��׼������
            IntResult = MeterClass.OperationHC_Fun(SourceType, IntComPort, hcAddress, IntCommandID, IntPhase, ref StrData);
            if (IntResult == -1)
            {
                MessageBox.Show("���óɹ�����������⣡", "��׼������", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                Grp_Test.Enabled = true;
            }
            else
            {
                MessageBox.Show("����ʧ�ܣ���������⣡", "��׼������", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

        }

        private void Demo_CNet_DLL7000_Load(object sender, EventArgs e)
        {
            SetParClass.SetParClass.MeterNo = 16;
            Draw_Tree();
        }

        private void Draw_Tree()
        {
            int I;
            MeterTree.Nodes.Add("SelectMeter", "ѡ��");
            for (I=1;I<=SetParClass.SetParClass.MeterNo;I++)
            {
                MeterTree.Nodes[0].Nodes.Add("MeterNO" + Convert.ToString(I), "����"+Convert.ToString(I));
            }
            MeterTree.Nodes[0].Expand();
        }

        private void Btn_TestCom485_Click(object sender, EventArgs e)
        {//���Խ������̴���
            Demo_CNet_DLL700.JiaoBiao jiaobiao = new Demo_CNet_DLL700.JiaoBiao();

            jiaobiao.Show();
            //��䵽���ñ�����
            MeterClass.Standard RealStrData = new MeterClass.Standard();
            float RealV = (RealStrData.RealVA + RealStrData.RealVB + RealStrData.RealVC) / 3;
            float RealC = (RealStrData.RealAA + RealStrData.RealAB + RealStrData.RealAC) / 3;
            Cbo_Voltage.Text = RealV.ToString();
            Cbo_Current.Text = RealC.ToString();
            SetParClass.SetParClass.Voltage = Convert.ToSingle(Cbo_Voltage.Text);
            SetParClass.SetParClass.Current = Convert.ToSingle(Cbo_Current.Text);
            SetParClass.SetParClass.MaxCurrent = Convert.ToSingle(Cbo_MaxCurrent.Text);
            SetParClass.SetParClass.Frequency = Convert.ToSingle(Cbo_Fre.Text);
            SetParClass.SetParClass.Class_Watt = Convert.ToSingle(Cbo_Class_Watt.Text);
            SetParClass.SetParClass.Class_Var = Convert.ToSingle(Cbo_Class_Var.Text);
            SetParClass.SetParClass.Const_Watt = Convert.ToInt16(Cbo_Const_Watt.Text);
            SetParClass.SetParClass.Const_Var = Convert.ToInt16(Cbo_Const_Var.Text);
            SetParClass.SetParClass.GL = Convert.ToString(Cbo_GL.Text);
            ReadrealData();

        }

        private void MeterTree_AfterSelect(object sender, TreeViewEventArgs e)
        {

        }

        private void MeterTree_Click(object sender, EventArgs e)
        {
            int I = 0;
            int lIntPoint = 0;
            
            if (MeterTree.Nodes[0].Checked)
            {
                if (mBlnChecked)
                {
                    for (I = 1; I <= SetParClass.SetParClass.MeterNo; I++)
                    {
                        if (MeterTree.Nodes[0].Nodes[I - 1].Checked)
                        {
                            MeterTree.Nodes[0].Nodes[I - 1].Checked = true;
                        }
                    }   
                }
                else
                {
                    for (I = 1; I <= SetParClass.SetParClass.MeterNo; I++)
                    {
                        MeterTree.Nodes[0].Nodes[I - 1].Checked = true;
                    }               
                }
            }
            else if(MeterTree.Nodes[0].Checked == false)
            {
                for (I = 1; I <= SetParClass.SetParClass.MeterNo; I++)
                {
                    if (MeterTree.Nodes[0].Nodes[I - 1].Checked)
                    {
                        MeterTree.Nodes[0].Nodes[I - 1].Checked = true;
                        MeterTree.Nodes[0].Checked = true;
                        mBlnChecked = true;
                    }
                    else
                    {
                        MeterTree.Nodes[0].Nodes[I - 1].Checked = false;
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            long mPortHandle;
            MeterClass.SerialPort mSerialPort;
            mSerialPort.ComNo = 1;//����Ϊ1
            mSerialPort.Baud = 9600;
            mSerialPort.Parity = 1;
            mSerialPort.StopBits = 1;
            mSerialPort.DataBit = 8;

            mPortHandle = MeterClass.OpenComm(ref mSerialPort);
            if (mPortHandle != 0)
            {
                long mHanle = mPortHandle;
            }
            //SerialPort spcom = new SerialPort("COM1", 9600, Parity.Even, 8, StopBits.One);
            //if (spcom.IsOpen) spcom.Close();

            // spcom.Open();
           
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //��̬������ĵ���

        }

        private void ReadrealData()
        {
            int IntPhase = 1;// ���������й�/�����޹�
            int IntResult = 2;
            int SourceType = 3;//�ź�Դ
            int hcAddress = 55;   //��׼����ַĬ��Ϊ55
            int IntCommandID = 3;// ���������� 1 �������������֣�2 ���ѻ��������֣�3 ����ȡ��׼����ʾֵ 
            int IntComPort = SetParClass.SetParClass.mIntComPort;//����
            MeterClass.Standard StrData = new MeterClass.Standard();
            IntResult = MeterClass.OperationHC_Fun(SourceType, IntComPort, hcAddress, IntCommandID, IntPhase, ref StrData);

            float RealVA = StrData.RealVA;        //A���ѹ(V)                   
            float RealVB = StrData.RealVB;      //B���ѹ(V)
            float RealVC = StrData.RealVC;
            float RealAA = StrData.RealAA;                           
            float RealAB = StrData.RealAB;      
            float RealAC = StrData.RealAC;
            float RealPVA = StrData.RealPVA;//�����ڹ���(VA)
            float RealP = StrData.RealP;//�������й�����(W)
            float RealQ = StrData.RealQ; //�������޹�����(var)
            listBox1.Items.Add("VA ��" + RealVA);
            listBox1.Items.Add("VB ��" + RealVB);
            listBox1.Items.Add("VC ��" + RealVC);
            listBox1.Items.Add("IA ��" + RealAA);
            listBox1.Items.Add("IB ��" + RealAB);
            listBox1.Items.Add("IC ��" + RealAC);
            listBox1.Items.Add("PVA ��" + RealPVA);
            listBox1.Items.Add("IP ��" + RealP);
            listBox1.Items.Add("IQ ��" + RealQ);



        }
        
    }
}