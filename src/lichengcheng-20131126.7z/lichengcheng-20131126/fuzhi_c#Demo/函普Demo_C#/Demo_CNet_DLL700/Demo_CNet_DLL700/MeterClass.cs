using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace Demo_Class
{
    class MeterClass
    {
        //��Դ
        [DllImport("DLL7000.dll")]
        public static extern int SourceClear_Fun(int comPort);

        //��Դ����
        [DllImport("DLL7000.dll")]  //, CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)] //, EntryPoint = "OutPutData_gSub", CharSet = CharSet.Auto, SetLastError = false, CallingConvention = CallingConvention.StdCall)]
        public static extern int OutPutData_gSub(int pLngAdjust, int pLngSourceType, int ComPort, int pIntPhase, int pIntStatus, int pIntSequence, float pSngVoltage, float pSngCurrent, float pSngFrequency, int pStrIABC, int pIntIB, int pStrLC, int pIntWave, int pIntWaveTimes, int pStrUWave, int pStrIWave, ref DelayTime timedelay);

        [DllImport("DLL7000.dll")] //CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall
        public static extern int DSPOutput(int pLngAdjust, int ComPort, int pIntID, int pIntPhase, float pSngFrequency, float Ua, float Ub, float Uc, float Ia, float Ib, float Ic, float DUab, float DUac, float DUIa, float DUIb, float DUIc, int WaveType, ref DelayTime timedelay);
        
        //��׼�����ü���ȡ
        [DllImport("DLL7000.dll")] //, EntryPoint = "OperationHC_Fun", CharSet = CharSet.Auto, SetLastError = true, CallingConvention = CallingConvention.StdCall)]
        public static extern int OperationHC_Fun(int sourceType, int comPort, int hcAddress, int commandID, int Data, ref Standard strData);
    
        //���������
        [DllImport("DLL7000.DLL")]
        public static extern int ErrorOrder_gFun(int comPort, int pintID, int hcAddress, int pIntTime, ref Answer strData);

        //����Ȧ��
        [DllImport("DLL7000.DLL")]
        public static extern int ErrorCircles_gFun(int comPort, int lIntAddress, int lIntCircles, int lLngPules, Single lSngMaxError, ref Answer strData, ref Pules strPules);

        //�������������״̬
        [DllImport("DLL7000.dll")]
        public static extern int Ini_SecPules(int comPort, int pIntID);

        [DllImport("ComPort.dll")]
        public static extern int OpenComm(ref SerialPort pComPort);
        //public static extern Boolean ComPortAvailable(int pIntComPortt);
        //public aferror[] afer = new aferror[47];
        //[DllImport("GetError.dll")]
        //public static extern bool funGetPowerError(ref);


        public static short HCARange_gFun(short pIntID, float pSngCurrent)
        {
            //HC3100���������б�
            //pSngCurrent  ����ֵ
            //pIntID  1-������������������� 2-������ʾ��������
            float lSngCurrent;
            short lIntOutA, lIntDispA;
            lSngCurrent = pSngCurrent;
            if (lSngCurrent <= 0.12)
            {
                lIntOutA = 1;
                lIntDispA = 1;
            }
            else if (lSngCurrent <= 0.6)
            {
                lIntOutA = 5;
                lIntDispA = 1;
            }
            else if (lSngCurrent <= 1.2)
            {
                lIntOutA = 10;
                lIntDispA = 1;
            }
            else if (lSngCurrent <= 6)
            {
                lIntOutA = 5;
                lIntDispA = 10;
            }
            else if (lSngCurrent <= 12)
            {
                lIntOutA = 10;
                lIntDispA = 10;
            }
            else if (lSngCurrent <= 60)
            {
                lIntOutA = 5;
                lIntDispA = 100;
            }
            else
            {
                lIntOutA = 10;
                lIntDispA = 100;
            }
            if (pIntID == 1)
                return lIntOutA;
            return lIntDispA;
        }

        public static Single LCtoDegree_gFun(int pIntStatus, String pStrLC)
        {
            Single lSngResult;
            String lStrLC;
            if ((pStrLC.Contains("C")) || (pStrLC.Contains("L")))
            {
                lStrLC=pStrLC.Remove(pStrLC.Length-1);   
            }
            else
            {
                lStrLC=pStrLC;
            }
            lSngResult = ArcCos_lFun(Convert.ToSingle(lStrLC));
            if ((pIntStatus == 0) || (pIntStatus == 1))
            {
                if (pStrLC.Contains("C"))
                {
                    lSngResult = 360 - lSngResult;
                }
            }
            else
            {
                if (pStrLC.Contains("C"))
                {
                    lSngResult = 270 + lSngResult;
                }
                else
                {
                    lSngResult = 90 - lSngResult;
                }
            }
            if ((pIntStatus == 1) || (pIntStatus == 3))
            {
                if (lSngResult > 180)
                {
                    lSngResult = lSngResult - 180;
                }
                else
                {
                    lSngResult = lSngResult + 180;
                }
            }
            return lSngResult;
        }

        public static Single ArcCos_lFun(Single X)
        {
            Single lSngResult;
            double Y;
            if (X == 0)
            {
                lSngResult = 90;
            }
            else if (X == 1)
            {
                lSngResult = 0;
            }
            else
            {
                Y = Convert.ToDouble(X);
                lSngResult =Convert.ToSingle( Math.Atan(-Y / Math.Sqrt(-Y * Y + 1)) + 2 * Math.Atan(1));
                lSngResult = Convert.ToSingle(lSngResult * 180 / 3.1415926);
            }
            return lSngResult;
        }

        public struct Pules
        {
            public Int32 pIntSourceVersion;
            public Int32 pIntConstFactor;
            public Int32 pIntPulesConst;
            public Int32 pIntRoundConst;
        }

        public struct aferror
        {
            public Single Error;
        }

        

        public struct Answer
        {
            public Single SngAnswer;
            public Single SngTimes;
        }


        public struct SerialPort  //���пڶ��� typedef
        {
            public int ComNo;
            public int Baud;
            public int Parity;
            public Byte DataBit;
            public int StopBits;
        }

// ComNO As Long          '���ں�
// Baud As Long           '������
//  Parity As Long        '����λ
// DataBit As Byte    '����λ
 //StopBits As Long     'ֹͣλ
 //RTS As Long         '����RTS
 //DTR As Long         '����DTR

        public struct DelayTime
        {
            public Int32 SteadyTime;      //��Դ�ȶ�ʱ�䡣
            public Int32 AdjustTime;      //��Դ�ȶ��������ѹ��������ֵ����ʱ�䡣
        }

        public struct Standard
        {
            public float RealVA;        //A���ѹ(V)                   
            public float RealVB;        //B���ѹ(V)
            public float RealVC;        //C���ѹ(V)
            public float RealAA;        //A�����(A)
            public float RealAB;        //B�����(A)
            public float RealAC;        //C�����(A)
            public float RealPFA;       //A�๦������
            public float RealPFB;       //B�๦������
            public float RealPFC;       //C�๦������
            public float RealWA;        //A�๦�ʣ���׼�����й��������״̬ʱΪ�й���(W)���޹�ʱΪ�޹�����(var)
            public float RealWB;        //B�๦��
            public float RealWC;        //C�๦��
            public float RealPF;        //ƽ����������
            public float RealAngle;     //�Ƕ�
            public float RealFrequency; //Ƶ��(Hz)
            public float RealPVA;       //�����ڹ���(VA)
            public float RealP;         //�������й�����(W)
            public float RealQ;         //�������޹�����(var)
        }

        public static Double StandardConst_gFun(Int32 pIntAPules,Int32 pIntARange,Single pSngVoltage)
        {
            Single lSngKI,lSngKU;
            Double lDblHCConst;
            lSngKI = 1 * pIntAPules * pIntARange;
            if (pSngVoltage < 80)
            {
                lSngKU = 1 / 2;
            }
            else if (pSngVoltage < 160)
            {
                lSngKU = 1;
            }
            else if (pSngVoltage < 320)
            {
                lSngKU = 2;
            }
            else
            {
                lSngKU = 4;
            }
            lDblHCConst = 1800000000 / lSngKU / lSngKI;
            return lDblHCConst;
        }
        
    }
}
