﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Program
{
    static class Program
    {
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Demo_CNet_DLL7000.Demo_CNet_DLL7000());
            //Application.Run(new Demo_CNet_DLL7000.JiaoBiao());
           
        }
    }
}