﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.CompilerServices;

namespace  ClassBCD

{
   public static class ClassBCD
    {
        public static byte[] BCDEncode(long intvalue, int byteLength)
        {
            byte[] r = new byte[byteLength];
            char[] chars = intvalue.ToString().ToCharArray();
            int clengh = chars.Length;
            int[] ints = new int[clengh];
            for (int j = 0; j < clengh; j++)
            {
                ints[j] = Convert.ToInt32(chars[j].ToString());
            }

            int rvalue = GetSum(16, ints);

            byte[] sas = BitConverter.GetBytes(rvalue);
            byte[] ras = new byte[byteLength];
            for (int k = 0; k < byteLength; k++)
            {
                ras[byteLength - k - 1] = sas[k];
            }
            return ras;

        }
        private static int GetSum(int baseInt, int[] sValue)
        {
            int count = sValue.Length;
            if (count == 1) return sValue[0];
            int r = 1;
            int b = sValue[0];
            for (int i = 1; i < count; i++)
            {
                r *= baseInt;
            }
            count--;
            int[] ri = new int[sValue.Length - 1];
            for (int j = 0; j < ri.Length; j++)
            {
                ri[j] = sValue[j + 1];
            }
            return b * r + GetSum(baseInt, ri);
        }
    }
}
