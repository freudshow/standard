﻿namespace Jiaobiao
{
    partial class JiaoBiao
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.gBox4 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.WC_TEXT = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.WB_TEXT = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.WA_TEXT = new System.Windows.Forms.TextBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.Cbo_Port = new System.Windows.Forms.ComboBox();
            this.button3 = new System.Windows.Forms.Button();
            this.gBox3 = new System.Windows.Forms.GroupBox();
            this.VB_TEXT = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.VA_TEXT = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.VC_TEXT = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.IA_TEXT = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.IB_TEXT = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.IC_TEXT = new System.Windows.Forms.TextBox();
            this.rButt015 = new System.Windows.Forms.RadioButton();
            this.rButt15A = new System.Windows.Forms.RadioButton();
            this.PC_TEXT = new System.Windows.Forms.TextBox();
            this.PC = new System.Windows.Forms.Label();
            this.PB_TEXT = new System.Windows.Forms.TextBox();
            this.PB = new System.Windows.Forms.Label();
            this.PA_TEXT = new System.Windows.Forms.TextBox();
            this.PA = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.gBox4.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.gBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.gBox4);
            this.groupBox1.Controls.Add(this.groupBox7);
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Controls.Add(this.gBox3);
            this.groupBox1.Controls.Add(this.rButt015);
            this.groupBox1.Controls.Add(this.rButt15A);
            this.groupBox1.Controls.Add(this.PC_TEXT);
            this.groupBox1.Controls.Add(this.PC);
            this.groupBox1.Controls.Add(this.PB_TEXT);
            this.groupBox1.Controls.Add(this.PB);
            this.groupBox1.Controls.Add(this.PA_TEXT);
            this.groupBox1.Controls.Add(this.PA);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Location = new System.Drawing.Point(12, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(587, 263);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "测试校表流程";
            // 
            // gBox4
            // 
            this.gBox4.Controls.Add(this.label8);
            this.gBox4.Controls.Add(this.WC_TEXT);
            this.gBox4.Controls.Add(this.label7);
            this.gBox4.Controls.Add(this.WB_TEXT);
            this.gBox4.Controls.Add(this.label10);
            this.gBox4.Controls.Add(this.WA_TEXT);
            this.gBox4.Location = new System.Drawing.Point(280, 163);
            this.gBox4.Name = "gBox4";
            this.gBox4.Size = new System.Drawing.Size(211, 100);
            this.gBox4.TabIndex = 58;
            this.gBox4.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(20, 67);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(17, 12);
            this.label8.TabIndex = 50;
            this.label8.Text = "WC";
            // 
            // WC_TEXT
            // 
            this.WC_TEXT.Location = new System.Drawing.Point(54, 64);
            this.WC_TEXT.Name = "WC_TEXT";
            this.WC_TEXT.Size = new System.Drawing.Size(100, 21);
            this.WC_TEXT.TabIndex = 51;
            this.WC_TEXT.Text = "285";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(20, 45);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(17, 12);
            this.label7.TabIndex = 48;
            this.label7.Text = "WB";
            // 
            // WB_TEXT
            // 
            this.WB_TEXT.Location = new System.Drawing.Point(54, 42);
            this.WB_TEXT.Name = "WB_TEXT";
            this.WB_TEXT.Size = new System.Drawing.Size(100, 21);
            this.WB_TEXT.TabIndex = 49;
            this.WB_TEXT.Text = "285";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(20, 18);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(17, 12);
            this.label10.TabIndex = 46;
            this.label10.Text = "WA";
            // 
            // WA_TEXT
            // 
            this.WA_TEXT.Location = new System.Drawing.Point(54, 15);
            this.WA_TEXT.Name = "WA_TEXT";
            this.WA_TEXT.Size = new System.Drawing.Size(100, 21);
            this.WA_TEXT.TabIndex = 47;
            this.WA_TEXT.Text = "285";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.Cbo_Port);
            this.groupBox7.Location = new System.Drawing.Point(6, 70);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(112, 68);
            this.groupBox7.TabIndex = 59;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "串口及通讯设置";
            // 
            // Cbo_Port
            // 
            this.Cbo_Port.FormattingEnabled = true;
            this.Cbo_Port.Location = new System.Drawing.Point(6, 26);
            this.Cbo_Port.Name = "Cbo_Port";
            this.Cbo_Port.Size = new System.Drawing.Size(84, 20);
            this.Cbo_Port.TabIndex = 1;
            this.Cbo_Port.Text = "选择COM";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(6, 195);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 56;
            this.button3.Text = "初始化清需量";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // gBox3
            // 
            this.gBox3.Controls.Add(this.VB_TEXT);
            this.gBox3.Controls.Add(this.label1);
            this.gBox3.Controls.Add(this.VA_TEXT);
            this.gBox3.Controls.Add(this.label2);
            this.gBox3.Controls.Add(this.label3);
            this.gBox3.Controls.Add(this.VC_TEXT);
            this.gBox3.Controls.Add(this.label6);
            this.gBox3.Controls.Add(this.IA_TEXT);
            this.gBox3.Controls.Add(this.label5);
            this.gBox3.Controls.Add(this.IB_TEXT);
            this.gBox3.Controls.Add(this.label4);
            this.gBox3.Controls.Add(this.IC_TEXT);
            this.gBox3.Location = new System.Drawing.Point(136, 46);
            this.gBox3.Name = "gBox3";
            this.gBox3.Size = new System.Drawing.Size(355, 109);
            this.gBox3.TabIndex = 54;
            this.gBox3.TabStop = false;
            // 
            // VB_TEXT
            // 
            this.VB_TEXT.Location = new System.Drawing.Point(36, 49);
            this.VB_TEXT.Name = "VB_TEXT";
            this.VB_TEXT.Size = new System.Drawing.Size(100, 21);
            this.VB_TEXT.TabIndex = 31;
            this.VB_TEXT.Text = "220";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(23, 12);
            this.label1.TabIndex = 28;
            this.label1.Text = "VA:";
            // 
            // VA_TEXT
            // 
            this.VA_TEXT.Location = new System.Drawing.Point(35, 24);
            this.VA_TEXT.Name = "VA_TEXT";
            this.VA_TEXT.Size = new System.Drawing.Size(100, 21);
            this.VA_TEXT.TabIndex = 29;
            this.VA_TEXT.Text = "220";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(23, 12);
            this.label2.TabIndex = 30;
            this.label2.Text = "VB:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 74);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(23, 12);
            this.label3.TabIndex = 32;
            this.label3.Text = "VC:";
            // 
            // VC_TEXT
            // 
            this.VC_TEXT.Location = new System.Drawing.Point(35, 76);
            this.VC_TEXT.Name = "VC_TEXT";
            this.VC_TEXT.Size = new System.Drawing.Size(100, 21);
            this.VC_TEXT.TabIndex = 33;
            this.VC_TEXT.Text = "220";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(164, 29);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(23, 12);
            this.label6.TabIndex = 34;
            this.label6.Text = "IA:";
            // 
            // IA_TEXT
            // 
            this.IA_TEXT.Location = new System.Drawing.Point(198, 26);
            this.IA_TEXT.Name = "IA_TEXT";
            this.IA_TEXT.Size = new System.Drawing.Size(100, 21);
            this.IA_TEXT.TabIndex = 35;
            this.IA_TEXT.Text = "1.5";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(165, 58);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(23, 12);
            this.label5.TabIndex = 36;
            this.label5.Text = "IB:";
            // 
            // IB_TEXT
            // 
            this.IB_TEXT.Location = new System.Drawing.Point(198, 52);
            this.IB_TEXT.Name = "IB_TEXT";
            this.IB_TEXT.Size = new System.Drawing.Size(100, 21);
            this.IB_TEXT.TabIndex = 37;
            this.IB_TEXT.Text = "1.5";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(165, 81);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(23, 12);
            this.label4.TabIndex = 38;
            this.label4.Text = "IC:";
            // 
            // IC_TEXT
            // 
            this.IC_TEXT.Location = new System.Drawing.Point(198, 81);
            this.IC_TEXT.Name = "IC_TEXT";
            this.IC_TEXT.Size = new System.Drawing.Size(100, 21);
            this.IC_TEXT.TabIndex = 39;
            this.IC_TEXT.Text = "1.5";
            // 
            // rButt015
            // 
            this.rButt015.AutoSize = true;
            this.rButt015.Location = new System.Drawing.Point(334, 24);
            this.rButt015.Name = "rButt015";
            this.rButt015.Size = new System.Drawing.Size(53, 16);
            this.rButt015.TabIndex = 53;
            this.rButt015.Text = "0.15A";
            this.rButt015.UseVisualStyleBackColor = true;
            this.rButt015.CheckedChanged += new System.EventHandler(this.rButt015_CheckedChanged);
            // 
            // rButt15A
            // 
            this.rButt15A.AutoSize = true;
            this.rButt15A.Checked = true;
            this.rButt15A.Location = new System.Drawing.Point(162, 24);
            this.rButt15A.Name = "rButt15A";
            this.rButt15A.Size = new System.Drawing.Size(47, 16);
            this.rButt15A.TabIndex = 52;
            this.rButt15A.TabStop = true;
            this.rButt15A.Text = "1.5A";
            this.rButt15A.UseVisualStyleBackColor = true;
            this.rButt15A.CheckedChanged += new System.EventHandler(this.rButt15A_CheckedChanged);
            // 
            // PC_TEXT
            // 
            this.PC_TEXT.Location = new System.Drawing.Point(172, 230);
            this.PC_TEXT.Name = "PC_TEXT";
            this.PC_TEXT.Size = new System.Drawing.Size(100, 21);
            this.PC_TEXT.TabIndex = 45;
            this.PC_TEXT.Text = "165";
            // 
            // PC
            // 
            this.PC.AutoSize = true;
            this.PC.Location = new System.Drawing.Point(143, 228);
            this.PC.Name = "PC";
            this.PC.Size = new System.Drawing.Size(23, 12);
            this.PC.TabIndex = 44;
            this.PC.Text = "PC:";
            // 
            // PB_TEXT
            // 
            this.PB_TEXT.Location = new System.Drawing.Point(173, 203);
            this.PB_TEXT.Name = "PB_TEXT";
            this.PB_TEXT.Size = new System.Drawing.Size(100, 21);
            this.PB_TEXT.TabIndex = 43;
            this.PB_TEXT.Text = "165";
            // 
            // PB
            // 
            this.PB.AutoSize = true;
            this.PB.Location = new System.Drawing.Point(143, 206);
            this.PB.Name = "PB";
            this.PB.Size = new System.Drawing.Size(23, 12);
            this.PB.TabIndex = 42;
            this.PB.Text = "PB:";
            // 
            // PA_TEXT
            // 
            this.PA_TEXT.Location = new System.Drawing.Point(172, 178);
            this.PA_TEXT.Name = "PA_TEXT";
            this.PA_TEXT.Size = new System.Drawing.Size(100, 21);
            this.PA_TEXT.TabIndex = 41;
            this.PA_TEXT.Text = "165";
            // 
            // PA
            // 
            this.PA.AutoSize = true;
            this.PA.Location = new System.Drawing.Point(143, 178);
            this.PA.Name = "PA";
            this.PA.Size = new System.Drawing.Size(23, 12);
            this.PA.TabIndex = 40;
            this.PA.Text = "PA:";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(6, 163);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 1;
            this.button2.Text = "开始校表";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Enabled = false;
            this.button1.Location = new System.Drawing.Point(6, 33);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "读取标准值";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.listBox1);
            this.groupBox2.Location = new System.Drawing.Point(12, 275);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(578, 139);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "显示标准表数值";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 12;
            this.listBox1.Location = new System.Drawing.Point(6, 20);
            this.listBox1.Name = "listBox1";
            this.listBox1.ScrollAlwaysVisible = true;
            this.listBox1.Size = new System.Drawing.Size(566, 112);
            this.listBox1.TabIndex = 0;
            this.listBox1.DoubleClick += new System.EventHandler(this.listBox1_DoubleClick);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(506, 142);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(75, 21);
            this.textBox1.TabIndex = 60;
            this.textBox1.Text = "0.998";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(508, 127);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(29, 12);
            this.label9.TabIndex = 61;
            this.label9.Text = "系数";
            // 
            // JiaoBiao
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(611, 426);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "JiaoBiao";
            this.Text = "校表窗口";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.gBox4.ResumeLayout(false);
            this.gBox4.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.gBox3.ResumeLayout(false);
            this.gBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.RadioButton rButt015;
        private System.Windows.Forms.RadioButton rButt15A;
        private System.Windows.Forms.TextBox PC_TEXT;
        private System.Windows.Forms.Label PC;
        private System.Windows.Forms.TextBox PB_TEXT;
        private System.Windows.Forms.Label PB;
        private System.Windows.Forms.TextBox PA_TEXT;
        private System.Windows.Forms.Label PA;
        private System.Windows.Forms.TextBox IC_TEXT;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox IB_TEXT;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox IA_TEXT;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox VC_TEXT;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox VB_TEXT;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox VA_TEXT;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox gBox3;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.ComboBox Cbo_Port;
        private System.Windows.Forms.GroupBox gBox4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox WC_TEXT;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox WB_TEXT;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox WA_TEXT;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox1;
    }
}