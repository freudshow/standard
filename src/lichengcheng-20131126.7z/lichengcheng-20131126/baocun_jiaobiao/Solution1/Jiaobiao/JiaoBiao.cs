﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;
using ClassBCD;
using System.Threading;

namespace Jiaobiao
{
    public  partial class JiaoBiao : Form
    {
        public JiaoBiao()
        {
            InitializeComponent();
            Cbo_Port.Items.AddRange(System.IO.Ports.SerialPort.GetPortNames());
            
        }

        //private void button1_Click(object sender, EventArgs e)
        //{//读取标准表值          
        //    int IntPhase = 1;// 三相四线有功/正弦无功
        //    int IntResult = 2;
        //    int SourceType = 3;//信号源
        //    int hcAddress = 55;   //标准表地址默认为55
        //    int IntCommandID=3;// 控制命令字 1 ：联机（保留字）2 ：脱机（保留字）3 ：读取标准表显示值 
        //    int IntComPort = SetParClass.SetParClass.mIntComPort;//串口
        //    MeterClass.Standard StrData = new MeterClass.Standard();
        //    IntResult = MeterClass.OperationHC_Fun(SourceType, IntComPort, hcAddress, IntCommandID, IntPhase, ref StrData);

        //     float RealVA=StrData.RealVA;        //A相电压(V)                   
        //     float RealVB = StrData.RealVB;      //B相电压(V)
        //     float RealVC = StrData.RealVC;
        //     float RealPVA = StrData.RealPVA;//总视在功率(VA)
        //     float RealP = StrData.RealP;//总视在有功功率(W)
        //     float RealQ = StrData.RealQ; //总视在无功功率(var)

        //     listBox1.Items.Add("VA ：" + RealVA);
        //     listBox1.Items.Add("VB ：" + RealVB);
        //     listBox1.Items.Add("VC ：" + RealVC);
        //     listBox1.Items.Add("PVA ：" + RealPVA);
        //     listBox1.Items.Add("IP ：" + RealP);
        //     listBox1.Items.Add("IQ ：" + RealQ);
            
        //}
        private byte Count_Cs(byte[] buffe)
        {
            byte cs = 0;
            for (int i = 0; i < buffe.LongLength - 1; i++)
            {
                cs += buffe[i] ;
            }
            return cs;

        }

        private void button2_Click(object sender, EventArgs e)
        {//校正表
            //int count = SetParClass.SetParClass.MeterNo;
            SerialPort spcom = new SerialPort();
            
            spcom.PortName = Cbo_Port.Items[0].ToString();
            spcom.BaudRate = 2400;
            spcom.Parity = Parity.Even;
            spcom.StopBits = StopBits.One;
            spcom.DataBits = 8;
            //SerialPort spcom = new SerialPort("COM3",2400, Parity.Even, 8, StopBits.One);
            if (spcom.IsOpen)
            {
                spcom.Close();
            }
            else
            {
                try
                {
                    spcom.Open();
                    if (spcom.IsOpen)
                        listBox1.Items.Add(Cbo_Port.Items[0].ToString() + "串口打开");
                    else
                        listBox1.Items.Add(Cbo_Port.Items[0].ToString() + "串口失败");
                   
                    byte[] sendbuff = new byte[256];
                    if (rButt15A.Checked)
                    {//1.5a
                      
                        double VA1 = Convert.ToDouble(VA_TEXT.Text) * 10000;
                        double VB1 = Convert.ToDouble(VB_TEXT.Text) * 10000;
                        double VC1 = Convert.ToDouble(VC_TEXT.Text) * 10000;
                        long VA = Convert.ToInt32(VA1);
                        long VB = Convert.ToInt32(VB1);
                        long VC = Convert.ToInt32(VC1);
                        double ia1 = Convert.ToDouble(IA_TEXT.Text);
                        long IA = Convert.ToInt32(ia1 * 10000);
                        double ib1 = Convert.ToDouble(IB_TEXT.Text);
                        long IB = Convert.ToInt32(ib1 * 10000);
                        double ic1 = Convert.ToDouble(IC_TEXT.Text);
                        long IC = Convert.ToInt32(ic1 * 10000);
                        //int IA = Convert.ToInt32(IA_TEXT.Text);

                        //int IB = Convert.ToInt32(IB_TEXT.Text);
                        //int IC = Convert.ToInt32(IC_TEXT.Text);

                        double PA1 = Convert.ToDouble(PA_TEXT.Text);
                        long PA = Convert.ToInt32(PA1 * 10000);
                        double PB1 = Convert.ToDouble(PB_TEXT.Text);
                        long PB = Convert.ToInt32(PB1 * 10000);
                        double PC1 = Convert.ToDouble(PC_TEXT.Text);
                        long PC = Convert.ToInt32(PC1 * 10000);


                        if (WA_TEXT.Text == "")
                        {
                            MessageBox.Show("无功无值！");
                            spcom.Dispose();
                            spcom.Close();
                            return;
                        }
                        double WA1 = Convert.ToDouble(WA_TEXT.Text);
                        long WA = Convert.ToInt32(WA1 * 10000);
                        double WB1 = Convert.ToDouble(WB_TEXT.Text);
                        long WB = Convert.ToInt32(WB1 * 10000);
                        double WC1 = Convert.ToDouble(WC_TEXT.Text);
                        long WC = Convert.ToInt32(WC1 * 10000);

                        byte[] va = ClassBCD.ClassBCD.BCDEncode(VA, 4);

                        byte[] vb = ClassBCD.ClassBCD.BCDEncode(VB, 4);
                        byte[] vc = ClassBCD.ClassBCD.BCDEncode(VC, 4);

                        byte[] ia = ClassBCD.ClassBCD.BCDEncode(IA, 4);
                        byte[] ib = ClassBCD.ClassBCD.BCDEncode(IB, 4);
                        byte[] ic = ClassBCD.ClassBCD.BCDEncode(IC, 4);

                        byte[] pa = ClassBCD.ClassBCD.BCDEncode(PA, 4);
                        byte[] pb = ClassBCD.ClassBCD.BCDEncode(PB, 4);
                        byte[] pc = ClassBCD.ClassBCD.BCDEncode(PC, 4);
                        byte[] wa = ClassBCD.ClassBCD.BCDEncode(WA, 4);
                        byte[] wb = ClassBCD.ClassBCD.BCDEncode(WB, 4);
                        byte[] wc = ClassBCD.ClassBCD.BCDEncode(WC, 4);
                        //{ 0x68, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0x68, 0x14, 0x04, 0x38, 0x33, 0x33, 0x36 };
                        int index = 0;
                        sendbuff[index++] = 0x68;
                        sendbuff[index++] = 0xAA;
                        sendbuff[index++] = 0xAA;
                        sendbuff[index++] = 0xAA;
                        sendbuff[index++] = 0xAA;
                        sendbuff[index++] = 0xAA;
                        sendbuff[index++] = 0xAA;
                        sendbuff[index++] = 0x68;
                        sendbuff[index++] = 0x14;
                        sendbuff[index++] = 0x34;
                        sendbuff[index++] = 0x34;
                        sendbuff[index++] = 0x33;
                        sendbuff[index++] = 0x33;
                        sendbuff[index++] = 0x38;
                        sendbuff[index] = pa[3];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = pa[2];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = pa[1];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = pa[0];
                        sendbuff[index++] += 0x33;

                        sendbuff[index] = pb[3];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = pb[2];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = pb[1];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = pb[0];
                        sendbuff[index++] += 0x33;


                        sendbuff[index] = pc[3];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = pc[2];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = pc[1];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = pc[0];
                        sendbuff[index++] += 0x33;

                        sendbuff[index] = wa[3];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = wa[2];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = wa[1];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = wa[0];
                        sendbuff[index++] += 0x33;

                        sendbuff[index] = wb[3];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = wb[2];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = wb[1];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = wb[0];
                        sendbuff[index++] += 0x33;

                        sendbuff[index] = wc[3];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = wc[2];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = wc[1];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = wc[0];
                        sendbuff[index++] += 0x33;

                        sendbuff[index] = va[3];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = va[2];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = va[1];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = va[0];
                        sendbuff[index++] += 0x33;

                        sendbuff[index] = vb[3];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = vb[2];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = vb[1];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = vb[0];
                        sendbuff[index++] += 0x33;

                        sendbuff[index] = vc[3];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = vc[2];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = vc[1];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = vc[0];
                        sendbuff[index++] += 0x33;

                        sendbuff[index] = ia[3];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = ia[2];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = ia[1];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = ia[0];
                        sendbuff[index++] += 0x33;

                        sendbuff[index] = ib[3];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = ib[2];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = ib[1];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = ib[0];
                        sendbuff[index++] += 0x33;

                        sendbuff[index] = ic[3];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = ic[2];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = ic[1];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = ic[0];
                        sendbuff[index++] += 0x33;
                        //05 00 00 01 // 1.5A校表 
                        sendbuff[index++] = Count_Cs(sendbuff);
                        sendbuff[index++] = 0x16;
                        spcom.Write(sendbuff, 0, index);
                        spcom.WriteTimeout = 500;
                    }
                    else 
                    {//0.15a
                        gBox3.Enabled = false;
                        gBox4.Enabled = false;
                        double PA1 = Convert.ToDouble(PA_TEXT.Text);
                        long PA = Convert.ToInt32(PA1 * 10000);
                        double PB1 = Convert.ToDouble(PB_TEXT.Text);
                        long PB = Convert.ToInt32(PB1 * 10000);
                        double PC1 = Convert.ToDouble(PC_TEXT.Text);
                        long PC = Convert.ToInt32(PC1 * 10000);


                        byte[] pa = ClassBCD.ClassBCD.BCDEncode(PA, 4);
                        byte[] pb = ClassBCD.ClassBCD.BCDEncode(PB, 4);
                        byte[] pc = ClassBCD.ClassBCD.BCDEncode(PC, 4);

                        int index = 0;
                        sendbuff[index++] = 0x68;
                        sendbuff[index++] = 0xAA;
                        sendbuff[index++] = 0xAA;
                        sendbuff[index++] = 0xAA;
                        sendbuff[index++] = 0xAA;
                        sendbuff[index++] = 0xAA;
                        sendbuff[index++] = 0xAA;
                        sendbuff[index++] = 0x68;
                        sendbuff[index++] = 0x14;
                        sendbuff[index++] = 0x10;
                        //05 00 00 02 // 0.15A校表
                        sendbuff[index++] = 0x35;
                        sendbuff[index++] = 0x33;
                        sendbuff[index++] = 0x33;
                        sendbuff[index++] = 0x38;
                        sendbuff[index] = pa[3];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = pa[2];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = pa[1];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = pa[0];
                        sendbuff[index++] += 0x33;

                        sendbuff[index] = pb[3];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = pb[2];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = pb[1];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = pb[0];
                        sendbuff[index++] += 0x33;


                        sendbuff[index] = pc[3];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = pc[2];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = pc[1];
                        sendbuff[index++] += 0x33;
                        sendbuff[index] = pc[0];
                        sendbuff[index++] += 0x33;
                        sendbuff[index++] = Count_Cs(sendbuff);
                        sendbuff[index++] = 0x16;
                   

                    spcom.Write(sendbuff, 0, index);
                    spcom.WriteTimeout = 500;
                    }

                    listBox1.Items.Add("发送完成");
                    spcom.Dispose();
                    spcom.Close();
                  

                }
                catch (TimeoutException)
                {
                    MessageBox.Show("超时");
                    spcom.Dispose();
                    spcom.Close();
                }

            }

           
            

        }


       private byte[]  TEST_015A()
        {//0.15A交表报文
           byte[] sendbuff = new byte[256];
           double PA1 = Convert.ToDouble(PA_TEXT.Text);
           long PA = Convert.ToInt32(PA1 * 10000);
           double PB1 = Convert.ToDouble(PB_TEXT.Text);
           long PB = Convert.ToInt32(PB1 * 10000);
           double PC1 = Convert.ToDouble(PC_TEXT.Text);
           long PC = Convert.ToInt32(PC1 * 10000);
          

           byte[] pa = ClassBCD.ClassBCD.BCDEncode(PA, 4);
           byte[] pb = ClassBCD.ClassBCD.BCDEncode(PB, 4);
           byte[] pc = ClassBCD.ClassBCD.BCDEncode(PC, 4);
          
           int index = 0;
           sendbuff[index++] = 0x68;
           sendbuff[index++] = 0xAA;
           sendbuff[index++] = 0xAA;
           sendbuff[index++] = 0xAA;
           sendbuff[index++] = 0xAA;
           sendbuff[index++] = 0xAA;
           sendbuff[index++] = 0xAA;
           sendbuff[index++] = 0x68;
           sendbuff[index++] = 0x14;
           sendbuff[index++] = 0x10;
           //05 00 00 02 // 0.15A校表
           sendbuff[index++] = 0x35;
           sendbuff[index++] = 0x33;
           sendbuff[index++] = 0x33;
           sendbuff[index++] = 0x38;
           sendbuff[index] = pa[3];
           sendbuff[index++] += 0x33;
           sendbuff[index] = pa[2];
           sendbuff[index++] += 0x33;
           sendbuff[index] = pa[1];
           sendbuff[index++] += 0x33;
           sendbuff[index] = pa[0];
           sendbuff[index++] += 0x33;

           sendbuff[index] = pb[3];
           sendbuff[index++] += 0x33;
           sendbuff[index] = pb[2];
           sendbuff[index++] += 0x33;
           sendbuff[index] = pb[1];
           sendbuff[index++] += 0x33;
           sendbuff[index] = pb[0];
           sendbuff[index++] += 0x33;


           sendbuff[index] = pc[3];
           sendbuff[index++] += 0x33;
           sendbuff[index] = pc[2];
           sendbuff[index++] += 0x33;
           sendbuff[index] = pc[1];
           sendbuff[index++] += 0x33;
           sendbuff[index] = pc[0];
           sendbuff[index++] += 0x33;
           sendbuff[index++] = Count_Cs(sendbuff);
           sendbuff[index++] = 0x16;

           return sendbuff;
          

       }

       //private byte[] TEST_15A() {
       //    //1.5A交表
       //     byte[] sendbuff = new byte[256];
       //             double VA1 = Convert.ToDouble(VA_TEXT.Text) * 10000;                  
       //             double VB1 = Convert.ToDouble(VB_TEXT.Text) * 10000;
       //             double VC1 = Convert.ToDouble(VC_TEXT.Text) * 10000;
       //             long VA = Convert.ToInt32(VA1);
       //             long VB = Convert.ToInt32(VB1);
       //             long VC = Convert.ToInt32(VC1);
       //             double ia1 = Convert.ToDouble(IA_TEXT.Text);
       //             long IA = Convert.ToInt32(ia1 * 10000);
       //             double ib1 = Convert.ToDouble(IB_TEXT.Text);
       //             long IB = Convert.ToInt32(ib1 * 10000);
       //             double ic1 = Convert.ToDouble(IC_TEXT.Text);
       //             long IC = Convert.ToInt32(ic1 * 10000);
       //             //int IA = Convert.ToInt32(IA_TEXT.Text);

       //             //int IB = Convert.ToInt32(IB_TEXT.Text);
       //             //int IC = Convert.ToInt32(IC_TEXT.Text);

       //             double PA1 = Convert.ToDouble(PA_TEXT.Text);
       //             long PA = Convert.ToInt32(PA1 * 10000);
       //             double PB1 = Convert.ToDouble(PB_TEXT.Text);
       //             long PB = Convert.ToInt32(PB1 * 10000);
       //             double PC1 = Convert.ToDouble(PC_TEXT.Text);
       //             long PC = Convert.ToInt32(PC1 * 10000);
       //             double WA1 = Convert.ToDouble(WA_TEXT.Text);
       //             long WA = Convert.ToInt32(WA1 * 10000);
       //             double WB1 = Convert.ToDouble(WB_TEXT.Text);
       //             long WB = Convert.ToInt32(WB1 * 10000);
       //             double WC1 = Convert.ToDouble(WC_TEXT.Text);
       //             long WC = Convert.ToInt32(WC1 * 10000);

       //             byte[] va =ClassBCD.ClassBCD.BCDEncode(VA, 4);

       //             byte[] vb = ClassBCD.ClassBCD.BCDEncode(VB, 4);
       //             byte[] vc = ClassBCD.ClassBCD.BCDEncode(VC, 4);

       //             byte[] ia = ClassBCD.ClassBCD.BCDEncode(IA, 4);
       //             byte[] ib = ClassBCD.ClassBCD.BCDEncode(IB, 4);
       //             byte[] ic = ClassBCD.ClassBCD.BCDEncode(IC, 4);

       //             byte[] pa = ClassBCD.ClassBCD.BCDEncode(PA, 4);
       //             byte[] pb = ClassBCD.ClassBCD.BCDEncode(PB, 4);
       //             byte[] pc = ClassBCD.ClassBCD.BCDEncode(PC, 4);
       //             byte[] wa = ClassBCD.ClassBCD.BCDEncode(WA, 4);
       //             byte[] wb = ClassBCD.ClassBCD.BCDEncode(WB, 4);
       //             byte[] wc = ClassBCD.ClassBCD.BCDEncode(WC, 4);
       //             //{ 0x68, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0x68, 0x14, 0x04, 0x38, 0x33, 0x33, 0x36 };
       //             int index=0;
       //             sendbuff[index++] = 0x68;
       //             sendbuff[index++] = 0xAA;
       //             sendbuff[index++] = 0xAA;
       //             sendbuff[index++] = 0xAA;
       //             sendbuff[index++] = 0xAA;
       //             sendbuff[index++] = 0xAA;
       //             sendbuff[index++] = 0xAA;
       //             sendbuff[index++] = 0x68;
       //             sendbuff[index++] = 0x14;
       //             sendbuff[index++] = 0x34;
       //             sendbuff[index++] = 0x34;
       //             sendbuff[index++] = 0x33;
       //             sendbuff[index++] = 0x33;
       //             sendbuff[index++] = 0x38;
       //             sendbuff[index] = pa[3];
       //             sendbuff[index++] += 0x33;
       //             sendbuff[index] = pa[2];
       //             sendbuff[index++] += 0x33;
       //             sendbuff[index] = pa[1];
       //             sendbuff[index++] += 0x33;
       //             sendbuff[index] = pa[0];
       //             sendbuff[index++] += 0x33;

       //             sendbuff[index] = pb[3];
       //             sendbuff[index++] += 0x33;
       //             sendbuff[index] = pb[2];
       //             sendbuff[index++] += 0x33;
       //             sendbuff[index] = pb[1];
       //             sendbuff[index++] += 0x33;
       //             sendbuff[index] = pb[0];
       //             sendbuff[index++] += 0x33;
                  

       //             sendbuff[index] = pc[3];
       //             sendbuff[index++] += 0x33;
       //             sendbuff[index] = pc[2];
       //             sendbuff[index++] += 0x33;
       //             sendbuff[index] = pc[1];
       //             sendbuff[index++] += 0x33;
       //             sendbuff[index] = pc[0];
       //             sendbuff[index++] += 0x33;

       //             sendbuff[index] = wa[3];
       //             sendbuff[index++] += 0x33;
       //             sendbuff[index] = wa[2];
       //             sendbuff[index++] += 0x33;
       //             sendbuff[index] = wa[1];
       //             sendbuff[index++] += 0x33;
       //             sendbuff[index] = wa[0];
       //             sendbuff[index++] += 0x33;

       //             sendbuff[index] = wb[3];
       //             sendbuff[index++] += 0x33;
       //             sendbuff[index] = wb[2];
       //             sendbuff[index++] += 0x33;
       //             sendbuff[index] = wb[1];
       //             sendbuff[index++] += 0x33;
       //             sendbuff[index] = wb[0];
       //             sendbuff[index++] += 0x33;

       //             sendbuff[index] = wc[3];
       //             sendbuff[index++] += 0x33;
       //             sendbuff[index] = wc[2];
       //             sendbuff[index++] += 0x33;
       //             sendbuff[index] = wc[1];
       //             sendbuff[index++] += 0x33;
       //             sendbuff[index] = wc[0];
       //             sendbuff[index++] += 0x33;

       //             sendbuff[index] = va[3];
       //             sendbuff[index++] += 0x33;
       //             sendbuff[index] = va[2];
       //             sendbuff[index++] += 0x33;
       //             sendbuff[index] = va[1];
       //             sendbuff[index++] += 0x33;
       //             sendbuff[index] = va[0];
       //             sendbuff[index++] += 0x33;

       //             sendbuff[index] = vb[3];
       //             sendbuff[index++] += 0x33;
       //             sendbuff[index] = vb[2];
       //             sendbuff[index++] += 0x33;
       //             sendbuff[index] = vb[1];
       //             sendbuff[index++] += 0x33;
       //             sendbuff[index] = vb[0];
       //             sendbuff[index++] += 0x33;

       //             sendbuff[index] = vc[3];
       //             sendbuff[index++] += 0x33;
       //             sendbuff[index] = vc[2];
       //             sendbuff[index++] += 0x33;
       //             sendbuff[index] = vc[1];
       //             sendbuff[index++] += 0x33;
       //             sendbuff[index] = vc[0];
       //             sendbuff[index++] += 0x33;

       //             sendbuff[index] = ia[3];
       //             sendbuff[index++] += 0x33;
       //             sendbuff[index] = ia[2];
       //             sendbuff[index++] += 0x33;
       //             sendbuff[index] = ia[1];
       //             sendbuff[index++] += 0x33;
       //             sendbuff[index] = ia[0];
       //             sendbuff[index++] += 0x33;
                    
       //             sendbuff[index] = ib[3];
       //             sendbuff[index++] += 0x33;
       //             sendbuff[index] = ib[2];
       //             sendbuff[index++] += 0x33;
       //             sendbuff[index] = ib[1];
       //             sendbuff[index++] += 0x33;
       //             sendbuff[index] = ib[0];
       //             sendbuff[index++] += 0x33;

       //             sendbuff[index] = ic[3];
       //             sendbuff[index++] += 0x33;
       //             sendbuff[index] = ic[2];
       //             sendbuff[index++] += 0x33;
       //             sendbuff[index] = ic[1];
       //             sendbuff[index++] += 0x33;
       //             sendbuff[index] = ic[0];
       //             sendbuff[index++] += 0x33;
       //           //05 00 00 01 // 1.5A校表 
       //             sendbuff[index++] = Count_Cs(sendbuff);
       //             sendbuff[index++] = 0x16;
       //             return sendbuff;
       //}

       private void button3_Click(object sender, EventArgs e)
       {
           SerialPort spcom = new SerialPort();

           spcom.PortName = Cbo_Port.Items[0].ToString();
           spcom.BaudRate = 2400;
           spcom.Parity = Parity.Even;
           spcom.StopBits = StopBits.One;
           spcom.DataBits = 8;
            //SerialPort spcom = new SerialPort("COM3",2400, Parity.Even, 8, StopBits.One);
            if (spcom.IsOpen)
            {
                spcom.Close();
            }
            else
            {
                try
                {
                    spcom.Open();
                    if (spcom.IsOpen)
                        listBox1.Items.Add(Cbo_Port.Items[0].ToString() + "串口打开");
                    else
                        listBox1.Items.Add(Cbo_Port.Items[0].ToString()+"串口失败");
                   
                    byte[] sendbuff = new byte[256];
                    int index = 0;
                    sendbuff[index++] = 0x68;
                    sendbuff[index++] = 0xAA;
                    sendbuff[index++] = 0xAA;
                    sendbuff[index++] = 0xAA;
                    sendbuff[index++] = 0xAA;
                    sendbuff[index++] = 0xAA;
                    sendbuff[index++] = 0xAA;
                    sendbuff[index++] = 0x68;
                    sendbuff[index++] = 0x14;
                    sendbuff[index++] = 0x04;
                    //05 00 00 03 // 清需量参数，初始化设置
                    sendbuff[index++] = 0x38;
                    sendbuff[index++] = 0x33;
                    sendbuff[index++] = 0x33;
                    sendbuff[index++] = 0x36;
                    sendbuff[index++] = Count_Cs(sendbuff);
                    sendbuff[index++] = 0x16;
                    spcom.Write(sendbuff, 0, index);
                    Thread.Sleep(200);
                    spcom.WriteTimeout = 500;
                    listBox1.Items.Add("发送完成");
                    spcom.Dispose();
                    spcom.Close();
                }
                catch (TimeoutException)
                {
                    MessageBox.Show("超时");
                    spcom.Dispose();
                    spcom.Close();
                }
            }

       }

       private void rButt15A_CheckedChanged(object sender, EventArgs e)
       {
           gBox3.Enabled = true;
           gBox4.Enabled = true;

       }

       private void rButt015_CheckedChanged(object sender, EventArgs e)
       {
           gBox3.Enabled = false;
           gBox4.Enabled = false;
           PA_TEXT.Text = "16.";
           PB_TEXT.Text = "16.";
           PC_TEXT.Text = "16.";


       }

       private void listBox1_DoubleClick(object sender, EventArgs e)
       {
           listBox1.Items.Clear();
       }

       
    }
}
