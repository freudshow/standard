﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using SetParClass;
using Demo_Class;
using Demo_CNet_DLL7000;

namespace JiaoBiao
{
    public partial class JiaoBiao : Form
    {
        public JiaoBiao()
        {
            InitializeComponent();
            //listBox1.Items.Add("VA:" );
            //listBox1.Items.Add("VB:" );
            //listBox1.Items.Add("VC:" );
            //listBox1.Items.Add("PVA:" );
            //listBox1.Items.Add("IP:" );
            //listBox1.Items.Add("IQ：" );
        }

        private void button1_Click(object sender, EventArgs e)
        {//读取标准表值          
            int IntPhase = 1;// 三相四线有功/正弦无功
            int IntResult = 2;
            int SourceType = 3;//信号源
            int hcAddress = 55;   //标准表地址默认为55
            int IntCommandID=3;// 控制命令字 1 ：联机（保留字）2 ：脱机（保留字）3 ：读取标准表显示值 
            int IntComPort = SetParClass.SetParClass.mIntComPort;//串口
            MeterClass.Standard StrData = new MeterClass.Standard();
            IntResult = MeterClass.OperationHC_Fun(SourceType, IntComPort, hcAddress, IntCommandID, IntPhase, ref StrData);


             float RealVA=StrData.RealVA;        //A相电压(V)                   
             float RealVB = StrData.RealVB;      //B相电压(V)
             float RealVC = StrData.RealVC;
             float RealPVA = StrData.RealPVA;//总视在功率(VA)
             float RealP = StrData.RealP;//总视在有功功率(W)
             float RealQ = StrData.RealQ; //总视在无功功率(var)

            
             listBox1.Items.Add("VA ：" + RealVA);
             //listBox1.Items.AddRange(new object[] { "VA ：" + RealVA, "VA ：" + RealVA, "VA ：" + RealVA });
             listBox1.Items.Add("VB ：" + RealVB);
             listBox1.Items.Add("VC ：" + RealVC);
             listBox1.Items.Add("PVA ：" + RealPVA);
             listBox1.Items.Add("IP ：" + RealP);
             listBox1.Items.Add("IQ ：" + RealQ);


             VA_TEXT.Text = StrData.RealVA.ToString();
             VB_TEXT.Text = StrData.RealVB.ToString();
             VC_TEXT.Text = StrData.RealVC.ToString();

             IA_TEXT.Text = StrData.RealAA.ToString();
             IB_TEXT.Text = StrData.RealAB.ToString();
             IC_TEXT.Text = StrData.RealAC.ToString();

             PA_TEXT.Text = StrData.RealWA.ToString();
             PB_TEXT.Text = StrData.RealWB.ToString();
             PC_TEXT.Text = StrData.RealWC.ToString();

             IA_TEXT.Text = StrData.RealAA.ToString();
             IB_TEXT.Text = StrData.RealAB.ToString();
             IC_TEXT.Text = StrData.RealAC.ToString();

            
        }

        private void button2_Click(object sender, EventArgs e)
        {//校正表
            int count = SetParClass.SetParClass.MeterNo;
            int Type;
            //2.报文格式
            int VA = Convert.ToInt32(VA_TEXT.Text);
            int VB = Convert.ToInt32(VB_TEXT.Text);
            int VC = Convert.ToInt32(VC_TEXT.Text);

            int IA = Convert.ToInt32(IA_TEXT.Text);
            int IB = Convert.ToInt32(IB_TEXT.Text);
            int IC = Convert.ToInt32(IC_TEXT.Text);

            int PA = Convert.ToInt32(PA_TEXT.Text);
            int PB = Convert.ToInt32(PB_TEXT.Text);
            int PC = Convert.ToInt32(PC_TEXT.Text);
            int WA = Convert.ToInt32(WA_TEXT.Text);
            int WB = Convert.ToInt32(WB_TEXT.Text);
            int WC = Convert.ToInt32(WC_TEXT.Text);

            byte[] va = BCDEncode(VA, 4);
            byte[] vb = BCDEncode(VB, 4);
            byte[] vc = BCDEncode(VC, 4);

            byte[] ia = BCDEncode(VA, 4);
            byte[] ib = BCDEncode(VB, 4);
            byte[] ic = BCDEncode(VC, 4);
                
           
            if (rButt15A.Checked == true)
            {
                Type = 1;
             
            }
            else if (rButt015.Checked == true)
            {
                Type = 2;
            }
            else
            {
                Type = 1;
            }

            if (Type == 1)
            {//1.5A

                byte[] sendBuffer = { 0x68, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA,0x68,0x14,0x34,0x05 ,0x00 ,0x00 ,0x01 };
            }

        }
           

       
        public static byte[] BCDEncode(this int intvalue, int byteLength)
        {
            byte[] r = new byte[byteLength];
            char[] chars = intvalue.ToString().ToCharArray();
            int clengh = chars.Length;
            int[] ints = new int[clengh];
            for (int j = 0; j < clengh; j++)
            {
                ints[j] = Convert.ToInt32(chars[j].ToString());
            }

            int rvalue = GetSum(16, ints);

            byte[] sas = BitConverter.GetBytes(rvalue);
            byte[] ras = new byte[byteLength];
            for (int k = 0; k < byteLength; k++)
            {
                ras[byteLength - k - 1] = sas[k];
            }
            return ras;

        }
        private static int GetSum(int baseInt, int[] sValue)
        {
            int count = sValue.Length;
            if (count == 1) return sValue[0];
            int r = 1;
            int b = sValue[0];
            for (int i = 1; i < count; i++)
            {
                r *= baseInt;
            }
            count--;
            int[] ri = new int[sValue.Length - 1];
            for (int j = 0; j < ri.Length; j++)
            {
                ri[j] = sValue[j + 1];
            }
            return b * r + GetSum(baseInt, ri);
        }

        private void button3_Click(object sender, EventArgs e)
        {


        }



    }
}
