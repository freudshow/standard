#ifndef WS40_H_
#define WS40_H_

#endif /*WS40_H_*/

void WsDlt645GetData(unsigned char i);
unsigned char WS40DdCheck(unsigned char *buff, unsigned int len);
unsigned char WS40GetVlue(unsigned char *Addr,unsigned char DI1,unsigned char DI0,unsigned char *Dest,unsigned char GetNum);
void WsGetDemand_N_Set_Value(unsigned char DDNo);
void WsGetMaximum_Demand_N_Set_Value(unsigned char DDNo);
void ToBcd(unsigned char *s,unsigned char *d,unsigned char len);
void WsGetMaximum_Demand_Time_N_Set_Value(unsigned char DDNo);
void WsGetVariable_Set_value(unsigned char DDNo);
unsigned int WS_GetData(unsigned char *S,unsigned char Num);
void WS_GetDataTime(unsigned char *S,unsigned char *D,unsigned char Num);
void WS_Data_Calc(unsigned char DDNo);
