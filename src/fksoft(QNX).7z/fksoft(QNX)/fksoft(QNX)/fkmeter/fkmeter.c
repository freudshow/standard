#include <stdio.h>
#include <string.h>
#include <termios.h>
#include <fcntl.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <ctype.h>
#include <time.h>
#include <signal.h>
#include <sys/sched.h>
#include <semaphore.h>
#include <process.h>
#include <sys/neutrino.h>
#include <sys/netmgr.h>
#include <sys/dispatch.h>
#include <errno.h>
#include <hw/inout.h>

#include <fkbase/fkbasefun.h>
#include "fkmeter.h"
#include "DLT645.h"
#include "DLT645_2007_DEF.h"
#include "iec62056-21.h"
extern unsigned int old_z_p_all[8];

const char verstr[]={"VER-STRING-FLG=008.002.217.004"__DATE__" "__TIME__};
//-------------------------------------------------------------------
void markver()//��Ŀ������б�ʶ�����汾��Ϣ
{
	printf("\n%s\n", verstr);
}

unsigned char CmpINT8U(unsigned char *s,unsigned char *d,unsigned char len)
{
	unsigned char ret,i;
	ret=0;
	for(i=0;i<len;i++)
	{
		if(s[i]!=d[i])
		return 1;
	}
	return 0;
}
unsigned int CalcSec(unsigned int s,unsigned int d)
{
	unsigned int  temp;
	if(s>d)
	{
		temp=s-d;
	}
	else
	{
		temp=d-s;
	}
	if(temp>=30)
	{
		return 60-temp;
	}
	else
	{
		return temp;
	}
}
void TimeGetType15(INT8U *D,TS ts)
{
	D[0]=ts.Minute/10;
	D[0]=(D[0]<<4)+(ts.Minute%10);
	D[1]=ts.Hour/10;
	D[1]=(D[1]<<4)+(ts.Hour%10);
	D[2]=ts.Day/10;
	D[2]=(D[2]<<4)+(ts.Day%10);
	D[3]=ts.Month/10;
	D[3]=(D[3]<<4)+(ts.Month%10);
	D[4]=(ts.Year%100)/10;
	D[4]=(D[4]<<4)+(ts.Year%10);
}
void REC_485_ON()
{
	switch(PORT_ID)
	{
		case 1:
			SetSpiLed(CB1REC);
			break;
		case 2:
			SetSpiLed(CB2REC);
			break;
	}
}
void OFF_R485()
{
	switch(PORT_ID)
	{
		case 1:
			ClearSpiLed(CB1REC);
			break;
		case 2:
			ClearSpiLed(CB2REC);
			break;
	}
}
void SEND_485_ON()
{
	switch(PORT_ID)
	{
		case 1:
			SetSpiLed(CB1SEND);
			break;
		case 2:
			SetSpiLed(CB2SEND);
			break;
	}
	return;
}
void OFF_S485()
{
	switch(PORT_ID)
	{
		case 1:
			ClearSpiLed(CB1SEND);
			break;
		case 2:
			ClearSpiLed(CB2SEND);
			break;
	}
	return;
}
int BCDTo_INT32(unsigned char *S,unsigned char len)
{
	int i;
	int Result=0;
	for(i=len;i>0;i--)
	{
		if(i==len)
		{
			Result=(Result*10)+((S[i-1]>>4)&0x7);//����λȡ����λת��Ϊ��λ
			Result=(Result*10)+(S[i-1]&0xf);//����λת��Ϊ��λ+��λ
		}
		else
		{
			Result=(Result*10)+((S[i-1]>>4)&0xf);//����λת��Ϊ��λ
			Result=(Result*10)+(S[i-1]&0xf);//����λת��Ϊ����λ+����λ
		}
	}
	if(S[len-1]&0x80)//����Ǹ�ֵ��result����1000,0000����Ϊ1��Ϊ��ֵ��
	{
		return 0-Result;
	}
	return Result;

}
void ValidInit()
{
	memset(&Demand_N_Set_Value.valid,0,sizeof(Demand_N_Set_Value));
	memset(&Maximum_Demand_N_Set_Value.valid,0,sizeof(Maximum_Demand_N_Set_Value));
	memset(&Maximum_Demand_Time_N_Set_Value.valid,0,sizeof(Maximum_Demand_Time_N_Set_Value));
	memset(&Variable_Set_value.valid,0,sizeof(Variable_Set_value));
}
void pro_CL_ERR8(unsigned short i)//���ܱ��������
{
	if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)//�ն��¼���¼��������
	{
		if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[0]&0x80)//��Ҫ�Բ������ý����¼���¼
		{
			Dlt645Dbg("\r\n   ERR8      \r\n");
			RtuDataAddr->Event_Save.Event.Err8.ERCNo=8;
			RtuDataAddr->Event_Save.Event.Err8.len=8;

			RtuDataAddr->Event_Save.Event.Err8.Cl_No[0]=(RtuDataAddr->Meter_Para.Dian_Meter[i].CeLiangNo&0xff);//�������
			RtuDataAddr->Event_Save.Event.Err8.Cl_No[1]=((RtuDataAddr->Meter_Para.Dian_Meter[i].CeLiangNo>>8)&0xff);
			RtuDataAddr->Event_Save.Event.Err8.BiaoZhi=RtuDataAddr->e;
			if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[0]&0x80)//��Ҫ�¼������λΪ1��Ϊ��Ҫ�¼���
			{
				SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err8.Occur_Time.BCD01,1,8);
			}
			else//һ���¼�
			{
				SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err8.Occur_Time.BCD01,2,8);
			}
		}
	}

}

void pro_ERR13(unsigned short i)//���������Ϣ--���ܱ����Ƿѹ
{
	if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)
	{
		if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[1]&0x10)//��Ҫ�Բ������ý����¼���¼
		{
			RtuDataAddr->Event_Save.Event.Err13.ERCNo=13;
			RtuDataAddr->Event_Save.Event.Err13.len=8;
			RtuDataAddr->Event_Save.Event.Err13.ClNo[0]=(i+1)&0xff;//����
			RtuDataAddr->Event_Save.Event.Err13.ClNo[1]=(((i+1)>>8)&0xff);//����
			RtuDataAddr->Event_Save.Event.Err13.Biaozhi=0x10;  //0001 0000 -- ���ܱ����Ƿѹ
			if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[1]&0x10)//��Ҫ�¼�
			{
				SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err13.Occur_Time.BCD01,1,13);
			}
			else//һ���¼�
			{
				SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err13.Occur_Time.BCD01,2,13);
			}
		}
	}
}

void pro_ERR33(unsigned short i,unsigned char chg[14],unsigned char stat[14])
{
	//printf("\n\r\n\r\n\r\n\r\n\r Err33 Begin !!!!!!!!!\n\r\n\r\n\r\n\r\n\r");
	//printf("\n\r");
	if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)
	{
		if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[4]&0x01)//��Ҫ�Բ������ý����¼���¼
		{
			RtuDataAddr->Event_Save.Event.Err33.ERCNo=33;
			RtuDataAddr->Event_Save.Event.Err33.len=35;
			RtuDataAddr->Event_Save.Event.Err33.ClNo[0]=i+1;//����
			RtuDataAddr->Event_Save.Event.Err33.ClNo[1]=0;//����
			memcpy(RtuDataAddr->Event_Save.Event.Err33.statChg,chg,14);
			memcpy(RtuDataAddr->Event_Save.Event.Err33.statN,stat,14);
			if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[4]&0x01)//��Ҫ�¼�
			{
				SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err33.Occur_Time.BCD01,1,33);
			}
			else//һ���¼�
			{
				SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err33.Occur_Time.BCD01,2,33);
			}
		}
	}
}

void pro_CL_ERR12(unsigned short i)//���ܱ�ʱ�䳬��
{
	if((MetTimeErr^MetTimeErrOld)==(1<<i))//�����ͬΪ��
	{
		if((MetTimeErr&(1<<i))==(1<<i))
		{
			if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)
			{
				NeedSetTime=1;//--------------------------//
				if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[1]&0x08)//��Ҫ�Բ������ý����¼���¼
				{
					RtuDataAddr->Event_Save.Event.Err12.ERCNo=12;
					RtuDataAddr->Event_Save.Event.Err12.len=7;
					RtuDataAddr->Event_Save.Event.Err12.ClNo[0]=(RtuDataAddr->Meter_Para.Dian_Meter[i].CeLiangNo)&0xff;
					RtuDataAddr->Event_Save.Event.Err12.ClNo[1]=((RtuDataAddr->Meter_Para.Dian_Meter[i].CeLiangNo>>8)&0xff)|0x80;
					if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[1]&0x08)//��Ҫ�¼�
					{
						SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err12.Occur_Time.BCD01,1,12);
					}
					else//һ���¼�
					{
						SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err12.Occur_Time.BCD01,2,12);
					}
				}
			}
		}
		else
		{
			if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)
			{
				NeedSetTime=0;//--------------------------//
				if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[1]&0x08)//��Ҫ�Բ������ý����¼���¼
				{
					RtuDataAddr->Event_Save.Event.Err12.ERCNo=12;
					RtuDataAddr->Event_Save.Event.Err12.len=7;

					RtuDataAddr->Event_Save.Event.Err12.ClNo[0]=(RtuDataAddr->Meter_Para.Dian_Meter[i].CeLiangNo)&0xff;
					RtuDataAddr->Event_Save.Event.Err12.ClNo[1]=((RtuDataAddr->Meter_Para.Dian_Meter[i].CeLiangNo>>8)&0xff);

					if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[1]&0x08)//��Ҫ�¼�
					{
						SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err12.Occur_Time.BCD01,1,12);
					}
					else//һ���¼�
					{
						SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err12.Occur_Time.BCD01,2,12);
					}
				}
			}
		}
	}
}

void UpdateValue(unsigned short i)
{
	if(RtuDataAddr->DD_Device_BiaoShi_Value[i].Valid!=1)
		return;
	RtuDataAddr->CL_ERR[i].OldDuanXiangNum=BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[i].Duanxiang_All,2);
	RtuDataAddr->CL_ERR[i].OldMacPZero=BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[i].ZeroNum,2);
	RtuDataAddr->CL_ERR[i].OldProgNum=BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[i].ProgNum,2);

	RtuDataAddr->CL_ERR[i].OldTingDianNum=BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[i].Tingdian,3);
	RtuDataAddr->CL_ERR[i].BetteryLow= (RtuDataAddr->DD_BianLiang_Shuju[i].Dian_biao_stat[0][0]>>2)&0x01;
	RtuDataAddr->CL_ERR[i].BetteryLow2= (RtuDataAddr->DD_BianLiang_Shuju[i].Dian_biao_stat[0][0]>>3)&0x01;
	memcpy(RtuDataAddr->CL_ERR[i].PChangShu,RtuDataAddr->DD_BianLiang_Shuju[i].PChangShu,3);
	memcpy(RtuDataAddr->CL_ERR[i].QChangShu,RtuDataAddr->DD_BianLiang_Shuju[i].QChangShu,3);
	RtuDataAddr->CL_ERR[i].Year_ShiQu=RtuDataAddr->DD_BianLiang_Shuju[i].Year_ShiQu;
	RtuDataAddr->CL_ERR[i].Day_ShiDuanBiao=RtuDataAddr->DD_BianLiang_Shuju[i].Day_ShiDuanBiao;
	RtuDataAddr->CL_ERR[i].Now_ShiDuan=RtuDataAddr->DD_BianLiang_Shuju[i].Now_ShiDuan;
	RtuDataAddr->CL_ERR[i].FeiLvShu=RtuDataAddr->DD_BianLiang_Shuju[i].FeiLvShu;
	RtuDataAddr->CL_ERR[i].GongGongJiari=RtuDataAddr->DD_BianLiang_Shuju[i].GongGongJiari;
	memcpy(RtuDataAddr->CL_ERR[i].Chao_biao_riqi,RtuDataAddr->DD_BianLiang_Shuju[i].Chao_biao_riqi,2);//���ܱ����ʱ�����
}
void pro_CL_ERR17(unsigned char i,unsigned char Flag,unsigned char* unU,unsigned char* unI)
{
	//printf("\n\r chaobiao banduan !!!!!!!!!!!!!!!!!");
	//printf("\n\r");
	if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)
	{
		if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[2]&0x01)//��Ҫ�¼�
		{
			RtuDataAddr->Event_Save.Event.Err17.ERCNo=17;
			RtuDataAddr->Event_Save.Event.Err17.len=27;

			RtuDataAddr->Event_Save.Event.Err17.CeliangNo[0]=(i+1)&0xff;
			RtuDataAddr->Event_Save.Event.Err17.CeliangNo[1]=(((i+1)>>8)&0xff)|0x80;
			RtuDataAddr->Event_Save.Event.Err17.Flag=Flag;
			memcpy(&RtuDataAddr->Event_Save.Event.Err17.UBalance[0],unU,2);
			memcpy(&RtuDataAddr->Event_Save.Event.Err17.IBalance[0],unI,2);

			INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA,&RtuDataAddr->Event_Save.Event.Err17.UA[0],2);
			INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB,&RtuDataAddr->Event_Save.Event.Err17.UB[0],2);
			INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC,&RtuDataAddr->Event_Save.Event.Err17.UC[0],2);
			INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[i].IA*10),&RtuDataAddr->Event_Save.Event.Err17.IA[0],3);
			INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[i].IB*10),&RtuDataAddr->Event_Save.Event.Err17.IB[0],3);
			INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[i].IC*10),&RtuDataAddr->Event_Save.Event.Err17.IC[0],3);

			if (Flag == 0x01)
				memcpy(&RtuDataAddr->Event_Save.Event.Err17.Occur_Time.BCD01,&RtuDataAddr->DD_BianLiang_Shuju[i].U_Unbalance.StartTime[1],5);
			else
				memcpy(&RtuDataAddr->Event_Save.Event.Err17.Occur_Time.BCD01,&RtuDataAddr->DD_BianLiang_Shuju[i].I_Unbalance.StartTime[1],5);

			if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[2]&0x01)
			{//��Ҫ�¼�
				SaveEveBuff_ER17(1,17);
			}
			else//һ���¼�
			{
				SaveEveBuff_ER17(2,17);
			}
		}
	}
}
void Pro_CL_ERR(unsigned char i)
{
	TS ts;
	int TingDianNum;
	RtuDataAddr->e=0;
	if(RtuDataAddr->DD_BianLiang_Shuju[i].Valid!=1)return;
	if (RtuDataAddr->CL_ERR[i].TimePronumOld!=BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[i].TimePronum,3) )
	{
		RtuDataAddr->e=RtuDataAddr->e|0x1;
		RtuDataAddr->CL_ERR[i].TimePronumOld =BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[i].TimePronum,3);
	}
	if((RtuDataAddr->CL_ERR[i].ProgTime[0]!=RtuDataAddr->DD_BianLiang_Shuju[i].LastProg_Time[0])||
		(RtuDataAddr->CL_ERR[i].ProgTime[1]!=RtuDataAddr->DD_BianLiang_Shuju[i].LastProg_Time[1])||
		(RtuDataAddr->CL_ERR[i].ProgTime[2]!=RtuDataAddr->DD_BianLiang_Shuju[i].LastProg_Time[2])||
		(RtuDataAddr->CL_ERR[i].ProgTime[3]!=RtuDataAddr->DD_BianLiang_Shuju[i].LastProg_Time[3]))
	{
		RtuDataAddr->e=RtuDataAddr->e|0x02;
		memcpy(RtuDataAddr->CL_ERR[i].ProgTime,RtuDataAddr->DD_BianLiang_Shuju[i].LastProg_Time,4);//���ܱ����ʱ�����
	}

	if((RtuDataAddr->CL_ERR[i].PChangShu[0]!=RtuDataAddr->DD_BianLiang_Shuju[i].PChangShu[0])||
		(RtuDataAddr->CL_ERR[i].PChangShu[1]!=RtuDataAddr->DD_BianLiang_Shuju[i].PChangShu[1])||
		(RtuDataAddr->CL_ERR[i].PChangShu[2]!=RtuDataAddr->DD_BianLiang_Shuju[i].PChangShu[2]))
	{
		RtuDataAddr->e=RtuDataAddr->e|0x08;
		memcpy(RtuDataAddr->CL_ERR[i].PChangShu,RtuDataAddr->DD_BianLiang_Shuju[i].PChangShu,3);
	}

	if((RtuDataAddr->CL_ERR[i].QChangShu[0]!=RtuDataAddr->DD_BianLiang_Shuju[i].QChangShu[0])||
		(RtuDataAddr->CL_ERR[i].QChangShu[1]!=RtuDataAddr->DD_BianLiang_Shuju[i].QChangShu[1])||
		(RtuDataAddr->CL_ERR[i].QChangShu[2]!=RtuDataAddr->DD_BianLiang_Shuju[i].QChangShu[2]))
	{
		RtuDataAddr->e=RtuDataAddr->e|0x08;
		memcpy(RtuDataAddr->CL_ERR[i].PChangShu,RtuDataAddr->DD_BianLiang_Shuju[i].PChangShu,3);
	}
	if((RtuDataAddr->CL_ERR[i].Chao_biao_riqi[0]!=RtuDataAddr->DD_BianLiang_Shuju[i].Chao_biao_riqi[0])||
		(RtuDataAddr->CL_ERR[i].Chao_biao_riqi[1]!=RtuDataAddr->DD_BianLiang_Shuju[i].Chao_biao_riqi[1]))
	{
		RtuDataAddr->e=RtuDataAddr->e|0x04;
		memcpy(RtuDataAddr->CL_ERR[i].Chao_biao_riqi,RtuDataAddr->DD_BianLiang_Shuju[i].Chao_biao_riqi,2);//���ܱ����ʱ�����
	}
	if((RtuDataAddr->CL_ERR[i].Year_ShiQu!=RtuDataAddr->DD_BianLiang_Shuju[i].Year_ShiQu)||
	(RtuDataAddr->CL_ERR[i].Day_ShiDuanBiao!=RtuDataAddr->DD_BianLiang_Shuju[i].Day_ShiDuanBiao)||
	(RtuDataAddr->CL_ERR[i].Now_ShiDuan!=RtuDataAddr->DD_BianLiang_Shuju[i].Now_ShiDuan)||
	(RtuDataAddr->CL_ERR[i].FeiLvShu!=RtuDataAddr->DD_BianLiang_Shuju[i].FeiLvShu)||
	(RtuDataAddr->CL_ERR[i].GongGongJiari!=RtuDataAddr->DD_BianLiang_Shuju[i].GongGongJiari))
	{
		RtuDataAddr->e=RtuDataAddr->e|0x1;
	}
	if(RtuDataAddr->CL_ERR[i].c41e!=Variable_Set_value.c41e)
	{
		RtuDataAddr->e=RtuDataAddr->e|0x1;
	}
	if(CmpINT8U(RtuDataAddr->CL_ERR[i].c320,Variable_Set_value.c320,30))
	{
		RtuDataAddr->e=RtuDataAddr->e|0x1;
	}
	if(CmpINT8U(RtuDataAddr->CL_ERR[i].c330,Variable_Set_value.c330,30))
	{
		RtuDataAddr->e=RtuDataAddr->e|0x1;
	}
	if(CmpINT8U(RtuDataAddr->CL_ERR[i].c340,Variable_Set_value.c340,30))
	{
		RtuDataAddr->e=RtuDataAddr->e|0x1;
	}
	if(CmpINT8U(RtuDataAddr->CL_ERR[i].c350,Variable_Set_value.c350,30))
	{
		RtuDataAddr->e=RtuDataAddr->e|0x1;
	}
	if(CmpINT8U(RtuDataAddr->CL_ERR[i].c360,Variable_Set_value.c360,30))
	{
		RtuDataAddr->e=RtuDataAddr->e|0x1;
	}
	if(CmpINT8U(RtuDataAddr->CL_ERR[i].c370,Variable_Set_value.c370,30))
	{
		RtuDataAddr->e=RtuDataAddr->e|0x1;
	}
	if(CmpINT8U(RtuDataAddr->CL_ERR[i].c380,Variable_Set_value.c380,30))
	{
		RtuDataAddr->e=RtuDataAddr->e|0x1;
	}
	if(CmpINT8U(RtuDataAddr->CL_ERR[i].c390,Variable_Set_value.c390,30))
	{
		RtuDataAddr->e=RtuDataAddr->e|0x1;
	}
	if(CmpINT8U(RtuDataAddr->CL_ERR[i].c3a0,Variable_Set_value.c3a0,30))
	{
		RtuDataAddr->e=RtuDataAddr->e|0x1;
	}
	if(CmpINT8U(RtuDataAddr->CL_ERR[i].c410,Variable_Set_value.c410,30))
	{
		RtuDataAddr->e=RtuDataAddr->e|0x1;
	}
	if((RtuDataAddr->e&0x01)==1)
	{
		RtuDataAddr->ShiDuanBianHuaCount++;
		TSGet(&ts);
		TimeGetType15(RtuDataAddr->Last_ShiDuanChange_Time,ts);
	}

	RtuDataAddr->CL_ERR[i].c41e=Variable_Set_value.c41e;
	memcpy(RtuDataAddr->CL_ERR[i].c320,Variable_Set_value.c320,30);
	memcpy(RtuDataAddr->CL_ERR[i].c330,Variable_Set_value.c330,30);
	memcpy(RtuDataAddr->CL_ERR[i].c340,Variable_Set_value.c340,30);
	memcpy(RtuDataAddr->CL_ERR[i].c350,Variable_Set_value.c350,30);
	memcpy(RtuDataAddr->CL_ERR[i].c360,Variable_Set_value.c360,30);
	memcpy(RtuDataAddr->CL_ERR[i].c370,Variable_Set_value.c370,30);
	memcpy(RtuDataAddr->CL_ERR[i].c380,Variable_Set_value.c380,30);
	memcpy(RtuDataAddr->CL_ERR[i].c390,Variable_Set_value.c390,30);
	memcpy(RtuDataAddr->CL_ERR[i].c3a0,Variable_Set_value.c3a0,30);
	//memcpy(RtuDataAddr->CL_ERR[i].c410,Variable_Set_value.c410,30);
	if(RtuDataAddr->CL_ERR[i].OldMacPZero!=BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[i].ZeroNum,2))
	{
		RtuDataAddr->e=RtuDataAddr->e|0x20;
	}

	if((RtuDataAddr->e!=0)&&(RtuDataAddr->CL_ERR[i].first!=1))
	{
		pro_CL_ERR8(i);
	}
	RtuDataAddr->e=0;

	if(RtuDataAddr->CL_ERR[i].OldDuanXiangNum!=BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[i].Duanxiang_All,2))
	{//�����ļ��ж�   ����
		//pro_CL_ERR10(Flag,i);
		RtuDataAddr->e=RtuDataAddr->e|0x02;//0000 0010
		RtuDataAddr->CL_ERR[i].OldDuanXiangNum=BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[i].Duanxiang_All,2);
	}

	if(RtuDataAddr->CL_ERR[i].OldShiYaCishu!=BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[i].shiyacishu,3))
	{//�����ļ��ж�   ʧѹ
		RtuDataAddr->e=RtuDataAddr->e|0x04;//0000 0010
		RtuDataAddr->CL_ERR[i].OldShiYaCishu=BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[i].shiyacishu,3);
	}
	{//���������ж�  ͣ��
		TingDianNum = BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[i].Tingdian ,3);
		//printf("\n\r TingDianNum===%d RtuDataAddr->CL_ERR[%d].OldTingDianNum===%d",TingDianNum,i,RtuDataAddr->CL_ERR[i].OldTingDianNum);
		//printf("\n\r");
		if (RtuDataAddr->CL_ERR[i].OldTingDianNum!= TingDianNum)
		{
			RtuDataAddr->e=RtuDataAddr->e|0x08;
			RtuDataAddr->CL_ERR[i].OldTingDianNum= TingDianNum;
		}
	}
	if((RtuDataAddr->CL_ERR[i].OldProgNum!=BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[i].ProgNum,2))||
		(RtuDataAddr->CL_ERR[i].OldMacPZero!=BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[i].ZeroNum,2)))
	{
	//Dlt645Dbg(DebugComm,"[e08]",i);
		RtuDataAddr->e=RtuDataAddr->e|1;//0000 0001
		RtuDataAddr->CL_ERR[i].OldProgNum=BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[i].ProgNum,2);
		RtuDataAddr->CL_ERR[i].OldMacPZero=BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[i].ZeroNum,2);
	}
	//---------------ʱ�ӵ��
	if(((RtuDataAddr->CL_ERR[i].BetteryLow==0)&&RtuDataAddr->CL_ERR[i].BetteryLow!=((RtuDataAddr->DD_BianLiang_Shuju[i].Dian_biao_stat[0][0]>>2)&0x01)))
	{
		RtuDataAddr->e=RtuDataAddr->e|0x10;//0001 0000
		RtuDataAddr->CL_ERR[i].BetteryLow=(RtuDataAddr->DD_BianLiang_Shuju[i].Dian_biao_stat[0][0]>>2)&0x01;
	}
	//printf("\n\rRtuDataAddr->CL_ERR[%d].BetteryLow===%d",i,RtuDataAddr->CL_ERR[i].BetteryLow);
	//printf("\n\rRtuDataAddr->DD_BianLiang_Shuju[%d].Dian_biao_stat[0][0]===%d",i,RtuDataAddr->DD_BianLiang_Shuju[i].Dian_biao_stat[0][0]);
	//printf("\n\r");
	if(((RtuDataAddr->DD_BianLiang_Shuju[i].Dian_biao_stat[0][0]>>2)&0x01)==0)
	{
		RtuDataAddr->CL_ERR[i].BetteryLow=0;
	}
	//---------------------
	//---------------ͣ�糭�����
	if(((RtuDataAddr->CL_ERR[i].BetteryLow2==0)&&RtuDataAddr->CL_ERR[i].BetteryLow2!=((RtuDataAddr->DD_BianLiang_Shuju[i].Dian_biao_stat[0][0]>>3)&0x01)))
	{
		RtuDataAddr->e=RtuDataAddr->e|0x10;//0001 0000
		RtuDataAddr->CL_ERR[i].BetteryLow2=(RtuDataAddr->DD_BianLiang_Shuju[i].Dian_biao_stat[0][0]>>3)&0x01;
	}
	//printf("\n\rRtuDataAddr->CL_ERR[%d].BetteryLow2===%d",i,RtuDataAddr->CL_ERR[i].BetteryLow2);
	//printf("\n\rRtuDataAddr->DD_BianLiang_Shuju[%d].Dian_biao_stat[0][0]===%d",i,RtuDataAddr->DD_BianLiang_Shuju[i].Dian_biao_stat[0][0]);
	//printf("\n\r");
	if(((RtuDataAddr->DD_BianLiang_Shuju[i].Dian_biao_stat[0][0]>>3)&0x01)==0)
	{
		RtuDataAddr->CL_ERR[i].BetteryLow2=0;
	}
	//--------------------
	if(RtuDataAddr->e!=0)
	{
		//Dlt645Dbg(DebugComm,"\r\n e=%x\r\n",e);
		//printf("\n\rRtuDataAddr->e======%d",RtuDataAddr->e);
		//printf("\n\r");
		pro_CL_ERR13(i);
		//----------//�������������Ϣ-----------//
		//�б仯���������
	}
	/*
	//��ƽ���Խ���¼�   (��ѹ)
	if (strncmp((char *)RtuDataAddr->CL_ERR[i].U_UnbalanceOldTime,(char *)RtuDataAddr->DD_BianLiang_Shuju[i].U_Unbalance.StartTime,6)!=0)
	{
		pro_CL_ERR17(i,0x01,RtuDataAddr->DD_BianLiang_Shuju[i].U_Unbalance.BupinghengValue,RtuDataAddr->DD_BianLiang_Shuju[i].I_Unbalance.BupinghengValue);
		memcpy(RtuDataAddr->CL_ERR[i].U_UnbalanceOldTime,RtuDataAddr->DD_BianLiang_Shuju[i].U_Unbalance.StartTime,6);
	}
	//��ƽ���Խ���¼�   (����)
	if (strncmp((char *)RtuDataAddr->CL_ERR[i].I_UnbalanceOldTime,(char *)RtuDataAddr->DD_BianLiang_Shuju[i].I_Unbalance.StartTime,6)!=0)
	{
		pro_CL_ERR17(i,0x02,RtuDataAddr->DD_BianLiang_Shuju[i].U_Unbalance.BupinghengValue,RtuDataAddr->DD_BianLiang_Shuju[i].I_Unbalance.BupinghengValue);
		memcpy(RtuDataAddr->CL_ERR[i].I_UnbalanceOldTime,RtuDataAddr->DD_BianLiang_Shuju[i].I_Unbalance.StartTime,6);
	}
	*/
	UpdateValue(i);//������ֵ
}
void pro_CL_ERR10(unsigned short Flag,unsigned short i)
{
	if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)
	{
		if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[1]&0x02)//��Ҫ�¼�
		{
			RtuDataAddr->Event_Save.Event.Err10.ERCNo=10;
			RtuDataAddr->Event_Save.Event.Err10.len=28;
			RtuDataAddr->Event_Save.Event.Err10.Cl_No[0]=(i+1)&0xff;
			RtuDataAddr->Event_Save.Event.Err10.Cl_No[1]=(((i+1)>>8)&0xff)|0x80;

			RtuDataAddr->Event_Save.Event.Err10.BiaoZhi=Flag;

			INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA,&RtuDataAddr->Event_Save.Event.Err10.UA[0],2);
			INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB,&RtuDataAddr->Event_Save.Event.Err10.UB[0],2);
			INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC,&RtuDataAddr->Event_Save.Event.Err10.UC[0],2);

			INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[i].IA*10),&RtuDataAddr->Event_Save.Event.Err10.IA[0],3);
			INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[i].IB*10),&RtuDataAddr->Event_Save.Event.Err10.IB[0],3);
			INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[i].IC*10),&RtuDataAddr->Event_Save.Event.Err10.IC[0],3);
			RtuDataAddr->Event_Save.Event.Err10.PDD[0]=0;
			INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_All,&RtuDataAddr->Event_Save.Event.Err10.PDD[1],4);
			if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[1]&0x02)//��Ҫ�¼�
			{
				SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err10.Occur_Time.BCD01,1,10);
			}
			else//һ���¼�
			{
				SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err10.Occur_Time.BCD01,2,10);
			}
		}
	}
}
void pro_CL_ERR13(unsigned short i)//�������������Ϣ
{
	if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)
	{
		if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[1]&0x10)//��Ҫ�Բ������ý����¼���¼
		{
			Dlt645Dbg("\r\n   ERR13e    �������������Ϣ  \r\n");
			RtuDataAddr->Event_Save.Event.Err13.ERCNo=13;
			RtuDataAddr->Event_Save.Event.Err13.len=8;
			RtuDataAddr->Event_Save.Event.Err13.ClNo[0]=(RtuDataAddr->Meter_Para.Dian_Meter[i].CeLiangNo&0xff);//�������
			RtuDataAddr->Event_Save.Event.Err13.ClNo[1]=((RtuDataAddr->Meter_Para.Dian_Meter[i].CeLiangNo>>8)&0xff)|0x80;
			RtuDataAddr->Event_Save.Event.Err13.Biaozhi=RtuDataAddr->e;
			if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[1]&0x10)//��Ҫ�¼�
			{
				SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err13.Occur_Time.BCD01,1,13);
			}
			else//һ���¼�
			{
				SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err13.Occur_Time.BCD01,2,13);
			}
		}
	}

}
void pro_CL_ERR21(unsigned short i)//�ն˹��ϼ�¼
{
	if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)
	{
		if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[2]&0x10)//��Ҫ�Բ������ý����¼���¼
		{
			RtuDataAddr->Event_Save.Event.Err21.ERCNo=21;
			RtuDataAddr->Event_Save.Event.Err21.len=6;
			RtuDataAddr->Event_Save.Event.Err21.Code=4;//485��������
			if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[2]&0x10)//��Ҫ�¼�
			{
				SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err21.Occur_Time.BCD01,1,21);
			}
			else//һ���¼�
			{
				SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err21.Occur_Time.BCD01,2,21);
			}
		}
	}
}
void CL_ERRInit(INT16U i)
{
	if(i<=CeLiangPoint_Max)
	{
		if(RtuDataAddr->DD_Device_BiaoShi_Value[i].Valid!=1)
			return;
		RtuDataAddr->CL_ERR[i].OldDuanXiangNum=BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[i].Duanxiang_All,2);
		RtuDataAddr->CL_ERR[i].OldMacPZero=BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[i].ZeroNum,2);
		//�ɵ��ܱ���̴���=�µ��ܱ���̴���
		RtuDataAddr->CL_ERR[i].OldProgNum=BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[i].ProgNum,2);

		//RtuDataAddr->CL_ERR[i].OldTingDianNum=0;
		RtuDataAddr->CL_ERR[i].BetteryLow=(RtuDataAddr->DD_BianLiang_Shuju[i].Dian_biao_stat[0][0]>>2)&0x01;
		RtuDataAddr->CL_ERR[i].BetteryLow2=(RtuDataAddr->DD_BianLiang_Shuju[i].Dian_biao_stat[0][0]>>3)&0x01;
		memcpy(RtuDataAddr->CL_ERR[i].PChangShu,RtuDataAddr->DD_BianLiang_Shuju[i].PChangShu,3);
		memcpy(RtuDataAddr->CL_ERR[i].QChangShu,RtuDataAddr->DD_BianLiang_Shuju[i].QChangShu,3);
		RtuDataAddr->CL_ERR[i].Year_ShiQu=RtuDataAddr->DD_BianLiang_Shuju[i].Year_ShiQu;
		RtuDataAddr->CL_ERR[i].Day_ShiDuanBiao=RtuDataAddr->DD_BianLiang_Shuju[i].Day_ShiDuanBiao;
		RtuDataAddr->CL_ERR[i].Now_ShiDuan=RtuDataAddr->DD_BianLiang_Shuju[i].Now_ShiDuan;
		RtuDataAddr->CL_ERR[i].FeiLvShu=RtuDataAddr->DD_BianLiang_Shuju[i].FeiLvShu;
		RtuDataAddr->CL_ERR[i].GongGongJiari=RtuDataAddr->DD_BianLiang_Shuju[i].GongGongJiari;
		memcpy(RtuDataAddr->CL_ERR[i].Chao_biao_riqi,RtuDataAddr->DD_BianLiang_Shuju[i].Chao_biao_riqi,2);//���ܱ����ʱ�����
		//���ܱ�������Ϣ
		//�ɶ������=�¶������
		RtuDataAddr->CL_ERR[i].OldDuanXiangNum=BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[i].Duanxiang_All,2);
		//���ܱ�ʧѹ����

		//���ܱ�ͣ�����
		RtuDataAddr->CL_ERR[i].OldTingDianNum=0;
		//���Ƿѹ��ʶ�������ڵ������״̬�֣�����¼B1����
		//RtuDataAddr->CL_ERR[i].BetteryLow=(RtuDataAddr->DD_BianLiang_Shuju[i].Dian_biao_stat[0][0]>>2)&0x01;
		//���ܱ��������
		//�ɱ��ʱ��=���һ�α��ʱ��
//		DD_BianLiang_Shuju[i].LastProg_Time[0]=DD_BianLiang_Shuju[i].LastProg_Time[0]+1;
		memcpy(RtuDataAddr->CL_ERR[i].ProgTime,RtuDataAddr->DD_BianLiang_Shuju[i].LastProg_Time,4);
		//�������й��ܵ���=ͣ��ʱ�����й��ܵ���=�������й��ܵ���
		//RtuDataAddr->CL_ERR[i].Old_PDD=RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_All;
		//���ܱ�ͣ�߷�ֵ
		//CL_ERR[i].StopValue=0;
		//����������������=����������������
		RtuDataAddr->CL_ERR[i].OldMacPZero=BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[i].ZeroNum,2);
//		Dlt645Dbg(DebugComm,"CL_ERRInit\r\n");
//		CL_ERR[i].BetteryLow=1;
		RtuDataAddr->CL_ERR[i].c41e=Variable_Set_value.c41e;
		memcpy(RtuDataAddr->CL_ERR[i].c320,Variable_Set_value.c320,30);
		memcpy(RtuDataAddr->CL_ERR[i].c330,Variable_Set_value.c330,30);
		memcpy(RtuDataAddr->CL_ERR[i].c340,Variable_Set_value.c340,30);
		memcpy(RtuDataAddr->CL_ERR[i].c350,Variable_Set_value.c350,30);
		memcpy(RtuDataAddr->CL_ERR[i].c360,Variable_Set_value.c360,30);
		memcpy(RtuDataAddr->CL_ERR[i].c370,Variable_Set_value.c370,30);
		memcpy(RtuDataAddr->CL_ERR[i].c380,Variable_Set_value.c380,30);
		memcpy(RtuDataAddr->CL_ERR[i].c390,Variable_Set_value.c390,30);
		memcpy(RtuDataAddr->CL_ERR[i].c3a0,Variable_Set_value.c3a0,30);
		memcpy(RtuDataAddr->CL_ERR[i].c410,Variable_Set_value.c410,30);

		if((RtuDataAddr->CL_ERR[i].BetteryLow==1)||(RtuDataAddr->CL_ERR[i].BetteryLow2==1))//���Ƿѹ
		{
			pro_ERR13(i);//���������Ϣ
		}
	}
}
void Pro_ERC31(unsigned short i)
{
	if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)
	{
		if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[3]&0x40)
		{
			RtuDataAddr->Event_Save.Event.Err31.ERCNo=31;
			RtuDataAddr->Event_Save.Event.Err31.len=21;
			RtuDataAddr->Event_Save.Event.Err31.ClNo[0]=(RtuDataAddr->Meter_Para.Dian_Meter[i].CeLiangNo&0xff);
			RtuDataAddr->Event_Save.Event.Err31.ClNo[1]=((RtuDataAddr->Meter_Para.Dian_Meter[i].CeLiangNo>>8)&0xff)|0x80;
			if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[3]&0x40)//��Ҫ�¼�
			{
				SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err31.Occur_Time.BCD01,1,31);
			}
			else//һ���¼�
			{
				SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err31.Occur_Time.BCD01,2,31);
			}
		}
	}
}
void ProREC(unsigned short i)
{
	TS ts645;
	unsigned char TYear,TMonth,TDay,THour,TMinute;
	//CL_ERR��ʼ��
	if((firstreadflag[i]==1)&&(RtuDataAddr->DD_Device_BiaoShi_Value[i].Valid==1))//�ϵ�ʱ��ʼ����ͨѶ����
	{
		CL_ERRInit(i);//ֻ���ϵ�ʱ��ʼ����ͨѶ����ʱ����˴�
		firstreadflag[i]=0;
	}
	//�ն˹���
	if(GetValueErr!=GetValueErrOld)
	{
		if((GetValueErr^GetValueErrOld)==(1<<i))
		{
			if((GetValueErr&(1<<i))==(1<<i))
			{
				//pro_CL_ERR21(i);
				GetValueErrOld=GetValueErr;
			}
		}
	}
	if((GetValueErr&(1<<i))==0)//�ն��޹���
	{
		if(Variable_Set_value.valid==1)
		{
			TSGet(&ts645);
			//ȡ���ر���ʱ��
			SecCount=((ts645.Year%100)*525600)+
			(ts645.Month*44640)+
			(ts645.Day*1440)+
			(ts645.Hour*60)+ts645.Minute  ;
			//ȡ����ʱ���ܱ���ʱ��
			TYear=RtuDataAddr->DD_BianLiang_Shuju[i].Date_Week[3];
			TYear=((TYear>>4)*10)+(TYear&0x0f);
			TMonth=RtuDataAddr->DD_BianLiang_Shuju[i].Date_Week[2];
			TMonth=((TMonth>>4)*10)+(TMonth&0x0f);
			TDay=RtuDataAddr->DD_BianLiang_Shuju[i].Date_Week[1];
			TDay=((TDay>>4)*10)+(TDay&0x0f);
			THour=RtuDataAddr->DD_BianLiang_Shuju[i].Now_Time[2];
			THour=((THour>>4)*10)+(THour&0x0f);
			TMinute=RtuDataAddr->DD_BianLiang_Shuju[i].Now_Time[1];
			TMinute=((TMinute>>4)*10)+(TMinute&0x0f);
			GetSecCount=(TYear*525600)+
			(TMonth*44640)+
			(TDay*1440)+
			(THour*60)+
			TMinute  ;

			if(RtuDataAddr->Event_Value.F59_Set_Para.Valid==1)
			{
				if(CalcSec(SecCount,GetSecCount)>(RtuDataAddr->Event_Value.F59_Set_Para.DD_Jiaoshi_Men))//
				{
					MetTimeErr=MetTimeErr|(1<<i);
				}
				else
				{
					MetTimeErr=MetTimeErr&((1<<i)^0xff);
				}
				if(MetTimeErr!=MetTimeErrOld)
				{
					pro_CL_ERR12(i);//���ܱ�ʱ�䳬��
					MetTimeErrOld=MetTimeErr;
					//Dlt645Dbg(DebugComm,"\r\nERR1212\r\n");
				}
			}
		}
	}

	Pro_CL_ERR(i);//���ܱ���ֵ�¼�����
	if(NeedSetTime==1)
	{
		//SendDD_Time();//��ʱ���˹�����ʱ������
		NeedSetTime=2;
	}
}

void GetZhuZhanTrans()
{
	int i;
	unsigned char C;
	unsigned short Baud=1200;
	unsigned char Bits=8;
	unsigned char Parity[12];
	unsigned char stopb=1;
	unsigned char OldPo;

	if ((RtuDataAddr->DD_Device_BaoWen.ASK_Stat==1)&& (PORT_ID== RtuDataAddr->DD_Device_BaoWen.ASK_Port ))//tiaoshi
	{
		memset(Parity,0,12);
		C = RtuDataAddr->DD_Device_BaoWen.ASK_Control;
		if(((C>>5)&0x07)==0)Baud=300;
		if(((C>>5)&0x07)==1)Baud=600;
		if(((C>>5)&0x07)==2)Baud=1200;
		if(((C>>5)&0x07)==3)Baud=2400;
		if(((C>>5)&0x07)==4)Baud=4800;
		if(((C>>5)&0x07)==5)Baud=7200;
		if(((C>>5)&0x07)==6)Baud=9600;
		if(((C>>5)&0x07)==7)Baud=19200;
		if((C&0x08)==0x08)//�ж�����У��
		{
			if((C&0x04)==0x04)
				sprintf((char *)Parity,"odd");
			else
				sprintf((char *)Parity,"even");
		}
		else//��У��
		{
			sprintf((char *)Parity,"none");
		}
		OldPo= MeterCh;
		MeterCh = RtuDataAddr->DD_Device_BaoWen.ASK_Port;
		fprintf(stderr,"\n\r Baud=%d Parity=%s Stopb=%d Bits=%d",Baud,Parity,stopb,Bits);
		close( ComPort );
		ComPort = 0;
		int retu = user_init_io(Baud,Parity,stopb,Bits);
		fprintf(stderr,"\n\r fanhui = %d ComPort=%d",retu,ComPort);

		int length = RtuDataAddr->DD_Device_BaoWen.len[0] + (RtuDataAddr->DD_Device_BaoWen.len[1]<<8) + 4;


		delay(10);
		int relen = write(ComPort,RtuDataAddr->DD_Device_BaoWen.ASK_Buf,length);
		printf("\n\rBegin Send To 485 ASK_Port=%d len=%d   len0 %02x  len1 %02x   send->%d\n\r",RtuDataAddr->DD_Device_BaoWen.ASK_Port,length,RtuDataAddr->DD_Device_BaoWen.len[0],RtuDataAddr->DD_Device_BaoWen.len[1],relen);

		for(i=0;i< relen;i++)
			printf("%02x ",RtuDataAddr->DD_Device_BaoWen.ASK_Buf[i]);
		printf("\n\r");
		OFF_S485();

    	delay(500);
    	relen = 0;
    	i =0;
    	while((relen<=0)&&(i<5))
    	{
    		relen = ReceiveFrom485(RtuDataAddr->DD_Device_BaoWen.ANSWER_Buf);
    		delay(200);
    		i++;
    	}

		RtuDataAddr->DD_Device_BaoWen.ASK_Stat =0;
		RtuDataAddr->DD_Device_BaoWen.ANSWER_Len[0] = relen & 0xff;;
		RtuDataAddr->DD_Device_BaoWen.ANSWER_Len[1] = (relen>>8)&0xff;
		CleardeadCount();
		//RtuDataAddr->DD_Device_BaoWen.ANSWER_Len=ReceiveFrom485(RtuDataAddr->DD_Device_BaoWen.ANSWER_Buf);

		printf("\n\rDataTrans-RecvFrom485[%d bytes]:",relen);
		for(i=0;i<relen;i++)
			printf("%02x ",RtuDataAddr->DD_Device_BaoWen.ANSWER_Buf[i]);
		printf("\n\r");

		if(relen > 0)
		{
			RtuDataAddr->DD_Device_BaoWen.ANSWER_Stat=1;
		}

		MeterCh=OldPo;
		user_init_io(OldPort[MeterCh].Baud,OldPort[MeterCh].Parity,stopb,Bits );
		delay(10);
	}
}

void SendStrTo485(unsigned char *str,unsigned short Len)
{
	INT8U i;
	ssize_t r = 0;
	CleardeadCount();
	GetZhuZhanTrans();
	SEND_485_ON();
	r = write(ComPort,str,Len);

	Dlt645Dbg(" len=%d ComPort=%d",Len,ComPort);//xinjia
	Dlt645Dbg("\r\nSend:");
	Dlt645Dbg(" Begin Send to 485:\n");
	for(i = 0;i < Len;i++)
    {
		Dlt645Dbg("[%x]",str[i]);
		Dlt645Dbg(" %x ",str[i]);
    }
 	delay(200);
	OFF_S485();
}
unsigned short ReceiveFrom485(unsigned char *str)
{
	unsigned char i;
	unsigned short pos = 0;
	int len,lencount = 0;
	unsigned char TmpBuf[256];
	memset(TmpBuf, 0, 256);

	pos=0;
	i=0;
	lencount = 0;
	while(1)
	{
		CleardeadCount();
		delay(50);
		len = read(ComPort,TmpBuf,200);//********************//
		lencount = lencount + len;
		if (len<=0)
		{
			break;
		}else
			REC_485_ON();

		Dlt645Dbg("\n\r len= %d ComPort=%d",len,ComPort);//����
		Dlt645Dbg("\n\r receive:");
		Dlt645Dbg(" Begin receive from 485:\n");//����
		for(i=0;i<len;i++)
		{
			str[pos]=TmpBuf[i];
			Dlt645Dbg("%x ",str[pos]);//Dlt645Dbg
			//pos=(pos+1)%512;
			pos++;
		}
		delay(200);
		OFF_R485();
	}
	OFF_R485();

	if (lencount <= 0)
	{//485���չ���
		if(ComErrFlag!=1)
		{
			//printf("\n\r 485Receive Error!  ComErrFlag===%d",ComErrFlag);
			pro_CL_ERR21(0);
			ComErrFlag = 1;
		}
	}else
		ComErrFlag = 0;

	return pos;
}
unsigned char   PARSE_CMD(int argc, char * argv[])
{
	unsigned char  proc_name[32] = "";

	Dlt645Dbg("cmdline=%d,%s %s\r\n", argc, argv[0], argv[1]);
	if(argc < 2)return (FALSE);
	PORT_ID = atoi(argv[1]);
	sprintf((char *)proc_name, "%s %d", argv[0], PORT_ID);
	if((attach = name_attach(NULL, (char *)proc_name,0))  == NULL)
	{
		//fprintf(stderr, "ERR:'%s' runed,cann't regist: %s\r\n", proc_name, strerror(errno));
		return (FALSE);
	}
	return (TRUE);
}
int user_init_io(INT16U baud,INT8U *par,INT8U stopb,INT8U bits )
{
	unsigned char tmp[128];
	memset(tmp,0,128);
    sprintf((char *)tmp,"/dev/ser%d",PORT_ID);

    ComPort = open((char *)tmp, O_RDWR|O_NOCTTY);/* �򿪴����ļ� */
    if( ComPort<0 )
    {
    	Dlt645Dbg("open the serial port fail! errno is: %d\n", errno);
    	_exit(EXIT_FAILURE); /*�򿪴���ʧ��*/
    }
    if ( tcgetattr( ComPort, &old_termi) != 0) /*�洢ԭ��������*/
    {
    	Dlt645Dbg("get the terminal parameter error when set baudrate! errno is: %d\n", errno);
    	/*��ȡ�ն���ز���ʱ����*/
    	exit(EXIT_FAILURE);
    }
    bzero(&new_termi,sizeof(new_termi));    				/*���ṹ������*/
    new_termi.c_cflag|= (CLOCAL|CREAD); 					/*���Ե��ƽ����״̬�У�����ʹ��*/
    new_termi.c_lflag&=~(ICANON|ECHO|ECHOE);				/*ѡ��Ϊԭʼ����ģʽ*/
    new_termi.c_oflag&=~OPOST; 								/*ѡ��Ϊԭʼ���ģʽ*/
    new_termi.c_cc[VTIME] = 5; 								/*���ó�ʱʱ��Ϊ0.5 s*/
    new_termi.c_cc[VMIN] = 0;								/*���ٷ��ص��ֽ����� 7*/
    cfsetispeed(&new_termi, baud); 							/* �������벦���� */
    cfsetospeed(&new_termi, baud); 							/* ������������� */
    new_termi.c_cflag &= (~CSIZE); 							/* ��������λ��,8λ���� */
    //new_termi.c_cflag |= CS8;
    if (bits==8)
    new_termi.c_cflag |= CS8;
    else if (bits==7)
    new_termi.c_cflag |= CS7;
    else if (bits==6)
    new_termi.c_cflag |= CS6;
    else if (bits==5)
    new_termi.c_cflag |= CS5;
    else
        new_termi.c_cflag |= CS8;

    //new_termi.c_cflag &= ~PARENB; 							/*������żУ��Ϊ��У��*/
    new_termi.c_cflag |= PARENB;
    new_termi.c_cflag &= ~PARODD;                               /*������żУ��ΪżУ��*/
    new_termi.c_iflag &=~ ISTRIP; new_termi.c_cflag&= ~CSTOPB; /*����ֹͣλΪ:һλֹͣλ*/
    tcflush(ComPort, TCIOFLUSH); 								/* ˢ����������� */
   // printf("\r\n comset baud ========== %d",baud);

    if(tcsetattr(ComPort,TCSANOW,&new_termi)!= 0)				/* ��������� */
    {
    	Dlt645Dbg("Set serial port parameter error!\n");
    	exit(EXIT_FAILURE);
    }
    return EXIT_SUCCESS;
}
void QuitProcess(int signo)
{
	delay(100);
	RtuDataAddr->stPortPara[PORT_ID].PID=0;
   	name_detach(attach, 0);
   	fprintf(stderr,"fkmeter quit");
	exit(0);
}
void mydelay(int s)
{
	int i;
	for(i=0; i<s; i++)
	{
		CleardeadCount();
		delay(1000);
	}
}
extern void iec_read(unsigned char DBNo);
extern void Dlt645_2007GetData(unsigned char i);

//�ʼಿ�ż��485��������
int Tuser_init_io(INT16U baud,INT8U *par,INT8U stopb,INT8U bits,INT8U port)
{
	unsigned char tmp[128];
	memset(tmp,0,128);
    sprintf((char *)tmp,"/dev/ser%d",port);
    ComPort = open((char *)tmp, O_RDWR|O_NOCTTY);/* �򿪴����ļ� */
    if( ComPort<0 )
    {
    	Dlt645Dbg("open the serial port fail! errno is: %d\n", errno);
    	_exit(EXIT_FAILURE); /*�򿪴���ʧ��*/
    }
    if ( tcgetattr( ComPort, &old_termi) != 0) /*�洢ԭ��������*/
    {
    	Dlt645Dbg("get the terminal parameter error when set baudrate! errno is: %d\n", errno);
    	/*��ȡ�ն���ز���ʱ����*/
    	exit(EXIT_FAILURE);
    }
    bzero(&new_termi,sizeof(new_termi));    				/*���ṹ������*/
    new_termi.c_cflag|= (CLOCAL|CREAD); 					/*���Ե��ƽ����״̬�У�����ʹ��*/
    new_termi.c_lflag&=~(ICANON|ECHO|ECHOE);				/*ѡ��Ϊԭʼ����ģʽ*/
    new_termi.c_oflag&=~OPOST; 								/*ѡ��Ϊԭʼ���ģʽ*/
    new_termi.c_cc[VTIME] = 5; 								/*���ó�ʱʱ��Ϊ0.5 s*/
    new_termi.c_cc[VMIN] = 0;								/*���ٷ��ص��ֽ����� 7*/
    cfsetispeed(&new_termi, baud); 							/* �������벦���� */
    cfsetospeed(&new_termi, baud); 							/* ������������� */
    new_termi.c_cflag &= (~CSIZE); 							/* ��������λ��,8λ���� */
    new_termi.c_cflag |= CS8;

    //new_termi.c_cflag &= ~PARENB; 							/*������żУ��Ϊ��У��*/
    new_termi.c_cflag |= PARENB;
    new_termi.c_cflag &= ~PARODD;                               /*������żУ��ΪżУ��*/
    new_termi.c_iflag &=~ ISTRIP; new_termi.c_cflag&= ~CSTOPB; /*����ֹͣλΪ:һλֹͣλ*/
    tcflush(ComPort, TCIOFLUSH); 								/* ˢ����������� */
   // printf("\r\n comset baud ========== %d",baud);

    if(tcsetattr(ComPort,TCSANOW,&new_termi)!= 0)				/* ��������� */
    {
    	Dlt645Dbg("Set serial port parameter error!\n");
    	exit(EXIT_FAILURE);
    }
    return ComPort;
}
int TSendStrTo485(unsigned char *str,unsigned short Len,unsigned char port)
{
	INT8U i;
	ssize_t r = 0;
	CleardeadCount();
	SEND_485_ON();
	r = write(port,str,Len);

	Dlt645Dbg(" len=%d ComPort=%d",Len,port);//xinjia
	Dlt645Dbg("\r\nSend:");
	Dlt645Dbg(" Begin Send to 485:\n");
	for(i = 0;i < Len;i++)
    {
		Dlt645Dbg("[%x]",str[i]);
		Dlt645Dbg(" %x ",str[i]);
    }
 	delay(200);
	OFF_S485();
	return r;
}
unsigned char TReceiveFrom485(unsigned char *str,unsigned char port)
{
	unsigned char i;
	unsigned short pos = 0;
	int len,lencount = 0;
	unsigned char TmpBuf[256];
	pos=0;
	i=0;
	lencount = 0;
	while(1)
	{
		CleardeadCount();
		delay(50);
		len = read(port,TmpBuf,200);//********************//
		lencount = lencount + len;
		if (len<=0)
		{
			break;
		}else
			REC_485_ON();

		Dlt645Dbg("\n\r len= %d ComPort=%d",len,port);//����
		Dlt645Dbg("\n\r receive:");
		Dlt645Dbg(" Begin receive from 485:\n");//����
		for(i=0;i<len;i++)
		{
			str[pos]=TmpBuf[i];
			Dlt645Dbg("%x ",str[pos]);//Dlt645Dbg
			pos=(pos+1)%512;
		}
		delay(200);
		OFF_R485();
	}
	return pos;
}
void SelfTest()
{
	unsigned char buftmp[100];
	int i,sendlen1=0,sendlen2=0,receivelen1=0,receivelen2=0;
	int ComPort1,ComPort2;

	for(i=0;i<100;i++)
		buftmp[i] = i;

	ComPort1=Tuser_init_io(2400,(INT8U *)"even",1,8,1);
	delay(30);
	ComPort2=Tuser_init_io(2400,(INT8U *)"even",1,8,2);
	delay(30);
	printf("\n\r ComPort1==%d  ComPort2==%d",ComPort1,ComPort2);

	sendlen1=TSendStrTo485(buftmp,100,1);
	printf("\n SendStrTo485111111 DataNum = %d \n\r",sendlen1);
	delay(500);
	memset(buftmp,0,100);
	receivelen2=TReceiveFrom485(buftmp,2);
	printf("\n ReceiveFrom485222222 DataNum = %d \n\r",receivelen2);

	sendlen2=TSendStrTo485(buftmp,100,2);
	printf("\n SendStrTo4852 DataNum = %d \n\r",sendlen2);
	delay(500);
	memset(buftmp,0,100);
	receivelen1=TReceiveFrom485(buftmp,1);
	printf("\n ReceiveFrom4851 DataNum = %d \n\r",receivelen1);

	close( ComPort1 );
	close( ComPort2 );

	if(sendlen1>0)
		printf("\n\r-----------------------------> com1 send  ok ok!!! \n\r");
	else
		printf("\n\r-----------------------------> com1 send  error!!! \n\r");
	if(sendlen2>0)
		printf("\n\r-----------------------------> com2 send ok ok!!! \n\r");
	else
		printf("\n\r-----------------------------> com2 send  error \n\r");
	if(receivelen1>0)
		printf("\n\r-----------------------------> com1 receive  ok ok!!! \n\r");
	else
		printf("\n\r-----------------------------> com1 receive  error \n\r");
	if(receivelen2>0)
		printf("\n\r-----------------------------> com2 receive ok ok!!! \n\r");
	else
		printf("\n\r-----------------------------> com2 receive  error \n\r");
}
////�ʼಿ�ż��485�������ӽ���
int main(int argc, char *argv[])
{

	struct sigaction sa1;
	int   i,first_flag=0;
	INT8U ChaoBiaoJG,OldMin,tmpmin;
	TS ts;
	TSGet(&ts);
	markver();
	if(OpenMem())return EXIT_FAILURE;

	if(RtuDataAddr->mem_len!=sizeof(RTimeData))
	{
		//fprintf( stderr, "base mem uncompared prog will exit %d  %d :\n",sizeof(RTimeData),RtuDataAddr->mem_len);
		return EXIT_FAILURE;
	}

	if(!PARSE_CMD(argc, argv))
	{
		//printf("\n Bad command format. Type 'use exe_name' for help!\n\r");
		return EXIT_FAILURE;
	}
	//////////////////////////////////////////////////////////////////////////
	sa1.sa_handler = QuitProcess;
	sigemptyset(&sa1.sa_mask);
	sa1.sa_flags = 0;
	sigaction(SIGTERM, &sa1,NULL);
	sigaction(SIGSYS, &sa1,NULL);
	sigaction(SIGPWR, &sa1,NULL);
	sigaction(SIGKILL, &sa1,NULL);
	sigaction(SIGQUIT, &sa1,NULL);
	sigaction(SIGILL, &sa1,NULL);
	sigaction(SIGINT, &sa1,NULL);
	sigaction(SIGHUP, &sa1,NULL);
	sigaction(SIGABRT, &sa1,NULL);
	sigaction(SIGBUS, &sa1,NULL);
	RtuDataAddr->stPortPara[PORT_ID].PID=getpid();
	OldMin=ts.Minute;
	Min_Count=0;
	MetTimeErr=MetTimeErrOld=0;
	GetValueErr=GetValueErrOld=0;//���ܱ���ͨ�������¼���
	RtuDataAddr->ShiDuanBianHuaCount=0;
 	ValidInit();

	while(RtuDataAddr->Dev_Init_OK==0)
	{
		CleardeadCount();
		delay(1000);
	}
	memset(&old_z_p_all,0,sizeof(int)*8);
	Dlt645Dbg("\n Chaobiao ser %d \n\r",PORT_ID);
	MeterCh=PORT_ID;

	memcpy(&RtuDataAddr->Meter_Para.Valid,&RtuDataAddr->FkInput_Value.F10_Set_Para.Valid,sizeof(RtuDataAddr->FkInput_Value.F10_Set_Para));

	for(i=0;i<CeLiangPoint_Max;i++)//��ֹ�״γ����������ܱ����������¼�¼�
		RtuDataAddr->CL_ERR[i].first = 1;
	ChaoBiaoJG = 5;
	ComErrFlag = ComInitErrFlag = 0;
	Dlt645Dbg("\n\rChaoBiaoJG1==%d",ChaoBiaoJG);
	while(1)
	{
		GetZhuZhanTrans();
		CleardeadCount();
		memcpy(&RtuDataAddr->Meter_Para.Valid,&RtuDataAddr->FkInput_Value.F10_Set_Para.Valid,sizeof(RtuDataAddr->FkInput_Value.F10_Set_Para));

		if(RtuDataAddr->FkInput_Value.New_F33_Set_Para.Valid==1)
			for(i=0;i<RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai_Num;i++)
			{
				//Dlt645Dbg("\n\rRtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[%d].PortNo=%d",i,RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[i].PortNo);
				//if((RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[i].PortNo)==MeterCh)
				if((RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[i].PortNo-1)==MeterCh)
				{
					ChaoBiaoJG =RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[i].ChaoBiaoJianGe;
					//Dlt645Dbg("\n\rChaoBiaoJG2==%d",ChaoBiaoJG);
				}
			}
		TSGet(&ts);
		if(first_flag==1)		// ���� ��������
		{
			tmpmin=((ts.Minute+60)-OldMin)%60;
			if(tmpmin<ChaoBiaoJG)
			{
				delay(100);
				continue;
			}
		}
		delay(50);
		if(RtuDataAddr->FuKong_Control_Value.F49_Control_Para.Valid==1)
			//if((RtuDataAddr->FuKong_Control_Value.F49_Control_Para.ZhongduanPort)==MeterCh)
			if((RtuDataAddr->FuKong_Control_Value.F49_Control_Para.ZhongduanPort-1)==MeterCh)
				continue;

		memset(read485ERR,0,sizeof(read485ERR));//���ܱ�����������ͨ���жϣ�����������
  		Dlt645Dbg("\n\rChaoBiaoJG==%d",ChaoBiaoJG);
		Dlt645Dbg("\n\rRtuDataAddr->Meter_Para.Valid==%d",RtuDataAddr->Meter_Para.Valid);
		if(RtuDataAddr->Meter_Para.Valid==1)
		{
			Dlt645Dbg("\n\rRtuDataAddr->Meter_Para.Metet_jiaoliu_Num==%d",RtuDataAddr->Meter_Para.Metet_jiaoliu_Num);
			if(RtuDataAddr->Meter_Para.Metet_jiaoliu_Num>CeLiangPoint_Max)
			{
				RtuDataAddr->Meter_Para.Metet_jiaoliu_Num=CeLiangPoint_Max;
			}
			for(i=0;i<RtuDataAddr->Meter_Para.Metet_jiaoliu_Num;i++)
			{
				CleardeadCount();
				Dlt645Dbg("\n\r RtuDataAddr->Meter_Para.Dian_Meter[%d].Port==%d",i,RtuDataAddr->Meter_Para.Dian_Meter[i].BaudAndPort&0x1f);
				//if((((RtuDataAddr->Meter_Para.Dian_Meter[i].BaudAndPort&0x1f) )!=PORT_ID))
				if((((RtuDataAddr->Meter_Para.Dian_Meter[i].BaudAndPort&0x1f) -1)!=PORT_ID))//��1��ʾ����վ�·�ͨ�Ŷ˿�2�ǽ�485������1���·�3�ǽӳ�����2��
					continue;
				Dlt645Dbg("\n\r RtuDataAddr->Meter_Para.Dian_Meter[%d].Baud==%d",i,(RtuDataAddr->Meter_Para.Dian_Meter[i].BaudAndPort>>5)&0x07);
				switch((RtuDataAddr->Meter_Para.Dian_Meter[i].BaudAndPort>>5)&0x07)
				{//ѡ������
					case 0:
						OldPort[MeterCh].Baud=1200;
						break;
					case 1:
						OldPort[MeterCh].Baud=600;
						break;
					case 2:
						OldPort[MeterCh].Baud=1200;
						break;
					case 3:
						OldPort[MeterCh].Baud=2400;
						break;
					case 4:
						OldPort[MeterCh].Baud=4800;
						break;
					case 5:
						OldPort[MeterCh].Baud=7200;
						break;
					case 6:
						OldPort[MeterCh].Baud=9600;
						break;
					case 7:
						OldPort[MeterCh].Baud=19200;
						break;
				}
				Dlt645Dbg("\n\r RtuDataAddr->Meter_Para.Dian_Meter[%d].GuiYue_Type==%d",i,RtuDataAddr->Meter_Para.Dian_Meter[i].GuiYue_Type);
				if(RtuDataAddr->Meter_Para.Dian_Meter[i].GuiYue_Type==DLT6451997)
				{//645��Լ��1997
					OldPort[MeterCh].Bits=8;
					memset(OldPort[MeterCh].Parity,0,sizeof(OldPort[MeterCh].Parity));
					sprintf((char *)OldPort[MeterCh].Parity,"even");
					if (user_init_io(OldPort[MeterCh].Baud,(INT8U *)"even",1,8 )==EXIT_FAILURE)
					{
						//485��ʼ������
						if (ComInitErrFlag!=1)
						{
							pro_CL_ERR21(0);
							ComInitErrFlag = 1;
							close( ComPort );
							continue;
						}else
							ComInitErrFlag = 0;

						Dlt645Dbg("\n Chaobiao ser %d SetPro EXIT_FAILURE!!  \n\r",PORT_ID);
						return EXIT_FAILURE;
					}
					delay(30);
					Dlt645Dbg("\n Chaobiao Begin.....1997\n\r");//����
					Dlt645GetData(i);
					Dlt645Dbg("\n Chaobiao End.....1997\n\r");//����
					mydelay(1);
				}
				if(RtuDataAddr->Meter_Para.Dian_Meter[i].GuiYue_Type==DLT6452007)
				{//DL/T645-2007
					OldPort[MeterCh].Bits=8;
					memset(OldPort[MeterCh].Parity,0,sizeof(OldPort[MeterCh].Parity));
					sprintf((char *)OldPort[MeterCh].Parity,"even");
					if (user_init_io(OldPort[MeterCh].Baud,(INT8U *)"even",1,8 )==EXIT_FAILURE)
					{
						//485��ʼ������
						if (ComInitErrFlag!=1)
						{
							pro_CL_ERR21(0);
							ComInitErrFlag = 1;
							close( ComPort );
							continue;
						}else
							ComInitErrFlag = 0;
						Dlt645Dbg("\n Chaobiao ser %d SetPro EXIT_FAILURE!!  \n\r",PORT_ID);
						return EXIT_FAILURE;
					}
					delay(30);
					Dlt645Dbg("\n Chaobiao Begin.....2007\n\r");//����
					Dlt645_2007GetData(i);
					Dlt645Dbg("\n Chaobiao End.....2007\n\r");//����
					mydelay(1);
				}
				if(RtuDataAddr->Meter_Para.Dian_Meter[i].GuiYue_Type==WSDDTyp40)
				{//�ݶ�Ϊ��ʤ4.0��Լ
					OldPort[MeterCh].Bits=8;
					memset(OldPort[MeterCh].Parity,0,sizeof(OldPort[MeterCh].Parity));
					sprintf((char *)OldPort[MeterCh].Parity,"even");
					if (user_init_io(OldPort[MeterCh].Baud,(INT8U *)"even",1,8 )==EXIT_FAILURE)
					{
						//485��ʼ������
						if (ComInitErrFlag!=1)
						{
							pro_CL_ERR21(0);
							ComInitErrFlag = 1;
							close( ComPort );
							continue;
						}else
							ComInitErrFlag = 0;
						Dlt645Dbg("\n Chaobiao ser %d SetPro EXIT_FAILURE!!  \n\r",PORT_ID);
						return EXIT_FAILURE;
					}
					delay(30);
					Dlt645Dbg("\n WsDlt645GetData start...\n\r");//����
					WsDlt645GetData(i);
					Dlt645Dbg("\n WsDlt645GetData end...\n\r");//����
					mydelay(1);
				}
				if(RtuDataAddr->Meter_Para.Dian_Meter[i].GuiYue_Type==IEC1107)//LANJIER_D)
				{//������D��(ZD405/410�ͺź�ZxH300/400�ͺž����ô˹�Լ)
					OldPort[MeterCh].Bits=8;
					memset(OldPort[MeterCh].Parity,0,sizeof(OldPort[MeterCh].Parity));
					sprintf((char *)OldPort[MeterCh].Parity,"even");
					OldPort[MeterCh].Baud = 300;
					if (user_init_io(OldPort[MeterCh].Baud,(INT8U *)"even",1,7 )==EXIT_FAILURE)
					{
						//485��ʼ������
						if (ComInitErrFlag!=1)
						{
							pro_CL_ERR21(0);
							ComInitErrFlag = 1;
							close( ComPort );
							continue;
						}else
							ComInitErrFlag = 0;
						Dlt645Dbg("\n Chaobiao ser %d SetPro EXIT_FAILURE!!  \n\r",PORT_ID);
						return EXIT_FAILURE;
					}
					close( ComPort );
					delay(30);
					Dlt645Dbg("\n HTDlt645GetDataiec_read start...\n\r");//����
					//iec_read(i);
					iec_read_ZxD402(i);
					Dlt645Dbg("\n HTDlt645GetDataiec_read end...\n\r");//����
					mydelay(1);
				}
				close( ComPort );
			}
			mydelay(10);
			first_flag=1;
			TSGet(&ts);
			OldMin=ts.Minute;
		}
	}
   //-----------------------------------------------------------
	name_detach(attach, 0);
 	return EXIT_SUCCESS;

}
