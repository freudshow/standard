#ifndef DLT645_H_
#define DLT645_H_

#endif /*DLT645_H_*/
unsigned int old_z_p_all[8];
void Dlt645GetData(unsigned char i);
void GetDemand_N_Set_Value(unsigned char DDNo);
void GetMaximum_Demand_N_Set_Value(unsigned char DDNo);
void GetMaximum_Demand_Time_N_Set_Value(unsigned char DDNo);
void GetVariable_Set_value(unsigned char  DDNo);
unsigned char Dlt645GetVlue(unsigned char *Addr,unsigned char DI1,unsigned char DI0,unsigned char *Dest,unsigned char GetNum);

