#ifndef DLT645_2007_H_
#define DLT645_2007_H_

#endif /*DLT645_2007_H_*/

void Dlt645_2007GetData(unsigned char i);
void Get2007Demand_N_Set_Value(unsigned char DDNo);
void Get2007Maximum_Demand_NT_Set_Value(unsigned char DDNo);
void Get2007Variable_Set_value(unsigned char  DDNo);
unsigned char Dlt645_2007GetVlue(unsigned char *Addr,unsigned char DI3,unsigned char DI2,unsigned char DI1,unsigned char DI0,unsigned char *Dest,unsigned char GetNum);
