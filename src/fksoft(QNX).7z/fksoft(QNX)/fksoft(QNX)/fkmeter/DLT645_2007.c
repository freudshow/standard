
#include "DLT645_2007.h"
#include "fkmeter.h"
#include "DLT645_2007_DEF.h"
extern void pro_ERR33(unsigned short i,unsigned char chg[14],unsigned char stat[14]);
extern INT8U *INT32ToBCD(INT32S S, INT8U *D, INT8U len);
extern void Pro_ERC31(unsigned short i);
unsigned char Dlt645_2007GetVlue(unsigned char *Addr,unsigned char DI3,unsigned char DI2,unsigned char DI1,unsigned char DI0,unsigned char *Dest,unsigned char GetNum)
{
	//����
	unsigned int i,j,len;
    unsigned char Check;
	len=0;
	Check=0;

	///CleardeadCount();
	//��֯���ͱ���
	Trn645Buff[len++]=0xFE;
	Trn645Buff[len++]=0xFE;
	Trn645Buff[len++]=0xFE;
	Trn645Buff[len++]=0xFE;
	Trn645Buff[len++]=0x68;

	for(i=0;i<6;i++)
	{
		Trn645Buff[len++]=Addr[i];
	}

	Trn645Buff[len++]=0x68;
	Trn645Buff[len++]=0x11;
	Trn645Buff[len++]=0x04;
	Trn645Buff[len++]=0x33+DI0;
	Trn645Buff[len++]=0x33+DI1;
	Trn645Buff[len++]=0x33+DI2;
	Trn645Buff[len++]=0x33+DI3;
	for(i=4;i<18;i++)
		Check+=Trn645Buff[i];
	Trn645Buff[len++]=(unsigned char)(Check&0xff);
	Trn645Buff[len++]=0x16;
	Dlt645Dbg("\n\r read ITEM DI3 %x DI2 %x DI1 %x DI0 %x",DI3,DI2,DI1,DI0);
	SendStrTo485(Trn645Buff,len);

	//���ͱ���
	//����
	delay(500);
	len=ReceiveFrom485(Rec645Buff);
	for(i=0;i<len;i++)
	{
		if(Rec645Buff[i]==0x68)
		{
			//printf("\n\r -----------break i is %d",i);
			break;
		}
	}
	if(len>=(i+9))
	{
		if(Rec645Buff[i+8]!=0x91)
		{
			Dlt645Dbg("\r\n�����ݻ�Ӧ");
			//printf("\n\r \n\r err1----------");
			memset(Dest,0,GetNum);
			return 0;
		}
		GetLen=Rec645Buff[i+9];
	}
	else
	{
		return 1;
	}

	if(len>=(i+GetLen+12))
	{
		Check=0x00;
		for(j=0;j<(GetLen+10);j++)
		{
			Check=Check+Rec645Buff[i+j];
		}
		if(Check==Rec645Buff[i+GetLen+10])
		{
			DI0=DI0+0x33;
			DI1=DI1+0x33;
			DI2=DI2+0x33;
			DI3=DI3+0x33;
			if((Rec645Buff[i+10]!=DI0)||(Rec645Buff[i+11]!=DI1)||(Rec645Buff[i+12]!=DI2)||(Rec645Buff[i+13]!=DI3))
			{
				memset(Dest,0,GetNum);
				//printf("\n\r \n\r err2----------");
				return 0;
			}
			for(j=0;j<GetNum;j++)
			{
				Rec645Buff[i+14+j]=Rec645Buff[i+14+j]-0x33;
			}
			memset(Dest,0,GetNum);
			if(GetNum>(GetLen-2))
			{
				memcpy(Dest,&Rec645Buff[i+14],GetLen-3);
			}
			else
			{
				memcpy(Dest,&Rec645Buff[i+14],GetNum);
			}
			return 0;
		}
		else
		{
			//printf("\n\r \n\r \n\r \n\r check err %x %x %x %x \n\r \n\r \n\r  ",DI0,DI1,DI2,DI3);
			return 1;
		}
	}
	else
	{
		return 1;
	}
}

//����������
void Get2007Demand_N_Set_Value(unsigned char DDNo)
{

	TS ts;
	if(DDNo>=RtuDataAddr->Meter_Para.Metet_jiaoliu_Num)
		return;
	Dlt645Dbg("\r\nRtuDataAddr->Meter_Para.Metet_jiaoliu_Num=%d",RtuDataAddr->Meter_Para.Metet_jiaoliu_Num);
	Dlt645Dbg("\r\n");
	//�����й��ܵ��ܡ�����1�����й�����
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x00,0x01,0xff,0x00,Demand_N_Set_Value.N_Z_P_All,sizeof(Demand_N_Set_Value.N_Z_P_All)*(FeiLvNum+1)))
	{read485ERR[DDNo]++;}
	//printf("\n\r \n\r \n\r \n\r P_ALL   is    %x %x %x %x \n\r \n\r \n\r \n\r ",Demand_N_Set_Value.N_Z_P_All[0],Demand_N_Set_Value.N_Z_P_All[1],Demand_N_Set_Value.N_Z_P_All[2],Demand_N_Set_Value.N_Z_P_All[3]);
	//�����й��ܵ��ܡ�����1�����й�����
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x00,0x02,0xff,0x00,Demand_N_Set_Value.N_F_P_All,sizeof(Demand_N_Set_Value.N_F_P_All)*(FeiLvNum+1))){read485ERR[DDNo]++;}
	//�����޹��ܵ��ܡ�����1�����޹�����
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x00,0x03,0xff,0x00,Demand_N_Set_Value.N_Z_Q_All,sizeof(Demand_N_Set_Value.N_Z_Q_All)*(FeiLvNum+1))){read485ERR[DDNo]++;}
	//�����޹��ܵ��ܡ�����1�����޹�����
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x00,0x04,0xff,0x00,Demand_N_Set_Value.N_F_Q_All,sizeof(Demand_N_Set_Value.N_F_Q_All)*(FeiLvNum+1))){read485ERR[DDNo]++;}
	//һ�����޹��ܵ��ܡ�����1һ�����޹�����
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x00,0x05,0xff,0x00,Demand_N_Set_Value.N_X1_Q_All,sizeof(Demand_N_Set_Value.N_X1_Q_All)*(FeiLvNum+1))){read485ERR[DDNo]++;}
	//�������޹��ܵ��ܡ�����1�������޹�����
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x00,0x08,0xff,0x00,Demand_N_Set_Value.N_X4_Q_All,sizeof(Demand_N_Set_Value.N_X4_Q_All)*(FeiLvNum+1))){read485ERR[DDNo]++;}
	//�������޹��ܵ��ܡ�����1�������޹�����
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x00,0x06,0xff,0x00,Demand_N_Set_Value.N_X2_Q_All,sizeof(Demand_N_Set_Value.N_X2_Q_All)*(FeiLvNum+1))){read485ERR[DDNo]++;}
	//�������޹��ܵ��ܡ�����1�������޹�����
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x00,0x07,0xff,0x00,Demand_N_Set_Value.N_X3_Q_All,sizeof(Demand_N_Set_Value.N_X3_Q_All)*(FeiLvNum+1))){read485ERR[DDNo]++;}
	//printf("\n\r********** read485ERR[DDNo]===%d",read485ERR[DDNo]);
	//if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x00,0x07,0xff,0x00,Demand_N_Set_Value.N_X3_Q_All,sizeof(Demand_N_Set_Value.N_X3_Q_All)*(FeiLvNum+1))){read485ERR[DDNo]++;}
	Demand_N_Set_Value.valid=1;
	TSGet(&ts);
	Demand_N_Set_Value.Time_Chaobiao.BCD01=((ts.Minute/10)<<4)+(ts.Minute%10);
	Demand_N_Set_Value.Time_Chaobiao.BCD02=((ts.Hour/10)<<4)+(ts.Hour%10);
	Demand_N_Set_Value.Time_Chaobiao.BCD03=((ts.Day/10)<<4)+(ts.Day%10);
	Demand_N_Set_Value.Time_Chaobiao.BCD04=((ts.Month/10)<<4)+(ts.Month%10);
	Demand_N_Set_Value.Time_Chaobiao.BCD05=(((ts.Year%100)/10)<<4)+(ts.Year%10);

	return;
}

//�������������ʱ��
void Get2007Maximum_Demand_NT_Set_Value(unsigned char DDNo)
{
	TS ts;
    unsigned char i;

	if(DDNo>=RtuDataAddr->Meter_Para.Metet_jiaoliu_Num)
		return;
	//printf("\n\r  Begin  Get2007Maximum_Demand_NT_Set_Value  ok ok");
	//�����й�
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x01,0x01,0xff,0x00,mx_dm_nt.N_Z_P_X_All,(sizeof(mx_dm_nt.N_Z_P_X_All)+sizeof(mx_dm_nt.Time_N_Z_P_X_All))*(FeiLvNum+1))){read485ERR[DDNo]++;}
	memcpy(&Maximum_Demand_N_Set_Value.N_Z_P_X_All,&mx_dm_nt.N_Z_P_X_All,3);
	memcpy(&Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_All,&mx_dm_nt.Time_N_Z_P_X_All[0],4);
	//printf("\n\r[0]=%x [1]=%x [2]=%x [3]=%x",Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_All[0],Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_All[1],Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_All[2],Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_All[3]);
	for (i=0;i<FeiLvNum;i++)
	{
		memcpy(&Maximum_Demand_N_Set_Value.N_Z_P_X_F[i],&mx_dm_nt.NT_Z_P_X_F[i].N_X_F,3);
		memcpy(&Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_F[i],&mx_dm_nt.NT_Z_P_X_F[i].Time_N_X_F[0],4);
	}

	//�����й�
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x01,0x02,0xff,0x00,mx_dm_nt.N_F_P_X_All,(sizeof(mx_dm_nt.N_F_P_X_All)+sizeof(mx_dm_nt.Time_N_F_P_X_All))*(FeiLvNum+1))){read485ERR[DDNo]++;}
	memcpy(&Maximum_Demand_N_Set_Value.N_F_P_X_All,&mx_dm_nt.N_F_P_X_All,3);
	memcpy(&Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_All,&mx_dm_nt.Time_N_F_P_X_All[0],4);
	for (i=0;i<FeiLvNum;i++)
	{
		memcpy(&Maximum_Demand_N_Set_Value.N_F_P_X_F[i],&mx_dm_nt.NT_F_P_X_F[i].N_X_F,3);
		memcpy(&Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_F[i],&mx_dm_nt.NT_F_P_X_F[i].Time_N_X_F[0],4);
	}

	//�����޹�
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x01,0x03,0xff,0x00,mx_dm_nt.N_Z_Q_X_All,(sizeof(mx_dm_nt.N_Z_Q_X_All)+sizeof(mx_dm_nt.Time_N_Z_Q_X_All))*(FeiLvNum+1))){read485ERR[DDNo]++;}
	memcpy(&Maximum_Demand_N_Set_Value.N_Z_Q_X_All,&mx_dm_nt.N_Z_Q_X_All,3);
	memcpy(&Maximum_Demand_Time_N_Set_Value.Time_N_Z_Q_X_All,&mx_dm_nt.Time_N_Z_Q_X_All[0],4);
	for (i=0;i<FeiLvNum;i++)
	{
		memcpy(&Maximum_Demand_N_Set_Value.N_Z_Q_X_F[i],&mx_dm_nt.NT_Z_Q_X_F[i].N_X_F,3);
		memcpy(&Maximum_Demand_Time_N_Set_Value.Time_N_Z_Q_X_F[i],&mx_dm_nt.NT_Z_Q_X_F[i].Time_N_X_F[0],4);
	}

    //�����޹�
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x01,0x04,0xff,0x00,mx_dm_nt.N_F_Q_X_All,(sizeof(mx_dm_nt.N_F_Q_X_All)+sizeof(mx_dm_nt.Time_N_F_Q_X_All))*(FeiLvNum+1))){read485ERR[DDNo]++;}
	memcpy(&Maximum_Demand_N_Set_Value.N_F_Q_X_All,&mx_dm_nt.N_F_Q_X_All,3);
	memcpy(&Maximum_Demand_Time_N_Set_Value.Time_N_F_Q_X_All,&mx_dm_nt.Time_N_F_Q_X_All[0],4);
	for (i=0;i<FeiLvNum;i++)
	{
		memcpy(&Maximum_Demand_N_Set_Value.N_F_Q_X_F[i],&mx_dm_nt.NT_F_Q_X_F[i].N_X_F,3);
		memcpy(&Maximum_Demand_Time_N_Set_Value.Time_N_F_Q_X_F[i],&mx_dm_nt.NT_F_Q_X_F[i].Time_N_X_F[0],4);
	}

	//һ�����޹�
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x01,0x05,0xff,0x00,mx_dm_nt.N_X1_Q_X_All,(sizeof(mx_dm_nt.N_X1_Q_X_All)+sizeof(mx_dm_nt.Time_N_X1_Q_X_All))*(FeiLvNum+1))){read485ERR[DDNo]++;}
	memcpy(&Maximum_Demand_N_Set_Value.N_X1_Q_X_All,&mx_dm_nt.N_X1_Q_X_All,3);
	memcpy(&Maximum_Demand_Time_N_Set_Value.Time_N_X1_Q_X_All,&mx_dm_nt.Time_N_X1_Q_X_All[0],4);
	for (i=0;i<FeiLvNum;i++)
	{
		memcpy(&Maximum_Demand_N_Set_Value.N_X1_Q_X_F[i],&mx_dm_nt.NT_X1_Q_X_F[i].N_X_F,3);
		memcpy(&Maximum_Demand_Time_N_Set_Value.Time_N_X1_Q_X_F[i],&mx_dm_nt.NT_X1_Q_X_F[i].Time_N_X_F[0],4);
	}

	//�������޹�
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x01,0x08,0xff,0x00,mx_dm_nt.N_X4_Q_X_All,(sizeof(mx_dm_nt.N_X4_Q_X_All)+sizeof(mx_dm_nt.Time_N_X4_Q_X_All))*(FeiLvNum+1))){read485ERR[DDNo]++;}
	memcpy(&Maximum_Demand_N_Set_Value.N_X4_Q_X_All,&mx_dm_nt.N_X4_Q_X_All,3);
	memcpy(&Maximum_Demand_Time_N_Set_Value.Time_N_X4_Q_X_All,&mx_dm_nt.Time_N_X4_Q_X_All[0],4);
	for (i=0;i<FeiLvNum;i++)
	{
		memcpy(&Maximum_Demand_N_Set_Value.N_X4_Q_X_F[i],&mx_dm_nt.NT_X4_Q_X_F[i].N_X_F,3);
		memcpy(&Maximum_Demand_Time_N_Set_Value.Time_N_X4_Q_X_F[i],&mx_dm_nt.NT_X4_Q_X_F[i].Time_N_X_F[0],4);
	}

	//�������޹�
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x01,0x06,0xff,0x00,mx_dm_nt.N_X2_Q_X_All,(sizeof(mx_dm_nt.N_X2_Q_X_All)+sizeof(mx_dm_nt.Time_N_X2_Q_X_All))*(FeiLvNum+1))){read485ERR[DDNo]++;}
	memcpy(&Maximum_Demand_N_Set_Value.N_X2_Q_X_All,&mx_dm_nt.N_X2_Q_X_All,3);
	memcpy(&Maximum_Demand_Time_N_Set_Value.Time_N_X2_Q_X_All,&mx_dm_nt.Time_N_X2_Q_X_All[0],4);
	for (i=0;i<FeiLvNum;i++)
	{
		memcpy(&Maximum_Demand_N_Set_Value.N_X2_Q_X_F[i],&mx_dm_nt.NT_X2_Q_X_F[i].N_X_F,3);
		memcpy(&Maximum_Demand_Time_N_Set_Value.Time_N_X2_Q_X_F[i],&mx_dm_nt.NT_X2_Q_X_F[i].Time_N_X_F[0],4);
	}

	//�������޹�
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x01,0x07,0xff,0x00,mx_dm_nt.N_X3_Q_X_All,(sizeof(mx_dm_nt.N_X3_Q_X_All)+sizeof(mx_dm_nt.Time_N_X3_Q_X_All))*(FeiLvNum+1))){read485ERR[DDNo]++;}
	memcpy(&Maximum_Demand_N_Set_Value.N_X3_Q_X_All,&mx_dm_nt.N_X3_Q_X_All,3);
	memcpy(&Maximum_Demand_Time_N_Set_Value.Time_N_X3_Q_X_All,&mx_dm_nt.Time_N_X3_Q_X_All[0],4);
	for (i=0;i<FeiLvNum;i++)
	{
		memcpy(&Maximum_Demand_N_Set_Value.N_X3_Q_X_F[i],&mx_dm_nt.NT_X3_Q_X_F[i].N_X_F,3);
		memcpy(&Maximum_Demand_Time_N_Set_Value.Time_N_X3_Q_X_F[i],&mx_dm_nt.NT_X3_Q_X_F[i].Time_N_X_F[0],4);
	}
	//if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x02,0x07,0xff,0x00,Maximum_Demand_N_Set_Value.IAJ,6)){read485ERR[DDNo]++;}

	Maximum_Demand_N_Set_Value.valid=1;
	Maximum_Demand_Time_N_Set_Value.valid=1;
	TSGet(&ts);
	Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD01=((ts.Minute/10)<<4)+(ts.Minute%10);
	Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD02=((ts.Hour/10)<<4)+(ts.Hour%10);
	Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD03=((ts.Day/10)<<4)+(ts.Day%10);
	Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD04=((ts.Month/10)<<4)+(ts.Month%10);
	Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD05=(((ts.Year%100)/10)<<4)+(ts.Year%10);

	return;
}

void Get2007Variable_Set_value(unsigned char DDNo)
{
	TS ts;

	if(DDNo>=RtuDataAddr->Meter_Para.Metet_jiaoliu_Num)
		return;

	//���һ�α��ʱ��
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x03,0x30,0x00,0x01,v2007s.Time_LastProg,6)){read485ERR[DDNo]++;}
	//memcpy(&Variable_Set_value.Time_LastProg,&v2007s.Time_LastProg[2],4);//xinjia[2]

	//���һ�������������ʱ��
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x03,0x30,0x02,0x01,v2007s.Time_LastZero,6)){read485ERR[DDNo]++;}
	//memcpy(&Variable_Set_value.Time_LastZero,&v2007s.Time_LastZero[2],4);//xinjia[2]

	//��̴���
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x03,0x30,0x00,0x00,v2007s.ProgNum,3)){read485ERR[DDNo]++;}
	//memcpy(&Variable_Set_value.ProgNum,&v2007s.ProgNum[1],2);//xinjia[1]

	//��������������
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x03,0x30,0x02,0x00,v2007s.ZeroNum,3)){read485ERR[DDNo]++;}
	//memcpy(&Variable_Set_value.ZeroNum,&v2007s.ZeroNum[1],2);//xinjia[1]

	//��ع���ʱ��
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x02,0x80,0x00,0x0a,v2007s.Time_Battery,3)){read485ERR[DDNo]++;}
	memcpy(&Variable_Set_value.Time_Battery,&v2007s.Time_Battery[0],3);//xinjia[1]
	//��������ܴ���
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x03,0x30,0x01,0x00,v2007s.DbQingNum,3)){read485ERR[DDNo]++;}
	//��������ܷ���ʱ��
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x03,0x30,0x01,0x01,v2007s.LastDbQing_Time,6)){read485ERR[DDNo]++;}
	//�¼������ܴ���������ʱ��
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x03,0x30,0x03,0x00,v2007s.EventQingNum,3)){read485ERR[DDNo]++;}
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x03,0x30,0x03,0x01,v2007s.LastEventQing_Time,6)){read485ERR[DDNo]++;}
	//Уʱ�ܴ���������ʱ��
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x03,0x30,0x04,0x00,v2007s.JiaoshiNum,3)){read485ERR[DDNo]++;}
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x03,0x30,0x03,0x01,v2007s.JiaoShiShuJu,10)){read485ERR[DDNo]++;}
	memcpy(v2007s.LastJiaoshi_Time,&v2007s.JiaoShiShuJu[4],6);

	//�ܶ������������ʱ���ۼ�ֵ

	//ABC����ʱ���ۼ�ֵ���������
	//if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x03,0x04,0x00,0x00,v2007s.A_Duan_Time,18)){read485ERR[DDNo]++;}
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x13,0x01,0x00,0x01,v2007s.A_Duan,3)){read485ERR[DDNo]++;}
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x13,0x01,0x00,0x02,v2007s.A_Duan_Time,3)){read485ERR[DDNo]++;}
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x13,0x02,0x00,0x01,v2007s.B_Duan,3)){read485ERR[DDNo]++;}
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x13,0x02,0x00,0x02,v2007s.B_Duan_Time,3)){read485ERR[DDNo]++;}
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x13,0x03,0x00,0x01,v2007s.C_Duan,3)){read485ERR[DDNo]++;}
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x13,0x03,0x00,0x02,v2007s.C_Duan_Time,3)){read485ERR[DDNo]++;}
	memcpy(&Variable_Set_value.A_Duan,&v2007s.A_Duan[0],2);
	memcpy(&Variable_Set_value.A_Duan_Time,&v2007s.A_Duan_Time,3);
	memcpy(&Variable_Set_value.B_Duan,&v2007s.B_Duan[0],2);
	memcpy(&Variable_Set_value.B_Duan_Time,&v2007s.B_Duan_Time,3);
	memcpy(&Variable_Set_value.C_Duan,&v2007s.C_Duan[0],2);
	memcpy(&Variable_Set_value.C_Duan_Time,&v2007s.C_Duan_Time,3);

	//���һ�ζ�����ʼ������ʱ��

	//A�������ʼʱ�̡�����ʱ��
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x13,0x01,0x01,0x01,v2007s.Time_ADuan_S,6)){read485ERR[DDNo]++;}
	memcpy(&Variable_Set_value.Time_ADuan_S,&v2007s.Time_ADuan_S[1],4);
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x13,0x01,0x25,0x01,v2007s.Time_ADuan_E,6)){read485ERR[DDNo]++;}
	memcpy(&Variable_Set_value.Time_ADuan_E,&v2007s.Time_ADuan_E[1],4);

	//B�������ʼʱ�̡�����ʱ��
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x13,0x02,0x01,0x01,v2007s.Time_BDuan_S,6)){read485ERR[DDNo]++;}
	memcpy(&Variable_Set_value.Time_BDuan_S,&v2007s.Time_BDuan_S[1],4);
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x13,0x02,0x25,0x01,v2007s.Time_BDuan_E,6)){read485ERR[DDNo]++;}
	memcpy(&Variable_Set_value.Time_BDuan_E,&v2007s.Time_BDuan_E[1],4);

	//C�������ʼʱ�̡�����ʱ��
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x13,0x03,0x01,0x01,v2007s.Time_CDuan_S,6)){read485ERR[DDNo]++;}
	memcpy(&Variable_Set_value.Time_CDuan_S,&v2007s.Time_CDuan_S[1],4);
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x13,0x03,0x25,0x01,v2007s.Time_CDuan_E,6)){read485ERR[DDNo]++;}
	memcpy(&Variable_Set_value.Time_CDuan_E,&v2007s.Time_CDuan_E[1],4);

	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x01,0x00,0x01,Variable_Set_value.A_ShiYa,3)){read485ERR[DDNo]++;}
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x02,0x00,0x01,Variable_Set_value.B_ShiYa,3)){read485ERR[DDNo]++;}
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x03,0x00,0x01,Variable_Set_value.C_ShiYa,3)){read485ERR[DDNo]++;}

	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x00,0x00,0x01,Variable_Set_value.shiyacishu,3)){read485ERR[DDNo]++;}
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x00,0x00,0x02,Variable_Set_value.shiya_time,3)){read485ERR[DDNo]++;}
	//printf("\n\r\n\r\n\r\n\r shiya    %x  %x  %x \n\r\n\r\n\r\n\r\n\r\n\r",Variable_Set_value.shiyacishu[0],Variable_Set_value.shiyacishu[1],Variable_Set_value.shiyacishu[2]);
	//printf("\n\r\n\r\n\r\n\r shiya_time    %x  %x  %x \n\r\n\r\n\r\n\r\n\r\n\r",Variable_Set_value.shiya_time[0],Variable_Set_value.shiya_time[1],Variable_Set_value.shiya_time[2]);
	//���һ��ʧѹ��ʼ������ʱ��

	//�����ѹ��ƽ��
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x16,0x00,0x01,0x01,Variable_Set_value.U_Unbalance.StartTime,6)){read485ERR[DDNo]++;}
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x16,0x00,0x12,0x01,Variable_Set_value.U_Unbalance.BupinghengValue,3)){read485ERR[DDNo]++;}

	//���������ƽ��
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x17,0x00,0x01,0x01,Variable_Set_value.I_Unbalance.StartTime,6)){read485ERR[DDNo]++;}
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x17,0x00,0x12,0x01,Variable_Set_value.I_Unbalance.BupinghengValue,3)){read485ERR[DDNo]++;}

	//A��ʧѹ��ʼʱ�̡�����ʱ��
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x03,0x01,0x01,0x01,v2007s.Time_AShi_S,12)){read485ERR[DDNo]++;}
	memcpy(&Variable_Set_value.Time_AShi_S,&v2007s.Time_AShi_S[2],4);
	memcpy(&Variable_Set_value.Time_AShi_E,&v2007s.Time_AShi_E[2],4);

	//B��ʧѹ��ʼʱ�̡�����ʱ��
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x03,0x01,0x02,0x01,v2007s.Time_BShi_S,12)){read485ERR[DDNo]++;}
	memcpy(&Variable_Set_value.Time_BShi_S,&v2007s.Time_BShi_S[2],4);
	memcpy(&Variable_Set_value.Time_BShi_E,&v2007s.Time_BShi_E[2],4);

	//C��ʧѹ��ʼʱ�̡�����ʱ��
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x03,0x01,0x03,0x01,v2007s.Time_CShi_S,12)){read485ERR[DDNo]++;}
	memcpy(&Variable_Set_value.Time_CShi_S,&v2007s.Time_CShi_S[2],4);
	memcpy(&Variable_Set_value.Time_CShi_E,&v2007s.Time_CShi_E[2],4);

	//Ϊ�˱��Ⳮ����2007��ʱb��c���ѹ��ʾ1665����������ϲ���������-86.65���������´���.
	//ABC���ѹ
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x02,0x01,0xff,0x00,Variable_Set_value.VA,6)){read485ERR[DDNo]++;}
	if((Variable_Set_value.VA[0]==0xff)&&(Variable_Set_value.VA[1]==0xff))
		memset(Variable_Set_value.VA,0,2);
	else
	{
		Variable_Set_value.VA[0]=(Variable_Set_value.VA[0]>>4)&0x0f;
		Variable_Set_value.VA[0]=((Variable_Set_value.VA[1]<<4)&0xf0)|Variable_Set_value.VA[0];
		Variable_Set_value.VA[1]=(Variable_Set_value.VA[1]>>4)&0x0f;
	}
	if((Variable_Set_value.VB[0]==0xff)&&(Variable_Set_value.VB[1]==0xff))
		memset(Variable_Set_value.VB,0,2);
	else
	{
		Variable_Set_value.VB[0]=(Variable_Set_value.VB[0]>>4)&0x0f;
		Variable_Set_value.VB[0]=((Variable_Set_value.VB[1]<<4)&0xf0)|Variable_Set_value.VB[0];
		Variable_Set_value.VB[1]=(Variable_Set_value.VB[1]>>4)&0x0f;
	}
	if((Variable_Set_value.VC[0]==0xff)&&(Variable_Set_value.VC[1]==0xff))
		memset(Variable_Set_value.VC,0,2);
	else
	{
		Variable_Set_value.VC[0]=(Variable_Set_value.VC[0]>>4)&0x0f;
		Variable_Set_value.VC[0]=((Variable_Set_value.VC[1]<<4)&0xf0)|Variable_Set_value.VC[0];
		Variable_Set_value.VC[1]=(Variable_Set_value.VC[1]>>4)&0x0f;
	}

	//ABC�����-----�����ֽڲ�ƥ��
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x02,0x02,0xff,0x00,v2007s.IA,9)){read485ERR[DDNo]++;}
	if((v2007s.IA[0]==0xff)&&(v2007s.IA[1]==0xff)&&(v2007s.IA[2]==0Xff))
		memset(v2007s.IA,0,3);
	else
	{
		Variable_Set_value.IA[0]=((v2007s.IA[1]&0x0f)<<4)|((v2007s.IA[0]>>4)&0x0f);
		Variable_Set_value.IA[1]=((v2007s.IA[2]&0x0f)<<4)|((v2007s.IA[1]>>4)&0x0f);
		Variable_Set_value.IA[1]=Variable_Set_value.IA[1]|((v2007s.IA[2])&0x80);
	}
	if((v2007s.IB[0]==0xff)&&(v2007s.IB[1]==0xff)&&(v2007s.IB[2]==0Xff))
		memset(v2007s.IB,0,3);
	else
	{
		Variable_Set_value.IB[0]=((v2007s.IB[1]&0x0f)<<4)|((v2007s.IB[0]>>4)&0x0f);
		Variable_Set_value.IB[1]=((v2007s.IB[2]&0x0f)<<4)|((v2007s.IB[1]>>4)&0x0f);
		Variable_Set_value.IB[1]=Variable_Set_value.IB[1]|((v2007s.IB[2])&0x80);
	}
	if((v2007s.IC[0]==0xff)&&(v2007s.IC[1]==0xff)&&(v2007s.IC[2]==0Xff))
		memset(v2007s.IC,0,3);
	else
	{
		Variable_Set_value.IC[0]=((v2007s.IC[1]&0x0f)<<4)|((v2007s.IC[0]>>4)&0x0f);
		Variable_Set_value.IC[1]=((v2007s.IC[2]&0x0f)<<4)|((v2007s.IC[1]>>4)&0x0f);
		Variable_Set_value.IC[1]=Variable_Set_value.IC[1]|((v2007s.IC[2])&0x80);
	}

	//Variable_Set_value.IL[0]=(v2007s.IL[1]&0xf0)|((v2007s.IL[0]>>4)&0x0f);
	//Variable_Set_value.IL[1]=(v2007s.IL[2]&0x0f)|((v2007s.IL[1]<<4)&0xf0);
	//˲ʱ�й����ʡ�ABC���й�����
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x02,0x03,0xff,0x00,Variable_Set_value.P,12)){read485ERR[DDNo]++;}

	//�������й���������ֵ
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x04,0x00,0x0E,0x01,v2007s.Z_P_UP,6)){read485ERR[DDNo]++;}
	memcpy(&Variable_Set_value.Z_P_UP,&v2007s.Z_P_UP,2);

	//˲ʱ�޹����ʡ�ABC���޹�����
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x02,0x04,0xff,0x00,v2007s.Q,12)){read485ERR[DDNo]++;}
	Variable_Set_value.Q[0]=v2007s.Q[1];
	Variable_Set_value.Q[1]=v2007s.Q[2];
	Variable_Set_value.QA[0]=v2007s.QA[1];
	Variable_Set_value.QA[1]=v2007s.QA[2];
	Variable_Set_value.QB[0]=v2007s.QB[1];
	Variable_Set_value.QB[1]=v2007s.QB[2];
	Variable_Set_value.QC[0]=v2007s.QC[1];
	Variable_Set_value.QC[1]=v2007s.QC[2];

	//�ܹ���������ABC�๦������
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x02,0x06,0xff,0x00,Variable_Set_value.Cos,8)){read485ERR[DDNo]++;}
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x02,0x07,0xff,0x00,Variable_Set_value.Ajiao,6)){read485ERR[DDNo]++;}
	//���ڼ��ܴΡ�ʱ�䡢����������ڡ�����ʱ��
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x04,0x00,0x01,0x01,v2007s.Date_Week,4)){read485ERR[DDNo]++;}
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x04,0x00,0x01,0x02,v2007s.Now_Time,3)){read485ERR[DDNo]++;}

	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x04,0x00,0x01,0x03,&v2007s.Zhou_qi_xu_liang,1)){read485ERR[DDNo]++;}
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x04,0x00,0x01,0x04,&v2007s.Time_hua_cha,1)){read485ERR[DDNo]++;}

	memcpy(&Variable_Set_value.Date_Week,&v2007s.Date_Week,4);
	memcpy(&Variable_Set_value.Now_Time,&v2007s.Now_Time,3);
	Variable_Set_value.Zhou_qi_xu_liang=v2007s.Zhou_qi_xu_liang;
	Variable_Set_value.Time_hua_cha=v2007s.Time_hua_cha;

	//��ʱ��������ʱ�α�������ʱ�Σ�ÿ���л���)��������������������
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x04,0x00,0x02,0x01,&v2007s.Year_ShiQu,1)){read485ERR[DDNo]++;}
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x04,0x00,0x02,0x02,&v2007s.Day_ShiDuanBiao,1)){read485ERR[DDNo]++;}
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x04,0x00,0x02,0x03,&v2007s.Now_ShiDuan,1)){read485ERR[DDNo]++;}
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x04,0x00,0x02,0x04,&v2007s.FeiLvShu,1)){read485ERR[DDNo]++;}
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x04,0x00,0x02,0x05,v2007s.GongGongJiari,2)){read485ERR[DDNo]++;}
	//ѭ��ʱ�䡢��ʾ����С��λ������ʾ���ʣ����������С��λ��
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x04,0x00,0x03,0x02,&v2007s.Time_xun_xian,1)){read485ERR[DDNo]++;}
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x04,0x00,0x03,0x03,&v2007s.Dian_neng_xiaoshuwei,1)){read485ERR[DDNo]++;}
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x04,0x00,0x03,0x04,&v2007s.Gong_lv_xiaoshuwei,1)){read485ERR[DDNo]++;}
	Variable_Set_value.Time_xun_xian = v2007s.Time_xun_xian;
	Variable_Set_value.Dian_neng_xiaoshuwei = v2007s.Dian_neng_xiaoshuwei;
	Variable_Set_value.Gong_lv_xiaoshuwei = v2007s.Gong_lv_xiaoshuwei;

	//ͣ��ʱ��
	//�������״̬��
	//if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x04,0x00,0x05,0x01,&Variable_Set_value.Dian_biao_stat,1)){read485ERR[DDNo]++;}
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x04,0x00,0x05,0xff,&v2007s.Dian_biao_stat[0][0],14)){read485ERR[DDNo]++;}

	//����״̬��

	//������״̬��
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x04,0x00,0x08,0x01,&Variable_Set_value.Zhou_xiu_stat,1)){read485ERR[DDNo]++;}

	//�������P��Q
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x04,0x00,0x04,0x09,Variable_Set_value.Dian_biao_changshu_P,3)){read485ERR[DDNo]++;}
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x04,0x00,0x04,0x0a,Variable_Set_value.Dian_biao_changshu_Q,3)){read485ERR[DDNo]++;}

	//����
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x04,0x00,0x04,0x02,Variable_Set_value.Dian_biao_hao,6)){read485ERR[DDNo]++;}

	//�û��š��豸��

	//�Զ���������
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x04,0x00,0x0b,0x01,Variable_Set_value.Chao_biao_riqi,2)){read485ERR[DDNo]++;}

	//���ɴ����ա��й�������ʼ�������޹�������ʼ����

	//ʱ����ʼ���ڼ���ʱ�α���
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x04,0x01,0x00,0x00,Variable_Set_value.c320,30)){read485ERR[DDNo]++;}

	//��һ��ʱ�α���Nʱ����ʼʱ�估���ʺ�
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x04,0x01,0x00,0x01,Variable_Set_value.c330,30)){read485ERR[DDNo]++;}

	//�ڶ���ʱ�α���Nʱ����ʼʱ�估���ʺ�
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x04,0x01,0x00,0x02,Variable_Set_value.c340,30)){read485ERR[DDNo]++;}

	//������ʱ�α���Nʱ����ʼʱ�估���ʺ�
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x04,0x01,0x00,0x03,Variable_Set_value.c350,30)){read485ERR[DDNo]++;}

	//������ʱ�α���Nʱ����ʼʱ�估���ʺ�
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x04,0x01,0x00,0x04,Variable_Set_value.c360,30)){read485ERR[DDNo]++;}

	//������ʱ�α���Nʱ����ʼʱ�估���ʺ�
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x04,0x01,0x00,0x05,Variable_Set_value.c370,30)){read485ERR[DDNo]++;}

	//������ʱ�α���Nʱ����ʼʱ�估���ʺ�
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x04,0x01,0x00,0x06,Variable_Set_value.c380,30)){read485ERR[DDNo]++;}

	//������ʱ�α���Nʱ����ʼʱ�估���ʺ�
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x04,0x01,0x00,0x07,Variable_Set_value.c390,30)){read485ERR[DDNo]++;}

	//�ڰ���ʱ�α���Nʱ����ʼʱ�估���ʺ�
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x04,0x01,0x00,0x08,Variable_Set_value.c3a0,30)){read485ERR[DDNo]++;}

	//ʱ�α�����ܴ���
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x03,0x30,0x05,0x00,v2007s.TimePronum,3)){read485ERR[DDNo]++;}

	//���ͣ�����
	if(Dlt645_2007GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x03,0x11,0x00,0x00,Variable_Set_value.TingDianNum ,3)){read485ERR[DDNo]++;}
	//printf("\n\rVariable_Set_value.TingDianNum[0]=%xVariable_Set_value.TingDianNum[1]=%x Variable_Set_value.TingDianNum[2]=%x",Variable_Set_value.TingDianNum[0],Variable_Set_value.TingDianNum[1],Variable_Set_value.TingDianNum[3]);
	//printf("\n\r");
	//for(i=0;i<10;i++)
	//{
	//	memcpy(Variable_Set_value.c410+i*3,v2007s.c410+i*4,3);
	//}
	memcpy(Variable_Set_value.TimePronum,v2007s.TimePronum,3);
	//�����ղ��õ���ʱ�α���
	Variable_Set_value.valid=1;
	TSGet(&ts);
	Variable_Set_value.Time_Chaobiao.BCD01=((ts.Minute/10)<<4)+(ts.Minute%10);
	Variable_Set_value.Time_Chaobiao.BCD02=((ts.Hour/10)<<4)+(ts.Hour%10);
	Variable_Set_value.Time_Chaobiao.BCD03=((ts.Day/10)<<4)+(ts.Day%10);
	Variable_Set_value.Time_Chaobiao.BCD04=((ts.Month/10)<<4)+(ts.Month%10);
	Variable_Set_value.Time_Chaobiao.BCD05=(((ts.Year%100)/10)<<4)+(ts.Year%10);

	return;
}
time_t changetime(int min,int hour,int day,int month)
{
	struct tm timep;
	time_t t;
	timep.tm_sec=0;
	timep.tm_min=min;
	timep.tm_hour=hour;
	timep.tm_mday=day;
	timep.tm_mon=month-1;
	timep.tm_year=110;
	t=mktime(&timep);
	return t;
}
int MaxValue(time_t a,time_t b,time_t c)
{
	time_t t;
	t=a;
	if(t<b)t=b;
	if(t<c)t=c;
	return t;
}
void DLT645_2007_Data_Calc(unsigned char DDNo)
{
	unsigned char /*j,*/Num;
	char ERRCreate;
	unsigned char tmpchg[14];
	unsigned char tmp;
	unsigned char tmpstat[14];
	int min,hour,day,month;
	unsigned char i,j;
    INT16U DuanXiang_All;
    time_t A_Time,B_Time,C_Time,MAX_TIME;
	if(RtuDataAddr->Meter_Para.Valid!=1)
		return;
	if(RtuDataAddr->Meter_Para.Metet_jiaoliu_Num>CeLiangPoint_Max)
		return;
	if(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].GuiYue_Type==30)
	{
		Num=RtuDataAddr->Meter_Para.Dian_Meter[DDNo].CeLiangNo-1;
		if(Num>CeLiangPoint_Max)
			return;
        //Num=0;
		if(Demand_N_Set_Value.valid==1)
		{
			memcpy(&RtuDataAddr->DD_Device_BiaoShi_Value[Num].Chao_Time.BCD01,&Demand_N_Set_Value.Time_Chaobiao.BCD01,5);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_All=BCDTo_INT32(Demand_N_Set_Value.N_Z_P_All,4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_F[0]=BCDTo_INT32(Demand_N_Set_Value.N_Z_P_F[0],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_F[1]=BCDTo_INT32(Demand_N_Set_Value.N_Z_P_F[1],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_F[2]=BCDTo_INT32(Demand_N_Set_Value.N_Z_P_F[2],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_F[3]=BCDTo_INT32(Demand_N_Set_Value.N_Z_P_F[3],4);

			RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_All=BCDTo_INT32(Demand_N_Set_Value.N_F_P_All,4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_F[0]=BCDTo_INT32(Demand_N_Set_Value.N_F_P_F[0],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_F[1]=BCDTo_INT32(Demand_N_Set_Value.N_F_P_F[1],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_F[2]=BCDTo_INT32(Demand_N_Set_Value.N_F_P_F[2],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_F[3]=BCDTo_INT32(Demand_N_Set_Value.N_F_P_F[3],4);

			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_All=BCDTo_INT32(Demand_N_Set_Value.N_Z_Q_All,4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_F[0]=BCDTo_INT32(Demand_N_Set_Value.N_Z_Q_F[0],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_F[1]=BCDTo_INT32(Demand_N_Set_Value.N_Z_Q_F[1],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_F[2]=BCDTo_INT32(Demand_N_Set_Value.N_Z_Q_F[2],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_F[3]=BCDTo_INT32(Demand_N_Set_Value.N_Z_Q_F[3],4);

			RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_All=BCDTo_INT32(Demand_N_Set_Value.N_F_Q_All,4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_F[0]=BCDTo_INT32(Demand_N_Set_Value.N_F_Q_F[0],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_F[1]=BCDTo_INT32(Demand_N_Set_Value.N_F_Q_F[1],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_F[2]=BCDTo_INT32(Demand_N_Set_Value.N_F_Q_F[2],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_F[3]=BCDTo_INT32(Demand_N_Set_Value.N_F_Q_F[3],4);

			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X1_Q_All=BCDTo_INT32(Demand_N_Set_Value.N_X1_Q_All,4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X1_F_Q[0]=BCDTo_INT32(Demand_N_Set_Value.N_X1_Q_F[0],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X1_F_Q[1]=BCDTo_INT32(Demand_N_Set_Value.N_X1_Q_F[1],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X1_F_Q[2]=BCDTo_INT32(Demand_N_Set_Value.N_X1_Q_F[2],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X1_F_Q[3]=BCDTo_INT32(Demand_N_Set_Value.N_X1_Q_F[3],4);

			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X4_Q_All=BCDTo_INT32(Demand_N_Set_Value.N_X4_Q_All,4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X4_F_Q[0]=BCDTo_INT32(Demand_N_Set_Value.N_X4_Q_F[0],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X4_F_Q[1]=BCDTo_INT32(Demand_N_Set_Value.N_X4_Q_F[1],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X4_F_Q[2]=BCDTo_INT32(Demand_N_Set_Value.N_X4_Q_F[2],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X4_F_Q[3]=BCDTo_INT32(Demand_N_Set_Value.N_X4_Q_F[3],4);

			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X2_Q_All=BCDTo_INT32(Demand_N_Set_Value.N_X2_Q_All,4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X2_F_Q[0]=BCDTo_INT32(Demand_N_Set_Value.N_X2_Q_F[0],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X2_F_Q[1]=BCDTo_INT32(Demand_N_Set_Value.N_X2_Q_F[1],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X2_F_Q[2]=BCDTo_INT32(Demand_N_Set_Value.N_X2_Q_F[2],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X2_F_Q[3]=BCDTo_INT32(Demand_N_Set_Value.N_X2_Q_F[3],4);

			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X3_Q_All=BCDTo_INT32(Demand_N_Set_Value.N_X3_Q_All,4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X3_F_Q[0]=BCDTo_INT32(Demand_N_Set_Value.N_X3_Q_F[0],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X3_F_Q[1]=BCDTo_INT32(Demand_N_Set_Value.N_X3_Q_F[1],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X3_F_Q[2]=BCDTo_INT32(Demand_N_Set_Value.N_X3_Q_F[2],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X3_F_Q[3]=BCDTo_INT32(Demand_N_Set_Value.N_X3_Q_F[3],4);

			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Valid=1;
		}

		if(Maximum_Demand_N_Set_Value.valid==1)
		{
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Chao_Time.BCD01,&Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD01,5);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_P_X_All=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_Z_P_X_All,3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_P_X_F[0]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_Z_P_X_F[0],3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_P_X_F[1]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_Z_P_X_F[1],3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_P_X_F[2]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_Z_P_X_F[2],3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_P_X_F[3]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_Z_P_X_F[3],3);

			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_P_X_All=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_F_P_X_All,3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_P_X_F[0]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_F_P_X_F[0],3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_P_X_F[1]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_F_P_X_F[1],3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_P_X_F[2]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_F_P_X_F[2],3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_P_X_F[3]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_F_P_X_F[3],3);

			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_Q_X_All=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_Z_Q_X_All,3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_Q_X_F[0]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_Z_Q_X_F[0],3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_Q_X_F[1]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_Z_Q_X_F[1],3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_Q_X_F[2]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_Z_Q_X_F[2],3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_Q_X_F[3]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_Z_Q_X_F[3],3);

			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_Q_X_All=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_F_Q_X_All,3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_Q_X_F[0]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_F_Q_X_F[0],3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_Q_X_F[1]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_F_Q_X_F[1],3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_Q_X_F[2]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_F_Q_X_F[2],3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_Q_X_F[3]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_F_Q_X_F[3],3);

			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Valid=1;
		}
		//printf("\n\rMaximum_Demand_Time_N_Set_Value.valid===%d",Maximum_Demand_Time_N_Set_Value.valid);
		if(Maximum_Demand_Time_N_Set_Value.valid==1)
		{
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Chao_Time.BCD01,&Maximum_Demand_Time_N_Set_Value.Time_Chaobiao.BCD01,5);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_P_X_All[0],&Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_All[0],4);
			//printf("\n\rTime_Z_P_X_All[0]==%x Time_Z_P_X_All[1]==%x Time_Z_P_X_All[2]==%x Time_Z_P_X_All[3]==%x",RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_P_X_All[0],RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_P_X_All[1],RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_P_X_All[2],RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_P_X_All[3]);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_P_X_F[0][0],&Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_F[0][0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_P_X_F[1][0],&Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_F[1][0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_P_X_F[2][0],&Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_F[2][0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_P_X_F[3][0],&Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_F[3][0],4);

			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_P_X_All[0],&Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_All[0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_P_X_F[0][0],&Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_F[0][0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_P_X_F[1][0],&Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_F[1][0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_P_X_F[2][0],&Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_F[2][0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_P_X_F[3][0],&Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_F[3][0],4);

			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_Q_X_All[0],&Maximum_Demand_Time_N_Set_Value.Time_N_Z_Q_X_All[0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_Q_X_F[0][0],&Maximum_Demand_Time_N_Set_Value.Time_N_Z_Q_X_F[0][0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_Q_X_F[1][0],&Maximum_Demand_Time_N_Set_Value.Time_N_Z_Q_X_F[1][0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_Q_X_F[2][0],&Maximum_Demand_Time_N_Set_Value.Time_N_Z_Q_X_F[2][0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_Q_X_F[3][0],&Maximum_Demand_Time_N_Set_Value.Time_N_Z_Q_X_F[3][0],4);

			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_Q_X_All[0],&Maximum_Demand_Time_N_Set_Value.Time_N_F_Q_X_All[0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_Q_X_F[0][0],&Maximum_Demand_Time_N_Set_Value.Time_N_F_Q_X_F[0][0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_Q_X_F[1][0],&Maximum_Demand_Time_N_Set_Value.Time_N_F_Q_X_F[1][0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_Q_X_F[2][0],&Maximum_Demand_Time_N_Set_Value.Time_N_F_Q_X_F[2][0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_Q_X_F[3][0],&Maximum_Demand_Time_N_Set_Value.Time_N_F_Q_X_F[3][0],4);

			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Valid=1;
		}
		if(Variable_Set_value.valid==1)
		{
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].UAJ=0;//BCDTo_INT32(Variable_Set_value.Ajiao,2);//0
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].UBJ=1200;//BCDTo_INT32(Variable_Set_value.Bjiao,2);//1200
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].UCJ=2400;//BCDTo_INT32(Variable_Set_value.Cjiao,2);//2400
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].IAJ=0;//BCDTo_INT32(Variable_Set_value.Ajiao,2);//0
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].IBJ=1200;//BCDTo_INT32(Variable_Set_value.Bjiao,2);//1200
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].ICJ=2400;//BCDTo_INT32(Variable_Set_value.Cjiao,2);//2400

			memcpy(&RtuDataAddr->DD_Device_BiaoShi_Value[Num].Chao_Time.BCD01,&Variable_Set_value.Time_Chaobiao.BCD01,5);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Cos=BCDTo_INT32(Variable_Set_value.Cos,2);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].CosA=BCDTo_INT32(Variable_Set_value.CosA,2);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].CosB=BCDTo_INT32(Variable_Set_value.CosB,2);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].CosC=BCDTo_INT32(Variable_Set_value.CosC,2);

			RtuDataAddr->DD_Device_BiaoShi_Value[Num].IA=BCDTo_INT32(Variable_Set_value.IA,2);//0.01A
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].IB=BCDTo_INT32(Variable_Set_value.IB,2);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].IC=BCDTo_INT32(Variable_Set_value.IC,2);
			//DD_Device_BiaoShi_Value[Num].IL=BCDTo_INT32(Variable_Set_value.IL,2);

//			printf("\n\r2007 Variable_Set_value.VA[0] %02x [1] %02x",Variable_Set_value.VA[0],Variable_Set_value.VA[1]);
//			printf("\n\r2007 Variable_Set_value.VB[0] %02x [1] %02x",Variable_Set_value.VB[0],Variable_Set_value.VB[1]);
//			printf("\n\r2007 Variable_Set_value.VC[0] %02x [1] %02x",Variable_Set_value.VC[0],Variable_Set_value.VC[1]);
//			printf("\n\r");
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].VA=BCDTo_INT32(Variable_Set_value.VA,2)*10;//0.1V
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].VB=BCDTo_INT32(Variable_Set_value.VB,2)*10;
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].VC=BCDTo_INT32(Variable_Set_value.VC,2)*10;

//			printf("\n\r2007 VA %d",RtuDataAddr->DD_Device_BiaoShi_Value[Num].VA);
//			printf("\n\r2007 VB %d",RtuDataAddr->DD_Device_BiaoShi_Value[Num].VB);
//			printf("\n\r2007 VC %d",RtuDataAddr->DD_Device_BiaoShi_Value[Num].VC);
//			printf("\n\r");

			RtuDataAddr->DD_Device_BiaoShi_Value[Num].P=BCDTo_INT32(Variable_Set_value.P,3);//��λС��
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].PA=BCDTo_INT32(Variable_Set_value.PA,3);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].PB=BCDTo_INT32(Variable_Set_value.PB,3);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].PC=BCDTo_INT32(Variable_Set_value.PC,3);

			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Q=BCDTo_INT32(Variable_Set_value.Q,2)*100;
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].QA=BCDTo_INT32(Variable_Set_value.QA,2)*100;
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].QB=BCDTo_INT32(Variable_Set_value.QB,2)*100;
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].QC=BCDTo_INT32(Variable_Set_value.QC,2)*100;


			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].Chao_Time.BCD01,&Variable_Set_value.Time_Chaobiao.BCD01,5);
			//-------------------------------------------->
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].Date_Week[0],&Variable_Set_value.Date_Week[0],4);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].Now_Time[0],&Variable_Set_value.Now_Time[0],3);
			//--------------------------------------------<
			tmp=Variable_Set_value.Date_Week[0];
			//date transform
			RtuDataAddr->DD_BianLiang_Shuju[Num].NowDB_Time.BCDSec  = Variable_Set_value.Now_Time[0];
			RtuDataAddr->DD_BianLiang_Shuju[Num].NowDB_Time.BCDMin  = Variable_Set_value.Now_Time[1];
			RtuDataAddr->DD_BianLiang_Shuju[Num].NowDB_Time.BCDHour = Variable_Set_value.Now_Time[2];
			RtuDataAddr->DD_BianLiang_Shuju[Num].NowDB_Time.BCDDay  = Variable_Set_value.Date_Week[1];
			RtuDataAddr->DD_BianLiang_Shuju[Num].NowDB_Time.BCDMon  = (Variable_Set_value.Date_Week[2]);//|((Variable_Set_value.Date_Week[0]<<5)&0xe0);
			RtuDataAddr->DD_BianLiang_Shuju[Num].NowDB_Time.BCDYear = Variable_Set_value.Date_Week[3];

			memcpy(RtuDataAddr->DD_BianLiang_Shuju[Num].Dian_biao_stat,v2007s.Dian_biao_stat,14);
			//RtuDataAddr->DD_BianLiang_Shuju[Num].Dian_biao_stat=Variable_Set_value.Dian_biao_stat;
			//RtuDataAddr->DD_BianLiang_Shuju[Num].Dian_wang_stat=Variable_Set_value.Dian_wang_stat;
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].LastProg_Time[0],&v2007s.Time_LastProg[0],6);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].LastZero_Time[0],&v2007s.Time_LastZero[0],6);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].ProgNum[0],&v2007s.ProgNum[0],3);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].ZeroNum[0],&v2007s.ZeroNum[0],3);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].BatteryTime[0],&Variable_Set_value.Time_Battery[0],3);

			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].DbQingNum[0],&v2007s.DbQingNum[0],3);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].LastDbQing_Time[0],&v2007s.LastDbQing_Time[0],6);

			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].EventQingNum[0],&v2007s.EventQingNum[0],3);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].LastEventQing_Time[0],&v2007s.LastEventQing_Time[0],6);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].JiaoshiNum[0],&v2007s.JiaoshiNum[0],3);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].LastJiaoshi_Time[0],&v2007s.LastJiaoshi_Time[0],6);
			//memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].Duanxiang_All[0],&Variable_Set_value.Duanxiang_All[0],2);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].A_Duan[0],&Variable_Set_value.A_Duan[0],2);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].B_Duan[0],&Variable_Set_value.B_Duan[0],2);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].C_Duan[0],&Variable_Set_value.C_Duan[0],2);
			//RtuDataAddr->DD_BianLiang_Shuju[Num].Duanxiang_All[0]=RtuDataAddr->DD_BianLiang_Shuju[Num].A_Duan[0]+RtuDataAddr->DD_BianLiang_Shuju[Num].B_Duan[0]+RtuDataAddr->DD_BianLiang_Shuju[Num].C_Duan[0];
			//RtuDataAddr->DD_BianLiang_Shuju[Num].Duanxiang_All[1]=RtuDataAddr->DD_BianLiang_Shuju[Num].A_Duan[1]+RtuDataAddr->DD_BianLiang_Shuju[Num].B_Duan[1]+RtuDataAddr->DD_BianLiang_Shuju[Num].C_Duan[1];
			DuanXiang_All=BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[Num].A_Duan,2)+BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[Num].B_Duan,2)+BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[Num].C_Duan,2);
			//printf("\n\r\n\r\n\r\n\r\n\r DuanXiang_all is %d   A %d   B %d  C %d",DuanXiang_All,BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[Num].A_Duan,2),BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[Num].B_Duan,2),BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[Num].C_Duan,2));
			INT32ToBCD(DuanXiang_All, RtuDataAddr->DD_BianLiang_Shuju[Num].Duanxiang_All, 2);

			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].shiyacishu[0],&Variable_Set_value.shiyacishu[0],3);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].shiya_time[0],&Variable_Set_value.shiya_time[0],3);
			DuanXiang_All=0;
			//memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].Duanxiang_Time[0],&Variable_Set_value.Time_Duanxiang[0],3);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].A_Duan_Time[0],&Variable_Set_value.A_Duan_Time[0],3);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].B_Duan_Time[0],&Variable_Set_value.B_Duan_Time[0],3);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].C_Duan_Time[0],&Variable_Set_value.C_Duan_Time[0],3);
			DuanXiang_All=BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[Num].A_Duan_Time,3)+BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[Num].B_Duan_Time,3)+BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[Num].C_Duan_Time,3);
			//printf("\n\r\n\r\n\r\n\r\n\r DuanXiang_all is %d   A %d   B %d  C %d",DuanXiang_All,BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[Num].A_Duan,2),BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[Num].B_Duan,2),BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[Num].C_Duan,2));
			INT32ToBCD(DuanXiang_All, RtuDataAddr->DD_BianLiang_Shuju[Num].Duanxiang_Time, 3);

			//memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].LastDuan_S_Time[0],&Variable_Set_value.Time_LastDuan_S[0],4);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].ADuan_S_Time[0],&Variable_Set_value.Time_ADuan_S[0],4);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].BDuan_S_Time[0],&Variable_Set_value.Time_BDuan_S[0],4);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].CDuan_S_Time[0],&Variable_Set_value.Time_CDuan_S[0],4);
			//memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].LastDuan_E_Time[0],&Variable_Set_value.Time_LastDuan_E[0],4);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].ADuan_E_Time[0],&Variable_Set_value.Time_ADuan_E[0],4);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].BDuan_E_Time[0],&Variable_Set_value.Time_BDuan_E[0],4);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].CDuan_E_Time[0],&Variable_Set_value.Time_CDuan_E[0],4);
			min=BCDTo_INT32(&RtuDataAddr->DD_BianLiang_Shuju[Num].ADuan_S_Time[0],1);
			hour=BCDTo_INT32(&RtuDataAddr->DD_BianLiang_Shuju[Num].ADuan_S_Time[1],1);
			day=BCDTo_INT32(&RtuDataAddr->DD_BianLiang_Shuju[Num].ADuan_S_Time[2],1);
			month=BCDTo_INT32(&RtuDataAddr->DD_BianLiang_Shuju[Num].ADuan_S_Time[3],1);

			A_Time=changetime(min,hour,day,month);
			min=BCDTo_INT32(&RtuDataAddr->DD_BianLiang_Shuju[Num].BDuan_S_Time[0],1);
			hour=BCDTo_INT32(&RtuDataAddr->DD_BianLiang_Shuju[Num].BDuan_S_Time[1],1);
			day=BCDTo_INT32(&RtuDataAddr->DD_BianLiang_Shuju[Num].BDuan_S_Time[2],1);
			month=BCDTo_INT32(&RtuDataAddr->DD_BianLiang_Shuju[Num].BDuan_S_Time[3],1);
			B_Time=changetime(min,hour,day,month);
			min=BCDTo_INT32(&RtuDataAddr->DD_BianLiang_Shuju[Num].CDuan_S_Time[0],1);
			hour=BCDTo_INT32(&RtuDataAddr->DD_BianLiang_Shuju[Num].CDuan_S_Time[1],1);
			day=BCDTo_INT32(&RtuDataAddr->DD_BianLiang_Shuju[Num].CDuan_S_Time[2],1);
			month=BCDTo_INT32(&RtuDataAddr->DD_BianLiang_Shuju[Num].CDuan_S_Time[3],1);
			C_Time=changetime(min,hour,day,month);
			MAX_TIME=MaxValue(A_Time,B_Time,C_Time);
			if(MAX_TIME==A_Time)
			{
				memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].LastDuan_S_Time[0],&RtuDataAddr->DD_BianLiang_Shuju[Num].ADuan_S_Time[0],4);
				memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].LastDuan_E_Time[0],&RtuDataAddr->DD_BianLiang_Shuju[Num].ADuan_E_Time[0],4);
			}
			if(MAX_TIME==B_Time)
			{
				memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].LastDuan_S_Time[0],&RtuDataAddr->DD_BianLiang_Shuju[Num].BDuan_S_Time[0],4);
				memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].LastDuan_E_Time[0],&RtuDataAddr->DD_BianLiang_Shuju[Num].BDuan_E_Time[0],4);
			}
			if(MAX_TIME==C_Time)
			{
				memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].LastDuan_S_Time[0],&RtuDataAddr->DD_BianLiang_Shuju[Num].CDuan_S_Time[0],4);
				memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].LastDuan_E_Time[0],&RtuDataAddr->DD_BianLiang_Shuju[Num].CDuan_E_Time[0],4);
			}

			//////////////////////yyx add 2004 4 6
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].PChangShu[0],&Variable_Set_value.Dian_biao_changshu_P[0],3);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].QChangShu[0],&Variable_Set_value.Dian_biao_changshu_Q[0],3);

			memcpy(RtuDataAddr->DD_BianLiang_Shuju[Num].Tingdian,Variable_Set_value.TingDianNum,3);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].U_Unbalance  ,&Variable_Set_value.U_Unbalance,9);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].I_Unbalance  ,&Variable_Set_value.I_Unbalance,9);

			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].Chao_biao_riqi[0],&Variable_Set_value.Chao_biao_riqi[0],2);
			RtuDataAddr->DD_BianLiang_Shuju[Num].Year_ShiQu=Variable_Set_value.Year_ShiQu;
			RtuDataAddr->DD_BianLiang_Shuju[Num].Day_ShiDuanBiao=Variable_Set_value.Day_ShiDuanBiao;
			RtuDataAddr->DD_BianLiang_Shuju[Num].Now_ShiDuan=Variable_Set_value.Now_ShiDuan;
			RtuDataAddr->DD_BianLiang_Shuju[Num].FeiLvShu=Variable_Set_value.FeiLvShu;
			RtuDataAddr->DD_BianLiang_Shuju[Num].GongGongJiari=Variable_Set_value.GongGongJiari;
			RtuDataAddr->DD_BianLiang_Shuju[Num].Now_ShiDuan=Variable_Set_value.Now_ShiDuan;
			memcpy(RtuDataAddr->DD_BianLiang_Shuju[Num].TimePronum,Variable_Set_value.TimePronum,3);

			RtuDataAddr->DD_BianLiang_Shuju[Num].Valid=1;
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Valid=1;

			ERRCreate=0;
			for(i=0;i<7;i++)
			{
				for(j=0;j<2;j++)
				{
					tmpchg[i*2+j] = v2007s.Dian_biao_stat[i][j] ^ v2007s.Dian_biao_stat_old[i][j];
					RtuDataAddr->DD_BianLiang_Shuju[Num].Dian_biao_stat[i][j] = v2007s.Dian_biao_stat[i][j];
					RtuDataAddr->DD_BianLiang_Shuju[Num].Dianbiaostat_Flag[i][j] = tmpchg[i*2+j] ;
					//printf("\n\v2007s.Dian_biao_stat[%d][%d]  %d Dian_biao_stat_old[%d][%d] ===%d",i,j,v2007s.Dian_biao_stat[i][j],i,j,v2007s.Dian_biao_stat_old[i][j]);
					if (tmpchg[i*2+j])
					{
						ERRCreate=1;
						break;
					}
				}
			}
			if(ERRCreate)
			{
				memcpy(tmpstat,v2007s.Dian_biao_stat,14);
				pro_ERR33(Num,tmpchg,tmpstat);
				//memcpy(RtuDataAddr->CL_ERR[Num].c410,v2007s.Dian_biao_stat,14);
				memcpy(v2007s.Dian_biao_stat_old,v2007s.Dian_biao_stat,14);
			}
		}
	}
	return;
}

void Dlt645_2007GetData(unsigned char i)
{
	TS ts;
	Dlt645Dbg("\r\nDlt645_2007GetData11\r\n");
	Dlt645Dbg("\r\n");
	Get2007Demand_N_Set_Value(i);
	Get2007Maximum_Demand_NT_Set_Value(i);
	Get2007Variable_Set_value(i);

	//if(read485ERR[i]>=20)//ĳ����ܱ������������г���
	Dlt645Dbg("\n\r err count %d",read485ERR[i]);
	Dlt645Dbg("\n\r");
	if((read485ERR[i]>=10))//&&(read485ERR[i]<=40))//ĳ����ܱ������������г���
	{
		GetValueErr=GetValueErr|(1<<i);//iλ��1����ʶ�ñ�ͨ���ж�
		Dlt645Dbg("\r\n%s%d%s\r\n","�ɼ�",i,"�ű�����");
		Pro_ERC31(i);
	}
	else//�޴�
	{
		GetValueErr=GetValueErr&((1<<i)^0xffff);//iλ��0
		Dlt645Dbg("\r\n%s%d%s\r\n","�ɼ�",i,"�ű����");
		TSGet(&ts);
		RtuDataAddr->Event_Save.Event.Err31.Last_OK[0]=((ts.Minute/10)<<4)+(ts.Minute%10);
		RtuDataAddr->Event_Save.Event.Err31.Last_OK[1]=((ts.Hour/10)<<4)+(ts.Hour%10);
		RtuDataAddr->Event_Save.Event.Err31.Last_OK[2]=((ts.Day/10)<<4)+(ts.Day%10);
		RtuDataAddr->Event_Save.Event.Err31.Last_OK[3]=((ts.Month/10)<<4)+(ts.Month%10);
		RtuDataAddr->Event_Save.Event.Err31.Last_OK[4]=(((ts.Year%100)/10)<<4)+(ts.Year%10);
		memcpy(RtuDataAddr->Event_Save.Event.Err31.Last_Value_P,Demand_N_Set_Value.N_Z_P_All,4);
		memcpy(RtuDataAddr->Event_Save.Event.Err31.Last_Value_Q,Demand_N_Set_Value.N_Z_Q_All,4);
		DLT645_2007_Data_Calc(i);
		if(RtuDataAddr->CL_ERR[i].first==1)
		{
			//printf("\r\n i=====%d",i);
			//printf("\n\rRtuDataAddr->CL_ERR[i].OldDuanXiangNum===%d",RtuDataAddr->CL_ERR[i].OldDuanXiangNum);
			RtuDataAddr->CL_ERR[i].OldDuanXiangNum=BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[i].Duanxiang_All,2);
			RtuDataAddr->CL_ERR[i].OldShiYaCishu=BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[i].shiyacishu,3);
			RtuDataAddr->CL_ERR[i].OldTingDianNum = BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[i].Tingdian,3);
			RtuDataAddr->CL_ERR[i].OldProgNum=BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[i].ProgNum,2);
			RtuDataAddr->CL_ERR[i].OldMacPZero=BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[i].ZeroNum,2);
			RtuDataAddr->CL_ERR[i].Old_PDD=RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_All;
			RtuDataAddr->CL_ERR[i].TimePronumOld = BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[i].TimePronum,3);
		}
		ProREC(i);//�¼�
		RtuDataAddr->CL_ERR[i].first = 0;
	}
	return;
}
