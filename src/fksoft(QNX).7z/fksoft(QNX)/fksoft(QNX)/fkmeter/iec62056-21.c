#include "iec62056-21.h"
#include "fkmeter.h"

unsigned char jiexianfangshi_flag=0;//�������������Ϊ�������ߣ���Ϊ0�� ���������߷�ʽΪ�������ߣ���Ϊ1��

extern int user_init_io(INT16U baud,INT8U *par,INT8U stopb,INT8U bits );

void Pprintf(unsigned char *p, unsigned short len)
{//��ӡ����������Ϣ��pΪ������ָ�룬lenΪ��ӡ�ĳ���
	unsigned short i;

	for(i=0; i<len; i++)
	{
		printf("%x ",p[i]);
	}
	printf("\r\n");
}
void SPprintf(unsigned char (*p)[35])
{
	unsigned short i,k;

	for(i=0; i<266; i++)
	{
		for(k=0; k<35; k++)
		{
			printf("%x ",p[i][k]);
		}
		printf("\r\n");
	}
}
void BCDToASC(unsigned char * BCD, int Len, unsigned char *Ret)
{
	unsigned char *BCDtmp = (unsigned char *) malloc(Len * sizeof(unsigned char)+1);
	memcpy(BCDtmp, BCD, Len);
	int i, j, k;
	if (BCDtmp != NULL) {
		i = 0;
		while (BCDtmp[i] != '\0') {
			i++;
		};
		//i--;
		i = Len;
		memset(Ret, 0, Len);
		for (j = 0, k = 0; j < i; j++) {
			if (BCDtmp != NULL) {
				unsigned char A = BCDtmp[j] >> 4;
				unsigned char B = BCDtmp[j] & 0x0F;
				if (A < 10)
					*(Ret + k) = A + '0';
				else
					*(Ret + k) = A + '7';
				if (B < 10)
					*(Ret + k + 1) = B + '0';
				else
					*(Ret + k + 1) = B + '7';
				k++;
				k++;
			}
		}
		*(Ret + i * 2) = '\0';
	}
	free(BCDtmp);
}
int ASCToBCD(unsigned char * ASC, int Len, unsigned char *Ret) {
	int i, j, k;
	if (ASC != NULL) {
		for (i = 0; i < Len; i++) {
			if (ASC[i] <= '9')
				ASC[i] = ASC[i] - '0';
			else
				ASC[i] = ASC[i] - '7';
		}
		if (Len % 2 == 0) {
			//unsigned char *Ret=new char[Len/2+1];
			memset(Ret, 0, Len / 2 + 1);
			for (j = 0, k = 0; j < Len / 2; j++) {
				*(Ret + j) = (ASC[k] << 4) | ASC[k + 1];
				k++;
				k++;
			}
			//return Ret;
		}

	}
	return 0;
}
char xor_check(const char *p)
{
	char check = 0;
	p++;
	while(*p != ETX)
	{
		check ^= *p;
		p++;
	}
	check ^= ETX;
	return check;
}
void iec_data(const char *s,char *o)
{
	unsigned char i;
	for(i = 0;i < 4;i++)
		*(o + i) = ((*(s + 2 * i) - 0x30) << 4) + (*(s + 2 * i + 1) - 0x30);
}
void iec_data_two(const char *s,char *o)
{
	unsigned char i;
	for(i = 0;i < 2;i++)
		*(1+ o - i) = ((*(s + 2 * i) - 0x30) << 4) + (*(s + 2 * i + 1) - 0x30);
}
void iec_data_three(const char *s,char *o)
{
	unsigned char i;
	for(i = 0;i < 3;i++)
		*(2+ o - i) = ((*(s + 2 * i) - 0x30) << 4) + (*(s + 2 * i + 1) - 0x30);
}
void iec_data_three_lf(const char *s,char *o)
{
	unsigned char i;
	for(i = 0;i < 3;i++)
		*(o + i) = ((*(s + 2 * i) - 0x30) << 4) + (*(s + 2 * i + 1) - 0x30);
}
/*static char iec_data_time(  char *s, int *o)
{
	unsigned char i;
	*o = 0;
	for(i = 0;i < 4;i++)
	{	if(s[i * 2] > '9')
			s[i * 2] -= 0x07;
		if(s[i * 2 + 1] > '9')
			s[i * 2 + 1] -= 0x07;
	(*o) += (( (((s[i * 2] - 0x30)  & 0x0f) << 4) + ((s[i * 2 + 1] - 0x30) & 0x0f)) << (i * 8)) ;
	}
	return 1;
}*/
void iec_req(char *s,char *r,char *code)
{
	char *p = s;

	*s++ = SOH;
	*s++ = 'W';
	*s++ = '1';
	*s++ = STX;
	*s++ = '6';
	*s++ = '0';
	*s++ = '5';
	*s++ = '0';
	*s++ = '0';
	*s++ = '1';
	*s++ = '(';
	*s++ = *code++;
	*s++ = *code++;
	*s++ = *code++;
	*s++ = *code++;
	*s++ = *code++;
	*s++ = *code++;
	*s++ = *code++;
	*s++ = *code++;
	*s++ = ')';
	*s++ = ETX;
	*s++ = xor_check(p);

	SendStrTo485((INT8U *)p ,22);
	delay(300);
	delay(2000);
	ReceiveFrom485((INT8U *)r);
}
void iec_send(char *s,char *r,char *code,char *len)
{	printf("000000000000000000000\r\n");
	char *p = s;
	*s++ = SOH;
	*s++ = 'R';
	*s++ = '1';
	*s++ = STX;
	*s++ = *code++;
	*s++ = *code++;
	*s++ = *code++;
	*s++ = *code++;
	*s++ = *code++;
	*s++ = *code++;
	*s++ = '(';
	*s++ = *len++;
	*s++ = *len++;
	*s++ = ')';
	*s++ = ETX;
	*s++ = xor_check(p);
	SendStrTo485((INT8U *)p ,16);
	Pprintf((INT8U *)p,16);

	user_init_io(9600,(INT8U *)"even",1,7 );
	*len = ReceiveFrom485((INT8U *)r);
	close( ComPort );
	printf("\r\nReceive_ZongDianLiang_Frame len==%d:",len);
	Pprintf((INT8U *)r,*len);
}
char iec_sta(char *s)
{
	char num =0;
	iec_req((char *)Trn645Buff,(char *)Rec645Buff,s);
	if(Rec645Buff[0] == ACK)
	{
dianliu:
		iec_send((char *)Trn645Buff,(char *)Rec645Buff,"605001","04");
		if((Rec645Buff[0] == STX) && (Rec645Buff[1] == '('))
		{
			if((Rec645Buff[8] - 0x30) & 0x08)
			{
				return 1;
			}
			else
			{
				delay(2000);
				if(num++ < 4)
					goto dianliu;
				else
					return 0;
			}
		}
	}
	return 0;
}


void getMeterData1()
{
	iec_send((char *)Trn645Buff,(char *)Rec645Buff,"507001","40");
	if((Rec645Buff[0] == STX) && (Rec645Buff[1] == '('))
	{
		iec_data((char *)&Rec645Buff[6],(char *)Demand_N_Set_Value.N_Z_P_All);  //�����й�
		iec_data((char *)&Rec645Buff[22],(char *)Demand_N_Set_Value.N_F_P_All); //�����й�
		iec_data((char *)&Rec645Buff[38],(char *)Demand_N_Set_Value.N_X1_Q_All);//һ�����޹��ܵ���
		iec_data((char *)&Rec645Buff[54],(char *)Demand_N_Set_Value.N_X2_Q_All);//�������޹��ܵ���
		iec_data((char *)&Rec645Buff[70],(char *)Demand_N_Set_Value.N_X3_Q_All);//�������޹��ܵ���
		iec_data((char *)&Rec645Buff[86],(char *)Demand_N_Set_Value.N_X4_Q_All);//�������޹��ܵ���
		//iec_data(&Rec645Buff[118],p + 194);//�����޹�����
	}
	else
	{
		memset(Demand_N_Set_Value.N_Z_P_All,0xff,4);
		memset(Demand_N_Set_Value.N_F_P_All,0xff,4);
		memset(Demand_N_Set_Value.N_X1_Q_All,0xff,4);
		memset(Demand_N_Set_Value.N_X2_Q_All,0xff,4);
		memset(Demand_N_Set_Value.N_X3_Q_All,0xff,4);
		memset(Demand_N_Set_Value.N_X4_Q_All,0xff,4);
	}
}
void getMeterData2()
{
	iec_send((char *)Trn645Buff,(char *)Rec645Buff,"508001","40");//
	if((Rec645Buff[0] == STX) && (Rec645Buff[1] == '('))
	{
		iec_data((char *)&Rec645Buff[6],(char *)Demand_N_Set_Value.N_Z_P_F[0]);   //�����й���
		iec_data((char *)&Rec645Buff[22],(char *)Demand_N_Set_Value.N_Z_P_F[1]);  //�����й�ƽ
		iec_data((char *)&Rec645Buff[38],(char *)Demand_N_Set_Value.N_Z_P_F[2]);  //�����й���
		iec_data((char *)&Rec645Buff[54],(char *)Demand_N_Set_Value.N_F_P_F[0]);  //�����й���
		iec_data((char *)&Rec645Buff[70],(char *)Demand_N_Set_Value.N_F_P_F[1]);  //�����й�ƽ
		iec_data((char *)&Rec645Buff[86],(char *)Demand_N_Set_Value.N_F_P_F[2]);  //�����й���
		iec_data((char *)&Rec645Buff[102],(char *)Demand_N_Set_Value.N_Z_P_F[3]); //�����й���
		iec_data((char *)&Rec645Buff[118],(char *)Demand_N_Set_Value.N_F_P_F[3]); //�����й���
	}
	else
	{
		memset(Demand_N_Set_Value.N_Z_P_F[0],0xff,4);
		memset(Demand_N_Set_Value.N_Z_P_F[1],0xff,4);
		memset(Demand_N_Set_Value.N_Z_P_F[2],0xff,4);
		memset(Demand_N_Set_Value.N_Z_P_F[3],0xff,4);
		memset(Demand_N_Set_Value.N_F_P_F[0],0xff,4);
		memset(Demand_N_Set_Value.N_F_P_F[1],0xff,4);
		memset(Demand_N_Set_Value.N_F_P_F[2],0xff,4);
		memset(Demand_N_Set_Value.N_F_P_F[3],0xff,4);
	}
}
void getMeterData3()
{
	char linshi;
	if(iec_sta("1B2B4B00"))
	{
		iec_send((char *)Trn645Buff,(char *)Rec645Buff,"606001","1C");
		if((Rec645Buff[0] == STX) && (Rec645Buff[1] == '('))
		{
			linshi = ((Rec645Buff[3] - 0x30) & 0x07);
			iec_data_two((char *)&Rec645Buff[8 + linshi],(char *)Variable_Set_value.VA);  //��ѹA
			iec_data_two((char *)&Rec645Buff[22 + linshi],(char *)Variable_Set_value.VB); //��ѹB
			iec_data_two((char *)&Rec645Buff[36 + linshi],(char *)Variable_Set_value.VC); //��ѹC
		}
		else
		{
			memset(Variable_Set_value.VA,0xff,2);
			memset(Variable_Set_value.VB,0xff,2);
			memset(Variable_Set_value.VC,0xff,2);
		}
	}
	else
	{
			memset(Variable_Set_value.VA,0xff,2);
			memset(Variable_Set_value.VB,0xff,2);
			memset(Variable_Set_value.VC,0xff,2);
	}
}
void getMeterData4()
{
	char linshi;
	if(iec_sta("1A2A4A00"))
	{
		iec_send((char *)Trn645Buff,(char *)Rec645Buff,"606001","1C");
		if((Rec645Buff[0] == STX) && (Rec645Buff[1] == '('))
		{
			linshi = ((Rec645Buff[3] - 0x30) & 0x07);
			iec_data_two((char *)&Rec645Buff[10 + linshi],(char *)Variable_Set_value.IA);  //����A
			iec_data_two((char *)&Rec645Buff[24 + linshi],(char *)Variable_Set_value.IB);  //����B
			iec_data_two((char *)&Rec645Buff[38 + linshi],(char *)Variable_Set_value.IC);  //����C
		}
		else
		{
			memset(Variable_Set_value.IA,0xff,2);
			memset(Variable_Set_value.IB,0xff,2);
			memset(Variable_Set_value.IC,0xff,2);
		}
	}
	else
	{
		memset(Variable_Set_value.IA,0xff,2);
		memset(Variable_Set_value.IB,0xff,2);
		memset(Variable_Set_value.IC,0xff,2);
	}
}
void getMeterData5()
{
	char linshi;
	if(iec_sta("1C2C4C0C"))
	{
		iec_send((char *)Trn645Buff,(char *)Rec645Buff,"606001","1C");
		if((Rec645Buff[0] == STX) && (Rec645Buff[1] == '('))
		{
			linshi = ((Rec645Buff[3] - 0x30) & 0x07);
			iec_data_three((char *)&Rec645Buff[10 + linshi],(char *)Variable_Set_value.PA);  //A���й�����
			iec_data_three((char *)&Rec645Buff[24 + linshi],(char *)Variable_Set_value.PB);  //B���й�����
			iec_data_three((char *)&Rec645Buff[38 + linshi],(char *)Variable_Set_value.PC);  //C���й�����
			iec_data_three((char *)&Rec645Buff[52 + linshi],(char *)Variable_Set_value.P);   //˲ʱ�й�����
		 }
		 else
		 {
			memset(Variable_Set_value.PA,0xff,3);
			memset(Variable_Set_value.PB,0xff,3);
			memset(Variable_Set_value.PC,0xff,3);
			memset(Variable_Set_value.P,0xff,3);
		 }
	}
	else
	{
		memset(Variable_Set_value.PA,0xff,3);
		memset(Variable_Set_value.PB,0xff,3);
		memset(Variable_Set_value.PC,0xff,3);
		memset(Variable_Set_value.P,0xff,3);
	}
}
void getMeterData6()
{
	char linshi;
	if(iec_sta("1D2D4D0D"))
	{
		iec_send((char *)Trn645Buff,(char *)Rec645Buff,"606001","1C");
		if((Rec645Buff[0] == STX) && (Rec645Buff[1] == '('))
		{
			linshi = ((Rec645Buff[3] - 0x30) & 0x07);
			iec_data_two((char *)&Rec645Buff[10 + linshi],(char *)Variable_Set_value.QA);  //A���޹�����
			iec_data_two((char *)&Rec645Buff[24 + linshi],(char *)Variable_Set_value.QB);  //B���޹�����
			iec_data_two((char *)&Rec645Buff[38 + linshi],(char *)Variable_Set_value.QC);  //C���޹�����
			iec_data_two((char *)&Rec645Buff[52 + linshi],(char *)Variable_Set_value.Q);   //˲ʱ�޹�����
		}
		else
		{
			memset(Variable_Set_value.QA,0xff,2);
			memset(Variable_Set_value.QB,0xff,2);
			memset(Variable_Set_value.QC,0xff,2);
			memset(Variable_Set_value.Q,0xff,2);
		}
	}
	else
	{
		memset(Variable_Set_value.QA,0xff,2);
		memset(Variable_Set_value.QB,0xff,2);
		memset(Variable_Set_value.QC,0xff,2);
		memset(Variable_Set_value.Q,0xff,2);
	}
}
void getMeterData7()
{
	if(iec_sta("13234303"))
	{
		iec_send((char *)Trn645Buff,(char *)Rec645Buff,"606001","1C");
		if((Rec645Buff[0] == STX) && (Rec645Buff[1] == '('))
		{
			iec_data_two((char *)&Rec645Buff[11 ],(char *)Variable_Set_value.CosA);  //A�๦������
			iec_data_two((char *)&Rec645Buff[25 ],(char *)Variable_Set_value.CosB);  //B�๦������
			iec_data_two((char *)&Rec645Buff[39 ],(char *)Variable_Set_value.CosC);  //C�๦������
			iec_data_two((char *)&Rec645Buff[53 ],(char *)Variable_Set_value.Cos);   //�ܹ�������
		}
		else
		{
			memset(Variable_Set_value.CosA,0xff,2);
			memset(Variable_Set_value.CosB,0xff,2);
			memset(Variable_Set_value.CosC,0xff,2);
			memset(Variable_Set_value.Cos,0xff,2);
		}
	}
	else
	{
		memset(Variable_Set_value.CosA,0xff,2);
		memset(Variable_Set_value.CosB,0xff,2);
		memset(Variable_Set_value.CosC,0xff,2);
		memset(Variable_Set_value.Cos,0xff,2);
	}
}
void IECExit()
{
	//<SOH>B0<ETX>q
	Trn645Buff[0] = SOH;
	Trn645Buff[1] = 'B';
	Trn645Buff[2] = '0';
	Trn645Buff[3] = ETX;
	Trn645Buff[4] = xor_check((char *)Trn645Buff);
	SendStrTo485(Trn645Buff ,5);
	delay(300);
	delay(1000);
	ReceiveFrom485(Rec645Buff);
}
void iec_Data_Calc(unsigned char DDNo)
{
	unsigned char Num;
//	unsigned char tmp;

	if(RtuDataAddr->Meter_Para.Valid!=1)
		return;
	if(RtuDataAddr->Meter_Para.Metet_jiaoliu_Num>CeLiangPoint_Max)
		return;
	if(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].GuiYue_Type==1)
	{
		Num=RtuDataAddr->Meter_Para.Dian_Meter[DDNo].CeLiangNo-1;
		if(Num>CeLiangPoint_Max)
			return;

		if(Demand_N_Set_Value.valid==1)
		{
			//memcpy(&RtuDataAddr->DD_Device_BiaoShi_Value[Num].Chao_Time.BCD01,&Demand_N_Set_Value.Time_Chaobiao.BCD01,5);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_All=BCDTo_INT32(Demand_N_Set_Value.N_Z_P_All,4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_F[0]=BCDTo_INT32(Demand_N_Set_Value.N_Z_P_F[0],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_F[1]=BCDTo_INT32(Demand_N_Set_Value.N_Z_P_F[1],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_F[2]=BCDTo_INT32(Demand_N_Set_Value.N_Z_P_F[2],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_F[3]=BCDTo_INT32(Demand_N_Set_Value.N_Z_P_F[3],4);

			RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_All=BCDTo_INT32(Demand_N_Set_Value.N_F_P_All,4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_F[0]=BCDTo_INT32(Demand_N_Set_Value.N_F_P_F[0],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_F[1]=BCDTo_INT32(Demand_N_Set_Value.N_F_P_F[1],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_F[2]=BCDTo_INT32(Demand_N_Set_Value.N_F_P_F[2],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_F[3]=BCDTo_INT32(Demand_N_Set_Value.N_F_P_F[3],4);

			/*RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_All=BCDTo_INT32(Demand_N_Set_Value.N_Z_Q_All,4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_F[0]=BCDTo_INT32(Demand_N_Set_Value.N_Z_Q_F[0],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_F[1]=BCDTo_INT32(Demand_N_Set_Value.N_Z_Q_F[1],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_F[2]=BCDTo_INT32(Demand_N_Set_Value.N_Z_Q_F[2],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_F[3]=BCDTo_INT32(Demand_N_Set_Value.N_Z_Q_F[3],4);
			*/
			/*RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_All=BCDTo_INT32(Demand_N_Set_Value.N_F_Q_All,4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_F[0]=BCDTo_INT32(Demand_N_Set_Value.N_F_Q_F[0],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_F[1]=BCDTo_INT32(Demand_N_Set_Value.N_F_Q_F[1],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_F[2]=BCDTo_INT32(Demand_N_Set_Value.N_F_Q_F[2],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_F[3]=BCDTo_INT32(Demand_N_Set_Value.N_F_Q_F[3],4);
			*/
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X1_Q_All=BCDTo_INT32(Demand_N_Set_Value.N_X1_Q_All,4);
			/*RtuDataAddr->DD_Device_BiaoShi_Value[Num].X1_F_Q[0]=BCDTo_INT32(Demand_N_Set_Value.N_X1_Q_F[0],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X1_F_Q[1]=BCDTo_INT32(Demand_N_Set_Value.N_X1_Q_F[1],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X1_F_Q[2]=BCDTo_INT32(Demand_N_Set_Value.N_X1_Q_F[2],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X1_F_Q[3]=BCDTo_INT32(Demand_N_Set_Value.N_X1_Q_F[3],4);
			*/
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X4_Q_All=BCDTo_INT32(Demand_N_Set_Value.N_X4_Q_All,4);
			/*RtuDataAddr->DD_Device_BiaoShi_Value[Num].X4_F_Q[0]=BCDTo_INT32(Demand_N_Set_Value.N_X4_Q_F[0],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X4_F_Q[1]=BCDTo_INT32(Demand_N_Set_Value.N_X4_Q_F[1],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X4_F_Q[2]=BCDTo_INT32(Demand_N_Set_Value.N_X4_Q_F[2],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X4_F_Q[3]=BCDTo_INT32(Demand_N_Set_Value.N_X4_Q_F[3],4);
			*/
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X2_Q_All=BCDTo_INT32(Demand_N_Set_Value.N_X2_Q_All,4);
			/*RtuDataAddr->DD_Device_BiaoShi_Value[Num].X2_F_Q[0]=BCDTo_INT32(Demand_N_Set_Value.N_X2_Q_F[0],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X2_F_Q[1]=BCDTo_INT32(Demand_N_Set_Value.N_X2_Q_F[1],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X2_F_Q[2]=BCDTo_INT32(Demand_N_Set_Value.N_X2_Q_F[2],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X2_F_Q[3]=BCDTo_INT32(Demand_N_Set_Value.N_X2_Q_F[3],4);
			*/
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X3_Q_All=BCDTo_INT32(Demand_N_Set_Value.N_X4_Q_All,4);
			/*RtuDataAddr->DD_Device_BiaoShi_Value[Num].X3_F_Q[0]=BCDTo_INT32(Demand_N_Set_Value.N_X3_Q_F[0],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X3_F_Q[1]=BCDTo_INT32(Demand_N_Set_Value.N_X3_Q_F[1],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X3_F_Q[2]=BCDTo_INT32(Demand_N_Set_Value.N_X3_Q_F[2],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X3_F_Q[3]=BCDTo_INT32(Demand_N_Set_Value.N_X3_Q_F[3],4);
			*/
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Valid=1;
		}
		if(Maximum_Demand_N_Set_Value.valid==1)
		{
			/*memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Chao_Time.BCD01,&Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD01,5);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_P_X_All=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_Z_P_X_All,3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_P_X_F[0]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_Z_P_X_F[0],3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_P_X_F[1]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_Z_P_X_F[1],3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_P_X_F[2]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_Z_P_X_F[2],3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_P_X_F[3]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_Z_P_X_F[3],3);

			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_P_X_All=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_F_P_X_All,3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_P_X_F[0]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_F_P_X_F[0],3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_P_X_F[1]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_F_P_X_F[1],3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_P_X_F[2]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_F_P_X_F[2],3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_P_X_F[3]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_F_P_X_F[3],3);

			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_Q_X_All=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_Z_Q_X_All,3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_Q_X_F[0]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_Z_Q_X_F[0],3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_Q_X_F[1]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_Z_Q_X_F[1],3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_Q_X_F[2]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_Z_Q_X_F[2],3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_Q_X_F[3]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_Z_Q_X_F[3],3);

			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_Q_X_All=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_F_Q_X_All,3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_Q_X_F[0]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_F_Q_X_F[0],3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_Q_X_F[1]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_F_Q_X_F[1],3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_Q_X_F[2]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_F_Q_X_F[2],3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_Q_X_F[3]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_F_Q_X_F[3],3);

			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Valid=1;
			*/
		}

		if(Maximum_Demand_Time_N_Set_Value.valid==1)
		{
			/*memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Chao_Time.BCD01,&Maximum_Demand_Time_N_Set_Value.Time_Chaobiao.BCD01,5);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_P_X_All[0],&Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_All[0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_P_X_F[0][0],&Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_F[0][0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_P_X_F[1][0],&Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_F[1][0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_P_X_F[2][0],&Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_F[2][0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_P_X_F[3][0],&Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_F[3][0],4);

			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_P_X_All[0],&Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_All[0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_P_X_F[0][0],&Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_F[0][0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_P_X_F[1][0],&Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_F[1][0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_P_X_F[2][0],&Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_F[2][0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_P_X_F[3][0],&Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_F[3][0],4);

			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_Q_X_All[0],&Maximum_Demand_Time_N_Set_Value.Time_N_Z_Q_X_All[0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_Q_X_F[0][0],&Maximum_Demand_Time_N_Set_Value.Time_N_Z_Q_X_F[0][0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_Q_X_F[1][0],&Maximum_Demand_Time_N_Set_Value.Time_N_Z_Q_X_F[1][0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_Q_X_F[2][0],&Maximum_Demand_Time_N_Set_Value.Time_N_Z_Q_X_F[2][0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_Q_X_F[3][0],&Maximum_Demand_Time_N_Set_Value.Time_N_Z_Q_X_F[3][0],4);

			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_Q_X_All[0],&Maximum_Demand_Time_N_Set_Value.Time_N_F_Q_X_All[0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_Q_X_F[0][0],&Maximum_Demand_Time_N_Set_Value.Time_N_F_Q_X_F[0][0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_Q_X_F[1][0],&Maximum_Demand_Time_N_Set_Value.Time_N_F_Q_X_F[1][0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_Q_X_F[2][0],&Maximum_Demand_Time_N_Set_Value.Time_N_F_Q_X_F[2][0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_Q_X_F[3][0],&Maximum_Demand_Time_N_Set_Value.Time_N_F_Q_X_F[3][0],4);
			*/
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].UAJ=0;
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].UBJ=1200;
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].UCJ=2400;
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].IAJ=0;
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].IBJ=1200;
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].ICJ=2400;

			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Valid=1;
		}
		if(Variable_Set_value.valid==1)
		{
			//memcpy(&RtuDataAddr->DD_Device_BiaoShi_Value[Num].Chao_Time.BCD01,&Variable_Set_value.Time_Chaobiao.BCD01,5);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Cos=BCDTo_INT32(Variable_Set_value.Cos,2);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].CosA=BCDTo_INT32(Variable_Set_value.CosA,2);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].CosB=BCDTo_INT32(Variable_Set_value.CosB,2);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].CosC=BCDTo_INT32(Variable_Set_value.CosC,2);

			RtuDataAddr->DD_Device_BiaoShi_Value[Num].IA=BCDTo_INT32(Variable_Set_value.IA,2);//0.01A
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].IB=BCDTo_INT32(Variable_Set_value.IB,2);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].IC=BCDTo_INT32(Variable_Set_value.IC,2);

			RtuDataAddr->DD_Device_BiaoShi_Value[Num].VA=BCDTo_INT32(Variable_Set_value.VA,2)*10;//0.1V
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].VB=BCDTo_INT32(Variable_Set_value.VB,2)*10;
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].VC=BCDTo_INT32(Variable_Set_value.VC,2)*10;

			RtuDataAddr->DD_Device_BiaoShi_Value[Num].P=BCDTo_INT32(Variable_Set_value.P,3);//��λС��
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].PA=BCDTo_INT32(Variable_Set_value.PA,3);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].PB=BCDTo_INT32(Variable_Set_value.PB,3);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].PC=BCDTo_INT32(Variable_Set_value.PC,3);

			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Q=BCDTo_INT32(Variable_Set_value.Q,2)*100;
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].QA=BCDTo_INT32(Variable_Set_value.QA,2)*100;
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].QB=BCDTo_INT32(Variable_Set_value.QB,2)*100;
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].QC=BCDTo_INT32(Variable_Set_value.QC,2)*100;

			//memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].Chao_Time.BCD01,&Variable_Set_value.Time_Chaobiao.BCD01,5);
			//-------------------------------------------->
			//memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].Date_Week[0],&Variable_Set_value.Date_Week[0],4);
			//memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].Now_Time[0],&Variable_Set_value.Now_Time[0],3);
			//--------------------------------------------<
			//tmp=Variable_Set_value.Date_Week[0];
			//date transform
			/*RtuDataAddr->DD_BianLiang_Shuju[Num].NowDB_Time.BCDSec  = Variable_Set_value.Now_Time[0];
			RtuDataAddr->DD_BianLiang_Shuju[Num].NowDB_Time.BCDMin  = Variable_Set_value.Now_Time[1];
			RtuDataAddr->DD_BianLiang_Shuju[Num].NowDB_Time.BCDHour = Variable_Set_value.Now_Time[2];
			RtuDataAddr->DD_BianLiang_Shuju[Num].NowDB_Time.BCDDay  = Variable_Set_value.Date_Week[1];
			RtuDataAddr->DD_BianLiang_Shuju[Num].NowDB_Time.BCDMon  = (Variable_Set_value.Date_Week[2]);//|((Variable_Set_value.Date_Week[0]<<5)&0xe0);
			RtuDataAddr->DD_BianLiang_Shuju[Num].NowDB_Time.BCDYear = Variable_Set_value.Date_Week[3];

			RtuDataAddr->DD_BianLiang_Shuju[Num].Dian_biao_stat=Variable_Set_value.Dian_biao_stat;
			RtuDataAddr->DD_BianLiang_Shuju[Num].Dian_wang_stat=Variable_Set_value.Dian_wang_stat;
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].LastProg_Time[0],&Variable_Set_value.Time_LastProg[0],4);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].LastZero_Time[0],&Variable_Set_value.Time_LastZero[0],4);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].ProgNum[0],&Variable_Set_value.ProgNum[0],2);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].ZeroNum[0],&Variable_Set_value.ZeroNum[0],2);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].BatteryTime[0],&Variable_Set_value.Time_Battery[0],3);


			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].Duanxiang_All[0],&Variable_Set_value.Duanxiang_All[0],2);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].A_Duan[0],&Variable_Set_value.A_Duan[0],2);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].B_Duan[0],&Variable_Set_value.B_Duan[0],2);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].C_Duan[0],&Variable_Set_value.C_Duan[0],2);

			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].Duanxiang_Time[0],&Variable_Set_value.Time_Duanxiang[0],3);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].A_Duan_Time[0],&Variable_Set_value.A_Duan_Time[0],3);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].B_Duan_Time[0],&Variable_Set_value.B_Duan_Time[0],3);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].C_Duan_Time[0],&Variable_Set_value.C_Duan_Time[0],3);

			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].LastDuan_S_Time[0],&Variable_Set_value.Time_LastDuan_S[0],4);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].ADuan_S_Time[0],&Variable_Set_value.Time_ADuan_S[0],4);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].BDuan_S_Time[0],&Variable_Set_value.Time_BDuan_S[0],4);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].CDuan_S_Time[0],&Variable_Set_value.Time_CDuan_S[0],4);

			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].LastDuan_E_Time[0],&Variable_Set_value.Time_LastDuan_E[0],4);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].ADuan_E_Time[0],&Variable_Set_value.Time_ADuan_E[0],4);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].BDuan_E_Time[0],&Variable_Set_value.Time_BDuan_E[0],4);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].CDuan_E_Time[0],&Variable_Set_value.Time_CDuan_E[0],4);

			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].PChangShu[0],&Variable_Set_value.Dian_biao_changshu_P[0],3);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].QChangShu[0],&Variable_Set_value.Dian_biao_changshu_Q[0],3);

			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].Chao_biao_riqi[0],&Variable_Set_value.Chao_biao_riqi[0],2);
			RtuDataAddr->DD_BianLiang_Shuju[Num].Year_ShiQu=Variable_Set_value.Year_ShiQu;
			RtuDataAddr->DD_BianLiang_Shuju[Num].Day_ShiDuanBiao=Variable_Set_value.Day_ShiDuanBiao;
			RtuDataAddr->DD_BianLiang_Shuju[Num].Now_ShiDuan=Variable_Set_value.Now_ShiDuan;
			RtuDataAddr->DD_BianLiang_Shuju[Num].FeiLvShu=Variable_Set_value.FeiLvShu;
			RtuDataAddr->DD_BianLiang_Shuju[Num].GongGongJiari=Variable_Set_value.GongGongJiari;
			RtuDataAddr->DD_BianLiang_Shuju[Num].Now_ShiDuan=Variable_Set_value.Now_ShiDuan;
			*/
			RtuDataAddr->DD_BianLiang_Shuju[Num].Valid=1;
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Valid=1;
		}
	}
	return;
}

void iec_read(unsigned char DBNo)
{
	char seed[17] ;
	char pass[9] = "0001ABCD";
	char pss[32];
	unsigned char len = 0,i;
	Trn645Buff[len++]='/';
	Trn645Buff[len++]='?';
	Trn645Buff[len++]=RtuDataAddr->Meter_Para.Dian_Meter[DBNo].Addr[5];
	Trn645Buff[len++]=RtuDataAddr->Meter_Para.Dian_Meter[DBNo].Addr[4];
	Trn645Buff[len++]=RtuDataAddr->Meter_Para.Dian_Meter[DBNo].Addr[3];
	Trn645Buff[len++]=RtuDataAddr->Meter_Para.Dian_Meter[DBNo].Addr[2];
	Trn645Buff[len++]=RtuDataAddr->Meter_Para.Dian_Meter[DBNo].Addr[1];
	Trn645Buff[len++]=RtuDataAddr->Meter_Para.Dian_Meter[DBNo].Addr[0];
	Trn645Buff[len++]='!';
	Trn645Buff[len++]=CR;
	Trn645Buff[len++]=LF;
	SendStrTo485(Trn645Buff,len);
	printf("\r\nSend len==%d:",len);
	for(i = 0;i < len;i++)
    {
		printf("%x ",Trn645Buff[i]);
    }
	delay(300);
	len = ReceiveFrom485(Rec645Buff);
	printf("\r\nreceive len==%d:",len);
	for(i = 0;i < len;i++)
    {
		printf("%x ",Rec645Buff[i]);
    }
	if((len > 15)&&(Rec645Buff[0] == '/'))
	{
		Trn645Buff[len++]=ACK;
		Trn645Buff[len++]='0';
		Trn645Buff[len++]='2';
		Trn645Buff[len++]='1';
		Trn645Buff[len++]=CR;
		Trn645Buff[len++]=LF;
		SendStrTo485(Trn645Buff ,len);
		delay(300);
		len = ReceiveFrom485(Rec645Buff);
		if((Rec645Buff[1] == 'P') && (Rec645Buff[2] == '0') &&(Rec645Buff[4] == '(')&&(Rec645Buff[22] == ETX))
		{
			if(Rec645Buff[23] == xor_check((char *)Rec645Buff))
			{
				memcpy(seed,&Rec645Buff[5],16);
				Encrypt(pass, seed, pss);
				Trn645Buff[0] = SOH;
			  	Trn645Buff[1] = 'P';
			    Trn645Buff[2] = '2';
				Trn645Buff[3] = STX;
				Trn645Buff[4] = '(';
				memcpy(	&Trn645Buff[5],pss,16);
				Trn645Buff[21] = ')';
				Trn645Buff[22] = ETX;
				Trn645Buff[23] = xor_check((char *)Trn645Buff);
				SendStrTo485(Trn645Buff ,24);
				delay(300);
				len = ReceiveFrom485(Rec645Buff);
				if(Rec645Buff[0] == ACK)
				{
					getMeterData1(); //�����й�  �����й�  ��һ~ �ģ� �����޹��ܵ���
					getMeterData2(); //�����й����ʣ�1 -4 �������з��ʣ�1-4��
					getMeterData3(); //��ѹ A B C
					getMeterData4(); //���� A B C
					getMeterData5(); //A���й�����  B���й�����  C���й�����  ˲ʱ�й�����
					getMeterData6(); //A���޹�����  B���޹�����  C���޹�����  ˲ʱ�޹�����
					getMeterData7(); //A�๦������  B�๦������  C�๦������  �ܹ�������
					IECExit();
					iec_Data_Calc(DBNo);
				}
			}
		}
	}
}

void iec_data_402SH(const char *s,char *o)//��ǰ�����������ʱ��  ����ʱ����,�洢ʱ���������еġ��ꡯ��
{
	*(3+ o) = (((*(s + 14))- 0x30) << 4) + ((*(s + 15)) - 0x30);
	*(2+ o) = (((*(s + 17))- 0x30) << 4) + ((*(s + 18)) - 0x30);
	*(1+ o) = (((*(s + 20))- 0x30) << 4) + ((*(s + 21)) - 0x30);
	*o = (((*(s + 23))- 0x30) << 4) + ((*(s + 24)) - 0x30);
}

void iec_data_402SYSH(const char *s,char *o)//���������������ʱ��  ����ʱ����,�洢ʱ���������еġ��ꡯ��
{
	*(3+ o) = (((*(s + 11))- 0x30) << 4) + ((*(s + 12)) - 0x30);
	*(2+ o) = (((*(s + 14))- 0x30) << 4) + ((*(s + 15)) - 0x30);
	*(1+ o) = (((*(s + 17))- 0x30) << 4) + ((*(s + 18)) - 0x30);
	*o = (((*(s + 20))- 0x30) << 4) + ((*(s + 21)) - 0x30);
}

void iec_data_402ZDXL(const char *s,char *o)//�������
{
	*(2+ o) = (*s - 0x30);
	*(1+ o) = (((*(s + 2))- 0x30) << 4) + ((*(s + 3)) - 0x30);
	*o = (((*(s + 4))- 0x30) << 4) + ((*(s + 5)) - 0x30);
}

void iec_data_402FLDN(const char *s,char *o)//���ƽ�ȣ������й� �����й� �����޹� �����޹�   FLDN:���ʵ���ʾֵ
{
	*(3+ o) = 0x00;
	*(2+ o) = ((*s - 0x30) << 4) + ((*(s + 1)) - 0x30);
	*(1+ o) = (((*(s + 2))- 0x30) << 4) + ((*(s + 3)) - 0x30);
	*o = (((*(s + 5))- 0x30) << 4) + ((*(s + 6)) - 0x30);
}

void iec_data_402ZDN(const char *s,char *o)//�����й��� �����й��� �����޹��� �����޹���  ZDN:�ܵ���
{
	*(3+ o) = 0x00;
	*(2+ o) = (((*s) - 0x30) << 4) + ((*(s + 1)) - 0x30);
	*(1+ o) = (((*(s + 2))- 0x30) << 4) + ((*(s + 3)) - 0x30);
	*o = (((*(s + 5))- 0x30) << 4) + ((*(s + 6)) - 0x30);
}

void iec_data_402DY(const char *s,char *o)//��ѹ
{
	*(1+ o) = (((*s) - 0x30)<< 4) + ((*(s + 1))- 0x30);
	*o = (((*(s + 2))- 0x30) << 4) + ((*(s + 4)) - 0x30);
}
void iec_data_402DL(const char *s,char *o)//����
{
	*(1+ o) = (((*s) - 0x30) << 4) + ((*(s + 1)) - 0x30);
	*o = (((*(s + 3))- 0x30) << 4) + ((*(s + 4)) - 0x30);
}
void iec_data_402SXSY(const char *s,char *o)//����ʧѹ����
{
	*(2+ o) = (((*(s + 2)) - 0x30) << 4) + ((*(s + 3)) - 0x30);
	*(1+ o) = (((*(s + 4))- 0x30) << 4) + ((*(s + 5)) - 0x30);
	*o = (((*(s + 6))- 0x30) << 4) + ((*(s + 7)) - 0x30);
}
void iec_data_402SYCS(const char *s,char *o)//A��B��C�����ѹʧѹ����
{
	*(1+ o) = (((*s) - 0x30) << 4) + ((*(s + 1)) - 0x30);
	*o = (((*(s + 2)) - 0x30) << 4) + ((*(s + 3)) - 0x30);
}
void iec_data_402GLYS(const char *s,char *o)//��������
{
	*(1+ o) = (((*(s + 1)) - 0x30) << 4) + ((*(s + 3)) - 0x30);
	*o = (((*(s + 4)) - 0x30) << 4);
}
void iec_data_402DYXJ(const char *s,char *o)//�����ѹ���
{

}
void iec_data_402YGGL(const char *s,char *o)//˲ʱ�й�����
{
	*(2+ o) = ((*(s + 3) - 0x30) << 4) + ((*(s + 4)) - 0x30);
	*(1+ o) = (((*(s + 6)) - 0x30) << 4) + ((*(s + 7)) - 0x30);
	*o = (((*(s + 8))- 0x30) << 4) ;
}
void iec_data_402WGGL(const char *s,char *o)//˲ʱ�޹�����
{
	*(1+ o) = (((*(s + 3)) - 0x30) << 4) + ((*(s + 4)) - 0x30);
	*o = (((*(s + 6))- 0x30) << 4) + ((*(s + 7)) - 0x30);
}

void analyse_iec_frame()
{
	unsigned char framebuff[266][35];
	unsigned char *p=Rec645Buff;
	unsigned short i;
	unsigned char k,m=0,flag=0;
	TS ts;

	for(i=0; i<266; i++)
	{
		memset(&framebuff[i][0],0,35);
	}
	if(0x2!= (*p))return ;
	p++;
	for(i=0; i<266; i++)
	{
		if(0x3 == (*p)) break;
		for(k=0; k<35; k++)
		{
			if(0 == flag)
			{
				if('(' == (*p))
					flag = 1;
				p++;
				continue;
			}
			if(0xd == (*p))
			{
				p +=2;
				m =0;
				flag =0;
				break;
			}
			framebuff[i][m]= *p;
			m++;
			p++;
		}
	}
	//SPprintf(framebuff);//��������ת�浽��ά�������ȥ����һ��'('����ǰ�������

	//--------------�ܵ���-------------------
	//printf("\r\nZhengXiangYouGongZong:\r\n");
	iec_data_402ZDN((char *)&framebuff[4][0],(char *)Demand_N_Set_Value.N_Z_P_All);//�����й��ܵ���
	//Pprintf(Demand_N_Set_Value.N_Z_P_All,4);

	//printf("\r\nFanXiangYouGongZong:\r\n");
	iec_data_402ZDN((char *)&framebuff[39][0],(char *)Demand_N_Set_Value.N_F_P_All);//�����й��ܵ���
	//Pprintf(Demand_N_Set_Value.N_F_P_All,4);

	//printf("\r\nZhengXiangWuGongZong:\r\n");
	iec_data_402ZDN((char *)&framebuff[144][0],(char *)Demand_N_Set_Value.N_Z_Q_All);//�����޹��ܵ���
	//Pprintf(Demand_N_Set_Value.N_Z_Q_All,4);

	//printf("\r\nFanXiangWuGongZong:\r\n");
	iec_data_402ZDN((char *)&framebuff[179][0],(char *)Demand_N_Set_Value.N_F_Q_All);//�����޹��ܵ���
	//Pprintf(Demand_N_Set_Value.N_F_Q_All,4);
	//--------------���ƽ��------------------
	//printf("\r\nZhengXiangYouGongFeng:\r\n");
	iec_data_402FLDN((char *)&framebuff[11][0],(char *)Demand_N_Set_Value.N_Z_P_F[0]);   //�����й���
	//Pprintf(Demand_N_Set_Value.N_Z_P_F[0],4);

	//printf("\r\nZhengXiangYouGongPing:\r\n");
	iec_data_402FLDN((char *)&framebuff[18][0],(char *)Demand_N_Set_Value.N_Z_P_F[1]);   //�����й�ƽ
	//Pprintf(Demand_N_Set_Value.N_Z_P_F[1],4);

	//printf("\r\nZhengXiangYouGongGu:\r\n");
	iec_data_402FLDN((char *)&framebuff[25][0],(char *)Demand_N_Set_Value.N_Z_P_F[2]);   //�����й���
	//Pprintf(Demand_N_Set_Value.N_Z_P_F[2],4);

	//printf("\r\nZhengXiangYouGongJian:\r\n");
	iec_data_402FLDN((char *)&framebuff[32][0],(char *)Demand_N_Set_Value.N_Z_P_F[3]);   //�����й���
	//Pprintf(Demand_N_Set_Value.N_Z_P_F[3],4);

	//printf("\r\nFanXiangWuGongFeng:\r\n");
	iec_data_402FLDN((char *)&framebuff[46][0],(char *)Demand_N_Set_Value.N_F_P_F[0]);  //�����й���
	//Pprintf(Demand_N_Set_Value.N_F_P_F[0],4);

	//printf("\r\nFanXiangWuGongPing:\r\n");
	iec_data_402FLDN((char *)&framebuff[53][0],(char *)Demand_N_Set_Value.N_F_P_F[1]);  //�����й�ƽ
	//Pprintf(Demand_N_Set_Value.N_F_P_F[1],4);

	//printf("\r\nFanXiangWuGongGu:\r\n");
	iec_data_402FLDN((char *)&framebuff[60][0],(char *)Demand_N_Set_Value.N_F_P_F[2]);  //�����й���
	//Pprintf(Demand_N_Set_Value.N_F_P_F[2],4);

	//printf("\r\nFanXiangWuGongJian:\r\n");
	iec_data_402FLDN((char *)&framebuff[67][0],(char *)Demand_N_Set_Value.N_F_P_F[3]);  //�����й���
	//Pprintf(Demand_N_Set_Value.N_F_P_F[3],4);

	//printf("\r\nZhengXiangWuGongFeng:\r\n");
	iec_data_402FLDN((char *)&framebuff[151][0],(char *)Demand_N_Set_Value.N_Z_Q_F[0]);  //�����޹���
	//Pprintf(Demand_N_Set_Value.N_Z_Q_F[0],4);

	//printf("\r\nZhengXiangWuGongPing:\r\n");
	iec_data_402FLDN((char *)&framebuff[158][0],(char *)Demand_N_Set_Value.N_Z_Q_F[1]);  //�����޹�ƽ
	//Pprintf(Demand_N_Set_Value.N_Z_Q_F[1],4);

	//printf("\r\nZhengXiangWuGongGu:\r\n");
	iec_data_402FLDN((char *)&framebuff[165][0],(char *)Demand_N_Set_Value.N_Z_Q_F[2]);  //�����޹���
	//Pprintf(Demand_N_Set_Value.N_Z_Q_F[2],4);

	//printf("\r\nZhengXiangWuGongJian:\r\n");
	iec_data_402FLDN((char *)&framebuff[172][0],(char *)Demand_N_Set_Value.N_Z_Q_F[3]);  //�����޹���
	//Pprintf(Demand_N_Set_Value.N_Z_Q_F[3],4);

	//printf("\r\nFanXiangWuGongFeng:\r\n");
	iec_data_402FLDN((char *)&framebuff[186][0],(char *)Demand_N_Set_Value.N_F_Q_F[0]);  //�����޹���
	//Pprintf(Demand_N_Set_Value.N_F_Q_F[0],4);

	//printf("\r\nFanXiangWuGongPing:\r\n");
	iec_data_402FLDN((char *)&framebuff[193][0],(char *)Demand_N_Set_Value.N_F_Q_F[1]);  //�����޹�ƽ
	//Pprintf(Demand_N_Set_Value.N_F_Q_F[1],4);

	//printf("\r\nFanXiangWuGongGu:\r\n");
	iec_data_402FLDN((char *)&framebuff[200][0],(char *)Demand_N_Set_Value.N_F_Q_F[2]);  //�����޹���
	//Pprintf(Demand_N_Set_Value.N_F_Q_F[2],4);

	//printf("\r\nFanXiangWuGongJian:\r\n");
	iec_data_402FLDN((char *)&framebuff[207][0],(char *)Demand_N_Set_Value.N_F_Q_F[3]);  //�����޹���
	//Pprintf(Demand_N_Set_Value.N_F_Q_F[3],4);

	//--------------���������ʱ��--------------
	//printf("\r\nZhengXiangYouGongZuiDaXuLiang:\r\n");
	iec_data_402ZDXL((char *)&framebuff[74][0],(char *)Maximum_Demand_N_Set_Value.N_Z_P_X_All);  //�����й��������
	//Pprintf(Maximum_Demand_N_Set_Value.N_Z_P_X_All,3);
	iec_data_402SH((char *)&framebuff[74][0],(char *)Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_All);//ʱ��
	//Pprintf(Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_All,4);

	//printf("\r\nFengDuanZhengXiangYouGongZuiDaXuLiang:\r\n");
	iec_data_402ZDXL((char *)&framebuff[81][0],(char *)Maximum_Demand_N_Set_Value.N_Z_P_X_F[0]);  //��������й��������
	//Pprintf(Maximum_Demand_N_Set_Value.N_Z_P_X_F[0],3);
	iec_data_402SH((char *)&framebuff[81][0],(char *)Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_F[0]);//ʱ��
	//Pprintf(Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_F[0],4);

	//printf("\r\nPingDuanZhengXiangYouGongZuiDaXuLiang:\r\n");
	iec_data_402ZDXL((char *)&framebuff[88][0],(char *)Maximum_Demand_N_Set_Value.N_Z_P_X_F[1]);  //ƽ�������й��������
	//Pprintf(Maximum_Demand_N_Set_Value.N_Z_P_X_F[1],3);
	iec_data_402SH((char *)&framebuff[88][0],(char *)Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_F[1]);//ʱ��
	//Pprintf(Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_F[1],4);

	//printf("\r\nGuDuanZhengXiangYouGongZuiDaXuLiang:\r\n");
	iec_data_402ZDXL((char *)&framebuff[95][0],(char *)Maximum_Demand_N_Set_Value.N_Z_P_X_F[2]);  //�ȶ������й��������
	//Pprintf(Maximum_Demand_N_Set_Value.N_Z_P_X_F[2],3);
	iec_data_402SH((char *)&framebuff[95][0],(char *)Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_F[2]);//ʱ��
	//Pprintf(Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_F[2],4);

	//printf("\r\nJianDuanZhengXiangYouGongZuiDaXuLiang:\r\n");
	iec_data_402ZDXL((char *)&framebuff[102][0],(char *)Maximum_Demand_N_Set_Value.N_Z_P_X_F[3]);  //��������й��������
	//Pprintf(Maximum_Demand_N_Set_Value.N_Z_P_X_F[3],3);
	iec_data_402SH((char *)&framebuff[102][0],(char *)Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_F[3]);//ʱ��
	//Pprintf(Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_F[3],4);

	//printf("\r\nFanXiangYouGongZuiDaXuLiang:\r\n");
	iec_data_402ZDXL((char *)&framebuff[109][0],(char *)Maximum_Demand_N_Set_Value.N_F_P_X_All);   //�����й��������
	//Pprintf(Maximum_Demand_N_Set_Value.N_F_P_X_All,3);
	iec_data_402SH((char *)&framebuff[109][0],(char *)Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_All);//ʱ��
	//Pprintf(Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_All,4);

	//printf("\r\nFengDuanFanXiangYouGongZuiDaXuLiang:\r\n");
	iec_data_402ZDXL((char *)&framebuff[116][0],(char *)Maximum_Demand_N_Set_Value.N_F_P_X_F[0]);  //��η����й��������
	//Pprintf(Maximum_Demand_N_Set_Value.N_F_P_X_F[0],3);
	iec_data_402SH((char *)&framebuff[116][0],(char *)Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_F[0]);//ʱ��
	//Pprintf(Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_F[0],4);

	//printf("\r\nPingDuanFanXiangYouGongZuiDaXuLiang:\r\n");
	iec_data_402ZDXL((char *)&framebuff[123][0],(char *)Maximum_Demand_N_Set_Value.N_F_P_X_F[1]);  //ƽ�η����й��������
	//Pprintf(Maximum_Demand_N_Set_Value.N_F_P_X_F[1],3);
	iec_data_402SH((char *)&framebuff[123][0],(char *)Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_F[1]);//ʱ��
	//Pprintf(Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_F[1],4);

	//printf("\r\nGuDuanFanXiangYouGongZuiDaXuLiang:\r\n");
	iec_data_402ZDXL((char *)&framebuff[130][0],(char *)Maximum_Demand_N_Set_Value.N_F_P_X_F[2]);  //�ȶη����й��������
	//Pprintf(Maximum_Demand_N_Set_Value.N_F_P_X_F[2],3);
	iec_data_402SH((char *)&framebuff[130][0],(char *)Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_F[2]);//ʱ��
	//Pprintf(Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_F[2],4);

	//printf("\r\nJianDuanFanXiangYouGongZuiDaXuLiang:\r\n");
	iec_data_402ZDXL((char *)&framebuff[137][0],(char *)Maximum_Demand_N_Set_Value.N_F_P_X_F[3]);  //��η����й��������
	//Pprintf(Maximum_Demand_N_Set_Value.N_F_P_X_F[3],3);
	iec_data_402SH((char *)&framebuff[137][0],(char *)Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_F[3]);//ʱ��
	//Pprintf(Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_F[3],4);

	//�����������
	//--------------���������ʱ��--------------
	//printf("\r\nShangYueZhengXiangYouGongZuiDaXuLiang:\r\n");
	iec_data_402ZDXL((char *)&framebuff[75][0],(char *)Yue_Maximum_Demand_N_Set_Value.SY_Z_P_X_All);  //�����й��������
	//Pprintf(Yue_Maximum_Demand_N_Set_Value.SY_Z_P_X_All,3);
	iec_data_402SYSH((char *)&framebuff[75][0],(char *)Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_Z_P_X_All);//ʱ��
	//Pprintf(Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_Z_P_X_All,4);

	//printf("\r\nShangYueFengDuanZhengXiangYouGongZuiDaXuLiang:\r\n");
	iec_data_402ZDXL((char *)&framebuff[83][0],(char *)Yue_Maximum_Demand_N_Set_Value.SY_Z_P_X_F[0]);  //��������й��������
	//Pprintf(Yue_Maximum_Demand_N_Set_Value.SY_Z_P_X_F[0],3);
	iec_data_402SYSH((char *)&framebuff[83][0],(char *)Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_Z_P_X_F[0]);//ʱ��
	//Pprintf(Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_Z_P_X_F[0],4);

	//printf("\r\nShangYuePingDuanZhengXiangYouGongZuiDaXuLiang:\r\n");
	iec_data_402ZDXL((char *)&framebuff[90][0],(char *)Yue_Maximum_Demand_N_Set_Value.SY_Z_P_X_F[1]);  //ƽ�������й��������
	//Pprintf(Yue_Maximum_Demand_N_Set_Value.SY_Z_P_X_F[1],3);
	iec_data_402SYSH((char *)&framebuff[90][0],(char *)Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_Z_P_X_F[1]);//ʱ��
	//Pprintf(Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_Z_P_X_F[1],4);

	//printf("\r\nShangYueGuDuanZhengXiangYouGongZuiDaXuLiang:\r\n");
	iec_data_402ZDXL((char *)&framebuff[97][0],(char *)Yue_Maximum_Demand_N_Set_Value.SY_Z_P_X_F[2]);  //�ȶ������й��������
	//Pprintf(Yue_Maximum_Demand_N_Set_Value.SY_Z_P_X_F[2],3);
	iec_data_402SYSH((char *)&framebuff[97][0],(char *)Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_Z_P_X_F[2]);//ʱ��
	//Pprintf(Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_Z_P_X_F[2],4);

	//printf("\r\nShangYueJianDuanZhengXiangYouGongZuiDaXuLiang:\r\n");
	iec_data_402ZDXL((char *)&framebuff[104][0],(char *)Yue_Maximum_Demand_N_Set_Value.SY_Z_P_X_F[3]);  //��������й��������
	//Pprintf(Yue_Maximum_Demand_N_Set_Value.SY_Z_P_X_F[3],3);
	iec_data_402SYSH((char *)&framebuff[104][0],(char *)Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_Z_P_X_F[3]);//ʱ��
	//Pprintf(Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_Z_P_X_F[3],4);

	//printf("\r\nShangYueFanXiangYouGongZuiDaXuLiang:\r\n");
	iec_data_402ZDXL((char *)&framebuff[111][0],(char *)Yue_Maximum_Demand_N_Set_Value.SY_F_P_X_All);   //�����й��������
	//Pprintf(Yue_Maximum_Demand_N_Set_Value.SY_F_P_X_All,3);
	iec_data_402SYSH((char *)&framebuff[111][0],(char *)Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_F_P_X_All);//ʱ��
	//Pprintf(Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_F_P_X_All,4);

	//printf("\r\nShangYueFengDuanFanXiangYouGongZuiDaXuLiang:\r\n");
	iec_data_402ZDXL((char *)&framebuff[118][0],(char *)Yue_Maximum_Demand_N_Set_Value.SY_F_P_X_F[0]);  //��η����й��������
	//Pprintf(Yue_Maximum_Demand_N_Set_Value.SY_F_P_X_F[0],3);
	iec_data_402SYSH((char *)&framebuff[118][0],(char *)Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_Z_P_X_F[0]);//ʱ��
	//Pprintf(Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_Z_P_X_F[0],4);

	//printf("\r\nShangYuePingDuanFanXiangYouGongZuiDaXuLiang:\r\n");
	iec_data_402ZDXL((char *)&framebuff[125][0],(char *)Yue_Maximum_Demand_N_Set_Value.SY_F_P_X_F[1]);  //ƽ�η����й��������
	//Pprintf(Yue_Maximum_Demand_N_Set_Value.SY_F_P_X_F[1],3);
	iec_data_402SYSH((char *)&framebuff[125][0],(char *)Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_Z_P_X_F[1]);//ʱ��
	//Pprintf(Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_Z_P_X_F[1],4);

	//printf("\r\nShangYueGuDuanFanXiangYouGongZuiDaXuLiang:\r\n");
	iec_data_402ZDXL((char *)&framebuff[132][0],(char *)Yue_Maximum_Demand_N_Set_Value.SY_F_P_X_F[2]);  //�ȶη����й��������
	//Pprintf(Yue_Maximum_Demand_N_Set_Value.SY_F_P_X_F[2],3);
	iec_data_402SYSH((char *)&framebuff[132][0],(char *)Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_Z_P_X_F[2]);//ʱ��
	//Pprintf(Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_Z_P_X_F[2],4);

	//printf("\r\nShangYueJianDuanFanXiangYouGongZuiDaXuLiang:\r\n");
	iec_data_402ZDXL((char *)&framebuff[139][0],(char *)Yue_Maximum_Demand_N_Set_Value.SY_F_P_X_F[3]);  //��η����й��������
	//Pprintf(Yue_Maximum_Demand_N_Set_Value.SY_F_P_X_F[3],3);
	iec_data_402SYSH((char *)&framebuff[139][0],(char *)Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_Z_P_X_F[3]);//ʱ��
	//Pprintf(Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_Z_P_X_F[3],4);

	if(1 == jiexianfangshi_flag)//----------------�������߽��߷�ʽ-------------------
	{
		printf("\r\n---------------------DianBiaoJieXianFangShi:SanXiangSiXian------------------------\r\n");
		//-------------��ѹ A B C------------------
		printf("\r\nDianYa-A:\r\n");
		iec_data_402DY((char *)&framebuff[228][0],(char *)Variable_Set_value.VA);
		Pprintf(Variable_Set_value.VA,2);

		printf("\r\nDianYa-B:\r\n");
		iec_data_402DY((char *)&framebuff[229][0],(char *)Variable_Set_value.VB);
		Pprintf(Variable_Set_value.VB,2);

		printf("\r\nDianYa-C:\r\n");
		iec_data_402DY((char *)&framebuff[230][0],(char *)Variable_Set_value.VC);
		Pprintf(Variable_Set_value.VC,2);

		//-------------���� A B C------------------
		printf("\r\nDianLiu-A:\r\n");
		iec_data_402DL((char *)&framebuff[231][0],(char *)Variable_Set_value.IA);
		Pprintf(Variable_Set_value.IA,2);

		printf("\r\nDianLiu-B:\r\n");
		iec_data_402DL((char *)&framebuff[232][0],(char *)Variable_Set_value.IB);
		Pprintf(Variable_Set_value.IB,2);

		printf("\r\nDianLiu-C:\r\n");
		iec_data_402DL((char *)&framebuff[233][0],(char *)Variable_Set_value.IC);
		Pprintf(Variable_Set_value.IC,2);

		printf("\r\nShiYaCiShu:\r\n");
		iec_data_402SXSY((char *)&framebuff[234][0],(char *)Variable_Set_value.shiyacishu);
		Pprintf(Variable_Set_value.shiyacishu,3);

		printf("\r\nGongLvYinShu:\r\n");
		iec_data_402GLYS((char *)&framebuff[238][0],(char *)Variable_Set_value.Cos);
		Pprintf(Variable_Set_value.Cos,2);

		//-------------˲ʱ�й�����---------------------
		printf("\r\nShunShiYouGongGongLv:\r\n");
		if(0x2d != framebuff[263][4])
			iec_data_402YGGL((char *)&framebuff[263][0],(char *)Variable_Set_value.P);
		Pprintf(Variable_Set_value.P,3);

		//-------------˲ʱ�޹�����---------------------
		printf("\r\nShunShiWuGongGongLv:\r\n");
		if(0x2d != framebuff[264][4])
			iec_data_402WGGL((char *)&framebuff[264][0],(char *)Variable_Set_value.Q);
		Pprintf(Variable_Set_value.Q,2);
	}
	else//----------------�������߽��߷�ʽ-------------------
	{
		printf("\r\n---------------------DianBiaoJieXianFangShi:SanXiangSanXian------------------------\r\n");
		//-------------��ѹ A B C------------------
		//printf("\r\nDianYa-A:\r\n");
		iec_data_402DY((char *)&framebuff[228][0],(char *)Variable_Set_value.VA);
		//Pprintf(Variable_Set_value.VA,2);

		//printf("\r\nDianYa-C:\r\n");
		iec_data_402DY((char *)&framebuff[229][0],(char *)Variable_Set_value.VC);
		//Pprintf(Variable_Set_value.VC,2);

		//-------------���� A B C------------------
		//printf("\r\nDianLiu-A:\r\n");
		iec_data_402DL((char *)&framebuff[230][0],(char *)Variable_Set_value.IA);
		//Pprintf(Variable_Set_value.IA,2);

		//printf("\r\nDianLiu-C:\r\n");
		iec_data_402DL((char *)&framebuff[231][0],(char *)Variable_Set_value.IC);
		//Pprintf(Variable_Set_value.IC,2);

		//printf("\r\nShiYaCiShu:\r\n");
		iec_data_402SXSY((char *)&framebuff[232][0],(char *)Variable_Set_value.shiyacishu);
		//Pprintf(Variable_Set_value.shiyacishu,3);

		//printf("\r\nGongLvYinShu:\r\n");
		if(0x2d != framebuff[235][1])//С����ǰ��ĸ�λ����ֵ������0x2d
			iec_data_402GLYS((char *)&framebuff[235][0],(char *)Variable_Set_value.Cos);
		//Pprintf(Variable_Set_value.Cos,2);

		//-------------˲ʱ�й�����---------------------
		//printf("\r\nShunShiYouGongGongLv:\r\n");
		if(0x2d != framebuff[254][4])
			iec_data_402YGGL((char *)&framebuff[254][0],(char *)Variable_Set_value.P);
		//Pprintf(Variable_Set_value.P,3);

		//-------------˲ʱ�޹�����---------------------
		//printf("\r\nShunShiWuGongGongLv:\r\n");
		if(0x2d != framebuff[255][4])//С����ǰ��ĸ�λ����ֵ������0x2d
			iec_data_402WGGL((char *)&framebuff[255][0],(char *)Variable_Set_value.Q);
		//Pprintf(Variable_Set_value.Q,2);
	}

	RtuDataAddr->Meter_Para.Valid = 1;
	TSGet(&ts);
	Variable_Set_value.Time_Chaobiao.BCD01=((ts.Minute/10)<<4)+(ts.Minute%10);
	Variable_Set_value.Time_Chaobiao.BCD02=((ts.Hour/10)<<4)+(ts.Hour%10);
	Variable_Set_value.Time_Chaobiao.BCD03=((ts.Day/10)<<4)+(ts.Day%10);
	Variable_Set_value.Time_Chaobiao.BCD04=((ts.Month/10)<<4)+(ts.Month%10);
	Variable_Set_value.Time_Chaobiao.BCD05=(((ts.Year%100)/10)<<4)+(ts.Year%10);

	Maximum_Demand_Time_N_Set_Value.Time_Chaobiao.BCD01=((ts.Minute/10)<<4)+(ts.Minute%10);
	Maximum_Demand_Time_N_Set_Value.Time_Chaobiao.BCD02=((ts.Hour/10)<<4)+(ts.Hour%10);
	Maximum_Demand_Time_N_Set_Value.Time_Chaobiao.BCD03=((ts.Day/10)<<4)+(ts.Day%10);
	Maximum_Demand_Time_N_Set_Value.Time_Chaobiao.BCD04=((ts.Month/10)<<4)+(ts.Month%10);
	Maximum_Demand_Time_N_Set_Value.Time_Chaobiao.BCD05=(((ts.Year%100)/10)<<4)+(ts.Year%10);

	Yue_Maximum_Demand_Time_N_Set_Value.Time_Chaobiao.BCD01=((ts.Minute/10)<<4)+(ts.Minute%10);
	Yue_Maximum_Demand_Time_N_Set_Value.Time_Chaobiao.BCD02=((ts.Hour/10)<<4)+(ts.Hour%10);
	Yue_Maximum_Demand_Time_N_Set_Value.Time_Chaobiao.BCD03=((ts.Day/10)<<4)+(ts.Day%10);
	Yue_Maximum_Demand_Time_N_Set_Value.Time_Chaobiao.BCD04=((ts.Month/10)<<4)+(ts.Month%10);
	Yue_Maximum_Demand_Time_N_Set_Value.Time_Chaobiao.BCD05=(((ts.Year%100)/10)<<4)+(ts.Year%10);

	Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD01=((ts.Minute/10)<<4)+(ts.Minute%10);
	Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD02=((ts.Hour/10)<<4)+(ts.Hour%10);
	Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD03=((ts.Day/10)<<4)+(ts.Day%10);
	Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD04=((ts.Month/10)<<4)+(ts.Month%10);
	Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD05=(((ts.Year%100)/10)<<4)+(ts.Year%10);

	Yue_Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD01=((ts.Minute/10)<<4)+(ts.Minute%10);
	Yue_Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD02=((ts.Hour/10)<<4)+(ts.Hour%10);
	Yue_Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD03=((ts.Day/10)<<4)+(ts.Day%10);
	Yue_Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD04=((ts.Month/10)<<4)+(ts.Month%10);
	Yue_Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD05=(((ts.Year%100)/10)<<4)+(ts.Year%10);

	Demand_N_Set_Value.Time_Chaobiao.BCD01=((ts.Minute/10)<<4)+(ts.Minute%10);
	Demand_N_Set_Value.Time_Chaobiao.BCD02=((ts.Hour/10)<<4)+(ts.Hour%10);
	Demand_N_Set_Value.Time_Chaobiao.BCD03=((ts.Day/10)<<4)+(ts.Day%10);
	Demand_N_Set_Value.Time_Chaobiao.BCD04=((ts.Month/10)<<4)+(ts.Month%10);
	Demand_N_Set_Value.Time_Chaobiao.BCD05=(((ts.Year%100)/10)<<4)+(ts.Year%10);

	return ;
}

void iec_402Data_Calc(unsigned char DDNo)    //������402��
{
	unsigned char Num;
//	unsigned char tmp;

	if(RtuDataAddr->Meter_Para.Valid!=1)
		return;
	if(RtuDataAddr->Meter_Para.Metet_jiaoliu_Num>CeLiangPoint_Max)
		return;
	if(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].GuiYue_Type==IEC1107)//LANJIER_D)
	{
		Num=RtuDataAddr->Meter_Para.Dian_Meter[DDNo].CeLiangNo-1;
		if(Num>CeLiangPoint_Max)
			return;
		//printf("\r\nFangDaoHuanCunQuZhong\r\n");
		memcpy(&RtuDataAddr->DD_Device_BiaoShi_Value[Num].Chao_Time.BCD01,&Demand_N_Set_Value.Time_Chaobiao.BCD01,5);
		memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Chao_Time.BCD01,&Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD01,5);
		memcpy(&RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].Chao_Time.BCD01,&Yue_Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD01,5);
		memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Chao_Time.BCD01,&Maximum_Demand_Time_N_Set_Value.Time_Chaobiao.BCD01,5);
		memcpy(&RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].Chao_Time.BCD01,&Yue_Maximum_Demand_Time_N_Set_Value.Time_Chaobiao.BCD01,5);
		memcpy(&RtuDataAddr->DD_Device_BiaoShi_Value[Num].Chao_Time.BCD01,&Variable_Set_value.Time_Chaobiao.BCD01,5);

		RtuDataAddr->DD_Device_BiaoShi_Value[Num].IA=BCDTo_INT32(Variable_Set_value.IA,2);//0.01A
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].IB=BCDTo_INT32(Variable_Set_value.IB,2);
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].IC=BCDTo_INT32(Variable_Set_value.IC,2);

		RtuDataAddr->DD_Device_BiaoShi_Value[Num].VA=BCDTo_INT32(Variable_Set_value.VA,2);//0.1V
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].VB=BCDTo_INT32(Variable_Set_value.VB,2);
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].VC=BCDTo_INT32(Variable_Set_value.VC,2);

		RtuDataAddr->DD_Device_BiaoShi_Value[Num].Cos=BCDTo_INT32(Variable_Set_value.Cos,2);
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].P=BCDTo_INT32(Variable_Set_value.P,3);//��λС��
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].Q=BCDTo_INT32(Variable_Set_value.Q,2);//*100;

		RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_All=BCDTo_INT32(Demand_N_Set_Value.N_Z_P_All,4);
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_F[0]=BCDTo_INT32(Demand_N_Set_Value.N_Z_P_F[0],4);
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_F[1]=BCDTo_INT32(Demand_N_Set_Value.N_Z_P_F[1],4);
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_F[2]=BCDTo_INT32(Demand_N_Set_Value.N_Z_P_F[2],4);
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_F[3]=BCDTo_INT32(Demand_N_Set_Value.N_Z_P_F[3],4);

		RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_All=BCDTo_INT32(Demand_N_Set_Value.N_F_P_All,4);
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_F[0]=BCDTo_INT32(Demand_N_Set_Value.N_F_P_F[0],4);
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_F[1]=BCDTo_INT32(Demand_N_Set_Value.N_F_P_F[1],4);
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_F[2]=BCDTo_INT32(Demand_N_Set_Value.N_F_P_F[2],4);
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_F[3]=BCDTo_INT32(Demand_N_Set_Value.N_F_P_F[3],4);

		RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_All=BCDTo_INT32(Demand_N_Set_Value.N_Z_Q_All,4);
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_F[0]=BCDTo_INT32(Demand_N_Set_Value.N_Z_Q_F[0],4);
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_F[1]=BCDTo_INT32(Demand_N_Set_Value.N_Z_Q_F[1],4);
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_F[2]=BCDTo_INT32(Demand_N_Set_Value.N_Z_Q_F[2],4);
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_F[3]=BCDTo_INT32(Demand_N_Set_Value.N_Z_Q_F[3],4);

		RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_All=BCDTo_INT32(Demand_N_Set_Value.N_F_Q_All,4);
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_F[0]=BCDTo_INT32(Demand_N_Set_Value.N_F_Q_F[0],4);
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_F[1]=BCDTo_INT32(Demand_N_Set_Value.N_F_Q_F[1],4);
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_F[2]=BCDTo_INT32(Demand_N_Set_Value.N_F_Q_F[2],4);
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_F[3]=BCDTo_INT32(Demand_N_Set_Value.N_F_Q_F[3],4);

		RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_P_X_All=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_Z_P_X_All,3);
		RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_P_X_F[0]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_Z_P_X_F[0],3);
		RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_P_X_F[1]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_Z_P_X_F[1],3);
		RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_P_X_F[2]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_Z_P_X_F[2],3);
		RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_P_X_F[3]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_Z_P_X_F[3],3);

		RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_P_X_All=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_F_P_X_All,3);
		RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_P_X_F[0]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_F_P_X_F[0],3);
		RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_P_X_F[1]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_F_P_X_F[1],3);
		RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_P_X_F[2]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_F_P_X_F[2],3);
		RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_P_X_F[3]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_F_P_X_F[3],3);

		memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_P_X_All[0],&Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_All[0],4);
		memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_P_X_F[0][0],&Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_F[0][0],4);
		memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_P_X_F[1][0],&Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_F[1][0],4);
		memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_P_X_F[2][0],&Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_F[2][0],4);
		memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_P_X_F[3][0],&Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_F[3][0],4);

		memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_P_X_All[0],&Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_All[0],4);
		memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_P_X_F[0][0],&Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_F[0][0],4);
		memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_P_X_F[1][0],&Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_F[1][0],4);
		memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_P_X_F[2][0],&Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_F[2][0],4);
		memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_P_X_F[3][0],&Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_F[3][0],4);

		RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].UAJ=0;
		RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].UBJ=1200;
		RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].UCJ=2400;

		RtuDataAddr->DD_Device_BiaoShi_Value[Num].Valid = 1;
		RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Valid = 1;
		RtuDataAddr->DD_BianLiang_Shuju[Num].Valid=1;
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].Valid=1;
	}
	return;
}

void iec_read_data(unsigned char DDNo)
{
	unsigned short len = 0;
	unsigned short i;
	unsigned char *p;

	Trn645Buff[0] = 0x6;
	Trn645Buff[1] = '0';
	Trn645Buff[2] = '5';  //ȷ�Ͻ���9600������ͨѶ
	Trn645Buff[3] = '0';
	Trn645Buff[4] = 0xd;
	Trn645Buff[5] = 0xa;
	Trn645Buff[6] = '\0';

	SendStrTo485(Trn645Buff,6);
	printf("\r\nSend_Frame:");
	Pprintf(Trn645Buff,6);
	close( ComPort );

	//OldPort[MeterCh].Baud =9600;
	user_init_io(9600,(INT8U *)"even",1,7 );
	len = ReceiveFrom485(Rec645Buff);
	//printf("\r\nLanJiEr whole frame len==%d:",len);//��������
	//Pprintf(Rec645Buff,len);

	p = Rec645Buff;
	for(i=0; i<len; i++)
	{
		if(0x4c == (*p))//���ݱ����е�ѹ�ı�ʶ�жϳ�λ��ѹ��ʶΪ0x4c
		{
			p +=2;
			if(0x32 == (*p))//0x31ΪA���ѹ 0x32ΪB���ѹ0x33ΪC���ѹ
			{
				jiexianfangshi_flag =1;
				break;
			}
		}
		p++;
	}
	if((Rec645Buff[0] == STX) && (Rec645Buff[len-2] == ETX))
	{
		if(Rec645Buff[len-1] == xor_check((char *)Rec645Buff))
		{
			analyse_iec_frame();
			iec_402Data_Calc(DDNo);
		}
	}
	return;

}

/*void iec_read_event()
{
	Trn645Buff[0] = 0x6;
	Trn645Buff[1] = '0';
	Trn645Buff[2] = '5';  //ȷ�Ͻ���9600������ͨѶ
	Trn645Buff[3] = '1';
	Trn645Buff[4] = 0xd;
	Trn645Buff[5] = 0xa;
	Trn645Buff[6] = '\0';

	SendStrTo485(Trn645Buff,6);
	printf("\r\nSend_Frame:");
	Pprintf(Trn645Buff,6);
	close( ComPort );

	//OldPort[MeterCh].Baud =9600;
	user_init_io(9600,(INT8U *)"even",1,7 );
	//len = ReceiveFrom485(Rec645Buff);
	//printf("\r\nReceive_ZongDianLiang_Frame len==%d:",len);
	//Pprintf(Rec645Buff,len);

	if((Rec645Buff[0] == STX) && (Rec645Buff[len-2] == ETX))
	{
		if(Rec645Buff[len-1] == xor_check((char *)Rec645Buff))
		{

		}
	}
}

void iec_read_time()
{
	Trn645Buff[0] = SOH;
	Trn645Buff[1] = 'R';
	Trn645Buff[2] = '2';
	Trn645Buff[3] = STX;
	Trn645Buff[4] = 'C';
	Trn645Buff[5] = '0';
	Trn645Buff[6] = '0';
	Trn645Buff[7] = '3';
	Trn645Buff[8] = '(';
	Trn645Buff[9] = ')';
	Trn645Buff[10] = ETX;
	Trn645Buff[11] = xor_check((char *)Trn645Buff);
	SendStrTo485(Trn645Buff ,12);
	delay(300);

	//len = ReceiveFrom485(Rec645Buff);
	//printf("\r\nReceive_Time_Frame: len==%d:",len);
	//Pprintf(Rec645Buff, len);

}*/

void iec_read_ZxD402(unsigned char DBNo)
{//������D��ZxD402���ô˹�Լ)
	unsigned short len = 0;
	unsigned short i,j;

	//printf("\r\n**********000000LanJiEr_ChaoBiao00000**********\r\n");

	user_init_io(9600,(INT8U *)"even",1,7 );
	IECExit();//ȷ������˳�9600�����ʣ�Ȼ���ն���300�����������¼
    close( ComPort );

	user_init_io(300,(INT8U *)"even",1,7 );   //��300�����ʽ���ͨѶ

	unsigned char jj[13];
	unsigned char tt[6];
	j=0;
	for(i=0;i<6;i++)
	{
		if(RtuDataAddr->Meter_Para.Dian_Meter[DBNo].Addr[5-i]==0)
			continue;
		tt[j++]=RtuDataAddr->Meter_Para.Dian_Meter[DBNo].Addr[5-i];
	}
	BCDToASC(&tt[0],j,jj);
	printf("%s\r\n",jj);

	Trn645Buff[len++]='/';
	Trn645Buff[len++]='?';
	//for(i=0;i<j*2;i++)

	Trn645Buff[len++]=jj[0];//���Ա���ַ96557926
	Trn645Buff[len++]=jj[1];
	Trn645Buff[len++]=jj[2];
	Trn645Buff[len++]=jj[3];
	Trn645Buff[len++]=jj[4];
	Trn645Buff[len++]=jj[5];
	Trn645Buff[len++]=jj[6];
	Trn645Buff[len++]=jj[7];
	Trn645Buff[len++]='!';
	Trn645Buff[len++]=0xd;
	Trn645Buff[len++]=0xa;
	SendStrTo485(Trn645Buff,len);
	//printf("\r\nSend len==%d:",len);
	//Pprintf(Trn645Buff,len);
	delay(100);

	len = ReceiveFrom485(Rec645Buff);
	//printf("\r\n000receive len==%d:",len);
	//Pprintf(Rec645Buff,len);

	if((Rec645Buff[0] == '/')&&('5' == Rec645Buff[4])) //ȷ��Ϊ����ʶ��֡�� ��5����ʾ������Ϊ9600
	{
		iec_read_data(DBNo);
		IECExit();
		close( ComPort );
	}
}
