#ifndef IEC6205621_H_
#define IEC6205621_H_

#endif /*IEC6205621_H_*/

#define SOH                1
#define STX                2
#define ETX                3
#define EOT                4
#define CR                 0x0d
#define LF                 0x0a
#define ACK                0x06

int Encrypt(const char* Password, const char* Seed, char* EncryptedPassword);
void iec_read_ZxD402(unsigned char DBNo);
