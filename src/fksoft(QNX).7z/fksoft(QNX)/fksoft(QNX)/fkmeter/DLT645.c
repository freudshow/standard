
#include "DLT645.h"
#include "fkmeter.h"
INT8U chaoflag=0;
extern void CleardeadCount();
extern void pro_ERR33(unsigned short i,unsigned char chg[14],unsigned char stat[14]);
extern void Pro_ERC31(unsigned short i);
unsigned char Dlt645GetVlue(unsigned char *Addr,unsigned char DI1,unsigned char DI0,unsigned char *Dest,unsigned char GetNum)
{
	//����
	unsigned char i,j,Check=0,len;
	Dlt645Dbg("\n print from Dlt645GetVlue \n\r");
	len=0;
	Check=0;
	///CleardeadCount();
	//��֯���ͱ���
	Trn645Buff[len++]=0xFE;
	Trn645Buff[len++]=0xFE;
	Trn645Buff[len++]=0xFE;
	Trn645Buff[len++]=0xFE;
	Trn645Buff[len++]=0x68;
	//-----------------------
	Trn645Buff[len++]=Addr[0];//0x12;
	Trn645Buff[len++]=Addr[1];//0x10;
	Trn645Buff[len++]=Addr[2];//0x18;
	Trn645Buff[len++]=Addr[3];//0x04;
	Trn645Buff[len++]=Addr[4];//0x00;
	Trn645Buff[len++]=Addr[5];//0x00;
/*
	Trn645Buff[len++]=0x12;
	Trn645Buff[len++]=0x10;
	Trn645Buff[len++]=0x18;
	Trn645Buff[len++]=0x04;
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x00;
*/
	//----------------------
	Trn645Buff[len++]=0x68;
	Trn645Buff[len++]=0x01;
	Trn645Buff[len++]=0x02;
	Trn645Buff[len++]=0x33+DI0;
	Trn645Buff[len++]=0x33+DI1;
	for(i=4;i<16;i++)
		Check+=Trn645Buff[i];
	Trn645Buff[len++]=(unsigned char)(Check&0xff);
	Trn645Buff[len++]=0x16;
	SendStrTo485(Trn645Buff,len);

	//���ͱ���
	//����
	delay(500);

	len=ReceiveFrom485(Rec645Buff);
	Dlt645Dbg("\n ReceiveFrom485 DataNum = %d \n\r",len);

	for(i=0;i<len;i++)
	{
		if(Rec645Buff[i]==0x68)
			break;
	}
	if(len>=(i+9))
	{
		if(Rec645Buff[i+8]!=0x81)
		{
			//Dlt645Dbg(DebugComm,"\r\n�����ݻ�Ӧ");
			memset(Dest,0,GetNum);
			return 0;
		}
		GetLen=Rec645Buff[i+9];
	}
	else
	{
		return 1;
	}
	if(len>=(i+GetLen+12))
	{
		Check=0x00;
		for(j=0;j<(GetLen+10);j++)
		{
			Check=Check+Rec645Buff[i+j];
		}
		if(Check==Rec645Buff[i+GetLen+10])
		{
			if((Rec645Buff[i+10]!=(DI0+0x33))||(Rec645Buff[i+11]!=(DI1+0x33)))
			{
				memset(Dest,0,GetNum);
				return 0;
			}
			for(j=0;j<GetNum;j++)
			{
				Rec645Buff[i+12+j]=Rec645Buff[i+12+j]-0x33;
			}
			memset(Dest,0,GetNum);
			if(GetNum>(GetLen-2))
			{
				memcpy(Dest,&Rec645Buff[i+12],GetLen-3);
			}
			else
			{
				memcpy(Dest,&Rec645Buff[i+12],GetNum);
			}

			return 0;
		}
		else
		{
			return 1;
		}
	}
	else
	{
		return 1;
	}
}
void GetDemand_N_Set_Value(unsigned char DDNo)
{
	TS ts;
	if(DDNo>=RtuDataAddr->Meter_Para.Metet_jiaoliu_Num)
		return;

	Dlt645Dbg("\n GetDemand_N_Set_Value\n\r");//����
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x90,0x1f,Demand_N_Set_Value.N_Z_P_All,sizeof(Demand_N_Set_Value.N_Z_P_All)*(FeiLvNum+1))){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x90,0x2f,Demand_N_Set_Value.N_F_P_All,sizeof(Demand_N_Set_Value.N_F_P_All)*(FeiLvNum+1))){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x91,0x1f,Demand_N_Set_Value.N_Z_Q_All,sizeof(Demand_N_Set_Value.N_Z_Q_All)*(FeiLvNum+1))){read485ERR[DDNo]++;}
	CleardeadCount();
	if(((Demand_N_Set_Value.N_Z_Q_All[0]==0)&&(Demand_N_Set_Value.N_Z_Q_All[1]==0)&&(Demand_N_Set_Value.N_Z_Q_All[2]==0)
		&&(Demand_N_Set_Value.N_Z_Q_All[3]==0))||((Demand_N_Set_Value.N_Z_Q_All[0]==0xFF)&&(Demand_N_Set_Value.N_Z_Q_All[1]==0xFF)&&(Demand_N_Set_Value.N_Z_Q_All[2]==0xFF)
				&&(Demand_N_Set_Value.N_Z_Q_All[3]==0xFF)))
	{
	    //�����޹��ܵ��ܣ���ʤ�����ܳ�911f������޸ġ�
	    if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x91,0x10,Demand_N_Set_Value.N_Z_Q_All,sizeof(Demand_N_Set_Value.N_Z_Q_All))){read485ERR[DDNo]++;}
		CleardeadCount();
	}


	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x91,0x2f,Demand_N_Set_Value.N_F_Q_All,sizeof(Demand_N_Set_Value.N_F_Q_All)*(FeiLvNum+1))){read485ERR[DDNo]++;}
	CleardeadCount();
	if(((Demand_N_Set_Value.N_F_Q_All[0]==0)&&(Demand_N_Set_Value.N_F_Q_All[1]==0)&&(Demand_N_Set_Value.N_F_Q_All[2]==0)
		&&(Demand_N_Set_Value.N_F_Q_All[3]==0))||((Demand_N_Set_Value.N_F_Q_All[0]==0xFF)&&(Demand_N_Set_Value.N_F_Q_All[1]==0xFF)&&(Demand_N_Set_Value.N_F_Q_All[2]==0xFF)
				&&(Demand_N_Set_Value.N_F_Q_All[3]==0xFF)))
	{
		//�����޹��ܵ��ܣ���ʤ�����ܳ�912f������޸ġ�
		if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x91,0x20,Demand_N_Set_Value.N_F_Q_All,sizeof(Demand_N_Set_Value.N_F_Q_All))){read485ERR[DDNo]++;}
		CleardeadCount();
	}

	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x91,0x3f,Demand_N_Set_Value.N_X1_Q_All,sizeof(Demand_N_Set_Value.N_X1_Q_All)*(FeiLvNum+1))){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x91,0x4f,Demand_N_Set_Value.N_X4_Q_All,sizeof(Demand_N_Set_Value.N_X4_Q_All)*(FeiLvNum+1))){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x91,0x5f,Demand_N_Set_Value.N_X2_Q_All,sizeof(Demand_N_Set_Value.N_X2_Q_All)*(FeiLvNum+1))){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x91,0x6f,Demand_N_Set_Value.N_X3_Q_All,sizeof(Demand_N_Set_Value.N_X3_Q_All)*(FeiLvNum+1))){read485ERR[DDNo]++;}
	CleardeadCount();
	Demand_N_Set_Value.valid=1;
	TSGet(&ts);
	Demand_N_Set_Value.Time_Chaobiao.BCD01=((ts.Minute/10)<<4)+(ts.Minute%10);
	Demand_N_Set_Value.Time_Chaobiao.BCD02=((ts.Hour/10)<<4)+(ts.Hour%10);
	Demand_N_Set_Value.Time_Chaobiao.BCD03=((ts.Day/10)<<4)+(ts.Day%10);
	Demand_N_Set_Value.Time_Chaobiao.BCD04=((ts.Month/10)<<4)+(ts.Month%10);
	Demand_N_Set_Value.Time_Chaobiao.BCD05=(((ts.Year%100)/10)<<4)+(ts.Year%10);

	return;
}
void GetMaximum_Demand_N_Set_Value(unsigned char DDNo)
{
	TS ts;

	if(DDNo>=RtuDataAddr->Meter_Para.Metet_jiaoliu_Num)
		return;
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xa0,0x1f,Maximum_Demand_N_Set_Value.N_Z_P_X_All,sizeof(Maximum_Demand_N_Set_Value.N_Z_P_X_All)*(FeiLvNum+1))){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xa0,0x2f,Maximum_Demand_N_Set_Value.N_F_P_X_All,sizeof(Maximum_Demand_N_Set_Value.N_F_P_X_All)*(FeiLvNum+1))){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xa1,0x1f,Maximum_Demand_N_Set_Value.N_Z_Q_X_All,sizeof(Maximum_Demand_N_Set_Value.N_Z_Q_X_All)*(FeiLvNum+1))){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xa1,0x2f,Maximum_Demand_N_Set_Value.N_F_Q_X_All,sizeof(Maximum_Demand_N_Set_Value.N_F_Q_X_All)*(FeiLvNum+1))){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xa1,0x3f,Maximum_Demand_N_Set_Value.N_X1_Q_X_All,sizeof(Maximum_Demand_N_Set_Value.N_X1_Q_X_All)*(FeiLvNum+1))){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xa1,0x4f,Maximum_Demand_N_Set_Value.N_X4_Q_X_All,sizeof(Maximum_Demand_N_Set_Value.N_X4_Q_X_All)*(FeiLvNum+1))){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xa1,0x5f,Maximum_Demand_N_Set_Value.N_X2_Q_X_All,sizeof(Maximum_Demand_N_Set_Value.N_X2_Q_X_All)*(FeiLvNum+1))){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xa1,0x6f,Maximum_Demand_N_Set_Value.N_X3_Q_X_All,sizeof(Maximum_Demand_N_Set_Value.N_X3_Q_X_All)*(FeiLvNum+1))){read485ERR[DDNo]++;}
	CleardeadCount();
	//wojia
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xa4,0x1f,Yue_Maximum_Demand_N_Set_Value.SY_Z_P_X_All,sizeof(Yue_Maximum_Demand_N_Set_Value.SY_Z_P_X_All)*(FeiLvNum+1))){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xa4,0x2f,Yue_Maximum_Demand_N_Set_Value.SY_F_P_X_All,sizeof(Yue_Maximum_Demand_N_Set_Value.SY_F_P_X_All)*(FeiLvNum+1))){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xa5,0x1f,Yue_Maximum_Demand_N_Set_Value.SY_Z_Q_X_All,sizeof(Yue_Maximum_Demand_N_Set_Value.SY_Z_Q_X_All)*(FeiLvNum+1))){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xa5,0x2f,Yue_Maximum_Demand_N_Set_Value.SY_F_Q_X_All,sizeof(Yue_Maximum_Demand_N_Set_Value.SY_F_Q_X_All)*(FeiLvNum+1))){read485ERR[DDNo]++;}
	CleardeadCount();
	//wojia

	Maximum_Demand_N_Set_Value.valid=1;
	Yue_Maximum_Demand_N_Set_Value.valid=1;/////
	TSGet(&ts);
	Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD01=((ts.Minute/10)<<4)+(ts.Minute%10);
	Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD02=((ts.Hour/10)<<4)+(ts.Hour%10);
	Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD03=((ts.Day/10)<<4)+(ts.Day%10);
	Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD04=((ts.Month/10)<<4)+(ts.Month%10);
	Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD05=(((ts.Year%100)/10)<<4)+(ts.Year%10);

	Yue_Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD01=((ts.Minute/10)<<4)+(ts.Minute%10);
	Yue_Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD02=((ts.Hour/10)<<4)+(ts.Hour%10);
	Yue_Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD03=((ts.Day/10)<<4)+(ts.Day%10);
	Yue_Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD04=((ts.Month/10)<<4)+(ts.Month%10);
	Yue_Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD05=(((ts.Year%100)/10)<<4)+(ts.Year%10);
	return;
}
void GetMaximum_Demand_Time_N_Set_Value(unsigned char DDNo)
{
	TS ts;
	if(DDNo>=RtuDataAddr->Meter_Para.Metet_jiaoliu_Num)
		return;
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xb0,0x1f,Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_All,sizeof(Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_All)*(FeiLvNum+1))){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xb0,0x2f,Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_All,sizeof(Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_All)*(FeiLvNum+1))){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xb1,0x1f,Maximum_Demand_Time_N_Set_Value.Time_N_Z_Q_X_All,sizeof(Maximum_Demand_Time_N_Set_Value.Time_N_Z_Q_X_All)*(FeiLvNum+1))){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xb1,0x2f,Maximum_Demand_Time_N_Set_Value.Time_N_F_Q_X_All,sizeof(Maximum_Demand_Time_N_Set_Value.Time_N_F_Q_X_All)*(FeiLvNum+1))){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xb1,0x3f,Maximum_Demand_Time_N_Set_Value.Time_N_X1_Q_X_All,sizeof(Maximum_Demand_Time_N_Set_Value.Time_N_X1_Q_X_All)*(FeiLvNum+1))){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xb1,0x4f,Maximum_Demand_Time_N_Set_Value.Time_N_X4_Q_X_All,sizeof(Maximum_Demand_Time_N_Set_Value.Time_N_X4_Q_X_All)*(FeiLvNum+1))){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xb1,0x5f,Maximum_Demand_Time_N_Set_Value.Time_N_X2_Q_X_All,sizeof(Maximum_Demand_Time_N_Set_Value.Time_N_X2_Q_X_All)*(FeiLvNum+1))){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xb1,0x6f,Maximum_Demand_Time_N_Set_Value.Time_N_X3_Q_X_All,sizeof(Maximum_Demand_Time_N_Set_Value.Time_N_X3_Q_X_All)*(FeiLvNum+1))){read485ERR[DDNo]++;}
	CleardeadCount();
	//wojia

	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xb4,0x1f,Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_Z_P_X_All,sizeof(Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_Z_P_X_All)*(FeiLvNum+1))){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xb4,0x2f,Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_F_P_X_All,sizeof(Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_F_P_X_All)*(FeiLvNum+1))){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xb5,0x1f,Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_Z_Q_X_All,sizeof(Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_Z_Q_X_All)*(FeiLvNum+1))){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xb5,0x2f,Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_F_Q_X_All,sizeof(Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_F_Q_X_All)*(FeiLvNum+1))){read485ERR[DDNo]++;}
	CleardeadCount();
	//wojia

	Maximum_Demand_Time_N_Set_Value.valid=1;
	Yue_Maximum_Demand_Time_N_Set_Value.valid=1;/////
	TSGet(&ts);
	Maximum_Demand_Time_N_Set_Value.Time_Chaobiao.BCD01=((ts.Minute/10)<<4)+(ts.Minute%10);
	Maximum_Demand_Time_N_Set_Value.Time_Chaobiao.BCD02=((ts.Hour/10)<<4)+(ts.Hour%10);
	Maximum_Demand_Time_N_Set_Value.Time_Chaobiao.BCD03=((ts.Day/10)<<4)+(ts.Day%10);
	Maximum_Demand_Time_N_Set_Value.Time_Chaobiao.BCD04=((ts.Month/10)<<4)+(ts.Month%10);
	Maximum_Demand_Time_N_Set_Value.Time_Chaobiao.BCD05=(((ts.Year%100)/10)<<4)+(ts.Year%10);

	Yue_Maximum_Demand_Time_N_Set_Value.Time_Chaobiao.BCD01=((ts.Minute/10)<<4)+(ts.Minute%10);
	Yue_Maximum_Demand_Time_N_Set_Value.Time_Chaobiao.BCD02=((ts.Hour/10)<<4)+(ts.Hour%10);
	Yue_Maximum_Demand_Time_N_Set_Value.Time_Chaobiao.BCD03=((ts.Day/10)<<4)+(ts.Day%10);
	Yue_Maximum_Demand_Time_N_Set_Value.Time_Chaobiao.BCD04=((ts.Month/10)<<4)+(ts.Month%10);
	Yue_Maximum_Demand_Time_N_Set_Value.Time_Chaobiao.BCD05=(((ts.Year%100)/10)<<4)+(ts.Year%10);
	return;
}
void GetVariable_Set_value(unsigned char DDNo)
{
	TS ts;

	if(DDNo>=RtuDataAddr->Meter_Para.Metet_jiaoliu_Num)
		return;

	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xb2,0x1f,Variable_Set_value.Time_LastProg,15)){read485ERR[DDNo]++;}
//--------------
	//if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xb2,0x10,Variable_Set_value.Time_LastProg,4)){read485ERR[DDNo]++;}
	//if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xb2,0x11,Variable_Set_value.Time_LastZero,4)){read485ERR[DDNo]++;}
	//if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xb2,0x12,Variable_Set_value.ProgNum,2)){read485ERR[DDNo]++;}
	//if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xb2,0x13,Variable_Set_value.ZeroNum,2)){read485ERR[DDNo]++;}
	//if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xb2,0x14,Variable_Set_value.Time_Battery,3)){read485ERR[DDNo]++;}
	//���ô��� 2
//--------------
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xb3,0x1f,Variable_Set_value.Duanxiang_All,8)){read485ERR[DDNo]++;}
//--------------
	//if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xb3,0x10,Variable_Set_value.Duanxiang_All,2)){read485ERR[DDNo]++;}
	//if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xb3,0x11,Variable_Set_value.A_Duan,2)){read485ERR[DDNo]++;}
	//if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xb3,0x12,Variable_Set_value.B_Duan,2)){read485ERR[DDNo]++;}
	//if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xb3,0x13,Variable_Set_value.C_Duan,2)){read485ERR[DDNo]++;}
	//���ô��� 4
//--------------
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xb3,0x2f,Variable_Set_value.Time_Duanxiang,12)){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xb3,0x3f,Variable_Set_value.Time_LastDuan_S,16)){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xb3,0x4f,Variable_Set_value.Time_LastDuan_E,16)){read485ERR[DDNo]++;}
	CleardeadCount();
//	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xb6,0x1f,Variable_Set_value.VA,6)){read485ERR[DDNo]++;}
//	CleardeadCount();

	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xb6,0x11,Variable_Set_value.VA,2)){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xb6,0x12,Variable_Set_value.VB,2)){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xb6,0x13,Variable_Set_value.VC,2)){read485ERR[DDNo]++;}
	CleardeadCount();

//	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xb6,0x2f,Variable_Set_value.IA,6)){read485ERR[DDNo]++;}
//	CleardeadCount();

	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xb6,0x21,Variable_Set_value.IA,2)){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xb6,0x22,Variable_Set_value.IB,2)){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xb6,0x23,Variable_Set_value.IC,2)){read485ERR[DDNo]++;}
	CleardeadCount();

	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xb6,0x3f,Variable_Set_value.P,16)){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xb6,0x4f,Variable_Set_value.Q,8)){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xb6,0x5f,Variable_Set_value.Cos,8)){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xc0,0x2f,&Variable_Set_value.Dian_biao_stat,3)){read485ERR[DDNo]++;}
//-------------------
	//if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xc0,0x20,&Variable_Set_value.Dian_biao_stat,1)){read485ERR[DDNo]++;}
	//if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xc0,0x21,&Variable_Set_value.Dian_wang_stat,1)){read485ERR[DDNo]++;}
	//if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xc0,0x22,&Variable_Set_value.Zhou_xiu_stat,1)){read485ERR[DDNo]++;}
	// ���ô��� 3
//-------------------
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xc0,0x3f,&Variable_Set_value.Dian_biao_changshu_P[0],24)){read485ERR[DDNo]++;}
//---------
	//if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xc0,0x30,&Variable_Set_value.Dian_biao_changshu_P[0],3)){read485ERR[DDNo]++;}
	//if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xc0,0x31,&Variable_Set_value.Dian_biao_changshu_Q[0],3)){read485ERR[DDNo]++;}
	//if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xc0,0x32,&Variable_Set_value.Dian_biao_hao[0],6)){read485ERR[DDNo]++;}
	//if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xc0,0x33,&Variable_Set_value.Yong_hu_hao[0],6)){read485ERR[DDNo]++;}
	//if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xc0,0x34,&Variable_Set_value.She_bei_ma[0],6)){read485ERR[DDNo]++;}
	//���ô���
//---------
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xc1,0x1f,&Variable_Set_value.Zhou_qi_xu_liang,17)){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xc1,0x17,Variable_Set_value.Chao_biao_riqi,2)){read485ERR[DDNo]++;}
	CleardeadCount();

	clock_gettime(CLOCK_REALTIME, &now_tp);
	//printf("\n\r %d",now_tp.tv_sec);
	//printf("\n\r 2Begin  shijian chaocha jisuan\n\r\n\r");
	//printf("\n\r 2");
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xc0,0x1f,Variable_Set_value.Date_Week,7)){read485ERR[DDNo]++;}
//-----------
	//if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xc0,0x10,Variable_Set_value.Date_Week,4)){read485ERR[DDNo]++;}
	//if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xc0,0x11,Variable_Set_value.Now_Time,3)){read485ERR[DDNo]++;}
	//���ô��� 5
//-----------
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xc3,0x1f,&Variable_Set_value.Year_ShiQu,5)){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xc3,0x2f,Variable_Set_value.c320,30)){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xc3,0x3f,Variable_Set_value.c330,30)){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xc3,0x4f,Variable_Set_value.c340,30)){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xc3,0x5f,Variable_Set_value.c350,30)){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xc3,0x6f,Variable_Set_value.c360,30)){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xc3,0x7f,Variable_Set_value.c370,30)){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xc3,0x8f,Variable_Set_value.c380,30)){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xc3,0x9f,Variable_Set_value.c390,30)){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xc3,0xaf,Variable_Set_value.c3a0,30)){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xc4,0x1f,Variable_Set_value.c410,30)){read485ERR[DDNo]++;}
	CleardeadCount();
	if(Dlt645GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0xc4,0x1E,&Variable_Set_value.c41e,1)){read485ERR[DDNo]++;}
	CleardeadCount();
	Variable_Set_value.valid=1;
	TSGet(&ts);
	Variable_Set_value.Time_Chaobiao.BCD01=((ts.Minute/10)<<4)+(ts.Minute%10);
	Variable_Set_value.Time_Chaobiao.BCD02=((ts.Hour/10)<<4)+(ts.Hour%10);
	Variable_Set_value.Time_Chaobiao.BCD03=((ts.Day/10)<<4)+(ts.Day%10);
	Variable_Set_value.Time_Chaobiao.BCD04=((ts.Month/10)<<4)+(ts.Month%10);
	Variable_Set_value.Time_Chaobiao.BCD05=(((ts.Year%100)/10)<<4)+(ts.Year%10);

	return;
}
void DLT645_Data_Calc(unsigned char DDNo)
{
	unsigned char Num;
	unsigned char statmp[14],chgtmp[14];
	unsigned char tmp ,ERRCreate;

	if(RtuDataAddr->Meter_Para.Valid!=1)
		return;
	if(RtuDataAddr->Meter_Para.Metet_jiaoliu_Num>CeLiangPoint_Max)
		return;
	if(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].GuiYue_Type==1)
	{
		Num=RtuDataAddr->Meter_Para.Dian_Meter[DDNo].CeLiangNo-1;
		if(Num>CeLiangPoint_Max)
			return;

		if(Demand_N_Set_Value.valid==1)
		{
			memcpy(&RtuDataAddr->DD_Device_BiaoShi_Value[Num].Chao_Time.BCD01,&Demand_N_Set_Value.Time_Chaobiao.BCD01,5);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_All=BCDTo_INT32(Demand_N_Set_Value.N_Z_P_All,4);

	/*		if(old_z_p_all[Num]==0&&RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_All==800191)
			{//���Դ���
				if(chaoflag==0)
				{
					RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_All=800000;
					chaoflag=1;
				}
			}
			old_z_p_all[Num]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_All;*/
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_F[0]=BCDTo_INT32(Demand_N_Set_Value.N_Z_P_F[0],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_F[1]=BCDTo_INT32(Demand_N_Set_Value.N_Z_P_F[1],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_F[2]=BCDTo_INT32(Demand_N_Set_Value.N_Z_P_F[2],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_F[3]=BCDTo_INT32(Demand_N_Set_Value.N_Z_P_F[3],4);

			RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_All=BCDTo_INT32(Demand_N_Set_Value.N_F_P_All,4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_F[0]=BCDTo_INT32(Demand_N_Set_Value.N_F_P_F[0],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_F[1]=BCDTo_INT32(Demand_N_Set_Value.N_F_P_F[1],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_F[2]=BCDTo_INT32(Demand_N_Set_Value.N_F_P_F[2],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_F[3]=BCDTo_INT32(Demand_N_Set_Value.N_F_P_F[3],4);

			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_All=BCDTo_INT32(Demand_N_Set_Value.N_Z_Q_All,4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_F[0]=BCDTo_INT32(Demand_N_Set_Value.N_Z_Q_F[0],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_F[1]=BCDTo_INT32(Demand_N_Set_Value.N_Z_Q_F[1],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_F[2]=BCDTo_INT32(Demand_N_Set_Value.N_Z_Q_F[2],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_F[3]=BCDTo_INT32(Demand_N_Set_Value.N_Z_Q_F[3],4);

			RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_All=BCDTo_INT32(Demand_N_Set_Value.N_F_Q_All,4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_F[0]=BCDTo_INT32(Demand_N_Set_Value.N_F_Q_F[0],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_F[1]=BCDTo_INT32(Demand_N_Set_Value.N_F_Q_F[1],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_F[2]=BCDTo_INT32(Demand_N_Set_Value.N_F_Q_F[2],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_F[3]=BCDTo_INT32(Demand_N_Set_Value.N_F_Q_F[3],4);

			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X1_Q_All=BCDTo_INT32(Demand_N_Set_Value.N_X1_Q_All,4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X1_F_Q[0]=BCDTo_INT32(Demand_N_Set_Value.N_X1_Q_F[0],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X1_F_Q[1]=BCDTo_INT32(Demand_N_Set_Value.N_X1_Q_F[1],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X1_F_Q[2]=BCDTo_INT32(Demand_N_Set_Value.N_X1_Q_F[2],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X1_F_Q[3]=BCDTo_INT32(Demand_N_Set_Value.N_X1_Q_F[3],4);

			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X4_Q_All=BCDTo_INT32(Demand_N_Set_Value.N_X4_Q_All,4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X4_F_Q[0]=BCDTo_INT32(Demand_N_Set_Value.N_X4_Q_F[0],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X4_F_Q[1]=BCDTo_INT32(Demand_N_Set_Value.N_X4_Q_F[1],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X4_F_Q[2]=BCDTo_INT32(Demand_N_Set_Value.N_X4_Q_F[2],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X4_F_Q[3]=BCDTo_INT32(Demand_N_Set_Value.N_X4_Q_F[3],4);

			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X2_Q_All=BCDTo_INT32(Demand_N_Set_Value.N_X2_Q_All,4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X2_F_Q[0]=BCDTo_INT32(Demand_N_Set_Value.N_X2_Q_F[0],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X2_F_Q[1]=BCDTo_INT32(Demand_N_Set_Value.N_X2_Q_F[1],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X2_F_Q[2]=BCDTo_INT32(Demand_N_Set_Value.N_X2_Q_F[2],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X2_F_Q[3]=BCDTo_INT32(Demand_N_Set_Value.N_X2_Q_F[3],4);

			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X3_Q_All=BCDTo_INT32(Demand_N_Set_Value.N_X3_Q_All,4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X3_F_Q[0]=BCDTo_INT32(Demand_N_Set_Value.N_X3_Q_F[0],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X3_F_Q[1]=BCDTo_INT32(Demand_N_Set_Value.N_X3_Q_F[1],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X3_F_Q[2]=BCDTo_INT32(Demand_N_Set_Value.N_X3_Q_F[2],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].X3_F_Q[3]=BCDTo_INT32(Demand_N_Set_Value.N_X3_Q_F[3],4);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Valid=1;
		}

		if(Maximum_Demand_N_Set_Value.valid==1)
		{
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Chao_Time.BCD01,&Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD01,5);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_P_X_All=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_Z_P_X_All,3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_P_X_F[0]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_Z_P_X_F[0],3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_P_X_F[1]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_Z_P_X_F[1],3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_P_X_F[2]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_Z_P_X_F[2],3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_P_X_F[3]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_Z_P_X_F[3],3);

			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_P_X_All=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_F_P_X_All,3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_P_X_F[0]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_F_P_X_F[0],3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_P_X_F[1]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_F_P_X_F[1],3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_P_X_F[2]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_F_P_X_F[2],3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_P_X_F[3]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_F_P_X_F[3],3);

			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_Q_X_All=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_Z_Q_X_All,3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_Q_X_F[0]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_Z_Q_X_F[0],3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_Q_X_F[1]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_Z_Q_X_F[1],3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_Q_X_F[2]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_Z_Q_X_F[2],3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_Q_X_F[3]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_Z_Q_X_F[3],3);

			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_Q_X_All=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_F_Q_X_All,3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_Q_X_F[0]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_F_Q_X_F[0],3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_Q_X_F[1]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_F_Q_X_F[1],3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_Q_X_F[2]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_F_Q_X_F[2],3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_Q_X_F[3]=BCDTo_INT32(Maximum_Demand_N_Set_Value.N_F_Q_X_F[3],3);
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Valid=1;
		}

		if(Yue_Maximum_Demand_N_Set_Value.valid==1)
		{
			//wojia
			memcpy(&RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].Chao_Time.BCD01,&Yue_Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD01,5);

			RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].SY_Z_P_X_All=BCDTo_INT32(Yue_Maximum_Demand_N_Set_Value.SY_Z_P_X_All,3);
			RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].SY_Z_P_X_F[0]=BCDTo_INT32(Yue_Maximum_Demand_N_Set_Value.SY_Z_P_X_F[0],3);
			RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].SY_Z_P_X_F[1]=BCDTo_INT32(Yue_Maximum_Demand_N_Set_Value.SY_Z_P_X_F[1],3);
			RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].SY_Z_P_X_F[2]=BCDTo_INT32(Yue_Maximum_Demand_N_Set_Value.SY_Z_P_X_F[2],3);
			RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].SY_Z_P_X_F[3]=BCDTo_INT32(Yue_Maximum_Demand_N_Set_Value.SY_Z_P_X_F[3],3);

			RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].SY_F_P_X_All=BCDTo_INT32(Yue_Maximum_Demand_N_Set_Value.SY_F_P_X_All,3);
			RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].SY_F_P_X_F[0]=BCDTo_INT32(Yue_Maximum_Demand_N_Set_Value.SY_F_P_X_F[0],3);
			RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].SY_F_P_X_F[1]=BCDTo_INT32(Yue_Maximum_Demand_N_Set_Value.SY_F_P_X_F[1],3);
			RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].SY_F_P_X_F[2]=BCDTo_INT32(Yue_Maximum_Demand_N_Set_Value.SY_F_P_X_F[2],3);
			RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].SY_F_P_X_F[3]=BCDTo_INT32(Yue_Maximum_Demand_N_Set_Value.SY_F_P_X_F[3],3);

			RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].SY_Z_Q_X_All=BCDTo_INT32(Yue_Maximum_Demand_N_Set_Value.SY_Z_Q_X_All,3);
			RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].SY_Z_Q_X_F[0]=BCDTo_INT32(Yue_Maximum_Demand_N_Set_Value.SY_Z_Q_X_F[0],3);
			RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].SY_Z_Q_X_F[1]=BCDTo_INT32(Yue_Maximum_Demand_N_Set_Value.SY_Z_Q_X_F[1],3);
			RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].SY_Z_Q_X_F[2]=BCDTo_INT32(Yue_Maximum_Demand_N_Set_Value.SY_Z_Q_X_F[2],3);
			RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].SY_Z_Q_X_F[3]=BCDTo_INT32(Yue_Maximum_Demand_N_Set_Value.SY_Z_Q_X_F[3],3);

			RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].SY_F_Q_X_All=BCDTo_INT32(Yue_Maximum_Demand_N_Set_Value.SY_F_Q_X_All,3);
			RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].SY_F_Q_X_F[0]=BCDTo_INT32(Yue_Maximum_Demand_N_Set_Value.SY_F_Q_X_F[0],3);
			RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].SY_F_Q_X_F[1]=BCDTo_INT32(Yue_Maximum_Demand_N_Set_Value.SY_F_Q_X_F[1],3);
			RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].SY_F_Q_X_F[2]=BCDTo_INT32(Yue_Maximum_Demand_N_Set_Value.SY_F_Q_X_F[2],3);
			RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].SY_F_Q_X_F[3]=BCDTo_INT32(Yue_Maximum_Demand_N_Set_Value.SY_F_Q_X_F[3],3);

			RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].Valid=1;
			//wojia
		}

		if(Maximum_Demand_Time_N_Set_Value.valid==1)
		{
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Chao_Time.BCD01,&Maximum_Demand_Time_N_Set_Value.Time_Chaobiao.BCD01,5);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_P_X_All[0],&Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_All[0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_P_X_F[0][0],&Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_F[0][0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_P_X_F[1][0],&Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_F[1][0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_P_X_F[2][0],&Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_F[2][0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_P_X_F[3][0],&Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_F[3][0],4);

			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_P_X_All[0],&Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_All[0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_P_X_F[0][0],&Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_F[0][0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_P_X_F[1][0],&Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_F[1][0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_P_X_F[2][0],&Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_F[2][0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_P_X_F[3][0],&Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_F[3][0],4);

			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_Q_X_All[0],&Maximum_Demand_Time_N_Set_Value.Time_N_Z_Q_X_All[0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_Q_X_F[0][0],&Maximum_Demand_Time_N_Set_Value.Time_N_Z_Q_X_F[0][0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_Q_X_F[1][0],&Maximum_Demand_Time_N_Set_Value.Time_N_Z_Q_X_F[1][0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_Q_X_F[2][0],&Maximum_Demand_Time_N_Set_Value.Time_N_Z_Q_X_F[2][0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_Q_X_F[3][0],&Maximum_Demand_Time_N_Set_Value.Time_N_Z_Q_X_F[3][0],4);

			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_Q_X_All[0],&Maximum_Demand_Time_N_Set_Value.Time_N_F_Q_X_All[0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_Q_X_F[0][0],&Maximum_Demand_Time_N_Set_Value.Time_N_F_Q_X_F[0][0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_Q_X_F[1][0],&Maximum_Demand_Time_N_Set_Value.Time_N_F_Q_X_F[1][0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_Q_X_F[2][0],&Maximum_Demand_Time_N_Set_Value.Time_N_F_Q_X_F[2][0],4);
			memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_Q_X_F[3][0],&Maximum_Demand_Time_N_Set_Value.Time_N_F_Q_X_F[3][0],4);

			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].UAJ=0;
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].UBJ=1200;
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].UCJ=2400;
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].IAJ=0;
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].IBJ=1200;
			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].ICJ=2400;


			RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Valid=1;
		}
		if(Yue_Maximum_Demand_Time_N_Set_Value.valid==1)
		{
			//wojia
			memcpy(&RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].Chao_Time.BCD01,&Yue_Maximum_Demand_Time_N_Set_Value.Time_Chaobiao.BCD01,5);
			memcpy(&RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].Time_SY_Z_P_X_All[0],&Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_Z_P_X_All[0],4);
			memcpy(&RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].Time_SY_Z_P_X_F[0][0],&Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_Z_P_X_F[0][0],4);
			memcpy(&RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].Time_SY_Z_P_X_F[1][0],&Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_Z_P_X_F[1][0],4);
			memcpy(&RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].Time_SY_Z_P_X_F[2][0],&Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_Z_P_X_F[2][0],4);
			memcpy(&RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].Time_SY_Z_P_X_F[3][0],&Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_Z_P_X_F[3][0],4);

			memcpy(&RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].Time_SY_F_P_X_All[0],&Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_F_P_X_All[0],4);
			memcpy(&RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].Time_SY_F_P_X_F[0][0],&Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_F_P_X_F[0][0],4);
			memcpy(&RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].Time_SY_F_P_X_F[1][0],&Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_F_P_X_F[1][0],4);
			memcpy(&RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].Time_SY_F_P_X_F[2][0],&Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_F_P_X_F[2][0],4);
			memcpy(&RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].Time_SY_F_P_X_F[3][0],&Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_F_P_X_F[3][0],4);

			memcpy(&RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].Time_SY_Z_Q_X_All[0],&Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_Z_Q_X_All[0],4);
			memcpy(&RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].Time_SY_Z_Q_X_F[0][0],&Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_Z_Q_X_F[0][0],4);
			memcpy(&RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].Time_SY_Z_Q_X_F[1][0],&Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_Z_Q_X_F[1][0],4);
			memcpy(&RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].Time_SY_Z_Q_X_F[2][0],&Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_Z_Q_X_F[2][0],4);
			memcpy(&RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].Time_SY_Z_Q_X_F[3][0],&Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_Z_Q_X_F[3][0],4);

			memcpy(&RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].Time_SY_F_Q_X_All[0],&Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_F_Q_X_All[0],4);
			memcpy(&RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].Time_SY_F_Q_X_F[0][0],&Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_F_Q_X_F[0][0],4);
			memcpy(&RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].Time_SY_F_Q_X_F[1][0],&Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_F_Q_X_F[1][0],4);
			memcpy(&RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].Time_SY_F_Q_X_F[2][0],&Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_F_Q_X_F[2][0],4);
			memcpy(&RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].Time_SY_F_Q_X_F[3][0],&Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_F_Q_X_F[3][0],4);
			RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].Valid=1;
			//wojia

		}

		if(Variable_Set_value.valid==1)
		{
			memcpy(&RtuDataAddr->DD_Device_BiaoShi_Value[Num].Chao_Time.BCD01,&Variable_Set_value.Time_Chaobiao.BCD01,5);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Cos=BCDTo_INT32(Variable_Set_value.Cos,2);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].CosA=BCDTo_INT32(Variable_Set_value.CosA,2);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].CosB=BCDTo_INT32(Variable_Set_value.CosB,2);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].CosC=BCDTo_INT32(Variable_Set_value.CosC,2);

			RtuDataAddr->DD_Device_BiaoShi_Value[Num].IA=BCDTo_INT32(Variable_Set_value.IA,2);//0.01A

			RtuDataAddr->DD_Device_BiaoShi_Value[Num].IB=BCDTo_INT32(Variable_Set_value.IB,2);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].IC=BCDTo_INT32(Variable_Set_value.IC,2);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].VA=BCDTo_INT32(Variable_Set_value.VA,2)*10;//0.1V
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].VB=BCDTo_INT32(Variable_Set_value.VB,2)*10;
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].VC=BCDTo_INT32(Variable_Set_value.VC,2)*10;
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].P=BCDTo_INT32(Variable_Set_value.P,3);//��λС��
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].PA=BCDTo_INT32(Variable_Set_value.PA,3);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].PB=BCDTo_INT32(Variable_Set_value.PB,3);
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].PC=BCDTo_INT32(Variable_Set_value.PC,3);

			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Q=BCDTo_INT32(Variable_Set_value.Q,2)*100;
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].QA=BCDTo_INT32(Variable_Set_value.QA,2)*100;
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].QB=BCDTo_INT32(Variable_Set_value.QB,2)*100;
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].QC=BCDTo_INT32(Variable_Set_value.QC,2)*100;


			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].Chao_Time.BCD01,&Variable_Set_value.Time_Chaobiao.BCD01,5);
			//-------------------------------------------->
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].Date_Week[0],&Variable_Set_value.Date_Week[0],4);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].Now_Time[0],&Variable_Set_value.Now_Time[0],3);
			//--------------------------------------------<
			tmp=Variable_Set_value.Date_Week[0];
			//date transform
			RtuDataAddr->DD_BianLiang_Shuju[Num].NowDB_Time.BCDSec  = Variable_Set_value.Now_Time[0];
			RtuDataAddr->DD_BianLiang_Shuju[Num].NowDB_Time.BCDMin  = Variable_Set_value.Now_Time[1];
			RtuDataAddr->DD_BianLiang_Shuju[Num].NowDB_Time.BCDHour = Variable_Set_value.Now_Time[2];
			RtuDataAddr->DD_BianLiang_Shuju[Num].NowDB_Time.BCDDay  = Variable_Set_value.Date_Week[1];
			RtuDataAddr->DD_BianLiang_Shuju[Num].NowDB_Time.BCDMon  = (Variable_Set_value.Date_Week[2]);//|((Variable_Set_value.Date_Week[0]<<5)&0xe0);
			RtuDataAddr->DD_BianLiang_Shuju[Num].NowDB_Time.BCDYear = Variable_Set_value.Date_Week[3];


			//RtuDataAddr->DD_BianLiang_Shuju[Num].Dian_biao_stat=Variable_Set_value.Dian_biao_stat;
			RtuDataAddr->DD_BianLiang_Shuju[Num].Dian_wang_stat=Variable_Set_value.Dian_wang_stat;
			RtuDataAddr->DD_BianLiang_Shuju[Num].LastProg_Time[0]=0;
			RtuDataAddr->DD_BianLiang_Shuju[Num].LastProg_Time[5]=0;
			RtuDataAddr->DD_BianLiang_Shuju[Num].LastZero_Time[0]=0;
		    RtuDataAddr->DD_BianLiang_Shuju[Num].LastZero_Time[5]=0;
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].LastProg_Time[1],&Variable_Set_value.Time_LastProg[0],4);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].LastZero_Time[1],&Variable_Set_value.Time_LastZero[0],4);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].ProgNum[0],&Variable_Set_value.ProgNum[0],2);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].ZeroNum[0],&Variable_Set_value.ZeroNum[0],2);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].BatteryTime[0],&Variable_Set_value.Time_Battery[0],3);
			//

			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].Duanxiang_All[0],&Variable_Set_value.Duanxiang_All[0],2);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].A_Duan[0],&Variable_Set_value.A_Duan[0],2);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].B_Duan[0],&Variable_Set_value.B_Duan[0],2);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].C_Duan[0],&Variable_Set_value.C_Duan[0],2);

			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].Duanxiang_Time[0],&Variable_Set_value.Time_Duanxiang[0],3);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].A_Duan_Time[0],&Variable_Set_value.A_Duan_Time[0],3);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].B_Duan_Time[0],&Variable_Set_value.B_Duan_Time[0],3);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].C_Duan_Time[0],&Variable_Set_value.C_Duan_Time[0],3);

			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].LastDuan_S_Time[0],&Variable_Set_value.Time_LastDuan_S[0],4);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].ADuan_S_Time[0],&Variable_Set_value.Time_ADuan_S[0],4);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].BDuan_S_Time[0],&Variable_Set_value.Time_BDuan_S[0],4);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].CDuan_S_Time[0],&Variable_Set_value.Time_CDuan_S[0],4);

			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].LastDuan_E_Time[0],&Variable_Set_value.Time_LastDuan_E[0],4);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].ADuan_E_Time[0],&Variable_Set_value.Time_ADuan_E[0],4);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].BDuan_E_Time[0],&Variable_Set_value.Time_BDuan_E[0],4);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].CDuan_E_Time[0],&Variable_Set_value.Time_CDuan_E[0],4);
//////////////////////yyx add 2004 4 6
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].PChangShu[0],&Variable_Set_value.Dian_biao_changshu_P[0],3);
			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].QChangShu[0],&Variable_Set_value.Dian_biao_changshu_Q[0],3);

			memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].Chao_biao_riqi[0],&Variable_Set_value.Chao_biao_riqi[0],2);
			RtuDataAddr->DD_BianLiang_Shuju[Num].Year_ShiQu=Variable_Set_value.Year_ShiQu;
			RtuDataAddr->DD_BianLiang_Shuju[Num].Day_ShiDuanBiao=Variable_Set_value.Day_ShiDuanBiao;
			RtuDataAddr->DD_BianLiang_Shuju[Num].Now_ShiDuan=Variable_Set_value.Now_ShiDuan;
			RtuDataAddr->DD_BianLiang_Shuju[Num].FeiLvShu=Variable_Set_value.FeiLvShu;
			RtuDataAddr->DD_BianLiang_Shuju[Num].GongGongJiari=Variable_Set_value.GongGongJiari;
			RtuDataAddr->DD_BianLiang_Shuju[Num].Now_ShiDuan=Variable_Set_value.Now_ShiDuan;

			RtuDataAddr->DD_BianLiang_Shuju[Num].Valid=1;
			RtuDataAddr->DD_Device_BiaoShi_Value[Num].Valid=1;

			ERRCreate=0;

			memset (RtuDataAddr->DD_BianLiang_Shuju[Num].Dianbiaostat_Flag  ,0,14);
			memset (RtuDataAddr->DD_BianLiang_Shuju[Num].Dian_biao_stat,0,14  );

			RtuDataAddr->DD_BianLiang_Shuju[Num].Dian_biao_stat[0][0] = Variable_Set_value.Dian_biao_stat; //fanzhihong
			tmp = Variable_Set_value.Dian_biao_stat ^ Variable_Set_value.Dian_biao_stat_old;
			RtuDataAddr->DD_BianLiang_Shuju[Num].Dianbiaostat_Flag[0][0] = tmp;
			if (tmp)
			{
				ERRCreate=1;
			}
			if(ERRCreate)
			{
					memset(statmp,0,14);
					memset(chgtmp,0,14);
					statmp[0] = Variable_Set_value.Dian_biao_stat;
					chgtmp[0] = tmp;
					pro_ERR33(Num,chgtmp,statmp);
					Variable_Set_value.Dian_biao_stat_old = Variable_Set_value.Dian_biao_stat;
			}
		}
	}
	return;
}
void Dlt645GetData(unsigned char i)
{
	TS ts;

	GetDemand_N_Set_Value(i);
	GetMaximum_Demand_N_Set_Value(i);
	GetMaximum_Demand_Time_N_Set_Value(i);
	GetVariable_Set_value(i);
	if(read485ERR[i]>=20)//ĳ����ܱ������������г���
	{
		GetValueErr=GetValueErr|(1<<i);//iλ��1����ʶ�ñ�ͨ���ж�
		Pro_ERC31(i);
	}
	else//�޴�
	{
		GetValueErr=GetValueErr&((1<<i)^0xffff);//iλ��0
		Dlt645Dbg("\r\n%s%d%s\r\n","�ɼ�",i,"�ű����");
		TSGet(&ts);
		RtuDataAddr->Event_Save.Event.Err31.Last_OK[0]=((ts.Minute/10)<<4)+(ts.Minute%10);
		RtuDataAddr->Event_Save.Event.Err31.Last_OK[1]=((ts.Hour/10)<<4)+(ts.Hour%10);
		RtuDataAddr->Event_Save.Event.Err31.Last_OK[2]=((ts.Day/10)<<4)+(ts.Day%10);
		RtuDataAddr->Event_Save.Event.Err31.Last_OK[3]=((ts.Month/10)<<4)+(ts.Month%10);
		RtuDataAddr->Event_Save.Event.Err31.Last_OK[4]=(((ts.Year%100)/10)<<4)+(ts.Year%10);
		memcpy(RtuDataAddr->Event_Save.Event.Err31.Last_Value_P,Demand_N_Set_Value.N_Z_P_All,4);
		memcpy(RtuDataAddr->Event_Save.Event.Err31.Last_Value_Q,Demand_N_Set_Value.N_Z_Q_All,4);
		DLT645_Data_Calc(i);
		if(RtuDataAddr->CL_ERR[i].first==1)
		{
			//printf("\r\n i=====%d",i);
			//printf("\n\rRtuDataAddr->CL_ERR[i].OldDuanXiangNum===%d",RtuDataAddr->CL_ERR[i].OldDuanXiangNum);
			RtuDataAddr->CL_ERR[i].OldDuanXiangNum=BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[i].Duanxiang_All,2);
			//RtuDataAddr->CL_ERR[i].OldShiYaCishu=BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[i].shiyacishu,3);
			//RtuDataAddr->CL_ERR[i].OldTingDianNum = BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[i].Tingdian,3);
			RtuDataAddr->CL_ERR[i].OldProgNum=BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[i].ProgNum,2);
			RtuDataAddr->CL_ERR[i].OldMacPZero=BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[i].ZeroNum,2);
			RtuDataAddr->CL_ERR[i].Old_PDD=RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_All;
			//RtuDataAddr->CL_ERR[i].TimePronumOld = BCDTo_INT32(RtuDataAddr->DD_BianLiang_Shuju[i].TimePronum,3);
		}
		ProREC(i);//�¼�
		RtuDataAddr->CL_ERR[i].first = 0;
	}
	return;
}
