#include "ws40.h"
#include "fkmeter.h"
extern void CleardeadCount();

unsigned char WS40DdCheck(unsigned char *buff, unsigned int len)
{
      unsigned int i;
      unsigned char temp = 0;
      for(i = 0; i < len; i ++)
      {
            temp += buff[i];
      }
      return temp;
}
unsigned char WS40GetVlue(unsigned char *Addr,unsigned char DI1,unsigned char DI0,unsigned char *Dest,unsigned char GetNum)
{
	//����
	unsigned char i,j,m,len;
	unsigned short Check;
	len=0;
	Check=0;
	INT8U addr;
	addr =((Addr[1]&0x0f)*100)+((Addr[0]>>4)*10)+(Addr[0]&0x0f);
	//CleardeadCount();
	//��֯���ͱ���
	Trn645Buff[len++]=addr;
	Trn645Buff[len++]=0x55;
	Trn645Buff[len++]=DI0;
	Trn645Buff[len++]=DI1;
	Trn645Buff[len++]=GetNum;
	Check=WS40DdCheck(Trn645Buff, 5);
	Trn645Buff[len++]=Check&0xff;
	Trn645Buff[len++]=0x0d;
	SendStrTo485(Trn645Buff,len);
	//**********���ͱ���**********************
	Dlt645Dbg("\r\nsend:   ");
	for(m=0;m<len;m++)
	{
		Dlt645Dbg("%x ",Trn645Buff[m]);
	}
	//*****************************************
	//����
	delay(200);
	len=ReceiveFrom485(Rec645Buff);
	//**************���ձ���******************
	Dlt645Dbg("\r\nreceive:len=%d\r\n",len);
	for(m=0;m<len;m++)
	{
		Dlt645Dbg("%x ",Rec645Buff[m]);
	}
	//*****************************************/

	for(i=0;i<len;i++)
	{
		if(Rec645Buff[i]==addr)
			break;
	}
	if(len>=4)
	{
		if((Rec645Buff[i]!=addr)
		&&(Rec645Buff[i+1]!=0x4f)
		&&(Rec645Buff[i+2]!=0x4b)
		&&(Rec645Buff[i+3]!=0x0d)
		&&(Rec645Buff[i+4]!=addr))
		{
			memset(Dest,0,GetNum);
			return 0;
		}
		GetLen=Rec645Buff[i+8];
		if(len<(GetLen+10))
		{
			memset(Dest,0,GetNum);
			return 0;
		}
		else
		{
			Check=0x00;
			for(j=0;j<(GetLen+5);j++)
			{
				Check=Check+Rec645Buff[i+4+j];
			}
			Check=Check&0xff;
			if(Check==Rec645Buff[i+GetLen+9])
			{
				if((Rec645Buff[i+6]!=DI0)||(Rec645Buff[i+7]!=DI1))
				{
					memset(Dest,0,GetNum);
					return 1;
				}
				else
				{
					memcpy(Dest,&Rec645Buff[i+9],GetLen);
					return 0;
				}
			}
		}
	}
	else
	{
		return 1;
	}
	return 1;
}
void WsGetDemand_N_Set_Value(unsigned char DDNo)
{
	TS ts;
	if(DDNo>=RtuDataAddr->Meter_Para.Metet_jiaoliu_Num)
		return;
	CleardeadCount();
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x01,Demand_N_Set_Value.N_Z_P_All,4)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x05,Demand_N_Set_Value.N_Z_P_F[0],4)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x02,Demand_N_Set_Value.N_Z_P_F[1],4)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x03,Demand_N_Set_Value.N_Z_P_F[2],4)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x04,Demand_N_Set_Value.N_Z_P_F[3],4)){read485ERR[DDNo]++;}

	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x10,Demand_N_Set_Value.N_F_P_All,4)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x14,Demand_N_Set_Value.N_F_P_F[0],4)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x11,Demand_N_Set_Value.N_F_P_F[1],4)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x12,Demand_N_Set_Value.N_F_P_F[2],4)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x13,Demand_N_Set_Value.N_F_P_F[3],4)){read485ERR[DDNo]++;}

	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x06,Demand_N_Set_Value.N_X1_Q_All,4)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x0A,Demand_N_Set_Value.N_X1_Q_F[0],4)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x07,Demand_N_Set_Value.N_X1_Q_F[1],4)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x08,Demand_N_Set_Value.N_X1_Q_F[2],4)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x09,Demand_N_Set_Value.N_X1_Q_F[3],4)){read485ERR[DDNo]++;}

	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x0B,Demand_N_Set_Value.N_X4_Q_All,4)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x0F,Demand_N_Set_Value.N_X4_Q_F[0],4)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x0C,Demand_N_Set_Value.N_X4_Q_F[1],4)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x0D,Demand_N_Set_Value.N_X4_Q_F[2],4)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x0E,Demand_N_Set_Value.N_X4_Q_F[3],4)){read485ERR[DDNo]++;}

	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x15,Demand_N_Set_Value.N_X2_Q_All,4)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x19,Demand_N_Set_Value.N_X2_Q_F[0],4)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x16,Demand_N_Set_Value.N_X2_Q_F[1],4)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x17,Demand_N_Set_Value.N_X2_Q_F[2],4)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x18,Demand_N_Set_Value.N_X2_Q_F[3],4)){read485ERR[DDNo]++;}

	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x1A,Demand_N_Set_Value.N_X3_Q_All,4)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x1E,Demand_N_Set_Value.N_X3_Q_F[0],4)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x1B,Demand_N_Set_Value.N_X3_Q_F[1],4)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x1C,Demand_N_Set_Value.N_X3_Q_F[2],4)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x1D,Demand_N_Set_Value.N_X3_Q_F[3],4)){read485ERR[DDNo]++;}

	Demand_N_Set_Value.valid=1;
	TSGet(&ts);
	Demand_N_Set_Value.Time_Chaobiao.BCD01=((ts.Minute/10)<<4)+(ts.Minute%10);
	Demand_N_Set_Value.Time_Chaobiao.BCD02=((ts.Hour/10)<<4)+(ts.Hour%10);
	Demand_N_Set_Value.Time_Chaobiao.BCD03=((ts.Day/10)<<4)+(ts.Day%10);
	Demand_N_Set_Value.Time_Chaobiao.BCD04=((ts.Month/10)<<4)+(ts.Month%10);
	Demand_N_Set_Value.Time_Chaobiao.BCD05=(((ts.Year%100)/10)<<4)+(ts.Year%10);
}
void WsGetMaximum_Demand_N_Set_Value(unsigned char DDNo)
{
	TS ts;
	if(DDNo>=RtuDataAddr->Meter_Para.Metet_jiaoliu_Num)
		return;
	CleardeadCount();
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x65,Maximum_Demand_N_Set_Value.N_Z_P_X_All,2)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x61,Maximum_Demand_N_Set_Value.N_Z_P_X_F[0],2)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x62,Maximum_Demand_N_Set_Value.N_Z_P_X_F[1],2)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x63,Maximum_Demand_N_Set_Value.N_Z_P_X_F[2],2)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x64,Maximum_Demand_N_Set_Value.N_Z_P_X_F[3],2)){read485ERR[DDNo]++;}

	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x6f,Maximum_Demand_N_Set_Value.N_F_P_X_All,2)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x6b,Maximum_Demand_N_Set_Value.N_F_P_X_F[0],2)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x6c,Maximum_Demand_N_Set_Value.N_F_P_X_F[1],2)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x6d,Maximum_Demand_N_Set_Value.N_F_P_X_F[2],2)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x6e,Maximum_Demand_N_Set_Value.N_F_P_X_F[3],2)){read485ERR[DDNo]++;}
//XINJIA

	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x85,Yue_Maximum_Demand_N_Set_Value.SY_Z_P_X_All,2)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x81,Yue_Maximum_Demand_N_Set_Value.SY_Z_P_X_F[0],2)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x82,Yue_Maximum_Demand_N_Set_Value.SY_Z_P_X_F[1],2)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x83,Yue_Maximum_Demand_N_Set_Value.SY_Z_P_X_F[2],2)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x84,Yue_Maximum_Demand_N_Set_Value.SY_Z_P_X_F[3],2)){read485ERR[DDNo]++;}

	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x8f,Yue_Maximum_Demand_N_Set_Value.SY_F_P_X_All,2)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x8b,Yue_Maximum_Demand_N_Set_Value.SY_F_P_X_F[0],2)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x8c,Yue_Maximum_Demand_N_Set_Value.SY_F_P_X_F[1],2)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x8d,Yue_Maximum_Demand_N_Set_Value.SY_F_P_X_F[2],2)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x8e,Yue_Maximum_Demand_N_Set_Value.SY_F_P_X_F[3],2)){read485ERR[DDNo]++;}
//XINJIA


	Maximum_Demand_N_Set_Value.valid=1;
	Yue_Maximum_Demand_N_Set_Value.valid=1;
	TSGet(&ts);
	Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD01=((ts.Minute/10)<<4)+(ts.Minute%10);
	Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD02=((ts.Hour/10)<<4)+(ts.Hour%10);
	Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD03=((ts.Day/10)<<4)+(ts.Day%10);
	Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD04=((ts.Month/10)<<4)+(ts.Month%10);
	Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD05=(((ts.Year%100)/10)<<4)+(ts.Year%10);

	Yue_Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD01=((ts.Minute/10)<<4)+(ts.Minute%10);
	Yue_Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD02=((ts.Hour/10)<<4)+(ts.Hour%10);
	Yue_Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD03=((ts.Day/10)<<4)+(ts.Day%10);
	Yue_Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD04=((ts.Month/10)<<4)+(ts.Month%10);
	Yue_Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD05=(((ts.Year%100)/10)<<4)+(ts.Year%10);

}
void ToBcd(unsigned char *s,unsigned char *d,unsigned char len)
{
	unsigned char tmp,i;
	for(i=0;i<len;i++)
	{
		tmp=s[i];
		d[i]=((tmp/10)<<4)+(tmp%10);
	}
}
void WsGetMaximum_Demand_Time_N_Set_Value(unsigned char DDNo)
{
	TS ts;
	if(DDNo>=RtuDataAddr->Meter_Para.Metet_jiaoliu_Num)
		return;
	CleardeadCount();
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x6a,Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_All,4)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x66,Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_F[0],4)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x67,Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_F[1],4)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x68,Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_F[2],4)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x69,Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_F[3],4)){read485ERR[DDNo]++;}

	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x74,Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_All,4)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x70,Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_F[0],4)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x71,Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_F[1],4)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x73,Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_F[2],4)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x73,Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_F[3],4)){read485ERR[DDNo]++;}
/////xinjia

	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x8a,Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_Z_P_X_All,4)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x86,Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_Z_P_X_F[0],4)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x87,Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_Z_P_X_F[1],4)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x88,Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_Z_P_X_F[2],4)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x89,Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_Z_P_X_F[3],4)){read485ERR[DDNo]++;}

	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x94,Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_F_P_X_All,4)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x9d,Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_F_P_X_F[0],4)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x91,Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_F_P_X_F[1],4)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x92,Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_F_P_X_F[2],4)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0x93,Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_F_P_X_F[3],4)){read485ERR[DDNo]++;}

	Maximum_Demand_Time_N_Set_Value.valid=1;
	Yue_Maximum_Demand_Time_N_Set_Value.valid=1;
	TSGet(&ts);
	Maximum_Demand_Time_N_Set_Value.Time_Chaobiao.BCD01=((ts.Minute/10)<<4)+(ts.Minute%10);
	Maximum_Demand_Time_N_Set_Value.Time_Chaobiao.BCD02=((ts.Hour/10)<<4)+(ts.Hour%10);
	Maximum_Demand_Time_N_Set_Value.Time_Chaobiao.BCD03=((ts.Day/10)<<4)+(ts.Day%10);
	Maximum_Demand_Time_N_Set_Value.Time_Chaobiao.BCD04=((ts.Month/10)<<4)+(ts.Month%10);
	Maximum_Demand_Time_N_Set_Value.Time_Chaobiao.BCD05=(((ts.Year%100)/10)<<4)+(ts.Year%10);

	Yue_Maximum_Demand_Time_N_Set_Value.Time_Chaobiao.BCD01=((ts.Minute/10)<<4)+(ts.Minute%10);
	Yue_Maximum_Demand_Time_N_Set_Value.Time_Chaobiao.BCD02=((ts.Hour/10)<<4)+(ts.Hour%10);
	Yue_Maximum_Demand_Time_N_Set_Value.Time_Chaobiao.BCD03=((ts.Day/10)<<4)+(ts.Day%10);
	Yue_Maximum_Demand_Time_N_Set_Value.Time_Chaobiao.BCD04=((ts.Month/10)<<4)+(ts.Month%10);
	Yue_Maximum_Demand_Time_N_Set_Value.Time_Chaobiao.BCD05=(((ts.Year%100)/10)<<4)+(ts.Year%10);


}
void WsGetVariable_Set_value(unsigned char DDNo)
{
	TS ts;
	unsigned char TmpTime[6];
	if(DDNo>=RtuDataAddr->Meter_Para.Metet_jiaoliu_Num)
		return;
	CleardeadCount();
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0xB3,Variable_Set_value.VA,2)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0xB4,Variable_Set_value.VB,2)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0xB5,Variable_Set_value.VC,2)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0xB6,Variable_Set_value.IA,2)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0xB7,Variable_Set_value.IB,2)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0xB8,Variable_Set_value.IC,2)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0xB1,Variable_Set_value.P,3)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x10,0xB2,Variable_Set_value.Q,3)){read485ERR[DDNo]++;}
	if(WS40GetVlue(RtuDataAddr->Meter_Para.Dian_Meter[DDNo].Addr,0x20,0x01,TmpTime,5)){read485ERR[DDNo]++;}
	ToBcd(&TmpTime[0],&Variable_Set_value.Date_Week[3],1);//year
	ToBcd(&TmpTime[1],&Variable_Set_value.Date_Week[2],1);//moj
	ToBcd(&TmpTime[2],&Variable_Set_value.Date_Week[1],1);//day
	ToBcd(&TmpTime[3],&Variable_Set_value.Now_Time[2],1);//hour
	ToBcd(&TmpTime[4],&Variable_Set_value.Now_Time[1],1);//min
	Variable_Set_value.valid=1;
	TSGet(&ts);
	Variable_Set_value.Time_Chaobiao.BCD01=((ts.Minute/10)<<4)+(ts.Minute%10);
	Variable_Set_value.Time_Chaobiao.BCD02=((ts.Hour/10)<<4)+(ts.Hour%10);
	Variable_Set_value.Time_Chaobiao.BCD03=((ts.Day/10)<<4)+(ts.Day%10);
	Variable_Set_value.Time_Chaobiao.BCD04=((ts.Month/10)<<4)+(ts.Month%10);
	Variable_Set_value.Time_Chaobiao.BCD05=(((ts.Year%100)/10)<<4)+(ts.Year%10);
}
unsigned int WS_GetData(unsigned char *S,unsigned char Num)
{
	unsigned int res;
	int i;
	res=0;
	i=Num-1;
	while(i>=0)
	{
		res=(res<<8)+S[i];
		i--;
	}
	return res;
}
void WS_GetDataTime(unsigned char *S,unsigned char *D,unsigned char Num)
{
	int i;
	for(i=0;i<Num;i++)
	{
		S[i]=((D[i]/10)<<4)+(D[i]%10);//S����D��D����S
	}
}
void WS_Data_Calc(unsigned char DDNo)
{
	unsigned char /*j,*/Num;

	unsigned char tmp;

	if(RtuDataAddr->Meter_Para.Valid!=1)
		return;
	if(RtuDataAddr->Meter_Para.Metet_jiaoliu_Num>CeLiangPoint_Max)
		return;
	Num=RtuDataAddr->Meter_Para.Dian_Meter[DDNo].CeLiangNo-1;
	if(Num>CeLiangPoint_Max)
		return;

	if(Demand_N_Set_Value.valid==1)
	{
		CleardeadCount();
		memcpy(&RtuDataAddr->DD_Device_BiaoShi_Value[Num].Chao_Time.BCD01,&Demand_N_Set_Value.Time_Chaobiao.BCD01,5);
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_All=WS_GetData(Demand_N_Set_Value.N_Z_P_All,4)/10;
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_F[0]=WS_GetData(Demand_N_Set_Value.N_Z_P_F[0],4)/10;
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_F[1]=WS_GetData(Demand_N_Set_Value.N_Z_P_F[1],4)/10;
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_F[2]=WS_GetData(Demand_N_Set_Value.N_Z_P_F[2],4)/10;
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_F[3]=WS_GetData(Demand_N_Set_Value.N_Z_P_F[3],4)/10;

		RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_All=WS_GetData(Demand_N_Set_Value.N_F_P_All,4)/10;
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_F[0]=WS_GetData(Demand_N_Set_Value.N_F_P_F[0],4)/10;
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_F[1]=WS_GetData(Demand_N_Set_Value.N_F_P_F[1],4)/10;
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_F[2]=WS_GetData(Demand_N_Set_Value.N_F_P_F[2],4)/10;
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_F[3]=WS_GetData(Demand_N_Set_Value.N_F_P_F[3],4)/10;

		RtuDataAddr->DD_Device_BiaoShi_Value[Num].X1_Q_All=WS_GetData(Demand_N_Set_Value.N_X1_Q_All,4)/10;
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].X1_F_Q[0]=WS_GetData(Demand_N_Set_Value.N_X1_Q_F[0],4)/10;
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].X1_F_Q[1]=WS_GetData(Demand_N_Set_Value.N_X1_Q_F[1],4)/10;
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].X1_F_Q[2]=WS_GetData(Demand_N_Set_Value.N_X1_Q_F[2],4)/10;
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].X1_F_Q[3]=WS_GetData(Demand_N_Set_Value.N_X1_Q_F[3],4)/10;

		RtuDataAddr->DD_Device_BiaoShi_Value[Num].X4_Q_All=WS_GetData(Demand_N_Set_Value.N_X4_Q_All,4)/10;
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].X4_F_Q[0]=WS_GetData(Demand_N_Set_Value.N_X4_Q_F[0],4)/10;
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].X4_F_Q[1]=WS_GetData(Demand_N_Set_Value.N_X4_Q_F[1],4)/10;
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].X4_F_Q[2]=WS_GetData(Demand_N_Set_Value.N_X4_Q_F[2],4)/10;
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].X4_F_Q[3]=WS_GetData(Demand_N_Set_Value.N_X4_Q_F[3],4)/10;

		RtuDataAddr->DD_Device_BiaoShi_Value[Num].X2_Q_All=WS_GetData(Demand_N_Set_Value.N_X2_Q_All,4)/10;
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].X2_F_Q[0]=WS_GetData(Demand_N_Set_Value.N_X2_Q_F[0],4)/10;
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].X2_F_Q[1]=WS_GetData(Demand_N_Set_Value.N_X2_Q_F[1],4)/10;
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].X2_F_Q[2]=WS_GetData(Demand_N_Set_Value.N_X2_Q_F[2],4)/10;
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].X2_F_Q[3]=WS_GetData(Demand_N_Set_Value.N_X2_Q_F[3],4)/10;

		RtuDataAddr->DD_Device_BiaoShi_Value[Num].X3_Q_All=WS_GetData(Demand_N_Set_Value.N_X3_Q_All,4)/10;
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].X3_F_Q[0]=WS_GetData(Demand_N_Set_Value.N_X3_Q_F[0],4)/10;
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].X3_F_Q[1]=WS_GetData(Demand_N_Set_Value.N_X3_Q_F[1],4)/10;
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].X3_F_Q[2]=WS_GetData(Demand_N_Set_Value.N_X3_Q_F[2],4)/10;
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].X3_F_Q[3]=WS_GetData(Demand_N_Set_Value.N_X3_Q_F[3],4)/10;

		RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_All=RtuDataAddr->DD_Device_BiaoShi_Value[Num].X1_Q_All+RtuDataAddr->DD_Device_BiaoShi_Value[Num].X2_Q_All;
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_F[0]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].X1_F_Q[0]+RtuDataAddr->DD_Device_BiaoShi_Value[Num].X2_F_Q[0];
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_F[1]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].X1_F_Q[1]+RtuDataAddr->DD_Device_BiaoShi_Value[Num].X2_F_Q[1];
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_F[2]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].X1_F_Q[2]+RtuDataAddr->DD_Device_BiaoShi_Value[Num].X2_F_Q[2];
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_F[3]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].X1_F_Q[3]+RtuDataAddr->DD_Device_BiaoShi_Value[Num].X2_F_Q[3];

		RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_All=RtuDataAddr->DD_Device_BiaoShi_Value[Num].X4_Q_All+RtuDataAddr->DD_Device_BiaoShi_Value[Num].X3_Q_All;
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_F[0]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].X4_F_Q[0]+RtuDataAddr->DD_Device_BiaoShi_Value[Num].X3_F_Q[0];
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_F[1]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].X4_F_Q[1]+RtuDataAddr->DD_Device_BiaoShi_Value[Num].X3_F_Q[1];
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_F[2]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].X4_F_Q[2]+RtuDataAddr->DD_Device_BiaoShi_Value[Num].X3_F_Q[2];
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_F[3]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].X4_F_Q[3]+RtuDataAddr->DD_Device_BiaoShi_Value[Num].X3_F_Q[3];

		RtuDataAddr->DD_Device_BiaoShi_Value[Num].Valid=1;
	}


	if(Maximum_Demand_N_Set_Value.valid==1)
	{
		CleardeadCount();
		memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Chao_Time.BCD01,&Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD01,5);

		RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_P_X_All=WS_GetData(Maximum_Demand_N_Set_Value.N_Z_P_X_All,2);
		RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_P_X_F[0]=WS_GetData(Maximum_Demand_N_Set_Value.N_Z_P_X_F[0],2);
		RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_P_X_F[1]=WS_GetData(Maximum_Demand_N_Set_Value.N_Z_P_X_F[1],2);
		RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_P_X_F[2]=WS_GetData(Maximum_Demand_N_Set_Value.N_Z_P_X_F[2],2);
		RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_P_X_F[3]=WS_GetData(Maximum_Demand_N_Set_Value.N_Z_P_X_F[3],2);

		RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_P_X_All=WS_GetData(Maximum_Demand_N_Set_Value.N_F_P_X_All,2);
		RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_P_X_F[0]=WS_GetData(Maximum_Demand_N_Set_Value.N_F_P_X_F[0],2);
		RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_P_X_F[1]=WS_GetData(Maximum_Demand_N_Set_Value.N_F_P_X_F[1],2);
		RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_P_X_F[2]=WS_GetData(Maximum_Demand_N_Set_Value.N_F_P_X_F[2],2);
		RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_P_X_F[3]=WS_GetData(Maximum_Demand_N_Set_Value.N_F_P_X_F[3],2);


		RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Valid=1;
	}

	if(Yue_Maximum_Demand_N_Set_Value.valid==1)
	{
		CleardeadCount();
		//xinjia
		memcpy(&RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].Chao_Time.BCD01,&Yue_Maximum_Demand_N_Set_Value.Time_Chaobiao.BCD01,5);

		RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].SY_Z_P_X_All=WS_GetData(Yue_Maximum_Demand_N_Set_Value.SY_Z_P_X_All,2);
		RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].SY_F_P_X_All=WS_GetData(Yue_Maximum_Demand_N_Set_Value.SY_F_P_X_All,2);
		RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].Valid=1;
		//xinjia

	}
	if(Maximum_Demand_Time_N_Set_Value.valid==1)
	{
		CleardeadCount();
		memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Chao_Time.BCD01,&Maximum_Demand_Time_N_Set_Value.Time_Chaobiao.BCD01,5);
		WS_GetDataTime(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_P_X_All[0],&Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_All[0],4);
		WS_GetDataTime(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_P_X_F[0][0],&Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_F[0][0],4);
		WS_GetDataTime(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_P_X_F[1][0],&Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_F[1][0],4);
		WS_GetDataTime(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_P_X_F[2][0],&Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_F[2][0],4);
		WS_GetDataTime(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_P_X_F[3][0],&Maximum_Demand_Time_N_Set_Value.Time_N_Z_P_X_F[3][0],4);

		WS_GetDataTime(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_P_X_All[0],&Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_All[0],4);
		WS_GetDataTime(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_P_X_F[0][0],&Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_F[0][0],4);
		WS_GetDataTime(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_P_X_F[1][0],&Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_F[1][0],4);
		WS_GetDataTime(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_P_X_F[2][0],&Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_F[2][0],4);
		WS_GetDataTime(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_P_X_F[3][0],&Maximum_Demand_Time_N_Set_Value.Time_N_F_P_X_F[3][0],4);

		RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].UAJ=0;
		RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].UBJ=1200;
		RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].UCJ=2400;
		RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].IAJ=0;
		RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].IBJ=1200;
		RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].ICJ=2400;

		RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Valid=1;
	}
	if(Yue_Maximum_Demand_Time_N_Set_Value.valid==1)
	{
		CleardeadCount();
		memcpy(&RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].Chao_Time.BCD01,&Yue_Maximum_Demand_Time_N_Set_Value.Time_Chaobiao.BCD01,5);
		//xinjia
		WS_GetDataTime(&RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].Time_SY_Z_P_X_All[0],&Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_Z_P_X_All[0],4);
		WS_GetDataTime(&RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].Time_SY_F_P_X_All[0],&Yue_Maximum_Demand_Time_N_Set_Value.Time_SY_F_P_X_All[0],4);
		//xinjia
		RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[Num].Valid=1;
	}
	//
	if(Variable_Set_value.valid==1)
	{
		CleardeadCount();
		memcpy(&RtuDataAddr->DD_Device_BiaoShi_Value[Num].Chao_Time.BCD01,&Variable_Set_value.Time_Chaobiao.BCD01,5);

		RtuDataAddr->DD_Device_BiaoShi_Value[Num].IA=WS_GetData(Variable_Set_value.IA,2);
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].IB=WS_GetData(Variable_Set_value.IB,2);
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].IC=WS_GetData(Variable_Set_value.IC,2);
		//DD_Device_BiaoShi_Value[Num].IL=BCDTo_INT32(Variable_Set_value.IL,2);

		RtuDataAddr->DD_Device_BiaoShi_Value[Num].VA=WS_GetData(Variable_Set_value.VA,2)/10;
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].VB=WS_GetData(Variable_Set_value.VB,2)/10;
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].VC=WS_GetData(Variable_Set_value.VC,2)/10;

		RtuDataAddr->DD_Device_BiaoShi_Value[Num].P=WS_GetData(Variable_Set_value.P,3);

		RtuDataAddr->DD_Device_BiaoShi_Value[Num].Q=WS_GetData(Variable_Set_value.Q,3);

/*
		memcpy(&DD_BianLiang_Shuju[Num].Chao_Time.BCD01,&Variable_Set_value.Time_Chaobiao.BCD01,5);
		//-------------------------------------------->
*/		memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].Date_Week[0],&Variable_Set_value.Date_Week[0],4);
		memcpy(&RtuDataAddr->DD_BianLiang_Shuju[Num].Now_Time[0],&Variable_Set_value.Now_Time[0],3);
		//--------------------------------------------<
		tmp=Variable_Set_value.Date_Week[0];
		RtuDataAddr->DD_BianLiang_Shuju[Num].Valid=1;
		RtuDataAddr->DD_Device_BiaoShi_Value[Num].Valid=1;
	}

}

void WsDlt645GetData(unsigned char i)
{
	WsGetDemand_N_Set_Value(i);
	WsGetMaximum_Demand_N_Set_Value(i);
	WsGetMaximum_Demand_Time_N_Set_Value(i);
	WsGetVariable_Set_value(i);//����
	if(read485ERR[i]>=20)//ĳ����ܱ������������г���
	{
		GetValueErr=GetValueErr|(1<<i);//iλ��1����ʶ�ñ�ͨ���ж�
	}
	else//�޴�
	{
		GetValueErr=GetValueErr&((1<<i)^0xffff);//iλ��0
		WS_Data_Calc(i);
	}
}
