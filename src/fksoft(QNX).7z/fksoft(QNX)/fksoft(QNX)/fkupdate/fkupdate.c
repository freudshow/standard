
#include "fkupdate.h"
const char verstr[]={"VER-STRING-FLG=011.002.217.004"__DATE__" "__TIME__};
int filenum;


void markver()//��Ŀ������б�ʶ�����汾��Ϣ
{
	printf("\n%s\n", verstr);
}
void readconfig()
{
	FILE *fp;
	int numstr;
	unsigned char ReadString[256];
	int erro;
	unsigned char filename[128];
	memset(filename,0,128);
	sprintf((char *)filename,"/nand/update/update/1.txt");
	fp=fopen((char *)filename,"r");
	if(fp!=NULL)
	{
		filenum = 0;
		erro    = 0;
		for(;;)
		{
			numstr  = 0;
			//----------------��ȡ�ļ�����
			printf("\n\r filenum index is %d",filenum);
			memset(ReadString,0,256);
			numstr  = fscanf(fp, "%s", ReadString);
			if (numstr<=0)
			{
				erro++;
				break;
			}
			if(sscanf((char *)ReadString,"%s",&fileconfig[filenum].filename)!=1)
				erro++;
			fileconfig[filenum].isverflag = 0;
			if(strcmp(fileconfig[filenum].filename,"ver")==0)
			{
				fileconfig[filenum].isverflag = 1;
				memset(ReadString,0,256);
				numstr  = fscanf(fp, "%s", ReadString);
				sscanf((char *)ReadString,"%d",&fileconfig[filenum].ver[1]);
				//printf("\n\r ver ReadString 1 is %s",ReadString);
				memset(ReadString,0,256);
				numstr  = fscanf(fp, "%s", ReadString);
				//printf("\n\r ver ReadString 2 is %s",ReadString);
				sscanf((char *)ReadString,"%d",&fileconfig[filenum].ver[0]);
				//printf("\n\r fileconfig ver is %d  .  %d ",fileconfig[filenum].ver[1],fileconfig[filenum].ver[0]);
				filenum++;
				continue;
			}
			if(strcmp(fileconfig[filenum].filename,"ip")==0)
			{
				fileconfig[filenum].isverflag = 2;
			}

			//printf("\n\r ----file%d filename  %s", filenum,fileconfig[filenum].filename);
			//----------------��ȡ�汾��Ϣ
			memset(ReadString,0,256);
			numstr  = fscanf(fp, "%s", ReadString);
			if (numstr<=0)
			{
				erro++;
				break;
			}
			if(sscanf((char *)ReadString,"%s",&fileconfig[filenum].version)!=1)
				erro++;
			//printf("\n\r----file%d version  %s", filenum,fileconfig[filenum].version);
			//---------------��ȡ�ļ��ֽ���
			memset(ReadString,0,256);
			numstr  = fscanf(fp, "%s", ReadString);
			if (numstr<=0)
			{
				erro++;
				break;
			}
			if(sscanf((char *)ReadString,"%d",&fileconfig[filenum].size)!=1)
				erro++;
			//printf("\n\r----file%d size  %d ",filenum,fileconfig[filenum].size);
			fileconfig[filenum].okflag = 0;
			filenum++;
		}
		if (erro>1)
			printf("can't do update");
		printf("\n\r erro %d  filenum %d ",erro,filenum);
	}
	fclose(fp);
}

int getversioninfile(FILE *f,int fnum)
{
	char buf[20];
	//char ver[4];
	int findverflag = 0;
	long number = 0;
	int num;

	fseek(f,0,0);
	num = fread(buf,1,4,f);
	if (num>=4)
	{
		if ((buf[0]=='')&&(buf[1]=='E')&&(buf[2]=='L')&&(buf[3]=='F'))
		{
				number = 3;
				while(1)
				{
					number++;
					num = 0;
					num = fread(buf,1,1,f);
					if (num==0)
						break;
					if (buf[0]=='V')
					{
						num = fread(buf,1,1,f);
						if (num==0) break;
						if(buf[0]== 'E')
						{
							num = fread(buf,1,1,f);
							if (num==0) break;
							if(buf[0]== 'R')
							{
								num = fread(buf,1,1,f);
								if (num==0) break;
								if (buf[0]== '-')
								{
									num = fread(buf,1,1,f);
									if (num==0) break;
									if(buf[0]=='S')
									{
										num = fread(buf,1,1,f);
										if (num==0) break;
										if(buf[0]=='T')
										{
											num = fread(buf,1,1,f);
											if (num==0) break;
											if(buf[0]=='R')
											{
												num = fread(buf,1,1,f);
												if (num==0) break;
												if(buf[0]=='I')
												{
													num = fread(buf,1,1,f);
													if (num==0) break;
													if(buf[0]=='N')
													{
														num = fread(buf,1,1,f);
														if (num==0) break;
														if(buf[0]=='G')
														{
															num = fread(buf,1,1,f);
															if (num==0) break;
															if(buf[0]=='-')
															{
																num = fread(buf,1,1,f);
																if (num==0) break;
																if(buf[0]=='F')
																{
																	num = fread(buf,1,1,f);
																	if (num==0) break;
																	if(buf[0]=='L')
																	{
																		num = fread(buf,1,1,f);
																		if (num==0) break;
																		if(buf[0]=='G')
																		{
																			num = fread(buf,1,1,f);
																			if (num==0) break;
																			if(buf[0]=='=')
																			{
																				num = fread(buf,1,15,f);
																				if (strncmp(buf,fileconfig[fnum].version,15)==0)
																					findverflag = 1;
																				break;
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		if (findverflag == 0)
			printf("\n\r %s ver=%s",fileconfig[fnum].filename,buf);
		printf("\n\r fileconfig[%d].version %s",fnum,fileconfig[fnum].version);
		return findverflag;
}
int getfilesize(FILE *f,int fnum)
{
	int filesizeok = 0;
	long int save_pos;
	long size_of_file;
	save_pos = ftell( f );
	fseek( f, 0L, SEEK_END );
	size_of_file = ftell( f );
	fseek( f, save_pos, SEEK_SET );
	if (fileconfig[fnum].size==size_of_file)
		filesizeok = 1;
	if (filesizeok==0)
		printf("\n\r %s size%d",fileconfig[fnum].filename,size_of_file);
	return filesizeok;
}
int checkfile()
{
	int i,sizflag,veflag;
	char filename[128];
	int allok;
	FILE *fp;
	allok = 1;
	memset(filename,0,128);
	for(i=0;i<filenum;i++)
	{
		fp = NULL;
		if ((fileconfig[i].isverflag==1)||(fileconfig[i].isverflag==2))//�汾��Ϣ      //��վIP�Ͷ˿ں�
			continue;

		sprintf(filename,"/nand/update/update/%s",fileconfig[i].filename);
		fp = fopen(filename,"rb");
		//printf("\n\r check file ptr is %d !!!!!!!!",fp);
		veflag = getversioninfile(fp,i);
		sizflag = getfilesize(fp,i);
		//printf("\n\r veflag is %d  sizflag is %d",veflag,sizflag);
		if ((fp!=NULL)&&(veflag)&&(sizflag))
		{
			fileconfig[i].okflag = 1;
			//printf("\n\r %s is check ok",fileconfig[i].filename);
		}
		else
		{
			allok = 0;
			fileconfig[i].okflag = 0;
			//printf("\n\r %s is check no ok",fileconfig[i].filename);
		}
	}
	return allok;
}

void EditeMsg()
{
	int i;
	rmsg.filenum = 0;
	rmsg.start_flag= UPDATE_BEGIN;
	for(i=0;i<filenum;i++)
	{
		if (fileconfig[i].okflag == 1)//��������
		{
			memcpy(rmsg.fnameList[i],fileconfig[i].filename,30);
			rmsg.filenum++;
			//printf("\n\r num is %d okflag %s",rmsg.filenum,fileconfig[i].filename);
			continue;
		}
		if(fileconfig[i].isverflag==1)//�汾��Ϣ
		{
			//printf("\n\r get get get %d.%d",fileconfig[i].ver[1],fileconfig[i].ver[0]);
			rmsg.ver[0]=fileconfig[i].ver[0];
			rmsg.ver[1]=fileconfig[i].ver[1];
			continue;
		}
		if(fileconfig[i].isverflag==2)//��վIP�Ͷ˿ں�
		{
			memcpy(rmsg.ip,fileconfig[i].version,30);
			rmsg.port = fileconfig[i].size;
			continue;
		}
	}
}
void buildUpdatefile(my_data_t msg)
{
	FILE *fp;
	FILE *UpDataFile;
	unsigned char buf[300];
	int num;
	int space,lastpack;
	int j;
	unsigned int AllByteCount;
	int oneSize;
	int AllPackNum;

	AllByteCount = msg.AllByteCount;
	AllPackNum = msg.AllPackNum;
	oneSize = msg.oneSize;
	//printf("\n\r allbyte %d  packnum %d  onesize %d",AllByteCount,AllPackNum,oneSize);
	fp=fopen("/nand/update/gprs.tar.gz","wb+");
	UpDataFile = fopen("/nand/update/gprs.tar.gz.tmp","r");

	lastpack = (AllByteCount)%oneSize;
	space = oneSize +1;
	//printf("\n\r space = %d  AllByteCount= %d  laskpack = %d",space,AllByteCount,lastpack);
	if (fp!= NULL)
	{
		fseek(UpDataFile,0,0);
		for(j=0;j<AllPackNum-1;j++)
		{
			num = 0;
			num = fread(buf,space,1,UpDataFile);
			if (num<=0)
				break;
			fwrite(&buf[1],oneSize,1,fp);
		}
		memset(buf,0,300);
		num = 0;
		space=lastpack+1;
		num = fread(buf,space,1,UpDataFile);
		//printf("\n\r fread lastpack num is %d",num);
		if (num>0)
		{
			num = fwrite(&buf[1],lastpack,1,fp);
			//printf("\n\r fwrite lastpack num is %d",num);
		}
	}
	fclose(fp);
	fclose(UpDataFile);
}
#define USB_PATH /usb10-dos-1/update
#define TARGET_PATH /tmp
#define UPDATE_APP_NAME usbupdate.sh

#define _mypath(path) (#path)
#define mypath(path) _mypath(path)
// mypath(USB_PATH)  mypath(TARGET_PATH)  mypath(UPDATE_APP_NAME)
void *thread_UpdateApp()
{
	DIR *usbdir;
	struct dirent *ptr;
	int system_ret=0;
	int IsUSBUpdated = 0;
	char tmpstr[100];
	sleep(10);

	while(!IsUSBUpdated)
	{
		sleep(5);
		usbdir = opendir(mypath(USB_PATH));//"/usb10-dos-1");
		if(usbdir == NULL)
		{
			//fprintf(stderr,"\n\rfailed to open /usb10-dos-1");
		}
		else
		{
			while((ptr = readdir(usbdir)) != NULL)
			{
				//printf(" \n\r ptr->d_name == %s", ptr->d_name);
				if(strcmp(ptr->d_name, mypath(UPDATE_APP_NAME)) == 0)
				{
					memset(tmpstr, 0, 100);
					sprintf(tmpstr, "cp -rf %s/%s %s", mypath(USB_PATH), mypath(UPDATE_APP_NAME), mypath(TARGET_PATH));
					//if((system_ret = system("cp -rf " "/usb10-dos-1/usbupdate.sh" " " mypath(TARGET_PATH)))== -1)
					if((system_ret = system(tmpstr))== -1)
					{
						printf("\n\r cp -rf /usb10-dos-1/usbupdate.sh /tmp failed!!!");
					}else{
						printf("\n\r");
						memset(tmpstr, 0, 100);
						sprintf(tmpstr, "%s/%s", mypath(TARGET_PATH), mypath(UPDATE_APP_NAME));
						//chmod("/tmp/usbupdat.sh",S_IRWXU);
						chmod(tmpstr,S_IRWXU);
						memset(tmpstr, 0, 100);
						sprintf(tmpstr, ". %s/%s", mypath(TARGET_PATH), mypath(UPDATE_APP_NAME));
						//if( (system_ret = system(". /tmp/usbupdate.sh")) == -1)
						if( (system_ret = system(tmpstr)) == -1)
						{
							printf("\n\r system /tmp/usbupdate.sh failed!!!");
						}else{
							IsUSBUpdated = 1;
						}
					}
				}
			}
			closedir(usbdir);
		}
	}
	pthread_exit(NULL);
}
int main(int argc, char *argv[])
{
	   name_attach_t *attach;
	   my_data_t msg;
	   int rcvid;

	   /* Create a local name (/dev/name/local/...) */
	   if ((attach = name_attach(NULL, ATTACH_POINT, 0)) == NULL) {
	       return EXIT_FAILURE;
	   }
	   //usb���Զ���������
	   pthread_t thread_update;
	   pthread_create(&thread_update, NULL, thread_UpdateApp, NULL);	 /*�����߳�*/
	   /* Do your MsgReceive's here now with the chid */
	   while (1) {
	       rcvid = MsgReceive(attach->chid, &msg, sizeof(msg), NULL);
	       if (rcvid == -1) {/* Error condition, exit */
	           break;
	       }

	       if (rcvid == 0) {/* Pulse received */
	          //printf("\n\r we receive a pulse");
	          continue;
	       }
	       //printf("rec=%d   strat_flag %d\n",rcvid,msg.start_flag);

	       if (msg.start_flag == UPDATE_BEGIN ) {
	    	   //printf("\n\r #begin update");
	    	   //system("ls /nand/update/");
	    	   //system("rm -Rf /nand/update/update/");
	    	   //delay(1000);
	    	   buildUpdatefile(msg);
	    	   delay(1000);
	    	   system("tar -zxvf /nand/update/gprs.tar.gz -C /nand/update/");
	    	   readconfig();//��ȡ��������
	    	   if (checkfile()) //У�������ļ�
	    	   {
				   EditeMsg();
			       MsgReply(rcvid, EOK, &rmsg, sizeof(rmsg));
	    	   }else
	    	   {
	    		   rmsg.start_flag= UPDATE_FAILURE;
	    		   MsgReply(rcvid, EOK, &rmsg, sizeof(rmsg));
	    	   }
	       }
	   }
	   name_detach(attach, 0);
	   return EXIT_SUCCESS;
}
