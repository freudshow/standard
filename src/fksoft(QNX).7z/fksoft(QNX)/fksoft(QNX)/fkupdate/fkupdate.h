#ifndef FKUPDATE_H_
#define FKUPDATE_H_
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <ctype.h>
#include <time.h>
#include <stdint.h>
#include <signal.h>
#include <sys/sched.h>
#include <semaphore.h>
#include <process.h>
#include <sys/neutrino.h>
#include <sys/netmgr.h>
#include <sys/dispatch.h>
#include <errno.h>
#include <netdb.h>
#include <hw/inout.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <math.h>
#include <termios.h>
#include <string.h>
#include <sys/neutrino.h>
#include <dirent.h>
#define ATTACH_POINT "UPDATE_SERVER"
#define UPDATE_BEGIN    1
#define UPDATE_FAILURE  2

typedef struct
{
	long size;
	int  okflag;
	int  isverflag;
	int  ver[2];
	char filename[30];
	char version[30];
}CONFIGTYPE;

typedef struct {
    int start_flag;
    unsigned int AllByteCount;
    int oneSize;
    int AllPackNum;
	char fnameList[20][30];
	int  filenum;
    int ip[30];
    int port;
    int ver[2];
} my_data_t;

CONFIGTYPE fileconfig[20];
my_data_t  msg,rmsg;
int ver_var;
void markver();//��Ŀ������б�ʶ�����汾��Ϣ
void readconfig();
int getversioninfile(FILE *f,int fnum);
int getfilesize(FILE *f,int fnum);
int checkfile();
void cpyfile();

#endif /* FKUPDATE_H_ */
