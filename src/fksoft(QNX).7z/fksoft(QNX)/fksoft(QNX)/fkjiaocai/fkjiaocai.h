#ifndef FKJIAOCAI_H_
#define FKJIAOCAI_H_
#include <fkbase/spi-master.h>
#include <math.h>
#include "fkbase/fkbasefun.h"
#include <fkbase/i2c.h>
#define AT24ADDR (0x50)
extern unsigned char pagelist[7][8];
//xiebo
typedef struct
{
	INT32S ua[80];
	INT32S ub[80];
	INT32S uc[80];

	INT32S ia[80];
	INT32S ib[80];
	INT32S ic[80];

}xdata;
xdata XBpoint;
/*******************************************
*3��3 3����ѡ��  ,Kuduan ��ѹ���෧ֵ   Kufan ��ѹ���෵�ط�ֵ
*******************************************
*/
/*******************************************
***************У��ϵ��*****************
*******************************************/
#define JIAOCAIDbg if(RtuDataAddr->DBON)printf
/*******************************************
*ATT�����붨��
*******************************************
*/
#define ATTCMD_WRDI					0x04
#define ATTCMD_WREN					0x06

/*
*******************************************
*ATT�����붨��
*******************************************
*/
////#define ATT_ERR_BYTE				0xFF
////#define ATT_NO_CASE_BIT				0x55

/*
*******************************************
*FRAƬѡIO�ڶ��弰��ز���
*******************************************
*/
#define SPI1   0
extern RTimeData  *RtuDataAddr;//�ڴ湲��������ָ��
extern spi_devinfo_t cfg;
extern spi_cfg_t cfg_t ;
extern int fp;
/*
*******************************************
*ATT��ؽ�����ṹ����
*******************************************
*/
extern int device;
extern unsigned char cmd[1024];
extern INT8U PORT_ID;
extern int setupTimer();
extern void QuitProcess(int signo);
extern name_attach_t *attach;
extern INT32U 	Z_P_ALL_Temp;
extern INT32U 	F_P_ALL_Temp;
extern INT32U 	Q_1_ALL_Temp;
extern INT32U 	Q_2_ALL_Temp;
extern INT32U 	Q_3_ALL_Temp;
extern INT32U 	Q_4_ALL_Temp;
extern INT8U 	FeiLvMin;

/*
*******************************************
*�ӿں�������
*******************************************
*/
extern INT8U 	SpiByteSend(INT8U spi,INT8U da,INT16U to);
extern INT8U 	ATTWriteEnable(INT8U spi,INT16U to);
extern INT8U 	ATTWriteDisable(INT8U spi,INT16U to);
extern INT8U 	ATTStatusGet(INT8U spi,INT16U to);
extern INT8U 	ATTStatusSet(INT8U spi,INT8U st,INT16U to);
extern INT8U 	ATTDataRead(INT8U spi,INT32U addr,INT32U len,INT8U *buf,INT16U to);
extern INT8U 	ATTDataWrite(INT8U spi,INT32U addr,INT32U len,INT8U *buf,INT16U to);
extern void  	ATTInit();
extern INT32S 	ATTRead(INT8U spi,INT32U addr,INT32U len,INT8U *buf,INT16U to);
extern INT32S 	ATTWrite(INT8U spi,INT32U addr,INT32U len,INT8U *buf,INT16U to);
extern unsigned char Att24Tmp[1024];

//��ڲ���˵����reg ��ʼ��ַ��val ���ص���ֵ��num ����

extern int openi2c();
extern void testi(int i,unsigned char* buf);
extern void test2(int i,unsigned char* buf,int len,char* name);
//  ͨ�� I2C ��ȡ����ϵ��
extern void Read_Fk_xiu_I2C(int flag);
extern void readrec();
extern void savetest();
//  ��������ϵ�����浽оƬ  �൱��Save_Fk_xiu_I2C();
extern void savefun(void);
extern INT8U Save_Fk_xiu_Set();
extern INT8U Read_Fk_xiu_Set();
extern void AT24Read(int addr,unsigned char *dest,int len);
extern void AT24Write(int addr,unsigned char data);
extern INT8U ATTWriteEnable(INT8U spi,INT16U to);
extern INT8U ATTWriteDisable(INT8U spi,INT16U to);
extern void RESet7022b();
extern void ATTInit();
extern INT32S ATTRead(INT8U spi,INT32U addr,INT32U len,INT8U *buf,INT16U to);
extern INT32S ATTWrite(INT8U spi,INT32U addr,INT32U len,INT8U *buf,INT16U to);
extern INT32S CkSum,CkSunOld;
extern void att_spi_init (void);
extern void spi_test(void);
/*************************************************************************************/
/*************  ��ѹ��������I0������ У������  ***************************************/
/*************************************************************************************/
//////////////////////2009.3.12/////////////////////
extern void modify_uipp(void);
/*************************************************************************************/
/*************  �ǲ�У������  ********************************************************/
/*************************************************************************************/
//////////////////////2009.03.12//////////////////////
extern void jiaoxiu_pa(void);
extern void mcjiaozheng();
extern void jiaoxiu_pb(void);
extern void jiaoxiu_pc(void);
extern void qingabc(void);
extern void YCP_Jingdu(void);
////////////////////////////////////////////////////////////////////////////////////////////////////////
extern void initdl();
extern void calcdianliang(void);
extern void dddealpro(void);
extern void XuLiangCalc(INT32S *Dest,INT32S *S,INT8U *DestTime,INT32S *CMP,TS ts);
extern void XuLiangRst();
extern void FeiLvCalc();
extern void CreateErr14(INT8U Flag);
extern void DoFkDataChange(TS ts);
extern void DoYouGongShuChu();
extern void DoWuGongShuChu();

#endif /*FKJIAOCAI_H_*/
