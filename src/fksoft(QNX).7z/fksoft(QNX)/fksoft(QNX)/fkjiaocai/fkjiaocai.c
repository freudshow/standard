#include <stdlib.h>
#include <stdio.h>
#include <fkbase/spi-master.h>
#include <string.h>
#include <unistd.h>
#include <hw/inout.h>
#include <sys/mman.h>
#include <fkbase/memdef.h>
#include <fkbase/fkbasefun.h>
#include "fkjiaocai.h"
INT32S CkSum, CkSunOld;
const char verstr[] = { "VER-STRING-FLG=007.002.217.004"__DATE__" "__TIME__ };
INT8U PARSE_CMD(int argc, char * argv[]) {
	char proc_name[32] = "";

	//printf("cmdline=%d,%s %s\r\n", argc, argv[0], argv[1]);
	if (argc < 2)
		return (FALSE);
	PORT_ID = atoi(argv[1]);
	sprintf(proc_name, "%s %d", argv[0], PORT_ID);
	if ((attach = name_attach(NULL, proc_name, 0)) == NULL) {
		fprintf(stderr, "ERR:'%s' runed,cann't regist: %s\r\n", proc_name, strerror(errno));
		return (FALSE);
	}
	return (TRUE);
}
void QuitProcess(int signo) {
	delay(100);
	RtuDataAddr->stPortPara[PORT_ID].PID = 0;
	name_detach(attach, 0);
	fprintf(stderr, "fkjiaocai quit");
	exit(0);
}
void markver()//��Ŀ������б�ʶ�����汾��Ϣ
{
	printf("\n%s\n", verstr);
}
/*********************************/
//���������㲢�Ҵ�����
//********************************/
INT32S ReadXBpoint(void)
{
     INT32S readc=0;
     INT8U temp[3];

     readc=ATTRead(SPI1,0x7f,3,temp,0);

	 if(readc>8388608)
		 readc = (readc>>8) - 0x10000;
	 else
		 readc = readc>>8;
	 return readc;

}
//**************************************************/
// ʹ�ܵ�ѹ\����ͨ����г����������
// 0xa ��ѹͨ�� ���� ua ub uc��˳��Ų�����
// 0xb ��ѹͨ�� ���� ia ib ic��˳��Ų�����
//**************************************************/
void UIXBenable(INT8U t)
{
	INT8U  temp[3];

	temp[0] = 0xcc;
	temp[1] = 0xcc;
	temp[2] = 0xc0 + t;
	ATTWrite(SPI1,0xc0,3,temp,0);     //U I ͨ��ѡ��
}
void ATT7022C()
{
	INT8U i,temp[3];

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //����д����

    //д����//
    UIXBenable(0xA);   //��ѹг��ʹ�ܣ��ɼ�Ua��Ub��Uc
    delay(1000);

	temp[0] = 0x00;
	temp[1] = 0x00;
	temp[2] = 0x00;
	ATTWrite(SPI1,0xc1,3,temp,0);     //U ͨ��0 ��ʼλ��

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 1;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //bu����д����
	JIAOCAIDbg("\n\r--------------------------------UA UB UC");
	for(i=0;i<80;i++)
	{
		CleardeadCount();
		XBpoint.ua[i]=ReadXBpoint();
		XBpoint.ub[i]=ReadXBpoint();
		XBpoint.uc[i]=ReadXBpoint();
//		JIAOCAIDbg("\n\r");
//		JIAOCAIDbg("\n\r%d",XBpoint.ua[i]);
//		JIAOCAIDbg("\n\r7022 XBpoint.ub[%d]=%ld",i,XBpoint.ub[i]);
//		JIAOCAIDbg("\n\r7022 XBpoint.uc[%d]=%ld",i,XBpoint.uc[i]);
	}
	delay(100);

    UIXBenable(0xB);   //����г��ʹ��
	ATTWrite(SPI1,0xc1,3,temp,0);     //I ͨ��0 ��ʼλ��
	JIAOCAIDbg("\n\r--------------------------------IA IB IC");
	for(i=0;i<80;i++)
	{
		CleardeadCount();
		XBpoint.ia[i]=ReadXBpoint();
		XBpoint.ib[i]=ReadXBpoint();
		XBpoint.ic[i]=ReadXBpoint();
		JIAOCAIDbg("\n\r");
		JIAOCAIDbg("\n\r7022 XBpoint.ia[%d]=%ld",i,XBpoint.ia[i]);
		JIAOCAIDbg("\n\r7022 XBpoint.ib[%d]=%ld",i,XBpoint.ib[i]);
		JIAOCAIDbg("\n\r7022 XBpoint.ic[%d]=%ld",i,XBpoint.ic[i]);
	}
	JIAOCAIDbg("\n\r--------------------------------");
    temp[0] = 0x00;
	temp[1] = 0x00;
	temp[2] = 0x00;
    ATTWrite(SPI1,0xc0,3,temp,0);     //�ر������������ݻ���
}
int main(int argc, char *argv[]) {
	struct sigaction sa1;
	INT8U Min, i, Sec,Now_Min;
	int battdly;

	TS ts;
	markver();

	if (OpenMem())
		return EXIT_FAILURE;
	if (RtuDataAddr->mem_len != sizeof(RTimeData)) {
		fprintf(stderr, "base mem uncompared prog will exit %d :\n", sizeof(RTimeData));
		return EXIT_FAILURE;
	}

	if (!PARSE_CMD(argc, argv)) {
		return EXIT_FAILURE;
	}
	//////////////////////////////////////////////////////////////////////////
	sa1.sa_handler = QuitProcess;
	sigemptyset(&sa1.sa_mask);
	sa1.sa_flags = 0;
	sigaction(SIGTERM, &sa1, NULL);
	sigaction(SIGSYS, &sa1, NULL);
	sigaction(SIGPWR, &sa1, NULL);
	sigaction(SIGKILL, &sa1, NULL);
	sigaction(SIGQUIT, &sa1, NULL);
	sigaction(SIGILL, &sa1, NULL);
	sigaction(SIGINT, &sa1, NULL);
	sigaction(SIGHUP, &sa1, NULL);
	sigaction(SIGABRT, &sa1, NULL);
	sigaction(SIGBUS, &sa1, NULL);
	RtuDataAddr->stPortPara[PORT_ID].PID = getpid();
	Min = 0;
	while (RtuDataAddr->Dev_Init_OK == 0) {
		CleardeadCount();
		delay(1000);
	}
	for (i = 0; i < CeLiangPoint_Max; i++)
		RtuDataAddr->CL_ERR[i].Old_PDD = RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_All;

	Read_Fk_xiu_I2C(1);// �� I2C ��ȡϵ��
	ATTInit(); // ATT7022��ʼ��
	att_spi_init(); // ����ȡ��ϵ��д��SPI0���� (�������� оƬ ATT7022)

	initdl();
	TSGet(&ts);
	Sec = ts.Sec;
	Now_Min=ts.Minute;
	battdly = 0;
	RtuDataAddr->Setting = 0;

	for (;;) {
		delay(500);
		CleardeadCount();

		memcpy(&RtuDataAddr->Meter_Para.Valid, &RtuDataAddr->FkInput_Value.F10_Set_Para.Valid, sizeof(RtuDataAddr->FkInput_Value.F10_Set_Para));

		spi_test();
		if (RtuDataAddr->Setting !=1) {
			if (CkSum != CkSunOld) {
				printf("\n\rSaving to 7022 ......");
				printf("\n\r");
				att_spi_init();
				CkSunOld = CkSum;
				printf("\n\rSave to 7022 OK!!!");
				printf("\n\r");
				delay(50);
			}
		}

		TSGet(&ts);
		if (ts.Sec != Sec) {
			dddealpro();//ԭ�����������
			calcdianliang();//7022B�ɼ�������
			Sec = ts.Sec;
			RtuDataAddr->NowFeiLvNo = FeiLvNo(ts);
			FeiLvCalc();
			DoFkDataChange(ts);
			if ((RtuDataAddr->FkDdRealData.VA < SD_Men) && (RtuDataAddr->FkDdRealData.VB < SD_Men) && (RtuDataAddr->FkDdRealData.VC< SD_Men))
			{
				battdly++;
			}
			else
				battdly = 0;
			delay(300);
			if (RtuDataAddr->FkJcXiu == 8) {//SPI ����У���Ĵ�������
				readrec();
				RtuDataAddr->FkJcXiu = 0;
			}
			if (RtuDataAddr->FkJcXiu == 6) {//I2C����
				savetest();
				RtuDataAddr->FkJcXiu = 0;
			}
			if (RtuDataAddr->FkJcXiu == 7) {//У���������
				mcjiaozheng();
				RtuDataAddr->FkJcXiu = 0;
			}
			if (RtuDataAddr->FkJcXiu == 1) {//mpp
				modify_uipp();

				RtuDataAddr->FkJcXiu = 0;
			}
			if (RtuDataAddr->FkJcXiu == 2) {//mpa
				jiaoxiu_pa();
				RtuDataAddr->FkJcXiu = 0;
			}
			if (RtuDataAddr->FkJcXiu == 3) {//mpb
				jiaoxiu_pb();
				RtuDataAddr->FkJcXiu = 0;
			}
			if (RtuDataAddr->FkJcXiu == 4) {//mpc
				jiaoxiu_pc();
				RtuDataAddr->FkJcXiu = 0;
			}
			if (RtuDataAddr->FkJcXiu == 5) {//qing
				qingabc();
				RtuDataAddr->FkJcXiu = 0;
			}
		}
		if (ts.Minute!=Now_Min){
			Now_Min=ts.Minute;
			ATT7022C();
			memcpy(RtuDataAddr->XBpoint.ua, XBpoint.ua, sizeof(RtuDataAddr->XBpoint));
		}
		/*if (ts.Minute!=Now_Min){
			JIAOCAIDbg("\n\r-----------------------------------------------save FkDdRealData");
			Now_Min=ts.Minute;
			Fm25cl64_Write(&RtuDataAddr->FkDdRealData.Valid,sizeof(RtuDataAddr->FkDdRealData),FkDdRealData_Offset);
		}*/
	}
	name_detach(attach, 0);
	return EXIT_SUCCESS;
}
