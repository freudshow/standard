#ifndef AT91SAM9260_PIO_H_
#define AT91SAM9260_PIO_H_

 /* -------------------------------------------------------- */
 /* PIO ID definitions for AT91SAM9260 */
 /* -------------------------------------------------------- */
 #ifndef AT91C_ID_PIOA
 #define AT91C_ID_PIOA 2 /**< Parallel IO Controller A id */
 #endif /* AT91C_ID_PIOA */
 #ifndef AT91C_ID_PIOB
 #define AT91C_ID_PIOB 3 /**< Parallel IO Controller B id */
 #endif /* AT91C_ID_PIOB */
 #ifndef AT91C_ID_PIOC
 #define AT91C_ID_PIOC 4 /**< Parallel IO Controller C id */
 #endif /* AT91C_ID_PIOC */
 
 /* -------------------------------------------------------- */
 /* PIO Base Address definitions for AT91SAM9260 */
 /* -------------------------------------------------------- */
 #define AT91C_BASE_PIOA 0xFFFFF400 /**< PIOA base address */
 #define AT91C_BASE_PIOB 0xFFFFF600 /**< PIOB base address */
 #define AT91C_BASE_PIOC 0xFFFFF800 /**< PIOC base address */
 
 /* -------------------------------------------------------- */
 /* PIO definition for PIO hardware peripheral */
 /* -------------------------------------------------------- */
 
 /* -------------------------------------------------------- */
 /* Register offset definition for PIO hardware peripheral */
 /* -------------------------------------------------------- */
 #define PIO_PER (0x0000) /**< PIO Enable Register */
 #define PIO_PDR (0x0004) /**< PIO Disable Register */
 #define PIO_PSR (0x0008) /**< PIO Status Register */
 #define PIO_OER (0x0010) /**< Output Enable Register */
 #define PIO_ODR (0x0014) /**< Output Disable Registerr */
 #define PIO_OSR (0x0018) /**< Output Status Register */
 #define PIO_IFER (0x0020) /**< Input Filter Enable Register */
 #define PIO_IFDR (0x0024) /**< Input Filter Disable Register */
 #define PIO_IFSR (0x0028) /**< Input Filter Status Register */
 #define PIO_SODR (0x0030) /**< Set Output Data Register */
 #define PIO_CODR (0x0034) /**< Clear Output Data Register */
 #define PIO_ODSR (0x0038) /**< Output Data Status Register */
 #define PIO_PDSR (0x003C) /**< Pin Data Status Register */
 #define PIO_IER (0x0040) /**< Interrupt Enable Register */
 #define PIO_IDR (0x0044) /**< Interrupt Disable Register */
 #define PIO_IMR (0x0048) /**< Interrupt Mask Register */
 #define PIO_ISR (0x004C) /**< Interrupt Status Register */
 #define PIO_MDER (0x0050) /**< Multi-driver Enable Register */
 #define PIO_MDDR (0x0054) /**< Multi-driver Disable Register */
 #define PIO_MDSR (0x0058) /**< Multi-driver Status Register */
 #define PIO_PPUDR (0x0060) /**< Pull-up Disable Register */
 #define PIO_PPUER (0x0064) /**< Pull-up Enable Register */
 #define PIO_PPUSR (0x0068) /**< Pull-up Status Register */
 #define PIO_ASR (0x0070) /**< Select A Register */
 #define PIO_BSR (0x0074) /**< Select B Register */
 #define PIO_ABSR (0x0078) /**< AB Select Status Register */
 #define PIO_OWER (0x00A0) /**< Output Write Enable Register */
 #define PIO_OWDR (0x00A4) /**< Output Write Disable Register */
 #define PIO_OWSR (0x00A8) /**< Output Write Status Register */
 
 /* -------------------------------------------------------- */
 /* Bitfields definition for PIO hardware peripheral */
 /* -------------------------------------------------------- */
 

#endif /*AT91SAM9260_PIO_H_*/
