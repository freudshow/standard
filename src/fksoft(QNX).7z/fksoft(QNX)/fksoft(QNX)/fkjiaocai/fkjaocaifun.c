/*
 * fkjaocaifun.c
 *
 *  Created on: Dec 16, 2009
 *      Author: ln
 */

#include <fkbase/spi-master.h>
#include <math.h>
#include "fkbase/fkbasefun.h"
#include "fkjiaocai.h"

//----------I2C

#include <fkbase/i2c.h>
#define AT24ADDR (0x50)
static int i2cfd = -1;
unsigned char pagelist[7][8];
//�¶Ȳ���ϵ��
#define WDXISHU  996
#define WDCANSHU 10
/***************************************/

/*******************************************
 *3��3 3����ѡ��  ,Kuduan ��ѹ���෧ֵ   Kufan ��ѹ���෵�ط�ֵ
 *******************************************
 */

/*******************************************
 ***************У��ϵ��*****************
 *******************************************/
/*******************************************
 *ATT�����붨��
 *******************************************
 */
////#define ATTCMD_WRSR					0x01
////#define ATTCMD_WRITE				0x02
////#define ATTCMD_READ					0x3e
////#define ATTCMD_WRDI					0x04
////#define ATTCMD_RDSR					0x05
////#define ATTCMD_WREN					0x06

/*
 *******************************************
 *ATT�����붨��
 *******************************************
 */
////#define ATT_ERR_BYTE				0xFF
////#define ATT_NO_CASE_BIT				0x55

/*
 *******************************************
 *FRAƬѡIO�ڶ��弰��ز���
 *******************************************
 */

////#define ATT_ADDR_BYTE 					2
////#define ATT_ADDR_BIT_MASK 				0x7FFF

////#define  ATT_EXT  extern
#define SPI1   0
RTimeData *RtuDataAddr;//�ڴ湲��������ָ��

spi_devinfo_t cfg;
spi_cfg_t cfg_t;
int fp = -1;

/*
 *******************************************
 *ATT��ؽ�����ṹ����
 *******************************************
 */

int device = 0;
unsigned char cmd[1024];
////unsigned char spirec[1024];

INT8U PORT_ID;
////int id1;
int setupTimer();
void QuitProcess(int signo);
////int chid;
name_attach_t *attach;
////int ComPort;
INT32U Z_P_ALL_Temp;
INT32U F_P_ALL_Temp;
INT32U Q_1_ALL_Temp;
INT32U Q_2_ALL_Temp;
INT32U Q_3_ALL_Temp;
INT32U Q_4_ALL_Temp;
INT8U FeiLvMin;

/*
 *******************************************
 *�ӿں�������
 *******************************************
 */
INT8U SpiByteSend(INT8U spi, INT8U da, INT16U to);

INT8U ATTWriteEnable(INT8U spi, INT16U to);

INT8U ATTWriteDisable(INT8U spi, INT16U to);

INT8U ATTStatusGet(INT8U spi, INT16U to);

INT8U ATTStatusSet(INT8U spi, INT8U st, INT16U to);

INT8U ATTDataRead(INT8U spi, INT32U addr, INT32U len, INT8U *buf, INT16U to);

INT8U ATTDataWrite(INT8U spi, INT32U addr, INT32U len, INT8U *buf, INT16U to);

void ATTInit();

INT32S ATTRead(INT8U spi, INT32U addr, INT32U len, INT8U *buf, INT16U to);

INT32S ATTWrite(INT8U spi, INT32U addr, INT32U len, INT8U *buf, INT16U to);

unsigned char Att24Tmp[1024];

//��ڲ���˵����reg ��ʼ��ַ��val ���ص���ֵ��num ����

static int i2c_read(unsigned char reg, unsigned char val[], unsigned char num) {
	iov_t siov[2], riov[2];
	i2c_sendrecv_t hdr;

	hdr.slave.addr = AT24ADDR;
	hdr.slave.fmt = I2C_ADDRFMT_7BIT;
	hdr.send_len = 1;
	hdr.recv_len = num;
	hdr.stop = 1;

	SETIOV(&siov[0], &hdr, sizeof(hdr));
	SETIOV(&siov[1], &reg, sizeof(reg));

	SETIOV(&riov[0], &hdr, sizeof(hdr));
	SETIOV(&riov[1], val, num);

	return devctlv(i2cfd, DCMD_I2C_SENDRECV, 2, 2, siov, riov, NULL);

}

//��ڲ���˵����reg ��ʼ��ַ��val Ҫд����ֵ��num ����
//ע�⣺                    д�����ǰ���ҳ�����ġ�ÿҳ8���ֽڡ�
//             ����    num �������Ϊ8
static int i2c_write(unsigned char reg, unsigned char val[], unsigned char num) {
	iov_t siov[3];
	i2c_send_t hdr;

	hdr.slave.addr = AT24ADDR;
	hdr.slave.fmt = I2C_ADDRFMT_7BIT;
	hdr.len = num + 1;
	hdr.stop = 1;

	SETIOV(&siov[0], &hdr, sizeof(hdr));
	SETIOV(&siov[1], &reg, sizeof(reg));
	SETIOV(&siov[2], val, num);

	return devctlv(i2cfd, DCMD_I2C_SEND, 3, 0, siov, NULL, NULL);
}
int openi2c() {
	if ((i2cfd = open("/dev/i2c0", O_RDWR)) < 0) {
		//printf("Error Occured while opening Device File.!!  %d \n", i2cfd);
		return 0;
	} else {
		//printf("Device File Opened Successfully !! %d\n",i2cfd);
		return 1;
	}
}
void testi(int i, unsigned char* buf) {
#if 0
	printf("\n\r -------------------------------");
	printf("\n\r page = %d",i);
	printf("\n\r Display[0]=========%d",buf[0]);
	printf("\n\r Display[1]=========%d",buf[1]);
	printf("\n\r Display[2]=========%d",buf[2]);
#endif

}
void test2(int i, unsigned char* buf, int len, char* name) {
#if 0
	int k = 0;
	printf("\n\r -------------------------------");
	printf("\n\r page = %d %s",i,name);
	for(k=0;k<len;k++)
	{
		printf("\n\r After Xiuzheng  %d",buf[k]);
	}
#endif
}
//  ͨ�� I2C ��ȡ����ϵ��
void Read_Fk_xiu_I2C(int flag) {
	unsigned char rbuf[128];
	int i;
	int index = 0;
	static int ret;
	unsigned char pagetmp[8];
	flag = openi2c();
	if (flag == 1) {
		delay(10);
		for (i = 0; i < 128; i++) {
			ret = i2c_read(i, &rbuf[i], 1);
			delay(10);
		}
		if (i2cfd > 0)
			close(i2cfd);

		memcpy(pagetmp, rbuf + index, 8);
		RtuDataAddr->displayUA_xishu[0] = pagetmp[0];
		RtuDataAddr->displayUA_xishu[1] = pagetmp[1];
		RtuDataAddr->displayUA_xishu[2] = pagetmp[2];
		testi(index, RtuDataAddr->displayUA_xishu);
		RtuDataAddr->displayUB_xishu[0] = pagetmp[4];
		RtuDataAddr->displayUB_xishu[1] = pagetmp[5];
		RtuDataAddr->displayUB_xishu[2] = pagetmp[6];
		testi(index, RtuDataAddr->displayUB_xishu);
		index = index + 8;
		delay(10);

		memcpy(pagetmp, rbuf + index, 8);
		RtuDataAddr->displayUC_xishu[0] = pagetmp[0];
		RtuDataAddr->displayUC_xishu[1] = pagetmp[1];
		RtuDataAddr->displayUC_xishu[2] = pagetmp[2];
		testi(index, RtuDataAddr->displayUC_xishu);
		RtuDataAddr->displayIA_xishu[0] = pagetmp[4];
		RtuDataAddr->displayIA_xishu[1] = pagetmp[5];
		RtuDataAddr->displayIA_xishu[2] = pagetmp[6];
		testi(index, RtuDataAddr->displayIA_xishu);
		index = index + 8;
		delay(10);

		memcpy(pagetmp, rbuf + index, 8);
		RtuDataAddr->displayIB_xishu[0] = pagetmp[0];
		RtuDataAddr->displayIB_xishu[1] = pagetmp[1];
		RtuDataAddr->displayIB_xishu[2] = pagetmp[2];
		testi(index, RtuDataAddr->displayIB_xishu);
		RtuDataAddr->displayIC_xishu[0] = pagetmp[4];
		RtuDataAddr->displayIC_xishu[1] = pagetmp[5];
		RtuDataAddr->displayIC_xishu[2] = pagetmp[6];
		testi(index, RtuDataAddr->displayIC_xishu);
		index = index + 8;
		delay(10);

		memcpy(pagetmp, rbuf + index, 8);
		RtuDataAddr->displayI0_xishu[0] = pagetmp[0];
		RtuDataAddr->displayI0_xishu[1] = pagetmp[1];
		RtuDataAddr->displayI0_xishu[2] = pagetmp[2];
		testi(index, RtuDataAddr->displayI0_xishu);
		RtuDataAddr->displayPA_xishu[0] = pagetmp[4];
		RtuDataAddr->displayPA_xishu[1] = pagetmp[5];
		RtuDataAddr->displayPA_xishu[2] = pagetmp[6];
		testi(index, RtuDataAddr->displayPA_xishu);
		index = index + 8;
		delay(10);

		memcpy(pagetmp, rbuf + index, 8);
		RtuDataAddr->displayPB_xishu[0] = pagetmp[0];
		RtuDataAddr->displayPB_xishu[1] = pagetmp[1];
		RtuDataAddr->displayPB_xishu[2] = pagetmp[2];
		testi(index, RtuDataAddr->displayPB_xishu);
		RtuDataAddr->displayPC_xishu[0] = pagetmp[4];
		RtuDataAddr->displayPC_xishu[1] = pagetmp[5];
		RtuDataAddr->displayPC_xishu[2] = pagetmp[6];
		testi(index, RtuDataAddr->displayPC_xishu);
		index = index + 8;
		delay(10);

		memcpy(pagetmp, rbuf + index, 8);
		RtuDataAddr->displayA_jiaoxiu[0] = pagetmp[0];
		RtuDataAddr->displayA_jiaoxiu[1] = pagetmp[1];
		RtuDataAddr->displayA_jiaoxiu[2] = pagetmp[2];
		testi(index, RtuDataAddr->displayA_jiaoxiu);
		RtuDataAddr->displayB_jiaoxiu[0] = pagetmp[4];
		RtuDataAddr->displayB_jiaoxiu[1] = pagetmp[5];
		RtuDataAddr->displayB_jiaoxiu[2] = pagetmp[6];
		testi(index, RtuDataAddr->displayB_jiaoxiu);
		index = index + 8;
		delay(10);

		memcpy(pagetmp, rbuf + index, 8);
		RtuDataAddr->displayC_jiaoxiu[0] = pagetmp[0];
		RtuDataAddr->displayC_jiaoxiu[1] = pagetmp[1];
		RtuDataAddr->displayC_jiaoxiu[2] = pagetmp[2];
		testi(index, RtuDataAddr->displayC_jiaoxiu);
		RtuDataAddr->displayMC_out_xishu[0] = pagetmp[4];
		RtuDataAddr->displayMC_out_xishu[1] = pagetmp[5];
		RtuDataAddr->displayMC_out_xishu[2] = pagetmp[6];
		testi(index, RtuDataAddr->displayMC_out_xishu);

	} else {
		return;
	}
}
void readrec() {
	//printf("\n\r read rec form spi");
	INT8U temp[3];
	temp[0] = 0x00;
	temp[1] = 0x00;
	temp[2] = 0x5A;
	ATTWrite(SPI1, 0xC6, 3, temp, 0);//ѡ���ȡУ���Ĵ�������
	sleep(1);
	ATTRead(SPI1, 0x00, 3, temp, 0);
	//printf("\n\r temp[0]=%x temp[1]=%x temp[2]=%x", temp[0], temp[1], temp[2]);
	if ((temp[0] == 0xAA) && (temp[1] == 0xAA) && (temp[2] == 0xAA)) {
		ATTRead(SPI1, 0x020, 3, temp, 0);
		ATTRead(SPI1, 0x06, 3, temp, 0);
		ATTRead(SPI1, 0x09, 3, temp, 0);
		ATTRead(SPI1, 0x07, 3, temp, 0);
		ATTRead(SPI1, 0x0A, 3, temp, 0);
		ATTRead(SPI1, 0x08, 3, temp, 0);
		ATTRead(SPI1, 0x0B, 3, temp, 0);
	}
	temp[0] = 0x00;
	temp[1] = 0x00;
	temp[1] = 0x00;
	ATTWrite(SPI1, 0xc6, 3, temp, 0);//ѡ���ȡУ���Ĵ�������
	//printf("\n\r read end.");
}
void savetest() {
	INT8U temp[3], i;
	INT32S ATT_PA, ATT_PB, ATT_PC;
	INT32S XISHU_PA, XISHU_PB, XISHU_PC;

	for (i = 0; i < 0x1D; i++) {
		RtuDataAddr->REC[i] = ATTRead(SPI1, i, 3, temp, 0);
	}
	RtuDataAddr->REC[0x29] = ATTRead(SPI1, 0x29, 3, temp, 0);

	if (RtuDataAddr->REC[0x01] > 8388608)
		ATT_PA = (RtuDataAddr->REC[0x01] - 16777216) / 256; //pa
	else
		ATT_PA = RtuDataAddr->REC[0x01] / 256;



	if (RtuDataAddr->REC[0x02] > 8388608)
		ATT_PB = (RtuDataAddr->REC[0x02] - 16777216) / 256; //pb
	else
		ATT_PB = RtuDataAddr->REC[0x02] / 256;

	if (RtuDataAddr->REC[0x03] > 8388608)
		ATT_PC = (RtuDataAddr->REC[0x03] - 16777216) / 256; //pc
	else
		ATT_PC = RtuDataAddr->REC[0x03] / 256;

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //����д����
	if(RtuDataAddr->RES.RES_JXFS == 04) // ��������
	{
		if (ATT_PA != 0) {
			ATT_PA = ATT_PA / 2;
			if (1100 >= ATT_PA)
				XISHU_PA = ((1100 - ATT_PA) * 32768 / ATT_PA) * 256; //PA
			else
				XISHU_PA = ((1100 + ATT_PA) * 32768 / ATT_PA) * 256;

			//XISHU_PA = ((ATT_PA - 1100)*100/1100);
			//XISHU_PA=XISHU_PA/256;

			temp[0] = (XISHU_PA & 0xff0000) >> 16;
			temp[1] = (XISHU_PA & 0xff00) >> 8;
			temp[2] = XISHU_PA & 0xff;
			//temp[0] = 0x00;
			//temp[1] = 0xF4;
			//temp[2] = 0x4A;
			RtuDataAddr->displayPA_xishu[0] = temp[0];
			RtuDataAddr->displayPA_xishu[1] = temp[1];
			RtuDataAddr->displayPA_xishu[2] = temp[2];

			ATTWrite(SPI1, 0x06, 3, temp, 0);
			ATTWrite(SPI1, 0x09, 3, temp, 0);
		} else JIAOCAIDbg("%s\r\n", "�Ҹ�ʲô�ɻ���");

		if (ATT_PB != 0) {
			ATT_PB = ATT_PB / 2;
			if (1100 >= ATT_PB)
				XISHU_PB = ((1100 - ATT_PB) * 32768 / ATT_PB) * 256; //PB
			else
				XISHU_PB = ((1100 + ATT_PB) * 32768 / ATT_PB) * 256;
			//XISHU_PB = ((ATT_PB - 1100)*100/1100);
			//XISHU_PB = XISHU_PB/256;
			temp[0] = (XISHU_PB & 0xff0000) >> 16;
			temp[1] = (XISHU_PB & 0xff00) >> 8;
			temp[2] = XISHU_PB & 0xff;
			//temp[0] = 0x07;
			//temp[1] = 0xB5;
			//temp[2] = 0x4E;

			RtuDataAddr->displayPB_xishu[0] = temp[0];
			RtuDataAddr->displayPB_xishu[1] = temp[1];
			RtuDataAddr->displayPB_xishu[2] = temp[2];

			ATTWrite(SPI1, 0x07, 3, temp, 0);
			ATTWrite(SPI1, 0x0A, 3, temp, 0);
		} else JIAOCAIDbg("%s\r\n", "�Ҹ�ʲô�ɻ���");

		if (ATT_PC != 0) {
			ATT_PC = ATT_PC / 2;
			if (1100 >= ATT_PC)
				XISHU_PC = ((1100 - ATT_PC) * 32768 / ATT_PC) * 256; //PC
			else
				XISHU_PC = ((1100 + ATT_PC) * 32768 / ATT_PC) * 256;

			temp[0] = (XISHU_PC & 0xff0000) >> 16;
			temp[1] = (XISHU_PC & 0xff00) >> 8;
			temp[2] = XISHU_PC & 0xff;

			RtuDataAddr->displayPC_xishu[0] = temp[0];
			RtuDataAddr->displayPC_xishu[1] = temp[1];
			RtuDataAddr->displayPC_xishu[2] = temp[2];

			ATTWrite(SPI1, 0x08, 3, temp, 0);
			ATTWrite(SPI1, 0x0B, 3, temp, 0);
		} else JIAOCAIDbg("%s\r\n", "�Ҹ�ʲô�ɻ���");
	}
	if(RtuDataAddr->RES.RES_JXFS == 03) // ��������
	{
		if (ATT_PA != 0)
		{
			ATT_PA = ATT_PA / 2;
			if (433 >= ATT_PA)
				XISHU_PA = ((433 - ATT_PA) * 32768 / ATT_PA) * 256; //PA / *10000
			else
				XISHU_PA = ((433 + ATT_PA) * 32768 / ATT_PA) * 256;

			temp[0] = (XISHU_PA & 0xff0000) >> 16;
			temp[1] = (XISHU_PA & 0xff00) >> 8;
			temp[2] = XISHU_PA & 0xff;

			RtuDataAddr->displayPA_xishu[0] = temp[0];
			RtuDataAddr->displayPA_xishu[1] = temp[1];
			RtuDataAddr->displayPA_xishu[2] = temp[2];

			ATTWrite(SPI1, 0x06, 3, temp, 0);
			ATTWrite(SPI1, 0x09, 3, temp, 0);
			ATTWrite(SPI1, 0x07, 3, temp, 0);
			ATTWrite(SPI1, 0x0a, 3, temp, 0);
		} else JIAOCAIDbg("%s\r\n", "�Ҹ�ʲô�ɻ���");

		if (ATT_PC != 0)
		{
			ATT_PC = ATT_PC / 2;
			if (433 >= ATT_PC)
				XISHU_PC = ((433 - ATT_PC) * 32768 / ATT_PC) * 256; //PC
			else
				XISHU_PC = ((433 + ATT_PC) * 32768 / ATT_PC) * 256;

			temp[0] = (XISHU_PC & 0xff0000) >> 16;
			temp[1] = (XISHU_PC & 0xff00) >> 8;
			temp[2] = XISHU_PC & 0xff;

			RtuDataAddr->displayPC_xishu[0] = temp[0];
			RtuDataAddr->displayPC_xishu[1] = temp[1];
			RtuDataAddr->displayPC_xishu[2] = temp[2];

			ATTWrite(SPI1, 0x08, 3, temp, 0);
			ATTWrite(SPI1, 0x0B, 3, temp, 0);
		} else JIAOCAIDbg("%s\r\n", "�Ҹ�ʲô�ɻ���");
	}
	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 1;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //bu����д����
	savefun();
	printf("\n\r test over!!!!!");
	printf("\n\r over!!!!!");
	printf("\n\r");
}
//  ��������ϵ�����浽оƬ  �൱��Save_Fk_xiu_I2C();
void savefun(void) {
	int i, j;
	if (openi2c()) {
		memset(pagelist, 0, 56);
		pagelist[0][0] = RtuDataAddr->displayUA_xishu[0];
		pagelist[0][1] = RtuDataAddr->displayUA_xishu[1];
		pagelist[0][2] = RtuDataAddr->displayUA_xishu[2];
		test2(0, &pagelist[0][0], 3, "Ua");
		pagelist[0][4] = RtuDataAddr->displayUB_xishu[0];
		pagelist[0][5] = RtuDataAddr->displayUB_xishu[1];
		pagelist[0][6] = RtuDataAddr->displayUB_xishu[2];
		test2(0, &pagelist[0][4], 3, "Ub");
		//-----------------------------
		pagelist[1][0] = RtuDataAddr->displayUC_xishu[0];
		pagelist[1][1] = RtuDataAddr->displayUC_xishu[1];
		pagelist[1][2] = RtuDataAddr->displayUC_xishu[2];
		test2(1, &pagelist[1][0], 3, "Uc");
		pagelist[1][4] = RtuDataAddr->displayIA_xishu[0];
		pagelist[1][5] = RtuDataAddr->displayIA_xishu[1];
		pagelist[1][6] = RtuDataAddr->displayIA_xishu[2];
		test2(1, &pagelist[1][4], 3, "Ia");
		//-----------------------------
		pagelist[2][0] = RtuDataAddr->displayIB_xishu[0];
		pagelist[2][1] = RtuDataAddr->displayIB_xishu[1];
		pagelist[2][2] = RtuDataAddr->displayIB_xishu[2];
		test2(2, &pagelist[2][0], 3, "Ib");
		pagelist[2][4] = RtuDataAddr->displayIC_xishu[0];
		pagelist[2][5] = RtuDataAddr->displayIC_xishu[1];
		pagelist[2][6] = RtuDataAddr->displayIC_xishu[2];
		test2(2, &pagelist[2][4], 3, "Ic");
		//-----------------------------
		pagelist[3][0] = RtuDataAddr->displayI0_xishu[0];
		pagelist[3][1] = RtuDataAddr->displayI0_xishu[1];
		pagelist[3][2] = RtuDataAddr->displayI0_xishu[2];
		test2(3, &pagelist[3][0], 3, "I0");
		pagelist[3][4] = RtuDataAddr->displayPA_xishu[0];
		pagelist[3][5] = RtuDataAddr->displayPA_xishu[1];
		pagelist[3][6] = RtuDataAddr->displayPA_xishu[2];
		test2(3, &pagelist[3][4], 3, "PA");
		//-----------------------------
		pagelist[4][0] = RtuDataAddr->displayPB_xishu[0];
		pagelist[4][1] = RtuDataAddr->displayPB_xishu[1];
		pagelist[4][2] = RtuDataAddr->displayPB_xishu[2];
		test2(4, &pagelist[4][0], 3, "PB");
		pagelist[4][4] = RtuDataAddr->displayPC_xishu[0];
		pagelist[4][5] = RtuDataAddr->displayPC_xishu[1];
		pagelist[4][6] = RtuDataAddr->displayPC_xishu[2];
		test2(4, &pagelist[4][4], 3, "PC");
		//-----------------------------
		pagelist[5][0] = RtuDataAddr->displayA_jiaoxiu[0];
		pagelist[5][1] = RtuDataAddr->displayA_jiaoxiu[1];
		pagelist[5][2] = RtuDataAddr->displayA_jiaoxiu[2];
		test2(5, &pagelist[5][0], 3, "ja");
		pagelist[5][4] = RtuDataAddr->displayB_jiaoxiu[0];
		pagelist[5][5] = RtuDataAddr->displayB_jiaoxiu[1];
		pagelist[5][6] = RtuDataAddr->displayB_jiaoxiu[2];
		test2(5, &pagelist[5][4], 3, "jb");
		//-----------------------------
		pagelist[6][0] = RtuDataAddr->displayC_jiaoxiu[0];
		pagelist[6][1] = RtuDataAddr->displayC_jiaoxiu[1];
		pagelist[6][2] = RtuDataAddr->displayC_jiaoxiu[2];
		test2(6, &pagelist[6][0], 3, "jc");
		pagelist[6][4] = RtuDataAddr->displayMC_out_xishu[0];
		pagelist[6][5] = RtuDataAddr->displayMC_out_xishu[1];
		pagelist[6][6] = RtuDataAddr->displayMC_out_xishu[2];
		test2(6, &pagelist[6][4], 3, "mc");
		//printf("\n\r end!!!");
		delay(1000);

		for (i = 0; i < 7; i++) {
			for (j = 0; j < 8; j++) {
				delay(100);
				i2c_write(i * 8 + j, &pagelist[i][j], 1);
			}
		}
		delay(500);
		if (i2cfd > 0)
			close(i2cfd);
	}
}

INT8U Save_Fk_xiu_Set() {
	FILE *fp;
	sem_wait(&RtuDataAddr->UseFileFlg);
	fp = fopen("/config/pfkxiu.set", "w");
	if (fp != NULL) {
		fseek(fp, 0, SEEK_SET);
		fwrite(Att24Tmp, sizeof(Att24Tmp), 1, fp);
		fclose(fp);
		sem_post(&RtuDataAddr->UseFileFlg);
		return TRUE;
	}
	sem_post(&RtuDataAddr->UseFileFlg);
	return FALSE;
}
INT8U Read_Fk_xiu_Set() {
	FILE *fp;
	sem_wait(&RtuDataAddr->UseFileFlg);
	fp = fopen("/config/pfkxiu.set", "r");
	if (fp != NULL) {
		fseek(fp, 0, SEEK_SET);
		fread(Att24Tmp, sizeof(Att24Tmp), 1, fp);
		fclose(fp);
		sem_post(&RtuDataAddr->UseFileFlg);
		return TRUE;
	}
	sem_post(&RtuDataAddr->UseFileFlg);
	return FALSE;
}

void AT24Read(int addr, unsigned char *dest, int len) {
	//memcpy(dest,&Att24Tmp[addr],len);
}
void AT24Write(int addr, unsigned char data) {
	Att24Tmp[addr] = data;
}

INT8U ATTWriteEnable(INT8U spi, INT16U to) {
	int cnt = 0;
	cmd[cnt++] = ATTCMD_WREN;
	spi_write(fp, device, cmd, cnt);
	return 0;
}

INT8U ATTWriteDisable(INT8U spi, INT16U to) {
	int cnt = 0;
	cmd[cnt++] = ATTCMD_WRDI;
	spi_write(fp, device, cmd, cnt);
	return 0;
}

void RESet7022b() {
	if (fp != -1) {
		spi_close(fp);
	}
	fp = spi_open("/dev/spi1");
	spi_getdevinfo(fp, device, &cfg);
	//printf("\nRESet7022b:cfg.name=%s cfg.device=%d cfg.clock_rate=%d cfg.mode=%x\n",cfg.name,cfg.device,cfg.cfg.clock_rate,cfg.cfg.mode);
}

void ATTInit() {
	INT8U temp[3];
	INT32U jiexianfangshi;
	RtuDataAddr->mod_uip_flag = 0;
	RtuDataAddr->mod_q_flag = 0;
	if (!PortOpened) {
		OpenGPIO();  //quxiaogpio
		printf("\n\r opengpio ******");
	}  //quxiaogpio

	GpioEnable(1, 29);//�¼���
	RESet7022b();
	GpioClear(1, 29);//�¼���
	OSTimeDly(10);
	GpioSet(1, 29);//�¼���
	OSTimeDly(1000);

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //����д����
	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0;
	ATTWrite(SPI1, 0xc3, 3, temp, 0); //��У���Ĵ���
	temp[0] = 0;
	temp[1] = 0x35;
	temp[2] = 0x84; //dian ya jian ce shi neng
	ATTWrite(SPI1, 0x2e, 3, temp, 0);
	temp[0] = 0;
	temp[1] = 0x56;
	temp[2] = 0x78; //dian liu jian ce shi neng
	ATTWrite(SPI1, 0x30, 3, temp, 0);
	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 1;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //bu����д����

	while(1)
	{
		jiexianfangshi = ATTRead(SPI1, 0x3e, 3, temp, 0);
		if ((jiexianfangshi&0xff0000) == 0x040000)
		{
			RtuDataAddr->RES.RES_JXFS = 4;
			break;
		}
		if ((jiexianfangshi&0xff0000) == 0x160000)
		{
			RtuDataAddr->RES.RES_JXFS = 3;
			break;
		}
	}
}

INT32S ATTRead(INT8U spi, INT32U addr, INT32U len, INT8U *buf, INT16U to) {
	INT32U i;
	INT32S rec;
	int cnt = 0;

	cmd[cnt++] = addr & 0x7f;
	spi_cmdread(fp, device, cmd, cnt, buf, len);
	rec = 0;
	for (i = 0; i < len; i++) {
		rec = (rec << 8) | buf[i];
	}
	return rec;
}

INT32S ATTWrite(INT8U spi, INT32U addr, INT32U len, INT8U *buf, INT16U to) {
	INT32U i;
	int cnt = 0;
	int num;

	if ((addr == 0xC3) || (addr == 0xC6) || (addr == 0xC9) || (addr == 0xD3)) {
		cmd[cnt++] = addr | 0xC0; //д��������
	} else
		cmd[cnt++] = addr | 0x80; //д����У������
	for (i = 0; i < len; i++) {
		cmd[cnt++] = buf[i];
	}
	num = spi_write(fp, device, cmd, cnt);
	return 0;
}
extern INT32S CkSum, CkSunOld;
void att_spi_init(void) {
	INT8U tempp[3];

	delay(50);
	tempp[0] = 0;
	tempp[1] = 0;
	tempp[2] = 0;
	ATTWrite(SPI1, 0xc9, 3, tempp, 0); //����д����

	tempp[0] = 0x46;
    tempp[1] = 0x55;
	tempp[2] = 0x01;

	ATTWrite(SPI1, 0x3f, 3, tempp, 0); //��ѹͨ��AD����

	tempp[0] = 0x0;
	tempp[1] = 0x0;
	tempp[2] = 0x4;
	ATTWrite(SPI1, 0x2c, 3, tempp, 0); //�¶�ʹ��

	tempp[0] = 0x0;
	tempp[1] = 0x56;
	tempp[2] = 0x78;
	ATTWrite(SPI1, 0x30, 3, tempp, 0); //�������ʹ��

	//ATTWrite(SPI1,0x20,3,RtuDataAddr->displayMC_out_xishu,0);

	ATTWrite(SPI1, 0x1B, 3, RtuDataAddr->displayUA_xishu, 0);
	ATTWrite(SPI1, 0x1C, 3, RtuDataAddr->displayUB_xishu, 0);
	ATTWrite(SPI1, 0x1D, 3, RtuDataAddr->displayUC_xishu, 0);

	ATTWrite(SPI1, 0x26, 3, RtuDataAddr->displayIA_xishu, 0);
	ATTWrite(SPI1, 0x27, 3, RtuDataAddr->displayIB_xishu, 0);
	ATTWrite(SPI1, 0x28, 3, RtuDataAddr->displayIC_xishu, 0);
	ATTWrite(SPI1, 0x2B, 3, RtuDataAddr->displayI0_xishu, 0);
	//.......................
	tempp[0] = 0;
	tempp[1] = 0;
	tempp[2] = 18;//RtuDataAddr->McAttr;//0xb;//0x39;//53;72//  8000 ->2d  6400->39
	//ATTWrite(SPI1,0x20,3,RtuDataAddr->displayMC_out_xishu,0);///�������
	//ATTWrite(SPI1,0x20,3,tempp,0);///�������
	//.......................

	ATTWrite(SPI1, 0x06, 3, RtuDataAddr->displayPA_xishu, 0);
	ATTWrite(SPI1, 0x09, 3, RtuDataAddr->displayPA_xishu, 0);

	ATTWrite(SPI1, 0x07, 3, RtuDataAddr->displayPB_xishu, 0);
	ATTWrite(SPI1, 0x0A, 3, RtuDataAddr->displayPB_xishu, 0);

	ATTWrite(SPI1, 0x08, 3, RtuDataAddr->displayPC_xishu, 0);
	ATTWrite(SPI1, 0x0B, 3, RtuDataAddr->displayPC_xishu, 0);
	if (RtuDataAddr->RES.RES_JXFS == 04) //jiaoxiu
	{
		ATTWrite(SPI1, 0xc, 3, RtuDataAddr->displayA_jiaoxiu, 0);
		ATTWrite(SPI1, 0xd, 3, RtuDataAddr->displayA_jiaoxiu, 0);
		ATTWrite(SPI1, 0xe, 3, RtuDataAddr->displayA_jiaoxiu, 0);
		ATTWrite(SPI1, 0xf, 3, RtuDataAddr->displayA_jiaoxiu, 0);
		ATTWrite(SPI1, 0x10, 3, RtuDataAddr->displayA_jiaoxiu, 0);

		ATTWrite(SPI1, 0x11, 3, RtuDataAddr->displayB_jiaoxiu, 0);
		ATTWrite(SPI1, 0x12, 3, RtuDataAddr->displayB_jiaoxiu, 0);
		ATTWrite(SPI1, 0x13, 3, RtuDataAddr->displayB_jiaoxiu, 0);
		ATTWrite(SPI1, 0x14, 3, RtuDataAddr->displayB_jiaoxiu, 0);
		ATTWrite(SPI1, 0x15, 3, RtuDataAddr->displayB_jiaoxiu, 0);

		ATTWrite(SPI1, 0x16, 3, RtuDataAddr->displayC_jiaoxiu, 0);
		ATTWrite(SPI1, 0x17, 3, RtuDataAddr->displayC_jiaoxiu, 0);
		ATTWrite(SPI1, 0x18, 3, RtuDataAddr->displayC_jiaoxiu, 0);
		ATTWrite(SPI1, 0x19, 3, RtuDataAddr->displayC_jiaoxiu, 0);
		ATTWrite(SPI1, 0x1A, 3, RtuDataAddr->displayC_jiaoxiu, 0);
	}
	tempp[0] = 0;
	tempp[1] = 0;
	tempp[2] = 1;
	ATTWrite(SPI1, 0xc9, 3, tempp, 0); //bu����д����
	delay(1000);
	CkSum = ATTRead(SPI1, 0x3e, 3, tempp, 0);
	CkSunOld = ATTRead(SPI1, 0x3e, 3, tempp, 0);
}
void spi_test(void) {
	INT8U temp[3], tempi;
	FP64 j;
	int i;
	INT32U temper;
	INT32S tread;
	CkSum = ATTRead(SPI1, 0x3e, 3, temp, 0);
	CkSum = CkSum & 0xffffff;

	temper = ATTRead(SPI1, 0x2A, 3, temp, 0);

	for (i = 0; i < 0x1D; i++) {
		RtuDataAddr->REC[i] = ATTRead(SPI1, i, 3, temp, 0);
		CleardeadCount();
	}
	RtuDataAddr->REC[0x29] = ATTRead(SPI1, 0x29, 3, temp, 0);
	RtuDataAddr->REC[0x2c] = ATTRead(SPI1, 0x2c, 3, temp, 0);
	RtuDataAddr->REC[0x5c] = ATTRead(SPI1, 0x5c, 3, temp, 0);
	RtuDataAddr->REC[0x5d] = ATTRead(SPI1, 0x5d, 3, temp, 0);
	RtuDataAddr->REC[0x5e] = ATTRead(SPI1, 0x5e, 3, temp, 0);
//�ۼ��������Ĵ���
	RtuDataAddr->REC[0x43] = ATTRead(SPI1, 0x43, 3, temp, 0);
	RtuDataAddr->REC[0x47] = ATTRead(SPI1, 0x47, 3, temp, 0);
	RtuDataAddr->REC[0x4B] = ATTRead(SPI1, 0x4B, 3, temp, 0);
	RtuDataAddr->REC[0x4F] = ATTRead(SPI1, 0x4F, 3, temp, 0);
/*
//�����������Ĵ���
	RtuDataAddr->REC[0x63] = ATTRead(SPI1, 0x63, 3, temp, 0);
	RtuDataAddr->REC[0x67] = ATTRead(SPI1, 0x67, 3, temp, 0);
	RtuDataAddr->REC[0x6B] = ATTRead(SPI1, 0x6B, 3, temp, 0);
	RtuDataAddr->REC[0x6F] = ATTRead(SPI1, 0x6F, 3, temp, 0);
*/
	if (RtuDataAddr->REC[0x01] > 8388608)
		 tread= (RtuDataAddr->REC[0x01] - 16777216) * 10 / 256 / 2; //p
	else
		 tread = RtuDataAddr->REC[0x01] * 10 / 256 / 2;
///PA XIU ZHENG
	if( (temper<WDCANSHU)|| (temper >128))
	    RtuDataAddr->RES.RES_PA= tread * WDXISHU /1000;
	else
		RtuDataAddr->RES.RES_PA= tread;

	if (RtuDataAddr->REC[0x02] > 8388608)
		 tread = (RtuDataAddr->REC[0x02] - 16777216) * 10 / 256 / 2;
	else
		 tread = RtuDataAddr->REC[0x02] * 10 / 256 / 2;
///PB XIU ZHENG
	if( (temper<WDCANSHU)|| (temper >128))
		RtuDataAddr->RES.RES_PB= tread * WDXISHU /1000;
	else
		RtuDataAddr->RES.RES_PB= tread;

	if (RtuDataAddr->REC[0x03] > 8388608)
		 tread= (RtuDataAddr->REC[0x03] - 16777216) * 10 / 256 / 2;
	else
		 tread = RtuDataAddr->REC[0x03] * 10 / 256 / 2;

///PC XIU ZHENG
	if( (temper<WDCANSHU)|| (temper >128))
		RtuDataAddr->RES.RES_PC= tread * WDXISHU /1000;
	else
		RtuDataAddr->RES.RES_PC= tread;

	RtuDataAddr->RES.RES_PZ =RtuDataAddr->RES.RES_PA+RtuDataAddr->RES.RES_PB+RtuDataAddr->RES.RES_PC;
	if (RtuDataAddr->REC[0x05] > 8388608)
		tread = (RtuDataAddr->REC[0x05] - 16777216) * 10 / 256 / 2;
	else
		tread = RtuDataAddr->REC[0x05] * 10 / 256 / 2;

///QA XIU ZHENG
	if( (temper<WDCANSHU)|| (temper >128))
		RtuDataAddr->RES.RES_QA= tread * WDXISHU /1000;
	else
		RtuDataAddr->RES.RES_QA= tread;


	if (RtuDataAddr->REC[0x06] > 8388608)
		tread = (RtuDataAddr->REC[0x06] - 16777216) * 10 / 256 / 2;
	else
		tread = RtuDataAddr->REC[0x06] * 10 / 256 / 2;
///QB XIU ZHENG
	if( (temper<WDCANSHU)|| (temper >128))
		RtuDataAddr->RES.RES_QB= tread * WDXISHU /1000;
	else
		RtuDataAddr->RES.RES_QB= tread;


	if (RtuDataAddr->REC[0x07] > 8388608)
		tread = (RtuDataAddr->REC[0x07] - 16777216) * 10 / 256 / 2;
	else
		tread = RtuDataAddr->REC[0x07] * 10 / 256 / 2;
///QC XIU ZHENG
	if( (temper<WDCANSHU)|| (temper >128))
		RtuDataAddr->RES.RES_QC= tread * WDXISHU /1000;
	else
		RtuDataAddr->RES.RES_QC= tread;

	RtuDataAddr->RES.RES_QZ=RtuDataAddr->RES.RES_QA+RtuDataAddr->RES.RES_QB+RtuDataAddr->RES.RES_QC;
	if (RtuDataAddr->REC[0x09] > 8388608)
		RtuDataAddr->RES.RES_SA = ((RtuDataAddr->REC[0x09] - 16777216) * 10) / 256 / 2; //p
	else
		RtuDataAddr->RES.RES_SA = (RtuDataAddr->REC[0x09] * 10) / 256 / 2;
	if (RtuDataAddr->REC[0x0a] > 8388608)
		RtuDataAddr->RES.RES_SB = ((RtuDataAddr->REC[0x0a] - 16777216) * 10) / 256 / 2;
	else
		RtuDataAddr->RES.RES_SB = (RtuDataAddr->REC[0x0a] * 10) / 256 / 2;

	if (RtuDataAddr->REC[0x0b] > 8388608)
		RtuDataAddr->RES.RES_SC = ((RtuDataAddr->REC[0x0b] - 16777216) * 10) / 256;
	else
		RtuDataAddr->RES.RES_SC = (RtuDataAddr->REC[0x0b] * 10) / 256;

	if (RtuDataAddr->REC[0x0c] > 8388608)
		RtuDataAddr->RES.RES_SZ = ((RtuDataAddr->REC[0x0c] - 16777216) * 10) >> 6;
	else
		RtuDataAddr->RES.RES_SZ = (RtuDataAddr->REC[0x0c] * 10) >> 6;

	//RtuDataAddr->RES.RES_SA = sqrt(RtuDataAddr->RES.RES_PA*RtuDataAddr->RES.RES_PA + RtuDataAddr->RES.RES_QA*RtuDataAddr->RES.RES_QA);
	//RtuDataAddr->RES.RES_SB = sqrt(RtuDataAddr->RES.RES_PB*RtuDataAddr->RES.RES_PB + RtuDataAddr->RES.RES_QB*RtuDataAddr->RES.RES_QB);
	//RtuDataAddr->RES.RES_SC = sqrt(RtuDataAddr->RES.RES_PC*RtuDataAddr->RES.RES_PC + RtuDataAddr->RES.RES_QC*RtuDataAddr->RES.RES_QC);        ///S
	//RtuDataAddr->RES.RES_SZ = sqrt(RtuDataAddr->RES.RES_PZ*RtuDataAddr->RES.RES_PZ + RtuDataAddr->RES.RES_QZ*RtuDataAddr->RES.RES_QZ);
//�����й�����
	tread = RtuDataAddr->REC[0x43] * 100 / 6400;
	if( (temper<WDCANSHU)|| (temper >128)){
		RtuDataAddr->RES.RES_PALLZ= tread * WDXISHU /1000;
	}
	else{
		RtuDataAddr->RES.RES_PALLZ= tread;
	}
//�����й�����
	tread = RtuDataAddr->REC[0x47] * 100 / 6400;
	if( (temper<WDCANSHU)|| (temper >128))
		RtuDataAddr->RES.RES_PALLF= tread * WDXISHU /1000;
	else
		RtuDataAddr->RES.RES_PALLF= tread;

//�����޹�����
	tread = RtuDataAddr->REC[0x4B] * 100 / 6400;
	if( (temper<WDCANSHU)|| (temper >128))
		RtuDataAddr->RES.RES_QALLZ= tread * WDXISHU /1000;
	else
		RtuDataAddr->RES.RES_QALLZ= tread;
//�����޹�����
	tread = RtuDataAddr->REC[0x4F] * 100 / 6400;
	if( (temper<WDCANSHU)|| (temper >128))
		RtuDataAddr->RES.RES_QALLF= tread * WDXISHU /1000;
	else
		RtuDataAddr->RES.RES_QALLF= tread;
/*
	JIAOCAIDbg("\n\r\n\r\n\r");
	JIAOCAIDbg("\n\rtemper %d tread %d  WDXISHU %d  ",temper,tread,WDXISHU);
	JIAOCAIDbg("\n\r0x43 RtuDataAddr->RES.RES_PALLZ=%d",RtuDataAddr->RES.RES_PALLZ);
	JIAOCAIDbg("\n\r0x47 RtuDataAddr->RES.RES_PALLF=%d",RtuDataAddr->RES.RES_PALLF);
	JIAOCAIDbg("\n\r0x4B RtuDataAddr->RES.RES_QALLZ=%d",RtuDataAddr->RES.RES_QALLZ);
	JIAOCAIDbg("\n\r0x4F RtuDataAddr->RES.RES_QALLF=%d",RtuDataAddr->RES.RES_QALLF);
*/
//UA
	tread = RtuDataAddr->REC[0x0D] * 10 / 8192;
	if( (temper<WDCANSHU)|| (temper >128))
		RtuDataAddr->RES.RES_UA= tread * WDXISHU /1000;
	else
		RtuDataAddr->RES.RES_UA= tread;
//UB

	tread = RtuDataAddr->REC[0x0E] * 10 / 8192; ///U
	if( (temper<WDCANSHU)|| (temper >128))
		RtuDataAddr->RES.RES_UB= tread * WDXISHU /1000;
	else
		RtuDataAddr->RES.RES_UB= tread;
//UC
	tread = RtuDataAddr->REC[0x0F] * 10 / 8192;
	if( (temper<WDCANSHU)|| (temper >128))
		RtuDataAddr->RES.RES_UC= tread * WDXISHU /1000;
	else
		RtuDataAddr->RES.RES_UC= tread;
//IA
	tread = (RtuDataAddr->REC[0x10] * 1000) / 8192;
	if( (temper<WDCANSHU) || (temper >128))
		RtuDataAddr->RES.RES_IA= tread * WDXISHU /1000;
	else
		RtuDataAddr->RES.RES_IA= tread;
//IB
	tread = (RtuDataAddr->REC[0x11] * 1000) / 8192; ///I
	if( (temper<WDCANSHU) || (temper >128))
		RtuDataAddr->RES.RES_IB= tread * WDXISHU /1000;
	else
		RtuDataAddr->RES.RES_IB= tread;
//IC
	tread = (RtuDataAddr->REC[0x12] * 1000) / 8192;
	if( (temper<WDCANSHU) || (temper >128))
		RtuDataAddr->RES.RES_IC= tread * WDXISHU /1000;
	else
		RtuDataAddr->RES.RES_IC= tread;

	/////////////��λ////////////
	tempi = RtuDataAddr->RES.RES_IA % 10;
	if (tempi > 4)
		RtuDataAddr->RES.RES_IA = RtuDataAddr->RES.RES_IA + 10;

	tempi = RtuDataAddr->RES.RES_IB % 10;
	if (tempi > 4)
		RtuDataAddr->RES.RES_IB = RtuDataAddr->RES.RES_IB + 10;

	tempi = RtuDataAddr->RES.RES_IC % 10;
	if (tempi > 4)
		RtuDataAddr->RES.RES_IC = RtuDataAddr->RES.RES_IC + 10;
	//////////////////////////////

	RtuDataAddr->RES.RES_I0 = (RtuDataAddr->REC[0x29] * 1000) / 8192; //I0
	if(RtuDataAddr->RES.RES_JXFS == 04)
	{
  		if (RtuDataAddr->RES.RES_PA<0)
			RtuDataAddr->RES.RES_IA = - RtuDataAddr->RES.RES_IA;
  		if (RtuDataAddr->RES.RES_PB<0)
			RtuDataAddr->RES.RES_IB = - RtuDataAddr->RES.RES_IB;
  		if (RtuDataAddr->RES.RES_PC<0)
			RtuDataAddr->RES.RES_IC = - RtuDataAddr->RES.RES_IC;
	}
	if(RtuDataAddr->RES.RES_JXFS == 03) // ��������   ��ʵ�������Ҳ����
	{
		if (RtuDataAddr->RES.RES_PA<0)
			RtuDataAddr->RES.RES_IA =  RtuDataAddr->RES.RES_IA;
		if (RtuDataAddr->RES.RES_PB<0)
			RtuDataAddr->RES.RES_IB =  RtuDataAddr->RES.RES_IB;
		if (RtuDataAddr->RES.RES_PC<0)
			RtuDataAddr->RES.RES_IC =  RtuDataAddr->RES.RES_IC;
	}
	if (RtuDataAddr->REC[0x14] > 8388608)
		RtuDataAddr->RES.RES_PFA = (RtuDataAddr->REC[0x14] - 16777216) * 100 / 838861;
	else
		RtuDataAddr->RES.RES_PFA = RtuDataAddr->REC[0x14] * 100 / 838861;

	if (RtuDataAddr->REC[0x15] > 8388608)
		RtuDataAddr->RES.RES_PFB = (RtuDataAddr->REC[0x15] - 16777216) * 100 / 838861;
	else
		RtuDataAddr->RES.RES_PFB = RtuDataAddr->REC[0x15] * 100 / 838861;

	if (RtuDataAddr->REC[0x16] > 8388608)
		RtuDataAddr->RES.RES_PFC = (RtuDataAddr->REC[0x16] - 16777216) * 100 / 838861;
	else
		RtuDataAddr->RES.RES_PFC = RtuDataAddr->REC[0x16] * 100 / 838861;

	if (RtuDataAddr->REC[0x17] > 8388608)
		RtuDataAddr->RES.RES_PFZ = (RtuDataAddr->REC[0x17] - 16777216) * 100 / 838861;
	else
		RtuDataAddr->RES.RES_PFZ = RtuDataAddr->REC[0x17] * 100 / 838861;

	//////////////////////////////////////////////////////////////////////////////////////////////////

	RtuDataAddr->RES.RES_F = RtuDataAddr->REC[0x1C] * 100 / Kf;//Kf+RtuDataAddr->display_xiu[15]);      //hz
	RtuDataAddr->RES.RES_FLAG = RtuDataAddr->REC[0x2C];
	RtuDataAddr->REC[0x5C] = RtuDataAddr->REC[0x5C] * 10 / Kuab;
	RtuDataAddr->REC[0x5D] = RtuDataAddr->REC[0x5D] * 10 / Kuac; //YUaUbUc
	RtuDataAddr->REC[0x5E] = RtuDataAddr->REC[0x5E] * 10 / Kubc;
	j = RtuDataAddr->RES.RES_PFA / 1000.0;
	if (RtuDataAddr->RES.RES_QA >= 0)
		RtuDataAddr->REC[0x18] = 3600 - acos(j) * 1800 / 3.14;
	else
		RtuDataAddr->REC[0x18] = (acos(j) * 1800 / 3.14);
	j = RtuDataAddr->RES.RES_PFB / 1000.0;
	if (RtuDataAddr->RES.RES_QB >= 0)
		RtuDataAddr->REC[0x19] = 3600 - acos(j) * 1800 / 3.14;
	else
		RtuDataAddr->REC[0x19] = (acos(j) * 1800 / 3.14);
	j = RtuDataAddr->RES.RES_PFC / 1000.0;
	if (RtuDataAddr->RES.RES_QC >= 0)
		RtuDataAddr->REC[0x1A] = 3600 - acos(j) * 1800 / 3.14;
	else
		RtuDataAddr->REC[0x1A] = (acos(j) * 1800 / 3.14); ///jiao
	if (((0 <= RtuDataAddr->REC[0x5C]) && (RtuDataAddr->REC[0x5C] <= 3600)) && ((0 <= RtuDataAddr->REC[0x5D])
			&& (RtuDataAddr->REC[0x5D] <= 3600))) {
		RtuDataAddr->RES.RES_UAJ = 0;
		RtuDataAddr->RES.RES_UBJ = RtuDataAddr->REC[0x5C];
		RtuDataAddr->RES.RES_UCJ = RtuDataAddr->REC[0x5D];
		RtuDataAddr->RES.RES_IAJ = RtuDataAddr->RES.RES_UAJ - RtuDataAddr->REC[0x18];
		if (RtuDataAddr->RES.RES_UBJ < 0)
			RtuDataAddr->RES.RES_UBJ = RtuDataAddr->RES.RES_UBJ + 3600;
		if (RtuDataAddr->RES.RES_UCJ < 0)
			RtuDataAddr->RES.RES_UCJ = RtuDataAddr->RES.RES_UCJ + 3600;
		RtuDataAddr->RES.RES_IBJ = RtuDataAddr->RES.RES_UBJ - RtuDataAddr->REC[0x19];
		RtuDataAddr->RES.RES_ICJ = RtuDataAddr->RES.RES_UCJ - RtuDataAddr->REC[0x1A]; //��ѹ������ǳ���
		if (RtuDataAddr->RES.RES_IAJ < 0)
			RtuDataAddr->RES.RES_IAJ = RtuDataAddr->RES.RES_IAJ + 3600;
		if (RtuDataAddr->RES.RES_IBJ < 0)
			RtuDataAddr->RES.RES_IBJ = RtuDataAddr->RES.RES_IBJ + 3600;
		if (RtuDataAddr->RES.RES_ICJ < 0)
			RtuDataAddr->RES.RES_ICJ = RtuDataAddr->RES.RES_ICJ + 3600;

		if (RtuDataAddr->RES.RES_IA < 2)
			RtuDataAddr->RES.RES_IAJ = 0;

		if (RtuDataAddr->RES.RES_IB < 2)
			RtuDataAddr->RES.RES_IBJ = 0;

		if (RtuDataAddr->RES.RES_IC < 2)
			RtuDataAddr->RES.RES_ICJ = 0;

		if (RtuDataAddr->RES.RES_UB < 10)
			RtuDataAddr->RES.RES_UBJ = 0;

		if (RtuDataAddr->RES.RES_UC < 10)
			RtuDataAddr->RES.RES_UCJ = 0;
	}
}

/*************************************************************************************/
/*************  ��ѹ��������I0������ У������  ***************************************/
/*************************************************************************************/
//////////////////////2009.3.12/////////////////////

void modify_uipp(void) {

  	INT8U temp[3], i,j;
	INT32S ATT_PA, ATT_PB, ATT_PC;
	INT32S XISHU_UA, XISHU_UB, XISHU_UC, XISHU_IA, XISHU_IB, XISHU_IC;
	INT32S Temp_REC1[128];
	INT32S Temp_REC2[128];
	FP32 f_temp;
	memset(Temp_REC1,0,128);
	memset(Temp_REC2,0,128);
	for (j= 0; j < 2; j++)
	{
		for (i = 0; i < 0x1D; i++)
		{
			Temp_REC1[i] = Temp_REC1[i] + ATTRead(SPI1, i, 3, temp, 0);
			Temp_REC1[i] = Temp_REC1[i]/(j+1);
		}
		delay(500);
	}
	for (j= 0; j < 2; j++)
	{
		for (i = 0; i < 0x1D; i++)
		{
			Temp_REC2[i] = Temp_REC2[i] + ATTRead(SPI1, i, 3, temp, 0);
			Temp_REC2[i] = Temp_REC2[i]/(j+1);
		}
		delay(500);
	}
	for (i=0;i<0x1D;i++)
	{
		RtuDataAddr->REC[i] = (Temp_REC1[i] + Temp_REC2[i])/2;
	}

	/*for (i = 0; i < 0x1D; i++)
	{
		RtuDataAddr->REC[i] = Temp_REC[i]/3;
	}*/
	RtuDataAddr->REC[0x29] = ATTRead(SPI1, 0x29, 3, temp, 0);

	if (RtuDataAddr->REC[0x01] > 8388608)
		ATT_PA = (RtuDataAddr->REC[0x01] - 16777216) / 256; //pa
	else
		ATT_PA = RtuDataAddr->REC[0x01] / 256;

	if (RtuDataAddr->REC[0x02] > 8388608)
		ATT_PB = (RtuDataAddr->REC[0x02] - 16777216) / 256; //pb
	else
		ATT_PB = RtuDataAddr->REC[0x02] / 256;

	if (RtuDataAddr->REC[0x03] > 8388608)
		ATT_PC = (RtuDataAddr->REC[0x03] - 16777216) / 256; //pc
	else
		ATT_PC = RtuDataAddr->REC[0x03] / 256;

	//-------------------------------------------
//	printf("\n\r UA REC = % d",RtuDataAddr->REC[0x0D]);
//	printf("\n\r UB REC = % d",RtuDataAddr->REC[0x0E]);
//	printf("\n\r UC REC = % d",RtuDataAddr->REC[0x0F]);
//
//	printf("\n\r IA REC = % d",RtuDataAddr->REC[0x10]);
//	printf("\n\r IB REC = % d",RtuDataAddr->REC[0x11]);
//	printf("\n\r IC REC = % d",RtuDataAddr->REC[0x12]);
	//-------------------------------------------

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //����д����
	/*
	 temp[0] = 0;
	 temp[1] = 0;
	 temp[2] = 0;
	 ATTWrite(SPI1,0xc3,3,temp,0);     //��У���Ĵ���
	 */
	if(RtuDataAddr->RES.RES_JXFS == 04)
	{
	    if(RtuDataAddr->REC[0x0D]!=0)
	    {
		    f_temp =1.0*220*8192/RtuDataAddr->REC[0x0D];
		    printf("\n\r f_temp = %f",f_temp);

			if (f_temp >= 1)
				XISHU_UA   =  (INT32U )((f_temp-1)*8388608);
			else
				XISHU_UA   =  (INT32U )((f_temp+1)*8388608);

			printf("\n\r XISHU_UA = %x",XISHU_UA);

			temp[0] = (XISHU_UA & 0xff0000) >> 16;
			temp[1] = (XISHU_UA & 0xff00) >> 8;
			temp[2] = XISHU_UA & 0xff;
			RtuDataAddr->displayUA_xishu[0] = temp[0];
			RtuDataAddr->displayUA_xishu[1] = temp[1];
			RtuDataAddr->displayUA_xishu[2] = temp[2];
			printf("\n\r xishu_ua= %x",XISHU_UA);
			printf("\n\r ");
			ATTWrite(SPI1, 0x1B, 3, temp, 0);
		} else JIAOCAIDbg("UA%s\r\n", "���Ӹ�ɻ���");


		if (RtuDataAddr->REC[0x0E] != 0) {
			f_temp = 1.0*220*8192/RtuDataAddr->REC[0x0E];
		    printf("\n\r f_temp = %f",f_temp);
			if (f_temp >= 1)
				XISHU_UB   =  (INT32U )((f_temp-1)*8388608);
			else
				XISHU_UB   =  (INT32U )((f_temp+1)*8388608);
			printf("\n\r XISHU_UB %x",XISHU_UB);

			temp[0] = (XISHU_UB & 0xff0000) >> 16;
			temp[1] = (XISHU_UB & 0xff00) >> 8;
			temp[2] = XISHU_UB & 0xff;
			RtuDataAddr->displayUB_xishu[0] = temp[0];
			RtuDataAddr->displayUB_xishu[1] = temp[1];
			RtuDataAddr->displayUB_xishu[2] = temp[2];

			ATTWrite(SPI1, 0x1C, 3, temp, 0);
		} else JIAOCAIDbg("UB%s\r\n", "���Ӹ�ɻ���");


		if (RtuDataAddr->REC[0x0F] != 0) {
			f_temp = 1.0*220*8192/RtuDataAddr->REC[0x0F];
			if (f_temp >= 1)
				XISHU_UC   =  (INT32U )((f_temp-1)*8388608);
			else
				XISHU_UC   =  (INT32U )((f_temp+1)*8388608);
			temp[0] = (XISHU_UC & 0xff0000) >> 16;
			temp[1] = (XISHU_UC & 0xff00) >> 8;
			temp[2] = XISHU_UC & 0xff;
			RtuDataAddr->displayUC_xishu[0] = temp[0];
			RtuDataAddr->displayUC_xishu[1] = temp[1];
			RtuDataAddr->displayUC_xishu[2] = temp[2];

			ATTWrite(SPI1, 0x1D, 3, temp, 0);
		} else JIAOCAIDbg("UC%s\r\n", "���Ӹ�ɻ���");




		if (RtuDataAddr->REC[0x10] != 0) {        //IA
			f_temp =1.0* 5*8192/RtuDataAddr->REC[0x10];
			if (f_temp >= 1)
				XISHU_IA   =  (INT32U )((f_temp-1)*8388608);
			else
				XISHU_IA   =  (INT32U )((f_temp+1)*8388608);
			temp[0] = (XISHU_IA & 0xff0000) >> 16;
			temp[1] = (XISHU_IA & 0xff00) >> 8;
			temp[2] = XISHU_IA & 0xff;
			RtuDataAddr->displayIA_xishu[0] = temp[0];
			RtuDataAddr->displayIA_xishu[1] = temp[1];
			RtuDataAddr->displayIA_xishu[2] = temp[2];

			ATTWrite(SPI1, 0x26, 3, temp, 0);
		} else JIAOCAIDbg("IA%s\r\n", "���Ӹ�ɻ���");


		if (RtuDataAddr->REC[0x11] != 0) {        //IB
			f_temp = 1.0*5*8192/RtuDataAddr->REC[0x11];
			if (f_temp >= 1)
				XISHU_IB   =  (INT32U )((f_temp-1)*8388608);
			else
				XISHU_IB   =  (INT32U )((f_temp+1)*8388608);
			temp[0] = (XISHU_IB & 0xff0000) >> 16;
			temp[1] = (XISHU_IB & 0xff00) >> 8;
			temp[2] = XISHU_IB & 0xff;
			RtuDataAddr->displayIB_xishu[0] = temp[0];
			RtuDataAddr->displayIB_xishu[1] = temp[1];
			RtuDataAddr->displayIB_xishu[2] = temp[2];

			ATTWrite(SPI1, 0x27, 3, temp, 0);
		} else JIAOCAIDbg("IB%s\r\n", "���Ӹ�ɻ���");


		if (RtuDataAddr->REC[0x12] != 0) {        //IC
			f_temp = 1.0*5*8192/RtuDataAddr->REC[0x12];
			if (f_temp >= 1)
				XISHU_IC   =  (INT32U )((f_temp-1)*8388608);
			else
				XISHU_IC   =  (INT32U )((f_temp+1)*8388608);
			temp[0] = (XISHU_IC & 0xff0000) >> 16;
			temp[1] = (XISHU_IC & 0xff00) >> 8;
			temp[2] = XISHU_IC & 0xff;
			RtuDataAddr->displayIC_xishu[0] = temp[0];
			RtuDataAddr->displayIC_xishu[1] = temp[1];
			RtuDataAddr->displayIC_xishu[2] = temp[2];

			ATTWrite(SPI1, 0x28, 3, temp, 0);
		} else JIAOCAIDbg("IC%s\r\n", "���Ӹ�ɻ���");
	}
	if(RtuDataAddr->RES.RES_JXFS == 03) // ��������
	{
		if(RtuDataAddr->REC[0x0D]!=0)
		{
			f_temp =1.0*100*8192/RtuDataAddr->REC[0x0D];
			//printf("\n\r f_temp = %f",f_temp);

			if (f_temp >= 1)
				XISHU_UA   =  (INT32U )((f_temp-1)*8388608);
			else
				XISHU_UA   =  (INT32U )((f_temp+1)*8388608);

			//printf("\n\r XISHU_UA = %x",XISHU_UA);

			temp[0] = (XISHU_UA & 0xff0000) >> 16;
			temp[1] = (XISHU_UA & 0xff00) >> 8;
			temp[2] = XISHU_UA & 0xff;
			RtuDataAddr->displayUA_xishu[0] = temp[0];
			RtuDataAddr->displayUA_xishu[1] = temp[1];
			RtuDataAddr->displayUA_xishu[2] = temp[2];
			//printf("\n\r xishu_ua= %x",XISHU_UA);
			//printf("\n\r ");
			ATTWrite(SPI1, 0x1B, 3, temp, 0);
			delay(100);
			ATTWrite(SPI1, 0x1C, 3, temp, 0);
			delay(100);
		} else JIAOCAIDbg("UA%s\r\n", "���Ӹ�ɻ���");

		if (RtuDataAddr->REC[0x0F] != 0) {
			f_temp = 1.0*100*8192/RtuDataAddr->REC[0x0F];
			if (f_temp >= 1)
				XISHU_UC   =  (INT32U )((f_temp-1)*8388608);
			else
				XISHU_UC   =  (INT32U )((f_temp+1)*8388608);
			temp[0] = (XISHU_UC & 0xff0000) >> 16;
			temp[1] = (XISHU_UC & 0xff00) >> 8;
			temp[2] = XISHU_UC & 0xff;
			RtuDataAddr->displayUC_xishu[0] = temp[0];
			RtuDataAddr->displayUC_xishu[1] = temp[1];
			RtuDataAddr->displayUC_xishu[2] = temp[2];
			delay(100);
			ATTWrite(SPI1, 0x1D, 3, temp, 0);
			delay(100);
		} else JIAOCAIDbg("UC%s\r\n", "���Ӹ�ɻ���");


		if (RtuDataAddr->REC[0x10] != 0) {        //IA
			f_temp =1.0* 5*8192/RtuDataAddr->REC[0x10];
			if (f_temp >= 1)
				XISHU_IA   =  (INT32U )((f_temp-1)*8388608);
			else
				XISHU_IA   =  (INT32U )((f_temp+1)*8388608);
			temp[0] = (XISHU_IA & 0xff0000) >> 16;
			temp[1] = (XISHU_IA & 0xff00) >> 8;
			temp[2] = XISHU_IA & 0xff;
			RtuDataAddr->displayIA_xishu[0] = temp[0];
			RtuDataAddr->displayIA_xishu[1] = temp[1];
			RtuDataAddr->displayIA_xishu[2] = temp[2];

			ATTWrite(SPI1, 0x26, 3, temp, 0);
			delay(100);
			ATTWrite(SPI1, 0x27, 3, temp, 0);
			delay(100);
		} else JIAOCAIDbg("IA%s\r\n", "���Ӹ�ɻ���");


		if (RtuDataAddr->REC[0x12] != 0) {        //IC
			f_temp = 1.0*5*8192/RtuDataAddr->REC[0x12];
			if (f_temp >= 1)
				XISHU_IC   =  (INT32U )((f_temp-1)*8388608);
			else
				XISHU_IC   =  (INT32U )((f_temp+1)*8388608);
			temp[0] = (XISHU_IC & 0xff0000) >> 16;
			temp[1] = (XISHU_IC & 0xff00) >> 8;
			temp[2] = XISHU_IC & 0xff;
			RtuDataAddr->displayIC_xishu[0] = temp[0];
			RtuDataAddr->displayIC_xishu[1] = temp[1];
			RtuDataAddr->displayIC_xishu[2] = temp[2];
			delay(100);
			ATTWrite(SPI1, 0x28, 3, temp, 0);
			delay(100);
		} else JIAOCAIDbg("IC%s\r\n", "���Ӹ�ɻ���");

	}//end  ��������
	savefun();
	printf("\n\r mpp over!!!");
	printf("\n\r over!!!!!");
	printf("\n\r");
}

/*************************************************************************************/
/*************  �ǲ�У������  ********************************************************/
/*************************************************************************************/
//////////////////////2009.03.12//////////////////////

void jiaoxiu_pa(void) {
	INT8U temp[3];
	float err;
	INT32U tem, jiaoxiu;

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //����д����
	if (RtuDataAddr->RES.RES_JXFS == 04)
	{
		err = (RtuDataAddr->RES.RES_PA - 5500) / 5500.0;
		tem = 300* acos ((1 + err) / 2);

		if (tem >= 314)
			jiaoxiu = (tem - 314) * 8388608 / 300;
		else
			jiaoxiu = (286 + tem) * (8388608 / 300);
	}else
	{
  		err =  (RtuDataAddr->RES.RES_PA -4330)/4330.0;
  		tem =  600*acos((1+err)*0.866);
	 	if(tem>=314)
			jiaoxiu = (tem -314)*8388608/300;
		else
			jiaoxiu = (286+tem)*(8388608/300);
	}

	temp[0] = (jiaoxiu & 0xff0000) >> 16;
	temp[1] = (jiaoxiu & 0xff00) >> 8;
	temp[2] = jiaoxiu & 0xff;

	RtuDataAddr->displayA_jiaoxiu[0] = temp[0];
	RtuDataAddr->displayA_jiaoxiu[1] = temp[1];
	RtuDataAddr->displayA_jiaoxiu[2] = temp[2];

	ATTWrite(SPI1, 0xc, 3, temp, 0);
	ATTWrite(SPI1, 0xd, 3, temp, 0);
	ATTWrite(SPI1, 0xe, 3, temp, 0);
	ATTWrite(SPI1, 0xf, 3, temp, 0);
	ATTWrite(SPI1, 0x10, 3, temp, 0);

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 1;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //bu����д����
	delay(100);
	printf("\n\r mpa over!!!!!");
	printf("\n\r over!!!!!");
	printf("\n\r");
	savefun();
}
void mcjiaozheng() {
	INT8U temp[3];
	//INT32U HFConst;

	float Vu, Vi;
	//int EC = 6400;//3200
	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //����д����

	Vu = 0.1;//220*0.9/450;        //                      450/0.9  = 220/Vu
	//Vi=5*5*30/(1.5*1000);  //                      1.5/(5(mA)/1000)= 5(A)  /y     Vi=y*30(ŷ)
	Vi = 0.5;//((5*5*30)/1.5)/1000;
	//HFConst = (INT32U) (5760000000* 0.648 * 0.648 * Vu * Vi / (EC * 220* 1.5 ));

	//temp[0] = (HFConst & 0xff0000) >> 16;
	//temp[1] = (HFConst & 0xff00) >> 8;
	//temp[2] = HFConst & 0xff;

	//RtuDataAddr->displayMC_out_xishu[0] = temp[0];
	//RtuDataAddr->displayMC_out_xishu[1] = temp[1];
	//RtuDataAddr->displayMC_out_xishu[2] = temp[2];

	//printf("\n\r mcjiaozheng w HFConst=%d   temp0=%d   temp1=%d  temp2=%d ",HFConst,temp[0],temp[1],temp[2]);
	temp[0] = 0;
	temp[1] = 0;
	temp[2] =18; //RtuDataAddr->McAttr; //0xb;//0x39;
	ATTWrite(SPI1, 0x20, 3, temp, 0);

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 1;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //bu����д����

	savefun();
	//printf("tmp0=%d tmp1=%d tmp2=%d  ",temp[0],temp[1],temp[2]);
	//printf("\n\r m=%d",m);
	printf("\n\r mc over!!!!!");
	printf("\n\r over!!!!!");
	printf("\n\r ");
}
void jiaoxiu_pb(void) {
	INT8U temp[3];
	float err;
	INT32U tem, jiaoxiu;

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //����д����


	if (MODE == 04)
		err = (RtuDataAddr->RES.RES_PB - 5500) / 5500.0;
	else
		err = 0;

	tem = 300* acos ((1 + err) / 2);

	if (tem >= 314)
		jiaoxiu = (tem - 314) * 8388608 / 300;
	else
		jiaoxiu = (286 + tem) * (8388608 / 300);

	temp[0] = (jiaoxiu & 0xff0000) >> 16;
	temp[1] = (jiaoxiu & 0xff00) >> 8;
	temp[2] = jiaoxiu & 0xff;

	RtuDataAddr->displayB_jiaoxiu[0] = temp[0];
	RtuDataAddr->displayB_jiaoxiu[1] = temp[1];
	RtuDataAddr->displayB_jiaoxiu[2] = temp[2];

	ATTWrite(SPI1, 0x11, 3, temp, 0);
	ATTWrite(SPI1, 0x12, 3, temp, 0);
	ATTWrite(SPI1, 0x13, 3, temp, 0);
	ATTWrite(SPI1, 0x14, 3, temp, 0);
	ATTWrite(SPI1, 0x15, 3, temp, 0);

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 1;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //bu����д����
	delay(100);
	printf("\n\rmpb over!!!!!");
	printf("\n\r over!!!!!");
	printf("\n\r");
	savefun();
}

void jiaoxiu_pc(void) {
	INT8U temp[3];
	float err;
	INT32U tem, jiaoxiu;

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //����д����

	if (RtuDataAddr->RES.RES_JXFS == 04) //
	{
		err = (RtuDataAddr->RES.RES_PC - 5500) / 5500.0;
		tem = 300* acos ((1 + err) / 2);
		if (tem >= 314)
			jiaoxiu = (tem - 314) * 8388608 / 300;
		else
			jiaoxiu = (286 + tem) * (8388608 / 300);
	}
	else// jiaocai  RtuDataAddr->RES.RES_JXFS == 03  ��������
	{
  		err =  (RtuDataAddr->RES.RES_PC -4330)/4330.0;
  		tem =  600*acos((1+err)*0.866);
		if(tem>=314)
			jiaoxiu = (tem -314)*8388608/600;
		else
			jiaoxiu = (286+tem)*(8388608/600);
	}

	temp[0] = (jiaoxiu & 0xff0000) >> 16;
	temp[1] = (jiaoxiu & 0xff00) >> 8;
	temp[2] = jiaoxiu & 0xff;

	RtuDataAddr->displayC_jiaoxiu[0] = temp[0];
	RtuDataAddr->displayC_jiaoxiu[1] = temp[1];
	RtuDataAddr->displayC_jiaoxiu[2] = temp[2];

	ATTWrite(SPI1, 0x16, 3, temp, 0);
	ATTWrite(SPI1, 0x17, 3, temp, 0);
	ATTWrite(SPI1, 0x18, 3, temp, 0);
	ATTWrite(SPI1, 0x19, 3, temp, 0);
	ATTWrite(SPI1, 0x1A, 3, temp, 0);

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 1;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //bu����д����
	delay(100);
	printf("\n\r mpc over!!!!!");
	printf("\n\r over!!!!!");
	printf("\n\r");
	savefun();
}

void qingabc(void) {
	INT8U temp[3];
	INT32U m;
	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //����д����

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0;
	ATTWrite(SPI1, 0xc3, 3, temp, 0); //��У���Ĵ���


	temp[0] = 0x46;
    temp[1] = 0x55;
	temp[2] = 0x01;

	ATTWrite(SPI1, 0x3f, 3, temp, 0); //��ѹͨ��AD����

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 1;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //bu����д����

	m = ATTRead(SPI1, 0x20, 3, temp, 0);
	printf("\n\rQing chu jiaocai can shu! qing over");
	printf("\n\r");
}

/************************************************************************************
 *         ��λУ�������ȼ����Գ���
 *************************************************************************************/

void YCP_Jingdu(void) {

	JIAOCAIDbg("\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r");

	JIAOCAIDbg("\n\r                            ��GPRS�װ���λ���Ȳ�����\n\r");
	JIAOCAIDbg("\n\r�밴������Ҫ����в�����\n\r");
	JIAOCAIDbg("\n\r1�����µ�ѹ�����������ֵʱ����(�������߼�220v��5A��60�ȣ�������Ч��) \r");
	JIAOCAIDbg("\n\r2���й����ʺ��޹����ʵ����ȼ�����ֵ������0.5���ȼ����ڣ�\r");

	JIAOCAIDbg("\n\r*************************************************************************");
	JIAOCAIDbg("\n\r                           ����������ʾ���£�");
	JIAOCAIDbg("\n\r*************************************************************************\n\r");

	if (MODE == 4) {
		INT16U k;

		if (RtuDataAddr->RES.RES_PZ != 0) {
			k = abs(RtuDataAddr->RES.RES_PZ - 16500);
			if (k <= 165) {
				JIAOCAIDbg("\n\rPz�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�0.%d��\n\r", k * 1000 / 16500);
			} else {
				JIAOCAIDbg("\n\r�����������������ˣ���������Pz�������ϸ�NONONO!!!!     �����ȼ�����%d.%d��\n\r", k * 1000 / 16500 / 10, k * 1000 / 16500
							% 10);
			}
		}

		if (RtuDataAddr->RES.RES_QZ != 0) {
			k = abs(RtuDataAddr->RES.RES_QZ - 28578);
			if (k <= 285) {
				JIAOCAIDbg("\n\rQz�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�0.%d��\n\r", k * 1000 / 28578);
			} else {
				JIAOCAIDbg("\n\r�����������������ˣ���������Pz�������ϸ�NONONO!!!!     �����ȼ�����%d.%d��\n\r", k * 1000 / 28578 / 10, k * 1000 / 28578
							% 10);
			}
		}

		JIAOCAIDbg("\n\r*************************************************************************");
		JIAOCAIDbg("\n\r          �ǲ�У�����ȼ���ʾ���,�޴�ͨ�����д�����������");
		JIAOCAIDbg("\n\r*************************************************************************\n\r");
	}

	else JIAOCAIDbg("\n\r�������ն˽��߷�ʽ��������������������������n\r");

}
////////////////////////////////////////////////////////////////////////////////////////////////////////


void initdl() {
	INT8U i;
	Z_P_ALL_Temp = 0;
	F_P_ALL_Temp = 0;
	Q_1_ALL_Temp = 0;
	Q_2_ALL_Temp = 0;
	Q_3_ALL_Temp = 0;
	Q_4_ALL_Temp = 0;
	RtuDataAddr->FkOldXuLiang.Z_P_Value = RtuDataAddr->FkMaxXuliang.Z_P_X_All;
	RtuDataAddr->FkOldXuLiang.Z_Q_Value = RtuDataAddr->FkMaxXuliang.Z_Q_X_All;
	RtuDataAddr->FkOldXuLiang.F_P_Value = RtuDataAddr->FkMaxXuliang.F_P_X_All;
	RtuDataAddr->FkOldXuLiang.F_Q_Value = RtuDataAddr->FkMaxXuliang.F_Q_X_All;
	for (i = 0; i < FeiLvNum; i++) {
		RtuDataAddr->FkOldXuLiang.Z_P_FL_Value[i] = RtuDataAddr->FkMaxXuliang.Z_P_X_F[i];
		RtuDataAddr->FkOldXuLiang.F_P_FL_Value[i] = RtuDataAddr->FkMaxXuliang.F_P_X_F[i];
		RtuDataAddr->FkOldXuLiang.Z_Q_FL_Value[i] = RtuDataAddr->FkMaxXuliang.Z_Q_X_F[i];
		RtuDataAddr->FkOldXuLiang.F_Q_FL_Value[i] = RtuDataAddr->FkMaxXuliang.F_Q_X_F[i];
		RtuDataAddr->FkOldXuLiang.X1_Q_FL_Value[i] = RtuDataAddr->FkMaxXXXuliang.X1_Q_F[i];
		RtuDataAddr->FkOldXuLiang.X2_Q_FL_Value[i] = RtuDataAddr->FkMaxXXXuliang.X2_Q_F[i];
		RtuDataAddr->FkOldXuLiang.X3_Q_FL_Value[i] = RtuDataAddr->FkMaxXXXuliang.X3_Q_F[i];
		RtuDataAddr->FkOldXuLiang.X4_Q_FL_Value[i] = RtuDataAddr->FkMaxXXXuliang.X4_Q_F[i];
	}
}
unsigned int Z_P_All;//�����й��ܵ���(+A)6 7 8 9
unsigned int Z_P_F[FeiLvNum];//����1<-->4�����й����� 9 10 11

unsigned int F_P_All;//�����й��ܵ���(-A)
unsigned int F_P_F[FeiLvNum];//����1�����й�����

unsigned int Z_Q_All;//�����޹��ܵ���(+RL,+RC)
unsigned int Z_Q_F[FeiLvNum];//����1�����޹�����

unsigned int F_Q_All;//�����޹��ܵ���(-RL,-RC)
unsigned int F_Q_F[FeiLvNum];//����1�����޹�����

unsigned int X1_Q_All;//һ�����޹��ܵ���(+RL)
unsigned int X1_F_Q[FeiLvNum];//����1һ�����޹�����

unsigned int X4_Q_All;//�������޹��ܵ���(-Rc)
unsigned int X4_F_Q[FeiLvNum];//����1�������޹�����

unsigned int X2_Q_All;//�������޹��ܵ���(+RC)
unsigned int X2_F_Q[FeiLvNum];//����1�������޹�����

unsigned int X3_Q_All;//�������޹��ܵ���(�DRL)
unsigned int X3_F_Q[FeiLvNum];//����1�������޹�����
void dddealpro(void) {
	INT8U tmp;
	tmp = RtuDataAddr->NowFeiLvNo;

	if (RtuDataAddr->RES.RES_PZ >= 0) //�����������
	{
		Z_P_ALL_Temp = Z_P_ALL_Temp + abs(RtuDataAddr->RES.RES_PZ);
		Z_P_All = Z_P_All + Z_P_ALL_Temp / 360000;
		Z_P_F[tmp] += Z_P_ALL_Temp / 360000;
		Z_P_ALL_Temp = Z_P_ALL_Temp % 360000;
	}

	if (RtuDataAddr->RES.RES_PZ < 0) //�����������
	{
		F_P_ALL_Temp = F_P_ALL_Temp + abs(RtuDataAddr->RES.RES_PZ);
		F_P_All = F_P_All + F_P_ALL_Temp / 360000;
		F_P_F[tmp] += F_P_ALL_Temp / 360000;
		F_P_ALL_Temp = F_P_ALL_Temp % 360000;
	}

	RtuDataAddr->FkMaxXXXuliang.Q_X_1 = 0;
	RtuDataAddr->FkMaxXXXuliang.Q_X_2 = 0;
	RtuDataAddr->FkMaxXXXuliang.Q_X_3 = 0;
	RtuDataAddr->FkMaxXXXuliang.Q_X_4 = 0;

	if (RtuDataAddr->RES.RES_PZ >= 0) {
		if (RtuDataAddr->RES.RES_QZ >= 0) {
			Q_1_ALL_Temp = Q_1_ALL_Temp + RtuDataAddr->RES.RES_QZ;
			X1_Q_All = X1_Q_All + Q_1_ALL_Temp / 360000;
			X1_F_Q[tmp] += Q_1_ALL_Temp / 360000;
			Q_1_ALL_Temp = Q_1_ALL_Temp % 360000;
			RtuDataAddr->FkMaxXXXuliang.Q_X_1 = RtuDataAddr->RES.RES_QZ;
		}

		else {
			Q_4_ALL_Temp = Q_4_ALL_Temp + abs(RtuDataAddr->RES.RES_QZ);
			X4_Q_All = X4_Q_All + Q_4_ALL_Temp / 360000;
			X4_F_Q[tmp] += Q_4_ALL_Temp / 360000;
			Q_4_ALL_Temp = Q_4_ALL_Temp % 360000;
			RtuDataAddr->FkMaxXXXuliang.Q_X_4 = RtuDataAddr->RES.RES_QZ;
		}

	} else {
		if (RtuDataAddr->RES.RES_QZ < 0) {
			Q_3_ALL_Temp = Q_3_ALL_Temp + abs(RtuDataAddr->RES.RES_QZ);
			X3_Q_All =X3_Q_All + Q_3_ALL_Temp / 360000;
			X3_F_Q[tmp] += Q_3_ALL_Temp / 360000;
			Q_3_ALL_Temp = Q_3_ALL_Temp % 360000;
			RtuDataAddr->FkMaxXXXuliang.Q_X_3 = RtuDataAddr->RES.RES_QZ;
		} else {
			Q_2_ALL_Temp = Q_2_ALL_Temp + RtuDataAddr->RES.RES_QZ;
			X2_Q_All = X2_Q_All + Q_2_ALL_Temp / 360000;
			X2_F_Q[tmp] += Q_2_ALL_Temp / 360000;
			Q_2_ALL_Temp = Q_2_ALL_Temp % 360000;
			RtuDataAddr->FkMaxXXXuliang.Q_X_2 = RtuDataAddr->RES.RES_QZ;
		}
	}
	Z_Q_All = X1_Q_All + X2_Q_All;
	Z_Q_F[tmp] = X1_F_Q[tmp] + X2_F_Q[tmp];
	F_Q_All = X4_Q_All + X3_Q_All;
	F_Q_F[tmp] = X4_F_Q[tmp] + X3_F_Q[tmp];

	JIAOCAIDbg("\n\r-----------calc start");
	JIAOCAIDbg("\n\rZ_P_All=%d",Z_P_All);
	JIAOCAIDbg("\n\rF_P_All=%d",F_P_All);
	JIAOCAIDbg("\n\rZ_Q_All=%d",Z_Q_All);
	JIAOCAIDbg("\n\rF_Q_All=%d",F_Q_All);
	JIAOCAIDbg("\n\rRtuDataAddr->FkMaxXXXuliang.Q_X_1=%d",RtuDataAddr->FkMaxXXXuliang.Q_X_1);
	JIAOCAIDbg("\n\rRtuDataAddr->FkMaxXXXuliang.Q_X_2=%d",RtuDataAddr->FkMaxXXXuliang.Q_X_2);
	JIAOCAIDbg("\n\rRtuDataAddr->FkMaxXXXuliang.Q_X_3=%d",RtuDataAddr->FkMaxXXXuliang.Q_X_3);
	JIAOCAIDbg("\n\rRtuDataAddr->FkMaxXXXuliang.Q_X_3=%d",RtuDataAddr->FkMaxXXXuliang.Q_X_4);
	JIAOCAIDbg("\n\r-------------calc end");

}
void calcdianliang() {

	INT8U tmp;
	tmp = RtuDataAddr->NowFeiLvNo;
	CleardeadCount();
	RtuDataAddr->FkDdRealData.Z_P_All=RtuDataAddr->OldFkDdRealData.Z_P_All + RtuDataAddr->RES.RES_PALLZ;
	RtuDataAddr->FkDdRealData.Z_P_F[tmp]=RtuDataAddr->OldFkDdRealData.Z_P_F[tmp]+RtuDataAddr->RES.RES_PALLZ;

	RtuDataAddr->FkDdRealData.F_P_All= RtuDataAddr->OldFkDdRealData.F_P_All+RtuDataAddr->RES.RES_PALLF;
	RtuDataAddr->FkDdRealData.F_P_F[tmp]=RtuDataAddr->OldFkDdRealData.F_P_F[tmp]+RtuDataAddr->RES.RES_PALLF;

	RtuDataAddr->FkMaxXXXuliang.Q_X_1 = 0;
	RtuDataAddr->FkMaxXXXuliang.Q_X_2 = 0;
	RtuDataAddr->FkMaxXXXuliang.Q_X_3 = 0;
	RtuDataAddr->FkMaxXXXuliang.Q_X_4 = 0;

	if (RtuDataAddr->RES.RES_PZ >= 0) {
		if (RtuDataAddr->RES.RES_QZ >= 0) {
			RtuDataAddr->FkDdRealData.X1_Q_All=  RtuDataAddr->OldFkDdRealData.X1_Q_All+RtuDataAddr->RES.RES_QALLZ;
			RtuDataAddr->FkDdRealData.X1_F_Q[tmp]= RtuDataAddr->OldFkDdRealData.X1_F_Q[tmp]+RtuDataAddr->RES.RES_QALLZ;
			RtuDataAddr->FkMaxXXXuliang.Q_X_1 = RtuDataAddr->RES.RES_QZ;
		}

		else {
			RtuDataAddr->FkDdRealData.X4_Q_All= RtuDataAddr->OldFkDdRealData.X4_Q_All+RtuDataAddr->RES.RES_QALLZ;
			RtuDataAddr->FkDdRealData.X4_F_Q[tmp]= RtuDataAddr->OldFkDdRealData.X4_F_Q[tmp]+RtuDataAddr->RES.RES_QALLZ;
			RtuDataAddr->FkMaxXXXuliang.Q_X_4 = RtuDataAddr->RES.RES_QZ;
		}

	} else {
		if (RtuDataAddr->RES.RES_QZ < 0) {
			RtuDataAddr->FkDdRealData.X3_Q_All= RtuDataAddr->OldFkDdRealData.X3_Q_All+RtuDataAddr->RES.RES_QALLF;
			RtuDataAddr->FkDdRealData.X3_F_Q[tmp]= RtuDataAddr->OldFkDdRealData.X3_F_Q[tmp]+RtuDataAddr->RES.RES_QALLF;
			RtuDataAddr->FkMaxXXXuliang.Q_X_3 = RtuDataAddr->RES.RES_QZ;
		} else {
			RtuDataAddr->FkDdRealData.X2_Q_All= RtuDataAddr->OldFkDdRealData.X2_Q_All+RtuDataAddr->RES.RES_QALLF;
			RtuDataAddr->FkDdRealData.X2_F_Q[tmp]= RtuDataAddr->OldFkDdRealData.X2_F_Q[tmp]+RtuDataAddr->RES.RES_QALLF;
			RtuDataAddr->FkMaxXXXuliang.Q_X_2 = RtuDataAddr->RES.RES_QZ;
		}

	}
	RtuDataAddr->FkDdRealData.Z_Q_All= RtuDataAddr->OldFkDdRealData.Z_Q_All+RtuDataAddr->FkDdRealData.X1_Q_All + RtuDataAddr->FkDdRealData.X2_Q_All;
	RtuDataAddr->FkDdRealData.Z_Q_F[tmp]= RtuDataAddr->OldFkDdRealData.Z_Q_F[tmp]+RtuDataAddr->FkDdRealData.X1_F_Q[tmp] + RtuDataAddr->FkDdRealData.X2_F_Q[tmp];
	RtuDataAddr->FkDdRealData.F_Q_All= RtuDataAddr->OldFkDdRealData.F_Q_All+RtuDataAddr->FkDdRealData.X4_Q_All + RtuDataAddr->FkDdRealData.X3_Q_All;
	RtuDataAddr->FkDdRealData.F_Q_F[tmp]= RtuDataAddr->OldFkDdRealData.F_Q_F[tmp]+RtuDataAddr->FkDdRealData.X4_F_Q[tmp] + RtuDataAddr->FkDdRealData.X3_F_Q[tmp];

	JIAOCAIDbg("\n\r*************************7022b start");
	JIAOCAIDbg("\n\rRtuDataAddr->FkDdRealData.Z_P_All=%d",RtuDataAddr->FkDdRealData.Z_P_All);
	JIAOCAIDbg("\n\rRtuDataAddr->FkDdRealData.F_P_All=%d",RtuDataAddr->FkDdRealData.F_P_All);
	JIAOCAIDbg("\n\rRtuDataAddr->FkDdRealData.Z_Q_All=%d",RtuDataAddr->FkDdRealData.Z_Q_All);
	JIAOCAIDbg("\n\rRtuDataAddr->FkDdRealData.F_Q_All=%d",RtuDataAddr->FkDdRealData.F_Q_All);
	JIAOCAIDbg("\n\rRtuDataAddr->FkMaxXXXuliang.Q_X_1=%d",RtuDataAddr->FkMaxXXXuliang.Q_X_1);
	JIAOCAIDbg("\n\rRtuDataAddr->FkMaxXXXuliang.Q_X_2=%d",RtuDataAddr->FkMaxXXXuliang.Q_X_2);
	JIAOCAIDbg("\n\rRtuDataAddr->FkMaxXXXuliang.Q_X_3=%d",RtuDataAddr->FkMaxXXXuliang.Q_X_3);
	JIAOCAIDbg("\n\rRtuDataAddr->FkMaxXXXuliang.Q_X_3=%d",RtuDataAddr->FkMaxXXXuliang.Q_X_4);
	JIAOCAIDbg("\n\r*************************7022b end");
}
void XuLiangCalc(INT32S *Dest, INT32S *S, INT8U *DestTime, INT32S *CMP, TS ts) {
	INT8U i;
	INT32S Temp;
	Temp = 0;
	for (i = 0; i < 15; i++) {
		Temp = Temp + S[i];
	}
	Temp = Temp / 15;
	if (Temp > *CMP) {//�洢�й��������
		*Dest = Temp;
		*CMP = Temp;
		DestTime[3] = ((ts.Month / 10) << 4) + (ts.Month % 10);
		DestTime[2] = ((ts.Day / 10) << 4) + (ts.Day % 10);
		DestTime[1] = ((ts.Hour / 10) << 4) + (ts.Hour % 10);
		DestTime[0] = ((ts.Minute / 10) << 4) + (ts.Minute % 10);
	}
}

void XuLiangRst() {
	INT8U i, j;
	/////
	RtuDataAddr->FkMaxXuliang.F_P_X_All = 0;
	RtuDataAddr->FkMaxXuliang.F_Q_X_All = 0;
	RtuDataAddr->FkMaxXuliang.Z_P_X_All = 0;
	RtuDataAddr->FkMaxXuliang.Z_Q_X_All = 0;
	for (i = 0; i < 15; i++) {
		RtuDataAddr->FkMaxXuliang.F_P_X_F[i] = 0;
		RtuDataAddr->FkMaxXuliang.F_Q_X_F[i] = 0;
		RtuDataAddr->FkMaxXuliang.Z_P_X_F[i] = 0;
		RtuDataAddr->FkMaxXuliang.Z_Q_X_F[i] = 0;
	}
	/////
	for (i = 0; i < 15; i++) {
		RtuDataAddr->FkXuLiangCalc.F_P_Value[i] = 0;
		RtuDataAddr->FkXuLiangCalc.F_Q_Value[i] = 0;
		RtuDataAddr->FkXuLiangCalc.Z_P_Value[i] = 0;
		RtuDataAddr->FkXuLiangCalc.Z_Q_Value[i] = 0;
		for (j = 0; j < FeiLvNum; j++) {
			RtuDataAddr->FkXuLiangCalc.F_P_FL_Value[j][i] = 0;
			RtuDataAddr->FkXuLiangCalc.F_Q_FL_Value[j][i] = 0;
			RtuDataAddr->FkXuLiangCalc.Z_P_FL_Value[j][i] = 0;
			RtuDataAddr->FkXuLiangCalc.Z_Q_FL_Value[j][i] = 0;
		}
	}
	RtuDataAddr->FkXuLiangCalc.Offset = 0;
}

void FeiLvCalc() {
	TS ts;
	double m,n;
	TSGet(&ts);
	RtuDataAddr->FkDdRealData.Valid = 1;
	//RtuDataAddr->FkDdRealData.Cos = RtuDataAddr->RES.RES_PFZ;
	RtuDataAddr->FkDdRealData.CosA = RtuDataAddr->RES.RES_PFA;
	RtuDataAddr->FkDdRealData.CosB = RtuDataAddr->RES.RES_PFB;
	RtuDataAddr->FkDdRealData.CosC = RtuDataAddr->RES.RES_PFC;

	RtuDataAddr->FkDdRealData.IA = RtuDataAddr->RES.RES_IA / 10;
	RtuDataAddr->FkDdRealData.IB = RtuDataAddr->RES.RES_IB / 10;
	RtuDataAddr->FkDdRealData.IC = RtuDataAddr->RES.RES_IC / 10;
	RtuDataAddr->FkDdRealData.IL = RtuDataAddr->RES.RES_I0 / 10;

	RtuDataAddr->FkDdRealData.VA = RtuDataAddr->RES.RES_UA;
	RtuDataAddr->FkDdRealData.VB = RtuDataAddr->RES.RES_UB;
	RtuDataAddr->FkDdRealData.VC = RtuDataAddr->RES.RES_UC;
	//RtuDataAddr->FkDdRealData.P = RtuDataAddr->RES.RES_PZ;
	RtuDataAddr->FkDdRealData.PA = RtuDataAddr->RES.RES_PA;
	RtuDataAddr->FkDdRealData.PB = RtuDataAddr->RES.RES_PB;
	RtuDataAddr->FkDdRealData.PC = RtuDataAddr->RES.RES_PC;
	RtuDataAddr->FkDdRealData.P=RtuDataAddr->FkDdRealData.PA+RtuDataAddr->FkDdRealData.PB+RtuDataAddr->FkDdRealData.PC;
	//RtuDataAddr->FkDdRealData.Q = RtuDataAddr->RES.RES_QZ;
	RtuDataAddr->FkDdRealData.QA = RtuDataAddr->RES.RES_QA;
	RtuDataAddr->FkDdRealData.QB = RtuDataAddr->RES.RES_QB;
	RtuDataAddr->FkDdRealData.QC = RtuDataAddr->RES.RES_QC;
	RtuDataAddr->FkDdRealData.Q=RtuDataAddr->FkDdRealData.QA+RtuDataAddr->FkDdRealData.QB+RtuDataAddr->FkDdRealData.QC;
	//RtuDataAddr->FkDdRealData.S = RtuDataAddr->RES.RES_SZ;
	RtuDataAddr->FkMaxXuliang.UAJ = RtuDataAddr->RES.RES_UAJ;
	RtuDataAddr->FkMaxXuliang.UBJ = RtuDataAddr->RES.RES_UBJ;
	RtuDataAddr->FkMaxXuliang.UCJ = RtuDataAddr->RES.RES_UCJ;
	RtuDataAddr->FkMaxXuliang.IAJ = RtuDataAddr->RES.RES_IAJ;
	RtuDataAddr->FkMaxXuliang.IBJ = RtuDataAddr->RES.RES_IBJ;
	RtuDataAddr->FkMaxXuliang.ICJ = RtuDataAddr->RES.RES_ICJ;
	RtuDataAddr->FkMaxXuliang.FKStat = RtuDataAddr->RES.RES_FLAG;
	m=(double)RtuDataAddr->FkDdRealData.P;
	n=(double)((RtuDataAddr->FkDdRealData.P)*(RtuDataAddr->FkDdRealData.P)+(RtuDataAddr->FkDdRealData.Q)*(RtuDataAddr->FkDdRealData.Q));
	if(n!=0)
		 RtuDataAddr->FkDdRealData.Cos=1000*m/sqrt(n);
	else
		 RtuDataAddr->FkDdRealData.Cos=0;

	//	ts.Hour;ts.Day;ts.Month;ts.Year;
	RtuDataAddr->FkDdRealData.Chao_Time.BCD01 = ((ts.Minute / 10) << 4) + (ts.Minute % 10);
	RtuDataAddr->FkDdRealData.Chao_Time.BCD02 = ((ts.Hour / 10) << 4) + (ts.Hour % 10);
	RtuDataAddr->FkDdRealData.Chao_Time.BCD03 = ((ts.Day / 10) << 4) + (ts.Day % 10);
	RtuDataAddr->FkDdRealData.Chao_Time.BCD04 = ((ts.Month / 10) << 4) + (ts.Month % 10);
	RtuDataAddr->FkDdRealData.Chao_Time.BCD05 = (((ts.Year % 100) / 10) << 4) + (ts.Year % 10);
	//	RtuDataAddr->FkDdRealData.ProtocolType=2;
	if (FeiLvMin != ts.Minute) {
		RtuDataAddr->NowFeiLvNo = FeiLvNo(ts); //by liuxw
		//printf("\n\r\n\r\n\r now feilvNo is %d\n\r\n\r",RtuDataAddr->NowFeiLvNo);
		if (RtuDataAddr->FkDdRealData.P > 0) {
			RtuDataAddr->FkXuLiangCalc.Z_P_Value[RtuDataAddr->FkXuLiangCalc.Offset] = RtuDataAddr->FkDdRealData.P;
			RtuDataAddr->FkXuLiangCalc.F_P_Value[RtuDataAddr->FkXuLiangCalc.Offset] = 0;

			RtuDataAddr->FkXuLiangCalc.Z_P_FL_Value[RtuDataAddr->NowFeiLvNo][RtuDataAddr->FkXuLiangCalc.Offset]
					= RtuDataAddr->FkDdRealData.P;
			RtuDataAddr->FkXuLiangCalc.F_P_FL_Value[RtuDataAddr->NowFeiLvNo][RtuDataAddr->FkXuLiangCalc.Offset] = 0;
		} else {
			RtuDataAddr->FkXuLiangCalc.F_P_Value[RtuDataAddr->FkXuLiangCalc.Offset] = 0 - RtuDataAddr->FkDdRealData.P;
			RtuDataAddr->FkXuLiangCalc.Z_P_Value[RtuDataAddr->FkXuLiangCalc.Offset] = 0;

			RtuDataAddr->FkXuLiangCalc.F_P_FL_Value[RtuDataAddr->NowFeiLvNo][RtuDataAddr->FkXuLiangCalc.Offset] = 0
					- RtuDataAddr->FkDdRealData.P;
			RtuDataAddr->FkXuLiangCalc.Z_P_FL_Value[RtuDataAddr->NowFeiLvNo][RtuDataAddr->FkXuLiangCalc.Offset] = 0;
		}
		if (RtuDataAddr->FkDdRealData.Q > 0) {
			RtuDataAddr->FkXuLiangCalc.Z_Q_Value[RtuDataAddr->FkXuLiangCalc.Offset] = abs(RtuDataAddr->FkDdRealData.Q);
			RtuDataAddr->FkXuLiangCalc.F_Q_Value[RtuDataAddr->FkXuLiangCalc.Offset] = 0;

			RtuDataAddr->FkXuLiangCalc.Z_Q_FL_Value[RtuDataAddr->NowFeiLvNo][RtuDataAddr->FkXuLiangCalc.Offset]
					= RtuDataAddr->FkDdRealData.Q;
			RtuDataAddr->FkXuLiangCalc.F_Q_FL_Value[RtuDataAddr->NowFeiLvNo][RtuDataAddr->FkXuLiangCalc.Offset] = 0;
		} else {
			RtuDataAddr->FkXuLiangCalc.F_Q_Value[RtuDataAddr->FkXuLiangCalc.Offset] = 0 - RtuDataAddr->FkDdRealData.Q;
			RtuDataAddr->FkXuLiangCalc.Z_Q_Value[RtuDataAddr->FkXuLiangCalc.Offset] = 0;

			RtuDataAddr->FkXuLiangCalc.F_Q_FL_Value[RtuDataAddr->NowFeiLvNo][RtuDataAddr->FkXuLiangCalc.Offset] = 0
					- RtuDataAddr->FkDdRealData.Q;
			RtuDataAddr->FkXuLiangCalc.Z_Q_FL_Value[RtuDataAddr->NowFeiLvNo][RtuDataAddr->FkXuLiangCalc.Offset] = 0;
		}

		RtuDataAddr->FkXuLiangCalc.X1_Q_FL_Value[RtuDataAddr->NowFeiLvNo][RtuDataAddr->FkXuLiangCalc.Offset]
				= RtuDataAddr->FkMaxXXXuliang.Q_X_1;
		RtuDataAddr->FkXuLiangCalc.X2_Q_FL_Value[RtuDataAddr->NowFeiLvNo][RtuDataAddr->FkXuLiangCalc.Offset]
				= RtuDataAddr->FkMaxXXXuliang.Q_X_2;
		RtuDataAddr->FkXuLiangCalc.X3_Q_FL_Value[RtuDataAddr->NowFeiLvNo][RtuDataAddr->FkXuLiangCalc.Offset]
				= RtuDataAddr->FkMaxXXXuliang.Q_X_3;
		RtuDataAddr->FkXuLiangCalc.X4_Q_FL_Value[RtuDataAddr->NowFeiLvNo][RtuDataAddr->FkXuLiangCalc.Offset]
				= RtuDataAddr->FkMaxXXXuliang.Q_X_4;

		RtuDataAddr->FkXuLiangCalc.Offset = (RtuDataAddr->FkXuLiangCalc.Offset + 1) % 15;
		////////////////////////////////////////////////////////
		XuLiangCalc(&RtuDataAddr->FkMaxXuliang.Z_P_X_All, RtuDataAddr->FkXuLiangCalc.Z_P_Value, RtuDataAddr->FkMaxXuliang.Time_Z_P_X_All, &RtuDataAddr->FkOldXuLiang.Z_P_Value, ts);//,INT32S *S,INT8U *DestTime,INT32S *CMP,TS ts)
		XuLiangCalc(&RtuDataAddr->FkMaxXuliang.Z_Q_X_All, RtuDataAddr->FkXuLiangCalc.Z_Q_Value, RtuDataAddr->FkMaxXuliang.Time_Z_Q_X_All, &RtuDataAddr->FkOldXuLiang.Z_Q_Value, ts);//,INT32S *S,INT8U *DestTime,INT32S *CMP,TS ts)
		XuLiangCalc(&RtuDataAddr->FkMaxXuliang.F_P_X_All, RtuDataAddr->FkXuLiangCalc.F_P_Value, RtuDataAddr->FkMaxXuliang.Time_F_P_X_All, &RtuDataAddr->FkOldXuLiang.F_P_Value, ts);//,INT32S *S,INT8U *DestTime,INT32S *CMP,TS ts)
		XuLiangCalc(&RtuDataAddr->FkMaxXuliang.F_Q_X_All, RtuDataAddr->FkXuLiangCalc.F_Q_Value, RtuDataAddr->FkMaxXuliang.Time_F_Q_X_All, &RtuDataAddr->FkOldXuLiang.F_Q_Value, ts);//,INT32S *S,INT8U *DestTime,INT32S *CMP,TS ts)

		XuLiangCalc(&RtuDataAddr->FkMaxXuliang.Z_P_X_F[RtuDataAddr->NowFeiLvNo], RtuDataAddr->FkXuLiangCalc.Z_P_FL_Value[RtuDataAddr->NowFeiLvNo], RtuDataAddr->FkMaxXuliang.Time_Z_P_X_F[RtuDataAddr->NowFeiLvNo], &RtuDataAddr->FkOldXuLiang.Z_P_FL_Value[RtuDataAddr->NowFeiLvNo], ts);
		XuLiangCalc(&RtuDataAddr->FkMaxXuliang.F_P_X_F[RtuDataAddr->NowFeiLvNo], RtuDataAddr->FkXuLiangCalc.F_P_FL_Value[RtuDataAddr->NowFeiLvNo], RtuDataAddr->FkMaxXuliang.Time_F_P_X_F[RtuDataAddr->NowFeiLvNo], &RtuDataAddr->FkOldXuLiang.F_P_FL_Value[RtuDataAddr->NowFeiLvNo], ts);
		XuLiangCalc(&RtuDataAddr->FkMaxXuliang.Z_Q_X_F[RtuDataAddr->NowFeiLvNo], RtuDataAddr->FkXuLiangCalc.Z_Q_FL_Value[RtuDataAddr->NowFeiLvNo], RtuDataAddr->FkMaxXuliang.Time_Z_Q_X_F[RtuDataAddr->NowFeiLvNo], &RtuDataAddr->FkOldXuLiang.Z_Q_FL_Value[RtuDataAddr->NowFeiLvNo], ts);
		XuLiangCalc(&RtuDataAddr->FkMaxXuliang.F_Q_X_F[RtuDataAddr->NowFeiLvNo], RtuDataAddr->FkXuLiangCalc.F_Q_FL_Value[RtuDataAddr->NowFeiLvNo], RtuDataAddr->FkMaxXuliang.Time_F_Q_X_F[RtuDataAddr->NowFeiLvNo], &RtuDataAddr->FkOldXuLiang.F_Q_FL_Value[RtuDataAddr->NowFeiLvNo], ts);

		XuLiangCalc(&RtuDataAddr->FkMaxXXXuliang.X1_Q_F[RtuDataAddr->NowFeiLvNo], RtuDataAddr->FkXuLiangCalc.X1_Q_FL_Value[RtuDataAddr->NowFeiLvNo], RtuDataAddr->FkMaxXXXuliang.Time_X1_Q_F[RtuDataAddr->NowFeiLvNo], &RtuDataAddr->FkOldXuLiang.X1_Q_FL_Value[RtuDataAddr->NowFeiLvNo], ts);
		XuLiangCalc(&RtuDataAddr->FkMaxXXXuliang.X2_Q_F[RtuDataAddr->NowFeiLvNo], RtuDataAddr->FkXuLiangCalc.X2_Q_FL_Value[RtuDataAddr->NowFeiLvNo], RtuDataAddr->FkMaxXXXuliang.Time_X2_Q_F[RtuDataAddr->NowFeiLvNo], &RtuDataAddr->FkOldXuLiang.X2_Q_FL_Value[RtuDataAddr->NowFeiLvNo], ts);
		XuLiangCalc(&RtuDataAddr->FkMaxXXXuliang.X3_Q_F[RtuDataAddr->NowFeiLvNo], RtuDataAddr->FkXuLiangCalc.X3_Q_FL_Value[RtuDataAddr->NowFeiLvNo], RtuDataAddr->FkMaxXXXuliang.Time_X3_Q_F[RtuDataAddr->NowFeiLvNo], &RtuDataAddr->FkOldXuLiang.X3_Q_FL_Value[RtuDataAddr->NowFeiLvNo], ts);
		XuLiangCalc(&RtuDataAddr->FkMaxXXXuliang.X4_Q_F[RtuDataAddr->NowFeiLvNo], RtuDataAddr->FkXuLiangCalc.X4_Q_FL_Value[RtuDataAddr->NowFeiLvNo], RtuDataAddr->FkMaxXXXuliang.Time_X4_Q_F[RtuDataAddr->NowFeiLvNo], &RtuDataAddr->FkOldXuLiang.X4_Q_FL_Value[RtuDataAddr->NowFeiLvNo], ts);
		RtuDataAddr->FkMaxXuliang.Valid = 1;
		//		RtuDataAddr->FkMaxXuliang.ProtocolType=2;
		memcpy(&RtuDataAddr->FkMaxXuliang.Chao_Time.BCD01, &RtuDataAddr->FkDdRealData.Chao_Time.BCD01, 5);
		FeiLvMin = ts.Minute;
	}
}

void DoFkDataChange(TS ts) {

	INT8U i, Num, Ch;
	Ch = 0;

	if (RtuDataAddr->Meter_Para.Valid != 1)
		return;
	if (RtuDataAddr->Meter_Para.Metet_jiaoliu_Num > CeLiangPoint_Max)
		return;
	for (i = 0; i < RtuDataAddr->Meter_Para.Metet_jiaoliu_Num; i++) {
		if (RtuDataAddr->Meter_Para.Dian_Meter[i].GuiYue_Type == JiaoLiuType) {//ϵͳĬ��һ�齻������װ�ã����ն˱���
			//if (RtuDataAddr->Meter_Para.Dian_Meter[i].Addr[0] == 1)
			{
				Num = RtuDataAddr->Meter_Para.Dian_Meter[i].CeLiangNo - 1;
				if (Num > CeLiangPoint_Max)
				{
					RtuDataAddr->DD_Device_BiaoShi_Value[Num].Valid = 0;
					RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Valid = 0;
					return;
				}
				memcpy(&RtuDataAddr->DD_Device_BiaoShi_Value[Num].Valid, &RtuDataAddr->FkDdRealData.Valid, sizeof(RtuDataAddr->FkDdRealData));
				memcpy(&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Valid, &RtuDataAddr->FkMaxXuliang.Valid, sizeof(RtuDataAddr->FkMaxXuliang));
				RtuDataAddr->DD_BianLiang_Shuju[Num].Valid = 1;
				//�����ն˵�ѹ�ϸ���ͳ�Ƽ�����жϼӵ�ʧ���ж�
				if ((RtuDataAddr->DD_Device_BiaoShi_Value[Num].VA > SD_Men) || (RtuDataAddr->DD_Device_BiaoShi_Value[Num].VB
						> SD_Men) || (RtuDataAddr->DD_Device_BiaoShi_Value[Num].VC > SD_Men)) {
					if ((RtuDataAddr->Fm_Save_Eve.FKTmp.VA <= SD_Men) && (RtuDataAddr->Fm_Save_Eve.FKTmp.VB <= SD_Men)
							&& (RtuDataAddr->Fm_Save_Eve.FKTmp.VC <= SD_Men)) {
						Sev_Data_Type_17(ts, RtuDataAddr->Fm_Save_Eve.FKTmp.LastDuan_E_Time);
						Sev_Data_Type_17(ts, RtuDataAddr->DD_BianLiang_Shuju[Num].LastDuan_E_Time);
						Ch = 1;
					}
				}
				if ((RtuDataAddr->Fm_Save_Eve.FKTmp.VA > SD_Men) || (RtuDataAddr->Fm_Save_Eve.FKTmp.VB > SD_Men)
						|| (RtuDataAddr->Fm_Save_Eve.FKTmp.VC > SD_Men)) {
					if ((RtuDataAddr->DD_Device_BiaoShi_Value[Num].VA <= SD_Men) && (RtuDataAddr->DD_Device_BiaoShi_Value[Num].VB
							<= SD_Men) && (RtuDataAddr->DD_Device_BiaoShi_Value[Num].VC <= SD_Men)) {
						Sev_Data_Type_17(ts, RtuDataAddr->Fm_Save_Eve.FKTmp.LastDuan_S_Time);
						RtuDataAddr->Fm_Save_Eve.FKTmp.Duanxiang_All++;
						Ch = 1;
					}
				}
				if (RtuDataAddr->Fm_Save_Eve.FKTmp.VA > SD_Men) {
					if (RtuDataAddr->DD_Device_BiaoShi_Value[Num].VA <= SD_Men) {
						Sev_Data_Type_17(ts, RtuDataAddr->Fm_Save_Eve.FKTmp.ADuan_S_Time);
						RtuDataAddr->Fm_Save_Eve.FKTmp.A_Duan++;
						Ch = 1;
					}
				}
				if (RtuDataAddr->Fm_Save_Eve.FKTmp.VB > SD_Men) {
					if (RtuDataAddr->DD_Device_BiaoShi_Value[Num].VB <= SD_Men) {
						Sev_Data_Type_17(ts, RtuDataAddr->Fm_Save_Eve.FKTmp.BDuan_S_Time);
						Sev_Data_Type_17(ts, RtuDataAddr->DD_BianLiang_Shuju[Num].BDuan_S_Time);
						RtuDataAddr->Fm_Save_Eve.FKTmp.B_Duan++;
						Ch = 1;
					}
				}
				if (RtuDataAddr->Fm_Save_Eve.FKTmp.VC > SD_Men) {
					if (RtuDataAddr->DD_Device_BiaoShi_Value[Num].VC <= SD_Men) {
						Sev_Data_Type_17(ts, RtuDataAddr->Fm_Save_Eve.FKTmp.CDuan_S_Time);
						RtuDataAddr->Fm_Save_Eve.FKTmp.C_Duan++;
						Ch = 1;
					}
				}
				if (RtuDataAddr->DD_Device_BiaoShi_Value[Num].VA > SD_Men) {
					if (RtuDataAddr->Fm_Save_Eve.FKTmp.VA <= SD_Men) {
						Sev_Data_Type_17(ts, RtuDataAddr->Fm_Save_Eve.FKTmp.ADuan_E_Time);
						Ch = 1;
					}
				}
				if (RtuDataAddr->DD_Device_BiaoShi_Value[Num].VB > SD_Men) {
					if (RtuDataAddr->Fm_Save_Eve.FKTmp.VB <= SD_Men) {
						Sev_Data_Type_17(ts, RtuDataAddr->Fm_Save_Eve.FKTmp.BDuan_E_Time);
						Ch = 1;
					}
				}
				if (RtuDataAddr->DD_Device_BiaoShi_Value[Num].VC > SD_Men) {
					if (RtuDataAddr->Fm_Save_Eve.FKTmp.VC <= SD_Men) {
						Sev_Data_Type_17(ts, RtuDataAddr->Fm_Save_Eve.FKTmp.CDuan_E_Time);
						Ch = 1;
					}
				}
				INT32ToBCD(RtuDataAddr->Fm_Save_Eve.FKTmp.Duanxiang_All, RtuDataAddr->DD_BianLiang_Shuju[Num].Duanxiang_All, 2);
				INT32ToBCD(RtuDataAddr->Fm_Save_Eve.FKTmp.A_Duan, RtuDataAddr->DD_BianLiang_Shuju[Num].A_Duan, 2);
				INT32ToBCD(RtuDataAddr->Fm_Save_Eve.FKTmp.B_Duan, RtuDataAddr->DD_BianLiang_Shuju[Num].B_Duan, 2);
				INT32ToBCD(RtuDataAddr->Fm_Save_Eve.FKTmp.C_Duan, RtuDataAddr->DD_BianLiang_Shuju[Num].C_Duan, 2);
				INT32ToBCD(RtuDataAddr->Fm_Save_Eve.FKTmp.Duanxiang_Time, RtuDataAddr->DD_BianLiang_Shuju[Num].Duanxiang_Time, 3);
				INT32ToBCD(RtuDataAddr->Fm_Save_Eve.FKTmp.A_Duan_Time, RtuDataAddr->DD_BianLiang_Shuju[Num].A_Duan_Time, 3);
				INT32ToBCD(RtuDataAddr->Fm_Save_Eve.FKTmp.B_Duan_Time, RtuDataAddr->DD_BianLiang_Shuju[Num].B_Duan_Time, 3);
				INT32ToBCD(RtuDataAddr->Fm_Save_Eve.FKTmp.C_Duan_Time, RtuDataAddr->DD_BianLiang_Shuju[Num].C_Duan_Time, 3);
				memcpy(RtuDataAddr->DD_BianLiang_Shuju[Num].LastDuan_E_Time, RtuDataAddr->Fm_Save_Eve.FKTmp.LastDuan_E_Time, 4);
				memcpy(RtuDataAddr->DD_BianLiang_Shuju[Num].LastDuan_S_Time, RtuDataAddr->Fm_Save_Eve.FKTmp.LastDuan_S_Time, 4);
				memcpy(RtuDataAddr->DD_BianLiang_Shuju[Num].ADuan_E_Time, RtuDataAddr->Fm_Save_Eve.FKTmp.ADuan_E_Time, 4);
				memcpy(RtuDataAddr->DD_BianLiang_Shuju[Num].BDuan_E_Time, RtuDataAddr->Fm_Save_Eve.FKTmp.BDuan_E_Time, 4);
				memcpy(RtuDataAddr->DD_BianLiang_Shuju[Num].CDuan_E_Time, RtuDataAddr->Fm_Save_Eve.FKTmp.CDuan_E_Time, 4);
				memcpy(RtuDataAddr->DD_BianLiang_Shuju[Num].ADuan_S_Time, RtuDataAddr->Fm_Save_Eve.FKTmp.ADuan_S_Time, 4);
				memcpy(RtuDataAddr->DD_BianLiang_Shuju[Num].BDuan_S_Time, RtuDataAddr->Fm_Save_Eve.FKTmp.BDuan_S_Time, 4);
				memcpy(RtuDataAddr->DD_BianLiang_Shuju[Num].CDuan_S_Time, RtuDataAddr->Fm_Save_Eve.FKTmp.CDuan_S_Time, 4);
				Sev_Data_Type_15(ts, &RtuDataAddr->DD_BianLiang_Shuju[Num].Chao_Time.BCD01);
				RtuDataAddr->Fm_Save_Eve.FKTmp.VA = RtuDataAddr->DD_Device_BiaoShi_Value[Num].VA;
				RtuDataAddr->Fm_Save_Eve.FKTmp.VB = RtuDataAddr->DD_Device_BiaoShi_Value[Num].VB;
				RtuDataAddr->Fm_Save_Eve.FKTmp.VC = RtuDataAddr->DD_Device_BiaoShi_Value[Num].VC;
				if (Ch == 1) {
					Fm25cl64_Write(&RtuDataAddr->Fm_Save_Eve.EC1, sizeof(RtuDataAddr->Fm_Save_Eve), Fm_Save_Eve_Offset);
				}
			}
		}
	}
	//JugePowerEvent(ts);
}
void DoYouGongShuChu() {
	char light1 = 0;
	for (;;) {
		if (RtuDataAddr->FkDdRealData.VB > 0) {
			SetSpiLed(PSTEP_LED);
			if (light1) {
				SetSpiLed(PSTEP_LED);
				light1 = 0;
			} else {
				ClearSpiLed(PSTEP_LED);
				light1 = 1;
			}
		} else
			ClearSpiLed(PSTEP_LED);
	}
}
void DoWuGongShuChu() {
	char light2 = 0;
	for (;;) {
		if (RtuDataAddr->FkDdRealData.VB > 0) {
			SetSpiLed(QSTEP_LED);
			if (light2) {
				SetSpiLed(QSTEP_LED);
				light2 = 0;
			} else {
				ClearSpiLed(QSTEP_LED);
				light2 = 1;
			}
		} else
			ClearSpiLed(QSTEP_LED);
	}
}
