#ifndef FKDSFUN_H_
#define FKDSFUN_H_
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <ctype.h>
#include <time.h>
#include <signal.h>
#include <sys/sched.h>
#include <semaphore.h>
#include <process.h>
#include <sys/neutrino.h>
#include <sys/netmgr.h>
#include <sys/dispatch.h>
#include <errno.h>
#include <netdb.h>
#include <hw/inout.h>
#include <fkbase/spi-master.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <math.h>
#include <fkbase/memdef.h>
#include <fkbase/fkbasefun.h>
#include <fkbase/basetype.h>
#define DataSaveDbg if(RtuDataAddr->DATASAVEDBON)printf

RTimeData  *RtuDataAddr;//�ڴ湲��������ָ��
name_attach_t *attach;
INT8U 	   PORT_ID;
FILE *Gwfp;
#define XXPrint(...) fprintf(Gwfp, __VA_ARGS__);fflush(Gwfp);
typedef struct
{
	F27_28_29_30_level_stru   TongjiData[CeLiangPoint_Max];
	TS                        SaveTime;
}SAVETONGJI_TYPE;
int setupTimer();
void QuitProcess(int signo);
INT8U CheckMem(INT8U *s,INT16U len);
void SaveZhongwen();
void ReadZhongwen();
void SaveDayCLInit();
void ReadDayCLInit();
void SaveYueCLInit();
void ReadYueCLInit();
void SaveDayZJInit();
void ReadDayZJInit();
void SaveYueZJInit();
void ReadYueZJInit();
INT32S Get_BianBi(INT8U ClNo);
void Save_Min15_Data();
void Read_Min15_Data();
void Make_DayHisDianneng();
void Make_YueHisDianneng();
void Make_DaySave(INT8U Hour,INT8U Sort);
void HisDiannengTest();
void Make_Hour_Value(INT8U Sort);
void Save_Hour_Value();
void Save_Zj_real_Data();
void Read_Zj_real_Data();
void Save_Fk_real_Data();
void Read_Fk_real_Data();
void SaveGlvXFValue();
void ResetSet();
void ResetData();
void Calc_Day_Bs_zj();
void Calc_Yue_Bs_zj();
void SaveClQuXian(/*TS ts,*/INT16U Sort,INT8U month,INT8U day);
void ReadQx(TS ts);
void SaveClYueValue(Data_Type_15 Savedate);
void SaveClDayValue(Data_Type_15 Savedate);

#endif /*FKDSFUN_H_*/
