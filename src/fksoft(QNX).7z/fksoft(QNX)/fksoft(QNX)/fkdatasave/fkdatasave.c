#include "fkdsfun.h"
const char verstr[]={"VER-STRING-FLG=004.002.217.004"__DATE__" "__TIME__};

INT8U CheckMem(INT8U *s,INT16U len)
{
	INT16U i;
	INT8U C;
	C=0;
	for(i=0;i<len-4;i++)
	{
		C=C+s[i];
	}
	return C;
}
void SaveZhongwen()
{
	SaveFile((INT8U *)"/nand/save/fkzhongwen.sav",(INT8U *)RtuDataAddr->FkZhongWen,sizeof(RtuDataAddr->FkZhongWen));
}
void ReadZhongwen()
{
	if(ReadFile((INT8U *)"/nand/save/fkzhongwen.sav",(INT8U *)RtuDataAddr->FkZhongWen,sizeof(RtuDataAddr->FkZhongWen)))
	{
		memset(RtuDataAddr->FkZhongWen,0,sizeof(RtuDataAddr->FkZhongWen));
		SaveZhongwen();
	}
}
void SaveDayCLInit()
{
	SaveFile((INT8U *)"/nand/save/fkcldayinit.sav",(INT8U *)RtuDataAddr->DD_Device_BiaoShi_Value,sizeof(RtuDataAddr->DD_Device_BiaoShi_Value));
}
void ReadDayCLInit()
{
	if(ReadFile((INT8U *)"/nand/save/fkcldayinit.sav",(INT8U *)RtuDataAddr->DD_Device_BiaoShi_Value,sizeof(RtuDataAddr->DD_Device_BiaoShi_Value)))
	{
		memset(RtuDataAddr->DD_Device_BiaoShi_Value,0,sizeof(RtuDataAddr->DD_Device_BiaoShi_Value));
		SaveDayCLInit();
	}
}
void SaveYueCLInit()
{
	SaveFile((INT8U *)"/nand/save/fkclyueinit.sav",(INT8U *)RtuDataAddr->DD_Device_BiaoShi_Value,sizeof(RtuDataAddr->DD_Device_BiaoShi_Value));
}
void ReadYueCLInit()
{
	if(ReadFile((INT8U *)"/nand/save/fkclyueinit.sav",(INT8U *)RtuDataAddr->Yue_DD_BS_Value,sizeof(RtuDataAddr->Yue_DD_BS_Value)))
	{
		memset(RtuDataAddr->Yue_DD_BS_Value,0,sizeof(RtuDataAddr->Yue_DD_BS_Value));
		SaveYueCLInit();
	}
}
void SaveDayZJInit()
{
	SaveFile((INT8U *)"/nand/save/fkzjdayinit.sav",(INT8U *)RtuDataAddr->Real_Zj_Value,sizeof(RtuDataAddr->Real_Zj_Value));
}
void ReadDayZJInit()
{
	if(ReadFile((INT8U *)"/nand/save/fkzjdayinit.sav",(INT8U *)RtuDataAddr->Day_Zj_Value,sizeof(RtuDataAddr->Day_Zj_Value)))
	{
		memset(RtuDataAddr->Day_Zj_Value,0,sizeof(RtuDataAddr->Day_Zj_Value));
		SaveDayZJInit();
	}
}
void SaveYueZJInit()
{
	SaveFile((INT8U *)"/nand/save/fkzjyueinit.sav",(INT8U *)RtuDataAddr->Real_Zj_Value,sizeof(RtuDataAddr->Real_Zj_Value));
}
void ReadYueZJInit()
{
	if(ReadFile((INT8U *)"/nand/save/fkzjyueinit.sav",(INT8U *)RtuDataAddr->Yue_Zj_Value,sizeof(RtuDataAddr->Yue_Zj_Value)))
	{
		memset(RtuDataAddr->Yue_Zj_Value,0,sizeof(RtuDataAddr->Yue_Zj_Value));
		SaveYueZJInit();
	}
}
INT32S Get_BianBi(INT8U ClNo)
{
	INT32S I,V;
	if(RtuDataAddr->Cl_MenXian_Value[ClNo].F25_Set_Para.Valid==1)
	{
		I=RtuDataAddr->Cl_MenXian_Value[ClNo].F25_Set_Para.I_BeiLv[1];
		I=(I<<8)+RtuDataAddr->Cl_MenXian_Value[ClNo].F25_Set_Para.I_BeiLv[0];
		V=RtuDataAddr->Cl_MenXian_Value[ClNo].F25_Set_Para.V_BeiLv[1];
		V=(V<<8)+RtuDataAddr->Cl_MenXian_Value[ClNo].F25_Set_Para.V_BeiLv[0];
		return I*V;
	}
	else
	{
		return 1;
	}
return 1;
}
void Save_Min15_Data()
{
	SaveFile((INT8U *)"/nand/save/fkzjMin15.sav",(INT8U *)RtuDataAddr->Min_15_Zj_Value,sizeof(RtuDataAddr->Min_15_Zj_Value));
	SaveFile((INT8U *)"/nand/save/fkclMin15.sav",(INT8U *)RtuDataAddr->Min_15_DD_BS_Value,sizeof(RtuDataAddr->Min_15_DD_BS_Value));
}
void Read_Min15_Data()
{
	if(!ReadFile((INT8U *)"/nand/save/fkzjMin15.sav",(INT8U *)RtuDataAddr->Min_15_Zj_Value,sizeof(RtuDataAddr->Min_15_Zj_Value)))
	{
		memset(RtuDataAddr->Min_15_Zj_Value,0,sizeof(RtuDataAddr->Min_15_Zj_Value));
	}
	if(!ReadFile((INT8U *)"/nand/save/fkclMin15.sav",(INT8U *)RtuDataAddr->Min_15_DD_BS_Value,sizeof(RtuDataAddr->Min_15_DD_BS_Value)))
	{
		memset(RtuDataAddr->Min_15_DD_BS_Value,0,sizeof(RtuDataAddr->Min_15_DD_BS_Value));
	}
}
void Make_DayHisDianneng()
{
	INT16U i,j;
	for(i=0;i<ZongJia_Max;i++)
	{
		RtuDataAddr->Day_Save_Value.Zj_His_DianNeng[i].Valid=RtuDataAddr->Real_Zj_Value[i].Valid;
		RtuDataAddr->Day_Save_Value.Zj_His_DianNeng[i].Z_P_All_S=RtuDataAddr->Real_Zj_Value[i].P_All;
		RtuDataAddr->Day_Save_Value.Zj_His_DianNeng[i].Z_Q_All_S=RtuDataAddr->Real_Zj_Value[i].Q_All;
		if(RtuDataAddr->Real_Zj_Value[i].P_All<RtuDataAddr->Day_Zj_Value[i].P_All)
			RtuDataAddr->Day_Save_Value.Zj_His_DianNeng[i].Z_P_All_D=0;
		else
			RtuDataAddr->Day_Save_Value.Zj_His_DianNeng[i].Z_P_All_D=
				RtuDataAddr->Real_Zj_Value[i].P_All-RtuDataAddr->Day_Zj_Value[i].P_All;
		if(RtuDataAddr->Real_Zj_Value[i].Q_All<RtuDataAddr->Day_Zj_Value[i].Q_All)
			RtuDataAddr->Day_Save_Value.Zj_His_DianNeng[i].Z_Q_All_D=0;
		else
			RtuDataAddr->Day_Save_Value.Zj_His_DianNeng[i].Z_Q_All_D=
				RtuDataAddr->Real_Zj_Value[i].Q_All-RtuDataAddr->Day_Zj_Value[i].Q_All;
		for(j=0;j<FeiLvNum;j++)
		{
			RtuDataAddr->Day_Save_Value.Zj_His_DianNeng[i].Z_P_F_S[j]=RtuDataAddr->Real_Zj_Value[i].P_F[j];
			RtuDataAddr->Day_Save_Value.Zj_His_DianNeng[i].Z_Q_F_S[j]=RtuDataAddr->Real_Zj_Value[i].Q_F[j];
			if(RtuDataAddr->Real_Zj_Value[i].P_F[j]<RtuDataAddr->Day_Zj_Value[i].P_F[j])
				RtuDataAddr->Day_Save_Value.Zj_His_DianNeng[i].Z_P_F_D[j]=0;
			else
				RtuDataAddr->Day_Save_Value.Zj_His_DianNeng[i].Z_P_F_D[j]=RtuDataAddr->Real_Zj_Value[i].P_F[j]-RtuDataAddr->Day_Zj_Value[i].P_F[j];

			if(RtuDataAddr->Real_Zj_Value[i].Q_F[j]<RtuDataAddr->Day_Zj_Value[i].Q_F[j])
				RtuDataAddr->Day_Save_Value.Zj_His_DianNeng[i].Z_Q_F_D[j]=0;
			else
				RtuDataAddr->Day_Save_Value.Zj_His_DianNeng[i].Z_Q_F_D[j]=RtuDataAddr->Real_Zj_Value[i].Q_F[j]-RtuDataAddr->Day_Zj_Value[i].Q_F[j];
		}
	}
	for(i=0;i<CeLiangPoint_Max;i++)
	{
		RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[i].Valid=RtuDataAddr->DD_Device_BiaoShi_Value[i].Valid;
		memcpy(&RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[i].Chao_Time.BCD01,&RtuDataAddr->DD_Device_BiaoShi_Value[i].Chao_Time.BCD01,sizeof(RtuDataAddr->DD_Device_BiaoShi_Value[i].Chao_Time));
		RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[i].Z_P_All_S=RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_All;
		RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[i].Z_Q_All_S=RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_Q_All;
		RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[i].F_P_All_S=RtuDataAddr->DD_Device_BiaoShi_Value[i].F_P_All;
		RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[i].F_Q_All_S=RtuDataAddr->DD_Device_BiaoShi_Value[i].F_Q_All;
		RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[i].X1_Q_All=RtuDataAddr->DD_Device_BiaoShi_Value[i].X1_Q_All;
		RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[i].X4_Q_All=RtuDataAddr->DD_Device_BiaoShi_Value[i].X4_Q_All;
		RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[i].X2_Q_All=RtuDataAddr->DD_Device_BiaoShi_Value[i].X2_Q_All;
		RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[i].X3_Q_All=RtuDataAddr->DD_Device_BiaoShi_Value[i].X3_Q_All;
		if(RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_All<RtuDataAddr->Day_DD_BS_Value[i].Z_P_All)
			RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[i].Z_P_All_D=0;
		else
			RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[i].Z_P_All_D=RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_All-RtuDataAddr->Day_DD_BS_Value[i].Z_P_All;
		if(RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_Q_All<RtuDataAddr->Day_DD_BS_Value[i].Z_Q_All)
			RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[i].Z_Q_All_D=0;
		else
			RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[i].Z_Q_All_D=RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_Q_All-RtuDataAddr->Day_DD_BS_Value[i].Z_Q_All;
		if(RtuDataAddr->DD_Device_BiaoShi_Value[i].F_P_All<RtuDataAddr->Day_DD_BS_Value[i].F_P_All)
			RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[i].F_P_All_D=0;
		else
			RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[i].F_P_All_D=RtuDataAddr->DD_Device_BiaoShi_Value[i].F_P_All-RtuDataAddr->Day_DD_BS_Value[i].F_P_All;
		if(RtuDataAddr->DD_Device_BiaoShi_Value[i].F_Q_All<RtuDataAddr->Day_DD_BS_Value[i].F_Q_All)
			RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[i].F_Q_All_D=0;
		else
			RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[i].F_Q_All_D=RtuDataAddr->DD_Device_BiaoShi_Value[i].F_Q_All-RtuDataAddr->Day_DD_BS_Value[i].F_Q_All;
		for(j=0;j<FeiLvNum;j++)
		{
			RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[i].Z_P_F_S[j]=RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_F[j];
			RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[i].Z_Q_F_S[j]=RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_Q_F[j];
			RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[i].F_P_F_S[j]=RtuDataAddr->DD_Device_BiaoShi_Value[i].F_P_F[j];
			RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[i].F_Q_F_S[j]=RtuDataAddr->DD_Device_BiaoShi_Value[i].F_Q_F[j];
			RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[i].X1_F_Q[j]=RtuDataAddr->DD_Device_BiaoShi_Value[i].X1_F_Q[j];
			RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[i].X4_F_Q[j]=RtuDataAddr->DD_Device_BiaoShi_Value[i].X4_F_Q[j];
			RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[i].X2_F_Q[j]=RtuDataAddr->DD_Device_BiaoShi_Value[i].X2_F_Q[j];
			RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[i].X3_F_Q[j]=RtuDataAddr->DD_Device_BiaoShi_Value[i].X3_F_Q[j];
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_F[j]<RtuDataAddr->Day_DD_BS_Value[i].Z_P_F[j])
				RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[i].Z_P_F_D[j]=0;
			else
				RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[i].Z_P_F_D[j]=RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_F[j]-RtuDataAddr->Day_DD_BS_Value[i].Z_P_F[j];

			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_Q_F[j]<RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_Q_F[j])
				RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[i].Z_Q_F_D[j]=0;
			else
				RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[i].Z_Q_F_D[j]=RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_Q_F[j]-RtuDataAddr->Day_DD_BS_Value[i].Z_Q_F[j];

			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].F_P_F[j]<RtuDataAddr->DD_Device_BiaoShi_Value[i].F_P_F[j])
				RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[i].F_P_F_D[j]=0;
			else
				RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[i].F_P_F_D[j]=RtuDataAddr->DD_Device_BiaoShi_Value[i].F_P_F[j]-RtuDataAddr->Day_DD_BS_Value[i].F_P_F[j];

			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].F_Q_F[j]<RtuDataAddr->DD_Device_BiaoShi_Value[i].F_Q_F[j])
				RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[i].F_Q_F_D[j]=0;
			else
				RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[i].F_Q_F_D[j]=RtuDataAddr->DD_Device_BiaoShi_Value[i].F_Q_F[j]-RtuDataAddr->Day_DD_BS_Value[i].F_Q_F[j];
		}
	}
}
void Make_YueHisDianneng()
{
	INT16U i,j;
	for(i=0;i<ZongJia_Max;i++)
	{
		RtuDataAddr->Yue_Save_Value.Zj_His_DianNeng[i].Valid=RtuDataAddr->Real_Zj_Value[i].Valid;
		RtuDataAddr->Yue_Save_Value.Zj_His_DianNeng[i].Z_P_All_S=RtuDataAddr->Real_Zj_Value[i].P_All;
		RtuDataAddr->Yue_Save_Value.Zj_His_DianNeng[i].Z_Q_All_S=RtuDataAddr->Real_Zj_Value[i].Q_All;
		if(RtuDataAddr->Real_Zj_Value[i].P_All<RtuDataAddr->Yue_Zj_Value[i].P_All)
		RtuDataAddr->Yue_Save_Value.Zj_His_DianNeng[i].Z_P_All_D=0;else
		RtuDataAddr->Yue_Save_Value.Zj_His_DianNeng[i].Z_P_All_D=RtuDataAddr->Real_Zj_Value[i].P_All-RtuDataAddr->Yue_Zj_Value[i].P_All;
		if(RtuDataAddr->Real_Zj_Value[i].Q_All<RtuDataAddr->Yue_Zj_Value[i].Q_All)
		RtuDataAddr->Yue_Save_Value.Zj_His_DianNeng[i].Z_P_All_D=0;else
		RtuDataAddr->Yue_Save_Value.Zj_His_DianNeng[i].Z_Q_All_D=RtuDataAddr->Real_Zj_Value[i].Q_All-RtuDataAddr->Yue_Zj_Value[i].Q_All;
		for(j=0;j<FeiLvNum;j++)
		{
			RtuDataAddr->Yue_Save_Value.Zj_His_DianNeng[i].Z_P_F_S[j]=RtuDataAddr->Real_Zj_Value[i].P_F[j];
			RtuDataAddr->Yue_Save_Value.Zj_His_DianNeng[i].Z_Q_F_S[j]=RtuDataAddr->Real_Zj_Value[i].Q_F[j];
			if(RtuDataAddr->Real_Zj_Value[i].P_F[j]<RtuDataAddr->Yue_Zj_Value[i].P_F[j])
			RtuDataAddr->Yue_Save_Value.Zj_His_DianNeng[i].Z_P_F_D[j]=0;else
			RtuDataAddr->Yue_Save_Value.Zj_His_DianNeng[i].Z_P_F_D[j]=RtuDataAddr->Real_Zj_Value[i].P_F[j]-RtuDataAddr->Yue_Zj_Value[i].P_F[j];

			if(RtuDataAddr->Real_Zj_Value[i].Q_F[j]<RtuDataAddr->Yue_Zj_Value[i].Q_F[j])
			RtuDataAddr->Yue_Save_Value.Zj_His_DianNeng[i].Z_Q_F_D[j]=0;else
			RtuDataAddr->Yue_Save_Value.Zj_His_DianNeng[i].Z_Q_F_D[j]=RtuDataAddr->Real_Zj_Value[i].Q_F[j]-RtuDataAddr->Yue_Zj_Value[i].Q_F[j];
		}
	}
	for(i=0;i<CeLiangPoint_Max;i++)
	{
		RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[i].Valid=RtuDataAddr->DD_Device_BiaoShi_Value[i].Valid;
		memcpy(&RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[i].Chao_Time.BCD01,&RtuDataAddr->DD_Device_BiaoShi_Value[i].Chao_Time.BCD01,sizeof(RtuDataAddr->DD_Device_BiaoShi_Value[i].Chao_Time));
		RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[i].Z_P_All_S=RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_All;
		RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[i].Z_Q_All_S=RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_Q_All;
		RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[i].F_P_All_S=RtuDataAddr->DD_Device_BiaoShi_Value[i].F_P_All;
		RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[i].F_Q_All_S=RtuDataAddr->DD_Device_BiaoShi_Value[i].F_Q_All;
		RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[i].X1_Q_All=RtuDataAddr->DD_Device_BiaoShi_Value[i].X1_Q_All;
		RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[i].X4_Q_All=RtuDataAddr->DD_Device_BiaoShi_Value[i].X4_Q_All;
		RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[i].X2_Q_All=RtuDataAddr->DD_Device_BiaoShi_Value[i].X2_Q_All;
		RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[i].X3_Q_All=RtuDataAddr->DD_Device_BiaoShi_Value[i].X3_Q_All;
		if(RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_All<RtuDataAddr->Yue_DD_BS_Value[i].Z_P_All)
		RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[i].Z_P_All_D=0;else
		RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[i].Z_P_All_D=RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_All-RtuDataAddr->Yue_DD_BS_Value[i].Z_P_All;
		if(RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_Q_All<RtuDataAddr->Yue_DD_BS_Value[i].Z_Q_All)
		RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[i].Z_Q_All_D=0;else
		RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[i].Z_Q_All_D=RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_Q_All-RtuDataAddr->Yue_DD_BS_Value[i].Z_Q_All;
		if(RtuDataAddr->DD_Device_BiaoShi_Value[i].F_P_All<RtuDataAddr->Yue_DD_BS_Value[i].F_P_All)
		RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[i].F_P_All_D=0;else
		RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[i].F_P_All_D=RtuDataAddr->DD_Device_BiaoShi_Value[i].F_P_All-RtuDataAddr->Yue_DD_BS_Value[i].F_P_All;
		if(RtuDataAddr->DD_Device_BiaoShi_Value[i].F_Q_All<RtuDataAddr->Yue_DD_BS_Value[i].F_Q_All)
		RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[i].F_Q_All_D=0;else
		RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[i].F_Q_All_D=RtuDataAddr->DD_Device_BiaoShi_Value[i].F_Q_All-RtuDataAddr->Yue_DD_BS_Value[i].F_Q_All;
		for(j=0;j<FeiLvNum;j++)
		{
			RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[i].Z_P_F_S[j]=RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_F[j];
			RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[i].Z_Q_F_S[j]=RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_Q_F[j];
			RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[i].F_P_F_S[j]=RtuDataAddr->DD_Device_BiaoShi_Value[i].F_P_F[j];
			RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[i].F_Q_F_S[j]=RtuDataAddr->DD_Device_BiaoShi_Value[i].F_Q_F[j];
			RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[i].X1_F_Q[j]=RtuDataAddr->DD_Device_BiaoShi_Value[i].X1_F_Q[j];
			RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[i].X4_F_Q[j]=RtuDataAddr->DD_Device_BiaoShi_Value[i].X4_F_Q[j];
			RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[i].X2_F_Q[j]=RtuDataAddr->DD_Device_BiaoShi_Value[i].X2_F_Q[j];
			RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[i].X3_F_Q[j]=RtuDataAddr->DD_Device_BiaoShi_Value[i].X3_F_Q[j];

			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_F[j]<RtuDataAddr->Yue_DD_BS_Value[i].Z_P_F[j])
			RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[i].Z_P_F_D[j]=0;else
			RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[i].Z_P_F_D[j]=RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_F[j]-RtuDataAddr->Yue_DD_BS_Value[i].Z_P_F[j];

			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_Q_F[j]<RtuDataAddr->Yue_DD_BS_Value[i].Z_Q_F[j])
			RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[i].Z_Q_F_D[j]=0;else
			RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[i].Z_Q_F_D[j]=RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_Q_F[j]-RtuDataAddr->Yue_DD_BS_Value[i].Z_Q_F[j];

			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].F_P_F[j]<RtuDataAddr->Yue_DD_BS_Value[i].F_P_F[j])
			RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[i].F_P_F_D[j]=0;else
			RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[i].F_P_F_D[j]=RtuDataAddr->DD_Device_BiaoShi_Value[i].F_P_F[j]-RtuDataAddr->Yue_DD_BS_Value[i].F_P_F[j];

			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].F_Q_F[j]<RtuDataAddr->Yue_DD_BS_Value[i].F_Q_F[j])
			RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[i].F_Q_F_D[j]=0;else
			RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[i].F_Q_F_D[j]=RtuDataAddr->DD_Device_BiaoShi_Value[i].F_Q_F[j]-RtuDataAddr->Yue_DD_BS_Value[i].F_Q_F[j];
		}
	}
}
void Make_DaySave(INT8U Hour,INT8U Sort)
{
	INT16U i,Pos;
	Pos=Hour*4+Sort;
	for(i=0;i<ZongJia_Max;i++)
	{
		RtuDataAddr->Day_Save_Value.QX_Zj[i].Zj_P=RtuDataAddr->Real_Zj_Value[i].P;
		RtuDataAddr->Day_Save_Value.QX_Zj[i].Zj_Q=RtuDataAddr->Real_Zj_Value[i].Q;
		if(RtuDataAddr->Real_Zj_Value[i].P_All<RtuDataAddr->Min_15_Zj_Value[i].P_All)
			RtuDataAddr->Day_Save_Value.QX_Zj[i].Zj_PDD=0;
		else
			RtuDataAddr->Day_Save_Value.QX_Zj[i].Zj_PDD=RtuDataAddr->Real_Zj_Value[i].P_All-RtuDataAddr->Min_15_Zj_Value[i].P_All;
		if(RtuDataAddr->Real_Zj_Value[i].Q_All<RtuDataAddr->Min_15_Zj_Value[i].Q_All)
			RtuDataAddr->Day_Save_Value.QX_Zj[i].Zj_QDD=0;
		else
			RtuDataAddr->Day_Save_Value.QX_Zj[i].Zj_QDD=RtuDataAddr->Real_Zj_Value[i].Q_All-RtuDataAddr->Min_15_Zj_Value[i].Q_All;
	}
	for(i=0;i<CeLiangPoint_Max;i++)
	{
		RtuDataAddr->Day_Save_Value.QX_Cl[i].Cl_P=RtuDataAddr->DD_Device_BiaoShi_Value[i].P;
		RtuDataAddr->Day_Save_Value.QX_Cl[i].Cl_Q=RtuDataAddr->DD_Device_BiaoShi_Value[i].Q;
		if(RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_All<RtuDataAddr->Min_15_DD_BS_Value[i].Z_P_All)
			RtuDataAddr->Day_Save_Value.QX_Cl[i].Cl_PDD=0;
		else
			RtuDataAddr->Day_Save_Value.QX_Cl[i].Cl_PDD=RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_All-RtuDataAddr->Min_15_DD_BS_Value[i].Z_P_All;
		if(RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_Q_All<RtuDataAddr->Min_15_DD_BS_Value[i].Z_Q_All)
			RtuDataAddr->Day_Save_Value.QX_Cl[i].Cl_QDD=0;
		else
			RtuDataAddr->Day_Save_Value.QX_Cl[i].Cl_QDD=RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_Q_All-RtuDataAddr->Min_15_DD_BS_Value[i].Z_Q_All;

		if(RtuDataAddr->DD_Device_BiaoShi_Value[i].F_P_All<RtuDataAddr->Min_15_DD_BS_Value[i].F_P_All)
			RtuDataAddr->Day_Save_Value.QX_Cl[i].Cl_PFDD=0;
		else
			RtuDataAddr->Day_Save_Value.QX_Cl[i].Cl_PFDD=RtuDataAddr->DD_Device_BiaoShi_Value[i].F_P_All-RtuDataAddr->Min_15_DD_BS_Value[i].F_P_All;
		if(RtuDataAddr->DD_Device_BiaoShi_Value[i].F_Q_All<RtuDataAddr->Min_15_DD_BS_Value[i].F_Q_All)
			RtuDataAddr->Day_Save_Value.QX_Cl[i].Cl_QFDD=0;
		else
			RtuDataAddr->Day_Save_Value.QX_Cl[i].Cl_QFDD=RtuDataAddr->DD_Device_BiaoShi_Value[i].F_Q_All-RtuDataAddr->Min_15_DD_BS_Value[i].F_Q_All;
	}
}
void HisDiannengTest()
{
	INT8U i,j;
	for(i=0;i<CeLiangPoint_Max;i++)
	{
		if(RtuDataAddr->DD_Device_BiaoShi_Value[i].Valid==1)
		{
			if((RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_All<RtuDataAddr->Day_DD_BS_Value[i].Z_P_All)
			||(RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_Q_All<RtuDataAddr->Day_DD_BS_Value[i].Z_Q_All)
			||(RtuDataAddr->DD_Device_BiaoShi_Value[i].F_P_All<RtuDataAddr->Day_DD_BS_Value[i].F_P_All)
			||(RtuDataAddr->DD_Device_BiaoShi_Value[i].F_Q_All<RtuDataAddr->Day_DD_BS_Value[i].F_Q_All)
			)
			{
				RtuDataAddr->Day_DD_BS_Value[i].Z_P_All=	RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_All;
				RtuDataAddr->Day_DD_BS_Value[i].Z_Q_All=	RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_Q_All;
				RtuDataAddr->Day_DD_BS_Value[i].F_P_All=	RtuDataAddr->DD_Device_BiaoShi_Value[i].F_P_All;
				RtuDataAddr->Day_DD_BS_Value[i].F_Q_All=	RtuDataAddr->DD_Device_BiaoShi_Value[i].F_Q_All;
				for(j=0;j<FeiLvNum;j++)
				{
					RtuDataAddr->Day_DD_BS_Value[i].Z_P_F[j]=RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_F[j];
					RtuDataAddr->Day_DD_BS_Value[i].Z_Q_F[j]=RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_Q_F[j];
					RtuDataAddr->Day_DD_BS_Value[i].F_P_F[j]=RtuDataAddr->DD_Device_BiaoShi_Value[i].F_P_F[j];
					RtuDataAddr->Day_DD_BS_Value[i].F_Q_F[j]=RtuDataAddr->DD_Device_BiaoShi_Value[i].F_Q_F[j];
				}
			}
		}
	}
	for(i=0;i<CeLiangPoint_Max;i++)
	{
		if(RtuDataAddr->DD_Device_BiaoShi_Value[i].Valid==1)
		{
			if((RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_All<RtuDataAddr->Yue_DD_BS_Value[i].Z_P_All)
			||(RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_Q_All<RtuDataAddr->Yue_DD_BS_Value[i].Z_Q_All)
			||(RtuDataAddr->DD_Device_BiaoShi_Value[i].F_P_All<RtuDataAddr->Yue_DD_BS_Value[i].F_P_All)
			||(RtuDataAddr->DD_Device_BiaoShi_Value[i].F_Q_All<RtuDataAddr->Yue_DD_BS_Value[i].F_Q_All)
			)
			{
				RtuDataAddr->Yue_DD_BS_Value[i].Z_P_All=	RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_All;
				RtuDataAddr->Yue_DD_BS_Value[i].Z_Q_All=	RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_Q_All;
				RtuDataAddr->Yue_DD_BS_Value[i].F_P_All=	RtuDataAddr->DD_Device_BiaoShi_Value[i].F_P_All;
				RtuDataAddr->Yue_DD_BS_Value[i].F_Q_All=	RtuDataAddr->DD_Device_BiaoShi_Value[i].F_Q_All;
				for(j=0;j<FeiLvNum;j++)
				{
					RtuDataAddr->Yue_DD_BS_Value[i].Z_P_F[j]=RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_F[j];
					RtuDataAddr->Yue_DD_BS_Value[i].Z_Q_F[j]=RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_Q_F[j];
					RtuDataAddr->Yue_DD_BS_Value[i].F_P_F[j]=RtuDataAddr->DD_Device_BiaoShi_Value[i].F_P_F[j];
					RtuDataAddr->Yue_DD_BS_Value[i].F_Q_F[j]=RtuDataAddr->DD_Device_BiaoShi_Value[i].F_Q_F[j];
				}
			}
		}
	}
}

void Make_Hour_Value(INT8U Sort)
{
	INT8U i;
	for(i=0;i<CeLiangPoint_Max;i++)
	{
		memcpy(&RtuDataAddr->Hour_DD_BS_Value[Sort][i].Valid,&RtuDataAddr->DD_Device_BiaoShi_Value[i].Valid,sizeof(RtuDataAddr->DD_Device_BiaoShi_Value[i]));
		RtuDataAddr->Hour_DD_BS_Value[Sort][i].Z_P_All=(RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_All-RtuDataAddr->Min_15_DD_BS_Value[i].Z_P_All);
		RtuDataAddr->Hour_DD_BS_Value[Sort][i].Z_P_F[0]=RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_All;

		RtuDataAddr->Hour_DD_BS_Value[Sort][i].Z_Q_All=(RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_Q_All-RtuDataAddr->Min_15_DD_BS_Value[i].Z_Q_All);
		RtuDataAddr->Hour_DD_BS_Value[Sort][i].Z_Q_F[0]=RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_Q_All;

		RtuDataAddr->Hour_DD_BS_Value[Sort][i].F_P_All=(RtuDataAddr->DD_Device_BiaoShi_Value[i].F_P_All-RtuDataAddr->Min_15_DD_BS_Value[i].F_P_All);
		RtuDataAddr->Hour_DD_BS_Value[Sort][i].F_P_F[0]=RtuDataAddr->DD_Device_BiaoShi_Value[i].F_P_All;

		RtuDataAddr->Hour_DD_BS_Value[Sort][i].F_Q_All=(RtuDataAddr->DD_Device_BiaoShi_Value[i].F_Q_All-RtuDataAddr->Min_15_DD_BS_Value[i].F_Q_All);
		RtuDataAddr->Hour_DD_BS_Value[Sort][i].F_Q_F[0]=RtuDataAddr->DD_Device_BiaoShi_Value[i].F_Q_All;

		RtuDataAddr->Hour_DD_BS_Value[Sort][i].IA=RtuDataAddr->DD_Device_BiaoShi_Value[i].IA;
		RtuDataAddr->Hour_DD_BS_Value[Sort][i].IB=RtuDataAddr->DD_Device_BiaoShi_Value[i].IB;
		RtuDataAddr->Hour_DD_BS_Value[Sort][i].IC=RtuDataAddr->DD_Device_BiaoShi_Value[i].IC;
		RtuDataAddr->Hour_DD_BS_Value[Sort][i].VA=RtuDataAddr->DD_Device_BiaoShi_Value[i].VA;
		RtuDataAddr->Hour_DD_BS_Value[Sort][i].VB=RtuDataAddr->DD_Device_BiaoShi_Value[i].VB;
		RtuDataAddr->Hour_DD_BS_Value[Sort][i].VC=RtuDataAddr->DD_Device_BiaoShi_Value[i].VC;
		RtuDataAddr->Min_15_DD_BS_Value[i].Z_P_All=RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_All;
		RtuDataAddr->Min_15_DD_BS_Value[i].Z_Q_All=RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_Q_All;
		RtuDataAddr->Min_15_DD_BS_Value[i].F_P_All=RtuDataAddr->DD_Device_BiaoShi_Value[i].F_P_All;
		RtuDataAddr->Min_15_DD_BS_Value[i].F_Q_All=RtuDataAddr->DD_Device_BiaoShi_Value[i].F_Q_All;
	}
	for(i=0;i<ZongJia_Max;i++)
	{
		memcpy(&RtuDataAddr->Hour_Zj_Value[Sort][i].Valid,&RtuDataAddr->Real_Zj_Value[i].Valid,sizeof(RtuDataAddr->Real_Zj_Value[i]));
		RtuDataAddr->Hour_Zj_Value[Sort][i].P_All=RtuDataAddr->Real_Zj_Value[i].P_All-RtuDataAddr->Min_15_Zj_Value[i].P_All;
		RtuDataAddr->Hour_Zj_Value[Sort][i].Q_All=RtuDataAddr->Real_Zj_Value[i].Q_All-RtuDataAddr->Min_15_Zj_Value[i].Q_All;
		RtuDataAddr->Min_15_Zj_Value[i].P_All=RtuDataAddr->Real_Zj_Value[i].P_All;
		RtuDataAddr->Min_15_Zj_Value[i].Q_All=RtuDataAddr->Real_Zj_Value[i].Q_All;
	}
	Save_Min15_Data();
}
void Save_Hour_Value()
{
	memcpy(&RtuDataAddr->OldHour_DD_BS_Value[0][0].Valid,RtuDataAddr->Hour_DD_BS_Value,sizeof(RtuDataAddr->Hour_DD_BS_Value));
	memcpy(&RtuDataAddr->OldHour_Zj_Value[0][0].Valid,RtuDataAddr->Hour_Zj_Value,sizeof(RtuDataAddr->Hour_Zj_Value));
}

void Save_Zj_real_Data()
{
	memcpy(&RtuDataAddr->FM_Save_ZjValue.ZjData,RtuDataAddr->Real_Zj_Value,sizeof(RtuDataAddr->Real_Zj_Value));
	RtuDataAddr->FM_Save_ZjValue.Valid=1;
	Fm25cl64_Write(&RtuDataAddr->FM_Save_ZjValue.Valid,sizeof(RtuDataAddr->FM_Save_ZjValue),Zj_Real_Offset);
}
void Read_Zj_real_Data()
{
	Fm25cl64_Read(&RtuDataAddr->FM_Save_ZjValue.Valid,sizeof(RtuDataAddr->FM_Save_ZjValue),Zj_Real_Offset);
	if(RtuDataAddr->FM_Save_ZjValue.Valid!=1)
	{
		memset(&RtuDataAddr->FM_Save_ZjValue.Valid,0,sizeof(RtuDataAddr->FM_Save_ZjValue));
	}
	memcpy(RtuDataAddr->Real_Zj_Value,&RtuDataAddr->FM_Save_ZjValue.ZjData,sizeof(RtuDataAddr->FM_Save_ZjValue.ZjData));
}

void Save_Fk_real_Data()
{
	INT8U i,Num;
	RtuDataAddr->FM_Save_ZDValue.Valid=1;
	for(i=0;i<RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num;i++)
	{
		if(RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].GuiYue_Type==JiaoLiuType)
		{//ϵͳĬ��һ�齻������װ�ã����ն˱���
			if(RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Addr[0]==1)
			{
				Num=RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].CeLiangNo-1;
				if(Num>CeLiangPoint_Max)
				{
					break;
				}
				memcpy(&RtuDataAddr->FM_Save_ZDValue.Day_Zd_Cl_Stat.Valid,&RtuDataAddr->Day_Save_Value.Cl_Stat[Num].Valid,sizeof(RtuDataAddr->FM_Save_ZDValue.Day_Zd_Cl_Stat));
				memcpy(&RtuDataAddr->FM_Save_ZDValue.Day_Zd_Stat.Valid,&RtuDataAddr->Day_Save_Value.ZD_Day_stat.Valid,sizeof(RtuDataAddr->FM_Save_ZDValue.Day_Zd_Stat));
				memcpy(&RtuDataAddr->FM_Save_ZDValue.Yue_Zd_Cl_Stat.Valid,&RtuDataAddr->Yue_Save_Value.Cl_Stat[Num].Valid,sizeof(RtuDataAddr->FM_Save_ZDValue.Yue_Zd_Cl_Stat));
				memcpy(&RtuDataAddr->FM_Save_ZDValue.Yue_Zd_Stat.Valid,&RtuDataAddr->Yue_Save_Value.ZD_Yue_stat.Valid,sizeof(RtuDataAddr->FM_Save_ZDValue.Yue_Zd_Stat));
				RtuDataAddr->FM_Save_ZDValue.Valid=1;
			}
		}
	}
	//Fm25cl64_Write(&RtuDataAddr->FkDdRealData.Valid,sizeof(RtuDataAddr->FkDdRealData),FkDdRealData_Offset);
	SaveFile((INT8U *)"/nand/save/zddiannengliang.sav",&RtuDataAddr->FkDdRealData.Valid,sizeof(RtuDataAddr->FkDdRealData));
	Fm25cl64_Write(&RtuDataAddr->FkMaxXuliang.Valid,sizeof(RtuDataAddr->FkMaxXuliang),FkMaxXuliang_Offset);
	Fm25cl64_Write(&RtuDataAddr->FM_Save_ZDValue.Valid,sizeof(RtuDataAddr->FM_Save_ZDValue),FM_Save_ZDValue_Offset);
	Fm25cl64_Write(&RtuDataAddr->F27_28_29_30_Mem[0].valid,sizeof(RtuDataAddr->F27_28_29_30_Mem),F27_28_29_30_Mem_Offset);
	Fm25cl64_Write(&RtuDataAddr->YF27_28_29_30_Mem[0].valid,sizeof(RtuDataAddr->YF27_28_29_30_Mem),YF27_28_29_30_Mem_Offset);
	Fm25cl64_Write(&RtuDataAddr->Fm_Save_Eve.EC1, sizeof(RtuDataAddr->Fm_Save_Eve), Fm_Save_Eve_Offset);
}
void Read_Fk_real_Data()
{
	INT8U i,Num;
	Fm25cl64_Read(&RtuDataAddr->Fm_Save_Eve.EC1,sizeof(RtuDataAddr->Fm_Save_Eve),Fm_Save_Eve_Offset);
	RtuDataAddr->Fm_Save_Eve.DayLiuLiang=0;
	RtuDataAddr->Fm_Save_Eve.yueLiuLiang=0;
	RtuDataAddr->EC1=RtuDataAddr->EC1old=RtuDataAddr->Fm_Save_Eve.EC1;
	RtuDataAddr->EC2=RtuDataAddr->EC2old=RtuDataAddr->Fm_Save_Eve.EC2;
	//Fm25cl64_Read(&RtuDataAddr->OldFkDdRealData.Valid,sizeof(RtuDataAddr->OldFkDdRealData),FkDdRealData_Offset);
	//if(RtuDataAddr->OldFkDdRealData.Valid!=1){
	//	memset(&RtuDataAddr->OldFkDdRealData.Valid,0,sizeof(RtuDataAddr->OldFkDdRealData));
	//}
	if(ReadFile((INT8U *)"/nand/save/zddiannengliang.sav",&RtuDataAddr->OldFkDdRealData.Valid,sizeof(RtuDataAddr->OldFkDdRealData)))
	{
		memset(&RtuDataAddr->OldFkDdRealData.Valid,0,sizeof(RtuDataAddr->OldFkDdRealData));
	}
//	printf("\n\rRtuDataAddr->OldFkDdRealData.Z_P_All=%d",RtuDataAddr->OldFkDdRealData.Z_P_All);
//	printf("\n\rRtuDataAddr->OldFkDdRealData.F_P_All=%d",RtuDataAddr->OldFkDdRealData.F_P_All);
//	printf("\n\rRtuDataAddr->OldFkDdRealData.Z_Q_All=%d",RtuDataAddr->OldFkDdRealData.Z_Q_All);
//	printf("\n\rRtuDataAddr->OldFkDdRealData.F_Q_All=%d",RtuDataAddr->OldFkDdRealData.F_Q_All);
	Fm25cl64_Read(&RtuDataAddr->FkMaxXuliang.Valid,sizeof(RtuDataAddr->FkMaxXuliang),FkMaxXuliang_Offset);
	if(RtuDataAddr->FkMaxXuliang.Valid!=1)
		memset(&RtuDataAddr->FkMaxXuliang.Valid,0,sizeof(RtuDataAddr->FkMaxXuliang));
	Fm25cl64_Read(&RtuDataAddr->Gonglv_XiaFu_Value[0].Valid,sizeof(RtuDataAddr->Gonglv_XiaFu_Value),GlvXFK_Offset);
	Fm25cl64_Read(&RtuDataAddr->FM_Save_ZDValue.Valid,sizeof(RtuDataAddr->FM_Save_ZDValue),FM_Save_ZDValue_Offset);
	Fm25cl64_Read(&RtuDataAddr->F27_28_29_30_Mem[0].valid,sizeof(RtuDataAddr->F27_28_29_30_Mem),F27_28_29_30_Mem_Offset);
	Fm25cl64_Read(&RtuDataAddr->YF27_28_29_30_Mem[0].valid,sizeof(RtuDataAddr->YF27_28_29_30_Mem),YF27_28_29_30_Mem_Offset);
	if(RtuDataAddr->FM_Save_ZDValue.Valid!=1)
		memset(&RtuDataAddr->FM_Save_ZDValue.Valid,0,sizeof(RtuDataAddr->FM_Save_ZDValue));

	for(i=0;i<RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num;i++)
	{
		if(RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].GuiYue_Type==JiaoLiuType)
		{//ϵͳĬ��һ�齻������װ�ã����ն˱���
			if(RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Addr[0]==1)
			{
				Num=RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].CeLiangNo-1;
				if(Num>CeLiangPoint_Max)
				{
					break;
				}
				memcpy(&RtuDataAddr->Day_Save_Value.Cl_Stat[Num].Valid,&RtuDataAddr->FM_Save_ZDValue.Day_Zd_Cl_Stat.Valid,sizeof(RtuDataAddr->FM_Save_ZDValue.Day_Zd_Cl_Stat));
				memcpy(&RtuDataAddr->Day_Save_Value.ZD_Day_stat.Valid,&RtuDataAddr->FM_Save_ZDValue.Day_Zd_Stat.Valid,sizeof(RtuDataAddr->FM_Save_ZDValue.Day_Zd_Stat));
				memcpy(&RtuDataAddr->Yue_Save_Value.Cl_Stat[Num].Valid,&RtuDataAddr->FM_Save_ZDValue.Yue_Zd_Cl_Stat.Valid,sizeof(RtuDataAddr->FM_Save_ZDValue.Yue_Zd_Cl_Stat));
				memcpy(&RtuDataAddr->Yue_Save_Value.ZD_Yue_stat.Valid,&RtuDataAddr->FM_Save_ZDValue.Yue_Zd_Stat.Valid,sizeof(RtuDataAddr->FM_Save_ZDValue.Yue_Zd_Stat));
			}
		}
	}
}
void SaveGlvXFValue()
{
	Fm25cl64_Write(&RtuDataAddr->Gonglv_XiaFu_Value[0].Valid,sizeof(RtuDataAddr->Gonglv_XiaFu_Value),GlvXFK_Offset);
}
void ResetSet()
{
	INT8U i;
	RtuDataAddr->FkComm_Value.F1_Set_Para.Valid=1;
	RtuDataAddr->FkComm_Value.F1_Set_Para.RTS_Time=10;
	RtuDataAddr->FkComm_Value.F1_Set_Para.QiDong_FaSong_Yanshi=1;
	RtuDataAddr->FkComm_Value.F1_Set_Para.ChongDong_XiangYing[0]=0;
	RtuDataAddr->FkComm_Value.F1_Set_Para.ChongDong_XiangYing[1]=0;
	RtuDataAddr->FkComm_Value.F1_Set_Para.CON_Stat=0x03;
	RtuDataAddr->FkComm_Value.F1_Set_Para.Heart_Beat=5;
	//f2_set����ֵ
	CleardeadCount();
	memset(&RtuDataAddr->FkComm_Value.F6_Set_Para.Valid,0,sizeof(RtuDataAddr->FkComm_Value.F6_Set_Para));
	memset(&RtuDataAddr->FkComm_Value.F3_Set_Para.Valid,0,sizeof(RtuDataAddr->FkComm_Value.F3_Set_Para));
	//��ʼ��apn
	RtuDataAddr->FkComm_Value.F3_Set_Para.APN[0]='C';
	RtuDataAddr->FkComm_Value.F3_Set_Para.APN[1]='M';
	RtuDataAddr->FkComm_Value.F3_Set_Para.APN[2]='N';
	RtuDataAddr->FkComm_Value.F3_Set_Para.APN[3]='E';
	RtuDataAddr->FkComm_Value.F3_Set_Para.APN[4]='T';
	//��ʼ������
	memset(&RtuDataAddr->FkComm_Value.F2_Set_Para.Valid,0,sizeof(RtuDataAddr->FkComm_Value.F2_Set_Para));
	memset(&RtuDataAddr->FkComm_Value.F4_Set_Para.Valid,0,sizeof(RtuDataAddr->FkComm_Value.F4_Set_Para));
	memset(&RtuDataAddr->FkComm_Value.F5_Set_Para.Valid,0,sizeof(RtuDataAddr->FkComm_Value.F5_Set_Para));
	memset(&RtuDataAddr->FkComm_Value.F16_Set_Para.Valid,0,sizeof(RtuDataAddr->FkComm_Value.F16_Set_Para));
	memset(&RtuDataAddr->FkComm_Value.F63_Set_Para.Valid,0,sizeof(RtuDataAddr->FkComm_Value.F63_Set_Para));
	memset(&RtuDataAddr->FkComm_Value.F11_Set_Para.Valid,0,sizeof(RtuDataAddr->FkComm_Value.F11_Set_Para));
	RtuDataAddr->FkComm_Value.F8_Set_Para.Valid = 1;
	RtuDataAddr->FkComm_Value.F8_Set_Para.GPRS_MODE = 1;
	RtuDataAddr->FkComm_Value.F8_Set_Para.BeiDongJihuo = 0;
	RtuDataAddr->FkComm_Value.F8_Set_Para.WUTongXinDuan = 1;
	RtuDataAddr->FkComm_Value.F8_Set_Para.ZaiXian_ChongBo[0] = 30;
	RtuDataAddr->FkComm_Value.F8_Set_Para.ZaiXian_ChongBo[1] = 0;
	RtuDataAddr->FkComm_Value.F8_Set_Para.ShiDuanBiaoZhi[0]=0;
	RtuDataAddr->FkComm_Value.F8_Set_Para.ShiDuanBiaoZhi[1]=0;
	RtuDataAddr->FkComm_Value.F8_Set_Para.ShiDuanBiaoZhi[2]=0;
	///////////////////////////////////////////////////////////////

	memset(&RtuDataAddr->FkInput_Value.F7_Set_Para.Valid,0,sizeof(RtuDataAddr->FkInput_Value.F7_Set_Para));
	memset(&RtuDataAddr->FkInput_Value.F10_Set_Para.Valid,0,sizeof(RtuDataAddr->FkInput_Value.F10_Set_Para));
	//��ʼ��һ����������
	RtuDataAddr->FkInput_Value.F10_Set_Para.Valid=1;
	RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num=1;
	RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[0].Addr[0]=0x01;
	RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[0].GuiYue_Type=JiaoLiuType;
	RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[0].CeLiangNo=1;
	RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[0].No=1;
	RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[0].BaudAndPort=0x41;
	//��ʼ������
	memcpy(&RtuDataAddr->Meter_Para.Valid,&RtuDataAddr->FkInput_Value.F10_Set_Para.Valid,sizeof(RtuDataAddr->FkInput_Value));

	RtuDataAddr->ZongJia_Value.F14_Set_Para.Valid=0;
	memset(&RtuDataAddr->ZongJia_Value.F14_Set_Para.Valid,0,sizeof(RtuDataAddr->ZongJia_Value.F14_Set_Para));
	for(i=0;i<ZongJia_Max;i++)
	memset(&RtuDataAddr->ZongJia_Value.F33_Set_Para[i].Valid,0,sizeof(RtuDataAddr->ZongJia_Value.F33_Set_Para[i]));
	memset(&RtuDataAddr->FkInput_Value.New_F33_Set_Para.Valid,0,sizeof(RtuDataAddr->FkInput_Value.New_F33_Set_Para));
	CleardeadCount();
	for(i=0;i<CeLiangPoint_Max;i++)
	{
		memset(&RtuDataAddr->Cl_MenXian_Value[i].F25_Set_Para.Valid,0,sizeof(RtuDataAddr->Cl_MenXian_Value[i].F25_Set_Para));
		memset(&RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.Valid,0,sizeof(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para));
		memset(&RtuDataAddr->Cl_MenXian_Value[i].F27_Set_Para.Valid,0,sizeof(RtuDataAddr->Cl_MenXian_Value[i].F27_Set_Para));
		memset(&RtuDataAddr->Cl_MenXian_Value[i].F28_Set_Para.Valid,0,sizeof(RtuDataAddr->Cl_MenXian_Value[i].F28_Set_Para));
	}
	memset(&RtuDataAddr->Fk_Control_Set_Value.F17_Set_Para.Valid,0,sizeof(RtuDataAddr->Fk_Control_Set_Value.F17_Set_Para));
	memset(&RtuDataAddr->Fk_Control_Set_Value.F18_Set_Para.Valid,0,sizeof(RtuDataAddr->Fk_Control_Set_Value.F18_Set_Para));
	memset(&RtuDataAddr->Fk_Control_Set_Value.F19_Set_Para.Valid,0,sizeof(RtuDataAddr->Fk_Control_Set_Value.F19_Set_Para));
	memset(&RtuDataAddr->Fk_Control_Set_Value.F20_Set_Para.Valid,0,sizeof(RtuDataAddr->Fk_Control_Set_Value.F20_Set_Para));
	memset(&RtuDataAddr->Fk_Control_Set_Value.F23_Set_Para.Valid,0,sizeof(RtuDataAddr->Fk_Control_Set_Value.F23_Set_Para));
	memset(&RtuDataAddr->Fk_Control_Set_Value.F24_Set_Para.Valid,0,sizeof(RtuDataAddr->Fk_Control_Set_Value.F24_Set_Para));
	CleardeadCount();
	for(i=0;i<Control_Lunci_Max;i++)
	{
		RtuDataAddr->Fk_Control_Set_Value.F49_Set_Para[i].Valid=1;
		RtuDataAddr->Fk_Control_Set_Value.F49_Set_Para[i].GK_Alarm_Time=1;
	}
		//memset(&RtuDataAddr->Fk_Control_Set_Value.F49_Set_Para[i].Valid,0,sizeof(RtuDataAddr->Fk_Control_Set_Value.F49_Set_Para[i]));

	memset(&RtuDataAddr->Fk_Control_Set_Value.F57_Set_Para.Valid,0,sizeof(RtuDataAddr->Fk_Control_Set_Value.F57_Set_Para));
	memset(&RtuDataAddr->Fk_Control_Set_Value.F58_Set_Para.Valid,0,sizeof(RtuDataAddr->Fk_Control_Set_Value.F58_Set_Para));
	memset(&RtuDataAddr->Event_Value.F9_Set_Para.Valid,0,sizeof(RtuDataAddr->Event_Value.F9_Set_Para));

	memset(&RtuDataAddr->Event_Value.F15_Set_Para.Valid,0,sizeof(RtuDataAddr->Event_Value.F15_Set_Para));
	memset(&RtuDataAddr->Event_Value.F59_Set_Para.Valid,0,sizeof(RtuDataAddr->Event_Value.F59_Set_Para));
	memset(&RtuDataAddr->FkComm_Value.F11_Set_Para.Valid,0,sizeof(F11_Set_Stru));
	memset(&RtuDataAddr->FkInput_Value.F12_Set_Para.Valid,0,sizeof(RtuDataAddr->FkInput_Value.F12_Set_Para));
	CleardeadCount();
	for(i=0;i<ZongJia_Max;i++)
	{
		memset(&RtuDataAddr->Zj_Control_Value[i].F41_Set_Para.Valid,0,sizeof(RtuDataAddr->Zj_Control_Value[i].F41_Set_Para));
		memset(&RtuDataAddr->Zj_Control_Value[i].F42_Set_Para.Valid,0,sizeof(RtuDataAddr->Zj_Control_Value[i].F42_Set_Para));
		memset(&RtuDataAddr->Zj_Control_Value[i].F43_Set_Para.Valid,0,sizeof(RtuDataAddr->Zj_Control_Value[i].F43_Set_Para));
		memset(&RtuDataAddr->Zj_Control_Value[i].F44_Set_Para.Valid,0,sizeof(RtuDataAddr->Zj_Control_Value[i].F44_Set_Para));
		//memset(&RtuDataAddr->Zj_Control_Value[i].F45_Set_Para.Valid,0,sizeof(RtuDataAddr->Zj_Control_Value[i].F45_Set_Para));
		RtuDataAddr->Zj_Control_Value[i].F45_Set_Para.Valid=1;
		RtuDataAddr->Zj_Control_Value[i].F45_Set_Para.GongKong_Lunci_Biaozhi=15;
		memset(&RtuDataAddr->Zj_Control_Value[i].F46_Set_Para.Valid,0,sizeof(RtuDataAddr->Zj_Control_Value[i].F46_Set_Para));
		memset(&RtuDataAddr->Zj_Control_Value[i].F47_Set_Para.Valid,0,sizeof(RtuDataAddr->Zj_Control_Value[i].F47_Set_Para));
		//memset(&RtuDataAddr->Zj_Control_Value[i].F48_Set_Para.Valid,0,sizeof(RtuDataAddr->Zj_Control_Value[i].F48_Set_Para));
		RtuDataAddr->Zj_Control_Value[i].F48_Set_Para.Valid=1;
		RtuDataAddr->Zj_Control_Value[i].F48_Set_Para.DianKong_Lunci_Biaozhi=15;
		memset(&RtuDataAddr->Zj_Control_Value[i].Old_DianLiang,0,4);
		memset(&RtuDataAddr->Zj_Control_Value[i].New_DianLiang,0,4);
	}
	CleardeadCount();
	for(i=0;i<Task_Max;i++)
	{
		memset(&RtuDataAddr->Task_Value[i].F65_Set_Para.Valid,0,sizeof(RtuDataAddr->Task_Value[i].F65_Set_Para));
		memset(&RtuDataAddr->Task_Value[i].F66_Set_Para.Valid,0,sizeof(RtuDataAddr->Task_Value[i].F66_Set_Para));
		memset(&RtuDataAddr->Task_Value[i].F67_Set_Para.Valid,0,sizeof(RtuDataAddr->Task_Value[i].F67_Set_Para));
		memset(&RtuDataAddr->Task_Value[i].F68_Set_Para.Valid,0,sizeof(RtuDataAddr->Task_Value[i].F68_Set_Para));
	}
	CleardeadCount();
	memset(&RtuDataAddr->FuKong_Control_Value.Asdu130Addr[0],0,sizeof(RtuDataAddr->FuKong_Control_Value));
	Save_Fk_Control_para_Set();
	SaveFKSet();
}
void ResetSet2()
{
	INT8U i;
	//f2_set����ֵ
	memset(&RtuDataAddr->FkComm_Value.F6_Set_Para.Valid,0,sizeof(RtuDataAddr->FkComm_Value.F6_Set_Para));
	memset(&RtuDataAddr->FkComm_Value.F16_Set_Para.Valid,0,sizeof(RtuDataAddr->FkComm_Value.F16_Set_Para));
	memset(&RtuDataAddr->FkComm_Value.F63_Set_Para.Valid,0,sizeof(RtuDataAddr->FkComm_Value.F63_Set_Para));
	memset(&RtuDataAddr->FkInput_Value.F10_Set_Para.Valid,0,sizeof(RtuDataAddr->FkInput_Value.F10_Set_Para));
	memcpy(&RtuDataAddr->Meter_Para.Valid,&RtuDataAddr->FkInput_Value.F10_Set_Para.Valid,sizeof(RtuDataAddr->FkInput_Value));
	CleardeadCount();
	memset(&RtuDataAddr->FkComm_Value.F11_Set_Para.Valid,0,sizeof(F11_Set_Stru));
	RtuDataAddr->ZongJia_Value.F14_Set_Para.Valid=0;
	memset(&RtuDataAddr->ZongJia_Value.F14_Set_Para.Valid,0,sizeof(RtuDataAddr->ZongJia_Value.F14_Set_Para));
	for(i=0;i<ZongJia_Max;i++)
	memset(&RtuDataAddr->ZongJia_Value.F33_Set_Para[i].Valid,0,sizeof(RtuDataAddr->ZongJia_Value.F33_Set_Para[i]));
	memset(&RtuDataAddr->FkInput_Value.New_F33_Set_Para.Valid,0,sizeof(RtuDataAddr->FkInput_Value.New_F33_Set_Para));
	memset(&RtuDataAddr->FkInput_Value.F12_Set_Para.Valid,0,sizeof(RtuDataAddr->FkInput_Value.F12_Set_Para));
	CleardeadCount();
	for(i=0;i<CeLiangPoint_Max;i++)
	{
		memset(&RtuDataAddr->Cl_MenXian_Value[i].F25_Set_Para.Valid,0,sizeof(RtuDataAddr->Cl_MenXian_Value[i].F25_Set_Para));
		memset(&RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.Valid,0,sizeof(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para));
		memset(&RtuDataAddr->Cl_MenXian_Value[i].F27_Set_Para.Valid,0,sizeof(RtuDataAddr->Cl_MenXian_Value[i].F27_Set_Para));
		memset(&RtuDataAddr->Cl_MenXian_Value[i].F28_Set_Para.Valid,0,sizeof(RtuDataAddr->Cl_MenXian_Value[i].F28_Set_Para));
	}
	memset(&RtuDataAddr->Fk_Control_Set_Value.F17_Set_Para.Valid,0,sizeof(RtuDataAddr->Fk_Control_Set_Value.F17_Set_Para));
	memset(&RtuDataAddr->Fk_Control_Set_Value.F18_Set_Para.Valid,0,sizeof(RtuDataAddr->Fk_Control_Set_Value.F18_Set_Para));
	memset(&RtuDataAddr->Fk_Control_Set_Value.F19_Set_Para.Valid,0,sizeof(RtuDataAddr->Fk_Control_Set_Value.F19_Set_Para));
	memset(&RtuDataAddr->Fk_Control_Set_Value.F20_Set_Para.Valid,0,sizeof(RtuDataAddr->Fk_Control_Set_Value.F20_Set_Para));
	memset(&RtuDataAddr->Fk_Control_Set_Value.F23_Set_Para.Valid,0,sizeof(RtuDataAddr->Fk_Control_Set_Value.F23_Set_Para));
	memset(&RtuDataAddr->Fk_Control_Set_Value.F24_Set_Para.Valid,0,sizeof(RtuDataAddr->Fk_Control_Set_Value.F24_Set_Para));
	CleardeadCount();
	for(i=0;i<Control_Lunci_Max;i++)
	{
		RtuDataAddr->Fk_Control_Set_Value.F49_Set_Para[i].Valid=1;
		RtuDataAddr->Fk_Control_Set_Value.F49_Set_Para[i].GK_Alarm_Time=1;
	}
		//memset(&RtuDataAddr->Fk_Control_Set_Value.F49_Set_Para[i].Valid,0,sizeof(RtuDataAddr->Fk_Control_Set_Value.F49_Set_Para[i]));

	memset(&RtuDataAddr->Fk_Control_Set_Value.F57_Set_Para.Valid,0,sizeof(RtuDataAddr->Fk_Control_Set_Value.F57_Set_Para));
	memset(&RtuDataAddr->Fk_Control_Set_Value.F58_Set_Para.Valid,0,sizeof(RtuDataAddr->Fk_Control_Set_Value.F58_Set_Para));
	memset(&RtuDataAddr->Event_Value.F9_Set_Para.Valid,0,sizeof(RtuDataAddr->Event_Value.F9_Set_Para));
	memset(&RtuDataAddr->Event_Value.F15_Set_Para.Valid,0,sizeof(RtuDataAddr->Event_Value.F15_Set_Para));
	memset(&RtuDataAddr->Event_Value.F59_Set_Para.Valid,0,sizeof(RtuDataAddr->Event_Value.F59_Set_Para));
	CleardeadCount();
	for(i=0;i<ZongJia_Max;i++)
	{
		CleardeadCount();
		memset(&RtuDataAddr->Zj_Control_Value[i].F41_Set_Para.Valid,0,sizeof(RtuDataAddr->Zj_Control_Value[i].F41_Set_Para));
		memset(&RtuDataAddr->Zj_Control_Value[i].F42_Set_Para.Valid,0,sizeof(RtuDataAddr->Zj_Control_Value[i].F42_Set_Para));
		memset(&RtuDataAddr->Zj_Control_Value[i].F43_Set_Para.Valid,0,sizeof(RtuDataAddr->Zj_Control_Value[i].F43_Set_Para));
		memset(&RtuDataAddr->Zj_Control_Value[i].F44_Set_Para.Valid,0,sizeof(RtuDataAddr->Zj_Control_Value[i].F44_Set_Para));
		memset(&RtuDataAddr->Zj_Control_Value[i].F45_Set_Para.Valid,0,sizeof(RtuDataAddr->Zj_Control_Value[i].F45_Set_Para));
		memset(&RtuDataAddr->Zj_Control_Value[i].F46_Set_Para.Valid,0,sizeof(RtuDataAddr->Zj_Control_Value[i].F46_Set_Para));
		memset(&RtuDataAddr->Zj_Control_Value[i].F47_Set_Para.Valid,0,sizeof(RtuDataAddr->Zj_Control_Value[i].F47_Set_Para));
		//memset(&RtuDataAddr->Zj_Control_Value[i].F48_Set_Para.Valid,0,sizeof(RtuDataAddr->Zj_Control_Value[i].F48_Set_Para));
		RtuDataAddr->Zj_Control_Value[i].F48_Set_Para.Valid=0;
		RtuDataAddr->Zj_Control_Value[i].F48_Set_Para.DianKong_Lunci_Biaozhi=15;
		memset(&RtuDataAddr->Zj_Control_Value[i].Old_DianLiang,0,4);
		memset(&RtuDataAddr->Zj_Control_Value[i].New_DianLiang,0,4);
	}
	CleardeadCount();
	for(i=0;i<Task_Max;i++)
	{
		memset(&RtuDataAddr->Task_Value[i].F65_Set_Para.Valid,0,sizeof(RtuDataAddr->Task_Value[i].F65_Set_Para));
		memset(&RtuDataAddr->Task_Value[i].F66_Set_Para.Valid,0,sizeof(RtuDataAddr->Task_Value[i].F66_Set_Para));
		memset(&RtuDataAddr->Task_Value[i].F67_Set_Para.Valid,0,sizeof(RtuDataAddr->Task_Value[i].F67_Set_Para));
		memset(&RtuDataAddr->Task_Value[i].F68_Set_Para.Valid,0,sizeof(RtuDataAddr->Task_Value[i].F68_Set_Para));
	}
	CleardeadCount();
	memset(&RtuDataAddr->FuKong_Control_Value.Asdu130Addr[0],0,sizeof(RtuDataAddr->FuKong_Control_Value));
	Save_Fk_Control_para_Set();
	SaveFKSet();
}
void ResetData()
{
	INT8U i;
	TS ts;
	unsigned char name[128];
	memset(name,0,128);
	TSGet(&ts);
//////���ر�ʵʱ�����
	memset(&RtuDataAddr->OldFkDdRealData.Valid,0,sizeof(RtuDataAddr->OldFkDdRealData));
	memset(&RtuDataAddr->FkDdRealData.Valid,0,sizeof(RtuDataAddr->FkDdRealData));
	memset(&RtuDataAddr->FkMaxXuliang.Valid,0,sizeof(RtuDataAddr->FkMaxXuliang));
	memset(&RtuDataAddr->FkXuLiangCalc.Offset,0,sizeof(RtuDataAddr->FkXuLiangCalc));
	memset(&RtuDataAddr->FkOldXuLiang.Month,0,sizeof(RtuDataAddr->FkOldXuLiang));
	memset(&RtuDataAddr->FkMaxXXXuliang.Valid,0,sizeof(RtuDataAddr->FkMaxXXXuliang));
	memset(&RtuDataAddr->Fm_Save_Eve.EC1,0,sizeof(RtuDataAddr->Fm_Save_Eve));
	CleardeadCount();
	memset(RtuDataAddr->FkZhongWen,0,sizeof(RtuDataAddr->FkZhongWen));/////////xinjia
	memset(&RtuDataAddr->ERCBiaoZhi,0,8);
	memset(&RtuDataAddr->M_Event_Save,0,256*sizeof(event_record_Save));
	memset(&RtuDataAddr->S_Event_Save,0,256*sizeof(event_record_Save));
	CleardeadCount();
	memset(RtuDataAddr->F27_28_29_30_Mem,0,sizeof(RtuDataAddr->F27_28_29_30_Mem));
	memset(RtuDataAddr->YF27_28_29_30_Mem,0,sizeof(RtuDataAddr->YF27_28_29_30_Mem));
	for(i=0;i<CeLiangPoint_Max;i++)
	{
		CleardeadCount();
		memset(&RtuDataAddr->F27_28_29_30_Mem[i].USSU_Count,0,sizeof(F27_28_29_30_level_stru)-1);
		RtuDataAddr->F27_28_29_30_Mem[i].DUUMIN=0xffff;
		RtuDataAddr->F27_28_29_30_Mem[i].DUVMIN=0xffff;
		RtuDataAddr->F27_28_29_30_Mem[i].DUWMIN=0xffff;

		memset(&RtuDataAddr->YF27_28_29_30_Mem[i].USSU_Count,0,sizeof(F27_28_29_30_level_stru)-1);

		RtuDataAddr->YF27_28_29_30_Mem[i].DUUMIN=0xffff;
		RtuDataAddr->YF27_28_29_30_Mem[i].DUVMIN=0xffff;
		RtuDataAddr->YF27_28_29_30_Mem[i].DUWMIN=0xffff;

	}
	CleardeadCount();
	memset(RtuDataAddr->DD_Device_BiaoShi_Value,0,sizeof(RtuDataAddr->DD_Device_BiaoShi_Value));
	memset(RtuDataAddr->Min_15_DD_BS_Value,0,sizeof(RtuDataAddr->Min_15_DD_BS_Value));
	memset(RtuDataAddr->Day_DD_BS_Value,0,sizeof(RtuDataAddr->Day_DD_BS_Value));
	memset(RtuDataAddr->Yue_DD_BS_Value,0,sizeof(RtuDataAddr->Yue_DD_BS_Value));
	memset(RtuDataAddr->OldHour_DD_BS_Value,0,sizeof(RtuDataAddr->OldHour_DD_BS_Value));
	memset(RtuDataAddr->Hour_DD_BS_Value,0,sizeof(RtuDataAddr->Hour_DD_BS_Value));
	memset(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju,0,sizeof(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju));
	memset(RtuDataAddr->Yue_DD_Xl_Value,0,sizeof(RtuDataAddr->Yue_DD_Xl_Value));
	/* ����һ�����¼ӵ����������ݵ�          */
	memset(RtuDataAddr->QX_DD_Device_BiaoShi_Value,0,sizeof(RtuDataAddr->QX_DD_Device_BiaoShi_Value));
	memset(&RtuDataAddr->QX_Real_Zj_Value,0,sizeof(RtuDataAddr->QX_Real_Zj_Value));
	memset(RtuDataAddr->DD_BianLiang_Shuju,0,sizeof(RtuDataAddr->DD_BianLiang_Shuju));
	memset(RtuDataAddr->CL_XL_JX,0,sizeof(RtuDataAddr->CL_XL_JX));
	memset(RtuDataAddr->Now_CL_XL_JX,0,sizeof(RtuDataAddr->Now_CL_XL_JX));
	memset(RtuDataAddr->CL_ERR,0,sizeof(RtuDataAddr->CL_ERR));
	//�ܼ���ʵʱ�������
	CleardeadCount();
	memset(RtuDataAddr->Min_15_Zj_Value,0,sizeof(RtuDataAddr->Min_15_Zj_Value));
	memset(RtuDataAddr->Real_Zj_Value,0,sizeof(RtuDataAddr->Real_Zj_Value));
	memset(RtuDataAddr->Day_Zj_Value,0,sizeof(RtuDataAddr->Day_Zj_Value));
	memset(RtuDataAddr->Yue_Zj_Value,0,sizeof(RtuDataAddr->Yue_Zj_Value));
	memset(RtuDataAddr->OldHour_Zj_Value,0,sizeof(RtuDataAddr->OldHour_Zj_Value));
	memset(RtuDataAddr->Hour_Zj_Value,0,sizeof(RtuDataAddr->Hour_Zj_Value));
	memset(&RtuDataAddr->Yue_Save_Value,0,sizeof(RtuDataAddr->Yue_Save_Value));
	memset(&RtuDataAddr->Day_Save_Value,0,sizeof(RtuDataAddr->Day_Save_Value));
	memset(RtuDataAddr->Zj_HC_Buff,0,sizeof(RtuDataAddr->Zj_HC_Buff));
	RtuDataAddr->Fm_Save_Eve.ZWNo=0;
	RtuDataAddr->Fm_Save_Eve.EC1=0;
	RtuDataAddr->Fm_Save_Eve.EC2=0;
	memset(RtuDataAddr->Fm_Save_Eve.SdTime,0,5);
	memset(RtuDataAddr->Fm_Save_Eve.TdTime,0,5);
	RtuDataAddr->Fm_Save_Eve.DayLiuLiang=0;
	RtuDataAddr->Fm_Save_Eve.yueLiuLiang=0;
	memset(RtuDataAddr->FM_Save_ZDValue.MaiCong,0,sizeof(RtuDataAddr->FM_Save_ZDValue.MaiCong));
	memset(RtuDataAddr->MaiChongVar,0,sizeof(RtuDataAddr->MaiChongVar));
	CleardeadCount();
	SaveGlvXFValue();
	SaveDayCLInit();
	SaveYueCLInit();
	SaveDayZJInit();
	SaveYueZJInit();
	Save_Fk_real_Data();
	Save_Min15_Data();
	sprintf((char *)name,"/nand/save/qxddbs%02d%02d.dat",ts.Month,ts.Day);
	SaveFile(name,&RtuDataAddr->QX_DD_Device_BiaoShi_Value[0][0].Valid,sizeof(RtuDataAddr->QX_DD_Device_BiaoShi_Value));
	memset(name,0,128);
	sprintf((char *)name,"/nand/save/qxzj%02d%02d.dat",ts.Month,ts.Day);
	SaveFile(name,&RtuDataAddr->QX_Real_Zj_Value[0][0].Valid,sizeof(RtuDataAddr->QX_Real_Zj_Value));
}
void	Calc_Day_Bs_zj()
{
	INT8U Num,i;

	for(Num=0;Num<CeLiangPoint_Max;Num++)
	{
		RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[Num].Z_P_All_S=RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[Num].Z_P_F_S[i]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_F[i];
		}
		RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[Num].F_P_All_S=RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[Num].F_P_F_S[i]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_F[i];
		}
		RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[Num].Z_Q_All_S=RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[Num].Z_Q_F_S[i]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_F[i];
		}
		RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[Num].F_Q_All_S=RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[Num].F_Q_F_S[i]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_F[i];
		}
		RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[Num].Z_P_All_D=RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_All-RtuDataAddr->Day_DD_BS_Value[Num].Z_P_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[Num].Z_P_F_D[i]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_F[i]-RtuDataAddr->Day_DD_BS_Value[Num].Z_P_F[i];
		}
		RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[Num].F_P_All_D=RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_All-RtuDataAddr->Day_DD_BS_Value[Num].F_P_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[Num].F_P_F_D[i]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_F[i]-RtuDataAddr->Day_DD_BS_Value[Num].F_P_F[i];
		}
		RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[Num].Z_Q_All_D=RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_All-RtuDataAddr->Day_DD_BS_Value[Num].Z_Q_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[Num].Z_Q_F_D[i]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_F[i]-RtuDataAddr->Day_DD_BS_Value[Num].Z_Q_F[i];
		}
		RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[Num].F_Q_All_D=RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_All-RtuDataAddr->Day_DD_BS_Value[Num].F_Q_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[Num].F_Q_F_D[i]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_F[i]-RtuDataAddr->Day_DD_BS_Value[Num].F_Q_F[i];
		}
		//-----------------------------------------------���������
		memcpy(&RtuDataAddr->Day_Save_Value.Cl_His_XuLiang[Num].Chao_Time,&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Chao_Time,5);
		RtuDataAddr->Day_Save_Value.Cl_His_XuLiang[Num].Z_P_X_All=RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_P_X_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Day_Save_Value.Cl_His_XuLiang[Num].Z_P_X_F[i]=RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_P_X_F[i];
		}
		memcpy(&RtuDataAddr->Day_Save_Value.Cl_His_XuLiang[Num].Time_Z_P_X_All,RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_P_X_All,4);
		for(i=0;i<FeiLvNum;i++)
		{
			memcpy(RtuDataAddr->Day_Save_Value.Cl_His_XuLiang[Num].Time_Z_P_X_F[i],RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_P_X_F[i],4);
		}
		RtuDataAddr->Day_Save_Value.Cl_His_XuLiang[Num].Z_Q_X_All=RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_Q_X_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Day_Save_Value.Cl_His_XuLiang[Num].Z_Q_X_F[i]=RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_Q_X_F[i];
		}
		memcpy(RtuDataAddr->Day_Save_Value.Cl_His_XuLiang[Num].Time_Z_Q_X_All,RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_Q_X_All,4);
		for(i=0;i<FeiLvNum;i++)
		{
			memcpy(RtuDataAddr->Day_Save_Value.Cl_His_XuLiang[Num].Time_Z_Q_X_F[i],RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_Q_X_F[i],4);
		}
		RtuDataAddr->Day_Save_Value.Cl_His_XuLiang[Num].F_P_X_All=RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_P_X_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Day_Save_Value.Cl_His_XuLiang[Num].F_P_X_F[i]=RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_P_X_F[i];
		}
		memcpy(RtuDataAddr->Day_Save_Value.Cl_His_XuLiang[Num].Time_F_P_X_All,RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_P_X_All,4);
		for(i=0;i<FeiLvNum;i++)
		{
			memcpy(RtuDataAddr->Day_Save_Value.Cl_His_XuLiang[Num].Time_F_P_X_F[i],RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_P_X_F[i],4);
		}
		RtuDataAddr->Day_Save_Value.Cl_His_XuLiang[Num].F_Q_X_All=RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_Q_X_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Day_Save_Value.Cl_His_XuLiang[Num].F_Q_X_F[i]=RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_Q_X_F[i];
		}
		memcpy(RtuDataAddr->Day_Save_Value.Cl_His_XuLiang[Num].Time_F_Q_X_All,RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_Q_X_All,4);
		for(i=0;i<FeiLvNum;i++)
		{
			memcpy(RtuDataAddr->Day_Save_Value.Cl_His_XuLiang[Num].Time_F_Q_X_F[i],RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_Q_X_F[i],4);
		}
		//-----------------------------------------
	}
	for(Num=0;Num<ZongJia_Max;Num++)
	{
		RtuDataAddr->Day_Save_Value.Zj_His_DianNeng[Num].Z_P_All_S=RtuDataAddr->Real_Zj_Value[Num].P_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Day_Save_Value.Zj_His_DianNeng[Num].Z_P_F_S[i]=RtuDataAddr->Real_Zj_Value[Num].P_F[i];
		}
		RtuDataAddr->Day_Save_Value.Zj_His_DianNeng[Num].Z_Q_All_S=RtuDataAddr->Real_Zj_Value[Num].Q_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Day_Save_Value.Zj_His_DianNeng[Num].Z_Q_F_S[i]=RtuDataAddr->Real_Zj_Value[Num].Q_F[i];
		}
		RtuDataAddr->Day_Save_Value.Zj_His_DianNeng[Num].Z_P_All_D=RtuDataAddr->Real_Zj_Value[Num].P_All-RtuDataAddr->Day_Zj_Value[Num].P_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Day_Save_Value.Zj_His_DianNeng[Num].Z_P_F_D[i]=RtuDataAddr->Real_Zj_Value[Num].P_F[i]-RtuDataAddr->Day_Zj_Value[Num].P_F[i];
		}
		RtuDataAddr->Day_Save_Value.Zj_His_DianNeng[Num].Z_Q_All_D=RtuDataAddr->Real_Zj_Value[Num].Q_All-RtuDataAddr->Day_Zj_Value[Num].Q_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Day_Save_Value.Zj_His_DianNeng[Num].Z_Q_F_D[i]=RtuDataAddr->Real_Zj_Value[Num].Q_F[i]-RtuDataAddr->Day_Zj_Value[Num].Q_F[i];
		}
	}
}
void	Calc_Yue_Bs_zj()
{
	INT8U Num,i;
	for(Num=0;Num<CeLiangPoint_Max;Num++)
	{
		RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[Num].Z_P_All_S=RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[Num].Z_P_F_S[i]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_F[i];
		}
		RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[Num].F_P_All_S=RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[Num].F_P_F_S[i]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_F[i];
		}
		RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[Num].Z_Q_All_S=RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[Num].Z_Q_F_S[i]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_F[i];
		}
		RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[Num].F_Q_All_S=RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[Num].F_Q_F_S[i]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_F[i];
		}
		RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[Num].Z_P_All_D=RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_All-RtuDataAddr->Yue_DD_BS_Value[Num].Z_P_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[Num].Z_P_F_D[i]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_F[i]-RtuDataAddr->Yue_DD_BS_Value[Num].Z_P_F[i];
		}
		RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[Num].F_P_All_D=RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_All-RtuDataAddr->Yue_DD_BS_Value[Num].F_P_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[Num].F_P_F_D[i]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_F[i]-RtuDataAddr->Yue_DD_BS_Value[Num].F_P_F[i];
		}
		RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[Num].Z_Q_All_D=RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_All-RtuDataAddr->Yue_DD_BS_Value[Num].Z_Q_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[Num].Z_Q_F_D[i]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_F[i]-RtuDataAddr->Yue_DD_BS_Value[Num].Z_Q_F[i];
		}
		RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[Num].F_Q_All_D=RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_All-RtuDataAddr->Yue_DD_BS_Value[Num].F_Q_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[Num].F_Q_F_D[i]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_F[i]-RtuDataAddr->Yue_DD_BS_Value[Num].F_Q_F[i];
		}
		//-----------------------------------------------���������

				memcpy(&RtuDataAddr->Yue_Save_Value.Cl_His_XuLiang[Num].Chao_Time,&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Chao_Time,5);
				RtuDataAddr->Yue_Save_Value.Cl_His_XuLiang[Num].Z_P_X_All=RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_P_X_All;
				for(i=0;i<FeiLvNum;i++)
				{
					RtuDataAddr->Yue_Save_Value.Cl_His_XuLiang[Num].Z_P_X_F[i]=RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_P_X_F[i];
				}
				memcpy(RtuDataAddr->Yue_Save_Value.Cl_His_XuLiang[Num].Time_Z_P_X_All,RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_P_X_All,4);
				for(i=0;i<FeiLvNum;i++)
				{
					memcpy(RtuDataAddr->Yue_Save_Value.Cl_His_XuLiang[Num].Time_Z_P_X_F[i],RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_P_X_F[i],4);
				}
				RtuDataAddr->Yue_Save_Value.Cl_His_XuLiang[Num].Z_Q_X_All=RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_Q_X_All;
				for(i=0;i<FeiLvNum;i++)
				{
					RtuDataAddr->Yue_Save_Value.Cl_His_XuLiang[Num].Z_Q_X_F[i]=RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Z_Q_X_F[i];
				}
				memcpy(RtuDataAddr->Yue_Save_Value.Cl_His_XuLiang[Num].Time_Z_Q_X_All,RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_Q_X_All,4);
				for(i=0;i<FeiLvNum;i++)
				{
					memcpy(RtuDataAddr->Yue_Save_Value.Cl_His_XuLiang[Num].Time_Z_Q_X_F[i],RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_Z_Q_X_F[i],4);
				}
				RtuDataAddr->Yue_Save_Value.Cl_His_XuLiang[Num].F_P_X_All=RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_P_X_All;
				for(i=0;i<FeiLvNum;i++)
				{
					RtuDataAddr->Yue_Save_Value.Cl_His_XuLiang[Num].F_P_X_F[i]=RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_P_X_F[i];
				}
				memcpy(RtuDataAddr->Yue_Save_Value.Cl_His_XuLiang[Num].Time_F_P_X_All,RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_P_X_All,4);
				for(i=0;i<FeiLvNum;i++)
				{
					memcpy(RtuDataAddr->Yue_Save_Value.Cl_His_XuLiang[Num].Time_F_P_X_F[i],RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_P_X_F[i],4);
				}
				RtuDataAddr->Yue_Save_Value.Cl_His_XuLiang[Num].F_Q_X_All=RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_Q_X_All;
				for(i=0;i<FeiLvNum;i++)
				{
					RtuDataAddr->Yue_Save_Value.Cl_His_XuLiang[Num].F_Q_X_F[i]=RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].F_Q_X_F[i];
				}
				memcpy(RtuDataAddr->Yue_Save_Value.Cl_His_XuLiang[Num].Time_F_Q_X_All,RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_Q_X_All,4);
				for(i=0;i<FeiLvNum;i++)
				{
					memcpy(RtuDataAddr->Yue_Save_Value.Cl_His_XuLiang[Num].Time_F_Q_X_F[i],RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[Num].Time_F_Q_X_F[i],4);
				}
				//-----------------------------------------
	}
	for(Num=0;Num<ZongJia_Max;Num++)
	{
		RtuDataAddr->Yue_Save_Value.Zj_His_DianNeng[Num].Z_P_All_S=RtuDataAddr->Real_Zj_Value[Num].P_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Yue_Save_Value.Zj_His_DianNeng[Num].Z_P_F_S[i]=RtuDataAddr->Real_Zj_Value[Num].P_F[i];
		}
		RtuDataAddr->Yue_Save_Value.Zj_His_DianNeng[Num].Z_Q_All_S=RtuDataAddr->Real_Zj_Value[Num].Q_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Yue_Save_Value.Zj_His_DianNeng[Num].Z_Q_F_S[i]=RtuDataAddr->Real_Zj_Value[Num].Q_F[i];
		}
		RtuDataAddr->Yue_Save_Value.Zj_His_DianNeng[Num].Z_P_All_D=RtuDataAddr->Real_Zj_Value[Num].P_All-RtuDataAddr->Yue_Zj_Value[Num].P_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Yue_Save_Value.Zj_His_DianNeng[Num].Z_P_F_D[i]=RtuDataAddr->Real_Zj_Value[Num].P_F[i]-RtuDataAddr->Yue_Zj_Value[Num].P_F[i];
		}
		RtuDataAddr->Yue_Save_Value.Zj_His_DianNeng[Num].Z_Q_All_D=RtuDataAddr->Real_Zj_Value[Num].Q_All-RtuDataAddr->Yue_Zj_Value[Num].Q_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Yue_Save_Value.Zj_His_DianNeng[Num].Z_Q_F_D[i]=RtuDataAddr->Real_Zj_Value[Num].Q_F[i]-RtuDataAddr->Yue_Zj_Value[Num].Q_F[i];
		}
	}
}
void SaveClQuXian(/*TS ts,*/INT16U Sort,INT8U month,INT8U day)
{
	INT8U i;
	unsigned char name[128];
	memset(name,0,128);
	RtuDataAddr->autoReport=0;
	for(i=0;i<CeLiangPoint_Max;i++)
	{
		RtuDataAddr->QX_DD_Device_BiaoShi_Value[i][Sort]=RtuDataAddr->DD_Device_BiaoShi_Value[i];
		RtuDataAddr->QX_DD_ZuiDa_Xuliang_Shuju[i][Sort]=RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[i];
		//RtuDataAddr->QX_DD_Device_BiaoShi_Value[i][Sort].QX_Z_P_All = RtuDataAddr->QX_DD_Device_BiaoShi_Value[i][Sort].Z_P_All;
		//RtuDataAddr->QX_DD_Device_BiaoShi_Value[i][Sort].QX_F_P_All=RtuDataAddr->QX_DD_Device_BiaoShi_Value[i][Sort].F_P_All;
		//RtuDataAddr->QX_DD_Device_BiaoShi_Value[i][Sort].QX_Z_Q_All=RtuDataAddr->QX_DD_Device_BiaoShi_Value[i][Sort].Z_Q_All;
		//RtuDataAddr->QX_DD_Device_BiaoShi_Value[i][Sort].QX_F_Q_All=RtuDataAddr->QX_DD_Device_BiaoShi_Value[i][Sort].F_Q_All;
		//���Ժ��ⷢ�� ���������� ���򡢷����й��ܵ�����  �����򡢷����޹��ܵ�����Ϊ 0  �о�����ע�͵����������⡣
		RtuDataAddr->QX_DD_Device_BiaoShi_Value[i][Sort].QX_Z_P_All=
		RtuDataAddr->QX_DD_Device_BiaoShi_Value[i][Sort].Z_P_All-RtuDataAddr->Min_15_DD_BS_Value[i].Z_P_All;
		RtuDataAddr->QX_DD_Device_BiaoShi_Value[i][Sort].QX_F_P_All=
		RtuDataAddr->QX_DD_Device_BiaoShi_Value[i][Sort].F_P_All-RtuDataAddr->Min_15_DD_BS_Value[i].F_P_All;
		RtuDataAddr->QX_DD_Device_BiaoShi_Value[i][Sort].QX_Z_Q_All=
		RtuDataAddr->QX_DD_Device_BiaoShi_Value[i][Sort].Z_Q_All-RtuDataAddr->Min_15_DD_BS_Value[i].Z_Q_All;
		RtuDataAddr->QX_DD_Device_BiaoShi_Value[i][Sort].QX_F_Q_All=
		RtuDataAddr->QX_DD_Device_BiaoShi_Value[i][Sort].F_Q_All-RtuDataAddr->Min_15_DD_BS_Value[i].F_Q_All;
		//printf("\n\rRtuDataAddr->QX_DD_Device_BiaoShi_Value[%d][%d].P   =====%d",i,Sort,RtuDataAddr->QX_DD_Device_BiaoShi_Value[i][Sort].P);
	}
	for(i=0;i<ZongJia_Max;i++)
	{
		RtuDataAddr->QX_Real_Zj_Value[i][Sort]=RtuDataAddr->Real_Zj_Value[i];
		//���Ժ��������Ϊ0�����ɴ�������
		RtuDataAddr->QX_Real_Zj_Value[i][Sort].P_All=
		RtuDataAddr->QX_Real_Zj_Value[i][Sort].P_All-RtuDataAddr->Min_15_Zj_Value[i].P_All;
		RtuDataAddr->QX_Real_Zj_Value[i][Sort].Q_All=
		RtuDataAddr->QX_Real_Zj_Value[i][Sort].Q_All-RtuDataAddr->Min_15_Zj_Value[i].Q_All;
	}
	//sprintf(name,"/nand/save/qxddbs%02d%02d.dat",ts.Month,ts.Day);
	sprintf((char *)name,"/nand/save/qxddbs%02d%02d.dat",month,day);
	SaveFile(name,&RtuDataAddr->QX_DD_Device_BiaoShi_Value[0][0].Valid,sizeof(RtuDataAddr->QX_DD_Device_BiaoShi_Value));
	delay(50);
	RtuDataAddr->autoReport=1;

	memset(name,0,128);
	//sprintf(name,"/nand/save/qxzj%02d%02d.dat",ts.Month,ts.Day);
	sprintf((char *)name,"/nand/save/qxzj%02d%02d.dat",month,day);
	SaveFile(name,&RtuDataAddr->QX_Real_Zj_Value[0][0].Valid,sizeof(RtuDataAddr->QX_Real_Zj_Value));
}
void ReadQx(TS ts)
{
	unsigned char name[128];
	memset(name,0,128);
	sprintf((char *)name,"/nand/save/qxddbs%02d%02d.dat",ts.Month,ts.Day);
	ReadFile(name,&RtuDataAddr->QX_DD_Device_BiaoShi_Value[0][0].Valid,sizeof(RtuDataAddr->QX_DD_Device_BiaoShi_Value));
	memset(name,0,128);
	sprintf((char *)name,"/nand/save/qxzj%02d%02d.dat",ts.Month,ts.Day);
	ReadFile(name,&RtuDataAddr->QX_Real_Zj_Value[0][0].Valid,sizeof(RtuDataAddr->QX_Real_Zj_Value));
}
void SaveClYueValue(Data_Type_15 Savedate)
{
	unsigned char name[128];
	int i;
	memset(name,0,128);
	Calc_Yue_Bs_zj();
	SaveYueCLInit();
	SaveYueZJInit();
	memcpy(RtuDataAddr->Yue_DD_BS_Value,RtuDataAddr->DD_Device_BiaoShi_Value,sizeof(RtuDataAddr->Yue_DD_BS_Value));
	memcpy(RtuDataAddr->Yue_Zj_Value,RtuDataAddr->Real_Zj_Value,sizeof(RtuDataAddr->Yue_Zj_Value));
	RtuDataAddr->Yue_Save_Value.ZD_Yue_stat.Valid=1;
	RtuDataAddr->Yue_Save_Value.ZD_Yue_stat.liuliang=RtuDataAddr->Fm_Save_Eve.yueLiuLiang;
	RtuDataAddr->Fm_Save_Eve.yueLiuLiang=0;
	sprintf((char *)name,"/nand/save/YueSave%02x.dat",Savedate.BCD04);
	SaveFile(name,(INT8U *)&RtuDataAddr->Yue_Save_Value,sizeof(RtuDataAddr->Yue_Save_Value));
	memset(&RtuDataAddr->Yue_Save_Value,0,sizeof(RtuDataAddr->Yue_Save_Value));
	memset(name,0,128);
	sprintf((char *)name,"/nand/save/YueF2730Save%02x.dat",Savedate.BCD04);
	//printf("\n\rsave yue tongji----%s",name);
	//XXPrint("\n\rsave yue tongji----%s",name);
	SaveFile(name,(INT8U *)&RtuDataAddr->YF27_28_29_30_Mem[0].valid,sizeof(RtuDataAddr->YF27_28_29_30_Mem));
	for(i=0;i<ZongJia_Max;i++)
	{
		RtuDataAddr->Yue_Save_Value.Zj_Stat[i].MinP=0x7fff;
		RtuDataAddr->Yue_Save_Value.Zj_Stat[i].MaxP=0;
	}
}
void CheckDayTongjiData()
{
	int ssize,xsize,i;
	for (i=0;i<CeLiangPoint_Max;i++)
	{
		//-------------------------------------------------UA��ѹԽ���ۼ�ʱ��У��--------------------------------------------
		ssize = 1440; xsize = 1440;
		if ((RtuDataAddr->F27_28_29_30_Mem[i].USU_Count + RtuDataAddr->F27_28_29_30_Mem[i].UXU_Count)>1440)
		{//������ֵʱ���ܺʹ���1440���ӣ���ʱ��Ҫ�ж��ĸ�ֵ��������������˺���ֵʣ��ʱ��ȫΪ�ϸ�ʱ��
			if (RtuDataAddr->F27_28_29_30_Mem[i].USU_Count <= 1440) ssize = 1440 - RtuDataAddr->F27_28_29_30_Mem[i].USU_Count;
			if (RtuDataAddr->F27_28_29_30_Mem[i].UXU_Count <= 1440) xsize = 1440 - RtuDataAddr->F27_28_29_30_Mem[i].UXU_Count;
			if (ssize <= xsize)//����ֵ�����ں���ˮƽ
			{
				//����ʱ�䱣�ֲ��䣬����ʱ��Ϊ0 ����ʱ��Ϊ�ϸ�ʱ��
				RtuDataAddr->F27_28_29_30_Mem[i].UXU_Count = 0;
				RtuDataAddr->F27_28_29_30_Mem[i].UHGU_Count= 1440 - RtuDataAddr->F27_28_29_30_Mem[i].USU_Count;
			}else             //����ֵ�����ں���ˮƽ
			{
				//����ʱ�䱣�ֲ��䣬����ʱ��Ϊ0����ʱ��Ϊ�ϸ�ʱ��
				RtuDataAddr->F27_28_29_30_Mem[i].USU_Count = 0;
				RtuDataAddr->F27_28_29_30_Mem[i].UHGU_Count= 1440 - RtuDataAddr->F27_28_29_30_Mem[i].UXU_Count;
			}
		}else
		{
			RtuDataAddr->F27_28_29_30_Mem[i].UHGU_Count= 1440 - RtuDataAddr->F27_28_29_30_Mem[i].UXU_Count - RtuDataAddr->F27_28_29_30_Mem[i].USU_Count;
		}
		//-------------------------------------------------UB��ѹԽ���ۼ�ʱ��У��--------------------------------------------
		ssize = 1440; xsize = 1440;
		if ((RtuDataAddr->F27_28_29_30_Mem[i].USV_Count + RtuDataAddr->F27_28_29_30_Mem[i].UXV_Count)>1440)
		{
			if (RtuDataAddr->F27_28_29_30_Mem[i].USV_Count <= 1440) ssize = 1440 - RtuDataAddr->F27_28_29_30_Mem[i].USV_Count;
			if (RtuDataAddr->F27_28_29_30_Mem[i].UXV_Count <= 1440) xsize = 1440 - RtuDataAddr->F27_28_29_30_Mem[i].UXV_Count;
			if (ssize <= xsize)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].UXV_Count = 0;
				RtuDataAddr->F27_28_29_30_Mem[i].UHGV_Count= 1440 - RtuDataAddr->F27_28_29_30_Mem[i].USV_Count;
			}else
			{
				RtuDataAddr->F27_28_29_30_Mem[i].USV_Count = 0;
				RtuDataAddr->F27_28_29_30_Mem[i].UHGV_Count= 1440 - RtuDataAddr->F27_28_29_30_Mem[i].UXV_Count;
			}
		}else
		{
			RtuDataAddr->F27_28_29_30_Mem[i].UHGV_Count= 1440 - RtuDataAddr->F27_28_29_30_Mem[i].UXV_Count - RtuDataAddr->F27_28_29_30_Mem[i].USV_Count;
		}
		//-------------------------------------------------UB��ѹԽ���ۼ�ʱ��У��--------------------------------------------
		ssize = 1440; xsize = 1440;
		if ((RtuDataAddr->F27_28_29_30_Mem[i].USW_Count + RtuDataAddr->F27_28_29_30_Mem[i].UXW_Count)>1440)
		{
			if (RtuDataAddr->F27_28_29_30_Mem[i].USW_Count <= 1440) ssize = 1440 - RtuDataAddr->F27_28_29_30_Mem[i].USW_Count;
			if (RtuDataAddr->F27_28_29_30_Mem[i].UXW_Count <= 1440) xsize = 1440 - RtuDataAddr->F27_28_29_30_Mem[i].UXW_Count;
			if (ssize <= xsize)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].UXW_Count = 0;
				RtuDataAddr->F27_28_29_30_Mem[i].UHGW_Count= 1440 - RtuDataAddr->F27_28_29_30_Mem[i].USW_Count;
			}else
			{
				RtuDataAddr->F27_28_29_30_Mem[i].USW_Count = 0;
				RtuDataAddr->F27_28_29_30_Mem[i].UHGW_Count= 1440 - RtuDataAddr->F27_28_29_30_Mem[i].UXW_Count;
			}
		}else
		{
			RtuDataAddr->F27_28_29_30_Mem[i].UHGW_Count= 1440 - RtuDataAddr->F27_28_29_30_Mem[i].UXW_Count - RtuDataAddr->F27_28_29_30_Mem[i].USW_Count;
		}
	}
}
void SaveDayValue_everyhour(Data_Type_15 Savedate)
{
	unsigned char name[128];
	memset(name,0,128);
	memcpy(RtuDataAddr->Day_DD_BS_Value,RtuDataAddr->DD_Device_BiaoShi_Value,sizeof(RtuDataAddr->Day_DD_BS_Value));
	memcpy(RtuDataAddr->Day_Zj_Value,RtuDataAddr->Real_Zj_Value,sizeof(RtuDataAddr->Day_Zj_Value));
	Calc_Day_Bs_zj();
}
void SaveClDayValue(Data_Type_15 Savedate)
{
	INT16U i;
	unsigned char name[128];
	RtuDataAddr->autoReport=0;
	memset(name,0,128);
	Calc_Day_Bs_zj();
	SaveDayCLInit();
	SaveDayZJInit();
	memcpy(RtuDataAddr->Day_DD_BS_Value,RtuDataAddr->DD_Device_BiaoShi_Value,sizeof(RtuDataAddr->Day_DD_BS_Value));
	memcpy(RtuDataAddr->Day_Zj_Value,RtuDataAddr->Real_Zj_Value,sizeof(RtuDataAddr->Day_Zj_Value));

	RtuDataAddr->Day_Save_Value.ZD_Day_stat.Valid=1;
	RtuDataAddr->Day_Save_Value.ZD_Day_stat.liuliang=RtuDataAddr->Fm_Save_Eve.DayLiuLiang;
	RtuDataAddr->Fm_Save_Eve.DayLiuLiang=0;
	sprintf((char *)name,"/nand/save/DaySave%02x%02x.dat",Savedate.BCD04,Savedate.BCD03);
	SaveFile(name,(INT8U *)&RtuDataAddr->Day_Save_Value,sizeof(RtuDataAddr->Day_Save_Value));

	memset(name,0,128);
	sprintf((char *)name,"/nand/save/DayF2730Save%02x%02x.dat",Savedate.BCD04,Savedate.BCD03);

	CheckDayTongjiData();//����յ�ѹͳ������
	SaveFile(name,(INT8U *)&RtuDataAddr->F27_28_29_30_Mem[0].valid,sizeof(RtuDataAddr->F27_28_29_30_Mem));
    delay(50);

	RtuDataAddr->autoReport=1;

	printf("\n\r Day change save %s",name);
    memset(name,0,128);
    sprintf((char *)name,"/nand/save/DayFuZaiLvTongJiSave%02x%02x.dat",Savedate.BCD04,Savedate.BCD03);
	SaveFile(name,(INT8U *)&RtuDataAddr->FuZaiLvTongJi.valid,sizeof(RtuDataAddr->FuZaiLvTongJi));
	memset(&RtuDataAddr->Day_Save_Value,0,sizeof(RtuDataAddr->Day_Save_Value));
	memset(&RtuDataAddr->Day_Save_Value.Zj_Stat[0].Valid,0,sizeof(RtuDataAddr->Day_Save_Value.Zj_Stat));
	memset(RtuDataAddr->Day_Save_Value.Cl_Stat,0,sizeof(RtuDataAddr->Day_Save_Value.Cl_Stat));

	for(i=0;i<ZongJia_Max;i++)
	{
		RtuDataAddr->Day_Save_Value.Zj_Stat[i].MinP=0x7fff;
		RtuDataAddr->Day_Save_Value.Zj_Stat[i].MaxP=0;
	}
}
INT8U   PARSE_CMD(int argc, char * argv[])
{
	INT8U  proc_name[32] = "";
	if(argc < 2)return (FALSE);
	PORT_ID = atoi(argv[1]);
	sprintf((char *)proc_name, "%s %d", argv[0], PORT_ID);
	if((attach = name_attach(NULL, (char *)proc_name,0))  == NULL)
	{
		fprintf(stderr, "ERR:'%s' runed,cann't regist: %s\r\n", proc_name, strerror(errno));
		return (FALSE);
	}
	return (TRUE);
}
void QuitProcess(int signo)
{
	delay(100);
	fclose(Gwfp);
	RtuDataAddr->stPortPara[PORT_ID].PID=0;
   	name_detach(attach, 0);
   	fprintf(stderr,"fkdatasave quit");
	exit(0);
}
void markver()//��Ŀ������б�ʶ�����汾��Ϣ
{
	printf("\n%s\n", verstr);
}
int GetLocalIp()
{
	FILE *fp=NULL;
	int numstr =0;
	char string[100];
	int temp1,temp2,temp3,temp4;
	fp = fopen("/etc/rc.d/ip.sh","r");
	if (fp!=NULL){
		memset(string,0,100);
		numstr  = fscanf(fp, "%s", string);
		if (numstr<=0)
			return 0;

		memset(string,0,100);
		numstr  = fscanf(fp, "%s", string);
		if (numstr<=0)
			return 0;

		memset(string,0,100);
		numstr  = fscanf(fp, "%s", string);
		if (numstr<=0)
			return 0;
		sscanf(string,"%d.%d.%d.%d", &temp1, &temp2, &temp3, &temp4);
		RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[0] = temp1;
		RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[1] = temp2;
		RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[2] = temp3;
		RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[3] = temp4;
		return 1;
	}
	return 0;
}
//��ͳ�����ݴ���
void SaveTongji_dayCount(TS ts)
{
	int i;
	SAVETONGJI_TYPE filedata;
	for(i=0;i<CeLiangPoint_Max;i++)
		filedata.TongjiData[i] = RtuDataAddr->F27_28_29_30_Mem[i] ;
	filedata.SaveTime   = ts;

	SaveFile((INT8U *)"/nand/save/tongji_day.tmp",(INT8U *)&filedata,sizeof(SAVETONGJI_TYPE));
	fprintf(stderr,"\n\r save day tongji tmp");
	return;
}
//��ͳ�����ݴ���
void SaveTongji_yueCount(TS ts)
{
	int i;
	SAVETONGJI_TYPE filedata;
	for(i=0;i<CeLiangPoint_Max;i++)
		filedata.TongjiData[i] = RtuDataAddr->YF27_28_29_30_Mem[i] ;
	filedata.SaveTime   = ts;

	SaveFile((INT8U *)"/nand/save/tongji_yue.tmp",(INT8U *)&filedata,sizeof(SAVETONGJI_TYPE));
	fprintf(stderr,"\n\r save yue tongji tmp");
	return;
}
void TimeGetType18(INT8U *D,TS ts)
{
	D[0]=ts.Minute/10;
	D[0]=(D[0]<<4)+(ts.Minute%10);
	D[1]=ts.Hour/10;
	D[1]=(D[1]<<4)+(ts.Hour%10);
	D[2]=ts.Day/10;
	D[2]=(D[2]<<4)+(ts.Day%10);
}
void InitYu_U_MaxMin(TS ts)//��ʼ����ͳ�����ݣ���ѹ�����Сֵ������ʱ�䣬ͳ�Ƽ�������
{
	unsigned char i;
	for(i=0;i<CeLiangPoint_Max;i++)
	{
		RtuDataAddr->YF27_28_29_30_Mem[i].DUUMAX = RtuDataAddr->DD_Device_BiaoShi_Value[i].VA;
		TimeGetType18(RtuDataAddr->YF27_28_29_30_Mem[i].DUUMAX_TIME,ts);
		RtuDataAddr->YF27_28_29_30_Mem[i].DUVMAX = RtuDataAddr->DD_Device_BiaoShi_Value[i].VB;
		TimeGetType18(RtuDataAddr->YF27_28_29_30_Mem[i].DUVMAX_TIME,ts);
		RtuDataAddr->YF27_28_29_30_Mem[i].DUWMAX = RtuDataAddr->DD_Device_BiaoShi_Value[i].VC;
		TimeGetType18(RtuDataAddr->YF27_28_29_30_Mem[i].DUWMAX_TIME,ts);

		RtuDataAddr->YF27_28_29_30_Mem[i].DUUMIN = RtuDataAddr->DD_Device_BiaoShi_Value[i].VA;
		TimeGetType18(RtuDataAddr->YF27_28_29_30_Mem[i].DUUMIN_TIME,ts);
		RtuDataAddr->YF27_28_29_30_Mem[i].DUVMIN = RtuDataAddr->DD_Device_BiaoShi_Value[i].VB;
		TimeGetType18(RtuDataAddr->YF27_28_29_30_Mem[i].DUVMIN_TIME,ts);
		RtuDataAddr->YF27_28_29_30_Mem[i].DUWMIN = RtuDataAddr->DD_Device_BiaoShi_Value[i].VC;
		TimeGetType18(RtuDataAddr->YF27_28_29_30_Mem[i].DUWMIN_TIME,ts);
		RtuDataAddr->YF27_28_29_30_Mem[i].USSU_Count =0;
		RtuDataAddr->YF27_28_29_30_Mem[i].USU_Count =0;
		RtuDataAddr->YF27_28_29_30_Mem[i].UXXU_Count =0;
		RtuDataAddr->YF27_28_29_30_Mem[i].UXU_Count =0;
		RtuDataAddr->YF27_28_29_30_Mem[i].UHGU_Count =0;
		RtuDataAddr->YF27_28_29_30_Mem[i].USSV_Count =0;
		RtuDataAddr->YF27_28_29_30_Mem[i].USV_Count =0;
		RtuDataAddr->YF27_28_29_30_Mem[i].UXXV_Count =0;
		RtuDataAddr->YF27_28_29_30_Mem[i].UXV_Count =0;
		RtuDataAddr->YF27_28_29_30_Mem[i].UHGV_Count =0;
		RtuDataAddr->YF27_28_29_30_Mem[i].USSW_Count =0;
		RtuDataAddr->YF27_28_29_30_Mem[i].USW_Count =0;
		RtuDataAddr->YF27_28_29_30_Mem[i].UXXW_Count =0;
		RtuDataAddr->YF27_28_29_30_Mem[i].UXW_Count =0;
		RtuDataAddr->YF27_28_29_30_Mem[i].UHGW_Count =0;
		RtuDataAddr->YF27_28_29_30_Mem[i].U_A_Sum = 0;
		RtuDataAddr->YF27_28_29_30_Mem[i].U_B_Sum = 0;
		RtuDataAddr->YF27_28_29_30_Mem[i].U_C_Sum = 0;
		RtuDataAddr->YF27_28_29_30_Mem[i].V_UNBALANCE_Count =0;
	}
}

void InitDay_U_MaxMin(TS ts)//��ʼ����ͳ�����ݣ���ѹ�����Сֵ������ʱ�䣬ͳ�Ƽ�������
{
	unsigned char i;
	for(i=0;i<CeLiangPoint_Max;i++)
	{
		RtuDataAddr->F27_28_29_30_Mem[i].DUUMAX = RtuDataAddr->DD_Device_BiaoShi_Value[i].VA;//FkDdRealData
		TimeGetType18(RtuDataAddr->F27_28_29_30_Mem[i].DUUMAX_TIME,ts);
		RtuDataAddr->F27_28_29_30_Mem[i].DUVMAX = RtuDataAddr->DD_Device_BiaoShi_Value[i].VB;
		TimeGetType18(RtuDataAddr->F27_28_29_30_Mem[i].DUVMAX_TIME,ts);
		RtuDataAddr->F27_28_29_30_Mem[i].DUWMAX = RtuDataAddr->DD_Device_BiaoShi_Value[i].VC;
		TimeGetType18(RtuDataAddr->F27_28_29_30_Mem[i].DUWMAX_TIME,ts);

		RtuDataAddr->F27_28_29_30_Mem[i].DUUMIN = RtuDataAddr->DD_Device_BiaoShi_Value[i].VA;
		TimeGetType18(RtuDataAddr->F27_28_29_30_Mem[i].DUUMIN_TIME,ts);
		RtuDataAddr->F27_28_29_30_Mem[i].DUVMIN = RtuDataAddr->DD_Device_BiaoShi_Value[i].VB;
		TimeGetType18(RtuDataAddr->F27_28_29_30_Mem[i].DUVMIN_TIME,ts);
		RtuDataAddr->F27_28_29_30_Mem[i].DUWMIN = RtuDataAddr->DD_Device_BiaoShi_Value[i].VC;
		TimeGetType18(RtuDataAddr->F27_28_29_30_Mem[i].DUWMIN_TIME,ts);
		RtuDataAddr->F27_28_29_30_Mem[i].USSU_Count =0;
		RtuDataAddr->F27_28_29_30_Mem[i].USU_Count =0;
		RtuDataAddr->F27_28_29_30_Mem[i].UXXU_Count =0;
		RtuDataAddr->F27_28_29_30_Mem[i].UXU_Count =0;
		RtuDataAddr->F27_28_29_30_Mem[i].UHGU_Count =0;
		RtuDataAddr->F27_28_29_30_Mem[i].USSV_Count =0;
		RtuDataAddr->F27_28_29_30_Mem[i].USV_Count =0;
		RtuDataAddr->F27_28_29_30_Mem[i].UXXV_Count =0;
		RtuDataAddr->F27_28_29_30_Mem[i].UXV_Count =0;
		RtuDataAddr->F27_28_29_30_Mem[i].UHGV_Count =0;
		RtuDataAddr->F27_28_29_30_Mem[i].USSW_Count =0;
		RtuDataAddr->F27_28_29_30_Mem[i].USW_Count =0;
		RtuDataAddr->F27_28_29_30_Mem[i].UXXW_Count =0;
		RtuDataAddr->F27_28_29_30_Mem[i].UXW_Count =0;
		RtuDataAddr->F27_28_29_30_Mem[i].UHGW_Count =0;
		RtuDataAddr->F27_28_29_30_Mem[i].U_A_Sum = 0;
		RtuDataAddr->F27_28_29_30_Mem[i].U_B_Sum = 0;
		RtuDataAddr->F27_28_29_30_Mem[i].U_C_Sum = 0;
		RtuDataAddr->F27_28_29_30_Mem[i].V_UNBALANCE_Count =0;
	}
}


int main(int argc, char *argv[]) {
	struct sigaction sa1;
	INT8U Min,i;
	TS ts;
	INT8U NowMin,NowHour,NowDay,NowMonth,NowWeek,MinCount,NowYear,NowSec=0;
	TS DayFreezeOldTs,MonthFreezeOldTs;
	Data_Type_15 Savedate;
	markver();
	if(OpenMem())return EXIT_FAILURE;
	if(RtuDataAddr->mem_len!=sizeof(RTimeData))
	{
		fprintf( stderr, "base mem uncompared prog will exit %d :\n",sizeof(RTimeData));
		return EXIT_FAILURE;
	}
	if(!PARSE_CMD(argc, argv))
	{
		return EXIT_FAILURE;
	}
	sa1.sa_handler = QuitProcess;
	sigemptyset(&sa1.sa_mask);
	sa1.sa_flags = 0;
	sigaction(SIGTERM, &sa1,NULL);
	sigaction(SIGSYS, &sa1,NULL);
	sigaction(SIGPWR, &sa1,NULL);
	sigaction(SIGKILL, &sa1,NULL);
	sigaction(SIGQUIT, &sa1,NULL);
	sigaction(SIGILL, &sa1,NULL);
	sigaction(SIGINT, &sa1,NULL);
	sigaction(SIGHUP, &sa1,NULL);
	sigaction(SIGABRT, &sa1,NULL);
	sigaction(SIGBUS, &sa1,NULL);
	RtuDataAddr->stPortPara[PORT_ID].PID=getpid();
	Gwfp = NULL;
	Gwfp =  fopen("/nand/fkdatasave.log","a+");

	Min=0;
	MinCount=0;
	DataSaveDbg("\r\n%d %d %d ",ts.Hour,ts.Minute,ts.Sec);
	OSTimeDly(2000);

	if(ReadConfig()==FALSE)
	{
		name_detach(attach, 0);
		fprintf(stderr,"\n\r fkdatasave return error");
		return EXIT_FAILURE;
	}
	GetLocalIp();		//��ȡ����IP
	for(i=0;i<8;i++)
	{
		RtuDataAddr->Zj_Control_Value[i].F48_Set_Para.Valid=1;
		RtuDataAddr->Zj_Control_Value[i].F48_Set_Para.DianKong_Lunci_Biaozhi=15;
	}

	Read_Fk_Control_para_Set();//���Ʋ�����ȡ  /config/p130ctl.set
	TSGet(&ts);
	TSGet(&DayFreezeOldTs);
	TSGet(&MonthFreezeOldTs);
	NowMin=ts.Minute;
	NowHour=ts.Hour;
	NowDay=ts.Day;

	NowMonth=ts.Month;
	NowWeek=ts.Week;
	NowYear=ts.Year%100;
	while(RtuDataAddr->Fm_Init_OK==0)
	{
		CleardeadCount();
		delay(1000);
	}
	Read_Fk_real_Data();//��ȡ�����е�ʵʱ����   ���������ģ�
	RtuDataAddr->Day_Save_Value.ZD_Day_stat.Reset_Time++;
	RtuDataAddr->Yue_Save_Value.ZD_Yue_stat.Reset_Time++;
	Read_Zj_real_Data();////��ȡ�����е�ʵʱ����   ���ܼ���ģ�
	ReadDayCLInit();
	ReadYueCLInit();
	ReadDayZJInit();
	ReadYueZJInit();
	Read_Min15_Data();
	for(i=0;i<ZongJia_Max;i++)
	{
		RtuDataAddr->Day_Save_Value.Zj_Stat[i].MinP=0x7fff;
		RtuDataAddr->Day_Save_Value.Zj_Stat[i].MaxP=0;
	}
	for(i=0;i<ZongJia_Max;i++)
	{
		RtuDataAddr->Yue_Save_Value.Zj_Stat[i].MinP=0x7fff;
		RtuDataAddr->Yue_Save_Value.Zj_Stat[i].MaxP=0;
	}
	ReadFile((INT8U *)"/nand/save/Merc1.dat",&RtuDataAddr->M_Event_Save[0].UseFlag,sizeof(RtuDataAddr->M_Event_Save));
	ReadFile((INT8U *)"/nand/save/Serc1.dat",&RtuDataAddr->S_Event_Save[0].UseFlag,sizeof(RtuDataAddr->S_Event_Save));
	ReadFile((INT8U *)"/nand/save/fkzhongwen.sav",(INT8U *)RtuDataAddr->FkZhongWen,sizeof(RtuDataAddr->FkZhongWen));

	RtuDataAddr->Dev_Init_OK=1;
	RtuDataAddr->FM_Changed=0;
	ReadQx(ts);
  	for (;;)
   	{
  		CleardeadCount();
		HisDiannengTest();
		TSGet(&ts);
		Savedate.BCD01=((NowMin/10)<<4)+(NowMin%10);
		Savedate.BCD02=((NowHour/10)<<4)+(NowHour%10);
		Savedate.BCD03=((NowDay/10)<<4)+(NowDay%10);
		Savedate.BCD04=((NowMonth/10)<<4)+(NowMonth%10);
		Savedate.BCD05=(((NowYear%100)/10)<<4)+(NowYear%10);

		Savedate.BCD01=((NowMin/10)<<4)+(NowMin%10);
		Savedate.BCD02=((NowHour/10)<<4)+(NowHour%10);
		Savedate.BCD03=((NowDay/10)<<4)+(NowDay%10);
		Savedate.BCD04=((NowMonth/10)<<4)+(NowMonth%10);
		Savedate.BCD05=(((NowYear%100)/10)<<4)+(NowYear%10);
  		delay(900);
		Save_Fk_real_Data();
		Save_Zj_real_Data();
  		if(NowMin!=ts.Minute)
		{
			RtuDataAddr->GprsRedialBetween=RtuDataAddr->GprsRedialBetween+((ts.Sec+60-NowSec)%60);
			NowSec=ts.Sec;
			if(ts.Minute==15)
			{
				Make_DaySave(NowHour,0);
				//SaveClQuXian(ts,ts.Hour*4);
				SaveClQuXian(NowHour*4,NowMonth,NowDay);
				Make_Hour_Value(0);
			}
			if(ts.Minute==30)
			{
				Make_DaySave(NowHour,1);
				SaveClQuXian(NowHour*4+1,NowMonth,NowDay);
				//SaveClQuXian(ts,ts.Hour*4+1);
				Make_Hour_Value(1);
			}
			if(ts.Minute==45)
			{
				Make_DaySave(NowHour,2);
				//SaveClQuXian(ts,ts.Hour*4+2);
				SaveClQuXian(NowHour*4+2,NowMonth,NowDay);
				Make_Hour_Value(2);
			}
			if(ts.Minute==0)
			{
				Make_DaySave(NowHour,3);
				//SaveClQuXian(ts,NowHour*4+3);
				SaveClQuXian(NowHour*4+3,NowMonth,NowDay);
				printf("\n\r Minute change save quxian %d-%d",NowMonth,NowDay);
				printf("\n\r 00RtuDataAddr->autoReport==%d",RtuDataAddr->autoReport);
				Make_Hour_Value(3);
			}
			MinCount++;
		}
		if(NowHour!=ts.Hour)
		{
			//ͳ�����ݴ���
			fprintf(stderr,"\n\r Save Day tongji ---------");
			SaveTongji_dayCount(ts);
			fprintf(stderr,"\n\r Save Yue tongji ---------");
			SaveTongji_yueCount(ts);
			//Сʱ���ݴ洢
			Save_Hour_Value();

			if (ts.Hour != 0){
				Savedate.BCD01=((NowMin/10)<<4)+(NowMin%10);
				Savedate.BCD02=((NowHour/10)<<4)+(NowHour%10);
				Savedate.BCD03=((NowDay/10)<<4)+(NowDay%10);
				Savedate.BCD04=((NowMonth/10)<<4)+(NowMonth%10);
				Savedate.BCD05=(((NowYear%100)/10)<<4)+(NowYear%10);
				Make_DayHisDianneng();
				SaveDayValue_everyhour(Savedate);//ÿСʱ����һ���ն���
			}
		}
		if(DayFreezeOldTs.Day!=ts.Day)
		{
//			if((ts.Hour==0)&&(ts.Minute==0))
			{
				//SaveClQuXian(ts,NowHour*4+3);
				memset(RtuDataAddr->QX_DD_Device_BiaoShi_Value,0,sizeof(RtuDataAddr->QX_DD_Device_BiaoShi_Value));
				SaveClQuXian(ts.Hour,ts.Month,ts.Day);////////////////
				printf("\n\r Day change save quxian %d-%d",ts.Month,ts.Day);
				printf("\n\r 11RtuDataAddr->autoReport==%d",RtuDataAddr->autoReport);
				//�����ݴ洢
				Savedate.BCD01=((DayFreezeOldTs.Minute/10)<<4)+(DayFreezeOldTs.Minute%10);
				Savedate.BCD02=((DayFreezeOldTs.Hour/10)<<4)+(DayFreezeOldTs.Hour%10);
				Savedate.BCD03=((DayFreezeOldTs.Day/10)<<4)+(DayFreezeOldTs.Day%10);
				Savedate.BCD04=((DayFreezeOldTs.Month/10)<<4)+(DayFreezeOldTs.Month%10);
				Savedate.BCD05=(((DayFreezeOldTs.Year%100)/10)<<4)+(DayFreezeOldTs.Year%10);
				Make_DayHisDianneng();
				SaveClDayValue(Savedate);
				InitDay_U_MaxMin(ts);//ͳ�����ݴ��̺��ʼ����ͳ�����ݣ���fkcalc��ת�ƹ���
				fprintf(stderr,"\n\r Init Day tongji !!");
				printf("\n\r 22RtuDataAddr->autoReport==%d",RtuDataAddr->autoReport);
				RtuDataAddr->Fm_Save_Eve.DayLiuLiang=0;
				for(i=0;i<CeLiangPoint_Max;i++)
				{
					memset(&RtuDataAddr->QX_DD_Device_BiaoShi_Value[i],0,sizeof(RtuDataAddr->QX_DD_Device_BiaoShi_Value[i]));
				}
				for(i=0;i<ZongJia_Max;i++)
				{
					memset(&RtuDataAddr->QX_Real_Zj_Value[i],0,sizeof(RtuDataAddr->QX_Real_Zj_Value[i]));
				}
			}
			DayFreezeOldTs.Year=ts.Year%100;
			DayFreezeOldTs.Month=ts.Month;
			DayFreezeOldTs.Day=ts.Day;
			DayFreezeOldTs.Hour=ts.Hour;
			DayFreezeOldTs.Minute=ts.Minute;
		}
		if(MonthFreezeOldTs.Month!=ts.Month)
		{
			//�����ݴ洢
//			if((ts.Hour==0)&&(ts.Minute==0))
			{
				memset(RtuDataAddr->QX_DD_Device_BiaoShi_Value,0,sizeof(RtuDataAddr->QX_DD_Device_BiaoShi_Value));
				//printf("\n\r \n\r\n\r\n\rYue change save quxian %d-%d-----------------",ts.Month,ts.Day);
				SaveClQuXian(ts.Hour,ts.Month,ts.Day);///////////

				Savedate.BCD01=((MonthFreezeOldTs.Minute/10)<<4)+(MonthFreezeOldTs.Minute%10);
				Savedate.BCD02=((MonthFreezeOldTs.Hour/10)<<4)+(MonthFreezeOldTs.Hour%10);
				Savedate.BCD03=((MonthFreezeOldTs.Day/10)<<4)+(MonthFreezeOldTs.Day%10);
				Savedate.BCD04=((MonthFreezeOldTs.Month/10)<<4)+(MonthFreezeOldTs.Month%10);
				Savedate.BCD05=(((MonthFreezeOldTs.Year%100)/10)<<4)+(MonthFreezeOldTs.Year%10);
				Make_YueHisDianneng();
				SaveClYueValue(Savedate);
				RtuDataAddr->Fm_Save_Eve.yueLiuLiang=0;
				InitYu_U_MaxMin(ts);//ͳ�����ݴ��̺��ʼ����ͳ�����ݣ���fkcalc��ת�ƹ���
				fprintf(stderr,"\n\r Init Yue tongji !!");
			}
			MonthFreezeOldTs.Year=ts.Year%100;
			MonthFreezeOldTs.Month=ts.Month;
			MonthFreezeOldTs.Day=ts.Day;
			MonthFreezeOldTs.Hour=ts.Hour;
			MonthFreezeOldTs.Minute=ts.Minute;
		}
		NowMin=ts.Minute;
		NowHour=ts.Hour;
		NowDay=ts.Day;
		NowMonth=ts.Month;
		NowYear=ts.Year%100;
		if(MinCount>=20)
		{
			MinCount=0;
		}
		if(RtuDataAddr->ResetdataSet==1)
		{
			ResetData();
			RtuDataAddr->ResetdataSet=0;
			//ԭʼ�������
		}
		if(RtuDataAddr->ResetSetSet==1)
		{
			ResetData();
			ResetSet();
			RtuDataAddr->ResetSetSet=0;
			// ��λ��������
		}
		if(RtuDataAddr->ResetSetSet2==1)
		{
			ResetData();
			ResetSet2();
			printf("\n\r reset over!");
			RtuDataAddr->ResetSetSet2=0;
			// ��λ��������
		}
		if(RtuDataAddr->ResetHardSet==1)
		{
			system("shutdown");
			RtuDataAddr->ResetHardSet=0;
			//�ն�Ӳ����λ
		}
   	}
  	name_detach(attach, 0);
 	return EXIT_SUCCESS;
}
