
/*
 *
 * Version:GK-GPRS200
 *
 */
#include "lcm.h"
#include "lcdapp.h"
#include "time.h"
#include <string.h>
#include <errno.h>
#include <fkbase/memdef.h>
#include <fkbase/fkbasefun.h>
#include <stdio.h>
#include <stdlib.h>
#include <fkbase/p130set.h>

#include <hw/inout.h>
#include <sched.h>
#include <pthread.h>
#include <inttypes.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/neutrino.h>

pthread_t thread[2];
pthread_mutex_t mut;
int number=0;
unsigned char *LcdBuff;
unsigned char Pixel[2]={0xff,0};
uintptr_t BaseLcdIo,CmdAddr,DataAddr;

uintptr_t BaseKeyIo;
uintptr_t BaseLcmIo;

unsigned char Txmode_flag;
char HzBuf[32];
unsigned char HzDat[267615];
unsigned char a_up,a_down,a_left,a_right;
unsigned  times_thru;
unsigned char GUI_KeyState;
unsigned char OldLevel;
unsigned char incount=0;
INT8U	ShowSd48[48];
const char verstr[]={"VER-STRING-FLG=013.002.217.004"__DATE__" "__TIME__};

INT16U GetNum(INT8U *s,INT8U len,INT8U Flag);
INT8U ScreenInput(void);
void markver()//��Ŀ������б�ʶ�����汾��Ϣ
{
	printf("\n%s\n", verstr);
}
void SetLcdFun(unsigned short ms,unsigned int val)
{
	//msg.messageType = msg.messageType | (ms &0x0000ffff);
	msg.messageType = ((val<<16)|ms);
	if (MsgSend(coid, &msg, sizeof(msg) + 1, &msg, sizeof(msg)) != 0) {
		perror("LED Message Error!\n");
	}
}
int ReadLiangdu()
{
	char strtmp[50];
	memset(strtmp,0,50);
	int liangdu;
	FILE *fp = NULL;
	fp = fopen("/user/liangdu.conf","r");
	if (fp!=NULL)
	{
		fread(strtmp,1,50,fp);
		sscanf(strtmp,"liangdu=%d",&liangdu);
	}
	//printf("\n\rread liangdu==%x",liangdu);
	if((liangdu<0x41A)||(liangdu>0x53F)||((liangdu>0x43F)&&(liangdu<0x500)))
		liangdu= 0x43F;
//	if((liangdu>0x40)||(liangdu<0x00))
//		liangdu=0x3f;
	printf("\n\rreturn liangdu==%x",liangdu);
	printf("\n\r");
	return liangdu;

}
void Lcmpower()
{
    int templiang;
	if (RtuDataAddr->PowerOFFMessage == 1)
	{
		SetLcdFun(AC_POWER_OFF,0);
		RtuDataAddr->PowerOFFMessage = 0;
		fprintf(stderr,"\n\r LcmPOWER  off=1 sendmsg --->dev");
	}
	if(RtuDataAddr->PowerOnMessage == 1)
	{
		SetLcdFun(AC_POWER_ON,0);
		delay(100);
		SetLcdFun(UPDATE_SCREEN,0);
		templiang=ReadLiangdu();
		SetLcdFun(BEIGUANG,templiang);
		SetLcdFun(LED_ON,0);//����Ϣ�����������������
		RtuDataAddr->PowerOnMessage = 0;
		fprintf(stderr,"\n\r LcmPOWER  on=1 sendmsg --->dev");
	}
}
/*******************************************************************************************************************/
INT32S GetDataType02(INT8U *S)
{
	INT32S Temp;
	INT8U T1;
	Temp=S[1]&0x0f;
	Temp=Temp*100;
	Temp=Temp+((S[0]>>4)*10)+(S[0]&0x0f);
	T1=S[1]>>5;
	if(T1==0)Temp=Temp*100000000;
	if(T1==1)Temp=Temp*10000000;
	if(T1==2)Temp=Temp*1000000;
	if(T1==3)Temp=Temp*100000;
	if(T1==4)Temp=Temp*10000;
	if(T1==5)Temp=Temp*1000;
	if(T1==6)Temp=Temp*100;
	if(T1==7)Temp=Temp*10;

	T1=S[1]>>4;
	if(T1&1)
	{
		Temp=0-Temp;
	}
	return Temp;
}
long GetdataType03(INT8U *S)
{
	long t;
	t=S[3]&0x0f;
	t=(t*10)+((S[2]>>4)&0x0f);
	t=(t*10)+(S[2]&0x0f);
	t=(t*10)+((S[1]>>4)&0x0f);
	t=(t*10)+(S[1]&0x0f);
	t=(t*10)+((S[0]>>4)&0x0f);
	t=(t*10)+(S[0]&0x0f);
	if(S[3]&0x40)
	{
		t=t*1000;
	}
	if(S[3]&0x10)
	{
		t=0-t;
	}
	return t;
}
int getevent(unsigned char* local, int flag ,int type)
{
	INT8U no,y,m,d,h,min;
	unsigned char i,EC;
    unsigned int count=0;

	if(flag==1)
	{
		EC = RtuDataAddr->Fm_Save_Eve.EC1;
	}
	else
	{
		EC = RtuDataAddr->Fm_Save_Eve.EC2;
	}
	i = EC-1;

	while(1)
	{
		//---------------
		y = RtuDataAddr->M_Event_Save[i].Event.Buff[6];
		m = RtuDataAddr->M_Event_Save[i].Event.Buff[5];
		d = RtuDataAddr->M_Event_Save[i].Event.Buff[4];
		h = RtuDataAddr->M_Event_Save[i].Event.Buff[3];
		min=RtuDataAddr->M_Event_Save[i].Event.Buff[2];
		no =RtuDataAddr->M_Event_Save[i].Event.Buff[0];
		//printf("\n\r index %d type %d %x %x %x %x: %x",i,no,y,m,d,h,min);
		//printf("\n\r");
		switch(flag)
		{
		case 1:
			if(RtuDataAddr->M_Event_Save[i].Event.Buff[0]==type)
			{
				local[count]=i;
				count++;
			}
			break;
		default:
			if(RtuDataAddr->S_Event_Save[i].Event.Buff[0]==type)
			{
				local[count]=i;
				count++;
			}
		}
		if(i==EC)
			break;
		i--;
	}
	return count;
}

//******************************************************************************************************************
//* �������ƣ�GUI_Point()
//* ��    �ܣ� ����ӳ���Я�����X��������λ����д�����
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void GUI_Point(unsigned int Px, unsigned char Py, unsigned char attr )
{
	LcdBuff[Py*160+Px]= Pixel[attr];//˳ʱ��ת90
}
//******************************************************************************************************************
//* �������ƣ�GUI_RLine()
//* ��    �ܣ���LCD����ʾ����������ֱ�ߡ�
//* ��ڲ���    x0		��ֱ����������е�λ��
//*          y0		��ֱ����������е�λ��
//*          y1       ��ֱ���յ������е�λ��
//* ���ڲ�������
//*******************************************************************************************************************/

void  GUI_DrawVLine(unsigned int x0, unsigned char y0, unsigned char y1)
{
	unsigned char  bak;

	if(y0>y1) {bak = y1;y1 = y0; y0 = bak;}        // ��x0��x1��С�������У��Ա㻭ͼ

	/* �����ʾ�����ˮƽ�� */
	/*==========================*/
	do
	{
		GUI_Point(x0, y0, 1);
		y0++;
	}while(y1>=y0);
	/*==========================*/
}
//******************************************************************************************************************
//* �������ƣ�GUI_HLine()
//* ��    �ܣ���LCD����ʾ��������ˮƽ�ߡ�
//* ��ڲ�����x0		ˮƽ����������е�λ��
//*           y0		ˮƽ����������е�λ��
//*           x1      ˮƽ���յ������е�λ��
//*           color	���ںڰ�ɫ������ɫLCD��Ϊ0ʱ��Ϊ1ʱ��ʾ
//* ���ڲ�������
//*******************************************************************************************************************/
void  GUI_DrawHLine(unsigned int x0, unsigned char y0, unsigned int x1)
{
	unsigned int  bak;

	if(x0>x1){bak = x1;x1 = x0;x0 = bak;}          // ��y0��y1��С�������У��Ա㻭ͼ

	/* �����ʾ�������ֱ�� */
	/*==========================*/
	do
	{
		GUI_Point(x0, y0, 1);
		x0++;
	}while(x1>=x0);
	/*==========================*/
}
void  GUI_Line(unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1)
{
	int   dx;						// ֱ��x���ֵ����
	int   dy;          			// ֱ��y���ֵ����
	int   dx_sym;					// x����������Ϊ-1ʱ��ֵ����Ϊ1ʱ��ֵ����
	int   dy_sym;					// y����������Ϊ-1ʱ��ֵ����Ϊ1ʱ��ֵ����
	int   dx_x2;					// dx*2ֵ���������ڼӿ������ٶ�
	int   dy_x2;					// dy*2ֵ���������ڼӿ������ٶ�
	int   di;						// ���߱���

	dx = x1-x0;						// ��ȡ����֮��Ĳ�ֵ
	dy = y1-y0;

	/* �ж��������򣬻��Ƿ�Ϊˮƽ�ߡ���ֱ�ߡ��� */
	if(dx>0)							// �ж�x�᷽��
	{  dx_sym = 1;					// dx>0������dx_sym=1
	}
	else
	{  if(dx<0)
	{  dx_sym = -1;				// dx<0������dx_sym=-1
	}
	else
	{  // dx==0������ֱ�ߣ���һ��
		GUI_DrawHLine(x0, y0, y1);
		return;
	}
	}

	if(dy>0)							// �ж�y�᷽��
	{  dy_sym = 1;					// dy>0������dy_sym=1
	}
	else
	{  if(dy<0)
	{  dy_sym = -1;				// dy<0������dy_sym=-1
	}
	else
	{  // dy==0����ˮƽ�ߣ���һ��
		GUI_DrawVLine(x0, y0, x1);
		return;
	}
	}

	/* ��dx��dyȡ����ֵ */
	dx = dx_sym * dx;
	dy = dy_sym * dy;

	/* ����2����dx��dyֵ */
	dx_x2 = dx*2;
	dy_x2 = dy*2;

	/* ʹ��Bresenham�����л�ֱ�� */
	if(dx>=dy)						// ����dx>=dy����ʹ��x��Ϊ��׼
	{
		di = dy_x2 - dx;
		while(x0!=x1)
		{
			GUI_Point(x0, y0,1);
			x0 += dx_sym;
			if(di<0)
			{  di += dy_x2;			// �������һ���ľ���ֵ
			}
			else
			{
				di += dy_x2 - dx_x2;
				y0 += dy_sym;
			}
		}
		GUI_Point(x0, y0,1);		// ��ʾ���һ��
	}
	else								// ����dx<dy����ʹ��y��Ϊ��׼
	{
		di = dx_x2 - dy;
		while(y0!=y1)
		{
			GUI_Point(x0, y0,1);
			y0 += dy_sym;
			if(di<0)
			{  di += dx_x2;
			}
			else
			{  di += dx_x2 - dy_x2;
			x0 += dx_sym;
			}
		}
		GUI_Point(x0, y0,1);		// ��ʾ���һ��
	}

}

void ReadHzkBuff()
{
	int	err;
	int hdrfp;

	hdrfp = open("/user/16",O_RDONLY);
	if(hdrfp == -1)
	{
		exit(1);
	}
	err = read(hdrfp,HzDat,267615);
	close(hdrfp);

}
//******************************************************************************************************************
//* �������ƣ�GUI_SetTextMode()
//* ��    �ܣ����÷�����ʾ
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void GUI_SetTextMode(unsigned char flag)
{
	if(flag)Txmode_flag=1;
	else
		Txmode_flag =0;
}
//******************************************************************************************************************
//* �������ƣ�GUI_DispStringAt()
//* ��    �ܣ���ʾ�ַ���
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void GUI_DispStringAt( unsigned char *format,unsigned int y, unsigned int x)
{
    unsigned char st[64];
    unsigned int i,m,Len;
    unsigned int j,k,l,pos,yp,xp;

	unsigned long int RecPos;
	unsigned long int b1,b2;

    Len = strlen((char *)format);

    delay(5);

	for(l=0;l<Len;l++)
	{
		st[l]=format[l];
	}
    i=0;
	yp=y;
    while(i<Len)
    {
		pos=0xffff;
		if(st[i]<0x80)
		{
			for(j=0;j<sizeof(UsedAsc)/17;j++)   //wsl
			{
				if(st[i]==UsedAsc[j].AnsiCode)
				{
					pos=j;
					break;
				}
			}
			if(pos==0xffff)
			{
				i++;
				continue;
			}
			xp=x;
			for(m=0;m<16;m++)
			{
				for(k=0;k<8;k++)
				{
					if(Txmode_flag)
						GUI_Point(yp+k,xp,(((UsedAsc[pos].Buf[m]>>(7-k))&0x01)^0x01));
					else
						GUI_Point(yp+k,xp,(UsedAsc[pos].Buf[m]>>(7-k))&0x01);
				}

				xp=(xp+1)%LCM_Y;
			}

			yp=(yp+8)%LCM_X;
			i++;
		}
		else
		{
			b1=st[i];
			b2=st[i+1];
			b1-=0xa0;//����
			b2-=0xa0;//λ��
			RecPos = (94*(b1-1)+(b2-1))*32L ;//- 0xb040;

			memcpy((void *)&HzBuf[0],(void *)&HzDat[RecPos], 32);
			k=0;

			xp=x;
			for(m=0;m<16;m++)
			{
				for(k=0;k<8;k++)
				{
					if(Txmode_flag)
						GUI_Point(yp+k,xp,(((HzBuf[m*2]>>(7-k))&0x01)^0x01));
					else
						GUI_Point(yp+k,xp,(HzBuf[m*2]>>(7-k))&0x01);
				}
				for(k=0;k<8;k++)
				{
					if(Txmode_flag)
						GUI_Point(yp+k+8,xp,(((HzBuf[m*2+1]>>(7-k))&0x01)^0x01));
					else
						GUI_Point(yp+k+8,xp,(HzBuf[m*2+1]>>(7-k))&0x01);
				}
				xp=(xp+1)%LCM_Y;
			}
			yp=(yp+16)%LCM_X;
			i+=2;
		}
    }
}
//******************************************************************************************************************
//* �������ƣ�GUI_DispDecAt()
//* ��    �ܣ���ʾ����,������,����ռ1λ
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
//void GUI_DispDecAt(INT32S v,INT8U x,INT8U y,INT8U len)
void GUI_DispDecAt(signed long int v,unsigned char x,unsigned char y,unsigned char len)
{
	unsigned char buf[16];
	memset(buf,0,16);
	switch(len)
	{
	case 1:sprintf((char *)buf,"%01d", v );break;
	case 2:sprintf((char *)buf,"%02d", v );break;
	case 3:sprintf((char *)buf,"%03d", v );break;
	case 4:sprintf((char *)buf,"%04d", v );break;
	case 5:sprintf((char *)buf,"%05d", v );break;
	case 6:sprintf((char *)buf,"%06d", v );break;
	case 7:sprintf((char *)buf,"%07d", v );break;
	case 8:sprintf((char *)buf,"%08d", v );break;
	case 9:sprintf((char *)buf,"%09d", v );break;
	case 10:sprintf((char *)buf,"%10d", v );break;
	case 11:sprintf((char *)buf,"%11d", v );break;
	case 12:sprintf((char *)buf,"%12d", v );break;
	default:break;
	}
	GUI_DispStringAt(buf,x,y);
}
/*******************************************************************************************************************/
//void GUI_DispDecAt(INT32S v,INT8U x,INT8U y,INT8U len)
void GUI_DispHexAt(signed long int v,unsigned char x,unsigned char y,unsigned char len)
{
	unsigned char buf[16];
	memset(buf,0,16);
	switch(len)
	{
	case 1:sprintf((char *)buf,"%01x", v );break;
	case 2:sprintf((char *)buf,"%02x", v );break;
	case 3:sprintf((char *)buf,"%03x", v );break;
	case 4:sprintf((char *)buf,"%04x", v );break;
	case 5:sprintf((char *)buf,"%05x", v );break;
	case 6:sprintf((char *)buf,"%06x", v );break;
	default:break;
	}

	GUI_DispStringAt(buf,x,y);

}
//******************************************************************************************************************
//* �������ƣ�GUI_DispDecShiftAt()
//* ��    �ܣ���ʾС��,������,����ռ1λ,С����ռ1λ
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void GUI_DispDecShiftAt(unsigned char y, unsigned char x,unsigned char Num1,unsigned char Num2,signed long int Num3)
{
	//Ĭ��ascii ��ʹ��8*16����
    unsigned char i,m,Len,st[64],yp,xp;
    unsigned int j,k,l,pos;

    unsigned char format[32];
    float Num4=0;
    memset(format,0,32);
    switch(Num2)
    {
	case 0: Num4 = ((float)Num3)/1;break;
	case 1: Num4 = ((float)Num3)/10;break;
	case 2: Num4 = ((float)Num3)/100;break;
	case 3: Num4 = ((float)Num3)/1000;break;
	case 4: Num4 = ((float)Num3)/10000;break;
	case 5: Num4 = ((float)Num3)/100000;break;
	default: GUI_DispStringAt((INT8U *)"GUI_DispDecShiftAt���ĸ���������(1-5)",0,0); break;
    }
    sprintf((char *)format,"%0*.*f",Num1,Num2,Num4);
    Len = sizeof(format);
    for(l=0;l<Len;l++)
	{
		st[l]=format[l];
	}
    i=0;
	yp=y;
    while(i<Len)
    {
		pos=0xffff;
		if(st[i]<0x80)
		{
			for(j=0;j<sizeof(UsedAsc)/17;j++)   //wsl
			{
				if(st[i]==UsedAsc[j].AnsiCode)
				{
					pos=j;
					break;
				}
			}
			if(pos==0xffff)
			{
				i++;
				continue;
			}
			xp=x;
			for(m=0;m<16;m++)
			{
				for(k=0;k<8;k++)
				{
					GUI_Point(yp+k,xp,(UsedAsc[pos].Buf[m]>>(7-k))&0x01);
				}
				xp=(xp+1)%LCM_Y;
			}
			yp=(yp+8)%LCM_X;
			i++;
		}
    }
}
//******************************************************************************************************************
//* �������ƣ�GUI_DispCharAt()
//* ��    �ܣ�дһ���ַ�
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void GUI_DispCharAt(unsigned char c,unsigned char x,unsigned char y)
{
	unsigned char buf[2];
	memset(buf,0,2);
	buf[0]= c;
	buf[1]='\0';
	GUI_DispStringAt(buf,x,y);
}
//******************************************************************************************************************
//* �������ƣ�LcmClear()
//* ��    �ܣ� ����ʾ
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void LcmClear( void ) {
	memset(LcdBuff,0xff,160*160);
	return;
}
//******************************************************************************************************************
//* �������ƣ�Lcmfull()
//* ��    �ܣ�����д����
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void Lcmfull( void )
{
	SetLcdFun(UPDATE_SCREEN,0);
	delay(50);
	return;//fanzhihong
}

void FillDataFromBuffer(void)
{
	Lcmfull();
}
void GUI_Clear(void)
{
	memset(LcdBuff,0xff,160*160);
}
///******************************************************************************************************************
//* �������ƣ�LCDpoweroff()
//* ��    �ܣ�Һ����ʼ����
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void LCDpoweroff(void)
{
	SetLcdFun(AC_POWER_OFF,0);//�رյ�Դ
}

//******************************************************************************************************************
//* �������ƣ�LCDinit()
//* ��    �ܣ�Һ����ʼ����
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void LCDinit(void)
{
	return;//fanzhihong
}
//******************************************************************************************************************
//* �������ƣ�IOInit()
//* ��    �ܣ���ʼ��Һ������������Ҫ��IO
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void IOInit(void)
{
	if (!PortOpened) {
		OpenGPIO();
	}
    out32(port2,AT91C_PIO_PB20|AT91C_PIO_PB21|AT91C_PIO_PB22|AT91C_PIO_PB23|AT91C_PIO_PB24|AT91C_PIO_PB25);
    out32(port2+0x20,AT91C_PIO_PB20|AT91C_PIO_PB21|AT91C_PIO_PB22|AT91C_PIO_PB23|AT91C_PIO_PB24|AT91C_PIO_PB25);
}

//******************************************************************************************************************
//* �������ƣ�TSSet()
//* ��    �ܣ�ȡʱ��
///* ��ڲ�����
//* ���ڲ�����
//*******************************************************************************************************************/
void TSSet1(TS *ts1)
{
	struct tm new_year;
	struct timespec rtime;
    new_year.tm_year  = ts1->Year - 1900;
    new_year.tm_mon   = ts1->Month-1;
    new_year.tm_mday  = ts1->Day;
    new_year.tm_hour  = ts1->Hour;
    new_year.tm_min   = ts1->Minute;
    new_year.tm_sec   = ts1->Sec;

    new_year.tm_isdst = 0;
    rtime.tv_sec=mktime(&new_year);
    rtime.tv_nsec=0;
    if (clock_settime(CLOCK_REALTIME,&rtime)==-1)
    {
		//printf("\n\r set time erro!!!");
		//printf("\n\r set time erro!!!");
    }
    RtuDataAddr->settime1=1;

}

INT8U SecurityCHK(INT8U flag)
{
	FILE *fp = NULL;
	time_t time_of_day;
	time_t nowtime;
	INT32U tmp;
	INT8U c;
	INT8U rv = 1;
	nowtime= time( NULL );
	if(flag==0)//д�ļ� ��¼�������볬�� ʱ��
	{
		fp=fopen("/nand/save/security.sav","wb+");
		if(fp!=NULL)
		{
			tmp = nowtime;
			c = fwrite(&tmp,4,1,fp);
			fclose(fp);
		}
	}
	else//���ļ� ����ʱ���ж�
	{
		fp=fopen("/nand/save/security.sav","rb");
		if(fp!=NULL)
		{
			fread(&time_of_day,4,1,fp);
			if((nowtime-time_of_day)<(24*60*60))
			{
				GUI_Clear();
				GUI_DispStringAt((INT8U *)"��������!",44,64);
				incount = 0;
				rv = 0;
			}
		}
	}
	if (fp!=NULL)
		fclose(fp);
	return  rv;
}

//*******************************************************************************************************************/
//******************************************************************************************************************
//* �������ƣ�PassPro()
//* ��    �ܣ�ȡʱ��
//* ��ڲ�����
//* ���ڲ�����
//*******************************************************************************************************************/
INT16U PassPro()
{
	unsigned char i,Tpassword[2];
    unsigned int TmpPass=0;
    int rnum;
    INT16U keysele,DelayTime;
    DelayTime=0;
    if(SecurityCHK(1)==1)
    {
		memset(Tpassword,0,2);
		GUI_Clear(); //������

		if (incount>=3)
		{
			SecurityCHK(0);
			return 0;
		}
		GUI_DispStringAt((INT8U *)"��������:",28,64);
		memset(NowInput.buf,0,128);
		sprintf((char *)NowInput.buf,"%02d%02d",   //16���Ƶ�BCD��
			Tpassword[0],Tpassword[1]);  //����ת����Ϊ�ַ���
		i=0;
		while(i<4)
		{
			NowInput.col[i]=64;//y��
			NowInput.row[i]=100+i*8;//x��
			NowInput.set[i]=1;
			i++;
		}
		NowInput.AllNum=5;
		rnum = 0;
		rnum = ScreenInput();
		Tpassword[0]=GetNum(&NowInput.buf[0],2,1);
		Tpassword[1]=GetNum(&NowInput.buf[2],2,1);
		TmpPass=Tpassword[0]*100+Tpassword[1];

		if(rnum == 1)
		{
			if(TmpPass!=PassWord)
			{
				incount++;
				return PassPro();
			}
			else
			{
				incount = 0;
				return 1;
			}
		}
		else
			if((rnum==0)&&(TmpPass == PassWord))
			{
				incount = 0;
				return 1;
			}
			else
				return 0;//2
    }else
    {
		while(1)
		{
			GUI_Clear();
			GUI_DispStringAt((INT8U *)"�������ޣ�",32,60);
			Status_Bar();
			Lcmfull();

			keysele=KeySeleflag;
			KeySeleflag =0;
			if(keysele!=0)
				DelayTime=0;
			else
				DelayTime++;
			if(DelayTime>=PageDelayTime)
			{
				OldLevel=0;
				return 0;
			}
			switch(keysele)
			{
			case 0:DelayTime++;break;
			case 6: OldLevel=0;return 0;break;
			default:break;
			}
		}
    }
    return 0;
}

//******************************************************************************************************************
//* �������ƣ�GetNum()
//* ��    �ܣ���ֵת��������(����ת��)
//* ��ڲ���������1��   ��Ҫ��ת��������
//����������     ����2��   ת���Ժ�ĳ���
//����3��   ת��������ͣ�Flag=1 ʮ�������ָ�ʽ��Flag=2 ʮ���������ָ�ʽ��Flag=3 ʮ���������ָ�ʽ��a��f
//* ���ڲ�����
//*******************************************************************************************************************/

INT16U GetNum(INT8U *s,INT8U len,INT8U Flag)
{
	INT16U t,i;
	t=0;
	for(i=0;i<len;i++)
	{
		if(Flag==1)//���ָ�ʽ
			t=(t*10)+(s[i]-0x30);
		if(Flag==2)//ʮ�����Ƹ�ʽ
			t=(t*16)+(s[i]-0x30);
		if(Flag==3)//ʮ�����Ƹ�ʽ
		{
			if((s[i]>='0')&&(s[i]<='9'))
				t=(t<<4)+(s[i]-0x30);
			if((s[i]>='a')&&(s[i]<='f'))
				t=(t<<4)+(s[i]-87);
			if((s[i]>='A')&&(s[i]<='F'))
				t=(t<<4)+(s[i]-55);
		}
	}
	return t;
}
///******************************************************************************************************************
//* �������ƣ�ScreenInput()
//* ��    �ܣ�Һ������������õĺ���
//* ��ڲ�������
//* ���ڲ���������1��   ��Ҫ���õ��������ַ��������ı�
//����0��   ��Ҫ���õ��������ַ���û�з����ı�
//����0��   ��ʱ�ް������Զ��˳�
//*******************************************************************************************************************/
INT8U ScreenInput(void)
{
	INT8U ix,NowEdit,bufold[128];
	INT16U keysele,DelayTime;
	NowEdit=0;
	DelayTime=0;
	for(ix=0;ix<32;ix++)
	{
		bufold[ix]=NowInput.buf[ix];
	}
	while(1)
	{
		//��ʾ��Ҫ�޸ĵ����ݣ�ͬʱ������ʾĿǰ���ڸĶ������ݡ�
		for(ix=0;ix<NowInput.AllNum;ix++)
		{
			GUI_DispCharAt(NowInput.buf[ix],NowInput.row[ix], NowInput.col[ix]);
		}
		GUI_SetTextMode(GUI_TM_REV);
		GUI_DispCharAt(NowInput.buf[NowEdit],NowInput.row[NowEdit], NowInput.col[NowEdit]);
		GUI_SetTextMode(GUI_TM_NORMAL);
		DelayTime++;
		Status_Bar();

        Lcmfull();

        keysele=KeySeleflag;
        KeySeleflag =0;
		if(keysele!=0)
		{
			DelayTime=0;
		}
		if(DelayTime>=PageDelayTime)  //��ʱ�˳�
		{
			return 0;
		}

		switch(keysele)
		{
			//if(keysele==1) //��
		case 1:
			{
				switch(NowInput.set[NowEdit])
				{
				case 1:
					//if(NowInput.set[NowEdit]==1)
					{
						NowInput.buf[NowEdit]++;
						if(NowInput.buf[NowEdit]>'9')NowInput.buf[NowEdit]='0';
					}
					break;
				case 2:
					//if(NowInput.set[NowEdit]==2)
					{
						{
							if(NowInput.buf[NowEdit]<0x20)
								NowInput.buf[NowEdit]=0x20;

							NowInput.buf[NowEdit]=NowInput.buf[NowEdit]+1;
							if(NowInput.buf[NowEdit]==0x7a)
								NowInput.buf[NowEdit]=0x20;
						}
					}
					break;
				default:break;
				}
			}
			break;
			//if(keysele==2) //��
		case 2:
			{
				switch(NowInput.set[NowEdit])
				{
				case 1:
					//if(NowInput.set[NowEdit]==1)
					{
						if(NowInput.buf[NowEdit]!='0')
							NowInput.buf[NowEdit]--;
						else
							NowInput.buf[NowEdit]='9';
					}
					break;
				case 2:
					//if(NowInput.set[NowEdit]==2)
					{
						{
							//if(NowInput.buf[NowEdit]!=0x20)
							if(NowInput.buf[NowEdit]>0x20)
								NowInput.buf[NowEdit]=NowInput.buf[NowEdit]-1;
							else
								NowInput.buf[NowEdit]=0x7a;  ///z
						}
					}
					break;
				default :break;
				}
			}
			break;
		case 3:
			//if(keysele==3) //��
			{
				if(NowEdit!=0)NowEdit--;
			}
			break;
		case 4:
			//if(keysele==4) //��
			{
				if(NowEdit!=NowInput.AllNum-2)NowEdit++;
			}
			break;
		case 5:
			//if(keysele==5) //ȷ��
			{
				GUI_DispCharAt(NowInput.buf[NowEdit],NowInput.row[NowEdit], NowInput.col[NowEdit]);
				//OSSemPost(FlushSem);
				Lcmfull();

				for(ix=0;ix<NowInput.AllNum;ix++)
				{
					if(bufold[ix]!=NowInput.buf[ix])return 1;
				}
				return 0;
			}
			break;
        case 6:
			//if(keysele==6) //ȡ��
			{
				return 0;
			}
			break;
		default:break;
		}
	}
}

//******************************************************************************************************************
//* �������ƣ�Show_Mainpage()
//* ��    �ܣ�����ʾ������ʼ��ҳ�桿
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void Show_Mainpage(void)
{
	unsigned char datestr[50];
	TS ts;
	memset(datestr,0,50);
   	while (RtuDataAddr->Dev_Init_OK==0)
	{
		delay(1000);
		GUI_DispStringAt((INT8U *)"GK-GPRS200",40,65);
		TSGet(&ts);
		sprintf((char *)datestr,"%d/%d/%d %d:%d",ts.Year,ts.Month,ts.Day,ts.Hour,ts.Minute);
		GUI_DispStringAt(datestr,24,105);
	}
	KeySeleflag=0;
}
//******************************************************************************************************************
//* �������ƣ�Show_Zj_Data()
//* ��    �ܣ���ʾ�ܼ�����
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
INT32S Get_BianBi(INT8U ClNo)
{
	INT32S I,V;
	if(RtuDataAddr->Cl_MenXian_Value[ClNo].F25_Set_Para.Valid==1)
	{
		I=RtuDataAddr->Cl_MenXian_Value[ClNo].F25_Set_Para.I_BeiLv[1];
		I=(I<<8)+RtuDataAddr->Cl_MenXian_Value[ClNo].F25_Set_Para.I_BeiLv[0];
		V=RtuDataAddr->Cl_MenXian_Value[ClNo].F25_Set_Para.V_BeiLv[1];
		V=(V<<8)+RtuDataAddr->Cl_MenXian_Value[ClNo].F25_Set_Para.V_BeiLv[0];
		return I*V;
	}
	else
	{
		return 1;
	}
return 1;
}

//******************************************************************************************************************
//* �������ƣ� BottomBar()
//* ��    �ܣ����ݲ�ͬ��ҳ����ʾ�������Ҽ�ͷ
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/

void BottomBar()
{
	INT8U str[2];
	if (a_up==1)
    {
		str[0]=0x7e;
		GUI_DispStringAt(str, 130, 144);
    }
    if (a_down==1)
    {
		str[0]=0x7f;
		GUI_DispStringAt(str, 130, 144);
    }
    if ((a_up==1)&&(a_down==1))
    {
		str[0]=0x7d;
		GUI_DispStringAt(str, 130, 144);
    }
    if (a_left==1)
    {
		str[0]=0x17;
		GUI_DispStringAt(str, 122, 144);
    }
    if (a_right ==1)
    {
		str[0]=0x16;
		GUI_DispStringAt(str, 138, 144);
    }
}
int Show_Zj_Data(INT8U SeleMenu)
{
	unsigned char keysele,i,j;
	unsigned int DelayTime;
	// GUI_Clear();
	DelayTime=0;
	j=i=0;
	a_up = a_down =  1;
	a_right = a_left = 0;

	while(1)
	{
		Lcmpower();
		GUI_Clear();
		if(i<8)
		{
			GUI_DispStringAt((INT8U *)"�ܼ��� :",54,16);
			GUI_DispDecAt(i+1, 102, 16, 1);
			GUI_DispStringAt((INT8U *)"�й�:",16,46);GUI_DispDecShiftAt(60,46,8,3,RtuDataAddr->Real_Zj_Value[i].P);GUI_DispStringAt((INT8U *)"kw",128,46);
			GUI_DispStringAt((INT8U *)"�޹�:",16,66);GUI_DispDecShiftAt(60,66,8,3,RtuDataAddr->Real_Zj_Value[i].Q);GUI_DispStringAt((INT8U *)"kvar",128,66);

		}
		else
		{
			GUI_DispStringAt((INT8U *)"�� ·����:",40,16);
			GUI_DispDecAt(i-7, 56, 16, 1);
			j = RtuDataAddr->MaiCongSetPara.MaiChong[i-8].CeLiangNo-1;
			GUI_DispStringAt((INT8U *)"�����������:",16,32);
			if(j<8)
				GUI_DispDecAt(j+1, 120, 32, 1);
			GUI_DispStringAt((INT8U *)"�й�:",16,62);GUI_DispDecShiftAt(60,62,8,3,(RtuDataAddr->DD_Device_BiaoShi_Value[j].P*Get_BianBi(j)/10));GUI_DispStringAt((INT8U *)"kw",128,62);
			GUI_DispStringAt((INT8U *)"�޹�:",16,82);GUI_DispDecShiftAt(60,82,8,3,(RtuDataAddr->DD_Device_BiaoShi_Value[j].Q*Get_BianBi(j)/10));GUI_DispStringAt((INT8U *)"kvar",128,82);
		}
		Status_Bar();
		BottomBar();
		Lcmfull();
		keysele=KeySeleflag;
		KeySeleflag =0;
		if(DelayTime>=PageDelayTime)
		{
			OldLevel=0;
			return 0;
		}
		switch(keysele)
		{
		case 0:DelayTime++;break;
		case 1: if(i==0) i=9; else i=(i-1)%10; DelayTime=0;break;
		case 2: i=(i+1)%(ZongJia_Max+2) ;DelayTime=0;break;
		case 3: DelayTime=0;break;
		case 4: DelayTime=0;break;
		case 5:  DelayTime=0;break;
		case 6: OldLevel=0;return 0;break;
		default:break;
		}
	}
}

/******************************************************************************************************************
* �������ƣ�Show_Golv_QuXian()
* ���ܣ���ʾ��������
* ��ڲ�������
* ���ڲ�������
*
******************************************************************************************************************/
int FindMax(int *maxarray)
{
	int i,j , max=0;
	for (i=0;i<CeLiangPoint_Max;i++)
	{
		for (j=0;j<96;j++)
		{
			if (maxarray[i]<RtuDataAddr->QX_DD_Device_BiaoShi_Value[i][j].P)
				maxarray[i] = RtuDataAddr->QX_DD_Device_BiaoShi_Value[i][j].P;
		}
		if (max<maxarray[i])
			max = maxarray[i];
	}
	return max;
}
void DrawMaxFlag(signed int x)
{
	GUI_Point(36,(125-x),1);
	GUI_Point(37,(125-x),1);
	GUI_Point(38,(125-x),1);
	GUI_Point(39,(125-x),1);

	GUI_Point(37,(125-(x-2)),1);
	GUI_Point(37,(125-(x+2)),1);
	GUI_Point(38,(125-(x-1)),1);
	GUI_Point(38,(125-(x+1)),1);//����ļ�ͷ
	GUI_DispStringAt((INT8U *)"H",20,(125-x));

}
int Show_Golv_QuXian(INT8U SeleMenu)
{
	unsigned char keysele;
	unsigned int DelayTime,i,j;
	signed int Golv_Max,x;
	signed int qxgl_max[8];
	DelayTime=0;
	i=0;
	Golv_Max=0;
	memset(qxgl_max,0,sizeof(int)*8);
	while(1)
	{
		Lcmpower();
		Golv_Max= FindMax(qxgl_max);

		GUI_Clear();
		GUI_DispStringAt((INT8U *)"��",0,40);
		GUI_DispStringAt((INT8U *)"��",0,60);
		GUI_DispStringAt((INT8U *)"��",0,80);
		GUI_DispDecAt(i+1, 0, 100, 2);
		GUI_DispStringAt((INT8U *)"P ",16,16);
		GUI_DispStringAt((INT8U *)"H=",40,16);
		GUI_DispDecShiftAt(56,16,7,4,qxgl_max[i]);
		GUI_DispStringAt((INT8U *)"kw",120,16);

		GUI_DrawVLine( 40,  45, 125);//������
		GUI_DrawHLine( 40, 125, 140);//������

		GUI_Point(39,(125-79),1);
		GUI_Point(38,(125-78),1);
		GUI_Point(41,(125-79),1);
		GUI_Point(42,(125-78),1);//����ļ�ͷ

		GUI_Point(139,(124),1);
		GUI_Point(139,(126),1);
		GUI_Point(138,(123),1);
		GUI_Point(138,(127),1);//����ļ�ͷ
		GUI_DispStringAt((INT8U *)"h",148,128);

		for(j=0;j<96;j++)
		{
			if(Golv_Max!=0)
				x=(RtuDataAddr->QX_DD_Device_BiaoShi_Value[i][j].P*70)/Golv_Max;
			else
				x=0;
			GUI_Point((40+j),(125-x),1);
		}
		if (Golv_Max!=0)
			DrawMaxFlag(70*qxgl_max[i]/Golv_Max);

		GUI_Point(40,126,1);
		GUI_Point(40,127,1);
		GUI_Point(88,126,1);
		GUI_Point(88,127,1);
		GUI_Point(136,126,1);
		GUI_Point(136,127,1);
		GUI_DispStringAt((INT8U *)"0",40,128);
		GUI_DispStringAt((INT8U *)"12",80,128);
		GUI_DispStringAt((INT8U *)"24",128,128);
		Status_Bar();
		Lcmfull();
		keysele=KeySeleflag;
		KeySeleflag =0;
		if(DelayTime>=PageDelayTime)
		{
			OldLevel=0;
			return 0;
		}
		switch(keysele)
		{
			case 0:DelayTime++;break;
			case 1: if(i==0) i=7; else i=(i-1)%8; DelayTime=0;break;
			case 2: i=(i+1)%ZongJia_Max ;DelayTime=0;break;
			case 3: DelayTime=0;break;
			case 4: DelayTime=0;break;
			case 5:  DelayTime=0;break;
			case 6: OldLevel=0;return 0;break;
			default:break;
		}
	}
}
//******************************************************************************************************************
//* �������ƣ�Show_Zj_DianLiang()
//* ��    �ܣ���ʾ�ܼ�����
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
int Show_Zj_DianLiang(INT8U SeleMenu)
{
	unsigned char keysele,i,j;
	unsigned int DelayTime;
	// GUI_Clear();
	DelayTime=0;
	j=i=0;
	a_up = a_down =  1;
	a_right = a_left = 1;

	while(1)
	{
		Lcmpower();
		GUI_Clear();

		switch(j)
		{
		case 0:
			GUI_DispStringAt((INT8U *)"���յ��� ",28,16);
			GUI_DispStringAt((INT8U *)"�ܼ��� :",0,32);
			GUI_DispDecAt(i+1, 48, 32, 1);

			//GUI_DispStringAt("�й�:",0,32);GUI_DispDecShiftAt(40,32,7,3,RtuDataAddr->Day_Zj_Value[i].P);
			GUI_DispStringAt((INT8U *)"P��:",2,48);GUI_DispDecShiftAt(40,48,10,0,(RtuDataAddr->Real_Zj_Value[i].P_All-RtuDataAddr->Day_Zj_Value[i].P_All));
			GUI_DispStringAt((INT8U *)"P��:",2,64);GUI_DispDecShiftAt(40,64,10,0,(RtuDataAddr->Real_Zj_Value[i].P_F[0]-RtuDataAddr->Day_Zj_Value[i].P_F[0]));
			GUI_DispStringAt((INT8U *)"P��:",2,80);GUI_DispDecShiftAt(40,80,10,0,(RtuDataAddr->Real_Zj_Value[i].P_F[1]-RtuDataAddr->Day_Zj_Value[i].P_F[1]));
			GUI_DispStringAt((INT8U *)"Pƽ:",2,96);GUI_DispDecShiftAt(40,96,10,0,(RtuDataAddr->Real_Zj_Value[i].P_F[2]-RtuDataAddr->Day_Zj_Value[i].P_F[2]));
			GUI_DispStringAt((INT8U *)"P��:",2,112);GUI_DispDecShiftAt(40,112,10,0,(RtuDataAddr->Real_Zj_Value[i].P_F[3]-RtuDataAddr->Day_Zj_Value[i].P_F[3]));
			GUI_DispStringAt((INT8U *)"Q��:",2,128);GUI_DispDecShiftAt(40,128,7,0,(RtuDataAddr->Real_Zj_Value[i].Q_All-RtuDataAddr->Day_Zj_Value[i].Q_All));

			GUI_DispStringAt((INT8U *)"kwh",132,48);
			GUI_DispStringAt((INT8U *)"kwh",132,64);
			GUI_DispStringAt((INT8U *)"kwh",132,80);
			GUI_DispStringAt((INT8U *)"kwh",132,96);
			GUI_DispStringAt((INT8U *)"kwh",132,112);
			GUI_DispStringAt((INT8U *)"kvarh",116,128);
	           break;

		case 1:

			GUI_DispStringAt((INT8U *)"���µ���",28,16);
			GUI_DispStringAt((INT8U *)"�ܼ��� :",0,32);

			GUI_DispDecAt(i+1, 48, 32, 1);

			//GUI_DispStringAt("�й�:",0,32);GUI_DispDecShiftAt(40,32,7,3,RtuDataAddr->Yue_Zj_Value[i].P);
			GUI_DispStringAt((INT8U *)"P��:",2,48);GUI_DispDecShiftAt(40,48,10,0,(RtuDataAddr->Real_Zj_Value[i].P_All-RtuDataAddr->Yue_Zj_Value[i].P_All));
			GUI_DispStringAt((INT8U *)"P��:",2,64);GUI_DispDecShiftAt(40,64,10,0,(RtuDataAddr->Real_Zj_Value[i].P_F[0]-RtuDataAddr->Yue_Zj_Value[i].P_F[0]));
			GUI_DispStringAt((INT8U *)"P��:",2,80);GUI_DispDecShiftAt(40,80,10,0,(RtuDataAddr->Real_Zj_Value[i].P_F[1]-RtuDataAddr->Yue_Zj_Value[i].P_F[1]));
			GUI_DispStringAt((INT8U *)"Pƽ:",2,96);GUI_DispDecShiftAt(40,96,10,0,(RtuDataAddr->Real_Zj_Value[i].P_F[2]-RtuDataAddr->Yue_Zj_Value[i].P_F[2]));
			GUI_DispStringAt((INT8U *)"P��:",2,112);GUI_DispDecShiftAt(40,112,10,0,(RtuDataAddr->Real_Zj_Value[i].P_F[3]-RtuDataAddr->Yue_Zj_Value[i].P_F[3]));
			GUI_DispStringAt((INT8U *)"Q��:",2,128);GUI_DispDecShiftAt(40,128,7,0,(RtuDataAddr->Real_Zj_Value[i].Q_All-RtuDataAddr->Yue_Zj_Value[i].Q_All));

			//GUI_DispStringAt("kwh",132,32);
			GUI_DispStringAt((INT8U *)"kwh",132,48);
			GUI_DispStringAt((INT8U *)"kwh",132,64);
			GUI_DispStringAt((INT8U *)"kwh",132,80);
			GUI_DispStringAt((INT8U *)"kwh",132,96);
			GUI_DispStringAt((INT8U *)"kwh",132,112);
			GUI_DispStringAt((INT8U *)"kvarh",116,128);
	           break;

		default: break;

		}
		Status_Bar();
		BottomBar();
		Lcmfull();
		keysele=KeySeleflag;
		KeySeleflag =0;
		if(DelayTime>=PageDelayTime)
		{
			OldLevel=0;
			return 0;
		}
		switch(keysele)
		{
		case 0:DelayTime++;break;
		case 1: if(i==0) i=7; else i=(i-1)%8; DelayTime=0;break;
		case 2: i=(i+1)%ZongJia_Max ;DelayTime=0;break;
		case 3: j=(j+1)%2;DelayTime=0;break;
		case 4: j=(j+1)%2;DelayTime=0;break;
		case 5:  DelayTime=0;break;
		case 6: OldLevel=0;return 0;break;
		default:break;
		}
		  }



}

//******************************************************************************************************************
//* �������ƣ�Show_SYDL()
//* ��    �ܣ���ʾʣ��������գ����ܵ���
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void Show_SYDLV(unsigned int SYDL)
{
    //GUI_Clear();
    if(LunXianCount<LunXianTime)RunArrow(2);
    GUI_DispStringAt((INT8U *)"ʣ�����:",16,32);
    GUI_DispDecShiftAt(16,48,8,0,SYDL);GUI_DispStringAt((INT8U *)"kwh",104,48);
}
void Show_SYDLN(unsigned int SYDL)
{
    //GUI_Clear();
    if(LunXianCount<LunXianTime)RunArrow(2);
    GUI_DispStringAt((INT8U *)"ʣ�����:",16,32);
    GUI_DispStringAt((INT8U *)"��Ч��",16,48);
}
void Show_YDDL(unsigned int D_PAll,unsigned int Y_PAll)
{
    GUI_DispStringAt((INT8U *)"���ܵ���: ",16,64);
    GUI_DispDecShiftAt(16,80,8,0,D_PAll);GUI_DispStringAt((INT8U *)"kwh",104,80);
    GUI_DispStringAt((INT8U *)"���ܵ���: ",16,96);
    GUI_DispDecShiftAt(16,112,8,0,Y_PAll);GUI_DispStringAt((INT8U *)"kwh",104,112);

}

//******************************************************************************************************************
//* �������ƣ�Show_ZX_YOUGONG()
//* ��    �ܣ���ʾ�����й� �ܼ���ƽ
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void Show_ZX_YOUGONG(unsigned int Z_ZAll,unsigned int Z_JAll,unsigned int Z_FAll,unsigned int Z_GAll,unsigned int Z_PAll,unsigned char POINT)
{
    //GUI_Clear();
    if(LunXianCount<LunXianTime)RunArrow(2);
    GUI_DispStringAt((INT8U *)"�����й�����ʾֵ",16,16);
	//GUI_DispDecShiftAt(y ,x ,...)
    GUI_DispStringAt((INT8U *)"��: ",16,33);GUI_DispDecShiftAt(40,32,9,2,Z_ZAll);GUI_DispStringAt((INT8U *)"kwh",116,32);
    GUI_DispStringAt((INT8U *)"��: ",16,49);GUI_DispDecShiftAt(40,48,9,2,Z_JAll);GUI_DispStringAt((INT8U *)"kwh",116,48);
    GUI_DispStringAt((INT8U *)"��: ",16,65);GUI_DispDecShiftAt(40,64,9,2,Z_FAll);GUI_DispStringAt((INT8U *)"kwh",116,64);
    GUI_DispStringAt((INT8U *)"ƽ: ",16,81);GUI_DispDecShiftAt(40,80,9,2,Z_GAll);GUI_DispStringAt((INT8U *)"kwh",116,80);
    GUI_DispStringAt((INT8U *)"��: ",16,97);GUI_DispDecShiftAt(40,96,9,2,Z_PAll);GUI_DispStringAt((INT8U *)"kwh",116,96);

    GUI_DispStringAt((INT8U *)"����ʱ��",48,111);
    GUI_DispStringAt((INT8U *)"��  ��  ��  ʱ  ��",16,126);
    GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD05 ,0,126,2);
	GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD04 ,32,126,2);
	GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD03 ,64,126,2);
	GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD02 ,96,126,2);
	GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD01 ,128,126,2);
}
//******************************************************************************************************************
//* �������ƣ�Show_FX_YOUGONG()
//* ��    �ܣ���ʾ�����й� �ܼ���ƽ
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/

void Show_FX_YOUGONG(unsigned int Z_ZAll,unsigned int Z_JAll,unsigned int Z_FAll,unsigned int Z_GAll,unsigned int Z_PAll,unsigned char POINT)
{
    //GUI_Clear();
    if(LunXianCount<LunXianTime)
		RunArrow(3);
    GUI_DispStringAt((INT8U *)"�����й�����ʾֵ",16,16);
	//GUI_DispDecShiftAt(y ,x ,...)
    GUI_DispStringAt((INT8U *)"��: ",16,33);GUI_DispDecShiftAt(40,32,9,2,Z_ZAll);GUI_DispStringAt((INT8U *)"kwh",116,32);
    GUI_DispStringAt((INT8U *)"��: ",16,49);GUI_DispDecShiftAt(40,48,9,2,Z_JAll);GUI_DispStringAt((INT8U *)"kwh",116,48);
    GUI_DispStringAt((INT8U *)"��: ",16,65);GUI_DispDecShiftAt(40,64,9,2,Z_FAll);GUI_DispStringAt((INT8U *)"kwh",116,64);
    GUI_DispStringAt((INT8U *)"ƽ: ",16,81);GUI_DispDecShiftAt(40,80,9,2,Z_GAll);GUI_DispStringAt((INT8U *)"kwh",116,80);
    GUI_DispStringAt((INT8U *)"��: ",16,97);GUI_DispDecShiftAt(40,96,9,2,Z_PAll);GUI_DispStringAt((INT8U *)"kwh",116,96);

    GUI_DispStringAt((INT8U *)"����ʱ��",48,111);

    GUI_DispStringAt((INT8U *)"��  ��  ��  ʱ  ��",16,126);
    GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD05 ,0,126,2);
	GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD04 ,32,126,2);
	GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD03  ,64,126,2);
	GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD02  ,96,126,2);
	GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD01 ,128,126,2);




}
///******************************************************************************************************************
//* �������ƣ�Show_ZX_WUGONG()
//* ��    �ܣ���ʾ�����޹� �ܼ���ƽ
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void Show_ZX_WUGONG(INT32U Z_ZAll,INT32U Z_JAll,INT32U Z_FAll,INT32U Z_GAll,INT32U Z_PAll,INT8U POINT)
{
    //GUI_Clear();
    if(LunXianCount<LunXianTime)RunArrow(3);
	GUI_DispStringAt((INT8U *)"�����޹�����ʾֵ",16,16);
	//GUI_DispDecShiftAt(y ,x ,...)
    GUI_DispStringAt((INT8U *)"��: ",16,33);GUI_DispDecShiftAt(40,32,9,2,Z_ZAll);GUI_DispStringAt((INT8U *)"kwh",116,32);
    GUI_DispStringAt((INT8U *)"��: ",16,49);GUI_DispDecShiftAt(40,48,9,2,Z_JAll);GUI_DispStringAt((INT8U *)"kwh",116,48);
    GUI_DispStringAt((INT8U *)"��: ",16,65);GUI_DispDecShiftAt(40,64,9,2,Z_FAll);GUI_DispStringAt((INT8U *)"kwh",116,64);
    GUI_DispStringAt((INT8U *)"ƽ: ",16,81);GUI_DispDecShiftAt(40,80,9,2,Z_GAll);GUI_DispStringAt((INT8U *)"kwh",116,80);
    GUI_DispStringAt((INT8U *)"��: ",16,97);GUI_DispDecShiftAt(40,96,9,2,Z_PAll);GUI_DispStringAt((INT8U *)"kwh",116,96);

    GUI_DispStringAt((INT8U *)"����ʱ��",48,111);

    GUI_DispStringAt((INT8U *)"��  ��  ��  ʱ  ��",16,126);
	GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD05 ,0,126,2);
				GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD04 ,32,126,2);
				GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD03 ,64,126,2);
				GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD02 ,96,126,2);
				GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD01 ,128,126,2);



}
//******************************************************************************************************************
//* �������ƣ�Show_FX_WUGONG()
//* ��    �ܣ���ʾ�����޹� �ܼ���ƽ
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void Show_FX_WUGONG(INT32U Z_ZAll,INT32U Z_JAll,INT32U Z_FAll,INT32U Z_GAll,INT32U Z_PAll,INT8U POINT)
{
    //GUI_Clear();
    if(LunXianCount<LunXianTime)RunArrow(3);
    GUI_DispStringAt((INT8U *)"�����޹�����ʾֵ",16,16);
	//GUI_DispDecShiftAt(y ,x ,...)
    GUI_DispStringAt((INT8U *)"��: ",16,33);GUI_DispDecShiftAt(40,32,9,2,Z_ZAll);GUI_DispStringAt((INT8U *)"kwh",116,32);
    GUI_DispStringAt((INT8U *)"��: ",16,49);GUI_DispDecShiftAt(40,48,9,2,Z_JAll);GUI_DispStringAt((INT8U *)"kwh",116,48);
    GUI_DispStringAt((INT8U *)"��: ",16,65);GUI_DispDecShiftAt(40,64,9,2,Z_FAll);GUI_DispStringAt((INT8U *)"kwh",116,64);
    GUI_DispStringAt((INT8U *)"ƽ: ",16,81);GUI_DispDecShiftAt(40,80,9,2,Z_GAll);GUI_DispStringAt((INT8U *)"kwh",116,80);
    GUI_DispStringAt((INT8U *)"��: ",16,97);GUI_DispDecShiftAt(40,96,9,2,Z_PAll);GUI_DispStringAt((INT8U *)"kwh",116,96);

    GUI_DispStringAt((INT8U *)"����ʱ��",48,111);

    GUI_DispStringAt((INT8U *)"��  ��  ��  ʱ  ��",16,126);
	GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD05 ,0,126,2);
				GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD04 ,32,126,2);
				GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD03   ,64,126,2);
				GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD02  ,96,126,2);
				GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD01 ,128,126,2);



}
//******************************************************************************************************************
//* �������ƣ�Show_UI()
//* ��    �ܣ���ʾ������ѹ
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void Show_UI(INT32U Ua,INT32U Ub,INT32U Uc,INT32U Ia,INT32U Ib,INT32U Ic,INT8U POINT)
{
	// GUI_Clear();
    if(LunXianCount<LunXianTime)RunArrow(3);
    GUI_DispStringAt((INT8U *)"��ѹ(V)",52,16);
    GUI_DispStringAt((INT8U *)"Ua/Uab:    ",16,32);
    GUI_DispDecShiftAt(96,32,5,1,Ua);
    GUI_DispStringAt((INT8U *)"Ub/Ubc:    ",16,48);
    GUI_DispDecShiftAt(96,48,5,1,Ub);
    GUI_DispStringAt((INT8U *)"Uc/Uca:    ",16,64);
    GUI_DispDecShiftAt(96,64,5,1,Uc);


    GUI_DispStringAt((INT8U *)"����(A)",52,80);
    GUI_DispStringAt((INT8U *)"Ia:  ",32,96);
    GUI_DispDecShiftAt(96,96,5,2,Ia);
    GUI_DispStringAt((INT8U *)"Ib:  ",32,112);
    GUI_DispDecShiftAt(96,112,5,2,Ib);
    GUI_DispStringAt((INT8U *)"Ic:  ",32,128);
    GUI_DispDecShiftAt(96,128,5,2,Ic);

}
//******************************************************************************************************************
//* �������ƣ�Show_PQC()
//* ��    �ܣ���ʾ�С��ѡ��ãϣ�
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void Show_PQC(INT32U P,INT32U Q,INT32U Cos,INT8U POINT)
{
    //GUI_Clear();
    if(LunXianCount<LunXianTime)RunArrow(3);
	//GUI_DispDecShiftAt(y ,x ,...)
    GUI_DispStringAt((INT8U *)"�й�����(Kw)",32,16);
    GUI_DispDecShiftAt(56,32,7,1,P);

    GUI_DispStringAt((INT8U *)"�޹�����(Kavr)",24,48);
    GUI_DispDecShiftAt(56,64,7,1,Q);

    GUI_DispStringAt((INT8U *)"��������",48,80);
    GUI_DispDecShiftAt(64,96,5,3,Cos);

    GUI_DispStringAt((INT8U *)"����ʱ��",48,111);
    GUI_DispStringAt((INT8U *)"��  ��  ��  ʱ  ��",16,126);
	GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD05 ,0,126,2);
				GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD04 ,32,126,2);
				GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD03   ,64,126,2);
				GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD02  ,96,126,2);
				GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD01 ,128,126,2);


}
//******************************************************************************************************************
//* �������ƣ�Show_ZXU()
//* ��    �ܣ���ʾ�����������ʱ��
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/

void Show_ZXU(INT32U P,INT32U Q,INT8U POINT)
{

	// GUI_Clear();
    if(LunXianCount<LunXianTime)RunArrow(1);
    GUI_DispStringAt((INT8U *)"�������������ʱ��",8,18);
    GUI_DispStringAt((INT8U *)"�����й�(Kw)",32,36);
    GUI_DispDecShiftAt(52,54,7,4,P);
   	GUI_DispStringAt((INT8U *)"  ��  ��  ʱ  ��",16,72);

   	GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[POINT].Time_Z_P_X_All[0],16,72,2);
	GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[POINT].Time_Z_P_X_All[1],48,72,2);
	GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[POINT].Time_Z_P_X_All[2],80,72,2);
	GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[POINT].Time_Z_P_X_All[3],112,72,2);


    GUI_DispStringAt((INT8U *)"�����й�(Kw)",32,90);
    GUI_DispDecShiftAt(52,108,7,4,Q);
    GUI_DispStringAt((INT8U *)"  ��  ��  ʱ  ��",16,126);

    GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[POINT].Time_F_P_X_All[0],16,126,2);
	GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[POINT].Time_F_P_X_All[1],48,126,2);
	GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[POINT].Time_F_P_X_All[2],80,126,2);
	GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[POINT].Time_F_P_X_All[3],112,126,2);


}

//******************************************************************************************************************
//* �������ƣ�XiuMeterNum()�����ڵ�һ���˵�
//* ��    �ܣ�����Ҫ�鿴�ı������
///* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void XiuMeterNum(unsigned char SeleMenu)
{

	unsigned char i;
	memset(NowInput.buf,0,128);
	sprintf((char *)NowInput.buf,"%02d",ChakanMeterNum);  //����ת����Ϊ�ַ���

	i=0;
	while(i<2)
	{
			     NowInput.col[i]=54;//y��
				 NowInput.row[i]=72+i*8;//x��
				 NowInput.set[i]=1;
				 i++;
	}

	NowInput.AllNum=3;
	if(ScreenInput()==1)
	{
		ChakanMeterNum = GetNum(&NowInput.buf[0],2,1);
		if(ChakanMeterNum>=DD_Device_Max)ChakanMeterNum=DD_Device_Max-1;

	}


}
//******************************************************************************************************************
//* �������ƣ�XiuMeterSetNum()�����ڵ�һ���˵�
//* ��    �ܣ�����Ҫ�鿴�ı������
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void XiuMeterSetNum(unsigned char SeleMenu)
{
/*
unsigned char i;
memset(NowInput.buf,0,128);
sprintf(NowInput.buf,"%02d",ChakanMeterSetNum);  //����ת����Ϊ�ַ���
i=0;
while(i<2)
{
NowInput.col[i]=74;//y��
NowInput.row[i]=72+i*8;//x��
NowInput.set[i]=1;
i++;
}

		NowInput.AllNum=3;
		if(ScreenInput()==1)
		{
		ChakanMeterSetNum = GetNum(&NowInput.buf[0],2,1);
		if(ChakanMeterSetNum>=DD_Device_Max)ChakanMeterSetNum=DD_Device_Max-1;
		}
	*/
}
//******************************************************************************************************************
//* �������ƣ�XiuMeterMaichongNum()�����ڵ�һ���˵�
//* ��    �ܣ�����Ҫ�޸ĵı��������� �����ű���MaichongNumΪ1-4��������F11_Set_Para.MaiChong[n]nΪ0-3
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void XiuMeterMaichongNum(unsigned char SeleMenu)
{
/*
unsigned char i;
memset(NowInput.buf,0,128);
sprintf(NowInput.buf,"%02d",MaichongNum);  //����ת����Ϊ�ַ���
i=0;
while(i<2)
{
NowInput.col[i]=54;//y��
NowInput.row[i]=72+i*8;//x��
NowInput.set[i]=1;
i++;
}

		NowInput.AllNum=3;
		if(ScreenInput()==1)
		{
		MaichongNum = GetNum(&NowInput.buf[0],2,1);
		if(MaichongNum>MaiChong_Max)	MaichongNum=MaiChong_Max;
		if((MaichongNum<1)||(MaichongNum==0))	MaichongNum=1;
}*/
}
//******************************************************************************************************************
//* �������ƣ�Fb_XiuMaichongNum()�����ڵڶ����˵�
//* ��    �ܣ������ס����ġ��鿴���š�
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void Fb_XiuMaichongNum(INT8U SelMenu)
{

    memset(NowInput.buf,0,128);
	sprintf((char *)NowInput.buf,"%02d",MaichongNum);  //����ת����Ϊ�ַ���

	if(SelMenu==62)
	{
		GUI_SetTextMode(GUI_TM_REV);
		GUI_DispStringAt(NowInput.buf,72,54);
	}
	else
		GUI_DispStringAt(NowInput.buf,72,54);
	GUI_SetTextMode(GUI_TM_NORMAL);

	if(SelMenu==63)
	{
		GUI_SetTextMode(GUI_TM_REV);
		GUI_DispStringAt((INT8U *)"�����޸�",48,76);
	}
	else
		GUI_DispStringAt((INT8U *)"�����޸�",48,76);
	GUI_SetTextMode(GUI_TM_NORMAL);
}

//******************************************************************************************************************
//* �������ƣ�XiuRenWuType()�����ڵ�һ���˵�
//* ��    �ܣ�����Ҫ�鿴�ı������
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void XiuRenWuType(unsigned char SeleMenu)
{

	unsigned char i;
	memset(NowInput.buf,0,128);
	sprintf((char *)NowInput.buf,"%1d",RenWuType);  //����ת����Ϊ�ַ���
	i=0;
	while(i<2)
	{
			     NowInput.col[i]=44;//y��
				 NowInput.row[i]=104+i*8;//x��
				 NowInput.set[i]=1;
				 i++;
	}

	NowInput.AllNum=3;
	if(ScreenInput()==1)
	{
		RenWuType = GetNum(&NowInput.buf[0],2,1);
		if(RenWuType>=64)RenWuType=64-1;
	}
}

//******************************************************************************************************************
//* �������ƣ�XiuRenWuNum()�����ڵ�һ���˵�
//* ��    �ܣ�����Ҫ�鿴�ı������
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void XiuRenWuNum(unsigned char SeleMenu)
{

	unsigned char i;
	memset(NowInput.buf,0,128);
	sprintf((char *)NowInput.buf,"%1d",RenWuType);  //����ת����Ϊ�ַ���
	i=0;
	while(i<1)
	{
			     NowInput.col[i]=44;//y��
				 NowInput.row[i]=104+i*8;//x��
				 NowInput.set[i]=1;
				 i++;
	}
	NowInput.AllNum=3;
	if(ScreenInput()==1)
	{
		RenWuType = GetNum(&NowInput.buf[0],2,1);
		if(RenWuType>=2)RenWuType=2-1;
	}
	memset(NowInput.buf,0,128);
	sprintf((char *)NowInput.buf,"%02d",RenWuNum);  //����ת����Ϊ�ַ���
	i=0;
	while(i<2)
	{
			     NowInput.col[i]=64;//y��
				 NowInput.row[i]=104+i*8;//x��
				 NowInput.set[i]=1;
				 i++;
	}

	NowInput.AllNum=3;
	if(ScreenInput()==1)
	{
		RenWuNum = GetNum(&NowInput.buf[0],2,1);
		if(RenWuNum>=64)RenWuNum=64-1;
	}
}
//******************************************************************************************************************
//*/ �������ƣ�Fb_XiuRenWuType()�����ڵ�һ���˵�
///* ��    �ܣ�����Ҫ�鿴�ı������
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void Fb_XiuRenWuType(INT8U SelMenu)
{

    memset(NowInput.buf,0,128);
	sprintf((char *)NowInput.buf,"%1d",RenWuNum);  //����ת����Ϊ�ַ���

	if(SelMenu==77)
	{
		GUI_SetTextMode(GUI_TM_REV);
		GUI_DispStringAt(NowInput.buf,104,44);
	}
	else
		GUI_DispStringAt(NowInput.buf,104,44);
	GUI_SetTextMode(GUI_TM_NORMAL);

	if(SelMenu==79)
	{
		GUI_SetTextMode(GUI_TM_REV);
		GUI_DispStringAt((INT8U *)"����",48,76);
	}
	else
		GUI_DispStringAt((INT8U *)"����",48,76);
	GUI_SetTextMode(GUI_TM_NORMAL);
}
///******************************************************************************************************************
//* �������ƣ�Fb_XiuRenWuNum()�����ڵ�һ���˵�
//* ��    �ܣ�����Ҫ�鿴�ı������
//* ��ڲ�������
//* ���ڲ�������
///*******************************************************************************************************************/
void Fb_XiuRenWuNum(INT8U SelMenu)
{
	memset(NowInput.buf,0,128);
	sprintf((char *)NowInput.buf,"%1d",RenWuNum);  //����ת����Ϊ�ַ���

	if(SelMenu==77)
	{
		GUI_SetTextMode(GUI_TM_REV);
		GUI_DispStringAt(NowInput.buf,104,44);
	}
	else
		GUI_DispStringAt(NowInput.buf,104,44);
	 	 GUI_SetTextMode(GUI_TM_NORMAL);

		 memset(NowInput.buf,0,128);
		 sprintf((char *)NowInput.buf,"%02d",RenWuNum);  //����ת����Ϊ�ַ���

		 if(SelMenu==78)
		 {
			 GUI_SetTextMode(GUI_TM_REV);
			 GUI_DispStringAt(NowInput.buf,104,64);
		 }
		 else
			 GUI_DispStringAt(NowInput.buf,104,64);
		 GUI_SetTextMode(GUI_TM_NORMAL);

		 if(SelMenu==79)
		 {
			 GUI_SetTextMode(GUI_TM_REV);
			 GUI_DispStringAt((INT8U *)"����",48,76);
		 }
		 else
			 GUI_DispStringAt((INT8U *)"����",48,76);
		 GUI_SetTextMode(GUI_TM_NORMAL);
}
//******************************************************************************************************************
//* �������ƣ�Fb_XiuMaichong()�����ڵڶ����˵�
//* ��    �ܣ������ס����ġ��鿴���š�
//*/ ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void Fb_XiuMaichong(INT8U SelMenu)
{
	INT8U TempBuf[16];
	INT32U num;

	GUI_DispStringAt((INT8U *)"����  ״̬:",36,24);
	GUI_DispDecAt(MaichongNum, 72, 24, 1);

	if(SelMenu==64)//���׶˿ں�
	{
		GUI_SetTextMode(GUI_TM_REV);
		GUI_DispDecAt(FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].InputNo, 116, 44, 2);
	}
	else
		GUI_DispDecAt(FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].InputNo, 116, 44, 2);
	GUI_SetTextMode(GUI_TM_NORMAL);

	if(SelMenu==65)//���ײ�����
	{
		GUI_SetTextMode(GUI_TM_REV);
		GUI_DispDecAt(FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].CeLiangNo, 116, 64, 2);
	}
	else
		GUI_DispDecAt(FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].CeLiangNo, 116, 64, 2);
	GUI_SetTextMode(GUI_TM_NORMAL);

	if(SelMenu==66)//������������
	{
		GUI_SetTextMode(GUI_TM_REV);
		GUI_DispDecAt(FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].Stat, 116, 84, 2);
	}
	else
		GUI_DispDecAt(FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].Stat, 116, 84, 2);
	GUI_SetTextMode(GUI_TM_NORMAL);

	memset(TempBuf,0,16);
	num = (FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].Changhu[1]<<8)|FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].Changhu[0];

	sprintf((char *)TempBuf,"%05d",num);  //����ת����Ϊ�ַ���

	if(SelMenu==67)//���׵������
	{
		// printf("\n\r TempBuf=%s changshu[0]=%x changshu[1]=%x",TempBuf,FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].Changhu[0],FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].Changhu[1]);
		GUI_SetTextMode(GUI_TM_REV);
		GUI_DispStringAt(TempBuf,100,104);
	}
	else
		GUI_DispStringAt(TempBuf,100,104);
	GUI_SetTextMode(GUI_TM_NORMAL);

	/*	if(SelMenu==40)//���׵������
	{
	GUI_SetTextMode(GUI_TM_REV);
	GUI_DispStringAt("�޸�",64,124);
	}
	else
	GUI_DispStringAt("�޸�",64,124);
	GUI_SetTextMode(GUI_TM_NORMAL);
	*/
}
//******************************************************************************************************************
//* �������ƣ�Xiu_Maichong_Duankou()�����ڵڶ����˵�
//* ��    �ܣ������ס����ġ��鿴���š�
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void Xiu_Maichong_Duankou(INT8U SelMenu)
{
/*
INT8U i;
memset(NowInput.buf,0,128);
sprintf(NowInput.buf,"%02d",FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].InputNo);  //����ת����Ϊ�ַ��� //16���Ƶ�BCD��
i=0;
while(i<2)
{

  NowInput.col[i]=44;//y��
  NowInput.row[i]=116+i*8;//x��
  NowInput.set[i]=1;
  i++;
	 }
	 NowInput.AllNum=3;
	 if(ScreenInput()==1)
	 {
	 FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].InputNo=GetNum(&NowInput.buf[0],2,1);
	 //��ʱ��� Lcmfull();
	 //OSSemPost(FlushSem);
	 RtuDataAddr->FkComm_Value.F11_Set_Para=FkComm_ValueTmp.F11_Set_Para;
	 SaveFKSet();
}*/
}
///******************************************************************************************************************
//* �������ƣ�Xiu_Maichong_Celiang()�����ڵڶ����˵�
//* ��    �ܣ������ס����ġ��鿴���š�
//* ��ڲ�������
//* ���ڲ�������
///*******************************************************************************************************************/
void Xiu_Maichong_Celiang(INT8U SelMenu)
{
/*
INT8U i;
memset(NowInput.buf,0,128);
sprintf(NowInput.buf,"%02d",   //16���Ƶ�BCD��
FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].CeLiangNo
);  //����ת����Ϊ�ַ���
i=0;
while(i<2)
{

  NowInput.col[i]=64;//y��
  NowInput.row[i]=116+i*8;//x��
  NowInput.set[i]=1;
  i++;
		}
		NowInput.AllNum=3;
		if(ScreenInput()==1)
		{
		FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].CeLiangNo=GetNum(&NowInput.buf[0],2,1);
		//��ʱ��� Lcmfull();
		//OSSemPost(FlushSem);
		RtuDataAddr->FkComm_Value.F11_Set_Para=FkComm_ValueTmp.F11_Set_Para;
		SaveFKSet();
}*/
}
///******************************************************************************************************************
//* �������ƣ�Xiu_Maichong_Shuxing()�����ڵڶ����˵�
//* ��    �ܣ������ס����ġ��鿴���š�
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void Xiu_Maichong_Shuxing(INT8U SelMenu)
{/*

   INT8U i;
   memset(NowInput.buf,0,128);
   sprintf(NowInput.buf,"%02d",   //16���Ƶ�BCD��
   FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].Stat
   );  //����ת����Ϊ�ַ���
   i=0;
   while(i<2)
   {

	 NowInput.col[i]=84;//y��
	 NowInput.row[i]=116+i*8;//x��
	 NowInput.set[i]=1;
	 i++;
	 }
	 NowInput.AllNum=3;
	 if(ScreenInput()==1)
	 {
	 FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].Stat=GetNum(&NowInput.buf[0],2,1);
	 //��ʱ��� Lcmfull();
	 //OSSemPost(FlushSem);
	 RtuDataAddr->FkComm_Value.F11_Set_Para=FkComm_ValueTmp.F11_Set_Para;
	 SaveFKSet();
}*/
}
///******************************************************************************************************************
//* �������ƣ�Xiu_Maichong_Changshu()�����ڵڶ����˵�
//* ��    �ܣ������ס����ġ��鿴���š�
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void Xiu_Maichong_Changshu(INT8U SelMenu)
{/*
	INT32U num;
	INT8U i;
	//int m=0;
	unsigned char  changshu[3];
	memset(NowInput.buf,0,128);
	//m=FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].Changhu[1]*100+FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].Changhu[0];

	  //printf("\n\rFkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].Changhu[1] =%d,FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].Changhu[0]=%d",FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].Changhu[1],FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].Changhu[0]);
	  //num = FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].Changhu[1]*100 + FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].Changhu[0];
	  num=(FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].Changhu[1]<<8)|(FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].Changhu[0]);
	  //printf("\n\r num = %d",num);

		sprintf(NowInput.buf,"%05d",num);
		//printf("\n\r NowInput.buf = %s",NowInput.buf);
		i=0;
		while(i<5)
		{
		NowInput.col[i]=104;//y��
		NowInput.row[i]=100+i*8;//x��
		NowInput.set[i]=1;
		i++;
		}
		NowInput.AllNum=6;
		//GUI_DispStringAt(NowInput.buf,100,104);

		  if(ScreenInput()==1)
		  {
		  //printf("\n\r NowInput.buf=%d %d %d %d %d ",NowInput.buf[0],NowInput.buf[1],NowInput.buf[2],NowInput.buf[3],NowInput.buf[4]);
		  for(i=0;i<2;i++)
		  changshu[i]=GetNum(&NowInput.buf[2*i],2,1);
		  changshu[2]=GetNum(&NowInput.buf[4],1,1);
		  num=changshu[0]*1000+changshu[1]*10+changshu[2];

			//	printf("\n\r changshu[2]=%d,changshu[1]=%d,changshu[0]=%d",changshu[2],changshu[1],changshu[0]);
			//num = GetNum(&NowInput.buf[0],2,1) *100 + GetNum(&NowInput.buf[2],2,1);
			FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].Changhu[1]=(num&0xff00)>>8;//GetNum(&NowInput.buf[0],2,1);
			FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].Changhu[0]=num&0x00ff;//GetNum(&NowInput.buf[2],2,1);
			RtuDataAddr->FkComm_Value.F11_Set_Para=FkComm_ValueTmp.F11_Set_Para;
			SaveFKSet();
}*/
}

//******************************************************************************************************************
//* �������ƣ�Fb_ChakanMeterNum()�����ڵڶ����˵�
//* ��    �ܣ������ס����ġ��鿴���š�
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void Fb_ChakanMeterNum(INT8U SelMenu)
{

    memset(NowInput.buf,0,128);
				sprintf((char *)NowInput.buf,"%02d",
					ChakanMeterNum);  //����ת����Ϊ�ַ���

				if(SelMenu==6)
				{
					GUI_SetTextMode(GUI_TM_REV);
					GUI_DispStringAt(NowInput.buf,72,54);
				}
				else
					GUI_DispStringAt(NowInput.buf,72,54);
				GUI_SetTextMode(GUI_TM_NORMAL);
				GUI_DispStringAt((INT8U *)"(0-  )",88,54);
				GUI_DispDecAt(RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num-1, 112, 54, 2);

				if(SelMenu==7)
				{
					GUI_SetTextMode(GUI_TM_REV);
					GUI_DispStringAt((INT8U *)"����鿴",48,76);
				}
				else
					GUI_DispStringAt((INT8U *)"����鿴",48,76);
				GUI_SetTextMode(GUI_TM_NORMAL);


}
//******************************************************************************************************************
//* �������ƣ�Fb_XiuMeterSetNum()�����ڵڶ����˵�
//* ��    �ܣ������ס����ġ��޸ı��š�
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void Fb_XiuMeterSetNum(INT8U SelMenu)
{
    //  INT8U i;
    //  INT8U DongJie;
	GUI_DispStringAt((INT8U *)"��������",48,17);
	/*       memset(NowInput.buf,0,128);
				sprintf(NowInput.buf,"%02d",
				Fk_Control_Set_ValueTmp.F24_Set_Para.Zhong_Duan_ChaoBiao_Jiange
				);  //����ת����Ϊ�ַ���
				if(SelMenu==68)
				{
				GUI_SetTextMode(GUI_TM_REV);
				GUI_DispStringAt(NowInput.buf,92,36);
				}
				else
				GUI_DispStringAt(NowInput.buf,92,36);
				GUI_SetTextMode(GUI_TM_NORMAL);

				  if(SelMenu==13)
				  {
				  GUI_SetTextMode(GUI_TM_REV);
				  GUI_DispStringAt("�޸�",64,54);
				  }
				  else
				  GUI_DispStringAt("�޸�",64,54);
				  GUI_SetTextMode(GUI_TM_NORMAL);
	*/

    memset(NowInput.buf,0,128);
				sprintf((char *)NowInput.buf,"%02d",
					ChakanMeterSetNum);  //����ת����Ϊ�ַ���

				if(SelMenu==49)
				{
					GUI_SetTextMode(GUI_TM_REV);
					GUI_DispStringAt(NowInput.buf,72,74);//106-32
				}
				else
					GUI_DispStringAt(NowInput.buf,72,74);
				GUI_SetTextMode(GUI_TM_NORMAL);

				GUI_DispStringAt((INT8U *)"(0-  )",88,74);//106-32
				GUI_DispDecAt(RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num-1, 112, 74, 2);

				if(SelMenu==50)
				{
					GUI_SetTextMode(GUI_TM_REV);
					GUI_DispStringAt((INT8U *)"�����޸�",48,90);//122-32
				}
				else
					GUI_DispStringAt((INT8U *)"�����޸�",48,90);
				GUI_SetTextMode(GUI_TM_NORMAL);


}
//******************************************************************************************************************
//* �������ƣ�ChaoBiaoJG()
//* ��    �ܣ����޸ġ����ġ����ʱ�䡿
//* ��ڲ�������
//* ���ڲ�������
///*******************************************************************************************************************/
void ChaoBiaoJGSet(INT8U SeleMenu)
{/*
 INT8U i;
 memset(NowInput.buf,0,128);
 Fk_Control_Set_ValueTmp.F24_Set_Para.Zhong_Duan_ChaoBiao_Jiange = RtuDataAddr->Fk_Control_Set_Value.F24_Set_Para.Zhong_Duan_ChaoBiao_Jiange;
 sprintf(NowInput.buf,"%02d",
 Fk_Control_Set_ValueTmp.F24_Set_Para.Zhong_Duan_ChaoBiao_Jiange
 );  //����ת����Ϊ�ַ���
 i=0;
 while(i<2)
 {

   NowInput.col[i]=120;//y��
   NowInput.row[i]=88+i*8;//x��
   NowInput.set[i]=1;
			i++;
			}

			  NowInput.AllNum=3;
			  if(ScreenInput()==1)
			  {

				Fk_Control_Set_ValueTmp.F24_Set_Para.Zhong_Duan_ChaoBiao_Jiange=GetNum(&NowInput.buf[0],2,1);
				RtuDataAddr->Fk_Control_Set_Value.F24_Set_Para.Zhong_Duan_ChaoBiao_Jiange=Fk_Control_Set_ValueTmp.F24_Set_Para.Zhong_Duan_ChaoBiao_Jiange;
				RtuDataAddr->Fk_Control_Set_Value.F24_Set_Para.Valid=1;

				  SaveFKSet();
				  //��ʱ���Lcmfull();
				  //OSSemPost(FlushSem);
}*/
}
//******************************************************************************************************************
//* �������ƣ�ShowMeterData()�����ڵ�һ���˵�
//* ��    �ܣ�������Ĳ�����ź�-����ʾ���������
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void ShowMeterData(INT8U SeleMenu)
{
	unsigned int DelayTime;
	INT8U keysele,i;
	i=0;
	DelayTime=0;
	while(1)

	{
		GUI_Clear();
		switch(i)
		{

		case 0: Show_ZX_YOUGONG(RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].Z_P_All,
					RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].Z_P_F[0],
					RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].Z_P_F[1],
					RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].Z_P_F[2],
					RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].Z_P_F[3],
					ChakanMeterNum);break;
		case 1: Show_FX_YOUGONG(RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].F_P_All,
					RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].F_P_F[0],
					RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].F_P_F[1],
					RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].F_P_F[2],
					RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].F_P_F[3],
					ChakanMeterNum);break;
		case 2: Show_ZX_WUGONG(RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].Z_Q_All,
					RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].Z_Q_F[0],
					RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].Z_Q_F[1],
					RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].Z_Q_F[2],
					RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].Z_Q_F[3],
					ChakanMeterNum);break;
		case 3: Show_FX_WUGONG(RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].F_Q_All,
					RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].F_Q_F[0],
					RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].F_Q_F[1],
					RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].F_Q_F[2],
					RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].F_Q_F[3],
					ChakanMeterNum);break;
		case 4: Show_UI(RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].VA,
                    RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].VB,
                    RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].VC,
                    RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].IA,
                    RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].IB,
                    RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].IC,
                    ChakanMeterNum);break;
		case 5:      Show_PQC(RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].P,
						 RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].Q,
						 RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].Cos,
						 ChakanMeterNum);break;
		case 6:      Show_ZXU(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[ChakanMeterNum].Z_P_X_All,
						 RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[ChakanMeterNum].F_P_X_All,
						 ChakanMeterNum);break;
		default:break;
		}

		GUI_DispStringAt((INT8U *)"(",16,144);
		GUI_DispStringAt((INT8U *)")",40,144);
		GUI_DispDecAt(ChakanMeterNum, 24, 144, 2);//���������ڱ��� ���ű�??

		memset(NowInput.buf,0,128);
		sprintf((char *)NowInput.buf,"%02x%02x%02x%02x%02x%x",   //16���Ƶ�BCD��
			RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[ChakanMeterNum].Addr[5],
			RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[ChakanMeterNum].Addr[4],
			RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[ChakanMeterNum].Addr[3],
			RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[ChakanMeterNum].Addr[2],
			RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[ChakanMeterNum].Addr[1],
			RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[ChakanMeterNum].Addr[0]);
		//  GUI_DispStringAt(NowInput.buf,48,143);//Ӧ����ʾ����ַ����

		Status_Bar();//Ȼ��״̬����Ȼ������ʾ�����ı��ţ����ǵ�һ���˵�����
		GUI_DispStringAt(NowInput.buf,48,144);//Ӧ����ʾ����ַ����

		Lcmfull();
		keysele=KeySeleflag;
		KeySeleflag =0;
		if(DelayTime>=PageDelayTime)
		{
			OldLevel=0;
			return;
		}
		switch(keysele)
		{
		case 0:DelayTime++;break;
		case 1: if(i==0) i=0; else i=(i-1)%7 ;DelayTime=0; break;
	       case 2: if(i==6) i=6; else i=(i+1)%7 ;DelayTime=0; break;
		   case 3: DelayTime=0;break;
		   case 4: DelayTime=0;break;
		   case 5: DelayTime=0;break;
		   case 6: OldLevel=0;return;break;
		   default:break;
		}
	}
}

//******************************************************************************************************************
//* �������ƣ�ShowMeterSetting()
//* ��    �ܣ�״̬������Ϊ��������ʾ�ź�ǿ�ȣ�ͨѶ��ʽ���澯�¼��빦�������ԣ�ʱ�䣫����
//* ��ڲ������ޡ�����������������ʾ���˵�ѡ��Ĳ˵�������ҳ��־
//* ���ڲ�������
//*******************************************************************************************************************/
int ShowMeterSetting(INT8U SeleMenu)
{
	unsigned char keysele,i;
    unsigned int DelayTime;
	i=0;
	DelayTime=0;
	GUI_Clear();//������
	GUI_DispStringAt((INT8U *)"��  :", 16, 24);
	GUI_DispStringAt((INT8U *)"��Լ:", 16, 40);
	GUI_DispStringAt((INT8U *)"����:", 16, 56);
	GUI_DispStringAt((INT8U *)"�˿�:", 16, 72);
	GUI_DispStringAt((INT8U *)"����:", 16, 88);
	GUI_DispStringAt((INT8U *)"����������:", 16, 104);
	GUI_DispStringAt((INT8U *)"�������:  ����", 16, 120);
	while(1)

	{
		GUI_SetTextMode(GUI_TM_REV);
		GUI_DispDecAt(i, 32, 24, 2);
		GUI_SetTextMode(GUI_TM_NORMAL);
        memset(NowInput.buf,0,128);
		sprintf((char *)NowInput.buf,"%02x%02x%02x%02x%02x%02x",   //16���Ƶ�BCD��
			RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Addr[5],
			RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Addr[4],
			RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Addr[3],
			RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Addr[2],
			RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Addr[1],
			RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Addr[0]);  //����ת����Ϊ�ַ���
		GUI_DispStringAt(NowInput.buf,56,24);//Ӧ����ʾ����ַ


		GUI_DispDecAt(RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].GuiYue_Type,56,40,2);
        switch(((RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].BaudAndPort&0xe0)>>5)&0x7)
		{  case 1:
		GUI_DispStringAt((INT8U *)" 600", 56, 56);break;//Ӧ����ʾͨѶ����
		case 3:
			GUI_DispStringAt((INT8U *)"2400", 56, 56);break;//Ӧ����ʾͨѶ����
		case 4:
			GUI_DispStringAt((INT8U *)"4800", 56, 56);break;//Ӧ����ʾͨѶ����
		case 5:
			GUI_DispStringAt((INT8U *)"7200", 56, 56);break;//Ӧ����ʾͨѶ����
		case 6:
			GUI_DispStringAt((INT8U *)"9600", 56, 56);break;//Ӧ����ʾͨѶ����
		default:
			GUI_DispStringAt((INT8U *)"1200", 56, 56);break;//Ӧ����ʾͨѶ����
		}

		GUI_DispDecAt(((RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].BaudAndPort))&0x1f , 56, 72, 2);

		memset(NowInput.buf,0,128);
		sprintf((char *)NowInput.buf,"%02x%02x%02x%02x%02x%02x",   //16���Ƶ�BCD��
			RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Passwd[5],
			RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Passwd[4],
			RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Passwd[3],
			RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Passwd[2],
			RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Passwd[1],
			RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Passwd[0]);  //����ת����Ϊ�ַ���
		GUI_DispStringAt(NowInput.buf,56,88);//Ӧ����ʾ����ַ

		GUI_DispDecAt(((RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].CeLiangNo)) , 104, 104, 2);

		memset(NowInput.buf,0,128);
		sprintf((char *)NowInput.buf,"%02d",
			RtuDataAddr->Fk_Control_Set_Value.F24_Set_Para.Zhong_Duan_ChaoBiao_Jiange
			);  //����ת����Ϊ�ַ���
		GUI_DispStringAt(NowInput.buf,88,120);

		Status_Bar();
		Lcmfull();
		//OSSemPend(KeySem,50,&err);
		keysele=KeySeleflag;
		KeySeleflag =0;
		if(DelayTime>=PageDelayTime)
		{
			OldLevel=0;
			return 0;
		}

		switch(keysele)
		{
		case 0:DelayTime++;break;
		case 1: if(i!=0)  i=(i-1)%RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num ;DelayTime=0; break;
	       case 2: if(i!=RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num) i=(i+1)%RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num ;DelayTime=0; break;
		   case 3: DelayTime=0;break;
		   case 4: DelayTime=0;break;
		   case 5: DelayTime=0;break;
		   case 6: OldLevel=0;return 0;break;
		   default:break;
		}
	}

}
//******************************************************************************************************************
//* �������ƣ�Show_TXcanshu() ���ڵ�һ���˵�
//* ��    �ܣ�����ʾ����ͨ�Ų�����
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void Show_TXcanshu(void)
{
    INT8U keysele;
    INT8U TempBuf[16];
    INT8U x;
    unsigned int DelayTime;
    DelayTime=0;
	while(1)
	{
		GUI_Clear();//������
		Status_Bar();//��д״̬����Ȼ����д�����ġ�GPRS����ͨ�š����ǵ�һ���˵�����

		switch(TongDaoLeiXing)
		{
		case 0:

			GUI_DispStringAt((INT8U *)"GPRS����ͨ��", 32, 144);
			GUI_DispStringAt((INT8U *)"APN:", 0, 17);
			GUI_DispStringAt((INT8U *)"��վIP�˿�:", 0, 35);
			GUI_DispStringAt((INT8U *)"��������:  ����", 0, 53);
			GUI_DispStringAt((INT8U *)"��������:", 0, 71);
			GUI_DispStringAt((INT8U *)"��վIP��ַ:", 0, 89);
			GUI_DispStringAt((INT8U *)"����ģʽ:", 0, 125);
			//apn
			GUI_DispStringAt(RtuDataAddr->FkComm_Value.F3_Set_Para.APN,32,17);
			//port
			memset(TempBuf,0,16);
			sprintf((char *)TempBuf,"%05d",
				(RtuDataAddr->FkComm_Value.F3_Set_Para.PortMaster[1]<<8)+RtuDataAddr->FkComm_Value.F3_Set_Para.PortMaster[0]);  //����ת����Ϊ�ַ���
			GUI_DispStringAt(TempBuf,88,35);
			//Heart
			memset(TempBuf,0,16);
			sprintf((char *)TempBuf,"%02d",RtuDataAddr->FkComm_Value.F1_Set_Para.Heart_Beat);  //����ת����Ϊ�ַ���
			GUI_DispStringAt(TempBuf,72,53);
			//����
			memset(TempBuf,0,16);
			sprintf((char *)TempBuf,"%02x%02x%02x%02x%02x%1x",
				RtuDataAddr->FkComm_Value.F4_Set_Para.DuanXin[0],
				RtuDataAddr->FkComm_Value.F4_Set_Para.DuanXin[1],
				RtuDataAddr->FkComm_Value.F4_Set_Para.DuanXin[2],
				RtuDataAddr->FkComm_Value.F4_Set_Para.DuanXin[3],
				RtuDataAddr->FkComm_Value.F4_Set_Para.DuanXin[4],
				RtuDataAddr->FkComm_Value.F4_Set_Para.DuanXin[5]>>4);  //����ת����Ϊ�ַ���
			GUI_DispStringAt(TempBuf,72,71);
			//ip
			x=24;
			GUI_DispDecAt(RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[0],x,107,3);
			GUI_DispCharAt('.',x+24,108);
			GUI_DispDecAt(RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[1],x+24+4,107,3);
			GUI_DispCharAt('.',x+48+4,108);
			GUI_DispDecAt(RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[2],x+48+8,107,3);
			GUI_DispCharAt('.',x+72+8,108);
			GUI_DispDecAt(RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[3],x+84,107,3);

			//����ģʽ
			switch(RtuDataAddr->FkComm_Value.F8_Set_Para.GPRS_MODE)
			{
			case 1:GUI_DispStringAt((INT8U *)"��������", 72, 126);break;
			case 2:GUI_DispStringAt((INT8U *)"��������", 72, 126);break;
			default:GUI_DispStringAt((INT8U *)"��������", 72, 126);break;
			}

			break;
			case 1:
				GUI_DispStringAt((INT8U *)"PSTN����ͨ��", 32, 145);
				break;
			default :break;

		}
		Lcmfull();
		keysele=KeySeleflag;
		KeySeleflag =0;

		if(DelayTime>=(PageDelayTime/2))
		{
			OldLevel=0;
			GUI_Clear();
			GUI_DispStringAt((INT8U *)"�ɼ�����ʶ",40,18);
			GUI_DispStringAt((INT8U *)"�ɼ���ַ:",24,36);
			GUI_DispStringAt((INT8U *)"ͨ����λ��:",20,54);
			GUI_DispStringAt((INT8U *)"ͨ������",48,72);
			return;
		}
		switch(keysele)
		{
		case 0:DelayTime++;break;
		case 1: DelayTime=0; break;
	       case 2: DelayTime=0; break;
		   case 3: DelayTime=0;break;
		   case 4: DelayTime=0;break;
		   case 5: DelayTime=0;break;
		   case 6:
			   OldLevel=0;
			   GUI_Clear();
			   GUI_DispStringAt((INT8U *)"�ɼ�����ʶ",40,18);
			   GUI_DispStringAt((INT8U *)"�ɼ���ַ:",24,36);
			   GUI_DispStringAt((INT8U *)"ͨ����λ��:",20,54);
			   GUI_DispStringAt((INT8U *)"ͨ������",48,72);
			   return ;
			   break;
		   default:break;
		}

	}

}
//******************************************************************************************************************
//* �������ƣ�Show_TX_canshu() ���ڵ�һ���˵�
//* ��    �ܣ�����ʾ����ͨ�Ų�����GPRS���á�PSTN���á�CDMA���á�
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
int Show_TX_canshu(INT8U SeleMenu)
{
	INT8U keysele;
	INT8U TempBuf[16];
	INT16U tmpaddr;
	unsigned int DelayTime;
    DelayTime=0;
	GUI_Clear();
	GUI_DispStringAt((INT8U *)"�ն˱�ʶ",48,18);
	GUI_DispStringAt((INT8U *)"�ն˵�ַ:",24,36);
	GUI_DispStringAt((INT8U *)"������λ��:",20,54);
	GUI_DispStringAt((INT8U *)"ͨ������",48,72);

	while(1)
	{
		keysele=KeySeleflag;
		KeySeleflag =0;
		if(DelayTime>=PageDelayTime)
		{
			OldLevel=0;
			return 0;
		}

		switch(keysele)
		{
		case 0:DelayTime++;break;
		case 1: DelayTime=0; break;
	       case 2: DelayTime=0; break;
		   case 3: DelayTime=0;break;
		   case 4: DelayTime=0;break;
		   case 5: Show_TXcanshu(); break;
		   case 6: OldLevel=0;return 0;break;
		   default:break;
		}

		Status_Bar();
		tmpaddr= (RtuDataAddr->FkComm_Value.ADDR[1]<<8)+ RtuDataAddr->FkComm_Value.ADDR[0];


		memset(TempBuf,0,16);
		sprintf((char *)TempBuf,"%05d",tmpaddr);
		GUI_DispStringAt(TempBuf,98,36);


		memset(TempBuf,0,16);
		sprintf((char *)TempBuf,"%02x%02x",
			RtuDataAddr->FkComm_Value.GB22601991[0],
			RtuDataAddr->FkComm_Value.GB22601991[1]
			);  //����ת����Ϊ�ַ���
		GUI_DispStringAt(TempBuf,108,54);


		if(TongDaoLeiXing==0)
		{
			GUI_SetTextMode(GUI_TM_REV);
			GUI_DispStringAt((INT8U *)"GPRS",64,90);
		}
		/*      if(TongDaoLeiXing==1)
		{
		GUI_SetTextMode(GUI_TM_REV);
		GUI_DispStringAt("PSTN",64,90);//("PSTN",64,108);
		}
		if(TongDaoLeiXing==2)
		{
		GUI_SetTextMode(GUI_TM_REV);
		GUI_DispStringAt("CDMA",64,90);//("CDMA",64,126);
		}
		*/
		GUI_SetTextMode(GUI_TM_NORMAL);


		Lcmfull();


	}

}


//******************************************************************************************************************
//* �������ƣ�Status_Bar()
//* ��    �ܣ�״̬������Ϊ��������ʾ�ź�ǿ�ȣ�ͨѶ��ʽ���澯�¼��빦�������ԣ�ʱ�䣫����
//* ��ڲ������ޡ�����������������ʾ���˵�ѡ��Ĳ˵�������ҳ��־
//* ���ڲ�������
//*******************************************************************************************************************/
void Status_Bar(void)
{
    int i;
	INT8U str[2];
	INT8U tl[8],TERC[64],k;
	INT8U Warning,Warn[64];//�澯�¼���־
	TS ts;
	TSGet(&ts);
    memset(str,0,sizeof(str));
    memset(TERC,0,sizeof(TERC));
    memset(Warn,0,sizeof(Warn));
    Warning=0;
	/*************************��ʾʱ��****************** *********��ʼ**/
	GUI_DispDecAt(ts.Hour , 96, 0, 2);
	GUI_DispDecAt(ts.Minute , 120, 0, 2);
	GUI_DispDecAt(ts.Sec , 144, 0, 2);
	GUI_DispStringAt((INT8U *)":", 112, 0);
    GUI_DispStringAt((INT8U *)":", 136, 0);
	/*************************��ʾʱ��****************** *********����**/
	/*************************��ʾ�ź�ǿ��*************** *********��ʼ**/
   // if(RtuDataAddr->Gprs_ok)
   // {
		str[0]=0x1c;
        GUI_DispStringAt(str, 0, 0);//��ʾ����
   // }
	if(RtuDataAddr->GprsCSQ>=24)
	{
		GUI_DrawVLine( 16, 2, 13);
		GUI_DrawVLine( 15, 2, 13);
	}
	if(RtuDataAddr->GprsCSQ>=16)
	{
		GUI_DrawVLine( 13,  5, 13);
		GUI_DrawVLine( 12,  5, 13);
	}
	if(RtuDataAddr->GprsCSQ>=8)
	{
		GUI_DrawVLine( 10,  8, 13);
		GUI_DrawVLine( 9,  8, 13);
	}
	if(RtuDataAddr->GprsCSQ>0)
	{
		GUI_DrawVLine( 7,  10, 13);
		GUI_DrawVLine( 6,  10, 13);
	}
	/*************************��ʾ�ź�ǿ��*************** *********����**/
	/*************************��ʾͨ�ŷ�ʽ GPRS TCp CDMA *********��ʼ**/
	switch(RtuDataAddr->ModuleType)
	{
	case 1://��ʾGΪGprs ͨѶ��ʽ
		str[0]=0x1e;
		GUI_DispStringAt(str, 25, 0);//x+8
		GUI_DrawHLine( 22, 0, 34);//
		GUI_DrawVLine( 22, 0, 14);//
		GUI_DrawVLine( 34, 0, 14);//
		break;
	case 3://��ʾLΪ��̫������ ͨѶ��ʽ
		str[0]=0x1f;
		GUI_DispStringAt(str, 25, 0);//x+8
		GUI_DrawHLine( 22, 0, 34);//
		GUI_DrawVLine( 22, 0, 14);//
		GUI_DrawVLine( 34, 0, 14);//
		break;
	case 2://��ʾCΪCDMA ͨѶ��ʽ
		str[0]=0x1d;
		GUI_DispStringAt(str, 25, 0);//x+8
		GUI_DrawHLine( 22, 0, 34);//
		GUI_DrawVLine( 22, 0, 14);//
		GUI_DrawVLine( 34, 0, 14);//
		break;
	default:
		GUI_DispStringAt((INT8U *)"  ", 22, 0);//x+8
		break;
	}
	/*************************��ʾͨ�ŷ�ʽ��� GPRS PSDN CDMA *********����**/
	/*************************��ʾ���� *********��ʼ**/
	if( RtuDataAddr->FuKong_Control_Value.F25_Control_Para.Valid==1)
	   {
		str[0]=0x1b;
		GUI_DispStringAt(str, 42, 0);//x+8
		GUI_DrawHLine( 38, 0, 52);//
		GUI_DrawVLine( 38, 0, 14);//
		GUI_DrawVLine( 52, 0, 14);//
	   }
	   else
		   GUI_DispStringAt((INT8U *)"  ", 42, 0);
	   /*************************��ʾ���� *********����**/
	   /*************************��ʾ**�澯�¼���̾�ţ��루�¼������룩����***��ʼ**/
	   for(i=0;i<4;i++)
	   {
		   tl[i]=RtuDataAddr->ERCBiaoZhi[i];
		   if(tl[i]!=0)
		   {
			   for(k=0;k<8;k++)
			   {
				   if((tl[i]&0x01)==0x01)
				   {
					   Warn[Warning]=8*i+k+1;
					   Warning=Warning+1;//Warning ������ж��ٸ��¼���Waring[]������¼�����
				   }
				   tl[i]=(tl[i]>>1);
			   }
		   }
	   }
	   if (Warning >= 1)
	   {
		   if (ts.Sec %2==0)
		   {//��ʾ̾��
			   str[0]=0x7b;
			   str[1]=0x7c;
			   GUI_DispStringAt(str,56,0);
			   GUI_DispStringAt((INT8U *)"   ",72,0);
		   }
		   else //������������
		   {
			   GUI_DispStringAt((INT8U *)"    ",56,0);
			   LcdK=((LcdK+1)%(Warning));
		   }
	   }
	   /*************************��ʾ**�澯�¼���̾�ţ��루�¼������룩����***����**/
	   GUI_DrawHLine( 0, 15, 159); //(x,y,y1)��������
	   GUI_DrawHLine( 0, 143, 159); //��������
 }

 //******************************************************************************************************************
 //* �������ƣ�RunArrow()
 //* ��    �ܣ�������ʾ���ϼ�ͷ�����ߡ��¼�ͷ�����ߡ����¼�ͷ��
 //* ��ڲ�������
 //* ���ڲ�������
 //*******************************************************************************************************************/

 void RunArrow(INT8U Arrow)

 {
	 INT8U str[1];
	 memset(str,0,sizeof(str));
	 switch(Arrow)
	 {
    	case 1:str[0]=0x7e;break;
		case 2:str[0]=0x7f;break;
		case 3:str[0]=0x7d;break;
		default:break;
	 }

	 GUI_DispStringAt(&str[0],151,144);
 }
 //******************************************************************************************************************
 //* �������ƣ�Fb_ChaobiaoSet(INT8U SelMenu)
 //* ��    �ܣ�������ʾ��Լ�����ʡ��˿ںš�ͨѶ���롢���������㣬���������������
 //* ��ڲ�������
 //* ���ڲ�������
 //*******************************************************************************************************************/
 void Fb_ChaobiaoSet(INT8U SelMenu)
 {
	 // INT8U i;
	 //   GUI_Clear();
	 //   GUI_DispStringAt("��  :",16,24);
	 //   GUI_DispStringAt("��Լ:",16,40);
	 //   GUI_DispStringAt("����:",16,56);
	 //   GUI_DispStringAt("�˿�:",16,72);
	 //   GUI_DispStringAt("����:",16,88);
	 //   GUI_DispStringAt("����������:",16,104);
	 GUI_DispDecAt(ChakanMeterSetNum, 32, 24, 2);//��ʾ�������

	 memset(NowInput.buf,0,128);
	 sprintf((char *)NowInput.buf,"%02x%02x%02x%02x%02x%02x",   //16���Ƶ�BCD��
		 FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Addr[5],
		 FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Addr[4],
		 FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Addr[3],
		 FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Addr[2],
		 FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Addr[1],
		 FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Addr[0]);  //����ת����Ϊ�ַ���
	 if(SelMenu==51)//��ʾ����ַ
				 {
		 GUI_SetTextMode(GUI_TM_REV);
		 GUI_DispStringAt(NowInput.buf,56,24);
				 }
			  else
				  GUI_DispStringAt(NowInput.buf,56,24);
			  GUI_SetTextMode(GUI_TM_NORMAL);


			  memset(NowInput.buf,0,128);
			  sprintf((char *)NowInput.buf,"%02d",   //16���Ƶ�BCD��
				  FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].GuiYue_Type);  //����ת����Ϊ�ַ���
			  if(SelMenu==52)//��ʾ����Լ
			  {
				  GUI_SetTextMode(GUI_TM_REV);
				  GUI_DispStringAt(NowInput.buf,56,40);
			  }
			  else
				  GUI_DispStringAt(NowInput.buf,56,40);
			  GUI_SetTextMode(GUI_TM_NORMAL);

			  memset(NowInput.buf,0,128);
			  sprintf((char *)NowInput.buf,"%02d",   //16���Ƶ�BCD��
				  ((FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].BaudAndPort&0xe0)>>5)&0x7);  //����ת����Ϊ�ַ���
			  if(SelMenu==53)//��ʾ������
			  {
				  GUI_SetTextMode(GUI_TM_REV);
				  GUI_DispStringAt(NowInput.buf,56,56);
			  }
			  else
				  GUI_DispStringAt(NowInput.buf,56,56);
			  GUI_SetTextMode(GUI_TM_NORMAL);


			  memset(NowInput.buf,0,128);
			  sprintf((char *)NowInput.buf,"%02d",   //16���Ƶ�BCD��
				  FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].BaudAndPort&0x1f);  //����ת����Ϊ�ַ���
			  if(SelMenu==54)//��ʾ���˿ں�
			  {
				  GUI_SetTextMode(GUI_TM_REV);
				  GUI_DispStringAt(NowInput.buf,56,72);
			  }
			  else
				  GUI_DispStringAt(NowInput.buf,56,72);
			  GUI_SetTextMode(GUI_TM_NORMAL);


			  memset(NowInput.buf,0,128);
			  sprintf((char *)NowInput.buf,"%02x%02x%02x%02x%02x%02x",   //16���Ƶ�BCD��
				  FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Passwd[5],
				  FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Passwd[4],
				  FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Passwd[3],
				  FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Passwd[2],
				  FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Passwd[1],
				  FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Passwd[0]);  //����ת����Ϊ�ַ���
			  if(SelMenu==55)//��ʾ������
			  {
				  GUI_SetTextMode(GUI_TM_REV);
				  GUI_DispStringAt(NowInput.buf,56,88);
			  }
			  else
				  GUI_DispStringAt(NowInput.buf,56,88);
			  GUI_SetTextMode(GUI_TM_NORMAL);

			  memset(NowInput.buf,0,128);
			  sprintf((char *)NowInput.buf,"%02d",   //16���Ƶ�BCD��
				  FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].CeLiangNo);  //����ת����Ϊ�ַ���
			  if(SelMenu==56)//��ʾ��������
			  {
				  GUI_SetTextMode(GUI_TM_REV);
				  GUI_DispStringAt(NowInput.buf,104,104);
			  }
			  else
				  GUI_DispStringAt(NowInput.buf,104,104);
			  GUI_SetTextMode(GUI_TM_NORMAL);
			  memset(NowInput.buf,0,128);
			  Fk_Control_Set_ValueTmp.F24_Set_Para.Zhong_Duan_ChaoBiao_Jiange = RtuDataAddr->Fk_Control_Set_Value.F24_Set_Para.Zhong_Duan_ChaoBiao_Jiange;
		         		 //printf("\n\rFk_Control_Set_ValueTmp.F24_Set_Para.Zhong_Duan_ChaoBiao_Jiange=%d ",Fk_Control_Set_ValueTmp.F24_Set_Para.Zhong_Duan_ChaoBiao_Jiange);
			  sprintf((char *)NowInput.buf,"%02d",
				  Fk_Control_Set_ValueTmp.F24_Set_Para.Zhong_Duan_ChaoBiao_Jiange);  //����ת����Ϊ�ַ���
			  if(SelMenu==68)//��ʾ��������
			  {
				  GUI_SetTextMode(GUI_TM_REV);
				  GUI_DispStringAt(NowInput.buf,88,120);
			  }
			  else
				  GUI_DispStringAt(NowInput.buf,88,120);
			  GUI_SetTextMode(GUI_TM_NORMAL);
			  /*
			  memset(NowInput.buf,0,128);
			  //memcpy(RtuDataAddr->Fk_Control_Set_Value.F7_Set_Para.ZhongDuan_ChaoBiao_Date,Fk_Control_Set_ValueTmp.F7_Set_Para.ZhongDuan_ChaoBiao_Date,sizeof(RtuDataAddr->Fk_Control_Set_Value.F7_Set_Para.ZhongDuan_ChaoBiao_Date));
			  sprintf(NowInput.buf,"%02d",
			  RtuDataAddr->Fk_Control_Set_Value.F7_Set_Para.ZhongDuan_ChaoBiao_Date);  //����ת����Ϊ�ַ���
			  if(SelMenu==76)//��ʾ��������
			  {
			  for(i=0;i<31;i++)
			  {
			  if(NowInput.buf[i])
			  {
			  GUI_SetTextMode(GUI_TM_REV);
			  //GUI_DispStringAt(NowInput.buf[i],88,120);
			  }
			  }
			  }

				if(SelMenu==10)
				{
				GUI_SetTextMode(GUI_TM_REV);
				GUI_DispStringAt("�޸�",64,120);
				}
				else
				GUI_DispStringAt("�޸�",64,120);
				GUI_SetTextMode(GUI_TM_NORMAL);
			  */
}
//******************************************************************************************************************
//* �������ƣ�Xiu_BiaoHao()�����ڵڶ����˵�
//* ��    �ܣ����޸ġ����ľ������á������š�
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void Xiu_BiaoHao(INT8U SeleMenu)
{
/*
INT8U i;
memset(NowInput.buf,0,128);
sprintf(NowInput.buf,"%02x%02x%02x%02x%02x%02x",   //16���Ƶ�BCD��
FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Addr[5],
FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Addr[4],
FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Addr[3],
FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Addr[2],
FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Addr[1],
FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Addr[0]);  //����ת����Ϊ�ַ���
i=0;
while(i<12)
{

  NowInput.col[i]=24;//y��
  NowInput.row[i]=56+i*8;//x��
  NowInput.set[i]=1;
  i++;
		}
		NowInput.AllNum=13;
		if(ScreenInput()==1)
		{
		FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Addr[5]=GetNum(&NowInput.buf[0],2,3);
		FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Addr[4]=GetNum(&NowInput.buf[2],2,3);
		FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Addr[3]=GetNum(&NowInput.buf[4],2,3);
		FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Addr[2]=GetNum(&NowInput.buf[6],2,3);
		FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Addr[1]=GetNum(&NowInput.buf[8],2,3);
		FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Addr[0]=GetNum(&NowInput.buf[10],2,3);
		//��ʱ��� Lcmfull();
		//OSSemPost(FlushSem);
		RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[ChakanMeterSetNum]=FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum];
		RtuDataAddr->FkInput_Value.F10_Set_Para.Valid=1;
		RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num = DD_Device_Max;
		SaveFKSet();
		}
	*/

}
//******************************************************************************************************************
//* �������ƣ�Xiu_BiaoGuiyue()�����ڵڶ����˵�
//* ��    �ܣ����޸ġ����ľ������á�����Լ��
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void Xiu_BiaoGuiyue(INT8U SeleMenu)
{
/*
INT8U i;
memset(NowInput.buf,0,128);
sprintf(NowInput.buf,"%02d",   //16���Ƶ�BCD��
FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].GuiYue_Type);  //����ת����Ϊ�ַ���
i=0;
while(i<2)
{

  NowInput.col[i]=40;//y��
  NowInput.row[i]=56+i*8;//x��
  NowInput.set[i]=1;
  i++;
		}
		NowInput.AllNum=3;
		if(ScreenInput()==1)
		{
		FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].GuiYue_Type=GetNum(&NowInput.buf[0],2,1);
		//��ʱ���Lcmfull();
		//OSSemPost(FlushSem);
		RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[ChakanMeterSetNum]=FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum];
		RtuDataAddr->FkInput_Value.F10_Set_Para.Valid=1;
		RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num = DD_Device_Max;
		SaveFKSet();
		}
	*/
}
//******************************************************************************************************************
//* �������ƣ�Xiu_Biaoband()�����ڵڶ����˵�
//* ��    �ܣ����޸ġ����ľ������á������ʡ�
//* ��ڲ�������
//* ���ڲ�������
///*******************************************************************************************************************/
void Xiu_Biaoband(INT8U SeleMenu)
{/*
 unsigned char i,TmpBaud,TmpPort;
 TmpPort=FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].BaudAndPort&0x1F;
	memset(NowInput.buf,0,128);
	sprintf(NowInput.buf,"%02d",   //16���Ƶ�BCD��
	((FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].BaudAndPort&0xe0)>>5)&0x7);  //����ת����Ϊ�ַ���
	i=0;
	while(i<2)
	{

	  NowInput.col[i]=56;//y��
	  NowInput.row[i]=56+i*8;//x��
	  NowInput.set[i]=1;
	  i++;
	  }
	  NowInput.AllNum=3;
	  if(ScreenInput()==1)
	  {
	  TmpBaud=GetNum(&NowInput.buf[0],2,1);
	  FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].BaudAndPort=TmpPort+(TmpBaud<<5);
	  //��ʱ��� Lcmfull();
	  RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[ChakanMeterSetNum]=FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum];
	  RtuDataAddr->FkInput_Value.F10_Set_Para.Valid=1;
	  RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num = DD_Device_Max;
	  SaveFKSet(); }
	*/
}
///******************************************************************************************************************
//* �������ƣ�Xiu_Biaoport()�����ڵڶ����˵�
//* ��    �ܣ����޸ġ����ľ������á����˿ڡ�
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void Xiu_Biaoport(INT8U SeleMenu)
{/*
 unsigned char i,TmpBaud,TmpPort;
 TmpBaud=FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].BaudAndPort&0xe0;
	memset(NowInput.buf,0,128);
	sprintf(NowInput.buf,"%02d",   //16���Ƶ�BCD��
	FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].BaudAndPort&0x1F);  //����ת����Ϊ�ַ���
	i=0;
	while(i<2)
	{

	  NowInput.col[i]=72;//y��
	  NowInput.row[i]=56+i*8;//x��
	  NowInput.set[i]=1;
	  i++;
	  }
	  NowInput.AllNum=3;
	  if(ScreenInput()==1)
	  {
	  TmpPort=GetNum(&NowInput.buf[0],2,1);
	  FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].BaudAndPort=TmpPort+TmpBaud;
	  //��ʱ���Lcmfull();
	  RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[ChakanMeterSetNum]=FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum];
	  RtuDataAddr->FkInput_Value.F10_Set_Para.Valid=1;
	  RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num = DD_Device_Max;
	  SaveFKSet(); }
	*/
}
///******************************************************************************************************************
//* �������ƣ�Xiu_BiaoPassword()�����ڵڶ����˵�
//* ��    �ܣ����޸ġ����ľ������á������š�
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void Xiu_BiaoPassword(INT8U SeleMenu)
{
/*
INT8U i;
memset(NowInput.buf,0,128);
sprintf(NowInput.buf,"%02x%02x%02x%02x%02x%02x",   //16���Ƶ�BCD��
FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Passwd[5],
FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Passwd[4],
FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Passwd[3],
FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Passwd[2],
FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Passwd[1],
FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Passwd[0]);  //����ת����Ϊ�ַ���
i=0;
while(i<12)
{
NowInput.col[i]=88;//y��
NowInput.row[i]=56+i*8;//x��
NowInput.set[i]=1;
i++;
}
NowInput.AllNum=13;
if(ScreenInput()==1)
{
FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Passwd[5]=GetNum(&NowInput.buf[0],2,2);
FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Passwd[4]=GetNum(&NowInput.buf[2],2,2);
FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Passwd[3]=GetNum(&NowInput.buf[4],2,2);
FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Passwd[2]=GetNum(&NowInput.buf[6],2,2);
FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Passwd[1]=GetNum(&NowInput.buf[8],2,2);
FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Passwd[0]=GetNum(&NowInput.buf[10],2,2);
//��ʱ���Lcmfull();
//OSSemPost(FlushSem);
RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[ChakanMeterSetNum]=FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum];
RtuDataAddr->FkInput_Value.F10_Set_Para.Valid=1;
RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num = DD_Device_Max;
SaveFKSet(); }
	*/
}
///******************************************************************************************************************
//* �������ƣ�Xiu_BiaoCeliangdian()�����ڵڶ����˵�
//* ��    �ܣ����޸ġ����ľ������á����˿ڡ�
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void Xiu_BiaoCeliangdian(INT8U SeleMenu)
{/*
 unsigned char i;
 memset(NowInput.buf,0,128);
	sprintf(NowInput.buf,"%02d",   //16���Ƶ�BCD��
	FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].CeLiangNo);  //����ת����Ϊ�ַ���
	i=0;
	while(i<2)
	{

	  NowInput.col[i]=104;//y��
	  NowInput.row[i]=104+i*8;//x��
	  NowInput.set[i]=1;
	  i++;
	  }
	  NowInput.AllNum=3;
	  if(ScreenInput()==1)
	  {
	  FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].CeLiangNo=GetNum(&NowInput.buf[0],2,1);
	  //��ʱ���Lcmfull();
	  RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[ChakanMeterSetNum]=FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum];
	  RtuDataAddr->FkInput_Value.F10_Set_Para.Valid=1;
	  RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num = DD_Device_Max;
	  SaveFKSet();
	  }
	*/
}
///******************************************************************************************************************
//* �������ƣ�EnterXiuBiaoCanshu()
//* ��    �ܣ�ȷ���޸ı��Ĳ���ô
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void EnterXiuBiaoCanshu(INT8U SeleMenu)
{
/*
unsigned char i,Tpassword[2];
unsigned int TmpPass=0;

  memset(Tpassword,0,2);
  GUI_Clear(); //������
  GUI_DispStringAt("��������:",28,64);
  memset(NowInput.buf,0,128);
  sprintf(NowInput.buf,"%02d%02d",   //16���Ƶ�BCD��
		Tpassword[0],Tpassword[1]);  //����ת����Ϊ�ַ���
		i=0;
		while(i<4)
		{

		  NowInput.col[i]=64;//y��
		  NowInput.row[i]=100+i*8;//x��
		  NowInput.set[i]=1;
		  i++;
		  }
		  NowInput.AllNum=5;
		  if(ScreenInput()==1)
		  {
		  Tpassword[0]=GetNum(&NowInput.buf[0],2,1);
		  Tpassword[1]=GetNum(&NowInput.buf[2],2,1);
		  TmpPass=Tpassword[0]*100+Tpassword[1];
		  if(TmpPass!=PassWord)
		  EnterXiuBiaoCanshu(SeleMenu);
		  }
		  else OldLevel = 0;

			if(TmpPass==PassWord)
			{
			switch(Menu[SeleMenu].level)
			{
			case 11://�洢��������
            {
			RtuDataAddr->FkInput_Value.F10_Set_Para.Valid=1;
			RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num = DD_Device_Max;
			RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[ChakanMeterSetNum]=FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum];

			  }
			  break;
			  case 12://�洢ͨѶ��λ�룬�ɼ�����ַ
			  {
			  RtuDataAddr->FkComm_Value.ADDR[0]=FkComm_ValueTmp.ADDR[0];
			  RtuDataAddr->FkComm_Value.ADDR[1]=FkComm_ValueTmp.ADDR[1];
			  RtuDataAddr->FkComm_Value.GB22601991[0]=FkComm_ValueTmp.GB22601991[0];
			  RtuDataAddr->FkComm_Value.GB22601991[1]=FkComm_ValueTmp.GB22601991[1];

				}
				break;
				case 13://�洢ͨѶ������apn ��ip�˿ڣ����ź��룬����ģʽ��ip
				{
				RtuDataAddr->FkComm_Value.F1_Set_Para=FkComm_ValueTmp.F1_Set_Para;
				RtuDataAddr->FkComm_Value.F3_Set_Para=FkComm_ValueTmp.F3_Set_Para;
				RtuDataAddr->FkComm_Value.F4_Set_Para=FkComm_ValueTmp.F4_Set_Para;
				RtuDataAddr->FkComm_Value.F8_Set_Para=FkComm_ValueTmp.F8_Set_Para;
                RtuDataAddr->FkComm_Value.F3_Set_Para.Valid=1;
				}
				break;
				case 15://�洢�������
				RtuDataAddr->Fk_Control_Set_Value.F24_Set_Para.Zhong_Duan_ChaoBiao_Jiange=Fk_Control_Set_ValueTmp.F24_Set_Para.Zhong_Duan_ChaoBiao_Jiange;
				break;
				case 18://�洢������
				RtuDataAddr->FkComm_Value.F11_Set_Para=FkComm_ValueTmp.F11_Set_Para;
				break;
				case 10://װ������ѡ���е������ݼ�Ӳ����λ���ָ�����ֵ
				{
				switch(SeleMenu)
				{
				case 44:printf("UIP\r\n");break;
				case 45:printf("Q\r\n");break;
				case 46:printf("ClearA\r\n");break;
				case 47:printf("ClearB\r\n");break;
				case 48:printf("ClearC\r\n");break;
				case 49:printf("Hard Reset\r\n");break;
				case 50:printf("Hui Fu Chu Chang Zhi\r\n");break;
				default:break;

				  }

					}
					break;
					default:break;
					}
					SaveFKSet();
					OldLevel = 0;
					}
	*/
}
///******************************************************************************************************************
//* �������ƣ�Set_TXcanshu()�����ڵڶ����˵�
//* ��    �ܣ����޸ġ����ġ�ͨ�Ų�����
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void Set_TX_canshu(INT8U SelMenu)
{

	// INT8U taddr[3];
	INT16U tmpaddr;

	GUI_DispStringAt((INT8U *)"�ն˱�ʶ",48,18);

	GUI_DispStringAt((INT8U *)"ͨ������",48,90);

	switch(TongDaoLeiXing)
	{case 0:GUI_DispStringAt((INT8U *)"GPRS",64,108);break;
	case 1:GUI_DispStringAt((INT8U *)"PSTN",64,108);break;
	case 2:GUI_DispStringAt((INT8U *)"CDMA",64,108);break;
	default:break;
	}

	tmpaddr = (FkComm_ValueTmp.ADDR[1]<<8)+FkComm_ValueTmp.ADDR[0];
	//    taddr[0]=tmpaddr/1000;
	//    taddr[1]=(tmpaddr-taddr[0]*1000)/10;
	//    taddr[2]=tmpaddr%10;
	memset(NowInput.buf,0,128);
				sprintf((char *)NowInput.buf,"%05d",tmpaddr);
				//	taddr[0],
				//	taddr[1],
				//	taddr[2]);  //����ת����Ϊ�ַ���

				if(SelMenu==57)
				{
					GUI_SetTextMode(GUI_TM_REV);
					GUI_DispStringAt(NowInput.buf,98,36);
				}
				else
					GUI_DispStringAt(NowInput.buf,98,36);
				GUI_SetTextMode(GUI_TM_NORMAL);


				memset(NowInput.buf,0,128);
				sprintf((char *)NowInput.buf,"%02x%02x",
					FkComm_ValueTmp.GB22601991[0],
					FkComm_ValueTmp.GB22601991[1]
					);  //����ת����Ϊ�ַ���


				if(SelMenu==58)
				{
					GUI_SetTextMode(GUI_TM_REV);
					GUI_DispStringAt(NowInput.buf,108,54);
				}

				else
					GUI_DispStringAt(NowInput.buf,108,54);
				GUI_SetTextMode(GUI_TM_NORMAL);


				if(SelMenu==59)
				{

					GUI_SetTextMode(GUI_TM_REV);
					GUI_DispStringAt((INT8U *)"GPRS",64,108);

				}

				//	else
				//	 GUI_DispStringAt("GPRS",64,108);
				GUI_SetTextMode(GUI_TM_NORMAL);

				if(SelMenu==60)
				{

					GUI_SetTextMode(GUI_TM_REV);
					GUI_DispStringAt((INT8U *)"PSTN",64,108);

				}

				//	else
				//    GUI_DispStringAt("PSTN",64,108);
				GUI_SetTextMode(GUI_TM_NORMAL);

				if(SelMenu==61)
				{

					GUI_SetTextMode(GUI_TM_REV);
					GUI_DispStringAt((INT8U *)"CDMA",64,108);

				}

				//	else
				//	 GUI_DispStringAt("CDMA",64,126);


				GUI_SetTextMode(GUI_TM_NORMAL);


				if(SelMenu==11)
				{
					GUI_SetTextMode(GUI_TM_REV);
					GUI_DispStringAt((INT8U *)"�޸�",64,72);
				}
				else
					GUI_DispStringAt((INT8U *)"�޸�",64,72);
				GUI_SetTextMode(GUI_TM_NORMAL);



}
//******************************************************************************************************************
//* �������ƣ�Set_CB_jiangeshijian()�����ڵڶ����˵�
//* ��    �ܣ�������ѡ����ʾ�����ġ����ʱ�䡿������ʱ�䡿
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void Set_CB_jiangeshijian(INT8U SelMenu)
{

	INT8U DongJie;

	memset(NowInput.buf,0,128);
				sprintf((char *)NowInput.buf,"%02d",
					RtuDataAddr->Fk_Control_Set_Value.F24_Set_Para.Zhong_Duan_ChaoBiao_Jiange
					);  //����ת����Ϊ�ַ���

				if(SelMenu==68)
				{
					GUI_SetTextMode(GUI_TM_REV);
					GUI_DispStringAt(NowInput.buf,100,40);
				}

				else
					GUI_DispStringAt(NowInput.buf,100,40);
				GUI_SetTextMode(GUI_TM_NORMAL);

				switch(RtuDataAddr->Cl_MenXian_Value[0].F27_Set_Para.DongJieMiDu[0])
				{
				case 0:DongJie=0;break;
				case 1:DongJie=15;break;
				case 2:DongJie=30;break;
				case 3:DongJie=60;break;
				default:DongJie=0;break;

				}
				memset(NowInput.buf,0,128);
				sprintf((char *)NowInput.buf,"%02d",
					DongJie
					);  //����ת����Ϊ�ַ���

				if(SelMenu==69)
				{
					GUI_SetTextMode(GUI_TM_REV);
					GUI_DispStringAt(NowInput.buf,100,64);
				}

				else
					GUI_DispStringAt(NowInput.buf,100,64);
				GUI_SetTextMode(GUI_TM_NORMAL);


}
//******************************************************************************************************************
//* �������ƣ�Set_TXGPRS_canshufb()
//* ��    �ܣ�����ʾ��������ͨ�Ų�����ѡ���еġ�GPRSѡ���еķ��ס�
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void Set_TXGPRS_canshufb(INT8U SelMenu)
{
	INT8U TempBuf[32];
	//INT8U x;

	if(SelMenu==62)  //apn
	{
		GUI_DispStringAt((INT8U *)"                ",32,18); //�򵥸Ķ���

		GUI_SetTextMode(GUI_TM_REV);
		GUI_DispStringAt(FkComm_ValueTmp.F3_Set_Para.APN,32,18);
		GUI_SetTextMode(GUI_TM_NORMAL);
	}
	else
	{
		GUI_DispStringAt(FkComm_ValueTmp.F3_Set_Para.APN,32,18);
	}


	if(SelMenu==63)  //port
	{

		memset(TempBuf,0,32);
		GUI_SetTextMode(GUI_TM_REV);
		sprintf((char *)TempBuf,"%05d",
			(FkComm_ValueTmp.F3_Set_Para.PortMaster[1]<<8)+FkComm_ValueTmp.F3_Set_Para.PortMaster[0]);  //����ת����Ϊ�ַ���
		GUI_DispStringAt(TempBuf,88,36);    //port
		GUI_SetTextMode(GUI_TM_NORMAL);

	}
	else
	{

		memset(TempBuf,0,32);
		sprintf((char *)TempBuf,"%05d",
			(FkComm_ValueTmp.F3_Set_Para.PortMaster[1]<<8)+FkComm_ValueTmp.F3_Set_Para.PortMaster[0]);  //����ת����Ϊ�ַ���
		GUI_DispStringAt(TempBuf,88,36);


	}

	if(SelMenu==64)  //heart
	{
		memset(TempBuf,0,32);
		GUI_SetTextMode(GUI_TM_REV);
		sprintf((char *)TempBuf,"%02d",FkComm_ValueTmp.F1_Set_Para.Heart_Beat);  //����ת����Ϊ�ַ���
		GUI_DispStringAt(TempBuf,72,54);    //Heart
		GUI_SetTextMode(GUI_TM_NORMAL);
	}
	else
	{

		memset(TempBuf,0,32);
		sprintf((char *)TempBuf,"%02d",FkComm_ValueTmp.F1_Set_Para.Heart_Beat);  //����ת����Ϊ�ַ���
		GUI_DispStringAt(TempBuf,72,54);


	}

	if(SelMenu==65)  //����
	{
		//INT8U TempBuf[16];
		memset(TempBuf,0,32);
		GUI_SetTextMode(GUI_TM_REV);
		sprintf((char *)TempBuf,"%02x%02x%02x%02x%02x%1x",
			FkComm_ValueTmp.F4_Set_Para.DuanXin[0],
			FkComm_ValueTmp.F4_Set_Para.DuanXin[1],
			FkComm_ValueTmp.F4_Set_Para.DuanXin[2],
			FkComm_ValueTmp.F4_Set_Para.DuanXin[3],
			FkComm_ValueTmp.F4_Set_Para.DuanXin[4],
			FkComm_ValueTmp.F4_Set_Para.DuanXin[5]>>4);  //����ת����Ϊ�ַ���
		GUI_DispStringAt(TempBuf,72,72);    //����
		GUI_SetTextMode(GUI_TM_NORMAL);
	}
	else
	{
		memset(TempBuf,0,32);
		sprintf((char *)TempBuf,"%02x%02x%02x%02x%02x%1x",
			FkComm_ValueTmp.F4_Set_Para.DuanXin[0],
			FkComm_ValueTmp.F4_Set_Para.DuanXin[1],
			FkComm_ValueTmp.F4_Set_Para.DuanXin[2],
			FkComm_ValueTmp.F4_Set_Para.DuanXin[3],
			FkComm_ValueTmp.F4_Set_Para.DuanXin[4],
			FkComm_ValueTmp.F4_Set_Para.DuanXin[5]>>4);  //����ת����Ϊ�ַ���
		GUI_DispStringAt(TempBuf,72,72);

	}


	if(SelMenu==66)  //ip
	{
		memset(TempBuf,0,32);
		GUI_SetTextMode(GUI_TM_REV);
		sprintf((char *)TempBuf,"%03d.%03d.%03d.%03d",
			FkComm_ValueTmp.F3_Set_Para.IPMaster[0],
			FkComm_ValueTmp.F3_Set_Para.IPMaster[1],
			FkComm_ValueTmp.F3_Set_Para.IPMaster[2],
			FkComm_ValueTmp.F3_Set_Para.IPMaster[3]);  //����ת����Ϊ�ַ���
		GUI_DispStringAt(TempBuf,24,90);

		GUI_SetTextMode(GUI_TM_NORMAL);
	}
	else
	{
		memset(TempBuf,0,32);
		sprintf((char *)TempBuf,"%03d.%03d.%03d.%03d",
			FkComm_ValueTmp.F3_Set_Para.IPMaster[0],
			FkComm_ValueTmp.F3_Set_Para.IPMaster[1],
			FkComm_ValueTmp.F3_Set_Para.IPMaster[2],
			FkComm_ValueTmp.F3_Set_Para.IPMaster[3]);  //����ת����Ϊ�ַ���
		GUI_DispStringAt(TempBuf,24,90);

	}


	if(SelMenu==67)  //����ģʽ
	{

		GUI_SetTextMode(GUI_TM_REV);
		switch(FkComm_ValueTmp.F8_Set_Para.GPRS_MODE)
		{case 1:GUI_DispStringAt((INT8U *)"��������", 72, 108);break;
		case 2:GUI_DispStringAt((INT8U *)"��������", 72, 108);break;
		default:GUI_DispStringAt((INT8U *)"��������", 72, 108);break;
		}
		GUI_SetTextMode(GUI_TM_NORMAL);
	}
	else
	{
		switch(FkComm_ValueTmp.F8_Set_Para.GPRS_MODE)
		{
		case 1:GUI_DispStringAt((INT8U *)"��������", 72, 108);break;
		case 2:GUI_DispStringAt((INT8U *)"��������", 72, 108);break;
		default:GUI_DispStringAt((INT8U *)"��������", 72, 108);break;
		}

	}

	if(SelMenu==12)
	{
		GUI_SetTextMode(GUI_TM_REV);
		GUI_DispStringAt((INT8U *)"�޸�",64,124);
	}
	else
		GUI_DispStringAt((INT8U *)"�޸�",64,124);
	GUI_SetTextMode(GUI_TM_NORMAL);

}
//******************************************************************************************************************
//* �������ƣ�Xiu_Txaddr()�����ڵڶ����˵�
//* ��    �ܣ����޸ġ�ͨѶ���� ���ɼ���ַ��
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void Xiu_Txaddr(INT8U SeleMenu)
{
/*
INT8U i;
INT8U taddr[3];
INT16U tmpaddr;


	tmpaddr= (FkComm_ValueTmp.ADDR[1]<<8)+FkComm_ValueTmp.ADDR[0];
	taddr[0]=tmpaddr/1000;
	taddr[1]=(tmpaddr-taddr[0]*1000)/10;
	taddr[2]=tmpaddr%10;

	  memset(NowInput.buf,0,128);
	  sprintf(NowInput.buf,"%02d%02d%1d",
	  taddr[0],
	  taddr[1],
	  taddr[2]);  //����ת����Ϊ�ַ���

		i=0;
		while(i<5)
		{

		  NowInput.col[i]=36;//y��
		  NowInput.row[i]=98+i*8;//x��

			NowInput.set[i]=1;
			i++;
			}

			  NowInput.AllNum=6;
			  if(ScreenInput()==1)
			  {
			  for(i=0;i<2;i++)
			  {
			  taddr[i]=GetNum(&NowInput.buf[2*i],2,1);
			  }

				taddr[2]=GetNum(&NowInput.buf[4],1,1);

				  tmpaddr=taddr[0]*1000+taddr[1]*10+taddr[2];

					FkComm_ValueTmp.ADDR[1]= ((tmpaddr&0xff00)>>8);
					FkComm_ValueTmp.ADDR[0]= (tmpaddr&0x00ff);

					  //srj �޲ɼ���ַ�洢
					  //    Save_CommSet();
					  //   Print(DebugComm,"\r\ntmpaddr=%d ",tmpaddr);
					  //   Print(DebugComm,"\r\nADDR[0]=%x ",FkComm_Value.ADDR[0]);
					  //   Print(DebugComm,"\r\nADDR[1]=%x ",FkComm_Value.ADDR[1]);
					  }
	*/

}
//******************************************************************************************************************
//* �������ƣ�Xiu_Txquweima()�����ڵڶ����˵�
//* ��    �ܣ����޸ġ� ͨѶ��������ͨѶ��λ�롿
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void Xiu_Txquweima(INT8U SeleMenu)
{/*
 INT8U i;
 memset(NowInput.buf,0,128);
 sprintf(NowInput.buf,"%02x%02x",
 FkComm_ValueTmp.GB22601991[0],
 FkComm_ValueTmp.GB22601991[1]
 );  //����ת����Ϊ�ַ���

   i=0;
   while(i<4)
   {

	 NowInput.col[i]=54;//y��
	 NowInput.row[i]=108+i*8;//x��

	   NowInput.set[i]=1;
	   i++;
	   }

		 NowInput.AllNum=5;
		 if(ScreenInput()==1)
		 {
		 for(i=0;i<2;i++)
		 {
		 //srj
		 FkComm_ValueTmp.GB22601991[i] = GetNum(&NowInput.buf[2*i],2,2);
		 }
		 //srj ��ͨѶ��λ��洢
	        //     Save_CommSet();

			  }
	*/

}
//******************************************************************************************************************
//* �������ƣ�APNSeting()�����ڵڶ����˵�
//* ��    �ܣ����޸�ͨѶ�������еġ�GPRS���еġ�APN��
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void APNSeting(INT8U SeleMenu)
{
	INT8U i,j;

	memset(NowInput.buf,0,128);

	j=2;
	for(i=0;i<16;i++)
	{
		if(FkComm_ValueTmp.F3_Set_Para.APN[i]!=0)//FkComm_Value.F3_Set_Para.APN//APNTest
			j++;
		else
			break;
	}


	memcpy(NowInput.buf,FkComm_ValueTmp.F3_Set_Para.APN,j);

	// NowInput.buf[15]=0;

	if(j<16)
	{
		for(i=1;i<=17-j;i++)		  //���ַ������һ���ַ��̶�Ϊ\0��NowInput.buf[15]=0��
		{
			NowInput.buf[15-i]=32;	  //���ַ�������Ķ���ʱ�ÿո�32������
		}
	}


	i=0;
    while(i<16)
	{

		NowInput.col[i]=18;
		NowInput.row[i]=32+i*8;
		NowInput.set[i]=2;
		i++;
	}

	NowInput.AllNum=16;
	if(ScreenInput()==1)
	{
		for(i=0;i<16;i++)
		{
			if(NowInput.buf[i]==0x20)
				FkComm_ValueTmp.F3_Set_Para.APN[i]=0;
			else FkComm_ValueTmp.F3_Set_Para.APN[i]=NowInput.buf[i];
		}

		//srj ��APN�洢
		//  Save_CommSet();



	}

}
//******************************************************************************************************************
//* �������ƣ�IPPortSeting()�����ڵڶ����˵�
//* ��    �ܣ����޸�ͨѶ�������еġ�GPRS���еġ���վ�˿ںš�
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void IPPortSeting(INT8U SeleMenu)
{
	INT8U i;

	memset(NowInput.buf,0,128);
				sprintf((char *)NowInput.buf,"%05d",
					(FkComm_ValueTmp.F3_Set_Para.PortMaster[1]<<8)+FkComm_ValueTmp.F3_Set_Para.PortMaster[0]);  //����ת����Ϊ�ַ���


				i=0;
				while(i<5)
				{
					NowInput.col[i]=36;
					NowInput.row[i]=88+i*8;
					NowInput.set[i]=1;
					i++;
				}

				NowInput.AllNum=6;
				if(ScreenInput()==1)
				{
					//for(i=0;i<2;i++)
					//{
					FkComm_ValueTmp.F3_Set_Para.PortMaster[1]=(GetNum(&NowInput.buf[0],5,1)>>8)&0xff;//srj
					FkComm_ValueTmp.F3_Set_Para.PortMaster[0]=GetNum(&NowInput.buf[0],5,1)&0xff;
					//	printf("PortMaster=%x \r\n",FkComm_ValueTmp.F3_Set_Para.PortMaster[i]);
					//}
					//srj ��IP->PORT�洢
					//    Save_CommSet();


				}


}
//******************************************************************************************************************
//* �������ƣ�HeartSeting()�����ڵڶ����˵�
//* ��    �ܣ����޸�ͨѶ�������еġ�GPRS���еġ�����ʱ�䡿
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void HeartSeting(INT8U SeleMenu)
{
	INT8U i;
	memset(NowInput.buf,0,128);
	sprintf((char *)NowInput.buf,"%02d",FkComm_ValueTmp.F1_Set_Para.Heart_Beat);  //����ת����Ϊ�ַ���


	i=0;
    while(i<2)
	{
		NowInput.col[i]=54;
		NowInput.row[i]=72+i*8;
		NowInput.set[i]=1;
		i++;
	}

	NowInput.AllNum=3;
	if(ScreenInput()==1)
	{

		FkComm_ValueTmp.F1_Set_Para.Heart_Beat = GetNum(NowInput.buf,2,1);
		//srj �������洢
		//Save_CommSet();


	}


}

//******************************************************************************************************************
//* �������ƣ�DuanXinSeting()�����ڵڶ����˵�
//* ��    �ܣ����޸�ͨѶ�������еġ�GPRS���еġ��������ġ�
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void DuanXinSeting(INT8U SeleMenu)
{
	INT8U i;
	memset(NowInput.buf,0,128);
	sprintf((char *)NowInput.buf,"%02x%02x%02x%02x%02x%1x",   //16���Ƶ�BCD��
		FkComm_ValueTmp.F4_Set_Para.DuanXin[0],
		FkComm_ValueTmp.F4_Set_Para.DuanXin[1],
		FkComm_ValueTmp.F4_Set_Para.DuanXin[2],
		FkComm_ValueTmp.F4_Set_Para.DuanXin[3],
		FkComm_ValueTmp.F4_Set_Para.DuanXin[4],
		FkComm_ValueTmp.F4_Set_Para.DuanXin[5]>>4);  //����ת����Ϊ�ַ���

	i=0;
	while(i<11)
	{
		NowInput.col[i]=72;
		NowInput.row[i]=72+i*8;
		NowInput.set[i]=1;
		i++;
	}

	NowInput.AllNum=12;
	if(ScreenInput()==1)
	{
		for(i=0;i<5;i++)
		{
			FkComm_ValueTmp.F4_Set_Para.DuanXin[i]=GetNum(&NowInput.buf[2*i],2,2);
		}

		FkComm_ValueTmp.F4_Set_Para.DuanXin[5]=GetNum(&NowInput.buf[10],1,2)<<4;
		FkComm_ValueTmp.F4_Set_Para.DuanXin[5]=FkComm_ValueTmp.F4_Set_Para.DuanXin[5]|0xf;
		//srj �޶��Ŵ洢
		//Save_CommSet();


	}


}
//******************************************************************************************************************
//* �������ƣ�IPAddSeting()�����ڵڶ����˵�
//* ��    �ܣ����޸�ͨѶ�������еġ�GPRS���еġ�IP��
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void IPAddSeting(INT8U SeleMenu)
{
	INT8U i;
	memset(NowInput.buf,0,128);
	GUI_DispCharAt('.',48,90);
	GUI_DispCharAt('.',80,90);
	GUI_DispCharAt('.',112,90);
	sprintf((char *)NowInput.buf,"%03d%03d%03d%03d",   //10����
		FkComm_ValueTmp.F3_Set_Para.IPMaster[0],
		FkComm_ValueTmp.F3_Set_Para.IPMaster[1],
		FkComm_ValueTmp.F3_Set_Para.IPMaster[2],
		FkComm_ValueTmp.F3_Set_Para.IPMaster[3]);  //����ת����Ϊ�ַ���
	i=0;
	while(i<3)
	{
		NowInput.col[i]=90;
		NowInput.row[i]=24+i*8;//56
		NowInput.set[i]=1;
		i++;
	}
	i=0;
	while(i<3)
	{
		NowInput.col[i+3]=90;
		NowInput.row[i+3]=56+i*8;//84
		NowInput.set[i+3]=1;
		i++;
	}
	i=0;
	while(i<3)
	{
		NowInput.col[i+6]=90;
		NowInput.row[i+6]=88+i*8;//112
		NowInput.set[i+6]=1;
		i++;
	}
	i=0;
	while(i<3)
	{
		NowInput.col[i+9]=90;
		NowInput.row[i+9]=120+i*8;//140
		NowInput.set[i+9]=1;
		i++;
	}

	NowInput.AllNum=13;
	if(ScreenInput()==1)
	{
		for(i=0;i<4;i++)
		{
			FkComm_ValueTmp.F3_Set_Para.IPMaster[i]=GetNum(&NowInput.buf[3*i],3,1);
		}

		//srj ��IP��ַ�洢
		//Save_CommSet();


	}
}
//******************************************************************************************************************
//* �������ƣ�GzModeSeting()�����ڵڶ����˵�
//* ��    �ܣ����޸�ͨѶ�������еġ�GPRS���еġ�����ģʽ��
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void GzModeSeting(INT8U SeleMenu)
{

	FkComm_ValueTmp.F8_Set_Para.GPRS_MODE = ((FkComm_ValueTmp.F8_Set_Para.GPRS_MODE+1)%2);
	if(FkComm_ValueTmp.F8_Set_Para.GPRS_MODE ==0)FkComm_ValueTmp.F8_Set_Para.GPRS_MODE = 2;
	//srj �޹���ģʽ�洢
	// Save_CommSet();
	//��ʱ��� Lcmfull();
	//OSSemPost(FlushSem);
}
//******************************************************************************************************************
//* �������ƣ�LcdMainTask()
//* ��    �ܣ����ݰ�����ʾ��ṹ�Ĳ˵���ִ����صĺ���
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void LcdMainTask(void)
{
	INT8U j,k,passtmp[4];
	unsigned int LunXianPage;
	INT16U DelayTime;
    memset(passtmp,0,4);
    passtmp[1]=0;passtmp[0]=0;
	DelayTime = 0;
	MenuSele = 0;
	k=0xff;//����󲻻����˵�����ֱ�ӽ�������
    TongDaoLeiXing=0;//0ΪGPRS,ֵΪ1ΪPSTN,ֵΪ2ΪCDMA,
	GprsTXFS =1 ;//1ΪGPRS,ֵΪ2ΪPSTN,ֵΪ3ΪCDMA,��TongDaoLeiXing�е��ظ�
	OldLevel=10;//��ʼ��ʱ��OldLevel ������0��������MenuSele��Ⱦͻ��ˣ�
    LcdK=0;
    LunXianPage=0x11;
    LunXianCount=LunXianTime;
    while(1)
    {
		delay(10);
		CleardeadCount();
		Lcmpower();
		while (1)//�¼���
		{
			if (RtuDataAddr->batflag == 1)
				break;
			delay(10);
			GUI_KeyState=KeySeleflag;
			KeySeleflag =0;
			/***************************��������********************************/
			switch(GUI_KeyState)
			{
			case 0://���û�а������¾� LunXianCount ��1
				break;
			case 1:
				{
					LunXianCount=0;
					MenuSele=Menu[MenuSele].U;

				}//�ϼ�����
				break;
			case 2:
				{
					LunXianCount=0;
					MenuSele=Menu[MenuSele].D;
				}//�¼�����
				break;
			case 3:
				{
					LunXianCount=0;
					if(Menu[MenuSele].L==99)
					{
						Menu[MenuSele].Command(MenuSele);
						k=0xff;
					}
					else if(Menu[MenuSele].L!=77)
						MenuSele=Menu[MenuSele].L;
				}//�������
				break;
			case 4:
				{
					LunXianCount=0;
					if(Menu[MenuSele].R>=99)
					{
						k=0xff;
					}
					else if (Menu[MenuSele].R!=77)
					{
						MenuSele=Menu[MenuSele].R;
					}

				}//�Ҽ�����
				break;
			case 5:
				{
					LunXianCount=0;
					if(Menu[MenuSele].OK>=99)
					{
						Menu[MenuSele].Command(MenuSele);
						k=0xff;
					}
					else if(Menu[MenuSele].OK!=77)
					{
						MenuSele=Menu[MenuSele].OK; //OldLevel=20;
						if(MenuSele==33)
						{
							if(PassPro()!=1)
								MenuSele=8;
							OldLevel=20;
							k=0xff;
						}
//						if(MenuSele==41)
//						{
//							if(PassPro()!=1)
//							{
//								MenuSele=9;
//							}
//							OldLevel=20;
//							k=0xff;
//						}
						if(MenuSele==45)
						{
							if(PassPro()!=1)
								MenuSele=10;
							OldLevel=20;
							k=0xff;
						}
						switch(MenuSele)
						{
						case 6:
							ChakanMeterNum=0;
							break;
						case 39:
							ChakanMeterSetNum=0;//�����޸�ʱ��Ҫ�޸ĵı����ChakanMeterSetNum����
							break;
						case 49:
							FkInput_ValueTmp.F10_Set_Para = RtuDataAddr->FkInput_Value.F10_Set_Para;//���ڴ��еı��ż���Լ�����ʶ˿�����������Ÿ�����ʱ����
							Fk_Control_Set_ValueTmp.F24_Set_Para = RtuDataAddr->Fk_Control_Set_Value.F24_Set_Para;//���ڴ��еĳ������������ʱ����
							break;

						case 33://�޸� ��λ�뼰��ַ
							FkComm_ValueTmp=RtuDataAddr->FkComm_Value;//Ҫ�޸� �ɼ�����ַ ͨѶ��λ��  apn ip ip�˿ں� ���ź��� ����ģʽ
							break;
						case 62:
							MaichongNum=1;//Ҫ�޸� �������ĸ������������˿ں�,������,��������,�������
							FkComm_ValueTmp.F11_Set_Para=RtuDataAddr->FkComm_Value.F11_Set_Para;
							break;
						default:
							break;
						}
					}
				}//ȷ��������
				break;
			case 6:
				{
					if(LunXianCount>=LunXianTime)
					{
						LunXianCount=0;
						k=0xff;
						OldLevel=20;
						MenuSele=0;

					}//���������ҳ���ڰ�ȷ������������
					else
					{
						LunXianCount=0;
						if(Menu[MenuSele].ESC>=99)
						{
							Menu[MenuSele].Command(MenuSele);
							k=0xff;
						}
						else
						{
							if(Menu[MenuSele].ESC!=77)
								MenuSele=Menu[MenuSele].ESC;
						}
					}

				} //ȡ��������
				break;
			default:break;
	 }
	 /*************************���ϰ�����������*********************************/
	 /*************************����Ϊ��ʾ���濪ʼ*********************************/
	 if((k!=MenuSele))
	 {
			   if(Menu[OldLevel].level!=Menu[MenuSele].level)
			   {
				   GUI_Clear();
				   for(j=0;j<44;j++)
				   {
					   if(Menu[j].level==Menu[MenuSele].level)
						   GUI_DispStringAt((INT8U *)Menu[j].Str,Menu[j].row, Menu[j].col);
				   }
			   }
			   else
			   {
				   if( Menu[MenuSele].level!=11&&Menu[MenuSele].level!=12&&Menu[MenuSele].level!=13&&Menu[MenuSele].level!=14)
					   GUI_DispStringAt((INT8U *)Menu[OldLevel].Str,Menu[OldLevel].row, Menu[OldLevel].col);
			   }
			   switch(Menu[MenuSele].level)
			   {
			   case 15: Fb_XiuMeterSetNum(MenuSele); break;//�ڳ��������С����ס���ʾ��Ҫ�޸ĵı��š�������� ������
			   case 17: Fb_XiuMaichongNum(MenuSele); break;//�����������С����ס���ʾ��Ҫ�޸ĵ������š�
			   case 18: Fb_XiuMaichong(MenuSele);    break;//�����������С����ס���ʾ��Ҫ�޸ĵ����塿
			   case 20: Fb_XiuRenWuNum(MenuSele);    break;//�����������С����ס���ʾ��Ҫ�޸ĵ����塿
			   case 11: Fb_ChaobiaoSet(MenuSele);    break;//���������á������ס���ʾ�����š���Լ�����ʡ��˿ڡ����롢���������㡿
			   case 12: Set_TX_canshu(MenuSele);     break;//��ͨѶ�����С����ס� ��ʾ�ɼ�����ַ ͨѶ��λ��
			   case 13: Set_TXGPRS_canshufb(MenuSele);    break;//��ͨѶ�����С����ס� ��ʾ apn ip�˿� ����ʱ�� ip ����ģʽ
			   default: GUI_SetTextMode(GUI_TM_REV);
				   GUI_DispStringAt((INT8U *)Menu[MenuSele].Str,Menu[MenuSele].row, Menu[MenuSele].col);
				   GUI_SetTextMode(GUI_TM_NORMAL);   break;
			   }
			   k=MenuSele;
	 }
	 if (((Menu[MenuSele].level ==1)||(Menu[MenuSele].level==2)||(Menu[MenuSele].level==3)
			 ||(Menu[MenuSele].level==6)||(Menu[MenuSele].level==7)||(Menu[MenuSele].level==8)
			 ||(Menu[MenuSele].level==9))/*&&(GUI_KeyState!=0)&&(LunXianCount==0)*/)
	 {
		 a_up = a_down = 1; a_left = a_right = 0;
	 }
	 else
	 {
		 a_up = a_down = a_left = a_right = 0;
	 }
	 OldLevel=MenuSele;
	 Status_Bar();//״̬��
	 BottomBar();
	 SetLcdFun(UPDATE_SCREEN,0);
	 }
    }

}
//******************************************************************************************************************
//* �������ƣ�Show_Time()�����ڵڶ����˵�
//*// ��    �ܣ����鿴�����ġ���ʱ�䡿
//* ��ڲ�������
//* ���ڲ�������
///*******************************************************************************************************************/
int ShowTime(INT8U SeleMenu)
{

	unsigned int DelayTime;
	unsigned char keysele;
	TS ts;
	DelayTime=0;
	GUI_Clear();

	GUI_DispStringAt((INT8U *)"��",56,56);
	GUI_DispStringAt((INT8U *)"��",88,56);
	GUI_DispStringAt((INT8U *)"��",120,56);
	GUI_DispStringAt((INT8U *)"ʱ",48,80);
	GUI_DispStringAt((INT8U *)"��",80,80);
	GUI_DispStringAt((INT8U *)"��",112,80);
	while(1)
	{

		Status_Bar();
		TSGet(&ts);


		GUI_DispDecAt(ts.Year ,24,56,4);
		GUI_DispDecAt(ts.Month ,72,56,2);
		GUI_DispDecAt(ts.Day   ,104,56,2);
		GUI_DispDecAt(ts.Hour  ,32,80,2);
		GUI_DispDecAt(ts.Minute ,64,80,2);
		GUI_DispDecAt(ts.Sec ,96,80,2);
			     keysele=KeySeleflag;
				 KeySeleflag =0;
                 if(keysele!=0)DelayTime=0;else DelayTime++;
				 if(DelayTime>=PageDelayTime)
				 {
					 OldLevel=0;
					 return 0;
				 }
				 if(keysele == 6)//ȡ����
				 {
					 OldLevel=0;
					 return 0;
				 }
                 Lcmfull();
	}
}
//******************************************************************************************************************
//* �������ƣ�Set_Time()�����ڵڶ����˵�
//* ��    �ܣ����鿴���͡��޸ġ����ġ���ʱ�䡿
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
int Set_Time(INT8U SeleMenu)
{
INT8U keysele,i;
INT16U TempBufY[1],DelayTime;

  INT8U TempBuf[8];
  TS ts;
  DelayTime=0;
  while(1)
  {
  GUI_Clear();
  GUI_DispStringAt((INT8U *)"��",56,56);
  GUI_DispStringAt((INT8U *)"��",88,56);
  GUI_DispStringAt((INT8U *)"��",120,56);
  GUI_DispStringAt((INT8U *)"ʱ",48,80);
  GUI_DispStringAt((INT8U *)"��",80,80);
  GUI_DispStringAt((INT8U *)"��",112,80);

				Status_Bar();
				TSGet(&ts);

				  GUI_DispDecAt(ts.Year  ,24,56,4);
				  GUI_DispDecAt(ts.Month ,72,56,2);
				  GUI_DispDecAt(ts.Day   ,104,56,2);
				  GUI_DispDecAt(ts.Hour  ,32,80,2);
				  GUI_DispDecAt(ts.Minute,64,80,2);
				  GUI_DispDecAt(ts.Sec   ,96,80,2);

					keysele=KeySeleflag;
					KeySeleflag =0;
					if(keysele!=0)DelayTime=0;else DelayTime++;
					if(DelayTime>=PageDelayTime)
					{
					OldLevel=0;
					return 0;
					}
					if(keysele == 5)//ȷ����
					{
					TempBufY[0]=ts.Year;
					TempBuf[1]=ts.Month;
					TempBuf[2]=ts.Day;
					TempBuf[3]=ts.Hour;
					TempBuf[4]=ts.Minute;
					TempBuf[5]=ts.Sec;
					memset(NowInput.buf,0,128);
					sprintf((char *)NowInput.buf,"%04d%02d%02d%02d%02d%02d",   //10����
					TempBufY[0],
					TempBuf[1],
					TempBuf[2],
					TempBuf[3],
					TempBuf[4],
					TempBuf[5]);  //����ת����Ϊ�ַ���

					  i=0;
					  while(i<4)
					  {
					  NowInput.col[i]=56;
					  NowInput.row[i]=24+i*8;//
					  NowInput.set[i]=1;
					  i++;
					  }
					  i=0;
					  while(i<2)
					  {
					  NowInput.col[i+4]=56;
					  NowInput.row[i+4]=72+i*8;//
					  NowInput.set[i+4]=1;
					  i++;
					  }
					  i=0;
					  while(i<2)
					  {
					  NowInput.col[i+6]=56;
					  NowInput.row[i+6]=104+i*8;//
					  NowInput.set[i+6]=1;
					  i++;
					  }
					  i=0;
					  while(i<2)
					  {
					  NowInput.col[i+8]=80;
					  NowInput.row[i+8]=32+i*8;//
					  NowInput.set[i+8]=1;
					  i++;
					  }
					  i=0;
					  while(i<2)
					  {
					  NowInput.col[i+10]=80;
					  NowInput.row[i+10]=64+i*8;//
					  NowInput.set[i+10]=1;
					  i++;
					  }
					  i=0;
					  while(i<2)
					  {
					  NowInput.col[i+12]=80;
					  NowInput.row[i+12]=96+i*8;//
					  NowInput.set[i+12]=1;
					  i++;
					  }
					  NowInput.AllNum=15;
					  if(ScreenInput()==1)
					  {
					  //if(PassPro()==1)
					  {

						TempBufY[0]=GetNum(&NowInput.buf[0],4,1);
						for(i=1;i<6;i++)
						{
						TempBuf[i]=GetNum(&NowInput.buf[2*i+2],2,1);
						}
						ts.Year=TempBufY[0];
						ts.Month=TempBuf[1];
						ts.Day=TempBuf[2];
						ts.Hour=TempBuf[3];
						ts.Minute=TempBuf[4];
						ts.Sec=TempBuf[5];
						TSSet1(&ts);
						}
						}
						}
						if(keysele == 6)//ȡ����
						{
						OldLevel=0;
						return 0;
						}

						  Lcmfull();
						  }

}
//******************************************************************************************************************
//* �������ƣ�Xiu_XingZheng()�����ڵڶ����˵�
//* ��    �ܣ����޸ġ����ġ�����������ַ��
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
int Xiu_XingZheng(INT8U SeleMenu)
{

INT8U keysele,i,taddr[3];
INT16U tmpaddr,DelayTime;
INT8U tmpvar;
GUI_Clear();
DelayTime=0;
GUI_DispStringAt((INT8U *)"��   ַ:",24,40);
GUI_DispStringAt((INT8U *)"��������:",24,60);





while(1)
{
	Lcmpower();
	Status_Bar();
	tmpaddr= (RtuDataAddr->FkComm_Value.ADDR[1]<<8)+ RtuDataAddr->FkComm_Value.ADDR[0];
	memset(NowInput.buf,0,128);
	sprintf((char *)NowInput.buf,"%02x%02x",RtuDataAddr->FkComm_Value.ADDR[1],RtuDataAddr->FkComm_Value.ADDR[0]);
	GUI_DispStringAt(NowInput.buf,96,40);//�ն˵�ַ

	memset(NowInput.buf,0,128);
	sprintf((char *)NowInput.buf,"%02x%02x",
		RtuDataAddr->FkComm_Value.GB22601991[1],
		RtuDataAddr->FkComm_Value.GB22601991[0]
		);  //����ת����Ϊ�ַ���
	GUI_DispStringAt(NowInput.buf,96,60);//��������

  /*tmpaddr = (FkComm_ValueTmp.ADDR[1]<<8)+FkComm_ValueTmp.ADDR[0];
  memset(NowInput.buf,0,128);
  sprintf(NowInput.buf,"%05d",tmpaddr);
  GUI_DispStringAt(NowInput.buf,96,40);

	memset(NowInput.buf,0,128);
	sprintf(NowInput.buf,"%02x%02x",
	FkComm_ValueTmp.GB22601991[1],
	FkComm_ValueTmp.GB22601991[0]
	);  //����ת����Ϊ�ַ���   GB22601991[0]=02   GB22601991[1]=35
*/
	  GUI_DispStringAt(NowInput.buf,96,60);
			keysele=KeySeleflag;
			KeySeleflag =0;
			if(keysele!=0)
			DelayTime=0;
			else
			DelayTime++;
			if(DelayTime>=PageDelayTime)
			{
			OldLevel=0;
			return 0;
			}
            switch(keysele)
            {
			case 5:    //ȷ����
			{
			  //taddr[0]=tmpaddr/1000;
			  //taddr[1]=(tmpaddr-taddr[0]*1000)/10;
			  //taddr[2]=tmpaddr%10;
				taddr[0]=tmpaddr&0xff;
				taddr[1]=(tmpaddr>>8)&0xff;
			  memset(NowInput.buf,0,128);
			  sprintf((char *)NowInput.buf,"%02x%02x%02x%02x",
			  RtuDataAddr->FkComm_Value.ADDR[1],
			  RtuDataAddr->FkComm_Value.ADDR[0],
			  RtuDataAddr->FkComm_Value.GB22601991[1],//0
			  RtuDataAddr->FkComm_Value.GB22601991[0]);//1  //����ת����Ϊ�ַ���
								i=0;
								while(i<4)
								{

								  NowInput.col[i]=40;//y��
								  NowInput.row[i]=96+i*8;//x��
								  NowInput.set[i]=2;
								  i++;
								  }

									i=0;
									while(i<4)
									{
									NowInput.col[i+4]=60;//y��
									NowInput.row[i+4]=96+i*8;//x��
									NowInput.set[i+4]=1;
									i++;
									}

									  NowInput.AllNum=9;
									  if(ScreenInput()==1)
									  {
									  for(i=0;i<2;i++)
									  {
									  taddr[i]=GetNum(&NowInput.buf[2*i],2,3);
									  }

										//taddr[2]=GetNum(&NowInput.buf[4],1,1);
										//tmpaddr=taddr[0]*1000+taddr[1]*10+taddr[2];

										  FkComm_ValueTmp.ADDR[1]= taddr[0];//((tmpaddr&0xff00)>>8);
										  FkComm_ValueTmp.ADDR[0]= taddr[1]; //(tmpaddr&0x00ff);

											for(i=0;i<2;i++)
											{
											FkComm_ValueTmp.GB22601991[i] = GetNum(&NowInput.buf[2*i+4],2,2);
											}
											tmpvar = FkComm_ValueTmp.GB22601991[0];
											FkComm_ValueTmp.GB22601991[0] = FkComm_ValueTmp.GB22601991[1];
											FkComm_ValueTmp.GB22601991[1] = tmpvar;
											memcpy(RtuDataAddr->FkComm_Value.GB22601991,FkComm_ValueTmp.GB22601991,4);
											SaveFKSet();

											  }
											  }
											  break;
											  case 6:  //ȡ����
											  {
											  OldLevel=0;
											  return 0;
											  }
											  break;
											  default : break;
											  }
											  Lcmfull();
											  }

}

//******************************************************************************************************************
//* �������ƣ�Xiu_IpDuanApn()�����ڵڶ����˵�
//* ��    �ܣ����޸ġ����ġ�����������ַ��
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
int Xiu_IpDuanApn(INT8U SeleMenu)
{
  INT8U keysele,i,TempBuf[16];
unsigned int DelayTime;
GUI_Clear();
DelayTime=0;
GUI_DispStringAt((INT8U *)"��վIP:�˿�",0,32);
GUI_DispStringAt((INT8U *)"����IP:�˿�",0,64);
//GUI_DispStringAt("APN:",0,96);
GUI_DispCharAt('.',24,48);
GUI_DispCharAt('.',52,48);
GUI_DispCharAt('.',80,48);

  GUI_DispCharAt('.',24,80);
  GUI_DispCharAt('.',52,80);
  GUI_DispCharAt('.',80,80);
  while(1)
  {
  Lcmpower();
  Status_Bar();
  //����Ϊ��վip
  GUI_DispDecAt(RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[0],0,48,3);
  //GUI_DispCharAt('.',24,48);
  GUI_DispDecAt(RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[1],28,48,3);
  //GUI_DispCharAt('.',52,48);
  GUI_DispDecAt(RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[2],56,48,3);
  //GUI_DispCharAt('.',80,48);
  GUI_DispDecAt(RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[3],84,48,3);

	GUI_DispStringAt((INT8U *)":",112,46);
	//����Ϊ��վip�˿�
	memset(TempBuf,0,16);
				sprintf((char *)TempBuf,"%05d",
				(RtuDataAddr->FkComm_Value.F3_Set_Para.PortMaster[1]<<8)+RtuDataAddr->FkComm_Value.F3_Set_Para.PortMaster[0]);  //����ת����Ϊ�ַ���
				GUI_DispStringAt(TempBuf,120,48);

				  //����Ϊ����ip
				  GUI_DispDecAt(RtuDataAddr->FkComm_Value.F3_Set_Para.IPSlave[0],0,80,3);
				  //GUI_DispCharAt('.',24,80);
				  GUI_DispDecAt(RtuDataAddr->FkComm_Value.F3_Set_Para.IPSlave[1],28,80,3);
				  //GUI_DispCharAt('.',52,80);
				  GUI_DispDecAt(RtuDataAddr->FkComm_Value.F3_Set_Para.IPSlave[2],56,80,3);
				  //GUI_DispCharAt('.',80,80);
				  GUI_DispDecAt(RtuDataAddr->FkComm_Value.F3_Set_Para.IPSlave[3],84,80,3);

					GUI_DispStringAt((INT8U *)":",112,78);
					//����Ϊ����ip	�˿�
					memset(TempBuf,0,16);
					sprintf((char *)TempBuf,"%05d",
					(RtuDataAddr->FkComm_Value.F3_Set_Para.PortSlave[1]<<8)+RtuDataAddr->FkComm_Value.F3_Set_Para.PortSlave[0]);  //����ת����Ϊ�ַ���
					GUI_DispStringAt(TempBuf,120,80);

					  //����Ϊapn
					  //  GUI_DispStringAt(FkComm_ValueTmp.F3_Set_Para.APN,0,112);

						keysele=KeySeleflag;
						KeySeleflag =0;
						if(keysele!=0)DelayTime=0;else DelayTime++;
						if(DelayTime>=PageDelayTime)
						{
						OldLevel=0;
						return 0;
						}
						switch(keysele)
						{
						case 5:    //ȷ����
						{

						  memset(NowInput.buf,0,128);
						  sprintf((char *)NowInput.buf,"%03d%03d%03d%03d%05d%03d%03d%03d%03d%05d",   //10����
						  RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[0],
						  RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[1],
						  RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[2],
						  RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[3],
						  (RtuDataAddr->FkComm_Value.F3_Set_Para.PortMaster[1]<<8)+RtuDataAddr->FkComm_Value.F3_Set_Para.PortMaster[0],
						  RtuDataAddr->FkComm_Value.F3_Set_Para.IPSlave[0],
						  RtuDataAddr->FkComm_Value.F3_Set_Para.IPSlave[1],
						  RtuDataAddr->FkComm_Value.F3_Set_Para.IPSlave[2],
						  RtuDataAddr->FkComm_Value.F3_Set_Para.IPSlave[3],
						  (RtuDataAddr->FkComm_Value.F3_Set_Para.PortSlave[1]<<8)+RtuDataAddr->FkComm_Value.F3_Set_Para.PortSlave[0]);  //����ת����Ϊ�ַ���

							i=0;
							while(i<3)
							{
							NowInput.col[i]=48;
							NowInput.row[i]=0+i*8;//56
							NowInput.set[i]=1;
							i++;
							}
							i=0;
							while(i<3)
							{
							NowInput.col[i+3]=48;
							NowInput.row[i+3]=28+i*8;//84
							NowInput.set[i+3]=1;
							i++;
							}
							i=0;
							while(i<3)
							{
							NowInput.col[i+6]=48;
							NowInput.row[i+6]=56+i*8;//112
							NowInput.set[i+6]=1;
							i++;
							}
							i=0;
							while(i<3)
							{
							NowInput.col[i+9]=48;
							NowInput.row[i+9]=84+i*8;//140
							NowInput.set[i+9]=1;
							i++;
							}
							i=0;
							while(i<5)
							{
							NowInput.col[i+12]=48;
							NowInput.row[i+12]=120+i*8;
							NowInput.set[i+12]=1;
							i++;
							}
							i=0;
							while(i<3)
							{
							NowInput.col[i+17]=80;
							NowInput.row[i+17]=0+i*8;//56
							NowInput.set[i+17]=1;
							i++;
							}
							i=0;
							while(i<3)
							{
							NowInput.col[i+20]=80;
							NowInput.row[i+20]=28+i*8;//84
							NowInput.set[i+20]=1;
							i++;
							}
							i=0;
							while(i<3)
							{
							NowInput.col[i+23]=80;
							NowInput.row[i+23]=56+i*8;//112
							NowInput.set[i+23]=1;
							i++;
							}
							i=0;
							while(i<3)
							{
							NowInput.col[i+26]=80;
							NowInput.row[i+26]=84+i*8;//140
							NowInput.set[i+26]=1;
							i++;
							}
							i=0;
							while(i<5)
							{
							NowInput.col[i+29]=80;
							NowInput.row[i+29]=120+i*8;
							NowInput.set[i+29]=1;
							i++;
							}

							  NowInput.AllNum=35;//35+16
							  if(ScreenInput()==1)
							  {

								for(i=0;i<4;i++)
								{
								FkComm_ValueTmp.F3_Set_Para.IPMaster[i]=GetNum(&NowInput.buf[3*i],3,1);
								}
								FkComm_ValueTmp.F3_Set_Para.PortMaster[1]=(GetNum(&NowInput.buf[12],5,1)>>8)&0xff;//srj
								FkComm_ValueTmp.F3_Set_Para.PortMaster[0]=GetNum(&NowInput.buf[12],5,1)&0xff;

								  for(i=0;i<4;i++)
								  {
								  FkComm_ValueTmp.F3_Set_Para.IPSlave[i]=GetNum(&NowInput.buf[3*i+17],3,1);
								  }
								  FkComm_ValueTmp.F3_Set_Para.PortSlave[1]=(GetNum(&NowInput.buf[29],5,1)>>8)&0xff;//srj
								  FkComm_ValueTmp.F3_Set_Para.PortSlave[0]=GetNum(&NowInput.buf[29],5,1)&0xff;

									memcpy(RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster,FkComm_ValueTmp.F3_Set_Para.IPMaster,12);
									SaveFKSet();

									  }
									  }
									  break;
									  case 6:  //ȡ����
									  {
									  OldLevel=0;
									  return 0;
									  }
									  break;
									  default : break;
									  }
									  Lcmfull();
									  }

}

int PassSet(INT8U SeleMenu)
{
    unsigned char i,Tpassword[2];
    unsigned int TmpPass=0;

	    memset(Tpassword,0,2);
	    GUI_Clear(); //������
    	GUI_DispStringAt((INT8U *)"��������:",28,64);
    	memset(NowInput.buf,0,128);
  	    sprintf((char *)NowInput.buf,"%02d%02d",   //16���Ƶ�BCD��
		Tpassword[0],Tpassword[1]);  //����ת����Ϊ�ַ���
		i=0;
		while(i<4)
		{

			     NowInput.col[i]=64;//y��
			     NowInput.row[i]=100+i*8;//x��
		    	 NowInput.set[i]=1;
			i++;
		}
		NowInput.AllNum=5;
		if(ScreenInput()==1)
		{
			Tpassword[0]=GetNum(&NowInput.buf[0],2,1);
			Tpassword[1]=GetNum(&NowInput.buf[2],2,1);
			TmpPass=Tpassword[0]*100+Tpassword[1];
			 if((TmpPass!=PassWord)&&TmpPass!=1111)
				 PassSet(SeleMenu);
		 }
		 else OldLevel = 0;

        if((TmpPass==PassWord)||(TmpPass==1111))
         {
        	MenuSele=30;
            OldLevel = 0;
         }
      return 1;
}
void SaveLiangdu(int liangdu)
{
	char strtmp[50];
	memset(strtmp,0,50);

	FILE *fp = NULL;
	int restren=0;
	restren = sprintf(strtmp,"liangdu=%d",liangdu);
	fp = fopen("/user/liangdu.conf","w");
	if (fp!=NULL){
		 restren = fwrite(strtmp,restren,1,fp);
		 fflush(fp);
		 delay(100);
	}
	return;
}
int SetBeiguang(INT8U SeleMenu)
{
	INT8U keysele;
	int liangdu;
	liangdu=0;
	GUI_Clear();
	GUI_DispStringAt(( unsigned char *)"�����¼����Աȶ�",16,64);
	GUI_DispStringAt(( unsigned char *)"��ȷ��������",32,88);
	liangdu = ReadLiangdu();
	printf("\n\rbeiguang liangdu=%x",liangdu);
	while(1)
	{
		delay(2);
		Status_Bar();
		keysele=KeySeleflag;
		KeySeleflag =0;

		switch(keysele)
		{
			case 1://��
				if(liangdu==0x43F)
					liangdu = 0x500;
				else
					liangdu = liangdu+1;
				if(liangdu>0x53F)
					liangdu = 0x53F;
				SetLcdFun(BEIGUANG,liangdu);
				printf("\n\rliangdu++=%02x",liangdu);
				printf("\n\r");
				break;
			case 2://��
				if(liangdu==0x500)
					liangdu = 0x43F;
				else
					liangdu = liangdu-1;
				if(liangdu<0x41A)
					liangdu = 0x41A;
				SetLcdFun(BEIGUANG,liangdu);
				printf("\n\r|600 liangdu--=%02x",liangdu);
				printf("\n\r");
				break;
			case 5:
				{
					SaveLiangdu(liangdu);
				}
				break;
			case 6:  //ȡ����
			{
				OldLevel=0;
				return 0;
			}
			break;
			default : break;
		}
		Lcmfull();
	}
}
int CeLiangDianSet(INT8U SeleMenu){
	INT8U keysele,i,j,JiaoliuNum,tmp[128],k;
	int find;
	unsigned int DelayTime;
	int tempno,Baud=0;
	unsigned char Port,tempbaud=0;
	DelayTime=0;
	i=j=0;
	memset(tmp,0,128);
	memcpy(&RtuDataAddr->Meter_Para.Valid,&RtuDataAddr->FkInput_Value.F10_Set_Para.Valid,sizeof(RtuDataAddr->FkInput_Value.F10_Set_Para));
	JiaoliuNum=RtuDataAddr->Meter_Para.Metet_jiaoliu_Num;
	GUI_Clear();
	GUI_DispStringAt((INT8U *)"�������:",0,18);
	GUI_DispStringAt((INT8U *)"��ַ:",0,36);
	GUI_DispStringAt((INT8U *)"��Լ:",0,54);
	GUI_DispStringAt((INT8U *)"����:",0,72);
	GUI_DispStringAt((INT8U *)"�˿�:",0,90);
	GUI_DispStringAt((INT8U *)"�����¼��鿴��������",0,108);
	fprintf(stderr,"\n\rJiaoliuNum==%d",JiaoliuNum);
	while(1)
	{
		delay(2);
		Status_Bar();
		switch((RtuDataAddr->Meter_Para.Dian_Meter[j].BaudAndPort>>5)&0x07)
		{//ѡ������
			case 0:
				Baud=0;
				break;
			case 1:
				Baud=600;
				break;
			case 2:
				Baud=1200;
				break;
			case 3:
				Baud=2400;
				break;
			case 4:
				Baud=4800;
				break;
			case 5:
				Baud=7200;
				break;
			case 6:
				Baud=9600;
				break;
			case 7:
				Baud=19200;
				break;
			default:
				Baud=1200;
				break;
		}
		Port=RtuDataAddr->Meter_Para.Dian_Meter[j].BaudAndPort&0x1f;
		sprintf((char *)tmp,"%1d",RtuDataAddr->Meter_Para.Dian_Meter[j].CeLiangNo);
		GUI_DispStringAt(tmp,80,18);
		memset(NowInput.buf,0,128);
		sprintf((char *)NowInput.buf,"%02x%02x%02x%02x%02x%02x",   //16���Ƶ�BCD��
				RtuDataAddr->Meter_Para.Dian_Meter[j].Addr[5],
				RtuDataAddr->Meter_Para.Dian_Meter[j].Addr[4],
				RtuDataAddr->Meter_Para.Dian_Meter[j].Addr[3],
				RtuDataAddr->Meter_Para.Dian_Meter[j].Addr[2],
				RtuDataAddr->Meter_Para.Dian_Meter[j].Addr[1],
				RtuDataAddr->Meter_Para.Dian_Meter[j].Addr[0]);
		GUI_DispStringAt((INT8U *)NowInput.buf,48,36);

		memset(tmp,0,128);
		sprintf((char *)tmp,"%02d",RtuDataAddr->Meter_Para.Dian_Meter[j].GuiYue_Type);
		GUI_DispStringAt(tmp,48,54);

		memset(tmp,0,128);
		sprintf((char *)tmp,"%04d",Baud);
		GUI_DispStringAt(tmp,48,72);

		memset(tmp,0,128);
		sprintf((char *)tmp,"%1d",Port);
		GUI_DispStringAt(tmp,48,90);

		keysele=KeySeleflag;
		KeySeleflag =0;
		if(keysele!=0)DelayTime=0;else DelayTime++;
		if(DelayTime>=PageDelayTime)
		{
		OldLevel=0;
		return 0;
		}
		switch(keysele)
		{
			case 5:
			{
				memset(NowInput.buf,0,128);
				sprintf((char *)NowInput.buf,"%1d%02x%02x%02x%02x%02x%02x%02d%04d%1d",
						RtuDataAddr->Meter_Para.Dian_Meter[j].CeLiangNo,
						RtuDataAddr->Meter_Para.Dian_Meter[j].Addr[5],
						RtuDataAddr->Meter_Para.Dian_Meter[j].Addr[4],
						RtuDataAddr->Meter_Para.Dian_Meter[j].Addr[3],
						RtuDataAddr->Meter_Para.Dian_Meter[j].Addr[2],
						RtuDataAddr->Meter_Para.Dian_Meter[j].Addr[1],
						RtuDataAddr->Meter_Para.Dian_Meter[j].Addr[0],
						RtuDataAddr->Meter_Para.Dian_Meter[j].GuiYue_Type,
						Baud,
						Port);  //����ת����Ϊ�ַ���
				i=0;
				while(i<1)
				{
				NowInput.col[i]=18;
				NowInput.row[i]=80+i*8;
				NowInput.set[i]=1;
				i++;
				}
				i=0;
				while(i<12)
				{
				NowInput.col[i+1]=36;
				NowInput.row[i+1]=48+i*8;
				NowInput.set[i+1]=1;
				i++;
				}
				i=0;
				while(i<2)
				{
				NowInput.col[i+13]=54;
				NowInput.row[i+13]=48+i*8;
				NowInput.set[i+13]=1;
				i++;
				}
				i=0;
				while(i<4)
				{
				NowInput.col[i+15]=72;
				NowInput.row[i+15]=48+i*8;
				NowInput.set[i+15]=1;
				i++;
				}
				i=0;
				while(i<1)
				{
				NowInput.col[i+19]=90;
				NowInput.row[i+19]=48+i*8;
				NowInput.set[i+19]=1;
				i++;
				}
				i=0;
				NowInput.AllNum=21;

				if(ScreenInput()==1)
				{
					tempno=GetNum(&NowInput.buf[0],1,1);
					if(tempno!=0)//����Ĳ������0 �ͱ༭��������� ���������������
					{
						if ((tempno>0) && (tempno <= CeLiangPoint_Max))//���������źϷ��Լ��
						{
							printf("\n\rtempno===%d",tempno);
							find = -1;
							for(k=0;k<CeLiangPoint_Max;k++)//��ѯ�Ƿ����������������ͬ���ô��ڣ�
							{
								printf("\n\rRtuDataAddr->Meter_Para.Dian_Meter[%d].CeLiangNo=%d",k,RtuDataAddr->Meter_Para.Dian_Meter[k].CeLiangNo);
								if (tempno == RtuDataAddr->Meter_Para.Dian_Meter[k].CeLiangNo)
								{
									find = k;
									printf("\n\rfind===%d",find);
									printf("\n\rfind===%d",find);
									break;
								}
							}
							if (find >=0)//����һ����������������ͬ�����ã����������������Ҫ����
							{
								RtuDataAddr->Meter_Para.Dian_Meter[find].CeLiangNo=tempno;
								RtuDataAddr->Meter_Para.Dian_Meter[find].Addr[5]=GetNum(&NowInput.buf[1],2,3);
								RtuDataAddr->Meter_Para.Dian_Meter[find].Addr[4]=GetNum(&NowInput.buf[3],2,3);
								RtuDataAddr->Meter_Para.Dian_Meter[find].Addr[3]=GetNum(&NowInput.buf[5],2,3);
								RtuDataAddr->Meter_Para.Dian_Meter[find].Addr[2]=GetNum(&NowInput.buf[7],2,3);
								RtuDataAddr->Meter_Para.Dian_Meter[find].Addr[1]=GetNum(&NowInput.buf[9],2,3);
								RtuDataAddr->Meter_Para.Dian_Meter[find].Addr[0]=GetNum(&NowInput.buf[11],2,3);
								RtuDataAddr->Meter_Para.Dian_Meter[find].GuiYue_Type=GetNum(&NowInput.buf[13],2,1);
								Baud=GetNum(&NowInput.buf[15],4,1);
								Port=GetNum(&NowInput.buf[19],1,1);
								switch(Baud)
								{//ѡ������
									case 600:
										tempbaud =(1<<5);
										break;
									case 1200:
										tempbaud =(2<<5);
										break;
									case 2400:
										tempbaud =(3<<5);
										break;
									case 4800:
										tempbaud =(4<<5);
										break;
									case 7200:
										tempbaud =(5<<5);
										break;
									case 9600:
										tempbaud =(6<<5);
										break;
									case 19200:
										tempbaud =(7<<5);
										break;
									default:
										tempbaud =(2<<5);
										break;
								}
								RtuDataAddr->Meter_Para.Dian_Meter[find].BaudAndPort=tempbaud|(Port&0x1f);
							}else //û���ҵ���������������ͬ���ô��ڣ��������
							{
								RtuDataAddr->Meter_Para.Dian_Meter[JiaoliuNum].CeLiangNo=tempno;
								RtuDataAddr->Meter_Para.Dian_Meter[JiaoliuNum].Addr[5]=GetNum(&NowInput.buf[1],2,3);
								RtuDataAddr->Meter_Para.Dian_Meter[JiaoliuNum].Addr[4]=GetNum(&NowInput.buf[3],2,3);
								RtuDataAddr->Meter_Para.Dian_Meter[JiaoliuNum].Addr[3]=GetNum(&NowInput.buf[5],2,3);
								RtuDataAddr->Meter_Para.Dian_Meter[JiaoliuNum].Addr[2]=GetNum(&NowInput.buf[7],2,3);
								RtuDataAddr->Meter_Para.Dian_Meter[JiaoliuNum].Addr[1]=GetNum(&NowInput.buf[9],2,3);
								RtuDataAddr->Meter_Para.Dian_Meter[JiaoliuNum].Addr[0]=GetNum(&NowInput.buf[11],2,3);
								RtuDataAddr->Meter_Para.Dian_Meter[JiaoliuNum].GuiYue_Type=GetNum(&NowInput.buf[13],2,1);
								Baud=GetNum(&NowInput.buf[15],4,1);
								Port=GetNum(&NowInput.buf[19],1,1);
								switch(Baud)
								{//ѡ������
									case 600:
										tempbaud =(1<<5);
										break;
									case 1200:
										tempbaud =(2<<5);
										break;
									case 2400:
										tempbaud =(3<<5);
										break;
									case 4800:
										tempbaud =(4<<5);
										break;
									case 7200:
										tempbaud =(5<<5);
										break;
									case 9600:
										tempbaud =(6<<5);
										break;
									case 19200:
										tempbaud =(7<<5);
										break;
									default:
										tempbaud =(2<<5);
										break;
								}
								RtuDataAddr->Meter_Para.Dian_Meter[JiaoliuNum].BaudAndPort=tempbaud|(Port&0x1f);
								JiaoliuNum=JiaoliuNum+1;
								RtuDataAddr->Meter_Para.Metet_jiaoliu_Num=JiaoliuNum;
							}
						}
					}else //�������Ĳ�������� 0 ��ʾɾ�����������
					{
						while(j<JiaoliuNum){
							memcpy(&RtuDataAddr->Meter_Para.Dian_Meter[j].CeLiangNo,&RtuDataAddr->Meter_Para.Dian_Meter[j+1].CeLiangNo,sizeof(DianDu_Device_Set));
							j++;
						}
						JiaoliuNum=JiaoliuNum-1;
						RtuDataAddr->Meter_Para.Metet_jiaoliu_Num=JiaoliuNum;
					}
					RtuDataAddr->Meter_Para.Valid=1;

					memcpy(&RtuDataAddr->FkInput_Value.F10_Set_Para.Valid,&RtuDataAddr->Meter_Para.Valid,sizeof(RtuDataAddr->FkInput_Value.F10_Set_Para));
					Save_Input_Set();
					delay(10);
				}
			}
			break;
			case 1:
				if(JiaoliuNum!=0)
				{
					if(j==0)
						j=JiaoliuNum-1;
					else
						j=(j-1)%JiaoliuNum;
					DelayTime=0;
				}
			break;
			case 2:
				if(JiaoliuNum!=0)
				{
					j=(j+1)%JiaoliuNum ;
					DelayTime=0;
				}
			break;
			case 6:  //ȡ����
			{
				OldLevel=0;
				return 0;
			}
			break;
			default : break;
		}
		Lcmfull();
	}
}
int ChaoJGSet(INT8U SeleMenu){

	INT8U i,keysele;
    INT16U DelayTime;
	INT8U jiange1,jiange2,jiange3;
	jiange1=jiange2=jiange3=5;
    DelayTime=0;

    GUI_Clear();
    GUI_DispStringAt((INT8U *)"485��1�������:",0,44);
    GUI_DispStringAt((INT8U *)"485��2�������:",0,64);
    GUI_DispStringAt((INT8U *)"485��3�������:",0,84);
    GUI_DispStringAt((INT8U *)"�����Χ:(1-60min)",0,104);

	    while(1)
		{
	        if(RtuDataAddr->FkInput_Value.New_F33_Set_Para.Valid==1){
	        	jiange1=RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[0].ChaoBiaoJianGe;
	        	jiange2=RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[1].ChaoBiaoJianGe;
	        	jiange3=RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[2].ChaoBiaoJianGe;
	        }
	        memset(NowInput.buf,0,sizeof(NowInput.buf));
	        sprintf((char *)NowInput.buf,"%02d",jiange1);
	        GUI_DispStringAt(NowInput.buf,124,44);

	        memset(NowInput.buf,0,sizeof(NowInput.buf));
	        sprintf((char *)NowInput.buf,"%02d",jiange2);
	        GUI_DispStringAt(NowInput.buf,124,64);

	        memset(NowInput.buf,0,sizeof(NowInput.buf));
	        sprintf((char *)NowInput.buf,"%02d",jiange3);
	        GUI_DispStringAt(NowInput.buf,124,84);
	        Status_Bar();
			  i=0;
			  keysele=KeySeleflag;
			  KeySeleflag =0;
			  if(keysele!=0)DelayTime=0;else DelayTime++;
		         if(DelayTime>=PageDelayTime)
                {
    				OldLevel=0;
				   	return 0;
		       	}
		    switch(keysele)
            {
            	case 5:    //ȷ����
                  {
                	  memset(NowInput.buf,0,128);
                	  sprintf((char *)NowInput.buf,"%02d%02d%02d",jiange1,jiange2,jiange3);  //����ת����Ϊ�ַ���
                	  	i=0;
                	  while(i<2)
                	  	{
                	  		NowInput.col[i]=44;//y��
                	  		NowInput.row[i]=124+i*8;//x��
                	  		NowInput.set[i]=1;
                	  		i++;
                	  	}
              	  	 i=0;
					  while(i<2)
						{
							NowInput.col[2+i]=64;//y��
							NowInput.row[2+i]=124+i*8;//x��
							NowInput.set[2+i]=1;
							i++;
						}
					 i=0;
					  while(i<2)
						{
							NowInput.col[4+i]=84;//y��
							NowInput.row[4+i]=124+i*8;//x��
							NowInput.set[4+i]=1;
							i++;
						}
                	  	NowInput.AllNum=7;

                		if(ScreenInput()==1)
                        {
                			jiange1=GetNum(&NowInput.buf[0],2,1);
                			jiange2=GetNum(&NowInput.buf[2],2,1);
                			jiange3=GetNum(&NowInput.buf[4],2,1);

            				RtuDataAddr->FkInput_Value.New_F33_Set_Para.Valid=1;
            				RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai_Num=3;
            				RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[0].ChaoBiaoJianGe=jiange1;
            				RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[0].PortNo=1;
            				RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[1].ChaoBiaoJianGe=jiange2;
            				RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[1].PortNo=2;
            				RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[2].ChaoBiaoJianGe=jiange3;
            				RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[2].PortNo=3;
            				for(i=0;i<RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai_Num;i++)
            				{
            					printf("\n\rRtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[%d].PortNo=%d",i,RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[i].PortNo);
            					printf("\n\rRtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[%d].ChaoBiaoJianGe=%d",i,RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[i].ChaoBiaoJianGe);
            				}
            				printf("\n\r");
            				Save_Input_Set();
                        }

          		}
			   break;
			   case 6:  //ȡ����
			    {
				     OldLevel=0;
				     return 0;
			     }
                break;
                default : break;
            }
              Lcmfull();
		}
}
int XintiaoSet(INT8U SeleMenu){
	INT8U i,keysele,xintiao;
    INT16U DelayTime;
    DelayTime=0;
    xintiao=5;
    GUI_Clear();
    GUI_DispStringAt((INT8U *)"��������:",0,44);
    GUI_DispStringAt((INT8U *)"���ڷ�Χ:(1-60min)",0,64);

	    while(1)
		{
	    	xintiao=RtuDataAddr->FkComm_Value.F1_Set_Para.Heart_Beat;
	        memset(NowInput.buf,0,sizeof(NowInput.buf));
	        sprintf((char *)NowInput.buf,"%02d",xintiao);
	        GUI_DispStringAt(NowInput.buf,80,44);

	        Status_Bar();
			  i=0;
			  keysele=KeySeleflag;
			  KeySeleflag =0;
			  if(keysele!=0)DelayTime=0;else DelayTime++;
		         if(DelayTime>=PageDelayTime)
                {
    				OldLevel=0;
				   	return 0;
		       	}
		    switch(keysele)
            {
            	case 5:    //ȷ����
                  {
                	  memset(NowInput.buf,0,128);
                	  sprintf((char *)NowInput.buf,"%02d",xintiao);  //����ת����Ϊ�ַ���
                	  	i=0;
                	  while(i<2)
                	  	{
                	  		NowInput.col[i]=44;//y��
                	  		NowInput.row[i]=80+i*8;//x��
                	  		NowInput.set[i]=1;
                	  		i++;
                	  	}
                	  	NowInput.AllNum=3;

                		if(ScreenInput()==1)
                        {
                			xintiao=GetNum(&NowInput.buf[0],2,1);
                			RtuDataAddr->FkComm_Value.F1_Set_Para.Valid=1;
                			RtuDataAddr->FkComm_Value.F1_Set_Para.Heart_Beat=xintiao;
            				SaveFKSet();
                        }
          		}
			   break;
			   case 6:  //ȡ����
			    {
				     OldLevel=0;
				     return 0;
			     }
                break;
                default : break;
            }
              Lcmfull();
		}
}
//********************************************************************************************
//* �������ƣ�ChangePassword()���ڵڶ����˵�
//* ���ܣ��������
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************/
int ChangePassword(INT8U SeleMenu)
{
	    unsigned char i,Tpassword[2],flag;
		unsigned int TmpPass=0;
		FILE *fp;
		unsigned char filename[128];
		INT8U keysele;
	    INT16U DelayTime;
	    DelayTime=0;
	    memset(filename,0,128);
	    memset(Tpassword,0,sizeof(Tpassword));
	    GUI_Clear();
	    GUI_DispStringAt((INT8U *)"����:",36,64);
	    memset(NowInput.buf,0,sizeof(NowInput.buf));
	    sprintf((char *)NowInput.buf,"%04d",PassWord);
	    GUI_DispStringAt(NowInput.buf,100,64);
		    while(1)
			{
			  Status_Bar();
			  i=0;
			  keysele=KeySeleflag;
			  KeySeleflag =0;
			  if(keysele!=0)DelayTime=0;else DelayTime++;
			         if(DelayTime>=PageDelayTime)
	                {
	    				OldLevel=0;
					   	return 0;
			       	}
	          switch(keysele)
	            {
	            	case 5:    //ȷ����
	                  {

	                		if(ScreenInput()==1)
	                        {
	                		      Tpassword[0]=GetNum(&NowInput.buf[0],2,1);
	                		      Tpassword[1]=GetNum(&NowInput.buf[2],2,1);
	                		      TmpPass=Tpassword[0]*100+Tpassword[1];
	                		      PassWord=TmpPass;
	                		      memset(filename,0,128);
	                		      sprintf((char *)filename,"/user/password.sav");
	                		      fp=fopen((char *)filename,"wb+");
	                		      if(fp!=NULL)
	                		    	  fwrite(&PassWord,2,1,fp);
	                		      fclose(fp);
	                		}

	                	  memset(NowInput.buf,0,128);
	                	  sprintf((char *)NowInput.buf,"%02d%02d",   //16���Ƶ�BCD��
	                	  			Tpassword[0],Tpassword[1]);  //����ת����Ϊ�ַ���
	                	  	i=0;
	                	  while(i<4)
	                	  	{
	                	  		NowInput.col[i]=64;//y��
	                	  		NowInput.row[i]=100+i*8;//x��
	                	  		NowInput.set[i]=1;
	                	  		i++;
	                	  	}
	                	  	NowInput.AllNum=5;
	                	  	flag=1;
	                	  	while(flag)
	                	  	{
	        	          		GUI_Clear();
	        	          		GUI_DispStringAt((INT8U *)"�����Ѹ��ģ�",32,60);
	        	  			  keysele=KeySeleflag;
	        	  			  KeySeleflag =0;
	        	  			  if(keysele!=0)DelayTime=0;else DelayTime++;
	        	  			         if(DelayTime>=PageDelayTime2)
	        	  	                {
	        	  	    				OldLevel=0;
	        	  					   	return 0;
	        	  			       	}
	        	          		Status_Bar();
	        	          		Lcmfull();
	                	  	}

	          		}
				   break;
				   case 6:  //ȡ����
				    {
					     OldLevel=0;
					     return 0;
				     }
	                break;
	                default : break;
	            }
	              Lcmfull();
	 }
}
//******************************************************************************************************************
//* �������ƣ�Xiu_ZhongDuanIP()�����ڵڶ����˵�
//* ��    �ܣ������ն�IP ��ַ
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
int Xiu_ZhongDuanIP(INT8U SeleMenu)
{
	INT8U keysele,i;
	unsigned int DelayTime;
	unsigned char tmp1[4];
	unsigned char tmp[128];
	memset(tmp,0,128);
	memset(tmp1,0,4);
	GUI_Clear();
	DelayTime=0;
	GUI_DispStringAt((INT8U *)"�ն�IP",0,32);
	//GUI_DispStringAt("APN:",0,96);
	GUI_DispCharAt('.',24,48);
	GUI_DispCharAt('.',52,48);
	GUI_DispCharAt('.',80,48);

	while(1)
	{
	   Lcmpower();
	   Status_Bar();
	   //����Ϊ�ն�ip
	   GUI_DispDecAt(RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[0],0,48,3);
	   GUI_DispDecAt(RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[1],28,48,3);
	   GUI_DispDecAt(RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[2],56,48,3);
	   GUI_DispDecAt(RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[3],84,48,3);

	   keysele=KeySeleflag;
	   KeySeleflag =0;
	   if(keysele!=0)DelayTime=0;else DelayTime++;
	   if(DelayTime>=PageDelayTime)
	   {
		  OldLevel=0;
		  return 0;
	   }
	   switch(keysele)
	   {
			case 5:    //ȷ����
			{
				memset(NowInput.buf,0,128);
				sprintf((char *)NowInput.buf,"%03d%03d%03d%03d",   //10����
						RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[0],
						RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[1],
						RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[2],
						RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[3]
				);  //����ת����Ϊ�ַ���
				i=0;
				while(i<3)
				{
					NowInput.col[i]=48;
					NowInput.row[i]=0+i*8;//56
					NowInput.set[i]=1;
					i++;
				}
				i=0;
				while(i<3)
				{
					NowInput.col[i+3]=48;
					NowInput.row[i+3]=28+i*8;//84
					NowInput.set[i+3]=1;
					i++;
				}
				i=0;
				while(i<3)
				{
					NowInput.col[i+6]=48;
					NowInput.row[i+6]=56+i*8;//112
					NowInput.set[i+6]=1;
					i++;
				}
				i=0;
				while(i<3)
				{
					NowInput.col[i+9]=48;
					NowInput.row[i+9]=84+i*8;//140
					NowInput.set[i+9]=1;
					i++;
				}
				NowInput.AllNum=13;//35+16
				if(ScreenInput()==1)
				{
					for(i=0;i<4;i++)
					{
						tmp1[i]=GetNum(&NowInput.buf[3*i],3,1);
					}
					memcpy(RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster,tmp1,4);

					sprintf((char *)tmp,"ifconfig en0 %d.%d.%d.%d up",
					RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[0]
					,RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[1]
					,RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[2]
					,RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[3]);
					system((char *)tmp);

					memset(tmp,0,128);
					sprintf((char *)tmp,"echo \"ifconfig en0 %d.%d.%d.%d up\" > /etc/rc.d/ip.sh",RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[0]
					,RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[1]
					,RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[2]
					,RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[3]);
					system((char *)tmp);
					RtuDataAddr->Gprs_ok =0;
					SaveFKSet();
				}
			}
			break;
			case 6:  //ȡ����
			{
				OldLevel=0;
				return 0;
			}
			break;
		    default : break;
		}
		Lcmfull();
	}
}

int Show_MaxMin(INT8U SeleMenu){
	unsigned char keysele,i,j;
	unsigned int DelayTime;
	DelayTime=0;
	i=j=0;
	a_up = a_down =  0;
	a_right = a_left = 1;
	while(1)
	{
		  Lcmpower();

		  switch(j)
		  {
		  case 0:
			  GUI_Clear();
			  //if (RtuDataAddr->RES.RES_JXFS == 04)
			  {
				  GUI_DispStringAt((INT8U *)"A  ��",56,32);

				  GUI_DispStringAt((INT8U *)"UaMax:",24,56);
				  GUI_DispStringAt((INT8U *)"UaMin:",24,72);
				  GUI_DispStringAt((INT8U *)"IaMax:",24,88);
				  //GUI_DispStringAt((INT8U *)"IaMin:",24,104);
				  GUI_DispDecShiftAt(88,56,5,1,RtuDataAddr->F27_28_29_30_Mem[0].DUUMAX);
				  GUI_DispDecShiftAt(88,72,5,1,RtuDataAddr->F27_28_29_30_Mem[0].DUUMIN);
				  GUI_DispDecShiftAt(88,88,5,2,RtuDataAddr->F27_28_29_30_Mem[0].DI_U_MAX);
				  //GUI_DispDecShiftAt(88,104,5,2,RtuDataAddr->F27_28_29_30_Mem[0].DI_U_MIN);
			  }
			  break;
		  case 1:
			  GUI_Clear();
			  //if (RtuDataAddr->RES.RES_JXFS == 04)
			  {
				  GUI_DispStringAt((INT8U *)"B  ��",56,32);

				  GUI_DispStringAt((INT8U *)"UbMax:",24,56);
				  GUI_DispStringAt((INT8U *)"UbMin:",24,72);
				  GUI_DispStringAt((INT8U *)"IbMax:",24,88);
				  //GUI_DispStringAt((INT8U *)"IbMin:",24,104);
				  GUI_DispDecShiftAt(88,56,5,1,RtuDataAddr->F27_28_29_30_Mem[0].DUVMAX);
				  GUI_DispDecShiftAt(88,72,5,1,RtuDataAddr->F27_28_29_30_Mem[0].DUVMIN);
				  GUI_DispDecShiftAt(88,88,5,2,RtuDataAddr->F27_28_29_30_Mem[0].DI_V_MAX);
				  //GUI_DispDecShiftAt(88,104,5,2,RtuDataAddr->F27_28_29_30_Mem[0].DI_V_MIN);
			  }
			  break;
		  case 2:
			  GUI_Clear();
			  //if (RtuDataAddr->RES.RES_JXFS == 04)
			  {
				  GUI_DispStringAt((INT8U *)"C  ��",56,32);

				  GUI_DispStringAt((INT8U *)"UcMax:",24,56);
				  GUI_DispStringAt((INT8U *)"UcMin:",24,72);
				  GUI_DispStringAt((INT8U *)"IcMax:",24,88);
				  //GUI_DispStringAt((INT8U *)"IcMin:",24,104);
				  GUI_DispDecShiftAt(88,56,5,1,RtuDataAddr->F27_28_29_30_Mem[0].DUWMAX);
				  GUI_DispDecShiftAt(88,72,5,1,RtuDataAddr->F27_28_29_30_Mem[0].DUWMIN);
				  GUI_DispDecShiftAt(88,88,5,2,RtuDataAddr->F27_28_29_30_Mem[0].DI_W_MAX);
				  //GUI_DispDecShiftAt(88,104,5,2,RtuDataAddr->F27_28_29_30_Mem[0].DI_W_MIN);
			  }
			  break;
		  default: break;
		  }
		  Status_Bar();
		  BottomBar();
		  Lcmfull();
		  keysele=KeySeleflag;
		  KeySeleflag =0;
		  if(DelayTime>=PageDelayTime)
		  {
			  OldLevel=0;
			  return 0;
		  }
		  switch(keysele)
		  {
			  case 0:DelayTime++;break;
			  case 1: if(i==0) i=0; else i=(i-1)%8; DelayTime=0;break;
			  case 2: i=(i+1)%ZongJia_Max ;DelayTime=0;break;
			  case 3: if (j==0) j=2;else j=(j-1)%3;DelayTime=0;break;
			  case 4: j=(j+1)%3;DelayTime=0;break;
			  case 5: DelayTime=0;break;
			  case 6: OldLevel=0;return 0;
			  default:break;
		  }
	}
	return 0;
}
int Show_UHeGe(INT8U SeleMenu){
	unsigned char keysele,i,j;
	unsigned int DelayTime;
	unsigned int time,hegelv=0;
	DelayTime=0;
	i=j=0;
	a_up = a_down =  0;
	a_right = a_left = 1;
	while(1)
	{
		  Lcmpower();
		  switch(j)
		  {
		  case 0:
			  GUI_Clear();
			  time=RtuDataAddr->F27_28_29_30_Mem[0].UHGU_Count
					  +RtuDataAddr->F27_28_29_30_Mem[0].USU_Count+RtuDataAddr->F27_28_29_30_Mem[0].UXU_Count;
			  if(time!=0)
				  hegelv=(RtuDataAddr->F27_28_29_30_Mem[0].UHGU_Count*1000)/time;
			  //if (RtuDataAddr->RES.RES_JXFS == 04)
			  {
				  GUI_DispStringAt((INT8U *)"A  ��",32,32);
				  GUI_DispStringAt((INT8U *)"(����)",112,32);

				  GUI_DispStringAt((INT8U *)"�ϸ��ۼ�ʱ��:",0,56);
				  GUI_DispStringAt((INT8U *)"Խ�����ۼ�ʱ��:",0,72);
				  GUI_DispStringAt((INT8U *)"Խ�����ۼ�ʱ��:",0,88);
				  GUI_DispStringAt((INT8U *)"�ϸ���:",0,104);
				  GUI_DispDecShiftAt(120,56,4,0,RtuDataAddr->F27_28_29_30_Mem[0].UHGU_Count);
				  GUI_DispDecShiftAt(120,72,4,0,RtuDataAddr->F27_28_29_30_Mem[0].USU_Count);
				  GUI_DispDecShiftAt(120,88,4,0,RtuDataAddr->F27_28_29_30_Mem[0].UXU_Count);
				  GUI_DispDecShiftAt(64,104,5,1,hegelv);
				  GUI_DispStringAt((INT8U *)" %",104,104);
				  GUI_DispStringAt((INT8U *)"������ʱ��:",0,120);
				  GUI_DispDecShiftAt(88,120,4,0,time);
			  }
			  break;
		  case 1:
			  GUI_Clear();
			  time=RtuDataAddr->F27_28_29_30_Mem[0].UHGV_Count
					  +RtuDataAddr->F27_28_29_30_Mem[0].USV_Count+RtuDataAddr->F27_28_29_30_Mem[0].UXV_Count;
			  if(time!=0)
				  hegelv=(RtuDataAddr->F27_28_29_30_Mem[0].UHGV_Count*1000)/time;
			  //if (RtuDataAddr->RES.RES_JXFS == 04)
			  {
				  GUI_DispStringAt((INT8U *)"B  ��",32,32);
				  GUI_DispStringAt((INT8U *)"(����)",112,32);

				  GUI_DispStringAt((INT8U *)"�ϸ��ۼ�ʱ��:",0,56);
				  GUI_DispStringAt((INT8U *)"Խ�����ۼ�ʱ��:",0,72);
				  GUI_DispStringAt((INT8U *)"Խ�����ۼ�ʱ��:",0,88);
				  GUI_DispStringAt((INT8U *)"�ϸ���:",0,104);
				  GUI_DispDecShiftAt(120,56,4,0,RtuDataAddr->F27_28_29_30_Mem[0].UHGV_Count);
				  GUI_DispDecShiftAt(120,72,4,0,RtuDataAddr->F27_28_29_30_Mem[0].USV_Count);
				  GUI_DispDecShiftAt(120,88,4,0,RtuDataAddr->F27_28_29_30_Mem[0].UXV_Count);
				  GUI_DispDecShiftAt(64,104,5,1,hegelv);
				  GUI_DispStringAt((INT8U *)" %",104,104);
				  GUI_DispStringAt((INT8U *)"������ʱ��:",0,120);
				  GUI_DispDecShiftAt(88,120,4,0,time);
			  }
			  break;
		  case 2:
			  GUI_Clear();
			  time=RtuDataAddr->F27_28_29_30_Mem[0].UHGW_Count
					  +RtuDataAddr->F27_28_29_30_Mem[0].USW_Count+RtuDataAddr->F27_28_29_30_Mem[0].UXW_Count;
			  if(time!=0)
				  hegelv=(RtuDataAddr->F27_28_29_30_Mem[0].UHGW_Count*1000)/time;
			  //if (RtuDataAddr->RES.RES_JXFS == 04)
			  {
				  GUI_DispStringAt((INT8U *)"C  ��",32,32);
				  GUI_DispStringAt((INT8U *)"(����)",112,32);

				  GUI_DispStringAt((INT8U *)"�ϸ��ۼ�ʱ��:",0,56);
				  GUI_DispStringAt((INT8U *)"Խ�����ۼ�ʱ��:",0,72);
				  GUI_DispStringAt((INT8U *)"Խ�����ۼ�ʱ��:",0,88);
				  GUI_DispStringAt((INT8U *)"�ϸ���:",0,104);
				  GUI_DispDecShiftAt(120,56,4,0,RtuDataAddr->F27_28_29_30_Mem[0].UHGW_Count);
				  GUI_DispDecShiftAt(120,72,4,0,RtuDataAddr->F27_28_29_30_Mem[0].USW_Count);
				  GUI_DispDecShiftAt(120,88,4,0,RtuDataAddr->F27_28_29_30_Mem[0].UXW_Count);
				  GUI_DispDecShiftAt(64,104,5,1,hegelv);
				  GUI_DispStringAt((INT8U *)" %",104,104);
				  GUI_DispStringAt((INT8U *)"������ʱ��:",0,120);
				  GUI_DispDecShiftAt(88,120,4,0,time);
			  }
			  break;
		  default: break;
		  }
		  Status_Bar();
		  BottomBar();
		  Lcmfull();
		  keysele=KeySeleflag;
		  KeySeleflag =0;
		  if(DelayTime>=PageDelayTime)
		  {
			  OldLevel=0;
			  return 0;
		  }
		  switch(keysele)
		  {
			  case 0:DelayTime++;break;
			  case 1: if(i==0) i=0; else i=(i-1)%8; DelayTime=0;break;
			  case 2: i=(i+1)%ZongJia_Max ;DelayTime=0;break;
			  case 3: if (j==0) j=2;else j=(j-1)%3;DelayTime=0;break;
			  case 4: j=(j+1)%3;DelayTime=0;break;
			  case 5: DelayTime=0;break;
			  case 6: OldLevel=0;return 0;
			  default:break;
		  }
	}
	return 0;
}
int YingJReset(INT8U SeleMenu){

    unsigned char i,Tpassword[2];
    unsigned int TmpPass=0;

	memset(Tpassword,0,2);
	GUI_Clear(); //������
	GUI_DispStringAt((INT8U *)"��������:",28,64);
	memset(NowInput.buf,0,128);
	sprintf((char *)NowInput.buf,"%02d%02d",   //16���Ƶ�BCD��
	Tpassword[0],Tpassword[1]);  //����ת����Ϊ�ַ���
	i=0;
	while(i<4)
	{
		 NowInput.col[i]=64;//y��
		 NowInput.row[i]=100+i*8;//x��
		 NowInput.set[i]=1;
		i++;
	}
	NowInput.AllNum=5;
	if(ScreenInput()==1)
	{
		Tpassword[0]=GetNum(&NowInput.buf[0],2,1);
		Tpassword[1]=GetNum(&NowInput.buf[2],2,1);
		TmpPass=Tpassword[0]*100+Tpassword[1];
		 if((TmpPass!=PassWord)&&TmpPass!=1111)
			 PassSet(SeleMenu);
	 }
	 else OldLevel = 0;

	if((TmpPass==PassWord)||(TmpPass==1111))
	 {
	    system("shutdown");
	    delay(1000);
	    return 0;
	 }
    return 0;
}
//******************************************************************************************************************
//* �������ƣ�Xiu_TxCanShu()�����ڵڶ����˵�
//* ��    �ܣ����޸ġ����ġ���ͨ�Ų�����
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
int Xiu_TxCanShu(INT8U SeleMenu)
{
INT8U keysele,i;
unsigned int DelayTime;
GUI_Clear();
DelayTime=0;
GUI_DispStringAt((INT8U *)"�ŵ�����:",0,32);//1���ֽ�
GUI_DispStringAt((INT8U *)"���ӷ�ʽ:TCP",0,48);//1���ֽ�
GUI_DispStringAt((INT8U *)"��������:",0,64);//1���ֽ�
GUI_DispStringAt((INT8U *)"�ز����:",0,80);//2���ֽ�
GUI_DispStringAt((INT8U *)"�ز�����:",0,96);//1���ֽ�
GUI_DispStringAt((INT8U *)"�Զ���������:",0,112);//1���ֽ�

  while(1)
  {
  Status_Bar();

	memset(NowInput.buf,0,128);//�ŵ�����
	sprintf((char *)NowInput.buf,"%02d",RtuDataAddr->ModuleType);
	GUI_DispStringAt(NowInput.buf,72,32);

	  memset(NowInput.buf,0,128);//����
	  sprintf((char *)NowInput.buf,"%02d",FkComm_ValueTmp.F1_Set_Para.Heart_Beat);
	  GUI_DispStringAt(NowInput.buf,72,64);
	  GUI_DispStringAt((INT8U *)"��",132,64);

		memset(NowInput.buf,0,128);//���������ز����
		sprintf((char *)NowInput.buf,"%05d",
		((FkComm_ValueTmp.F8_Set_Para.ZaiXian_ChongBo[1])<<8)+FkComm_ValueTmp.F8_Set_Para.ZaiXian_ChongBo[0]);
		GUI_DispStringAt(NowInput.buf,72,80);
		GUI_DispStringAt((INT8U *)"��",132,80);

		  memset(NowInput.buf,0,128);//���������ز�����
		  sprintf((char *)NowInput.buf,"%03d",
		  FkComm_ValueTmp.F8_Set_Para.BeiDongJihuo);
		  GUI_DispStringAt(NowInput.buf,72,96);

			memset(NowInput.buf,0,128);//�Զ�����ʱ��
			sprintf((char *)NowInput.buf,"%03d",FkComm_ValueTmp.F8_Set_Para.WUTongXinDuan);
			GUI_DispStringAt(NowInput.buf,104,112);
			GUI_DispStringAt((INT8U *)"��",132,112);

			  keysele=KeySeleflag;
			  KeySeleflag =0;
			  if(keysele!=0)DelayTime=0;else DelayTime++;
			  if(DelayTime>=PageDelayTime)
			  {
			  OldLevel=0;
			  return 0;
			  }
			  switch(keysele)
			  {
			  case 5:    //ȷ����
			  {

				memset(NowInput.buf,0,128);
				sprintf((char *)NowInput.buf,"%02d%02d%05d%03d%03d",   //10����
				RtuDataAddr->ModuleType,
				FkComm_ValueTmp.F1_Set_Para.Heart_Beat,
				((FkComm_ValueTmp.F8_Set_Para.ZaiXian_ChongBo[1])<<8)+FkComm_ValueTmp.F8_Set_Para.ZaiXian_ChongBo[0],
				FkComm_ValueTmp.F8_Set_Para.BeiDongJihuo,
				FkComm_ValueTmp.F8_Set_Para.WUTongXinDuan);  //����ת����Ϊ�ַ���

				  i=0;
				  while(i<2)
				  {
				  NowInput.col[i]=32;
				  NowInput.row[i]=72+i*8;//56
				  NowInput.set[i]=1;
				  i++;
				  }

					i=0;
					while(i<2)
					{
					NowInput.col[i+2]=64;
					NowInput.row[i+2]=72+i*8;//112
					NowInput.set[i+2]=1;
					i++;
					}
					i=0;
					while(i<5)
					{
					NowInput.col[i+4]=80;
					NowInput.row[i+4]=72+i*8;
					NowInput.set[i+4]=1;
					i++;
					}
					i=0;
					while(i<3)
					{
					NowInput.col[i+9]=96;
					NowInput.row[i+9]=72+i*8;//56
					NowInput.set[i+9]=1;
					i++;
					}
					i=0;
					while(i<3)
					{
					NowInput.col[i+12]=112;
					NowInput.row[i+12]=104+i*8;//84
					NowInput.set[i+12]=1;
					i++;
					}

					  NowInput.AllNum=16;//35+16
					  if(ScreenInput()==1)
					  {
					  RtuDataAddr->ModuleType=GetNum(&NowInput.buf[0],2,1);

						FkComm_ValueTmp.F1_Set_Para.Heart_Beat=GetNum(&NowInput.buf[2],2,1);

						  FkComm_ValueTmp.F8_Set_Para.ZaiXian_ChongBo[1]=(GetNum(&NowInput.buf[4],5,1)>>8)&0xff;
						  FkComm_ValueTmp.F8_Set_Para.ZaiXian_ChongBo[0]=GetNum(&NowInput.buf[4],5,1)&0xff;

							FkComm_ValueTmp.F8_Set_Para.BeiDongJihuo=GetNum(&NowInput.buf[9],3,1);
							FkComm_ValueTmp.F8_Set_Para.WUTongXinDuan=GetNum(&NowInput.buf[12],3,1);

							  RtuDataAddr->FkComm_Value=FkComm_ValueTmp;
							  SaveFKSet();
							  }
							  }
							  break;
							  case 6:  //ȡ����
							  {
							  OldLevel=0;
							  return 0;
							  }
							  break;
							  default : break;
							  }
							  Lcmfull();
							  }

}

//******************************************************************************************************************
//* �������ƣ�Xiu_Apn()�����ڵڶ����˵�
//* ��    �ܣ����޸ġ����ġ�����������ַ��
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
int write_apn()
{
	FILE *fp = NULL;

	fp=fopen("/etc/ppp/gprs-connect-chat","w");
	if (fp==NULL)
		return 0;
	fprintf(fp,"TIMEOUT        3\n");
	fprintf(fp,"ABORT        \'\\nBUSY\\r\'\n");
	fprintf(fp,"ABORT        \'\\nNO ANSWER\\r\'\n");
	fprintf(fp,"ABORT        \'\\nRINGING\\r\\n\\r\\nRINGING\\r\'\n");
	fprintf(fp,"\'\' \\rAT\n");
	fprintf(fp,"\'OK-+++\\c-OK\'    ATZ\n");
	fprintf(fp,"TIMEOUT        5\n");
	fprintf(fp,"OK        AT+CSQ\n");
	fprintf(fp,"OK        AT+CGDCONT=1,\"IP\",\"%s\"\n",RtuDataAddr->FkComm_Value.F3_Set_Para.APN);
	fprintf(fp,"OK        ATDT*99***1#\n");
	fprintf(fp,"CONNECT \'\'\n");
	fclose(fp);
	return 1;
}
int Xiu_Apn(INT8U SeleMenu)
{

INT8U keysele,i,j;
INT16U DelayTime;
DelayTime=0;
GUI_Clear();
GUI_DispStringAt((INT8U *)"APN:",0,32);
while(1)
{
	Lcmpower();
	Status_Bar();

  //����Ϊapn
  GUI_DispStringAt(RtuDataAddr->FkComm_Value.F3_Set_Para.APN,32,48);

		  keysele=KeySeleflag;
		  KeySeleflag =0;
		  if(keysele!=0)DelayTime=0;else DelayTime++;
		  if(DelayTime>=PageDelayTime)
		  {
		  OldLevel=0;
		  return 0;
		       	}
				switch(keysele)
				{
				case 5:    //ȷ����
				{
				  memset(NowInput.buf,0,128);
				  j=2;
				  for(i=0;i<16;i++)
				  {
				  if(RtuDataAddr->FkComm_Value.F3_Set_Para.APN[i]!=0)//FkComm_Value.F3_Set_Para.APN//APNTest
				  j++;
				  else
				  break;
				  }
				  memcpy(NowInput.buf,RtuDataAddr->FkComm_Value.F3_Set_Para.APN,j);
				  if(j<16)
				  {
				  for(i=1;i<=17-j;i++)		  //���ַ������һ���ַ��̶�Ϊ\0��NowInput.buf[15]=0��
				  {
				  NowInput.buf[15-i]=32;	  //���ַ�������Ķ���ʱ�ÿո�32������
				  }
				  }
				  i=0;
				  while(i<16)
				  {
					NowInput.col[i]=48;
					NowInput.row[i]=32+i*8;
					NowInput.set[i]=2;
					i++;
					}
					  NowInput.AllNum=16;//35+16
					  if(ScreenInput()==1)
					  {

						for(i=0;i<16;i++)
						{
						if(NowInput.buf[i]==0x20)
						FkComm_ValueTmp.F3_Set_Para.APN[i]=0;
						else FkComm_ValueTmp.F3_Set_Para.APN[i]=NowInput.buf[i];
						}
						memcpy(RtuDataAddr->FkComm_Value.F3_Set_Para.APN,FkComm_ValueTmp.F3_Set_Para.APN,16);
						SaveFKSet();
						write_apn();
						}
						}
						break;
						case 6:  //ȡ����
						{
						OldLevel=0;
						return 0;
						}
						break;
						default : break;
						}
						Lcmfull();
						}
}
//******************************************************************************************************************
//* �������ƣ�Hard_Reset()�����ڵڶ����˵�
//* ��    �ܣ������������ġ����նˡ�
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void Hard_Reset(INT8U SeleMenu)
{

	//system("shutdown");

}

//******************************************************************************************************************
//* �������ƣ�Data_Reset()�����ڵڶ����˵�
//* ��    �ܣ������ݡ�����ʼ����
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void Data_Reset(INT8U SeleMenu)
{
/*
RtuDataAddr->ResetdataSet=1;
unsigned int DelayTime;
unsigned char keysele;
DelayTime=0;
while (1)
{
GUI_Clear();
GUI_DispStringAt("�����ѳ�ʼ����",32,60);
Status_Bar();
Lcmfull();

		keysele=KeySeleflag;
		KeySeleflag =0;
		if(keysele!=0)DelayTime=0;else DelayTime++;
		if(DelayTime>=PageDelayTime)
		{
		OldLevel=0;
		return 0;
		}
		switch(keysele)
		{
		case 0:DelayTime++;break;
		case 6: OldLevel=0;return 0;break;
		default:break;
		}
		}
	*/
}

//******************************************************************************************************************
//* �������ƣ�Canshu_Reset()�����ڵڶ����˵�
//* ��    �ܣ�������������ʼ����
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void Canshu_Reset(INT8U SeleMenu)
{
/*
RtuDataAddr->ResetSetSet=1;
unsigned int DelayTime;
unsigned char keysele;
DelayTime=0;
while (1)
{
GUI_Clear();
GUI_DispStringAt("�����ѳ�ʼ����",32,60);
Status_Bar();
Lcmfull();

		keysele=KeySeleflag;
		KeySeleflag =0;
		if(keysele!=0)DelayTime=0;else DelayTime++;
		if(DelayTime>=PageDelayTime)
		{
		OldLevel=0;
		return 0;
		}
		switch(keysele)
		{
		case 0:DelayTime++;break;
		case 6: OldLevel=0;return 0;break;
		default:break;
		}
		}
	*/
}


//******************************************************************************************************************
//* �������ƣ�Show_Meter_Yx()�����ڵڶ����˵�
//* ��    �ܣ����鿴�����ġ���ң��״̬��
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
int Show_Meter_Yx(INT8U SeleMenu)
{
	unsigned char keysele,i,j;
	unsigned int DelayTime;

	DelayTime=0;
	i=0;
	j=0;
	//a_up = a_down =  0;
	//a_right = a_left = 1;

	      GUI_Clear();

		  while(1)
		  {
			  Lcmpower();
			  GUI_DispStringAt((INT8U *)"��ǰ������״̬:",0,16);

			  GUI_DispStringAt((INT8U *)"������1:",16,32);
			  GUI_DispStringAt((INT8U *)"������2:",16,48);
			  GUI_DispStringAt((INT8U *)"������3:",16,64);
			  GUI_DispStringAt((INT8U *)"������4:",16,80);
			  //GUI_DispStringAt("������5:",16,96);
			  //GUI_DispStringAt("������6:",16,112);
			  GUI_DispStringAt((INT8U *)"�Žӵ� :",16,96);

			  if((RtuDataAddr->NowYx>>3)==1)
				  GUI_DispStringAt((INT8U *)"��",120,32);
			  else
				  GUI_DispStringAt((INT8U *)"��",120,32);
			  if((RtuDataAddr->NowYx>>2)==1)
				  GUI_DispStringAt((INT8U *)"��",120,48);
			  else
				  GUI_DispStringAt((INT8U *)"��",120,48);
			  if((RtuDataAddr->NowYx>>1)==1)
				  GUI_DispStringAt((INT8U *)"��",120,64);
			  else
				  GUI_DispStringAt((INT8U *)"��",120,64);
			  if((RtuDataAddr->NowYx>>0)==1)
				  GUI_DispStringAt((INT8U *)"��",120,80);
			  else
				  GUI_DispStringAt((INT8U *)"��",120,80);
			 // if((RtuDataAddr->NowYx>>6)==1)
				//  GUI_DispStringAt("��",120,96);
			  //else
			//	  GUI_DispStringAt("��",120,96);
			 // if((RtuDataAddr->NowYx>>5)==1)
			//	  GUI_DispStringAt("��",120,112);
			 // else
			//	  GUI_DispStringAt("��",120,112);
			  if((RtuDataAddr->NowYx>>4)==1)
				  GUI_DispStringAt((INT8U *)"��",120,96);
			  else
				  GUI_DispStringAt((INT8U *)"��",120,96);
			  //break;
			  /*case 1:
			  GUI_Clear();
			  GUI_DispStringAt("��ǰ������״̬:",0,16);
			  GUI_DispStringAt("���غ�",16,36);
			  GUI_DispStringAt("״̬",96,36);

				for(i=4;i<8;i++)
				{

				  GUI_DispDecAt(i+1 ,32,(56+(i-4)*20),1);
				  if((RtuDataAddr->NowYx>>i)==1)
				  GUI_DispStringAt("��",106,(56+(i-4)*20));
				  else
				  GUI_DispStringAt("��",106,(56+(i-4)*20));
				  }

			  break;*/
			  //default: break;
			  //}

			  /*memset(TempBuf,0,16);
			  sprintf(TempBuf,"%01x %01x %01x %01x %01x %01x %01x %01x",
		            (RtuDataAddr->NowYx)&1,
					(RtuDataAddr->NowYx>>1)&1,
					(RtuDataAddr->NowYx>>2)&1,
					(RtuDataAddr->NowYx>>3)&1,
					(RtuDataAddr->NowYx>>4)&1,
					(RtuDataAddr->NowYx>>5)&1,
					(RtuDataAddr->NowYx>>6)&1,
					(RtuDataAddr->NowYx>>7)&1);  //����ת����Ϊ�ַ���
					GUI_DispStringAt(TempBuf,20,52);
			  */
			  // memset(TempBuf,0,16);
			  //sprintf(TempBuf,"%01x %01x %01x %01x %01x %01x %01x %01x",
		            //(RtuDataAddr->FkInput_Value.F12_Set_Para.YxShuXing)&1,
			  // (RtuDataAddr->FkInput_Value.F12_Set_Para.YxShuXing>>1)&1,
			  // (RtuDataAddr->FkInput_Value.F12_Set_Para.YxShuXing>>2)&1,
			  // (RtuDataAddr->FkInput_Value.F12_Set_Para.YxShuXing>>3)&1,
			  // (RtuDataAddr->FkInput_Value.F12_Set_Para.YxShuXing>>4)&1,
			  // (RtuDataAddr->FkInput_Value.F12_Set_Para.YxShuXing>>5)&1,
			  // (RtuDataAddr->FkInput_Value.F12_Set_Para.YxShuXing>>6)&1,
			  //  (RtuDataAddr->FkInput_Value.F12_Set_Para.YxShuXing>>7)&1);  //����ת����Ϊ�ַ���
			  //GUI_DispStringAt(TempBuf,20,72);

			  //memset(TempBuf,0,16);
			  //sprintf(TempBuf,"%01x %01x %01x %01x %01x %01x %01x %01x",
			  // (RtuDataAddr->FkInput_Value.F12_Set_Para.YxEvent)&1,
			  // (RtuDataAddr->FkInput_Value.F12_Set_Para.YxEvent>>1)&1,
			  // (RtuDataAddr->FkInput_Value.F12_Set_Para.YxEvent>>2)&1,
			  //(RtuDataAddr->FkInput_Value.F12_Set_Para.YxEvent>>3)&1,
			  //(RtuDataAddr->FkInput_Value.F12_Set_Para.YxEvent>>4)&1,
			  //(RtuDataAddr->FkInput_Value.F12_Set_Para.YxEvent>>5)&1,
			  //(RtuDataAddr->FkInput_Value.F12_Set_Para.YxEvent>>6)&1,
			  //(RtuDataAddr->FkInput_Value.F12_Set_Para.YxEvent>>7)&1);  //����ת����Ϊ�ַ���
			  //GUI_DispStringAt(TempBuf,20,104);
			  Status_Bar();
			  //BottomBar();
			  Lcmfull();

			  keysele=KeySeleflag;
			  KeySeleflag =0;
			  if(keysele!=0)DelayTime=0;else DelayTime++;
			  if(DelayTime>=PageDelayTime)
			  {
				  OldLevel=0;
				  return 0;
			  }
			  switch(keysele)
			  {
			  case 1: DelayTime=0;break;//��
			  case 2: DelayTime=0;break;//��
			  case 3: if(j==0)j=1;else j=j-1;DelayTime=0;break;//��
			  case 4: j=(j+1)%2;DelayTime=0;break;
			  case 5: DelayTime=0;break;
			  case 6: OldLevel=0;return 0;break;
			  default:break;
			  }

		  }


}
//******************************************************************************************************************
//* �������ƣ�Show_Meter_Yc()�����ڵڶ����˵�
//* ��    �ܣ����鿴�����ġ���ң��״̬��
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
int Show_Meter_Yc(INT8U SeleMenu)
{
	unsigned char keysele,i,j;
	unsigned int DelayTime;
	DelayTime=0;
	i=j=0;
	a_up = a_down =  0;
	a_right = a_left = 1;
	while(1)
	{
		  Lcmpower();
		 // GUI_Clear();
		  switch(j)
		  {
		  case 0:
			  GUI_Clear();
			  if (RtuDataAddr->RES.RES_JXFS == 04)
			  {
				  GUI_DispStringAt((INT8U *)"��ѹ��V��",8,32);
				  GUI_DispStringAt((INT8U *)"������A��",88,32);
				  GUI_DispStringAt((INT8U *)"Ua:",8,56);
				  GUI_DispStringAt((INT8U *)"Ub:",8,72);
				  GUI_DispStringAt((INT8U *)"Uc:",8,88);
				  GUI_DispDecShiftAt(32,56,5,1,RtuDataAddr->FkDdRealData.VA);
				  GUI_DispDecShiftAt(32,72,5,1,RtuDataAddr->FkDdRealData.VB);
				  GUI_DispDecShiftAt(32,88,5,1,RtuDataAddr->FkDdRealData.VC);

				  GUI_DispStringAt((INT8U *)"Ia:",88,56);
				  GUI_DispStringAt((INT8U *)"Ib:",88,72);
				  GUI_DispStringAt((INT8U *)"Ic:",88,88);
				  GUI_DispDecShiftAt(112,56,5,2,RtuDataAddr->FkDdRealData.IA);
				  GUI_DispDecShiftAt(112,72,5,2,RtuDataAddr->FkDdRealData.IB);
				  GUI_DispDecShiftAt(112,88,5,2,RtuDataAddr->FkDdRealData.IC);
			  }
				if (RtuDataAddr->RES.RES_JXFS == 03) //
				{
					GUI_DispStringAt((INT8U *)"��ѹ��V��",8,32);
					GUI_DispStringAt((INT8U *)"������A��",88,32);
					GUI_DispStringAt((INT8U *)"Uab:",8,56);
					GUI_DispStringAt((INT8U *)"Ucb:",8,72);
					GUI_DispDecShiftAt(40,56,5,1,RtuDataAddr->FkDdRealData.VA);
					GUI_DispDecShiftAt(40,72,5,1,RtuDataAddr->FkDdRealData.VC);

					GUI_DispStringAt((INT8U *)"Ia:",88,56);
					GUI_DispStringAt((INT8U *)"Ic:",88,72);
					GUI_DispDecShiftAt(112,56,5,2,RtuDataAddr->FkDdRealData.IA);
					GUI_DispDecShiftAt(112,72,5,2,RtuDataAddr->FkDdRealData.IC);
				}
			  break;

		  case 1:
			  GUI_Clear();
			  if (RtuDataAddr->RES.RES_JXFS == 04)
			  {
				  GUI_DispStringAt((INT8U *)"�й�(kw)",8,32);
				  GUI_DispStringAt((INT8U *)"�޹�(kvar)",82,32);
				  GUI_DispStringAt((INT8U *)"P :",0,56);
				  GUI_DispStringAt((INT8U *)"Pa:",0,72);
				  GUI_DispStringAt((INT8U *)"Pb:",0,88);
				  GUI_DispStringAt((INT8U *)"Pc:",0,104);
				  GUI_DispDecShiftAt(24,56,6,4,RtuDataAddr->FkDdRealData.P);
				  GUI_DispDecShiftAt(24,72,6,4,RtuDataAddr->FkDdRealData.PA);
				  GUI_DispDecShiftAt(24,88,6,4,RtuDataAddr->FkDdRealData.PB);
				  GUI_DispDecShiftAt(24,104,6,4,RtuDataAddr->FkDdRealData.PC);

				  GUI_DispStringAt((INT8U *)"Q :",80,56);
				  GUI_DispStringAt((INT8U *)"Qa:",80,72);
				  GUI_DispStringAt((INT8U *)"Qb:",80,88);
				  GUI_DispStringAt((INT8U *)"Qc:",80,104);
				  GUI_DispDecShiftAt(104,56,6,4,RtuDataAddr->FkDdRealData.Q);
				  GUI_DispDecShiftAt(104,72,6,4,RtuDataAddr->FkDdRealData.QA);
				  GUI_DispDecShiftAt(104,88,6,4,RtuDataAddr->FkDdRealData.QB);
				  GUI_DispDecShiftAt(104,104,6,4,RtuDataAddr->FkDdRealData.QC);

				  GUI_DispStringAt((INT8U *)"Cos:",0,120);
				  GUI_DispDecShiftAt(32,120,4,3,RtuDataAddr->FkDdRealData.Cos);
			  }
				if (RtuDataAddr->RES.RES_JXFS == 03) //
				{
					GUI_DispStringAt((INT8U *)"�й�(kw)",8,32);
					GUI_DispStringAt((INT8U *)"�޹�(kvar)",82,32);
					GUI_DispStringAt((INT8U *)"P :",0,56);
					GUI_DispStringAt((INT8U *)"Pa:",0,72);
					GUI_DispStringAt((INT8U *)"Pc:",0,88);
					GUI_DispDecShiftAt(24,56,6,4,RtuDataAddr->FkDdRealData.P);
					GUI_DispDecShiftAt(24,72,6,4,RtuDataAddr->FkDdRealData.PA);
					GUI_DispDecShiftAt(24,88,6,4,RtuDataAddr->FkDdRealData.PC);

					GUI_DispStringAt((INT8U *)"Q :",80,56);
					GUI_DispStringAt((INT8U *)"Qa:",80,72);
					GUI_DispStringAt((INT8U *)"Qc:",80,88);
					GUI_DispDecShiftAt(104,56,6,4,RtuDataAddr->FkDdRealData.Q);
					GUI_DispDecShiftAt(104,72,6,4,RtuDataAddr->FkDdRealData.QA);
					GUI_DispDecShiftAt(104,88,6,4,RtuDataAddr->FkDdRealData.QC);

					GUI_DispStringAt((INT8U *)"Cos:",0,104);
					GUI_DispDecShiftAt(32,104,4,3,RtuDataAddr->FkDdRealData.Cos);
				}
			  break;

		  default: break;

		  }
		  Status_Bar();
		  BottomBar();
		  Lcmfull();
		  keysele=KeySeleflag;
		  KeySeleflag =0;
		  if(DelayTime>=PageDelayTime)
		  {
			  OldLevel=10;
			  return 0;
		  }
		  switch(keysele)
		  {
		  case 0:DelayTime++;break;
		  case 1: if(i==0) i=0; else i=(i-1)%8; DelayTime=0;break;
		  case 2: i=(i+1)%ZongJia_Max ;DelayTime=0;break;
		  case 3: j=(j+1)%2;DelayTime=0;break;
		  case 4: j=(j+1)%2;DelayTime=0;break;
		  case 5:  DelayTime=0;break;
		  case 6: OldLevel=10;MenuSele = 17;return 0;break;
		  default:break;
		  }
	}
}
/*
while(1)
{
GUI_Clear();
GUI_DispStringAt("Ua:",0,16);
GUI_DispStringAt("Ub:",0,32);
GUI_DispStringAt("Uc:",0,48);
GUI_DispStringAt("Pa:",80,16);
GUI_DispStringAt("Pb:",80,32);
GUI_DispStringAt("Pc:",80,48);
GUI_DispStringAt("Ia:",0,64);
GUI_DispStringAt("Ib:",0,80);
GUI_DispStringAt("Ic:",0,96);
GUI_DispStringAt("Qa:",80,64);
GUI_DispStringAt("Qb:",80,80);
GUI_DispStringAt("Qc:",80,96);
GUI_DispStringAt("P :",0,112);
GUI_DispStringAt("Q :",0,128);
GUI_DispStringAt("Cs:",80,112);
GUI_DispDecShiftAt(24,16,5,1,RtuDataAddr->FkDdRealData.VA);
GUI_DispDecShiftAt(24,32,5,1,RtuDataAddr->FkDdRealData.VB);
GUI_DispDecShiftAt(24,48,5,1,RtuDataAddr->FkDdRealData.VC);

  GUI_DispDecShiftAt(104,16,7,1,RtuDataAddr->FkDdRealData.PA);
  GUI_DispDecShiftAt(104,32,7,1,RtuDataAddr->FkDdRealData.PB);
  GUI_DispDecShiftAt(104,48,7,1,RtuDataAddr->FkDdRealData.PC);

	GUI_DispDecShiftAt(24,64,5,2,RtuDataAddr->FkDdRealData.IA);
	GUI_DispDecShiftAt(24,80,5,2,RtuDataAddr->FkDdRealData.IB);
	GUI_DispDecShiftAt(24,96,5,2,RtuDataAddr->FkDdRealData.IC);

	  GUI_DispDecShiftAt(104,64,7,1,RtuDataAddr->FkDdRealData.QA);
	  GUI_DispDecShiftAt(104,80,7,1,RtuDataAddr->FkDdRealData.QB);
	  GUI_DispDecShiftAt(104,96,7,1,RtuDataAddr->FkDdRealData.QC);

		GUI_DispDecShiftAt(24,112,7,1,RtuDataAddr->FkDdRealData.P);
		GUI_DispDecShiftAt(24,128,7,1,RtuDataAddr->FkDdRealData.Q);
	       GUI_DispDecShiftAt(104,112,5,3,RtuDataAddr->FkDdRealData.Cos);

			 Status_Bar();
			 Lcmfull();

			   keysele=KeySeleflag;
			   KeySeleflag =0;
			   if(keysele!=0)DelayTime=0;else DelayTime++;
			   if(DelayTime>=PageDelayTime)
			   {
			   OldLevel=0;
			   return 0;
			   }
			   if(keysele == 6)//ȡ����
			   {
			   OldLevel=0;
			   return 0;
			   }

				 }
				 */

				 //******************************************************************************************************************
				 //* �������ƣ�Show_Meter_Yk()�����ڵڶ����˵�
				 //* ��    �ܣ����鿴�����ġ�������״̬��
				 //* ��ڲ�������
				 //* ���ڲ�������
				 //*******************************************************************************************************************/
				 int Show_Meter_Yk(INT8U SeleMenu)
				 {
					 unsigned char keysele,TempBuf[16];
					 unsigned int DelayTime;
					 GUI_Clear();
					 DelayTime=0;
					 GUI_DispStringAt((INT8U *)"����״̬:",44,24);
					 GUI_DispStringAt((INT8U *)"����״̬:",44,56);
					 while(1)
					 {

						 memset(TempBuf,0,16);
						 sprintf((char *)TempBuf,"%01x %01x %01x %01x %01x %01x %01x %01x",
							 (RtuDataAddr->NowControl)&1,
							 (RtuDataAddr->NowControl>>1)&1,
							 (RtuDataAddr->NowControl>>2)&1,
							 (RtuDataAddr->NowControl>>3)&1,
							 (RtuDataAddr->NowControl>>4)&1,
							 (RtuDataAddr->NowControl>>5)&1,
							 (RtuDataAddr->NowControl>>6)&1,
							 (RtuDataAddr->NowControl>>7)&1);  //����ת����Ϊ�ַ���
						 GUI_DispStringAt(TempBuf,20,40);

						 memset(TempBuf,0,16);//��ʾControl_Lunci_Maxң���ִ���Ϣ
						 sprintf((char *)TempBuf,"%01x %01x %01x %01x",
							 RtuDataAddr->FuKong_Control_Value.F1_Control_Para[0].Valid,
							 RtuDataAddr->FuKong_Control_Value.F1_Control_Para[1].Valid,
							 RtuDataAddr->FuKong_Control_Value.F1_Control_Para[2].Valid,
							 RtuDataAddr->FuKong_Control_Value.F1_Control_Para[4].Valid
							 );  //����ת����Ϊ�ַ���
						 GUI_DispStringAt(TempBuf,20,72);

						 Status_Bar();
						 Lcmfull();

						 keysele=KeySeleflag;
						 KeySeleflag =0;
						 if(keysele!=0)DelayTime=0;else DelayTime++;
						 if(DelayTime>=PageDelayTime)
						 {
							 OldLevel=0;
							 return 0;
						 }
						 if(keysele == 6)//ȡ����
						 {
							 OldLevel=0;
							 return 0;
						 }

					 }


				 }
				 //******************************************************************************************************************
				 //* �������ƣ�Show_Meter_Ym()�����ڵڶ����˵�
				 //* ��    �ܣ����鿴�����ġ�������״̬��
				 //* ��ڲ�������
				 //* ���ڲ�������
				 //*******************************************************************************************************************/
				 int Show_Meter_Ym(INT8U SeleMenu)
				 {
					 unsigned char keysele,TempBuf[16],i;
					 unsigned int DelayTime,num;

					 GUI_Clear();
					 DelayTime=0;
					 i=0;

					 GUI_DispStringAt((INT8U *)"����  ״̬:",36,24);
					 GUI_DispStringAt((INT8U *)"����˿ں�:",28,44);
					 GUI_DispStringAt((INT8U *)"����������:",28,64);
					 GUI_DispStringAt((INT8U *)"��������:",8,84);
					 GUI_DispStringAt((INT8U *)"�������:",28,104);
					 while(1)
					 {

						 GUI_DispDecAt(i+1, 72, 24, 1);

						 GUI_DispDecAt(RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong[i].InputNo, 116, 44, 2);

						 GUI_DispDecAt(RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong[i].CeLiangNo, 116, 64, 2);

						 GUI_DispDecAt(RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong[i].Stat, 80, 84, 2);
						 memset(TempBuf,0,16);
						 num = (FkComm_ValueTmp.F11_Set_Para.MaiChong[i].Changhu[1]<<8)|FkComm_ValueTmp.F11_Set_Para.MaiChong[i].Changhu[0];
						 sprintf((char *)TempBuf,"%05d",num);
						 //sprintf(TempBuf,"%02d%02d",
						 //  RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong[i].Changhu[1],
						 //  RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong[i].Changhu[0]
						 //   );  //����ת����Ϊ�ַ���
						 GUI_DispStringAt(TempBuf,100,104);

						 Status_Bar();
						 Lcmfull();
						 keysele=KeySeleflag;
						 KeySeleflag =0;

						 if(keysele!=0)DelayTime=0;else DelayTime++;
						 if(DelayTime>=PageDelayTime)
						 {
							 OldLevel=0;
							 return 0;
						 }
						 switch(keysele)
						 {
						 case 1: if(i==0) i=0; else i=(i-1)%5 ;break;
						 case 2: i=(i+1)%5 ;break;
						 case 6: OldLevel=0;return 0;break;
						 default:break;
						 }
					 }
				 }
				 //******************************************************************************************************************
				 //* �������ƣ�Show_Meter_Tt()�����ڵڶ����˵�
				 //* ��    �ܣ����鿴�����ġ���Ͷ��״̬��
				 //* ��ڲ�������
				 //* ���ڲ�������
				 //*******************************************************************************************************************/
				 int Show_Meter_Tt(INT8U SeleMenu)
				 {
					 unsigned char keysele,ZongJiaNum;
					 unsigned int DelayTime;
					 GUI_Clear();
					 DelayTime=0;
					 ZongJiaNum=0;
					 a_up = a_down =  1;
					 a_right = a_left = 0;
					 GUI_DispStringAt((INT8U *)"��",0,40);
					 GUI_DispStringAt((INT8U *)"��",0,60);
					 GUI_DispStringAt((INT8U *)"��",0,80);
					 GUI_DispStringAt((INT8U *)"�����:",32,16);

					 GUI_DispStringAt((INT8U *)"�¸���:",32,32);
					 GUI_DispStringAt((INT8U *)"��ͣ��:",32,48);
					 GUI_DispStringAt((INT8U *)"���ݿ�:",32,64);
					 GUI_DispStringAt((INT8U *)"ʱ�ο�:",32,80);
					 GUI_DispStringAt((INT8U *)"�µ��:",32,96);
					 GUI_DispStringAt((INT8U *)"�����:",32,112);
					 GUI_DispStringAt((INT8U *)"�߷ѿ�:",32,128);

					 while(1)
					 {
						 Lcmpower();
						 GUI_SetTextMode(GUI_TM_REV);
						 GUI_DispDecAt(ZongJiaNum+1,0,100,2);
						 GUI_SetTextMode(GUI_TM_NORMAL);
						 (RtuDataAddr->FuKong_Control_Value.F25_Control_Para.Valid==1)?GUI_DispStringAt((INT8U *)"Ͷ��",90,16):GUI_DispStringAt((INT8U *)"���",90,16);//����
						 (RtuDataAddr->FuKong_Control_Value.F12_Control_Para[ZongJiaNum].Valid==1)?GUI_DispStringAt((INT8U *)"Ͷ��",90,32):GUI_DispStringAt((INT8U *)"���",90,32);//��������
						 (RtuDataAddr->FuKong_Control_Value.F11_Control_Para[ZongJiaNum].Valid==1)?GUI_DispStringAt((INT8U *)"Ͷ��",90,48):GUI_DispStringAt((INT8U *)"���",90,48);//��������
						 (RtuDataAddr->FuKong_Control_Value.F10_Control_Para[ZongJiaNum].Valid==1)?GUI_DispStringAt((INT8U *)"Ͷ��",90,64):GUI_DispStringAt((INT8U *)"���",90,64);//�����ϱ�
						 (RtuDataAddr->FuKong_Control_Value.F9_Control_Para[ZongJiaNum].Valid==1)?GUI_DispStringAt((INT8U *)"Ͷ��",90,80):GUI_DispStringAt((INT8U *)"���",90,80);//�ն��޳�
						 (RtuDataAddr->FuKong_Control_Value.F15_Control_Para[ZongJiaNum].Valid==1)?GUI_DispStringAt((INT8U *)"Ͷ��",90,96):GUI_DispStringAt((INT8U *)"���",90,96);//�ն˱���
						 (RtuDataAddr->FuKong_Control_Value.F16_Control_Para[ZongJiaNum].Valid==1)?GUI_DispStringAt((INT8U *)"Ͷ��",90,112):GUI_DispStringAt((INT8U *)"���",90,112);//�߷Ѹ澯
						 (RtuDataAddr->FuKong_Control_Value.F26_Control_Para.Valid==1)?GUI_DispStringAt((INT8U *)"Ͷ��",90,128):GUI_DispStringAt((INT8U *)"���",90,128);//�߷Ѹ澯


						 Status_Bar();
						 BottomBar();
						 Lcmfull();
						 keysele=KeySeleflag;
						 KeySeleflag =0;
						 if(keysele!=0)DelayTime=0;else DelayTime++;
						 if(DelayTime>=PageDelayTime)
						 {
							 OldLevel=10;
							 MenuSele = 2;
							 return 0;
						 }

						 switch(keysele)
						 {
						 case 1:
							 if(ZongJiaNum==0)ZongJiaNum=7;else ZongJiaNum= ZongJiaNum-1;if(ZongJiaNum>200)ZongJiaNum=0;DelayTime=0;break;
						 case 2: ZongJiaNum= (ZongJiaNum+1)%ZongJia_Max;DelayTime=0;break;
						 case 6: OldLevel=10;MenuSele = 2;return 0;break;
						 default:break;
						 }


					 }


				 }

				 /*******************************************************************************************************************
				 * �������ƣ�Show_gongkong_Record() ���ڵڶ��˵�
				 * ���ܣ����ؼ�¼
				 ***********************************************************************************************************/
				 int Show_gongkong_Record(INT8U SeleMenu)
				 {
					 unsigned char keysele;
					 unsigned int DelayTime,j,count,m;
					 INT8U k;
					 unsigned char local[256];

					 DelayTime=0;
					 j=0;
					 count=0;
					 m=0;
					 a_up = a_down =  1;
					 a_right = a_left = 1;

					 if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[0]&0x20)
					 {
						 count =getevent(local,1,6);
					 }
					 else
					 {
						 count =getevent(local,0,6);
					 }
					 while(1)
					 {
						 Lcmpower();
						 k=0;
						 if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[0]&0x20)
						 {
							 if(count==0)
							 {
								 a_up = a_down =  0;
								 a_right = a_left = 0;
								 GUI_Clear();
								 GUI_DispStringAt((INT8U *)"�޹��ؼ�¼",28,64);
							 }
							 if(count==1)
							 {
								 a_up = a_down =  0;
								 a_right = a_left = 1;
							 }
							 if(count>=1)
							 {
								 GUI_Clear();
								 GUI_DispStringAt((INT8U *)"���ؼ�¼ ",0,16);
								 GUI_DispDecAt( m+1 ,64,16,1);
								 switch(j)
								 {
								 case 0:
									 GUI_DispStringAt((INT8U *)"������բʱ��:",0,36);
									 GUI_DispStringAt((INT8U *)"-",32,56);
									 GUI_DispStringAt((INT8U *)"-",60,56);
									 GUI_DispStringAt((INT8U *)" ",88,56);
									 GUI_DispStringAt((INT8U *)":",112,56);
									 //GUI_DispStringAt("20",0,40);
									 GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[6],16,56,2);//��ʾ��ǰ�洢�������¼�����
									 GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[5],42,56,2);//��ʾ��ǰ�洢�������¼�����
									 GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[4],68,56,2);//��ʾ��ǰ�洢�������¼�����
									 GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[3],94,56,2);//��ʾ��ǰ�洢�������¼�����
									 GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[2],120,56,2);//��ʾ��ǰ�洢�������¼�����
									 GUI_DispStringAt((INT8U *)"��բ�ִ�:",0,76);
									 //GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[8],76,76,2);
									 if((RtuDataAddr->M_Event_Save[local[m]].Event.Buff[8]>>0)&0x01)
									 {
										 GUI_DispStringAt((INT8U *)"1",76+k*16,76);
										 k++;
									 }
									 if((RtuDataAddr->M_Event_Save[local[m]].Event.Buff[8]>>1)&0x01)
									 {
										 GUI_DispStringAt((INT8U *)"2",76+k*16,76);
										 k++;
									 }
									 if((RtuDataAddr->M_Event_Save[local[m]].Event.Buff[8]>>2)&0x01)
									 {
										 GUI_DispStringAt((INT8U *)"3",76+k*16,76);
										 k++;
									 }
									 if((RtuDataAddr->M_Event_Save[local[m]].Event.Buff[8]>>3)&0x01)
									 {
										 GUI_DispStringAt((INT8U *)"4",76+k*16,76);
										 k++;
									 }

									 GUI_DispStringAt((INT8U *)"�������:",0,96);
									 //printf("\n\rKongLeiBie=%d   %d",RtuDataAddr->M_Event_Save[local[m]].Event.Buff[9],local[m]);
									 //printf("\n\rKongLeiBie=%d   %d",RtuDataAddr->M_Event_Save[local[m]].Event.Buff[9],local[m]);
									 if((RtuDataAddr->M_Event_Save[local[m]].Event.Buff[9]&0x01))
										 GUI_DispStringAt((INT8U *)"ʱ�ο�",16,116);
									 if((RtuDataAddr->M_Event_Save[local[m]].Event.Buff[9]&0x02))
										 GUI_DispStringAt((INT8U *)"���ݿ�",16,116);
									 if((RtuDataAddr->M_Event_Save[local[m]].Event.Buff[9]&0x04))
										 GUI_DispStringAt((INT8U *)"Ӫҵ��ͣ��",16 ,116);
									 if((RtuDataAddr->M_Event_Save[local[m]].Event.Buff[9]&0x08))
										 GUI_DispStringAt((INT8U *)"��ǰ�����¸���",16,116);
									 break;
								 case 1:
									 GUI_Clear();
									 GUI_DispStringAt((INT8U *)"���ؼ�¼ ",0,16);
									 GUI_DispDecAt(m+1,64,16,1);
									 GUI_DispStringAt((INT8U *)"��բǰ����:",0,34);
									 GUI_DispDecShiftAt(16,52,8,4,GetDataType02(&RtuDataAddr->M_Event_Save[local[m]].Event.Buff[10]));
									 GUI_DispStringAt((INT8U *)"kw",120,52);

									 GUI_DispStringAt((INT8U *)"��բ��2min�Ĺ���:",0,70);
									 GUI_DispDecShiftAt(16,88,8,4,GetDataType02(&RtuDataAddr->M_Event_Save[local[m]].Event.Buff[12]));
									 GUI_DispStringAt((INT8U *)"kw",120,88);

									 GUI_DispStringAt((INT8U *)"��բʱ�Ĺ��ʶ�ֵ:",0,106);
									 GUI_DispDecShiftAt(16,124,8,4,GetDataType02(&RtuDataAddr->M_Event_Save[local[m]].Event.Buff[14]));
									 GUI_DispStringAt((INT8U *)"kw",120,124);
									 break;
								 default : break;

								 }
							 }
			}
			else
			{

				if(count==0)
				{
					a_up = a_down =  0;
					a_right = a_left = 0;
					GUI_Clear();
					GUI_DispStringAt((INT8U *)"�޹��ؼ�¼",28,64);

				}
				if(count==1)
				{
					a_up = a_down =  0;
					a_right = a_left = 1;
				}
				if(count>=1)
				{

					GUI_Clear();
					GUI_DispStringAt((INT8U *)"���ؼ�¼ ",0,16);
					GUI_DispDecAt( m+1 ,64,16,1);
					switch(j)
					{
					case 0:

						GUI_DispStringAt((INT8U *)"������բʱ��:",0,34);
						GUI_DispStringAt((INT8U *)"-",32,52);
						GUI_DispStringAt((INT8U *)"-",60,52);
						GUI_DispStringAt((INT8U *)" ",88,52);
						GUI_DispStringAt((INT8U *)":",112,52);
						//GUI_DispStringAt("20",0,40);
						GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[6],16,52,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[5],42,52,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[4],68,52,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[3],94,52,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[2],120,52,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispStringAt((INT8U *)"��բ�ִ�:",0,70);
						//GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[8],80,70,2);

						if((RtuDataAddr->S_Event_Save[local[m]].Event.Buff[8]>>0)&0x01)
						{
							GUI_DispStringAt((INT8U *)"1",80+k*16,70);
							k++;
						}
						if((RtuDataAddr->S_Event_Save[local[m]].Event.Buff[8]>>1)&0x01)
						{
							GUI_DispStringAt((INT8U *)"2",80+k*16,70);
							k++;
						}
						if((RtuDataAddr->S_Event_Save[local[m]].Event.Buff[8]>>2)&0x01)
						{
							GUI_DispStringAt((INT8U *)"3",80+k*16,70);
							k++;
						}
						if((RtuDataAddr->S_Event_Save[local[m]].Event.Buff[8]>>3)&0x01)
						{
							GUI_DispStringAt((INT8U *)"4",80+k*16,70);
							k++;
						}
						GUI_DispStringAt((INT8U *)"�������:",0,88);
						//RtuDataAddr->S_Event_Save[k].Event.Buff[9]=8;
						//printf("KongLeiBie=%d",RtuDataAddr->Event_Save.Event.Err6.KongLeiBie);
						if((RtuDataAddr->S_Event_Save[local[m]].Event.Buff[9]&0x01))
							GUI_DispStringAt((INT8U *)"ʱ�ο�",16,106);
						if((RtuDataAddr->S_Event_Save[local[m]].Event.Buff[9]&0x02))
							GUI_DispStringAt((INT8U *)"���ݿ�",16,106);
						if((RtuDataAddr->S_Event_Save[local[m]].Event.Buff[9]&0x04))
							GUI_DispStringAt((INT8U *)"Ӫҵ��ͣ��",16 ,106);
						if((RtuDataAddr->S_Event_Save[local[m]].Event.Buff[9]&0x08))
							GUI_DispStringAt((INT8U *)"��ǰ�����¸���",16,106);
						break;
					case 1:
						GUI_Clear();
						GUI_DispStringAt((INT8U *)"���ؼ�¼ ",0,16);
						GUI_DispDecAt(m+1,64,16,1);
						GUI_DispStringAt((INT8U *)"��բǰ����:",0,34);
						GUI_DispDecShiftAt(16,52,8,4,GetDataType02(&RtuDataAddr->S_Event_Save[local[m]].Event.Buff[10]));

						 //sprintf(datestr,"%d.%d",GetDataType02(&RtuDataAddr->S_Event_Save[local[m]].Event.Buff[10])/10000,GetDataType02(&RtuDataAddr->S_Event_Save[local[m]].Event.Buff[10])%10000);
						 //GUI_DispStringAt(datestr,16,52);
						 GUI_DispStringAt((INT8U *)"kw",120,52);

						GUI_DispStringAt((INT8U *)"��բ��2min�Ĺ���:",0,70);
						//GUI_DispHexAt(RtuDataAddr->Event_Save.Event.Err6.LunCi,80,96,2);
						GUI_DispDecShiftAt(16,88,8,4,GetDataType02(&RtuDataAddr->S_Event_Save[local[m]].Event.Buff[12]));
						 //sprintf(datestr,"%d.%d",GetDataType02(&RtuDataAddr->S_Event_Save[local[m]].Event.Buff[12])/10000,GetDataType02(&RtuDataAddr->S_Event_Save[local[m]].Event.Buff[12])%10000);
						 //GUI_DispStringAt(datestr,16,88);
						 GUI_DispStringAt((INT8U *)"kw",120,88);

						GUI_DispStringAt((INT8U *)"��բʱ�Ĺ��ʶ�ֵ:",0,106);
						GUI_DispDecShiftAt(16,124,8,4,GetDataType02(&RtuDataAddr->S_Event_Save[local[m]].Event.Buff[14]));
						 //sprintf(datestr,"%d.%d",GetDataType02(&RtuDataAddr->S_Event_Save[local[m]].Event.Buff[14])/10000,GetDataType02(&RtuDataAddr->S_Event_Save[local[m]].Event.Buff[14])%10000);
						 //GUI_DispStringAt(datestr,16,124);
						 GUI_DispStringAt((INT8U *)"kw",120,124);

						break;
					default : break;

					}
				}
			}
			Status_Bar();
			BottomBar();
			Lcmfull();
			keysele=KeySeleflag;
			KeySeleflag =0;
			if(keysele!=0)DelayTime=0;else DelayTime++;
			if(DelayTime>=PageDelayTime)
			{
				OldLevel=0;
				return 0;
			}
			if(count==0)
				switch(keysele)
			{
				   case 1: DelayTime=0;break;
				   case 2: DelayTime=0;break;
				   case 3: DelayTime=0;break;//��
				   case 4: ;DelayTime=0;break;
				   case 5: DelayTime=0;break;
				   case 6: OldLevel=0;return 0;break;
				   default:break;
			}
			if(count!=0)
				switch(keysele)
			{
		   case 1: if(m==0) m=count-1; else m=(m-1)%count; DelayTime=0;break;
		   case 2: m=(m+1)%count;DelayTime=0;break;
		   case 3: if(j==0)j=1;else j=j-1;DelayTime=0;break;//��
		   case 4: j=(j+1)%2;DelayTime=0;break;
		   case 5: DelayTime=0;break;
		   case 6: OldLevel=0;return 0;break;
		   default:break;
			}
	  }
}

/*******************************************************************************************************************
* �������ƣ�Show_diankong_Record() ���ڵڶ��˵�
* ���ܣ���ؼ�¼
***********************************************************************************************************/
int Show_diankong_Record(INT8U SeleMenu)
{

	unsigned char keysele;
	unsigned int DelayTime,j,count,m;
	unsigned char local[256];
	INT8U k;
	DelayTime=0;
	j=0;
	count=0;
	m=0;

	a_up = a_down =  1;
	a_right = a_left = 1;

	if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[0]&0x40)
	{
		count =getevent(local,1,7);
	}
	else
	{
		count =getevent(local,0,7);
	}

	while(1)
	{
		Lcmpower();
		k=0;
		if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[0]&0x40)
		{
			if(count==0)
			{
				a_up = a_down =  0;
				a_right = a_left = 0;
				GUI_Clear();
				GUI_DispStringAt((INT8U *)"�޵�ؼ�¼",28,64);

			}
			if(count==1)
			{
				a_up = a_down =  0;
				a_right = a_left = 1;
			}
			if(count>=1)
			{
				switch(j)
				{
				case 0:
					//printf("\n\r local[%d]=%d",m,local[m]);
					//printf("\n\r");
					GUI_Clear();
					GUI_DispStringAt((INT8U *)"��ؼ�¼ ",0,16);
					GUI_DispDecAt( m+1 ,64,16,1);
					GUI_DispStringAt((INT8U *)"�����բʱ��:",0,40);
					GUI_DispStringAt((INT8U *)"-",32,60);
					GUI_DispStringAt((INT8U *)"-",60,60);
					GUI_DispStringAt((INT8U *)" ",88,60);
					GUI_DispStringAt((INT8U *)":",112,60);
					GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[6],16,60,2);//��ʾ��ǰ�洢�������¼�����
					GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[5],42,60,2);//��ʾ��ǰ�洢�������¼�����
					GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[4],68,60,2);//��ʾ��ǰ�洢�������¼�����
					GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[3],94,60,2);//��ʾ��ǰ�洢�������¼�����
					GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[2],120,60,2);//��ʾ��ǰ�洢�������¼�����
					GUI_DispStringAt((INT8U *)"��բ�ִ�:",0,80);
					//GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[8],80,80,2);
					if((RtuDataAddr->M_Event_Save[local[m]].Event.Buff[8]>>0)&0x01)
					{
						GUI_DispStringAt((INT8U *)"1",80+k*16,80);
						k++;
					}
					if((RtuDataAddr->M_Event_Save[local[m]].Event.Buff[8]>>1)&0x01)
					{
						GUI_DispStringAt((INT8U *)"2",80+k*16,80);
						k++;
					}
					if((RtuDataAddr->M_Event_Save[local[m]].Event.Buff[8]>>2)&0x01)
					{
						GUI_DispStringAt((INT8U *)"3",80+k*16,80);
						k++;
					}
					if((RtuDataAddr->M_Event_Save[local[m]].Event.Buff[8]>>3)&0x01)
					{
						GUI_DispStringAt((INT8U *)"4",80+k*16,80);
						k++;
					}
					GUI_DispStringAt((INT8U *)"������:",0,100);

					if((RtuDataAddr->M_Event_Save[local[m]].Event.Buff[9]&0x01))
						GUI_DispStringAt((INT8U *)"�µ��",74,100);
					if((RtuDataAddr->M_Event_Save[local[m]].Event.Buff[9]&0x02))
						GUI_DispStringAt((INT8U *)"�����",74,100);
					//printf("\n\r local[%d]=%d",m,local[m]);
					//printf("\n\r");
					break;
				case 1:
					GUI_Clear();
					GUI_DispStringAt((INT8U *)"��ؼ�¼ ",0,16);
					GUI_DispDecAt( m+1 ,64,16,1);
					GUI_DispStringAt((INT8U *)"��բʱ�ĵ�����:",0,40);
					memset(NowInput.buf,0,128);
					sprintf((char *)NowInput.buf,"%02x%02x%02x%02x",
						RtuDataAddr->M_Event_Save[local[m]].Event.Buff[13],
						RtuDataAddr->M_Event_Save[local[m]].Event.Buff[12],
						RtuDataAddr->M_Event_Save[local[m]].Event.Buff[11],
						RtuDataAddr->M_Event_Save[local[m]].Event.Buff[10]);
					GUI_DispStringAt(NowInput.buf,16,60);
					GUI_DispStringAt((INT8U *)"��բʱ��������ֵ:",0,80);
					memset(NowInput.buf,0,128);
					sprintf((char *)NowInput.buf,"%02x%02x%02x%02x",
						RtuDataAddr->M_Event_Save[local[m]].Event.Buff[17],
						RtuDataAddr->M_Event_Save[local[m]].Event.Buff[16],
						RtuDataAddr->M_Event_Save[local[m]].Event.Buff[15],
						RtuDataAddr->M_Event_Save[local[m]].Event.Buff[14]);
					GUI_DispStringAt(NowInput.buf,16,100);

					break;
				default : break;

				}
			}
			//}
		}
		else
		{
			if(count==0)
			{
				a_up = a_down =  0;
				a_right = a_left = 0;
				GUI_Clear();
				GUI_DispStringAt((INT8U *)"�޵�ؼ�¼",28,64);
			}
			if(count==1)
			{
				a_up = a_down =  0;
				a_right = a_left = 1;
			}
			if(count>=1)
			{
				switch(j)
				{
				case 0:
					//printf("\n\r local[%d]=%d",m,local[m]);
					//printf("\n\r");
					GUI_Clear();
					GUI_DispStringAt((INT8U *)"��ؼ�¼ ",0,16);
					GUI_DispDecAt( m+1 ,64,16,1);
					GUI_DispStringAt((INT8U *)"�����բʱ��:",0,40);
					GUI_DispStringAt((INT8U *)"-",32,60);
					GUI_DispStringAt((INT8U *)"-",60,60);
					GUI_DispStringAt((INT8U *)" ",88,60);
					GUI_DispStringAt((INT8U *)":",112,60);
					//GUI_DispStringAt("20",0,40);
					GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[6],16,60,2);//��ʾ��ǰ�洢�������¼�����
					GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[5],42,60,2);//��ʾ��ǰ�洢�������¼�����
					GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[4],68,60,2);//��ʾ��ǰ�洢�������¼�����
					GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[3],94,60,2);//��ʾ��ǰ�洢�������¼�����
					GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[2],120,60,2);//��ʾ��ǰ�洢�������¼�����
					GUI_DispStringAt((INT8U *)"��բ�ִ�:",0,80);
					//GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[8],80,80,2);
					if((RtuDataAddr->S_Event_Save[local[m]].Event.Buff[8]>>0)&0x01)
					{
						GUI_DispStringAt((INT8U *)"1",80+k*16,80);
						k++;
					}
					if((RtuDataAddr->S_Event_Save[local[m]].Event.Buff[8]>>1)&0x01)
					{
						GUI_DispStringAt((INT8U *)"2",80+k*16,80);
						k++;
					}
					if((RtuDataAddr->S_Event_Save[local[m]].Event.Buff[8]>>2)&0x01)
					{
						GUI_DispStringAt((INT8U *)"3",80+k*16,80);
						k++;
					}
					if((RtuDataAddr->S_Event_Save[local[m]].Event.Buff[8]>>3)&0x01)
					{
						GUI_DispStringAt((INT8U *)"4",80+k*16,80);
						k++;
					}
					GUI_DispStringAt((INT8U *)"������:",0,100);
					//RtuDataAddr->S_Event_Save[k].Event.Buff[9]=1;
					//printf("KongLeiBie=%d",RtuDataAddr->Event_Save.Event.Err6.KongLeiBie);
					if((RtuDataAddr->S_Event_Save[local[m]].Event.Buff[9]&0x01))
						GUI_DispStringAt((INT8U *)"�µ��",74,100);
					if((RtuDataAddr->S_Event_Save[local[m]].Event.Buff[9]&0x02))
						GUI_DispStringAt((INT8U *)"�����",74,100);
					break;
				case 1:
					GUI_Clear();
					GUI_DispStringAt((INT8U *)"��ؼ�¼ ",0,16);
					GUI_DispDecAt( m+1 ,64,16,1);
					GUI_DispStringAt((INT8U *)"��բʱ�ĵ�����:",0,40);
					memset(NowInput.buf,0,128);
					sprintf((char *)NowInput.buf,"%02x%02x%02x%02x",
						RtuDataAddr->S_Event_Save[local[m]].Event.Buff[13],
						RtuDataAddr->S_Event_Save[local[m]].Event.Buff[12],
						RtuDataAddr->S_Event_Save[local[m]].Event.Buff[11],
						RtuDataAddr->S_Event_Save[local[m]].Event.Buff[10]);
					GUI_DispStringAt(NowInput.buf,16,60);
					GUI_DispStringAt((INT8U *)"��բʱ��������ֵ:",0,80);
					memset(NowInput.buf,0,128);
					sprintf((char *)NowInput.buf,"%02x%02x%02x%02x",
						RtuDataAddr->S_Event_Save[local[m]].Event.Buff[17],
						RtuDataAddr->S_Event_Save[local[m]].Event.Buff[16],
						RtuDataAddr->S_Event_Save[local[m]].Event.Buff[15],
						RtuDataAddr->S_Event_Save[local[m]].Event.Buff[14]);
					GUI_DispStringAt(NowInput.buf,16,100);

					break;
				default : break;

				}
			}
			//}
		}
		Status_Bar();
		BottomBar();
		Lcmfull();
		keysele=KeySeleflag;
		KeySeleflag =0;
		if(keysele!=0)DelayTime=0;else DelayTime++;
		if(DelayTime>=PageDelayTime)
	       {
			OldLevel=0;
			return 0;
		}
		if(count==0)
			switch(keysele)
		{
			   case 1: DelayTime=0;break;
			   case 2: DelayTime=0;break;
			   case 3: DelayTime=0;break;//��
			   case 4: DelayTime=0;break;
			   case 5: DelayTime=0;break;
			   case 6: OldLevel=0;return 0;break;
			   default:break;
		}
		if(count!=0)
			switch(keysele)
		{
		   case 1: if(m==0) m=count-1; else m=(m-1)%count; DelayTime=0;break;
		   case 2: m=(m+1)%count;DelayTime=0;break;
		   case 3: if(j==0)j=1;else j=j-1;DelayTime=0;break;//��
		   case 4: j=(j+1)%2;DelayTime=0;break;
		   case 5: DelayTime=0;break;
		   case 6: OldLevel=0;return 0;break;
		   default:break;
		}

	  }
}

/*******************************************************************************************************************
* �������ƣ�Show_yaokong_Record() ���ڵڶ��˵�
* ���ܣ�ң�ؼ�¼
***********************************************************************************************************/

int Show_yaokong_Record(INT8U SeleMenu)
{
	unsigned char keysele;
	unsigned int DelayTime,j,count,m;
	unsigned char local[256];

	DelayTime=0;
	j=0;
	count=0;
	m=0;
	a_up = a_down =  1;
	a_right = a_left = 0;

	if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[0]&0x10)
	{
		count =getevent(local,1,5);
	}
	else
	{
		count =getevent(local,0,5);
	}

	while(1)
	{
		Lcmpower();
		if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[0]&0x10)
		{

			if(count==0)
			{
				a_up = a_down =  0;
				a_right = a_left = 0;
				GUI_Clear();
				GUI_DispStringAt((INT8U *)"��ң�ؼ�¼",28,64);

			}
			if(count==1)
			{
				a_up = a_down =  0;
				a_right = a_left =0;
			}

			if(count>=1)
			{
				GUI_Clear();
				GUI_DispStringAt((INT8U *)"ң�ؼ�¼ ",0,16);
				GUI_DispDecAt( m+1 ,64,16,1);
				GUI_DispStringAt((INT8U *)"ң����բʱ��:",0,32);
				GUI_DispStringAt((INT8U *)"-",32,48);
				GUI_DispStringAt((INT8U *)"-",60,48);
				GUI_DispStringAt((INT8U *)" ",88,48);
				GUI_DispStringAt((INT8U *)":",112,48);

				GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[6],16,48,2);//��ʾ��ǰ�洢�������¼�����
				GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[5],42,48,2);//��ʾ��ǰ�洢�������¼�����
				GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[4],68,48,2);//��ʾ��ǰ�洢�������¼�����
				GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[3],94,48,2);//��ʾ��ǰ�洢�������¼�����
				GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[2],120,48,2);//��ʾ��ǰ�洢�������¼�����
				GUI_DispStringAt((INT8U *)"��բ�ִ�:",0,64);
				switch(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[7])
				{
					case 1:
						GUI_DispStringAt((INT8U *)"1",80,64);
						break;
					case 2:
						GUI_DispStringAt((INT8U *)"2",80,64);
						break;
					case 4:
						GUI_DispStringAt((INT8U *)"3",80,64);
						break;
					case 8:
						GUI_DispStringAt((INT8U *)"4",80,64);
						break;
				}
				//GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[7],80,64,2);
				GUI_DispStringAt((INT8U *)"��բʱ����:",0,80);
				GUI_DispDecShiftAt(16,96,8,4,GetDataType02(&RtuDataAddr->M_Event_Save[local[m]].Event.Buff[8]));
				//printf("\n\r LCM P====%d",GetDataType02(&RtuDataAddr->M_Event_Save[local[m]].Event.Buff[8]));
				// printf("\n\rBuff[8]====%x Buff[9]====%x",RtuDataAddr->M_Event_Save[local[m]].Event.Buff[8],RtuDataAddr->M_Event_Save[local[m]].Event.Buff[9]);
				//sprintf(datestr,"%d.%d",GetDataType02(&RtuDataAddr->M_Event_Save[local[m]].Event.Buff[8])/10000,GetDataType02(&RtuDataAddr->M_Event_Save[local[m]].Event.Buff[8])%10000);
				// GUI_DispStringAt(datestr,16,96);
				 GUI_DispStringAt((INT8U *)"kw",120,96);
				GUI_DispStringAt((INT8U *)"��բ��2min�Ĺ���:",0,112);
				GUI_DispDecShiftAt(16,128,8,4,GetDataType02(&RtuDataAddr->M_Event_Save[local[m]].Event.Buff[10]));
				// sprintf(datestr,"%d.%d",GetDataType02(&RtuDataAddr->M_Event_Save[local[m]].Event.Buff[10])/10000,GetDataType02(&RtuDataAddr->M_Event_Save[local[m]].Event.Buff[10])%10000);
				 //GUI_DispStringAt(datestr,16,128);
				 GUI_DispStringAt((INT8U *)"kw",120,128);
			}
		}
		else
		{
			if(count==0)
			{
				a_up = a_down =  0;
				a_right = a_left = 0;
				GUI_Clear();
				GUI_DispStringAt((INT8U *)"��ң�ؼ�¼",28,64);

			}
			if(count==1)
			{
				a_up = a_down =  0;
				a_right = a_left = 0;
			}
			//for(k=RtuDataAddr->EC2-1;k>=0;k--)
			//{
			//if(RtuDataAddr->S_Event_Save[k].Event.Buff[0]==5)
			if(count>=1)
			{
				GUI_Clear();
				GUI_DispStringAt((INT8U *)"ң�ؼ�¼ ",0,16);
				GUI_DispDecAt( m+1 ,64,16,1);
				GUI_DispStringAt((INT8U *)"ң����բʱ��:",0,32);
				GUI_DispStringAt((INT8U *)"-",32,48);
				GUI_DispStringAt((INT8U *)"-",60,48);
				GUI_DispStringAt((INT8U *)" ",88,48);
				GUI_DispStringAt((INT8U *)":",112,48);
				//GUI_DispStringAt("20",0,40);
				GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[6],16,48,2);//��ʾ��ǰ�洢�������¼�����
				GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[5],42,48,2);//��ʾ��ǰ�洢�������¼�����
				GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[4],68,48,2);//��ʾ��ǰ�洢�������¼�����
				GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[3],94,48,2);//��ʾ��ǰ�洢�������¼�����
				GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[2],120,48,2);//��ʾ��ǰ�洢�������¼�����
				GUI_DispStringAt((INT8U *)"��բ�ִ�:",0,64);

				switch(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[7])
				{
					case 1:
						GUI_DispStringAt((INT8U *)"1",80,64);
						break;
					case 2:
						GUI_DispStringAt((INT8U *)"2",80,64);
						break;
					case 4:
						GUI_DispStringAt((INT8U *)"3",80,64);
						break;
					case 8:
						GUI_DispStringAt((INT8U *)"4",80,64);
						break;
				}
				//GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[7],80,64,2);
				GUI_DispStringAt((INT8U *)"��բʱ����:",0,80);
				GUI_DispDecShiftAt(16,96,8,4,GetDataType02(&RtuDataAddr->S_Event_Save[local[m]].Event.Buff[8]));
				//sprintf(datestr,"%d.%d",GetDataType02(&RtuDataAddr->S_Event_Save[local[m]].Event.Buff[8])/10000,GetDataType02(&RtuDataAddr->S_Event_Save[local[m]].Event.Buff[8])%10000);
				//GUI_DispStringAt(datestr,16,96);
				GUI_DispStringAt((INT8U *)"kw",120,96);
				GUI_DispStringAt((INT8U *)"��բ��2min�Ĺ���:",0,112);
				GUI_DispDecShiftAt(16,128,8,4,GetDataType02(&RtuDataAddr->S_Event_Save[local[m]].Event.Buff[10]));
				//sprintf(datestr,"%d.%d",GetDataType02(&RtuDataAddr->S_Event_Save[local[m]].Event.Buff[10])/10000,GetDataType02(&RtuDataAddr->S_Event_Save[local[m]].Event.Buff[10])%10000);
				//GUI_DispStringAt(datestr,16,128);
				GUI_DispStringAt((INT8U *)"kw",120,128);
			}
		}

		Status_Bar();
		BottomBar();
		Lcmfull();
		keysele=KeySeleflag;
		KeySeleflag =0;
		if(keysele!=0)DelayTime=0;else DelayTime++;
		if(DelayTime>=PageDelayTime)
	       {
			OldLevel=0;
			return 0;
		}
		if(count==0)
			switch(keysele)
		{
			   case 1: DelayTime=0;break;
			   case 2: DelayTime=0;break;
			   case 3: DelayTime=0;break;//��
			   case 4: DelayTime=0;break;
			   case 5: DelayTime=0;break;
			   case 6: OldLevel=0;return 0;break;
			   default:break;
		}
		if(count!=0)
			switch(keysele)
		{
		   case 1: if(m==0) m=count-1; else m=(m-1)%count; DelayTime=0;break;
		   case 2: m=(m+1)%count;DelayTime=0;break;
		   case 3: if(j==0)j=1;else j=j-1;DelayTime=0;break;//��
		   case 4: j=(j+1)%2;DelayTime=0;break;
		   case 5: DelayTime=0;break;
		   case 6: OldLevel=0;return 0;break;
		   default:break;
		}
	  }

}
//******************************************************************************************************************
//* �������ƣ�Show_ShiDian_Record()�����ڵڶ����˵�
//* ��    �ܣ���ʧ���¼��
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
int Show_ShiDian_Record(INT8U SeleMenu)
{
	unsigned char keysele;
	unsigned int DelayTime,j,count,m;
	unsigned char local[256];

	DelayTime=0;
	j=0;
	count=0;
	m=0;
	a_up = a_down =  1;
	a_right = a_left = 0;
	if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[1] & 0x20)
	{
		count =getevent(local,1,14);
	}
	else
	{
		count =getevent(local,0,14);
	}
	while(1)
	{
		Lcmpower();
		if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[1] & 0x20)
		{
			if(count==0)
			{
				a_up = a_down =  0;
				a_right = a_left = 0;
				GUI_Clear();
				GUI_DispStringAt((INT8U *)"��ʧ���¼",28,64);
			}
			if(count==1)
			{
				a_up = a_down =  0;
				a_right = a_left = 0;
			}

			if(count>=1)
			{
				GUI_Clear();
				GUI_DispStringAt((INT8U *)"ʧ���¼ ",0,16);
				GUI_DispDecAt( m+1 ,64,16,1);
				GUI_DispStringAt((INT8U *)"ʧ�緢��ʱ��:",0,40);
				GUI_DispStringAt((INT8U *)"-",32,60);
				GUI_DispStringAt((INT8U *)"-",60,60);
				GUI_DispStringAt((INT8U *)" ",88,60);
				GUI_DispStringAt((INT8U *)":",112,60);
				//GUI_DispStringAt("20",0,40);
				GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[6],16,60,2);//��ʾ��ǰ�洢�������¼�����
				GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[5],42,60,2);//��ʾ��ǰ�洢�������¼�����
				GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[4],68,60,2);//��ʾ��ǰ�洢�������¼�����
				GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[3],94,60,2);//��ʾ��ǰ�洢�������¼�����
				GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[2],120,60,2);//��ʾ��ǰ�洢�������¼�����

				GUI_DispStringAt((INT8U *)"�ָ�ʱ��:",0,80);
				GUI_DispStringAt((INT8U *)"-",32,100);
				GUI_DispStringAt((INT8U *)"-",60,100);
				GUI_DispStringAt((INT8U *)" ",88,100);
				GUI_DispStringAt((INT8U *)":",112,100);

				GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[11],16,100,2);//��ʾ��ǰ�洢�������¼�����
				GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[10],42,100,2);//��ʾ��ǰ�洢�������¼�����
				GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[9],68,100,2);//��ʾ��ǰ�洢�������¼�����
				GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[8],94,100,2);//��ʾ��ǰ�洢�������¼�����
				GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[7],120,100,2);//��ʾ��ǰ�洢�������¼�����

			}

		}
		else
		{
			if(count==0)
			{
				a_up = a_down =  0;
				a_right = a_left = 0;
				GUI_Clear();
				GUI_DispStringAt((INT8U *)"��ʧ���¼",28,64);
			}
			if(count==1)
			{
				a_up = a_down =  0;
				a_right = a_left = 0;
			}
			//for(k=RtuDataAddr->Fm_Save_Eve.EC2-1;k>=0;k--)
			//{
			//if(RtuDataAddr->S_Event_Save[k].Event.Buff[0]==14)
			if(count>=1)
			{
				GUI_Clear();
				GUI_DispStringAt((INT8U *)"ʧ���¼ ",0,16);
				GUI_DispDecAt( m+1 ,64,16,1);
				GUI_DispStringAt((INT8U *)"ʧ�緢��ʱ��:",0,40);
				GUI_DispStringAt((INT8U *)"-",32,60);
				GUI_DispStringAt((INT8U *)"-",60,60);
				GUI_DispStringAt((INT8U *)" ",88,60);
				GUI_DispStringAt((INT8U *)":",112,60);
				//GUI_DispStringAt("20",0,40);
				GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[6],16,60,2);//��ʾ��ǰ�洢�������¼�����
				GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[5],42,60,2);//��ʾ��ǰ�洢�������¼�����
				GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[4],68,60,2);//��ʾ��ǰ�洢�������¼�����
				GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[3],94,60,2);//��ʾ��ǰ�洢�������¼�����
				GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[2],120,60,2);//��ʾ��ǰ�洢�������¼�����

				GUI_DispStringAt((INT8U *)"�ָ�ʱ��:",0,80);
				GUI_DispStringAt((INT8U *)"-",32,100);
				GUI_DispStringAt((INT8U *)"-",60,100);
				GUI_DispStringAt((INT8U *)" ",88,100);
				GUI_DispStringAt((INT8U *)":",112,100);

				GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[11],16,100,2);//��ʾ��ǰ�洢�������¼�����
				GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[10],42,100,2);//��ʾ��ǰ�洢�������¼�����
				GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[9],68,100,2);//��ʾ��ǰ�洢�������¼�����
				GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[8],94,100,2);//��ʾ��ǰ�洢�������¼�����
				GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[7],120,100,2);//��ʾ��ǰ�洢�������¼�����

			}
			//}
		}

		Status_Bar();
		BottomBar();
		Lcmfull();
		keysele=KeySeleflag;
		KeySeleflag =0;
		if(keysele!=0)DelayTime=0;else DelayTime++;
		if(DelayTime>=PageDelayTime)
	       {
			OldLevel=0;
			return 0;
		}
		if(count==0)
			switch(keysele)
		{
			   case 1: DelayTime=0;break;
			   case 2: DelayTime=0;break;
			   case 3: DelayTime=0;break;//��
			   case 4: DelayTime=0;break;
			   case 5: DelayTime=0;break;
			   case 6: OldLevel=0;return 0;break;
			   default:break;
		}
		if(count!=0)
			switch(keysele)
		{
			   case 1: if(m==0) m=count-1; else m=(m-1)%count; DelayTime=0;break;
			   case 2: m=(m+1)%count;DelayTime=0;break;
			   case 3: if(j==0)j=1;else j=j-1;DelayTime=0;break;//��
			   case 4: j=(j+1)%2;DelayTime=0;break;
			   case 5: DelayTime=0;break;
			   case 6: OldLevel=0;return 0;break;
			   default:break;
		}
	  }

}
//******************************************************************************************************************
//* �������ƣ�Show_GouDian()�����ڵڶ����˵�
//* ��    �ܣ���������Ϣ��
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
int Show_GouDian(INT8U SeleMenu)
{
	unsigned char keysele,GoudianNum;
	unsigned int DelayTime;

	DelayTime=0;
	GoudianNum=0;
	a_up = a_down =  1;
	a_right = a_left = 0;

		  while(1)
		  {
			  Lcmpower();
			  GUI_Clear();

			  GUI_DispStringAt((INT8U *)"�ܼ��� :",0,16);
			  GUI_SetTextMode(GUI_TM_REV);
			  GUI_DispDecAt(GoudianNum+1 ,48,16,1);
			  GUI_SetTextMode(GUI_TM_NORMAL);

			  GUI_DispStringAt((INT8U *)"���絥��:",0,36);
			  memset(NowInput.buf,0,128);
			  sprintf((char *)NowInput.buf,"%02x%02x%02x%02x",
				  RtuDataAddr->Zj_Control_Value[GoudianNum].F47_Set_Para.Gou_DIan_DanHao[3],
				  RtuDataAddr->Zj_Control_Value[GoudianNum].F47_Set_Para.Gou_DIan_DanHao[2],
				  RtuDataAddr->Zj_Control_Value[GoudianNum].F47_Set_Para.Gou_DIan_DanHao[1],
				  RtuDataAddr->Zj_Control_Value[GoudianNum].F47_Set_Para.Gou_DIan_DanHao[0]);
			  GUI_DispStringAt(NowInput.buf,72,36);
			  GUI_DispStringAt((INT8U *)"��ǰ����:",0,52);

			  GUI_DispDecShiftAt(72,52,8,0,GetdataType03(RtuDataAddr->Zj_Control_Value[GoudianNum].Old_DianLiang));
			  /*memset(NowInput.buf,0,128);
			  sprintf(NowInput.buf,"%02x%02x%02x%02x",
			  RtuDataAddr->Zj_Control_Value[GoudianNum].Old_DianLiang[3],
			  RtuDataAddr->Zj_Control_Value[GoudianNum].Old_DianLiang[2],
			  RtuDataAddr->Zj_Control_Value[GoudianNum].Old_DianLiang[1],
			  RtuDataAddr->Zj_Control_Value[GoudianNum].Old_DianLiang[0]);
			  GUI_DispStringAt(NowInput.buf,72,52);*/


			  GUI_DispStringAt((INT8U *)"�������:",0,68);
			  GUI_DispDecShiftAt(72,68,8,0,(GetdataType03(RtuDataAddr->Zj_Control_Value[GoudianNum].New_DianLiang)));
			  /* memset(NowInput.buf,0,128);
			  sprintf(NowInput.buf,"%02x%02x%02x%02x",
			  RtuDataAddr->Zj_Control_Value[GoudianNum].New_DianLiang[3],
			  RtuDataAddr->Zj_Control_Value[GoudianNum].New_DianLiang[2],
			  RtuDataAddr->Zj_Control_Value[GoudianNum].New_DianLiang[1],
			  RtuDataAddr->Zj_Control_Value[GoudianNum].New_DianLiang[0]);
			  GUI_DispStringAt(NowInput.buf,72,68);*/
			  //GUI_DispStringAt("kwh",134,48);

			  GUI_DispStringAt((INT8U *)"��������:",0,84);
			  memset(NowInput.buf,0,128);
			  sprintf((char *)NowInput.buf,"%02x%02x%02x%02x",
				  RtuDataAddr->Zj_Control_Value[GoudianNum].F47_Set_Para.Alarm_Men[3],
				  RtuDataAddr->Zj_Control_Value[GoudianNum].F47_Set_Para.Alarm_Men[2],
				  RtuDataAddr->Zj_Control_Value[GoudianNum].F47_Set_Para.Alarm_Men[1],
				  RtuDataAddr->Zj_Control_Value[GoudianNum].F47_Set_Para.Alarm_Men[0]);
			  GUI_DispStringAt(NowInput.buf,72,84);
			  //GUI_DispStringAt("kwh",134,64);

			  GUI_DispStringAt((INT8U *)"��բ����:",0,100);
			  memset(NowInput.buf,0,128);
			  sprintf((char *)NowInput.buf,"%02x%02x%02x%02x",
				  RtuDataAddr->Zj_Control_Value[GoudianNum].F47_Set_Para.TiaoZha_Men[3],
				  RtuDataAddr->Zj_Control_Value[GoudianNum].F47_Set_Para.TiaoZha_Men[2],
				  RtuDataAddr->Zj_Control_Value[GoudianNum].F47_Set_Para.TiaoZha_Men[1],
				  RtuDataAddr->Zj_Control_Value[GoudianNum].F47_Set_Para.TiaoZha_Men[0]);
			  GUI_DispStringAt(NowInput.buf,72,100);
			  //GUI_DispStringAt("kwh",134,80);
			  //GUI_DispStringAt("�ִ���բ����:",0,112);

			  //GUI_DispDecShiftAt(104,112,7,0,RtuDataAddr->Gou_Dian_Kong_Value[GoudianNum].LunCi);
			  //printf("\n\r lcm shengyu[%d]==%d",GoudianNum,RtuDataAddr->Real_Zj_Value[GoudianNum].ShengYuDianLiang);
			  GUI_DispStringAt((INT8U *)"ʣ�����:",0,116);
			  GUI_DispDecShiftAt(72,116,8,0,(RtuDataAddr->Real_Zj_Value[GoudianNum].ShengYuDianLiang));
			  //GUI_DispStringAt("kwh",134,96);

			  Status_Bar();
			  BottomBar();
			  Lcmfull();
			  keysele=KeySeleflag;
			  KeySeleflag =0;
			  if(keysele!=0)DelayTime=0;else DelayTime++;
			  if(DelayTime>=PageDelayTime)
			  {
				  OldLevel=10;
				  MenuSele = 5;
				  return 0;
			  }
			  switch(keysele)
			  {
			  case 1: if(GoudianNum==0)GoudianNum=7;else GoudianNum=GoudianNum-1;DelayTime=0;break;//��
			  case 2: GoudianNum=(GoudianNum+1)%ZongJia_Max;DelayTime=0;break;//��
			  case 6: OldLevel=10;MenuSele = 5;return 0;break;
			  default:break;
			  }

		  }


}

//******************************************************************************************************************
//* �������ƣ�Show_ZhongDuan_Xx()�����ڵڶ����˵�
//* ��    �ܣ����汾��Ϣ��
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
int Show_ZhongDuan_Xx(INT8U SeleMenu)
{
	unsigned char keysele,TempBuf[16];
	unsigned int DelayTime,tmpaddr,j;
	unsigned char RTS_Time;
	DelayTime=0;
	j=0;
	while(1)
	{
		Lcmpower();
		GUI_Clear();
		GUI_DispStringAt((INT8U *)"1.��������:",0,16);
		GUI_DispStringAt((INT8U *)"2.��������:",0,32);
		GUI_DispStringAt((INT8U *)"3.�ն˵�ַ:",0,48);
		GUI_DispStringAt((INT8U *)"4.�ն˱��:",0,64);
		GUI_DispStringAt((INT8U *)"5.�����汾:",0,80);
		GUI_DispStringAt((INT8U *)"6.ͨ������:",0,96);
		GUI_DispStringAt((INT8U *)"7.������ʱ:",0,112);

		GUI_DispStringAt((INT8U *)"11",88,16);//��������
		memset(TempBuf,0,16);
		sprintf((char *)TempBuf,"%02x%02x",
			RtuDataAddr->FkComm_Value.GB22601991[1],
			RtuDataAddr->FkComm_Value.GB22601991[0]
			);  //����ת����Ϊ�ַ���
		GUI_DispStringAt(TempBuf,88,32);//��������

		tmpaddr= (RtuDataAddr->FkComm_Value.ADDR[1]<<8)+ RtuDataAddr->FkComm_Value.ADDR[0];
		memset(TempBuf,0,16);
		sprintf((char *)TempBuf,"%04x",tmpaddr);
		GUI_DispStringAt(TempBuf,88,48);//�ն˵�ַ

		memset(TempBuf,0,16);
		memcpy(TempBuf,RtuDataAddr->FkComm_Value.DevCode,8);
		GUI_DispStringAt(TempBuf,88,64);//�ն˱��

		GUI_DispStringAt(RtuDataAddr->ucsysVER,88,80);//�����汾

		GUI_DispStringAt((INT8U *)"53.6kbps",88,96);//ͨ������
		RTS_Time=(RtuDataAddr->FkComm_Value.F1_Set_Para.RTS_Time)*20;
		GUI_DispDecAt(RTS_Time,88,112,4);//������ʱ
		GUI_DispStringAt((INT8U *)"ms",120,112);//�ն˱��
		Status_Bar();
		Lcmfull();
		keysele=KeySeleflag;
		KeySeleflag =0;
		if(keysele!=0)DelayTime=0;else DelayTime++;
		if(DelayTime>=PageDelayTime)
	    {
			OldLevel=10;
			return 0;
		}
		switch(keysele)
		{
		case 0:DelayTime++;break;
		case 1: break;
		case 2:  break;
		case 3: if(j==0)j=2;else j=j-1;DelayTime=0;break;//��
		case 4: j=(j+1)%3;DelayTime=0;break;
		case 5: DelayTime=0;break;
		case 6: OldLevel=10;MenuSele = 6;return 0;break;
		default:break;
		}
	}
}


//******************************************************************************************************************
//* �������ƣ�Show_ShiDuan_Can()�����ڵڶ����˵�
//* ��    �ܣ���ʱ�οز�����
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
void initAllShiDuanshow()
{
	INT8U i,Temp,SdNo;
	INT16U NinCountTemp;
	NinCountTemp=0;
	SdNo=0;
	for(i=0;i<8;i++)
	{
		RtuDataAddr->All_ShiD_Value[i].startMin=0;
		RtuDataAddr->All_ShiD_Value[i].endMin=0;
		RtuDataAddr->All_ShiD_Value[i].Valid=0;
	}
	for(i=0;i<12;i++)
	{
		ShowSd48[i*4]=RtuDataAddr->Fk_Control_Set_Value.F18_Set_Para.ZD_GK_SD[i]&0x03;
		ShowSd48[i*4+1]=(RtuDataAddr->Fk_Control_Set_Value.F18_Set_Para.ZD_GK_SD[i]>>2)&0x03;
		ShowSd48[i*4+2]=(RtuDataAddr->Fk_Control_Set_Value.F18_Set_Para.ZD_GK_SD[i]>>4)&0x03;
		ShowSd48[i*4+3]=(RtuDataAddr->Fk_Control_Set_Value.F18_Set_Para.ZD_GK_SD[i]>>6)&0x03;
	}

	Temp=ShowSd48[0];
	RtuDataAddr->All_ShiD_Value[SdNo].startMin=0;
	for(i=0;i<48;i++)
	{
		if((Temp==0)||(Temp==3))
		{
			RtuDataAddr->All_ShiD_Value[SdNo].Valid=0;
		}
		else
		{
			RtuDataAddr->All_ShiD_Value[SdNo].Valid=1;
		}
		if(Temp!=ShowSd48[i])
		{
			RtuDataAddr->All_ShiD_Value[SdNo].endMin=NinCountTemp;
			Temp=ShowSd48[i];
			SdNo++;
			RtuDataAddr->All_ShiD_Value[SdNo].startMin=NinCountTemp;
		}
		NinCountTemp+=30;
		if(SdNo>=8)break;
	}
	RtuDataAddr->All_ShiD_Value[SdNo].endMin=NinCountTemp;
}
void initShiDuanshow(INT8U P)
{
	INT16U NinCountTemp;
	INT8U i,SdNo;
	NinCountTemp=0;
	SdNo=0;
	for(i=0;i<8;i++)
	{
		RtuDataAddr->ShiD_Kong_Value[P].Shiduan_value[i].Valid=0;
		RtuDataAddr->ShiD_Kong_Value[P].Shiduan_value[i].startMin=RtuDataAddr->All_ShiD_Value[i].startMin;
		RtuDataAddr->ShiD_Kong_Value[P].Shiduan_value[i].endMin=RtuDataAddr->All_ShiD_Value[i].endMin;
		RtuDataAddr->ShiD_Kong_Value[P].Shiduan_value[i].DingZhi=0;
	}
	for(i=0;i<8;i++)
	{
		if(RtuDataAddr->All_ShiD_Value[i].Valid==1)
		{
			RtuDataAddr->ShiD_Kong_Value[P].Shiduan_value[i].Valid=1;
		}
	}
}
int ShiDuanShow(INT8U ZongJia,INT8U Page)
{
	INT8U m,i=0;
	INT8U n=0;
    if(Page>=0&&Page<=5)
    {
		GUI_Clear();
		if(Page==0||Page==1)
		{
			n=0;
            GUI_DispStringAt((INT8U *)"�ܼ��� ������:",0,16);
            GUI_DispDecAt( ZongJia+1,48,16,1);
            GUI_DispStringAt((INT8U *)"1",104,16);
		}
		if(Page==2||Page==3)
		{
			n=1;
            GUI_DispStringAt((INT8U *)"�ܼ��� ������:",0,16);
            GUI_DispDecAt( ZongJia+1,48,16,1);
            GUI_DispStringAt((INT8U *)"2",104,16);
		}
		if(Page==4||Page==5)
		{
			n=2;
            GUI_DispStringAt((INT8U *)"�ܼ��� ������:",0,16);
            GUI_DispDecAt( ZongJia+1,48,16,1);
            GUI_DispStringAt((INT8U *)"3",104,16);
		}
        GUI_DispStringAt((INT8U *)"Ͷ���ִ�:",0,32);
		if((RtuDataAddr->Zj_Control_Value[ZongJia].F45_Set_Para.GongKong_Lunci_Biaozhi>>0)&0x01)
		{
			GUI_DispStringAt((INT8U *)"1",88+i*16,32);
			i++;
		}
		if((RtuDataAddr->Zj_Control_Value[ZongJia].F45_Set_Para.GongKong_Lunci_Biaozhi>>1)&0x01)
		{
			GUI_DispStringAt((INT8U *)"2",88+i*16,32);
			i++;
		}
		if((RtuDataAddr->Zj_Control_Value[ZongJia].F45_Set_Para.GongKong_Lunci_Biaozhi>>2)&0x01)
		{
			GUI_DispStringAt((INT8U *)"3",88+i*16,32);
			i++;
		}
		if((RtuDataAddr->Zj_Control_Value[ZongJia].F45_Set_Para.GongKong_Lunci_Biaozhi>>3)&0x01)
		{
			GUI_DispStringAt((INT8U *)"4",88+i*16,32);
			i++;
		}
		initAllShiDuanshow();
		initShiDuanshow(ZongJia);
        GUI_DispStringAt((INT8U *)"ʱ��",0,48);
        GUI_DispStringAt((INT8U *)"��ֵ(KW)",96,48);
		if(Page==0||Page==2||Page==4)
		{
			GUI_DispStringAt((INT8U *)"(1-4)",32,48);
			for(m=0;m<4;m++)
			{
				GUI_DispDecAt(RtuDataAddr->ShiD_Kong_Value[ZongJia].Shiduan_value[m].startMin/60 ,0,(64+m*16),2);
				GUI_DispDecAt(RtuDataAddr->ShiD_Kong_Value[ZongJia].Shiduan_value[m].startMin%60 ,24,(64+m*16),2);
				GUI_DispStringAt((INT8U *)":",16,(64+m*16));
				GUI_DispStringAt((INT8U *)"-",40,(64+m*16));
				GUI_DispDecAt(RtuDataAddr->ShiD_Kong_Value[ZongJia].Shiduan_value[m].endMin/60 ,48,(64+m*16),2);
				GUI_DispDecAt(RtuDataAddr->ShiD_Kong_Value[ZongJia].Shiduan_value[m].endMin%60 ,72,(64+m*16),2);
				GUI_DispStringAt((INT8U *)":",64,(64+m*16));
				//GUI_DispDecAt(RtuDataAddr->ShiD_Kong_Value[ZongJia].Shiduan_value[m].DingZhi ,96,(64+m*16),7);
				GUI_DispDecShiftAt(96,(64+m*16),7,0,GetDataType02(&RtuDataAddr->Zj_Control_Value[ZongJia].F41_Set_Para.ShiDuan_DingZhi[n].ShiDG_DingZhi[m][0])/10000);

			}
		}
       	if(Page==1||Page==3||Page==5)
        {
            GUI_DispStringAt((INT8U *)"(5-8)",32,48);
			for(m=4;m<8;m++)
			{
				GUI_DispDecAt(RtuDataAddr->ShiD_Kong_Value[ZongJia].Shiduan_value[m].startMin/60 ,0,(64+(m-4)*16),2);
				GUI_DispDecAt(RtuDataAddr->ShiD_Kong_Value[ZongJia].Shiduan_value[m].startMin%60 ,24,(64+(m-4)*16),2);
				GUI_DispStringAt((INT8U *)":",16,(64+(m-4)*16));
				GUI_DispStringAt((INT8U *)"-",40,(64+(m-4)*16));
				GUI_DispDecAt(RtuDataAddr->ShiD_Kong_Value[ZongJia].Shiduan_value[m].endMin/60 ,48,(64+(m-4)*16),2);
				GUI_DispDecAt(RtuDataAddr->ShiD_Kong_Value[ZongJia].Shiduan_value[m].endMin%60 ,72,(64+(m-4)*16),2);
				//GUI_DispDecAt(RtuDataAddr->ShiD_Kong_Value[ZongJia].Shiduan_value[m].DingZhi ,96,(64+(m-4)*16),7);
				GUI_DispDecShiftAt(96,(64+(m-4)*16),7,0,GetDataType02(&RtuDataAddr->Zj_Control_Value[ZongJia].F41_Set_Para.ShiDuan_DingZhi[n].ShiDG_DingZhi[m][0])/10000);
				GUI_DispStringAt((INT8U *)":",64,(64+(m-4)*16));
			}
        }
       	return 1;
    }
    else
		return 0;
}
int Show_ShiDuan_Can(INT8U SeleMenu)
{
	unsigned char keysele,GoudianNum,j;
	unsigned int DelayTime;

	DelayTime=0;
	GoudianNum=0;
	j=0;
	a_up = a_down =  1;
	a_right = a_left = 1;

	while(1)
	{
		Lcmpower();
		ShiDuanShow(GoudianNum,j);
	    Status_Bar();
		BottomBar();
		Lcmfull();
		keysele=KeySeleflag;
		KeySeleflag =0;
		if(keysele!=0)DelayTime=0;else DelayTime++;
		if(DelayTime>=PageDelayTime)
		{
			OldLevel=0;
			return 0;
		}
		switch(keysele)
		{
			case 1: if(GoudianNum==0)GoudianNum=7;else GoudianNum=GoudianNum-1;DelayTime=0;break;//��
			case 2: GoudianNum=(GoudianNum+1)%ZongJia_Max;DelayTime=0;break;//��
			case 3: if(j==0)j=5;else j=j-1;DelayTime=0;break;//��
			case 4: j=(j+1)%6;DelayTime=0;break;//��
			case 6: OldLevel=0;return 0;break;
			default:break;
		}
	}
}
//******************************************************************************************************************
//* �������ƣ�Show_ChangXiu_Can()�����ڵڶ����˵�
//* ��    �ܣ������ݿز�����
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
int Show_ChangXiu_Can(INT8U SeleMenu)
{
	unsigned char keysele,GoudianNum,i,j,m,Min,Hour;
	unsigned int DelayTime,Xiandian_End;

	DelayTime=0;
	GoudianNum=0;
	i=0;
	j=0;
	Min=0;
	Hour=0;
	Xiandian_End=0;
	a_up = a_down =  1;
	a_right = a_left = 0;

	while(1)
	{
		Lcmpower();
		i=0;
		j=0;
		m=0;
		GUI_Clear();
		GUI_DispStringAt((INT8U *)"�ܼ��� ���ݿز���",0,16);
		GUI_DispDecAt( GoudianNum+1,48,16,1);

		GUI_DispStringAt((INT8U *)"Ͷ���ִ�:",0,32);
			  //GUI_DispDecAt(RtuDataAddr->Gonglv_XiaFu_Value[GoudianNum].LunCi ,72,32,2);
		if((RtuDataAddr->Zj_Control_Value[GoudianNum].F45_Set_Para.GongKong_Lunci_Biaozhi>>0)&0x01)
		{
			GUI_DispStringAt((INT8U *)"1",72+m*16,32);
			m++;
		}
		if((RtuDataAddr->Zj_Control_Value[GoudianNum].F45_Set_Para.GongKong_Lunci_Biaozhi>>1)&0x01)
		{
			GUI_DispStringAt((INT8U *)"2",72+m*16,32);
			m++;
		}
		if((RtuDataAddr->Zj_Control_Value[GoudianNum].F45_Set_Para.GongKong_Lunci_Biaozhi>>2)&0x01)
		{
			GUI_DispStringAt((INT8U *)"3",72+m*16,32);
			m++;
		}
		if((RtuDataAddr->Zj_Control_Value[GoudianNum].F45_Set_Para.GongKong_Lunci_Biaozhi>>3)&0x01)
		{
			GUI_DispStringAt((INT8U *)"4",72+m*16,32);
			m++;
		}
		GUI_DispStringAt((INT8U *)"���ݿض�ֵ:",0,48);

		GUI_DispDecAt(GetDataType02(&RtuDataAddr->Zj_Control_Value[GoudianNum].F42_Set_Para.ChangXiu_DingZhi[0])/10000 ,88,48,7);

		Min=RtuDataAddr->Zj_Control_Value[GoudianNum].F42_Set_Para.XianDian_Start_Time[0];
		Min=((Min>>4)*10)+(Min&0x0f);
	    Hour=RtuDataAddr->Zj_Control_Value[GoudianNum].F42_Set_Para.XianDian_Start_Time[1];
		Hour=((Hour>>4)*10)+(Hour&0x0f);
		Xiandian_End=(Hour*60+Min)+(RtuDataAddr->Zj_Control_Value[GoudianNum].F42_Set_Para.XianDian_Delay_Time*30);
		GUI_DispStringAt((INT8U *)"��ʼʱ��:",0,64);
		GUI_DispDecAt(Hour,72,64,2);
		GUI_DispStringAt((INT8U *)":",88,64);
		GUI_DispDecAt(Min ,96,64,2);
		GUI_DispStringAt((INT8U *)"��ֹʱ��:",0,80);
		GUI_DispDecAt(Xiandian_End/60 ,72,80,2);
		GUI_DispStringAt((INT8U *)":",88,80);
		GUI_DispDecAt(Xiandian_End%60 ,96,80,2);
			  //GUI_DispStringAt("Ͷ���ִ�:",0,80);
			  //GUI_DispDecAt(RtuDataAddr->changxiu_Kong_Value[GoudianNum].LunCi ,72,80,2);
	    GUI_DispStringAt((INT8U *)"������:",0,96);
			  //GUI_DispDecAt(RtuDataAddr->changxiu_Kong_Value[GoudianNum].XianDianWeek,84,106,2);
		if((RtuDataAddr->Zj_Control_Value[GoudianNum].F42_Set_Para.XianDian_Day>>1)&0x01)
		{
			GUI_DispStringAt((INT8U *)"��һ",i*40,(112+j*16));
			i++;
			if(i==4)
			{
				i=0;
				j++;
			}
		}
		if((RtuDataAddr->Zj_Control_Value[GoudianNum].F42_Set_Para.XianDian_Day>>2)&0x01)
		{
			GUI_DispStringAt((INT8U *)"�ܶ�",i*40,(112+j*16));
			i++;
			if(i==4)
			{
				i=0;
				j++;
			}
		}
		if((RtuDataAddr->Zj_Control_Value[GoudianNum].F42_Set_Para.XianDian_Day>>3)&0x01)
		{
			GUI_DispStringAt((INT8U *)"����",i*40,(112+j*16));
			i++;
			if(i==4)
			{
				i=0;
				j++;
			}
		}
		if((RtuDataAddr->Zj_Control_Value[GoudianNum].F42_Set_Para.XianDian_Day>>4)&0x01)
		{
			GUI_DispStringAt((INT8U *)"����",i*40,(112+j*16));
			i++;
			if(i==4)
			{
				i=0;
				j++;
			}
		}
		if((RtuDataAddr->Zj_Control_Value[GoudianNum].F42_Set_Para.XianDian_Day>>5)&0x01)
		{
			GUI_DispStringAt((INT8U *)"����",i*40,(112+j*16));
			i++;
			if(i==4)
			{
				i=0;
				j++;
			}
		}
		if((RtuDataAddr->Zj_Control_Value[GoudianNum].F42_Set_Para.XianDian_Day>>6)&0x01)
		{
			GUI_DispStringAt((INT8U *)"����",i*40,(112+j*16));
			i++;
			if(i==4)
			{
				i=0;
				j++;
			}
		}
		if((RtuDataAddr->Zj_Control_Value[GoudianNum].F42_Set_Para.XianDian_Day>>7)&0x01)
		{
			GUI_DispStringAt((INT8U *)"����",i*40,(112+j*16));
			i++;
			if(i==4)
			{
				i=0;
				j++;
			}
		}

		Status_Bar();
		BottomBar();
		Lcmfull();
		keysele=KeySeleflag;
		KeySeleflag =0;
		if(keysele!=0)DelayTime=0;else DelayTime++;
		if(DelayTime>=PageDelayTime)
		{
			OldLevel=0;
			return 0;
		}
		switch(keysele)
		{
			 case 1: if(GoudianNum==0)GoudianNum=7;else GoudianNum=GoudianNum-1;DelayTime=0;break;//��
			 case 2: GoudianNum=(GoudianNum+1)%ZongJia_Max;DelayTime=0;break;//��
			 case 6: GUI_SetTextMode(GUI_TM_NORMAL);OldLevel=0;return 0;break;
			 default:break;
		}
	}
}
//******************************************************************************************************************
//* �������ƣ�Show_YingYe_Can()�����ڵڶ����˵�
//* ��    �ܣ���Ӫҵ��������
////* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
int Show_YingYe_Can(INT8U SeleMenu)
{
	unsigned char keysele,GoudianNum;
	unsigned int DelayTime;

	DelayTime=0;
	GoudianNum=0;
	a_up = a_down =  1;
	a_right = a_left = 0;
	while(1)
	{
		GUI_Clear();
		GUI_DispStringAt((INT8U *)"�ܼ���  Ӫҵ��ͣ����",0,16);
		GUI_DispDecAt( GoudianNum+1,56,16,1);

		GUI_DispStringAt((INT8U *)"��ͣ�ض�ֵ:",8,40);
		GUI_DispDecAt(RtuDataAddr->YingyeBaoting_Value[GoudianNum].DingZhi ,96,40,3);

		GUI_DispStringAt((INT8U *)"��ʼʱ��:",8,56);
		GUI_DispDecAt(RtuDataAddr->YingyeBaoting_Value[GoudianNum].Day_start ,80,56,5);

		GUI_DispStringAt((INT8U *)"��ֹʱ��:",8,72);
		GUI_DispDecAt(RtuDataAddr->YingyeBaoting_Value[GoudianNum].Day_End ,80,72,5);

		GUI_DispStringAt((INT8U *)"Ͷ���ִ�:",8,88);
		GUI_DispDecAt(RtuDataAddr->YingyeBaoting_Value[GoudianNum].LunCi ,80,88,2);
		Status_Bar();
		BottomBar();
		Lcmfull();
		keysele=KeySeleflag;
		KeySeleflag =0;
		if(keysele!=0)DelayTime=0;else DelayTime++;
		if(DelayTime>=PageDelayTime)
		{
			OldLevel=0;
			return 0;
		}
		switch(keysele)
		{
			 case 1: if(GoudianNum==0)GoudianNum=7;else GoudianNum=GoudianNum-1;DelayTime=0;break;//��
			 case 2: GoudianNum=(GoudianNum+1)%ZongJia_Max;DelayTime=0;break;//��
			 case 6: OldLevel=0;return 0;break;
			 default:break;
		}
	}
}
//******************************************************************************************************************
//* �������ƣ�Show_XiaFu_Can()�����ڵڶ����˵�
//* ��    �ܣ����¸�������
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
int Show_XiaFu_Can(INT8U SeleMenu)
{
	unsigned char keysele,GoudianNum,i,k;
	unsigned int DelayTime;

	DelayTime=0;
	GoudianNum=0;
	k=0;
	a_up = a_down =  1;
	a_right = a_left = 0;

		  while(1)
		  {
			  Lcmpower();
			  GUI_Clear();
			  i=0;
			  GUI_DispStringAt((INT8U *)"�ܼ��� �¸��ز���",12,16);
			  GUI_DispDecAt( GoudianNum+1,60,16,1);

			  GUI_DispStringAt((INT8U *)"Ͷ���ִ�:",0,32);
			  if((RtuDataAddr->Zj_Control_Value[GoudianNum].F45_Set_Para.GongKong_Lunci_Biaozhi>>0)&0x01)
			  {
				  GUI_DispStringAt((INT8U *)"1",72+i*16,32);
				  i++;
			  }
			  if((RtuDataAddr->Zj_Control_Value[GoudianNum].F45_Set_Para.GongKong_Lunci_Biaozhi>>1)&0x01)
			  {
				  GUI_DispStringAt((INT8U *)"2",72+i*16,32);
				  i++;
			  }
			  if((RtuDataAddr->Zj_Control_Value[GoudianNum].F45_Set_Para.GongKong_Lunci_Biaozhi>>2)&0x01)
			  {
				  GUI_DispStringAt((INT8U *)"3",72+i*16,32);
				  i++;
			  }
			  if((RtuDataAddr->Zj_Control_Value[GoudianNum].F45_Set_Para.GongKong_Lunci_Biaozhi>>3)&0x01)
			  {
				  GUI_DispStringAt((INT8U *)"4",72+i*16,32);
				  i++;
			  }
			  printf("\n\rRtuDataAddr->FuKong_Control_Value.F12_Control_Para[%d].Gonglv_Xiafu_Gaojing_Time1==%d",GoudianNum,RtuDataAddr->FuKong_Control_Value.F12_Control_Para[GoudianNum].Gonglv_Xiafu_Gaojing_Time1);
			  GUI_DispStringAt((INT8U *)"��1�ָ澯ʱ��:",0,48);
			  GUI_DispDecAt(RtuDataAddr->FuKong_Control_Value.F12_Control_Para[GoudianNum].Gonglv_Xiafu_Gaojing_Time1,112,48,2);
			  GUI_DispStringAt((INT8U *)"min",132,48);
			  GUI_DispStringAt((INT8U *)"��2�ָ澯ʱ��:",0,64);
			  GUI_DispDecAt(RtuDataAddr->FuKong_Control_Value.F12_Control_Para[GoudianNum].Gonglv_Xiafu_Gaojing_Time2,112,64,2);
			  GUI_DispStringAt((INT8U *)"min",132,64);
			  GUI_DispStringAt((INT8U *)"��3�ָ澯ʱ��:",0,80);
			  GUI_DispDecAt(RtuDataAddr->FuKong_Control_Value.F12_Control_Para[GoudianNum].Gonglv_Xiafu_Gaojing_Time3 ,112,80,2);
			  GUI_DispStringAt((INT8U *)"min",132,80);
			  GUI_DispStringAt((INT8U *)"��4�ָ澯ʱ��:",0,96);
			  GUI_DispDecAt(RtuDataAddr->FuKong_Control_Value.F12_Control_Para[GoudianNum].Gonglv_Xiafu_Gaojing_Time4 ,112,96,2);
			  GUI_DispStringAt((INT8U *)"min",132,96);
			  GUI_DispStringAt((INT8U *)"����ʱ��:",0,112);
			  // GUI_DispDecAt(RtuDataAddr->Gonglv_XiaFu_Value[GoudianNum].Gonglv_Xiafu_Kongzhi_Time ,72,112,2);
			  GUI_DispDecShiftAt(72,112,4,1,RtuDataAddr->FuKong_Control_Value.F12_Control_Para[GoudianNum].Gonglv_Xiafu_Kongzhi_Time*5);
			  GUI_DispStringAt((INT8U *)"h",110,112);
			  GUI_DispStringAt((INT8U *)"����ϵ��:",0,128);
			  if(RtuDataAddr->FuKong_Control_Value.F12_Control_Para[GoudianNum].Gonglv_Xiafu_HuaCXha_XiShu&0x80)
			  {
				  GUI_DispStringAt((INT8U *)"-",80,128);
			  }
			  else
			  {
				  GUI_DispStringAt((INT8U *)"+",80,128);
			  }
			  k=(((RtuDataAddr->FuKong_Control_Value.F12_Control_Para[GoudianNum].Gonglv_Xiafu_HuaCXha_XiShu>>4)&0x07)*10)+(RtuDataAddr->FuKong_Control_Value.F12_Control_Para[GoudianNum].Gonglv_Xiafu_HuaCXha_XiShu&0x0f);
			  GUI_DispDecAt(k,88,128,3);
			  GUI_DispStringAt((INT8U *)"%",120,128);
			  Status_Bar();
			  BottomBar();
			  Lcmfull();
			  keysele=KeySeleflag;
			  KeySeleflag =0;
			  if(keysele!=0)DelayTime=0;else DelayTime++;
			  if(DelayTime>=PageDelayTime)
			  {
				  OldLevel=0;
				  return 0;
			  }
			  switch(keysele)
			  {
			  case 1: if(GoudianNum==0)GoudianNum=7;else GoudianNum=GoudianNum-1;DelayTime=0;break;//��
			  case 2: GoudianNum=(GoudianNum+1)%ZongJia_Max;DelayTime=0;break;//��
			  case 6: OldLevel=0;return 0;break;
			  default:break;
			  }

		  }

}
//******************************************************************************************************************
//* �������ƣ�Show_YueDian_Can()�����ڵڶ����˵�
//* ��    �ܣ����¸�������
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
int Show_YueDian_Can(INT8U SeleMenu)
{
	unsigned char keysele,GoudianNum,xs;
	unsigned int DelayTime;

	DelayTime=0;
	GoudianNum=0;
	xs=0;
	a_up = a_down =  1;
	a_right = a_left = 0;

		  while(1)
		  {
			  GUI_Clear();
			  GUI_DispStringAt((INT8U *)"�ܼ��� �µ�ز���:",12,16);
			  GUI_DispDecAt( GoudianNum+1,60,16,1);

			  GUI_DispStringAt((INT8U *)"�����õ���:",12,40);
			  GUI_DispDecAt((RtuDataAddr->Real_Zj_Value[GoudianNum].P_All-RtuDataAddr->Yue_Zj_Value[GoudianNum].P_All) ,100,40,3);

			  GUI_DispStringAt((INT8U *)"�µ�ض�ֵ:",12,56);
			  GUI_DispDecAt( RtuDataAddr->Yue_Dian_Kong_Value[GoudianNum].DingZhi,100,56,3);

			  GUI_DispStringAt((INT8U *)"�µ�ظ���ϵ��:",12,72);

			  if(RtuDataAddr->Fk_Control_Set_Value.F20_Set_Para.ZD_Yue_DK_DZ_FD&0x80)
			  {
				  xs=100-(((RtuDataAddr->Fk_Control_Set_Value.F20_Set_Para.ZD_Yue_DK_DZ_FD>>4)&0x07)*10)+(RtuDataAddr->Fk_Control_Set_Value.F20_Set_Para.ZD_Yue_DK_DZ_FD&0x0f);
			  }
			  else
			  {
				  xs=100+(((RtuDataAddr->Fk_Control_Set_Value.F20_Set_Para.ZD_Yue_DK_DZ_FD>>4)&0x07)*10)+(RtuDataAddr->Fk_Control_Set_Value.F20_Set_Para.ZD_Yue_DK_DZ_FD&0x0f);
			  }
			  GUI_DispDecAt( xs,132,72,3);

			  GUI_DispStringAt((INT8U *)"Ͷ���ִ�:",12,88);
			  GUI_DispDecAt( RtuDataAddr->Yue_Dian_Kong_Value[GoudianNum].LunCi,88,88,3);


			  Status_Bar();
			  BottomBar();
			  Lcmfull();
			  keysele=KeySeleflag;
			  KeySeleflag =0;
			  if(keysele!=0)DelayTime=0;else DelayTime++;
			  if(DelayTime>=PageDelayTime)
			  {
				  OldLevel=0;
				  return 0;
			  }
			  switch(keysele)
			  {
			  case 1: if(GoudianNum==0)GoudianNum=7;else GoudianNum=GoudianNum-1;DelayTime=0;break;//��
			  case 2: GoudianNum=(GoudianNum+1)%ZongJia_Max;DelayTime=0;break;//��
			  case 6: OldLevel=0;return 0;break;
			  default:break;
			  }

		  }

}
/******************************************************************************************************************
* �������ƣ�Show_peizhi_Can()�����ڵڶ����˵�
* * ��    �ܣ���peizhi��
* ��ڲ�������
* ���ڲ�������
*********************************************************************************************************************/

int Show_peizhi_Can(INT8U SeleMenu)
{
	unsigned char keysele,TempBuf[16];
	unsigned int DelayTime,tmpaddr;

	DelayTime=0;

	while(1)
	{
		Lcmpower();
		GUI_Clear();
		GUI_DispStringAt((INT8U *)"1.��������:",0,42);
		GUI_DispStringAt((INT8U *)"2.�ն˵�ַ:",0,62);

		memset(TempBuf,0,16);
		sprintf((char *)TempBuf,"%02x%02x",
			RtuDataAddr->FkComm_Value.GB22601991[1],
			RtuDataAddr->FkComm_Value.GB22601991[0]
			);  //����ת����Ϊ�ַ���
		GUI_DispStringAt(TempBuf,88,42);//��������
		tmpaddr= (RtuDataAddr->FkComm_Value.ADDR[1]<<8)+ RtuDataAddr->FkComm_Value.ADDR[0];
		memset(TempBuf,0,16);
		sprintf((char *)TempBuf,"%04x",tmpaddr);
		GUI_DispStringAt(TempBuf,88,62);//�ն˵�ַ
		Status_Bar();
		Lcmfull();
		keysele=KeySeleflag;
		KeySeleflag =0;
		if(keysele!=0)DelayTime=0;else DelayTime++;
		if(DelayTime>=PageDelayTime)
	       {
			OldLevel=10;
			return 0;
		}
		switch(keysele)
		{
		case 0:DelayTime++;break;
		case 1: break;
		case 2:  ;break;
		case 6: OldLevel=0;return 0;break;
		default:break;
		}

	}

}
/*****************************************************************************************************************
* �������ƣ�Show_DianNengBiao_Can()�����ڵڶ����˵�
* ���ܣ���DianNengBiao��
* ��ڲ�������
* ���ڲ�������
****************************************************************************************************************/
int Show_DianNengBiao_Can(INT8U SeleMenu)
{
	unsigned char keysele,i,m;
	unsigned int DelayTime;

	DelayTime=0;
	i=0;
	m=0;
	a_up = a_down =  1;
	a_right = a_left = 0;
	while(1)
	{
		Lcmpower();
		GUI_Clear();
		GUI_DispStringAt((INT8U *)"������:",0,16);
		GUI_DispStringAt((INT8U *)"1.�ֱ��:",0,32);
		GUI_DispStringAt((INT8U *)"2.ͨ��:",0,64);
		GUI_DispStringAt((INT8U *)"3.Э��:",0,80);
		GUI_DispStringAt((INT8U *)"4.��ַ:",0,96);

		GUI_DispDecAt(i+1,78,16,2);
		memset(NowInput.buf,0,128);
		m=RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].CeLiangNo-1;
		memcpy(NowInput.buf,&RtuDataAddr->Fk_Control_Set_Value.F29_Set_Para[m].JuBianHao[0],12);
		GUI_DispStringAt(NowInput.buf,16,48);//Ӧ����ʾ����ַ����

		GUI_DispStringAt((INT8U *)"485��",60,64);
		memset(NowInput.buf,0,128);
		sprintf((char *)NowInput.buf,"%d",   //16���Ƶ�BCD��
			RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].BaudAndPort&0x1F);  //����ת����Ϊ�ַ���
		GUI_DispStringAt(NowInput.buf,100,64);
		//printf("\n\r FkInput_ValueTm.F10_Set_Para.Dian_Meter[i].GuiYue_Type===%d",FkInput_ValueTmp.F10_Set_Para.Dian_Meter[i].GuiYue_Type);
		if(RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].GuiYue_Type==DLT6451997)
			GUI_DispStringAt((INT8U *)"DL/T645-1997",60,80);
		if(RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].GuiYue_Type==DLT6452007)
			GUI_DispStringAt((INT8U *)"DL/T645-2007",60,80);
		if(RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].GuiYue_Type==JiaoLiuType)
			GUI_DispStringAt((INT8U *)"��������",60,80);
		if(RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].GuiYue_Type==IEC1107)
			GUI_DispStringAt((INT8U *)"��������Լ",60,80);
		if(RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].GuiYue_Type==WSDDTyp40)
			GUI_DispStringAt((INT8U *)"��ʤ4.0",60,80);

		//memset(NowInput.buf,0,128);
		//sprintf(NowInput.buf,"%02d",   //16���Ƶ�BCD��
		//FkInput_ValueTmp.F10_Set_Para.Dian_Meter[i].GuiYue_Type);  //����ת����Ϊ�ַ���
		//GUI_DispStringAt(NowInput.buf,60,76);
		memset(NowInput.buf,0,128);
		sprintf((char *)NowInput.buf,"%02x%02x%02x%02x%02x%02x",   //16���Ƶ�BCD��
			RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Addr[5],
			RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Addr[4],
			RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Addr[3],
			RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Addr[2],
			RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Addr[1],
			RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Addr[0]);
		      //  GUI_DispStringAt(NowInput.buf,48,143);//Ӧ����ʾ����ַ����
		GUI_DispStringAt(NowInput.buf,54,96);//Ӧ����ʾ����ַ����

		Status_Bar();
		BottomBar();
		Lcmfull();
		keysele=KeySeleflag;
		KeySeleflag =0;
		if(keysele!=0)DelayTime=0;else DelayTime++;
		if(DelayTime>=PageDelayTime)
	       {
			OldLevel=0;
			return 0;
		}
		switch(keysele)
		{
		case 0:DelayTime++;break;
		case 1: if(i==0) i=7; else i=(i-1)%CeLiangPoint_Max; DelayTime=0;break;
		case 2: i=(i+1)%CeLiangPoint_Max ;DelayTime=0;break;
		case 6: OldLevel=0;return 0;break;
		default:break;
		}

	}
}

//******************************************************************************************************************
//* �������ƣ�Show_KvKiKp_Can()�����ڵڶ����˵�
//* ��    �ܣ���KvKiKp��
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
int Show_KvKiKp_Can(INT8U SeleMenu)
{
	unsigned char keysele,GoudianNum,TempBuf[16],j;
	unsigned int DelayTime;
	unsigned int num,v_beilv,i_beilv;
	DelayTime=0;
	GoudianNum=0;
	j=0;
	a_up = a_down =  0;
	num=0;
	a_right = a_left = 1;

		  while(1)
		  {
			  Lcmpower();
			  GUI_Clear();
			  switch(j)
			  {
			  case 0:
				  GUI_DispStringAt((INT8U *)"KpKv����:",48,16);

				  GUI_DispStringAt((INT8U *)"Kp1:",8,48);
				  memset(TempBuf,0,16);
				  num=(RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong[0].Changhu[1]<<8)|(RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong[0].Changhu[0]);
				  sprintf((char *)TempBuf,"%04d",num);  //����ת����Ϊ�ַ���
				  GUI_DispStringAt(TempBuf,40,48);


				  GUI_DispStringAt((INT8U *)"Kp2:",88,48);
				  memset(TempBuf,0,16);
				  num=(RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong[1].Changhu[1]<<8)|(RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong[1].Changhu[0]);
				  sprintf((char *)TempBuf,"%04d",num);  //����ת����Ϊ�ַ���
				  GUI_DispStringAt(TempBuf,120,48);

				  /*GUI_DispStringAt("Kp3:",8,48);
				  memset(TempBuf,0,16);
				  num=(RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong[2].Changhu[1]<<8)|(RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong[2].Changhu[0]);
				  sprintf(TempBuf,"%04d",num);  //����ת����Ϊ�ַ���
				  GUI_DispStringAt(TempBuf,40,48);

				  GUI_DispStringAt("Kp4:",88,48);
				  memset(TempBuf,0,16);
				  num=(RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong[3].Changhu[1]<<8)|(RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong[3].Changhu[0]);
				  sprintf(TempBuf,"%04d",num);  //����ת����Ϊ�ַ���
				  GUI_DispStringAt(TempBuf,120,48);
*/
				  GUI_DispStringAt((INT8U *)"KV1:",8,64);
				  memset(TempBuf,0,16);
				  v_beilv=(RtuDataAddr->Cl_MenXian_Value[0].F25_Set_Para.V_BeiLv[1]<<8)|(RtuDataAddr->Cl_MenXian_Value[0].F25_Set_Para.V_BeiLv[0]);
				  sprintf((char *)TempBuf,"%04d",v_beilv);  //����ת����Ϊ�ַ���
				  GUI_DispStringAt(TempBuf,40,64);

				  GUI_DispStringAt((INT8U *)"KV2:",88,64);
				  memset(TempBuf,0,16);
				  v_beilv=(RtuDataAddr->Cl_MenXian_Value[1].F25_Set_Para.V_BeiLv[1]<<8)|(RtuDataAddr->Cl_MenXian_Value[1].F25_Set_Para.V_BeiLv[0]);
				  sprintf((char *)TempBuf,"%04d",v_beilv);  //����ת����Ϊ�ַ���
				  GUI_DispStringAt(TempBuf,120,64);

				  GUI_DispStringAt((INT8U *)"KV3:",8,80);
				  memset(TempBuf,0,16);
				  v_beilv=(RtuDataAddr->Cl_MenXian_Value[2].F25_Set_Para.V_BeiLv[1]<<8)|(RtuDataAddr->Cl_MenXian_Value[2].F25_Set_Para.V_BeiLv[0]);
				  sprintf((char *)TempBuf,"%04d",v_beilv);  //����ת����Ϊ�ַ���
				  GUI_DispStringAt(TempBuf,40,80);

				  GUI_DispStringAt((INT8U *)"KV4:",88,80);
				  memset(TempBuf,0,16);
				  v_beilv=(RtuDataAddr->Cl_MenXian_Value[3].F25_Set_Para.V_BeiLv[1]<<8)|(RtuDataAddr->Cl_MenXian_Value[3].F25_Set_Para.V_BeiLv[0]);
				  sprintf((char *)TempBuf,"%04d",v_beilv);  //����ת����Ϊ�ַ���
				  GUI_DispStringAt(TempBuf,120,80);

				  GUI_DispStringAt((INT8U *)"KV5:",8,96);
				  memset(TempBuf,0,16);
				  v_beilv=(RtuDataAddr->Cl_MenXian_Value[4].F25_Set_Para.V_BeiLv[1]<<8)|(RtuDataAddr->Cl_MenXian_Value[4].F25_Set_Para.V_BeiLv[0]);
				  sprintf((char *)TempBuf,"%04d",v_beilv);  //����ת����Ϊ�ַ���
				  GUI_DispStringAt(TempBuf,40,96);

				  GUI_DispStringAt((INT8U *)"KV6:",88,96);
				  memset(TempBuf,0,16);
				  v_beilv=(RtuDataAddr->Cl_MenXian_Value[5].F25_Set_Para.V_BeiLv[1]<<8)|(RtuDataAddr->Cl_MenXian_Value[5].F25_Set_Para.V_BeiLv[0]);
				  sprintf((char *)TempBuf,"%04d",v_beilv);  //����ת����Ϊ�ַ���
				  GUI_DispStringAt(TempBuf,120,96);

				  GUI_DispStringAt((INT8U *)"KV7:",8,112);
				  memset(TempBuf,0,16);
				  v_beilv=(RtuDataAddr->Cl_MenXian_Value[6].F25_Set_Para.V_BeiLv[1]<<8)|(RtuDataAddr->Cl_MenXian_Value[6].F25_Set_Para.V_BeiLv[0]);
				  sprintf((char *)TempBuf,"%04d",v_beilv);  //����ת����Ϊ�ַ���
				  GUI_DispStringAt(TempBuf,40,112);

				  GUI_DispStringAt((INT8U *)"KV8:",88,112);
				  memset(TempBuf,0,16);
				  v_beilv=(RtuDataAddr->Cl_MenXian_Value[7].F25_Set_Para.V_BeiLv[1]<<8)|(RtuDataAddr->Cl_MenXian_Value[7].F25_Set_Para.V_BeiLv[0]);
				  sprintf((char *)TempBuf,"%04d",v_beilv);  //����ת����Ϊ�ַ���
				  GUI_DispStringAt(TempBuf,120,112);
				  break;

			  case 1:
				  GUI_DispStringAt((INT8U *)"Ki����:",56,16);
				  GUI_DispStringAt((INT8U *)"KI1:",8,40);
				  memset(TempBuf,0,16);
				  i_beilv=(RtuDataAddr->Cl_MenXian_Value[0].F25_Set_Para.I_BeiLv[1]<<8)|(RtuDataAddr->Cl_MenXian_Value[0].F25_Set_Para.I_BeiLv[0]);
				  sprintf((char *)TempBuf,"%04d",i_beilv);  //����ת����Ϊ�ַ���
				  GUI_DispStringAt(TempBuf,40,40);

				  GUI_DispStringAt((INT8U *)"KI2:",88,40);
				  memset(TempBuf,0,16);
				  i_beilv=(RtuDataAddr->Cl_MenXian_Value[1].F25_Set_Para.I_BeiLv[1]<<8)|(RtuDataAddr->Cl_MenXian_Value[1].F25_Set_Para.I_BeiLv[0]);
				  sprintf((char *)TempBuf,"%04d",i_beilv);  //����ת����Ϊ�ַ���
				  GUI_DispStringAt(TempBuf,120,40);

				  GUI_DispStringAt((INT8U *)"KI3:",8,56);
				  memset(TempBuf,0,16);
				  i_beilv=(RtuDataAddr->Cl_MenXian_Value[2].F25_Set_Para.I_BeiLv[1]<<8)|(RtuDataAddr->Cl_MenXian_Value[2].F25_Set_Para.I_BeiLv[0]);
				  sprintf((char *)TempBuf,"%04d",i_beilv);  //����ת����Ϊ�ַ���
				  GUI_DispStringAt(TempBuf,40,56);

				  GUI_DispStringAt((INT8U *)"KI4:",88,56);
				  memset(TempBuf,0,16);
				  i_beilv=(RtuDataAddr->Cl_MenXian_Value[3].F25_Set_Para.I_BeiLv[1]<<8)|(RtuDataAddr->Cl_MenXian_Value[3].F25_Set_Para.I_BeiLv[0]);
				  sprintf((char *)TempBuf,"%04d",i_beilv);  //����ת����Ϊ�ַ���
				  GUI_DispStringAt(TempBuf,120,56);

				  GUI_DispStringAt((INT8U *)"KI5:",8,72);
				  memset(TempBuf,0,16);
				  i_beilv=(RtuDataAddr->Cl_MenXian_Value[4].F25_Set_Para.I_BeiLv[1]<<8)|(RtuDataAddr->Cl_MenXian_Value[4].F25_Set_Para.I_BeiLv[0]);
				  sprintf((char *)TempBuf,"%04d",i_beilv);  //����ת����Ϊ�ַ���
				  GUI_DispStringAt(TempBuf,40,72);

				  GUI_DispStringAt((INT8U *)"KI6:",88,72);
				  memset(TempBuf,0,16);
				  i_beilv=(RtuDataAddr->Cl_MenXian_Value[5].F25_Set_Para.I_BeiLv[1]<<8)|(RtuDataAddr->Cl_MenXian_Value[5].F25_Set_Para.I_BeiLv[0]);
				  sprintf((char *)TempBuf,"%04d",i_beilv);  //����ת����Ϊ�ַ���
				  GUI_DispStringAt(TempBuf,120,72);

				  GUI_DispStringAt((INT8U *)"KI7:",8,88);
				  memset(TempBuf,0,16);
				  i_beilv=(RtuDataAddr->Cl_MenXian_Value[6].F25_Set_Para.I_BeiLv[1]<<8)|(RtuDataAddr->Cl_MenXian_Value[6].F25_Set_Para.I_BeiLv[0]);
				  sprintf((char *)TempBuf,"%04d",i_beilv);  //����ת����Ϊ�ַ���
				  GUI_DispStringAt(TempBuf,40,88);

				  GUI_DispStringAt((INT8U *)"KI8:",88,88);
				  memset(TempBuf,0,16);
				  i_beilv=(RtuDataAddr->Cl_MenXian_Value[7].F25_Set_Para.I_BeiLv[1]<<8)|(RtuDataAddr->Cl_MenXian_Value[7].F25_Set_Para.I_BeiLv[0]);
				  sprintf((char *)TempBuf,"%04d",i_beilv);  //����ת����Ϊ�ַ���
				  GUI_DispStringAt(TempBuf,120,88);
				  break;

			  default :
				  break;
			}

			Status_Bar();
			BottomBar();
			Lcmfull();
			keysele=KeySeleflag;
			KeySeleflag =0;
			if(keysele!=0)DelayTime=0;else DelayTime++;
			if(DelayTime>=PageDelayTime)
			{
				OldLevel=0;
				return 0;
			}
			switch(keysele)
			{
			case 3: j=(j+1)%2;DelayTime=0;break;//��
			case 4: j=(j+1)%2;DelayTime=0;break;//��
			case 6: OldLevel=0;return 0;break;
			default:break;
			}
		  }
}
//******************************************************************************************************************
//* �������ƣ�Show_Meter_Celiangdian()�����ڵڶ����˵�
//* ��    �ܣ�����ʾ���ܱ��Ĳ��������ݡ�
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
int Show_Meter_Celiangdian(INT8U SeleMenu)
{
	unsigned char keysele,CeLiangDian,j,i;
	unsigned int DelayTime;

	DelayTime=0;
	CeLiangDian=0;
	j=0;
	a_up = a_down =  1;
	a_right = a_left = 1;
	//GUI_Clear();
	while(1)
	{
		Lcmpower();
		GUI_Clear();
		GUI_DispStringAt((INT8U *)"������:",0,16);
		GUI_DispDecAt(CeLiangDian+1 ,56,16,2);
		GUI_DispStringAt((INT8U *)"����:",0,128);

		for(i=0;i<DD_Device_Max;i++)
		{
			if(RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].CeLiangNo==(CeLiangDian+1))
			{
				memset(NowInput.buf,0,128);
				sprintf((char *)NowInput.buf,"%02x%02x%02x%02x%02x%02x",   //16���Ƶ�BCD��
					RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Addr[5],
					RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Addr[4],
					RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Addr[3],
					RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Addr[2],
					RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Addr[1],
					RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Addr[0]);
				GUI_DispStringAt(NowInput.buf,40,128);//Ӧ����ʾ����ַ����
			}
		}
		switch(j)
		{
		case 0:
			//GUI_Clear();
			GUI_DispStringAt((INT8U *)"�����й�",80,16);
			GUI_DispStringAt((INT8U *)"��:  ",8,40);GUI_DispDecShiftAt(40,40,9,2,RtuDataAddr->DD_Device_BiaoShi_Value[CeLiangDian].Z_P_All);
			GUI_DispStringAt((INT8U *)"��:  ",8,56);GUI_DispDecShiftAt(40,56,9,2,RtuDataAddr->DD_Device_BiaoShi_Value[CeLiangDian].Z_P_F[0]);
			GUI_DispStringAt((INT8U *)"��:  ",8,72);GUI_DispDecShiftAt(40,72,9,2,RtuDataAddr->DD_Device_BiaoShi_Value[CeLiangDian].Z_P_F[1]);
			GUI_DispStringAt((INT8U *)"ƽ:  ",8,88);GUI_DispDecShiftAt(40,88,9,2,RtuDataAddr->DD_Device_BiaoShi_Value[CeLiangDian].Z_P_F[2]);
			GUI_DispStringAt((INT8U *)"��:  ",8,104);GUI_DispDecShiftAt(40,104,9,2,RtuDataAddr->DD_Device_BiaoShi_Value[CeLiangDian].Z_P_F[3]);

			GUI_DispStringAt((INT8U *)"kwh",120,40);
			GUI_DispStringAt((INT8U *)"kwh",120,56);
			GUI_DispStringAt((INT8U *)"kwh",120,72);
			GUI_DispStringAt((INT8U *)"kwh",120,88);
			GUI_DispStringAt((INT8U *)"kwh",120,104);

			break;

		case 1:
			//GUI_Clear();
			GUI_DispStringAt((INT8U *)"�����޹��� ",0,40);
			GUI_DispDecShiftAt(16,56,9,2,RtuDataAddr->DD_Device_BiaoShi_Value[CeLiangDian].Z_Q_All);
			GUI_DispStringAt((INT8U *)"�����޹��� ",0,80);
			GUI_DispDecShiftAt(16,96,9,2,RtuDataAddr->DD_Device_BiaoShi_Value[CeLiangDian].F_Q_All);
			GUI_DispStringAt((INT8U *)"(Kvarh)",96,56);
			GUI_DispStringAt((INT8U *)"(Kvarh)",96,96);
			break;
		case 2:
			//GUI_Clear();
			GUI_DispStringAt((INT8U *)"����",80,16);
			GUI_DispStringAt((INT8U *)"�������������ʱ��",8,40);
			GUI_DispStringAt((INT8U *)"�����й�(kw)",0,64);
			GUI_DispDecShiftAt(100,64,7,4,RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[CeLiangDian].Z_P_X_All);
			GUI_DispStringAt((INT8U *)"  ��  ��  ʱ  ��",16,80);

			GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_Z_P_X_All[3] ,16,80,2);
			GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_Z_P_X_All[2] ,48,80,2);
			GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_Z_P_X_All[1] ,80,80,2);
			GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_Z_P_X_All[0] ,112,80,2);

			GUI_DispStringAt((INT8U *)"�����й�(kw)",0,96);
			GUI_DispDecShiftAt(100,96,7,4,RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[CeLiangDian].F_P_X_All);
			GUI_DispStringAt((INT8U *)"  ��  ��  ʱ  ��",16,112);
			GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_F_P_X_All[3] ,16,112,2);
			GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_F_P_X_All[2] ,48,112,2);
			GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_F_P_X_All[1] ,80,112,2);
			GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_F_P_X_All[0] ,112,112,2);
			break;
		case 3:
			//GUI_Clear();
			GUI_DispStringAt((INT8U *)"����",80,16);
			GUI_DispStringAt((INT8U *)"�������������ʱ��",8,40);
			GUI_DispStringAt((INT8U *)"�����޹�kvar",0,64);
			GUI_DispDecShiftAt(100,64,7,4,RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[CeLiangDian].Z_Q_X_All);
			GUI_DispStringAt((INT8U *)"  ��  ��  ʱ  ��",16,80);
			GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_Z_Q_X_All[3] ,16,80,2);
			GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_Z_Q_X_All[2] ,48,80,2);
			GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_Z_Q_X_All[1] ,80,80,2);
			GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_Z_Q_X_All[0] ,112,80,2);

			GUI_DispStringAt((INT8U *)"�����޹�kvar",0,96);
			GUI_DispDecShiftAt(100,96,7,4,RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[CeLiangDian].F_Q_X_All);
			GUI_DispStringAt((INT8U *)"  ��  ��  ʱ  ��",16,112);
			GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_F_Q_X_All[3] ,16,112,2);
			GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_F_Q_X_All[2] ,48,112,2);
			GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_F_Q_X_All[1] ,80,112,2);
			GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_F_Q_X_All[0] ,112,112,2);
			break;
		case 4:
			//GUI_Clear();
			if(CeLiangDian==0){
				  if (RtuDataAddr->RES.RES_JXFS == 04)
				  {
					  GUI_DispStringAt((INT8U *)"��ѹ��V��",8,40);
					  GUI_DispStringAt((INT8U *)"������A��",88,40);
					  GUI_DispStringAt((INT8U *)"Ua:",8,64);
					  GUI_DispStringAt((INT8U *)"Ub:",8,80);
					  GUI_DispStringAt((INT8U *)"Uc:",8,96);
					  GUI_DispDecShiftAt(32,64,5,1,RtuDataAddr->DD_Device_BiaoShi_Value[CeLiangDian].VA);
					  GUI_DispDecShiftAt(32,80,5,1,RtuDataAddr->DD_Device_BiaoShi_Value[CeLiangDian].VB);
					  GUI_DispDecShiftAt(32,96,5,1,RtuDataAddr->DD_Device_BiaoShi_Value[CeLiangDian].VC);

					  GUI_DispStringAt((INT8U *)"Ia:",88,64);
					  GUI_DispStringAt((INT8U *)"Ib:",88,80);
					  GUI_DispStringAt((INT8U *)"Ic:",88,96);
					  GUI_DispDecShiftAt(112,64,5,2,RtuDataAddr->DD_Device_BiaoShi_Value[CeLiangDian].IA);
					  GUI_DispDecShiftAt(112,80,5,2,RtuDataAddr->DD_Device_BiaoShi_Value[CeLiangDian].IB);
					  GUI_DispDecShiftAt(112,96,5,2,RtuDataAddr->DD_Device_BiaoShi_Value[CeLiangDian].IC);
				  }
					if (RtuDataAddr->RES.RES_JXFS == 03) //
					{
						GUI_DispStringAt((INT8U *)"��ѹ��V��",8,40);
						GUI_DispStringAt((INT8U *)"������A��",88,40);
						GUI_DispStringAt((INT8U *)"Uab:",8,64);
						GUI_DispStringAt((INT8U *)"Ucb:",8,80);
						GUI_DispDecShiftAt(40,64,5,1,RtuDataAddr->DD_Device_BiaoShi_Value[CeLiangDian].VA);
						GUI_DispDecShiftAt(40,80,5,1,RtuDataAddr->DD_Device_BiaoShi_Value[CeLiangDian].VC);

						GUI_DispStringAt((INT8U *)"Ia:",88,56);
						GUI_DispStringAt((INT8U *)"Ic:",88,72);
						GUI_DispDecShiftAt(112,64,5,2,RtuDataAddr->DD_Device_BiaoShi_Value[CeLiangDian].IA);
						GUI_DispDecShiftAt(112,80,5,2,RtuDataAddr->DD_Device_BiaoShi_Value[CeLiangDian].IC);
					}
			}else{
				  GUI_DispStringAt((INT8U *)"��ѹ��V��",8,40);
				  GUI_DispStringAt((INT8U *)"������A��",88,40);
				  GUI_DispStringAt((INT8U *)"Ua:",8,64);
				  GUI_DispStringAt((INT8U *)"Ub:",8,80);
				  GUI_DispStringAt((INT8U *)"Uc:",8,96);
				  GUI_DispDecShiftAt(32,64,5,1,RtuDataAddr->DD_Device_BiaoShi_Value[CeLiangDian].VA);
				  GUI_DispDecShiftAt(32,80,5,1,RtuDataAddr->DD_Device_BiaoShi_Value[CeLiangDian].VB);
				  GUI_DispDecShiftAt(32,96,5,1,RtuDataAddr->DD_Device_BiaoShi_Value[CeLiangDian].VC);

				  GUI_DispStringAt((INT8U *)"Ia:",88,64);
				  GUI_DispStringAt((INT8U *)"Ib:",88,80);
				  GUI_DispStringAt((INT8U *)"Ic:",88,96);
				  GUI_DispDecShiftAt(112,64,5,2,RtuDataAddr->DD_Device_BiaoShi_Value[CeLiangDian].IA);
				  GUI_DispDecShiftAt(112,80,5,2,RtuDataAddr->DD_Device_BiaoShi_Value[CeLiangDian].IB);
				  GUI_DispDecShiftAt(112,96,5,2,RtuDataAddr->DD_Device_BiaoShi_Value[CeLiangDian].IC);
			}
			break;
	/*	case 5:
			//GUI_Clear();
			GUI_DispStringAt("����",80,16);
			GUI_DispStringAt("�������������ʱ��",8,40);
			GUI_DispStringAt("�����޹�kvar",0,64);
			GUI_DispDecShiftAt(100,64,7,4,RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[CeLiangDian].SY_Z_Q_X_All);
			GUI_DispStringAt("  ��  ��  ʱ  ��",16,80);
			GUI_DispHexAt(RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_SY_Z_Q_X_All[3] ,16,80,2);
			GUI_DispHexAt(RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_SY_Z_Q_X_All[2] ,48,80,2);
			GUI_DispHexAt(RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_SY_Z_Q_X_All[1] ,80,80,2);
			GUI_DispHexAt(RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_SY_Z_Q_X_All[0] ,112,80,2);

			GUI_DispStringAt("�����޹�kvar",0,96);
			GUI_DispDecShiftAt(100,96,7,4,RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[CeLiangDian].SY_F_Q_X_All);
			GUI_DispStringAt("  ��  ��  ʱ  ��",16,112);
			GUI_DispHexAt(RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_SY_F_Q_X_All[3] ,16,112,2);
			GUI_DispHexAt(RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_SY_F_Q_X_All[2] ,48,112,2);
			GUI_DispHexAt(RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_SY_F_Q_X_All[1] ,80,112,2);
			GUI_DispHexAt(RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_SY_F_Q_X_All[0] ,112,112,2);
			break;*/
		default:break;
	}
	Status_Bar();
	BottomBar();
	Lcmfull();

	keysele=KeySeleflag;
	KeySeleflag =0;
	if(keysele!=0)DelayTime=0;else DelayTime++;
	if(DelayTime>=PageDelayTime)
	{
		OldLevel=10;
		MenuSele = 3;
		return 0;
	}
	switch(keysele)
	{
	case 1: if(CeLiangDian==0)CeLiangDian=7;else CeLiangDian=CeLiangDian-1;DelayTime=0;break;//��
	case 2: CeLiangDian=(CeLiangDian+1)%(CeLiangPoint_Max);DelayTime=0;break;//��
	case 3: if(j==0)j=4;else j=j-1;DelayTime=0;break;//��
	case 4: j=(j+1)%5;DelayTime=0;break;//��
	case 6: OldLevel=10;MenuSele = 3;return 0;break;
	default:break;
	}
}
}
//******************************************************************************************************************
//* �������ƣ�Show_Meter_ErZ()�����ڵڶ����˵�
//* ��    �ܣ����鿴�����ġ�����Ҫ�¼�״̬��
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
int Show_Meter_ErZ(INT8U SeleMenu)
{
	unsigned char keysele,TmpEc1,ErcI;
	unsigned char TmpEcBiaozhi,k,j;
	unsigned int DelayTime;
		 DelayTime=0;
		 TmpEcBiaozhi=0;
		 j=0;
		 a_up = a_down =  1;
		 a_right = a_left = 1;
		 while(1)
		 {
			 switch(j)
			 {
			 case 0:
				 GUI_Clear();
				 GUI_DispStringAt((INT8U *)"��Ҫ�¼�",24,20);
				 GUI_SetTextMode(GUI_TM_REV);
				 if(TmpEcBiaozhi<=0)
					 GUI_DispDecAt(-TmpEcBiaozhi+1 ,0,20,3);
				 if(TmpEcBiaozhi>0)
					 GUI_DispDecAt((256-TmpEcBiaozhi+1),0,20,3);
				 GUI_SetTextMode(GUI_TM_NORMAL);

				 k=RtuDataAddr->Fm_Save_Eve.EC1-1+TmpEcBiaozhi;
				 TmpEc1=k;
				 if(k<0) TmpEc1=256+k;
				 if(k>255) TmpEc1=k-256;
				 if(	RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[0]!=0)
				 {
					 GUI_DispStringAt((INT8U *)"�¼�����:",0,38);
					 GUI_DispStringAt((INT8U *)"ERC",80,38);
					 GUI_DispDecAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[0],106,38,2);//��ʾ��ǰ�洢�������¼�����
					 GUI_DispStringAt((INT8U *)"�¼�����:",0,56);
					 GUI_DispDecAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[1],80,56,2);//��ʾ��ǰ�洢�������¼�����
					 GUI_DispStringAt((INT8U *)"�¼�����:",0,74);
					 GUI_DispStringAt((INT8U *)ERCNAME[RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[0]].Ercname,0,92);
					 if(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[0]==14)
					 {
						 GUI_DispStringAt((INT8U *)"�ϵ�:",0,110);
						 GUI_DispStringAt((INT8U *)"-",72,110);
						 GUI_DispStringAt((INT8U *)"-",94,110);
						 GUI_DispStringAt((INT8U *)":",138,110);
						 GUI_DispStringAt((INT8U *)"20",40,110);
						 GUI_DispHexAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[11],56,110,2);//��ʾ��ǰ�洢�������¼�����
						 GUI_DispHexAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[10],80,110,2);//��ʾ��ǰ�洢�������¼�����
						 GUI_DispHexAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[9],102,110,2);//��ʾ��ǰ�洢�������¼�����
						 GUI_DispHexAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[8],124,110,2);//��ʾ��ǰ�洢�������¼�����
						 GUI_DispHexAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[7],144,110,2);//��ʾ��ǰ�洢�������¼�����
						 GUI_DispStringAt((INT8U *)"ͣ��:",0,128);
						 GUI_DispStringAt((INT8U *)"-",72,128);
						 GUI_DispStringAt((INT8U *)"-",94,128);
						 GUI_DispStringAt((INT8U *)":",138,128);
						 GUI_DispStringAt((INT8U *)"20",40,128);
						 GUI_DispHexAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[6],56,128,2);//��ʾ��ǰ�洢�������¼�����
						 GUI_DispHexAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[5],80,128,2);//��ʾ��ǰ�洢�������¼�����
						 GUI_DispHexAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[4],100,128,2);//��ʾ��ǰ�洢�������¼�����
						 GUI_DispHexAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[3],124,128,2);//��ʾ��ǰ�洢�������¼�����
						 GUI_DispHexAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[2],144,128,2);//��ʾ��ǰ�洢�������¼�����

					 }
					 else
					 {
						 GUI_DispStringAt((INT8U *)"����ʱ��:",0,110);
						 GUI_DispStringAt((INT8U *)"-",32,128);
						 GUI_DispStringAt((INT8U *)"-",60,128);
						 GUI_DispStringAt((INT8U *)" ",88,128);
						 GUI_DispStringAt((INT8U *)":",112,128);
						 GUI_DispStringAt((INT8U *)"20",0,128);
						 GUI_DispHexAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[6],16,128,2);//��ʾ��ǰ�洢�������¼�����
						 GUI_DispHexAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[5],42,128,2);//��ʾ��ǰ�洢�������¼�����
						 GUI_DispHexAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[4],68,128,2);//��ʾ��ǰ�洢�������¼�����
						 GUI_DispHexAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[3],94,128,2);//��ʾ��ǰ�洢�������¼�����
						 GUI_DispHexAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[2],120,128,2);//��ʾ��ǰ�洢�������¼�����
					 }
				 }
				 else
					 GUI_DispStringAt((INT8U *)ERCNAME[RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[0]].Ercname,32,80);



				 break;
			 case 1:

				 GUI_Clear();
				 GUI_DispStringAt((INT8U *)"��Ҫ�¼�",24,20);
				 GUI_SetTextMode(GUI_TM_REV);
				 if(TmpEcBiaozhi<=0)
					 GUI_DispDecAt(-TmpEcBiaozhi ,0,20,3);
				 if(TmpEcBiaozhi>0)
					 GUI_DispDecAt((256-TmpEcBiaozhi),0,20,3);
				 GUI_SetTextMode(GUI_TM_NORMAL);

				 k=RtuDataAddr->Fm_Save_Eve.EC1-1+TmpEcBiaozhi;
				 TmpEc1=k;
				 if(k<0) TmpEc1=256+k;
				 if(k>255) TmpEc1=k-256;

				 //GUI_DispDecAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[0],120,20,2);//��ʾ��ǰ�洢�������¼�����
				 // GUI_DispStringAt(ERCNAME[RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[0]].Ercname,0,40);
				 GUI_DispStringAt((INT8U *)"�¼�����:",0,40);
				 for(ErcI=0;ErcI<8;ErcI++)
					 GUI_DispHexAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[ErcI+1],20*ErcI,60,2);
				 for(ErcI=0;ErcI<8;ErcI++)
					 GUI_DispHexAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[ErcI+9],20*ErcI,80,2);
				 for(ErcI=0;ErcI<8;ErcI++)
					 GUI_DispHexAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[ErcI+17],20*ErcI,100,2);
				 for(ErcI=0;ErcI<8;ErcI++)
					 GUI_DispHexAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[ErcI+25],20*ErcI,120,2);
				 break;
			 default :
				 break;
			  }
			  Status_Bar();
			  BottomBar();
			  Lcmfull();
			  keysele=KeySeleflag;
			  KeySeleflag =0;
			  if(keysele!=0)DelayTime=0;else DelayTime++;
			  if(DelayTime>=PageDelayTime)
			  {
				  OldLevel=0;
				  return 0;
			  }
			  switch(keysele)
			  {
			  case 0:DelayTime++;break;
			  case 1: TmpEcBiaozhi= TmpEcBiaozhi-1;if(TmpEcBiaozhi<-255)TmpEcBiaozhi=0;break;
			  case 2: TmpEcBiaozhi= TmpEcBiaozhi+1;if(TmpEcBiaozhi>255)TmpEcBiaozhi=0; ;break;
			  case 3: j=(j+1)%2;DelayTime=0;break;
			  case 4: j=(j+1)%2;DelayTime=0;break;
			  case 6: OldLevel=0;return 0;break;
			  default:break;
			  }
		  }
}
//******************************************************************************************************************
//* �������ƣ�Show_Meter_Er1()�����ڵڶ����˵�
//* ��    �ܣ����鿴�����ġ�����Ҫ�¼�״̬��
//* ��ڲ�������
//*// ���ڲ�������
//*******************************************************************************************************************/
int Show_Meter_Er1(INT8U SeleMenu)
{
	unsigned char keysele,TmpEc1,ErcI;
	signed char TmpEcBiaozhi,k,j;
	unsigned int DelayTime;

	DelayTime=0;
	TmpEcBiaozhi=0;
	j=0;
	a_up = a_down =  1;
	a_right = a_left = 1;
	while(1)
	{
		switch(j)
		{
		case 0:
			GUI_Clear();
			GUI_DispStringAt((INT8U *)"һ���¼�",24,20);

			GUI_SetTextMode(GUI_TM_REV);
			if(TmpEcBiaozhi<=0)
				GUI_DispDecAt(-TmpEcBiaozhi+1 ,0,20,3);
			if(TmpEcBiaozhi>0)
				GUI_DispDecAt((256-TmpEcBiaozhi+1),0,20,3);
			GUI_SetTextMode(GUI_TM_NORMAL);

			k=RtuDataAddr->Fm_Save_Eve.EC2-1+TmpEcBiaozhi;
			TmpEc1=k;
			if(k<0) TmpEc1=256+k;
			if(k>255) TmpEc1=k-256;
			if(	RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[0]!=0)
			{
				GUI_DispStringAt((INT8U *)"�¼�����:",0,38);
				GUI_DispStringAt((INT8U *)"ERC",80,38);
				GUI_DispDecAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[0],106,38,2);//��ʾ��ǰ�洢�������¼�����
				GUI_DispStringAt((INT8U *)"�¼�����:",0,56);
				GUI_DispDecAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[1],80,56,2);//��ʾ��ǰ�洢�������¼�����
				GUI_DispStringAt((INT8U *)"�¼�����:",0,74);
				GUI_DispStringAt((INT8U *)ERCNAME[RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[0]].Ercname,0,92);
				if(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[0]==14)
				{
					GUI_DispStringAt((INT8U *)"�ϵ�:",0,110);
					GUI_DispStringAt((INT8U *)"-",72,110);
					GUI_DispStringAt((INT8U *)"-",94,110);
					//GUI_DispStringAt(" ",108,110);
					GUI_DispStringAt((INT8U *)":",138,110);
					GUI_DispStringAt((INT8U *)"20",40,110);
					GUI_DispHexAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[11],56,110,2);//��ʾ��ǰ�洢�������¼�����
					GUI_DispHexAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[10],80,110,2);//��ʾ��ǰ�洢�������¼�����
					GUI_DispHexAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[9],102,110,2);//��ʾ��ǰ�洢�������¼�����
					GUI_DispHexAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[8],124,110,2);//��ʾ��ǰ�洢�������¼�����
					GUI_DispHexAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[7],144,110,2);//��ʾ��ǰ�洢�������¼�����
					GUI_DispStringAt((INT8U *)"ͣ��:",0,128);
					GUI_DispStringAt((INT8U *)"-",72,128);
					GUI_DispStringAt((INT8U *)"-",94,128);
					//GUI_DispStringAt(" ",88,128);
					GUI_DispStringAt((INT8U *)":",138,128);
					GUI_DispStringAt((INT8U *)"20",40,128);
					GUI_DispHexAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[6],56,128,2);//��ʾ��ǰ�洢�������¼�����
					GUI_DispHexAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[5],80,128,2);//��ʾ��ǰ�洢�������¼�����
					GUI_DispHexAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[4],100,128,2);//��ʾ��ǰ�洢�������¼�����
					GUI_DispHexAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[3],124,128,2);//��ʾ��ǰ�洢�������¼�����
					GUI_DispHexAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[2],144,128,2);//��ʾ��ǰ�洢�������¼�����
				}
				else
				{
					GUI_DispStringAt((INT8U *)"����ʱ��:",0,110);
					GUI_DispStringAt((INT8U *)"-",32,128);
					GUI_DispStringAt((INT8U *)"-",60,128);
					GUI_DispStringAt((INT8U *)" ",88,128);
					GUI_DispStringAt((INT8U *)":",112,128);
					GUI_DispStringAt((INT8U *)"20",0,128);
					GUI_DispHexAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[6],16,128,2);//��ʾ��ǰ�洢�������¼�����
					GUI_DispHexAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[5],42,128,2);//��ʾ��ǰ�洢�������¼�����
					GUI_DispHexAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[4],68,128,2);//��ʾ��ǰ�洢�������¼�����
					GUI_DispHexAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[3],94,128,2);//��ʾ��ǰ�洢�������¼�����
					GUI_DispHexAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[2],120,128,2);//��ʾ��ǰ�洢�������¼�����
				}
			}
			else
				GUI_DispStringAt((INT8U *)ERCNAME[RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[0]].Ercname,32,80);
			break;
		case 1:

			GUI_Clear();
			GUI_DispStringAt((INT8U *)"һ���¼�",24,20);
			GUI_SetTextMode(GUI_TM_REV);
			if(TmpEcBiaozhi<=0)
				GUI_DispDecAt(-TmpEcBiaozhi ,0,20,3);
			if(TmpEcBiaozhi>0)
				GUI_DispDecAt((256-TmpEcBiaozhi),0,20,3);
			GUI_SetTextMode(GUI_TM_NORMAL);

			k=RtuDataAddr->Fm_Save_Eve.EC2-1+TmpEcBiaozhi;
			TmpEc1=k;
			if(k<0) TmpEc1=256+k;
			if(k>255) TmpEc1=k-256;

			GUI_DispStringAt((INT8U *)"�¼�����:",0,40);
			for(ErcI=0;ErcI<8;ErcI++)
				GUI_DispHexAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[ErcI+1],20*ErcI,60,2);
			for(ErcI=0;ErcI<8;ErcI++)
				GUI_DispHexAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[ErcI+9],20*ErcI,80,2);
			for(ErcI=0;ErcI<8;ErcI++)
				GUI_DispHexAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[ErcI+17],20*ErcI,100,2);
			for(ErcI=0;ErcI<8;ErcI++)
				GUI_DispHexAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[ErcI+25],20*ErcI,120,2);
			break;
		default :
			break;
		}
		Status_Bar();
		BottomBar();
		Lcmfull();
		keysele=KeySeleflag;
		KeySeleflag =0;
		if(keysele!=0)DelayTime=0;else DelayTime++;
		if(DelayTime>=PageDelayTime)
	       {
			OldLevel=0;
			return 0;
		}
		switch(keysele)
		{
		case 0:DelayTime++;break;
		case 1: TmpEcBiaozhi= TmpEcBiaozhi-1;if(TmpEcBiaozhi<-255)TmpEcBiaozhi=0;break;
		case 2: TmpEcBiaozhi= TmpEcBiaozhi+1;if(TmpEcBiaozhi>255)TmpEcBiaozhi=0; ;break;
		case 3: j=(j+1)%2;DelayTime=0;break;
		case 4: j=(j+1)%2;DelayTime=0;break;
		case 6: OldLevel=0;return 0;break;
		default:break;
		}
	  }
}
//******************************************************************************************************************
//* �������ƣ�Emptyevent()�����ڵڶ����˵�
//* ��    �ܣ����ʵʱ��Ҫ�¼���һ���¼�
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
int Emptyevent(INT8U SeleMenu)
{
	unsigned int DelayTime;
	unsigned char keysele;

	DelayTime=0;
	memset(&RtuDataAddr->Fm_Save_Eve.FKTmp,0,sizeof(RtuDataAddr->Fm_Save_Eve.FKTmp));
	memset(&RtuDataAddr->M_Event_Save,0,256*sizeof(event_record_Save));
	memset(&RtuDataAddr->S_Event_Save,0,256*sizeof(event_record_Save));
	memset(&RtuDataAddr->ERCBiaoZhi,0,8);
	SaveFile((INT8U *)"/nand/save/Merc1.dat",&RtuDataAddr->M_Event_Save[0].UseFlag,sizeof(RtuDataAddr->M_Event_Save));
	SaveFile((INT8U *)"/nand/save/Serc1.dat",&RtuDataAddr->S_Event_Save[0].UseFlag,sizeof(RtuDataAddr->S_Event_Save));
	RtuDataAddr->Fm_Save_Eve.ZWNo=0;
	RtuDataAddr->Fm_Save_Eve.DayLiuLiang=0;
	RtuDataAddr->Fm_Save_Eve.yueLiuLiang=0;
	while (1)
	{
		GUI_Clear();
		GUI_DispStringAt((INT8U *)"�¼��������",32,60);
		Status_Bar();
		Lcmfull();

		keysele=KeySeleflag;
		KeySeleflag =0;
		if(keysele!=0)DelayTime=0;else DelayTime++;
		if(DelayTime>=PageDelayTime)
		{
			OldLevel=0;
			return 0;
		}
		switch(keysele)
		{
		case 0:DelayTime++;break;
		case 6: OldLevel=0;return 0;break;
		default:break;
		}
	}
}
//******************************************************************************************************************
//* �������ƣ�Show_Meter_Erc()�����ڵڶ����˵�
//* ��    �ܣ����鿴�����ġ����¼���Ҫ�ȡ�
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
int Show_Meter_Erc(INT8U SeleMenu)
{
	unsigned char keysele,i,j;
	unsigned int DelayTime;
	GUI_Clear();
	DelayTime=0;
	GUI_DispStringAt((INT8U *)"��",0,16);
	GUI_DispStringAt((INT8U *)"¼",0,32);
	GUI_DispStringAt((INT8U *)"��",0,48);
	GUI_DispStringAt((INT8U *)"��",0,64);

	GUI_DispStringAt((INT8U *)"��",0,80);
	GUI_DispStringAt((INT8U *)"Ҫ",0,96);
	GUI_DispStringAt((INT8U *)"��",0,112);
	GUI_DispStringAt((INT8U *)"��",0,128);
		  while(1)
		  {
			  for(i=0;i<4;i++)
			  {
				  for(j=0;j<8;j++)
				  {
					  if((RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[i]>>j)&0x1==0x1)
						  GUI_DispDecAt((i*8+j+1),16+18*j,16+16*i,2);

					  if((RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[i]>>j)&0x1==0x1)
						  GUI_DispDecAt((i*8+j+1),16+18*j,80+16*i,2);
				  }
			  }
			  Status_Bar();
			  Lcmfull();

			  keysele=KeySeleflag;
			  KeySeleflag =0;
			  if(keysele!=0)DelayTime=0;else DelayTime++;
			  if(DelayTime>=PageDelayTime)
			  {
				  OldLevel=0;
				  return 0;
			  }
			  if(keysele == 6)//ȡ����
			  {
				  OldLevel=0;
				  return 0;
			  }
		  }
}

//******************************************************************************************************************
//* �������ƣ�Show_ZhongWen()�����ڵڶ����˵�
//* ��    �ܣ����鿴�����ġ�����Ҫ�����¼���
//* ��ڲ�������
//* ���ڲ�������
///*******************************************************************************************************************/
int Show_ZhongWen(INT8U SeleMenu)
{
	unsigned char keysele,TempHan[21],k[10],p,j,q;
	unsigned int DelayTime;

	DelayTime=0;
	j=0;
	q=0;
    //     i = RtuDataAddr->Fm_Save_Eve.ZWNo-1;
    //     if(i>200)i=9;
	for(p=0;p<10;p++)
	{
		if((RtuDataAddr->FkZhongWen[p].Stat&0x10)==0x10)
		{
			k[j]=p;
			j=j+1;
		}
		//k[j]���������Ϣ��������һ����Ϣ��jΪ��ʮ����Ϣ���ж�����һ����Ϣ��
	}
	if(j==0)
		q=j=1;
	else
	{
		q=j;
		if(j>=2)
			a_up=a_down=1;
	}
	while(1)
		  {
		Lcmpower();
		GUI_Clear();
		GUI_SetTextMode(GUI_TM_REV);
		GUI_DispDecAt(j-1,0,16,2);
		GUI_SetTextMode(GUI_TM_NORMAL);

		if(RtuDataAddr->FkZhongWen[k[j-1]].Valid ==1)
		{
			memset(TempHan,0,21);
			memcpy(TempHan,&RtuDataAddr->FkZhongWen[k[j-1]].HZXinXi[0],18);
			GUI_DispStringAt(TempHan,16,16);

			if(RtuDataAddr->FkZhongWen[k[j-1]].len>20)
			{
				memcpy(TempHan,&RtuDataAddr->FkZhongWen[k[j-1]].HZXinXi[18],20);
				GUI_DispStringAt(TempHan,0,32);
			}
			if(RtuDataAddr->FkZhongWen[k[j-1]].len>40)
			{
				memcpy(TempHan,&RtuDataAddr->FkZhongWen[k[j-1]].HZXinXi[38],20);
				GUI_DispStringAt(TempHan,0,48);
			}
			if(RtuDataAddr->FkZhongWen[k[j-1]].len>60)
			{
				memcpy(TempHan,&RtuDataAddr->FkZhongWen[k[j-1]].HZXinXi[58],20);
				GUI_DispStringAt(TempHan,0,64);
			}
			if(RtuDataAddr->FkZhongWen[k[j-1]].len>80)
			{
				memcpy(TempHan,&RtuDataAddr->FkZhongWen[k[j-1]].HZXinXi[78],20);
				GUI_DispStringAt(TempHan,0,80);
			}
			if(RtuDataAddr->FkZhongWen[k[j-1]].len>100)
			{
				memcpy(TempHan,&RtuDataAddr->FkZhongWen[k[j-1]].HZXinXi[98],20);
				GUI_DispStringAt(TempHan,0,96);
			}
			if(RtuDataAddr->FkZhongWen[k[j-1]].len>120)
			{
				memcpy(TempHan,&RtuDataAddr->FkZhongWen[k[j-1]].HZXinXi[118],20);
				GUI_DispStringAt(TempHan,0,112);
			}
			if(RtuDataAddr->FkZhongWen[k[j-1]].len>140)
			{
				memcpy(TempHan,&RtuDataAddr->FkZhongWen[k[j-1]].HZXinXi[138],18);
				GUI_DispStringAt(TempHan,0,128);
			}
		}
		else GUI_DispStringAt((INT8U *)"û��������Ϣ",32,66);

		Status_Bar();
		BottomBar();
		Lcmfull();

		keysele=KeySeleflag;
		KeySeleflag =0;
		if(keysele!=0)DelayTime=0;else DelayTime++;

		if(DelayTime>=PageDelayTime)
		{
			OldLevel=0;
			return 0;
		}
			     switch(keysele)
				 {
				 case 1:j=j-1;if(j>200||j==0)j=q; break;
				 case 2:j=j+1;if(j>q)j=1;break;
				 case 6: OldLevel=0;return 0;break;
				 default:break;
				 }
		  }
}
//******************************************************************************************************************
//* �������ƣ�Show_ZhongWenY()�����ڵڶ����˵�
//* ��    �ܣ����鿴�����ġ���һ�������¼���
///* ��ڲ�������
//* ���ڲ�������
///*******************************************************************************************************************/
int Show_ZhongWenY(INT8U SeleMenu)
{
	unsigned char keysele,TempHan[21],k[10],p,j,q;
	unsigned int DelayTime;

	DelayTime=0;
	j=0;
	q=0;
	for(p=0;p<10;p++)
	{
		if((RtuDataAddr->FkZhongWen[p].Stat&0x20)==0x20)
		{
			k[j]=p;
			j=j+1;

		}
		//k[j]���������Ϣ��������һ����Ϣ��jΪ��ʮ����Ϣ���ж�����һ����Ϣ��
	}
	if(j==0)
		q=j=1;
	else
	{
		q=j;
		if(j>=2)
			a_up=a_down=1;
	}
	while(1)
		  {
		Lcmpower();
		GUI_Clear();
		GUI_SetTextMode(GUI_TM_REV);
		GUI_DispDecAt(j-1,0,16,2);
		GUI_SetTextMode(GUI_TM_NORMAL);

		if(RtuDataAddr->FkZhongWen[k[j-1]].Valid ==1)
		{
			memset(TempHan,0,21);
			memcpy(TempHan,&RtuDataAddr->FkZhongWen[k[j-1]].HZXinXi[0],18);
			GUI_DispStringAt(TempHan,16,16);

			if(RtuDataAddr->FkZhongWen[k[j-1]].len>20)
			{
				memcpy(TempHan,&RtuDataAddr->FkZhongWen[k[j-1]].HZXinXi[18],20);
				GUI_DispStringAt(TempHan,0,32);
			}
			if(RtuDataAddr->FkZhongWen[k[j-1]].len>40)
			{
				memcpy(TempHan,&RtuDataAddr->FkZhongWen[k[j-1]].HZXinXi[38],20);
				GUI_DispStringAt(TempHan,0,48);
			}
			if(RtuDataAddr->FkZhongWen[k[j-1]].len>60)
			{
				memcpy(TempHan,&RtuDataAddr->FkZhongWen[k[j-1]].HZXinXi[58],20);
				GUI_DispStringAt(TempHan,0,64);
			}
			if(RtuDataAddr->FkZhongWen[k[j-1]].len>80)
			{
				memcpy(TempHan,&RtuDataAddr->FkZhongWen[k[j-1]].HZXinXi[78],20);
				GUI_DispStringAt(TempHan,0,80);
			}
			if(RtuDataAddr->FkZhongWen[k[j-1]].len>100)
			{
				memcpy(TempHan,&RtuDataAddr->FkZhongWen[k[j-1]].HZXinXi[98],20);
				GUI_DispStringAt(TempHan,0,96);
			}
			if(RtuDataAddr->FkZhongWen[k[j-1]].len>120)
			{
				memcpy(TempHan,&RtuDataAddr->FkZhongWen[k[j-1]].HZXinXi[118],20);
				GUI_DispStringAt(TempHan,0,112);
			}
			if(RtuDataAddr->FkZhongWen[k[j-1]].len>140)
			{
				memcpy(TempHan,&RtuDataAddr->FkZhongWen[k[j-1]].HZXinXi[138],18);
				GUI_DispStringAt(TempHan,0,128);
			}

		}
		else GUI_DispStringAt((INT8U *)"û��������Ϣ",32,66);

		Status_Bar();
		BottomBar();
		Lcmfull();

		keysele=KeySeleflag;
		KeySeleflag =0;
		if(keysele!=0)DelayTime=0;else DelayTime++;

		if(DelayTime>=PageDelayTime)
		{
			OldLevel=0;
			return 0;
		}
			     switch(keysele)
				 {
				 case 1:j=j-1;if(j>200||j==0)j=q;printf("j1=%d\r\n",j); break;
				 case 2:j=j+1;if(j>q)j=1;break;
				 case 6: OldLevel=0;return 0;break;
				 default:break;
				 }
		  }
}

//******************************************************************************************************************
//* �������ƣ�Show_MaiChongCount()�����ڵڶ����˵�
//*/ ��    �ܣ����鿴�����ġ������������
//* ��ڲ�������
//* ���ڲ�������
///*******************************************************************************************************************/
int Show_MaiChongCount(INT8U SeleMenu)
{
	unsigned char keysele;
	unsigned int DelayTime;
	GUI_Clear();
	DelayTime=0;
	GUI_DispStringAt((INT8U *)"���� 1:",20,34);
	GUI_DispStringAt((INT8U *)"���� 2:",20,54);
	//GUI_DispStringAt("���� 3:",20,74);
	//GUI_DispStringAt("���� 4:",20,94);
	// GUI_DispStringAt("ʵʱ����:",4,98);
	// GUI_DispStringAt("�ۼƵ�����:",4,118);// while�в����и�ֵ
		  while(1)
		  {
			  Lcmpower();
			  GUI_DispDecShiftAt(76,34,8,0,RtuDataAddr->MaiChongVar[0].ImpulseNum);
			  GUI_DispDecShiftAt(76,54,8,0,RtuDataAddr->MaiChongVar[1].ImpulseNum);
			 // GUI_DispDecShiftAt(76,74,8,0,RtuDataAddr->MaiChongVar[2].ImpulseNum);
			 // GUI_DispDecShiftAt(76,94,8,0,RtuDataAddr->MaiChongVar[3].ImpulseNum);

			  Status_Bar();
			  Lcmfull();
			  keysele=KeySeleflag;
			  KeySeleflag =0;
			  if(keysele!=0)DelayTime=0;else DelayTime++;
			  if(DelayTime>=PageDelayTime)
			  {
				  OldLevel=0;
				  return 0;
			  }
			  if(keysele == 6)//ȡ����
			  {
				  OldLevel=0;
				  return 0;
			  }
		  }
}
//******************************************************************************************************************
//* �������ƣ�Show_Banben()�����ڵڶ����˵�
//* ��    �ܣ����鿴�����ġ���������Ӳ���汾��Ϣ��
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
int Show_Banben(INT8U SeleMenu)
{
	unsigned char keysele;
	unsigned int DelayTime;
	GUI_Clear();
	DelayTime=0;
	GUI_DispStringAt((INT8U *)"�������Կ�",40,24);
	GUI_DispStringAt((INT8U *)"�ն��ͺ�:",24,54);
	GUI_DispStringAt((INT8U *)"��ǰ�汾:",24,74);
	GUI_DispStringAt((INT8U *)"�汾����:",24,94);
		  while(1)
		  {

			  Status_Bar();
			  Lcmfull();
			  keysele=KeySeleflag;
			  KeySeleflag =0;
			  if(keysele!=0)DelayTime=0;else DelayTime++;
			  if(DelayTime>=PageDelayTime)
			  {
				  OldLevel=0;
				  return 0;
			  }
			  if(keysele == 6)//ȡ����
			  {
				  OldLevel=0;
				  return 0;
			  }

		  }


}
//******************************************************************************************************************
//* �������ƣ�zhongduanzj()�����ڵ�һ���˵�
//* ��    �ܣ����ն��Լ졿
//* ��ڲ�������
//* ���ڲ�������
///*******************************************************************************************************************/
INT8U FlashCount;
int zhongduanzj(INT8U SeleMenu)
{
    unsigned char keysele;
    unsigned int DelayTime;
    DelayTime=0;
	GUI_Clear();
	GUI_DispStringAt((INT8U *)"ϵͳ��ʹ����:",0,16);GUI_DispDecShiftAt(104,16,3,0,RtuDataAddr->sys);GUI_DispStringAt((INT8U *)"%",128,16);
	GUI_DispStringAt((INT8U *)"������ʹ����:",0,36);GUI_DispDecShiftAt(104,36,3,0,RtuDataAddr->data);GUI_DispStringAt((INT8U *)"%",128,36);
	//GUI_DispStringAt("�ڴ�����: ",16,72);GUI_DispDecShiftAt(88,72,2,0,32);GUI_DispStringAt("MB",104,72);
	GUI_DispStringAt((INT8U *)"�ڴ�ʹ����: ",0,56);GUI_DispDecShiftAt(88,56,3,0,RtuDataAddr->mem);GUI_DispStringAt((INT8U *)"%",112,56);
	GUI_DispStringAt((INT8U *)"CPU����: ",0,76);GUI_DispDecShiftAt(64,76,3,0,RtuDataAddr->cpu);GUI_DispStringAt((INT8U *)"%",88,76);
	GUI_DispStringAt((INT8U *)"PPP_IP:",0,96);GUI_DispStringAt((INT8U *)RtuDataAddr->pppip,0,116);

    while(1)
    {
    	Lcmpower();
    	GUI_DispDecShiftAt(104,16,3,0,RtuDataAddr->sys);
    	GUI_DispDecShiftAt(104,36,3,0,RtuDataAddr->data);
    	//GUI_DispDecShiftAt(88,72,2,0,32);
    	GUI_DispDecShiftAt(88,56,3,0,RtuDataAddr->mem);
    	GUI_DispDecShiftAt(64,76,3,0,RtuDataAddr->cpu);
    	GUI_DispStringAt((INT8U *)RtuDataAddr->pppip,0,116);
     /*   GUI_DispDecShiftAt(98,96,2,0,RtuDataAddr->GprsCSQ);
        if(RtuDataAddr->Gprs_ok==1)
      	  GUI_DispStringAt("OK!",98,112);
        else
      	  GUI_DispStringAt("NO!",98,112);
        if(RtuDataAddr->linked_ok==1)
            GUI_DispStringAt("OK!",98,128);
        else
            GUI_DispStringAt("NO!",98,128);
*/
	     keysele=KeySeleflag;
	     KeySeleflag =0;
	     if(keysele!=0)DelayTime=0;else DelayTime++;
		     if(DelayTime>=PageDelayTime*4)
		       {
		       	OldLevel=0;
		       	return 0;
		       	}
	     if(keysele == 6)//ȡ����
	     {
		    OldLevel = 0;
		    return 0;
	     }
        Status_Bar();
		Lcmfull();

    }

}
//******************************************************************************************************************
//* �������ƣ�GprsTxZt()�����ڵڶ����˵�
//* ��    �ܣ����Լ졿�еġ�GPRSͨѶ״̬�����������������½������ͨ��������
//* ��ڲ�������
//* ���ڲ�������
///*******************************************************************************************************************/
int GprsTxZt(INT8U SeleMenu)
{
	unsigned char keysele;
	unsigned int DelayTime;
	GUI_Clear();
	DelayTime=0;
	GUI_DispStringAt((INT8U *)"���ߴ���:    ��",16,32);
	GUI_DispStringAt((INT8U *)"��½����:    ��",16,52);
	GUI_DispStringAt((INT8U *)"��������:",0,72);
	GUI_DispStringAt((INT8U *)"��������:",0,94);
	while(1)
	{
		keysele=KeySeleflag;
		KeySeleflag =0;
		if(keysele!=0)DelayTime=0;else DelayTime++;
		if(DelayTime>=PageDelayTime)
		{
			OldLevel=0;
			return 0;
		}
		if(keysele == 6)//ȡ����
		{
			OldLevel = 0;
			return 0;
		}
		GUI_DispDecShiftAt(88,32,3,0,OSCPUUsage);
		GUI_DispDecShiftAt(88,52,3,0,FlashCount);
		GUI_DispDecShiftAt(72,72,10,0,RtuDataAddr->Fm_Save_Eve.DayLiuLiang);
		GUI_DispDecShiftAt(72,94,10,0,RtuDataAddr->Fm_Save_Eve.yueLiuLiang);
		Status_Bar();
		Lcmfull();

	}
}
//********************************************************************************************
//* �������ƣ�set485()���ڵڶ����˵�
//* ���ܣ�����485�˿ڣ���ʾ�շ���������
//* ��ڲ�������
//* ���ڲ�������
///*******************************************************************************************/
int set485(INT8U SeleMenu)
{
	INT8U keysele;
	unsigned int DelayTime;
	DelayTime=0;
	GUI_Clear();
	GUI_DispStringAt((INT8U *)"���ͱ���:",0,24);GUI_DispDecShiftAt(80,24,2,0,RtuDataAddr->GprsCSQ);
	GUI_DispStringAt((INT8U *)"���ձ���:",0,68);GUI_DispDecShiftAt(80,68,2,0,RtuDataAddr->GprsCSQ);

	while(1)
	{
	   	   keysele=KeySeleflag;
		   KeySeleflag =0;
		   if(keysele!=0)DelayTime=0;else DelayTime++;
		   if(DelayTime>=PageDelayTime)
		   {
			   OldLevel=0;
			   return 0;
		   }
		   if(keysele == 6)//ȡ����
		   {
			   OldLevel = 0;
			   return 0;
		   }
		   Status_Bar();
		   Lcmfull();
	}

}
//********************************************************************************************
//* �������ƣ�HistoryDay()���ڵڶ����˵�
//* ���ܣ���ʾ��ʷ��ͳ������
//* ��ڲ�������
//* ���ڲ�������
///*******************************************************************************************/
int HistoryDay(INT8U SeleMenu)
{
	unsigned char keysele,CeLiangDian,j;
	unsigned int DelayTime;

	DelayTime=0;
	CeLiangDian=0;
	j=0;
	a_up = a_down =  1;
	a_right = a_left = 1;

	while(1)
	{
		GUI_Clear();
		GUI_DispStringAt((INT8U *)"������:",0,16);
		GUI_DispDecAt(CeLiangDian+1 ,56,16,2);
		switch(j)
		{
		case 0:

			GUI_DispStringAt((INT8U *)"�����й�",80,16);
			GUI_DispStringAt((INT8U *)"��:  ",8,40);GUI_DispDecShiftAt(40,40,9,2,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].Z_P_All);
			GUI_DispStringAt((INT8U *)"��:  ",8,56);GUI_DispDecShiftAt(40,56,9,2,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].Z_P_F[0]);
			GUI_DispStringAt((INT8U *)"��:  ",8,72);GUI_DispDecShiftAt(40,72,9,2,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].Z_P_F[1]);
			GUI_DispStringAt((INT8U *)"ƽ:  ",8,88);GUI_DispDecShiftAt(40,88,9,2,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].Z_P_F[2]);
			GUI_DispStringAt((INT8U *)"��:  ",8,104);GUI_DispDecShiftAt(40,104,9,2,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].Z_P_F[3]);

			GUI_DispStringAt((INT8U *)"(Kw)",120,40);
			GUI_DispStringAt((INT8U *)"(Kw)",120,56);
			GUI_DispStringAt((INT8U *)"(Kw)",120,72);
			GUI_DispStringAt((INT8U *)"(Kw)",120,88);
			GUI_DispStringAt((INT8U *)"(Kw)",120,104);

			break;

		case 1:

			GUI_DispStringAt((INT8U *)"�����й�",80,16);
			GUI_DispStringAt((INT8U *)"��:  ",8,40);GUI_DispDecShiftAt(40,40,9,2,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].F_P_All);
			GUI_DispStringAt((INT8U *)"��:  ",8,56);GUI_DispDecShiftAt(40,56,9,2,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].F_P_F[0]);
			GUI_DispStringAt((INT8U *)"��:  ",8,72);GUI_DispDecShiftAt(40,72,9,2,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].F_P_F[1]);
			GUI_DispStringAt((INT8U *)"ƽ:  ",8,88);GUI_DispDecShiftAt(40,88,9,2,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].F_P_F[2]);
			GUI_DispStringAt((INT8U *)"��:  ",8,104);GUI_DispDecShiftAt(40,104,9,2,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].F_P_F[3]);

			GUI_DispStringAt((INT8U *)"(Kw)",120,40);
			GUI_DispStringAt((INT8U *)"(Kw)",120,56);
			GUI_DispStringAt((INT8U *)"(Kw)",120,72);
			GUI_DispStringAt((INT8U *)"(Kw)",120,88);
			GUI_DispStringAt((INT8U *)"(Kw)",120,104);

			break;

		case 2:

			GUI_DispStringAt((INT8U *)"�������޹����� ",0,40);

			GUI_DispStringAt((INT8U *)"1:",0,56);GUI_DispDecShiftAt(16,56,9,2,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].X1_Q_All);
			GUI_DispStringAt((INT8U *)"2:",0,72);GUI_DispDecShiftAt(16,72,9,2,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].X2_Q_All);
			GUI_DispStringAt((INT8U *)"3:",0,88);GUI_DispDecShiftAt(16,88,9,2,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].X3_Q_All);
			GUI_DispStringAt((INT8U *)"4:",0,104);GUI_DispDecShiftAt(16,104,9,2,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].X4_Q_All);

			GUI_DispStringAt((INT8U *)"(Kvar/h)",96,56);
			GUI_DispStringAt((INT8U *)"(Kvar/h)",96,72);
			GUI_DispStringAt((INT8U *)"(Kvar/h)",96,88);
			GUI_DispStringAt((INT8U *)"(Kvar/h)",96,104);

			break;
		case 3:

			GUI_DispStringAt((INT8U *)"U��IԽ����ʱ��",0,32);
			GUI_DispStringAt((INT8U *)"TUa:",16,48);GUI_DispDecShiftAt(48,48,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].USU_Count);
			GUI_DispStringAt((INT8U *)"TUb:",16,64);GUI_DispDecShiftAt(48,64,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].USV_Count);
			GUI_DispStringAt((INT8U *)"TUc:",16,80);GUI_DispDecShiftAt(48,80,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].USW_Count);

			GUI_DispStringAt((INT8U *)"TIa:",16,96);GUI_DispDecShiftAt(48,96,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].ISU_Count);
			GUI_DispStringAt((INT8U *)"TIb:",16,112);GUI_DispDecShiftAt(48,112,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].ISV_Count);
			GUI_DispStringAt((INT8U *)"TIc:",16,128);GUI_DispDecShiftAt(48,128,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].ISW_Count);
			break;
		case 4:
			GUI_DispStringAt((INT8U *)"UԽ����ʱ��",0,40);
			GUI_DispStringAt((INT8U *)"TUa:",16,64);GUI_DispDecShiftAt(48,64,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].UXU_Count);
			GUI_DispStringAt((INT8U *)"TUb:",16,80);GUI_DispDecShiftAt(48,80,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].UXV_Count);
			GUI_DispStringAt((INT8U *)"TUc:",16,96);GUI_DispDecShiftAt(48,96,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].UXW_Count);

			break;
		case 5:
			GUI_DispStringAt((INT8U *)"U���ֵ��Сֵ",0,32);
			GUI_DispStringAt((INT8U *)"MAXUa:",16,48);GUI_DispDecShiftAt(64,48,5,1,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUUMAX);
			GUI_DispStringAt((INT8U *)"MAXUb:",16,64);GUI_DispDecShiftAt(64,64,5,1,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUVMAX);
			GUI_DispStringAt((INT8U *)"MAXUc:",16,80);GUI_DispDecShiftAt(64,80,5,1,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUWMAX);

			GUI_DispStringAt((INT8U *)"MINUa:",16,96);GUI_DispDecShiftAt(64,96,5,1,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUUMIN);
			GUI_DispStringAt((INT8U *)"MINUb:",16,112);GUI_DispDecShiftAt(64,112,5,1,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUVMIN);
			GUI_DispStringAt((INT8U *)"MINUc:",16,128);GUI_DispDecShiftAt(64,128,5,1,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUWMIN);

			break;

		case 6:
			GUI_DispStringAt((INT8U *)"����U��ֵ����ʱ��",0,32);
			GUI_DispStringAt((INT8U *)"TMAXUa:",16,48);GUI_DispDecShiftAt(72,48,10,0,(int)RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUUMAX_TIME);
			GUI_DispStringAt((INT8U *)"TMAXUb:",16,64);GUI_DispDecShiftAt(72,64,10,0,(int)RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUVMAX_TIME);
			GUI_DispStringAt((INT8U *)"TMAXUc:",16,80);GUI_DispDecShiftAt(72,80,10,0,(int)RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUWMAX_TIME);

			GUI_DispStringAt((INT8U *)"TMINUa:",16,96);GUI_DispDecShiftAt(72,96,10,0,(int)RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUUMIN_TIME);
			GUI_DispStringAt((INT8U *)"TMINUb:",16,112);GUI_DispDecShiftAt(72,112,10,0,(int)RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUVMIN_TIME);
			GUI_DispStringAt((INT8U *)"TMINUc:",16,128);GUI_DispDecShiftAt(72,128,10,0,(int)RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUWMIN_TIME);

			break;
		case 7:
			GUI_DispStringAt((INT8U *)"I���ֵ����ʱ��",0,40);
			GUI_DispStringAt((INT8U *)"TMAXIa:",16,64);GUI_DispDecShiftAt(72,64,10,0,(int)RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DIUMAX_TIME);
			GUI_DispStringAt((INT8U *)"TMAXIb:",16,80);GUI_DispDecShiftAt(72,80,10,0,(int)RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DIVMAX_TIME);
			GUI_DispStringAt((INT8U *)"TMAXIc:",16,96);GUI_DispDecShiftAt(72,96,10,0,(int)RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DIWMAX_TIME);
			break;

		case 8:
			GUI_DispStringAt((INT8U *)"�й�����",16,40);
			//GUI_DispStringAt("�й�����",80,16);
			GUI_DispStringAt((INT8U *)"P:",16,56);GUI_DispDecShiftAt(48,56,7,1,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].P);
			GUI_DispStringAt((INT8U *)"Pa:",16,72);GUI_DispDecShiftAt(48,72,7,1,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].PA);
			GUI_DispStringAt((INT8U *)"Pb:",16,88);GUI_DispDecShiftAt(48,88,7,1,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].PB);
			GUI_DispStringAt((INT8U *)"Pc:",16,104);GUI_DispDecShiftAt(48,104,7,1,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].PC);

			GUI_DispStringAt((INT8U *)"(Kw)",112,56);
			GUI_DispStringAt((INT8U *)"(Kw)",112,72);
			GUI_DispStringAt((INT8U *)"(Kw)",112,88);
			GUI_DispStringAt((INT8U *)"(Kw)",112,104);
			break;
		case 9:
			GUI_DispStringAt((INT8U *)"�޹�����",16,40);
			//GUI_DispStringAt("�޹�����",80,16);
			GUI_DispStringAt((INT8U *)"Q:",16,56);GUI_DispDecShiftAt(48,56,7,1,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].Q);
			GUI_DispStringAt((INT8U *)"Qa:",16,72);GUI_DispDecShiftAt(48,72,7,1,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].QA);
			GUI_DispStringAt((INT8U *)"Qb:",16,88);GUI_DispDecShiftAt(48,88,7,1,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].QB);
			GUI_DispStringAt((INT8U *)"Qc:",16,104);GUI_DispDecShiftAt(48,104,7,1,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].QC);


			GUI_DispStringAt((INT8U *)"(Kvar)",110,56);
			GUI_DispStringAt((INT8U *)"(Kvar)",110,72);
			GUI_DispStringAt((INT8U *)"(Kvar)",110,88);
			GUI_DispStringAt((INT8U *)"(Kvar)",110,104);
			break;

		case 10:
			GUI_DispStringAt((INT8U *)"��������",16,40);
			//GUI_DispStringAt("��������",80,16);
			GUI_DispStringAt((INT8U *)"Cs : ",16,56);GUI_DispDecShiftAt(64,56,5,3,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].Cos);
			GUI_DispStringAt((INT8U *)"Csa: ",16,72);GUI_DispDecShiftAt(64,72,5,3,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].CosA);
			GUI_DispStringAt((INT8U *)"Csb: ",16,88);GUI_DispDecShiftAt(64,88,5,3,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].CosB);
			GUI_DispStringAt((INT8U *)"Csc: ",16,104);GUI_DispDecShiftAt(64,104,5,3,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].CosC);

			break;

		default:break;
	}

	Status_Bar();
	BottomBar();
	Lcmfull();

	keysele=KeySeleflag;
	KeySeleflag =0;
	if(keysele!=0)DelayTime=0;else DelayTime++;
	if(DelayTime>=PageDelayTime)
	{
		OldLevel=0;
		return 0;
	}
	switch(keysele)
	{
	case 1: if(CeLiangDian==0)CeLiangDian=7;else CeLiangDian=CeLiangDian-1;DelayTime=0;break;//��
	case 2: CeLiangDian=(CeLiangDian+1)%(CeLiangPoint_Max);DelayTime=0;break;//��
	case 3: if(j==0)j=10;else j=j-1;DelayTime=0;break;//��
	case 4: j=(j+1)%11;DelayTime=0;break;//��
	case 6: OldLevel=0;return 0;break;
	default:break;
	}
}

}

//********************************************************************************************
////* �������ƣ�HistoryMonth()���ڵڶ����˵�
//* ���ܣ���ʾ��ʷ��ͳ������
//* ��ڲ�������
//* ���ڲ�������
///*******************************************************************************************/
void HistoryMonth(INT8U SeleMenu)
{/*
 unsigned char keysele,CeLiangDian,j,i;
 unsigned int DelayTime;

   DelayTime=0;
   CeLiangDian=0;
   j=0;
   a_up = a_down =  1;
   a_right = a_left = 1;

	 while(1)
	 {
	    GUI_Clear();
		GUI_DispStringAt("������:",0,16);
		GUI_DispDecAt(CeLiangDian+1 ,56,16,2);
		switch(j)
		{
		case 0:

		  GUI_DispStringAt("�����й�",80,16);
		  GUI_DispStringAt("��:  ",8,40);GUI_DispDecShiftAt(40,40,9,2,RtuDataAddr->Yue_DD_BS_Value[CeLiangDian].Z_P_All);
		  GUI_DispStringAt("��:  ",8,56);GUI_DispDecShiftAt(40,56,9,2,RtuDataAddr->Yue_DD_BS_Value[CeLiangDian].Z_P_F[0]);
		  GUI_DispStringAt("��:  ",8,72);GUI_DispDecShiftAt(40,72,9,2,RtuDataAddr->Yue_DD_BS_Value[CeLiangDian].Z_P_F[1]);
		  GUI_DispStringAt("ƽ:  ",8,88);GUI_DispDecShiftAt(40,88,9,2,RtuDataAddr->Yue_DD_BS_Value[CeLiangDian].Z_P_F[2]);
		  GUI_DispStringAt("��:  ",8,104);GUI_DispDecShiftAt(40,104,9,2,RtuDataAddr->Yue_DD_BS_Value[CeLiangDian].Z_P_F[3]);

			GUI_DispStringAt("(Kw)",120,40);
			GUI_DispStringAt("(Kw)",120,56);
			GUI_DispStringAt("(Kw)",120,72);
			GUI_DispStringAt("(Kw)",120,88);
			GUI_DispStringAt("(Kw)",120,104);

			  break;

				case 1:

				  GUI_DispStringAt("�����й�",80,16);
				  GUI_DispStringAt("��:  ",8,40);GUI_DispDecShiftAt(40,40,9,2,RtuDataAddr->Yue_DD_BS_Value[CeLiangDian].F_P_All);
				  GUI_DispStringAt("��:  ",8,56);GUI_DispDecShiftAt(40,56,9,2,RtuDataAddr->Yue_DD_BS_Value[CeLiangDian].F_P_F[0]);
				  GUI_DispStringAt("��:  ",8,72);GUI_DispDecShiftAt(40,72,9,2,RtuDataAddr->Yue_DD_BS_Value[CeLiangDian].F_P_F[1]);
				  GUI_DispStringAt("ƽ:  ",8,88);GUI_DispDecShiftAt(40,88,9,2,RtuDataAddr->Yue_DD_BS_Value[CeLiangDian].F_P_F[2]);
				  GUI_DispStringAt("��:  ",8,104);GUI_DispDecShiftAt(40,104,9,2,RtuDataAddr->Yue_DD_BS_Value[CeLiangDian].F_P_F[3]);

					GUI_DispStringAt("(Kw)",120,40);
					GUI_DispStringAt("(Kw)",120,56);
					GUI_DispStringAt("(Kw)",120,72);
					GUI_DispStringAt("(Kw)",120,88);
					GUI_DispStringAt("(Kw)",120,104);

					  break;

						case 2:

						  GUI_DispStringAt("�������޹����� ",0,40);

							GUI_DispStringAt("1:",0,56);GUI_DispDecShiftAt(16,56,9,2,RtuDataAddr->Yue_DD_BS_Value[CeLiangDian].X1_Q_All);
							GUI_DispStringAt("2:",0,72);GUI_DispDecShiftAt(16,72,9,2,RtuDataAddr->Yue_DD_BS_Value[CeLiangDian].X2_Q_All);
							GUI_DispStringAt("3:",0,88);GUI_DispDecShiftAt(16,88,9,2,RtuDataAddr->Yue_DD_BS_Value[CeLiangDian].X3_Q_All);
							GUI_DispStringAt("4:",0,104);GUI_DispDecShiftAt(16,104,9,2,RtuDataAddr->Yue_DD_BS_Value[CeLiangDian].X4_Q_All);

							  GUI_DispStringAt("(Kvar/h)",96,56);
							  GUI_DispStringAt("(Kvar/h)",96,72);
							  GUI_DispStringAt("(Kvar/h)",96,88);
							  GUI_DispStringAt("(Kvar/h)",96,104);

								break;
								case 3:

								  GUI_DispStringAt("U��IԽ�����ۼ�ʱ��",0,32);
								  GUI_DispStringAt("TUa:",16,48);GUI_DispDecShiftAt(48,48,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].USU_Count);
								  GUI_DispStringAt("TUb:",16,64);GUI_DispDecShiftAt(48,64,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].USV_Count);
								  GUI_DispStringAt("TUc:",16,80);GUI_DispDecShiftAt(48,80,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].USW_Count);

									GUI_DispStringAt("TIa:",16,96);GUI_DispDecShiftAt(48,96,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].ISU_Count);
									GUI_DispStringAt("TIb:",16,112);GUI_DispDecShiftAt(48,112,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].ISV_Count);
									GUI_DispStringAt("TIc:",16,128);GUI_DispDecShiftAt(48,128,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].ISW_Count);
									break;
									case 4:
									GUI_DispStringAt("UԽ�����ۼ�ʱ��",0,40);
									GUI_DispStringAt("TUa:",16,64);GUI_DispDecShiftAt(48,64,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].UXU_Count);
									GUI_DispStringAt("TUb:",16,80);GUI_DispDecShiftAt(48,80,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].UXV_Count);
									GUI_DispStringAt("TUc:",16,96);GUI_DispDecShiftAt(48,96,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].UXW_Count);

									  break;
									  case 5:
									  GUI_DispStringAt("U���ֵ��Сֵ",0,32);
									  GUI_DispStringAt("MAXUa:",16,48);GUI_DispDecShiftAt(64,48,5,1,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUUMAX);
									  GUI_DispStringAt("MAXUb:",16,64);GUI_DispDecShiftAt(64,64,5,1,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUVMAX);
									  GUI_DispStringAt("MAXUc:",16,80);GUI_DispDecShiftAt(64,80,5,1,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUWMAX);

										GUI_DispStringAt("MINUa:",16,96);GUI_DispDecShiftAt(64,96,5,1,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUUMIN);
										GUI_DispStringAt("MINUb:",16,112);GUI_DispDecShiftAt(64,112,5,1,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUVMIN);
										GUI_DispStringAt("MINUc:",16,128);GUI_DispDecShiftAt(64,128,5,1,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUWMIN);

										  break;

											case 6:
											GUI_DispStringAt("����U��ֵ����ʱ��",0,32);
											GUI_DispStringAt("TMAXUa:",16,48);GUI_DispDecShiftAt(72,48,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUUMAX_TIME);
											GUI_DispStringAt("TMAXUb:",16,64);GUI_DispDecShiftAt(72,64,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUVMAX_TIME);
											GUI_DispStringAt("TMAXUc:",16,80);GUI_DispDecShiftAt(72,80,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUWMAX_TIME);

											  GUI_DispStringAt("TMINUa:",16,96);GUI_DispDecShiftAt(72,96,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUUMIN_TIME);
											  GUI_DispStringAt("TMINUb:",16,112);GUI_DispDecShiftAt(72,112,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUVMIN_TIME);
											  GUI_DispStringAt("TMINUc:",16,128);GUI_DispDecShiftAt(72,128,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUWMIN_TIME);

												break;
												case 7:
												GUI_DispStringAt("I���ֵ����ʱ��",0,40);
												GUI_DispStringAt("TMAXIa:",16,64);GUI_DispDecShiftAt(72,64,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DIUMAX_TIME);
												GUI_DispStringAt("TMAXIb:",16,80);GUI_DispDecShiftAt(72,80,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DIVMAX_TIME);
												GUI_DispStringAt("TMAXIc:",16,96);GUI_DispDecShiftAt(72,96,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DIWMAX_TIME);
												break;

												  case 8:
												  GUI_DispStringAt("�й�����",16,40);
												  //GUI_DispStringAt("�й�����",80,16);
												  GUI_DispStringAt("P:",16,56);GUI_DispDecShiftAt(48,56,7,1,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].P);
												  GUI_DispStringAt("Pa:",16,72);GUI_DispDecShiftAt(48,72,7,1,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].PA);
												  GUI_DispStringAt("Pb:",16,88);GUI_DispDecShiftAt(48,88,7,1,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].PB);
												  GUI_DispStringAt("Pc:",16,104);GUI_DispDecShiftAt(48,104,7,1,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].PC);

													GUI_DispStringAt("(Kw)",112,56);
													GUI_DispStringAt("(Kw)",112,72);
													GUI_DispStringAt("(Kw)",112,88);
													GUI_DispStringAt("(Kw)",112,104);
													break;
													case 9:
													GUI_DispStringAt("�޹�����",16,40);
													//GUI_DispStringAt("�޹�����",80,16);
													GUI_DispStringAt("Q:",16,56);GUI_DispDecShiftAt(48,56,7,1,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].Q);
													GUI_DispStringAt("Qa:",16,72);GUI_DispDecShiftAt(48,72,7,1,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].QA);
													GUI_DispStringAt("Qb:",16,88);GUI_DispDecShiftAt(48,88,7,1,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].QB);
													GUI_DispStringAt("Qc:",16,104);GUI_DispDecShiftAt(48,104,7,1,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].QC);


														GUI_DispStringAt("(Kvar)",110,56);
														GUI_DispStringAt("(Kvar)",110,72);
														GUI_DispStringAt("(Kvar)",110,88);
														GUI_DispStringAt("(Kvar)",110,104);
														break;

														  case 10:
														  GUI_DispStringAt("��������",16,40);
														  //GUI_DispStringAt("��������",80,16);
														  GUI_DispStringAt("Cs : ",16,56);GUI_DispDecShiftAt(64,56,5,3,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].Cos);
														  GUI_DispStringAt("Csa: ",16,72);GUI_DispDecShiftAt(64,72,5,3,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].CosA);
														  GUI_DispStringAt("Csb: ",16,88);GUI_DispDecShiftAt(64,88,5,3,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].CosB);
														  GUI_DispStringAt("Csc: ",16,104);GUI_DispDecShiftAt(64,104,5,3,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].CosC);

															break;

															  default:break;
															  }

																Status_Bar();
																BottomBar();
																Lcmfull();

																  keysele=KeySeleflag;
																  KeySeleflag =0;
																  if(keysele!=0)DelayTime=0;else DelayTime++;
																  if(DelayTime>=PageDelayTime)
																  {
																  OldLevel=0;
																  return 0;
																  }
																  switch(keysele)
																  {
																  case 1: if(CeLiangDian==0)CeLiangDian=7;else CeLiangDian=CeLiangDian-1;DelayTime=0;break;//��
																  case 2: CeLiangDian=(CeLiangDian+1)%(CeLiangPoint_Max);DelayTime=0;break;//��
																  case 3: if(j==0)j=10;else j=j-1;DelayTime=0;break;//��
																  case 4: j=(j+1)%11;DelayTime=0;break;//��
																  case 6: OldLevel=0;return 0;break;
																  default:break;
																  }
}*/
}
//********************************************************************************************
//* �������ƣ�CeLiangXinxi()���ڵڶ����˵�
//* ���ܣ���ʾ���������Ϣ
////* ��ڲ�������
//* ���ڲ�������
///*******************************************************************************************/
void  CeLiangXinxi(INT8U SeleMenu)
{/*
 unsigned char keysele,CeLiangDian,j,i;
 unsigned int DelayTime;
 INT16U UED,IED,US,UX,UD,USS,UXX,ISS,IS,I0S,SSS,SS,UVWXZ,ABCXZ,U0Time,V,I;

   DelayTime=0;
   CeLiangDian=0;
   j=0;
   a_up = a_down =  1;
   a_right = a_left = 1;

	 for(i=0;i++;i<8)
	 {
	 I=RtuDataAddr->Cl_MenXian_Value[i].F25_Set_Para.I_BeiLv[1];
	 I=(I<<8)+RtuDataAddr->Cl_MenXian_Value[i].F25_Set_Para.I_BeiLv[0];
	 V=RtuDataAddr->Cl_MenXian_Value[i].F25_Set_Para.V_BeiLv[1];
	 V=(V<<8)+RtuDataAddr->Cl_MenXian_Value[i].F25_Set_Para.V_BeiLv[0];
	 UED=((RtuDataAddr->Cl_MenXian_Value[i].F25_Set_Para.E_Ding_V[1]>>4)*10)+
	 (RtuDataAddr->Cl_MenXian_Value[i].F25_Set_Para.E_Ding_V[1]&0x0f);
	 UED=(UED*100)+((RtuDataAddr->Cl_MenXian_Value[i].F25_Set_Para.E_Ding_V[0]>>4)*10)+
	 (RtuDataAddr->Cl_MenXian_Value[i].F25_Set_Para.E_Ding_V[0]&0x0f);
	 IED=((RtuDataAddr->Cl_MenXian_Value[i].F25_Set_Para.Max_I>>4)*10)+
	 (RtuDataAddr->Cl_MenXian_Value[i].F25_Set_Para.Max_I&0x0f);
	 IED=IED*10;

	   US=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_S[1]>>4)*10)+
	   (RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_S[1]&0x0f);
	   US=(US*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_S[0]>>4)*10)+
	   (RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_S[0]&0x0f);

		 UX=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_X[1]>>4)*10)+
		 (RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_X[1]&0x0f);
		 UX=(UX*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_X[0]>>4)*10)+
		 (RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_X[0]&0x0f);

		   UD=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_Duan_Men[1]>>4)*10)+
		   (RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_Duan_Men[1]&0x0f);
		   UD=(UD*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_Duan_Men[0]>>4)*10)+
		   (RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_Duan_Men[0]&0x0f);

			 USS=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_SS[1]>>4)*10)+
			 (RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_SS[1]&0x0f);
			 USS=(USS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_SS[0]>>4)*10)+
			 (RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_SS[0]&0x0f);

			   UXX=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_XX[1]>>4)*10)+
			   (RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_XX[1]&0x0f);
			   UXX=(UXX*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_XX[0]>>4)*10)+
			   (RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_XX[0]&0x0f);
			   ISS=(((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_SS[1]>>4)&0x07)*10)+
			   (RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_SS[1]&0x0f);
			   ISS=(ISS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_SS[0]>>4)*10)+
			   (RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_SS[0]&0x0f);

				 IS=(((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_S[1]>>4)&0x07)*10)+
				 (RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_S[1]&0x0f);
				 IS=(IS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_S[0]>>4)*10)+
				 (RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_S[0]&0x0f);
				 I0S=(((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.U0I_S[1]>>4)&0x07)*10)+
				 (RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.U0I_S[1]&0x0f);
				 I0S=(I0S*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.U0I_S[0]>>4)*10)+
				 (RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.U0I_S[0]&0x0f);
				 SSS=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[2]>>4)*10)+
				 (RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[2]&0x0f);
				 SSS=(SSS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[1]>>4)*10)+
				 (RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[1]&0x0f);
				 SSS=(SSS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[0]>>4)*10)+
				 (RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[0]&0x0f);
				 SSS=SSS;
				 SS=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[2]>>4)*10)+
				 (RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[2]&0x0f);
				 SS=(SS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[1]>>4)*10)+
				 (RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[1]&0x0f);
				 SS=(SS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[0]>>4)*10)+
				 (RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[0]&0x0f);
				 SS=SS;
				 UVWXZ=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.U3_Unbalance_Value[1]>>4)*10)+
				 (RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.U3_Unbalance_Value[1]&0x0f);
				 UVWXZ=(UVWXZ*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.U3_Unbalance_Value[0]>>4)*10)+
				 (RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.U3_Unbalance_Value[0]&0x0f);

				   ABCXZ=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I3_Unbalance_Value[1]>>4)*10)+
				   (RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I3_Unbalance_Value[1]&0x0f);
				   ABCXZ=(ABCXZ*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I3_Unbalance_Value[0]>>4)*10)+
				   (RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I3_Unbalance_Value[0]&0x0f);
				   U0Time=RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.LianXu_ShiYa;
				   }
				   while(1)
				   {
				   GUI_Clear();
				   switch(j)
				   {
				   case 0:
				   GUI_DispStringAt("������  ��������",16,16);
				   GUI_DispDecAt(CeLiangDian+1,64,16,2);
				   GUI_DispStringAt("PT:",0,40);GUI_DispDecShiftAt(32,40,5,0,V);
				   GUI_DispStringAt("CT:",0,56);GUI_DispDecShiftAt(32,56,5,0,I);
				   GUI_DispStringAt("���ѹ:",0,72);GUI_DispDecShiftAt(80,72,5,0,UED);
				   GUI_DispStringAt("������:",0,88);GUI_DispDecShiftAt(80,88,3,0,IED);
				   GUI_DispStringAt("��Դ���߷�ʽ:",0,104);
				   if(RtuDataAddr->Cl_MenXian_Value[CeLiangDian].F25_Set_Para.Type=1)
				   GUI_DispStringAt("������",104,104);
				   else
				   if(RtuDataAddr->Cl_MenXian_Value[CeLiangDian].F25_Set_Para.Type=2)
				   GUI_DispStringAt("������",104,104);
				   else
				   if(RtuDataAddr->Cl_MenXian_Value[CeLiangDian].F25_Set_Para.Type=3)
				   GUI_DispStringAt("�����",104,104);
				   else
				   GUI_DispStringAt("����",104,104);
				   GUI_DispStringAt("V",136,72);
				   GUI_DispStringAt("A",136,88);
				   break;

					 case 1:
					 GUI_DispStringAt("������  ��ֵ����",16,16);
					 GUI_DispDecAt(CeLiangDian+1,64,16,2);
					 GUI_DispStringAt("��ѹ�ϸ�����:",0,32);GUI_DispDecShiftAt(104,32,5,0,US);
					 GUI_DispStringAt("��ѹ�ϸ�����:",0,48);GUI_DispDecShiftAt(104,48,5,0,UX);
					 GUI_DispStringAt("��ѹ��������:",0,64);GUI_DispDecShiftAt(104,64,5,0,UD);
					 GUI_DispStringAt("��ѹ����:",0,80);GUI_DispDecShiftAt(80,80,5,0,USS);
					 GUI_DispStringAt("Ƿѹ����:",0,96);GUI_DispDecShiftAt(80,96,5,0,UXX);
					 GUI_DispStringAt("��������:",0,112);GUI_DispDecShiftAt(80,112,3,0,ISS);
					 GUI_DispStringAt("���������:",0,128);GUI_DispDecShiftAt(104,128,3,0,IS);

					   GUI_DispStringAt("V",144,32);
					   GUI_DispStringAt("V",144,48);
					   GUI_DispStringAt("V",144,64);
					   GUI_DispStringAt("V",144,80);
					   GUI_DispStringAt("V",144,96);
					   GUI_DispStringAt("A",144,112);
					   GUI_DispStringAt("A",144,128);
					   break;

						 case 2:

						   GUI_DispStringAt("������  ��ֵ����",16,16);
						   GUI_DispDecAt(CeLiangDian+1,64,16,2);
						   GUI_DispStringAt("�����������:",0,32);GUI_DispDecShiftAt(104,32,3,0,I0S);
						   GUI_DispStringAt("���ڹ���������:",0,48);GUI_DispDecShiftAt(104,64,5,0,SSS);
						   GUI_DispStringAt("���ڹ�������:",0,80);GUI_DispDecShiftAt(104,80,5,0,SS);
						   GUI_DispStringAt("��ѹ��ƽ����:",0,96);GUI_DispDecShiftAt(104,96,3,0,UVWXZ);
						   GUI_DispStringAt("������ƽ����:",0,112);GUI_DispDecShiftAt(104,112,3,0,ABCXZ);
						   GUI_DispStringAt("����ʧѹʱ����:",0,128);GUI_DispDecShiftAt(120,128,3,0,U0Time);

							 GUI_DispStringAt("A",144,32);
							 GUI_DispStringAt("KW",144,64);
							 GUI_DispStringAt("KW",144,80);
							 GUI_DispStringAt("%",144,96);
							 GUI_DispStringAt("%",144,112);
							 GUI_DispStringAt("��",144,128);

							   break;
							   default:break;
							   }
							   Status_Bar();
							   BottomBar();
							   Lcmfull();

								 keysele=KeySeleflag;
								 KeySeleflag =0;
								 if(keysele!=0)DelayTime=0;else DelayTime++;
								 if(DelayTime>=PageDelayTime)
								 {
								 OldLevel=0;
								 return 0;
								 }
								 switch(keysele)
								 {
								 case 1: if(CeLiangDian==0)CeLiangDian=7;else CeLiangDian=CeLiangDian-1;DelayTime=0;break;//��
								 case 2: CeLiangDian=(CeLiangDian+1)%(CeLiangPoint_Max);DelayTime=0;break;//��
								 case 3: if(j==0)j=2;else j=j-1;DelayTime=0;break;//��
								 case 4: j=(j+1)%3;DelayTime=0;break;//��
								 case 6: OldLevel=0;return 0;break;
								 default:break;
								 }
	 }*/
}

//********************************************************************************************
//* �������ƣ�RenWuXinxi()���ڵڶ����˵�
//* ���ܣ���ʾ������Ϣ
//* ��ڲ�������
//* ���ڲ�������
///*******************************************************************************************/
int RenWuXinxi(INT8U SeleMenu)
{
unsigned char keysele,TempBuf[16];
INT8U tasknum=0;
unsigned int DelayTime,j;
INT8U Min,Hour,Day,Month,zqdw,zqvalue,flag,start;

DelayTime=0;
j=0;
flag=0;
start=0;
INT8U i;
GUI_Clear();
//GUI_DispStringAt("�������������ͣ�",16,40);
GUI_DispStringAt((INT8U *)"�������������:",16,60);
//GUI_DispStringAt("00",56,60);
GUI_DispStringAt((INT8U *)"00",56,80);
Status_Bar();
keysele=KeySeleflag;
KeySeleflag =0;
if(keysele!=0)
DelayTime=0;
else
DelayTime++;
if(DelayTime>=PageDelayTime)
{
	  	OldLevel=0;
		return 0;
}

memset(NowInput.buf,0,128);

sprintf((char *)&NowInput.buf,"%02d",tasknum);
i=0;
while(i<2)
{
	NowInput.col[i]=80;
	NowInput.row[i]=56+i*8;
	NowInput.set[i]=1;
	i++;
}
NowInput.AllNum=3;
while(1)
{
	Status_Bar();
	keysele=KeySeleflag;
	KeySeleflag =0;
	if(keysele!=0)
		DelayTime=0;
	else
		DelayTime++;
	if(DelayTime>=PageDelayTime)
	{
		OldLevel=0;
		return 0;
	}

	memset(NowInput.buf,0,128);
	sprintf((char *)&NowInput.buf,"%02d",tasknum);
	i=0;
	while(i<2)
	{
		NowInput.col[i]=80;
		NowInput.row[i]=56+i*8;//84
		NowInput.set[i]=1;
		i++;
	}
	   NowInput.AllNum=3;
       switch(keysele)
       {
	   case 5:
		   {
			   if(flag==0)
			   {
				   if(ScreenInput()==1)
				   {
					   tasknum=GetNum((INT8U *)&NowInput.buf,2,1);
					   SaveFKSet();
				   }
				   flag=1;
			   }
		   }
		   break;
	   case 6:
		   {
			   OldLevel=0;
			   return 0;
		   }
		   break;
	   default : break;

       }
       if(flag==1)
       {
		   switch(j)
		   {
		   case 0:
			   GUI_Clear();
			   if(RtuDataAddr->Task_Value[tasknum].F67_Set_Para.type_1_Task_Enable==0xAA)
			   {
				   GUI_DispStringAt((INT8U *)"������δ����!!",16,80);
				   start=1;
			   }

			   else
				   if(RtuDataAddr->Task_Value[tasknum].F67_Set_Para.type_1_Task_Enable==0x55)
				   {
					   a_left=a_right=1;
					   a_up=a_down=0;
					   Min=(RtuDataAddr->Task_Value[tasknum].F65_Set_Para.Ji_Zhun_Shi_Jian[1]>>4)*10;
					   Min=Min+RtuDataAddr->Task_Value[tasknum].F65_Set_Para.Ji_Zhun_Shi_Jian[1]&0x0f;
					   Hour=(RtuDataAddr->Task_Value[tasknum].F65_Set_Para.Ji_Zhun_Shi_Jian[2]>>4)*10;
					   Hour=Hour+RtuDataAddr->Task_Value[tasknum].F65_Set_Para.Ji_Zhun_Shi_Jian[2]&0x0f;
					   Day=(RtuDataAddr->Task_Value[tasknum].F65_Set_Para.Ji_Zhun_Shi_Jian[3]>>4)*10;
					   Day=Day+RtuDataAddr->Task_Value[tasknum].F65_Set_Para.Ji_Zhun_Shi_Jian[3]&0x0f;
					   Month=((RtuDataAddr->Task_Value[tasknum].F65_Set_Para.Ji_Zhun_Shi_Jian[4]>>4)&1)*10;
					   Month=Month+RtuDataAddr->Task_Value[tasknum].F65_Set_Para.Ji_Zhun_Shi_Jian[4]&0x0f;
					   zqdw=RtuDataAddr->Task_Value[tasknum].F65_Set_Para.FaSong_ZhouQi>>6;
					   zqvalue=RtuDataAddr->Task_Value[tasknum].F65_Set_Para.FaSong_ZhouQi&0x3f;

					   GUI_DispStringAt((INT8U *)"��������:",0,20);

					   if(RtuDataAddr->Task_Value[tasknum].F65_Set_Para.Valid==1)
						   GUI_DispStringAt((INT8U *)"1",80,20);
					   else
						   if(RtuDataAddr->Task_Value[tasknum].F66_Set_Para.Valid==1)
							   GUI_DispStringAt((INT8U *)"2",80,20);
						   GUI_DispStringAt((INT8U *)"���ڵ�λ:",0,40);
						   if(zqdw=0)
							   GUI_DispStringAt((INT8U *)"��",72,40);
						   else
							   if(zqdw=1)
								   GUI_DispStringAt((INT8U *)"ʱ",72,40);
							   else
								   if(zqdw=2)
									   GUI_DispStringAt((INT8U *)"��",72,40);
								   else
									   GUI_DispStringAt((INT8U *)"��",72,40);
								   GUI_DispStringAt((INT8U *)"��׼ʱ��:",0,56);
								   GUI_DispDecShiftAt(16,72,2,0,Min);GUI_DispStringAt((INT8U *)"��",32,72);
								   GUI_DispDecShiftAt(48,72,2,0,Hour);GUI_DispStringAt((INT8U *)"ʱ",64,72);
								   GUI_DispDecShiftAt(80,72,2,0,Day);GUI_DispStringAt((INT8U *)"��",96,72);
								   GUI_DispDecShiftAt(112,72,2,0,Month);GUI_DispStringAt((INT8U *)"��",128,72);

								   GUI_DispStringAt((INT8U *)"��������:",0,88);GUI_DispDecShiftAt(72,88,5,0,zqvalue);
								   GUI_DispStringAt((INT8U *)"���߳�ȡ���ݱ���:",0,104);GUI_DispDecShiftAt(136,104,2,0,RtuDataAddr->Task_Value[tasknum].F65_Set_Para.Qu_Xian_ChouQu_BeiLv);
								   GUI_DispStringAt((INT8U *)"���ݵ�Ԫ��ʶ����:",0,120);GUI_DispDecShiftAt(136,120,2,0,RtuDataAddr->Task_Value[tasknum].F65_Set_Para.ShuJv_DanYuan_Num);
				   }

				   if(RtuDataAddr->Task_Value[tasknum].F68_Set_Para.type_2_Task_Enable==0xAA)
				   {
					   GUI_DispStringAt((INT8U *)"������δ����!!",16,80);
					   start=1;
				   }

				   else
					   if(RtuDataAddr->Task_Value[tasknum].F68_Set_Para.type_2_Task_Enable==0x55)
					   {
						   a_left=a_right=1;
						   a_up=a_down=0;
						   Min=(RtuDataAddr->Task_Value[tasknum].F66_Set_Para.Ji_Zhun_Shi_Jian[1]>>4)*10;
						   Min=Min+RtuDataAddr->Task_Value[tasknum].F66_Set_Para.Ji_Zhun_Shi_Jian[1]&0x0f;
						   Hour=(RtuDataAddr->Task_Value[tasknum].F66_Set_Para.Ji_Zhun_Shi_Jian[2]>>4)*10;
						   Hour=Hour+RtuDataAddr->Task_Value[tasknum].F66_Set_Para.Ji_Zhun_Shi_Jian[2]&0x0f;
						   Day=(RtuDataAddr->Task_Value[tasknum].F66_Set_Para.Ji_Zhun_Shi_Jian[3]>>4)*10;
						   Day=Day+RtuDataAddr->Task_Value[tasknum].F66_Set_Para.Ji_Zhun_Shi_Jian[3]&0x0f;
						   Month=((RtuDataAddr->Task_Value[tasknum].F66_Set_Para.Ji_Zhun_Shi_Jian[4]>>4)&1)*10;
						   Month=Month+RtuDataAddr->Task_Value[tasknum].F66_Set_Para.Ji_Zhun_Shi_Jian[4]&0x0f;
						   zqdw=RtuDataAddr->Task_Value[tasknum].F66_Set_Para.FaSong_ZhouQi>>6;
						   zqvalue=RtuDataAddr->Task_Value[tasknum].F66_Set_Para.FaSong_ZhouQi&0x3f;
						   GUI_DispStringAt((INT8U *)"��������:",0,20);

						   if(RtuDataAddr->Task_Value[tasknum].F65_Set_Para.Valid==1)
							   GUI_DispStringAt((INT8U *)"1",80,20);
						   else
							   if(RtuDataAddr->Task_Value[tasknum].F66_Set_Para.Valid==1)
								   GUI_DispStringAt((INT8U *)"2",80,20);
							   GUI_DispStringAt((INT8U *)"���ڵ�λ:",0,40);
							   if(zqdw=0)
								   GUI_DispStringAt((INT8U *)"��",72,40);
							   else
								   if(zqdw=1)
									   GUI_DispStringAt((INT8U *)"ʱ",72,40);
								   else
									   if(zqdw=2)
										   GUI_DispStringAt((INT8U *)"��",72,40);
									   else
										   GUI_DispStringAt((INT8U *)"��",72,40);
									   GUI_DispStringAt((INT8U *)"��׼ʱ��:",0,56);
									   GUI_DispDecShiftAt(16,72,2,0,Min);GUI_DispStringAt((INT8U *)"��",32,72);
									   GUI_DispDecShiftAt(48,72,2,0,Hour);GUI_DispStringAt((INT8U *)"ʱ",64,72);
									   GUI_DispDecShiftAt(80,72,2,0,Day);GUI_DispStringAt((INT8U *)"��",96,72);
									   GUI_DispDecShiftAt(112,72,2,0,Month);GUI_DispStringAt((INT8U *)"��",128,72);

									   GUI_DispStringAt((INT8U *)"��������:",0,88);GUI_DispDecShiftAt(72,88,5,0,zqvalue);
									   GUI_DispStringAt((INT8U *)"���߳�ȡ���ݱ���:",0,104);GUI_DispDecShiftAt(136,104,2,0,RtuDataAddr->Task_Value[tasknum].F66_Set_Para.Qu_Xian_ChouQu_BeiLv);
									   GUI_DispStringAt((INT8U *)"���ݵ�Ԫ��ʶ����:",0,120);GUI_DispDecShiftAt(136,120,2,0,RtuDataAddr->Task_Value[tasknum].F66_Set_Para.ShuJv_DanYuan_Num);
					   }


					   break;
				   case 1:
					   GUI_Clear();
					   //RtuDataAddr->Task_Value[tasknum].F66_Set_Para.ShuJv_DanYuan_Num=5;
					   if(RtuDataAddr->Task_Value[tasknum].F67_Set_Para.type_1_Task_Enable==0x55)
					   {
						   for(i=0;i<RtuDataAddr->Task_Value[tasknum].F65_Set_Para.ShuJv_DanYuan_Num;i++)
						   {
							   //GUI_DispDecShiftAt(0,(i*16),2,0,RtuDataAddr->Task_Value[tasknum].F65_Set_Para.DanYuan_BiaoShi[i][4]);
							   GUI_DispStringAt((INT8U *)"���ݵ�Ԫ��ʶ",0,((i+1)*16));
							   GUI_DispDecShiftAt(96,((i+1)*16),1,0,i+1);
							   GUI_DispStringAt((INT8U *)":",104,((i+1)*16));
							   memset(TempBuf,0,16);
							   sprintf((char *)TempBuf,"%x%x%x%x",
								   RtuDataAddr->Task_Value[tasknum].F65_Set_Para.DanYuan_BiaoShi[i][0],
								   RtuDataAddr->Task_Value[tasknum].F65_Set_Para.DanYuan_BiaoShi[i][1],
								   RtuDataAddr->Task_Value[tasknum].F65_Set_Para.DanYuan_BiaoShi[i][2],
								   RtuDataAddr->Task_Value[tasknum].F65_Set_Para.DanYuan_BiaoShi[i][3]
								   );  //����ת����Ϊ�ַ���
							   GUI_DispStringAt(TempBuf,120,((i+1)*16));
						   }

					   }
					   if(RtuDataAddr->Task_Value[tasknum].F68_Set_Para.type_2_Task_Enable==0x55)
					   {
						   for(i=0;i<RtuDataAddr->Task_Value[tasknum].F66_Set_Para.ShuJv_DanYuan_Num;i++)
						   {
							   //GUI_DispDecShiftAt(0,(i*16),2,0,RtuDataAddr->Task_Value[tasknum].F65_Set_Para.DanYuan_BiaoShi[i][4]);
							   GUI_DispStringAt((INT8U *)"���ݵ�Ԫ��ʶ",0,((i+1)*16));
							   GUI_DispDecShiftAt(96,((i+1)*16),1,0,i+1);
							   GUI_DispStringAt((INT8U *)":",104,((i+1)*16));
							   memset(TempBuf,0,16);
							   sprintf((char *)TempBuf,"%x%x%x%x",
								   RtuDataAddr->Task_Value[tasknum].F66_Set_Para.DanYuan_BiaoShi[i][0],
								   RtuDataAddr->Task_Value[tasknum].F66_Set_Para.DanYuan_BiaoShi[i][1],
								   RtuDataAddr->Task_Value[tasknum].F66_Set_Para.DanYuan_BiaoShi[i][2],
								   RtuDataAddr->Task_Value[tasknum].F66_Set_Para.DanYuan_BiaoShi[i][3]
								   );  //����ת����Ϊ�ַ���
							   GUI_DispStringAt(TempBuf,120,((i+1)*16));
						   }


					   }
					   break;
				   default:break;
			   }
			   Status_Bar();
			   BottomBar();
			   Lcmfull();
			   /*keysele=KeySeleflag;
			   KeySeleflag =0;
			   if(keysele!=0)DelayTime=0;else DelayTime++;
			   if(DelayTime>=PageDelayTime)
			   {
			   OldLevel=0;
			   return 0;
				}*/
			   switch(keysele)
			   {
			   case 1: DelayTime=0;break;//��
			   case 2: DelayTime=0;break;//��
			   case 3:if(start==0) if(j==0)j=1;else j=j-1;DelayTime=0;break;//��
			   case 4: if(start==0)j=(j+1)%2;DelayTime=0;break;//��
			   case 6: OldLevel=0;return 0;break;
			   default:break;
			   }
     }
	 Lcmfull();
	}
}

//******************************************************************************************************************
//* �������ƣ�ChaoBiaoRiSet()
//* ��    �ܣ��ն˳���������
//* ��ڲ�������
//* ���ڲ�������
///*******************************************************************************************************************/

void ChaoBiaoRiSet(INT8U SeleMenu)
{
/*	unsigned char ErcI=0;
unsigned char ErcJ=0;
unsigned char col,row,m,count=0;
unsigned char keysele,CeLiangDian,j,i;
unsigned int DelayTime;

  DelayTime=0;
  CeLiangDian=0;

	GUI_Clear();
	GUI_DispStringAt("��������:",0,20);//1���ֽ�
	GUI_DispStringAt("����ʱ��:",0,120);//1���ֽ�
	GUI_DispStringAt("ʱ",100,120);//1���ֽ�
	GUI_DispStringAt("��",136,120);//1���ֽ�
	GUI_DispHexAt(RtuDataAddr->FkInput_Value.F7_Set_Para.ZhongDuan_ChaoBiao_Time[1],80,120,2);

	  GUI_DispHexAt(RtuDataAddr->FkInput_Value.F7_Set_Para.ZhongDuan_ChaoBiao_Time[0],118,120,2);

		for(ErcI=0;ErcI<8;ErcI++)
		for(ErcJ=0;ErcJ<4;ErcJ++)
		if(((ErcI+1)+8*ErcJ)<32)
		GUI_DispDecAt(((ErcI+1)+8*ErcJ),20*ErcI,40+20*ErcJ,2);
		while(1)
		{
		for(j=0;j<4;j++)
		{
		for(i=1;i<9;i++)
		{
		m=0;
		if((((RtuDataAddr->FkInput_Value.F7_Set_Para.ZhongDuan_ChaoBiao_Date[j])>>(i-1))&0x01))
		{
		m=(i+j*8);
		col=(m-1)/8;
		row=(m-1)%8;
		GUI_SetTextMode(GUI_TM_REV);
		GUI_DispDecAt(m,20*row,40+20*col,2);
		}
		}
		}

		  keysele=KeySeleflag;
		  KeySeleflag =0;
		  if(keysele!=0)DelayTime=0;else DelayTime++;
		  if(DelayTime>=PageDelayTime)
		  {
		  OldLevel=0;
		  return 0;
		  }

			switch(keysele)
			{

			  case 6:  //ȡ����
			  {
		  			  	    GUI_SetTextMode(GUI_TM_NORMAL);
							OldLevel=0;
							return 0;
							}
							break;
							default : break;
							}
							Lcmfull();

}*/
}
///******************************************************************************************************************
//* �������ƣ�thread1
//* ��    �ܣ��߳�ҳ��
//* ��ڲ�������
//* ���ڲ�������/
///*******************************************************************************************************************/
void *thread1()//��ȡ��ֵ
{
    //printf ("thread1 : I'm LCM\n");
    LcdMainTask();
    pthread_exit(NULL);
}
//******************************************************************************************************************
//* �������ƣ�thread2()
//* ��    �ܣ��̰߳���
//* ��ڲ�������
//* ���ڲ�������
///*******************************************************************************************************************/
void *thread2()
{
    unsigned int KeySta,KeyStabuf,KeyStabuf1;
    unsigned int Beiguang;
    unsigned char Flag_NOkey;
    //printf("thread2 : I'm KEY\n");
    LunXianCount=0;//���Լ�����ʼ��
    Beiguang=0;//�����ʼ��

		while(1)//�¼���
		{
			Lcmpower();
			delay(10);
			CleardeadCount();
			KeyStabuf = in32(port2+0x3c);
			KeyStabuf = ((KeyStabuf&0x3f00000)>> 20);
			//Beiguang++;
			//if(Beiguang>BeiguangNum)//��Լ60���رձ���
			//	SetLcdFun(LED_OFF);
			if(KeyStabuf!=0x3f)
			{
				delay(50);
				KeyStabuf1 = in32(port2+0x3c);
				KeyStabuf1 = ((KeyStabuf1&0x3f00000)>> 20)&0x3f;

				if(KeyStabuf1==KeyStabuf)
				{
					Flag_NOkey=1;
					while(Flag_NOkey)
					{;
					if(((in32(port2+0x3c))&0x3f00000)==0x3f00000)
						Flag_NOkey=0;
					else Flag_NOkey=1;
					}
					delay(10);
					KeySta= KeyStabuf1;
					SetLcdFun(LED_ON,0);//����Ϣ�����������������
					Beiguang=0;
				}
			}
			switch(KeySta)
			{
			case 0x2f: KeySeleflag=1;break;//��
			case 0x1f: KeySeleflag=2;break;//��
			case 0x37: KeySeleflag=3;break;//��
			case 0x3e: KeySeleflag=4;break;//��
			case 0x3d: KeySeleflag=5;break;//ȷ��
			case 0x3b: KeySeleflag=6;break;//ȡ��
			default:break;
			}
			KeySta=0x3f;
		}

	pthread_exit(NULL);
}
//******************************************************************************************************************
//* �������ƣ�thread_create()
//* ��    �ܣ����������߳� һ���߳�Ϊ����,��һ��Ϊ��ʾ
//* ��ڲ�������
//* ���ڲ�������
///*******************************************************************************************************************/
void thread_create(void)
{
	int temp;
	memset(&thread, 0, sizeof(thread));          //comment1
	/*�����߳�*/
	if((temp = pthread_create(&thread[0], NULL, thread1, NULL)) != 0)       //comment2
		printf("Process 1 create fail!\n");

	if((temp = pthread_create(&thread[1], NULL, thread2, NULL)) != 0)  //comment3
		printf("Process 2 create fail!");
}
///******************************************************************************************************************
//* �������ƣ�thread_wait()
//* ��    �ܣ�
//* ��ڲ�������
//* ���ڲ�������
///*******************************************************************************************************************/
void thread_wait(void)
{
	/*�ȴ��߳̽���*/
	if(thread[0] !=0) {                   //comment4
		pthread_join(thread[0],NULL);
		//printf("Process 1 end !\n");
	}
	if(thread[1] !=0) {                //comment5
		pthread_join(thread[1],NULL);
		//printf("Process 2 end !\n");
	}
}

//******************************************************************************************************************
//* �������ƣ�PARSE_CMD()
//* ��    �ܣ�������
//* ��ڲ�������
//* ���ڲ�������
//*******************************************************************************************************************/
INT8U   PARSE_CMD(int argc, char * argv[])
{
	INT8U  proc_name[32] = "";

	//printf("cmdline=%d,%s %s\r\n", argc, argv[0], argv[1]);
	if(argc < 2)return (FALSE);
	PORT_ID = atoi(argv[1]);
	sprintf((char *)proc_name, "%s %d", argv[0], PORT_ID);
	if((attach = name_attach(NULL, (char *)proc_name,0))  == NULL)
	{
		fprintf(stderr, "ERR:'%s' runed,cann't regist: %s\r\n", proc_name, strerror(errno));
		return (FALSE);
	}
	return (TRUE);
}
//******************************************************************************************************************
//* �������ƣ�QuitProcess()
//* ��    �ܣ�
//* ��ڲ�������
//* ���ڲ�������
///*******************************************************************************************************************/
void QuitProcess(int signo)
{
	delay(100);
	RtuDataAddr->stPortPara[PORT_ID].PID=0;
   	name_detach(attach, 0);
   	fprintf(stderr,"LCM quit");
	exit(0);
}
int OpenLcdMem() {//fanzhihong
	int fd;
	fd = shm_open("/dev/shm/lcd_buf", O_RDWR, 0777);
	if (fd == -1) {
		fprintf(stderr, "\nERROR: Open lcdbuf memory failed:%s!\n", strerror(errno));
		return 1;
	}
	LcdBuff = mmap(0, 160*160, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
	if (LcdBuff == MAP_FAILED) {
		fprintf(stderr, "lcdbuf mmap failed: %s\n", strerror(errno));
		return 1;
	}
	close(fd);
	return 0;
}
//******************************************************************************************************************
//* �������ƣ�main()
//* ��    �ܣ�������
//* ��ڲ�������
//* ���ڲ�������
///*******************************************************************************************************************/
int main(int argc, char *argv[])
{
    struct sigaction sa1;
	FILE *fp;
	int templiang;
    unsigned char filename[128];
    int rnum;
	fp = NULL;
	memset(filename,0,128);
    markver();
	if(OpenMem())return EXIT_FAILURE;
	if (OpenLcdMem())return EXIT_FAILURE;

	sa1.sa_handler = QuitProcess;
	sigemptyset(&sa1.sa_mask);
	sa1.sa_flags = 0;
	sigaction(SIGTERM, &sa1,NULL);
	sigaction(SIGSYS, &sa1,NULL);
	sigaction(SIGPWR, &sa1,NULL);
	sigaction(SIGKILL, &sa1,NULL);
	sigaction(SIGQUIT, &sa1,NULL);
	sigaction(SIGILL, &sa1,NULL);
	sigaction(SIGINT, &sa1,NULL);
	sigaction(SIGHUP, &sa1,NULL);
	sigaction(SIGABRT, &sa1,NULL);
	sigaction(SIGBUS, &sa1,NULL);
	if(!PARSE_CMD(argc, argv))
	{
		return EXIT_FAILURE;
	}
    if ((coid = name_open("LCD", 0)) == -1) {
        return EXIT_FAILURE;
    }
    a_up = a_down = a_left = a_right = 0;
	RtuDataAddr->stPortPara[PORT_ID].PID=getpid();
    ReadHzkBuff();

    //��ȡԭʼ����
    	  sprintf((char *)filename,"/user/password.sav");
    	  fp=fopen((char *)filename,"rb+");
    	  rnum=0;
    	  if(fp==NULL)
    	 		fp = fopen((char *)filename,"wb+");

    	  rnum= fread(&PassWord,2,1,fp);
    	  if(rnum<1)
    	  {
    	 		PassWord=OLDPASSWORD;
    	 		fwrite(&PassWord,2,1,fp);
    	  }

    	fclose(fp);

	IOInit();
	templiang=ReadLiangdu();
	SetLcdFun(BEIGUANG,templiang);
	SetLcdFun(UPDATE_SCREEN,0);
	delay(50);
    LcmClear();
    delay(20);
    //���������߳� ʵ�ֻ�����ʾ�밴��
    pthread_mutex_init(&mut,NULL);
    thread_create();
    thread_wait();
    return EXIT_SUCCESS;
}

