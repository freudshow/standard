
#include "lcm.h"
#include "lcdapp.h"
#include "time.h"
#include <string.h>
#include <errno.h>

#include <fkbase/memdef.h>
#include <fkbase/fkbasefun.h>
#include <stdio.h>
#include <stdlib.h>
#include <fkbase/p130set.h>

#include <hw/inout.h>
#include <sched.h>
#include <pthread.h>
#include <inttypes.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/neutrino.h>

pthread_t thread[2];
pthread_mutex_t mut;
int number=0;
unsigned int ScanBuff[LCM_Y][LCM_X];      //������ʾ����,ʹ�ò��ô�Һ����������������
unsigned char Pixel[2]={0xff,0};
uintptr_t BaseLcdIo,CmdAddr,DataAddr;
unsigned char LcdDrawBuff[9600];

uintptr_t BaseKeyIo;
uintptr_t BaseLcmIo;

unsigned char Txmode_flag;
char HzBuf[32];
unsigned char HzDat[267615];//262144
unsigned char a_up,a_down,a_left,a_right;
unsigned  times_thru;
unsigned char GUI_KeyState;
unsigned char OldLevel;
unsigned char incount=0;
INT8U	ShowSd48[48];
const char verstr[]={"VER-STRING-FLG=013.002.217.004"__DATE__" "__TIME__};

INT16U GetNum(INT8U *s,INT8U len,INT8U Flag);
INT8U ScreenInput(void);
void markver()//��Ŀ������б�ʶ�����汾��Ϣ
{
	printf("\n%s\n", verstr);
}

/*******************************************************************************************************************/
INT32S GetDataType02(INT8U *S)
{
	INT32S Temp;
	INT8U T1;
	Temp=S[1]&0x0f;
	Temp=Temp*100;
	Temp=Temp+((S[0]>>4)*10)+(S[0]&0x0f);
	T1=S[1]>>5;
	//printf("\n\r T1=======%d",T1);
	if(T1==0)Temp=Temp*100000000;
	if(T1==1)Temp=Temp*10000000;
	if(T1==2)Temp=Temp*1000000;
	if(T1==3)Temp=Temp*100000;
	if(T1==4)Temp=Temp*10000;
	if(T1==5)Temp=Temp*1000;
	if(T1==6)Temp=Temp*100;
	if(T1==7)Temp=Temp*10;

	T1=S[1]>>4;
	if(T1&1)
	{
		Temp=0-Temp;
	}
	return Temp;
}
long GetdataType03(INT8U *S)
{
	long t;
	t=S[3]&0x0f;
	t=(t*10)+((S[2]>>4)&0x0f);
	t=(t*10)+(S[2]&0x0f);
	t=(t*10)+((S[1]>>4)&0x0f);
	t=(t*10)+(S[1]&0x0f);
	t=(t*10)+((S[0]>>4)&0x0f);
	t=(t*10)+(S[0]&0x0f);
	if(S[3]&0x40)
	{
		t=t*1000;
	}
	if(S[3]&0x10)
	{
		t=0-t;
	}
	return t;
}
int getevent(unsigned char* local, int flag ,int type)
{
	INT8U no,y,m,d,h,min;
	unsigned char i,EC;
    unsigned int count=0;

	if(flag==1)
	{
		EC = RtuDataAddr->Fm_Save_Eve.EC1;
	}
	else
	{
		EC = RtuDataAddr->Fm_Save_Eve.EC2;
	}
	i = EC-1;

	 while(1)
	 {
			//---------------
			y = RtuDataAddr->M_Event_Save[i].Event.Buff[6];
			m = RtuDataAddr->M_Event_Save[i].Event.Buff[5];
			d = RtuDataAddr->M_Event_Save[i].Event.Buff[4];
			h = RtuDataAddr->M_Event_Save[i].Event.Buff[3];
			min=RtuDataAddr->M_Event_Save[i].Event.Buff[2];
			no = RtuDataAddr->M_Event_Save[i].Event.Buff[0];
			printf("\n\r------------ event index %d",i);
			printf("\n\r ---------------event type=%d",no);
			printf("\n\r / 20%x /%x /%x  %x : %x",y,m,d,h,min);
			printf("\n\r");
			//---------------
		 switch(flag)
		 {
			 case 1:
					if(RtuDataAddr->M_Event_Save[i].Event.Buff[0]==type)
					{
						//---------------
						/*y = RtuDataAddr->M_Event_Save[i].Event.Buff[6];
						m = RtuDataAddr->M_Event_Save[i].Event.Buff[5];
						d = RtuDataAddr->M_Event_Save[i].Event.Buff[4];
						h = RtuDataAddr->M_Event_Save[i].Event.Buff[3];
						min=RtuDataAddr->M_Event_Save[i].Event.Buff[2];
						no = RtuDataAddr->M_Event_Save[i].Event.Buff[0];
						printf("\n\r------------ event index %d",i);
						printf("\n\r ---------------event type=%d",no);
						printf("\n\r / 20%x /%x /%x  %x : %x",y,m,d,h,min);
						printf("\n\r");*/
						//---------------
						local[count]=i;
						//printf("\n\r local[%d]=%d",count,i);
						count++;
					}
				 break;
			 default:
					if(RtuDataAddr->S_Event_Save[i].Event.Buff[0]==type)
					{
						//---------------
						y = RtuDataAddr->S_Event_Save[i].Event.Buff[6];
						m = RtuDataAddr->S_Event_Save[i].Event.Buff[5];
						d = RtuDataAddr->S_Event_Save[i].Event.Buff[4];
						h = RtuDataAddr->S_Event_Save[i].Event.Buff[3];
						min=RtuDataAddr->S_Event_Save[i].Event.Buff[2];
						no = RtuDataAddr->S_Event_Save[i].Event.Buff[0];
						printf("\n\r------------ event index %d",i);
						printf("\n\r ---------------event type=%d",no);
						printf("\n\r / 20%x /%x /%x  %x : %x",y,m,d,h,min);
						printf("\n\r");
						//---------------
						local[count]=i;
						printf("\n\r local[%d]=%d",count,i);
						count++;
					}
		 }
		if(i==EC)
			break;
		i--;
	}
	 return count;
}
/******************************************************************************************************************
* �������ƣ�LcdSendData()
* ��    �ܣ���ʾд����
//* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void LcdSendCmd(unsigned char cmd)
{
     out8(CmdAddr,cmd);
}
/******************************************************************************************************************
* �������ƣ�LcdSendData()
* ��    �ܣ� ��ʾд����
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void LcdSendData(unsigned char data)
{
     out8(DataAddr,data);
}

/******************************************************************************************************************
* �������ƣ�GUI_Point()
* ��    �ܣ� ����ӳ���Я�����X��������λ����д�����
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void GUI_Point(unsigned int Px, unsigned char Py, unsigned char attr )
{
  //ScanBuff[159-Px][Py]= Pixel[attr];
	ScanBuff[Py][Px]= Pixel[attr];//˳ʱ��ת90
	//ScanBuff[159-Py][159-Px]= Pixel[attr];//��ʱ��ת90
}

void GUI_lineto(unsigned int x1,unsigned int y1,unsigned int x2,unsigned int y2,unsigned char layer)
{

  signed int d_x,d_y;
  float k;

  d_x=x2-x1;
  d_y=y2-y1;
  k=d_y/d_x;

  if(k==0){
	  //printf("\n\r 111111111");
    for(x1=x1+1;x1<=x2;x1++){
    	GUI_Point(x1,y1,layer);
    }
  }
  if((k<0)&&(k>=-1)){
	  //printf("\n\r 222222222");
      for(x1=x1+1;x1<=x2;x1++){
      y1++;
      GUI_Point(x1,y1,layer);
    }
  }
  if((k>0)&&(k<=1)){
	  //printf("\n\r 333333333");
	    for(x1=x1+1;x1<=x2;x1++){
	      y1--;
	      GUI_Point(x1,y1,layer);
	    }
  }
  if(k>1){
	 // printf("\n\r 44444444");
	    for(y1=y1+1;y1<=y2;y1++){
	    	GUI_Point(x1,y1,layer);
	    }
	         x1++;
	         GUI_Point(x1,y1,layer);  }
  if(k<-1)
  {
	  //printf("\n\r 555555");
	    x1++;
	    for(y1=y1-1;y1>y2;y1--){
	    	GUI_Point(x1,y1,layer);
	    }
  }
}


/******************************************************************************************************************
* �������ƣ�GUI_RLine()
* ��    �ܣ���LCD����ʾ����������ֱ�ߡ�
* ��ڲ���    x0		��ֱ����������е�λ��
*          y0		��ֱ����������е�λ��
*          y1       ��ֱ���յ������е�λ��
* ���ڲ�������
/*******************************************************************************************************************/

void  GUI_DrawVLine(unsigned int x0, unsigned char y0, unsigned char y1)
{
  unsigned char  bak;

  if(y0>y1) {bak = y1;y1 = y0; y0 = bak;}        // ��x0��x1��С�������У��Ա㻭ͼ

  /* �����ʾ�����ˮƽ�� */
  /*==========================*/
  do
   {
     GUI_Point(x0, y0, 1);
     y0++;
   }while(y1>=y0);
  /*==========================*/

}

/******************************************************************************************************************
* �������ƣ�GUI_HLine()
* ��    �ܣ���LCD����ʾ��������ˮƽ�ߡ�
* ��ڲ�����x0		ˮƽ����������е�λ��
*           y0		ˮƽ����������е�λ��
*           x1      ˮƽ���յ������е�λ��
*           color	���ںڰ�ɫ������ɫLCD��Ϊ0ʱ��Ϊ1ʱ��ʾ
* ���ڲ�������
/*******************************************************************************************************************/
void  GUI_DrawHLine(unsigned int x0, unsigned char y0, unsigned int x1)
{
  unsigned int  bak;

  if(x0>x1){bak = x1;x1 = x0;x0 = bak;}          // ��y0��y1��С�������У��Ա㻭ͼ

  /* �����ʾ�������ֱ�� */
  /*==========================*/
 do
   {
     GUI_Point(x0, y0, 1);
     x0++;
   }while(x1>=x0);
  /*==========================*/
}


void  GUI_Line(unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1)
{  int   dx;						// ֱ��x���ֵ����
   int   dy;          			// ֱ��y���ֵ����
   int   dx_sym;					// x����������Ϊ-1ʱ��ֵ����Ϊ1ʱ��ֵ����
   int   dy_sym;					// y����������Ϊ-1ʱ��ֵ����Ϊ1ʱ��ֵ����
   int   dx_x2;					// dx*2ֵ���������ڼӿ������ٶ�
   int   dy_x2;					// dy*2ֵ���������ڼӿ������ٶ�
   int   di;						// ���߱���


 dx = x1-x0;						// ��ȡ����֮��Ĳ�ֵ
 dy = y1-y0;

 /* �ж��������򣬻��Ƿ�Ϊˮƽ�ߡ���ֱ�ߡ��� */
 if(dx>0)							// �ж�x�᷽��
 {  dx_sym = 1;					// dx>0������dx_sym=1
 }
 else
 {  if(dx<0)
    {  dx_sym = -1;				// dx<0������dx_sym=-1
    }
    else
    {  // dx==0������ֱ�ߣ���һ��
    	GUI_DrawHLine(x0, y0, y1);
    	 return;
    }
 }

 if(dy>0)							// �ж�y�᷽��
 {  dy_sym = 1;					// dy>0������dy_sym=1
 }
 else
 {  if(dy<0)
    {  dy_sym = -1;				// dy<0������dy_sym=-1
    }
    else
    {  // dy==0����ˮƽ�ߣ���һ��
    	GUI_DrawVLine(x0, y0, x1);
    	 return;
    }
 }

 /* ��dx��dyȡ����ֵ */
 dx = dx_sym * dx;
 dy = dy_sym * dy;

 /* ����2����dx��dyֵ */
 dx_x2 = dx*2;
 dy_x2 = dy*2;

 /* ʹ��Bresenham�����л�ֱ�� */
 if(dx>=dy)						// ����dx>=dy����ʹ��x��Ϊ��׼
 {  di = dy_x2 - dx;
    while(x0!=x1)
    {  GUI_Point(x0, y0,1);
       x0 += dx_sym;
       if(di<0)
       {  di += dy_x2;			// �������һ���ľ���ֵ
       }
       else
       {  di += dy_x2 - dx_x2;
          y0 += dy_sym;
       }
    }
    GUI_Point(x0, y0,1);		// ��ʾ���һ��
 }
 else								// ����dx<dy����ʹ��y��Ϊ��׼
 {  di = dx_x2 - dy;
    while(y0!=y1)
    {  GUI_Point(x0, y0,1);
       y0 += dy_sym;
       if(di<0)
       {  di += dx_x2;
       }
       else
       {  di += dx_x2 - dy_x2;
          x0 += dx_sym;
       }
    }
    GUI_Point(x0, y0,1);		// ��ʾ���һ��
 }

}

//unsigned char Txmode_flag;
//char HzBuf[32];
//unsigned char HzDat[267615];//262144

void ReadHzkBuff()
{
	     int	t, err;
		 int hdrfp;
		//hdrfp == open("hzk16.bin",O_RDONLY);
		hdrfp = open("/user/16",O_RDONLY);
		//printf("hdrfp = %x \n",hdrfp);
		if(hdrfp == -1)
		{
			//printf("han zi ku error!\n");
			exit(1);
		}
		err = read(hdrfp,HzDat,267615);
		//printf("ReadHz = %d \n",err);
		close(hdrfp);

}
/******************************************************************************************************************
* �������ƣ�GUI_SetTextMode()
* ��    �ܣ����÷�����ʾ
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void GUI_SetTextMode(unsigned char flag)
{
	if(flag)Txmode_flag=1;
	else
	Txmode_flag =0;
}
/******************************************************************************************************************
* �������ƣ�GUI_DispStringAt()
* ��    �ܣ���ʾ�ַ���
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void GUI_DispStringAt( unsigned char *format,unsigned int y, unsigned int x)
{
    unsigned char st[64];
    unsigned int i,m,Len;
    unsigned int j,k,l,pos,yp,xp;

	unsigned long int RecPos;
	unsigned long int b1,b2;

    Len = strlen(format);

    delay(5);

   for(l=0;l<Len;l++)
   {
   	st[l]=format[l];
   }
    i=0;
	yp=y;
    while(i<Len)
    {
		pos=0xffff;
    	if(st[i]<0x80)
    	{
    		for(j=0;j<sizeof(UsedAsc)/17;j++)   //wsl
    		{
    			if(st[i]==UsedAsc[j].AnsiCode)
    			{
					pos=j;
    				break;
    			}
    		}
			if(pos==0xffff)
			{
				i++;
				continue;
			}
			xp=x;
			for(m=0;m<16;m++)
			{
				for(k=0;k<8;k++)
				{
				if(Txmode_flag)
					GUI_Point(yp+k,xp,(((UsedAsc[pos].Buf[m]>>(7-k))&0x01)^0x01));
				else
					GUI_Point(yp+k,xp,(UsedAsc[pos].Buf[m]>>(7-k))&0x01);
				}

				xp=(xp+1)%LCM_Y;
			}

			yp=(yp+8)%LCM_X;
			i++;
		}
		else
		{
 			b1=st[i];
    		b2=st[i+1];
 			b1-=0xa0;//����
			b2-=0xa0;//λ��
			RecPos = (94*(b1-1)+(b2-1))*32L ;//- 0xb040;

			memcpy((void *)&HzBuf[0],(void *)&HzDat[RecPos], 32);
			k=0;

			xp=x;
			for(m=0;m<16;m++)
			{
				for(k=0;k<8;k++)
				{
				if(Txmode_flag)
					GUI_Point(yp+k,xp,(((HzBuf[m*2]>>(7-k))&0x01)^0x01));
				else
					GUI_Point(yp+k,xp,(HzBuf[m*2]>>(7-k))&0x01);
				}
				for(k=0;k<8;k++)
				{
				if(Txmode_flag)
					GUI_Point(yp+k+8,xp,(((HzBuf[m*2+1]>>(7-k))&0x01)^0x01));
				else
					GUI_Point(yp+k+8,xp,(HzBuf[m*2+1]>>(7-k))&0x01);
				}
				xp=(xp+1)%LCM_Y;
			}
			yp=(yp+16)%LCM_X;
			i+=2;
		}
    }
}
/******************************************************************************************************************
* �������ƣ�GUI_DispDecAt()
* ��    �ܣ���ʾ����,������,����ռ1λ
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
//void GUI_DispDecAt(INT32S v,INT8U x,INT8U y,INT8U len)
void GUI_DispDecAt(signed long int v,unsigned char x,unsigned char y,unsigned char len)
{
	unsigned char buf[16];
	memset(buf,0,16);
	switch(len)
	{
		case 1:sprintf(buf,"%01d", v );break;
		case 2:sprintf(buf,"%02d", v );break;
		case 3:sprintf(buf,"%03d", v );break;
		case 4:sprintf(buf,"%04d", v );break;
		case 5:sprintf(buf,"%05d", v );break;
		case 6:sprintf(buf,"%06d", v );break;
		case 7:sprintf(buf,"%07d", v );break;
		case 8:sprintf(buf,"%08d", v );break;
		case 9:sprintf(buf,"%09d", v );break;
		case 10:sprintf(buf,"%10d", v );break;
		case 11:sprintf(buf,"%11d", v );break;
		case 12:sprintf(buf,"%12d", v );break;
		default:break;
	}
	GUI_DispStringAt(buf,x,y);
}
/*******************************************************************************************************************/
//void GUI_DispDecAt(INT32S v,INT8U x,INT8U y,INT8U len)
void GUI_DispHexAt(signed long int v,unsigned char x,unsigned char y,unsigned char len)
{
	 unsigned char buf[16];
	 memset(buf,0,16);
	 switch(len)
	 {
		case 1:sprintf(buf,"%01x", v );break;
		case 2:sprintf(buf,"%02x", v );break;
		case 3:sprintf(buf,"%03x", v );break;
		case 4:sprintf(buf,"%04x", v );break;
		case 5:sprintf(buf,"%05x", v );break;
		case 6:sprintf(buf,"%06x", v );break;
		default:break;
	 }

	 GUI_DispStringAt(buf,x,y);

}
/******************************************************************************************************************
* �������ƣ�GUI_DispDecShiftAt()
* ��    �ܣ���ʾС��,������,����ռ1λ,С����ռ1λ
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void GUI_DispDecShiftAt(unsigned char y, unsigned char x,unsigned char Num1,unsigned char Num2,signed long int Num3)
{
//Ĭ��ascii ��ʹ��8*16����
    unsigned char i,m,Len,st[64],yp,xp;
    unsigned int j,k,l,pos;

    unsigned char format[32];
    float Num4;
    memset(format,0,32);
    switch(Num2)
    {
		 case 0: Num4 = ((float)Num3)/1;break;
		 case 1: Num4 = ((float)Num3)/10;break;
		 case 2: Num4 = ((float)Num3)/100;break;
		 case 3: Num4 = ((float)Num3)/1000;break;
		 case 4: Num4 = ((float)Num3)/10000;break;
		 case 5: Num4 = ((float)Num3)/100000;break;
		 default: GUI_DispStringAt("GUI_DispDecShiftAt���ĸ���������(1-5)",0,0); break;
    }
    sprintf(format,"%0*.*f",Num1,Num2,Num4);
    Len = sizeof(format);
    for(l=0;l<Len;l++)
   {
   	st[l]=format[l];
   }
    i=0;
	yp=y;
    while(i<Len)
    {
		pos=0xffff;
    	if(st[i]<0x80)
    	{
    		for(j=0;j<sizeof(UsedAsc)/17;j++)   //wsl
    		{
    			if(st[i]==UsedAsc[j].AnsiCode)
    			{
					pos=j;
    				break;
    			}
    		}
			if(pos==0xffff)
			{
				i++;
				continue;
			}
			xp=x;
			for(m=0;m<16;m++)
			{
				for(k=0;k<8;k++)
				{
					GUI_Point(yp+k,xp,(UsedAsc[pos].Buf[m]>>(7-k))&0x01);
				}
				xp=(xp+1)%LCM_Y;
			}
			yp=(yp+8)%LCM_X;
			i++;
		}
    }

}
/******************************************************************************************************************
* �������ƣ�GUI_DispCharAt()
* ��    �ܣ�дһ���ַ�
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void GUI_DispCharAt(unsigned char c,unsigned char x,unsigned char y)
{
     unsigned char buf[2];
	 memset(buf,0,2);
	 buf[0]= c;
	 buf[1]='\0';
     GUI_DispStringAt(buf,x,y);

}
/******************************************************************************************************************
* �������ƣ�LcmClear()
* ��    �ܣ� ����ʾ
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void LcmClear( void ) {

    int i,j;
    memset(ScanBuff,0xff,sizeof(ScanBuff));

    LcdSendCmd(0x75);
	LcdSendData(0x00);
	LcdSendData(0x9F);
	LcdSendCmd(0x15);
	LcdSendData(0x00);
	LcdSendData(0x35);
	LcdSendCmd(0x5C);
    for( j = 0; j < 160 ; j++ )
		for( i = 0 ; i < 162 ; i++ )
		{
		     LcdSendData(ScanBuff[i][j]);
		}
}
/******************************************************************************************************************
* �������ƣ�Lcmfull()
* ��    �ܣ�����д����
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void Lcmfull( void )
{
    int i,j;

    LcdSendCmd(0x75);
	LcdSendData(0x00);
	LcdSendData(0x9F);
	LcdSendCmd(0x15);
	LcdSendData(0x00);
	LcdSendData(0x35);
	LcdSendCmd(0x5C);
    for( j = 0; j < 160 ; j++ )
		for( i = 0 ; i < 162 ; i++ )
		{
		     LcdSendData(ScanBuff[i][j]);
		}
}

void FillDataFromBuffer(void)
{
	Lcmfull();
}
void GUI_Clear(void)
{
	memset(ScanBuff,0xff,sizeof(ScanBuff));
}
/******************************************************************************************************************
* �������ƣ�LCDpoweroff()
* ��    �ܣ�Һ����ʼ����
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void LCDpoweroff(void)
{
	LcdSendCmd(0xae);	    //
	LcdSendCmd(0xD12);		// INTERNAL OSCILLATION Off
	LcdSendCmd(0x20);		// POWER CONTROL SET
	LcdSendData(0x08);				// TURN ON BOOSTER first;
	usleep(10000);	//10ms
	LcdSendCmd(0x20);		// POWER CONTROL SET
	LcdSendData(0x00);				// TURN off BOOSTER AND REFERENCE VOLTAGE GENERATION CIRCUIT ;0bh

	// out32(BaseLcmIo + 0x34,AT91C_PIO_PA27);//�ر�bei guang//����
    out32(port3+ 0x34,AT91C_PIO_PC4);  //�¼���
}

/******************************************************************************************************************
* �������ƣ�LCDinit()
* ��    �ܣ�Һ����ʼ����
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void LCDinit(void)
{
	LcdSendCmd(0x30);	    // EXT=0
	LcdSendCmd(0x94);		// SLEEP OUT
	LcdSendCmd(0xD1);		// INTERNAL OSCILLATION ON
	LcdSendCmd(0x20);		// POWER CONTROL SET
	LcdSendData(0x08);				// TURN ON BOOSTER first;
	usleep(10000);	//10ms
	LcdSendCmd(0x20);		// POWER CONTROL SET
	LcdSendData(0x0B);				// TURN ON BOOSTER AND REFERENCE VOLTAGE GENERATION CIRCUIT ;0bh
	LcdSendCmd(0x81);		// (0x81) REFERENCE VOLTAGE SELECT MODE

	LcdSendData(0x36);		//srj	36	//0x0a REFERENCE VOLTAGE PARAMETER ;16
	LcdSendData(0x04);		//srj	04	// 0x05SET REFERENCE VOLTAGE PARAMETER ;04

	LcdSendCmd(0xCA); 	// DISPLAY CONTROL
	LcdSendData(0x00);				// CL DIVIDING RATIO ,F1 AND F2 DRIVE PATTERN
	LcdSendData(0x27);				// DRIVER DUTY 1/160
	LcdSendData(0x00);				// FR INVERSE-SET VALUE 16
	LcdSendCmd(0xA6 );  // DISPLAY NORMAL(0xA6)
	LcdSendCmd(0xBB); 		// (0xBB)C0M0-->COM79,C0M159-->COM81

	LcdSendData(0x02);

	LcdSendCmd(0xBC); // (0xBC)data scan direction


	LcdSendData(0x00);    //srj //inverse mode
	LcdSendData(0x00);    //srj //p3p2p1...

	LcdSendData(0x02);     //3B3P
	LcdSendCmd(0x75); 	//(0x75)line address set
	LcdSendData(0x00);                             //start line
	LcdSendData(0x9f);                              //end line
	LcdSendCmd(0x15);		//(0x15) SET COLUMN ADDRESS


	LcdSendData(0x00);// START COLUMN
	LcdSendData(0x54);// ENDCOLUMN

	LcdSendCmd(0x31); // EXT=1

	//====================================================

	LcdSendCmd(0x32);		// ANALOG CIRCUIT SET
	LcdSendData(0x00);		// OSC FREQUENCEY ADJUSTMENT
	LcdSendData(0x01);		// BOOSTER EFFICIENCY SET
	LcdSendData(0x00);		// BIAS SETTING 1/14
	LcdSendCmd(0x34);		// DITHERER OFF

	LcdSendCmd(0x30); 	// EXT=0
	LcdSendCmd(0xAF);
	//printf("\n\r end lcd init");

}

/******************************************************************************************************************
* �������ƣ�IOInit()
* ��    �ܣ���ʼ��Һ������������Ҫ��IO
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void IOInit(void)
{
    //BaseLcmIo = mmap_device_io(512,0xFFFFF400);//AT91C_BASE_PIOA
    //BaseKeyIo = mmap_device_io(512,0xFFFFF600);//AT91C_BASE_PIOB
    //BaseLcdIo = mmap_device_io(64,0xFFFFF800); //AT91C_BASE_PIOC
	if (!PortOpened) {
		OpenGPIO();  //quxiaogpio
	}  //quxiaogpio
 	CmdAddr   = mmap_device_io(1,0x60000000);
 	DataAddr  = mmap_device_io(1,0x60000002);

    //out32(BaseLcmIo,AT91C_PIO_PA26|AT91C_PIO_PA27);  //����
    //out32(BaseLcmIo+0x10,AT91C_PIO_PA26|AT91C_PIO_PA27);//����

    out32(port3,AT91C_PIO_PC6|AT91C_PIO_PC4);  //�¼���
    out32(port3+0x10,AT91C_PIO_PC6|AT91C_PIO_PC4);//�¼���


    //out32(BaseLcmIo + 0x34,AT91C_PIO_PA26);//����
    out32(port3 + 0x34,AT91C_PIO_PC6);
    delay(10);
    //out32(BaseLcmIo + 0x30,AT91C_PIO_PA26);//����
    out32(port3 + 0x30,AT91C_PIO_PC6);
    delay(10);

    out32(port2,AT91C_PIO_PB20|AT91C_PIO_PB21|AT91C_PIO_PB22|AT91C_PIO_PB23|AT91C_PIO_PB24|AT91C_PIO_PB25);
    out32(port2+0x20,AT91C_PIO_PB20|AT91C_PIO_PB21|AT91C_PIO_PB22|AT91C_PIO_PB23|AT91C_PIO_PB24|AT91C_PIO_PB25);
}


/******************************************************************************************************************
* �������ƣ�BOARD_ConfigureSMCLcd()
* ��    �ܣ�Configures the EBI for LCD access at ?MHz. Pins must be configured
*         after or before calling this function.
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void BOARD_ConfigureSMCLcd(void)
{

// Configure SMC

    uintptr_t base_smc;
    base_smc  = mmap_device_io(16,0xFFFFEC50);
    out32(base_smc,0x0);
   // out32(base_smc + 4,0x0f0f0f0f);
   // out32(base_smc + 8,0x001f001f);
      out32(base_smc + 4,0x0f0f0f0f);
      out32(base_smc + 8,0x001f001f);
    out32(base_smc + 0xc,AT91C_SMC_READMODE|AT91C_SMC_WRITEMODE|AT91C_SMC_DBW_WIDTH_EIGTH_BITS);
}


/******************************************************************************************************************
* �������ƣ�TSSet()
* ��    �ܣ�ȡʱ��
* ��ڲ�����
* ���ڲ�����
/*******************************************************************************************************************/
void TSSet1(TS *ts1)
{
	struct tm new_year;
	struct timespec rtime;
    new_year.tm_year  = ts1->Year - 1900;
    new_year.tm_mon   = ts1->Month-1;
    new_year.tm_mday  = ts1->Day;
    new_year.tm_hour  = ts1->Hour;
    new_year.tm_min   = ts1->Minute;
    new_year.tm_sec   = ts1->Sec;


    new_year.tm_isdst = 0;
    rtime.tv_sec=mktime(&new_year);
    rtime.tv_nsec=0;
    if (clock_settime(CLOCK_REALTIME,&rtime)==-1)
    {
    	printf("\n\r set time erro!!!");
    	printf("\n\r set time erro!!!");
    }
    RtuDataAddr->settime1=1;

}

INT8U SecurityCHK(INT8U flag)
{
	FILE *fp = NULL;
	time_t time_of_day;
	time_t nowtime;
	INT32U tmp;
	INT8U c;
	INT8U rv = 1;
	nowtime= time( NULL );
	if(flag==0)//д�ļ� ��¼�������볬�� ʱ��
	{
		fp=fopen("/nand/save/security.sav","wb+");
		if(fp!=NULL)
		{
			tmp = nowtime;
			c = fwrite(&tmp,4,1,fp);
			fclose(fp);
		}
	}
	else//���ļ� ����ʱ���ж�
	{
		fp=fopen("/nand/save/security.sav","rb");
		if(fp!=NULL)
		{
			fread(&time_of_day,4,1,fp);
			if((nowtime-time_of_day)<(24*60*60))
			{
				GUI_Clear();
				GUI_DispStringAt("��������!",44,64);
				incount = 0;
				rv = 0;
			}
		}
	}
	if (fp!=NULL)
		fclose(fp);
	return  rv;
}

/*******************************************************************************************************************/
/******************************************************************************************************************
* �������ƣ�PassPro()
* ��    �ܣ�ȡʱ��
* ��ڲ�����
* ���ڲ�����
/*******************************************************************************************************************/
INT16U PassPro()
{
	unsigned char i,Tpassword[2];
    unsigned int TmpPass=0;
    int rnum;
    INT16U keysele,DelayTime;
    DelayTime=0;
    if(SecurityCHK(1)==1)
    {
    	memset(Tpassword,0,2);
    	GUI_Clear(); //������

  		if (incount>=3)
  		{
  			 SecurityCHK(0);
  			 return 0;
  		}
		GUI_DispStringAt("��������:",28,64);
		memset(NowInput.buf,0,128);
		sprintf(NowInput.buf,"%02d%02d",   //16���Ƶ�BCD��
		Tpassword[0],Tpassword[1]);  //����ת����Ϊ�ַ���
		i=0;
		while(i<4)
		{
			NowInput.col[i]=64;//y��
			NowInput.row[i]=100+i*8;//x��
			NowInput.set[i]=1;
			i++;
		}
		NowInput.AllNum=5;
		rnum = 0;
		rnum = ScreenInput();
		Tpassword[0]=GetNum(&NowInput.buf[0],2,1);
		Tpassword[1]=GetNum(&NowInput.buf[2],2,1);
		TmpPass=Tpassword[0]*100+Tpassword[1];

		if(rnum == 1)
		{
			   if(TmpPass!=PassWord)
			   {
			    	 incount++;
			    	 return PassPro();
			   }
			   else
			   {
			    	 incount = 0;
			    	 return 1;
			   }
		}
		else
			if((rnum==0)&&(TmpPass == PassWord))
			{
			    incount = 0;
			    return 1;
			}
		    else
			    return 0;//2
    }else
    {
  	  while(1)
  	  {
  			GUI_Clear();
  			GUI_DispStringAt("�������ޣ�",32,60);
  			Status_Bar();
  			Lcmfull();

  			keysele=KeySeleflag;
  			KeySeleflag =0;
  			if(keysele!=0)
  				DelayTime=0;
  			else
  				DelayTime++;
  			if(DelayTime>=PageDelayTime)
  			{
  				OldLevel=0;
  				return 0;
  			}
  			switch(keysele)
  			{
  				case 0:DelayTime++;break;
  				case 6: OldLevel=0;return 0;break;
  				default:break;
  			}
  	  }
    }
    return 0;
}

/******************************************************************************************************************
* �������ƣ�GetNum()
* ��    �ܣ���ֵת��������(����ת��)
* ��ڲ���������1��   ��Ҫ��ת��������
����������     ����2��   ת���Ժ�ĳ���
                              ����3��   ת��������ͣ�Flag=1 ʮ�������ָ�ʽ��Flag=2 ʮ���������ָ�ʽ��Flag=3 ʮ���������ָ�ʽ��a��f
* ���ڲ�����
/*******************************************************************************************************************/

INT16U GetNum(INT8U *s,INT8U len,INT8U Flag)
{
	INT16U t,i;
	t=0;
	for(i=0;i<len;i++)
	{
		if(Flag==1)//���ָ�ʽ
			t=(t*10)+(s[i]-0x30);
		if(Flag==2)//ʮ�����Ƹ�ʽ
			t=(t*16)+(s[i]-0x30);
		if(Flag==3)//ʮ�����Ƹ�ʽ
		{
			if((s[i]>='0')&&(s[i]<='9'))
				t=(t<<4)+(s[i]-0x30);
			if((s[i]>='a')&&(s[i]<='f'))
				t=(t<<4)+(s[i]-87);
			if((s[i]>='A')&&(s[i]<='F'))
				t=(t<<4)+(s[i]-55);
		}
	}
	return t;
}
/******************************************************************************************************************
* �������ƣ�ScreenInput()
* ��    �ܣ�Һ������������õĺ���
* ��ڲ�������
* ���ڲ���������1��   ��Ҫ���õ��������ַ��������ı�
            ����0��   ��Ҫ���õ��������ַ���û�з����ı�
            ����0��   ��ʱ�ް������Զ��˳�
/*******************************************************************************************************************/
INT8U ScreenInput(void)
{
	INT8U ix,NowEdit,bufold[128];
	INT16U keysele,DelayTime;
	NowEdit=0;
	DelayTime=0;
	for(ix=0;ix<32;ix++)
	{
		bufold[ix]=NowInput.buf[ix];
	}
	while(1)
	{
		//��ʾ��Ҫ�޸ĵ����ݣ�ͬʱ������ʾĿǰ���ڸĶ������ݡ�
		for(ix=0;ix<NowInput.AllNum;ix++)
		{
			GUI_DispCharAt(NowInput.buf[ix],NowInput.row[ix], NowInput.col[ix]);
		}
		GUI_SetTextMode(GUI_TM_REV);
		GUI_DispCharAt(NowInput.buf[NowEdit],NowInput.row[NowEdit], NowInput.col[NowEdit]);
		GUI_SetTextMode(GUI_TM_NORMAL);
		DelayTime++;
	    Status_Bar();

        Lcmfull();

        keysele=KeySeleflag;
        KeySeleflag =0;
		if(keysele!=0)
		{
			DelayTime=0;
		}
		if(DelayTime>=PageDelayTime)  //��ʱ�˳�
		{
			return 0;
		}

	switch(keysele)
	{
		//if(keysele==1) //��
		case 1:
		{
			switch(NowInput.set[NowEdit])
			{
				case 1:
			//if(NowInput.set[NowEdit]==1)
			{
				NowInput.buf[NowEdit]++;
				if(NowInput.buf[NowEdit]>'9')NowInput.buf[NowEdit]='0';
			}
			break;
			case 2:
			//if(NowInput.set[NowEdit]==2)
			{
				{
					if(NowInput.buf[NowEdit]<0x20)
					NowInput.buf[NowEdit]=0x20;

					NowInput.buf[NowEdit]=NowInput.buf[NowEdit]+1;
					if(NowInput.buf[NowEdit]==0x7a)
					NowInput.buf[NowEdit]=0x20;
				}
			}
			break;
			default:break;
			}
		}
		break;
		//if(keysele==2) //��
		case 2:
		{
			switch(NowInput.set[NowEdit])
			{
			case 1:
			//if(NowInput.set[NowEdit]==1)
			{
				if(NowInput.buf[NowEdit]!='0')
				NowInput.buf[NowEdit]--;
				else
				NowInput.buf[NowEdit]='9';
			}
			break;
			case 2:
			//if(NowInput.set[NowEdit]==2)
			{
				{
					//if(NowInput.buf[NowEdit]!=0x20)
					if(NowInput.buf[NowEdit]>0x20)
					NowInput.buf[NowEdit]=NowInput.buf[NowEdit]-1;
					else
					NowInput.buf[NowEdit]=0x7a;  ///z
				}
			}
			break;
			default :break;
			}
		}
		break;
		case 3:
		//if(keysele==3) //��
		{
			if(NowEdit!=0)NowEdit--;
		}
		break;
		case 4:
		//if(keysele==4) //��
		{
			if(NowEdit!=NowInput.AllNum-2)NowEdit++;
		}
		break;
		case 5:
		//if(keysele==5) //ȷ��
		{
			GUI_DispCharAt(NowInput.buf[NowEdit],NowInput.row[NowEdit], NowInput.col[NowEdit]);
            //OSSemPost(FlushSem);
            Lcmfull();

			for(ix=0;ix<NowInput.AllNum;ix++)
			{
				if(bufold[ix]!=NowInput.buf[ix])return 1;
			}
			return 0;
		}
        break;
        case 6:
		//if(keysele==6) //ȡ��
		{
			return 0;
		}
		break;
		default:break;
	}
	}
}

/******************************************************************************************************************
* �������ƣ�Show_Mainpage()
* ��    �ܣ�����ʾ������ʼ��ҳ�桿
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void Show_Mainpage(void)
{
	INT8U i,j;
	i=j=0;

	while (RtuDataAddr->Dev_Init_OK==0)
	{
		j=j+1;
		GUI_DispStringAt("�ൺ�߿�",52,32);
		GUI_DispStringAt("GK-GPRS200",40,56);
		GUI_DispStringAt("V1.0",68,72);
		GUI_DispStringAt("2009��10��1��",36,96);
		GUI_DispStringAt("���ڳ�ʼ��",40,143);
		GUI_DispStringAt(".",120+i,144);
		i=(i+4)%24;
		Status_Bar();
		KeySeleflag=0;
		Lcmfull();
	}
}
/******************************************************************************************************************
* �������ƣ�Show_Zj_Data()
* ��    �ܣ���ʾ�ܼ�����
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
int Show_Zj_Data(INT8U SeleMenu)
{
		 unsigned char keysele,i,j;
		 unsigned int DelayTime;
		// GUI_Clear();
		 DelayTime=0;
		 j=i=0;
		 a_up = a_down =  1;
		 a_right = a_left = 0;

		 while(1)
		 {
		  	GUI_Clear();
		  	if(i<8)
		  	{
			  	GUI_DispStringAt("�ܼ��� :",54,16);
			    GUI_DispDecAt(i+1, 102, 16, 1);
			    GUI_DispStringAt("�й�:",16,46);GUI_DispDecShiftAt(60,46,8,4,RtuDataAddr->Real_Zj_Value[i].P);GUI_DispStringAt("kw",128,46);
				GUI_DispStringAt("�޹�:",16,66);GUI_DispDecShiftAt(60,66,8,4,RtuDataAddr->Real_Zj_Value[i].Q);GUI_DispStringAt("kvar",128,66);

		  	}
		  	else
		  	{
		  		GUI_DispStringAt("�� ·����:",40,16);
			    GUI_DispDecAt(i-7, 56, 16, 1);
			    j = RtuDataAddr->MaiCongSetPara.MaiChong[i-7].CeLiangNo-1;
			    GUI_DispStringAt("�й�:",16,46);GUI_DispDecShiftAt(60,46,8,4,RtuDataAddr->DD_Device_BiaoShi_Value[j].P);GUI_DispStringAt("kw",128,46);
				GUI_DispStringAt("�޹�:",16,66);GUI_DispDecShiftAt(60,66,8,4,RtuDataAddr->DD_Device_BiaoShi_Value[j].Q);GUI_DispStringAt("kvar",128,66);


		  	}


	        //switch(j)
	        //{
		      //case 0:
		       //GUI_DispStringAt("�й�:",0,46);GUI_DispDecShiftAt(40,32,7,3,RtuDataAddr->Real_Zj_Value[i].P);GUI_DispStringAt("kw",132,46);
			   //GUI_DispStringAt("�޹�:",0,66);GUI_DispDecShiftAt(40,32,7,3,RtuDataAddr->Real_Zj_Value[i].Q);GUI_DispStringAt("kw",132,66);
/*			   GUI_DispStringAt("P��:",2,48);GUI_DispDecShiftAt(40,48,10,0,RtuDataAddr->Real_Zj_Value[i].P_All);GUI_DispStringAt("kw",132,48);
		       GUI_DispStringAt("P��:",2,64);GUI_DispDecShiftAt(40,64,11,2,RtuDataAddr->Real_Zj_Value[i].P_F[0]);GUI_DispStringAt("kw",132,64);
		       GUI_DispStringAt("P��:",2,80);GUI_DispDecShiftAt(40,80,11,2,RtuDataAddr->Real_Zj_Value[i].P_F[1]);GUI_DispStringAt("kw",132,80);
		       GUI_DispStringAt("Pƽ:",2,96);GUI_DispDecShiftAt(40,96,11,2,RtuDataAddr->Real_Zj_Value[i].P_F[2]);GUI_DispStringAt("kw",132,96);
		       GUI_DispStringAt("P��:",2,112);GUI_DispDecShiftAt(40,112,11,2,RtuDataAddr->Real_Zj_Value[i].P_F[3]);GUI_DispStringAt("kw",132,112);

	       memset(NowInput.buf,0,128);
               sprintf(NowInput.buf,"%02d%02d%02d%02d",
					RtuDataAddr->Zj_Control_Value[i].F47_Set_Para.Gou_DIan_Value[3],
					RtuDataAddr->Zj_Control_Value[i].F47_Set_Para.Gou_DIan_Value[2],
					RtuDataAddr->Zj_Control_Value[i].F47_Set_Para.Gou_DIan_Value[1],
					RtuDataAddr->Zj_Control_Value[i].F47_Set_Para.Gou_DIan_Value[0]
				);
		       GUI_DispStringAt("������:",8,128);GUI_DispStringAt(NowInput.buf,64,128);

	           break;

			   case 1:

			   GUI_DispStringAt("Q��:",2,48);GUI_DispDecShiftAt(40,48,10,0,RtuDataAddr->Real_Zj_Value[i].Q_All);GUI_DispStringAt("kw",132,48);
		       GUI_DispStringAt("Q��:",2,64);GUI_DispDecShiftAt(40,64,11,2,RtuDataAddr->Real_Zj_Value[i].Q_F[0]);GUI_DispStringAt("kw",132,64);
		       GUI_DispStringAt("Q��:",2,80);GUI_DispDecShiftAt(40,80,11,2,RtuDataAddr->Real_Zj_Value[i].Q_F[1]);GUI_DispStringAt("kw",132,80);
		       GUI_DispStringAt("Qƽ:",2,96);GUI_DispDecShiftAt(40,96,11,2,RtuDataAddr->Real_Zj_Value[i].Q_F[2]);GUI_DispStringAt("kw",132,96);
		       GUI_DispStringAt("Q��:",2,112);GUI_DispDecShiftAt(40,112,11,2,RtuDataAddr->Real_Zj_Value[i].Q_F[3]);GUI_DispStringAt("kw",132,112);

	           break;

			   default: break;
*/
	        //}
 		    Status_Bar();
 		    BottomBar();
		    Lcmfull();
		    keysele=KeySeleflag;
		    KeySeleflag =0;
		    if(DelayTime>=PageDelayTime)
		    {
		       	OldLevel=0;
		       	return 0;
		     }
		    switch(keysele)
		    {
		     case 0:DelayTime++;break;
		     case 1: if(i==0) i=9; else i=(i-1)%10; DelayTime=0;break;
		     case 2: i=(i+1)%(ZongJia_Max+2) ;DelayTime=0;break;
		     case 3: DelayTime=0;break;
		     case 4: DelayTime=0;break;
		     case 5:  DelayTime=0;break;
		     case 6: OldLevel=0;return 0;break;
		     default:break;
		   }
		 }
}

/******************************************************************************************************************
 * �������ƣ�Show_Golv_QuXian()
 * ���ܣ���ʾ��������
 * ��ڲ�������
 * ���ڲ�������
 *
 ******************************************************************************************************************/
int Show_Golv_QuXian(INT8U SeleMenu)
{
	unsigned char keysele;
	unsigned int DelayTime,i,j,n;
	signed int Golv_Max,x;
	//signed int bili[96];
	/*signed int m[96]=  {100, 102, 104, 106, 108, 110, 112, 114, 116, 118, 120, 130, 140, 150, 160, 170, 180,190,200, 210, 220, 230, 240,
			250, 260, 270, 280, 290, 300, 310, 320, 330, 340, 350, 360, 370, 380, 390, 400, 410, 420, 410, 400, 390, 380, 370, 360, 350,
			340, 330, 320, 310, 300, 290, 280, 270, 260, 250, 240, 230, 220, 210, 200, 190, 180, 170, 160, 150, 140, 130, 120,
			110, 100, 150, 200, 250, 300, 350, 400, 450, 500, 550, 600, 650, 700, 750, 800, 850, 900, 950, 1000,
			1050, 1100, 1150, 1200, 1250};*/
	INT8U str[2];


	DelayTime=0;
	i=0;

	Golv_Max=0;
	//for(n=0;n<8;n++)
		//for(j=0;j<96;j++)
		//{
		//	RtuDataAddr->QX_DD_Device_BiaoShi_Value[n][j].P=m[j];
		//}

	while(1)
	{

		Golv_Max=0;
		for(j=0;j<96;j++)
		{
			if(RtuDataAddr->QX_DD_Device_BiaoShi_Value[i][j].P>Golv_Max)
				Golv_Max=RtuDataAddr->QX_DD_Device_BiaoShi_Value[i][j].P;
		}
			GUI_Clear();
			GUI_DispStringAt("��",0,40);
			GUI_DispStringAt("��",0,60);
			GUI_DispStringAt("��",0,80);
			GUI_DispDecAt(i+1, 0, 100, 2);
			GUI_DispStringAt("P ",0,16);
			GUI_DispStringAt("H=",16,16);
			GUI_DispDecShiftAt(32,16,7,4,Golv_Max);GUI_DispStringAt("kw",96,16);
			GUI_DrawVLine( 30,  35, 135);
			GUI_DrawHLine( 30, 135, 145);
			for(j=0;j<96;j++)
			{
				if(Golv_Max!=0)
					x=(RtuDataAddr->QX_DD_Device_BiaoShi_Value[i][j].P*70)/Golv_Max;
				else
					x=0;
			  GUI_Point((30+j),(135-x),1);
			}


		Status_Bar();
		Lcmfull();
		keysele=KeySeleflag;
		KeySeleflag =0;
		if(DelayTime>=PageDelayTime)
		{
			OldLevel=0;
			return 0;
		 }
			switch(keysele)
			{
			 case 0:DelayTime++;break;
			 case 1: if(i==0) i=7; else i=(i-1)%8; DelayTime=0;break;
			 case 2: i=(i+1)%ZongJia_Max ;DelayTime=0;break;
			 case 3: DelayTime=0;break;
			 case 4: DelayTime=0;break;
			 case 5:  DelayTime=0;break;
			 case 6: OldLevel=0;return 0;break;
			 default:break;
			}

	}

}
/******************************************************************************************************************
* �������ƣ�Show_Zj_DianLiang()
* ��    �ܣ���ʾ�ܼ�����
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
int Show_Zj_DianLiang(INT8U SeleMenu)
{
		unsigned char keysele,i,j;
		unsigned int DelayTime;
		// GUI_Clear();
		DelayTime=0;
		j=i=0;
	   	a_up = a_down =  1;
	   	a_right = a_left = 1;

		while(1)
		{
		  	GUI_Clear();

	        switch(j)
	        {
		       case 0:
		       GUI_DispStringAt("���յ��� ",28,16);
		       GUI_DispStringAt("�ܼ��� :",0,32);
		       GUI_DispDecAt(i+1, 48, 32, 1);

		       //GUI_DispStringAt("�й�:",0,32);GUI_DispDecShiftAt(40,32,7,3,RtuDataAddr->Day_Zj_Value[i].P);
		       GUI_DispStringAt("P��:",2,48);GUI_DispDecShiftAt(40,48,10,0,(RtuDataAddr->Real_Zj_Value[i].P_All-RtuDataAddr->Day_Zj_Value[i].P_All));
		       GUI_DispStringAt("P��:",2,64);GUI_DispDecShiftAt(40,64,11,2,(RtuDataAddr->Real_Zj_Value[i].P_F[0]-RtuDataAddr->Day_Zj_Value[i].P_F[0]));
		       GUI_DispStringAt("P��:",2,80);GUI_DispDecShiftAt(40,80,11,2,(RtuDataAddr->Real_Zj_Value[i].P_F[1]-RtuDataAddr->Day_Zj_Value[i].P_F[1]));
		       GUI_DispStringAt("Pƽ:",2,96);GUI_DispDecShiftAt(40,96,11,2,(RtuDataAddr->Real_Zj_Value[i].P_F[2]-RtuDataAddr->Day_Zj_Value[i].P_F[2]));
		       GUI_DispStringAt("P��:",2,112);GUI_DispDecShiftAt(40,112,11,2,(RtuDataAddr->Real_Zj_Value[i].P_F[3]-RtuDataAddr->Day_Zj_Value[i].P_F[3]));
		       GUI_DispStringAt("Q��:",2,128);GUI_DispDecShiftAt(40,128,7,3,(RtuDataAddr->Real_Zj_Value[i].Q-RtuDataAddr->Day_Zj_Value[i].Q));

/*		       memset(NowInput.buf,0,128);
               sprintf(NowInput.buf,"%02d%02d%02d%02d",
					RtuDataAddr->Zj_Control_Value[i].F47_Set_Para.Gou_DIan_Value[3],
					RtuDataAddr->Zj_Control_Value[i].F47_Set_Para.Gou_DIan_Value[2],
					RtuDataAddr->Zj_Control_Value[i].F47_Set_Para.Gou_DIan_Value[1],
					RtuDataAddr->Zj_Control_Value[i].F47_Set_Para.Gou_DIan_Value[0]
				);
		       GUI_DispStringAt("������:",8,128);GUI_DispStringAt(NowInput.buf,64,128);
*/
		       //GUI_DispStringAt("kwh",132,32);
		       GUI_DispStringAt("kwh",132,48);
		       GUI_DispStringAt("kwh",132,64);
		       GUI_DispStringAt("kwh",132,80);
		       GUI_DispStringAt("kwh",132,96);
		       GUI_DispStringAt("kwh",132,112);
		       GUI_DispStringAt("kvarh",116,128);
	           break;

			   case 1:

			   GUI_DispStringAt("���µ���",28,16);
			   GUI_DispStringAt("�ܼ��� :",0,32);

		       GUI_DispDecAt(i+1, 48, 32, 1);

			   //GUI_DispStringAt("�й�:",0,32);GUI_DispDecShiftAt(40,32,7,3,RtuDataAddr->Yue_Zj_Value[i].P);
		       GUI_DispStringAt("P��:",2,48);GUI_DispDecShiftAt(40,48,10,0,(RtuDataAddr->Real_Zj_Value[i].P_All-RtuDataAddr->Yue_Zj_Value[i].P_All));
		       GUI_DispStringAt("P��:",2,64);GUI_DispDecShiftAt(40,64,11,2,(RtuDataAddr->Real_Zj_Value[i].P_F[0]-RtuDataAddr->Yue_Zj_Value[i].P_F[0]));
		       GUI_DispStringAt("P��:",2,80);GUI_DispDecShiftAt(40,80,11,2,(RtuDataAddr->Real_Zj_Value[i].P_F[1]-RtuDataAddr->Yue_Zj_Value[i].P_F[1]));
		       GUI_DispStringAt("Pƽ:",2,96);GUI_DispDecShiftAt(40,96,11,2,(RtuDataAddr->Real_Zj_Value[i].P_F[2]-RtuDataAddr->Yue_Zj_Value[i].P_F[2]));
		       GUI_DispStringAt("P��:",2,112);GUI_DispDecShiftAt(40,112,11,2,(RtuDataAddr->Real_Zj_Value[i].P_F[3]-RtuDataAddr->Yue_Zj_Value[i].P_F[3]));
		       GUI_DispStringAt("Q��:",2,128);GUI_DispDecShiftAt(40,128,7,3,(RtuDataAddr->Real_Zj_Value[i].Q-RtuDataAddr->Yue_Zj_Value[i].Q));

		       //GUI_DispStringAt("kwh",132,32);
		       GUI_DispStringAt("kwh",132,48);
		       GUI_DispStringAt("kwh",132,64);
		       GUI_DispStringAt("kwh",132,80);
		       GUI_DispStringAt("kwh",132,96);
		       GUI_DispStringAt("kwh",132,112);
		       GUI_DispStringAt("kvarh",116,128);
	           break;

			   default: break;

	        }
 		    Status_Bar();
 		    BottomBar();
		    Lcmfull();
		    keysele=KeySeleflag;
		    KeySeleflag =0;
		    if(DelayTime>=PageDelayTime)
		    {
		       	OldLevel=0;
		       	return 0;
		     }
		    switch(keysele)
		    {
		     case 0:DelayTime++;break;
		     case 1: if(i==0) i=7; else i=(i-1)%8; DelayTime=0;break;
		     case 2: i=(i+1)%ZongJia_Max ;DelayTime=0;break;
		     case 3: j=(j+1)%2;DelayTime=0;break;
		     case 4: j=(j+1)%2;DelayTime=0;break;
		     case 5:  DelayTime=0;break;
		     case 6: OldLevel=0;return 0;break;
		     default:break;
		    }
		  }



}

/******************************************************************************************************************
* �������ƣ�Show_SYDL()
* ��    �ܣ���ʾʣ��������գ����ܵ���
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void Show_SYDLV(unsigned int SYDL)
{
    //GUI_Clear();
    if(LunXianCount<LunXianTime)RunArrow(2);
    GUI_DispStringAt("ʣ�����:",16,32);
    GUI_DispDecShiftAt(16,48,8,0,SYDL);GUI_DispStringAt("kwh",104,48);
}
void Show_SYDLN(unsigned int SYDL)
{
    //GUI_Clear();
    if(LunXianCount<LunXianTime)RunArrow(2);
    GUI_DispStringAt("ʣ�����:",16,32);
    GUI_DispStringAt("��Ч��",16,48);
 }
void Show_YDDL(unsigned int D_PAll,unsigned int Y_PAll)
{
    GUI_DispStringAt("���ܵ���: ",16,64);
    GUI_DispDecShiftAt(16,80,8,0,D_PAll);GUI_DispStringAt("kwh",104,80);
    GUI_DispStringAt("���ܵ���: ",16,96);
    GUI_DispDecShiftAt(16,112,8,0,Y_PAll);GUI_DispStringAt("kwh",104,112);

 }

/******************************************************************************************************************
* �������ƣ�Show_ZX_YOUGONG()
* ��    �ܣ���ʾ�����й� �ܼ���ƽ
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void Show_ZX_YOUGONG(unsigned int Z_ZAll,unsigned int Z_JAll,unsigned int Z_FAll,unsigned int Z_GAll,unsigned int Z_PAll,unsigned char POINT)
{
    //GUI_Clear();
    if(LunXianCount<LunXianTime)RunArrow(2);
    GUI_DispStringAt("�����й�����ʾֵ",16,16);
                                    //GUI_DispDecShiftAt(y ,x ,...)
    GUI_DispStringAt("��: ",16,33);GUI_DispDecShiftAt(40,32,9,2,Z_ZAll);GUI_DispStringAt("kwh",116,32);
    GUI_DispStringAt("��: ",16,49);GUI_DispDecShiftAt(40,48,9,2,Z_JAll);GUI_DispStringAt("kwh",116,48);
    GUI_DispStringAt("��: ",16,65);GUI_DispDecShiftAt(40,64,9,2,Z_FAll);GUI_DispStringAt("kwh",116,64);
    GUI_DispStringAt("ƽ: ",16,81);GUI_DispDecShiftAt(40,80,9,2,Z_GAll);GUI_DispStringAt("kwh",116,80);
    GUI_DispStringAt("��: ",16,97);GUI_DispDecShiftAt(40,96,9,2,Z_PAll);GUI_DispStringAt("kwh",116,96);

    GUI_DispStringAt("����ʱ��",48,111);


                GUI_DispStringAt("��  ��  ��  ʱ  ��",16,126);
                GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD05 ,0,126,2);
				GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD04 ,32,126,2);
				GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD03 ,64,126,2);
				GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD02 ,96,126,2);
				GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD01 ,128,126,2);



}
/******************************************************************************************************************
* �������ƣ�Show_FX_YOUGONG()
* ��    �ܣ���ʾ�����й� �ܼ���ƽ
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/

void Show_FX_YOUGONG(unsigned int Z_ZAll,unsigned int Z_JAll,unsigned int Z_FAll,unsigned int Z_GAll,unsigned int Z_PAll,unsigned char POINT)
{
    //GUI_Clear();
    if(LunXianCount<LunXianTime)RunArrow(3);
    GUI_DispStringAt("�����й�����ʾֵ",16,16);
                                    //GUI_DispDecShiftAt(y ,x ,...)
    GUI_DispStringAt("��: ",16,33);GUI_DispDecShiftAt(40,32,9,2,Z_ZAll);GUI_DispStringAt("kwh",116,32);
    GUI_DispStringAt("��: ",16,49);GUI_DispDecShiftAt(40,48,9,2,Z_JAll);GUI_DispStringAt("kwh",116,48);
    GUI_DispStringAt("��: ",16,65);GUI_DispDecShiftAt(40,64,9,2,Z_FAll);GUI_DispStringAt("kwh",116,64);
    GUI_DispStringAt("ƽ: ",16,81);GUI_DispDecShiftAt(40,80,9,2,Z_GAll);GUI_DispStringAt("kwh",116,80);
    GUI_DispStringAt("��: ",16,97);GUI_DispDecShiftAt(40,96,9,2,Z_PAll);GUI_DispStringAt("kwh",116,96);

    GUI_DispStringAt("����ʱ��",48,111);

    GUI_DispStringAt("��  ��  ��  ʱ  ��",16,126);
                GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD05 ,0,126,2);
				GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD04 ,32,126,2);
				GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD03  ,64,126,2);
				GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD02  ,96,126,2);
				GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD01 ,128,126,2);




}
/******************************************************************************************************************
* �������ƣ�Show_ZX_WUGONG()
* ��    �ܣ���ʾ�����޹� �ܼ���ƽ
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void Show_ZX_WUGONG(INT32U Z_ZAll,INT32U Z_JAll,INT32U Z_FAll,INT32U Z_GAll,INT32U Z_PAll,INT8U POINT)
{
    //GUI_Clear();
    if(LunXianCount<LunXianTime)RunArrow(3);
	GUI_DispStringAt("�����޹�����ʾֵ",16,16);
                                    //GUI_DispDecShiftAt(y ,x ,...)
    GUI_DispStringAt("��: ",16,33);GUI_DispDecShiftAt(40,32,9,2,Z_ZAll);GUI_DispStringAt("kwh",116,32);
    GUI_DispStringAt("��: ",16,49);GUI_DispDecShiftAt(40,48,9,2,Z_JAll);GUI_DispStringAt("kwh",116,48);
    GUI_DispStringAt("��: ",16,65);GUI_DispDecShiftAt(40,64,9,2,Z_FAll);GUI_DispStringAt("kwh",116,64);
    GUI_DispStringAt("ƽ: ",16,81);GUI_DispDecShiftAt(40,80,9,2,Z_GAll);GUI_DispStringAt("kwh",116,80);
    GUI_DispStringAt("��: ",16,97);GUI_DispDecShiftAt(40,96,9,2,Z_PAll);GUI_DispStringAt("kwh",116,96);

    GUI_DispStringAt("����ʱ��",48,111);

    GUI_DispStringAt("��  ��  ��  ʱ  ��",16,126);
                GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD05 ,0,126,2);
				GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD04 ,32,126,2);
				GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD03 ,64,126,2);
				GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD02 ,96,126,2);
				GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD01 ,128,126,2);



}
/******************************************************************************************************************
* �������ƣ�Show_FX_WUGONG()
* ��    �ܣ���ʾ�����޹� �ܼ���ƽ
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void Show_FX_WUGONG(INT32U Z_ZAll,INT32U Z_JAll,INT32U Z_FAll,INT32U Z_GAll,INT32U Z_PAll,INT8U POINT)
{
    //GUI_Clear();
    if(LunXianCount<LunXianTime)RunArrow(3);
    GUI_DispStringAt("�����޹�����ʾֵ",16,16);
                                     //GUI_DispDecShiftAt(y ,x ,...)
    GUI_DispStringAt("��: ",16,33);GUI_DispDecShiftAt(40,32,9,2,Z_ZAll);GUI_DispStringAt("kwh",116,32);
    GUI_DispStringAt("��: ",16,49);GUI_DispDecShiftAt(40,48,9,2,Z_JAll);GUI_DispStringAt("kwh",116,48);
    GUI_DispStringAt("��: ",16,65);GUI_DispDecShiftAt(40,64,9,2,Z_FAll);GUI_DispStringAt("kwh",116,64);
    GUI_DispStringAt("ƽ: ",16,81);GUI_DispDecShiftAt(40,80,9,2,Z_GAll);GUI_DispStringAt("kwh",116,80);
    GUI_DispStringAt("��: ",16,97);GUI_DispDecShiftAt(40,96,9,2,Z_PAll);GUI_DispStringAt("kwh",116,96);

    GUI_DispStringAt("����ʱ��",48,111);

    GUI_DispStringAt("��  ��  ��  ʱ  ��",16,126);
                GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD05 ,0,126,2);
				GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD04 ,32,126,2);
				GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD03   ,64,126,2);
				GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD02  ,96,126,2);
				GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD01 ,128,126,2);



}
/******************************************************************************************************************
* �������ƣ�Show_UI()
* ��    �ܣ���ʾ������ѹ
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void Show_UI(INT32U Ua,INT32U Ub,INT32U Uc,INT32U Ia,INT32U Ib,INT32U Ic,INT8U POINT)
{
   // GUI_Clear();
    if(LunXianCount<LunXianTime)RunArrow(3);
    GUI_DispStringAt("��ѹ(V)",52,16);
    GUI_DispStringAt("Ua/Uab:    ",16,32);
    GUI_DispDecShiftAt(96,32,5,1,Ua);
    GUI_DispStringAt("Ub/Ubc:    ",16,48);
    GUI_DispDecShiftAt(96,48,5,1,Ub);
    GUI_DispStringAt("Uc/Uca:    ",16,64);
    GUI_DispDecShiftAt(96,64,5,1,Uc);


    GUI_DispStringAt("����(A)",52,80);
    GUI_DispStringAt("Ia:  ",32,96);
    GUI_DispDecShiftAt(96,96,5,2,Ia);
    GUI_DispStringAt("Ib:  ",32,112);
    GUI_DispDecShiftAt(96,112,5,2,Ib);
    GUI_DispStringAt("Ic:  ",32,128);
    GUI_DispDecShiftAt(96,128,5,2,Ic);

}
/******************************************************************************************************************
* �������ƣ�Show_PQC()
* ��    �ܣ���ʾ�С��ѡ��ãϣ�
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void Show_PQC(INT32U P,INT32U Q,INT32U Cos,INT8U POINT)
{
    //GUI_Clear();
    if(LunXianCount<LunXianTime)RunArrow(3);
                                     //GUI_DispDecShiftAt(y ,x ,...)
    GUI_DispStringAt("�й�����(Kw)",32,16);
    GUI_DispDecShiftAt(56,32,7,1,P);

    GUI_DispStringAt("�޹�����(Kavr)",24,48);
    GUI_DispDecShiftAt(56,64,7,1,Q);

    GUI_DispStringAt("��������",48,80);
    GUI_DispDecShiftAt(64,96,5,3,Cos);

    GUI_DispStringAt("����ʱ��",48,111);
    GUI_DispStringAt("��  ��  ��  ʱ  ��",16,126);
                GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD05 ,0,126,2);
				GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD04 ,32,126,2);
				GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD03   ,64,126,2);
				GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD02  ,96,126,2);
				GUI_DispHexAt(RtuDataAddr->DD_Device_BiaoShi_Value[POINT].Chao_Time.BCD01 ,128,126,2);


}
/******************************************************************************************************************
* �������ƣ�Show_ZXU()
* ��    �ܣ���ʾ�����������ʱ��
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/

void Show_ZXU(INT32U P,INT32U Q,INT8U POINT)
{

   // GUI_Clear();
    if(LunXianCount<LunXianTime)RunArrow(1);
    GUI_DispStringAt("�������������ʱ��",8,18);
    GUI_DispStringAt("�����й�(Kw)",32,36);
    GUI_DispDecShiftAt(52,54,7,4,P);
   	GUI_DispStringAt("  ��  ��  ʱ  ��",16,72);

   	GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[POINT].Time_Z_P_X_All[0],16,72,2);
	GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[POINT].Time_Z_P_X_All[1],48,72,2);
	GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[POINT].Time_Z_P_X_All[2],80,72,2);
	GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[POINT].Time_Z_P_X_All[3],112,72,2);


    GUI_DispStringAt("�����й�(Kw)",32,90);
    GUI_DispDecShiftAt(52,108,7,4,Q);
    GUI_DispStringAt("  ��  ��  ʱ  ��",16,126);

    GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[POINT].Time_F_P_X_All[0],16,126,2);
	GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[POINT].Time_F_P_X_All[1],48,126,2);
	GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[POINT].Time_F_P_X_All[2],80,126,2);
	GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[POINT].Time_F_P_X_All[3],112,126,2);


}

/******************************************************************************************************************
* �������ƣ�XiuMeterNum()�����ڵ�һ���˵�
* ��    �ܣ�����Ҫ�鿴�ı������
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void XiuMeterNum(unsigned char SeleMenu)
{

  	    unsigned char i;
        memset(NowInput.buf,0,128);
        sprintf(NowInput.buf,"%02d",
					ChakanMeterNum
				);  //����ת����Ϊ�ַ���

		i=0;
		while(i<2)
		{
			     NowInput.col[i]=54;//y��
			     NowInput.row[i]=72+i*8;//x��
		         NowInput.set[i]=1;
			     i++;
		}

		NowInput.AllNum=3;
		if(ScreenInput()==1)
		{
			ChakanMeterNum = GetNum(&NowInput.buf[0],2,1);
			if(ChakanMeterNum>=DD_Device_Max)ChakanMeterNum=DD_Device_Max-1;

		}


}
/******************************************************************************************************************
* �������ƣ�XiuMeterSetNum()�����ڵ�һ���˵�
* ��    �ܣ�����Ҫ�鿴�ı������
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void XiuMeterSetNum(unsigned char SeleMenu)
{
/*
  	    unsigned char i;
        memset(NowInput.buf,0,128);
        sprintf(NowInput.buf,"%02d",ChakanMeterSetNum);  //����ת����Ϊ�ַ���
		i=0;
		while(i<2)
		{
			     NowInput.col[i]=74;//y��
			     NowInput.row[i]=72+i*8;//x��
		         NowInput.set[i]=1;
			     i++;
		}

		NowInput.AllNum=3;
		if(ScreenInput()==1)
		{
			ChakanMeterSetNum = GetNum(&NowInput.buf[0],2,1);
			if(ChakanMeterSetNum>=DD_Device_Max)ChakanMeterSetNum=DD_Device_Max-1;
		}
		*/
}
/******************************************************************************************************************
* �������ƣ�XiuMeterMaichongNum()�����ڵ�һ���˵�
* ��    �ܣ�����Ҫ�޸ĵı��������� �����ű���MaichongNumΪ1-4��������F11_Set_Para.MaiChong[n]nΪ0-3
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void XiuMeterMaichongNum(unsigned char SeleMenu)
{
/*
  	    unsigned char i;
        memset(NowInput.buf,0,128);
        sprintf(NowInput.buf,"%02d",MaichongNum);  //����ת����Ϊ�ַ���
		i=0;
		while(i<2)
		{
			     NowInput.col[i]=54;//y��
			     NowInput.row[i]=72+i*8;//x��
		         NowInput.set[i]=1;
			     i++;
		}

		NowInput.AllNum=3;
		if(ScreenInput()==1)
		{
			MaichongNum = GetNum(&NowInput.buf[0],2,1);
			if(MaichongNum>MaiChong_Max)	MaichongNum=MaiChong_Max;
			if((MaichongNum<1)||(MaichongNum==0))	MaichongNum=1;
		}*/
}
/******************************************************************************************************************
* �������ƣ�Fb_XiuMaichongNum()�����ڵڶ����˵�
* ��    �ܣ������ס����ġ��鿴���š�
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void Fb_XiuMaichongNum(INT8U SelMenu)
{

    memset(NowInput.buf,0,128);
	sprintf(NowInput.buf,"%02d",MaichongNum);  //����ת����Ϊ�ַ���

	if(SelMenu==62)
	 {
		 GUI_SetTextMode(GUI_TM_REV);
	     GUI_DispStringAt(NowInput.buf,72,54);
	 }
 	else
	     GUI_DispStringAt(NowInput.buf,72,54);
	     GUI_SetTextMode(GUI_TM_NORMAL);

	 if(SelMenu==63)
	 {
		 GUI_SetTextMode(GUI_TM_REV);
		 GUI_DispStringAt("�����޸�",48,76);
	 }
 	else
 		GUI_DispStringAt("�����޸�",48,76);
		GUI_SetTextMode(GUI_TM_NORMAL);
}

/******************************************************************************************************************
* �������ƣ�XiuRenWuType()�����ڵ�һ���˵�
* ��    �ܣ�����Ҫ�鿴�ı������
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
int XiuRenWuType(unsigned char SeleMenu)
{

  	    unsigned char i;
        memset(NowInput.buf,0,128);
        sprintf(NowInput.buf,"%1d",RenWuType);  //����ת����Ϊ�ַ���
		i=0;
		while(i<2)
		{
			     NowInput.col[i]=44;//y��
			     NowInput.row[i]=104+i*8;//x��
		         NowInput.set[i]=1;
			     i++;
		}

		NowInput.AllNum=3;
		if(ScreenInput()==1)
		{
			RenWuType = GetNum(&NowInput.buf[0],2,1);
			if(RenWuType>=64)RenWuType=64-1;
		}
}

/******************************************************************************************************************
* �������ƣ�XiuRenWuNum()�����ڵ�һ���˵�
* ��    �ܣ�����Ҫ�鿴�ı������
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
int XiuRenWuNum(unsigned char SeleMenu)
{

  	    unsigned char i;
        memset(NowInput.buf,0,128);
        sprintf(NowInput.buf,"%1d",RenWuType);  //����ת����Ϊ�ַ���
		i=0;
		while(i<1)
		{
			     NowInput.col[i]=44;//y��
			     NowInput.row[i]=104+i*8;//x��
		         NowInput.set[i]=1;
			     i++;
		}
		NowInput.AllNum=3;
		if(ScreenInput()==1)
		{
			RenWuType = GetNum(&NowInput.buf[0],2,1);
			if(RenWuType>=2)RenWuType=2-1;
		}
        memset(NowInput.buf,0,128);
        sprintf(NowInput.buf,"%02d",RenWuNum);  //����ת����Ϊ�ַ���
		i=0;
		while(i<2)
		{
			     NowInput.col[i]=64;//y��
			     NowInput.row[i]=104+i*8;//x��
		         NowInput.set[i]=1;
			     i++;
		}

		NowInput.AllNum=3;
		if(ScreenInput()==1)
		{
			RenWuNum = GetNum(&NowInput.buf[0],2,1);
			if(RenWuNum>=64)RenWuNum=64-1;
		}
}
/******************************************************************************************************************
* �������ƣ�Fb_XiuRenWuType()�����ڵ�һ���˵�
* ��    �ܣ�����Ҫ�鿴�ı������
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void Fb_XiuRenWuType(INT8U SelMenu)
{

    memset(NowInput.buf,0,128);
	sprintf(NowInput.buf,"%1d",RenWuNum);  //����ת����Ϊ�ַ���

	if(SelMenu==77)
	 {
		 GUI_SetTextMode(GUI_TM_REV);
	     GUI_DispStringAt(NowInput.buf,104,44);
	 }
 	else
	     GUI_DispStringAt(NowInput.buf,104,44);
	     GUI_SetTextMode(GUI_TM_NORMAL);

	 if(SelMenu==79)
	 {
		 GUI_SetTextMode(GUI_TM_REV);
		 GUI_DispStringAt("����",48,76);
	 }
 	else
 		GUI_DispStringAt("����",48,76);
		GUI_SetTextMode(GUI_TM_NORMAL);
}
/******************************************************************************************************************
* �������ƣ�Fb_XiuRenWuNum()�����ڵ�һ���˵�
* ��    �ܣ�����Ҫ�鿴�ı������
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void Fb_XiuRenWuNum(INT8U SelMenu)
{
	memset(NowInput.buf,0,128);
	sprintf(NowInput.buf,"%1d",RenWuNum);  //����ת����Ϊ�ַ���

	if(SelMenu==77)
	{
	 	 GUI_SetTextMode(GUI_TM_REV);
	 	 GUI_DispStringAt(NowInput.buf,104,44);
	 }
	else
	 	 GUI_DispStringAt(NowInput.buf,104,44);
	 	 GUI_SetTextMode(GUI_TM_NORMAL);

    memset(NowInput.buf,0,128);
	sprintf(NowInput.buf,"%02d",RenWuNum);  //����ת����Ϊ�ַ���

	if(SelMenu==78)
	 {
		 GUI_SetTextMode(GUI_TM_REV);
	     GUI_DispStringAt(NowInput.buf,104,64);
	 }
 	else
	     GUI_DispStringAt(NowInput.buf,104,64);
	     GUI_SetTextMode(GUI_TM_NORMAL);

	 if(SelMenu==79)
	 {
		 GUI_SetTextMode(GUI_TM_REV);
		 GUI_DispStringAt("����",48,76);
	 }
 	else
 		GUI_DispStringAt("����",48,76);
		GUI_SetTextMode(GUI_TM_NORMAL);
}
/******************************************************************************************************************
* �������ƣ�Fb_XiuMaichong()�����ڵڶ����˵�
* ��    �ܣ������ס����ġ��鿴���š�
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void Fb_XiuMaichong(INT8U SelMenu)
{
     INT8U TempBuf[16];
     INT32U num;

	 GUI_DispStringAt("����  ״̬:",36,24);
	 GUI_DispDecAt(MaichongNum, 72, 24, 1);

	 if(SelMenu==64)//���׶˿ں�
	 {
		 GUI_SetTextMode(GUI_TM_REV);
	     GUI_DispDecAt(FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].InputNo, 116, 44, 2);
	 }
	 else
	     GUI_DispDecAt(FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].InputNo, 116, 44, 2);
	     GUI_SetTextMode(GUI_TM_NORMAL);

	 if(SelMenu==65)//���ײ�����
	 {
		 GUI_SetTextMode(GUI_TM_REV);
	     GUI_DispDecAt(FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].CeLiangNo, 116, 64, 2);
	 }
	 else
	     GUI_DispDecAt(FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].CeLiangNo, 116, 64, 2);
	     GUI_SetTextMode(GUI_TM_NORMAL);

	 if(SelMenu==66)//������������
	 {
		 GUI_SetTextMode(GUI_TM_REV);
	     GUI_DispDecAt(FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].Stat, 116, 84, 2);
	 }
	 else
	     GUI_DispDecAt(FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].Stat, 116, 84, 2);
	     GUI_SetTextMode(GUI_TM_NORMAL);

	  memset(TempBuf,0,16);
	  num = (FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].Changhu[1]<<8)|FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].Changhu[0];

     sprintf(TempBuf,"%05d",num);  //����ת����Ϊ�ַ���

	 if(SelMenu==67)//���׵������
	 {
		// printf("\n\r TempBuf=%s changshu[0]=%x changshu[1]=%x",TempBuf,FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].Changhu[0],FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].Changhu[1]);
		 GUI_SetTextMode(GUI_TM_REV);
	     GUI_DispStringAt(TempBuf,100,104);
	 }
	 else
	     GUI_DispStringAt(TempBuf,100,104);
	     GUI_SetTextMode(GUI_TM_NORMAL);

/*	if(SelMenu==40)//���׵������
	 {
		 GUI_SetTextMode(GUI_TM_REV);
	     GUI_DispStringAt("�޸�",64,124);
	 }
	  else
	     GUI_DispStringAt("�޸�",64,124);
	     GUI_SetTextMode(GUI_TM_NORMAL);
*/
}
/******************************************************************************************************************
* �������ƣ�Xiu_Maichong_Duankou()�����ڵڶ����˵�
* ��    �ܣ������ס����ġ��鿴���š�
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void Xiu_Maichong_Duankou(INT8U SelMenu)
{
/*
     INT8U i;
	 memset(NowInput.buf,0,128);
	 sprintf(NowInput.buf,"%02d",FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].InputNo);  //����ת����Ϊ�ַ��� //16���Ƶ�BCD��
	 i=0;
	 while(i<2)
	 {

			NowInput.col[i]=44;//y��
			NowInput.row[i]=116+i*8;//x��
		    NowInput.set[i]=1;
			i++;
	 }
	 NowInput.AllNum=3;
	 if(ScreenInput()==1)
	 {
		 FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].InputNo=GetNum(&NowInput.buf[0],2,1);
		 //��ʱ��� Lcmfull();
		 //OSSemPost(FlushSem);
		RtuDataAddr->FkComm_Value.F11_Set_Para=FkComm_ValueTmp.F11_Set_Para;
		SaveFKSet();
	 }*/
}
/******************************************************************************************************************
* �������ƣ�Xiu_Maichong_Celiang()�����ڵڶ����˵�
* ��    �ܣ������ס����ġ��鿴���š�
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void Xiu_Maichong_Celiang(INT8U SelMenu)
{
/*
    INT8U i;
	memset(NowInput.buf,0,128);
	sprintf(NowInput.buf,"%02d",   //16���Ƶ�BCD��
		FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].CeLiangNo
		);  //����ת����Ϊ�ַ���
		i=0;
		while(i<2)
		{

			     NowInput.col[i]=64;//y��
			     NowInput.row[i]=116+i*8;//x��
		    	 NowInput.set[i]=1;
			i++;
		}
		NowInput.AllNum=3;
		if(ScreenInput()==1)
		{
		 FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].CeLiangNo=GetNum(&NowInput.buf[0],2,1);
		 //��ʱ��� Lcmfull();
		 //OSSemPost(FlushSem);
		 RtuDataAddr->FkComm_Value.F11_Set_Para=FkComm_ValueTmp.F11_Set_Para;
		 SaveFKSet();
		}*/
}
/******************************************************************************************************************
* �������ƣ�Xiu_Maichong_Shuxing()�����ڵڶ����˵�
* ��    �ܣ������ס����ġ��鿴���š�
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void Xiu_Maichong_Shuxing(INT8U SelMenu)
{/*

    INT8U i;
	memset(NowInput.buf,0,128);
	sprintf(NowInput.buf,"%02d",   //16���Ƶ�BCD��
		FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].Stat
		);  //����ת����Ϊ�ַ���
		i=0;
		while(i<2)
		{

			     NowInput.col[i]=84;//y��
			     NowInput.row[i]=116+i*8;//x��
		    	 NowInput.set[i]=1;
			i++;
		}
		NowInput.AllNum=3;
		if(ScreenInput()==1)
		{
		 FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].Stat=GetNum(&NowInput.buf[0],2,1);
		 //��ʱ��� Lcmfull();
		 //OSSemPost(FlushSem);
		 RtuDataAddr->FkComm_Value.F11_Set_Para=FkComm_ValueTmp.F11_Set_Para;
		 SaveFKSet();
		}*/
}
/******************************************************************************************************************
* �������ƣ�Xiu_Maichong_Changshu()�����ڵڶ����˵�
* ��    �ܣ������ס����ġ��鿴���š�
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void Xiu_Maichong_Changshu(INT8U SelMenu)
{/*
	INT32U num;
	INT8U i;
  //int m=0;
	unsigned char  changshu[3];
	memset(NowInput.buf,0,128);
	//m=FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].Changhu[1]*100+FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].Changhu[0];

	//printf("\n\rFkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].Changhu[1] =%d,FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].Changhu[0]=%d",FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].Changhu[1],FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].Changhu[0]);
	//num = FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].Changhu[1]*100 + FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].Changhu[0];
	num=(FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].Changhu[1]<<8)|(FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].Changhu[0]);
	//printf("\n\r num = %d",num);

	sprintf(NowInput.buf,"%05d",num);
	//printf("\n\r NowInput.buf = %s",NowInput.buf);
	i=0;
	while(i<5)
	{
		NowInput.col[i]=104;//y��
		NowInput.row[i]=100+i*8;//x��
		NowInput.set[i]=1;
		i++;
	}
	NowInput.AllNum=6;
	//GUI_DispStringAt(NowInput.buf,100,104);

	if(ScreenInput()==1)
	{
		//printf("\n\r NowInput.buf=%d %d %d %d %d ",NowInput.buf[0],NowInput.buf[1],NowInput.buf[2],NowInput.buf[3],NowInput.buf[4]);
		for(i=0;i<2;i++)
			changshu[i]=GetNum(&NowInput.buf[2*i],2,1);
		changshu[2]=GetNum(&NowInput.buf[4],1,1);
		num=changshu[0]*1000+changshu[1]*10+changshu[2];

		//	printf("\n\r changshu[2]=%d,changshu[1]=%d,changshu[0]=%d",changshu[2],changshu[1],changshu[0]);
			//num = GetNum(&NowInput.buf[0],2,1) *100 + GetNum(&NowInput.buf[2],2,1);
		 FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].Changhu[1]=(num&0xff00)>>8;//GetNum(&NowInput.buf[0],2,1);
		 FkComm_ValueTmp.F11_Set_Para.MaiChong[MaichongNum-1].Changhu[0]=num&0x00ff;//GetNum(&NowInput.buf[2],2,1);
		 RtuDataAddr->FkComm_Value.F11_Set_Para=FkComm_ValueTmp.F11_Set_Para;
		 SaveFKSet();
	}*/
}

/******************************************************************************************************************
* �������ƣ�Fb_ChakanMeterNum()�����ڵڶ����˵�
* ��    �ܣ������ס����ġ��鿴���š�
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void Fb_ChakanMeterNum(INT8U SelMenu)
{

    memset(NowInput.buf,0,128);
				sprintf(NowInput.buf,"%02d",
					ChakanMeterNum);  //����ת����Ϊ�ַ���

	if(SelMenu==6)
	 {
		 GUI_SetTextMode(GUI_TM_REV);
	     GUI_DispStringAt(NowInput.buf,72,54);
	 }
 	else
	     GUI_DispStringAt(NowInput.buf,72,54);
	     GUI_SetTextMode(GUI_TM_NORMAL);
    GUI_DispStringAt("(0-  )",88,54);
    GUI_DispDecAt(RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num-1, 112, 54, 2);

	 if(SelMenu==7)
	 {
	  GUI_SetTextMode(GUI_TM_REV);
	  GUI_DispStringAt("����鿴",48,76);
	 }
 	else
	   GUI_DispStringAt("����鿴",48,76);
       GUI_SetTextMode(GUI_TM_NORMAL);


}
/******************************************************************************************************************
* �������ƣ�Fb_XiuMeterSetNum()�����ڵڶ����˵�
* ��    �ܣ������ס����ġ��޸ı��š�
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void Fb_XiuMeterSetNum(INT8U SelMenu)
{
    //  INT8U i;
    //  INT8U DongJie;
      GUI_DispStringAt("��������",48,17);
 /*       memset(NowInput.buf,0,128);
				sprintf(NowInput.buf,"%02d",
						Fk_Control_Set_ValueTmp.F24_Set_Para.Zhong_Duan_ChaoBiao_Jiange
					);  //����ת����Ϊ�ַ���
	if(SelMenu==68)
	 {
	 GUI_SetTextMode(GUI_TM_REV);
	 GUI_DispStringAt(NowInput.buf,92,36);
	 }
 	else
     GUI_DispStringAt(NowInput.buf,92,36);
     GUI_SetTextMode(GUI_TM_NORMAL);

    if(SelMenu==13)
	 {
	  GUI_SetTextMode(GUI_TM_REV);
	  GUI_DispStringAt("�޸�",64,54);
	 }
 	else
	   GUI_DispStringAt("�޸�",64,54);
       GUI_SetTextMode(GUI_TM_NORMAL);
 */

    memset(NowInput.buf,0,128);
				sprintf(NowInput.buf,"%02d",
					ChakanMeterSetNum);  //����ת����Ϊ�ַ���

	if(SelMenu==49)
	 {
		 GUI_SetTextMode(GUI_TM_REV);
	     GUI_DispStringAt(NowInput.buf,72,74);//106-32
	 }
 	else
	     GUI_DispStringAt(NowInput.buf,72,74);
	     GUI_SetTextMode(GUI_TM_NORMAL);

    GUI_DispStringAt("(0-  )",88,74);//106-32
    GUI_DispDecAt(RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num-1, 112, 74, 2);

	 if(SelMenu==50)
	 {
	  GUI_SetTextMode(GUI_TM_REV);
	  GUI_DispStringAt("�����޸�",48,90);//122-32
	 }
 	else
	   GUI_DispStringAt("�����޸�",48,90);
       GUI_SetTextMode(GUI_TM_NORMAL);


}
/******************************************************************************************************************
* �������ƣ�ChaoBiaoJG()
* ��    �ܣ����޸ġ����ġ����ʱ�䡿
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void ChaoBiaoJGSet(INT8U SeleMenu)
{/*
        INT8U i;
        memset(NowInput.buf,0,128);
        Fk_Control_Set_ValueTmp.F24_Set_Para.Zhong_Duan_ChaoBiao_Jiange = RtuDataAddr->Fk_Control_Set_Value.F24_Set_Para.Zhong_Duan_ChaoBiao_Jiange;
        sprintf(NowInput.buf,"%02d",
					Fk_Control_Set_ValueTmp.F24_Set_Para.Zhong_Duan_ChaoBiao_Jiange
					);  //����ת����Ϊ�ַ���
		i=0;
		while(i<2)
		{

			     NowInput.col[i]=120;//y��
			     NowInput.row[i]=88+i*8;//x��
		     	 NowInput.set[i]=1;
			i++;
		}

		NowInput.AllNum=3;
		if(ScreenInput()==1)
		{

			Fk_Control_Set_ValueTmp.F24_Set_Para.Zhong_Duan_ChaoBiao_Jiange=GetNum(&NowInput.buf[0],2,1);
			RtuDataAddr->Fk_Control_Set_Value.F24_Set_Para.Zhong_Duan_ChaoBiao_Jiange=Fk_Control_Set_ValueTmp.F24_Set_Para.Zhong_Duan_ChaoBiao_Jiange;
			RtuDataAddr->Fk_Control_Set_Value.F24_Set_Para.Valid=1;

			SaveFKSet();
		    //��ʱ���Lcmfull();
		    //OSSemPost(FlushSem);
		}*/
}
/******************************************************************************************************************
* �������ƣ�ShowMeterData()�����ڵ�һ���˵�
* ��    �ܣ�������Ĳ�����ź�-����ʾ���������
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void ShowMeterData(INT8U SeleMenu)
{
   unsigned int DelayTime;
   INT8U keysele,i;
   i=0;
   DelayTime=0;
  while(1)

  {
   GUI_Clear();
   switch(i)
   {

    case 0: Show_ZX_YOUGONG(RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].Z_P_All,
                            RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].Z_P_F[0],
                            RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].Z_P_F[1],
                            RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].Z_P_F[2],
                            RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].Z_P_F[3],
                            ChakanMeterNum);break;
    case 1: Show_FX_YOUGONG(RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].F_P_All,
                            RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].F_P_F[0],
                            RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].F_P_F[1],
                            RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].F_P_F[2],
                            RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].F_P_F[3],
                            ChakanMeterNum);break;
    case 2: Show_ZX_WUGONG(RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].Z_Q_All,
                           RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].Z_Q_F[0],
                           RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].Z_Q_F[1],
                           RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].Z_Q_F[2],
                           RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].Z_Q_F[3],
                           ChakanMeterNum);break;
    case 3: Show_FX_WUGONG(RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].F_Q_All,
                           RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].F_Q_F[0],
                           RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].F_Q_F[1],
                           RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].F_Q_F[2],
                           RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].F_Q_F[3],
                           ChakanMeterNum);break;
    case 4: Show_UI(RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].VA,
                    RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].VB,
                    RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].VC,
                    RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].IA,
                    RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].IB,
                    RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].IC,
                    ChakanMeterNum);break;
    case 5:      Show_PQC(RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].P,
                     RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].Q,
                     RtuDataAddr->DD_Device_BiaoShi_Value[ChakanMeterNum].Cos,
                     ChakanMeterNum);break;
    case 6:      Show_ZXU(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[ChakanMeterNum].Z_P_X_All,
                     RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[ChakanMeterNum].F_P_X_All,
                     ChakanMeterNum);break;
    default:break;
   }

     GUI_DispStringAt("(",16,144);
     GUI_DispStringAt(")",40,144);
     GUI_DispDecAt(ChakanMeterNum, 24, 144, 2);//���������ڱ��� ���ű�??

     memset(NowInput.buf,0,128);
	 sprintf(NowInput.buf,"%02x%02x%02x%02x%02x%x",   //16���Ƶ�BCD��
		RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[ChakanMeterNum].Addr[5],
		RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[ChakanMeterNum].Addr[4],
		RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[ChakanMeterNum].Addr[3],
		RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[ChakanMeterNum].Addr[2],
		RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[ChakanMeterNum].Addr[1],
		RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[ChakanMeterNum].Addr[0]);
      //  GUI_DispStringAt(NowInput.buf,48,143);//Ӧ����ʾ����ַ����

     Status_Bar();//Ȼ��״̬����Ȼ������ʾ�����ı��ţ����ǵ�һ���˵�����
     GUI_DispStringAt(NowInput.buf,48,144);//Ӧ����ʾ����ַ����

     Lcmfull();
     keysele=KeySeleflag;
     KeySeleflag =0;
      if(DelayTime>=PageDelayTime)
		       {
		       	OldLevel=0;
		       	return;
		       	}
		   switch(keysele)
		   {
		   case 0:DelayTime++;break;
		   case 1: if(i==0) i=0; else i=(i-1)%7 ;DelayTime=0; break;
	       case 2: if(i==6) i=6; else i=(i+1)%7 ;DelayTime=0; break;
		   case 3: DelayTime=0;break;
		   case 4: DelayTime=0;break;
		   case 5: DelayTime=0;break;
		   case 6: OldLevel=0;return;break;
		   default:break;
		   }
  }
}

/******************************************************************************************************************
* �������ƣ�ShowMeterSetting()
* ��    �ܣ�״̬������Ϊ��������ʾ�ź�ǿ�ȣ�ͨѶ��ʽ���澯�¼��빦�������ԣ�ʱ�䣫����
* ��ڲ������ޡ�����������������ʾ���˵�ѡ��Ĳ˵�������ҳ��־
* ���ڲ�������
/*******************************************************************************************************************/
int ShowMeterSetting(INT8U SeleMenu)
{
   unsigned char keysele,i;
    unsigned int DelayTime;
   i=0;
   DelayTime=0;
   GUI_Clear();//������
   GUI_DispStringAt("��  :", 16, 24);
   GUI_DispStringAt("��Լ:", 16, 40);
   GUI_DispStringAt("����:", 16, 56);
   GUI_DispStringAt("�˿�:", 16, 72);
   GUI_DispStringAt("����:", 16, 88);
   GUI_DispStringAt("����������:", 16, 104);
   GUI_DispStringAt("�������:  ����", 16, 120);
   while(1)

  {
       GUI_SetTextMode(GUI_TM_REV);
       GUI_DispDecAt(i, 32, 24, 2);
       GUI_SetTextMode(GUI_TM_NORMAL);
        memset(NowInput.buf,0,128);
			sprintf(NowInput.buf,"%02x%02x%02x%02x%02x%02x",   //16���Ƶ�BCD��
			RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Addr[5],
			RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Addr[4],
	    	RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Addr[3],
			RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Addr[2],
		    RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Addr[1],
			RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Addr[0]);  //����ת����Ϊ�ַ���
	        GUI_DispStringAt(NowInput.buf,56,24);//Ӧ����ʾ����ַ


       GUI_DispDecAt(RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].GuiYue_Type,56,40,2);
 /*   	switch(RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].GuiYue_Type)
		{  case 0:
			GUI_DispStringAt("       δ�ӱ�",56,40);break;
		   case 1:
			GUI_DispStringAt("DL/T645-1997",56,40);break;
		   case 2:
			GUI_DispStringAt("     ��������",56,40);break;
		   case 3:
			GUI_DispStringAt("     ��ʤ��Լ",56,40);break;
		   case 4:
			GUI_DispStringAt("������LDZ_ZMC",56,40);break;
		   case 5:
			GUI_DispStringAt("       ������",56,40);break;
			default:break;
		 }
*/

        switch(((RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].BaudAndPort&0xe0)>>5)&0x7)
		{  case 1:
			GUI_DispStringAt(" 600", 56, 56);break;//Ӧ����ʾͨѶ����
		   case 3:
			 GUI_DispStringAt("2400", 56, 56);break;//Ӧ����ʾͨѶ����
		   case 4:
			GUI_DispStringAt("4800", 56, 56);break;//Ӧ����ʾͨѶ����
		   case 5:
			 GUI_DispStringAt("7200", 56, 56);break;//Ӧ����ʾͨѶ����
		   case 6:
			GUI_DispStringAt("9600", 56, 56);break;//Ӧ����ʾͨѶ����
		  default:
			GUI_DispStringAt("1200", 56, 56);break;//Ӧ����ʾͨѶ����
		}

  		GUI_DispDecAt(((RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].BaudAndPort))&0x1f , 56, 72, 2);

	        memset(NowInput.buf,0,128);
			sprintf(NowInput.buf,"%02x%02x%02x%02x%02x%02x",   //16���Ƶ�BCD��
			RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Passwd[5],
			RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Passwd[4],
	    	RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Passwd[3],
			RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Passwd[2],
		    RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Passwd[1],
			RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Passwd[0]);  //����ת����Ϊ�ַ���
	        GUI_DispStringAt(NowInput.buf,56,88);//Ӧ����ʾ����ַ

	   GUI_DispDecAt(((RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].CeLiangNo)) , 104, 104, 2);

    		   memset(NowInput.buf,0,128);
				sprintf(NowInput.buf,"%02d",
						RtuDataAddr->Fk_Control_Set_Value.F24_Set_Para.Zhong_Duan_ChaoBiao_Jiange
					);  //����ת����Ϊ�ַ���
				GUI_DispStringAt(NowInput.buf,88,120);

   	 Status_Bar();
     Lcmfull();
     //OSSemPend(KeySem,50,&err);
     keysele=KeySeleflag;
     KeySeleflag =0;
     if(DelayTime>=PageDelayTime)
		       {
		       	OldLevel=0;
		       	return 0;
		       	}
 //RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num
 //DD_Device_Max
		   switch(keysele)
		   {
		   case 0:DelayTime++;break;
		   case 1: if(i!=0)  i=(i-1)%RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num ;DelayTime=0; break;
	       case 2: if(i!=RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num) i=(i+1)%RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num ;DelayTime=0; break;
		   case 3: DelayTime=0;break;
		   case 4: DelayTime=0;break;
		   case 5: DelayTime=0;break;
		   case 6: OldLevel=0;return 0;break;
		   default:break;
		   }


  }

}
/******************************************************************************************************************
* �������ƣ�Show_TXcanshu() ���ڵ�һ���˵�
* ��    �ܣ�����ʾ����ͨ�Ų�����
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void Show_TXcanshu(void)
{
    INT8U keysele;
    INT8U TempBuf[16];
    INT8U x;
    unsigned int DelayTime;
    DelayTime=0;
     while(1)
     {
	    GUI_Clear();//������
	    Status_Bar();//��д״̬����Ȼ����д�����ġ�GPRS����ͨ�š����ǵ�һ���˵�����

     switch(TongDaoLeiXing)
     {
     	case 0:

                GUI_DispStringAt("GPRS����ͨ��", 32, 144);
				GUI_DispStringAt("APN:", 0, 17);
				GUI_DispStringAt("��վIP�˿�:", 0, 35);
				GUI_DispStringAt("��������:  ����", 0, 53);
				GUI_DispStringAt("��������:", 0, 71);
				GUI_DispStringAt("��վIP��ַ:", 0, 89);
				GUI_DispStringAt("����ģʽ:", 0, 125);
				//apn
				GUI_DispStringAt(RtuDataAddr->FkComm_Value.F3_Set_Para.APN,32,17);
				//port
		  	    memset(TempBuf,0,16);
				sprintf(TempBuf,"%05d",
					(RtuDataAddr->FkComm_Value.F3_Set_Para.PortMaster[1]<<8)+RtuDataAddr->FkComm_Value.F3_Set_Para.PortMaster[0]);  //����ת����Ϊ�ַ���
				GUI_DispStringAt(TempBuf,88,35);
			    //Heart
			    memset(TempBuf,0,16);
				sprintf(TempBuf,"%02d",RtuDataAddr->FkComm_Value.F1_Set_Para.Heart_Beat);  //����ת����Ϊ�ַ���
				GUI_DispStringAt(TempBuf,72,53);
                //����
				memset(TempBuf,0,16);
				sprintf(TempBuf,"%02x%02x%02x%02x%02x%1x",
					RtuDataAddr->FkComm_Value.F4_Set_Para.DuanXin[0],
				    RtuDataAddr->FkComm_Value.F4_Set_Para.DuanXin[1],
				    RtuDataAddr->FkComm_Value.F4_Set_Para.DuanXin[2],
				    RtuDataAddr->FkComm_Value.F4_Set_Para.DuanXin[3],
				    RtuDataAddr->FkComm_Value.F4_Set_Para.DuanXin[4],
				    RtuDataAddr->FkComm_Value.F4_Set_Para.DuanXin[5]>>4);  //����ת����Ϊ�ַ���
				GUI_DispStringAt(TempBuf,72,71);
				//ip
				x=24;
				GUI_DispDecAt(RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[0],x,107,3);
				GUI_DispCharAt('.',x+24,108);
				GUI_DispDecAt(RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[1],x+24+4,107,3);
				GUI_DispCharAt('.',x+48+4,108);
				GUI_DispDecAt(RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[2],x+48+8,107,3);
				GUI_DispCharAt('.',x+72+8,108);
				GUI_DispDecAt(RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[3],x+84,107,3);

		        //����ģʽ
		       switch(RtuDataAddr->FkComm_Value.F8_Set_Para.GPRS_MODE)
				{
				 case 1:GUI_DispStringAt("��������", 72, 126);break;
				 case 2:GUI_DispStringAt("��������", 72, 126);break;
				 default:GUI_DispStringAt("��������", 72, 126);break;
				}

		break;
		case 1:
               GUI_DispStringAt("PSTN����ͨ��", 32, 145);
        break;
		default :break;

     }
    	 Lcmfull();
	     keysele=KeySeleflag;
	     KeySeleflag =0;

       if(DelayTime>=(PageDelayTime/2))
		       {
		       	OldLevel=0;
		       	 GUI_Clear();
				 GUI_DispStringAt("�ɼ�����ʶ",40,18);
				 GUI_DispStringAt("�ɼ���ַ:",24,36);
				 GUI_DispStringAt("ͨ����λ��:",20,54);
				 GUI_DispStringAt("ͨ������",48,72);
		       	return;
		       	}
		   switch(keysele)
		   {
		   case 0:DelayTime++;break;
		   case 1: DelayTime=0; break;
	       case 2: DelayTime=0; break;
		   case 3: DelayTime=0;break;
		   case 4: DelayTime=0;break;
		   case 5: DelayTime=0;break;
		   case 6:
		   OldLevel=0;
		   GUI_Clear();
		   GUI_DispStringAt("�ɼ�����ʶ",40,18);
		   GUI_DispStringAt("�ɼ���ַ:",24,36);
		   GUI_DispStringAt("ͨ����λ��:",20,54);
		   GUI_DispStringAt("ͨ������",48,72);
		   return ;
		   break;
		   default:break;
		   }

     }

}
/******************************************************************************************************************
* �������ƣ�Show_TX_canshu() ���ڵ�һ���˵�
* ��    �ܣ�����ʾ����ͨ�Ų�����GPRS���á�PSTN���á�CDMA���á�
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
int Show_TX_canshu(INT8U SeleMenu)
{
	INT8U keysele;
	INT8U TempBuf[16];
	INT16U tmpaddr;
	unsigned int DelayTime;
    DelayTime=0;
     GUI_Clear();
     GUI_DispStringAt("�ն˱�ʶ",48,18);
	 GUI_DispStringAt("�ն˵�ַ:",24,36);
	 GUI_DispStringAt("������λ��:",20,54);
	 GUI_DispStringAt("ͨ������",48,72);

     while(1)
     {
 	     keysele=KeySeleflag;
	     KeySeleflag =0;
	     if(DelayTime>=PageDelayTime)
		       {
		       	OldLevel=0;
		       	return 0;
		       	}

		 switch(keysele)
		   {
		   case 0:DelayTime++;break;
		   case 1: DelayTime=0; break;
	       case 2: DelayTime=0; break;
		   case 3: DelayTime=0;break;
		   case 4: DelayTime=0;break;
		   case 5: Show_TXcanshu(); break;
		   case 6: OldLevel=0;return 0;break;
		   default:break;
		   }

      Status_Bar();
	  tmpaddr= (RtuDataAddr->FkComm_Value.ADDR[1]<<8)+ RtuDataAddr->FkComm_Value.ADDR[0];


	      memset(TempBuf,0,16);
				sprintf(TempBuf,"%05d",tmpaddr);
					GUI_DispStringAt(TempBuf,98,36);


            memset(TempBuf,0,16);
				sprintf(TempBuf,"%02x%02x",
					 RtuDataAddr->FkComm_Value.GB22601991[0],
					 RtuDataAddr->FkComm_Value.GB22601991[1]
					);  //����ת����Ϊ�ַ���
				GUI_DispStringAt(TempBuf,108,54);


         if(TongDaoLeiXing==0)
	 {
	          GUI_SetTextMode(GUI_TM_REV);
			  GUI_DispStringAt("GPRS",64,90);
	 }
 /*      if(TongDaoLeiXing==1)
	 {
	              GUI_SetTextMode(GUI_TM_REV);
			  GUI_DispStringAt("PSTN",64,90);//("PSTN",64,108);
	 }
	 if(TongDaoLeiXing==2)
	 {
	              GUI_SetTextMode(GUI_TM_REV);
			  GUI_DispStringAt("CDMA",64,90);//("CDMA",64,126);
	 }
 */
      GUI_SetTextMode(GUI_TM_NORMAL);


    Lcmfull();


     }

}


/******************************************************************************************************************
* �������ƣ�Status_Bar()
* ��    �ܣ�״̬������Ϊ��������ʾ�ź�ǿ�ȣ�ͨѶ��ʽ���澯�¼��빦�������ԣ�ʱ�䣫����
* ��ڲ������ޡ�����������������ʾ���˵�ѡ��Ĳ˵�������ҳ��־
* ���ڲ�������
/*******************************************************************************************************************/
void Status_Bar(void)
{
    int i;
	INT8U str[2];
	INT8U tl[8],TERC[64],k;
	INT8U Warning,Warn[64];//�澯�¼���־
	TS ts;

//	time_t time_of_day;
 //   unsigned char toe[24];
 //   struct tm *tz;
 //    time_of_day = time( NULL);
 //    tz = localtime( &time_of_day );

	TSGet(&ts);
    //tsbak=ts.Sec;
    memset(str,0,sizeof(str));
    memset(TERC,0,sizeof(TERC));
    memset(Warn,0,sizeof(Warn));
    Warning=0;

/*************************��ʾʱ��****************** *********��ʼ**/
	GUI_DispDecAt(ts.Hour , 96, 0, 2);
	GUI_DispDecAt(ts.Minute , 120, 0, 2);
	GUI_DispDecAt(ts.Sec , 144, 0, 2);
//	GUI_DispDecAt(tz->tm_hour , 88, 0, 2);
//	GUI_DispDecAt(tz->tm_min , 112, 0, 2);
//	GUI_DispDecAt(tz->tm_sec , 136, 0, 2);
	GUI_DispStringAt(":", 112, 0);
    GUI_DispStringAt(":", 136, 0);
/*************************��ʾʱ��****************** *********����**/
/*************************��ʾ�ź�ǿ��*************** *********��ʼ**/
    if(RtuDataAddr->Gprs_ok)
    {
    	str[0]=0x1c;
        GUI_DispStringAt(str, 12, 0);//��ʾ����
    }

      if(RtuDataAddr->GprsCSQ>=24)
      {
      	GUI_DrawVLine( 10, 2, 13);
      	GUI_DrawVLine( 9, 2, 13);
      }
       if(RtuDataAddr->GprsCSQ>=16)
      {
       GUI_DrawVLine( 7,  5, 13);
       GUI_DrawVLine( 6,  5, 13);
      }
      if(RtuDataAddr->GprsCSQ>=8)
      {
       GUI_DrawVLine( 4,  8, 13);
       GUI_DrawVLine( 3,  8, 13);
      }
      if(RtuDataAddr->GprsCSQ>0)
      {
       GUI_DrawVLine( 1,  10, 13);
       GUI_DrawVLine( 0,  10, 13);
      }

/*************************��ʾ�ź�ǿ��*************** *********����**/
/*************************��ʾͨ�ŷ�ʽ GPRS TCp CDMA *********��ʼ**/

	    switch(RtuDataAddr->ModuleType)
		{
		case 1://��ʾGΪGprs ͨѶ��ʽ
		    str[0]=0x1e;
		    GUI_DispStringAt(str, 25, 0);//x+8
			GUI_DrawHLine( 22, 0, 34);//
	    	GUI_DrawVLine( 22, 0, 14);//
			GUI_DrawVLine( 34, 0, 14);//
		    break;
		case 3://��ʾLΪ��̫������ ͨѶ��ʽ
		    str[0]=0x1f;
		    GUI_DispStringAt(str, 25, 0);//x+8
			GUI_DrawHLine( 22, 0, 34);//
	    	GUI_DrawVLine( 22, 0, 14);//
			GUI_DrawVLine( 34, 0, 14);//
			break;
		case 2://��ʾCΪCDMA ͨѶ��ʽ
		    str[0]=0x1d;
		    GUI_DispStringAt(str, 25, 0);//x+8
			GUI_DrawHLine( 22, 0, 34);//
	    	GUI_DrawVLine( 22, 0, 14);//
			GUI_DrawVLine( 34, 0, 14);//
			break;
		default:
		    GUI_DispStringAt("  ", 22, 0);//x+8
		break;

		}

/*************************��ʾͨ�ŷ�ʽ��� GPRS PSDN CDMA *********����**/
/*************************��ʾ���� *********��ʼ**/

      if( RtuDataAddr->FuKong_Control_Value.F25_Control_Para.Valid==1)
	   {
		str[0]=0x1b;
		GUI_DispStringAt(str, 83, 0);//x+8
		GUI_DrawHLine( 80, 0, 93);//
	    GUI_DrawVLine( 80, 0, 14);//
		GUI_DrawVLine( 93, 0, 14);//
	   }
	   else
	   GUI_DispStringAt("  ", 80, 0);

/*************************��ʾ���� *********����**/

/*************************��ʾ**�澯�¼���̾�ţ��루�¼������룩����***��ʼ**/

	for(i=0;i<4;i++)
	{
	   tl[i]=RtuDataAddr->ERCBiaoZhi[i];
	   if(tl[i]!=0)
	   {
	   	  for(k=0;k<8;k++)
	   	  {
		   	  	if((tl[i]&0x01)==0x01)
		   	  	 {
		   	  	 	Warn[Warning]=8*i+k+1;
		   	  	 //	printf("warn[%d]=%d\r\n",Warning,Warn[Warning]);
		   	  	    Warning=Warning+1;//Warning ������ж��ٸ��¼���Waring[]������¼�����
		   	  	  }
	   	            tl[i]=(tl[i]>>1);
 	   	  }

	   }//if
	}//for
 	   if (Warning >= 1)
	   {
 			     if (ts.Sec %2==0)
			     {//��ʾ̾��
			     	str[0]=0x7b;
			        str[1]=0x7c;
			        GUI_DispStringAt(str,39,0);
			        GUI_DispStringAt("   ",55,0);
			      }
	             else //������������
			      {
			      	        GUI_DispStringAt("     ",39,0);
			      	    //    GUI_DispStringAt("ERC",39,0);
					   /*           	switch(LcdK)
						        {
						        	case 0:GUI_DispDecAt(Warn[0], 63, 0, 2);break;
						        	case 1:GUI_DispDecAt(Warn[1], 63, 0, 2);break;
						        	case 2:GUI_DispDecAt(Warn[2], 63, 0, 2);break;
						        	case 3:GUI_DispDecAt(Warn[3], 63, 0, 2);break;
						        	case 4:GUI_DispDecAt(Warn[4], 63, 0, 2);break;
						        	case 5:GUI_DispDecAt(Warn[5], 63, 0, 2);break;
						        	case 6:GUI_DispDecAt(Warn[6], 63, 0, 2);break;
						        	case 7:GUI_DispDecAt(Warn[7], 63, 0, 2);break;
						        	case 8:GUI_DispDecAt(Warn[8], 63, 0, 2);break;
						        	case 9:GUI_DispDecAt(Warn[9], 63, 0, 2);break;
						        	case 10:GUI_DispDecAt(Warn[10], 63, 0, 2);break;
						        	case 11:GUI_DispDecAt(Warn[11], 63, 0, 2);break;
						        	case 12:GUI_DispDecAt(Warn[12], 63, 0, 2);break;
						        	case 13:GUI_DispDecAt(Warn[13], 63, 0, 2);break;
						        	case 14:GUI_DispDecAt(Warn[14], 63, 0, 2);break;
						        	case 15:GUI_DispDecAt(Warn[15], 63, 0, 2);break;
						        	case 16:GUI_DispDecAt(Warn[16], 63, 0, 2);break;
						        	case 17:GUI_DispDecAt(Warn[17], 63, 0, 2);break;
						        	case 18:GUI_DispDecAt(Warn[18], 63, 0, 2);break;
						        	case 19:GUI_DispDecAt(Warn[19], 63, 0, 2);break;
						        	case 20:GUI_DispDecAt(Warn[20], 63, 0, 2);break;
						            case 21:GUI_DispDecAt(Warn[21], 63, 0, 2);break;
						        	case 22:GUI_DispDecAt(Warn[22], 63, 0, 2);break;
						        	case 23:GUI_DispDecAt(Warn[23], 63, 0, 2);break;
						        	case 24:GUI_DispDecAt(Warn[24], 63, 0, 2);break;
						        	case 25:GUI_DispDecAt(Warn[25], 63, 0, 2);break;
						        	case 26:GUI_DispDecAt(Warn[26], 63, 0, 2);break;
						        	case 27:GUI_DispDecAt(Warn[27], 63, 0, 2);break;
						        	case 28:GUI_DispDecAt(Warn[28], 63, 0, 2);break;
						        	case 29:GUI_DispDecAt(Warn[29], 63, 0, 2);break;
						            case 30:GUI_DispDecAt(Warn[30], 63, 0, 2);break;
						        	case 31:GUI_DispDecAt(Warn[31], 63, 0, 2);break;
						            default :break;
						        }*/
				                LcdK=((LcdK+1)%(Warning));
			      }
      }
/*************************��ʾ**�澯�¼���̾�ţ��루�¼������룩����***����**/

    GUI_DrawHLine( 0, 15, 159); //(x,y,y1)��������
 	GUI_DrawHLine( 0, 143, 159); //��������

 }

/******************************************************************************************************************
* �������ƣ�RunArrow()
* ��    �ܣ�������ʾ���ϼ�ͷ�����ߡ��¼�ͷ�����ߡ����¼�ͷ��
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/

void RunArrow(INT8U Arrow)

{
   	INT8U str[1];
    memset(str,0,sizeof(str));
    switch(Arrow)
    {
    	case 1:str[0]=0x7e;break;
    	case 2:str[0]=0x7f;break;
    	case 3:str[0]=0x7d;break;
    	default:break;
    }

    GUI_DispStringAt(&str[0],151,144);
}
/******************************************************************************************************************
* �������ƣ�Fb_ChaobiaoSet(INT8U SelMenu)
* ��    �ܣ�������ʾ��Լ�����ʡ��˿ںš�ͨѶ���롢���������㣬���������������
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void Fb_ChaobiaoSet(INT8U SelMenu)
{
       // INT8U i;
      //   GUI_Clear();
      //   GUI_DispStringAt("��  :",16,24);
      //   GUI_DispStringAt("��Լ:",16,40);
      //   GUI_DispStringAt("����:",16,56);
      //   GUI_DispStringAt("�˿�:",16,72);
      //   GUI_DispStringAt("����:",16,88);
      //   GUI_DispStringAt("����������:",16,104);
            GUI_DispDecAt(ChakanMeterSetNum, 32, 24, 2);//��ʾ�������

	   	    memset(NowInput.buf,0,128);
			sprintf(NowInput.buf,"%02x%02x%02x%02x%02x%02x",   //16���Ƶ�BCD��
			FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Addr[5],
			FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Addr[4],
	    	FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Addr[3],
			FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Addr[2],
		    FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Addr[1],
			FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Addr[0]);  //����ת����Ϊ�ַ���
			 if(SelMenu==51)//��ʾ����ַ
				 {
				    GUI_SetTextMode(GUI_TM_REV);
					GUI_DispStringAt(NowInput.buf,56,24);
				 }
			  else
			         GUI_DispStringAt(NowInput.buf,56,24);
		         GUI_SetTextMode(GUI_TM_NORMAL);


        memset(NowInput.buf,0,128);
		sprintf(NowInput.buf,"%02d",   //16���Ƶ�BCD��
		FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].GuiYue_Type);  //����ת����Ϊ�ַ���
		 if(SelMenu==52)//��ʾ����Լ
			 {
			    GUI_SetTextMode(GUI_TM_REV);
				GUI_DispStringAt(NowInput.buf,56,40);
			 }
		  else
		         GUI_DispStringAt(NowInput.buf,56,40);
		         GUI_SetTextMode(GUI_TM_NORMAL);

        memset(NowInput.buf,0,128);
		sprintf(NowInput.buf,"%02d",   //16���Ƶ�BCD��
		((FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].BaudAndPort&0xe0)>>5)&0x7);  //����ת����Ϊ�ַ���
		 if(SelMenu==53)//��ʾ������
			 {
			    GUI_SetTextMode(GUI_TM_REV);
				GUI_DispStringAt(NowInput.buf,56,56);
			 }
		  else
		         GUI_DispStringAt(NowInput.buf,56,56);
		         GUI_SetTextMode(GUI_TM_NORMAL);


   	    memset(NowInput.buf,0,128);
		sprintf(NowInput.buf,"%02d",   //16���Ƶ�BCD��
		FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].BaudAndPort&0x1f);  //����ת����Ϊ�ַ���
		 if(SelMenu==54)//��ʾ���˿ں�
			 {
			    GUI_SetTextMode(GUI_TM_REV);
				GUI_DispStringAt(NowInput.buf,56,72);
			 }
		  else
		         GUI_DispStringAt(NowInput.buf,56,72);
		         GUI_SetTextMode(GUI_TM_NORMAL);


      	memset(NowInput.buf,0,128);
		sprintf(NowInput.buf,"%02x%02x%02x%02x%02x%02x",   //16���Ƶ�BCD��
		FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Passwd[5],
		FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Passwd[4],
		FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Passwd[3],
		FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Passwd[2],
		FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Passwd[1],
		FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Passwd[0]);  //����ת����Ϊ�ַ���
		 if(SelMenu==55)//��ʾ������
			 {
			    GUI_SetTextMode(GUI_TM_REV);
				GUI_DispStringAt(NowInput.buf,56,88);
			 }
		  else
		         GUI_DispStringAt(NowInput.buf,56,88);
		         GUI_SetTextMode(GUI_TM_NORMAL);

   	    memset(NowInput.buf,0,128);
		sprintf(NowInput.buf,"%02d",   //16���Ƶ�BCD��
		FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].CeLiangNo);  //����ת����Ϊ�ַ���
		 if(SelMenu==56)//��ʾ��������
			 {
			    GUI_SetTextMode(GUI_TM_REV);
				GUI_DispStringAt(NowInput.buf,104,104);
			 }
		  else
		         GUI_DispStringAt(NowInput.buf,104,104);
		         GUI_SetTextMode(GUI_TM_NORMAL);
		 memset(NowInput.buf,0,128);
		 Fk_Control_Set_ValueTmp.F24_Set_Para.Zhong_Duan_ChaoBiao_Jiange = RtuDataAddr->Fk_Control_Set_Value.F24_Set_Para.Zhong_Duan_ChaoBiao_Jiange;
		         		 //printf("\n\rFk_Control_Set_ValueTmp.F24_Set_Para.Zhong_Duan_ChaoBiao_Jiange=%d ",Fk_Control_Set_ValueTmp.F24_Set_Para.Zhong_Duan_ChaoBiao_Jiange);
		 sprintf(NowInput.buf,"%02d",
		 Fk_Control_Set_ValueTmp.F24_Set_Para.Zhong_Duan_ChaoBiao_Jiange);  //����ת����Ϊ�ַ���
		  if(SelMenu==68)//��ʾ��������
		  {
		         GUI_SetTextMode(GUI_TM_REV);
		         GUI_DispStringAt(NowInput.buf,88,120);
		  }
		  else
		         GUI_DispStringAt(NowInput.buf,88,120);
		         GUI_SetTextMode(GUI_TM_NORMAL);
/*
		 memset(NowInput.buf,0,128);
		 //memcpy(RtuDataAddr->Fk_Control_Set_Value.F7_Set_Para.ZhongDuan_ChaoBiao_Date,Fk_Control_Set_ValueTmp.F7_Set_Para.ZhongDuan_ChaoBiao_Date,sizeof(RtuDataAddr->Fk_Control_Set_Value.F7_Set_Para.ZhongDuan_ChaoBiao_Date));
		 sprintf(NowInput.buf,"%02d",
				 RtuDataAddr->Fk_Control_Set_Value.F7_Set_Para.ZhongDuan_ChaoBiao_Date);  //����ת����Ϊ�ַ���
		 if(SelMenu==76)//��ʾ��������
		 {
			 for(i=0;i<31;i++)
			 {
				 if(NowInput.buf[i])
				 {
					 GUI_SetTextMode(GUI_TM_REV);
					 //GUI_DispStringAt(NowInput.buf[i],88,120);
				 }
			 }
		 }

	if(SelMenu==10)
	 {
	  GUI_SetTextMode(GUI_TM_REV);
	  GUI_DispStringAt("�޸�",64,120);
	 }
 	else
	   GUI_DispStringAt("�޸�",64,120);
       GUI_SetTextMode(GUI_TM_NORMAL);
*/
}
/******************************************************************************************************************
* �������ƣ�Xiu_BiaoHao()�����ڵڶ����˵�
* ��    �ܣ����޸ġ����ľ������á������š�
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void Xiu_BiaoHao(INT8U SeleMenu)
{
/*
	INT8U i;
	memset(NowInput.buf,0,128);
	sprintf(NowInput.buf,"%02x%02x%02x%02x%02x%02x",   //16���Ƶ�BCD��
		FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Addr[5],
		FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Addr[4],
    	FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Addr[3],
		FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Addr[2],
	    FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Addr[1],
		FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Addr[0]);  //����ת����Ϊ�ַ���
		i=0;
		while(i<12)
		{

			     NowInput.col[i]=24;//y��
			     NowInput.row[i]=56+i*8;//x��
		    	 NowInput.set[i]=1;
			i++;
		}
		NowInput.AllNum=13;
		if(ScreenInput()==1)
		{
		 FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Addr[5]=GetNum(&NowInput.buf[0],2,3);
		 FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Addr[4]=GetNum(&NowInput.buf[2],2,3);
         FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Addr[3]=GetNum(&NowInput.buf[4],2,3);
		 FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Addr[2]=GetNum(&NowInput.buf[6],2,3);
         FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Addr[1]=GetNum(&NowInput.buf[8],2,3);
         FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Addr[0]=GetNum(&NowInput.buf[10],2,3);
		//��ʱ��� Lcmfull();
		//OSSemPost(FlushSem);
		RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[ChakanMeterSetNum]=FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum];
		RtuDataAddr->FkInput_Value.F10_Set_Para.Valid=1;
		RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num = DD_Device_Max;
		SaveFKSet();
		}
		*/

}
/******************************************************************************************************************
* �������ƣ�Xiu_BiaoGuiyue()�����ڵڶ����˵�
* ��    �ܣ����޸ġ����ľ������á�����Լ��
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void Xiu_BiaoGuiyue(INT8U SeleMenu)
{
	/*
  	INT8U i;
	memset(NowInput.buf,0,128);
	sprintf(NowInput.buf,"%02d",   //16���Ƶ�BCD��
		FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].GuiYue_Type);  //����ת����Ϊ�ַ���
		i=0;
		while(i<2)
		{

			     NowInput.col[i]=40;//y��
			     NowInput.row[i]=56+i*8;//x��
		    	 NowInput.set[i]=1;
			i++;
		}
		NowInput.AllNum=3;
		if(ScreenInput()==1)
		{
		 FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].GuiYue_Type=GetNum(&NowInput.buf[0],2,1);
		 //��ʱ���Lcmfull();
		//OSSemPost(FlushSem);
		RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[ChakanMeterSetNum]=FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum];
		RtuDataAddr->FkInput_Value.F10_Set_Para.Valid=1;
		RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num = DD_Device_Max;
		SaveFKSet();
		}
*/
}
/******************************************************************************************************************
* �������ƣ�Xiu_Biaoband()�����ڵڶ����˵�
* ��    �ܣ����޸ġ����ľ������á������ʡ�
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void Xiu_Biaoband(INT8U SeleMenu)
{/*
    unsigned char i,TmpBaud,TmpPort;
    TmpPort=FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].BaudAndPort&0x1F;
	memset(NowInput.buf,0,128);
	sprintf(NowInput.buf,"%02d",   //16���Ƶ�BCD��
		((FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].BaudAndPort&0xe0)>>5)&0x7);  //����ת����Ϊ�ַ���
		i=0;
		while(i<2)
		{

			     NowInput.col[i]=56;//y��
			     NowInput.row[i]=56+i*8;//x��
		    	 NowInput.set[i]=1;
			i++;
		}
		NowInput.AllNum=3;
		if(ScreenInput()==1)
		{
		 TmpBaud=GetNum(&NowInput.buf[0],2,1);
		 FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].BaudAndPort=TmpPort+(TmpBaud<<5);
		//��ʱ��� Lcmfull();
		RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[ChakanMeterSetNum]=FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum];
		RtuDataAddr->FkInput_Value.F10_Set_Para.Valid=1;
		RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num = DD_Device_Max;
		SaveFKSet(); }
*/
}
/******************************************************************************************************************
* �������ƣ�Xiu_Biaoport()�����ڵڶ����˵�
* ��    �ܣ����޸ġ����ľ������á����˿ڡ�
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void Xiu_Biaoport(INT8U SeleMenu)
{/*
    unsigned char i,TmpBaud,TmpPort;
    TmpBaud=FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].BaudAndPort&0xe0;
	memset(NowInput.buf,0,128);
	sprintf(NowInput.buf,"%02d",   //16���Ƶ�BCD��
		FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].BaudAndPort&0x1F);  //����ת����Ϊ�ַ���
		i=0;
		while(i<2)
		{

			     NowInput.col[i]=72;//y��
			     NowInput.row[i]=56+i*8;//x��
		    	 NowInput.set[i]=1;
			i++;
		}
		NowInput.AllNum=3;
		if(ScreenInput()==1)
		{
		 TmpPort=GetNum(&NowInput.buf[0],2,1);
		 FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].BaudAndPort=TmpPort+TmpBaud;
		 //��ʱ���Lcmfull();
		 RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[ChakanMeterSetNum]=FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum];
		RtuDataAddr->FkInput_Value.F10_Set_Para.Valid=1;
		RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num = DD_Device_Max;
		SaveFKSet(); }
*/
}
/******************************************************************************************************************
* �������ƣ�Xiu_BiaoPassword()�����ڵڶ����˵�
* ��    �ܣ����޸ġ����ľ������á������š�
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void Xiu_BiaoPassword(INT8U SeleMenu)
{
/*
	INT8U i;
	memset(NowInput.buf,0,128);
	sprintf(NowInput.buf,"%02x%02x%02x%02x%02x%02x",   //16���Ƶ�BCD��
		FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Passwd[5],
		FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Passwd[4],
    	FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Passwd[3],
		FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Passwd[2],
	    FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Passwd[1],
		FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Passwd[0]);  //����ת����Ϊ�ַ���
		i=0;
		while(i<12)
		{
			     NowInput.col[i]=88;//y��
			     NowInput.row[i]=56+i*8;//x��
		    	 NowInput.set[i]=1;
			i++;
		}
		NowInput.AllNum=13;
		if(ScreenInput()==1)
		{
		 FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Passwd[5]=GetNum(&NowInput.buf[0],2,2);
		 FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Passwd[4]=GetNum(&NowInput.buf[2],2,2);
         FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Passwd[3]=GetNum(&NowInput.buf[4],2,2);
		 FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Passwd[2]=GetNum(&NowInput.buf[6],2,2);
         FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Passwd[1]=GetNum(&NowInput.buf[8],2,2);
         FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].Passwd[0]=GetNum(&NowInput.buf[10],2,2);
		 //��ʱ���Lcmfull();
		//OSSemPost(FlushSem);
		RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[ChakanMeterSetNum]=FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum];
		RtuDataAddr->FkInput_Value.F10_Set_Para.Valid=1;
		RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num = DD_Device_Max;
		SaveFKSet(); }
*/
}
/******************************************************************************************************************
* �������ƣ�Xiu_BiaoCeliangdian()�����ڵڶ����˵�
* ��    �ܣ����޸ġ����ľ������á����˿ڡ�
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void Xiu_BiaoCeliangdian(INT8U SeleMenu)
{/*
    unsigned char i;
    memset(NowInput.buf,0,128);
	sprintf(NowInput.buf,"%02d",   //16���Ƶ�BCD��
		FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].CeLiangNo);  //����ת����Ϊ�ַ���
		i=0;
		while(i<2)
		{

			     NowInput.col[i]=104;//y��
			     NowInput.row[i]=104+i*8;//x��
		    	 NowInput.set[i]=1;
			i++;
		}
		NowInput.AllNum=3;
		if(ScreenInput()==1)
		{
		 FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum].CeLiangNo=GetNum(&NowInput.buf[0],2,1);
		 //��ʱ���Lcmfull();
		 RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[ChakanMeterSetNum]=FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum];
		 RtuDataAddr->FkInput_Value.F10_Set_Para.Valid=1;
		 RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num = DD_Device_Max;
		 SaveFKSet();
		}
*/
}
/******************************************************************************************************************
* �������ƣ�EnterXiuBiaoCanshu()
* ��    �ܣ�ȷ���޸ı��Ĳ���ô
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
 void EnterXiuBiaoCanshu(INT8U SeleMenu)
{
/*
    unsigned char i,Tpassword[2];
    unsigned int TmpPass=0;

	    memset(Tpassword,0,2);
	    GUI_Clear(); //������
    	GUI_DispStringAt("��������:",28,64);
    	memset(NowInput.buf,0,128);
  	    sprintf(NowInput.buf,"%02d%02d",   //16���Ƶ�BCD��
		Tpassword[0],Tpassword[1]);  //����ת����Ϊ�ַ���
		i=0;
		while(i<4)
		{

			     NowInput.col[i]=64;//y��
			     NowInput.row[i]=100+i*8;//x��
		    	 NowInput.set[i]=1;
			i++;
		}
		NowInput.AllNum=5;
		if(ScreenInput()==1)
		{
		 Tpassword[0]=GetNum(&NowInput.buf[0],2,1);
		 Tpassword[1]=GetNum(&NowInput.buf[2],2,1);
		 TmpPass=Tpassword[0]*100+Tpassword[1];
		 if(TmpPass!=PassWord)
           EnterXiuBiaoCanshu(SeleMenu);
		 }
		 else OldLevel = 0;

        if(TmpPass==PassWord)
         {
         	switch(Menu[SeleMenu].level)
         	{
         	case 11://�洢��������
            {
             RtuDataAddr->FkInput_Value.F10_Set_Para.Valid=1;
             RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num = DD_Device_Max;
             RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[ChakanMeterSetNum]=FkInput_ValueTmp.F10_Set_Para.Dian_Meter[ChakanMeterSetNum];

            }
            break;
            case 12://�洢ͨѶ��λ�룬�ɼ�����ַ
            {
            RtuDataAddr->FkComm_Value.ADDR[0]=FkComm_ValueTmp.ADDR[0];
            RtuDataAddr->FkComm_Value.ADDR[1]=FkComm_ValueTmp.ADDR[1];
            RtuDataAddr->FkComm_Value.GB22601991[0]=FkComm_ValueTmp.GB22601991[0];
            RtuDataAddr->FkComm_Value.GB22601991[1]=FkComm_ValueTmp.GB22601991[1];

            }
            break;
            case 13://�洢ͨѶ������apn ��ip�˿ڣ����ź��룬����ģʽ��ip
             {
            	RtuDataAddr->FkComm_Value.F1_Set_Para=FkComm_ValueTmp.F1_Set_Para;
            	RtuDataAddr->FkComm_Value.F3_Set_Para=FkComm_ValueTmp.F3_Set_Para;
            	RtuDataAddr->FkComm_Value.F4_Set_Para=FkComm_ValueTmp.F4_Set_Para;
            	RtuDataAddr->FkComm_Value.F8_Set_Para=FkComm_ValueTmp.F8_Set_Para;
                RtuDataAddr->FkComm_Value.F3_Set_Para.Valid=1;
            }
            break;
            case 15://�洢�������
            RtuDataAddr->Fk_Control_Set_Value.F24_Set_Para.Zhong_Duan_ChaoBiao_Jiange=Fk_Control_Set_ValueTmp.F24_Set_Para.Zhong_Duan_ChaoBiao_Jiange;
            break;
            case 18://�洢������
             RtuDataAddr->FkComm_Value.F11_Set_Para=FkComm_ValueTmp.F11_Set_Para;
            break;
            case 10://װ������ѡ���е������ݼ�Ӳ����λ���ָ�����ֵ
            {
            	switch(SeleMenu)
            	{
            	 case 44:printf("UIP\r\n");break;
            	 case 45:printf("Q\r\n");break;
            	 case 46:printf("ClearA\r\n");break;
            	 case 47:printf("ClearB\r\n");break;
            	 case 48:printf("ClearC\r\n");break;
            	 case 49:printf("Hard Reset\r\n");break;
            	 case 50:printf("Hui Fu Chu Chang Zhi\r\n");break;
            	 default:break;

            	}

            }
            break;
            default:break;
           }
           SaveFKSet();
            OldLevel = 0;
         }
*/
}
/******************************************************************************************************************
* �������ƣ�Set_TXcanshu()�����ڵڶ����˵�
* ��    �ܣ����޸ġ����ġ�ͨ�Ų�����
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void Set_TX_canshu(INT8U SelMenu)
{

     // INT8U taddr[3];
	  INT16U tmpaddr;

	GUI_DispStringAt("�ն˱�ʶ",48,18);

	GUI_DispStringAt("ͨ������",48,90);

	switch(TongDaoLeiXing)
	{case 0:GUI_DispStringAt("GPRS",64,108);break;
	 case 1:GUI_DispStringAt("PSTN",64,108);break;
	 case 2:GUI_DispStringAt("CDMA",64,108);break;
	 default:break;
	}

      tmpaddr = (FkComm_ValueTmp.ADDR[1]<<8)+FkComm_ValueTmp.ADDR[0];
  //    taddr[0]=tmpaddr/1000;
  //    taddr[1]=(tmpaddr-taddr[0]*1000)/10;
  //    taddr[2]=tmpaddr%10;
      memset(NowInput.buf,0,128);
				sprintf(NowInput.buf,"%05d",tmpaddr);
				//	taddr[0],
				//	taddr[1],
				//	taddr[2]);  //����ת����Ϊ�ַ���

	if(SelMenu==57)
	 {
	 GUI_SetTextMode(GUI_TM_REV);
	 GUI_DispStringAt(NowInput.buf,98,36);
	 }
 	else
	    GUI_DispStringAt(NowInput.buf,98,36);
	    GUI_SetTextMode(GUI_TM_NORMAL);


       memset(NowInput.buf,0,128);
		sprintf(NowInput.buf,"%02x%02x",
					FkComm_ValueTmp.GB22601991[0],
					FkComm_ValueTmp.GB22601991[1]
					);  //����ת����Ϊ�ַ���


	if(SelMenu==58)
	 {
	 GUI_SetTextMode(GUI_TM_REV);
	 GUI_DispStringAt(NowInput.buf,108,54);
	 }

	else
       GUI_DispStringAt(NowInput.buf,108,54);
       GUI_SetTextMode(GUI_TM_NORMAL);


     if(SelMenu==59)
	 {

	  GUI_SetTextMode(GUI_TM_REV);
	  GUI_DispStringAt("GPRS",64,108);

	 }

//	else
//	 GUI_DispStringAt("GPRS",64,108);
       GUI_SetTextMode(GUI_TM_NORMAL);

       if(SelMenu==60)
	 {

	 GUI_SetTextMode(GUI_TM_REV);
	 GUI_DispStringAt("PSTN",64,108);

	 }

//	else
//    GUI_DispStringAt("PSTN",64,108);
	 GUI_SetTextMode(GUI_TM_NORMAL);

	 if(SelMenu==61)
	 {

	 GUI_SetTextMode(GUI_TM_REV);
	 GUI_DispStringAt("CDMA",64,108);

	 }

//	else
//	 GUI_DispStringAt("CDMA",64,126);


     GUI_SetTextMode(GUI_TM_NORMAL);


     if(SelMenu==11)
	 {
	  GUI_SetTextMode(GUI_TM_REV);
	  GUI_DispStringAt("�޸�",64,72);
	 }
 	else
	   GUI_DispStringAt("�޸�",64,72);
       GUI_SetTextMode(GUI_TM_NORMAL);



}
/******************************************************************************************************************
* �������ƣ�Set_CB_jiangeshijian()�����ڵڶ����˵�
* ��    �ܣ�������ѡ����ʾ�����ġ����ʱ�䡿������ʱ�䡿
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void Set_CB_jiangeshijian(INT8U SelMenu)
{

      INT8U DongJie;

         memset(NowInput.buf,0,128);
				sprintf(NowInput.buf,"%02d",
						RtuDataAddr->Fk_Control_Set_Value.F24_Set_Para.Zhong_Duan_ChaoBiao_Jiange
					);  //����ת����Ϊ�ַ���

	if(SelMenu==68)
	 {
	 GUI_SetTextMode(GUI_TM_REV);
	 GUI_DispStringAt(NowInput.buf,100,40);
	 }

	else
     GUI_DispStringAt(NowInput.buf,100,40);
     GUI_SetTextMode(GUI_TM_NORMAL);

    switch(RtuDataAddr->Cl_MenXian_Value[0].F27_Set_Para.DongJieMiDu[0])
				{
					case 0:DongJie=0;break;
					case 1:DongJie=15;break;
					case 2:DongJie=30;break;
					case 3:DongJie=60;break;
					default:DongJie=0;break;

				}
	    memset(NowInput.buf,0,128);
		sprintf(NowInput.buf,"%02d",
					DongJie
					);  //����ת����Ϊ�ַ���

	if(SelMenu==69)
	 {
	 GUI_SetTextMode(GUI_TM_REV);
						GUI_DispStringAt(NowInput.buf,100,64);
	 }

	else
      GUI_DispStringAt(NowInput.buf,100,64);
      GUI_SetTextMode(GUI_TM_NORMAL);


}
/******************************************************************************************************************
* �������ƣ�Set_TXGPRS_canshufb()
* ��    �ܣ�����ʾ��������ͨ�Ų�����ѡ���еġ�GPRSѡ���еķ��ס�
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void Set_TXGPRS_canshufb(INT8U SelMenu)
{
	INT8U TempBuf[32];
	//INT8U x;

	if(SelMenu==62)  //apn
		{
			GUI_DispStringAt("                ",32,18); //�򵥸Ķ���

			GUI_SetTextMode(GUI_TM_REV);
			GUI_DispStringAt(FkComm_ValueTmp.F3_Set_Para.APN,32,18);
            GUI_SetTextMode(GUI_TM_NORMAL);
		}
	else
		{
		  GUI_DispStringAt(FkComm_ValueTmp.F3_Set_Para.APN,32,18);
		}


	 if(SelMenu==63)  //port
		{

			    memset(TempBuf,0,32);
				GUI_SetTextMode(GUI_TM_REV);
					sprintf(TempBuf,"%05d",
						(FkComm_ValueTmp.F3_Set_Para.PortMaster[1]<<8)+FkComm_ValueTmp.F3_Set_Para.PortMaster[0]);  //����ת����Ϊ�ַ���
	        	GUI_DispStringAt(TempBuf,88,36);    //port
	            GUI_SetTextMode(GUI_TM_NORMAL);

		}
	else
		{

				memset(TempBuf,0,32);
				sprintf(TempBuf,"%05d",
						(FkComm_ValueTmp.F3_Set_Para.PortMaster[1]<<8)+FkComm_ValueTmp.F3_Set_Para.PortMaster[0]);  //����ת����Ϊ�ַ���
				GUI_DispStringAt(TempBuf,88,36);


		}

	if(SelMenu==64)  //heart
		{
			memset(TempBuf,0,32);
			GUI_SetTextMode(GUI_TM_REV);
			sprintf(TempBuf,"%02d",FkComm_ValueTmp.F1_Set_Para.Heart_Beat);  //����ת����Ϊ�ַ���
			GUI_DispStringAt(TempBuf,72,54);    //Heart
            GUI_SetTextMode(GUI_TM_NORMAL);
		}
	else
		{

			memset(TempBuf,0,32);
			sprintf(TempBuf,"%02d",FkComm_ValueTmp.F1_Set_Para.Heart_Beat);  //����ת����Ϊ�ַ���
			GUI_DispStringAt(TempBuf,72,54);


		}

	if(SelMenu==65)  //����
		{
			//INT8U TempBuf[16];
			GUI_SetTextMode(GUI_TM_REV);
	        sprintf(TempBuf,"%02x%02x%02x%02x%02x%1x",
			        FkComm_ValueTmp.F4_Set_Para.DuanXin[0],
				    FkComm_ValueTmp.F4_Set_Para.DuanXin[1],
				    FkComm_ValueTmp.F4_Set_Para.DuanXin[2],
				    FkComm_ValueTmp.F4_Set_Para.DuanXin[3],
				    FkComm_ValueTmp.F4_Set_Para.DuanXin[4],
				    FkComm_ValueTmp.F4_Set_Para.DuanXin[5]>>4);  //����ת����Ϊ�ַ���
			GUI_DispStringAt(TempBuf,72,72);    //����
            GUI_SetTextMode(GUI_TM_NORMAL);
		}
		else
		{
			memset(TempBuf,0,32);
        	sprintf(TempBuf,"%02x%02x%02x%02x%02x%1x",
		            FkComm_ValueTmp.F4_Set_Para.DuanXin[0],
				    FkComm_ValueTmp.F4_Set_Para.DuanXin[1],
				    FkComm_ValueTmp.F4_Set_Para.DuanXin[2],
				    FkComm_ValueTmp.F4_Set_Para.DuanXin[3],
				    FkComm_ValueTmp.F4_Set_Para.DuanXin[4],
				    FkComm_ValueTmp.F4_Set_Para.DuanXin[5]>>4);  //����ת����Ϊ�ַ���
	        GUI_DispStringAt(TempBuf,72,72);

		}


     if(SelMenu==66)  //ip
	{

		  GUI_SetTextMode(GUI_TM_REV);
		    sprintf(TempBuf,"%03d.%03d.%03d.%03d",
			        FkComm_ValueTmp.F3_Set_Para.IPMaster[0],
				    FkComm_ValueTmp.F3_Set_Para.IPMaster[1],
				    FkComm_ValueTmp.F3_Set_Para.IPMaster[2],
				    FkComm_ValueTmp.F3_Set_Para.IPMaster[3]);  //����ת����Ϊ�ַ���
			GUI_DispStringAt(TempBuf,24,90);

		GUI_SetTextMode(GUI_TM_NORMAL);
	}
	else
	{
		     sprintf(TempBuf,"%03d.%03d.%03d.%03d",
			        FkComm_ValueTmp.F3_Set_Para.IPMaster[0],
				    FkComm_ValueTmp.F3_Set_Para.IPMaster[1],
				    FkComm_ValueTmp.F3_Set_Para.IPMaster[2],
				    FkComm_ValueTmp.F3_Set_Para.IPMaster[3]);  //����ת����Ϊ�ַ���
			GUI_DispStringAt(TempBuf,24,90);

	}


	if(SelMenu==67)  //����ģʽ
	{

		GUI_SetTextMode(GUI_TM_REV);
		switch(FkComm_ValueTmp.F8_Set_Para.GPRS_MODE)
		{case 1:GUI_DispStringAt("��������", 72, 108);break;
		 case 2:GUI_DispStringAt("��������", 72, 108);break;
		 default:GUI_DispStringAt("��������", 72, 108);break;
		}
		GUI_SetTextMode(GUI_TM_NORMAL);
	}
	else
	{
		switch(FkComm_ValueTmp.F8_Set_Para.GPRS_MODE)
		{
		 case 1:GUI_DispStringAt("��������", 72, 108);break;
		 case 2:GUI_DispStringAt("��������", 72, 108);break;
		 default:GUI_DispStringAt("��������", 72, 108);break;
		}

	}

	if(SelMenu==12)
	 {
	  GUI_SetTextMode(GUI_TM_REV);
	  GUI_DispStringAt("�޸�",64,124);
	 }
 	else
	   GUI_DispStringAt("�޸�",64,124);
       GUI_SetTextMode(GUI_TM_NORMAL);

}
/******************************************************************************************************************
* �������ƣ�Xiu_Txaddr()�����ڵڶ����˵�
* ��    �ܣ����޸ġ�ͨѶ���� ���ɼ���ַ��
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void Xiu_Txaddr(INT8U SeleMenu)
{
	/*
  	   INT8U i;
  	   INT8U taddr[3];
	   INT16U tmpaddr;


      tmpaddr= (FkComm_ValueTmp.ADDR[1]<<8)+FkComm_ValueTmp.ADDR[0];
      taddr[0]=tmpaddr/1000;
      taddr[1]=(tmpaddr-taddr[0]*1000)/10;
      taddr[2]=tmpaddr%10;

        memset(NowInput.buf,0,128);
        sprintf(NowInput.buf,"%02d%02d%1d",
					taddr[0],
					taddr[1],
					taddr[2]);  //����ת����Ϊ�ַ���

		i=0;
		while(i<5)
		{

			     NowInput.col[i]=36;//y��
			     NowInput.row[i]=98+i*8;//x��

		     	NowInput.set[i]=1;
			i++;
		}

		NowInput.AllNum=6;
		if(ScreenInput()==1)
		{
			for(i=0;i<2;i++)
			{
				taddr[i]=GetNum(&NowInput.buf[2*i],2,1);
			}

			    taddr[2]=GetNum(&NowInput.buf[4],1,1);

			    tmpaddr=taddr[0]*1000+taddr[1]*10+taddr[2];

			    FkComm_ValueTmp.ADDR[1]= ((tmpaddr&0xff00)>>8);
			    FkComm_ValueTmp.ADDR[0]= (tmpaddr&0x00ff);

			    //srj �޲ɼ���ַ�洢
	         //    Save_CommSet();
			 //   Print(DebugComm,"\r\ntmpaddr=%d ",tmpaddr);
			 //   Print(DebugComm,"\r\nADDR[0]=%x ",FkComm_Value.ADDR[0]);
			 //   Print(DebugComm,"\r\nADDR[1]=%x ",FkComm_Value.ADDR[1]);
		}
*/

}
/******************************************************************************************************************
* �������ƣ�Xiu_Txquweima()�����ڵڶ����˵�
* ��    �ܣ����޸ġ� ͨѶ��������ͨѶ��λ�롿
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void Xiu_Txquweima(INT8U SeleMenu)
{/*
  	INT8U i;
       memset(NowInput.buf,0,128);
        sprintf(NowInput.buf,"%02x%02x",
					FkComm_ValueTmp.GB22601991[0],
					FkComm_ValueTmp.GB22601991[1]
				);  //����ת����Ϊ�ַ���

		i=0;
		while(i<4)
		{

			     NowInput.col[i]=54;//y��
			     NowInput.row[i]=108+i*8;//x��

		     	NowInput.set[i]=1;
			i++;
		}

		NowInput.AllNum=5;
		if(ScreenInput()==1)
		{
			for(i=0;i<2;i++)
			{
			//srj
			FkComm_ValueTmp.GB22601991[i] = GetNum(&NowInput.buf[2*i],2,2);
			}
            //srj ��ͨѶ��λ��洢
	        //     Save_CommSet();

		}
*/

}
/******************************************************************************************************************
* �������ƣ�APNSeting()�����ڵڶ����˵�
* ��    �ܣ����޸�ͨѶ�������еġ�GPRS���еġ�APN��
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void APNSeting(INT8U SeleMenu)
{
	INT8U i,j;

	memset(NowInput.buf,0,128);

	j=2;
	for(i=0;i<16;i++)
	{
	 if(FkComm_ValueTmp.F3_Set_Para.APN[i]!=0)//FkComm_Value.F3_Set_Para.APN//APNTest
	 j++;
	 else
	 break;
	}


	memcpy(NowInput.buf,FkComm_ValueTmp.F3_Set_Para.APN,j);

   // NowInput.buf[15]=0;

	if(j<16)
	{
	 for(i=1;i<=17-j;i++)		  //���ַ������һ���ַ��̶�Ϊ\0��NowInput.buf[15]=0��
	 {
		NowInput.buf[15-i]=32;	  //���ַ�������Ķ���ʱ�ÿո�32������
	 }
	}


	i=0;
    while(i<16)
	{

		NowInput.col[i]=18;
		NowInput.row[i]=32+i*8;
		NowInput.set[i]=2;
		i++;
	}

	NowInput.AllNum=16;
	if(ScreenInput()==1)
	{
		for(i=0;i<16;i++)
		{
			if(NowInput.buf[i]==0x20)
			FkComm_ValueTmp.F3_Set_Para.APN[i]=0;
			else FkComm_ValueTmp.F3_Set_Para.APN[i]=NowInput.buf[i];
		}

		//srj ��APN�洢
	    //  Save_CommSet();



	}

}
/******************************************************************************************************************
* �������ƣ�IPPortSeting()�����ڵڶ����˵�
* ��    �ܣ����޸�ͨѶ�������еġ�GPRS���еġ���վ�˿ںš�
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void IPPortSeting(INT8U SeleMenu)
{
	INT8U i;

	memset(NowInput.buf,0,128);
				sprintf(NowInput.buf,"%05d",
					(FkComm_ValueTmp.F3_Set_Para.PortMaster[1]<<8)+FkComm_ValueTmp.F3_Set_Para.PortMaster[0]);  //����ת����Ϊ�ַ���


	i=0;
    while(i<5)
	{
		NowInput.col[i]=36;
		NowInput.row[i]=88+i*8;
		NowInput.set[i]=1;
		i++;
	}

	NowInput.AllNum=6;
	if(ScreenInput()==1)
	{
		//for(i=0;i<2;i++)
		//{
			FkComm_ValueTmp.F3_Set_Para.PortMaster[1]=(GetNum(&NowInput.buf[0],5,1)>>8)&0xff;//srj
			FkComm_ValueTmp.F3_Set_Para.PortMaster[0]=GetNum(&NowInput.buf[0],5,1)&0xff;
		//	printf("PortMaster=%x \r\n",FkComm_ValueTmp.F3_Set_Para.PortMaster[i]);
		//}
	  //srj ��IP->PORT�洢
	  //    Save_CommSet();


	}


}
/******************************************************************************************************************
* �������ƣ�HeartSeting()�����ڵڶ����˵�
* ��    �ܣ����޸�ͨѶ�������еġ�GPRS���еġ�����ʱ�䡿
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void HeartSeting(INT8U SeleMenu)
{
	INT8U i;
	memset(NowInput.buf,0,128);
	sprintf(NowInput.buf,"%02d",FkComm_ValueTmp.F1_Set_Para.Heart_Beat);  //����ת����Ϊ�ַ���


	i=0;
    while(i<2)
	{
		NowInput.col[i]=54;
		NowInput.row[i]=72+i*8;
		NowInput.set[i]=1;
		i++;
	}

	NowInput.AllNum=3;
	if(ScreenInput()==1)
	{

			FkComm_ValueTmp.F1_Set_Para.Heart_Beat = GetNum(NowInput.buf,2,1);
			//srj �������洢
	      //Save_CommSet();


	}


}

/******************************************************************************************************************
* �������ƣ�DuanXinSeting()�����ڵڶ����˵�
* ��    �ܣ����޸�ͨѶ�������еġ�GPRS���еġ��������ġ�
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void DuanXinSeting(INT8U SeleMenu)
{
	INT8U i;
	memset(NowInput.buf,0,128);
	sprintf(NowInput.buf,"%02x%02x%02x%02x%02x%1x",   //16���Ƶ�BCD��
		FkComm_ValueTmp.F4_Set_Para.DuanXin[0],
		FkComm_ValueTmp.F4_Set_Para.DuanXin[1],
		FkComm_ValueTmp.F4_Set_Para.DuanXin[2],
		FkComm_ValueTmp.F4_Set_Para.DuanXin[3],
		FkComm_ValueTmp.F4_Set_Para.DuanXin[4],
		FkComm_ValueTmp.F4_Set_Para.DuanXin[5]>>4);  //����ת����Ϊ�ַ���

		i=0;
		while(i<11)
		{
			NowInput.col[i]=72;
			NowInput.row[i]=72+i*8;
			NowInput.set[i]=1;
			i++;
		}

		NowInput.AllNum=12;
		if(ScreenInput()==1)
		{
			for(i=0;i<5;i++)
			{
				FkComm_ValueTmp.F4_Set_Para.DuanXin[i]=GetNum(&NowInput.buf[2*i],2,2);
			}

			    FkComm_ValueTmp.F4_Set_Para.DuanXin[5]=GetNum(&NowInput.buf[10],1,2)<<4;
			    FkComm_ValueTmp.F4_Set_Para.DuanXin[5]=FkComm_ValueTmp.F4_Set_Para.DuanXin[5]|0xf;
			    //srj �޶��Ŵ洢
	          //Save_CommSet();


		}


}
/******************************************************************************************************************
* �������ƣ�IPAddSeting()�����ڵڶ����˵�
* ��    �ܣ����޸�ͨѶ�������еġ�GPRS���еġ�IP��
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void IPAddSeting(INT8U SeleMenu)
{
	INT8U i;
	memset(NowInput.buf,0,128);
	GUI_DispCharAt('.',48,90);
	GUI_DispCharAt('.',80,90);
	GUI_DispCharAt('.',112,90);
	sprintf(NowInput.buf,"%03d%03d%03d%03d",   //10����
		FkComm_ValueTmp.F3_Set_Para.IPMaster[0],
		FkComm_ValueTmp.F3_Set_Para.IPMaster[1],
		FkComm_ValueTmp.F3_Set_Para.IPMaster[2],
		FkComm_ValueTmp.F3_Set_Para.IPMaster[3]);  //����ת����Ϊ�ַ���
	i=0;
	while(i<3)
	{
		NowInput.col[i]=90;
		NowInput.row[i]=24+i*8;//56
		NowInput.set[i]=1;
		i++;
	}
	i=0;
	while(i<3)
	{
		NowInput.col[i+3]=90;
		NowInput.row[i+3]=56+i*8;//84
		NowInput.set[i+3]=1;
		i++;
	}
	i=0;
	while(i<3)
	{
		NowInput.col[i+6]=90;
		NowInput.row[i+6]=88+i*8;//112
		NowInput.set[i+6]=1;
		i++;
	}
	i=0;
	while(i<3)
	{
		NowInput.col[i+9]=90;
		NowInput.row[i+9]=120+i*8;//140
		NowInput.set[i+9]=1;
		i++;
	}

	NowInput.AllNum=13;
	if(ScreenInput()==1)
	{
			for(i=0;i<4;i++)
			{
				FkComm_ValueTmp.F3_Set_Para.IPMaster[i]=GetNum(&NowInput.buf[3*i],3,1);
			}

			//srj ��IP��ַ�洢
	      //Save_CommSet();


	}
}
/******************************************************************************************************************
* �������ƣ�GzModeSeting()�����ڵڶ����˵�
* ��    �ܣ����޸�ͨѶ�������еġ�GPRS���еġ�����ģʽ��
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void GzModeSeting(INT8U SeleMenu)
{

  FkComm_ValueTmp.F8_Set_Para.GPRS_MODE = ((FkComm_ValueTmp.F8_Set_Para.GPRS_MODE+1)%2);
  if(FkComm_ValueTmp.F8_Set_Para.GPRS_MODE ==0)FkComm_ValueTmp.F8_Set_Para.GPRS_MODE = 2;
  //srj �޹���ģʽ�洢
  // Save_CommSet();
 //��ʱ��� Lcmfull();
  //OSSemPost(FlushSem);
}
/******************************************************************************************************************
* �������ƣ� BottomBar()
* ��    �ܣ����ݲ�ͬ��ҳ����ʾ�������Ҽ�ͷ
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/

void BottomBar()
{
	INT8U str[2];
	if (a_up==1)
    {
		str[0]=0x7e;
		GUI_DispStringAt(str, 130, 144);
    }
    if (a_down==1)
    {
    	str[0]=0x7f;
		GUI_DispStringAt(str, 130, 144);
    }
    if ((a_up==1)&&(a_down==1))
    {
    	str[0]=0x7d;
		GUI_DispStringAt(str, 130, 144);
    }
    if (a_left==1)
    {
    	str[0]=0x17;
		GUI_DispStringAt(str, 122, 144);
    }
    if (a_right ==1)
    {
    	str[0]=0x16;
		GUI_DispStringAt(str, 138, 144);
    }
}


/******************************************************************************************************************
* �������ƣ�LcdMainTask()
* ��    �ܣ����ݰ�����ʾ��ṹ�Ĳ˵���ִ����صĺ���
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void LcdMainTask(void)
{
  	INT8U j,k,passtmp[4];
  	unsigned int LunXianPage;
	INT16U DelayTime;
    memset(passtmp,0,4);
    passtmp[1]=0;passtmp[0]=0;
	DelayTime = 0;
	MenuSele = 0;
	k=0xff;//����󲻻����˵�����ֱ�ӽ�������
    TongDaoLeiXing=0;//0ΪGPRS,ֵΪ1ΪPSTN,ֵΪ2ΪCDMA,
	GprsTXFS =1 ;//1ΪGPRS,ֵΪ2ΪPSTN,ֵΪ3ΪCDMA,��TongDaoLeiXing�е��ظ�
	/////////////
	OldLevel=10;//��ʼ��ʱ��OldLevel ������0��������MenuSele��Ⱦͻ��ˣ�
	///////////
    LcdK=0;
    LunXianPage=0x11;
	 Show_Mainpage();
    LunXianCount=LunXianTime;

    while (1)//�¼���
    {
   	     delay(10);
         GUI_KeyState=KeySeleflag;
         KeySeleflag =0;
		 /***************************��������********************************/
         switch(GUI_KeyState)
         {
			 case 0://���û�а������¾� LunXianCount ��1
				 break;
        case 1:
		{
		   LunXianCount=0;
		   MenuSele=Menu[MenuSele].U;

		}//�ϼ�����
		break;
		case 2:
		{
		    LunXianCount=0;
		    MenuSele=Menu[MenuSele].D;
		}//�¼�����
		break;
		case 3:
		{
	     	LunXianCount=0;
			if(Menu[MenuSele].L==99)
			{
				Menu[MenuSele].Command(MenuSele);
				k=0xff;
			}
			else if(Menu[MenuSele].L!=77)
				    MenuSele=Menu[MenuSele].L;
		}//�������
		break;
		case 4:
		{
			LunXianCount=0;
			if(Menu[MenuSele].R>=99)
			{
				k=0xff;
			}
			else if (Menu[MenuSele].R!=77)
			{
				MenuSele=Menu[MenuSele].R;
			}

		}//�Ҽ�����
		break;
		case 5:
		{
     		LunXianCount=0;
			if(Menu[MenuSele].OK>=99)
			{
				Menu[MenuSele].Command(MenuSele);
				k=0xff;
			}
			else if(Menu[MenuSele].OK!=77)
			{
				MenuSele=Menu[MenuSele].OK; //OldLevel=20;
				if(MenuSele==33)
				{
				    if(PassPro()!=1)
				    	MenuSele=8;
					OldLevel=20;
					k=0xff;
				}
				if(MenuSele==41)
				{
				    if(PassPro()!=1)
				    {
				    	MenuSele=9;
				    }
				    OldLevel=20;
				    k=0xff;
				}
				if(MenuSele==45)
				{
				    if(PassPro()!=1)
				    	MenuSele=10;
					OldLevel=20;
					k=0xff;
			    }
			    switch(MenuSele)
				{
					  case 6:
					  ChakanMeterNum=0;
					  break;
					  case 39:
					  ChakanMeterSetNum=0;//�����޸�ʱ��Ҫ�޸ĵı����ChakanMeterSetNum����
					  break;
					  case 49:
					  FkInput_ValueTmp.F10_Set_Para = RtuDataAddr->FkInput_Value.F10_Set_Para;//���ڴ��еı��ż���Լ�����ʶ˿�����������Ÿ�����ʱ����
					  Fk_Control_Set_ValueTmp.F24_Set_Para = RtuDataAddr->Fk_Control_Set_Value.F24_Set_Para;//���ڴ��еĳ������������ʱ����
					  break;

					  case 33://�޸� ��λ�뼰��ַ
					  FkComm_ValueTmp=RtuDataAddr->FkComm_Value;//Ҫ�޸� �ɼ�����ַ ͨѶ��λ��  apn ip ip�˿ں� ���ź��� ����ģʽ
					  break;
					  case 62:
					  MaichongNum=1;//Ҫ�޸� �������ĸ������������˿ں�,������,��������,�������
					  FkComm_ValueTmp.F11_Set_Para=RtuDataAddr->FkComm_Value.F11_Set_Para;
					  break;
					  default:
					  break;
				}
			}
		}//ȷ��������
		break;
		case 6:
		{
		   	if(LunXianCount>=LunXianTime)
		   	{
		   		LunXianCount=0;
		   		k=0xff;
		   		OldLevel=20;
		   		MenuSele=0;

		   	}//���������ҳ���ڰ�ȷ������������
			else
			{
				LunXianCount=0;
				if(Menu[MenuSele].ESC>=99)
				{
					Menu[MenuSele].Command(MenuSele);
					k=0xff;
				}
				else
				{
					if(Menu[MenuSele].ESC!=77)
						MenuSele=Menu[MenuSele].ESC;
				}
			}

		} //ȡ��������
		break;
		default:break;
 }
/*************************���ϰ�����������*********************************/
/*************************����Ϊ��ʾ���濪ʼ*********************************/
		if((k!=MenuSele))
		{
		   if(Menu[OldLevel].level!=Menu[MenuSele].level)
		   {
		   	    GUI_Clear();
				for(j=0;j<28;j++)
				{
					if(Menu[j].level==Menu[MenuSele].level)
						GUI_DispStringAt(Menu[j].Str,Menu[j].row, Menu[j].col);
				}
		   }
		   else
		   {
			   if( Menu[MenuSele].level!=11&&Menu[MenuSele].level!=12&&Menu[MenuSele].level!=13&&Menu[MenuSele].level!=14)
				   GUI_DispStringAt(Menu[OldLevel].Str,Menu[OldLevel].row, Menu[OldLevel].col);
		   }
    	   switch(Menu[MenuSele].level)
    	   {
			   case 15: Fb_XiuMeterSetNum(MenuSele); break;//�ڳ��������С����ס���ʾ��Ҫ�޸ĵı��š�������� ������
			   case 17: Fb_XiuMaichongNum(MenuSele); break;//�����������С����ס���ʾ��Ҫ�޸ĵ������š�
			   case 18: Fb_XiuMaichong(MenuSele);    break;//�����������С����ס���ʾ��Ҫ�޸ĵ����塿
			   case 20: Fb_XiuRenWuNum(MenuSele);    break;//�����������С����ס���ʾ��Ҫ�޸ĵ����塿
			   case 11: Fb_ChaobiaoSet(MenuSele);    break;//���������á������ס���ʾ�����š���Լ�����ʡ��˿ڡ����롢���������㡿
			   case 12: Set_TX_canshu(MenuSele);     break;//��ͨѶ�����С����ס� ��ʾ�ɼ�����ַ ͨѶ��λ��
			   case 13: Set_TXGPRS_canshufb(MenuSele);    break;//��ͨѶ�����С����ס� ��ʾ apn ip�˿� ����ʱ�� ip ����ģʽ
			   default: GUI_SetTextMode(GUI_TM_REV);
						GUI_DispStringAt(Menu[MenuSele].Str,Menu[MenuSele].row, Menu[MenuSele].col);
						GUI_SetTextMode(GUI_TM_NORMAL);   break;
    	   }
			k=MenuSele;
		}
		if (((Menu[MenuSele].level ==1)||(Menu[MenuSele].level==2))/*&&(GUI_KeyState!=0)&&(LunXianCount==0)*/)
		{
			a_up = a_down = 1; a_left = a_right = 0;
		}
		else
		{
			a_up = a_down = a_left = a_right = 0;
		}
	    OldLevel=MenuSele;
	    Status_Bar();//״̬��
	    BottomBar();
	    Lcmfull();//д��
 }


}
/******************************************************************************************************************
* �������ƣ�Show_Time()�����ڵڶ����˵�
* ��    �ܣ����鿴�����ġ���ʱ�䡿
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
int ShowTime(INT8U SeleMenu)
{

      unsigned int DelayTime;
      unsigned char keysele;
   	  TS ts;
	  DelayTime=0;
      GUI_Clear();

	            GUI_DispStringAt("��",56,56);
		   		GUI_DispStringAt("��",88,56);
		   		GUI_DispStringAt("��",120,56);
		   		GUI_DispStringAt("ʱ",48,80);
		  		GUI_DispStringAt("��",80,80);
		   		GUI_DispStringAt("��",112,80);
			while(1)
			{

				Status_Bar();
		    	TSGet(&ts);


				GUI_DispDecAt(ts.Year ,24,56,4);
				GUI_DispDecAt(ts.Month ,72,56,2);
				GUI_DispDecAt(ts.Day   ,104,56,2);
				GUI_DispDecAt(ts.Hour  ,32,80,2);
				GUI_DispDecAt(ts.Minute ,64,80,2);
				GUI_DispDecAt(ts.Sec ,96,80,2);


			     keysele=KeySeleflag;
			     KeySeleflag =0;
                 if(keysele!=0)DelayTime=0;else DelayTime++;
		         if(DelayTime>=PageDelayTime)
                {
    				OldLevel=0;
				   	return 0;
		       	}
			     if(keysele == 6)//ȡ����
			     {
				     OldLevel=0;
				     return 0;
			     }


                 Lcmfull();

			}







}
/******************************************************************************************************************
* �������ƣ�Set_Time()�����ڵڶ����˵�
* ��    �ܣ����鿴���͡��޸ġ����ġ���ʱ�䡿
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
int Set_Time(INT8U SeleMenu)
{

/*
      INT8U keysele,i;
      INT16U TempBufY[1],DelayTime;

	  INT8U TempBuf[8];
	  TS ts;
      DelayTime=0;
        	while(1)
			{
				GUI_Clear();
                GUI_DispStringAt("��",56,56);
		   		GUI_DispStringAt("��",88,56);
		   		GUI_DispStringAt("��",120,56);
		   		GUI_DispStringAt("ʱ",48,80);
		  		GUI_DispStringAt("��",80,80);
		   		GUI_DispStringAt("��",112,80);

				Status_Bar();
			    TSGet(&ts);

				GUI_DispDecAt(ts.Year  ,24,56,4);
				GUI_DispDecAt(ts.Month ,72,56,2);
				GUI_DispDecAt(ts.Day   ,104,56,2);
				GUI_DispDecAt(ts.Hour  ,32,80,2);
				GUI_DispDecAt(ts.Minute,64,80,2);
				GUI_DispDecAt(ts.Sec   ,96,80,2);

			     keysele=KeySeleflag;
			     KeySeleflag =0;
			     if(keysele!=0)DelayTime=0;else DelayTime++;
		         if(DelayTime>=PageDelayTime)
                {
    				OldLevel=0;
				   	return 0;
		       	}
                 if(keysele == 5)//ȷ����
                  {
                  	TempBufY[0]=ts.Year;
			        TempBuf[1]=ts.Month;
		         	TempBuf[2]=ts.Day;
			        TempBuf[3]=ts.Hour;
			        TempBuf[4]=ts.Minute;
			        TempBuf[5]=ts.Sec;
				    memset(NowInput.buf,0,128);
					sprintf(NowInput.buf,"%04d%02d%02d%02d%02d%02d",   //10����
							TempBufY[0],
							TempBuf[1],
							TempBuf[2],
							TempBuf[3],
							TempBuf[4],
							TempBuf[5]);  //����ת����Ϊ�ַ���

					i=0;
					while(i<4)
					{
						NowInput.col[i]=56;
						NowInput.row[i]=24+i*8;//
						NowInput.set[i]=1;
						i++;
					}
					i=0;
					while(i<2)
					{
						NowInput.col[i+4]=56;
						NowInput.row[i+4]=72+i*8;//
						NowInput.set[i+4]=1;
						i++;
					}
					i=0;
					while(i<2)
					{
						NowInput.col[i+6]=56;
						NowInput.row[i+6]=104+i*8;//
						NowInput.set[i+6]=1;
						i++;
					}
					i=0;
					while(i<2)
					{
						NowInput.col[i+8]=80;
						NowInput.row[i+8]=32+i*8;//
						NowInput.set[i+8]=1;
						i++;
					}
					i=0;
					while(i<2)
					{
						NowInput.col[i+10]=80;
						NowInput.row[i+10]=64+i*8;//
						NowInput.set[i+10]=1;
						i++;
					}
					i=0;
					while(i<2)
					{
						NowInput.col[i+12]=80;
						NowInput.row[i+12]=96+i*8;//
						NowInput.set[i+12]=1;
						i++;
					}
					NowInput.AllNum=15;
					if(ScreenInput()==1)
					{
						  //if(PassPro()==1)
						 {

						 	  TempBufY[0]=GetNum(&NowInput.buf[0],4,1);
								for(i=1;i<6;i++)
								{
									TempBuf[i]=GetNum(&NowInput.buf[2*i+2],2,1);
								}
								    ts.Year=TempBufY[0];
							        ts.Month=TempBuf[1];
							        ts.Day=TempBuf[2];
							        ts.Hour=TempBuf[3];
							        ts.Minute=TempBuf[4];
						            ts.Sec=TempBuf[5];
						            TSSet1(&ts);
						  }
					}
			     }
			     if(keysele == 6)//ȡ����
			     {
				     OldLevel=0;
				     return 0;
			     }

                 Lcmfull();
 				}
*/
}
/******************************************************************************************************************
* �������ƣ�Xiu_XingZheng()�����ڵڶ����˵�
* ��    �ܣ����޸ġ����ġ�����������ַ��
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
int Xiu_XingZheng(INT8U SeleMenu)
{
	/*
      INT8U keysele,i,taddr[3];
      INT16U tmpaddr,DelayTime;
      INT8U tmpvar;
     GUI_Clear();
     DelayTime=0;
                GUI_DispStringAt("��   ַ:",24,40);
		   		GUI_DispStringAt("��������:",24,60);
	     	while(1)
			{
			  Status_Bar();

			  tmpaddr = (FkComm_ValueTmp.ADDR[1]<<8)+FkComm_ValueTmp.ADDR[0];
		      memset(NowInput.buf,0,128);
			  sprintf(NowInput.buf,"%05d",tmpaddr);
			  GUI_DispStringAt(NowInput.buf,96,40);

		      memset(NowInput.buf,0,128);
			  sprintf(NowInput.buf,"%02x%02x",
						FkComm_ValueTmp.GB22601991[1],
						FkComm_ValueTmp.GB22601991[0]
						);  //����ת����Ϊ�ַ���   GB22601991[0]=02   GB22601991[1]=35

			  GUI_DispStringAt(NowInput.buf,96,60);



			     keysele=KeySeleflag;
			     KeySeleflag =0;
			     if(keysele!=0)
			    	 DelayTime=0;
			     else
			    	 DelayTime++;
		         if(DelayTime>=PageDelayTime)
                {
    				OldLevel=0;
				   	return 0;
		       	}
            switch(keysele)
            {
            	case 5:    //ȷ����
                  {

			      	taddr[0]=tmpaddr/1000;
			      	taddr[1]=(tmpaddr-taddr[0]*1000)/10;
			      	taddr[2]=tmpaddr%10;
	     	        memset(NowInput.buf,0,128);
			        sprintf(NowInput.buf,"%02d%02d%1d%02x%02x",
								taddr[0],
								taddr[1],
								taddr[2],
								FkComm_ValueTmp.GB22601991[1],//0
						        FkComm_ValueTmp.GB22601991[0]);//1  //����ת����Ϊ�ַ���
					i=0;
					while(i<5)
					{

						 NowInput.col[i]=40;//y��
						 NowInput.row[i]=96+i*8;//x��
					     NowInput.set[i]=1;
						 i++;
					}

			       i=0;
					while(i<4)
					{
						NowInput.col[i+5]=60;//y��
						NowInput.row[i+5]=96+i*8;//x��
					    NowInput.set[i+5]=1;
						i++;
					}

					NowInput.AllNum=10;
					if(ScreenInput()==1)
					{
						for(i=0;i<2;i++)
						{
							taddr[i]=GetNum(&NowInput.buf[2*i],2,1);
						}

			    		taddr[2]=GetNum(&NowInput.buf[4],1,1);
			    		tmpaddr=taddr[0]*1000+taddr[1]*10+taddr[2];

			    		FkComm_ValueTmp.ADDR[1]= ((tmpaddr&0xff00)>>8);
			    		FkComm_ValueTmp.ADDR[0]= (tmpaddr&0x00ff);

						for(i=0;i<2;i++)
						{
							FkComm_ValueTmp.GB22601991[i] = GetNum(&NowInput.buf[2*i+5],2,2);
						}
						tmpvar = FkComm_ValueTmp.GB22601991[0];
						FkComm_ValueTmp.GB22601991[0] = FkComm_ValueTmp.GB22601991[1];
						FkComm_ValueTmp.GB22601991[1] = tmpvar;
						RtuDataAddr->FkComm_Value=FkComm_ValueTmp;
						SaveFKSet();

					}
			     }
			   break;
			   case 6:  //ȡ����
			    {
				     OldLevel=0;
				     return 0;
			     }
                break;
                default : break;
            }
                 Lcmfull();
 				}
*/
}

/******************************************************************************************************************
* �������ƣ�Xiu_IpDuanApn()�����ڵڶ����˵�
* ��    �ܣ����޸ġ����ġ�����������ַ��
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
int Xiu_IpDuanApn(INT8U SeleMenu)
{
    /*  INT8U keysele,i,taddr[3],TempBuf[32],j;
      unsigned int DelayTime;
      GUI_Clear();
      DelayTime=0;
                GUI_DispStringAt("��վIP:�˿�",0,32);
		   		GUI_DispStringAt("����IP:�˿�",0,64);
		   		//GUI_DispStringAt("APN:",0,96);
		   		GUI_DispCharAt('.',24,48);
				GUI_DispCharAt('.',52,48);
				GUI_DispCharAt('.',80,48);

				GUI_DispCharAt('.',24,80);
				GUI_DispCharAt('.',52,80);
				GUI_DispCharAt('.',80,80);
	     	while(1)
			{
			  Status_Bar();
               //����Ϊ��վip
				GUI_DispDecAt(RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[0],0,48,3);
				//GUI_DispCharAt('.',24,48);
				GUI_DispDecAt(RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[1],28,48,3);
				//GUI_DispCharAt('.',52,48);
				GUI_DispDecAt(RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[2],56,48,3);
				//GUI_DispCharAt('.',80,48);
				GUI_DispDecAt(RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[3],84,48,3);

    			GUI_DispStringAt(":",112,46);
    			//����Ϊ��վip�˿�
    			memset(TempBuf,0,16);
				sprintf(TempBuf,"%05d",
					(RtuDataAddr->FkComm_Value.F3_Set_Para.PortMaster[1]<<8)+RtuDataAddr->FkComm_Value.F3_Set_Para.PortMaster[0]);  //����ת����Ϊ�ַ���
				GUI_DispStringAt(TempBuf,120,48);

    			//����Ϊ����ip
    			GUI_DispDecAt(RtuDataAddr->FkComm_Value.F3_Set_Para.IPSlave[0],0,80,3);
				//GUI_DispCharAt('.',24,80);
				GUI_DispDecAt(RtuDataAddr->FkComm_Value.F3_Set_Para.IPSlave[1],28,80,3);
				//GUI_DispCharAt('.',52,80);
				GUI_DispDecAt(RtuDataAddr->FkComm_Value.F3_Set_Para.IPSlave[2],56,80,3);
				//GUI_DispCharAt('.',80,80);
				GUI_DispDecAt(RtuDataAddr->FkComm_Value.F3_Set_Para.IPSlave[3],84,80,3);

               GUI_DispStringAt(":",112,78);
               //����Ϊ����ip	�˿�
               memset(TempBuf,0,16);
				sprintf(TempBuf,"%05d",
					(RtuDataAddr->FkComm_Value.F3_Set_Para.PortSlave[1]<<8)+RtuDataAddr->FkComm_Value.F3_Set_Para.PortSlave[0]);  //����ת����Ϊ�ַ���
				GUI_DispStringAt(TempBuf,120,80);

	          //����Ϊapn
			 //  GUI_DispStringAt(FkComm_ValueTmp.F3_Set_Para.APN,0,112);

		  keysele=KeySeleflag;
		  KeySeleflag =0;
		  if(keysele!=0)DelayTime=0;else DelayTime++;
		         if(DelayTime>=PageDelayTime)
                {
    				OldLevel=0;
				   	return 0;
		       	}
          switch(keysele)
            {
            	case 5:    //ȷ����
                  {

    memset(NowInput.buf,0,128);
	sprintf(NowInput.buf,"%03d%03d%03d%03d%05d%03d%03d%03d%03d%05d",   //10����
		FkComm_ValueTmp.F3_Set_Para.IPMaster[0],
		FkComm_ValueTmp.F3_Set_Para.IPMaster[1],
		FkComm_ValueTmp.F3_Set_Para.IPMaster[2],
		FkComm_ValueTmp.F3_Set_Para.IPMaster[3],
		(FkComm_ValueTmp.F3_Set_Para.PortMaster[1]<<8)+FkComm_ValueTmp.F3_Set_Para.PortMaster[0],
		FkComm_ValueTmp.F3_Set_Para.IPSlave[0],
		FkComm_ValueTmp.F3_Set_Para.IPSlave[1],
		FkComm_ValueTmp.F3_Set_Para.IPSlave[2],
		FkComm_ValueTmp.F3_Set_Para.IPSlave[3],
		(FkComm_ValueTmp.F3_Set_Para.PortSlave[1]<<8)+FkComm_ValueTmp.F3_Set_Para.PortSlave[0]);  //����ת����Ϊ�ַ���

	i=0;
	while(i<3)
	{
		NowInput.col[i]=48;
		NowInput.row[i]=0+i*8;//56
		NowInput.set[i]=1;
		i++;
	}
	i=0;
	while(i<3)
	{
		NowInput.col[i+3]=48;
		NowInput.row[i+3]=28+i*8;//84
		NowInput.set[i+3]=1;
		i++;
	}
	i=0;
	while(i<3)
	{
		NowInput.col[i+6]=48;
		NowInput.row[i+6]=56+i*8;//112
		NowInput.set[i+6]=1;
		i++;
	}
	i=0;
	while(i<3)
	{
		NowInput.col[i+9]=48;
		NowInput.row[i+9]=84+i*8;//140
		NowInput.set[i+9]=1;
		i++;
	}
   i=0;
    while(i<5)
	{
		NowInput.col[i+12]=48;
		NowInput.row[i+12]=120+i*8;
		NowInput.set[i+12]=1;
		i++;
	}
	i=0;
	while(i<3)
	{
		NowInput.col[i+17]=80;
		NowInput.row[i+17]=0+i*8;//56
		NowInput.set[i+17]=1;
		i++;
	}
	i=0;
	while(i<3)
	{
		NowInput.col[i+20]=80;
		NowInput.row[i+20]=28+i*8;//84
		NowInput.set[i+20]=1;
		i++;
	}
	i=0;
	while(i<3)
	{
		NowInput.col[i+23]=80;
		NowInput.row[i+23]=56+i*8;//112
		NowInput.set[i+23]=1;
		i++;
	}
	i=0;
	while(i<3)
	{
		NowInput.col[i+26]=80;
		NowInput.row[i+26]=84+i*8;//140
		NowInput.set[i+26]=1;
		i++;
	}
    i=0;
    while(i<5)
	{
		NowInput.col[i+29]=80;
		NowInput.row[i+29]=120+i*8;
		NowInput.set[i+29]=1;
		i++;
	}

     			NowInput.AllNum=35;//35+16
					if(ScreenInput()==1)
					{

					for(i=0;i<4;i++)
					{
						FkComm_ValueTmp.F3_Set_Para.IPMaster[i]=GetNum(&NowInput.buf[3*i],3,1);
					}
					FkComm_ValueTmp.F3_Set_Para.PortMaster[1]=(GetNum(&NowInput.buf[12],5,1)>>8)&0xff;//srj
			        FkComm_ValueTmp.F3_Set_Para.PortMaster[0]=GetNum(&NowInput.buf[12],5,1)&0xff;

					for(i=0;i<4;i++)
					{
						FkComm_ValueTmp.F3_Set_Para.IPSlave[i]=GetNum(&NowInput.buf[3*i+17],3,1);
					}
					FkComm_ValueTmp.F3_Set_Para.PortSlave[1]=(GetNum(&NowInput.buf[29],5,1)>>8)&0xff;//srj
			        FkComm_ValueTmp.F3_Set_Para.PortSlave[0]=GetNum(&NowInput.buf[29],5,1)&0xff;

					RtuDataAddr->FkComm_Value=FkComm_ValueTmp;
					SaveFKSet();

					}
			     }
			   break;
			   case 6:  //ȡ����
			    {
				     OldLevel=0;
				     return 0;
			     }
                break;
                default : break;
            }
                 Lcmfull();
 				}
 				*/
}
/******************************************************************************************************************
* �������ƣ�Xiu_TxCanShu()�����ڵڶ����˵�
* ��    �ܣ����޸ġ����ġ���ͨ�Ų�����
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
int Xiu_TxCanShu(INT8U SeleMenu)
{
 /*     INT8U keysele,i;
     unsigned int DelayTime;
      GUI_Clear();
      DelayTime=0;
                GUI_DispStringAt("�ŵ�����:",0,32);//1���ֽ�
		   		GUI_DispStringAt("���ӷ�ʽ:TCP",0,48);//1���ֽ�
		   		GUI_DispStringAt("��������:",0,64);//1���ֽ�
		   		GUI_DispStringAt("�ز����:",0,80);//2���ֽ�
		   		GUI_DispStringAt("�ز�����:",0,96);//1���ֽ�
		   		GUI_DispStringAt("�Զ���������:",0,112);//1���ֽ�

	     	while(1)
			{
			  Status_Bar();

			   memset(NowInput.buf,0,128);//�ŵ�����
	          sprintf(NowInput.buf,"%02d",RtuDataAddr->ModuleType);
              GUI_DispStringAt(NowInput.buf,72,32);

              memset(NowInput.buf,0,128);//����
	          sprintf(NowInput.buf,"%02d",FkComm_ValueTmp.F1_Set_Para.Heart_Beat);
              GUI_DispStringAt(NowInput.buf,72,64);
              GUI_DispStringAt("��",132,64);

              memset(NowInput.buf,0,128);//���������ز����
	          sprintf(NowInput.buf,"%05d",
	          ((FkComm_ValueTmp.F8_Set_Para.ZaiXian_ChongBo[1])<<8)+FkComm_ValueTmp.F8_Set_Para.ZaiXian_ChongBo[0]
	          );
              GUI_DispStringAt(NowInput.buf,72,80);
              GUI_DispStringAt("��",132,80);

              memset(NowInput.buf,0,128);//���������ز�����
	          sprintf(NowInput.buf,"%03d",
	          FkComm_ValueTmp.F8_Set_Para.BeiDongJihuo);
              GUI_DispStringAt(NowInput.buf,72,96);

               memset(NowInput.buf,0,128);//�Զ�����ʱ��
	          sprintf(NowInput.buf,"%03d",FkComm_ValueTmp.F8_Set_Para.WUTongXinDuan);
              GUI_DispStringAt(NowInput.buf,104,112);
              GUI_DispStringAt("��",132,112);

		  keysele=KeySeleflag;
		  KeySeleflag =0;
		  if(keysele!=0)DelayTime=0;else DelayTime++;
		         if(DelayTime>=PageDelayTime)
                {
    				OldLevel=0;
				   	return 0;
		       	}
          switch(keysele)
            {
            	case 5:    //ȷ����
                  {

    memset(NowInput.buf,0,128);
	sprintf(NowInput.buf,"%02d%02d%05d%03d%03d",   //10����
		RtuDataAddr->ModuleType,
		FkComm_ValueTmp.F1_Set_Para.Heart_Beat,
		((FkComm_ValueTmp.F8_Set_Para.ZaiXian_ChongBo[1])<<8)+FkComm_ValueTmp.F8_Set_Para.ZaiXian_ChongBo[0],
		FkComm_ValueTmp.F8_Set_Para.BeiDongJihuo,
		FkComm_ValueTmp.F8_Set_Para.WUTongXinDuan);  //����ת����Ϊ�ַ���

	i=0;
	while(i<2)
	{
		NowInput.col[i]=32;
		NowInput.row[i]=72+i*8;//56
		NowInput.set[i]=1;
		i++;
	}

	i=0;
	while(i<2)
	{
		NowInput.col[i+2]=64;
		NowInput.row[i+2]=72+i*8;//112
		NowInput.set[i+2]=1;
		i++;
	}
   i=0;
    while(i<5)
	{
		NowInput.col[i+4]=80;
		NowInput.row[i+4]=72+i*8;
		NowInput.set[i+4]=1;
		i++;
	}
	i=0;
	while(i<3)
	{
		NowInput.col[i+9]=96;
		NowInput.row[i+9]=72+i*8;//56
		NowInput.set[i+9]=1;
		i++;
	}
	i=0;
	while(i<3)
	{
		NowInput.col[i+12]=112;
		NowInput.row[i+12]=104+i*8;//84
		NowInput.set[i+12]=1;
		i++;
	}

     			NowInput.AllNum=16;//35+16
					if(ScreenInput()==1)
					{
					RtuDataAddr->ModuleType=GetNum(&NowInput.buf[0],2,1);

					FkComm_ValueTmp.F1_Set_Para.Heart_Beat=GetNum(&NowInput.buf[2],2,1);

					FkComm_ValueTmp.F8_Set_Para.ZaiXian_ChongBo[1]=(GetNum(&NowInput.buf[4],5,1)>>8)&0xff;
					FkComm_ValueTmp.F8_Set_Para.ZaiXian_ChongBo[0]=GetNum(&NowInput.buf[4],5,1)&0xff;

					FkComm_ValueTmp.F8_Set_Para.BeiDongJihuo=GetNum(&NowInput.buf[9],3,1);
					FkComm_ValueTmp.F8_Set_Para.WUTongXinDuan=GetNum(&NowInput.buf[12],3,1);

					RtuDataAddr->FkComm_Value=FkComm_ValueTmp;
					SaveFKSet();
					}
			     }
			   break;
			   case 6:  //ȡ����
			    {
				     OldLevel=0;
				     return 0;
			     }
                break;
                default : break;
            }
                 Lcmfull();
 				}
*/
}

/******************************************************************************************************************
* �������ƣ�Xiu_Apn()�����ڵڶ����˵�
* ��    �ܣ����޸ġ����ġ�����������ַ��
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
int Xiu_Apn(INT8U SeleMenu)
{
	/*
      INT8U keysele,i,j;
      INT16U DelayTime;
      DelayTime=0;
      GUI_Clear();
                GUI_DispStringAt("APN:",0,32);
	     	while(1)
			{
			  Status_Bar();

	          //����Ϊapn
			   GUI_DispStringAt(FkComm_ValueTmp.F3_Set_Para.APN,32,48);

		  keysele=KeySeleflag;
		  KeySeleflag =0;
		  if(keysele!=0)DelayTime=0;else DelayTime++;
		         if(DelayTime>=PageDelayTime)
                {
    				OldLevel=0;
				   	return 0;
		       	}
          switch(keysele)
            {
            	case 5:    //ȷ����
                  {

				  	memset(NowInput.buf,0,128);
					j=2;
					for(i=0;i<16;i++)
					{
					 if(FkComm_ValueTmp.F3_Set_Para.APN[i]!=0)//FkComm_Value.F3_Set_Para.APN//APNTest
					 j++;
					 else
					 break;
					}
					memcpy(NowInput.buf,FkComm_ValueTmp.F3_Set_Para.APN,j);
				 	if(j<16)
					{
					 for(i=1;i<=17-j;i++)		  //���ַ������һ���ַ��̶�Ϊ\0��NowInput.buf[15]=0��
					 {
						NowInput.buf[15-i]=32;	  //���ַ�������Ķ���ʱ�ÿո�32������
					 }
					}
					i=0;
				    while(i<16)
					{

						NowInput.col[i]=48;
						NowInput.row[i]=32+i*8;
						NowInput.set[i]=2;
						i++;
					}

	   			    NowInput.AllNum=16;//35+16
					if(ScreenInput()==1)
					{

					  for(i=0;i<16;i++)
						{
							if(NowInput.buf[i]==0x20)
							FkComm_ValueTmp.F3_Set_Para.APN[i]=0;
							else FkComm_ValueTmp.F3_Set_Para.APN[i]=NowInput.buf[i];
						}
						RtuDataAddr->FkComm_Value=FkComm_ValueTmp;
						SaveFKSet();
					}
			     }
			   break;
			   case 6:  //ȡ����
			    {
				     OldLevel=0;
				     return 0;
			     }
                break;
                default : break;
            }
                 Lcmfull();
 				}
	     	*/
}
/******************************************************************************************************************
* �������ƣ�Hard_Reset()�����ڵڶ����˵�
* ��    �ܣ������������ġ����նˡ�
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
int Hard_Reset(INT8U SeleMenu)
{

	//system("shutdown");

}

/******************************************************************************************************************
* �������ƣ�Data_Reset()�����ڵڶ����˵�
* ��    �ܣ������ݡ�����ʼ����
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
int Data_Reset(INT8U SeleMenu)
{
	/*
  RtuDataAddr->ResetdataSet=1;
	unsigned int DelayTime;
	unsigned char keysele;
	DelayTime=0;
	while (1)
	{
		GUI_Clear();
		GUI_DispStringAt("�����ѳ�ʼ����",32,60);
		Status_Bar();
		Lcmfull();

		keysele=KeySeleflag;
		KeySeleflag =0;
		if(keysele!=0)DelayTime=0;else DelayTime++;
		if(DelayTime>=PageDelayTime)
		{
			OldLevel=0;
			return 0;
		}
		switch(keysele)
		{
			case 0:DelayTime++;break;
			case 6: OldLevel=0;return 0;break;
			default:break;
		}
	}
	*/
}

/******************************************************************************************************************
* �������ƣ�Canshu_Reset()�����ڵڶ����˵�
* ��    �ܣ�������������ʼ����
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
int Canshu_Reset(INT8U SeleMenu)
{
	/*
 RtuDataAddr->ResetSetSet=1;
	unsigned int DelayTime;
	unsigned char keysele;
	DelayTime=0;
	while (1)
	{
		GUI_Clear();
		GUI_DispStringAt("�����ѳ�ʼ����",32,60);
		Status_Bar();
		Lcmfull();

		keysele=KeySeleflag;
		KeySeleflag =0;
		if(keysele!=0)DelayTime=0;else DelayTime++;
		if(DelayTime>=PageDelayTime)
		{
			OldLevel=0;
			return 0;
		}
		switch(keysele)
		{
			case 0:DelayTime++;break;
			case 6: OldLevel=0;return 0;break;
			default:break;
		}
	}
	*/
}


/******************************************************************************************************************
* �������ƣ�Show_Meter_Yx()�����ڵڶ����˵�
* ��    �ܣ����鿴�����ġ���ң��״̬��
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
int Show_Meter_Yx(INT8U SeleMenu)
{
		 unsigned char keysele,TempBuf[16],i,j;
		 unsigned int DelayTime;

		 DelayTime=0;
		 i=0;
		 j=0;
		 //a_up = a_down =  0;
		 //a_right = a_left = 1;



		  while(1)
		  {

			  //switch(j)
			 // {
				  //case 0:
						 GUI_Clear();
						 GUI_DispStringAt("��ǰ������״̬:",0,16);
						 GUI_DispStringAt("���غ�",0,36);
						 GUI_DispStringAt("���غ�",76,36);
						 //GUI_DispStringAt("״̬",96,36);

						 for(i=0;i<4;i++)
						 {

							 GUI_DispDecAt(i+1 ,16,(56+i*20),1);
							 if((RtuDataAddr->NowYx>>i)==1)
								 GUI_DispStringAt("��",50,(56+i*20));
							 else
								 GUI_DispStringAt("��",50,(56+i*20));
							 GUI_DispDecAt(i+1+4 ,98,(56+i*20),1);
							 if((RtuDataAddr->NowYx>>(i+4))==1)
								 GUI_DispStringAt("��",132,(56+i*20));
							 else
								 GUI_DispStringAt("��",132,(56+i*20));
						 }

				  //break;
				  /*case 1:
						 GUI_Clear();
						 GUI_DispStringAt("��ǰ������״̬:",0,16);
						 GUI_DispStringAt("���غ�",16,36);
						 GUI_DispStringAt("״̬",96,36);

						 for(i=4;i<8;i++)
						 {

							 GUI_DispDecAt(i+1 ,32,(56+(i-4)*20),1);
							 if((RtuDataAddr->NowYx>>i)==1)
								 GUI_DispStringAt("��",106,(56+(i-4)*20));
							 else
								 GUI_DispStringAt("��",106,(56+(i-4)*20));
						 }

				  break;*/
				  //default: break;
			  //}

		    /*memset(TempBuf,0,16);
        	sprintf(TempBuf,"%01x %01x %01x %01x %01x %01x %01x %01x",
		            (RtuDataAddr->NowYx)&1,
				    (RtuDataAddr->NowYx>>1)&1,
				    (RtuDataAddr->NowYx>>2)&1,
				    (RtuDataAddr->NowYx>>3)&1,
				    (RtuDataAddr->NowYx>>4)&1,
				    (RtuDataAddr->NowYx>>5)&1,
				    (RtuDataAddr->NowYx>>6)&1,
				    (RtuDataAddr->NowYx>>7)&1);  //����ת����Ϊ�ַ���
	        GUI_DispStringAt(TempBuf,20,52);
*/
	       // memset(TempBuf,0,16);
        	//sprintf(TempBuf,"%01x %01x %01x %01x %01x %01x %01x %01x",
		            //(RtuDataAddr->FkInput_Value.F12_Set_Para.YxShuXing)&1,
				   // (RtuDataAddr->FkInput_Value.F12_Set_Para.YxShuXing>>1)&1,
				   // (RtuDataAddr->FkInput_Value.F12_Set_Para.YxShuXing>>2)&1,
				   // (RtuDataAddr->FkInput_Value.F12_Set_Para.YxShuXing>>3)&1,
				   // (RtuDataAddr->FkInput_Value.F12_Set_Para.YxShuXing>>4)&1,
				   // (RtuDataAddr->FkInput_Value.F12_Set_Para.YxShuXing>>5)&1,
				   // (RtuDataAddr->FkInput_Value.F12_Set_Para.YxShuXing>>6)&1,
				  //  (RtuDataAddr->FkInput_Value.F12_Set_Para.YxShuXing>>7)&1);  //����ת����Ϊ�ַ���
	        //GUI_DispStringAt(TempBuf,20,72);

	        //memset(TempBuf,0,16);
        	//sprintf(TempBuf,"%01x %01x %01x %01x %01x %01x %01x %01x",
		           // (RtuDataAddr->FkInput_Value.F12_Set_Para.YxEvent)&1,
				   // (RtuDataAddr->FkInput_Value.F12_Set_Para.YxEvent>>1)&1,
				   // (RtuDataAddr->FkInput_Value.F12_Set_Para.YxEvent>>2)&1,
				    //(RtuDataAddr->FkInput_Value.F12_Set_Para.YxEvent>>3)&1,
				    //(RtuDataAddr->FkInput_Value.F12_Set_Para.YxEvent>>4)&1,
				    //(RtuDataAddr->FkInput_Value.F12_Set_Para.YxEvent>>5)&1,
				    //(RtuDataAddr->FkInput_Value.F12_Set_Para.YxEvent>>6)&1,
				    //(RtuDataAddr->FkInput_Value.F12_Set_Para.YxEvent>>7)&1);  //����ת����Ϊ�ַ���
	        //GUI_DispStringAt(TempBuf,20,104);
		    Status_Bar();
		    //BottomBar();
		    Lcmfull();

		     keysele=KeySeleflag;
		     KeySeleflag =0;
		     if(keysele!=0)DelayTime=0;else DelayTime++;
		     if(DelayTime>=PageDelayTime)
		       {
		       	OldLevel=0;
		       	return 0;
		       	}
			   switch(keysele)
			   {
			   case 1: DelayTime=0;break;//��
			   case 2: DelayTime=0;break;//��
			   case 3: if(j==0)j=1;else j=j-1;DelayTime=0;break;//��
			   case 4: j=(j+1)%2;DelayTime=0;break;
			   case 5: DelayTime=0;break;
			   case 6: OldLevel=0;return 0;break;
			   default:break;
			   }

		  }


}
/******************************************************************************************************************
* �������ƣ�Show_Meter_Yc()�����ڵڶ����˵�
* ��    �ܣ����鿴�����ġ���ң��״̬��
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
int Show_Meter_Yc(INT8U SeleMenu)
{
		unsigned char keysele,i,j;
		unsigned int DelayTime;
		double m,n;
		DelayTime=0;
		i=j=0;
   		a_up = a_down =  0;
   		a_right = a_left = 1;
		  while(1)
		  {
		  	GUI_Clear();
	        switch(j)
	        {
		       case 0:
		       GUI_DispStringAt("��ѹ��V��",8,32);
		       GUI_DispStringAt("������A��",88,32);
			   GUI_DispStringAt("Ua:",8,56);
			   GUI_DispStringAt("Ub:",8,72);
			   GUI_DispStringAt("Uc:",8,88);
	           GUI_DispDecShiftAt(32,56,5,1,RtuDataAddr->FkDdRealData.VA);
	           GUI_DispDecShiftAt(32,72,5,1,RtuDataAddr->FkDdRealData.VB);
		       GUI_DispDecShiftAt(32,88,5,1,RtuDataAddr->FkDdRealData.VC);

			   GUI_DispStringAt("Ia:",88,56);
			   GUI_DispStringAt("Ib:",88,72);
			   GUI_DispStringAt("Ic:",88,88);
			   GUI_DispDecShiftAt(112,56,5,2,RtuDataAddr->FkDdRealData.IA);
	           GUI_DispDecShiftAt(112,72,5,2,RtuDataAddr->FkDdRealData.IB);
		       GUI_DispDecShiftAt(112,88,5,2,RtuDataAddr->FkDdRealData.IC);


/*		       memset(NowInput.buf,0,128);
              sprintf(NowInput.buf,"%02d%02d%02d%02d",
					RtuDataAddr->Zj_Control_Value[i].F47_Set_Para.Gou_DIan_Value[3],
					RtuDataAddr->Zj_Control_Value[i].F47_Set_Para.Gou_DIan_Value[2],
					RtuDataAddr->Zj_Control_Value[i].F47_Set_Para.Gou_DIan_Value[1],
					RtuDataAddr->Zj_Control_Value[i].F47_Set_Para.Gou_DIan_Value[0]
				);
		       GUI_DispStringAt("������:",8,128);GUI_DispStringAt(NowInput.buf,64,128);
*/
	           break;

			   case 1:
			   GUI_DispStringAt("�й�(kw)",8,32);
			   GUI_DispStringAt("�޹�(kvar)",82,32);
			   GUI_DispStringAt("P :",0,56);
			   GUI_DispStringAt("Pa:",0,72);
			   GUI_DispStringAt("Pb:",0,88);
			   GUI_DispStringAt("Pc:",0,104);
			   GUI_DispDecShiftAt(24,56,6,1,RtuDataAddr->FkDdRealData.P);
		       GUI_DispDecShiftAt(24,72,6,1,RtuDataAddr->FkDdRealData.PA);
		       GUI_DispDecShiftAt(24,88,6,1,RtuDataAddr->FkDdRealData.PB);
			   GUI_DispDecShiftAt(24,104,6,1,RtuDataAddr->FkDdRealData.PC);

			   GUI_DispStringAt("Q :",80,56);
			   GUI_DispStringAt("Qa:",80,72);
			   GUI_DispStringAt("Qb:",80,88);
			   GUI_DispStringAt("Qc:",80,104);
	           GUI_DispDecShiftAt(104,56,6,1,RtuDataAddr->FkDdRealData.Q);
			   GUI_DispDecShiftAt(104,72,6,1,RtuDataAddr->FkDdRealData.QA);
		       GUI_DispDecShiftAt(104,88,6,1,RtuDataAddr->FkDdRealData.QB);
			   GUI_DispDecShiftAt(104,104,6,1,RtuDataAddr->FkDdRealData.QC);
			   GUI_DispStringAt("Cos:",0,120);
			   GUI_DispDecShiftAt(32,120,4,3,RtuDataAddr->FkDdRealData.Cos);

			   break;

			   default: break;

	        }
		     Status_Bar();
		     BottomBar();
		     Lcmfull();
		     keysele=KeySeleflag;
		     KeySeleflag =0;
		    if(DelayTime>=PageDelayTime)
		       {
		       	OldLevel=10;
		       	return 0;
		       	}
		   switch(keysele)
		   {
		   case 0:DelayTime++;break;
		   case 1: if(i==0) i=0; else i=(i-1)%8; DelayTime=0;break;
		   case 2: i=(i+1)%ZongJia_Max ;DelayTime=0;break;
		   case 3: j=(j+1)%2;DelayTime=0;break;
		   case 4: j=(j+1)%2;DelayTime=0;break;
		   case 5:  DelayTime=0;break;
		   case 6: OldLevel=10;MenuSele = 17;return 0;break;
		   default:break;
		   }
		}
}
/*
		  while(1)
		  {
		  	 GUI_Clear();
		  	 GUI_DispStringAt("Ua:",0,16);
			 GUI_DispStringAt("Ub:",0,32);
			 GUI_DispStringAt("Uc:",0,48);
		 	 GUI_DispStringAt("Pa:",80,16);
			 GUI_DispStringAt("Pb:",80,32);
			 GUI_DispStringAt("Pc:",80,48);
			 GUI_DispStringAt("Ia:",0,64);
			 GUI_DispStringAt("Ib:",0,80);
			 GUI_DispStringAt("Ic:",0,96);
			 GUI_DispStringAt("Qa:",80,64);
			 GUI_DispStringAt("Qb:",80,80);
			 GUI_DispStringAt("Qc:",80,96);
			 GUI_DispStringAt("P :",0,112);
			 GUI_DispStringAt("Q :",0,128);
			 GUI_DispStringAt("Cs:",80,112);
           GUI_DispDecShiftAt(24,16,5,1,RtuDataAddr->FkDdRealData.VA);
           GUI_DispDecShiftAt(24,32,5,1,RtuDataAddr->FkDdRealData.VB);
	       GUI_DispDecShiftAt(24,48,5,1,RtuDataAddr->FkDdRealData.VC);

		   GUI_DispDecShiftAt(104,16,7,1,RtuDataAddr->FkDdRealData.PA);
           GUI_DispDecShiftAt(104,32,7,1,RtuDataAddr->FkDdRealData.PB);
	       GUI_DispDecShiftAt(104,48,7,1,RtuDataAddr->FkDdRealData.PC);

		   GUI_DispDecShiftAt(24,64,5,2,RtuDataAddr->FkDdRealData.IA);
           GUI_DispDecShiftAt(24,80,5,2,RtuDataAddr->FkDdRealData.IB);
	       GUI_DispDecShiftAt(24,96,5,2,RtuDataAddr->FkDdRealData.IC);

		   GUI_DispDecShiftAt(104,64,7,1,RtuDataAddr->FkDdRealData.QA);
           GUI_DispDecShiftAt(104,80,7,1,RtuDataAddr->FkDdRealData.QB);
	       GUI_DispDecShiftAt(104,96,7,1,RtuDataAddr->FkDdRealData.QC);

		   GUI_DispDecShiftAt(24,112,7,1,RtuDataAddr->FkDdRealData.P);
           GUI_DispDecShiftAt(24,128,7,1,RtuDataAddr->FkDdRealData.Q);
	       GUI_DispDecShiftAt(104,112,5,3,RtuDataAddr->FkDdRealData.Cos);

		    Status_Bar();
		    Lcmfull();

		     keysele=KeySeleflag;
		     KeySeleflag =0;
		     if(keysele!=0)DelayTime=0;else DelayTime++;
		    if(DelayTime>=PageDelayTime)
		       {
		       	OldLevel=0;
		       	return 0;
		       	}
		    if(keysele == 6)//ȡ����
		     {
			     OldLevel=0;
			     return 0;
		     }

		  }
*/

/******************************************************************************************************************
* �������ƣ�Show_Meter_Yk()�����ڵڶ����˵�
* ��    �ܣ����鿴�����ġ�������״̬��
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
int Show_Meter_Yk(INT8U SeleMenu)
{
		 unsigned char keysele,TempBuf[16];
		 unsigned int DelayTime;
		 GUI_Clear();
		 DelayTime=0;
		 GUI_DispStringAt("����״̬:",44,24);
		 GUI_DispStringAt("����״̬:",44,56);
		  while(1)
		  {

	        memset(TempBuf,0,16);
        	sprintf(TempBuf,"%01x %01x %01x %01x %01x %01x %01x %01x",
		            (RtuDataAddr->NowControl)&1,
				    (RtuDataAddr->NowControl>>1)&1,
				    (RtuDataAddr->NowControl>>2)&1,
				    (RtuDataAddr->NowControl>>3)&1,
				    (RtuDataAddr->NowControl>>4)&1,
				    (RtuDataAddr->NowControl>>5)&1,
				    (RtuDataAddr->NowControl>>6)&1,
				    (RtuDataAddr->NowControl>>7)&1);  //����ת����Ϊ�ַ���
	        GUI_DispStringAt(TempBuf,20,40);

		      memset(TempBuf,0,16);//��ʾControl_Lunci_Maxң���ִ���Ϣ
        	sprintf(TempBuf,"%01x %01x %01x %01x",
		            RtuDataAddr->FuKong_Control_Value.F1_Control_Para[0].Valid,
				    RtuDataAddr->FuKong_Control_Value.F1_Control_Para[1].Valid,
				    RtuDataAddr->FuKong_Control_Value.F1_Control_Para[2].Valid,
				    RtuDataAddr->FuKong_Control_Value.F1_Control_Para[4].Valid
				    );  //����ת����Ϊ�ַ���
	        GUI_DispStringAt(TempBuf,20,72);

		     Status_Bar();
		     Lcmfull();

		     keysele=KeySeleflag;
		     KeySeleflag =0;
		     if(keysele!=0)DelayTime=0;else DelayTime++;
		    if(DelayTime>=PageDelayTime)
		       {
		       	OldLevel=0;
		       	return 0;
		       	}
		    if(keysele == 6)//ȡ����
		     {
			     OldLevel=0;
			     return 0;
		     }

		  }


}
/******************************************************************************************************************
* �������ƣ�Show_Meter_Ym()�����ڵڶ����˵�
* ��    �ܣ����鿴�����ġ�������״̬��
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
int Show_Meter_Ym(INT8U SeleMenu)
{
		 unsigned char keysele,TempBuf[16],i;
		 unsigned int DelayTime,num;

		 GUI_Clear();
		 DelayTime=0;
		 i=0;

		 GUI_DispStringAt("����  ״̬:",36,24);
		 GUI_DispStringAt("����˿ں�:",28,44);
		 GUI_DispStringAt("����������:",28,64);
		 GUI_DispStringAt("��������:",8,84);
		 GUI_DispStringAt("�������:",28,104);
		  while(1)
		  {

	        GUI_DispDecAt(i+1, 72, 24, 1);

	        GUI_DispDecAt(RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong[i].InputNo, 116, 44, 2);

	        GUI_DispDecAt(RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong[i].CeLiangNo, 116, 64, 2);

	        GUI_DispDecAt(RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong[i].Stat, 80, 84, 2);
	        memset(TempBuf,0,16);
	        num = (FkComm_ValueTmp.F11_Set_Para.MaiChong[i].Changhu[1]<<8)|FkComm_ValueTmp.F11_Set_Para.MaiChong[i].Changhu[0];
	        sprintf(TempBuf,"%05d",num);
      	//sprintf(TempBuf,"%02d%02d",
		          //  RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong[i].Changhu[1],
				  //  RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong[i].Changhu[0]
				 //   );  //����ת����Ϊ�ַ���
	        GUI_DispStringAt(TempBuf,100,104);

		     Status_Bar();
		     Lcmfull();
		     keysele=KeySeleflag;
		     KeySeleflag =0;

		    if(keysele!=0)DelayTime=0;else DelayTime++;
		    if(DelayTime>=PageDelayTime)
		       {
		       	OldLevel=0;
		       	return 0;
		       	}
		   switch(keysele)
		   {
		   case 1: if(i==0) i=0; else i=(i-1)%5 ;break;
		   case 2: i=(i+1)%5 ;break;
		   case 6: OldLevel=0;return 0;break;
		   default:break;
		   }
		  }
}
/******************************************************************************************************************
* �������ƣ�Show_Meter_Tt()�����ڵڶ����˵�
* ��    �ܣ����鿴�����ġ���Ͷ��״̬��
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
int Show_Meter_Tt(INT8U SeleMenu)
{
		 unsigned char keysele,ZongJiaNum;
		 unsigned int DelayTime;
		 unsigned char str[2];
		 GUI_Clear();
		 DelayTime=0;
		 ZongJiaNum=0;
	   	a_up = a_down =  1;
	   	a_right = a_left = 0;
		GUI_DispStringAt("��",0,40);
		GUI_DispStringAt("��",0,60);
		GUI_DispStringAt("��",0,80);
		GUI_DispStringAt("�����:",32,16);

		GUI_DispStringAt("�¸���:",32,32);
		GUI_DispStringAt("��ͣ��:",32,48);
		GUI_DispStringAt("���ݿ�:",32,64);
		GUI_DispStringAt("ʱ�ο�:",32,80);
		GUI_DispStringAt("�µ��:",32,96);
		GUI_DispStringAt("�����:",32,112);
		GUI_DispStringAt("�߷ѿ�:",32,128);


		  while(1)
		  {
		     GUI_SetTextMode(GUI_TM_REV);
		     GUI_DispDecAt(ZongJiaNum+1,0,100,2);
		     GUI_SetTextMode(GUI_TM_NORMAL);
		    (RtuDataAddr->FuKong_Control_Value.F25_Control_Para.Valid==1)?GUI_DispStringAt("Ͷ��",120,16):GUI_DispStringAt("���",90,16);//����
		   	(RtuDataAddr->FuKong_Control_Value.F12_Control_Para[ZongJiaNum].Valid==1)?GUI_DispStringAt("Ͷ��",90,32):GUI_DispStringAt("���",90,32);//��������
		    (RtuDataAddr->FuKong_Control_Value.F11_Control_Para[ZongJiaNum].Valid==1)?GUI_DispStringAt("Ͷ��",90,48):GUI_DispStringAt("���",90,48);//��������
		    (RtuDataAddr->FuKong_Control_Value.F10_Control_Para[ZongJiaNum].Valid==1)?GUI_DispStringAt("Ͷ��",90,64):GUI_DispStringAt("���",90,64);//�����ϱ�
		    (RtuDataAddr->FuKong_Control_Value.F9_Control_Para[ZongJiaNum].Valid==1)?GUI_DispStringAt("Ͷ��",90,80):GUI_DispStringAt("���",90,80);//�ն��޳�
		    (RtuDataAddr->FuKong_Control_Value.F15_Control_Para[ZongJiaNum].Valid==1)?GUI_DispStringAt("Ͷ��",90,96):GUI_DispStringAt("���",90,96);//�ն˱���
		    (RtuDataAddr->FuKong_Control_Value.F16_Control_Para[ZongJiaNum].Valid==1)?GUI_DispStringAt("Ͷ��",90,112):GUI_DispStringAt("���",90,112);//�߷Ѹ澯
		    (RtuDataAddr->FuKong_Control_Value.F26_Control_Para.Valid==1)?GUI_DispStringAt("Ͷ��",90,128):GUI_DispStringAt("���",90,128);//�߷Ѹ澯


		     Status_Bar();
		     BottomBar();
		     Lcmfull();
	         keysele=KeySeleflag;
		     KeySeleflag =0;
		     if(keysele!=0)DelayTime=0;else DelayTime++;
		    if(DelayTime>=PageDelayTime)
		       {
		       	OldLevel=10;
		       	MenuSele = 2;
		       	return 0;
		       	}

		   switch(keysele)
		   {
		   case 1:
			   if(ZongJiaNum==0)ZongJiaNum=7;else ZongJiaNum= ZongJiaNum-1;if(ZongJiaNum>200)ZongJiaNum=0;DelayTime=0;break;
		   case 2: ZongJiaNum= (ZongJiaNum+1)%ZongJia_Max;DelayTime=0;break;
		   case 6: OldLevel=10;MenuSele = 2;return 0;break;
		   default:break;
		   }


		  }


}
/******************************************************************************************************************
* �������ƣ�Show_GongKong_Record()�����ڵڶ����˵�
* ��    �ܣ������ؼ�¼��
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
int Show_GongKong_Record(INT8U SeleMenu)
{
		 unsigned char keysele;
		 unsigned int DelayTime;

		 DelayTime=0;

		  while(1)
		  {

		    GUI_Clear();
		    GUI_DispStringAt("���ؼ�¼",0,20);







		     Status_Bar();
		     Lcmfull();
		     keysele=KeySeleflag;
		     KeySeleflag =0;
		    if(keysele!=0)DelayTime=0;else DelayTime++;
		    if(DelayTime>=PageDelayTime)
		       {
		       	OldLevel=0;
		       	return 0;
		       	}
			   switch(keysele)
			   {
			   case 1: DelayTime=0;break;//��
			   case 2: DelayTime=0;break;//��
			   case 6: OldLevel=0;return 0;break;
			   default:break;
			   }

		  }


}
/******************************************************************************************************************
* �������ƣ�Show_DianKong_Record()�����ڵڶ����˵�
* ��    �ܣ�����ؼ�¼��
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
int Show_DianKong_Record(INT8U SeleMenu)
{
		 unsigned char keysele;
		 unsigned int DelayTime;

		 DelayTime=0;

		  while(1)
		  {

		    GUI_Clear();
		    GUI_DispStringAt("��ؼ�¼",0,20);




		     Status_Bar();
		     Lcmfull();

		     keysele=KeySeleflag;
		     KeySeleflag =0;
		    if(keysele!=0)DelayTime=0;else DelayTime++;
		    if(DelayTime>=PageDelayTime)
		       {
		       	OldLevel=0;
		       	return 0;
		       	}
			   switch(keysele)
			   {
			   case 1: DelayTime=0;break;//��
			   case 2: DelayTime=0;break;//��
			   case 6: OldLevel=0;return 0;break;
			   default:break;
			   }

		  }


}
/******************************************************************************************************************
* �������ƣ�Show_YaoKong_Record()�����ڵڶ����˵�
* ��    �ܣ���ң�ؼ�¼��
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
int Show_YaoKong_Record(INT8U SeleMenu)
{
		 unsigned char keysele;
		 unsigned int DelayTime;

		 DelayTime=0;

		  while(1)
		  {

		    GUI_Clear();
		    GUI_DispStringAt("ң�ؼ�¼",0,20);




		     Status_Bar();
		     Lcmfull();

		     keysele=KeySeleflag;
		     KeySeleflag =0;
		    if(keysele!=0)DelayTime=0;else DelayTime++;
		    if(DelayTime>=PageDelayTime)
		       {
		       	OldLevel=0;
		       	return 0;
		       	}
			   switch(keysele)
			   {
			   case 1: DelayTime=0;break;//��
			   case 2: DelayTime=0;break;//��
			   case 6: OldLevel=0;return 0;break;
			   default:break;
			   }

		  }


}
/*******************************************************************************************************************
 * �������ƣ�Show_gongkong_Record() ���ڵڶ��˵�
 * ���ܣ����ؼ�¼
***********************************************************************************************************/
int Show_gongkong_Record(INT8U SeleMenu)
{
	 unsigned char keysele;
	 unsigned int DelayTime,j,count,m;
	// unsigned char TmpEcBiaozhi;
	 INT8U k;
	 unsigned char local[256];

	 DelayTime=0;
	 j=0;
     count=0;
	 m=0;
	 a_up = a_down =  1;
	 a_right = a_left = 1;

	 if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[0]&0x20)
	 {
		 count =getevent(local,1,6);
	 }
	 else
	 {
		 count =getevent(local,0,6);
	 }
	  while(1)
	  {
		    k=0;
			if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[0]&0x20)
			{
				if(count==0)
				{
					a_up = a_down =  0;
					a_right = a_left = 0;
					GUI_Clear();
					GUI_DispStringAt("�޹��ؼ�¼",28,64);

				}
				if(count==1)
				{
					a_up = a_down =  0;
					a_right = a_left = 1;
				}
				if(count>=1)
					{
					    GUI_Clear();
						GUI_DispStringAt("���ؼ�¼ ",0,16);
						GUI_DispDecAt( m+1 ,64,16,1);
						switch(j)
						{
							case 0:
								printf("count1111====%d",count);
								printf("\n\r");
								GUI_DispStringAt("������բʱ��:",0,36);
								GUI_DispStringAt("-",32,56);
								GUI_DispStringAt("-",60,56);
								GUI_DispStringAt(" ",88,56);
								GUI_DispStringAt(":",112,56);
								//GUI_DispStringAt("20",0,40);
								GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[6],16,56,2);//��ʾ��ǰ�洢�������¼�����
								GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[5],42,56,2);//��ʾ��ǰ�洢�������¼�����
								GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[4],68,56,2);//��ʾ��ǰ�洢�������¼�����
								GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[3],94,56,2);//��ʾ��ǰ�洢�������¼�����
								GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[2],120,56,2);//��ʾ��ǰ�洢�������¼�����
								GUI_DispStringAt("��բ�ִ�:",0,76);
								//GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[8],76,76,2);
							    if((RtuDataAddr->M_Event_Save[local[m]].Event.Buff[8]>>0)&0x01)
							    {
									GUI_DispStringAt("1",76+k*16,76);
									k++;
							    }
							    if((RtuDataAddr->M_Event_Save[local[m]].Event.Buff[8]>>1)&0x01)
							    {
									GUI_DispStringAt("2",76+k*16,76);
									k++;
							    }
							    if((RtuDataAddr->M_Event_Save[local[m]].Event.Buff[8]>>2)&0x01)
							    {
									GUI_DispStringAt("3",76+k*16,76);
									k++;
							    }
							    if((RtuDataAddr->M_Event_Save[local[m]].Event.Buff[8]>>3)&0x01)
							    {
									GUI_DispStringAt("4",76+k*16,76);
									k++;
							    }

								GUI_DispStringAt("�������:",0,96);
								RtuDataAddr->M_Event_Save[local[m]].Event.Buff[9]=8;
								//printf("KongLeiBie=%d",RtuDataAddr->Event_Save.Event.Err6.KongLeiBie);
								if((RtuDataAddr->M_Event_Save[local[m]].Event.Buff[9]&0x01))
									GUI_DispStringAt("ʱ�ο�",16,116);
								if((RtuDataAddr->M_Event_Save[local[m]].Event.Buff[9]&0x02))
									GUI_DispStringAt("���ݿ�",16,116);
								if((RtuDataAddr->M_Event_Save[local[m]].Event.Buff[9]&0x04))
									GUI_DispStringAt("Ӫҵ��ͣ��",16 ,116);
								if((RtuDataAddr->M_Event_Save[local[m]].Event.Buff[9]&0x08))
									GUI_DispStringAt("��ǰ�����¸���",16,116);
							break;
							case 1:
								GUI_Clear();
								GUI_DispStringAt("���ؼ�¼ ",0,16);
								GUI_DispDecAt(m+1,64,16,1);
								GUI_DispStringAt("��բǰ����:",0,34);
								memset(NowInput.buf,0,128);
								sprintf(NowInput.buf,"%02x%02x",
										RtuDataAddr->M_Event_Save[local[m]].Event.Buff[11],
										RtuDataAddr->M_Event_Save[local[m]].Event.Buff[10]);
								GUI_DispStringAt(NowInput.buf,16,52);

								GUI_DispStringAt("��բ��2min�Ĺ���:",0,70);
								//GUI_DispHexAt(RtuDataAddr->Event_Save.Event.Err6.LunCi,80,96,2);
								memset(NowInput.buf,0,128);
								sprintf(NowInput.buf,"%02x%02x",
										RtuDataAddr->M_Event_Save[local[m]].Event.Buff[13],
										RtuDataAddr->M_Event_Save[local[m]].Event.Buff[12]);
								GUI_DispStringAt(NowInput.buf,16,88);

								GUI_DispStringAt("��բʱ�Ĺ��ʶ�ֵ:",0,106);
								memset(NowInput.buf,0,128);
								sprintf(NowInput.buf,"%02x%02x",
										RtuDataAddr->M_Event_Save[local[m]].Event.Buff[15],
										RtuDataAddr->M_Event_Save[local[m]].Event.Buff[14]);
								GUI_DispStringAt(NowInput.buf,16,124);
							break;
							default : break;

						}
					}
			}
			else
			{

				if(count==0)
				{
					a_up = a_down =  0;
					a_right = a_left = 0;
				    GUI_Clear();
					GUI_DispStringAt("�޹��ؼ�¼",28,64);

				}
				if(count==1)
				{
					a_up = a_down =  0;
					a_right = a_left = 1;
				}
				if(count>=1)
					{

					    GUI_Clear();
						GUI_DispStringAt("���ؼ�¼ ",0,16);
						GUI_DispDecAt( m+1 ,64,16,1);
						switch(j)
						{
							case 0:

								GUI_DispStringAt("������բʱ��:",0,34);
								GUI_DispStringAt("-",32,52);
								GUI_DispStringAt("-",60,52);
								GUI_DispStringAt(" ",88,52);
								GUI_DispStringAt(":",112,52);
								//GUI_DispStringAt("20",0,40);
								GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[6],16,52,2);//��ʾ��ǰ�洢�������¼�����
								GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[5],42,52,2);//��ʾ��ǰ�洢�������¼�����
								GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[4],68,52,2);//��ʾ��ǰ�洢�������¼�����
								GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[3],94,52,2);//��ʾ��ǰ�洢�������¼�����
								GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[2],120,52,2);//��ʾ��ǰ�洢�������¼�����
								GUI_DispStringAt("��բ�ִ�:",0,70);
								//GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[8],80,70,2);

							    if((RtuDataAddr->S_Event_Save[local[m]].Event.Buff[8]>>0)&0x01)
							    {
									GUI_DispStringAt("1",80+k*16,70);
									k++;
							    }
							    if((RtuDataAddr->S_Event_Save[local[m]].Event.Buff[8]>>1)&0x01)
							    {
									GUI_DispStringAt("2",80+k*16,70);
									k++;
							    }
							    if((RtuDataAddr->S_Event_Save[local[m]].Event.Buff[8]>>2)&0x01)
							    {
									GUI_DispStringAt("3",80+k*16,70);
									k++;
							    }
							    if((RtuDataAddr->S_Event_Save[local[m]].Event.Buff[8]>>3)&0x01)
							    {
									GUI_DispStringAt("4",80+k*16,70);
									k++;
							    }
								GUI_DispStringAt("�������:",0,88);
								//RtuDataAddr->S_Event_Save[k].Event.Buff[9]=8;
								//printf("KongLeiBie=%d",RtuDataAddr->Event_Save.Event.Err6.KongLeiBie);
								if((RtuDataAddr->S_Event_Save[local[m]].Event.Buff[9]&0x01))
									GUI_DispStringAt("ʱ�ο�",16,106);
								if((RtuDataAddr->S_Event_Save[local[m]].Event.Buff[9]&0x02))
									GUI_DispStringAt("���ݿ�",16,106);
								if((RtuDataAddr->S_Event_Save[local[m]].Event.Buff[9]&0x04))
									GUI_DispStringAt("Ӫҵ��ͣ��",16 ,106);
								if((RtuDataAddr->S_Event_Save[local[m]].Event.Buff[9]&0x08))
									GUI_DispStringAt("��ǰ�����¸���",16,106);
							break;
							case 1:
								GUI_Clear();
								GUI_DispStringAt("���ؼ�¼ ",0,16);
								GUI_DispDecAt(m+1,64,16,1);
								GUI_DispStringAt("��բǰ����:",0,34);
								memset(NowInput.buf,0,128);
								sprintf(NowInput.buf,"%02x%02x",
										RtuDataAddr->S_Event_Save[local[m]].Event.Buff[11],
										RtuDataAddr->S_Event_Save[local[m]].Event.Buff[10]);
								GUI_DispStringAt(NowInput.buf,16,52);

								GUI_DispStringAt("��բ��2min�Ĺ���:",0,70);
								//GUI_DispHexAt(RtuDataAddr->Event_Save.Event.Err6.LunCi,80,96,2);
								memset(NowInput.buf,0,128);
								sprintf(NowInput.buf,"%02x%02x",
										RtuDataAddr->S_Event_Save[local[m]].Event.Buff[13],
										RtuDataAddr->S_Event_Save[local[m]].Event.Buff[12]);
								GUI_DispStringAt(NowInput.buf,16,88);

								GUI_DispStringAt("��բʱ�Ĺ��ʶ�ֵ:",0,106);
								memset(NowInput.buf,0,128);
								sprintf(NowInput.buf,"%02x%02x",
										RtuDataAddr->S_Event_Save[local[m]].Event.Buff[15],
										RtuDataAddr->S_Event_Save[local[m]].Event.Buff[14]);
								GUI_DispStringAt(NowInput.buf,16,124);
							break;
							default : break;

						}
					}
			}
         Status_Bar();
	     BottomBar();
	     Lcmfull();
	     keysele=KeySeleflag;
	     KeySeleflag =0;
	    if(keysele!=0)DelayTime=0;else DelayTime++;
	    if(DelayTime>=PageDelayTime)
	       {
	       	OldLevel=0;
	       	return 0;
	       	}
	    if(count==0)
			   switch(keysele)
			   {
				   case 1: DelayTime=0;break;
				   case 2: DelayTime=0;break;
				   case 3: DelayTime=0;break;//��
				   case 4: ;DelayTime=0;break;
				   case 5: DelayTime=0;break;
				   case 6: OldLevel=0;return 0;break;
				   default:break;
			   }
	    if(count!=0)
		   switch(keysele)
		   {
		   case 1: if(m==0) m=count-1; else m=(m-1)%count; DelayTime=0;break;
		   case 2: m=(m+1)%count;DelayTime=0;break;
		   case 3: if(j==0)j=1;else j=j-1;DelayTime=0;break;//��
		   case 4: j=(j+1)%2;DelayTime=0;break;
		   case 5: DelayTime=0;break;
		   case 6: OldLevel=0;return 0;break;
		   default:break;
		   }
	  }
}

/*******************************************************************************************************************
 * �������ƣ�Show_diankong_Record() ���ڵڶ��˵�
 * ���ܣ���ؼ�¼
***********************************************************************************************************/
int Show_diankong_Record(INT8U SeleMenu)
{

	 unsigned char keysele;
	 unsigned int DelayTime,j,count,m;
	 unsigned char local[256];
     INT8U k;
	 DelayTime=0;
	 j=0;
     count=0;
	 m=0;

	 a_up = a_down =  1;
	 a_right = a_left = 1;

	 if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[0]&0x40)
	 {
		 count =getevent(local,1,7);
	 }
	 else
	 {
		 count =getevent(local,0,7);
	 }

	  while(1)
	  {
		  k=0;
		  if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[0]&0x40)
		  {
				if(count==0)
				{
					a_up = a_down =  0;
					a_right = a_left = 0;
					GUI_Clear();
					GUI_DispStringAt("�޵�ؼ�¼",28,64);

				}
				if(count==1)
				{
					a_up = a_down =  0;
					a_right = a_left = 1;
				}
				if(count>=1)
				{
						switch(j)
						{
							case 0:
								printf("\n\r local[%d]=%d",m,local[m]);
								printf("\n\r");
							    GUI_Clear();
								GUI_DispStringAt("��ؼ�¼ ",0,16);
								GUI_DispDecAt( m+1 ,64,16,1);
								GUI_DispStringAt("�����բʱ��:",0,40);
								GUI_DispStringAt("-",32,60);
								GUI_DispStringAt("-",60,60);
								GUI_DispStringAt(" ",88,60);
								GUI_DispStringAt(":",112,60);
								GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[6],16,60,2);//��ʾ��ǰ�洢�������¼�����
								GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[5],42,60,2);//��ʾ��ǰ�洢�������¼�����
								GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[4],68,60,2);//��ʾ��ǰ�洢�������¼�����
								GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[3],94,60,2);//��ʾ��ǰ�洢�������¼�����
								GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[2],120,60,2);//��ʾ��ǰ�洢�������¼�����
								GUI_DispStringAt("��բ�ִ�:",0,80);
								//GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[8],80,80,2);
							    if((RtuDataAddr->M_Event_Save[local[m]].Event.Buff[8]>>0)&0x01)
							    {
									GUI_DispStringAt("1",80+k*16,80);
									k++;
							    }
							    if((RtuDataAddr->M_Event_Save[local[m]].Event.Buff[8]>>1)&0x01)
							    {
									GUI_DispStringAt("2",80+k*16,80);
									k++;
							    }
							    if((RtuDataAddr->M_Event_Save[local[m]].Event.Buff[8]>>2)&0x01)
							    {
									GUI_DispStringAt("3",80+k*16,80);
									k++;
							    }
							    if((RtuDataAddr->M_Event_Save[local[m]].Event.Buff[8]>>3)&0x01)
							    {
									GUI_DispStringAt("4",80+k*16,80);
									k++;
							    }
								GUI_DispStringAt("������:",0,100);

								if((RtuDataAddr->M_Event_Save[local[m]].Event.Buff[9]&0x01))
									GUI_DispStringAt("�µ��",74,100);
								if((RtuDataAddr->M_Event_Save[local[m]].Event.Buff[9]&0x02))
									GUI_DispStringAt("�����",74,100);
								printf("\n\r local[%d]=%d",m,local[m]);
								printf("\n\r");
							break;
							case 1:
							    GUI_Clear();
								GUI_DispStringAt("��ؼ�¼ ",0,16);
								GUI_DispDecAt( m+1 ,64,16,1);
								GUI_DispStringAt("��բʱ�ĵ�����:",0,40);
							    	memset(NowInput.buf,0,128);
									sprintf(NowInput.buf,"%02x%02x%02x%02x",
											RtuDataAddr->M_Event_Save[local[m]].Event.Buff[13],
											RtuDataAddr->M_Event_Save[local[m]].Event.Buff[12],
											RtuDataAddr->M_Event_Save[local[m]].Event.Buff[11],
											RtuDataAddr->M_Event_Save[local[m]].Event.Buff[10]);
									GUI_DispStringAt(NowInput.buf,16,60);
									GUI_DispStringAt("��բʱ��������ֵ:",0,80);
							    	memset(NowInput.buf,0,128);
									sprintf(NowInput.buf,"%02x%02x%02x%02x",
											RtuDataAddr->M_Event_Save[local[m]].Event.Buff[17],
											RtuDataAddr->M_Event_Save[local[m]].Event.Buff[16],
											RtuDataAddr->M_Event_Save[local[m]].Event.Buff[15],
											RtuDataAddr->M_Event_Save[local[m]].Event.Buff[14]);
									 GUI_DispStringAt(NowInput.buf,16,100);

							break;
							default : break;

						}
					}
				//}

		  }
		  else
		  {
				if(count==0)
				{
					a_up = a_down =  0;
					a_right = a_left = 0;
					GUI_Clear();
					GUI_DispStringAt("�޵�ؼ�¼",28,64);

				}
				if(count==1)
				{
					a_up = a_down =  0;
					a_right = a_left = 1;
				}
				//for(k=RtuDataAddr->EC2-1;k>=0;k--)
				//{
					//if(RtuDataAddr->S_Event_Save[k].Event.Buff[0]==7)
				if(count>=1)
					{

						switch(j)
						{
							case 0:
								printf("\n\r local[%d]=%d",m,local[m]);
								printf("\n\r");
							    GUI_Clear();
								GUI_DispStringAt("��ؼ�¼ ",0,16);
								GUI_DispDecAt( m+1 ,64,16,1);
								GUI_DispStringAt("�����բʱ��:",0,40);
								GUI_DispStringAt("-",32,60);
								GUI_DispStringAt("-",60,60);
								GUI_DispStringAt(" ",88,60);
								GUI_DispStringAt(":",112,60);
										//GUI_DispStringAt("20",0,40);
								GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[6],16,60,2);//��ʾ��ǰ�洢�������¼�����
								GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[5],42,60,2);//��ʾ��ǰ�洢�������¼�����
								GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[4],68,60,2);//��ʾ��ǰ�洢�������¼�����
								GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[3],94,60,2);//��ʾ��ǰ�洢�������¼�����
								GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[2],120,60,2);//��ʾ��ǰ�洢�������¼�����
								GUI_DispStringAt("��բ�ִ�:",0,80);
								//GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[8],80,80,2);
							    if((RtuDataAddr->S_Event_Save[local[m]].Event.Buff[8]>>0)&0x01)
							    {
									GUI_DispStringAt("1",80+k*16,80);
									k++;
							    }
							    if((RtuDataAddr->S_Event_Save[local[m]].Event.Buff[8]>>1)&0x01)
							    {
									GUI_DispStringAt("2",80+k*16,80);
									k++;
							    }
							    if((RtuDataAddr->S_Event_Save[local[m]].Event.Buff[8]>>2)&0x01)
							    {
									GUI_DispStringAt("3",80+k*16,80);
									k++;
							    }
							    if((RtuDataAddr->S_Event_Save[local[m]].Event.Buff[8]>>3)&0x01)
							    {
									GUI_DispStringAt("4",80+k*16,80);
									k++;
							    }
								GUI_DispStringAt("������:",0,100);
								//RtuDataAddr->S_Event_Save[k].Event.Buff[9]=1;
										//printf("KongLeiBie=%d",RtuDataAddr->Event_Save.Event.Err6.KongLeiBie);
								if((RtuDataAddr->S_Event_Save[local[m]].Event.Buff[9]&0x01))
									GUI_DispStringAt("�µ��",74,100);
								if((RtuDataAddr->S_Event_Save[local[m]].Event.Buff[9]&0x02))
									GUI_DispStringAt("�����",74,100);
							break;
							case 1:
							    GUI_Clear();
								GUI_DispStringAt("��ؼ�¼ ",0,16);
								GUI_DispDecAt( m+1 ,64,16,1);
								GUI_DispStringAt("��բʱ�ĵ�����:",0,40);
							    	memset(NowInput.buf,0,128);
									sprintf(NowInput.buf,"%02x%02x%02x%02x",
											RtuDataAddr->S_Event_Save[local[m]].Event.Buff[13],
											RtuDataAddr->S_Event_Save[local[m]].Event.Buff[12],
											RtuDataAddr->S_Event_Save[local[m]].Event.Buff[11],
											RtuDataAddr->S_Event_Save[local[m]].Event.Buff[10]);
									GUI_DispStringAt(NowInput.buf,16,60);
									GUI_DispStringAt("��բʱ��������ֵ:",0,80);
							    	memset(NowInput.buf,0,128);
									sprintf(NowInput.buf,"%02x%02x%02x%02x",
											RtuDataAddr->S_Event_Save[local[m]].Event.Buff[17],
											RtuDataAddr->S_Event_Save[local[m]].Event.Buff[16],
											RtuDataAddr->S_Event_Save[local[m]].Event.Buff[15],
											RtuDataAddr->S_Event_Save[local[m]].Event.Buff[14]);
									 GUI_DispStringAt(NowInput.buf,16,100);

							break;
							default : break;

						}
					}
				//}


		  }


	     Status_Bar();
	     BottomBar();
	     Lcmfull();
	     keysele=KeySeleflag;
	     KeySeleflag =0;
	    if(keysele!=0)DelayTime=0;else DelayTime++;
	    if(DelayTime>=PageDelayTime)
	       {
	       	OldLevel=0;
	       	return 0;
	       	}
	    if(count==0)
			switch(keysele)
			{
			   case 1: DelayTime=0;break;
			   case 2: DelayTime=0;break;
			   case 3: DelayTime=0;break;//��
			   case 4: DelayTime=0;break;
			   case 5: DelayTime=0;break;
			   case 6: OldLevel=0;return 0;break;
			   default:break;
			}
	    if(count!=0)
		   switch(keysele)
		   {
		   case 1: if(m==0) m=count-1; else m=(m-1)%count; DelayTime=0;break;
		   case 2: m=(m+1)%count;DelayTime=0;break;
		   case 3: if(j==0)j=1;else j=j-1;DelayTime=0;break;//��
		   case 4: j=(j+1)%2;DelayTime=0;break;
		   case 5: DelayTime=0;break;
		   case 6: OldLevel=0;return 0;break;
		   default:break;
		   }

	  }
}

/*******************************************************************************************************************
 * �������ƣ�Show_yaokong_Record() ���ڵڶ��˵�
 * ���ܣ�ң�ؼ�¼
***********************************************************************************************************/

int Show_yaokong_Record(INT8U SeleMenu)
{
	 unsigned char keysele;
	 unsigned int DelayTime,j,count,m;
	 unsigned char local[256];
	 int i;

	 DelayTime=0;
	 j=0;
     count=0;
	 m=0;
	 a_up = a_down =  1;
	 a_right = a_left = 0;

	 printf("\n\rRtuDataAddr->Event_Value.F9_Set_Para.Event_Level[0]==%d",RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[0]);
	 printf("\n\r");
	 if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[0]&0x10)
	 {
		 printf("\n\rRtuDataAddr->EC1==%d",RtuDataAddr->Fm_Save_Eve.EC1);
		 printf("\n\r");
		 count =getevent(local,1,5);
	 }
	 else
	 {
		 count =getevent(local,0,5);
	 }

	  while(1)
	  {
		  if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[0]&0x10)
		  {

				if(count==0)
				{
					a_up = a_down =  0;
					a_right = a_left = 0;
					GUI_Clear();
					GUI_DispStringAt("��ң�ؼ�¼",28,64);

				}
				if(count==1)
				{
					a_up = a_down =  0;
					a_right = a_left =0;
				}

				if(count>=1)
					{
						GUI_Clear();
						GUI_DispStringAt("ң�ؼ�¼ ",0,16);
						GUI_DispDecAt( m+1 ,64,16,1);
						GUI_DispStringAt("ң����բʱ��:",0,32);
						GUI_DispStringAt("-",32,48);
						GUI_DispStringAt("-",60,48);
						GUI_DispStringAt(" ",88,48);
						GUI_DispStringAt(":",112,48);

						GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[6],16,48,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[5],42,48,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[4],68,48,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[3],94,48,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[2],120,48,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispStringAt("��բ�ִ�:",0,64);
						GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[7],80,64,2);
						GUI_DispStringAt("��բʱ����:",0,80);
						GUI_DispDecShiftAt(16,96,4,0,GetDataType02(&RtuDataAddr->M_Event_Save[local[m]].Event.Buff[8])/10000);
				    	/*memset(NowInput.buf,0,128);
						sprintf(NowInput.buf,"%02x%02x",
								RtuDataAddr->M_Event_Save[local[m]].Event.Buff[9],
								RtuDataAddr->M_Event_Save[local[m]].Event.Buff[8]);
						GUI_DispStringAt(NowInput.buf,16,96);*/
						GUI_DispStringAt("��բ��2min�Ĺ���:",0,112);
						GUI_DispDecShiftAt(16,128,4,0,GetDataType02(&RtuDataAddr->M_Event_Save[local[m]].Event.Buff[10])/10000);
				    /*	memset(NowInput.buf,0,128);
						sprintf(NowInput.buf,"%02x%02x",
								RtuDataAddr->M_Event_Save[local[m]].Event.Buff[11],
								RtuDataAddr->M_Event_Save[local[m]].Event.Buff[10]);
						 GUI_DispStringAt(NowInput.buf,16,128);*/
					}
		  }
		  else
		  {
				if(count==0)
				{
					a_up = a_down =  0;
					a_right = a_left = 0;
					GUI_Clear();
					GUI_DispStringAt("��ң�ؼ�¼",28,64);

				}
				if(count==1)
				{
					a_up = a_down =  0;
					a_right = a_left = 0;
				}
				//for(k=RtuDataAddr->EC2-1;k>=0;k--)
				//{
					//if(RtuDataAddr->S_Event_Save[k].Event.Buff[0]==5)
				if(count>=1)
					{
						GUI_Clear();
						GUI_DispStringAt("ң�ؼ�¼ ",0,16);
						GUI_DispDecAt( m+1 ,64,16,1);
						GUI_DispStringAt("ң����բʱ��:",0,32);
						GUI_DispStringAt("-",32,48);
						GUI_DispStringAt("-",60,48);
						GUI_DispStringAt(" ",88,48);
						GUI_DispStringAt(":",112,48);
								//GUI_DispStringAt("20",0,40);
						GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[6],16,48,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[5],42,48,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[4],68,48,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[3],94,48,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[2],120,48,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispStringAt("��բ�ִ�:",0,64);
						GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[7],80,64,2);
						GUI_DispStringAt("��բʱ����:",0,80);
				    	memset(NowInput.buf,0,128);
						sprintf(NowInput.buf,"%02x%02x",
								RtuDataAddr->S_Event_Save[local[m]].Event.Buff[9],
								RtuDataAddr->S_Event_Save[local[m]].Event.Buff[8]);
						GUI_DispStringAt(NowInput.buf,16,96);
						GUI_DispStringAt("��բ��2min�Ĺ���:",0,112);
				    	memset(NowInput.buf,0,128);
						sprintf(NowInput.buf,"%02x%02x",
								RtuDataAddr->S_Event_Save[local[m]].Event.Buff[11],
								RtuDataAddr->S_Event_Save[local[m]].Event.Buff[10]);
						 GUI_DispStringAt(NowInput.buf,16,128);
					}
				//}
		  }

	     Status_Bar();
	     BottomBar();
	     Lcmfull();
	     keysele=KeySeleflag;
	     KeySeleflag =0;
	    if(keysele!=0)DelayTime=0;else DelayTime++;
	    if(DelayTime>=PageDelayTime)
	       {
	       	OldLevel=0;
	       	return 0;
	       	}
	    if(count==0)
	    	switch(keysele)
			{
			   case 1: DelayTime=0;break;
			   case 2: DelayTime=0;break;
			   case 3: DelayTime=0;break;//��
			   case 4: DelayTime=0;break;
			   case 5: DelayTime=0;break;
			   case 6: OldLevel=0;return 0;break;
			   default:break;
			}
	    if(count!=0)
		   switch(keysele)
		   {
		   case 1: if(m==0) m=count-1; else m=(m-1)%count; DelayTime=0;break;
		   case 2: m=(m+1)%count;DelayTime=0;break;
		   case 3: if(j==0)j=1;else j=j-1;DelayTime=0;break;//��
		   case 4: j=(j+1)%2;DelayTime=0;break;
		   case 5: DelayTime=0;break;
		   case 6: OldLevel=0;return 0;break;
		   default:break;
		   }
	  }

}
/******************************************************************************************************************
* �������ƣ�Show_ShiDian_Record()�����ڵڶ����˵�
* ��    �ܣ���ʧ���¼��
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
int Show_ShiDian_Record(INT8U SeleMenu)
{

	 unsigned char keysele;
	 unsigned int DelayTime,j,count,m;
	 int k,i;
	 unsigned char local[256];

	 DelayTime=0;
	 j=0;
     count=0;
	 m=0;
	 a_up = a_down =  1;
	 a_right = a_left = 0;
	 if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[1] & 0x20)
	 {
		 //printf("\n\r M_EVENT !!!!!!!!!!");
		 //printf("\n\rRtuDataAddr->EC1====%d",RtuDataAddr->EC1);
		 //printf("\n\rRtuDataAddr->M_Event_Save[i].Event.Buff[0]====%d",RtuDataAddr->M_Event_Save[i].Event.Buff[0]);
		 count =getevent(local,1,14);
			// printf("\n\rcount====%d",count);
	 }
	 else
	 {
		 count =getevent(local,0,14);
	 }
	  while(1)
	  {
		  if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[1] & 0x20)
		  {
				if(count==0)
				{
					a_up = a_down =  0;
					a_right = a_left = 0;
					GUI_Clear();
					GUI_DispStringAt("��ʧ���¼",28,64);

				}
				if(count==1)
				{
					a_up = a_down =  0;
					a_right = a_left = 0;
				}

					if(count>=1)
					{
						GUI_Clear();
						GUI_DispStringAt("ʧ���¼ ",0,16);
						GUI_DispDecAt( m+1 ,64,16,1);
						GUI_DispStringAt("ʧ�緢��ʱ��:",0,40);
						GUI_DispStringAt("-",32,60);
						GUI_DispStringAt("-",60,60);
						GUI_DispStringAt(" ",88,60);
						GUI_DispStringAt(":",112,60);
								//GUI_DispStringAt("20",0,40);
						GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[6],16,60,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[5],42,60,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[4],68,60,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[3],94,60,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[2],120,60,2);//��ʾ��ǰ�洢�������¼�����

						GUI_DispStringAt("�ָ�ʱ��:",0,80);
						GUI_DispStringAt("-",32,100);
						GUI_DispStringAt("-",60,100);
						GUI_DispStringAt(" ",88,100);
						GUI_DispStringAt(":",112,100);

						GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[11],16,100,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[10],42,100,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[9],68,100,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[8],94,100,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispHexAt(RtuDataAddr->M_Event_Save[local[m]].Event.Buff[7],120,100,2);//��ʾ��ǰ�洢�������¼�����

					}

		  }
		  else
		  {
				if(count==0)
				{
					a_up = a_down =  0;
					a_right = a_left = 0;
					GUI_Clear();
					GUI_DispStringAt("��ʧ���¼",28,64);

				}
				if(count==1)
				{
					a_up = a_down =  0;
					a_right = a_left = 0;
				}
				//for(k=RtuDataAddr->Fm_Save_Eve.EC2-1;k>=0;k--)
				//{
					//if(RtuDataAddr->S_Event_Save[k].Event.Buff[0]==14)
					if(count>=1)
					{
						GUI_Clear();
						GUI_DispStringAt("ʧ���¼ ",0,16);
						GUI_DispDecAt( m+1 ,64,16,1);
						GUI_DispStringAt("ʧ�緢��ʱ��:",0,40);
						GUI_DispStringAt("-",32,60);
						GUI_DispStringAt("-",60,60);
						GUI_DispStringAt(" ",88,60);
						GUI_DispStringAt(":",112,60);
								//GUI_DispStringAt("20",0,40);
						GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[6],16,60,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[5],42,60,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[4],68,60,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[3],94,60,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[2],120,60,2);//��ʾ��ǰ�洢�������¼�����

						GUI_DispStringAt("�ָ�ʱ��:",0,80);
						GUI_DispStringAt("-",32,100);
						GUI_DispStringAt("-",60,100);
						GUI_DispStringAt(" ",88,100);
						GUI_DispStringAt(":",112,100);

						GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[11],16,100,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[10],42,100,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[9],68,100,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[8],94,100,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispHexAt(RtuDataAddr->S_Event_Save[local[m]].Event.Buff[7],120,100,2);//��ʾ��ǰ�洢�������¼�����

					}
				//}
		  }

	     Status_Bar();
	     BottomBar();
	     Lcmfull();
	     keysele=KeySeleflag;
	     KeySeleflag =0;
	    if(keysele!=0)DelayTime=0;else DelayTime++;
	    if(DelayTime>=PageDelayTime)
	       {
	       	OldLevel=0;
	       	return 0;
	       	}
	    if(count==0)
	    	switch(keysele)
			{
			   case 1: DelayTime=0;break;
			   case 2: DelayTime=0;break;
			   case 3: DelayTime=0;break;//��
			   case 4: DelayTime=0;break;
			   case 5: DelayTime=0;break;
			   case 6: OldLevel=0;return 0;break;
			   default:break;
			}
	    if(count!=0)
		   switch(keysele)
		   {
			   case 1: if(m==0) m=count-1; else m=(m-1)%count; DelayTime=0;break;
			   case 2: m=(m+1)%count;DelayTime=0;break;
			   case 3: if(j==0)j=1;else j=j-1;DelayTime=0;break;//��
			   case 4: j=(j+1)%2;DelayTime=0;break;
			   case 5: DelayTime=0;break;
			   case 6: OldLevel=0;return 0;break;
			   default:break;
		   }
	  }

}
/******************************************************************************************************************
* �������ƣ�Show_GouDian()�����ڵڶ����˵�
* ��    �ܣ���������Ϣ��
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
int Show_GouDian(INT8U SeleMenu)
{
		 unsigned char keysele,GoudianNum;
		 unsigned int DelayTime;

		 DelayTime=0;
		 GoudianNum=0;
		   	a_up = a_down =  1;
		   	a_right = a_left = 0;

		  while(1)
		  {

		    GUI_Clear();

		     GUI_DispStringAt("�ܼ��� :",0,16);
		     GUI_SetTextMode(GUI_TM_REV);
		     GUI_DispDecAt(GoudianNum+1 ,48,16,1);
		     GUI_SetTextMode(GUI_TM_NORMAL);

		    GUI_DispStringAt("���絥��:",0,36);
		    memset(NowInput.buf,0,128);
			        sprintf(NowInput.buf,"%02x%02x%02x%02x",
					RtuDataAddr->Zj_Control_Value[GoudianNum].F47_Set_Para.Gou_DIan_DanHao[3],
					RtuDataAddr->Zj_Control_Value[GoudianNum].F47_Set_Para.Gou_DIan_DanHao[2],
					RtuDataAddr->Zj_Control_Value[GoudianNum].F47_Set_Para.Gou_DIan_DanHao[1],
					RtuDataAddr->Zj_Control_Value[GoudianNum].F47_Set_Para.Gou_DIan_DanHao[0]);
			GUI_DispStringAt(NowInput.buf,72,36);
		    GUI_DispStringAt("��ǰ����:",0,52);

		    GUI_DispDecShiftAt(72,52,8,0,GetdataType03(RtuDataAddr->Zj_Control_Value[GoudianNum].Old_DianLiang));
		    /*memset(NowInput.buf,0,128);
			        sprintf(NowInput.buf,"%02x%02x%02x%02x",
			        		RtuDataAddr->Zj_Control_Value[GoudianNum].Old_DianLiang[3],
			        		RtuDataAddr->Zj_Control_Value[GoudianNum].Old_DianLiang[2],
			        		RtuDataAddr->Zj_Control_Value[GoudianNum].Old_DianLiang[1],
			        		RtuDataAddr->Zj_Control_Value[GoudianNum].Old_DianLiang[0]);
			GUI_DispStringAt(NowInput.buf,72,52);*/


		    GUI_DispStringAt("�������:",0,68);
		    GUI_DispDecShiftAt(72,68,8,0,(GetdataType03(RtuDataAddr->Zj_Control_Value[GoudianNum].New_DianLiang)));
		   /* memset(NowInput.buf,0,128);
			        sprintf(NowInput.buf,"%02x%02x%02x%02x",
			        		RtuDataAddr->Zj_Control_Value[GoudianNum].New_DianLiang[3],
			        		RtuDataAddr->Zj_Control_Value[GoudianNum].New_DianLiang[2],
			        		RtuDataAddr->Zj_Control_Value[GoudianNum].New_DianLiang[1],
			        		RtuDataAddr->Zj_Control_Value[GoudianNum].New_DianLiang[0]);
			GUI_DispStringAt(NowInput.buf,72,68);*/
			//GUI_DispStringAt("kwh",134,48);

		    GUI_DispStringAt("��������:",0,84);
		    memset(NowInput.buf,0,128);
			        sprintf(NowInput.buf,"%02x%02x%02x%02x",
					RtuDataAddr->Zj_Control_Value[GoudianNum].F47_Set_Para.Alarm_Men[3],
					RtuDataAddr->Zj_Control_Value[GoudianNum].F47_Set_Para.Alarm_Men[2],
					RtuDataAddr->Zj_Control_Value[GoudianNum].F47_Set_Para.Alarm_Men[1],
					RtuDataAddr->Zj_Control_Value[GoudianNum].F47_Set_Para.Alarm_Men[0]);
			GUI_DispStringAt(NowInput.buf,72,84);
			//GUI_DispStringAt("kwh",134,64);

		    GUI_DispStringAt("��բ����:",0,100);
		    memset(NowInput.buf,0,128);
			        sprintf(NowInput.buf,"%02x%02x%02x%02x",
					RtuDataAddr->Zj_Control_Value[GoudianNum].F47_Set_Para.TiaoZha_Men[3],
					RtuDataAddr->Zj_Control_Value[GoudianNum].F47_Set_Para.TiaoZha_Men[2],
					RtuDataAddr->Zj_Control_Value[GoudianNum].F47_Set_Para.TiaoZha_Men[1],
					RtuDataAddr->Zj_Control_Value[GoudianNum].F47_Set_Para.TiaoZha_Men[0]);
			GUI_DispStringAt(NowInput.buf,72,100);
			//GUI_DispStringAt("kwh",134,80);
		    //GUI_DispStringAt("�ִ���բ����:",0,112);

		    //GUI_DispDecShiftAt(104,112,7,0,RtuDataAddr->Gou_Dian_Kong_Value[GoudianNum].LunCi);
			printf("\n\r lcm shengyu[%d]==%d",GoudianNum,RtuDataAddr->Real_Zj_Value[GoudianNum].ShengYuDianLiang);
            GUI_DispStringAt("ʣ�����:",0,116);
		    GUI_DispDecShiftAt(72,116,8,0,(RtuDataAddr->Real_Zj_Value[GoudianNum].ShengYuDianLiang));
		    //GUI_DispStringAt("kwh",134,96);

		     Status_Bar();
		     BottomBar();
		     Lcmfull();
 		     keysele=KeySeleflag;
		     KeySeleflag =0;
		    if(keysele!=0)DelayTime=0;else DelayTime++;
		    if(DelayTime>=PageDelayTime)
		       {
		       	OldLevel=10;
		       	MenuSele = 5;
		       	return 0;
		       	}
			   switch(keysele)
			   {
			   case 1: if(GoudianNum==0)GoudianNum=7;else GoudianNum=GoudianNum-1;DelayTime=0;break;//��
			   case 2: GoudianNum=(GoudianNum+1)%ZongJia_Max;DelayTime=0;break;//��
			   case 6: OldLevel=10;MenuSele = 5;return 0;break;
			   default:break;
			   }

		  }


}

/******************************************************************************************************************
* �������ƣ�Show_ZhongDuan_Xx()�����ڵڶ����˵�
* ��    �ܣ����汾��Ϣ��
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
int Show_ZhongDuan_Xx(INT8U SeleMenu)
{
	unsigned char keysele,TempBuf[16],x,i,m;
	unsigned int DelayTime,tmpaddr,j;

	DelayTime=0;
	j=0;
	  while(1)
	  {

				GUI_Clear();
				GUI_DispStringAt("1.��������:",0,16);
				GUI_DispStringAt("2.��������:",0,32);
				GUI_DispStringAt("3.�ն˵�ַ:",0,48);
				GUI_DispStringAt("4.�ն˱��:",0,64);
				GUI_DispStringAt("5.�����汾:",0,80);
				GUI_DispStringAt("6.ͨ������:",0,96);
				GUI_DispStringAt("7.������ʱ:",0,112);
				memset(TempBuf,0,16);
				sprintf(TempBuf,"%02x%02x",
						 RtuDataAddr->FkComm_Value.GB22601991[1],
						 RtuDataAddr->FkComm_Value.GB22601991[0]
						);  //����ת����Ϊ�ַ���
				GUI_DispStringAt(TempBuf,88,32);//��������
				tmpaddr= (RtuDataAddr->FkComm_Value.ADDR[1]<<8)+ RtuDataAddr->FkComm_Value.ADDR[0];
				memset(TempBuf,0,16);
				sprintf(TempBuf,"%05d",tmpaddr);
			    GUI_DispStringAt(TempBuf,88,48);//�ն˵�ַ

				GUI_DispStringAt("1.0",88,80);//�����汾

				GUI_DispDecAt(RtuDataAddr->FkComm_Value.F1_Set_Para.RTS_Time,88,112,4);//������ʱ

	     Status_Bar();
	     Lcmfull();
	     keysele=KeySeleflag;
	     KeySeleflag =0;
	    if(keysele!=0)DelayTime=0;else DelayTime++;
	    if(DelayTime>=PageDelayTime)
	       {
	       	OldLevel=10;
	       	return 0;
	       	}
	   switch(keysele)
	   {
	   case 0:DelayTime++;break;
	   case 1: break;
	   case 2:  break;
	   case 3: if(j==0)j=2;else j=j-1;DelayTime=0;break;//��
	   case 4: j=(j+1)%3;DelayTime=0;break;
	   case 5: DelayTime=0;break;
	   case 6: OldLevel=10;MenuSele = 6;return 0;break;
	   default:break;
	   }

	  }

}


/******************************************************************************************************************
* �������ƣ�Show_ShiDuan_Can()�����ڵڶ����˵�
* ��    �ܣ���ʱ�οز�����
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void initAllShiDuanshow()
{
	INT8U i,Temp,SdNo;
	INT16U NinCountTemp;
	NinCountTemp=0;
	SdNo=0;
	for(i=0;i<8;i++)
	{
		RtuDataAddr->All_ShiD_Value[i].startMin=0;
		RtuDataAddr->All_ShiD_Value[i].endMin=0;
		RtuDataAddr->All_ShiD_Value[i].Valid=0;
	}
	for(i=0;i<12;i++)
	{

		ShowSd48[i*4]=RtuDataAddr->Fk_Control_Set_Value.F18_Set_Para.ZD_GK_SD[i]&0x03;
		ShowSd48[i*4+1]=(RtuDataAddr->Fk_Control_Set_Value.F18_Set_Para.ZD_GK_SD[i]>>2)&0x03;
		ShowSd48[i*4+2]=(RtuDataAddr->Fk_Control_Set_Value.F18_Set_Para.ZD_GK_SD[i]>>4)&0x03;
		ShowSd48[i*4+3]=(RtuDataAddr->Fk_Control_Set_Value.F18_Set_Para.ZD_GK_SD[i]>>6)&0x03;

	}

	Temp=ShowSd48[0];
	RtuDataAddr->All_ShiD_Value[SdNo].startMin=0;
	for(i=0;i<48;i++)
	{
		if((Temp==0)||(Temp==3))
		{
			RtuDataAddr->All_ShiD_Value[SdNo].Valid=0;
		}
		else
		{
			RtuDataAddr->All_ShiD_Value[SdNo].Valid=1;
		}
		if(Temp!=ShowSd48[i])
		{
			RtuDataAddr->All_ShiD_Value[SdNo].endMin=NinCountTemp;
			Temp=ShowSd48[i];
			//printf("\n\rendMin=%d ",RtuDataAddr->All_ShiD_Value[SdNo].endMin);

			SdNo++;
			RtuDataAddr->All_ShiD_Value[SdNo].startMin=NinCountTemp;

			//printf("\n\rstartMin=%d ",RtuDataAddr->All_ShiD_Value[SdNo].startMin);
			//printf("\n\r");

		}
		NinCountTemp+=30;
		if(SdNo>=8)break;
	}
	RtuDataAddr->All_ShiD_Value[SdNo].endMin=NinCountTemp;
}
void initShiDuanshow(INT8U P)
{
	INT16U NinCountTemp;
	INT8U i,SdNo;
	NinCountTemp=0;
	SdNo=0;
	for(i=0;i<8;i++)
	{
		RtuDataAddr->ShiD_Kong_Value[P].Shiduan_value[i].Valid=0;
		RtuDataAddr->ShiD_Kong_Value[P].Shiduan_value[i].startMin=RtuDataAddr->All_ShiD_Value[i].startMin;
		RtuDataAddr->ShiD_Kong_Value[P].Shiduan_value[i].endMin=RtuDataAddr->All_ShiD_Value[i].endMin;
		RtuDataAddr->ShiD_Kong_Value[P].Shiduan_value[i].DingZhi=0;
	}
	for(i=0;i<8;i++)
	{
		if(RtuDataAddr->All_ShiD_Value[i].Valid==1)
		{
			RtuDataAddr->ShiD_Kong_Value[P].Shiduan_value[i].Valid=1;
		}
	}
}
int ShiDuanShow(INT8U ZongJia,INT8U Page)
{
	INT8U m,i=0;
	INT8U n=0;
    if(Page>=0&&Page<=5)
    {
    	GUI_Clear();
    	if(Page==0||Page==1)
    	{
    		n=0;
            GUI_DispStringAt("�ܼ��� ������:",0,16);
            GUI_DispDecAt( ZongJia+1,48,16,1);
            GUI_DispStringAt("1",104,16);
    	}

    	if(Page==2||Page==3)
    	{
    		n=1;
            GUI_DispStringAt("�ܼ��� ������:",0,16);
            GUI_DispDecAt( ZongJia+1,48,16,1);
            GUI_DispStringAt("2",104,16);
    	}
    	if(Page==4||Page==5)
    	{
    		n=2;
            GUI_DispStringAt("�ܼ��� ������:",0,16);
            GUI_DispDecAt( ZongJia+1,48,16,1);
            GUI_DispStringAt("3",104,16);
    	}
        GUI_DispStringAt("Ͷ���ִ�:",0,32);
	    if((RtuDataAddr->Zj_Control_Value[ZongJia].F45_Set_Para.GongKong_Lunci_Biaozhi>>0)&0x01)
	    {
			GUI_DispStringAt("1",88+i*16,32);
			i++;
	    }
	    if((RtuDataAddr->Zj_Control_Value[ZongJia].F45_Set_Para.GongKong_Lunci_Biaozhi>>1)&0x01)
	    {
			GUI_DispStringAt("2",88+i*16,32);
			i++;
	    }
	    if((RtuDataAddr->Zj_Control_Value[ZongJia].F45_Set_Para.GongKong_Lunci_Biaozhi>>2)&0x01)
	    {
			GUI_DispStringAt("3",88+i*16,32);
			i++;
	    }
	    if((RtuDataAddr->Zj_Control_Value[ZongJia].F45_Set_Para.GongKong_Lunci_Biaozhi>>3)&0x01)
	    {
			GUI_DispStringAt("4",88+i*16,32);
			i++;
	    }
		 initAllShiDuanshow();
		 initShiDuanshow(ZongJia);
        GUI_DispStringAt("ʱ��",0,48);
        GUI_DispStringAt("��ֵ(KW)",96,48);
    	if(Page==0||Page==2||Page==4)
    	{
    	     GUI_DispStringAt("(1-4)",32,48);
    	     for(m=0;m<4;m++)
    	     {
    	   	     GUI_DispDecAt(RtuDataAddr->ShiD_Kong_Value[ZongJia].Shiduan_value[m].startMin/60 ,0,(64+m*16),2);
    	   	     GUI_DispDecAt(RtuDataAddr->ShiD_Kong_Value[ZongJia].Shiduan_value[m].startMin%60 ,24,(64+m*16),2);
    	   	     GUI_DispStringAt(":",16,(64+m*16));
    	   	     GUI_DispStringAt("-",40,(64+m*16));
    	    	 GUI_DispDecAt(RtuDataAddr->ShiD_Kong_Value[ZongJia].Shiduan_value[m].endMin/60 ,48,(64+m*16),2);
    	    	 GUI_DispDecAt(RtuDataAddr->ShiD_Kong_Value[ZongJia].Shiduan_value[m].endMin%60 ,72,(64+m*16),2);
    	    	 GUI_DispStringAt(":",64,(64+m*16));
    	    	 //GUI_DispDecAt(RtuDataAddr->ShiD_Kong_Value[ZongJia].Shiduan_value[m].DingZhi ,96,(64+m*16),7);
    	    	 GUI_DispDecShiftAt(96,(64+m*16),7,0,GetDataType02(&RtuDataAddr->Zj_Control_Value[ZongJia].F41_Set_Para.ShiDuan_DingZhi[n].ShiDG_DingZhi[m][0])/10000);

    	     }
    	}
       	if(Page==1||Page==3||Page==5)
        {
            GUI_DispStringAt("(5-8)",32,48);
   	     for(m=4;m<8;m++)
   	     {
   	   	     GUI_DispDecAt(RtuDataAddr->ShiD_Kong_Value[ZongJia].Shiduan_value[m].startMin/60 ,0,(64+(m-4)*16),2);
   	   	     GUI_DispDecAt(RtuDataAddr->ShiD_Kong_Value[ZongJia].Shiduan_value[m].startMin%60 ,24,(64+(m-4)*16),2);
   	   	     GUI_DispStringAt(":",16,(64+(m-4)*16));
   	   	     GUI_DispStringAt("-",40,(64+(m-4)*16));
   	    	 GUI_DispDecAt(RtuDataAddr->ShiD_Kong_Value[ZongJia].Shiduan_value[m].endMin/60 ,48,(64+(m-4)*16),2);
   	    	 GUI_DispDecAt(RtuDataAddr->ShiD_Kong_Value[ZongJia].Shiduan_value[m].endMin%60 ,72,(64+(m-4)*16),2);
	    	 //GUI_DispDecAt(RtuDataAddr->ShiD_Kong_Value[ZongJia].Shiduan_value[m].DingZhi ,96,(64+(m-4)*16),7);
			 GUI_DispDecShiftAt(96,(64+(m-4)*16),7,0,GetDataType02(&RtuDataAddr->Zj_Control_Value[ZongJia].F41_Set_Para.ShiDuan_DingZhi[n].ShiDG_DingZhi[m][0])/10000);
   	    	 GUI_DispStringAt(":",64,(64+(m-4)*16));
   	     }
        }
       	return 1;
    }
    else
    	return 0;



}
int Show_ShiDuan_Can(INT8U SeleMenu)
{
		 unsigned char keysele,GoudianNum,j;
		 unsigned int DelayTime;

		 DelayTime=0;
		 GoudianNum=0;
		 j=0;
		 a_up = a_down =  1;
		 a_right = a_left = 1;

		  while(1)
		  {
			 ShiDuanShow(GoudianNum,j);
		     Status_Bar();
		     BottomBar();
		     Lcmfull();
  		     keysele=KeySeleflag;
		     KeySeleflag =0;
		    if(keysele!=0)DelayTime=0;else DelayTime++;
		    if(DelayTime>=PageDelayTime)
		       {
		       	OldLevel=0;
		       	return 0;
		       	}
			   switch(keysele)
			   {
			   case 1: if(GoudianNum==0)GoudianNum=7;else GoudianNum=GoudianNum-1;DelayTime=0;break;//��
			   case 2: GoudianNum=(GoudianNum+1)%ZongJia_Max;DelayTime=0;break;//��
			   case 3: if(j==0)j=5;else j=j-1;DelayTime=0;break;//��
			   case 4: j=(j+1)%6;DelayTime=0;break;//��
			   case 6: OldLevel=0;return 0;break;
			   default:break;
			   }

		  }


}
/******************************************************************************************************************
* �������ƣ�Show_ChangXiu_Can()�����ڵڶ����˵�
* ��    �ܣ������ݿز�����
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
int Show_ChangXiu_Can(INT8U SeleMenu)
{
		 unsigned char keysele,GoudianNum,i,j,m,Min,Hour;
		 unsigned int DelayTime,Xiandian_End;

		 DelayTime=0;
		 GoudianNum=0;
		 i=0;
		 j=0;
         Min=0;
         Hour=0;
         Xiandian_End=0;
		 a_up = a_down =  1;
		 a_right = a_left = 0;

		  while(1)
		  {
			  i=0;
			  j=0;
			  m=0;
			    GUI_Clear();
			    GUI_DispStringAt("�ܼ��� ���ݿز���",0,16);
			    GUI_DispDecAt( GoudianNum+1,48,16,1);

			    GUI_DispStringAt("Ͷ���ִ�:",0,32);
			    //GUI_DispDecAt(RtuDataAddr->Gonglv_XiaFu_Value[GoudianNum].LunCi ,72,32,2);
			    if((RtuDataAddr->Zj_Control_Value[GoudianNum].F45_Set_Para.GongKong_Lunci_Biaozhi>>0)&0x01)
			    {
					GUI_DispStringAt("1",72+m*16,32);
					m++;
			    }
			    if((RtuDataAddr->Zj_Control_Value[GoudianNum].F45_Set_Para.GongKong_Lunci_Biaozhi>>1)&0x01)
			    {
					GUI_DispStringAt("2",72+m*16,32);
					m++;
			    }
			    if((RtuDataAddr->Zj_Control_Value[GoudianNum].F45_Set_Para.GongKong_Lunci_Biaozhi>>2)&0x01)
			    {
					GUI_DispStringAt("3",72+m*16,32);
					m++;
			    }
			    if((RtuDataAddr->Zj_Control_Value[GoudianNum].F45_Set_Para.GongKong_Lunci_Biaozhi>>3)&0x01)
			    {
					GUI_DispStringAt("4",72+m*16,32);
					m++;
			    }


			    GUI_DispStringAt("���ݿض�ֵ:",0,48);

			    GUI_DispDecAt(GetDataType02(&RtuDataAddr->Zj_Control_Value[GoudianNum].F42_Set_Para.ChangXiu_DingZhi[0])/10000 ,88,48,7);

				Min=RtuDataAddr->Zj_Control_Value[GoudianNum].F42_Set_Para.XianDian_Start_Time[0];
				Min=((Min>>4)*10)+(Min&0x0f);
				Hour=RtuDataAddr->Zj_Control_Value[GoudianNum].F42_Set_Para.XianDian_Start_Time[1];
				Hour=((Hour>>4)*10)+(Hour&0x0f);
				Xiandian_End=(Hour*60+Min)+(RtuDataAddr->Zj_Control_Value[GoudianNum].F42_Set_Para.XianDian_Delay_Time*30);
				GUI_DispStringAt("��ʼʱ��:",0,64);
			    GUI_DispDecAt(Hour,72,64,2);
			    GUI_DispStringAt(":",88,64);
			    GUI_DispDecAt(Min ,96,64,2);
			    GUI_DispStringAt("��ֹʱ��:",0,80);
			    GUI_DispDecAt(Xiandian_End/60 ,72,80,2);
			    GUI_DispStringAt(":",88,80);
			    GUI_DispDecAt(Xiandian_End%60 ,96,80,2);
			    //GUI_DispStringAt("Ͷ���ִ�:",0,80);
			    //GUI_DispDecAt(RtuDataAddr->changxiu_Kong_Value[GoudianNum].LunCi ,72,80,2);
			    GUI_DispStringAt("������:",0,96);
			    //GUI_DispDecAt(RtuDataAddr->changxiu_Kong_Value[GoudianNum].XianDianWeek,84,106,2);
		    if((RtuDataAddr->Zj_Control_Value[GoudianNum].F42_Set_Para.XianDian_Day>>1)&0x01)
		    {
				GUI_DispStringAt("��һ",i*40,(112+j*16));
				i++;
				if(i==4)
				{
					i=0;
					j++;
				}
		    }
		    if((RtuDataAddr->Zj_Control_Value[GoudianNum].F42_Set_Para.XianDian_Day>>2)&0x01)
		    {
				GUI_DispStringAt("�ܶ�",i*40,(112+j*16));
				i++;
				if(i==4)
				{
					i=0;
					j++;
				}
		    }
		    if((RtuDataAddr->Zj_Control_Value[GoudianNum].F42_Set_Para.XianDian_Day>>3)&0x01)
		    {
				GUI_DispStringAt("����",i*40,(112+j*16));
				i++;
				if(i==4)
				{
					i=0;
					j++;
				}
		    }
		    if((RtuDataAddr->Zj_Control_Value[GoudianNum].F42_Set_Para.XianDian_Day>>4)&0x01)
		    {
				GUI_DispStringAt("����",i*40,(112+j*16));
				i++;
				if(i==4)
				{
					i=0;
					j++;
				}
		    }

		    if((RtuDataAddr->Zj_Control_Value[GoudianNum].F42_Set_Para.XianDian_Day>>5)&0x01)
		    {
				GUI_DispStringAt("����",i*40,(112+j*16));
				i++;
				if(i==4)
				{
					i=0;
					j++;
				}
		    }
		    if((RtuDataAddr->Zj_Control_Value[GoudianNum].F42_Set_Para.XianDian_Day>>6)&0x01)
		    {
				GUI_DispStringAt("����",i*40,(112+j*16));
				i++;
				if(i==4)
				{
					i=0;
					j++;
				}
		    }
		    if((RtuDataAddr->Zj_Control_Value[GoudianNum].F42_Set_Para.XianDian_Day>>7)&0x01)
		    {
				GUI_DispStringAt("����",i*40,(112+j*16));
				i++;
				if(i==4)
				{
					i=0;
					j++;
				}
		    }

		     Status_Bar();
		     BottomBar();
		     Lcmfull();
  		     keysele=KeySeleflag;
		     KeySeleflag =0;
		    if(keysele!=0)DelayTime=0;else DelayTime++;
		    if(DelayTime>=PageDelayTime)
		       {
		       	OldLevel=0;
		       	return 0;
		       	}
			   switch(keysele)
			   {
			   case 1: if(GoudianNum==0)GoudianNum=7;else GoudianNum=GoudianNum-1;DelayTime=0;break;//��
			   case 2: GoudianNum=(GoudianNum+1)%ZongJia_Max;DelayTime=0;break;//��
			   case 6: GUI_SetTextMode(GUI_TM_NORMAL);OldLevel=0;return 0;break;
			   default:break;
			   }

		  }

}
/******************************************************************************************************************
* �������ƣ�Show_YingYe_Can()�����ڵڶ����˵�
* ��    �ܣ���Ӫҵ��������
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
int Show_YingYe_Can(INT8U SeleMenu)
{
		 unsigned char keysele,GoudianNum;
		 unsigned int DelayTime;

		 DelayTime=0;
		 GoudianNum=0;
		 a_up = a_down =  1;
		 a_right = a_left = 0;

		  while(1)
		  {
		    GUI_Clear();
		    GUI_DispStringAt("�ܼ���  Ӫҵ��ͣ����",0,16);
		    GUI_DispDecAt( GoudianNum+1,56,16,1);

		    GUI_DispStringAt("��ͣ�ض�ֵ:",8,40);
		    GUI_DispDecAt(RtuDataAddr->YingyeBaoting_Value[GoudianNum].DingZhi ,96,40,3);

		    GUI_DispStringAt("��ʼʱ��:",8,56);
		    GUI_DispDecAt(RtuDataAddr->YingyeBaoting_Value[GoudianNum].Day_start ,80,56,5);

		    GUI_DispStringAt("��ֹʱ��:",8,72);
		    GUI_DispDecAt(RtuDataAddr->YingyeBaoting_Value[GoudianNum].Day_End ,80,72,5);

		    GUI_DispStringAt("Ͷ���ִ�:",8,88);
		    GUI_DispDecAt(RtuDataAddr->YingyeBaoting_Value[GoudianNum].LunCi ,80,88,2);


		     Status_Bar();
		     BottomBar();
		     Lcmfull();
  		     keysele=KeySeleflag;
		     KeySeleflag =0;
		    if(keysele!=0)DelayTime=0;else DelayTime++;
		    if(DelayTime>=PageDelayTime)
		       {
		       	OldLevel=0;
		       	return 0;
		       	}
			   switch(keysele)
			   {
			   case 1: if(GoudianNum==0)GoudianNum=7;else GoudianNum=GoudianNum-1;DelayTime=0;break;//��
			   case 2: GoudianNum=(GoudianNum+1)%ZongJia_Max;DelayTime=0;break;//��
			   case 6: OldLevel=0;return 0;break;
			   default:break;
			   }

		  }

}
/******************************************************************************************************************
* �������ƣ�Show_XiaFu_Can()�����ڵڶ����˵�
* ��    �ܣ����¸�������
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
int Show_XiaFu_Can(INT8U SeleMenu)
{
		 unsigned char keysele,GoudianNum,i,k;
		 unsigned int DelayTime;

		 DelayTime=0;
		 GoudianNum=0;
		 k=0;
		 a_up = a_down =  1;
		 a_right = a_left = 0;

		  while(1)
		  {
		    GUI_Clear();
		    i=0;
		    GUI_DispStringAt("�ܼ��� �¸��ز���",12,16);
		    GUI_DispDecAt( GoudianNum+1,60,16,1);

		    GUI_DispStringAt("Ͷ���ִ�:",0,32);
		    if((RtuDataAddr->Zj_Control_Value[GoudianNum].F45_Set_Para.GongKong_Lunci_Biaozhi>>0)&0x01)
		    {
				GUI_DispStringAt("1",72+i*16,32);
				i++;
		    }
		    if((RtuDataAddr->Zj_Control_Value[GoudianNum].F45_Set_Para.GongKong_Lunci_Biaozhi>>1)&0x01)
		    {
				GUI_DispStringAt("2",72+i*16,32);
				i++;
		    }
		    if((RtuDataAddr->Zj_Control_Value[GoudianNum].F45_Set_Para.GongKong_Lunci_Biaozhi>>2)&0x01)
		    {
				GUI_DispStringAt("3",72+i*16,32);
				i++;
		    }
		    if((RtuDataAddr->Zj_Control_Value[GoudianNum].F45_Set_Para.GongKong_Lunci_Biaozhi>>3)&0x01)
		    {
				GUI_DispStringAt("4",72+i*16,32);
				i++;
		    }
		    GUI_DispStringAt("��1�ָ澯ʱ��:",0,48);
		    GUI_DispDecAt(RtuDataAddr->FuKong_Control_Value.F12_Control_Para[GoudianNum].Gonglv_Xiafu_Gaojing_Time1,112,48,2);
		    GUI_DispStringAt("min",132,48);
		    GUI_DispStringAt("��2�ָ澯ʱ��:",0,64);
		    GUI_DispDecAt(RtuDataAddr->FuKong_Control_Value.F12_Control_Para[GoudianNum].Gonglv_Xiafu_Gaojing_Time2,112,64,2);
		    GUI_DispStringAt("min",132,64);
		    GUI_DispStringAt("��3�ָ澯ʱ��:",0,80);
		    GUI_DispDecAt(RtuDataAddr->FuKong_Control_Value.F12_Control_Para[GoudianNum].Gonglv_Xiafu_Gaojing_Time3 ,112,80,2);
		    GUI_DispStringAt("min",132,80);
		    GUI_DispStringAt("��4�ָ澯ʱ��:",0,96);
		    GUI_DispDecAt(RtuDataAddr->FuKong_Control_Value.F12_Control_Para[GoudianNum].Gonglv_Xiafu_Gaojing_Time4 ,112,96,2);
		    GUI_DispStringAt("min",132,96);
		    GUI_DispStringAt("����ʱ��:",0,112);
		   // GUI_DispDecAt(RtuDataAddr->Gonglv_XiaFu_Value[GoudianNum].Gonglv_Xiafu_Kongzhi_Time ,72,112,2);
			GUI_DispDecShiftAt(72,112,4,1,RtuDataAddr->FuKong_Control_Value.F12_Control_Para[GoudianNum].Gonglv_Xiafu_Kongzhi_Time*5);
		    GUI_DispStringAt("h",110,112);
			GUI_DispStringAt("����ϵ��:",0,128);
			if(RtuDataAddr->FuKong_Control_Value.F12_Control_Para[GoudianNum].Gonglv_Xiafu_HuaCXha_XiShu&0x80)
			{
				GUI_DispStringAt("-",80,128);
			}
			else
			{
				GUI_DispStringAt("+",80,128);
			}
			k=(((RtuDataAddr->FuKong_Control_Value.F12_Control_Para[GoudianNum].Gonglv_Xiafu_HuaCXha_XiShu>>4)&0x07)*10)+(RtuDataAddr->FuKong_Control_Value.F12_Control_Para[GoudianNum].Gonglv_Xiafu_HuaCXha_XiShu&0x0f);
			GUI_DispDecAt(k,88,128,3);
		    GUI_DispStringAt("%",120,128);
		     Status_Bar();
		     BottomBar();
		     Lcmfull();
  		     keysele=KeySeleflag;
		     KeySeleflag =0;
		    if(keysele!=0)DelayTime=0;else DelayTime++;
		    if(DelayTime>=PageDelayTime)
		       {
		       	OldLevel=0;
		       	return 0;
		       	}
			   switch(keysele)
			   {
			   case 1: if(GoudianNum==0)GoudianNum=7;else GoudianNum=GoudianNum-1;DelayTime=0;break;//��
			   case 2: GoudianNum=(GoudianNum+1)%ZongJia_Max;DelayTime=0;break;//��
			   case 6: OldLevel=0;return 0;break;
			   default:break;
			   }

		  }

}
/******************************************************************************************************************
* �������ƣ�Show_YueDian_Can()�����ڵڶ����˵�
* ��    �ܣ����¸�������
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
int Show_YueDian_Can(INT8U SeleMenu)
{
		 unsigned char keysele,GoudianNum,xs;
		 unsigned int DelayTime;

		 DelayTime=0;
		 GoudianNum=0;
         xs=0;
		 a_up = a_down =  1;
		 a_right = a_left = 0;

		  while(1)
		  {
		    GUI_Clear();
		    GUI_DispStringAt("�ܼ��� �µ�ز���:",12,16);
		    GUI_DispDecAt( GoudianNum+1,60,16,1);

		    GUI_DispStringAt("�����õ���:",12,40);
		    GUI_DispDecAt((RtuDataAddr->Real_Zj_Value[GoudianNum].P_All-RtuDataAddr->Yue_Zj_Value[GoudianNum].P_All) ,100,40,3);

		    GUI_DispStringAt("�µ�ض�ֵ:",12,56);
		    GUI_DispDecAt( RtuDataAddr->Yue_Dian_Kong_Value[GoudianNum].DingZhi,100,56,3);

	        GUI_DispStringAt("�µ�ظ���ϵ��:",12,72);

	           if(RtuDataAddr->Fk_Control_Set_Value.F20_Set_Para.ZD_Yue_DK_DZ_FD&0x80)
				{
					xs=100-(((RtuDataAddr->Fk_Control_Set_Value.F20_Set_Para.ZD_Yue_DK_DZ_FD>>4)&0x07)*10)+(RtuDataAddr->Fk_Control_Set_Value.F20_Set_Para.ZD_Yue_DK_DZ_FD&0x0f);
				}
				else
				{
					xs=100+(((RtuDataAddr->Fk_Control_Set_Value.F20_Set_Para.ZD_Yue_DK_DZ_FD>>4)&0x07)*10)+(RtuDataAddr->Fk_Control_Set_Value.F20_Set_Para.ZD_Yue_DK_DZ_FD&0x0f);
				}
		    GUI_DispDecAt( xs,132,72,3);

		    GUI_DispStringAt("Ͷ���ִ�:",12,88);
		    GUI_DispDecAt( RtuDataAddr->Yue_Dian_Kong_Value[GoudianNum].LunCi,88,88,3);


		     Status_Bar();
		     BottomBar();
		     Lcmfull();
  		     keysele=KeySeleflag;
		     KeySeleflag =0;
		    if(keysele!=0)DelayTime=0;else DelayTime++;
		    if(DelayTime>=PageDelayTime)
		       {
		       	OldLevel=0;
		       	return 0;
		       	}
			   switch(keysele)
			   {
			   case 1: if(GoudianNum==0)GoudianNum=7;else GoudianNum=GoudianNum-1;DelayTime=0;break;//��
			   case 2: GoudianNum=(GoudianNum+1)%ZongJia_Max;DelayTime=0;break;//��
			   case 6: OldLevel=0;return 0;break;
			   default:break;
			   }

		  }

}
/******************************************************************************************************************
 * �������ƣ�Show_peizhi_Can()�����ڵڶ����˵�
 * * ��    �ܣ���peizhi��
* ��ڲ�������
* ���ڲ�������
 *********************************************************************************************************************/

int Show_peizhi_Can(INT8U SeleMenu)
{
	unsigned char keysele,TempBuf[16],x,m;
	unsigned int DelayTime,tmpaddr;

	DelayTime=0;

	  while(1)
	  {
		 GUI_Clear();
	     GUI_DispStringAt("1.��������:",0,42);
		 GUI_DispStringAt("2.�ն˵�ַ:",0,62);

		 memset(TempBuf,0,16);
		 sprintf(TempBuf,"%02x%02x",
				 RtuDataAddr->FkComm_Value.GB22601991[1],
				 RtuDataAddr->FkComm_Value.GB22601991[0]
						);  //����ת����Ϊ�ַ���
		 GUI_DispStringAt(TempBuf,88,42);//��������
		 tmpaddr= (RtuDataAddr->FkComm_Value.ADDR[1]<<8)+ RtuDataAddr->FkComm_Value.ADDR[0];
	     memset(TempBuf,0,16);
		 sprintf(TempBuf,"%05d",tmpaddr);
		 GUI_DispStringAt(TempBuf,88,62);//�ն˵�ַ
	     Status_Bar();
	     Lcmfull();
	     keysele=KeySeleflag;
	     KeySeleflag =0;
	    if(keysele!=0)DelayTime=0;else DelayTime++;
	    if(DelayTime>=PageDelayTime)
	       {
	       	OldLevel=10;
	       	return 0;
	       	}
	   switch(keysele)
	   {
	   case 0:DelayTime++;break;
	   case 1: break;
	   case 2:  ;break;
	   case 6: OldLevel=0;return 0;break;
	   default:break;
	   }

	  }

}
/*****************************************************************************************************************
 * �������ƣ�Show_DianNengBiao_Can()�����ڵڶ����˵�
 * ���ܣ���DianNengBiao��
 * ��ڲ�������
 * ���ڲ�������
 ****************************************************************************************************************/
int Show_DianNengBiao_Can(INT8U SeleMenu)
{
	unsigned char keysele,TempBuf[16],x,m,i;
	unsigned int DelayTime,tmpaddr;

	 DelayTime=0;
	 i=0;
	 a_up = a_down =  1;
	 a_right = a_left = 0;
	  while(1)
	  {
		 GUI_Clear();
		 GUI_DispStringAt("������:",0,16);
	     GUI_DispStringAt("1.�ֱ��:",0,32);
		 GUI_DispStringAt("2.ͨ��:",0,64);
		 GUI_DispStringAt("3.Э��:",0,80);
		 GUI_DispStringAt("4.��ַ:",0,96);

		 GUI_DispDecAt(i+1,78,16,2);
		 memset(NowInput.buf,0,128);
		 sprintf(NowInput.buf,"%s",   //16���Ƶ�BCD��
				RtuDataAddr->Fk_Control_Set_Value.F29_Set_Para.JuBianHao);
		 //printf("\n\r NowInput.buf=%s",NowInput.buf);
		 //printf("\n\r NowInput.buf=%s",NowInput.buf);
		       // GUI_DispStringAt(NowInput.buf,48,143);//Ӧ����ʾ����ַ����
		GUI_DispStringAt(NowInput.buf,16,48);//Ӧ����ʾ����ַ����

		 GUI_DispStringAt("485��",60,64);
		 memset(NowInput.buf,0,128);
		 sprintf(NowInput.buf,"%d",   //16���Ƶ�BCD��
				 RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].BaudAndPort&0x1F);  //����ת����Ϊ�ַ���
		 GUI_DispStringAt(NowInput.buf,100,64);
		 //printf("\n\r FkInput_ValueTm.F10_Set_Para.Dian_Meter[i].GuiYue_Type===%d",FkInput_ValueTmp.F10_Set_Para.Dian_Meter[i].GuiYue_Type);
		 if(RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].GuiYue_Type==DLT6451997)
			 GUI_DispStringAt("DL/T645-1997",60,80);
		 if(RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].GuiYue_Type==DLT6452007)
			 GUI_DispStringAt("DL/T645-2007",60,80);

		//memset(NowInput.buf,0,128);
		 //sprintf(NowInput.buf,"%02d",   //16���Ƶ�BCD��
				//FkInput_ValueTmp.F10_Set_Para.Dian_Meter[i].GuiYue_Type);  //����ת����Ϊ�ַ���
		 //GUI_DispStringAt(NowInput.buf,60,76);
		 memset(NowInput.buf,0,128);
		 sprintf(NowInput.buf,"%02x%02x%02x%02x%02x%02x",   //16���Ƶ�BCD��
				RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Addr[5],
				RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Addr[4],
				RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Addr[3],
				RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Addr[2],
				RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Addr[1],
				RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Addr[0]);
		      //  GUI_DispStringAt(NowInput.buf,48,143);//Ӧ����ʾ����ַ����
		 GUI_DispStringAt(NowInput.buf,54,96);//Ӧ����ʾ����ַ����


	     Status_Bar();
	     BottomBar();
	     Lcmfull();
	     keysele=KeySeleflag;
	     KeySeleflag =0;
	    if(keysele!=0)DelayTime=0;else DelayTime++;
	    if(DelayTime>=PageDelayTime)
	       {
	       	OldLevel=0;
	       	return 0;
	       	}
	   switch(keysele)
	   {
	   case 0:DelayTime++;break;
	   case 1: if(i==0) i=7; else i=(i-1)%CeLiangPoint_Max; DelayTime=0;break;
	   case 2: i=(i+1)%CeLiangPoint_Max ;DelayTime=0;break;
	   case 6: OldLevel=0;return 0;break;
	   default:break;
	   }

	  }
}

/******************************************************************************************************************
* �������ƣ�Show_KvKiKp_Can()�����ڵڶ����˵�
* ��    �ܣ���KvKiKp��
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
int Show_KvKiKp_Can(INT8U SeleMenu)
{
		 unsigned char keysele,GoudianNum,TempBuf[16],j;
		 unsigned int DelayTime;
		 unsigned int num,v_beilv,i_beilv;
		 DelayTime=0;
		 GoudianNum=0;
         j=0;
		 a_up = a_down =  0;
		 a_right = a_left = 1;

		  while(1)
		  {
		    GUI_Clear();
		    switch(j)
		    {
		    case 0:
		    GUI_DispStringAt("KpKv����:",48,16);

		    GUI_DispStringAt("Kp1:",8,32);
		    memset(TempBuf,0,16);
		    num=(RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong[0].Changhu[1]<<8)|(RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong[0].Changhu[0]);
        	sprintf(TempBuf,"%04d",num);  //����ת����Ϊ�ַ���
	        GUI_DispStringAt(TempBuf,40,32);


		    GUI_DispStringAt("Kp2:",88,32);
		    memset(TempBuf,0,16);
		    num=(RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong[1].Changhu[1]<<8)|(RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong[1].Changhu[0]);
        	sprintf(TempBuf,"%04d",num);  //����ת����Ϊ�ַ���
	        GUI_DispStringAt(TempBuf,120,32);

		    GUI_DispStringAt("Kp3:",8,48);
		    memset(TempBuf,0,16);
		    num=(RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong[2].Changhu[1]<<8)|(RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong[2].Changhu[0]);
        	sprintf(TempBuf,"%04d",num);  //����ת����Ϊ�ַ���
	        GUI_DispStringAt(TempBuf,40,48);

		    GUI_DispStringAt("Kp4:",88,48);
		    memset(TempBuf,0,16);
		    num=(RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong[3].Changhu[1]<<8)|(RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong[3].Changhu[0]);
        	sprintf(TempBuf,"%04d",num);  //����ת����Ϊ�ַ���
	        GUI_DispStringAt(TempBuf,120,48);

		   GUI_DispStringAt("KV1:",8,64);
		    memset(TempBuf,0,16);
		    v_beilv=(RtuDataAddr->Cl_MenXian_Value[0].F25_Set_Para.V_BeiLv[1]<<8)|(RtuDataAddr->Cl_MenXian_Value[0].F25_Set_Para.V_BeiLv[0]);
        	sprintf(TempBuf,"%04d",v_beilv);  //����ת����Ϊ�ַ���
	        GUI_DispStringAt(TempBuf,40,64);

	        GUI_DispStringAt("KV2:",88,64);
		    memset(TempBuf,0,16);
		    v_beilv=(RtuDataAddr->Cl_MenXian_Value[1].F25_Set_Para.V_BeiLv[1]<<8)|(RtuDataAddr->Cl_MenXian_Value[1].F25_Set_Para.V_BeiLv[0]);
        	sprintf(TempBuf,"%04d",v_beilv);  //����ת����Ϊ�ַ���
	        GUI_DispStringAt(TempBuf,120,64);

	        GUI_DispStringAt("KV3:",8,80);
		    memset(TempBuf,0,16);
		    v_beilv=(RtuDataAddr->Cl_MenXian_Value[2].F25_Set_Para.V_BeiLv[1]<<8)|(RtuDataAddr->Cl_MenXian_Value[2].F25_Set_Para.V_BeiLv[0]);
        	sprintf(TempBuf,"%04d",v_beilv);  //����ת����Ϊ�ַ���
	        GUI_DispStringAt(TempBuf,40,80);

	        GUI_DispStringAt("KV4:",88,80);
		    memset(TempBuf,0,16);
		    v_beilv=(RtuDataAddr->Cl_MenXian_Value[3].F25_Set_Para.V_BeiLv[1]<<8)|(RtuDataAddr->Cl_MenXian_Value[3].F25_Set_Para.V_BeiLv[0]);
        	sprintf(TempBuf,"%04d",v_beilv);  //����ת����Ϊ�ַ���
	        GUI_DispStringAt(TempBuf,120,80);

		     GUI_DispStringAt("KV5:",8,96);
		    memset(TempBuf,0,16);
		    v_beilv=(RtuDataAddr->Cl_MenXian_Value[4].F25_Set_Para.V_BeiLv[1]<<8)|(RtuDataAddr->Cl_MenXian_Value[4].F25_Set_Para.V_BeiLv[0]);
        	sprintf(TempBuf,"%04d",v_beilv);  //����ת����Ϊ�ַ���
	        GUI_DispStringAt(TempBuf,40,96);

	        GUI_DispStringAt("KV6:",88,96);
		    memset(TempBuf,0,16);
		    v_beilv=(RtuDataAddr->Cl_MenXian_Value[5].F25_Set_Para.V_BeiLv[1]<<8)|(RtuDataAddr->Cl_MenXian_Value[5].F25_Set_Para.V_BeiLv[0]);
        	sprintf(TempBuf,"%04d",v_beilv);  //����ת����Ϊ�ַ���
	        GUI_DispStringAt(TempBuf,120,96);

		    GUI_DispStringAt("KV7:",8,112);
		    memset(TempBuf,0,16);
		    v_beilv=(RtuDataAddr->Cl_MenXian_Value[6].F25_Set_Para.V_BeiLv[1]<<8)|(RtuDataAddr->Cl_MenXian_Value[6].F25_Set_Para.V_BeiLv[0]);
        	sprintf(TempBuf,"%04d",v_beilv);  //����ת����Ϊ�ַ���
	        GUI_DispStringAt(TempBuf,40,112);

	        GUI_DispStringAt("KV8:",88,112);
		    memset(TempBuf,0,16);
		    v_beilv=(RtuDataAddr->Cl_MenXian_Value[7].F25_Set_Para.V_BeiLv[1]<<8)|(RtuDataAddr->Cl_MenXian_Value[7].F25_Set_Para.V_BeiLv[0]);
        	sprintf(TempBuf,"%04d",v_beilv);  //����ת����Ϊ�ַ���
	        GUI_DispStringAt(TempBuf,120,112);
		     break;

		     case 1:
		     GUI_DispStringAt("Ki����:",56,16);
		    		   GUI_DispStringAt("KI1:",8,40);
		    memset(TempBuf,0,16);
		    i_beilv=(RtuDataAddr->Cl_MenXian_Value[0].F25_Set_Para.I_BeiLv[1]<<8)|(RtuDataAddr->Cl_MenXian_Value[0].F25_Set_Para.I_BeiLv[0]);
        	sprintf(TempBuf,"%04d",i_beilv);  //����ת����Ϊ�ַ���
	        GUI_DispStringAt(TempBuf,40,40);

	        GUI_DispStringAt("KI2:",88,40);
		    memset(TempBuf,0,16);
		    i_beilv=(RtuDataAddr->Cl_MenXian_Value[1].F25_Set_Para.I_BeiLv[1]<<8)|(RtuDataAddr->Cl_MenXian_Value[1].F25_Set_Para.I_BeiLv[0]);
        	sprintf(TempBuf,"%04d",i_beilv);  //����ת����Ϊ�ַ���
	        GUI_DispStringAt(TempBuf,120,40);

	        GUI_DispStringAt("KI3:",8,56);
		    memset(TempBuf,0,16);
		    i_beilv=(RtuDataAddr->Cl_MenXian_Value[2].F25_Set_Para.I_BeiLv[1]<<8)|(RtuDataAddr->Cl_MenXian_Value[2].F25_Set_Para.I_BeiLv[0]);
        	sprintf(TempBuf,"%04d",i_beilv);  //����ת����Ϊ�ַ���
	        GUI_DispStringAt(TempBuf,40,56);

	        GUI_DispStringAt("KI4:",88,56);
		    memset(TempBuf,0,16);
		    i_beilv=(RtuDataAddr->Cl_MenXian_Value[3].F25_Set_Para.I_BeiLv[1]<<8)|(RtuDataAddr->Cl_MenXian_Value[3].F25_Set_Para.I_BeiLv[0]);
        	sprintf(TempBuf,"%04d",i_beilv);  //����ת����Ϊ�ַ���
	        GUI_DispStringAt(TempBuf,120,56);

		     GUI_DispStringAt("KI5:",8,72);
		    memset(TempBuf,0,16);
		    i_beilv=(RtuDataAddr->Cl_MenXian_Value[4].F25_Set_Para.I_BeiLv[1]<<8)|(RtuDataAddr->Cl_MenXian_Value[4].F25_Set_Para.I_BeiLv[0]);
        	sprintf(TempBuf,"%04d",i_beilv);  //����ת����Ϊ�ַ���
	        GUI_DispStringAt(TempBuf,40,72);

	        GUI_DispStringAt("KI6:",88,72);
		    memset(TempBuf,0,16);
		    i_beilv=(RtuDataAddr->Cl_MenXian_Value[5].F25_Set_Para.I_BeiLv[1]<<8)|(RtuDataAddr->Cl_MenXian_Value[5].F25_Set_Para.I_BeiLv[0]);
        	sprintf(TempBuf,"%04d",i_beilv);  //����ת����Ϊ�ַ���
	        GUI_DispStringAt(TempBuf,120,72);

		    GUI_DispStringAt("KI7:",8,88);
		    memset(TempBuf,0,16);
		    i_beilv=(RtuDataAddr->Cl_MenXian_Value[6].F25_Set_Para.I_BeiLv[1]<<8)|(RtuDataAddr->Cl_MenXian_Value[6].F25_Set_Para.I_BeiLv[0]);
        	sprintf(TempBuf,"%04d",i_beilv);  //����ת����Ϊ�ַ���
	        GUI_DispStringAt(TempBuf,40,88);

	        GUI_DispStringAt("KI8:",88,88);
		    memset(TempBuf,0,16);
		    i_beilv=(RtuDataAddr->Cl_MenXian_Value[7].F25_Set_Para.I_BeiLv[1]<<8)|(RtuDataAddr->Cl_MenXian_Value[7].F25_Set_Para.I_BeiLv[0]);
        	sprintf(TempBuf,"%04d",i_beilv);  //����ת����Ϊ�ַ���
	        GUI_DispStringAt(TempBuf,120,88);
		     break;

		     default :
		     break;
		    }

		     Status_Bar();
		     BottomBar();
		     Lcmfull();
  		     keysele=KeySeleflag;
		     KeySeleflag =0;
		    if(keysele!=0)DelayTime=0;else DelayTime++;
		    if(DelayTime>=PageDelayTime)
		       {
		       	OldLevel=0;
		       	return 0;
		       	}
			   switch(keysele)
			   {
			   case 3: j=(j+1)%2;DelayTime=0;break;//��
			   case 4: j=(j+1)%2;DelayTime=0;break;//��
			   case 6: OldLevel=0;return 0;break;
			   default:break;
			   }

		  }

}
/******************************************************************************************************************
* �������ƣ�Show_Meter_Celiangdian()�����ڵڶ����˵�
* ��    �ܣ�����ʾ���ܱ��Ĳ��������ݡ�
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
int Show_Meter_Celiangdian(INT8U SeleMenu)
{
	 unsigned char keysele,CeLiangDian,j,i;
	 unsigned int DelayTime;
	 unsigned char PChangShu,QChangShu,Duanxiang_All;

	 DelayTime=0;
     CeLiangDian=0;
	 j=0;
	 a_up = a_down =  1;
	 a_right = a_left = 1;

	  while(1)
	  {
	    GUI_Clear();
	    GUI_DispStringAt("������:",0,16);
	    GUI_DispDecAt(CeLiangDian+1 ,56,16,2);
	    GUI_DispStringAt("����:",0,128);

	    for(i=0;i<DD_Device_Max;i++)
	    {
		    if(RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].CeLiangNo==(CeLiangDian+1))
		    {
			    memset(NowInput.buf,0,128);
		        sprintf(NowInput.buf,"%02x%02x%02x%02x%02x%x",   //16���Ƶ�BCD��
				RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[CeLiangDian].Addr[5],
				RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[CeLiangDian].Addr[4],
				RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[CeLiangDian].Addr[3],
				RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[CeLiangDian].Addr[2],
				RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[CeLiangDian].Addr[1],
				RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[CeLiangDian].Addr[0]);
				GUI_DispStringAt(NowInput.buf,40,128);//Ӧ����ʾ����ַ����
		    }
	    }
	switch(j)
	{
	 case 0:
		GUI_DispStringAt("�����й�",80,16);
		GUI_DispStringAt("��:  ",8,40);GUI_DispDecShiftAt(40,40,9,2,RtuDataAddr->DD_Device_BiaoShi_Value[CeLiangDian].Z_P_All);
		GUI_DispStringAt("��:  ",8,56);GUI_DispDecShiftAt(40,56,9,2,RtuDataAddr->DD_Device_BiaoShi_Value[CeLiangDian].Z_P_F[0]);
		GUI_DispStringAt("��:  ",8,72);GUI_DispDecShiftAt(40,72,9,2,RtuDataAddr->DD_Device_BiaoShi_Value[CeLiangDian].Z_P_F[1]);
		GUI_DispStringAt("ƽ:  ",8,88);GUI_DispDecShiftAt(40,88,9,2,RtuDataAddr->DD_Device_BiaoShi_Value[CeLiangDian].Z_P_F[2]);
		GUI_DispStringAt("��:  ",8,104);GUI_DispDecShiftAt(40,104,9,2,RtuDataAddr->DD_Device_BiaoShi_Value[CeLiangDian].Z_P_F[3]);

		GUI_DispStringAt("kwh",120,40);
		GUI_DispStringAt("kwh",120,56);
		GUI_DispStringAt("kwh",120,72);
		GUI_DispStringAt("kwh",120,88);
		GUI_DispStringAt("kwh",120,104);

	break;

	case 1:

		GUI_DispStringAt("�����޹��� ",0,40);
		GUI_DispDecShiftAt(16,56,9,2,RtuDataAddr->DD_Device_BiaoShi_Value[CeLiangDian].Z_Q_All);
		GUI_DispStringAt("�����޹��� ",0,80);
		GUI_DispDecShiftAt(16,96,9,2,RtuDataAddr->DD_Device_BiaoShi_Value[CeLiangDian].F_Q_All);
		GUI_DispStringAt("(Kvarh)",96,56);
		GUI_DispStringAt("(Kvarh)",96,96);
  	break;
	case 2:
		GUI_DispStringAt("����",80,16);
	    GUI_DispStringAt("�������������ʱ��",8,40);
	    GUI_DispStringAt("�����й�(kw)",0,64);
	    GUI_DispDecShiftAt(100,64,7,4,RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[CeLiangDian].Z_P_X_All);
	   	GUI_DispStringAt("  ��  ��  ʱ  ��",16,80);

	    GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_Z_P_X_All[3] ,16,80,2);
		GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_Z_P_X_All[2] ,48,80,2);
		GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_Z_P_X_All[1] ,80,80,2);
		GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_Z_P_X_All[0] ,112,80,2);

	    GUI_DispStringAt("�����й�(kw)",0,96);
	    GUI_DispDecShiftAt(100,96,7,4,RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[CeLiangDian].F_P_X_All);
	    GUI_DispStringAt("  ��  ��  ʱ  ��",16,112);
	    GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_F_P_X_All[3] ,16,112,2);
		GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_F_P_X_All[2] ,48,112,2);
		GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_F_P_X_All[1] ,80,112,2);
		GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_F_P_X_All[0] ,112,112,2);
	break;
	case 3:
		GUI_DispStringAt("����",80,16);
	    GUI_DispStringAt("�������������ʱ��",8,40);
	    GUI_DispStringAt("�����޹�kvar",0,64);
	    GUI_DispDecShiftAt(100,64,7,4,RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[CeLiangDian].Z_Q_X_All);
	   	GUI_DispStringAt("  ��  ��  ʱ  ��",16,80);
	   	GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_Z_Q_X_All[3] ,16,80,2);
		GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_Z_Q_X_All[2] ,48,80,2);
		GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_Z_Q_X_All[1] ,80,80,2);
		GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_Z_Q_X_All[0] ,112,80,2);

	    GUI_DispStringAt("�����޹�kvar",0,96);
	    GUI_DispDecShiftAt(100,96,7,4,RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[CeLiangDian].F_Q_X_All);
	    GUI_DispStringAt("  ��  ��  ʱ  ��",16,112);
	    GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_F_Q_X_All[3] ,16,112,2);
		GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_F_Q_X_All[2] ,48,112,2);
		GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_F_Q_X_All[1] ,80,112,2);
		GUI_DispHexAt(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_F_Q_X_All[0] ,112,112,2);
	break;
		case 4:
		GUI_DispStringAt("����",80,16);
	    GUI_DispStringAt("�������������ʱ��",8,40);
	    GUI_DispStringAt("�����й�(kw)",0,64);
	    GUI_DispDecShiftAt(100,64,7,4,RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[CeLiangDian].SY_Z_P_X_All);
	   	GUI_DispStringAt("  ��  ��  ʱ  ��",16,80);
	   	printf("\n\r Time_SY_Z_P_X_All[0]=%02x",RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_SY_Z_P_X_All[0]);
	   	GUI_DispHexAt(RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_SY_Z_P_X_All[3] ,16,80,2);
		GUI_DispHexAt(RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_SY_Z_P_X_All[2] ,48,80,2);
		GUI_DispHexAt(RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_SY_Z_P_X_All[1] ,80,80,2);
		GUI_DispHexAt(RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_SY_Z_P_X_All[0] ,112,80,2);

	    GUI_DispStringAt("�����й�(kw)",0,96);
	    GUI_DispDecShiftAt(100,96,7,4,RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[CeLiangDian].SY_F_P_X_All);
	    GUI_DispStringAt("  ��  ��  ʱ  ��",16,112);
	    GUI_DispHexAt(RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_SY_F_P_X_All[3] ,16,112,2);
		GUI_DispHexAt(RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_SY_F_P_X_All[2] ,48,112,2);
		GUI_DispHexAt(RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_SY_F_P_X_All[1] ,80,112,2);
		GUI_DispHexAt(RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_SY_F_P_X_All[0] ,112,112,2);
	break;
	case 5:
		GUI_DispStringAt("����",80,16);
	    GUI_DispStringAt("�������������ʱ��",8,40);
	    GUI_DispStringAt("�����޹�kvar",0,64);
	    GUI_DispDecShiftAt(100,64,7,4,RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[CeLiangDian].SY_Z_Q_X_All);
	   	GUI_DispStringAt("  ��  ��  ʱ  ��",16,80);
	   	GUI_DispHexAt(RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_SY_Z_Q_X_All[3] ,16,80,2);
		GUI_DispHexAt(RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_SY_Z_Q_X_All[2] ,48,80,2);
		GUI_DispHexAt(RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_SY_Z_Q_X_All[1] ,80,80,2);
		GUI_DispHexAt(RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_SY_Z_Q_X_All[0] ,112,80,2);

	    GUI_DispStringAt("�����޹�kvar",0,96);
	    GUI_DispDecShiftAt(100,96,7,4,RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[CeLiangDian].SY_F_Q_X_All);
	    GUI_DispStringAt("  ��  ��  ʱ  ��",16,112);
	    GUI_DispHexAt(RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_SY_F_Q_X_All[3] ,16,112,2);
		GUI_DispHexAt(RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_SY_F_Q_X_All[2] ,48,112,2);
		GUI_DispHexAt(RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_SY_F_Q_X_All[1] ,80,112,2);
		GUI_DispHexAt(RtuDataAddr->YUE_ZuiDa_Xuliang_Shuju[CeLiangDian].Time_SY_F_Q_X_All[0] ,112,112,2);
	break;
	default:break;
	}
	Status_Bar();
	BottomBar();
	Lcmfull();

	keysele=KeySeleflag;
	KeySeleflag =0;
	if(keysele!=0)DelayTime=0;else DelayTime++;
   if(DelayTime>=PageDelayTime)
   {
	    OldLevel=10;
	    MenuSele = 3;
	   	return 0;
	}
	switch(keysele)
	{
		 case 1: if(CeLiangDian==0)CeLiangDian=7;else CeLiangDian=CeLiangDian-1;DelayTime=0;break;//��
		 case 2: CeLiangDian=(CeLiangDian+1)%(CeLiangPoint_Max);DelayTime=0;break;//��
		 case 3: if(j==0)j=5;else j=j-1;DelayTime=0;break;//��
		 case 4: j=(j+1)%6;DelayTime=0;break;//��
		 case 6: OldLevel=10;MenuSele = 3;return 0;break;
		 default:break;
   }
}

}
/******************************************************************************************************************
* �������ƣ�Show_Meter_ErZ()�����ڵڶ����˵�
* ��    �ܣ����鿴�����ġ�����Ҫ�¼�״̬��
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
int Show_Meter_ErZ(INT8U SeleMenu)
{
		 unsigned char keysele,TmpEc1,ErcI;
		 unsigned char TmpEcBiaozhi,k,j;
		 unsigned int DelayTime;
 		 printf("\n\r ------------1");
 		 printf("\n\r");
		 DelayTime=0;
		 TmpEcBiaozhi=0;
		 j=0;
	   	a_up = a_down =  1;
	   	a_right = a_left = 1;
		  while(1)
		  {
			  switch(j)
			  {
			 	 case 0:
			 		 printf("\n\r ------------2");
			 		 printf("\n\r");
					GUI_Clear();
					GUI_DispStringAt("��Ҫ�¼�",24,20);

					//GUI_DispStringAt("->",66,36);
			 		 printf("\n\r ------------3");
			 		 printf("\n\r");
					GUI_SetTextMode(GUI_TM_REV);
					if(TmpEcBiaozhi<=0)
						GUI_DispDecAt(-TmpEcBiaozhi+1 ,0,20,3);
					if(TmpEcBiaozhi>0)
						GUI_DispDecAt((256-TmpEcBiaozhi+1),0,20,3);
					 GUI_SetTextMode(GUI_TM_NORMAL);

					k=RtuDataAddr->Fm_Save_Eve.EC1-1+TmpEcBiaozhi;
					TmpEc1=k;
					if(k<0) TmpEc1=256+k;
					if(k>255) TmpEc1=k-256;
			 		 printf("\n\r ------------4");
			 		 printf("\n\r");
				if(	RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[0]!=0)
				{
			 		 printf("\n\r ------------5");
			 		 printf("\n\r");
					GUI_DispStringAt("�¼�����:",0,38);
					GUI_DispStringAt("ERC",80,38);
					GUI_DispDecAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[0],106,38,2);//��ʾ��ǰ�洢�������¼�����
			 		 printf("\n\r ------------5.1");
			 		 printf("\n\r");
					GUI_DispStringAt("�¼�����:",0,56);
					GUI_DispDecAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[1],80,56,2);//��ʾ��ǰ�洢�������¼�����
			 		 printf("\n\r ------------5.2");
			 		 printf("\n\r");
					GUI_DispStringAt("�¼�����:",0,74);
					GUI_DispStringAt(ERCNAME[RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[0]].Ercname,0,92);
			 		 printf("\n\r ------------5.3");
			 		 printf("\n\r");
					if(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[0]==14)
					{
						GUI_DispStringAt("�ϵ�:",0,110);
						GUI_DispStringAt("-",72,110);
						GUI_DispStringAt("-",94,110);
						//GUI_DispStringAt(" ",108,110);
						GUI_DispStringAt(":",138,110);
						GUI_DispStringAt("20",40,110);
						GUI_DispHexAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[11],56,110,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispHexAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[10],80,110,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispHexAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[9],102,110,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispHexAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[8],124,110,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispHexAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[7],144,110,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispStringAt("ͣ��:",0,128);
						GUI_DispStringAt("-",72,128);
						GUI_DispStringAt("-",94,128);
						//GUI_DispStringAt(" ",88,128);
						GUI_DispStringAt(":",138,128);
						GUI_DispStringAt("20",40,128);
						GUI_DispHexAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[6],56,128,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispHexAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[5],80,128,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispHexAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[4],100,128,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispHexAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[3],124,128,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispHexAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[2],144,128,2);//��ʾ��ǰ�洢�������¼�����

					}
					else
					{
				 		 printf("\n\r ------------6");
				 		 printf("\n\r");
						GUI_DispStringAt("����ʱ��:",0,110);
						GUI_DispStringAt("-",32,128);
						GUI_DispStringAt("-",60,128);
						GUI_DispStringAt(" ",88,128);
						GUI_DispStringAt(":",112,128);
						GUI_DispStringAt("20",0,128);
						GUI_DispHexAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[6],16,128,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispHexAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[5],42,128,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispHexAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[4],68,128,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispHexAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[3],94,128,2);//��ʾ��ǰ�洢�������¼�����
						GUI_DispHexAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[2],120,128,2);//��ʾ��ǰ�洢�������¼�����

					}

				}
				else
					GUI_DispStringAt(ERCNAME[RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[0]].Ercname,32,80);



					break;
			     case 1:

				    GUI_Clear();
				    GUI_DispStringAt("��Ҫ�¼�",24,20);
				    GUI_SetTextMode(GUI_TM_REV);
				    if(TmpEcBiaozhi<=0)
				    	GUI_DispDecAt(-TmpEcBiaozhi ,0,20,3);
		            if(TmpEcBiaozhi>0)
		            	GUI_DispDecAt((256-TmpEcBiaozhi),0,20,3);
		             GUI_SetTextMode(GUI_TM_NORMAL);

				    k=RtuDataAddr->Fm_Save_Eve.EC1-1+TmpEcBiaozhi;
				    TmpEc1=k;
				    if(k<0) TmpEc1=256+k;
		            if(k>255) TmpEc1=k-256;

		            //GUI_DispDecAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[0],120,20,2);//��ʾ��ǰ�洢�������¼�����
		           // GUI_DispStringAt(ERCNAME[RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[0]].Ercname,0,40);
		            GUI_DispStringAt("�¼�����:",0,40);
					for(ErcI=0;ErcI<8;ErcI++)
						GUI_DispHexAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[ErcI+1],20*ErcI,60,2);
					for(ErcI=0;ErcI<8;ErcI++)
						GUI_DispHexAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[ErcI+9],20*ErcI,80,2);
					for(ErcI=0;ErcI<8;ErcI++)
						GUI_DispHexAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[ErcI+17],20*ErcI,100,2);
					for(ErcI=0;ErcI<8;ErcI++)
						GUI_DispHexAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[ErcI+25],20*ErcI,120,2);
				    break;
			    default :
			        break;
			  }
		 		 printf("\n\r ------------7");
		 		 printf("\n\r");
		     Status_Bar();
		     BottomBar();
		     Lcmfull();
		     keysele=KeySeleflag;
		     KeySeleflag =0;
		    if(keysele!=0)DelayTime=0;else DelayTime++;
		    if(DelayTime>=PageDelayTime)
		       {
		       	OldLevel=0;
		       	return 0;
		       	}
		   switch(keysele)
		   {
		   /*case 1: TmpEcBiaozhi= TmpEcBiaozhi-1;if(TmpEcBiaozhi<-255)TmpEcBiaozhi=0;break;
		   case 2:TmpEcBiaozhi= TmpEcBiaozhi+1;if(TmpEcBiaozhi>255)TmpEcBiaozhi=0; ;break;
		   case 3: j=(j+1)%2;DelayTime=0;break;
		   case 4: j=(j+1)%2;DelayTime=0;break;
		   case 5:  DelayTime=0;break;
		   case 6:  OldLevel=0;return 0;break;
		   default:break;*/
		   case 0:DelayTime++;break;
		   case 1: TmpEcBiaozhi= TmpEcBiaozhi-1;if(TmpEcBiaozhi<-255)TmpEcBiaozhi=0;break;
		   case 2: TmpEcBiaozhi= TmpEcBiaozhi+1;if(TmpEcBiaozhi>255)TmpEcBiaozhi=0; ;break;
		   case 3: j=(j+1)%2;DelayTime=0;break;
		   case 4: j=(j+1)%2;DelayTime=0;break;
		   case 6: OldLevel=0;return 0;break;
		   default:break;
		   }

		  }
}
/******************************************************************************************************************
* �������ƣ�Show_Meter_Er1()�����ڵڶ����˵�
* ��    �ܣ����鿴�����ġ�����Ҫ�¼�״̬��
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
int Show_Meter_Er1(INT8U SeleMenu)
{
	 unsigned char keysele,TmpEc1,ErcI;
	 signed char TmpEcBiaozhi,k,j;
	 unsigned int DelayTime;

	 DelayTime=0;
	 TmpEcBiaozhi=0;
	 j=0;
	 a_up = a_down =  1;
	 a_right = a_left = 1;
	  while(1)
	  {
		  switch(j)
		  {
		 	 case 0:
				GUI_Clear();
				GUI_DispStringAt("һ���¼�",24,20);

				//GUI_DispStringAt("->",66,36);

				GUI_SetTextMode(GUI_TM_REV);
				if(TmpEcBiaozhi<=0)
					GUI_DispDecAt(-TmpEcBiaozhi+1 ,0,20,3);
				if(TmpEcBiaozhi>0)
					GUI_DispDecAt((256-TmpEcBiaozhi+1),0,20,3);
				 GUI_SetTextMode(GUI_TM_NORMAL);

				k=RtuDataAddr->Fm_Save_Eve.EC2-1+TmpEcBiaozhi;
				TmpEc1=k;
				if(k<0) TmpEc1=256+k;
				if(k>255) TmpEc1=k-256;
			if(	RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[0]!=0)
			{
				GUI_DispStringAt("�¼�����:",0,38);
				GUI_DispStringAt("ERC",80,38);
				GUI_DispDecAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[0],106,38,2);//��ʾ��ǰ�洢�������¼�����
				GUI_DispStringAt("�¼�����:",0,56);
				GUI_DispDecAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[1],80,56,2);//��ʾ��ǰ�洢�������¼�����
				GUI_DispStringAt("�¼�����:",0,74);
				GUI_DispStringAt(ERCNAME[RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[0]].Ercname,0,92);
				if(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[0]==14)
				{
					GUI_DispStringAt("�ϵ�:",0,110);
					GUI_DispStringAt("-",72,110);
					GUI_DispStringAt("-",94,110);
					//GUI_DispStringAt(" ",108,110);
					GUI_DispStringAt(":",138,110);
					GUI_DispStringAt("20",40,110);
					GUI_DispHexAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[11],56,110,2);//��ʾ��ǰ�洢�������¼�����
					GUI_DispHexAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[10],80,110,2);//��ʾ��ǰ�洢�������¼�����
					GUI_DispHexAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[9],102,110,2);//��ʾ��ǰ�洢�������¼�����
					GUI_DispHexAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[8],124,110,2);//��ʾ��ǰ�洢�������¼�����
					GUI_DispHexAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[7],144,110,2);//��ʾ��ǰ�洢�������¼�����
					GUI_DispStringAt("ͣ��:",0,128);
					GUI_DispStringAt("-",72,128);
					GUI_DispStringAt("-",94,128);
					//GUI_DispStringAt(" ",88,128);
					GUI_DispStringAt(":",138,128);
					GUI_DispStringAt("20",40,128);
					GUI_DispHexAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[6],56,128,2);//��ʾ��ǰ�洢�������¼�����
					GUI_DispHexAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[5],80,128,2);//��ʾ��ǰ�洢�������¼�����
					GUI_DispHexAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[4],100,128,2);//��ʾ��ǰ�洢�������¼�����
					GUI_DispHexAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[3],124,128,2);//��ʾ��ǰ�洢�������¼�����
					GUI_DispHexAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[2],144,128,2);//��ʾ��ǰ�洢�������¼�����
				}
				else
				{
					GUI_DispStringAt("����ʱ��:",0,110);
					GUI_DispStringAt("-",32,128);
					GUI_DispStringAt("-",60,128);
					GUI_DispStringAt(" ",88,128);
					GUI_DispStringAt(":",112,128);
					GUI_DispStringAt("20",0,128);
					GUI_DispHexAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[6],16,128,2);//��ʾ��ǰ�洢�������¼�����
					GUI_DispHexAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[5],42,128,2);//��ʾ��ǰ�洢�������¼�����
					GUI_DispHexAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[4],68,128,2);//��ʾ��ǰ�洢�������¼�����
					GUI_DispHexAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[3],94,128,2);//��ʾ��ǰ�洢�������¼�����
					GUI_DispHexAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[2],120,128,2);//��ʾ��ǰ�洢�������¼�����
				}
			}
			else
				GUI_DispStringAt(ERCNAME[RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[0]].Ercname,32,80);
				break;
		     case 1:

			    GUI_Clear();
			    GUI_DispStringAt("һ���¼�",24,20);
			    GUI_SetTextMode(GUI_TM_REV);
			    if(TmpEcBiaozhi<=0)
			    	GUI_DispDecAt(-TmpEcBiaozhi ,0,20,3);
	            if(TmpEcBiaozhi>0)
	            	GUI_DispDecAt((256-TmpEcBiaozhi),0,20,3);
	             GUI_SetTextMode(GUI_TM_NORMAL);

			    k=RtuDataAddr->Fm_Save_Eve.EC2-1+TmpEcBiaozhi;
			    TmpEc1=k;
			    if(k<0) TmpEc1=256+k;
	            if(k>255) TmpEc1=k-256;

	            //GUI_DispDecAt(RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[0],120,20,2);//��ʾ��ǰ�洢�������¼�����
	           // GUI_DispStringAt(ERCNAME[RtuDataAddr->M_Event_Save[TmpEc1].Event.Buff[0]].Ercname,0,40);
	            GUI_DispStringAt("�¼�����:",0,40);
				for(ErcI=0;ErcI<8;ErcI++)
					GUI_DispHexAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[ErcI+1],20*ErcI,60,2);
				for(ErcI=0;ErcI<8;ErcI++)
					GUI_DispHexAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[ErcI+9],20*ErcI,80,2);
				for(ErcI=0;ErcI<8;ErcI++)
					GUI_DispHexAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[ErcI+17],20*ErcI,100,2);
				for(ErcI=0;ErcI<8;ErcI++)
					GUI_DispHexAt(RtuDataAddr->S_Event_Save[TmpEc1].Event.Buff[ErcI+25],20*ErcI,120,2);
			    break;
		    default :
		        break;
		  }
	     Status_Bar();
	     BottomBar();
	     Lcmfull();
	     keysele=KeySeleflag;
	     KeySeleflag =0;
	    if(keysele!=0)DelayTime=0;else DelayTime++;
	    if(DelayTime>=PageDelayTime)
	       {
	       	OldLevel=0;
	       	return 0;
	       	}
	   switch(keysele)
	   {
	   case 0:DelayTime++;break;
	   case 1: TmpEcBiaozhi= TmpEcBiaozhi-1;if(TmpEcBiaozhi<-255)TmpEcBiaozhi=0;break;
	   case 2: TmpEcBiaozhi= TmpEcBiaozhi+1;if(TmpEcBiaozhi>255)TmpEcBiaozhi=0; ;break;
	   case 3: j=(j+1)%2;DelayTime=0;break;
	   case 4: j=(j+1)%2;DelayTime=0;break;
	   case 6: OldLevel=0;return 0;break;
	   default:break;
	   }

	  }
}
/******************************************************************************************************************
* �������ƣ�Emptyevent()�����ڵڶ����˵�
* ��    �ܣ����ʵʱ��Ҫ�¼���һ���¼�
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
int Emptyevent(INT8U SeleMenu)
{
	unsigned int DelayTime;
	unsigned char keysele;

	DelayTime=0;
	memset(&RtuDataAddr->Fm_Save_Eve.FKTmp,0,sizeof(RtuDataAddr->Fm_Save_Eve.FKTmp));
	memset(&RtuDataAddr->M_Event_Save,0,256*sizeof(event_record_Save));
	memset(&RtuDataAddr->S_Event_Save,0,256*sizeof(event_record_Save));
	memset(&RtuDataAddr->ERCBiaoZhi,0,8);
	SaveFile("/nand/save/Merc1.dat",&RtuDataAddr->M_Event_Save[0].UseFlag,sizeof(RtuDataAddr->M_Event_Save));
	SaveFile("/nand/save/Serc1.dat",&RtuDataAddr->S_Event_Save[0].UseFlag,sizeof(RtuDataAddr->S_Event_Save));
	RtuDataAddr->Fm_Save_Eve.ZWNo=0;
	RtuDataAddr->Fm_Save_Eve.DayLiuLiang=0;
	RtuDataAddr->Fm_Save_Eve.yueLiuLiang=0;
	while (1)
	{
		GUI_Clear();
		GUI_DispStringAt("�¼��������",32,60);
		Status_Bar();
		Lcmfull();

		keysele=KeySeleflag;
		KeySeleflag =0;
		if(keysele!=0)DelayTime=0;else DelayTime++;
		if(DelayTime>=PageDelayTime)
		{
			OldLevel=0;
			return 0;
		}
		switch(keysele)
		{
			case 0:DelayTime++;break;
			case 6: OldLevel=0;return 0;break;
			default:break;
		}
	}
}
/******************************************************************************************************************
* �������ƣ�Show_Meter_Erc()�����ڵڶ����˵�
* ��    �ܣ����鿴�����ġ����¼���Ҫ�ȡ�
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
int Show_Meter_Erc(INT8U SeleMenu)
{
		 unsigned char keysele,i,j;

		 unsigned int DelayTime;
		 GUI_Clear();
		 DelayTime=0;
		 GUI_DispStringAt("��",0,16);
		 GUI_DispStringAt("¼",0,32);
		 GUI_DispStringAt("��",0,48);
		 GUI_DispStringAt("��",0,64);

		 GUI_DispStringAt("��",0,80);
		 GUI_DispStringAt("Ҫ",0,96);
		 GUI_DispStringAt("��",0,112);
		 GUI_DispStringAt("��",0,128);
		  while(1)
		  {

	        for(i=0;i<4;i++)
	        {
	         for(j=0;j<8;j++)
	         {
	         	if((RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[i]>>j)&0x1==0x1)
	         	GUI_DispDecAt((i*8+j+1),16+18*j,16+16*i,2);

	         	if((RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[i]>>j)&0x1==0x1)
	         	GUI_DispDecAt((i*8+j+1),16+18*j,80+16*i,2);

	         }
	        }

		     Status_Bar();
		     Lcmfull();

		     keysele=KeySeleflag;
		     KeySeleflag =0;
		     if(keysele!=0)DelayTime=0;else DelayTime++;
		    if(DelayTime>=PageDelayTime)
		       {
		       	OldLevel=0;
		       	return 0;
		       	}
		    if(keysele == 6)//ȡ����
		     {
			     OldLevel=0;
			     return 0;
		     }

		  }


}

/******************************************************************************************************************
* �������ƣ�Show_ZhongWen()�����ڵڶ����˵�
* ��    �ܣ����鿴�����ġ�����Ҫ�����¼���
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
int Show_ZhongWen(INT8U SeleMenu)
{
		 unsigned char keysele,TempHan[21],k[10],p,j,q;
		 unsigned int DelayTime;

		 DelayTime=0;
		 j=0;
		 q=0;
    //     i = RtuDataAddr->Fm_Save_Eve.ZWNo-1;
    //     if(i>200)i=9;
         for(p=0;p<10;p++)
         {
	         if((RtuDataAddr->FkZhongWen[p].Stat&0x10)==0x10)
	         {
	         	k[j]=p;
	         	j=j+1;
	         }
	         //k[j]���������Ϣ��������һ����Ϣ��jΪ��ʮ����Ϣ���ж�����һ����Ϣ��
         }
         if(j==0)
         	q=j=1;
         else
         {
  		 	q=j;
  		 	if(j>=2)
  		 		a_up=a_down=1;
         }

 		  while(1)
		  {
		    GUI_Clear();
		    GUI_SetTextMode(GUI_TM_REV);
		    GUI_DispDecAt(j-1,0,16,2);
		    GUI_SetTextMode(GUI_TM_NORMAL);

		   if(RtuDataAddr->FkZhongWen[k[j-1]].Valid ==1)
		   {
		   	    memset(TempHan,0,21);
			    memcpy(TempHan,&RtuDataAddr->FkZhongWen[k[j-1]].HZXinXi[0],18);
			    GUI_DispStringAt(TempHan,16,16);

			    if(RtuDataAddr->FkZhongWen[k[j-1]].len>20)
			    {
			    	memcpy(TempHan,&RtuDataAddr->FkZhongWen[k[j-1]].HZXinXi[18],20);
			    	GUI_DispStringAt(TempHan,0,32);
			    }
			     if(RtuDataAddr->FkZhongWen[k[j-1]].len>40)
			    {
			    	memcpy(TempHan,&RtuDataAddr->FkZhongWen[k[j-1]].HZXinXi[38],20);
			    	GUI_DispStringAt(TempHan,0,48);
			    }
			     if(RtuDataAddr->FkZhongWen[k[j-1]].len>60)
			    {
			    	memcpy(TempHan,&RtuDataAddr->FkZhongWen[k[j-1]].HZXinXi[58],20);
			    	GUI_DispStringAt(TempHan,0,64);
			    }
			     if(RtuDataAddr->FkZhongWen[k[j-1]].len>80)
			    {
			    	memcpy(TempHan,&RtuDataAddr->FkZhongWen[k[j-1]].HZXinXi[78],20);
			    	GUI_DispStringAt(TempHan,0,80);
			    }
			     if(RtuDataAddr->FkZhongWen[k[j-1]].len>100)
			    {
			    	memcpy(TempHan,&RtuDataAddr->FkZhongWen[k[j-1]].HZXinXi[98],20);
			    	GUI_DispStringAt(TempHan,0,96);
			    }
			    if(RtuDataAddr->FkZhongWen[k[j-1]].len>120)
			    {
			    	memcpy(TempHan,&RtuDataAddr->FkZhongWen[k[j-1]].HZXinXi[118],20);
			    	GUI_DispStringAt(TempHan,0,112);
			    }
			    if(RtuDataAddr->FkZhongWen[k[j-1]].len>140)
			    {
			    	memcpy(TempHan,&RtuDataAddr->FkZhongWen[k[j-1]].HZXinXi[138],18);
			    	GUI_DispStringAt(TempHan,0,128);
			    }

		       // if((RtuDataAddr->FkZhongWen[i].Stat&0x10)==0x10)
		       //    GUI_DispStringAt("��",0,128);



		   }
		   else GUI_DispStringAt("û��������Ϣ",32,66);

		     Status_Bar();
		     BottomBar();
		     Lcmfull();

		     keysele=KeySeleflag;
		     KeySeleflag =0;
		     if(keysele!=0)DelayTime=0;else DelayTime++;

		     if(DelayTime>=PageDelayTime)
		       {
		       	OldLevel=0;
		       	return 0;
		       	}
			     switch(keysele)
			   {
			   case 1:j=j-1;if(j>200||j==0)j=q; break;
			   case 2:j=j+1;if(j>q)j=1;break;
			   case 6: OldLevel=0;return 0;break;
			   default:break;
			   }

		  }


}
/******************************************************************************************************************
* �������ƣ�Show_ZhongWenY()�����ڵڶ����˵�
* ��    �ܣ����鿴�����ġ���һ�������¼���
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
int Show_ZhongWenY(INT8U SeleMenu)
{
		 unsigned char keysele,TempHan[21],k[10],p,j,q;
		 unsigned int DelayTime;

		 DelayTime=0;
		 j=0;
		 q=0;
    //     i = RtuDataAddr->Fm_Save_Eve.ZWNo-1;
    //     if(i>200)i=9;
         for(p=0;p<10;p++)
         {
	         if((RtuDataAddr->FkZhongWen[p].Stat&0x20)==0x20)
	         {
	         	k[j]=p;
	         	j=j+1;

	         }
	         //k[j]���������Ϣ��������һ����Ϣ��jΪ��ʮ����Ϣ���ж�����һ����Ϣ��
         }
         if(j==0)
         	q=j=1;
         else
         {
  		 	q=j;
  		 	if(j>=2)
  		 		a_up=a_down=1;

         }


 		  while(1)
		  {
		    GUI_Clear();
		    GUI_SetTextMode(GUI_TM_REV);
		    GUI_DispDecAt(j-1,0,16,2);
		    GUI_SetTextMode(GUI_TM_NORMAL);

		   if(RtuDataAddr->FkZhongWen[k[j-1]].Valid ==1)
		   {
		   	    memset(TempHan,0,21);
			    memcpy(TempHan,&RtuDataAddr->FkZhongWen[k[j-1]].HZXinXi[0],18);
			    GUI_DispStringAt(TempHan,16,16);

			    if(RtuDataAddr->FkZhongWen[k[j-1]].len>20)
			    {
			    	memcpy(TempHan,&RtuDataAddr->FkZhongWen[k[j-1]].HZXinXi[18],20);
			    	GUI_DispStringAt(TempHan,0,32);
			    }
			     if(RtuDataAddr->FkZhongWen[k[j-1]].len>40)
			    {
			    	memcpy(TempHan,&RtuDataAddr->FkZhongWen[k[j-1]].HZXinXi[38],20);
			    	GUI_DispStringAt(TempHan,0,48);
			    }
			     if(RtuDataAddr->FkZhongWen[k[j-1]].len>60)
			    {
			    	memcpy(TempHan,&RtuDataAddr->FkZhongWen[k[j-1]].HZXinXi[58],20);
			    	GUI_DispStringAt(TempHan,0,64);
			    }
			     if(RtuDataAddr->FkZhongWen[k[j-1]].len>80)
			    {
			    	memcpy(TempHan,&RtuDataAddr->FkZhongWen[k[j-1]].HZXinXi[78],20);
			    	GUI_DispStringAt(TempHan,0,80);
			    }
			     if(RtuDataAddr->FkZhongWen[k[j-1]].len>100)
			    {
			    	memcpy(TempHan,&RtuDataAddr->FkZhongWen[k[j-1]].HZXinXi[98],20);
			    	GUI_DispStringAt(TempHan,0,96);
			    }
			    if(RtuDataAddr->FkZhongWen[k[j-1]].len>120)
			    {
			    	memcpy(TempHan,&RtuDataAddr->FkZhongWen[k[j-1]].HZXinXi[118],20);
			    	GUI_DispStringAt(TempHan,0,112);
			    }
			    if(RtuDataAddr->FkZhongWen[k[j-1]].len>140)
			    {
			    	memcpy(TempHan,&RtuDataAddr->FkZhongWen[k[j-1]].HZXinXi[138],18);
			    	GUI_DispStringAt(TempHan,0,128);
			    }

		   }
		   else GUI_DispStringAt("û��������Ϣ",32,66);

		     Status_Bar();
		     BottomBar();
		     Lcmfull();

		     keysele=KeySeleflag;
		     KeySeleflag =0;
		     if(keysele!=0)DelayTime=0;else DelayTime++;

		     if(DelayTime>=PageDelayTime)
		       {
		       	OldLevel=0;
		       	return 0;
		       	}
			     switch(keysele)
			   {
			   case 1:j=j-1;printf("j=%d\r\n",j);if(j>200||j==0)j=q;printf("j1=%d\r\n",j); break;
			   case 2:j=j+1;if(j>q)j=1;break;
			   case 6: OldLevel=0;return 0;break;
			   default:break;
			   }

		  }


}

/******************************************************************************************************************
* �������ƣ�Show_MaiChongCount()�����ڵڶ����˵�
* ��    �ܣ����鿴�����ġ������������
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
int Show_MaiChongCount(INT8U SeleMenu)
{
		 unsigned char keysele;
		 unsigned int DelayTime;
		 GUI_Clear();
		 DelayTime=0;
		 GUI_DispStringAt("���� 1:",20,34);
	     GUI_DispStringAt("���� 2:",20,54);
	     GUI_DispStringAt("���� 3:",20,74);
	     GUI_DispStringAt("���� 4:",20,94);
	    // GUI_DispStringAt("ʵʱ����:",4,98);
	    // GUI_DispStringAt("�ۼƵ�����:",4,118);// while�в����и�ֵ
		  while(1)
		  {
	        GUI_DispDecShiftAt(76,34,8,0,RtuDataAddr->MaiChongVar[0].ImpulseNum);
	        GUI_DispDecShiftAt(76,54,8,0,RtuDataAddr->MaiChongVar[1].ImpulseNum);
	        GUI_DispDecShiftAt(76,74,8,0,RtuDataAddr->MaiChongVar[2].ImpulseNum);
	        GUI_DispDecShiftAt(76,94,8,0,RtuDataAddr->MaiChongVar[3].ImpulseNum);

		     Status_Bar();
		     Lcmfull();
		     keysele=KeySeleflag;
		     KeySeleflag =0;
		     if(keysele!=0)DelayTime=0;else DelayTime++;
		    if(DelayTime>=PageDelayTime)
		       {
		       	OldLevel=0;
		       	return 0;
		       	}
		    if(keysele == 6)//ȡ����
		     {
			     OldLevel=0;
			     return 0;
		     }

		  }
}
/******************************************************************************************************************
* �������ƣ�Show_Banben()�����ڵڶ����˵�
* ��    �ܣ����鿴�����ġ���������Ӳ���汾��Ϣ��
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
int Show_Banben(INT8U SeleMenu)
{
		 unsigned char keysele;
		 unsigned int DelayTime;
		 GUI_Clear();
		 DelayTime=0;
		 GUI_DispStringAt("�������Կ�",40,24);
	     GUI_DispStringAt("�ն��ͺ�:",24,54);
	     GUI_DispStringAt("��ǰ�汾:",24,74);
	     GUI_DispStringAt("�汾����:",24,94);
		  while(1)
		  {

		     Status_Bar();
		     Lcmfull();
		     keysele=KeySeleflag;
		     KeySeleflag =0;
		     if(keysele!=0)DelayTime=0;else DelayTime++;
		    if(DelayTime>=PageDelayTime)
		       {
		       	OldLevel=0;
		       	return 0;
		       	}
		    if(keysele == 6)//ȡ����
		     {
			     OldLevel=0;
			     return 0;
		     }

		  }


}
/******************************************************************************************************************
* �������ƣ�zhongduanzj()�����ڵ�һ���˵�
* ��    �ܣ����ն��Լ졿
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
INT8U FlashCount;
int zhongduanzj(INT8U SeleMenu)
{/*
    unsigned char keysele;
    unsigned int DelayTime;
    DelayTime=0;
	GUI_Clear();
	GUI_DispStringAt("ϵͳ��ʹ����:",16,16);GUI_DispDecShiftAt(120,16,3,0,RtuDataAddr->sys);GUI_DispStringAt("%",144,16);
	GUI_DispStringAt("������ʹ����:",16,32);GUI_DispDecShiftAt(120,32,3,0,RtuDataAddr->data);GUI_DispStringAt("%",144,32);
	GUI_DispStringAt("�ڴ�����: ",16,48);GUI_DispDecShiftAt(88,48,2,0,32);GUI_DispStringAt("MB",104,48);
	GUI_DispStringAt("�ڴ�ʹ����: ",16,64);GUI_DispDecShiftAt(104,64,3,0,RtuDataAddr->mem);GUI_DispStringAt("%",128,64);
	GUI_DispStringAt("CPU����: ",16,80);GUI_DispDecShiftAt(88,80,3,0,RtuDataAddr->cpu);GUI_DispStringAt("%",112,80);

	GUI_DispStringAt("�ź�ǿ��:",16,96);
	GUI_DispStringAt("��������:",16,112);
	GUI_DispStringAt("ϵͳ����:",16,128);
    GUI_DispDecShiftAt(98,96,2,0,RtuDataAddr->GprsCSQ);
    if(RtuDataAddr->Gprs_ok==1)
  	  GUI_DispStringAt("OK!",98,112);
    else
  	  GUI_DispStringAt("NO!",98,112);
    if(RtuDataAddr->linked_ok==1)
        GUI_DispStringAt("OK!",98,128);
    else
        GUI_DispStringAt("NO!",98,128);
    while(1)
    {
    	GUI_DispDecShiftAt(120,16,3,0,RtuDataAddr->sys);
    	GUI_DispDecShiftAt(120,32,3,0,RtuDataAddr->data);
    	GUI_DispDecShiftAt(88,48,2,0,32);
    	GUI_DispDecShiftAt(104,64,3,0,RtuDataAddr->mem);
    	GUI_DispDecShiftAt(88,80,3,0,RtuDataAddr->cpu);

        GUI_DispDecShiftAt(98,96,2,0,RtuDataAddr->GprsCSQ);
        if(RtuDataAddr->Gprs_ok==1)
      	  GUI_DispStringAt("OK!",98,112);
        else
      	  GUI_DispStringAt("NO!",98,112);
        if(RtuDataAddr->linked_ok==1)
            GUI_DispStringAt("OK!",98,128);
        else
            GUI_DispStringAt("NO!",98,128);

	     keysele=KeySeleflag;
	     KeySeleflag =0;
	     if(keysele!=0)DelayTime=0;else DelayTime++;
		     if(DelayTime>=PageDelayTime*4)
		       {
		       	OldLevel=0;
		       	return 0;
		       	}
	     if(keysele == 6)//ȡ����
	     {
		    OldLevel = 0;
		    return 0;
	     }
        Status_Bar();
		Lcmfull();
    }*/
}
/******************************************************************************************************************
* �������ƣ�GprsTxZt()�����ڵڶ����˵�
* ��    �ܣ����Լ졿�еġ�GPRSͨѶ״̬�����������������½������ͨ��������
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
 int GprsTxZt(INT8U SeleMenu)
 {
     unsigned char keysele;
     unsigned int DelayTime;
 	 GUI_Clear();
 	 DelayTime=0;
 	 GUI_DispStringAt("���ߴ���:    ��",16,32);
 	 GUI_DispStringAt("��½����:    ��",16,52);
 	 GUI_DispStringAt("��������:",0,72);
 	 GUI_DispStringAt("��������:",0,94);
     while(1)
     {
 	     keysele=KeySeleflag;
	     KeySeleflag =0;
	     if(keysele!=0)DelayTime=0;else DelayTime++;
		     if(DelayTime>=PageDelayTime)
		       {
		       	OldLevel=0;
		       	return 0;
		       	}
	     if(keysele == 6)//ȡ����
	     {
		    OldLevel = 0;
		    return 0;
	     }
         GUI_DispDecShiftAt(88,32,3,0,OSCPUUsage);
         GUI_DispDecShiftAt(88,52,3,0,FlashCount);
         GUI_DispDecShiftAt(72,72,10,0,RtuDataAddr->Fm_Save_Eve.DayLiuLiang);
         GUI_DispDecShiftAt(72,94,10,0,RtuDataAddr->Fm_Save_Eve.yueLiuLiang);
         Status_Bar();
		 Lcmfull();

     }
 }
 /******************************************************************************************************************
* �������ƣ�CpuUse()�����ڵڶ����˵�
* ��    �ܣ����Լ졿�еġ�����������CPU���ɡ�ʹ������
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
 int CpuUse(INT8U SeleMenu)
 {/*
 	 INT8U keysele;
 	 unsigned int DelayTime;
 	 GUI_Clear();
 	 DelayTime=0;
 	 GUI_DispStringAt("CPU����:    %",32,32);
 	 GUI_DispStringAt("�洢����:  Ƭ",32,52);
     while(1)
     {
 	     keysele=KeySeleflag;
	     KeySeleflag =0;
	     if(keysele!=0)DelayTime=0;else DelayTime++;
		     if(DelayTime>=PageDelayTime)
		       {
		       	OldLevel=0;
		       	return 0;
		       	}
	     if(keysele == 6)//ȡ����
	     {
		    OldLevel = 0;
		    return 0;
	     }
         GUI_DispDecShiftAt(96,32,3,0,OSCPUUsage);
         GUI_DispDecShiftAt(104,52,2,0,FlashCount);
		  Status_Bar();
		  Lcmfull();
     }*/
 }
 /******************************************************************************************************************
 * �������ƣ�banbenxx()�����ڵ�һ���˵�
 * ��    �ܣ����汾��Ϣ��
 * ��ڲ�������
 * ���ڲ�������
 /*******************************************************************************************************************/
 int banbenxx(INT8U SeleMenu)
 {/*
 	 INT8U keysele;
 	 unsigned int DelayTime;
 	 GUI_Clear();
 	 DelayTime=0;
 	 GUI_DispStringAt("��������:�ൺ�߿�",8,48);
 	 GUI_DispStringAt("�����汾: 1.0",8,68);
 	 GUI_DispStringAt("Ӳ���汾: 1.0",8,90);
     while(1)
     {
 	     keysele=KeySeleflag;
	     KeySeleflag =0;
	     if(keysele!=0)DelayTime=0;else DelayTime++;
		     if(DelayTime>=PageDelayTime)
		       {
		       	OldLevel=0;
		       	return 0;
		       	}
	     if(keysele == 6)//ȡ����
	     {
		    OldLevel = 0;
		    return 0;
	     }
		 Status_Bar();
		 Lcmfull();

    }*/
}
 /********************************************************************************************
* �������ƣ�ChangePassword()���ڵڶ����˵�
* ���ܣ��������
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************/
int ChangePassword(INT8U SeleMenu)
{/*
	    unsigned char i,Tpassword[2];
		unsigned int TmpPass=0;
		FILE *fp;
		unsigned char filename[128];
		INT8U keysele;
	    INT16U DelayTime;
	    DelayTime=0;
	    GUI_Clear();
	    GUI_DispStringAt("����:",36,64);
	    GUI_DispStringAt(NowInput.buf,100,64);
		    while(1)
			{
			  Status_Bar();
			  i=0;
			  keysele=KeySeleflag;
			  KeySeleflag =0;
			  if(keysele!=0)DelayTime=0;else DelayTime++;
			         if(DelayTime>=PageDelayTime)
	                {
	    				OldLevel=0;
					   	return 0;
			       	}
	          switch(keysele)
	            {
	            	case 5:    //ȷ����
	                  {

	                		if(ScreenInput()==1)
	                        {
	                		      Tpassword[0]=GetNum(&NowInput.buf[0],2,1);
	                		      Tpassword[1]=GetNum(&NowInput.buf[2],2,1);
	                		      TmpPass=Tpassword[0]*100+Tpassword[1];
	                		      PassWord=TmpPass;
	                		      sprintf(filename,"/nand/save/password.sav");
	                		      fp=fopen(filename,"wb+");
	                		      if(fp!=NULL)
	                		    	  fwrite(&PassWord,2,1,fp);
	                		      fclose(fp);
	                		}

	                	  memset(NowInput.buf,0,128);
	                	  sprintf(NowInput.buf,"%02d%02d",   //16���Ƶ�BCD��
	                	  			Tpassword[0],Tpassword[1]);  //����ת����Ϊ�ַ���
	                	  	i=0;
	                	  while(i<4)
	                	  	{
	                	  		NowInput.col[i]=64;//y��
	                	  		NowInput.row[i]=100+i*8;//x��
	                	  		NowInput.set[i]=1;
	                	  		i++;
	                	  	}
	                	  	NowInput.AllNum=5;

	          		GUI_Clear();
	          		GUI_DispStringAt("�����Ѹ��ģ�",32,60);
	          		Status_Bar();
	          		Lcmfull();
	          		}
				   break;
				   case 6:  //ȡ����
				    {
					     OldLevel=0;
					     return 0;
				     }
	                break;
	                default : break;
	            }
	              Lcmfull();
	 }

*/
}
/********************************************************************************************
  * �������ƣ�set485()���ڵڶ����˵�
  * ���ܣ�����485�˿ڣ���ʾ�շ���������
  * ��ڲ�������
  * ���ڲ�������
  /*******************************************************************************************/
int set485(INT8U SeleMenu)
{
	  INT8U keysele;
	  unsigned int DelayTime;
	  DelayTime=0;
	  GUI_Clear();
	  GUI_DispStringAt("���ͱ���:",0,24);GUI_DispDecShiftAt(80,24,2,0,RtuDataAddr->GprsCSQ);
	  GUI_DispStringAt("���ձ���:",0,68);GUI_DispDecShiftAt(80,68,2,0,RtuDataAddr->GprsCSQ);

	  while(1)
	  {
	   	   keysele=KeySeleflag;
	  	   KeySeleflag =0;
	  	   if(keysele!=0)DelayTime=0;else DelayTime++;
	  		   if(DelayTime>=PageDelayTime)
	  		   {
	  		       	OldLevel=0;
	  		       	return 0;
	  		   }
	  	   if(keysele == 6)//ȡ����
	  	   {
	  		    OldLevel = 0;
	  		    return 0;
	  	   }
	  	   Status_Bar();
	  	   Lcmfull();
	  }

}
/********************************************************************************************
  * �������ƣ�LoginState()���ڵڶ����˵�
  * ���ܣ���ʾ��½״̬
  * ��ڲ�������
  * ���ڲ�������
  /*******************************************************************************************/
  int  LoginState(INT8U SeleMenu)
  {/*
	  INT8U keysele;
	  unsigned int DelayTime;
	  DelayTime=0;
	  GUI_Clear();

	  GUI_DispStringAt("�ź�ǿ��:",16,32);
	  GUI_DispStringAt("��������:",16,64);
	  GUI_DispStringAt("ϵͳ����:",16,96);
      GUI_DispDecShiftAt(98,32,2,0,RtuDataAddr->GprsCSQ);
      if(RtuDataAddr->Gprs_ok==1)
    	  GUI_DispStringAt("OK!",98,64);
      else
    	  GUI_DispStringAt("NO!",98,64);
      if(RtuDataAddr->linked_ok==1)
          GUI_DispStringAt("OK!",98,96);
      else
          GUI_DispStringAt("NO!",98,96);


	  while(1)
	  {
	   	   keysele=KeySeleflag;
	  	   KeySeleflag =0;
	  	   if(keysele!=0)DelayTime=0;else DelayTime++;
	  		   if(DelayTime>=PageDelayTime)
	  		   {
	  		       	OldLevel=0;
	  		       	return 0;
	  		   }
	  	   if(keysele == 6)//ȡ����
	  	   {
	  		    OldLevel = 0;
	  		    return 0;
	  	   }
	  	   Status_Bar();
	  	   Lcmfull();
	  }
	  */
  }
/********************************************************************************************
    * �������ƣ�HistoryDay()���ڵڶ����˵�
    * ���ܣ���ʾ��ʷ��ͳ������
    * ��ڲ�������
    * ���ڲ�������
/*******************************************************************************************/
int HistoryDay(INT8U SeleMenu)
{
	 unsigned char keysele,CeLiangDian,j,i;
	 unsigned int DelayTime;

	 DelayTime=0;
     CeLiangDian=0;
	 j=0;
	 a_up = a_down =  1;
	 a_right = a_left = 1;

	  while(1)
	  {
	    GUI_Clear();
	    GUI_DispStringAt("������:",0,16);
	    GUI_DispDecAt(CeLiangDian+1 ,56,16,2);
	switch(j)
	{
	case 0:

	GUI_DispStringAt("�����й�",80,16);
    GUI_DispStringAt("��:  ",8,40);GUI_DispDecShiftAt(40,40,9,2,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].Z_P_All);
    GUI_DispStringAt("��:  ",8,56);GUI_DispDecShiftAt(40,56,9,2,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].Z_P_F[0]);
    GUI_DispStringAt("��:  ",8,72);GUI_DispDecShiftAt(40,72,9,2,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].Z_P_F[1]);
    GUI_DispStringAt("ƽ:  ",8,88);GUI_DispDecShiftAt(40,88,9,2,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].Z_P_F[2]);
    GUI_DispStringAt("��:  ",8,104);GUI_DispDecShiftAt(40,104,9,2,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].Z_P_F[3]);

    GUI_DispStringAt("(Kw)",120,40);
    GUI_DispStringAt("(Kw)",120,56);
    GUI_DispStringAt("(Kw)",120,72);
    GUI_DispStringAt("(Kw)",120,88);
    GUI_DispStringAt("(Kw)",120,104);

	break;

	case 1:

	GUI_DispStringAt("�����й�",80,16);
    GUI_DispStringAt("��:  ",8,40);GUI_DispDecShiftAt(40,40,9,2,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].F_P_All);
    GUI_DispStringAt("��:  ",8,56);GUI_DispDecShiftAt(40,56,9,2,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].F_P_F[0]);
    GUI_DispStringAt("��:  ",8,72);GUI_DispDecShiftAt(40,72,9,2,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].F_P_F[1]);
    GUI_DispStringAt("ƽ:  ",8,88);GUI_DispDecShiftAt(40,88,9,2,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].F_P_F[2]);
    GUI_DispStringAt("��:  ",8,104);GUI_DispDecShiftAt(40,104,9,2,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].F_P_F[3]);

    GUI_DispStringAt("(Kw)",120,40);
	GUI_DispStringAt("(Kw)",120,56);
	GUI_DispStringAt("(Kw)",120,72);
    GUI_DispStringAt("(Kw)",120,88);
	GUI_DispStringAt("(Kw)",120,104);

	break;

	case 2:

	GUI_DispStringAt("�������޹����� ",0,40);

    GUI_DispStringAt("1:",0,56);GUI_DispDecShiftAt(16,56,9,2,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].X1_Q_All);
    GUI_DispStringAt("2:",0,72);GUI_DispDecShiftAt(16,72,9,2,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].X2_Q_All);
    GUI_DispStringAt("3:",0,88);GUI_DispDecShiftAt(16,88,9,2,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].X3_Q_All);
    GUI_DispStringAt("4:",0,104);GUI_DispDecShiftAt(16,104,9,2,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].X4_Q_All);

    GUI_DispStringAt("(Kvar/h)",96,56);
  	GUI_DispStringAt("(Kvar/h)",96,72);
  	GUI_DispStringAt("(Kvar/h)",96,88);
    GUI_DispStringAt("(Kvar/h)",96,104);

	break;
	case 3:

	GUI_DispStringAt("U��IԽ����ʱ��",0,32);
    GUI_DispStringAt("TUa:",16,48);GUI_DispDecShiftAt(48,48,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].USU_Count);
    GUI_DispStringAt("TUb:",16,64);GUI_DispDecShiftAt(48,64,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].USV_Count);
    GUI_DispStringAt("TUc:",16,80);GUI_DispDecShiftAt(48,80,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].USW_Count);

    GUI_DispStringAt("TIa:",16,96);GUI_DispDecShiftAt(48,96,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].ISU_Count);
    GUI_DispStringAt("TIb:",16,112);GUI_DispDecShiftAt(48,112,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].ISV_Count);
    GUI_DispStringAt("TIc:",16,128);GUI_DispDecShiftAt(48,128,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].ISW_Count);
	break;
	case 4:
	GUI_DispStringAt("UԽ����ʱ��",0,40);
    GUI_DispStringAt("TUa:",16,64);GUI_DispDecShiftAt(48,64,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].UXU_Count);
    GUI_DispStringAt("TUb:",16,80);GUI_DispDecShiftAt(48,80,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].UXV_Count);
    GUI_DispStringAt("TUc:",16,96);GUI_DispDecShiftAt(48,96,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].UXW_Count);

	break;
	case 5:
	GUI_DispStringAt("U���ֵ��Сֵ",0,32);
    GUI_DispStringAt("MAXUa:",16,48);GUI_DispDecShiftAt(64,48,5,1,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUUMAX);
    GUI_DispStringAt("MAXUb:",16,64);GUI_DispDecShiftAt(64,64,5,1,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUVMAX);
    GUI_DispStringAt("MAXUc:",16,80);GUI_DispDecShiftAt(64,80,5,1,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUWMAX);

    GUI_DispStringAt("MINUa:",16,96);GUI_DispDecShiftAt(64,96,5,1,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUUMIN);
    GUI_DispStringAt("MINUb:",16,112);GUI_DispDecShiftAt(64,112,5,1,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUVMIN);
    GUI_DispStringAt("MINUc:",16,128);GUI_DispDecShiftAt(64,128,5,1,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUWMIN);

	break;

	case 6:
	GUI_DispStringAt("����U��ֵ����ʱ��",0,32);
    GUI_DispStringAt("TMAXUa:",16,48);GUI_DispDecShiftAt(72,48,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUUMAX_TIME);
    GUI_DispStringAt("TMAXUb:",16,64);GUI_DispDecShiftAt(72,64,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUVMAX_TIME);
    GUI_DispStringAt("TMAXUc:",16,80);GUI_DispDecShiftAt(72,80,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUWMAX_TIME);

    GUI_DispStringAt("TMINUa:",16,96);GUI_DispDecShiftAt(72,96,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUUMIN_TIME);
    GUI_DispStringAt("TMINUb:",16,112);GUI_DispDecShiftAt(72,112,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUVMIN_TIME);
    GUI_DispStringAt("TMINUc:",16,128);GUI_DispDecShiftAt(72,128,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUWMIN_TIME);

	break;
	case 7:
	GUI_DispStringAt("I���ֵ����ʱ��",0,40);
    GUI_DispStringAt("TMAXIa:",16,64);GUI_DispDecShiftAt(72,64,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DIUMAX_TIME);
    GUI_DispStringAt("TMAXIb:",16,80);GUI_DispDecShiftAt(72,80,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DIVMAX_TIME);
    GUI_DispStringAt("TMAXIc:",16,96);GUI_DispDecShiftAt(72,96,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DIWMAX_TIME);
	break;

	case 8:
	GUI_DispStringAt("�й�����",16,40);
	//GUI_DispStringAt("�й�����",80,16);
	GUI_DispStringAt("P:",16,56);GUI_DispDecShiftAt(48,56,7,1,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].P);
	GUI_DispStringAt("Pa:",16,72);GUI_DispDecShiftAt(48,72,7,1,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].PA);
	GUI_DispStringAt("Pb:",16,88);GUI_DispDecShiftAt(48,88,7,1,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].PB);
	GUI_DispStringAt("Pc:",16,104);GUI_DispDecShiftAt(48,104,7,1,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].PC);

	GUI_DispStringAt("(Kw)",112,56);
	GUI_DispStringAt("(Kw)",112,72);
    GUI_DispStringAt("(Kw)",112,88);
	GUI_DispStringAt("(Kw)",112,104);
	break;
	case 9:
	GUI_DispStringAt("�޹�����",16,40);
	//GUI_DispStringAt("�޹�����",80,16);
	GUI_DispStringAt("Q:",16,56);GUI_DispDecShiftAt(48,56,7,1,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].Q);
	GUI_DispStringAt("Qa:",16,72);GUI_DispDecShiftAt(48,72,7,1,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].QA);
	GUI_DispStringAt("Qb:",16,88);GUI_DispDecShiftAt(48,88,7,1,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].QB);
	GUI_DispStringAt("Qc:",16,104);GUI_DispDecShiftAt(48,104,7,1,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].QC);


	GUI_DispStringAt("(Kvar)",110,56);
    GUI_DispStringAt("(Kvar)",110,72);
	GUI_DispStringAt("(Kvar)",110,88);
	GUI_DispStringAt("(Kvar)",110,104);
	break;

	case 10:
    GUI_DispStringAt("��������",16,40);
	//GUI_DispStringAt("��������",80,16);
	GUI_DispStringAt("Cs : ",16,56);GUI_DispDecShiftAt(64,56,5,3,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].Cos);
	GUI_DispStringAt("Csa: ",16,72);GUI_DispDecShiftAt(64,72,5,3,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].CosA);
	GUI_DispStringAt("Csb: ",16,88);GUI_DispDecShiftAt(64,88,5,3,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].CosB);
	GUI_DispStringAt("Csc: ",16,104);GUI_DispDecShiftAt(64,104,5,3,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].CosC);

	break;

	default:break;
	}

	Status_Bar();
	BottomBar();
	Lcmfull();

	keysele=KeySeleflag;
	KeySeleflag =0;
	if(keysele!=0)DelayTime=0;else DelayTime++;
   if(DelayTime>=PageDelayTime)
   {
	    OldLevel=0;
	   	return 0;
	}
	switch(keysele)
	{
		 case 1: if(CeLiangDian==0)CeLiangDian=7;else CeLiangDian=CeLiangDian-1;DelayTime=0;break;//��
		 case 2: CeLiangDian=(CeLiangDian+1)%(CeLiangPoint_Max);DelayTime=0;break;//��
		 case 3: if(j==0)j=10;else j=j-1;DelayTime=0;break;//��
		 case 4: j=(j+1)%11;DelayTime=0;break;//��
		 case 6: OldLevel=0;return 0;break;
		 default:break;
   }
}

}

/********************************************************************************************
    * �������ƣ�HistoryMonth()���ڵڶ����˵�
    * ���ܣ���ʾ��ʷ��ͳ������
    * ��ڲ�������
    * ���ڲ�������
/*******************************************************************************************/
int HistoryMonth(INT8U SeleMenu)
{/*
	 unsigned char keysele,CeLiangDian,j,i;
	 unsigned int DelayTime;

	 DelayTime=0;
     CeLiangDian=0;
	 j=0;
	 a_up = a_down =  1;
	 a_right = a_left = 1;

	  while(1)
	  {
	    GUI_Clear();
	    GUI_DispStringAt("������:",0,16);
	    GUI_DispDecAt(CeLiangDian+1 ,56,16,2);
	switch(j)
	{
	case 0:

	GUI_DispStringAt("�����й�",80,16);
    GUI_DispStringAt("��:  ",8,40);GUI_DispDecShiftAt(40,40,9,2,RtuDataAddr->Yue_DD_BS_Value[CeLiangDian].Z_P_All);
    GUI_DispStringAt("��:  ",8,56);GUI_DispDecShiftAt(40,56,9,2,RtuDataAddr->Yue_DD_BS_Value[CeLiangDian].Z_P_F[0]);
    GUI_DispStringAt("��:  ",8,72);GUI_DispDecShiftAt(40,72,9,2,RtuDataAddr->Yue_DD_BS_Value[CeLiangDian].Z_P_F[1]);
    GUI_DispStringAt("ƽ:  ",8,88);GUI_DispDecShiftAt(40,88,9,2,RtuDataAddr->Yue_DD_BS_Value[CeLiangDian].Z_P_F[2]);
    GUI_DispStringAt("��:  ",8,104);GUI_DispDecShiftAt(40,104,9,2,RtuDataAddr->Yue_DD_BS_Value[CeLiangDian].Z_P_F[3]);

    GUI_DispStringAt("(Kw)",120,40);
    GUI_DispStringAt("(Kw)",120,56);
    GUI_DispStringAt("(Kw)",120,72);
    GUI_DispStringAt("(Kw)",120,88);
    GUI_DispStringAt("(Kw)",120,104);

	break;

	case 1:

	GUI_DispStringAt("�����й�",80,16);
    GUI_DispStringAt("��:  ",8,40);GUI_DispDecShiftAt(40,40,9,2,RtuDataAddr->Yue_DD_BS_Value[CeLiangDian].F_P_All);
    GUI_DispStringAt("��:  ",8,56);GUI_DispDecShiftAt(40,56,9,2,RtuDataAddr->Yue_DD_BS_Value[CeLiangDian].F_P_F[0]);
    GUI_DispStringAt("��:  ",8,72);GUI_DispDecShiftAt(40,72,9,2,RtuDataAddr->Yue_DD_BS_Value[CeLiangDian].F_P_F[1]);
    GUI_DispStringAt("ƽ:  ",8,88);GUI_DispDecShiftAt(40,88,9,2,RtuDataAddr->Yue_DD_BS_Value[CeLiangDian].F_P_F[2]);
    GUI_DispStringAt("��:  ",8,104);GUI_DispDecShiftAt(40,104,9,2,RtuDataAddr->Yue_DD_BS_Value[CeLiangDian].F_P_F[3]);

    GUI_DispStringAt("(Kw)",120,40);
	GUI_DispStringAt("(Kw)",120,56);
	GUI_DispStringAt("(Kw)",120,72);
    GUI_DispStringAt("(Kw)",120,88);
	GUI_DispStringAt("(Kw)",120,104);

	break;

	case 2:

	GUI_DispStringAt("�������޹����� ",0,40);

    GUI_DispStringAt("1:",0,56);GUI_DispDecShiftAt(16,56,9,2,RtuDataAddr->Yue_DD_BS_Value[CeLiangDian].X1_Q_All);
    GUI_DispStringAt("2:",0,72);GUI_DispDecShiftAt(16,72,9,2,RtuDataAddr->Yue_DD_BS_Value[CeLiangDian].X2_Q_All);
    GUI_DispStringAt("3:",0,88);GUI_DispDecShiftAt(16,88,9,2,RtuDataAddr->Yue_DD_BS_Value[CeLiangDian].X3_Q_All);
    GUI_DispStringAt("4:",0,104);GUI_DispDecShiftAt(16,104,9,2,RtuDataAddr->Yue_DD_BS_Value[CeLiangDian].X4_Q_All);

    GUI_DispStringAt("(Kvar/h)",96,56);
 	GUI_DispStringAt("(Kvar/h)",96,72);
 	GUI_DispStringAt("(Kvar/h)",96,88);
    GUI_DispStringAt("(Kvar/h)",96,104);

	break;
	case 3:

	GUI_DispStringAt("U��IԽ�����ۼ�ʱ��",0,32);
    GUI_DispStringAt("TUa:",16,48);GUI_DispDecShiftAt(48,48,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].USU_Count);
    GUI_DispStringAt("TUb:",16,64);GUI_DispDecShiftAt(48,64,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].USV_Count);
    GUI_DispStringAt("TUc:",16,80);GUI_DispDecShiftAt(48,80,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].USW_Count);

    GUI_DispStringAt("TIa:",16,96);GUI_DispDecShiftAt(48,96,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].ISU_Count);
    GUI_DispStringAt("TIb:",16,112);GUI_DispDecShiftAt(48,112,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].ISV_Count);
    GUI_DispStringAt("TIc:",16,128);GUI_DispDecShiftAt(48,128,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].ISW_Count);
	break;
	case 4:
	GUI_DispStringAt("UԽ�����ۼ�ʱ��",0,40);
    GUI_DispStringAt("TUa:",16,64);GUI_DispDecShiftAt(48,64,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].UXU_Count);
    GUI_DispStringAt("TUb:",16,80);GUI_DispDecShiftAt(48,80,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].UXV_Count);
    GUI_DispStringAt("TUc:",16,96);GUI_DispDecShiftAt(48,96,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].UXW_Count);

	break;
	case 5:
	GUI_DispStringAt("U���ֵ��Сֵ",0,32);
    GUI_DispStringAt("MAXUa:",16,48);GUI_DispDecShiftAt(64,48,5,1,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUUMAX);
    GUI_DispStringAt("MAXUb:",16,64);GUI_DispDecShiftAt(64,64,5,1,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUVMAX);
    GUI_DispStringAt("MAXUc:",16,80);GUI_DispDecShiftAt(64,80,5,1,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUWMAX);

    GUI_DispStringAt("MINUa:",16,96);GUI_DispDecShiftAt(64,96,5,1,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUUMIN);
    GUI_DispStringAt("MINUb:",16,112);GUI_DispDecShiftAt(64,112,5,1,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUVMIN);
    GUI_DispStringAt("MINUc:",16,128);GUI_DispDecShiftAt(64,128,5,1,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUWMIN);

	break;

	case 6:
	GUI_DispStringAt("����U��ֵ����ʱ��",0,32);
    GUI_DispStringAt("TMAXUa:",16,48);GUI_DispDecShiftAt(72,48,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUUMAX_TIME);
    GUI_DispStringAt("TMAXUb:",16,64);GUI_DispDecShiftAt(72,64,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUVMAX_TIME);
    GUI_DispStringAt("TMAXUc:",16,80);GUI_DispDecShiftAt(72,80,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUWMAX_TIME);

    GUI_DispStringAt("TMINUa:",16,96);GUI_DispDecShiftAt(72,96,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUUMIN_TIME);
    GUI_DispStringAt("TMINUb:",16,112);GUI_DispDecShiftAt(72,112,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUVMIN_TIME);
    GUI_DispStringAt("TMINUc:",16,128);GUI_DispDecShiftAt(72,128,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DUWMIN_TIME);

	break;
	case 7:
	GUI_DispStringAt("I���ֵ����ʱ��",0,40);
    GUI_DispStringAt("TMAXIa:",16,64);GUI_DispDecShiftAt(72,64,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DIUMAX_TIME);
    GUI_DispStringAt("TMAXIb:",16,80);GUI_DispDecShiftAt(72,80,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DIVMAX_TIME);
    GUI_DispStringAt("TMAXIc:",16,96);GUI_DispDecShiftAt(72,96,10,0,RtuDataAddr->F27_28_29_30_Mem[CeLiangDian].DIWMAX_TIME);
	break;

	case 8:
	GUI_DispStringAt("�й�����",16,40);
	//GUI_DispStringAt("�й�����",80,16);
	GUI_DispStringAt("P:",16,56);GUI_DispDecShiftAt(48,56,7,1,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].P);
	GUI_DispStringAt("Pa:",16,72);GUI_DispDecShiftAt(48,72,7,1,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].PA);
	GUI_DispStringAt("Pb:",16,88);GUI_DispDecShiftAt(48,88,7,1,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].PB);
	GUI_DispStringAt("Pc:",16,104);GUI_DispDecShiftAt(48,104,7,1,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].PC);

	GUI_DispStringAt("(Kw)",112,56);
	GUI_DispStringAt("(Kw)",112,72);
    GUI_DispStringAt("(Kw)",112,88);
	GUI_DispStringAt("(Kw)",112,104);
	break;
	case 9:
	GUI_DispStringAt("�޹�����",16,40);
	//GUI_DispStringAt("�޹�����",80,16);
	GUI_DispStringAt("Q:",16,56);GUI_DispDecShiftAt(48,56,7,1,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].Q);
	GUI_DispStringAt("Qa:",16,72);GUI_DispDecShiftAt(48,72,7,1,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].QA);
	GUI_DispStringAt("Qb:",16,88);GUI_DispDecShiftAt(48,88,7,1,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].QB);
	GUI_DispStringAt("Qc:",16,104);GUI_DispDecShiftAt(48,104,7,1,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].QC);


	GUI_DispStringAt("(Kvar)",110,56);
    GUI_DispStringAt("(Kvar)",110,72);
	GUI_DispStringAt("(Kvar)",110,88);
	GUI_DispStringAt("(Kvar)",110,104);
	break;

	case 10:
    GUI_DispStringAt("��������",16,40);
	//GUI_DispStringAt("��������",80,16);
	GUI_DispStringAt("Cs : ",16,56);GUI_DispDecShiftAt(64,56,5,3,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].Cos);
	GUI_DispStringAt("Csa: ",16,72);GUI_DispDecShiftAt(64,72,5,3,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].CosA);
	GUI_DispStringAt("Csb: ",16,88);GUI_DispDecShiftAt(64,88,5,3,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].CosB);
	GUI_DispStringAt("Csc: ",16,104);GUI_DispDecShiftAt(64,104,5,3,RtuDataAddr->Day_DD_BS_Value[CeLiangDian].CosC);

	break;

	default:break;
	}

	Status_Bar();
	BottomBar();
	Lcmfull();

	keysele=KeySeleflag;
	KeySeleflag =0;
	if(keysele!=0)DelayTime=0;else DelayTime++;
  if(DelayTime>=PageDelayTime)
  {
	    OldLevel=0;
	   	return 0;
	}
	switch(keysele)
	{
		 case 1: if(CeLiangDian==0)CeLiangDian=7;else CeLiangDian=CeLiangDian-1;DelayTime=0;break;//��
		 case 2: CeLiangDian=(CeLiangDian+1)%(CeLiangPoint_Max);DelayTime=0;break;//��
		 case 3: if(j==0)j=10;else j=j-1;DelayTime=0;break;//��
		 case 4: j=(j+1)%11;DelayTime=0;break;//��
		 case 6: OldLevel=0;return 0;break;
		 default:break;
  }
}*/
}
/********************************************************************************************
    * �������ƣ�CeLiangXinxi()���ڵڶ����˵�
    * ���ܣ���ʾ���������Ϣ
    * ��ڲ�������
    * ���ڲ�������
/*******************************************************************************************/
int CeLiangXinxi(INT8U SeleMenu)
{/*
	 unsigned char keysele,CeLiangDian,j,i;
	 unsigned int DelayTime;
	 INT16U UED,IED,US,UX,UD,USS,UXX,ISS,IS,I0S,SSS,SS,UVWXZ,ABCXZ,U0Time,V,I;

	 DelayTime=0;
	 CeLiangDian=0;
	 j=0;
	 a_up = a_down =  1;
	 a_right = a_left = 1;

	 for(i=0;i++;i<8)
	 {
		 I=RtuDataAddr->Cl_MenXian_Value[i].F25_Set_Para.I_BeiLv[1];
		 I=(I<<8)+RtuDataAddr->Cl_MenXian_Value[i].F25_Set_Para.I_BeiLv[0];
		 V=RtuDataAddr->Cl_MenXian_Value[i].F25_Set_Para.V_BeiLv[1];
		 V=(V<<8)+RtuDataAddr->Cl_MenXian_Value[i].F25_Set_Para.V_BeiLv[0];
		 UED=((RtuDataAddr->Cl_MenXian_Value[i].F25_Set_Para.E_Ding_V[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F25_Set_Para.E_Ding_V[1]&0x0f);
		 UED=(UED*100)+((RtuDataAddr->Cl_MenXian_Value[i].F25_Set_Para.E_Ding_V[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F25_Set_Para.E_Ding_V[0]&0x0f);
		 IED=((RtuDataAddr->Cl_MenXian_Value[i].F25_Set_Para.Max_I>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F25_Set_Para.Max_I&0x0f);
		 IED=IED*10;

		 US=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_S[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_S[1]&0x0f);
		 US=(US*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_S[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_S[0]&0x0f);

		 UX=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_X[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_X[1]&0x0f);
		 UX=(UX*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_X[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_X[0]&0x0f);

		 UD=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_Duan_Men[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_Duan_Men[1]&0x0f);
		 UD=(UD*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_Duan_Men[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_Duan_Men[0]&0x0f);

		 USS=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_SS[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_SS[1]&0x0f);
		 USS=(USS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_SS[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_SS[0]&0x0f);

		 UXX=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_XX[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_XX[1]&0x0f);
		 UXX=(UXX*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_XX[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_XX[0]&0x0f);
		 ISS=(((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_SS[1]>>4)&0x07)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_SS[1]&0x0f);
		 ISS=(ISS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_SS[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_SS[0]&0x0f);

		 IS=(((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_S[1]>>4)&0x07)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_S[1]&0x0f);
		 IS=(IS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_S[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_S[0]&0x0f);
		 I0S=(((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.U0I_S[1]>>4)&0x07)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.U0I_S[1]&0x0f);
		 I0S=(I0S*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.U0I_S[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.U0I_S[0]&0x0f);
		 SSS=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[2]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[2]&0x0f);
		 SSS=(SSS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[1]&0x0f);
		 SSS=(SSS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[0]&0x0f);
		 SSS=SSS;
		 SS=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[2]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[2]&0x0f);
		 SS=(SS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[1]&0x0f);
		 SS=(SS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[0]&0x0f);
		 SS=SS;
		 UVWXZ=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.U3_Unbalance_Value[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.U3_Unbalance_Value[1]&0x0f);
		 UVWXZ=(UVWXZ*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.U3_Unbalance_Value[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.U3_Unbalance_Value[0]&0x0f);

		 ABCXZ=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I3_Unbalance_Value[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I3_Unbalance_Value[1]&0x0f);
		 ABCXZ=(ABCXZ*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I3_Unbalance_Value[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I3_Unbalance_Value[0]&0x0f);
		 U0Time=RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.LianXu_ShiYa;
	 }
	 while(1)
	 {
	    GUI_Clear();
	    switch(j)
	    {
			case 0:
		    GUI_DispStringAt("������  ��������",16,16);
		    GUI_DispDecAt(CeLiangDian+1,64,16,2);
	    	GUI_DispStringAt("PT:",0,40);GUI_DispDecShiftAt(32,40,5,0,V);
	    	GUI_DispStringAt("CT:",0,56);GUI_DispDecShiftAt(32,56,5,0,I);
	    	GUI_DispStringAt("���ѹ:",0,72);GUI_DispDecShiftAt(80,72,5,0,UED);
	    	GUI_DispStringAt("������:",0,88);GUI_DispDecShiftAt(80,88,3,0,IED);
	    	GUI_DispStringAt("��Դ���߷�ʽ:",0,104);
	    	if(RtuDataAddr->Cl_MenXian_Value[CeLiangDian].F25_Set_Para.Type=1)
	    		GUI_DispStringAt("������",104,104);
	    	else
	    		if(RtuDataAddr->Cl_MenXian_Value[CeLiangDian].F25_Set_Para.Type=2)
	    			GUI_DispStringAt("������",104,104);
	    		else
	    			if(RtuDataAddr->Cl_MenXian_Value[CeLiangDian].F25_Set_Para.Type=3)
	    				GUI_DispStringAt("�����",104,104);
	    			else
	    				GUI_DispStringAt("����",104,104);
	    	GUI_DispStringAt("V",136,72);
	    	GUI_DispStringAt("A",136,88);
	    	break;

			case 1:
			GUI_DispStringAt("������  ��ֵ����",16,16);
			GUI_DispDecAt(CeLiangDian+1,64,16,2);
	    	GUI_DispStringAt("��ѹ�ϸ�����:",0,32);GUI_DispDecShiftAt(104,32,5,0,US);
	    	GUI_DispStringAt("��ѹ�ϸ�����:",0,48);GUI_DispDecShiftAt(104,48,5,0,UX);
	    	GUI_DispStringAt("��ѹ��������:",0,64);GUI_DispDecShiftAt(104,64,5,0,UD);
	    	GUI_DispStringAt("��ѹ����:",0,80);GUI_DispDecShiftAt(80,80,5,0,USS);
	    	GUI_DispStringAt("Ƿѹ����:",0,96);GUI_DispDecShiftAt(80,96,5,0,UXX);
	    	GUI_DispStringAt("��������:",0,112);GUI_DispDecShiftAt(80,112,3,0,ISS);
	    	GUI_DispStringAt("���������:",0,128);GUI_DispDecShiftAt(104,128,3,0,IS);

	    	GUI_DispStringAt("V",144,32);
	    	GUI_DispStringAt("V",144,48);
	    	GUI_DispStringAt("V",144,64);
	    	GUI_DispStringAt("V",144,80);
	    	GUI_DispStringAt("V",144,96);
	    	GUI_DispStringAt("A",144,112);
	    	GUI_DispStringAt("A",144,128);
	    	break;

			case 2:

			GUI_DispStringAt("������  ��ֵ����",16,16);
			GUI_DispDecAt(CeLiangDian+1,64,16,2);
		    GUI_DispStringAt("�����������:",0,32);GUI_DispDecShiftAt(104,32,3,0,I0S);
		    GUI_DispStringAt("���ڹ���������:",0,48);GUI_DispDecShiftAt(104,64,5,0,SSS);
		    GUI_DispStringAt("���ڹ�������:",0,80);GUI_DispDecShiftAt(104,80,5,0,SS);
		    GUI_DispStringAt("��ѹ��ƽ����:",0,96);GUI_DispDecShiftAt(104,96,3,0,UVWXZ);
		    GUI_DispStringAt("������ƽ����:",0,112);GUI_DispDecShiftAt(104,112,3,0,ABCXZ);
		    GUI_DispStringAt("����ʧѹʱ����:",0,128);GUI_DispDecShiftAt(120,128,3,0,U0Time);

		    GUI_DispStringAt("A",144,32);
		    GUI_DispStringAt("KW",144,64);
		    GUI_DispStringAt("KW",144,80);
		    GUI_DispStringAt("%",144,96);
		    GUI_DispStringAt("%",144,112);
		    GUI_DispStringAt("��",144,128);

	    	break;
			default:break;
	    }
	    Status_Bar();
	    BottomBar();
	    Lcmfull();

	    keysele=KeySeleflag;
	    KeySeleflag =0;
	    if(keysele!=0)DelayTime=0;else DelayTime++;
	    if(DelayTime>=PageDelayTime)
	    {
	    	OldLevel=0;
	    	return 0;
	    }
	    switch(keysele)
	    {
		 case 1: if(CeLiangDian==0)CeLiangDian=7;else CeLiangDian=CeLiangDian-1;DelayTime=0;break;//��
		 case 2: CeLiangDian=(CeLiangDian+1)%(CeLiangPoint_Max);DelayTime=0;break;//��
		 case 3: if(j==0)j=2;else j=j-1;DelayTime=0;break;//��
		 case 4: j=(j+1)%3;DelayTime=0;break;//��
		 case 6: OldLevel=0;return 0;break;
		 default:break;
	    }
	 }*/
}

/********************************************************************************************
    * �������ƣ�RenWuXinxi()���ڵڶ����˵�
    * ���ܣ���ʾ������Ϣ
    * ��ڲ�������
    * ���ڲ�������
/*******************************************************************************************/
int RenWuXinxi(INT8U SeleMenu)
{
/*
	INT8U keysele,CeLiangDian,i,j;
     INT16U Type,Num,DelayTime;
     INT8U Min,Hour,Day,Month,zqdw,zqvalue;
	 Min=(RtuDataAddr->Task_Value[i].F65_Set_Para.Ji_Zhun_Shi_Jian[1]>>4)*10;
	 Min=Min+RtuDataAddr->Task_Value[i].F65_Set_Para.Ji_Zhun_Shi_Jian[1]&0x0f;
	 Hour=(RtuDataAddr->Task_Value[i].F65_Set_Para.Ji_Zhun_Shi_Jian[2]>>4)*10;
	 Hour=Hour+RtuDataAddr->Task_Value[i].F65_Set_Para.Ji_Zhun_Shi_Jian[2]&0x0f;
	 Day=(RtuDataAddr->Task_Value[i].F65_Set_Para.Ji_Zhun_Shi_Jian[3]>>4)*10;
	 Day=Day+RtuDataAddr->Task_Value[i].F65_Set_Para.Ji_Zhun_Shi_Jian[3]&0x0f;
	 Month=((RtuDataAddr->Task_Value[i].F65_Set_Para.Ji_Zhun_Shi_Jian[4]>>4)&1)*10;
	 Month=Month+RtuDataAddr->Task_Value[i].F65_Set_Para.Ji_Zhun_Shi_Jian[4]&0x0f;
	 zqdw=RtuDataAddr->Task_Value[i].F65_Set_Para.FaSong_ZhouQi>>6;
	 zqvalue=RtuDataAddr->Task_Value[i].F65_Set_Para.FaSong_ZhouQi&0x3f;

     GUI_Clear();
     DelayTime=0;
     CeLiangDian=0;
     j=0;
	 a_up = a_down =  1;
	 a_right = a_left = 1;

	 while(1)
	 {
		GUI_Clear();
		GUI_DispStringAt("������:",0,16);
		GUI_DispDecAt(CeLiangDian+1 ,56,16,2);
	    switch(j)
	    {
			case 0:
		    GUI_DispStringAt("1������",96,16);
	    	GUI_DispStringAt("���ڵ�λ:",0,40);
	    	if(zqdw=0)
	    		GUI_DispStringAt("��",72,40);
	    	else
	    		if(zqdw=1)
	    			GUI_DispStringAt("ʱ",72,40);
	    		else
	    			if(zqdw=2)
	    				GUI_DispStringAt("��",72,40);
	    			else
	    				GUI_DispStringAt("��",72,40);
	    	GUI_DispStringAt("��׼ʱ��:",0,56);
	    	GUI_DispDecShiftAt(16,72,2,0,Min);GUI_DispStringAt("��",32,72);
	    	GUI_DispDecShiftAt(48,72,2,0,Hour);GUI_DispStringAt("ʱ",64,72);
	    	GUI_DispDecShiftAt(80,72,2,0,Day);GUI_DispStringAt("��",96,72);
	    	GUI_DispDecShiftAt(112,72,2,0,Month);GUI_DispStringAt("��",128,72);

	    	GUI_DispStringAt("��������:",0,88);GUI_DispDecShiftAt(72,88,5,0,zqvalue);
	    	GUI_DispStringAt("���߳�ȡ���ݱ���:",0,104);GUI_DispDecShiftAt(136,104,2,0,RtuDataAddr->Task_Value[i].F65_Set_Para.Qu_Xian_ChouQu_BeiLv);
	    	GUI_DispStringAt("���ݵ�Ԫ��ʶ����:",0,120);GUI_DispDecShiftAt(136,120,2,0,RtuDataAddr->Task_Value[i].F65_Set_Para.ShuJv_DanYuan_Num);
	    	break;

			case 1:
		    GUI_DispStringAt("2������",96,16);
	    	GUI_DispStringAt("���ڵ�λ:",0,40);
	    	if(zqdw=0)
	    		GUI_DispStringAt("��",72,40);
	    	else
	    		if(zqdw=1)
	    			GUI_DispStringAt("ʱ",72,40);
	    		else
	    			if(zqdw=2)
	    				GUI_DispStringAt("��",72,40);
	    			else
	    				GUI_DispStringAt("��",72,40);
	    	GUI_DispStringAt("��׼ʱ��:",0,56);
	    	GUI_DispDecShiftAt(16,72,2,0,Min);GUI_DispStringAt("��",32,72);
	    	GUI_DispDecShiftAt(48,72,2,0,Hour);GUI_DispStringAt("ʱ",64,72);
	    	GUI_DispDecShiftAt(80,72,2,0,Day);GUI_DispStringAt("��",96,72);
	    	GUI_DispDecShiftAt(112,72,2,0,Month);GUI_DispStringAt("��",128,72);

	    	GUI_DispStringAt("��������:",0,88);GUI_DispDecShiftAt(72,88,5,0,zqvalue);
	    	GUI_DispStringAt("���߳�ȡ���ݱ���:",0,104);GUI_DispDecShiftAt(136,104,2,0,RtuDataAddr->Task_Value[i].F65_Set_Para.Qu_Xian_ChouQu_BeiLv);
	    	GUI_DispStringAt("���ݵ�Ԫ��ʶ����:",0,120);GUI_DispDecShiftAt(136,120,2,0,RtuDataAddr->Task_Value[i].F65_Set_Para.ShuJv_DanYuan_Num);
	    	break;

			case 2:
		    GUI_DispStringAt("��ʱ����1����������",0,48);
	    	GUI_DispStringAt("����/ֹͣ����",24,64);
	    	GUI_DispStringAt("����/ֹͣ��־:",0,88);
	    	if(RtuDataAddr->Task_Value[i].F67_Set_Para.type_1_Task_Enable==0x55)
	    		GUI_DispStringAt("����",112,88);
	    	else
	    		if(RtuDataAddr->Task_Value[i].F67_Set_Para.type_1_Task_Enable==0xAA)
	    			GUI_DispStringAt("ֹͣ",112,88);
	    		else
	    			GUI_DispStringAt("��Ч",112,88);
	    	break;

			case 3:
		    GUI_DispStringAt("��ʱ����2����������",0,48);
	    	GUI_DispStringAt("����/ֹͣ����",24,64);
	    	GUI_DispStringAt("����/ֹͣ��־:",0,88);
	    	if(RtuDataAddr->Task_Value[i].F67_Set_Para.type_1_Task_Enable==0x55)
	    		GUI_DispStringAt("����",112,88);
	    	else
	    		if(RtuDataAddr->Task_Value[i].F67_Set_Para.type_1_Task_Enable==0xAA)
	    			GUI_DispStringAt("ֹͣ",112,88);
	    		else
	    			GUI_DispStringAt("��Ч",112,88);
	    	break;
			default:break;
	    }
	    Status_Bar();
	    BottomBar();
	    Lcmfull();

	    keysele=KeySeleflag;
	    KeySeleflag =0;
	    if(keysele!=0)DelayTime=0;else DelayTime++;
	    if(DelayTime>=PageDelayTime)
	    {
	    	OldLevel=0;
	    	return 0;
	    }
	    switch(keysele)
	    {
		 case 1: if(CeLiangDian==0)CeLiangDian=7;else CeLiangDian=CeLiangDian-1;DelayTime=0;break;//��
		 case 2: CeLiangDian=(CeLiangDian+1)%(CeLiangPoint_Max);DelayTime=0;break;//��
		 case 3: if(j==0)j=0;else j=j-1;DelayTime=0;break;//��
		 case 4: j=(j+1)%4;DelayTime=0;break;//��
		 case 6: OldLevel=0;return 0;break;
		 default:break;
	    }
    }
	 */
	unsigned char keysele,TempBuf[16];
	INT8U tasknum=0;
	INT8U tasktype=0;
	INT8U count=0;
	unsigned int DelayTime,j;
    INT8U Min,Hour,Day,Month,zqdw,zqvalue,flag,start;

	DelayTime=0;
	j=0;
	flag=0;
	start=0;
	INT8U i;
	GUI_Clear();
	//GUI_DispStringAt("�������������ͣ�",16,40);
	GUI_DispStringAt("�������������:",16,60);
	//GUI_DispStringAt("00",56,60);
	GUI_DispStringAt("00",56,80);
	Status_Bar();
	keysele=KeySeleflag;
	KeySeleflag =0;
	if(keysele!=0)
		DelayTime=0;
	else
		DelayTime++;
	if(DelayTime>=PageDelayTime)
	{
	  	OldLevel=0;
		return 0;
	}

	memset(NowInput.buf,0,128);
	//sprintf(NowInput.buf,"%02d",tasktype);  //
	sprintf(&NowInput.buf,"%02d",tasknum);  //
	i=0;
	while(i<2)
	{
		NowInput.col[i]=80;
		NowInput.row[i]=56+i*8;//84
		NowInput.set[i]=1;
		i++;
	}
	NowInput.AllNum=3;
 	while(1)
	{
		Status_Bar();
		keysele=KeySeleflag;
		KeySeleflag =0;
		if(keysele!=0)
			DelayTime=0;
		else
			DelayTime++;
		if(DelayTime>=PageDelayTime)
        {
  			OldLevel=0;
			return 0;
		}

		memset(NowInput.buf,0,128);
		//sprintf(NowInput.buf,"%02d",tasktype);  //
		sprintf(&NowInput.buf,"%02d",tasknum);  //
		i=0;
		while(i<2)
		{
		     NowInput.col[i]=80;
		     NowInput.row[i]=56+i*8;//84
		     NowInput.set[i]=1;
		     i++;
		}
	   NowInput.AllNum=3;
       switch(keysele)
       {
          	case 5:    //
            {
          	 if(flag==0)
          	 {
                 if(ScreenInput()==1)
				  {
	            	   //tasktype=GetNum(&NowInput.buf[0],2,1);
				 	   tasknum=GetNum(&NowInput.buf,2,1);
					   SaveFKSet();
				  }
          	     flag=1;

          	 }

			 }
			 break;
			 case 6:  //
			 {
				   OldLevel=0;
				   return 0;
			 }
             break;
             default : break;
			// printf("\n\r flag=%d ",flag);
			 //printf("\n\r ");
       }
       if(flag==1)
       {
			   //RtuDataAddr->Task_Value[tasknum].F68_Set_Para.type_2_Task_Enable=0x55;
			   //RtuDataAddr->Task_Value[tasknum].F67_Set_Para.type_1_Task_Enable=0x00;
				 //printf("\n\r type_1_Task_Enable=%d ",RtuDataAddr->Task_Value[tasknum].F67_Set_Para.type_1_Task_Enable);
				 //printf("\n\r ");
			   switch(j)
			   {
				   case 0:
					   GUI_Clear();
					   if(RtuDataAddr->Task_Value[tasknum].F67_Set_Para.type_1_Task_Enable==0xAA)
					   {
						   GUI_DispStringAt("������δ����!!",16,80);
						   start=1;
					   }

					   else
						   if(RtuDataAddr->Task_Value[tasknum].F67_Set_Para.type_1_Task_Enable==0x55)
						   {
								 a_left=a_right=1;
								 a_up=a_down=0;
								 Min=(RtuDataAddr->Task_Value[tasknum].F65_Set_Para.Ji_Zhun_Shi_Jian[1]>>4)*10;
								 Min=Min+RtuDataAddr->Task_Value[tasknum].F65_Set_Para.Ji_Zhun_Shi_Jian[1]&0x0f;
								 Hour=(RtuDataAddr->Task_Value[tasknum].F65_Set_Para.Ji_Zhun_Shi_Jian[2]>>4)*10;
								 Hour=Hour+RtuDataAddr->Task_Value[tasknum].F65_Set_Para.Ji_Zhun_Shi_Jian[2]&0x0f;
								 Day=(RtuDataAddr->Task_Value[tasknum].F65_Set_Para.Ji_Zhun_Shi_Jian[3]>>4)*10;
								 Day=Day+RtuDataAddr->Task_Value[tasknum].F65_Set_Para.Ji_Zhun_Shi_Jian[3]&0x0f;
								 Month=((RtuDataAddr->Task_Value[tasknum].F65_Set_Para.Ji_Zhun_Shi_Jian[4]>>4)&1)*10;
								 Month=Month+RtuDataAddr->Task_Value[tasknum].F65_Set_Para.Ji_Zhun_Shi_Jian[4]&0x0f;
								 zqdw=RtuDataAddr->Task_Value[tasknum].F65_Set_Para.FaSong_ZhouQi>>6;
								 zqvalue=RtuDataAddr->Task_Value[tasknum].F65_Set_Para.FaSong_ZhouQi&0x3f;

							   GUI_DispStringAt("��������:",0,20);

							   //RtuDataAddr->Task_Value[tasknum].F66_Set_Para.Valid=1;

							   if(RtuDataAddr->Task_Value[tasknum].F65_Set_Para.Valid==1)
								   GUI_DispStringAt("1",80,20);
							   else
								   if(RtuDataAddr->Task_Value[tasknum].F66_Set_Para.Valid==1)
									   GUI_DispStringAt("2",80,20);
							   GUI_DispStringAt("���ڵ�λ:",0,40);
						    	if(zqdw=0)
						    		GUI_DispStringAt("��",72,40);
						    	else
						    		if(zqdw=1)
						    			GUI_DispStringAt("ʱ",72,40);
						    		else
						    			if(zqdw=2)
						    				GUI_DispStringAt("��",72,40);
						    			else
						    				GUI_DispStringAt("��",72,40);
						    	GUI_DispStringAt("��׼ʱ��:",0,56);
						    	GUI_DispDecShiftAt(16,72,2,0,Min);GUI_DispStringAt("��",32,72);
						    	GUI_DispDecShiftAt(48,72,2,0,Hour);GUI_DispStringAt("ʱ",64,72);
						    	GUI_DispDecShiftAt(80,72,2,0,Day);GUI_DispStringAt("��",96,72);
						    	GUI_DispDecShiftAt(112,72,2,0,Month);GUI_DispStringAt("��",128,72);

						    	GUI_DispStringAt("��������:",0,88);GUI_DispDecShiftAt(72,88,5,0,zqvalue);
						    	GUI_DispStringAt("���߳�ȡ���ݱ���:",0,104);GUI_DispDecShiftAt(136,104,2,0,RtuDataAddr->Task_Value[tasknum].F65_Set_Para.Qu_Xian_ChouQu_BeiLv);
						    	GUI_DispStringAt("���ݵ�Ԫ��ʶ����:",0,120);GUI_DispDecShiftAt(136,120,2,0,RtuDataAddr->Task_Value[tasknum].F65_Set_Para.ShuJv_DanYuan_Num);
						   }

					   if(RtuDataAddr->Task_Value[tasknum].F68_Set_Para.type_2_Task_Enable==0xAA)
					   {
						   GUI_DispStringAt("������δ����!!",16,80);
						   start=1;
					   }

					   else
						   if(RtuDataAddr->Task_Value[tasknum].F68_Set_Para.type_2_Task_Enable==0x55)
						   {
								 a_left=a_right=1;
								 a_up=a_down=0;
							     Min=(RtuDataAddr->Task_Value[tasknum].F66_Set_Para.Ji_Zhun_Shi_Jian[1]>>4)*10;
								 Min=Min+RtuDataAddr->Task_Value[tasknum].F66_Set_Para.Ji_Zhun_Shi_Jian[1]&0x0f;
								 Hour=(RtuDataAddr->Task_Value[tasknum].F66_Set_Para.Ji_Zhun_Shi_Jian[2]>>4)*10;
								 Hour=Hour+RtuDataAddr->Task_Value[tasknum].F66_Set_Para.Ji_Zhun_Shi_Jian[2]&0x0f;
								 Day=(RtuDataAddr->Task_Value[tasknum].F66_Set_Para.Ji_Zhun_Shi_Jian[3]>>4)*10;
								 Day=Day+RtuDataAddr->Task_Value[tasknum].F66_Set_Para.Ji_Zhun_Shi_Jian[3]&0x0f;
								 Month=((RtuDataAddr->Task_Value[tasknum].F66_Set_Para.Ji_Zhun_Shi_Jian[4]>>4)&1)*10;
								 Month=Month+RtuDataAddr->Task_Value[tasknum].F66_Set_Para.Ji_Zhun_Shi_Jian[4]&0x0f;
								 zqdw=RtuDataAddr->Task_Value[tasknum].F66_Set_Para.FaSong_ZhouQi>>6;
								 zqvalue=RtuDataAddr->Task_Value[tasknum].F66_Set_Para.FaSong_ZhouQi&0x3f;
							   GUI_DispStringAt("��������:",0,20);

							   //RtuDataAddr->Task_Value[tasknum].F66_Set_Para.Valid=1;
							   //RtuDataAddr->Task_Value[tasknum].F65_Set_Para.Valid=0;
							   if(RtuDataAddr->Task_Value[tasknum].F65_Set_Para.Valid==1)
								   GUI_DispStringAt("1",80,20);
							   else
								   if(RtuDataAddr->Task_Value[tasknum].F66_Set_Para.Valid==1)
									   GUI_DispStringAt("2",80,20);
							   GUI_DispStringAt("���ڵ�λ:",0,40);
						    	if(zqdw=0)
						    		GUI_DispStringAt("��",72,40);
						    	else
						    		if(zqdw=1)
						    			GUI_DispStringAt("ʱ",72,40);
						    		else
						    			if(zqdw=2)
						    				GUI_DispStringAt("��",72,40);
						    			else
						    				GUI_DispStringAt("��",72,40);
						    	GUI_DispStringAt("��׼ʱ��:",0,56);
						    	GUI_DispDecShiftAt(16,72,2,0,Min);GUI_DispStringAt("��",32,72);
						    	GUI_DispDecShiftAt(48,72,2,0,Hour);GUI_DispStringAt("ʱ",64,72);
						    	GUI_DispDecShiftAt(80,72,2,0,Day);GUI_DispStringAt("��",96,72);
						    	GUI_DispDecShiftAt(112,72,2,0,Month);GUI_DispStringAt("��",128,72);

						    	GUI_DispStringAt("��������:",0,88);GUI_DispDecShiftAt(72,88,5,0,zqvalue);
						    	GUI_DispStringAt("���߳�ȡ���ݱ���:",0,104);GUI_DispDecShiftAt(136,104,2,0,RtuDataAddr->Task_Value[tasknum].F66_Set_Para.Qu_Xian_ChouQu_BeiLv);
						    	GUI_DispStringAt("���ݵ�Ԫ��ʶ����:",0,120);GUI_DispDecShiftAt(136,120,2,0,RtuDataAddr->Task_Value[tasknum].F66_Set_Para.ShuJv_DanYuan_Num);
						   }


					   break;
				   case 1:
					   GUI_Clear();
					   //RtuDataAddr->Task_Value[tasknum].F66_Set_Para.ShuJv_DanYuan_Num=5;
					   if(RtuDataAddr->Task_Value[tasknum].F67_Set_Para.type_1_Task_Enable==0x55)
					   {
						   for(i=0;i<RtuDataAddr->Task_Value[tasknum].F65_Set_Para.ShuJv_DanYuan_Num;i++)
						   {
							   //GUI_DispDecShiftAt(0,(i*16),2,0,RtuDataAddr->Task_Value[tasknum].F65_Set_Para.DanYuan_BiaoShi[i][4]);
							   GUI_DispStringAt("���ݵ�Ԫ��ʶ",0,((i+1)*16));
							   GUI_DispDecShiftAt(96,((i+1)*16),1,0,i+1);
							   GUI_DispStringAt(":",104,((i+1)*16));
							   memset(TempBuf,0,16);
								sprintf(TempBuf,"%x%x%x%x",
										RtuDataAddr->Task_Value[tasknum].F65_Set_Para.DanYuan_BiaoShi[i][0],
										RtuDataAddr->Task_Value[tasknum].F65_Set_Para.DanYuan_BiaoShi[i][1],
										RtuDataAddr->Task_Value[tasknum].F65_Set_Para.DanYuan_BiaoShi[i][2],
										RtuDataAddr->Task_Value[tasknum].F65_Set_Para.DanYuan_BiaoShi[i][3]
										);  //����ת����Ϊ�ַ���
								GUI_DispStringAt(TempBuf,120,((i+1)*16));
						   }

					   }
					   if(RtuDataAddr->Task_Value[tasknum].F68_Set_Para.type_2_Task_Enable==0x55)
					   {
						   for(i=0;i<RtuDataAddr->Task_Value[tasknum].F66_Set_Para.ShuJv_DanYuan_Num;i++)
						   {
							   //GUI_DispDecShiftAt(0,(i*16),2,0,RtuDataAddr->Task_Value[tasknum].F65_Set_Para.DanYuan_BiaoShi[i][4]);
							   GUI_DispStringAt("���ݵ�Ԫ��ʶ",0,((i+1)*16));
							   GUI_DispDecShiftAt(96,((i+1)*16),1,0,i+1);
							   GUI_DispStringAt(":",104,((i+1)*16));
							   memset(TempBuf,0,16);
								sprintf(TempBuf,"%x%x%x%x",
										RtuDataAddr->Task_Value[tasknum].F66_Set_Para.DanYuan_BiaoShi[i][0],
										RtuDataAddr->Task_Value[tasknum].F66_Set_Para.DanYuan_BiaoShi[i][1],
										RtuDataAddr->Task_Value[tasknum].F66_Set_Para.DanYuan_BiaoShi[i][2],
										RtuDataAddr->Task_Value[tasknum].F66_Set_Para.DanYuan_BiaoShi[i][3]
										);  //����ת����Ϊ�ַ���
								GUI_DispStringAt(TempBuf,120,((i+1)*16));
						   }


					   }
					   break;
					default:break;
			   }
			    Status_Bar();
			    BottomBar();
			    Lcmfull();
    		    /*keysele=KeySeleflag;
			    KeySeleflag =0;
			    if(keysele!=0)DelayTime=0;else DelayTime++;
			    if(DelayTime>=PageDelayTime)
			    {
			    	OldLevel=0;
			    	return 0;
			    }*/
			    switch(keysele)
			    {
			     case 1: DelayTime=0;break;//��
				 case 2: DelayTime=0;break;//��
				 case 3:if(start==0) if(j==0)j=1;else j=j-1;DelayTime=0;break;//��
				 case 4: if(start==0)j=(j+1)%2;DelayTime=0;break;//��
				 case 6: OldLevel=0;return 0;break;
				 default:break;
			    }
     }
       Lcmfull();
	}
}

/******************************************************************************************************************
* �������ƣ�ChaoBiaoRiSet()
* ��    �ܣ��ն˳���������
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/

int ChaoBiaoRiSet(INT8U SeleMenu)
{
/*	unsigned char ErcI=0;
	unsigned char ErcJ=0;
	unsigned char col,row,m,count=0;
	unsigned char keysele,CeLiangDian,j,i;
	unsigned int DelayTime;

	DelayTime=0;
	CeLiangDian=0;

	GUI_Clear();
	GUI_DispStringAt("��������:",0,20);//1���ֽ�
	GUI_DispStringAt("����ʱ��:",0,120);//1���ֽ�
	GUI_DispStringAt("ʱ",100,120);//1���ֽ�
	GUI_DispStringAt("��",136,120);//1���ֽ�
	GUI_DispHexAt(RtuDataAddr->FkInput_Value.F7_Set_Para.ZhongDuan_ChaoBiao_Time[1],80,120,2);

	GUI_DispHexAt(RtuDataAddr->FkInput_Value.F7_Set_Para.ZhongDuan_ChaoBiao_Time[0],118,120,2);

	for(ErcI=0;ErcI<8;ErcI++)
		for(ErcJ=0;ErcJ<4;ErcJ++)
			if(((ErcI+1)+8*ErcJ)<32)
				GUI_DispDecAt(((ErcI+1)+8*ErcJ),20*ErcI,40+20*ErcJ,2);
	while(1)
	{
		for(j=0;j<4;j++)
		{
			  for(i=1;i<9;i++)
			  {
                m=0;
				  if((((RtuDataAddr->FkInput_Value.F7_Set_Para.ZhongDuan_ChaoBiao_Date[j])>>(i-1))&0x01))
				  {
					  m=(i+j*8);
					  col=(m-1)/8;
					  row=(m-1)%8;
					  GUI_SetTextMode(GUI_TM_REV);
					  GUI_DispDecAt(m,20*row,40+20*col,2);
				  }
			  }
		}

	keysele=KeySeleflag;
	KeySeleflag =0;
	if(keysele!=0)DelayTime=0;else DelayTime++;
		   if(DelayTime>=PageDelayTime)
		   {
				OldLevel=0;
				return 0;
		   }

		switch(keysele)
		              {

		  			   case 6:  //ȡ����
		  			    {
		  			  	    GUI_SetTextMode(GUI_TM_NORMAL);
		  			    	OldLevel=0;
		  				     return 0;
		  			     }
		                  break;
		                  default : break;
		              }
		Lcmfull();

	}*/
}

/******************************************************************************************************************
* �������ƣ�
* ��    �ܣ���ʱ����
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void delayms(unsigned int ms)
// ��ʱ�ӳ���
{
    unsigned int i;
    while(ms--)
    {
        for(i = 0; i < 120; i++);
    }
}

/******************************************************************************************************************
* �������ƣ�thread1
* ��    �ܣ��߳�ҳ��
* ��ڲ�������
* ���ڲ�������/
/*******************************************************************************************************************/
void *thread1()//��ȡ��ֵ
{
    //printf ("thread1 : I'm LCM\n");
    LcdMainTask();
    pthread_exit(NULL);
}
/******************************************************************************************************************
* �������ƣ�thread2()
* ��    �ܣ��̰߳���
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void *thread2()
{
    unsigned int KeySta,KeyStabuf,KeyStabuf1;
    unsigned int Beiguang;
    unsigned char Flag_NOkey;
    //printf("thread2 : I'm KEY\n");
    LunXianCount=0;//���Լ�����ʼ��
    Beiguang=0;//�����ʼ��

    while(1)
    {
    	delay(10);

    	/*if(RtuDataAddr->batflag == 1)
    	{
    		LCDpoweroff();
    		CleardeadCount();

    		//printf("\n\r ******close lcd******");
    	}
		if (RtuDataAddr->batflag == 0)
        {
			//printf("\n\r ******init lcd b******");
			LCDinit();
			CleardeadCount();
			//printf("\n\r ******init lcd e******");
			//printf(".");
        }
		while(RtuDataAddr->batflag!=1)*///����
		LCDinit();//�¼���
		CleardeadCount();//�¼���
		while(1)//�¼���
		{

        delay(10);
        CleardeadCount();
   	    KeyStabuf = in32(port2+0x3c);
   	   // printf("KeyStabuf=%x\r\n",KeyStabuf);
   	    KeyStabuf = ((KeyStabuf&0x3f00000)>> 20);
   	    Beiguang++;
   	    if(Beiguang>BeiguangNum)//��Լ60���رձ���

   	    	//out32(BaseLcmIo + 0x34,AT91C_PIO_PA27);//����
   	     out32(port3 + 0x34,AT91C_PIO_PC4);//�¼���
        if(KeyStabuf!=0x3f)
	    {
	    	delayms(50);
    	    KeyStabuf1 = in32(port2+0x3c);
            KeyStabuf1 = ((KeyStabuf1&0x3f00000)>> 20)&0x3f;
            //printf("KeyStabuf1=%x\r\n",KeyStabuf1);
            if(KeyStabuf1==KeyStabuf)
            {
            	Flag_NOkey=1;
                while(Flag_NOkey)
	            {
	             	//printf("KeyStabuf=%x\r\n",in32(BaseKeyIo+0x3c));
	             	if(((in32(port2+0x3c))&0x3f00000)==0x3f00000)
	             	   Flag_NOkey=0;
	             	else Flag_NOkey=1;
	            }
              delayms(10);
              KeySta= KeyStabuf1;
              //out32(BaseLcmIo + 0x30,AT91C_PIO_PA27);//�м����µ������Ⲣ�Ұѱ����������//����
              out32(port3 + 0x30,AT91C_PIO_PC4);//�¼���
              Beiguang=0;
            }
	    }
	    switch(KeySta)
		{
	   		case 0x2f: KeySeleflag=1;break;//��
	   		case 0x1f: KeySeleflag=2;break;//��
	   		case 0x37: KeySeleflag=3;break;//��
	   		case 0x3e: KeySeleflag=4;break;//��
	   		case 0x3d: KeySeleflag=5;break;//ȷ��
	   		case 0x3b: KeySeleflag=6;break;//ȡ��
	   		default:break;
	    }
        KeySta=0x3f;
      }
  }
     pthread_exit(NULL);
}
/******************************************************************************************************************
* �������ƣ�thread_create()
* ��    �ܣ����������߳� һ���߳�Ϊ����,��һ��Ϊ��ʾ
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void thread_create(void)
{
        int temp;
        memset(&thread, 0, sizeof(thread));          //comment1
        /*�����߳�*/
        if((temp = pthread_create(&thread[0], NULL, thread1, NULL)) != 0)       //comment2
                printf("Process 1 create fail!\n");
 //       else
 //               printf("Process 1 is created\n");
        if((temp = pthread_create(&thread[1], NULL, thread2, NULL)) != 0)  //comment3
                printf("Process 2 create fail!");
 //       else
 //               printf("Process 2 is created\n");
}
/******************************************************************************************************************
* �������ƣ�thread_wait()
* ��    �ܣ�
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void thread_wait(void)
{
        /*�ȴ��߳̽���*/
        if(thread[0] !=0) {                   //comment4
                pthread_join(thread[0],NULL);
                printf("Process 1 end !\n");
        }
        if(thread[1] !=0) {                //comment5
                pthread_join(thread[1],NULL);
                printf("Process 2 end !\n");
        }
}

/******************************************************************************************************************
* �������ƣ�PARSE_CMD()
* ��    �ܣ�������
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
INT8U   PARSE_CMD(int argc, char * argv[])
{
	INT8U  proc_name[32] = "";

	//printf("cmdline=%d,%s %s\r\n", argc, argv[0], argv[1]);
	if(argc < 2)return (FALSE);
	PORT_ID = atoi(argv[1]);
	sprintf(proc_name, "%s %d", argv[0], PORT_ID);
	if((attach = name_attach(NULL, proc_name,0))  == NULL)
	{
		fprintf(stderr, "ERR:'%s' runed,cann't regist: %s\r\n", proc_name, strerror(errno));
		return (FALSE);
	}
	return (TRUE);
}
/******************************************************************************************************************
* �������ƣ�QuitProcess()
* ��    �ܣ�
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
void QuitProcess(int signo)
{
	delay(100);
	RtuDataAddr->stPortPara[PORT_ID].PID=0;
   	name_detach(attach, 0);
   	fprintf(stderr,"LCM quit");
	exit(0);
}

/******************************************************************************************************************
* �������ƣ�main()
* ��    �ܣ�������
* ��ڲ�������
* ���ڲ�������
/*******************************************************************************************************************/
int main(int argc, char *argv[])
{
	////int     c = 0;
	////char   *node = NULL;
	////int	    iterations = 0;
	uintptr_t point;
	int test;
	////int fd;
    struct sigaction sa1;

    FILE *fp;
    unsigned char filename[128];
    int rnum;
    markver();
  	if(OpenMem())return EXIT_FAILURE;

 	sa1.sa_handler = QuitProcess;
	sigemptyset(&sa1.sa_mask);
	sa1.sa_flags = 0;
	sigaction(SIGTERM, &sa1,NULL);
	sigaction(SIGSYS, &sa1,NULL);
	sigaction(SIGPWR, &sa1,NULL);
	sigaction(SIGKILL, &sa1,NULL);
	sigaction(SIGQUIT, &sa1,NULL);
	sigaction(SIGILL, &sa1,NULL);
	sigaction(SIGINT, &sa1,NULL);
	sigaction(SIGHUP, &sa1,NULL);
	sigaction(SIGABRT, &sa1,NULL);
	sigaction(SIGBUS, &sa1,NULL);
	//��ȡattach

 	if(!PARSE_CMD(argc, argv))
	{
		return EXIT_FAILURE;
	}

 	a_up = a_down = a_left = a_right = 0;
	point = mmap_device_io( 0x20,0xfffffc10 );
	test=in32(point+8);
	test=(test&0xfff0)|0x0c;
	out32(point,test);

 	//��ȡ�����id��
 	RtuDataAddr->stPortPara[PORT_ID].PID=getpid();
 	//LCM�������õ���IO��ʼ�����������ߡ�Һ����ʼ������ȡ���ֿ⡢��������
	  fp = NULL;
 	  sprintf(filename,"/nand/save/password.sav");
 	  fp=fopen(filename,"rb+");
 	  rnum=0;
 	  if(fp==NULL)
 	 		fp = fopen(filename,"wb+");

 	  rnum= fread(&PassWord,2,1,fp);
 	  if(rnum<1)
 	  {
 	 		PassWord=OLDPASSWORD;
 	 		fwrite(&PassWord,2,1,fp);
 	  }
 	  fclose(fp);
	 	IOInit();
	    delay(5);
	    BOARD_ConfigureSMCLcd();
	    delay(5);
	    LCDinit();
	    delay(5);
	    ReadHzkBuff();
	    LcmClear();
	    //out32(BaseLcmIo + 0x30,AT91C_PIO_PA27);//����
	    out32( port3+ 0x30,AT91C_PIO_PC4);//�¼���

     //���������߳� ʵ�ֻ�����ʾ�밴��
        pthread_mutex_init(&mut,NULL);
        //printf("I am Main Function,I am Creating Processes ,hehe\n");
        thread_create();
        //printf("I am Main Function,I am Waiting Processes's ending ,hehe\n");
        thread_wait();

    return EXIT_SUCCESS;
}

