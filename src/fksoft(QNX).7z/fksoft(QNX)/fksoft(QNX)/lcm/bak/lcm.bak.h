#ifndef LCM
#define LCM


#include "TypeDef.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "stdarg.h"
#include <stdint.h>
#include <sys/mman.h>
#include <hw/inout.h>
#include "font8x16.h"
#include "fcntl.h"
#include "unistd.h"
#include <math.h>
#include <sys/time.h>
#include <pthread.h>
#define LCD_1
#define MAX 10




#define AT91C_SMC_READMODE    (0x1 <<  0) // (SMC) Read Mode
#define AT91C_SMC_WRITEMODE   (0x1 <<  1) // (SMC) Write Mode
#define AT91C_SMC_DBW_WIDTH_EIGTH_BITS     (0x0 << 12) // (SMC) 8 bits.


#define LCM_X    160
#define LCM_Y    160

#define AT91C_PIO_PB20        (1 <<  20) // Pin Controlled by PA22  ;;K1=��
#define AT91C_PIO_PB21        (1 <<  21) // Pin Controlled by PA25  ;;K2=ȡ��
#define AT91C_PIO_PB22        (1 <<  22) // Pin Controlled by PA26  ;;K3=��
#define AT91C_PIO_PB23        (1 <<  23) // Pin Controlled by PA27  ;;K4=��
#define AT91C_PIO_PB24        (1 <<  24) // Pin Controlled by PA28  ;;K5=ȷ��
#define AT91C_PIO_PB25        (1 <<  25) // Pin Controlled by PA29  ;;K6=��

#define AT91C_PIO_PA26        (1 <<  26) // Pin Controlled by PA26  Lcd rst
//#define AT91C_PIO_PA27        (1 <<  27) // Pin Controlled by PA27  Lcd����

#define AT91C_PIO_PC4		  (1 << 4)//LCD����//�¼���
#define AT91C_PIO_PC6		  (1 << 6)//LCD_RST//�¼���
#define AT91C_PIO_PC9		  (1 << 9)//LCD_CS//�¼���
#define AT91C_PIO_PC10		  (1 << 10)//LCD_HOT//�¼���


void LcdSendCmd(unsigned char cmd);
void LcdSendData(unsigned char data);
void GUI_Point(unsigned int Px, unsigned char Py, unsigned char attr );
void  GUI_DrawVLine(unsigned int x0, unsigned char y0, unsigned char y1);
void  GUI_DrawHLine(unsigned int x0, unsigned char y0, unsigned int x1);
void ReadHzkBuff();
void GUI_SetTextMode(unsigned char flag);
void GUI_DispStringAt( unsigned char *format,unsigned int y, unsigned int x);
void GUI_DispDecAt(signed long int v,unsigned char x,unsigned char y,unsigned char len);
void GUI_DispHexAt(signed long int v,unsigned char x,unsigned char y,unsigned char len);
void GUI_DispDecShiftAt(unsigned char y, unsigned char x,unsigned char Num1,unsigned char Num2,signed long int Num3);
void GUI_DispCharAt(unsigned char c,unsigned char x,unsigned char y);
void LcmClear( void );
void Lcmfull( void );
void FillDataFromBuffer(void);
void GUI_Clear(void);
void LCDpoweroff(void);
void LCDinit(void);
void IOInit(void);
void BOARD_ConfigureSMCLcd(void);
#endif



