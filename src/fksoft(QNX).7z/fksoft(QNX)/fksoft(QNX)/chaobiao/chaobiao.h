#ifndef CHAOBIAO_H_
#define CHAOBIAO_H_

#define AT91C_PIO_PB19    (1 <<  19)
#define MY_PULSE_CODE   _PULSE_CODE_MINAVAIL
#define ATTACH_POINT "cbkernel"
#define SystemDbg if(RtuDataAddr->SYSTENDBON)fprintf

typedef union
{
	struct _pulse pulse;
} my_message_t;
INT8U PORT_ID;
INT8U chid;
RTimeData *RtuDataAddr;//�ڴ湲��������ָ��
name_attach_t *attach;
int param;
pthread_t thread_dog;
void *dogpro();
void WaitQuit();
void ReadSysCfg();
int setupTimer();
void QuitProcess(int signo);
#endif /* CHAOBIAO_H_ */
