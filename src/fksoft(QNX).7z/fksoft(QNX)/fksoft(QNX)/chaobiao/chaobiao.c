/*
 * �汾��Ϣע�ͣ�
 *1.3  Һ����ʾ���Ӳ��������ã����ʾ����ʾ�����ӵ�ѹ�͵�����ʾ��
	   ( Ĭ�ϳ�ʼ��������1Ϊ�������������������ϱ���Ϊ�жϻ�׼ʱ�䡣)���
 *1.4  ����/nand/bin/�µ�*.log�ļ���һ������Сʱ���������ϱ����޸�,����Ӳ����λ��
 *1.4  2011-10-12 Ϊ�����ά��վ�вⲻ�����������в������ô��Ĳ����в�����ж�valid�Ƿ�Ϊ1�����Ρ�
 *1.4  2011-10-13 �ϵ�������ϵ�Һ������ʾ����thread2��������lcmpower������
 *1.5   2011.11.4 ������������l>=73)&&(l<=108 �ж�����������Сʱ���񣬷������㡣���� SelfheartCount �����ж�
 *      ���� RtuDataAddr->autoReport �жϴ洢�ɹ���1 ��Ϊ �������1    ��F29����
 *1.6   2011.12.21 F131�����й��в�ֵ��ʵ�����100����reboot�������ϱ�ͣ�ϵ��¼���
 *1.7   2012.4.6 ������Щ���645-1997��Լ���ܳ���ѹ�͵������ݿ飬ͬʱ������ʤ������ܳ�����ͷ����޹����ݿ�����⡣
 *1.8   �޸�lever2.fun.c��Read_Day_ClHisDianneng�������жϳ����������վ�ٲ���ݲ��Ȳ���ȡ�����⽫�������ݴ�������
 *1.8   �޸�fkdatasave.c���մ洢���ж���������1.8���԰汾��Ϊ�˽����վ�ٲ����ʾֵͻȻ�½��ָֻ��������������⣩��
 *1.9	�޸�͸�� DataTrans()���� INT8U k     int k      �˿�2 ��Ӧ ���ؿ�1   �˿�3���ؿ�2
 */
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <ctype.h>
#include <time.h>
#include <signal.h>
#include <sys/sched.h>
#include <semaphore.h>
#include <process.h>
#include <sys/neutrino.h>
#include <sys/netmgr.h>
#include <sys/dispatch.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <hw/inout.h>
#include <fkbase/memdef.h>
#include <fkbase/fkbasefun.h>
#include "chaobiao.h"
const char verstr[]={"VER-STRING-FLG=001.002.217.004"__DATE__" "__TIME__};
int dog_init_ok=0;
void markver()//��Ŀ������б�ʶ�����汾��Ϣ
{
	printf("\n\r%s", verstr);
}
void dog()
{
	out32(port2+0x34,AT91C_PIO_PB19);
	delay(10);
	out32(port2+0x30,AT91C_PIO_PB19);
}
void CreatThread()
{
    param = 1;
    pthread_create(&thread_dog, NULL, dogpro, &param);	    /*�����߳�*/
}
void ExitThread()
{
	param = 0;												/*�߳��˳�*/
}
void *dogpro()
{
	int* par;
	par = &param;
	while(*par)
	{
		dog();
		delay(1000);
	}
	pthread_exit(0);
	return NULL;
}
void init_dog()
{
	if(dog_init_ok==0)
	{
		out32(port2,AT91C_PIO_PB19);
		out32(port2+0x10,AT91C_PIO_PB19);
		resetptr=mmap_device_io(0x4, 0xfffffd08);
		out32(resetptr,0xA5000F01);
		dog_init_ok=1;
	}
}
int main(int argc, char *argv[])
{
	int rcvid;
	pid_t pid;//�ȼ���_INT32
	struct sigaction sa1;
	my_message_t msg;//������.�ṹ��.
	unsigned char t1[20], t2[20], t3[20], t4[20];
	int NowSecCount = 0;
	int i, PortNo = 0;
	markver();
	if (CreateMem())
		return EXIT_FAILURE;
	memset(RtuDataAddr, 0, sizeof(RTimeData));
	RtuDataAddr->mem_len = sizeof(RTimeData);
	sem_init(&RtuDataAddr->UseFMFileFlg, 1, 1);//����д������Ϣ��������ͻ
	sem_init(&RtuDataAddr->UseCycleFlg, 1, 1);//����д������Ϣ��������ͻ
	sem_init(&RtuDataAddr->UseFileFlg, 1, 1);//�����ļ�������ͻ
	sem_init(&RtuDataAddr->Gprs_Data_Flag, 1, 1);//��������ģ�黺������ͻ

	chid = setupTimer();
	if ((attach = name_attach(NULL, ATTACH_POINT, 0)) == NULL)
	{
		return EXIT_FAILURE;
	}
	(void) signal(SIGCHLD, WaitQuit);
	sa1.sa_handler = QuitProcess;
	sigemptyset(&sa1.sa_mask);
	sa1.sa_flags = 0;
	sigaction(SIGTERM, &sa1, NULL);
	sigaction(SIGSYS, &sa1, NULL);
	sigaction(SIGPWR, &sa1, NULL);
	sigaction(SIGKILL, &sa1, NULL);
	sigaction(SIGQUIT, &sa1, NULL);
	sigaction(SIGILL, &sa1, NULL);
	sigaction(SIGINT, &sa1, NULL);
	sigaction(SIGHUP, &sa1, NULL);
	sigaction(SIGABRT, &sa1, NULL);
	sigaction(SIGBUS, &sa1, NULL);
	SystemDbg(stderr, "step1");
	sem_wait(&RtuDataAddr->UseFileFlg);
	SystemDbg(stderr, "step2");
	ReadSysCfg();
	sem_post(&RtuDataAddr->UseFileFlg);
	SystemDbg(stderr, "\r\n %s", RtuDataAddr->uc_System_Describ);
	SystemDbg(stderr, "\r\n %s", RtuDataAddr->ucsysVER);
	SystemDbg(stderr, "\r\n %d-%d-%d %d-%d-%d ", RtuDataAddr->Year,
				RtuDataAddr->Month, RtuDataAddr->Day, RtuDataAddr->Hour,
				RtuDataAddr->Minutes, RtuDataAddr->Second);
	SystemDbg(stderr, "\r\n %s", RtuDataAddr->ucSysTimeFrom);
	SystemDbg(stderr, "\r\n %d", RtuDataAddr->RtuNo);
	RtuDataAddr->leddisp =0x0f;//gai
	RtuDataAddr->WIRELESSDBON = 0;
	RtuDataAddr->TASK130DBON = 0;
	RtuDataAddr->DATASAVEDBON = 0;
	RtuDataAddr->DLT645DBON = 0;
	RtuDataAddr->DATACALCDBON = 0;
	RtuDataAddr->DBON = 0;
	RtuDataAddr->CONTROLDBON = 0;
	RtuDataAddr->IFRDBON = 0;
	RtuDataAddr->XIEBOPRT=0;
	RtuDataAddr->SYSTENDBON = 0;
	RtuDataAddr->Dev_Init_OK = 0;
	RtuDataAddr->Fm_Init_OK = 0;
	RtuDataAddr->FkJcXiu = 0;
	RtuDataAddr->NETComUsed = 0;
	RtuDataAddr->Fk130RestartNum = 0 ;
	for (i = 0; i < PORTNO_MAX; i++)
	{
		SystemDbg(stderr, "\r\n %d %s", i,
					RtuDataAddr->stPortPara[i].ucProgName);
	}
	if (!PortOpened) {
		OpenGPIO();  //quxiaogpio
	}  //quxiaogpio
	//SetSpiLed(All_LunCi);//gai
	fprintf(stderr,"\n\rSoftware Version is  %s\n\r", RtuDataAddr->ucsysVER);
	for (;;)
	{
		//dog();
		rcvid = MsgReceive(chid, &msg, sizeof(msg), NULL);
		if (rcvid == 0)
		{ /* we got a pulse */
			if (msg.pulse.code == MY_PULSE_CODE)
			{
				SetSpiLed(RUN_LED);
				NowSecCount++;
				if (NowSecCount >= 300)
				{
					ReadSysCfg();
					NowSecCount = 0;
				}
				for (i = 0; i < PORTNO_MAX; i++)
				{
					SystemDbg(stderr, "%d ",
								RtuDataAddr->stPortPara[i].uiDeadCount);
					if (RtuDataAddr->stPortPara[i].ePortRunStat == NOWRUN)
					{

						RtuDataAddr->stPortPara[i].uiDeadCount++;

						if (RtuDataAddr->stPortPara[i].uiDeadCount
								> PROG_DEAD_COUNT_MAX)
						{
							pid = name_open((char *)RtuDataAddr->stPortPara[i].ucProgOldName,0);
							if (pid != -1)
							{//�ж��Ƿ�Ϊ�����̣�
								kill(RtuDataAddr->stPortPara[i].PID, SIGTERM);
								SystemDbg(
											stderr,
											"\nBE KILLED: process '%s', REASON:deadcount up to PROG_DEAD_COUNT_MAX! \n",
											RtuDataAddr->stPortPara[i].ucProgOldName);
								delay(100);
							}
							RtuDataAddr->stPortPara[i].ePortRunStat = NEEDSTART;
							RtuDataAddr->stPortPara[i].uiDeadCount = 0;
							RtuDataAddr->ProgStat[i] = 2;
						}
					}
				}
			}
		}
		//init_dog();
		for (PortNo = 0; PortNo < PORTNO_MAX; PortNo++)
		{
			memset(t1, 0, sizeof(t1));
			memset(t2, 0, sizeof(t2));
			memset(t3, 0, sizeof(t3));
			memset(t4, 0, sizeof(t3));
			if (RtuDataAddr->stPortPara[PortNo].ePortRunStat == NEEDKILL)
			{
				pid = name_open((char *)RtuDataAddr->stPortPara[PortNo].ucProgOldName,0);
				if (pid != -1)
				{
					kill(RtuDataAddr->stPortPara[PortNo].PID, SIGTERM);
					SystemDbg(
								stderr,
								"\nBE KILLED: process '%s', REASON: ePortRunStat == NEEDKILL.\n",
								RtuDataAddr->stPortPara[i].ucProgOldName);
					RtuDataAddr->stPortPara[PortNo].ePortRunStat = NONE;
				}
			}
			//dog();
			if (RtuDataAddr->stPortPara[PortNo].ePortRunStat == NEEDCHECK)
			{
				sprintf((char *)RtuDataAddr->stPortPara[PortNo].ucProgRunName, "%s %s",
						RtuDataAddr->stPortPara[PortNo].ucProgName, utoa(PortNo, (char *)t4, 10));
				if (strcmp((char *)RtuDataAddr->stPortPara[PortNo].ucProgRunName,(char *)RtuDataAddr->stPortPara[PortNo].ucProgOldName))
				{
					pid = name_open((char *)RtuDataAddr->stPortPara[PortNo].ucProgOldName, 0);
					if (pid != -1)
					{
						kill(RtuDataAddr->stPortPara[PortNo].PID, SIGTERM);
						SystemDbg(
									stderr,
									"\nBE KILLED: process '%s', REASON: ePortRunStat == NEEDCHECK.\n",
									RtuDataAddr->stPortPara[PortNo].ucProgOldName);
						RtuDataAddr->stPortPara[PortNo].ePortRunStat = NONE;
					}
					SystemDbg(stderr, "\nnow into fork  %d", PortNo);
					pid = fork();
					if (pid == -1)
					{
						perror("\r\nfork failure");
						PortNo = (PortNo + 1) % PORTNO_MAX;
						continue;
					}
					if (pid == 0)
					{
						execlp((char *)RtuDataAddr->stPortPara[PortNo].ucProgName,
								(char *)RtuDataAddr->stPortPara[PortNo].ucProgName,
								utoa(PortNo, (char *)t4, 10), NULL);
						SystemDbg(stderr, "\nno program quit");
						delay(80);
						return EXIT_FAILURE;
					}
					else
					{
						RtuDataAddr->stPortPara[PortNo].ePortRunStat = NOWRUN;
						strcpy((char *)RtuDataAddr->stPortPara[PortNo].ucProgOldName,(char *)RtuDataAddr->stPortPara[PortNo].ucProgRunName);
						delay(80);
					}
				}
				else
				{
					RtuDataAddr->stPortPara[PortNo].ePortRunStat = NOWRUN;
				}
			}
			dog();
			if (RtuDataAddr->stPortPara[PortNo].ePortRunStat == NEEDSTART)
			{
				RtuDataAddr->ProgStat[PortNo] = 0;
				sprintf((char *)RtuDataAddr->stPortPara[PortNo].ucProgRunName, "%s %s",
						RtuDataAddr->stPortPara[PortNo].ucProgName, utoa(PortNo, (char *)t4, 10));
				pid = name_open((char *)RtuDataAddr->stPortPara[PortNo].ucProgOldName,0);

				if (pid != -1)
				{
					if (RtuDataAddr->stPortPara[PortNo].PID != 0)
						kill(RtuDataAddr->stPortPara[PortNo].PID, SIGTERM);
					SystemDbg(stderr, "NEEDRESTART");
					RtuDataAddr->stPortPara[PortNo].ePortRunStat = NONE;
				}
				SystemDbg(stderr, "\nnow into fork %d %s %s", PortNo,
							RtuDataAddr->stPortPara[PortNo].ucProgName, utoa(PortNo, (char *)t4, 10));
				pid = fork();
				if (pid == -1)
				{
					perror("\r\nfork failure");
					continue;
				}
				if (pid == 0)
				{
					execlp((char *)RtuDataAddr->stPortPara[PortNo].ucProgName,
							(char *)RtuDataAddr->stPortPara[PortNo].ucProgName, utoa(PortNo, (char *)t4, 10), NULL);
					SystemDbg(stderr, "\nno program quit");
					return EXIT_FAILURE;
				}
				else
				{
					RtuDataAddr->stPortPara[PortNo].ePortRunStat = NOWRUN;
					strcpy((char *)RtuDataAddr->stPortPara[PortNo].ucProgOldName,(char *)RtuDataAddr->stPortPara[PortNo].ucProgRunName);
					delay(10);
				}
			}
			//dog();
		}
		init_dog();
	}
	for (i = 0; i < PORTNO_MAX; i++)
	{
		if (RtuDataAddr->stPortPara[i].ePortRunStat == NOWRUN)
		{
			pid = name_open((char *)RtuDataAddr->stPortPara[i].ucProgOldName, 0);
			if (pid != -1)
			{
				if (RtuDataAddr->stPortPara[PortNo].PID != 0)
					kill(RtuDataAddr->stPortPara[i].PID, SIGTERM);
				SystemDbg(stderr, "\nprocess:pid is killed\n");
			}
		}
	}
	timer_delete(chid);
	sem_destroy(&RtuDataAddr->UseCycleFlg);//����д�����������Ϣ��������ͻ
	sem_destroy(&RtuDataAddr->UseFileFlg);//����д�����������Ϣ��������ͻ
	sem_destroy(&RtuDataAddr->UseFMFileFlg);//����д�����������Ϣ��������ͻ
	sem_destroy(&RtuDataAddr->Gprs_Data_Flag);//����д�����������Ϣ��������ͻ
	shm_unlink("plc_mem");
	name_detach(attach, 0);
	return EXIT_SUCCESS;
}

int setupTimer()
{
	struct sigevent event;
	struct itimerspec itime;
	timer_t timer_id;
	int chid;
	chid = ChannelCreate(0);

	event.sigev_notify = SIGEV_PULSE;
	event.sigev_coid = ConnectAttach(ND_LOCAL_NODE, 0, chid, _NTO_SIDE_CHANNEL,
			0);
	event.sigev_priority = getprio(0);
	event.sigev_code = MY_PULSE_CODE;
	timer_create(CLOCK_REALTIME, &event, &timer_id);

	itime.it_value.tv_sec = 1;
	/* 500 million nsecs = .5 secs */
	itime.it_value.tv_nsec = 0;//500000000;
	itime.it_interval.tv_sec = 1;
	/* 500 million nsecs = .5 secs */
	itime.it_interval.tv_nsec = 0;//500000000;
	timer_settime(timer_id, 0, &itime, NULL);
	return chid;
}
void WaitQuit()
{
	int *s, i;
	pid_t pid;
	s = &i;
	i = 0;
	pid = wait(s);
	SystemDbg(stderr, "WaitquitPid=%d\n", pid);
	for (i = 0; i < PORTNO_MAX; i++)
	{
		if (RtuDataAddr->stPortPara[i].PID == pid)
		{
			RtuDataAddr->stPortPara[i].PID = 0;
			RtuDataAddr->stPortPara[i].uiDeadCount = 0;
			RtuDataAddr->stPortPara[i].ePortRunStat = NEEDSTART;
		}
	}
}
///////////////////////////////////////////
//�������ܣ������˳�ǰ����
//���ã�ϵͳ����
//������sa����
//�˳���
///////////////////////////////////////////
void QuitProcess(int signo)
{
	unsigned int i;
	int pid;
	SystemDbg(stderr, "\nprocess:pid is killed\n");
	ExitThread();
	for (i = 0; i < PORTNO_MAX; i++)
	{
		if (RtuDataAddr->stPortPara[i].ePortRunStat == NOWRUN)
		{
			pid = name_open((char *)RtuDataAddr->stPortPara[i].ucProgOldName, 0);
			if (pid != -1)
			{
				if (RtuDataAddr->stPortPara[i].PID != 0)
					kill(RtuDataAddr->stPortPara[i].PID, SIGTERM);
				SystemDbg(stderr, "\nprocess:pid is killed\n");
			}
		}
	}
	delay(100);
	timer_delete(chid);
	sem_destroy(&RtuDataAddr->UseCycleFlg);//����д�����������Ϣ��������ͻ
	sem_destroy(&RtuDataAddr->UseFileFlg);//����д�����������Ϣ��������ͻ
	sem_destroy(&RtuDataAddr->UseFMFileFlg);//����д�����������Ϣ��������ͻ
	sem_destroy(&RtuDataAddr->Gprs_Data_Flag);//����д�����������Ϣ��������ͻ
	shm_unlink("plc_mem");
	exit(0);
}
////////////////////////////////////////////
//�������ܣ���ȡϵͳ�����ļ�
//���ã�main����ʱ
//��������
//�˳����쳣�жϣ����³�������ʧ�ܡ�
///////////////////////////////////////////
void ReadSysCfg()
{
	char syssetfile[100] =
	{ 0 };
	int i = 0, uiPortTmp;
	unsigned char ReadString[256];
	FILE *fd;
	sprintf(syssetfile, "/config/system.cfg");
	fd = fopen(syssetfile, "r");
	if (fd != NULL)
	{
		for (;;)
		{
			memset(ReadString, 0, sizeof(ReadString));
			fscanf(fd, "%s", ReadString);
			if (strncmp((char *)ReadString, "[��̬�ļ�����]", sizeof(ReadString)) == 0)
			{
				break;
			}
			if (strncmp((char *)ReadString, "��������", 8) == 0)
			{
				strcpy((char *)RtuDataAddr->uc_System_Describ, (char *)&ReadString[9]);
				continue;
			}
			if (strncmp((char *)ReadString, "Version", 7) == 0)
			{
				strcpy((char *)RtuDataAddr->ucsysVER, (char *)&ReadString[8]);
				continue;
			}
			if (strncmp((char *)ReadString, "��", 2) == 0)
			{
				RtuDataAddr->Year = atoi((char *)&ReadString[3]);
				continue;
			}
			if (strncmp((char *)ReadString, "��", 2) == 0)
			{
				RtuDataAddr->Month = atoi((char *)&ReadString[3]);
				continue;
			}
			if (strncmp((char *)ReadString, "��", 2) == 0)
			{
				RtuDataAddr->Day = atoi((char *)&ReadString[3]);
				continue;
			}
			if (strncmp((char *)ReadString, "ʱ", 2) == 0)
			{
				RtuDataAddr->Hour = atoi((char *)&ReadString[3]);
				continue;
			}
			if (strncmp((char *)ReadString, "��", 2) == 0)
			{
				RtuDataAddr->Minutes = atoi((char *)&ReadString[3]);
				continue;
			}
			if (strncmp((char *)ReadString, "��", 2) == 0)
			{
				RtuDataAddr->Second = atoi((char *)&ReadString[3]);
				continue;
			}
			if (strncmp((char *)ReadString, "��ʱ", 4) == 0)
			{
				strcpy((char *)RtuDataAddr->ucSysTimeFrom, (char *)&ReadString[5]);
				continue;
			}
			if (strncmp((char *)ReadString, "װ�õ�ַ", 8) == 0)
			{
				for (i = 0; i < strlen((char *)ReadString); i++)
				{
					if ((ReadString[i] == ',') || (ReadString[i] == '='))
						ReadString[i] = ' ';
				}
				sscanf((char *)&ReadString[9], "%d", (char *)&RtuDataAddr->RtuNo);
				continue;

			}
			if (strncmp((char *)ReadString, "SER", 3) == 0)
			{
				for (i = 0; i < strlen((char *)ReadString); i++)
				{
					if ((ReadString[i] == ',') || (ReadString[i] == '='))
						ReadString[i] = ' ';
				}
				sscanf((char *)&ReadString[3], "%d", &uiPortTmp);
				uiPortTmp = uiPortTmp + SER_START;
				if (strlen((char *)ReadString) < 7)
				{
					if (RtuDataAddr->stPortPara[uiPortTmp].ePortRunStat== NOWRUN)
					{
						RtuDataAddr->stPortPara[uiPortTmp].ePortRunStat= NEEDKILL;
					}
					else
						RtuDataAddr->stPortPara[uiPortTmp].ePortRunStat = NONE;
					continue;
				}
				////////////////////////////////////////////////////////////////////////
				SystemDbg(stderr, "ser =%d", uiPortTmp);
				////////////////////////////////////////////////////////
				RtuDataAddr->stPortPara[uiPortTmp].uiPortAddr
						= RtuDataAddr->stPortPara[uiPortTmp].uiPhysicalAddr
								= uiPortTmp;
				RtuDataAddr->stPortPara[uiPortTmp].uiDeadCount = 0;
				if (sscanf((char *)&ReadString[3], "%d %s", &i,RtuDataAddr->stPortPara[uiPortTmp].ucProgName) == 2)
				{
					RtuDataAddr->stPortPara[uiPortTmp].ePortProgState = SERPROG;
					if (RtuDataAddr->stPortPara[uiPortTmp].ePortRunStat== NOWRUN)
					{
						RtuDataAddr->stPortPara[uiPortTmp].ePortRunStat= NEEDCHECK;
					}
					if (RtuDataAddr->stPortPara[uiPortTmp].ePortRunStat == NONE)
					{
						RtuDataAddr->stPortPara[uiPortTmp].ePortRunStat= NEEDSTART;
					}
				}
				else
				{
					RtuDataAddr->stPortPara[uiPortTmp].ePortRunStat = NEEDKILL;
				}
				continue;
			}
			if (strncmp((char *)ReadString, "TCP", 3) == 0)
			{
				for (i = 0; i < strlen((char *)ReadString); i++)
				{
					if ((ReadString[i] == ',') || (ReadString[i] == '='))
						ReadString[i] = ' ';
				}
				sscanf((char *)&ReadString[3], "%d", &uiPortTmp);
				uiPortTmp = uiPortTmp + TCP_IP_START;
				if (strlen((char *)ReadString) < 7)
				{
					if (RtuDataAddr->stPortPara[uiPortTmp].ePortRunStat== NOWRUN)
					{
						RtuDataAddr->stPortPara[uiPortTmp].ePortRunStat= NEEDKILL;
					}
					else
						RtuDataAddr->stPortPara[uiPortTmp].ePortRunStat = NONE;
					continue;
				}
				RtuDataAddr->stPortPara[uiPortTmp].uiPortAddr
						= RtuDataAddr->stPortPara[uiPortTmp].uiPhysicalAddr
								= uiPortTmp;
				RtuDataAddr->stPortPara[uiPortTmp].uiDeadCount = 0;
				if (sscanf((char *)&ReadString[3], "%d %s", &i,RtuDataAddr->stPortPara[uiPortTmp].ucProgName) == 2)
				{
					RtuDataAddr->stPortPara[uiPortTmp].ePortProgState = TCPPROG;
					if (RtuDataAddr->stPortPara[uiPortTmp].ePortRunStat== NOWRUN)
					{
						RtuDataAddr->stPortPara[uiPortTmp].ePortRunStat= NEEDCHECK;
					}
					if (RtuDataAddr->stPortPara[uiPortTmp].ePortRunStat == NONE)
					{
						RtuDataAddr->stPortPara[uiPortTmp].ePortRunStat= NEEDSTART;
					}
				}
				else
				{
					RtuDataAddr->stPortPara[uiPortTmp].ePortRunStat = NEEDKILL;
				}
				continue;
			}
			if (strncmp((char *)ReadString, "PROG", 4) == 0)
			{
				for (i = 0; i < strlen((char *)ReadString); i++)
				{
					if ((ReadString[i] == ',') || (ReadString[i] == '='))
						ReadString[i] = ' ';
				}
				sscanf((char *)&ReadString[4], "%d", &uiPortTmp);
				uiPortTmp = uiPortTmp + PROG_START;
				if (strlen((char *)ReadString) < 7)
				{
					if (RtuDataAddr->stPortPara[uiPortTmp].ePortRunStat== NOWRUN)
					{
						RtuDataAddr->stPortPara[uiPortTmp].ePortRunStat= NEEDKILL;
					}
					else
						RtuDataAddr->stPortPara[uiPortTmp].ePortRunStat = NONE;
					continue;
				}
				RtuDataAddr->stPortPara[uiPortTmp].uiPortAddr= RtuDataAddr->stPortPara[uiPortTmp].uiPhysicalAddr= uiPortTmp;
				RtuDataAddr->stPortPara[uiPortTmp].uiDeadCount = 0;
				if (sscanf((char *)&ReadString[4], "%d %s", &i,RtuDataAddr->stPortPara[uiPortTmp].ucProgName) == 2)
				{
					SystemDbg(stderr, "\nread prog set ok");
					RtuDataAddr->stPortPara[uiPortTmp].ePortProgState= FUNCATIONPROG;
					SystemDbg(stderr, "  %d %s", i,RtuDataAddr->stPortPara[uiPortTmp].ucProgName);
					if (RtuDataAddr->stPortPara[uiPortTmp].ePortRunStat== NOWRUN)
					{
						RtuDataAddr->stPortPara[uiPortTmp].ePortRunStat= NEEDCHECK;
					}
					if (RtuDataAddr->stPortPara[uiPortTmp].ePortRunStat == NONE)
					{
						RtuDataAddr->stPortPara[uiPortTmp].ePortRunStat= NEEDSTART;
					}
				}
				else
				{
					RtuDataAddr->stPortPara[uiPortTmp].ePortRunStat = NEEDKILL;
				}
				continue;
			}
		}
		fclose(fd);
	}
}
