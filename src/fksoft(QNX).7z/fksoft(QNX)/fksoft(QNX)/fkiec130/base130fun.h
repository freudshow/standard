#ifndef BASE103FUN_H_
#define BASE103FUN_H_
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <ctype.h>
#include <time.h>
#include <signal.h>
#include <sys/sched.h>
#include <semaphore.h>
#include <process.h>
#include <sys/neutrino.h>
#include <sys/netmgr.h>
#include <sys/dispatch.h>
#include <errno.h>
#include <netdb.h>
#include <hw/inout.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <fkbase/memdef.h>
#include <fkbase/fkbasefun.h>
#include "fk130mem.h"
#define MY_PULSE_CODE   _PULSE_CODE_MINAVAIL
FILE *Gwfp;
#define XXPrint(...) fprintf(Gwfp, __VA_ARGS__);fflush(Gwfp);
void WaitQuit();
int setupTimer();
void ReadFrame();
void QuitProcess(int signo);
INT8U CheckSum130(INT8U *buf,INT16U len);
INT8U SaveControlSet();
void ReadFrame();
/*
void FrameSend(unsigned int len)
{
	int sendlen;
	if(FK_130_Link_Ok==0)return;
	ReadFrame();
	if(FK_130_Link_Ok)
	{
		sendlen = write(dscr,SendBuff,len);
		if(sendlen<=0)
		{
			FK_130_Link_Ok=0;
			close(dscr);
		}
	}
}*/
unsigned char	user_init_io(const char *IP,unsigned int PORT);
INT8U 	TimeComp(INT8U *s);
INT16U CalcCRC(INT8U *pBuff,INT16U len,INT16U  wPsw);
void EC();
INT8U SetDa1(INT8U Value);
INT8U SetDa2(INT8U Value);
void Create_Data_Type15(INT8U *Dest);
INT8U SetDt1(INT8U Value);
INT8U SetDt2(INT8U Value);
void TP();
void GetDa(INT8U Da1,INT8U Da2);
INT8U testTime(INT8U *s );
INT8U TestFirFin(INT8U DtNo,INT8U DaNo);
void GetDt(INT8U Dt1,INT8U Dt2);
void FrameHeadCreate(INT8U PRM);
void FrameTailCreate_Send();
void SendNAK(INT8U F,INT8U P,INT8U AFN);
void SendALLNAK();
void SendALLACK();
void Zdrenzheng();
void Create_Data_Type02(INT32S S,INT8U *Dest);
void Create_Data_Type03(INT32S S,INT8U *Dest);
long GetdataType03(INT8U *S);
INT32S GetDataType02(INT8U *S);
void GetSetStat();
void CreateErr01(unsigned char flag,unsigned char *Ver_New,unsigned char *Ver_Old);
void CreateErr03(INT8U Da1,INT8U Da2,INT8U Dt1,INT8U Dt2);
void CreateErr4();
void CreateErr5();
void CreateErr6();
void CreateErr7();
void CreateErr8();
void CreateErr9();
void CreateErr10();
void CreateErr11();
void CreateErr12();
void CreateErr13();
void CreateErr14(INT8U Flag);
void CreateErr20(INT16U CrcValue);
void CreateErr32();

#endif /*BASE103FUN_H_*/
