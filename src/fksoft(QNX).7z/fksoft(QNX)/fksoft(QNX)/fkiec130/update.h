
#ifndef UPDATE_H_
#define UPDATE_H_

#include "base130fun.h"
#define ATTACH_POINT "UPDATE_SERVER"
#define UPDATE_BEGIN    1
#define UPDATE_FAILURE  2

typedef struct {
    int start_flag;
    unsigned int AllByteCount;
    int oneSize;
    int AllPackNum;
	char fnameList[20][30];
	int  filenum;
    int ip[20];
    int port;
    int ver[2];
} my_data_t;


my_data_t smsg;
my_data_t rmsg;

INT8U  PackFlagList[128];
INT32U AllByteCount;
INT16U oneSize;     //�����ֽ���
INT16U AllPackNum;	//�ܰ���
int chid, rcvid, status;
pid_t spid;
FILE			*m_UpDataFile;				//�����ļ�ָ��
unsigned char   g_fileName[15];				//�����ļ�����

void SendOKtoStation(unsigned char* buf);

void    TrnPackACK(INT16U num);
void    TrnFlagWord();
//-----------------------------------------------------------------------
INT8U Packflag(FILE *f,INT8U *buf);
//--------------------------------------------------------------------
void buildUpdatefile();
//---------------------------------------------------------------------
void copyfile();
//--------------------------------------------------------------------
int SendmyMsg();
//====================================================================
void    FileTrans(unsigned char* SendBuf,unsigned char* RevBuf);
#endif
