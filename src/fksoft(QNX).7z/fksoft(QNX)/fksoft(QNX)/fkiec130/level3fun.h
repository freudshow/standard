#ifndef LEVEL3FUN_H_
#define LEVEL3FUN_H_
#include "base130fun.h"

////INT8U Eve_Start,Eve_End;
event_record_Save		Tmp_Event_Save;
/***********************************************************************
*4.9	����3�����ݣ�AFN=0CH��
*���ú���:AskTwoLevelData();
*�ص�����:��
***********************************************************************/
void Set_Importnet_eve(INT8U B);
void Set_normal_eve(INT8U B);
void CallThreelevelData();
void Set_Importnet_eve(INT8U B);
void Set_normal_eve(INT8U B);
int AutoSendThreeLevelData(INT8U F);

#endif /*LEVEL3FUN_H_*/
