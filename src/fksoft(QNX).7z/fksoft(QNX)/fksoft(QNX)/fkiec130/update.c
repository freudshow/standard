/*
 * update.c
 *
 *  Created on: 2009-12-16
 *      Author: www
 */
#include "update.h"


void SendOKtoStation(unsigned char* buf)
{
	SendLen = 0;
	FrameHeadCreate(0x8e);
	buf[SendLen++] = 0x0f;//afn   0-12//AFN=0fH���ļ�����
	buf[SendLen++] = 0x60|(seq&0x0f);//seq
	buf[SendLen++] = 0;//Tmp130Buff[14];//da1e
	buf[SendLen++] = 0;//Tmp130Buff[15];//da2
	buf[SendLen++] = 0;//Tmp130Buff[16];//dt1
	buf[SendLen++] = 1;//Tmp130Buff[17];//dt2
	buf[SendLen++] = 4;//�������� 3
	buf[SendLen++] = 1;
	buf[SendLen++] = 0;
	buf[SendLen++] = 1;
	buf[SendLen++] = 2;
	buf[SendLen++] = 4;
	buf[SendLen++] = (unsigned char)(AllByteCount&0xff000000)>>24;//���ֽ���
	buf[SendLen++] = (unsigned char)(AllByteCount&0x00ff0000)>>16;
	buf[SendLen++] = (unsigned char)(AllByteCount&0x0000ff00)>>8;
	buf[SendLen++] = (unsigned char)(AllByteCount&0x000000ff);
	buf[SendLen++] = AllPackNum & 0x00ff;
	buf[SendLen++] = (AllPackNum & 0xff00)>>8;
	buf[SendLen++] = 0;
	buf[SendLen++] = 0;
	buf[SendLen++] = 0xff;
	buf[SendLen++] = 0xff;
	FrameTailCreate_Send();
}
void    TrnPackACK(INT16U num)
{
	FrameHeadCreate(0x9e);
	SendBuff[SendLen++]=0x9e;//afn						//13
	SendBuff[SendLen++]=0x60|(seq&0x0f);//seq			//14
	SendBuff[SendLen++]=0;//Tmp130Buff[14];//da1e  		//15
	SendBuff[SendLen++]=0;//Tmp130Buff[15];//da2		//16
	SendBuff[SendLen++]=0;//Tmp130Buff[16];//dt1		//17
	SendBuff[SendLen++]=1;//Tmp130Buff[17];//dt2		//18
	SendBuff[SendLen++]= num & 0x00FF;		//����� �� //19
	SendBuff[SendLen++]= (num & 0xFF00)>>8; //����� �� //20
	FrameTailCreate_Send();
	DebugOut("\r\n ack end");
}

void    TrnFlagWord()
{
	INT8U i;
	FrameHeadCreate(0x8a);								//1~12
	SendBuff[SendLen++]=0x0e;//afn							//13
	SendBuff[SendLen++]=0x60|(seq&0x0f);//seq			//14
	SendBuff[SendLen++]=0;//Tmp130Buff[14];//da1e  		//15
	SendBuff[SendLen++]=0;//Tmp130Buff[15];//da2		//16
	SendBuff[SendLen++]=0;//Tmp130Buff[16];//dt1		//17
	SendBuff[SendLen++]=1;//Tmp130Buff[17];//dt2		//18
	for(i=0;i<128;i++)
		SendBuff[SendLen++] = PackFlagList[i];
	FrameTailCreate_Send();
}
//-----------------------------------------------------------------------
INT8U Packflag(FILE *f,INT8U *buf)
{
  int j;
  INT8U m=0;
  int num;
	 if (f!=NULL)
	 {
		 for(j=0;j<AllPackNum;j++)
		 {
			num = 0;m = 0;
			fseek(f,j*(oneSize+1),0);
			num = fread(&m,1,1,f);
			if (num<=0)
				break;
			buf[j/8]=buf[j/8]|((m&0x01)<<(j%8));
		 }
		  for(j=0;j<128;j++)
			 printf("%x ",buf[j]);
		 return 1;
	 }
	 else
		 return 0;

}
//---------------------------------------------------------------------

//---------------------------------------------------------------------
void copyfile()
{
	char c;
	unsigned char num;
	INT8U infilename[128],outfilename[128];
    FILE *fpin,*fpout;
    memset(infilename,0,128);
    memset(outfilename,0,128);
	sprintf((char *)infilename,"/nand/update/%s",g_fileName);
	sprintf((char *)outfilename,"/user/%s",g_fileName);
	fpin=fopen((char *)infilename,"rb");
	fpout=fopen((char *)outfilename,"wb+");

	fseek(fpin,0,0);
	num = fread(&c,1,1,fpin);
	while(num>0)
	{
		fwrite(&c,1,1,fpout);
		num = fread(&c,1,1,fpin);
	}
	fclose(fpin);
	fclose(fpout);
}
//--------------------------------------------------------------------
void EditeVercode(int ver0,int ver1)
{
	int v[2],index;
	unsigned char ReadString[512];
	FILE *fd;
	unsigned char buf[50];
	memset(buf,0,50);
	fd = fopen("/config/system.cfg", "r+");
	v[0] = ver0;
	v[1] = ver1;

	for(;;)
	{
		fscanf(fd, "%s", ReadString);
		if(strcmp((char *)ReadString,"��������=����ר��ɼ��ն�") ==0)
		{
			index = ftell(fd);
			fseek(fd,index,0);
			sprintf((char *)buf,"\nVersion=%d.%d",v[1],v[0]);
			fwrite(buf,13,1,fd);
			break;
		}
	}
	fclose( fd );
	memset(RtuDataAddr->ucsysVER,0,32);
	sprintf((char *)RtuDataAddr->ucsysVER,"%d.%d",v[1],v[0]);
}
void cpyfile(){
	int i;
	char command[50];
	memset(command,0,50);
	for (i=0;i<smsg.filenum;i++)
	{
		sprintf(command,"slay %s",smsg.fnameList[i]);
		system(command);
		printf("\n\r update slay %s",smsg.fnameList[i]);
		delay(500);
		memset(command,0,50);
		sprintf(command,"cp -f /nand/update/update/%s /user/%s",smsg.fnameList[i],smsg.fnameList[i]);
		system(command);
		printf("\n\r update cp %s end",smsg.fnameList[i]);
		delay(1000);
		memset(command,0,50);
		sprintf(command,"chmod +x /user/%s",smsg.fnameList[i]);
		system(command);
		printf("\n\r update chmod %s end",smsg.fnameList[i]);
	}
}
int SendmyMsg()
{
	unsigned char ip[4];
	unsigned char vernew[4];
	struct sockaddr_in servaddr;
	int server_coid;
	memset(vernew,0,4);
	memset(ip,0,4);
	if ((server_coid = name_open(ATTACH_POINT, 0)) == -1) {
	    return EXIT_FAILURE;
	}
	smsg.AllByteCount = AllByteCount;
	smsg.AllPackNum = AllPackNum;
	smsg.oneSize = oneSize;
	smsg.start_flag = UPDATE_BEGIN;
    if (MsgSend(server_coid, &smsg, sizeof(smsg), &smsg, sizeof(smsg)) == -1) {
    	{
    		printf("\n\r in fkiec130 send msg   1");
    		perror("MsgSend");
    		printf("\n\r");
    		return 0;
    	}
    }
    printf("\n\r \n\r \n\r in fkiec130 Receive.... msg   1");

    if (smsg.start_flag == 2)
    {
    	printf("\n\r in fkiec130 recive msg pdate failure");
    	printf("\n\r");
    	return 0;
    }
    cpyfile();

    printf("\n\r master station ip %s ,prot %d",smsg.ip,smsg.port);
	inet_aton((char *)smsg.ip,&servaddr.sin_addr);
	ip[0] = servaddr.sin_addr.s_addr & 0x000000ff;
	ip[1] = (servaddr.sin_addr.s_addr & 0x0000ff00)>>8;
	ip[2] = (servaddr.sin_addr.s_addr & 0x00ff0000)>>16;
	ip[3] = (servaddr.sin_addr.s_addr & 0xff000000)>>24;
	RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[0]=ip[0];
	RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[1]=ip[1];
	RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[2]=ip[2];
	RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[3]=ip[3];
	RtuDataAddr->FkComm_Value.F3_Set_Para.PortMaster[0]= smsg.port & 0x00ff;
	RtuDataAddr->FkComm_Value.F3_Set_Para.PortMaster[1]= (smsg.port & 0xff00)>>8;
	printf("\n\r ip int %d.%d.%d.%d port %d",ip[0],ip[1],ip[2],ip[3],smsg.port);
	Save_CommSet();
	RtuDataAddr->Gprs_ok = 0;
	//���ɰ汾�����¼
	sprintf((char *)vernew,"%d.%d",smsg.ver[1],smsg.ver[0]);
	CreateErr01(0x02,vernew,ProgVer);

	printf("\n\r VerNew %s  ProgVer %s",vernew,ProgVer);
	EditeVercode(smsg.ver[0],smsg.ver[1]);
    name_close(server_coid);
    return 1;
}
//====================================================================
void    FileTrans(unsigned char* SendBuf,unsigned char* RevBuf)
{
	INT16U nowPackNum=0;  //��ǰ�����
	INT16U ByteCount;   //��ǰ�����ֽ�����
	INT8U  type;        //��������
	INT16U  i,j,p,w;
	INT8U  okflag;		//������ɱ�־
	INT8U  filename[128];
	INT8U version[4];
	int writenum;
	type = 0;
	AllPackNum  = (Tmp130Buff[29]<<8) + Tmp130Buff[28];
	type 	    = Tmp130Buff[18];
	oneSize     = (Tmp130Buff[31]<<8) + Tmp130Buff[30];
	AllByteCount= (Tmp130Buff[24]<<24) + (Tmp130Buff[25]<<16) + (Tmp130Buff[26]<<8) + Tmp130Buff[27];
	memset(filename,0,128);
	for(j=0;j<4;j++)
		version[j]=Tmp130Buff[20+j];
	switch(type)
	{
		case 1://��ѯ״̬
			DebugOut("\r\n data state call");
			okflag = 1;
			//-------------------------------------------------------
			for (i=0;i<15;i++)
				g_fileName[i] = Tmp130Buff[32+i];//�ļ���ռ15���ֽ�

			sprintf((char *)filename,"/nand/update/%s.tmp",g_fileName);
			if (m_UpDataFile!=NULL)
			{
				fflush(m_UpDataFile);
				fclose(m_UpDataFile);
			}
			m_UpDataFile = NULL;
			m_UpDataFile = fopen((char *)filename,"rb+");
			for(i=0;i<128;i++)
				PackFlagList[i]=0;

			if ((m_UpDataFile != NULL)&&(Packflag(m_UpDataFile,PackFlagList)))
			{
				for(p=0; p<AllPackNum; p++)
				{
					if(p/8 == 0)
						i = p;
					else
						i = p%8;
					switch(i)
					{
						case 0:
							if ((PackFlagList[p/8] & 0x01)==0)
								okflag = 0;
							break;
						case 1:
							if ((PackFlagList[p/8] & 0x02)==0)
								okflag = 0;
							break;
						case 2:
							if ((PackFlagList[p/8] & 0x04)==0)
								okflag = 0;
							break;
						case 3:
							if ((PackFlagList[p/8] & 0x08)==0)
								okflag = 0;
							break;
						case 4:
							if ((PackFlagList[p/8] & 0x10)==0)
								okflag = 0;
							break;
						case 5:
							if ((PackFlagList[p/8] & 0x20)==0)
								okflag = 0;
							break;
						case 6:
							if ((PackFlagList[p/8] & 0x40)==0)
								okflag = 0;
							break;
						case 7:
							if ((PackFlagList[p/8] & 0x80)==0)
								okflag = 0;
							break;
					}
				}
			}
			else
			{
				DebugOut("\r\n ------------ step 5 ");
				m_UpDataFile=fopen((char *)filename,"wb+");
				for(i=0;i<128;i++)
					PackFlagList[i]=0;
				okflag = 0;
			}
			//-----------------------------------------------------------
			if(okflag == 1)			   //�������
			{
				DebugOut("\n\r .UPDATE END ");
				fflush(m_UpDataFile);
				fclose(m_UpDataFile);
				delay(1000);
				//--------------------------------------------------------------------------
				//buildUpdatefile();
				delay(1000);
				//printf("\n\r begin SendMsg......");
				//--------------------------------------------------------------------------
				SendmyMsg();

				SendOKtoStation(Tmp130Buff);
				//printf("\n\r SendMsg end:::::::::::::::::::::::::::::");
			}
			else
			{
				TrnFlagWord();//����״̬��
			}
		break;
		case 2://���ݰ�����

			RtuDataAddr->m_updateflag = 1;
			RtuDataAddr->m_AllPackNum = AllPackNum;
			RtuDataAddr->m_NowPackNum = nowPackNum;

			ByteCount   = (Tmp130Buff[35]<<8) + Tmp130Buff[34];
			nowPackNum  = (Tmp130Buff[33]<<8) + Tmp130Buff[32];//33 34
			AllByteCount= (Tmp130Buff[24]<<24) + (Tmp130Buff[25]<<16) + (Tmp130Buff[26]<<8) + Tmp130Buff[27];
			DebugOut("\r\n one pack size %d ",oneSize);
			DebugOut("\r\n allpack num %d ",AllPackNum);
			DebugOut("\r\n now pack size %d ",ByteCount);
			DebugOut("\r\n now pack num %d ",nowPackNum);
			DebugOut("\r\n file byte size %d ",AllByteCount);
			PackFlagList[nowPackNum/8] = PackFlagList[nowPackNum/8] | (1<<(nowPackNum%8));
			printf("\n\r packflag==%d",PackFlagList[nowPackNum/8]);
			//-------------------------------------------------------------------------------------------------
			w=(PackFlagList[nowPackNum/8]>>(nowPackNum%8))&0x01;
			fseek(m_UpDataFile,nowPackNum*(oneSize+1),0);
			writenum = 0;
			writenum = fwrite(&w,1,1,m_UpDataFile);
			printf("\n\r writenum 1 ==%d",writenum);
			fseek(m_UpDataFile,nowPackNum*(oneSize+1)+1,0);
			writenum = 0;
			writenum = fwrite(&Tmp130Buff[36],1,ByteCount,m_UpDataFile);
			printf("\n\r writenum 2 ==%d",writenum);
			//------------------------------------------------------------------------------------------------------
			TrnPackACK(nowPackNum);
		break;
	}
}
