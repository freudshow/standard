/*
 * level2fun.c
 *
 *  Created on: 2009-12-16
 *      Author: www
 */
#include "level2fun.h"
extern int SelfheartCount;
void INT32_A25(INT32S Value,unsigned char * bcd)
{
	memset(bcd,0,3);
	if(Value<0)
		bcd[2]=bcd[2]|0x80;
	Value=abs(Value)*10;
	bcd[2]=bcd[2]|((Value/100000)<<4);
	Value=Value%100000;
	bcd[2]=bcd[2]|(Value/10000);
	Value=Value%10000;
	bcd[1]=(Value/1000)<<4;
	Value=Value%1000;
	bcd[1]=bcd[1]|(Value/100);
	Value=Value%100;
	bcd[0]=(Value/10)<<4;
	Value=Value%10;
	bcd[0]=bcd[0]|(Value);

}
void INT16_A5(INT16U Value,unsigned char * bcd)
{
	bcd[1]=(Value/1000)<<4;
	Value=Value%1000;
	bcd[1]=bcd[1]|(Value/100);

	Value=Value%100;
	bcd[0]=(Value/10)<<4;
	Value=Value%10;
	bcd[0]=bcd[0]|(Value);
}
INT8U Read_Yue_ZdStat(ZhongDuanTj *Dest,INT8U Point,INT8U *t)
{
	INT8U name[128];
	INT8U ret;
	sprintf((char *)name,"/nand/save/YueSave%02x.dat",t[0]);
	ret=ReadFile(name,(INT8U *)&RtuDataAddr->YdSave_Value.Yue_Save_Value,sizeof(RtuDataAddr->YdSave_Value.Yue_Save_Value));
	if(ret==0)memcpy(Dest,&RtuDataAddr->YdSave_Value.Yue_Save_Value.ZD_Yue_stat,sizeof(RtuDataAddr->YdSave_Value.Yue_Save_Value.ZD_Yue_stat));
	else return 0;
	return 1;
}
INT8U Read_Yue_ClXuLiang(his_XuLiang_Set *Dest,INT8U Point,INT8U *t)
{
	INT8U name[128];
	INT8U ret;
	sprintf((char *)name,"/nand/save/YueSave%02x.dat",t[0]);
	ret=ReadFile(name,(INT8U *)&RtuDataAddr->YdSave_Value.Yue_Save_Value,sizeof(RtuDataAddr->YdSave_Value.Yue_Save_Value));
	if(ret==0)memcpy(Dest,&RtuDataAddr->YdSave_Value.Yue_Save_Value.Cl_His_XuLiang[Point-1],sizeof(RtuDataAddr->YdSave_Value.Yue_Save_Value.Cl_His_XuLiang[Point-1]));
	else return 0;
	return 1;
}
INT8U Read_Yue_ClHisDianneng(his_Dianneng_Set *Dest,INT8U Point,INT8U *t)
{
	INT8U name[128];
	INT8U ret;
	sprintf((char *)name,"/nand/save/YueSave%02x.dat",t[0]);
	ret=ReadFile(name,(INT8U *)&RtuDataAddr->YdSave_Value.Yue_Save_Value,sizeof(RtuDataAddr->YdSave_Value.Yue_Save_Value));
	if(ret==0)memcpy(Dest,&RtuDataAddr->YdSave_Value.Yue_Save_Value.Cl_His_DianNeng[Point-1],sizeof(RtuDataAddr->YdSave_Value.Yue_Save_Value.Cl_His_DianNeng[Point-1]));
	else return 0;
	return 1;
}

INT8U Read_Yue_ClStat(Cl_Stat_Set *Dest,INT8U Point,INT8U *t)
{
	INT8U name[128];
	INT8U ret;
	sprintf((char *)name,"/nand/save/YueSave%02x.dat",t[0]);
	ret=ReadFile(name,(INT8U *)&RtuDataAddr->YdSave_Value.Yue_Save_Value,sizeof(RtuDataAddr->YdSave_Value.Yue_Save_Value));
	if(ret==0)memcpy(Dest,&RtuDataAddr->YdSave_Value.Yue_Save_Value.Cl_Stat[Point-1],sizeof(RtuDataAddr->YdSave_Value.Yue_Save_Value.Cl_Stat[Point-1]));
	else return 0;
	return 1;
}
INT8U Read_Yue_F2730Stat(F27_28_29_30_level_stru *Dest,INT8U Point,INT8U *t)
{
	INT8U name[128];
	INT8U ret;
	int siz;
	sprintf((char *)name,"/nand/save/YueF2730Save%02x.dat",t[0]);
	ret=ReadFile(name,(INT8U *)&RtuDataAddr->TF27_28_29_30_Mem[0].valid,sizeof(RtuDataAddr->TF27_28_29_30_Mem));
	if(ret==0)
	{
		siz = sizeof(Dest);
		memcpy(Dest,&RtuDataAddr->TF27_28_29_30_Mem[Point-1],sizeof(F27_28_29_30_level_stru));
	}
	else
		return 0;
	return 1;
}
INT8U Read_Yue_ZjHisDianneng(his_Dianneng_Set *Dest,INT8U Point,INT8U *t)
{
	INT8U name[128];
	INT8U ret;
	sprintf((char *)name,"/nand/save/YueSave%02x.dat",t[0]);
	ret=ReadFile(name,(INT8U *)&RtuDataAddr->YdSave_Value.Yue_Save_Value,sizeof(RtuDataAddr->YdSave_Value.Yue_Save_Value));
	if(ret==0)memcpy(Dest,&RtuDataAddr->YdSave_Value.Yue_Save_Value.Zj_His_DianNeng[Point-1],sizeof(RtuDataAddr->YdSave_Value.Yue_Save_Value.Zj_His_DianNeng[Point-1]));
	else return 0;
	return 1;
}
INT8U Read_Yue_ZjStat(Zj_Stat_Set *Dest,INT8U Point,INT8U *t)
{
	INT8U name[128];
	INT8U ret;
	sprintf((char *)name,"/nand/save/YueSave%02x.dat",t[0]);
	ret=ReadFile(name,(INT8U *)&RtuDataAddr->YdSave_Value.Yue_Save_Value,sizeof(RtuDataAddr->YdSave_Value.Yue_Save_Value));
	if(ret==0)memcpy(Dest,&RtuDataAddr->YdSave_Value.Yue_Save_Value.Zj_Stat[Point-1],sizeof(RtuDataAddr->YdSave_Value.Yue_Save_Value.Zj_Stat[Point-1]));
	else return 0;
	return 1;
}

INT8U Read_Day_ZdStat(INT8U *t,ZhongDuanTj *Dest,INT8U Point)
{
	INT8U name[128];
	INT8U ret;
	sprintf((char *)name,"/nand/save/DaySave%02x%02x.dat",t[1],t[0]);
	ret=ReadFile(name,(INT8U *)&RtuDataAddr->YdSave_Value.Day_Save_Value,sizeof(RtuDataAddr->YdSave_Value.Day_Save_Value));
	if(ret==0)
	{
		memcpy(Dest,&RtuDataAddr->YdSave_Value.Day_Save_Value.ZD_Day_stat,sizeof(RtuDataAddr->YdSave_Value.Day_Save_Value.ZD_Day_stat));
		printf("\n\r tiaozhaNum-read is %d",RtuDataAddr->YdSave_Value.Day_Save_Value.ZD_Day_stat.Yk_T);
		printf("\n\r");
	}
	else
		return 0;
	return 1;
}

INT8U Read_Day_ClXuLiang(INT8U *t,his_XuLiang_Set *Dest,INT8U Point)
{
	INT8U name[128];
	INT8U ret;
	sprintf((char *)name,"/nand/save/DaySave%02x%02x.dat",t[1],t[0]);
	ret=ReadFile(name,(INT8U *)&RtuDataAddr->YdSave_Value.Day_Save_Value,sizeof(RtuDataAddr->YdSave_Value.Day_Save_Value));
	if(ret==0)memcpy(Dest,&RtuDataAddr->YdSave_Value.Day_Save_Value.Cl_His_XuLiang[Point-1],sizeof(RtuDataAddr->YdSave_Value.Day_Save_Value.Cl_His_XuLiang[Point-1]));
	else return 0;
	return 1;
}

INT8U Read_Day_ClHisDianneng(INT8U *t,his_Dianneng_Set *Dest,INT8U Point)
{
	INT8U name[128];
	INT8U ret;
	sprintf((char *)name,"/nand/save/DaySave%02x%02x.dat",t[1],t[0]);
	ret=ReadFile(name,(INT8U *)&RtuDataAddr->YdSave_Value.Day_Save_Value,sizeof(RtuDataAddr->YdSave_Value.Day_Save_Value));
	if(ret==0){
		if(t[2]==RtuDataAddr->YdSave_Value.Day_Save_Value.Cl_His_DianNeng[Point-1].Chao_Time.BCD05)
			memcpy(Dest,&RtuDataAddr->YdSave_Value.Day_Save_Value.Cl_His_DianNeng[Point-1],sizeof(RtuDataAddr->YdSave_Value.Day_Save_Value.Cl_His_DianNeng[Point-1]));
		else return 0;
	}
	else return 0;
	return 1;
}

INT8U Read_Day_ClStat(INT8U *t,Cl_Stat_Set *Dest,INT8U Point)
{
	INT8U name[128];
	INT8U ret;
	sprintf((char *)name,"/nand/save/DaySave%02x%02x.dat",t[1],t[0]);
	ret=ReadFile(name,(INT8U *)&RtuDataAddr->YdSave_Value.Day_Save_Value,sizeof(RtuDataAddr->YdSave_Value.Day_Save_Value));
	if(ret==0)
		memcpy(Dest,&RtuDataAddr->YdSave_Value.Day_Save_Value.Cl_Stat[Point-1],sizeof(RtuDataAddr->YdSave_Value.Day_Save_Value.Cl_Stat[Point-1]));
	else
		return 0;
	return 1;
}

INT8U Read_Day_XieBo(INT8U *t,Min_15_XieBo_Set *Dest,INT8U Point)
{
/*	INT8U name[128];
	INT8U ret;
	sprintf(name,"/nand/save/xb%02x%02x.dat",t[0],t[1]);
	ret=ReadFile(name,(INT8U *)&RtuDataAddr->XieBo_QuXian,sizeof(Min_15_XieBo_Set));
	if(ret==0)
		memcpy(Dest,&RtuDataAddr->XieBo_QuXian,sizeof(Min_15_XieBo_Set));
	else
		return 0;*/
	return 1;
}

INT8U Read_Day_ZjHisDianneng(INT8U *t,his_Dianneng_Set *Dest,INT8U Point)
{
	INT8U name[128];
	INT8U ret;
	sprintf((char *)name,"/nand/save/DaySave%02x%02x.dat",t[1],t[0]);
	ret=ReadFile(name,(INT8U *)&RtuDataAddr->YdSave_Value.Day_Save_Value,sizeof(RtuDataAddr->YdSave_Value.Day_Save_Value));
	if(ret==0)memcpy(Dest,&RtuDataAddr->YdSave_Value.Day_Save_Value.Zj_His_DianNeng[Point-1],sizeof(RtuDataAddr->YdSave_Value.Day_Save_Value.Zj_His_DianNeng[Point-1]));
	else return 0;
	return 1;
}
INT8U Read_Day_F2730Stat(F27_28_29_30_level_stru *Dest,INT8U Point,INT8U *t)
{
	INT8U name[128];
	INT8U ret;
	sprintf((char *)name,"/nand/save/DayF2730Save%02x%02x.dat",t[1],t[0]);
	printf("read /nand/save/DayF2730Save%02x%02x.dat",t[1],t[0]);
	ret=ReadFile(name,(INT8U *)&RtuDataAddr->TF27_28_29_30_Mem[0].valid,sizeof(RtuDataAddr->TF27_28_29_30_Mem));
	if(ret==0)memcpy(Dest,&RtuDataAddr->TF27_28_29_30_Mem[Point-1].valid,sizeof(F27_28_29_30_level_stru));
	else return 0;
	return 1;
}

INT8U Read_Day_FuZaiLvTongJi(F31_level_stru *Dest,INT8U Point,INT8U *t)
{
	INT8U name[128];
	INT8U ret;
	sprintf((char *)name,"/nand/save/DayFuZaiLvTongJiSave%02x%02x.dat",t[1],t[0]);
	ret=ReadFile(name,(INT8U *)&RtuDataAddr->FuZaiLvTongJi.valid,sizeof(RtuDataAddr->FuZaiLvTongJi));
	if(ret==0)memcpy(Dest,&RtuDataAddr->FuZaiLvTongJi.valid,sizeof(F27_28_29_30_level_stru));
	else return 0;
	return 1;
}
INT8U Read_Day_ZjQuXian(INT8U *t,INT32U *Dest,INT8U Point,INT8U Flag)
{
	INT8U i=0;
	INT8U name[128];
	INT8U ret;
	switch(Flag)
	{
		case 81:
			sprintf((char *)name,"/nand/save/qxzj%02x%02x.dat",t[3],t[2]);
			ret=ReadFile(name,(INT8U *)&RtuDataAddr->Tmp_Qx_Buff.Tmp_Qx_Zj,sizeof(RtuDataAddr->Tmp_Qx_Buff.Tmp_Qx_Zj));

			if(!ret){for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_Qx_Zj[Point-1][i].P;}return 1;}else return 0;
		break;
		case 82:
			sprintf((char *)name,"/nand/save/qxzj%02x%02x.dat",t[3],t[2]);
			ret=ReadFile(name,(INT8U *)&RtuDataAddr->Tmp_Qx_Buff.Tmp_Qx_Zj,sizeof(RtuDataAddr->Tmp_Qx_Buff.Tmp_Qx_Zj));
			if(!ret){for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_Qx_Zj[Point-1][i].Q;}return 1;}else return 0;
			if(!ret){if(RtuDataAddr->Tmp_Qx_Buff.Tmp_Qx_Zj[Point-1][i].Valid==1)
				{for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_Qx_Zj[Point-1][i].Q;
					}return 1;}else return 0;}else return 0;
		break;
		case 83:
			sprintf((char *)name,"/nand/save/qxzj%02x%02x.dat",t[3],t[2]);
			ret=ReadFile(name,(INT8U *)&RtuDataAddr->Tmp_Qx_Buff.Tmp_Qx_Zj,sizeof(RtuDataAddr->Tmp_Qx_Buff.Tmp_Qx_Zj));
			if(!ret){for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_Qx_Zj[Point-1][i].P_All;}return 1;}else return 0;
			if(!ret){if(RtuDataAddr->Tmp_Qx_Buff.Tmp_Qx_Zj[Point-1][i].Valid==1)
				{for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_Qx_Zj[Point-1][i].P_All;}
					return 1;}else return 0;}else return 0;
		break;
		case 84:
			sprintf((char *)name,"/nand/save/qxzj%02x%02x.dat",t[3],t[2]);
			ret=ReadFile(name,(INT8U *)&RtuDataAddr->Tmp_Qx_Buff.Tmp_Qx_Zj,sizeof(RtuDataAddr->Tmp_Qx_Buff.Tmp_Qx_Zj));
			if(!ret){for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_Qx_Zj[Point-1][i].Q_All;}return 1;}else return 0;
			if(!ret){if(RtuDataAddr->Tmp_Qx_Buff.Tmp_Qx_Zj[Point-1][i].Valid==1)
				{for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_Qx_Zj[Point-1][i].Q_All;}
				return 1;}else return 0;}else return 0;
		break;
		case 89://2
			sprintf((char *)name,"/nand/save/qxddbs%02x%02x.dat",t[3],t[2]);
			ret=ReadFile(name,(INT8U *)&RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real,sizeof(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real));
			DebugOut("\r\n%s    -------  ret = %d",name,ret);
			if(!ret)
			{
				for(i=0;i<96;i++)
				{
					Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].P;
//					printf("\n\rDestPPPP[%d]===%d",i,Dest[i]);
//					printf("\n\r");
				}
				return 1;
			}else
				return 0;
		break;
		case 90://2
			sprintf((char *)name,"/nand/save/qxddbs%02x%02x.dat",t[3],t[2]);
			ret=ReadFile(name,(INT8U *)&RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real,sizeof(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real));
			if(!ret){for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].PA;}return 1;}else return 0;
			if(!ret){if(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].Valid==1)
				{for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].PA;}
				return 1;}else return 0;}else return 0;
		break;
		case 91://2
			sprintf((char *)name,"/nand/save/qxddbs%02x%02x.dat",t[3],t[2]);
			ret=ReadFile(name,(INT8U *)&RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real,sizeof(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real));
			if(!ret){for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].PB;}return 1;}else return 0;
			if(!ret){if(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].Valid==1)
				{for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].PB;}
				return 1;}else return 0;}else return 0;
		break;
		case 92://3
			sprintf((char *)name,"/nand/save/qxddbs%02x%02x.dat",t[3],t[2]);
			ret=ReadFile(name,(INT8U *)&RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real,sizeof(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real));
			if(!ret){for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].PC;}return 1;}else return 0;
			if(!ret){if(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].Valid==1)
				{for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].PC;}
				return 1;}else return 0;}else return 0;
		break;
		case 93://3
			sprintf((char *)name,"/nand/save/qxddbs%02x%02x.dat",t[3],t[2]);
			ret=ReadFile(name,(INT8U *)&RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real,sizeof(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real));
			if(!ret){for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].Q;
//			printf("\n\rDestQQQQQQQQ[%d]===%d",i,Dest[i]);
//			printf("\n\r");
			}return 1;}else return 0;
			if(!ret){if(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].Valid==1)
				{for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].Q;}
				return 1;}else return 0;}else return 0;
		break;
		case 94://3
			sprintf((char *)name,"/nand/save/qxddbs%02x%02x.dat",t[3],t[2]);
			ret=ReadFile(name,(INT8U *)&RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real,sizeof(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real));
			if(!ret){for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].QA;}return 1;}else return 0;
			if(!ret){if(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].Valid==1)
				{for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].QA;}
				return 1;}else return 0;}else return 0;
		break;
		case 95:
			sprintf((char *)name,"/nand/save/qxddbs%02x%02x.dat",t[3],t[2]);
			ret=ReadFile(name,(INT8U *)&RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real,sizeof(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real));
			if(!ret){for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].QB;}return 1;}else return 0;
			if(!ret){if(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].Valid==1)
				{for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].QB;}
				return 1;}else return 0;}else return 0;
		break;
		case 96:
			sprintf((char *)name,"/nand/save/qxddbs%02x%02x.dat",t[3],t[2]);
			ret=ReadFile(name,(INT8U *)&RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real,sizeof(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real));
			if(!ret){for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].QC;}return 1;}else return 0;
			if(!ret){if(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].Valid==1)
				{for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].QC;}
				return 1;}else return 0;}else return 0;
		break;
		case 97:
			sprintf((char *)name,"/nand/save/qxddbs%02x%02x.dat",t[3],t[2]);
			ret=ReadFile(name,(INT8U *)&RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real,sizeof(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real));
			if(!ret){for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].VA;}return 1;}else return 0;
			if(!ret){if(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].Valid==1)
				{for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].VA;}
				return 1;}else return 0;}else return 0;
		break;
		case 98:
			sprintf((char *)name,"/nand/save/qxddbs%02x%02x.dat",t[3],t[2]);
			ret=ReadFile(name,(INT8U *)&RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real,sizeof(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real));
			if(!ret){for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].VB;}return 1;}else return 0;
			if(!ret){if(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].Valid==1)
				{for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].VB;}
				return 1;}else return 0;}else return 0;
		break;
		case 99:
			sprintf((char *)name,"/nand/save/qxddbs%02x%02x.dat",t[3],t[2]);
			ret=ReadFile(name,(INT8U *)&RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real,sizeof(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real));
			if(!ret){for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].VC;}return 1;}else return 0;
			if(!ret){if(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].Valid==1)
				{for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].VC;}
				return 1;}else return 0;}else return 0;
		break;
		case 100:
			sprintf((char *)name,"/nand/save/qxddbs%02x%02x.dat",t[3],t[2]);
			ret=ReadFile(name,(INT8U *)&RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real,sizeof(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real));
			if(!ret){
				for(i=0;i<96;i++)
				{Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].IA;}return 1;
			}
			else return 0;
			if(!ret){if(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].Valid==1)
				{for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].IA;}
				return 1;}else return 0;}else return 0;
		break;
		case 101:
			sprintf((char *)name,"/nand/save/qxddbs%02x%02x.dat",t[3],t[2]);
			ret=ReadFile(name,(INT8U *)&RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real,sizeof(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real));
			if(!ret){for(i=0;i<96;i++){
				Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].IB;
				}return 1;}else return 0;
			if(!ret){if(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].Valid==1)
				{for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].IB;}
				return 1;}else return 0;}else return 0;
		break;
		case 102:
			sprintf((char *)name,"/nand/save/qxddbs%02x%02x.dat",t[3],t[2]);
			ret=ReadFile(name,(INT8U *)&RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real,sizeof(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real));
			if(!ret){for(i=0;i<96;i++){
				Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].IC;
				}return 1;}else return 0;
			if(!ret){if(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].Valid==1)
				{for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].IC;}
				return 1;}else return 0;}else return 0;
		break;
		case 103:
			sprintf((char *)name,"/nand/save/qxddbs%02x%02x.dat",t[3],t[2]);
			ret=ReadFile(name,(INT8U *)&RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real,sizeof(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real));
			if(!ret){for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].IL;}return 1;}else return 0;
			if(!ret){if(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].Valid==1)
				{for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].IL;}
				return 1;}else return 0;}else return 0;
		break;
		case 105:
			sprintf((char *)name,"/nand/save/qxddbs%02x%02x.dat",t[3],t[2]);
			ret=ReadFile(name,(INT8U *)&RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real,sizeof(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real));
			if(!ret){for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].QX_Z_P_All;}return 1;}else return 0;
			if(!ret){if(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].Valid==1)
				{for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].QX_Z_P_All;}
				return 1;}else return 0;}else return 0;
		break;
		case 106:
			sprintf((char *)name,"/nand/save/qxddbs%02x%02x.dat",t[3],t[2]);
			ret=ReadFile(name,(INT8U *)&RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real,sizeof(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real));
			if(!ret){for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].QX_Z_Q_All;}return 1;}else return 0;
			if(!ret){if(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].Valid==1)
				{for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].QX_Z_Q_All;}
				return 1;}else return 0;}else return 0;
		break;
		case 107:
			sprintf((char *)name,"/nand/save/qxddbs%02x%02x.dat",t[3],t[2]);
			ret=ReadFile(name,(INT8U *)&RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real,sizeof(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real));
			if(!ret){for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].QX_F_P_All;}return 1;}else return 0;
			if(!ret){if(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].Valid==1)
				{for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].QX_F_P_All;}
				return 1;}else return 0;}else return 0;
		break;
		case 108:
			sprintf((char *)name,"/nand/save/qxddbs%02x%02x.dat",t[3],t[2]);
			ret=ReadFile(name,(INT8U *)&RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real,sizeof(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real));
			if(!ret){for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].QX_F_Q_All;}return 1;}else return 0;
			if(!ret){if(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].Valid==1)
				{for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].QX_F_Q_All;}
				return 1;}else return 0;}else return 0;
		break;
		case 109:
			sprintf((char *)name,"/nand/save/qxddbs%02x%02x.dat",t[3],t[2]);
			ret=ReadFile(name,(INT8U *)&RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real,sizeof(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real));
			//printf("\n\r ret ==%d",ret);
			if(!ret)
			{
				for(i=0;i<96;i++)
				{
					Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].Z_P_All;

				}
				//printf("\n\rRtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[%d][0].Z_P_All===%d",Point-1,RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][0].Z_P_All);
				//printf("\n\rRtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[%d][95].Z_P_All===%d",Point-1,RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][95].Z_P_All);
				return 1;
			}else
				return 0;
			if(!ret){if(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].Valid==1)
				{for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].Z_P_All;}
				return 1;}else return 0;}else return 0;
		break;
		case 110:
			sprintf((char *)name,"/nand/save/qxddbs%02x%02x.dat",t[3],t[2]);
			ret=ReadFile(name,(INT8U *)&RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real,sizeof(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real));
			if(!ret){for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].Z_Q_All;}return 1;}else return 0;
			if(!ret){if(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].Valid==1)
				{for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].Z_Q_All;}
				return 1;}else return 0;}else return 0;
		break;
		case 111:
			sprintf((char *)name,"/nand/save/qxddbs%02x%02x.dat",t[3],t[2]);
			ret=ReadFile(name,(INT8U *)&RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real,sizeof(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real));
			if(!ret){for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].F_P_All;}return 1;}else return 0;
			if(!ret){if(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].Valid==1)
				{for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].F_P_All;}
				return 1;}else return 0;}else return 0;
		break;
		case 112:
			sprintf((char *)name,"/nand/save/qxddbs%02x%02x.dat",t[3],t[2]);
			ret=ReadFile(name,(INT8U *)&RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real,sizeof(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real));
			if(!ret){for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].F_Q_All;}return 1;}else return 0;
			if(!ret){if(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].Valid==1)
				{for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].F_Q_All;}
				return 1;}else return 0;}else return 0;
		break;
		case 113:
			sprintf((char *)name,"/nand/save/qxddbs%02x%02x.dat",t[3],t[2]);
			ret=ReadFile(name,(INT8U *)&RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real,sizeof(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real));
			if(!ret){for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].Cos;}return 1;}else return 0;
			if(!ret){if(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].Valid==1)
				{for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].Cos;}
				return 1;}else return 0;}else return 0;
		break;
		case 114:
			sprintf((char *)name,"/nand/save/qxddbs%02x%02x.dat",t[3],t[2]);
			ret=ReadFile(name,(INT8U *)&RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real,sizeof(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real));
			if(!ret){for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].CosA;}return 1;}else return 0;
			if(!ret){if(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].Valid==1)
				{for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].CosA;}
				return 1;}else return 0;}else return 0;
		break;
		case 115:
			sprintf((char *)name,"/nand/save/qxddbs%02x%02x.dat",t[3],t[2]);
			ret=ReadFile(name,(INT8U *)&RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real,sizeof(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real));
			if(!ret){for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].CosB;}return 1;}else return 0;
			if(!ret){if(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].Valid==1)
				{for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].CosB;}
				return 1;}else return 0;}else return 0;
		break;
		case 116:
			sprintf((char *)name,"/nand/save/qxddbs%02x%02x.dat",t[3],t[2]);
			ret=ReadFile(name,(INT8U *)&RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real,sizeof(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real));
			if(!ret){for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].CosC;}return 1;}else return 0;
			if(!ret){if(RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].Valid==1)
				{for(i=0;i<96;i++){Dest[i]=RtuDataAddr->Tmp_Qx_Buff.Tmp_QX_DD_Real[Point-1][i].CosC;}
				return 1;}else return 0;}else return 0;
		break;
	}
	return 1;
}
INT8U Read_Day_ZjStat(INT8U *t,Zj_Stat_Set *Dest,INT8U Point)
{
	return 1;
}

INT8U Set_Level2_F1(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F2(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F3(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F4(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F5(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F6(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F7(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F8(INT8U F,INT8U P,INT8U *t,INT8U FRM);

INT8U Set_Level2_F9(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F10(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F11(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F12(INT8U F,INT8U P,INT8U *t,INT8U FRM);

INT8U Set_Level2_F17(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F18(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F19(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F20(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F21(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F22(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F23(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F24(INT8U F,INT8U P,INT8U *t,INT8U FRM);

INT8U Set_Level2_F25(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F26(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F27(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F28(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F29(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F30(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F31(INT8U F,INT8U P,INT8U *t,INT8U FRM);

INT8U Set_Level2_F32(INT8U F,INT8U P,INT8U *t,INT8U FRM);

INT8U Set_Level2_F33(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F34(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F35(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F36(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F37(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F44(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F49(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F50(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F51(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F52(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F53(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F54(INT8U F,INT8U P,INT8U *t,INT8U FRM);

INT8U Set_Level2_F57(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F58(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F59(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F60(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F61(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F62(INT8U F,INT8U P,INT8U *t,INT8U FRM);

INT8U Set_Level2_F73(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F74(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F75(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F76(INT8U F,INT8U P,INT8U *t,INT8U FRM);

INT8U Set_Level2_F81(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F89(INT8U F,INT8U P,INT8U *t,INT8U FRM);

INT8U Set_Level2_F97(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F101(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F105(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F113(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F114(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F115(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F116(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F117(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F118(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F121(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F122(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F123(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U CallTwoDataProcCalc(INT8U F,INT8U P,INT8U QxBl,INT8U *S,INT8U FRM);
INT8U SendTwoLevelData(INT8U P,INT8U F,INT8U *t);
INT8U CallTwolevelData();
INT8U CallTwoDataProc(INT8U F,INT8U P,INT8U QxBl,INT8U *S,INT8U FRM);
INT8U Set_Level2_F161(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F162(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F163(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F164(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F165(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F166(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F167(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F168(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F177(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F178(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F179(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F180(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F181(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F182(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F183(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F184(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F185(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F186(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F187(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U Set_Level2_F188(INT8U F,INT8U P,INT8U *t,INT8U FRM);
INT8U CallTwoDataProcCalc(INT8U F,INT8U P,INT8U QxBl,INT8U *S,INT8U FRM)
{
	switch (F)
	{
	case 1://FuKong_Level2_Value ������/�޹�����ʾֵ��һ/�������޹�����ʾֵ���ܡ�����1~M��
		AllReportHead++;
		return 3;
	case 2://������/�޹�����ʾֵ����/�������޹�����ʾֵ���ܡ�����1~M��
		AllReportHead++;
		return 3;
	case 3://������/�޹��������������ʱ�䣨�ܡ�����1~M��
					AllReportHead++;
		return 3;
	case 4://������/�޹��������������ʱ�䣨�ܡ�����1~M��
					AllReportHead++;
		return 3;
	case 5://�����й����������ܡ�����1~M��
					AllReportHead++;
		return 3;
	case 6://�����޹����������ܡ�����1~M��
					AllReportHead++;
		return 3;
	case 7://�����й����������ܡ�����1~M��
					AllReportHead++;
		return 3;
	case 8://�����޹����������ܡ�����1~M��
					AllReportHead++;
		return 3;
	case 9://������/�޹�����ʾֵ��һ/�������޹�����ʾֵ���ܡ�����1~M��
					AllReportHead++;
		return 3;
	case 10://������/�޹�����ʾֵ����/�������޹�����ʾֵ���ܡ�����1~M��
					AllReportHead++;
		return 3;
	case 11://������/�޹��������������ʱ�䣨�ܡ�����1~M��
					AllReportHead++;
		return 3;
	case 12://������/�޹��������������ʱ�䣨�ܡ�����1~M��
					AllReportHead++;
		return 3;
	case 17://������/�޹�����ʾֵ��һ/�������޹�����ʾֵ���ܡ�����1~M��
					AllReportHead++;
		return 2;
	case 18://������/�޹�����ʾֵ����/�������޹�����ʾֵ���ܡ�����1~M��
					AllReportHead++;
		return 2;
	case 19://������/�޹��������������ʱ�䣨�ܡ�����1~M��
					AllReportHead++;
		return 2;
	case 20://������/�޹��������������ʱ�䣨�ܡ�����1~M��
					AllReportHead++;
		return 2;
	case 21://�����й����������ܡ�����1~M��
					AllReportHead++;
		return 2;
	case 22://�����޹����������ܡ�����1~M��
					AllReportHead++;
		return 2;
	case 23://�����й����������ܡ�����1~M��
					AllReportHead++;
		return 2;
	case 24://�����޹����������ܡ�����1~M
					AllReportHead++;
		return 2;
	case 25://���ܼ���������й����ʼ�����ʱ�䡢�й�����Ϊ��ʱ��
					AllReportHead++;
		return 3;
	case 26://���ܼ������������������ʱ��
					AllReportHead++;
		return 3;
	case 27://�յ�ѹͳ������
					AllReportHead++;
		return 3;
	case 28://�ղ�ƽ���Խ���ۼ�ʱ��
					AllReportHead++;
		return 3;
	case 29://�յ���Խ��ͳ��
					AllReportHead++;
		return 3;
	case 30://�����ڹ���Խ���ۼ�ʱ��
					AllReportHead++;
		return 3;
	case 31://�յ��ܱ���������
					AllReportHead++;
		return 3;
	case 33://���ܼ���������й����ʼ�����ʱ�䡢�й�����Ϊ��ʱ��
					AllReportHead++;
		return 2;
	case 34://���ܼ������й��������������ʱ��
					AllReportHead++;
		return 2;
	case 35://�µ�ѹͳ������
					AllReportHead++;
		return 2;
	case 36://�²�ƽ���Խ���ۼ�ʱ��
					AllReportHead++;
		return 2;
	case 37://�µ���Խ��ͳ��
					AllReportHead++;
		return 2;
	case 38://�����ڹ���Խ���ۼ�ʱ��
					AllReportHead++;
		return 2;
	case 41://������Ͷ���ۼ�ʱ��ʹ���
					AllReportHead++;
		return 3;
	case 42://�ա��µ������ۼƲ������޹�������
					AllReportHead++;
		return 3;
	case 43://�չ������������ۼ�ʱ��
					AllReportHead++;
		return 3;
	case 44://�¹������������ۼ�ʱ��
					AllReportHead++;
		return 2;
	case 49://�ն��չ���ʱ�䡢�ո�λ�ۼƴ���
					AllReportHead++;
		return 3;
	case 50://�ն��տ���ͳ������
					AllReportHead++;
		return 3;
	case 51://�ն��¹���ʱ�䡢�¸�λ�ۼƴ���
					AllReportHead++;
		return 2;
	case 52://�ն��¿���ͳ������
					AllReportHead++;
		return 2;
	case 57://�ܼ����������С�й����ʼ��䷢��ʱ�䣬�й�����Ϊ�����ۼ�ʱ��
					AllReportHead++;
		return 3;
	case 58://�ܼ������ۼ��й����������ܡ�����1~M��
					AllReportHead++;
		return 3;
	case 59://�ܼ������ۼ��޹����������ܡ�����1~M��
					AllReportHead++;
		return 3;
	case 60://�ܼ����������С�й����ʼ��䷢��ʱ�䣬�й�����Ϊ�����ۼ�ʱ��
					AllReportHead++;
		return 2;
	case 61://�ܼ������ۼ��й����������ܡ�����1~M��
					AllReportHead++;
		return 2;
	case 62://�ܼ������ۼ��޹����������ܡ�����1~M��
					AllReportHead++;
		return 2;
	case 65://�ܼ��鳬���ʶ�ֵ�����ۼ�ʱ�䡢���ۼƵ�����
					AllReportHead++;
		return 2;
	case 66://�ܼ��鳬�µ�������ֵ�����ۼ�ʱ�䡢�ۼƵ�����
					AllReportHead++;
		return 2;
	case 73://�ܼ����й���������
			if(S[6]<40)AllReportHead+=1;
			else if(S[6]<80)AllReportHead+=2;
			else AllReportHead+=3;
		return 7;
	case 74://�ܼ����޹���������
			if(S[6]<40)AllReportHead+=1;
			else if(S[6]<80)AllReportHead+=2;
			else AllReportHead+=3;
		return 7;
	case 75://�ܼ����й�����������
			if(S[6]<40)AllReportHead+=1;
			else if(S[6]<80)AllReportHead+=2;
			else AllReportHead+=3;
		return 7;
	case 76://�ܼ����޹�����������
			if(S[6]<40)AllReportHead+=1;
			else if(S[6]<80)AllReportHead+=2;
			else AllReportHead+=3;
		return 7;
	case 81://�й���������
			if(S[6]<40)AllReportHead+=1;
			else if(S[6]<80)AllReportHead+=2;
			else AllReportHead+=3;
		return 7;
	case 82://A���й���������
			if(S[6]<40)AllReportHead+=1;
			else if(S[6]<80)AllReportHead+=2;
			else AllReportHead+=3;
		return 7;
	case 83://B���й���������
			if(S[6]<40)AllReportHead+=1;
			else if(S[6]<80)AllReportHead+=2;
			else AllReportHead+=3;
		return 7;
	case 84://C���й���������
			if(S[6]<40)AllReportHead+=1;
			else if(S[6]<80)AllReportHead+=2;
			else AllReportHead+=3;
		return 7;
	case 85://�޹���������
			if(S[6]<40)AllReportHead+=1;
			else if(S[6]<80)AllReportHead+=2;
			else AllReportHead+=3;
		return 7;
	case 86://A���޹���������
			if(S[6]<40)AllReportHead+=1;
			else if(S[6]<80)AllReportHead+=2;
			else AllReportHead+=3;
		return 7;
	case 87://B���޹���������
			if(S[6]<40)AllReportHead+=1;
			else if(S[6]<80)AllReportHead+=2;
			else AllReportHead+=3;
		return 7;
	case 88://C���޹���������
			if(S[6]<40)AllReportHead+=1;
			else if(S[6]<80)AllReportHead+=2;
			else AllReportHead+=3;
		return 7;
	case 89://A���ѹ����
			if(S[6]<40)AllReportHead+=1;
			else if(S[6]<80)AllReportHead+=2;
			else AllReportHead+=3;
		return 7;
	case 90://B���ѹ����
			if(S[6]<40)AllReportHead+=1;
			else if(S[6]<80)AllReportHead+=2;
			else AllReportHead+=3;
		return 7;
	case 91://C���ѹ����
			if(S[6]<40)AllReportHead+=1;
			else if(S[6]<80)AllReportHead+=2;
			else AllReportHead+=3;
		return 7;
	case 92://A���������
			if(S[6]<40)AllReportHead+=1;
			else if(S[6]<80)AllReportHead+=2;
			else AllReportHead+=3;
		return 7;
	case 93://B���������
			if(S[6]<40)AllReportHead+=1;
			else if(S[6]<80)AllReportHead+=2;
			else AllReportHead+=3;
		return 7;
	case 94://C���������
			if(S[6]<40)AllReportHead+=1;
			else if(S[6]<80)AllReportHead+=2;
			else AllReportHead+=3;
		return 7;
	case 95://�����������
			if(S[6]<40)AllReportHead+=1;
			else if(S[6]<80)AllReportHead+=2;
			else AllReportHead+=3;
		return 7;
	case 97://�����й��ܵ�����
			if(S[6]<40)AllReportHead+=1;
			else if(S[6]<80)AllReportHead+=2;
			else AllReportHead+=3;
		return 7;
	case 98://�����޹��ܵ�����
			if(S[6]<40)AllReportHead+=1;
			else if(S[6]<80)AllReportHead+=2;
			else AllReportHead+=3;
		return 7;
	case 99://�����й��ܵ�����
			if(S[6]<40)AllReportHead+=1;
			else if(S[6]<80)AllReportHead+=2;
			else AllReportHead+=3;
		return 7;
	case 100://�����޹��ܵ�����
			if(S[6]<40)AllReportHead+=1;
			else if(S[6]<80)AllReportHead+=2;
			else AllReportHead+=3;
		return 7;
	case 101://�����й��ܵ���ʾֵ
			if(S[6]<40)AllReportHead+=1;
			else if(S[6]<80)AllReportHead+=2;
			else AllReportHead+=3;
		return 7;
	case 102://�����޹��ܵ���ʾֵ
			if(S[6]<40)AllReportHead+=1;
			else if(S[6]<80)AllReportHead+=2;
			else AllReportHead+=3;
		return 7;
	case 103://�����й��ܵ���ʾֵ
			if(S[6]<40)AllReportHead+=1;
			else if(S[6]<80)AllReportHead+=2;
			else AllReportHead+=3;
		return 7;
	case 104://�����޹��ܵ���ʾֵ
			if(S[6]<40)AllReportHead+=1;
			else if(S[6]<80)AllReportHead+=2;
			else AllReportHead+=3;
		return 7;
	case 105://�ܹ�������
			if(S[6]<40)AllReportHead+=1;
			else if(S[6]<80)AllReportHead+=2;
			else AllReportHead+=3;
		return 7;
	case 106://A�๦������
			if(S[6]<40)AllReportHead+=1;
			else if(S[6]<80)AllReportHead+=2;
			else AllReportHead+=3;
		return 7;
	case 107://B�๦������
			if(S[6]<40)AllReportHead+=1;
			else if(S[6]<80)AllReportHead+=2;
			else AllReportHead+=3;
		return 7;
	case 108://C�๦������
			if(S[6]<40)AllReportHead+=1;
			else if(S[6]<80)AllReportHead+=2;
			else AllReportHead+=3;
		return 7;
	case 113://A��2~19��г�����������ֵ������ʱ��
					AllReportHead++;
		return 3;
	case 114://B��2~19��г�����������ֵ������ʱ��
					AllReportHead++;
		return 3;
	case 115://C��2~19��г�����������ֵ������ʱ��
					AllReportHead++;
		return 3;
	case 116://A��2~19��г����ѹ�����ʼ��ܻ����������ֵ������ʱ��
					AllReportHead++;
		return 3;
	case 117://B��2~19��г����ѹ�����ʼ��ܻ����������ֵ������ʱ��
					AllReportHead++;
		return 3;
	case 118://C��2~19��г����ѹ�����ʼ��ܻ����������ֵ������ʱ��
					AllReportHead++;
		return 3;
	case 121://A��г��Խ����ͳ������
					AllReportHead++;
		return 3;
	case 122://B��г��Խ����ͳ������
					AllReportHead++;
		return 3;
	case 123://C��г��Խ����ͳ������
					AllReportHead++;
		return 3;
	case 129://ֱ��ģ����Խ�����ۼ�ʱ�䡢���/��Сֵ������ʱ��
					AllReportHead++;
		return 3;
	case 130://ֱ��ģ����Խ�����ۼ�ʱ�䡢���/��Сֵ������ʱ��
					AllReportHead++;
		return 2;
	case 138://ֱ��ģ������������
					AllReportHead++;
		return 7;
	}
	return 0;
}

/***********************************************************************
*4.9	����2�����ݣ�AFN=0CH��
*���ú���:AskTwoLevelData();
*�ص�����:��
***********************************************************************/
INT8U CallTwoDataProc(INT8U F,INT8U P,INT8U QxBl,INT8U *S,INT8U FRM)
{
	DebugOut("\r\n%s p=%d f=%d ","���Ͷ�������",P,F);
	switch (F)
	{
	case 1://�ն���������/�޹�����ʾֵ��һ/�������޹�����ʾֵ���ܡ�����1~M��
		Set_Level2_F1(F,P,S,FRM);
		return 3;
	case 2://�ն��ᷴ����/�޹�����ʾֵ����/�������޹�����ʾֵ���ܡ�����1~M��
		Set_Level2_F2(F,P,S,FRM);
		return 3;
	case 3://�ն���������/�޹��������������ʱ�䣨�ܡ�����1~M��
		Set_Level2_F3(F,P,S,FRM);
		return 3;
	case 4://�ն��ᷴ����/�޹��������������ʱ�䣨�ܡ�����1~M��
		Set_Level2_F4(F,P,S,FRM);
		return 3;
	case 5://�ն��������й����������ܡ�����1~M��
		Set_Level2_F5(F,P,S,FRM);
		return 3;
	case 6://�ն��������޹����������ܡ�����1~M��
		Set_Level2_F6(F,P,S,FRM);
		return 3;
	case 7://�ն��ᷴ���й����������ܡ�����1~M��
		Set_Level2_F7(F,P,S,FRM);
		return 3;
	case 8://�ն��ᷴ���޹����������ܡ�����1~M��
		Set_Level2_F8(F,P,S,FRM);
		return 3;
	case 9://�����ն���������/�޹�����ʾֵ��һ/�������޹�����ʾֵ���ܡ�����1~M��
		Set_Level2_F9(F,P,S,FRM);
		return 3;
	case 10://�����ն��ᷴ����/�޹�����ʾֵ����/�������޹�����ʾֵ���ܡ�����1~M��
		Set_Level2_F10(F,P,S,FRM);
		return 3;
	case 11://�����ն���������/�޹��������������ʱ�䣨�ܡ�����1~M��
		Set_Level2_F11(F,P,S,FRM);
		return 3;
	case 12://�����ն��ᷴ����/�޹��������������ʱ�䣨�ܡ�����1~M��
		Set_Level2_F12(F,P,S,FRM);
		return 3;
	case 17://�¶���������/�޹�����ʾֵ��һ/�������޹�����ʾֵ���ܡ�����1~M��
		Set_Level2_F17(F,P,S,FRM);
		return 2;
	case 18://�¶��ᷴ����/�޹�����ʾֵ����/�������޹�����ʾֵ���ܡ�����1~M��
		Set_Level2_F18(F,P,S,FRM);
		return 2;
	case 19://�¶���������/�޹��������������ʱ�䣨�ܡ�����1~M��
		Set_Level2_F19(F,P,S,FRM);
		return 2;
	case 20://�¶��ᷴ����/�޹��������������ʱ�䣨�ܡ�����1~M��
		Set_Level2_F20(F,P,S,FRM);
		return 2;
	case 21://�¶��������й����������ܡ�����1~M��
		Set_Level2_F21(F,P,S,FRM);
		return 2;
	case 22://�¶��������޹����������ܡ�����1~M��
		Set_Level2_F22(F,P,S,FRM);
		return 2;
	case 23://�¶��ᷴ���й����������ܡ�����1~M��
		Set_Level2_F23(F,P,S,FRM);
		return 2;
	case 24://�¶��ᷴ���޹����������ܡ�����1~M��
		Set_Level2_F24(F,P,S,FRM);
		return 2;
	case 25://���ܼ���������й����ʼ�����ʱ�䡢�й�����Ϊ��ʱ��
		Set_Level2_F25(F,P,S,FRM);
		return 3;
	case 26://���ܼ������������������ʱ��
		Set_Level2_F26(F,P,S,FRM);
		return 3;
	case 27://�յ�ѹͳ������
		Set_Level2_F27(F,P,S,FRM);
		return 3;
	case 28://�ղ�ƽ���Խ���ۼ�ʱ��
		Set_Level2_F28(F,P,S,FRM);
		return 3;
	case 29://�յ���Խ��ͳ��
		Set_Level2_F29(F,P,S,FRM);
		return 3;
	case 30://�����ڹ���Խ���ۼ�ʱ��
		Set_Level2_F30(F,P,S,FRM);
		return 3;
	case 31://�ո�����ͳ��
		Set_Level2_F31(F,P,S,FRM);
		return 3;
	case 32://�ն�����ܱ���������
		Set_Level2_F32(F,P,S,FRM);
		return 3;
	case 33://���ܼ���������й����ʼ�����ʱ�䡢�й�����Ϊ��ʱ��
		Set_Level2_F33(F,P,S,FRM);
		return 2;
	case 34://���ܼ������й��������������ʱ��
		Set_Level2_F34(F,P,S,FRM);
		return 2;
	case 35://�µ�ѹͳ������

		Set_Level2_F35(F,P,S,FRM);
		return 2;
	case 36://�²�ƽ���Խ���ۼ�ʱ��
		Set_Level2_F36(F,P,S,FRM);
		return 2;
	case 37://�µ���Խ��ͳ��
		Set_Level2_F37(F,P,S,FRM);
		return 2;
	case 38://�����ڹ���Խ���ۼ�ʱ��
		Set_Level2_F38(F,P,S,FRM);
		return 2;
	case 41://�յ�����Ͷ���ۼ�ʱ��ʹ���
		SendNAK(F,P,0x0d);
		return 3;
	case 42://�ա��µ������ۼƲ������޹�������
		SendNAK(F,P,0x0d);
		return 3;
	case 43://�չ������������ۼ�ʱ��
		SendNAK(F,P,0x0d);
		return 3;
	case 44://�¹������������ۼ�ʱ��
		Set_Level2_F44(F,P,S,FRM);
		return 2;
	case 49://�ն��չ���ʱ�䡢�ո�λ�ۼƴ���
		Set_Level2_F49(F,P,S,FRM);
		return 3;
	case 50://�ն��տ���ͳ������
		Set_Level2_F50(F,P,S,FRM);
		return 3;
	case 51://�ն��¹���ʱ�䡢�¸�λ�ۼƴ���
		Set_Level2_F51(F,P,S,FRM);
		return 2;
	case 52://�ն��¿���ͳ������
		Set_Level2_F52(F,P,S,FRM);
		return 2;
	case 53://�ն��¿���ͳ������
		Set_Level2_F53(F,P,S,FRM);
		return 3;
	case 54://�ն��¿���ͳ������
		Set_Level2_F54(F,P,S,FRM);
		return 2;
	case 57://�ܼ����������С�й����ʼ��䷢��ʱ�䣬�й�����Ϊ�����ۼ�ʱ��
		Set_Level2_F57(F,P,S,FRM);
		return 3;
	case 58://�ܼ������ۼ��й����������ܡ�����1~M��
		Set_Level2_F58(F,P,S,FRM);
		return 3;
	case 59://�ܼ������ۼ��޹����������ܡ�����1~M��
		Set_Level2_F59(F,P,S,FRM);
		return 3;
	case 60://�ܼ����������С�й����ʼ��䷢��ʱ�䣬�й�����Ϊ�����ۼ�ʱ��
		Set_Level2_F60(F,P,S,FRM);
		return 2;
	case 61://�ܼ������ۼ��й����������ܡ�����1~M��
		Set_Level2_F61(F,P,S,FRM);
		return 2;
	case 62://�ܼ������ۼ��޹����������ܡ�����1~M��
		Set_Level2_F62(F,P,S,FRM);
		return 2;
	case 65://�ܼ��鳬���ʶ�ֵ�����ۼ�ʱ�䡢���ۼƵ�����
		SendNAK(F,P,0x0d);
		return 2;
	case 66://�ܼ��鳬�µ�������ֵ�����ۼ�ʱ�䡢�ۼƵ�����
		SendNAK(F,P,0x0d);
		return 2;
	case 73://�ܼ����й���������
		Set_Level2_F73(F,P,S,FRM);
		return 7;
	case 74://�ܼ����޹���������
		Set_Level2_F74(F,P,S,FRM);
		return 7;
	case 75://�ܼ����й�����������
		Set_Level2_F75(F,P,S,FRM);
		return 7;
	case 76://�ܼ����޹�����������
		Set_Level2_F76(F,P,S,FRM);
		return 7;
	case 81://�й���������
		Set_Level2_F81(F,P,S,FRM);
		return 7;
	case 82://A���й���������
		Set_Level2_F81(F,P,S,FRM);
		return 7;
	case 83://B���й���������
		Set_Level2_F81(F,P,S,FRM);
		return 7;
	case 84://C���й���������
		Set_Level2_F81(F,P,S,FRM);
		return 7;
	case 85://�޹���������
		Set_Level2_F81(F,P,S,FRM);
		return 7;
	case 86://A���޹���������
		Set_Level2_F81(F,P,S,FRM);
		return 7;
	case 87://B���޹���������
		Set_Level2_F81(F,P,S,FRM);
		return 7;
	case 88://C���޹���������
		Set_Level2_F81(F,P,S,FRM);
		return 7;
	case 89://A���ѹ����
		Set_Level2_F89(F,P,S,FRM);
		return 7;
	case 90://B���ѹ����
		Set_Level2_F89(F,P,S,FRM);
		return 7;
	case 91://C���ѹ����
		Set_Level2_F89(F,P,S,FRM);
		return 7;
	case 92://A���������
		Set_Level2_F92(F,P,S,FRM);
		return 7;
	case 93://B���������
		Set_Level2_F92(F,P,S,FRM);
		return 7;
	case 94://C���������
		Set_Level2_F92(F,P,S,FRM);
		return 7;
	case 95://�����������
		Set_Level2_F92(F,P,S,FRM);
		return 7;
	case 97://�����й��ܵ���������
		Set_Level2_F97(F,P,S,FRM);
		return 7;
	case 98://�����޹��ܵ���������
		Set_Level2_F97(F,P,S,FRM);
		return 7;
	case 99://�����й��ܵ���������
		Set_Level2_F97(F,P,S,FRM);
		return 7;
	case 100://�����޹��ܵ���������
		Set_Level2_F97(F,P,S,FRM);
		return 7;
	case 101://�����й��ܵ���ʾֵ����
		Set_Level2_F101(F,P,S,FRM);
		return 7;
	case 102://�����޹��ܵ���ʾֵ����
		Set_Level2_F101(F,P,S,FRM);
		return 7;
	case 103://�����й��ܵ���ʾֵ����
		Set_Level2_F101(F,P,S,FRM);
		return 7;
	case 104://�����޹��ܵ���ʾֵ����
		Set_Level2_F101(F,P,S,FRM);
		return 7;
	case 105://�ܹ�����������
		Set_Level2_F105(F,P,S,FRM);
		return 7;
	case 106://A�๦����������
		Set_Level2_F105(F,P,S,FRM);
		return 7;
	case 107://B�๦����������
		Set_Level2_F105(F,P,S,FRM);
		return 7;
	case 108://C�๦����������
		Set_Level2_F105(F,P,S,FRM);
		return 7;
	case 113://A��2~19��г�����������ֵ������ʱ��
		Set_Level2_F113(F,P,S,FRM);
		return 3;
	case 114://B��2~19��г�����������ֵ������ʱ��
		Set_Level2_F114(F,P,S,FRM);
		return 3;
	case 115://C��2~19��г�����������ֵ������ʱ��
		Set_Level2_F115(F,P,S,FRM);
		return 3;
	case 116://A��2~19��г����ѹ�����ʼ��ܻ����������ֵ������ʱ��
		Set_Level2_F116(F,P,S,FRM);
		return 3;
	case 117://B��2~19��г����ѹ�����ʼ��ܻ����������ֵ������ʱ��
		Set_Level2_F117(F,P,S,FRM);
		return 3;
	case 118://C��2~19��г����ѹ�����ʼ��ܻ����������ֵ������ʱ��
		Set_Level2_F118(F,P,S,FRM);
		return 3;
	case 121://A��г��Խ����ͳ������
		Set_Level2_F121(F,P,S,FRM);
		return 3;
	case 122://B��г��Խ����ͳ������
		Set_Level2_F122(F,P,S,FRM);
		return 3;
	case 123://C��г��Խ����ͳ������
		Set_Level2_F123(F,P,S,FRM);
		return 3;
	case 129://ֱ��ģ����Խ�����ۼ�ʱ�䡢���/��Сֵ������ʱ��
		SendNAK(F,P,0x0d);
		return 3;
	case 130://ֱ��ģ����Խ�����ۼ�ʱ�䡢���/��Сֵ������ʱ��
		SendNAK(F,P,0x0d);
		return 2;
	case 138://ֱ��ģ������������
		SendNAK(F,P,0x0d);
		return 7;
	case 161://�ն��������й�����ʾֵ���ܡ�����1~M��
		Set_Level2_F161(F,P,S,FRM);
		return 3;
	case 162://�ն��������޹�����ʾֵ���ܡ�����1~M��
		Set_Level2_F162(F,P,S,FRM);
		return 3;
	case 163://�ն��ᷴ���й�����ʾֵ���ܡ�����1~M��
		Set_Level2_F163(F,P,S,FRM);
		return 3;
	case 164://�ն��ᷴ���޹�����ʾֵ���ܡ�����1~M��
		Set_Level2_F164(F,P,S,FRM);
		return 3;
	case 165://�ն���һ�����޹�����ʾֵ���ܡ�����1~M��
		Set_Level2_F165(F,P,S,FRM);
		return 3;
	case 166://�ն���������޹�����ʾֵ���ܡ�����1~M��
		Set_Level2_F166(F,P,S,FRM);
		return 3;
	case 167://�ն����������޹�����ʾֵ���ܡ�����1~M��
		Set_Level2_F167(F,P,S,FRM);
		return 3;
	case 168://�ն����������޹�����ʾֵ���ܡ�����1~M��
		Set_Level2_F168(F,P,S,FRM);
		return 3;
	case 169://�����ն��������й�����ʾֵ���ܡ�����1~M��
		Set_Level2_F161(F,P,S,FRM);
		return 3;
	case 170://�����ն��������޹�����ʾֵ���ܡ�����1~M��
		Set_Level2_F162(F,P,S,FRM);
		return 3;
	case 171://�����ն��ᷴ���й�����ʾֵ���ܡ�����1~M��
		Set_Level2_F163(F,P,S,FRM);
		return 3;
	case 172://�����ն��ᷴ���޹�����ʾֵ���ܡ�����1~M��
		Set_Level2_F164(F,P,S,FRM);
		return 3;
	case 173://�����ն���һ�����޹�����ʾֵ���ܡ�����1~M��
		Set_Level2_F165(F,P,S,FRM);
		return 3;
	case 174://�����ն���������޹�����ʾֵ���ܡ�����1~M��
		Set_Level2_F166(F,P,S,FRM);
		return 3;
	case 175://�����ն����������޹�����ʾֵ���ܡ�����1~M��
		Set_Level2_F167(F,P,S,FRM);
		return 3;
	case 176://�����ն����������޹�����ʾֵ���ܡ�����1~M��
		Set_Level2_F168(F,P,S,FRM);
		return 3;
	case 177://�¶��������й�����ʾֵ���ܡ�����1~M��
		Set_Level2_F177(F,P,S,FRM);
		return 2;
	case 178://�¶��������޹�����ʾֵ���ܡ�����1~M��
		Set_Level2_F178(F,P,S,FRM);
		return 2;
	case 179://�¶��ᷴ���й�����ʾֵ���ܡ�����1~M��
		Set_Level2_F179(F,P,S,FRM);
		return 2;
	case 180://�¶��ᷴ���޹�����ʾֵ���ܡ�����1~M��
		Set_Level2_F180(F,P,S,FRM);
		return 2;
	case 181://�¶���һ�����޹�����ʾֵ���ܡ�����1~M��
		Set_Level2_F181(F,P,S,FRM);
		return 2;
	case 182://�¶���������޹�����ʾֵ���ܡ�����1~M��
		Set_Level2_F182(F,P,S,FRM);
		return 2;
	case 183://�¶����������޹�����ʾֵ���ܡ�����1~M��
		Set_Level2_F183(F,P,S,FRM);
		return 2;
	case 184://�¶����������޹�����ʾֵ���ܡ�����1~M��
		Set_Level2_F184(F,P,S,FRM);
		return 2;
	case 185://�ն��������й��������������ʱ�䣨�ܡ�����1~M��
		Set_Level2_F185(F,P,S,FRM);
		return 3;
	case 186://�ն��������޹��������������ʱ�䣨�ܡ�����1~M��
		Set_Level2_F186(F,P,S,FRM);
		return 3;
	case 187://�ն��ᷴ���й��������������ʱ�䣨�ܡ�����1~M��
		Set_Level2_F187(F,P,S,FRM);
		return 3;
	case 188://�ն��ᷴ���޹��������������ʱ�䣨�ܡ�����1~M��
		Set_Level2_F188(F,P,S,FRM);
		return 3;
	case 189://�����ն��������й��������������ʱ�䣨�ܡ�����1~M��
		Set_Level2_F185(F,P,S,FRM);
		return 3;
	case 190://�����ն��������޹��������������ʱ�䣨�ܡ�����1~M��
		Set_Level2_F186(F,P,S,FRM);
		return 3;
	case 191://�����ն��ᷴ���й��������������ʱ�䣨�ܡ�����1~M��
		Set_Level2_F187(F,P,S,FRM);
		return 3;
	case 192://�����ն��ᷴ���޹��������������ʱ�䣨�ܡ�����1~M��
		Set_Level2_F188(F,P,S,FRM);
		return 3;
	default:
		SendNAK(F,P,0x0d);
		return 7;
	}
	return 0;
}
int CalcFrameCount(int ii)
{
	int count=0;
	int j,k,l;
	for(j=0;j<RtuDataAddr->Task_Value[ii].F66_Set_Para.ShuJv_DanYuan_Num;j++)
	{
		GetDa(RtuDataAddr->Task_Value[ii].F66_Set_Para.DanYuan_BiaoShi[j][0],RtuDataAddr->Task_Value[ii].F66_Set_Para.DanYuan_BiaoShi[j][1]);
		GetDt(RtuDataAddr->Task_Value[ii].F66_Set_Para.DanYuan_BiaoShi[j][2],RtuDataAddr->Task_Value[ii].F66_Set_Para.DanYuan_BiaoShi[j][3]);
		for(k=0;k<64;k++)
		{
			if(DA[k]==1)
			{
				for(l=0;l<255;l++)
				{
					if(DT[l]==1)
					{
						count++;
						CleardeadCount(PORT_ID);
					}
				}
			}
		}
	}//
	return count;;
}
void mydelays(int sec)
{
	int i;
	for(i=0;i<sec;i++)
	{
		delay(1000);
		CleardeadCount(PORT_ID);
		SelfheartCount = 0;
	}
}
void SetTsktime(int l,TS ts,INT8U zqdw)
{
	if(
	(l<=12)
	||((l>=25)&&(l<=31))
	||((l>=41)&&(l<=43))
	||((l>=45)&&(l<=50))
	||(l==53)
	||(l==57)
	||(l==58)
	||(l==59)
	||((l>=161)&&(l<=176))
	||((l>=185)&&(l<=192)))
	{
		TestTwo[3]=0;
		TestTwo[4]=0;
		TestTwo[5]=0;
		TestTwo[6]=0;

		if(ts.Day==1)
		{
			if(ts.Month==1)
			{
				TestTwo[0]=((31/10)<<4)+(31%10);
				TestTwo[1]=((12/10)<<4)+(12%10);
				TestTwo[2]=((((ts.Year-1)%100)/10)<<4)+((ts.Year-1)%10);
			}
			else
				if(ts.Month==2||ts.Month==4||ts.Month==6||ts.Month==8||ts.Month==9||ts.Month==11)
				{
					TestTwo[0]=((31/10)<<4)+(31%10);
					TestTwo[1]=((((ts.Month-1)/10)<<4)+((ts.Month-1)%10));
					TestTwo[2]=(((ts.Year%100)/10)<<4)+(ts.Year%10);
				}
				else
					if(ts.Month==3)
					{
						TestTwo[0]=((28/10)<<4)+(28%10);
						TestTwo[1]=((((ts.Month-1)/10)<<4)+((ts.Month-1)%10));
						TestTwo[2]=(((ts.Year%100)/10)<<4)+(ts.Year%10);
					}
					else
						if(ts.Month==5||ts.Month==7||ts.Month==10||ts.Month==12)
						{
							TestTwo[0]=((30/10)<<4)+(30%10);
							TestTwo[1]=((((ts.Month-1)/10)<<4)+((ts.Month-1)%10));
							TestTwo[2]=(((ts.Year%100)/10)<<4)+(ts.Year%10);
						}
		}
		else
		{
			TestTwo[0]=(((ts.Day-1)/10)<<4)+((ts.Day-1)%10);
			TestTwo[1]=(((ts.Month/10)<<4)+(ts.Month%10));
			TestTwo[2]=(((ts.Year%100)/10)<<4)+(ts.Year%10);
		}

	}
	if(
	((l>=17)&&(l<=24))
	||((l>=33)&&(l<=38))
	||(l==44)
	||(l==51)
	||(l==52)
	||(l==54)
	||((l>=60)&&(l<=66))
	||((l>=177)&&(l<=184)))
	{
		TestTwo[2]=0;
		TestTwo[3]=0;
		TestTwo[4]=0;
		TestTwo[5]=0;
		TestTwo[6]=0;
		if(ts.Month==1)
		{
			TestTwo[0]=((12/10)<<4)+(12%10);
			TestTwo[1]=((((ts.Year-1)%100)/10)<<4)+((ts.Year-1)%10);
		}
		else
		{
			TestTwo[0]=((((ts.Month-1)/10)<<4)+((ts.Month-1)%10));
			TestTwo[1]=(((ts.Year%100)/10)<<4)+(ts.Year%10);
		}
	}
	if((l>=73)&&(l<=108))
		{
		if (zqdw==1)
		{
			TestTwo[0]= 0;
		}else
			TestTwo[0]=((ts.Minute/10)<<4)+(ts.Minute%10);

		//TestTwo[0]=((ts.Minute/10)<<4)+(ts.Minute%10);
		TestTwo[1]=((ts.Hour/10)<<4)+(ts.Hour%10);
		TestTwo[2]=((ts.Day/10)<<4)+(ts.Day%10);
		TestTwo[3]=(((ts.Month/10)<<4)+(ts.Month%10));
		TestTwo[4]=(((ts.Year%100)/10)<<4)+(ts.Year%10);
		////TestTwo[5]=1;
		////TestTwo[6]=96;
		TestTwo[5]=3;
		TestTwo[6]=1;
	}
}
void SetFrameCount(int i,int j,TS ts,INT8U zqdw)
{
	int k,L;
	int TailSendOk = 0;

	AllReportTail=0;AllReportHead=0;
	//MY_MKLevel2Head(0xc4);
	SendLen =0;
	SendLen=SendLen+14;
	GetDa(RtuDataAddr->Task_Value[i].F66_Set_Para.DanYuan_BiaoShi[j][0],RtuDataAddr->Task_Value[i].F66_Set_Para.DanYuan_BiaoShi[j][1]);
	GetDt(RtuDataAddr->Task_Value[i].F66_Set_Para.DanYuan_BiaoShi[j][2],RtuDataAddr->Task_Value[i].F66_Set_Para.DanYuan_BiaoShi[j][3]);
	for(k=0;k<64;k++)
	{//������
		if(DA[k]==1)
		{
			for(L=0;L<255;L++)
			{//������
				if(DT[L]==1)
				{	// k:������     l:������
					SetTsktime(L,ts,zqdw);	   			//����ʱ��
					CallTwoDataProc(L,k,0,TestTwo,0xc4);//������ݵ�Ԫ
					TailSendOk = 0;
				}
			}
		}
		//����ĳ��������ȫ����������֯��ϣ��ж��Ƿ��ֽڳ�����ֵ��������ޱ��뷢�͸�֡
		if (SendLen > FRAME_MAX_LENGTH)//
		{
			AllReportHead++;
			TailSendOk = 1;
			SendLen =0;
			SendLen = SendLen + 14;
		}
	}
	if(TailSendOk == 0)
	{
		AllReportHead++;
	}
}
void MY_MKLevel2Head(INT8U FRM)
{
	FrameHeadCreate(FRM);
	SendBuff[SendLen++]=0x0d;//afn
	if(NeedTp)
		SendBuff[SendLen++]=(TestFirFin(1,1)|(seq&0x0f))|0x80;//seq
	else
		SendBuff[SendLen++]=(TestFirFin(1,1)|(seq&0x0f))&0x7f;//seq
}
void MY_MKDataUnitFlag(INT8U P,INT8U F)
{
	SendBuff[SendLen++]=SetDa1(P);//Tmp130Buff[14];//da1e
	SendBuff[SendLen++]=SetDa2(P);//Tmp130Buff[15];//da2
	SendBuff[SendLen++]=SetDt1(F);//Tmp130Buff[16];//dt1
	SendBuff[SendLen++]=SetDt2(F);//Tmp130Buff[17];//dt2
}
INT8U autoReportTwoLevelData()
{
	//int  TailSendOk;
	INT8U i,j,k,l;//,L;
	INT8U Min,Hour,Day,Month,zqdw,zqvalue,delta=0;
	delay(1000);

	DebugOut("\r\n%s ","�������������ϱ�");
	////if(RtuDataAddr->FuKong_Control_Value.F29_Control_Para.Valid==1)
	{
		for(i=0;i<Task_Max;i++)
		{
			SelfheartCount = 0;
			if(RtuDataAddr->Task_Value[i].F68_Set_Para.Valid==1)
			{
				if(RtuDataAddr->Task_Value[i].F68_Set_Para.type_2_Task_Enable==0x55)
				{
					if(RtuDataAddr->Task_Value[i].F66_Set_Para.Valid==1)
					{
						if(testTime(RtuDataAddr->Task_Value[i].F66_Set_Para.Ji_Zhun_Shi_Jian))
						{
							delta=0;
							TS ts;
							TSGet(&ts);
							Min=(RtuDataAddr->Task_Value[i].F66_Set_Para.Ji_Zhun_Shi_Jian[1]>>4)*10;
							Min=Min+RtuDataAddr->Task_Value[i].F66_Set_Para.Ji_Zhun_Shi_Jian[1]&0x0f;
							Hour=(RtuDataAddr->Task_Value[i].F66_Set_Para.Ji_Zhun_Shi_Jian[2]>>4)*10;
							Hour=Hour+RtuDataAddr->Task_Value[i].F66_Set_Para.Ji_Zhun_Shi_Jian[2]&0x0f;
							Day=(RtuDataAddr->Task_Value[i].F66_Set_Para.Ji_Zhun_Shi_Jian[3]>>4)*10;
							Day=Day+RtuDataAddr->Task_Value[i].F66_Set_Para.Ji_Zhun_Shi_Jian[3]&0x0f;
							Month=((RtuDataAddr->Task_Value[i].F66_Set_Para.Ji_Zhun_Shi_Jian[4]>>4)&1)*10;
							Month=Month+RtuDataAddr->Task_Value[i].F66_Set_Para.Ji_Zhun_Shi_Jian[4]&0x0f;
							zqdw=RtuDataAddr->Task_Value[i].F66_Set_Para.FaSong_ZhouQi>>6;
							zqvalue=RtuDataAddr->Task_Value[i].F66_Set_Para.FaSong_ZhouQi&0x3f;
							DebugOut("\r\n%s%d  zqdw%d zq%d %d ","�������������ϱ�", i,zqdw,zqvalue,task2_Delay_Count[i]);
							if(zqdw==0)
							{
								DebugOut("\n\rts.Minute=%d,task2_Delay_Count[i]=%d",ts.Minute,task2_Delay_Count[i]);
								DebugOut("\n\rts.Minute=%d,task2_Delay_Count[i]=%d",ts.Minute,task2_Delay_Count[i]);
								if(zqvalue!=0)
									if(((ts.Minute+60-task2_Delay_Count[i])%zqvalue)!=0)
										continue;
									else
										task2_Delay_Count[i]=ts.Minute;
							}
							if(zqdw==1)
							{
								DebugOut("\n\rts.Hour=%d,task2_Delay_Count[i]=%d",ts.Hour,task2_Delay_Count[i]);
								DebugOut("\n\rts.Hour=%d,task2_Delay_Count[i]=%d",ts.Hour,task2_Delay_Count[i]);
								if(zqvalue!=0)
									if(zqvalue==1)
									{
										if(ts.Hour>task2_Delay_Count[i])
											delta=ts.Hour-task2_Delay_Count[i];
										if(ts.Hour<task2_Delay_Count[i])
										{
											if((ts.Hour==0)&&(task2_Delay_Count[i]==23))
												delta=1;
											else
												delta=task2_Delay_Count[i]-ts.Hour;
										}
										if((delta==1)||((task2_Delay_Count[i]==0)&&(ts.Hour!=0)))
										{
											DebugOut(" in hourtask do ts.Minute =%d  Minute = %d",ts.Minute,Min);
											if (ts.Minute >= Min)
												task2_Delay_Count[i]=ts.Hour;
											else
												continue;
											//task2_Delay_Count[i]=ts.Hour;
										}
										else{
											if(delta!=0)
												task2_Delay_Count[i]=0;
											continue;
										}
									}
									else
									{
										//if(((((ts.Hour+24-task2_Delay_Count[i])%24)%zqvalue)!=0)&&((ts.Hour+24-task2_Delay_Count[i])%24<zqvalue))
										if((((ts.Hour+24-task2_Delay_Count[i])%24)!=zqvalue)&&((ts.Hour+24-task2_Delay_Count[i])%24<zqvalue))
										{
											continue;
										}
										else
										{
											task2_Delay_Count[i]=ts.Hour;
										}
									}
							}
							if(zqdw==2)
							{
								DebugOut("\n\rts.Day=%d,task2_Delay_Count[i]=%d",ts.Day,task2_Delay_Count[i]);
								DebugOut("\n\rts.Day=%d,task2_Delay_Count[i]=%d",ts.Day,task2_Delay_Count[i]);
								if(zqvalue!=0)
									if(zqvalue==1)
									{
										if(ts.Day>task2_Delay_Count[i])
											delta=ts.Day-task2_Delay_Count[i];
										if(ts.Day<task2_Delay_Count[i])
											delta=task2_Delay_Count[i]-ts.Day;
										if((delta==1)||task2_Delay_Count[i]==0)
										{
											DebugOut(" in daytask do ts.hour =%d  Hour = %d",ts.Hour,Hour);
											if (ts.Hour >= Hour)
												task2_Delay_Count[i]=ts.Day;
											else
												continue;
											//task2_Delay_Count[i]=ts.Day;
										}
										else{
											if(delta!=0)
												task2_Delay_Count[i]=0;
											continue;
										}
									}
									else
									{
										//if((((ts.Day+31-task2_Delay_Count[i])%31)%zqvalue)!=0)
										if((((ts.Day+31-task2_Delay_Count[i])%31)!=zqvalue)&&((ts.Day+31-task2_Delay_Count[i])%31<zqvalue))
											continue;
										else
											task2_Delay_Count[i]=ts.Day;
									}
							}
							if(zqdw==3)
							{
								DebugOut("\n\rts.Month=%d,task2_Delay_Count[i]=%d",ts.Month,task2_Delay_Count[i]);
								DebugOut("\n\rts.Month=%d,task2_Delay_Count[i]=%d",ts.Month,task2_Delay_Count[i]);
								if(zqvalue!=0)
									if(zqvalue==1)
									{
										if(ts.Month>task2_Delay_Count[i])
											delta=ts.Month-task2_Delay_Count[i];
										if(ts.Month<task2_Delay_Count[i])
											delta=task2_Delay_Count[i]-ts.Month;
										if((delta==1)||task2_Delay_Count[i]==0)
										{
											DebugOut(" in Monthtask do ts.Day =%d  Day = %d",ts.Day,Day);
											if (ts.Day >= Day)
												task2_Delay_Count[i]=ts.Month;
											else
												continue;
											//task2_Delay_Count[i]=ts.Month;
										}
										else{
											if(delta!=0)
												task2_Delay_Count[i]=0;
											continue;
										}
									}
									else
									{
										//if((((ts.Month+12-task2_Delay_Count[i])%12)%zqvalue)!=0)
										if((((ts.Month+12-task2_Delay_Count[i])%12)!=zqvalue)&&((ts.Month+12-task2_Delay_Count[i])%12<zqvalue))
											continue;
										else
											task2_Delay_Count[i]=ts.Month;
									}
							}
//							//-------------------------------------
//
//							for(j=0;j<RtuDataAddr->Task_Value[i].F66_Set_Para.ShuJv_DanYuan_Num;j++)
//							{
//								SetFrameCount(i,j,ts,zqdw); //����ĳ�����ݵ�Ԫ������֡������
//								printf("\n ���� %d  ������%d    ֡����%d \n",i,j,AllReportHead);
//								CleardeadCount();
//								SelfheartCount = 0;
//								MY_MKLevel2Head(0xc4);		//����֡ͷ  ��������ÿ�����ݵ�Ԫ����һ��Ӧ��֡
//								TailSendOk = 0;
//								GetDa(RtuDataAddr->Task_Value[i].F66_Set_Para.DanYuan_BiaoShi[j][0],RtuDataAddr->Task_Value[i].F66_Set_Para.DanYuan_BiaoShi[j][1]);
//								GetDt(RtuDataAddr->Task_Value[i].F66_Set_Para.DanYuan_BiaoShi[j][2],RtuDataAddr->Task_Value[i].F66_Set_Para.DanYuan_BiaoShi[j][3]);
//								for(k=0;k<64;k++)
//								{//������
//									if(DA[k]==1)
//									{
//										for(L=0;L<255;L++)
//										{//������
//											if(DT[L]==1)
//											{	// k:������     l:������
//												MY_MKDataUnitFlag(k,L);				//���ݵ�Ԫ��ʶ��һ��Ӧ��֡�а������ɸ����ݵ�Ԫ��ʶ
//												SetTsktime(L,ts,zqdw);	   			//����ʱ��
//												CallTwoDataProc(L,k,0,TestTwo,0xc4);//������ݵ�Ԫ
//												CleardeadCount(PORT_ID);
//												SelfheartCount = 0;
//												TailSendOk = 0;
//											}
//										}
//									}
//									//����ĳ��������ȫ����������֯��ϣ��ж��Ƿ��ֽڳ�����ֵ��������ޱ��뷢�͸�֡
//									if (SendLen > FRAME_MAX_LENGTH)
//									{
//										EC(); TP(); FrameTailCreate_Send();
//										TailSendOk = 1;
//										mydelays(5);
//
//										MY_MKLevel2Head(0xc4);//��������֡ͷ
//									}
//								}
//								if(TailSendOk == 0)
//								{
//									EC(); TP(); FrameTailCreate_Send(0);
//									mydelays(5);
//								}
//							}//end fro DanYuan_Num
//							//-------------------------------------


							for(j=0;j<RtuDataAddr->Task_Value[i].F66_Set_Para.ShuJv_DanYuan_Num;j++)
							{
								GetDa(RtuDataAddr->Task_Value[i].F66_Set_Para.DanYuan_BiaoShi[j][0],RtuDataAddr->Task_Value[i].F66_Set_Para.DanYuan_BiaoShi[j][1]);
								GetDt(RtuDataAddr->Task_Value[i].F66_Set_Para.DanYuan_BiaoShi[j][2],RtuDataAddr->Task_Value[i].F66_Set_Para.DanYuan_BiaoShi[j][3]);
								SelfheartCount = 0;
								delay(60);
								for(k=0;k<64;k++)
								{
									if(DA[k]==1)
									{
										for(l=0;l<255;l++)
										{
											SelfheartCount = 0;
											if(DT[l]==1)
											{
												if(
												(l<=12)
												||((l>=25)&&(l<=31))
												||((l>=41)&&(l<=43))
												||((l>=45)&&(l<=50))
												||(l==53)
												||(l==57)
												||(l==58)
												||(l==59)
												||((l>=161)&&(l<=176))
												||((l>=185)&&(l<=192)))
												{
													TestTwo[3]=0;
													TestTwo[4]=0;
											 		TestTwo[5]=0;
													TestTwo[6]=0;

													if(ts.Day==1)
													{
														if(ts.Month==1)
														{
															TestTwo[0]=((31/10)<<4)+(31%10);
															TestTwo[1]=((12/10)<<4)+(12%10);
															TestTwo[2]=((((ts.Year-1)%100)/10)<<4)+((ts.Year-1)%10);
														}
														else
															if(ts.Month==2||ts.Month==4||ts.Month==6||ts.Month==8||ts.Month==9||ts.Month==11)
															{
																TestTwo[0]=((31/10)<<4)+(31%10);
																TestTwo[1]=((((ts.Month-1)/10)<<4)+((ts.Month-1)%10));
																TestTwo[2]=(((ts.Year%100)/10)<<4)+(ts.Year%10);
															}
															else
																if(ts.Month==3)
																{
																	TestTwo[0]=((28/10)<<4)+(28%10);
																	TestTwo[1]=((((ts.Month-1)/10)<<4)+((ts.Month-1)%10));
																	TestTwo[2]=(((ts.Year%100)/10)<<4)+(ts.Year%10);
																}
																else
																	if(ts.Month==5||ts.Month==7||ts.Month==10||ts.Month==12)
																	{
																		TestTwo[0]=((30/10)<<4)+(30%10);
																		TestTwo[1]=((((ts.Month-1)/10)<<4)+((ts.Month-1)%10));
																		TestTwo[2]=(((ts.Year%100)/10)<<4)+(ts.Year%10);
																	}
													}
													else
													{
														TestTwo[0]=(((ts.Day-1)/10)<<4)+((ts.Day-1)%10);
														TestTwo[1]=(((ts.Month/10)<<4)+(ts.Month%10));
														TestTwo[2]=(((ts.Year%100)/10)<<4)+(ts.Year%10);
													}

												}
												if(
												((l>=17)&&(l<=24))
												||((l>=33)&&(l<=38))
												||(l==44)
												||(l==51)
												||(l==52)
												||(l==54)
												||((l>=60)&&(l<=66))
												||((l>=177)&&(l<=184)))
												{
													TestTwo[2]=0;
													TestTwo[3]=0;
													TestTwo[4]=0;
													TestTwo[5]=0;
													TestTwo[6]=0;
													if(ts.Month==1)
													{
														TestTwo[0]=((12/10)<<4)+(12%10);
														TestTwo[1]=((((ts.Year-1)%100)/10)<<4)+((ts.Year-1)%10);
													}
													else
													{
														TestTwo[0]=((((ts.Month-1)/10)<<4)+((ts.Month-1)%10));
														TestTwo[1]=(((ts.Year%100)/10)<<4)+(ts.Year%10);
													}
												}
												if((l>=73)&&(l<=108))
													{
													TestTwo[0]=((ts.Minute/10)<<4)+(ts.Minute%10);
													TestTwo[1]=((ts.Hour/10)<<4)+(ts.Hour%10);
													TestTwo[2]=((ts.Day/10)<<4)+(ts.Day%10);
													TestTwo[3]=(((ts.Month/10)<<4)+(ts.Month%10));
													TestTwo[4]=(((ts.Year%100)/10)<<4)+(ts.Year%10);
													////TestTwo[5]=1;
													////TestTwo[6]=96;
													TestTwo[5]=3;
													TestTwo[6]=1;
												}
												CallTwoDataProc(l,k,RtuDataAddr->Task_Value[i].F66_Set_Para.Qu_Xian_ChouQu_BeiLv,TestTwo,0xc4);
												delay(100);
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	DebugOut("\r\n%s ","�������������ϱ�����");
	DebugOut("\r\n");
	return 1;
}
INT8U SendTwoLevelDataCalc(INT8U P,INT8U F,INT8U *t)
{
	INT8U i;
	i=CallTwoDataProcCalc(F,P,1,t,0x88);//JI
	return i;
}
void CallTwolevelDataCalc()
{
	INT8U i,j;//Pro130SetMax
	INT16U Tmp_Resolve_Pos;
	Tmp_Resolve_Pos=14;
	AllReportHead=0;
	AllReportTail=0;
	while(Tmp_Resolve_Pos<(RecDataLen+6))
	{
    	GetDa(Tmp130Buff[Tmp_Resolve_Pos],Tmp130Buff[Tmp_Resolve_Pos+1]);
	    GetDt(Tmp130Buff[Tmp_Resolve_Pos+2],Tmp130Buff[Tmp_Resolve_Pos+3]);
		Tmp_Resolve_Pos=Tmp_Resolve_Pos+4;
		for(i=0;i<64;i++)
		{
			if(DA[i]==1)
			{
				for(j=0;j<255;j++)
				{
					if(DT[j]==1)
					{
						Tmp_Resolve_Pos=Tmp_Resolve_Pos+SendTwoLevelDataCalc(i,j,&Tmp130Buff[Tmp_Resolve_Pos]);
					}
				}
			}
		}
	}
}
INT8U CallTwolevelData()
{
	INT8U i,j;
	CallTwolevelDataCalc();//�¼��ֽ���������
	Resolve_Pos=14;
	while(Resolve_Pos<(RecDataLen+6))
	{
		GetDa(Tmp130Buff[Resolve_Pos],Tmp130Buff[Resolve_Pos+1]);
		GetDt(Tmp130Buff[Resolve_Pos+2],Tmp130Buff[Resolve_Pos+3]);
		Resolve_Pos=Resolve_Pos+4;
		for(i=0;i<64;i++)
		{
			if(DA[i]==1)
			{
				for(j=0;j<255;j++)
				{
					if(DT[j]==1)
					{
						DebugOut("  p=%d f=%d ",i,j);
						Resolve_Pos=Resolve_Pos+SendTwoLevelData(i,j,&Tmp130Buff[Resolve_Pos]);
						delay(100);
					}
				}
			}
		}
		////Resolve_Pos=Resolve_Pos+7;
	}
	return 1;
}

void MkLevel2Head(INT8U P,INT8U F,INT8U FRM)
{
	FrameHeadCreate(FRM);
	SendBuff[SendLen++]=0x0d;//afn
	if(NeedTp)
		SendBuff[SendLen++]=(TestFirFin(F,P)|(seq&0x0f))|0x80;//seq
	else
		SendBuff[SendLen++]=(TestFirFin(F,P)|(seq&0x0f))&0x7f;//seq
	SendBuff[SendLen++]=SetDa1(P);//Tmp130Buff[14];//da1e
	SendBuff[SendLen++]=SetDa2(P);//Tmp130Buff[15];//da2
	SendBuff[SendLen++]=SetDt1(F);//Tmp130Buff[16];//dt1
	SendBuff[SendLen++]=SetDt2(F);//Tmp130Buff[17];//dt2
}
INT8U SendTwoLevelData(INT8U P,INT8U F,INT8U *t)
{
	INT8U i;
	i=CallTwoDataProc(F,P,1,t,0x88);
	return i;
}

INT8U Set_Level2_F1(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT16U i;
	MkLevel2Head(P,F,FRM);
	i=t[0];
	//printf("\n\rt[0] ==%x t[1]===%x t[2]==%x",t[0],t[1],t[2]);
	//printf("\n\r");
	if(!Read_Day_ClHisDianneng(t,&Tmp_DD_BS_Value,P))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&Tmp_DD_BS_Value.Chao_Time.BCD01,5);
	SendLen=SendLen+5;
	SendBuff[SendLen++]=4;
		SendBuff[SendLen++]=0;
	INT32ToBCD(Tmp_DD_BS_Value.Z_P_All_S,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
		SendBuff[SendLen++]=0;
	INT32ToBCD(Tmp_DD_BS_Value.Z_P_F_S[i],&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}

	INT32ToBCD(Tmp_DD_BS_Value.Z_Q_All_S,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_BS_Value.Z_Q_F_S[i],&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}

	INT32ToBCD(Tmp_DD_BS_Value.X1_Q_All,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_BS_Value.X1_F_Q[i],&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}

	INT32ToBCD(Tmp_DD_BS_Value.X4_Q_All,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_BS_Value.X4_F_Q[i],&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F2(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_ClHisDianneng(t,&Tmp_DD_BS_Value,P))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&Tmp_DD_BS_Value.Chao_Time.BCD01,5);
	SendLen=SendLen+5;
	SendBuff[SendLen++]=4;
		SendBuff[SendLen++]=0;
	INT32ToBCD(Tmp_DD_BS_Value.F_P_All_S,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
		SendBuff[SendLen++]=0;
		INT32ToBCD(Tmp_DD_BS_Value.F_P_F_S[i],&SendBuff[SendLen],4);
		SendLen=SendLen+4;
	}

	INT32ToBCD(Tmp_DD_BS_Value.F_Q_All_S,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_BS_Value.F_Q_F_S[i],&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}

	INT32ToBCD(Tmp_DD_BS_Value.X2_Q_All,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_BS_Value.X2_F_Q[i],&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}

	INT32ToBCD(Tmp_DD_BS_Value.X3_Q_All,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_BS_Value.X3_F_Q[i],&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F3(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_ClXuLiang(t,&Tmp_DD_Xl_Value,P))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}

	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Chao_Time.BCD01,sizeof(RtuDataAddr->Day_DD_BS_Value[P-1].Chao_Time));
	SendLen=SendLen+5;
	SendBuff[SendLen++]=4;
	INT32ToBCD(Tmp_DD_Xl_Value.Z_P_X_All,&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_Xl_Value.Z_P_X_F[i],&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	}

	memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Time_Z_P_X_All[0],sizeof(Tmp_DD_Xl_Value.Time_Z_P_X_All));
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Time_Z_P_X_F[i][0],sizeof(Tmp_DD_Xl_Value.Time_Z_P_X_F[i]));
	SendLen=SendLen+4;
	}

	INT32ToBCD(Tmp_DD_Xl_Value.Z_Q_X_All,&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_Xl_Value.Z_Q_X_F[i],&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	}

	memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Time_Z_Q_X_All[0],sizeof(Tmp_DD_Xl_Value.Time_Z_Q_X_All));
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Time_Z_Q_X_F[i][0],sizeof(Tmp_DD_Xl_Value.Time_Z_Q_X_F[i]));
	SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F4(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_ClXuLiang(t,&Tmp_DD_Xl_Value,P))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}

	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Chao_Time.BCD01,sizeof(RtuDataAddr->Day_DD_BS_Value[P-1].Chao_Time));
	SendLen=SendLen+5;
	SendBuff[SendLen++]=4;
	INT32ToBCD(Tmp_DD_Xl_Value.F_P_X_All,&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_Xl_Value.F_P_X_F[i],&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	}

	memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Time_F_P_X_All[0],sizeof(Tmp_DD_Xl_Value.Time_F_P_X_All));
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Time_F_P_X_F[i][0],sizeof(Tmp_DD_Xl_Value.Time_F_P_X_F[i]));
	SendLen=SendLen+4;
	}

	INT32ToBCD(Tmp_DD_Xl_Value.F_Q_X_All,&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_Xl_Value.F_Q_X_F[i],&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	}

	memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Time_F_Q_X_All[0],sizeof(Tmp_DD_Xl_Value.Time_F_Q_X_All));
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Time_F_Q_X_F[i][0],sizeof(Tmp_DD_Xl_Value.Time_F_Q_X_F[i]));
	SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F5(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_ClHisDianneng(t,&Tmp_DD_BS_Value,P))
	{
	if(i!=0xff)
		SendALLNAK();
		//SendNAK(F,P,0x0d);
		return 0;
	}

	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	SendBuff[SendLen++]=4;
	INT32ToBCD(Tmp_DD_BS_Value.Z_P_All_D*100,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_BS_Value.Z_P_F_D[i]*100,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F6(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(Read_Day_ClHisDianneng(t,&Tmp_DD_BS_Value,P)==0)
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}

	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	SendBuff[SendLen++]=4;
	INT32ToBCD(Tmp_DD_BS_Value.Z_Q_All_D*100,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_BS_Value.Z_Q_F_D[i]*100,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F7(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_ClHisDianneng(t,&Tmp_DD_BS_Value,P))
	{
	if(i!=0xff)
		SendALLNAK();
		//SendNAK(F,P,0x0d);
		return 0;
	}

	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	SendBuff[SendLen++]=4;
	INT32ToBCD(Tmp_DD_BS_Value.F_P_All_D*100,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_BS_Value.F_P_F_D[i]*100,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}

	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F8(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_ClHisDianneng(t,&Tmp_DD_BS_Value,P))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}

	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	SendBuff[SendLen++]=4;
	INT32ToBCD(Tmp_DD_BS_Value.F_Q_All_D*100,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_BS_Value.F_Q_F_D[i]*100,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F9(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	MkLevel2Head(P,F,FRM);
	i=t[0];
	if(!Read_Day_ClHisDianneng(t,&Tmp_DD_BS_Value,P))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&Tmp_DD_BS_Value.Chao_Time.BCD01,5);
	SendLen=SendLen+5;
	SendBuff[SendLen++]=4;
		SendBuff[SendLen++]=0;
	INT32ToBCD(Tmp_DD_BS_Value.Z_P_All_S,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
		SendBuff[SendLen++]=0;
	INT32ToBCD(Tmp_DD_BS_Value.Z_P_F_S[i],&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}

	INT32ToBCD(Tmp_DD_BS_Value.Z_Q_All_S,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_BS_Value.Z_Q_F_S[i],&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}

	INT32ToBCD(Tmp_DD_BS_Value.X1_Q_All,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_BS_Value.X1_F_Q[i],&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}

	INT32ToBCD(Tmp_DD_BS_Value.X4_Q_All,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_BS_Value.X4_F_Q[i],&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F10(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_ClHisDianneng(t,&Tmp_DD_BS_Value,P))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}

	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&Tmp_DD_BS_Value.Chao_Time.BCD01,5);
	SendLen=SendLen+5;
	SendBuff[SendLen++]=4;
		SendBuff[SendLen++]=0;
	INT32ToBCD(Tmp_DD_BS_Value.F_P_All_S,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
		SendBuff[SendLen++]=0;
		INT32ToBCD(Tmp_DD_BS_Value.F_P_F_S[i],&SendBuff[SendLen],4);
		SendLen=SendLen+4;
	}

	INT32ToBCD(Tmp_DD_BS_Value.F_Q_All_S,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_BS_Value.F_Q_F_S[i],&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}

	INT32ToBCD(Tmp_DD_BS_Value.X2_Q_All,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_BS_Value.X2_F_Q[i],&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}

	INT32ToBCD(Tmp_DD_BS_Value.X3_Q_All,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_BS_Value.X3_F_Q[i],&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F11(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_ClXuLiang(t,&Tmp_DD_Xl_Value,P))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}

	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Chao_Time.BCD01,sizeof(RtuDataAddr->Day_DD_BS_Value[P-1].Chao_Time));
	SendLen=SendLen+5;
	SendBuff[SendLen++]=4;
	INT32ToBCD(Tmp_DD_Xl_Value.Z_P_X_All,&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_Xl_Value.Z_P_X_F[i],&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	}

	memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Time_Z_P_X_All[0],sizeof(Tmp_DD_Xl_Value.Time_Z_P_X_All));
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Time_Z_P_X_F[i][0],sizeof(Tmp_DD_Xl_Value.Time_Z_P_X_F[i]));
	SendLen=SendLen+4;
	}

	INT32ToBCD(Tmp_DD_Xl_Value.Z_Q_X_All,&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_Xl_Value.Z_Q_X_F[i],&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	}

	memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Time_Z_Q_X_All[0],sizeof(Tmp_DD_Xl_Value.Time_Z_Q_X_All));
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Time_Z_Q_X_F[i][0],sizeof(Tmp_DD_Xl_Value.Time_Z_Q_X_F[i]));
	SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F12(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_ClXuLiang(t,&Tmp_DD_Xl_Value,P))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}

	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Chao_Time.BCD01,sizeof(RtuDataAddr->Day_DD_BS_Value[P-1].Chao_Time));
	SendLen=SendLen+5;
	SendBuff[SendLen++]=4;
	INT32ToBCD(Tmp_DD_Xl_Value.F_P_X_All,&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_Xl_Value.F_P_X_F[i],&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	}

	memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Time_F_P_X_All[0],sizeof(Tmp_DD_Xl_Value.Time_F_P_X_All));
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Time_F_P_X_F[i][0],sizeof(Tmp_DD_Xl_Value.Time_F_P_X_F[i]));
	SendLen=SendLen+4;
	}

	INT32ToBCD(Tmp_DD_Xl_Value.F_Q_X_All,&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_Xl_Value.F_Q_X_F[i],&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	}

	memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Time_F_Q_X_All[0],sizeof(Tmp_DD_Xl_Value.Time_F_Q_X_All));
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Time_F_Q_X_F[i][0],sizeof(Tmp_DD_Xl_Value.Time_F_Q_X_F[i]));
	SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F17(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Yue_ClHisDianneng(&Tmp_DD_BS_Value,P,t))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}

	memcpy(&SendBuff[SendLen],t,2);
	SendLen=SendLen+2;
	memcpy(&SendBuff[SendLen],&Tmp_DD_BS_Value.Chao_Time.BCD01,5);
	SendLen=SendLen+5;
	SendBuff[SendLen++]=4;
	SendBuff[SendLen++]=0;
	INT32ToBCD(Tmp_DD_BS_Value.Z_P_All_S,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	SendBuff[SendLen++]=0;
	INT32ToBCD(Tmp_DD_BS_Value.Z_P_F_S[i],&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}

	INT32ToBCD(Tmp_DD_BS_Value.Z_Q_All_S,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_BS_Value.Z_Q_F_S[i],&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}

	INT32ToBCD(Tmp_DD_BS_Value.X1_Q_All,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_BS_Value.X1_F_Q[i],&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}

	INT32ToBCD(Tmp_DD_BS_Value.X4_Q_All,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_BS_Value.X4_F_Q[i],&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F18(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Yue_ClHisDianneng(&Tmp_DD_BS_Value,P,t))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}

	memcpy(&SendBuff[SendLen],t,2);
	SendLen=SendLen+2;
	memcpy(&SendBuff[SendLen],&Tmp_DD_BS_Value.Chao_Time.BCD01,5);
	SendLen=SendLen+5;
	SendBuff[SendLen++]=4;
	SendBuff[SendLen++]=0;
	INT32ToBCD(Tmp_DD_BS_Value.F_P_All_S,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	SendBuff[SendLen++]=0;
	INT32ToBCD(Tmp_DD_BS_Value.F_P_F_S[i],&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}

	INT32ToBCD(Tmp_DD_BS_Value.F_Q_All_S,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_BS_Value.F_Q_F_S[i],&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}

	INT32ToBCD(Tmp_DD_BS_Value.X2_Q_All,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_BS_Value.X2_F_Q[i],&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}

	INT32ToBCD(Tmp_DD_BS_Value.X3_Q_All,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_BS_Value.X3_F_Q[i],&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F19(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Yue_ClXuLiang(&Tmp_DD_Xl_Value,P,t))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}

	memcpy(&SendBuff[SendLen],t,2);
	SendLen=SendLen+2;
	memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Chao_Time.BCD01,sizeof(RtuDataAddr->Day_DD_BS_Value[P-1].Chao_Time));
	SendLen=SendLen+5;
	SendBuff[SendLen++]=4;
	INT32ToBCD(Tmp_DD_Xl_Value.Z_P_X_All,&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_Xl_Value.Z_P_X_F[i],&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	}

	memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Time_Z_P_X_All[0],sizeof(Tmp_DD_Xl_Value.Time_Z_P_X_All));
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Time_Z_P_X_F[i][0],sizeof(Tmp_DD_Xl_Value.Time_Z_P_X_F[i]));
	SendLen=SendLen+4;
	}

	INT32ToBCD(Tmp_DD_Xl_Value.Z_Q_X_All,&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_Xl_Value.Z_Q_X_F[i],&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	}

	memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Time_Z_Q_X_All[0],sizeof(Tmp_DD_Xl_Value.Time_Z_Q_X_All));
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Time_Z_Q_X_F[i][0],sizeof(Tmp_DD_Xl_Value.Time_Z_Q_X_F[i]));
	SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F20(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Yue_ClXuLiang(&Tmp_DD_Xl_Value,P,t))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}

	memcpy(&SendBuff[SendLen],t,2);
	SendLen=SendLen+2;
	memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Chao_Time.BCD01,sizeof(RtuDataAddr->Day_DD_BS_Value[P-1].Chao_Time));
	SendLen=SendLen+5;
	SendBuff[SendLen++]=4;
	INT32ToBCD(Tmp_DD_Xl_Value.F_P_X_All,&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_Xl_Value.F_P_X_F[i],&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	}

	memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Time_F_P_X_All[0],sizeof(Tmp_DD_Xl_Value.Time_F_P_X_All));
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Time_F_P_X_F[i][0],sizeof(Tmp_DD_Xl_Value.Time_F_P_X_F[i]));
	SendLen=SendLen+4;
	}

	INT32ToBCD(Tmp_DD_Xl_Value.F_Q_X_All,&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_Xl_Value.F_Q_X_F[i],&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	}

	memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Time_F_Q_X_All[0],sizeof(Tmp_DD_Xl_Value.Time_F_Q_X_All));
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Time_F_Q_X_F[i][0],sizeof(Tmp_DD_Xl_Value.Time_F_Q_X_F[i]));
	SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F21(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Yue_ClHisDianneng(&Tmp_DD_BS_Value,P,t))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}

	memcpy(&SendBuff[SendLen],t,2);
	SendLen=SendLen+2;
	SendBuff[SendLen++]=4;
	INT32ToBCD(Tmp_DD_BS_Value.Z_P_All_D*100,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_BS_Value.Z_P_F_D[i]*100,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F22(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Yue_ClHisDianneng(&Tmp_DD_BS_Value,P,t))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	memcpy(&SendBuff[SendLen],t,2);
	SendLen=SendLen+2;
	SendBuff[SendLen++]=4;
	INT32ToBCD(Tmp_DD_BS_Value.Z_Q_All_D*100,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_BS_Value.Z_Q_F_D[i]*100,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F23(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Yue_ClHisDianneng(&Tmp_DD_BS_Value,P,t))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}

	memcpy(&SendBuff[SendLen],t,2);
	SendLen=SendLen+2;
	SendBuff[SendLen++]=4;
	INT32ToBCD(Tmp_DD_BS_Value.F_P_All_D*100,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_BS_Value.F_P_F_D[i]*100,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}

	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F24(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Yue_ClHisDianneng(&Tmp_DD_BS_Value,P,t))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}

	memcpy(&SendBuff[SendLen],t,2);
	SendLen=SendLen+2;
	SendBuff[SendLen++]=FeiLvNum;
	INT32ToBCD(Tmp_DD_BS_Value.F_Q_All_D*100,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_BS_Value.F_Q_F_D[i]*100,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}

INT8U Set_Level2_F25(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_ClStat(t,&Tmp_Cl_Stat,P))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	INT32ToBCD(Tmp_Cl_Stat.P_All,&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&Tmp_Cl_Stat.P_All_Time.BCD01,3);
	SendLen=SendLen+3;
	INT32ToBCD(Tmp_Cl_Stat.P_U,&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&Tmp_Cl_Stat.P_U_Time.BCD01,3);
	SendLen=SendLen+3;
	INT32ToBCD(Tmp_Cl_Stat.P_V,&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&Tmp_Cl_Stat.P_V_Time.BCD01,3);
	SendLen=SendLen+3;
	INT32ToBCD(Tmp_Cl_Stat.P_W,&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&Tmp_Cl_Stat.P_W_Time.BCD01,3);
	SendLen=SendLen+3;
	SendBuff[SendLen++]=Tmp_Cl_Stat.P_Zero_Time&0xff;
	SendBuff[SendLen++]=(Tmp_Cl_Stat.P_Zero_Time>>8)&0xff;
	SendBuff[SendLen++]=Tmp_Cl_Stat.PU_Zero_Time&0xff;
	SendBuff[SendLen++]=(Tmp_Cl_Stat.PU_Zero_Time>>8)&0xff;
	SendBuff[SendLen++]=Tmp_Cl_Stat.PV_Zero_Time&0xff;
	SendBuff[SendLen++]=(Tmp_Cl_Stat.PV_Zero_Time>>8)&0xff;
	SendBuff[SendLen++]=Tmp_Cl_Stat.PW_Zero_Time&0xff;
	SendBuff[SendLen++]=(Tmp_Cl_Stat.PW_Zero_Time>>8)&0xff;

	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F26(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_ClStat(t,&Tmp_Cl_Stat,P))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	INT32ToBCD(Tmp_Cl_Stat.P_All_XL,&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&Tmp_Cl_Stat.P_All_XL_Time.BCD01,3);
	SendLen=SendLen+3;
	INT32ToBCD(Tmp_Cl_Stat.P_U_XL,&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&Tmp_Cl_Stat.P_U_XL_Time.BCD01,3);
	SendLen=SendLen+3;
	INT32ToBCD(Tmp_Cl_Stat.P_V_XL,&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&Tmp_Cl_Stat.P_V_XL_Time.BCD01,3);
	SendLen=SendLen+3;
	INT32ToBCD(Tmp_Cl_Stat.P_W_XL,&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&Tmp_Cl_Stat.P_W_XL_Time.BCD01,3);
	SendLen=SendLen+3;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}//Read_Day_F2730Stat
INT8U *INT16ToBCD(INT16U S, INT8U *D, INT8U len) {
	INT8U i;
	INT16U Temp;
	INT16U j = 1;
	Temp = abs(S);
	for (i = 0; i < len; i++) {
		j = Temp % 100;
		D[i] = (j / 10);
		D[i] = (D[i] << 4) + (j % 10);
		Temp = Temp / 100;
	}
	return D;
}
INT8U *INT16ToHEX(INT16U S, INT8U *D){

	INT16U Temp;
	Temp = abs(S);
	D[1] = (Temp>>8)&0xff;
	D[0] = Temp&0x00ff;
	return D;
}
INT8U Set_Level2_F27(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{

	INT8U D[2];
	MkLevel2Head(P,F,FRM);
	while(!RtuDataAddr->autoReport)
	{
		printf("\n\rtuDataAddr->autoReport==0 in saving!!!!!");
		delay(300);
	}
	printf("\n\rF27 start read ::\n");
	if(!Read_Day_F2730Stat(&TmpF27_28_29_30_Mem,P,t))
	{
		//SendNAK(F,P,0x0d);
		printf("\n\rread file error!!!");
		SendALLNAK();
		return 0;
	}
	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	INT16ToHEX(TmpF27_28_29_30_Mem.USSU_Count,D);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	INT16ToHEX(TmpF27_28_29_30_Mem.UXXU_Count,D);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	INT16ToHEX(TmpF27_28_29_30_Mem.USU_Count,D);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	INT16ToHEX(TmpF27_28_29_30_Mem.UXU_Count,D);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	INT16ToHEX(TmpF27_28_29_30_Mem.UHGU_Count,D);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	INT16ToHEX(TmpF27_28_29_30_Mem.USSV_Count,D);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	INT16ToHEX(TmpF27_28_29_30_Mem.UXXV_Count,D);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	INT16ToHEX(TmpF27_28_29_30_Mem.USV_Count,D);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	INT16ToHEX(TmpF27_28_29_30_Mem.UXV_Count,D);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	INT16ToHEX(TmpF27_28_29_30_Mem.UHGV_Count,D);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;


	INT16ToHEX(TmpF27_28_29_30_Mem.USSW_Count,D);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	INT16ToHEX(TmpF27_28_29_30_Mem.UXXW_Count,D);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	INT16ToHEX(TmpF27_28_29_30_Mem.USW_Count,D);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	INT16ToHEX(TmpF27_28_29_30_Mem.UXW_Count,D);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	INT16ToHEX(TmpF27_28_29_30_Mem.UHGW_Count,D);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	INT16ToBCD(TmpF27_28_29_30_Mem.DUUMAX,D,2);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	memcpy(&SendBuff[SendLen],&TmpF27_28_29_30_Mem.DUUMAX_TIME,3);
	SendLen=SendLen+3;
	INT16ToBCD(TmpF27_28_29_30_Mem.DUUMIN,D, 2);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	memcpy(&SendBuff[SendLen],&TmpF27_28_29_30_Mem.DUUMIN_TIME,3);
	SendLen=SendLen+3;

	INT16ToBCD(TmpF27_28_29_30_Mem.DUVMAX,D, 2);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	memcpy(&SendBuff[SendLen],&TmpF27_28_29_30_Mem.DUVMAX_TIME,3);
	SendLen=SendLen+3;
	INT16ToBCD(TmpF27_28_29_30_Mem.DUVMIN,D, 2);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	memcpy(&SendBuff[SendLen],&TmpF27_28_29_30_Mem.DUVMIN_TIME,3);
	SendLen=SendLen+3;
	INT16ToBCD(TmpF27_28_29_30_Mem.DUWMAX,D, 2);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	memcpy(&SendBuff[SendLen],&TmpF27_28_29_30_Mem.DUWMAX_TIME,3);
	SendLen=SendLen+3;
	INT16ToBCD(TmpF27_28_29_30_Mem.DUWMIN,D, 2);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	memcpy(&SendBuff[SendLen],&TmpF27_28_29_30_Mem.DUWMIN_TIME,3);
	SendLen=SendLen+3;
	INT16ToBCD(TmpF27_28_29_30_Mem.DUUAVE,D, 2);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	INT16ToBCD(TmpF27_28_29_30_Mem.DUVAVE,D, 2);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	INT16ToBCD(TmpF27_28_29_30_Mem.DUWAVE,D, 2);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;



}
INT8U Set_Level2_F28(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_F2730Stat(&TmpF27_28_29_30_Mem,P,t))
	{
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],(INT8U *)&TmpF27_28_29_30_Mem.I_UNBALANCE_Count,14);
	SendLen=SendLen+14;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F29(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	unsigned char BCD[3];
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_F2730Stat(&TmpF27_28_29_30_Mem,P,t))
	{
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],(INT8U *)&TmpF27_28_29_30_Mem.ISSU_Count,14);
	SendLen=SendLen+14;
	INT32_A25(TmpF27_28_29_30_Mem.DI_U_MAX,BCD);

	memcpy(&SendBuff[SendLen],BCD,3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],(INT8U *)&TmpF27_28_29_30_Mem.DIUMAX_TIME,3);
	SendLen=SendLen+3;
	INT32_A25(TmpF27_28_29_30_Mem.DI_V_MAX,BCD);
	memcpy(&SendBuff[SendLen],BCD,3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],(INT8U *)&TmpF27_28_29_30_Mem.DIVMAX_TIME,3);
	SendLen=SendLen+3;
	INT32_A25(TmpF27_28_29_30_Mem.DI_W_MAX,BCD);
	memcpy(&SendBuff[SendLen],BCD,3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],(INT8U *)&TmpF27_28_29_30_Mem.DIWMAX_TIME,3);
	SendLen=SendLen+3;
	INT32_A25(TmpF27_28_29_30_Mem.DI_L_MAX,BCD);
	memcpy(&SendBuff[SendLen],BCD,3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],(INT8U *)&TmpF27_28_29_30_Mem.DILMAX_TIME,3);
	SendLen=SendLen+3;

	EC();
	TP();
	FrameTailCreate_Send();
	return 1;

}
INT8U Set_Level2_F30(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_F2730Stat(&TmpF27_28_29_30_Mem,P,t))
	{
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],(INT8U *)&TmpF27_28_29_30_Mem.S_SS_Count,4);
	SendLen=SendLen+4;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F38(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	MkLevel2Head(P,F,FRM);
	if(!Read_Yue_F2730Stat(&TmpF27_28_29_30_Mem,P,t))
	{
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	memcpy(&SendBuff[SendLen],t,2);
	SendLen=SendLen+2;
	memcpy(&SendBuff[SendLen],(INT8U *)&TmpF27_28_29_30_Mem.S_SS_Count,4);
	SendLen=SendLen+4;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}

INT8U Set_Level2_F31(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_FuZaiLvTongJi(&TmpF31_Mem,P,t))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}

	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&TmpF31_Mem.FuZaiLv_Max[0],10);
	SendLen=SendLen+10;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F32(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_ClStat(t,&Tmp_Cl_Stat,P))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}

	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&Tmp_Cl_Stat.Chao_Time.BCD01,sizeof(RtuDataAddr->Day_DD_BS_Value[P-1].Chao_Time));
	SendLen=SendLen+5;
	memcpy(&SendBuff[SendLen],&Tmp_Cl_Stat.Duanxiang_All[0],52);
	SendLen=SendLen+52;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F33(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Yue_ClStat(&Tmp_Cl_Stat,P,t))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	memcpy(&SendBuff[SendLen],t,2);
	SendLen=SendLen+2;
	INT32ToBCD(Tmp_Cl_Stat.P_All,&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&Tmp_Cl_Stat.P_All_Time.BCD01,3);
	SendLen=SendLen+3;
	INT32ToBCD(Tmp_Cl_Stat.P_U,&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&Tmp_Cl_Stat.P_U_Time.BCD01,3);
	SendLen=SendLen+3;
	INT32ToBCD(Tmp_Cl_Stat.P_V,&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&Tmp_Cl_Stat.P_V_Time.BCD01,3);
	SendLen=SendLen+3;
	INT32ToBCD(Tmp_Cl_Stat.P_W,&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&Tmp_Cl_Stat.P_W_Time.BCD01,3);
	SendLen=SendLen+3;
	SendBuff[SendLen++]=Tmp_Cl_Stat.P_Zero_Time&0xff;
	SendBuff[SendLen++]=(Tmp_Cl_Stat.P_Zero_Time>>8)&0xff;
	SendBuff[SendLen++]=Tmp_Cl_Stat.PU_Zero_Time&0xff;
	SendBuff[SendLen++]=(Tmp_Cl_Stat.PU_Zero_Time>>8)&0xff;
	SendBuff[SendLen++]=Tmp_Cl_Stat.PV_Zero_Time&0xff;
	SendBuff[SendLen++]=(Tmp_Cl_Stat.PV_Zero_Time>>8)&0xff;
	SendBuff[SendLen++]=Tmp_Cl_Stat.PW_Zero_Time&0xff;
	SendBuff[SendLen++]=(Tmp_Cl_Stat.PW_Zero_Time>>8)&0xff;

	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F34(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Yue_ClStat(&Tmp_Cl_Stat,P,t))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}

	memcpy(&SendBuff[SendLen],t,2);
	SendLen=SendLen+2;
	INT32ToBCD(Tmp_Cl_Stat.P_All_XL,&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&Tmp_Cl_Stat.P_All_XL_Time.BCD01,3);
	SendLen=SendLen+3;
	INT32ToBCD(Tmp_Cl_Stat.P_U_XL,&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&Tmp_Cl_Stat.P_U_XL_Time.BCD01,3);
	SendLen=SendLen+3;
	INT32ToBCD(Tmp_Cl_Stat.P_V_XL,&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&Tmp_Cl_Stat.P_V_XL_Time.BCD01,3);
	SendLen=SendLen+3;
	INT32ToBCD(Tmp_Cl_Stat.P_W_XL,&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&Tmp_Cl_Stat.P_W_XL_Time.BCD01,3);
	SendLen=SendLen+3;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}


INT8U Set_Level2_F35(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U D[2];
	MkLevel2Head(P,F,FRM);
	if(!Read_Yue_F2730Stat(&TmpF27_28_29_30_Mem,P,t))
	{
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	memcpy(&SendBuff[SendLen],t,2);
	SendLen=SendLen+2;
	INT16ToBCD(TmpF27_28_29_30_Mem.USSU_Count,D, 2);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	INT16ToBCD(TmpF27_28_29_30_Mem.UXXU_Count,D, 2);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	INT16ToBCD(TmpF27_28_29_30_Mem.USU_Count,D, 2);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	INT16ToBCD(TmpF27_28_29_30_Mem.UXU_Count,D, 2);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	INT16ToBCD(TmpF27_28_29_30_Mem.UHGU_Count,D, 2);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	INT16ToBCD(TmpF27_28_29_30_Mem.USSV_Count,D, 2);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	INT16ToBCD(TmpF27_28_29_30_Mem.UXXV_Count,D, 2);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	INT16ToBCD(TmpF27_28_29_30_Mem.USV_Count,D, 2);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	INT16ToBCD(TmpF27_28_29_30_Mem.UXV_Count,D, 2);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	INT16ToBCD(TmpF27_28_29_30_Mem.UHGV_Count,D, 2);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;


	INT16ToBCD(TmpF27_28_29_30_Mem.USSW_Count,D, 2);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	INT16ToBCD(TmpF27_28_29_30_Mem.UXXW_Count,D, 2);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	INT16ToBCD(TmpF27_28_29_30_Mem.USW_Count,D, 2);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	INT16ToBCD(TmpF27_28_29_30_Mem.UXW_Count,D, 2);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	INT16ToBCD(TmpF27_28_29_30_Mem.UHGW_Count,D, 2);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	INT16ToBCD(TmpF27_28_29_30_Mem.DUUMAX,D, 2);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	memcpy(&SendBuff[SendLen],&TmpF27_28_29_30_Mem.DUUMAX_TIME,3);
	SendLen=SendLen+3;
	INT16ToBCD(TmpF27_28_29_30_Mem.DUUMIN,D, 2);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	memcpy(&SendBuff[SendLen],&TmpF27_28_29_30_Mem.DUUMIN_TIME,3);
	SendLen=SendLen+3;

	INT16ToBCD(TmpF27_28_29_30_Mem.DUVMAX,D, 2);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	memcpy(&SendBuff[SendLen],&TmpF27_28_29_30_Mem.DUVMAX_TIME,3);
	SendLen=SendLen+3;
	INT16ToBCD(TmpF27_28_29_30_Mem.DUVMIN,D, 2);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	memcpy(&SendBuff[SendLen],&TmpF27_28_29_30_Mem.DUVMIN_TIME,3);
	SendLen=SendLen+3;
	INT16ToBCD(TmpF27_28_29_30_Mem.DUWMAX,D, 2);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	memcpy(&SendBuff[SendLen],&TmpF27_28_29_30_Mem.DUWMAX_TIME,3);
	SendLen=SendLen+3;
	INT16ToBCD(TmpF27_28_29_30_Mem.DUWMIN,D, 2);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	memcpy(&SendBuff[SendLen],&TmpF27_28_29_30_Mem.DUWMIN_TIME,3);
	SendLen=SendLen+3;
	INT16ToBCD(TmpF27_28_29_30_Mem.DUUAVE,D, 2);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	INT16ToBCD(TmpF27_28_29_30_Mem.DUVAVE,D, 2);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	INT16ToBCD(TmpF27_28_29_30_Mem.DUWAVE,D, 2);
	memcpy(&SendBuff[SendLen],D,2);
	SendLen=SendLen+2;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F36(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	unsigned char BCD[2];
	MkLevel2Head(P,F,FRM);
	if(!Read_Yue_F2730Stat(&TmpF27_28_29_30_Mem,P,t))
	{
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	memcpy(&SendBuff[SendLen],t,2);
	SendLen=SendLen+2;
	memcpy(&SendBuff[SendLen],&TmpF27_28_29_30_Mem.I_UNBALANCE_Count,4);
	SendLen = SendLen+4;

	INT16_A5(TmpF27_28_29_30_Mem.I_UNBALANCE_Max ,BCD);
	memcpy(&SendBuff[SendLen],BCD,2);
	SendLen=SendLen+2;
	memcpy(&SendBuff[SendLen],TmpF27_28_29_30_Mem.I_UNBALANCE_MaxTime,4);
	SendLen=SendLen+4;

	INT16_A5(TmpF27_28_29_30_Mem.V_UNBALANCE_Max ,BCD);
	memcpy(&SendBuff[SendLen],BCD,2);
	SendLen=SendLen+2;
	memcpy(&SendBuff[SendLen],TmpF27_28_29_30_Mem.V_UNBALANCE_MaxTime,4);
	SendLen=SendLen+4;
	////////////////////////////////////////
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}

INT8U Set_Level2_F37(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{ unsigned char BCD[3];
	MkLevel2Head(P,F,FRM);
	if(!Read_Yue_F2730Stat(&TmpF27_28_29_30_Mem,P,t))
	{
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	memcpy(&SendBuff[SendLen],t,2);
	SendLen=SendLen+2;
	memcpy(&SendBuff[SendLen],(INT8U *)&TmpF27_28_29_30_Mem.ISSU_Count,14);
	SendLen=SendLen+14;
	INT32_A25(TmpF27_28_29_30_Mem.DI_U_MAX,BCD);

	memcpy(&SendBuff[SendLen],BCD,3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],(INT8U *)&TmpF27_28_29_30_Mem.DIUMAX_TIME,3);
	SendLen=SendLen+3;
	INT32_A25(TmpF27_28_29_30_Mem.DI_V_MAX,BCD);
	memcpy(&SendBuff[SendLen],BCD,3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],(INT8U *)&TmpF27_28_29_30_Mem.DIVMAX_TIME,3);
	SendLen=SendLen+3;
	INT32_A25(TmpF27_28_29_30_Mem.DI_W_MAX,BCD);
	memcpy(&SendBuff[SendLen],BCD,3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],(INT8U *)&TmpF27_28_29_30_Mem.DIWMAX_TIME,3);
	SendLen=SendLen+3;
	INT32_A25(TmpF27_28_29_30_Mem.DI_L_MAX,BCD);
	memcpy(&SendBuff[SendLen],BCD,3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],(INT8U *)&TmpF27_28_29_30_Mem.DILMAX_TIME,3);
	SendLen=SendLen+3;

	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}

INT8U Set_Level2_F39(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Yue_ClStat(&Tmp_Cl_Stat,P,t))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	memcpy(&SendBuff[SendLen],t,2);
	SendLen=SendLen+2;
	SendBuff[SendLen++]=(Tmp_Cl_Stat.DianYaHG>>8)&0xff;
	SendBuff[SendLen++]=Tmp_Cl_Stat.DianYaHG&0xff;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}

INT8U Set_Level2_F44(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Yue_F2730Stat(&TmpF27_28_29_30_Mem,P,t))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	memcpy(&SendBuff[SendLen],t,2);
	SendLen=SendLen+2;

	memcpy(&SendBuff[SendLen],&RtuDataAddr->YF27_28_29_30_Mem[i].QuDuan1_Count,2);
	SendLen=SendLen+2;
	memcpy(&SendBuff[SendLen],&RtuDataAddr->YF27_28_29_30_Mem[i].QuDuan2_Count,2);
	SendLen=SendLen+2;
	memcpy(&SendBuff[SendLen],&RtuDataAddr->YF27_28_29_30_Mem[i].QuDuan3_Count,2);
	SendLen=SendLen+2;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}

INT8U Set_Level2_F49(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_ZdStat(t,&Tmp_Fk_Stat,P))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}

	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	SendBuff[SendLen++]=Tmp_Fk_Stat.GD_Time&0xff;
	SendBuff[SendLen++]=(Tmp_Fk_Stat.GD_Time>>8)&0xff;
	SendBuff[SendLen++]=Tmp_Fk_Stat.Reset_Time&0xff;
	SendBuff[SendLen++]=(Tmp_Fk_Stat.Reset_Time>>8)&0xff;

	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F50(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_ZdStat(t,&Tmp_Fk_Stat,P))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	printf("\n\r tiaozhaNum-baowen is %d",Tmp_Fk_Stat.Yk_T);
	printf("\n\r");
	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	SendBuff[SendLen++]=Tmp_Fk_Stat.Yue_DK_T&0xff;
	SendBuff[SendLen++]=Tmp_Fk_Stat.Gou_DK_T&0xff;
	SendBuff[SendLen++]=Tmp_Fk_Stat.GongK_T&0xff;
	SendBuff[SendLen++]=Tmp_Fk_Stat.Yk_T&0xff;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F51(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
INT8U i;
	MkLevel2Head(P,F,FRM);
	i=t[0];
	if(!Read_Yue_ZdStat(&Tmp_Fk_Stat,P,t))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}

	memcpy(&SendBuff[SendLen],t,2);
	SendLen=SendLen+2;
	SendBuff[SendLen++]=Tmp_Fk_Stat.GD_Time&0xff;

	SendBuff[SendLen++]=(Tmp_Fk_Stat.GD_Time>>8)&0xff;
	SendBuff[SendLen++]=Tmp_Fk_Stat.Reset_Time&0xff;
	SendBuff[SendLen++]=(Tmp_Fk_Stat.Reset_Time>>8)&0xff;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F52(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Yue_ZdStat(&Tmp_Fk_Stat,P,t))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}

	memcpy(&SendBuff[SendLen],t,2);
	SendLen=SendLen+2;
	SendBuff[SendLen++]=Tmp_Fk_Stat.Yue_DK_T&0xff;
	SendBuff[SendLen++]=Tmp_Fk_Stat.Gou_DK_T&0xff;
	SendBuff[SendLen++]=Tmp_Fk_Stat.GongK_T&0xff;
	SendBuff[SendLen++]=Tmp_Fk_Stat.Yk_T&0xff;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F53(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_ZdStat(t,&Tmp_Fk_Stat,P))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}

	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	SendBuff[SendLen++]=(Tmp_Fk_Stat.liuliang)&0xff;
	SendBuff[SendLen++]=(Tmp_Fk_Stat.liuliang>>8)&0xff;
	SendBuff[SendLen++]=(Tmp_Fk_Stat.liuliang>>16)&0xff;
	SendBuff[SendLen++]=(Tmp_Fk_Stat.liuliang>>24)&0xff;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F54(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Yue_ZdStat(&Tmp_Fk_Stat,P,t))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}

	memcpy(&SendBuff[SendLen],t,2);
	SendLen=SendLen+2;
	SendBuff[SendLen++]=(Tmp_Fk_Stat.liuliang)&0xff;
	SendBuff[SendLen++]=(Tmp_Fk_Stat.liuliang>>8)&0xff;
	SendBuff[SendLen++]=(Tmp_Fk_Stat.liuliang>>16)&0xff;
	SendBuff[SendLen++]=(Tmp_Fk_Stat.liuliang>>24)&0xff;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}

INT8U Set_Level2_F57(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_ZjStat(t,&Tmp_Zj_Stat,P))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}

	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	Create_Data_Type02(Tmp_Zj_Stat.MaxP,&SendBuff[SendLen]);
	SendLen=SendLen+2;
	memcpy(&SendBuff[SendLen],&Tmp_Zj_Stat.MaxP_Time.BCD01,3);
	SendLen=SendLen+3;
	Create_Data_Type02(Tmp_Zj_Stat.MinP,&SendBuff[SendLen]);
	SendLen=SendLen+2;
	memcpy(&SendBuff[SendLen],&Tmp_Zj_Stat.MinP_Time.BCD01,3);
	SendLen=SendLen+3;
	SendBuff[SendLen++]=Tmp_Zj_Stat.P_Zero_Calc&0xff;
	SendBuff[SendLen++]=(Tmp_Zj_Stat.P_Zero_Calc>>8)&0xff;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F58(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_ZjHisDianneng(t,&Tmp_Zj_Value,P))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}

	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	SendBuff[SendLen++]=FeiLvNum;
	INT32ToBCD(Tmp_Zj_Value.Z_P_All_D/*+Tmp_Zj_Value.F_P_All_D*/,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_Zj_Value.Z_P_F_D[i]/*+Tmp_Zj_Value.F_P_F_D[i]*/,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F59(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_ZjHisDianneng(t,&Tmp_Zj_Value,P))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}

	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	SendBuff[SendLen++]=FeiLvNum;
	INT32ToBCD(Tmp_Zj_Value.Z_Q_All_D/*+Tmp_Zj_Value.F_Q_All_D*/,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_Zj_Value.Z_Q_F_D[i]/*+Tmp_Zj_Value.F_Q_F_D[i]*/,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F60(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	MkLevel2Head(P,F,FRM);
	i=t[0];
	if(!Read_Yue_ZjStat(&Tmp_Zj_Stat,P,t))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}


	memcpy(&SendBuff[SendLen],t,2);
	SendLen=SendLen+2;

	Create_Data_Type02(Tmp_Zj_Stat.MaxP,&SendBuff[SendLen]);
	SendLen=SendLen+2;

	memcpy(&SendBuff[SendLen],&Tmp_Zj_Stat.MaxP_Time.BCD01,3);
	SendLen=SendLen+3;

	Create_Data_Type02(Tmp_Zj_Stat.MinP,&SendBuff[SendLen]);
	SendLen=SendLen+2;

	memcpy(&SendBuff[SendLen],&Tmp_Zj_Stat.MinP_Time.BCD01,3);
	SendLen=SendLen+3;

	SendBuff[SendLen++]=Tmp_Zj_Stat.P_Zero_Calc&0xff;
	SendBuff[SendLen++]=(Tmp_Zj_Stat.P_Zero_Calc>>8)&0xff;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F61(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Yue_ZjHisDianneng(&Tmp_Zj_Value,P,t))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	memcpy(&SendBuff[SendLen],t,2);
	SendLen=SendLen+2;
	SendBuff[SendLen++]=FeiLvNum;
	INT32ToBCD(Tmp_Zj_Value.Z_P_All_D/*+Tmp_Zj_Value.F_P_All_D*/,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_Zj_Value.Z_P_F_D[i]/*+Tmp_Zj_Value.F_P_F_D[i]*/,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F62(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Yue_ZjHisDianneng(&Tmp_Zj_Value,P,t))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	memcpy(&SendBuff[SendLen],t,2);
	SendLen=SendLen+2;
	SendBuff[SendLen++]=FeiLvNum;
	INT32ToBCD(Tmp_Zj_Value.Z_Q_All_D+Tmp_Zj_Value.F_Q_All_D,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_Zj_Value.Z_Q_F_D[i]+Tmp_Zj_Value.F_Q_F_D[i],&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}

INT8U Set_Level2_F73(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U MiDu,i,j;
	INT8U pos;
	i=t[0];
	MkLevel2Head(P,F,FRM);

	if(!Read_Day_ZjQuXian(t,TmpBuff,P,81))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	MiDu=0;
	j=0;
	if(t[5]==0)
	{
	}
	if(t[5]==1)
	{

		if(i==0xff)
		{
			t[0]=0x15;
			t[1]=0;
			t[6]=96;
		}
		memcpy(&SendBuff[SendLen],t,7);
		SendLen=SendLen+7;
		pos=((t[1]>>4)*10)+(t[1]&0x0f);
		pos=pos*4;
		if(t[0]==0x00)pos=pos+0;
		if(t[0]==0x15)pos=pos+1;
		if(t[0]==0x30)pos=pos+2;
		if(t[0]==0x45)pos=pos+3;
		if(pos!=0)
			pos=pos-1;;
		DebugOut("\r\n F73 pos=%d ",pos);
		for(i=0;i<t[6];i++)
		{
			Create_Data_Type02(TmpBuff[pos+i],&SendBuff[SendLen]);//15
			SendLen=SendLen+2;
		}
	}
	if(t[5]==2)
	{
		if(i==0xff)
		{
			t[0]=0x30;
			t[1]=0;
			t[6]=48;
		}
		memcpy(&SendBuff[SendLen],t,7);
		SendLen=SendLen+7;
		pos=((t[1]>>4)*10)+(t[1]&0x0f);
		pos=pos*4;
		if(t[0]==0x00)pos=pos+0;
		if(t[0]==0x15)pos=pos+1;
		if(t[0]==0x30)pos=pos+2;
		if(t[0]==0x45)pos=pos+3;
		if(pos!=0)
			pos=pos-1;;
		for(i=0;i<t[6];i++)
		{
			Create_Data_Type02(TmpBuff[pos+j],&SendBuff[SendLen]);//30
			SendLen=SendLen+2;
			j+=2;
		}
	}
	if(t[5]==3)
	{
		if(i==0xff)
		{
			t[0]=0;
			t[1]=1;
			t[6]=24;
		}
		memcpy(&SendBuff[SendLen],t,7);
		SendLen=SendLen+7;
		pos=((t[1]>>4)*10)+(t[1]&0x0f);
		pos=pos*4;
		if(t[0]==0x00)pos=pos+0;
		if(t[0]==0x15)pos=pos+1;
		if(t[0]==0x30)pos=pos+2;
		if(t[0]==0x45)pos=pos+3;
		if(pos!=0)
			pos=pos-1;;
		for(i=0;i<t[6];i++)
		{
			Create_Data_Type02(TmpBuff[pos+j],&SendBuff[SendLen]);//60
			SendLen=SendLen+2;
			j+=4;
		}
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F74(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U MiDu,i,j;
	INT8U pos;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_ZjQuXian(t,TmpBuff,P,82))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}

	MiDu=0;
	j=0;
	if(t[5]==0)
	{
	}
	if(t[5]==1)
	{
		if(i==0xff)
		{
			t[0]=0x15;
			t[1]=0;
			t[6]=96;

		}
		memcpy(&SendBuff[SendLen],t,7);
		SendLen=SendLen+7;
		pos=((t[1]>>4)*10)+(t[1]&0x0f);
		pos=pos*4;
		if(t[0]==0x00)pos=pos+0;
		if(t[0]==0x15)pos=pos+1;
		if(t[0]==0x30)pos=pos+2;
		if(t[0]==0x45)pos=pos+3;
		if(pos!=0)
			pos=pos-1;;
		for(i=0;i<t[6];i++)
		{
			Create_Data_Type02(TmpBuff[i+pos],&SendBuff[SendLen]);//15
			SendLen=SendLen+2;
		}
	}

	if(t[5]==2)
	{
		if(i==0xff)
		{
			t[0]=0x30;
			t[1]=0;
			t[6]=48;
		}
		memcpy(&SendBuff[SendLen],t,7);
		SendLen=SendLen+7;
		pos=((t[1]>>4)*10)+(t[1]&0x0f);
		pos=pos*4;
		if(t[0]==0x00)pos=pos+0;
		if(t[0]==0x15)pos=pos+1;
		if(t[0]==0x30)pos=pos+2;
		if(t[0]==0x45)pos=pos+3;
		if(pos!=0)
			pos=pos-1;
		for(i=0;i<t[6];i++)
		{
			Create_Data_Type02(TmpBuff[j+pos],&SendBuff[SendLen]);//30
			SendLen=SendLen+2;
			j+=2;
		}
	}

	if(t[5]==3)
	{
		if(i==0xff)
		{
			t[0]=0;
			t[1]=1;
			t[6]=24;
		}
		memcpy(&SendBuff[SendLen],t,7);
		SendLen=SendLen+7;
		pos=((t[1]>>4)*10)+(t[1]&0x0f);
		pos=pos*4;
		if(t[0]==0x00)pos=pos+0;
		if(t[0]==0x15)pos=pos+1;
		if(t[0]==0x30)pos=pos+2;
		if(t[0]==0x45)pos=pos+3;
		if(pos!=0)
			pos=pos-1;
		for(i=0;i<t[6];i++)
		{
			Create_Data_Type02(TmpBuff[j+pos],&SendBuff[SendLen]);//60
			SendLen=SendLen+2;
			j+=4;
		}
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F75(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U MiDu,i,j,k;
	INT32U Temp;
	INT8U pos;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_ZjQuXian(t,TmpBuff,P,83))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}

	MiDu=0;
	j=0;
	k=0;
	if(t[5]==0)
	{
	}
	if(t[5]==1)
	{
		if(i==0xff)
		{
			t[0]=0x15;
			t[1]=0;
			t[6]=96;
		}
		pos=((t[1]>>4)*10)+(t[1]&0x0f);
		pos=pos*4;
		if(t[0]==0x00)pos=pos+0;
		if(t[0]==0x15)pos=pos+1;
		if(t[0]==0x30)pos=pos+2;
		if(t[0]==0x45)pos=pos+3;
		if(pos!=0)
			pos=pos-1;
		memcpy(&SendBuff[SendLen],t,7);
		SendLen=SendLen+7;

		while(k<t[6])
		{
			SendBuff[SendLen+1]=((((k+pos)/4)/10)<<4)+(((k+pos)/4)%10);
			j=SendLen;
			if(k==0)
			SendBuff[13]=(SendBuff[13]&0x8f)|0x40;
			else
			SendBuff[13]=(SendBuff[13]&0x8f);
			for(i=0;i<96;i++)
			{
				DebugOut("<%d %d>",k,TmpBuff[i+k]);
				Create_Data_Type03(TmpBuff[k+pos],&SendBuff[SendLen]);//15
				SendLen=SendLen+4;
				k++;
				if(k>=t[6])
				{
					SendBuff[13]=(SendBuff[13]&0x8f)|0x2f;
					i++;
					break;
				}
			}
			//SendBuff[j+6]=i;
			EC();
			TP();
			FrameTailCreate_Send();
		}
		return 1;
	}

	if(t[5]==2)
	{
		if(i==0xff)
		{
			t[0]=0x30;
			t[1]=0;
			t[6]=48;
		}
		memcpy(&SendBuff[SendLen],t,7);
		SendLen=SendLen+7;
		pos=((t[1]>>4)*10)+(t[1]&0x0f);
		pos=pos*4;
		if(t[0]==0x00)pos=pos+0;
		if(t[0]==0x15)pos=pos+1;
		if(t[0]==0x30)pos=pos+2;
		if(t[0]==0x45)pos=pos+3;
		if(pos!=0)
			pos=pos-1;
		while((k/2)<t[6])
		{
			SendBuff[SendLen+1]=((((k+pos)/4)/10)<<4)+(((k+pos)/4)%10);
			j=SendLen;
			if(k==0)
			SendBuff[13]=(SendBuff[13]&0x8f)|0x40;
			else
			SendBuff[13]=(SendBuff[13]&0x8f);
			for(i=0;i<96;i++)
			{
				Temp=0;
				Temp=TmpBuff[k+pos]+TmpBuff[k+1+pos];
				DebugOut("<%d %d %d>",k,Temp,t[6]);
				Create_Data_Type03(Temp,&SendBuff[SendLen]);//30
				SendLen=SendLen+4;
				k+=2;
				if((k/2)>=t[6])
				{
					SendBuff[13]=(SendBuff[13]&0x8f)|0x2f;
					i++;
					break;
				}
			}
			EC();
			TP();
			FrameTailCreate_Send();
		}
		return 1;
	}
	if(t[5]==3)
	{
		if(i==0xff)
		{
			t[0]=0;
			t[1]=1;
			t[6]=24;
		}
		memcpy(&SendBuff[SendLen],t,7);
		SendLen=SendLen+7;

		pos=((t[1]>>4)*10)+(t[1]&0x0f);
		pos=pos*4;
		if(t[0]==0x00)pos=pos+0;
		if(t[0]==0x15)pos=pos+1;
		if(t[0]==0x30)pos=pos+2;
		if(t[0]==0x45)pos=pos+3;
		if(pos!=0)
			pos=pos-1;
		for(i=0;i<t[6];i++)
		{
			Temp=0;
			Temp=TmpBuff[j+pos]+TmpBuff[j+1+pos]+TmpBuff[j+2+pos]+TmpBuff[j+3+pos];
			Create_Data_Type03(Temp,&SendBuff[SendLen]);//60
			SendLen=SendLen+4;
			j+=4;
		}
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F76(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT32U Temp;
	INT8U MiDu,i,j,k;
	INT8U pos;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_ZjQuXian(t,TmpBuff,P,84))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}

	MiDu=0;
	j=0;
	k=0;
	if(t[5]==0)
	{
	}
	if(t[5]==1)
	{
		if(i==0xff)
		{
			t[0]=0x15;
			t[1]=0;
			t[6]=96;

		}
		memcpy(&SendBuff[SendLen],t,7);
		SendLen=SendLen+7;
		pos=((t[1]>>4)*10)+(t[1]&0x0f);
		pos=pos*4;
		if(t[0]==0x00)pos=pos+0;
		if(t[0]==0x15)pos=pos+1;
		if(t[0]==0x30)pos=pos+2;
		if(t[0]==0x45)pos=pos+3;
		if(pos!=0)
			pos=pos-1;
		while(k<t[6])
		{
			SendBuff[SendLen+1]=((((k+pos)/4)/10)<<4)+(((k+pos)/4)%10);
			j=SendLen;
			if(k==0)
			SendBuff[13]=(SendBuff[13]&0x8f)|0x40;
			else
			SendBuff[13]=(SendBuff[13]&0x8f);

			//SendLen=SendLen+7;
			for(i=0;i<96;i++)
			{
				DebugOut("<%d %d>",k,TmpBuff[i+k]);
				Create_Data_Type03(TmpBuff[k+pos],&SendBuff[SendLen]);//15
				SendLen=SendLen+4;
				k++;
				if(k>=t[6])
				{
					SendBuff[13]=(SendBuff[13]&0x8f)|0x2f;
					i++;
					break;
				}
			}
			EC();
			TP();
			FrameTailCreate_Send();
		}
		return 1;
	}

	if(t[5]==2)
	{
		if(i==0xff)
		{
			t[0]=0x30;
			t[1]=0;
			t[6]=48;
		}
		memcpy(&SendBuff[SendLen],t,7);
		SendLen=SendLen+7;
		pos=((t[1]>>4)*10)+(t[1]&0x0f);
		pos=pos*4;
		if(t[0]==0x00)pos=pos+0;
		if(t[0]==0x15)pos=pos+1;
		if(t[0]==0x30)pos=pos+2;
		if(t[0]==0x45)pos=pos+3;
		if(pos!=0)
			pos=pos-1;
		while((k/2)<t[6])
		{
			SendBuff[SendLen+1]=((((k+pos)/4)/10)<<4)+(((k+pos)/4)%10);
			j=SendLen;
			if(k==0)
			SendBuff[13]=(SendBuff[13]&0x8f)|0x40;
			else
			SendBuff[13]=(SendBuff[13]&0x8f);
			for(i=0;i<96;i++)
			{
				Temp=0;
				Temp=TmpBuff[k+pos]+TmpBuff[k+1+pos];
				DebugOut("<%d %d %d>",k,Temp,t[6]);
				Create_Data_Type03(Temp,&SendBuff[SendLen]);//30
				SendLen=SendLen+4;
				k+=2;
				if((k/2)>=t[6])
				{
					SendBuff[13]=(SendBuff[13]&0x8f)|0x2f;
					i++;
					break;
				}
			}
			EC();
			TP();
			FrameTailCreate_Send();
		}
		return 1;
	}

	if(t[5]==3)
	{
		if(i==0xff)
		{
			t[0]=0;
			t[1]=1;
			t[6]=24;
		}
		memcpy(&SendBuff[SendLen],t,7);
		SendLen=SendLen+7;
		pos=((t[1]>>4)*10)+(t[1]&0x0f);
		pos=pos*4;
		if(t[0]==0x00)pos=pos+0;
		if(t[0]==0x15)pos=pos+1;
		if(t[0]==0x30)pos=pos+2;
		if(t[0]==0x45)pos=pos+3;
		if(pos!=0)
			pos=pos-1;
		for(i=0;i<t[6];i++)
		{
			Temp=0;
			Temp=TmpBuff[j+pos]+TmpBuff[j+1+pos]+TmpBuff[j+2+pos]+TmpBuff[j+3+pos];
			Create_Data_Type03(Temp,&SendBuff[SendLen]);//60
			SendLen=SendLen+4;
			j+=4;
		}
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F81(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U MiDu,i,j,k=89;
	INT8U pos;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	switch(F)
	{
		case 81:k=89;break;
		case 82:k=90;break;
		case 83:k=91;break;
		case 84:k=92;break;
		case 85:k=93;break;
		case 86:k=94;break;
		case 87:k=95;break;
		case 88:k=96;break;
	}
	while(!RtuDataAddr->autoReport)
	{
		delay(200);
	}
	if(!Read_Day_ZjQuXian(t,TmpBuff,P,k))
	{
		DebugOut("\r\n%s p=%d f=%d ","��ȡ����ʧ��",P,F);
		if(i!=0xff)
			//SendNAK(F,P,0x0d);
			SendALLNAK();
		return 0;
	}

	MiDu=0;
	j=0;
	k=0;
	if(t[5]==0)
	{
	}
	if(t[5]==1)
	{
		if(i==0xff)
		{
			t[0]=0x15;
			t[1]=0;
			t[6]=96;
		}
		memcpy(&SendBuff[SendLen],t,7);
		SendLen=SendLen+7;
		pos=((t[1]>>4)*10)+(t[1]&0x0f);
		pos=pos*4;
		if(t[0]==0x00)pos=pos+0;
		if(t[0]==0x15)pos=pos+1;
		if(t[0]==0x30)pos=pos+2;
		if(t[0]==0x45)pos=pos+3;
		if(pos!=0)
			pos=pos-1;
		while(k<t[6])
		{
			//delay(80);
			SendBuff[SendLen+1]=((((k+pos)/4)/10)<<4)+(((k+pos)/4)%10);
			j=SendLen;
			if(k==0)
			SendBuff[13]=(SendBuff[13]&0x8f)|0x40;
			else
			SendBuff[13]=(SendBuff[13]&0x8f);
			for(i=0;i<96;i++)
			{
				DebugOut("<%d %d>",k,TmpBuff[i+k]);
				INT32ToBCD(TmpBuff[k+pos],&SendBuff[SendLen],3);//30
				SendLen=SendLen+3;
				k++;
				if(k>=t[6])
				{
					SendBuff[13]=(SendBuff[13]&0x8f)|0x2f;
					i++;
					break;
				}
			}
			EC();
			TP();
			FrameTailCreate_Send();
		}
		return 1;
	}

	if(t[5]==2)
	{
		if(i==0xff)
		{
			t[0]=0x30;
			t[1]=0;
			t[6]=48;
		}
		memcpy(&SendBuff[SendLen],t,7);
		SendLen=SendLen+7;
		pos=((t[1]>>4)*10)+(t[1]&0x0f);
		pos=pos*4;
		if(t[0]==0x00)pos=pos+0;
		if(t[0]==0x15)pos=pos+1;
		if(t[0]==0x30)pos=pos+2;
		if(t[0]==0x45)pos=pos+3;
		if(pos!=0)
			pos=pos-1;

		while((k/2)<t[6])
		{
			//delay(80);
			SendBuff[SendLen+1]=((((k+pos)/4)/10)<<4)+(((k+pos)/4)%10);
			j=SendLen;
			if(k==0)
			SendBuff[13]=(SendBuff[13]&0x8f)|0x40;
			else
			SendBuff[13]=(SendBuff[13]&0x8f);
			for(i=0;i<96;i++)
			{
				INT32ToBCD(TmpBuff[k+pos],&SendBuff[SendLen],3);//30
				SendLen=SendLen+3;
				k+=2;
				if((k/2)>=t[6])
				{
					SendBuff[13]=(SendBuff[13]&0x8f)|0x2f;
					i++;
					break;
				}
			}
			EC();
			TP();
			FrameTailCreate_Send();
		}
		return 1;
	}

	//delay(80);
	if(t[5]==3)
	{
		if(i==0xff)
		{
			t[0]=0;
			t[1]=1;
			t[6]=24;
		}
		memcpy(&SendBuff[SendLen],t,7);
		SendLen=SendLen+7;
		pos=((t[1]>>4)*10)+(t[1]&0x0f);
		pos=pos*4;
		if(t[0]==0x00)pos=pos+0;
		if(t[0]==0x15)pos=pos+1;
		if(t[0]==0x30)pos=pos+2;
		if(t[0]==0x45)pos=pos+3;
		if(pos!=0)
			pos=pos-1;
		for(i=0;i<t[6];i++)
		{
			INT32ToBCD(TmpBuff[j+pos],&SendBuff[SendLen],3);//60
			SendLen=SendLen+3;
			j+=4;
		}
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F89(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{

	INT8U MiDu,i,j,k=97;
	INT8U pos;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	switch(F)
	{
		case 89:k=97;break;
		case 90:k=98;break;
		case 91:k=99;break;
	}
	while(!RtuDataAddr->autoReport)
	{
		delay(200);
	}
	if(!Read_Day_ZjQuXian(t,TmpBuff,P,k))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}

	MiDu=0;
	j=0;
	k=0;
	if(t[5]==0)
	{
	}
	if(t[5]==1)
	{
		if(i==0xff)
		{
			t[0]=0x15;
			t[1]=0;
			t[6]=96;

		}
		memcpy(&SendBuff[SendLen],t,7);
		SendLen=SendLen+7;
		pos=((t[1]>>4)*10)+(t[1]&0x0f);
		pos=pos*4;
		if(t[0]==0x00)pos=pos+0;
		if(t[0]==0x15)pos=pos+1;
		if(t[0]==0x30)pos=pos+2;
		if(t[0]==0x45)pos=pos+3;
		if(pos!=0)
			pos=pos-1;
		while(k<t[6])
		{
			//delay(80);
			SendBuff[SendLen+1]=((((k+pos)/4)/10)<<4)+(((k+pos)/4)%10);
			j=SendLen;
			if(k==0)
			SendBuff[13]=(SendBuff[13]&0x8f)|0x40;
			else
			SendBuff[13]=(SendBuff[13]&0x8f);
			for(i=0;i<96;i++)
			{
				INT32ToBCD(TmpBuff[k+pos],&SendBuff[SendLen],2);//
				SendLen=SendLen+2;
				k++;
				if(k>=t[6])
				{
					SendBuff[13]=(SendBuff[13]&0x8f)|0x2f;
					i++;
					break;
				}
			}
			EC();
			TP();
			FrameTailCreate_Send();
		}
		return 1;
	}

	if(t[5]==2)
	{
		if(i==0xff)
		{
			t[0]=0x30;
			t[1]=0;
			t[6]=48;
		}
		memcpy(&SendBuff[SendLen],t,7);
		SendLen=SendLen+7;
		pos=((t[1]>>4)*10)+(t[1]&0x0f);
		pos=pos*4;
		if(t[0]==0x00)pos=pos+0;
		if(t[0]==0x15)pos=pos+1;
		if(t[0]==0x30)pos=pos+2;
		if(t[0]==0x45)pos=pos+3;
		if(pos!=0)
			pos=pos-1;
		while((k/2)<t[6])
		{
			//delay(80);
			SendBuff[SendLen+1]=((((k+pos)/4)/10)<<4)+(((k+pos)/4)%10);
			j=SendLen;
			if(k==0)
			SendBuff[13]=(SendBuff[13]&0x8f)|0x40;
			else
			SendBuff[13]=(SendBuff[13]&0x8f);
			for(i=0;i<96;i++)
			{
				INT32ToBCD(TmpBuff[k+pos],&SendBuff[SendLen],2);//30
				SendLen=SendLen+2;
				k+=2;
				if((k/2)>=t[6])
				{
				i++;
					SendBuff[13]=(SendBuff[13]&0x8f)|0x2f;
					break;
				}
			}
			EC();
			TP();
			FrameTailCreate_Send();
		}
		return 1;
	}

	//delay(80);
	if(t[5]==3)
	{
		if(i==0xff)
		{
			t[0]=0;
			t[1]=1;
			t[6]=24;
		}
		memcpy(&SendBuff[SendLen],t,7);
		SendLen=SendLen+7;
		pos=((t[1]>>4)*10)+(t[1]&0x0f);
		pos=pos*4;
		if(t[0]==0x00)pos=pos+0;
		if(t[0]==0x15)pos=pos+1;
		if(t[0]==0x30)pos=pos+2;
		if(t[0]==0x45)pos=pos+3;
		if(pos!=0)
			pos=pos-1;
		for(i=0;i<t[6];i++)
		{
			INT32ToBCD(TmpBuff[j+pos],&SendBuff[SendLen],2);//60
			SendLen=SendLen+2;
			j+=4;
		}
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F92(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{

	INT8U MiDu,i,j,k=97;
	INT8U pos;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	switch(F)
	{
		case 92:k=100;break;
		case 93:k=101;break;
		case 94:k=102;break;
		case 95:k=103;break;
	}
	while(!RtuDataAddr->autoReport)
	{
		delay(200);
	}
	if(!Read_Day_ZjQuXian(t,TmpBuff,P,k))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}

	MiDu=0;
	j=0;
	k=0;
	if(t[5]==0)
	{
	}
	if(t[5]==1)
	{
		if(i==0xff)
		{
			t[0]=0x15;
			t[1]=0;
			t[6]=96;

		}
		memcpy(&SendBuff[SendLen],t,7);
		SendLen=SendLen+7;
		pos=((t[1]>>4)*10)+(t[1]&0x0f);
		pos=pos*4;
		if(t[0]==0x00)pos=pos+0;
		if(t[0]==0x15)pos=pos+1;
		if(t[0]==0x30)pos=pos+2;
		if(t[0]==0x45)pos=pos+3;
		if(pos!=0)
			pos=pos-1;
		while(k<t[6])
		{
			SendBuff[SendLen+1]=((((k+pos)/4)/10)<<4)+(((k+pos)/4)%10);
			j=SendLen;
			if(k==0)
			SendBuff[13]=(SendBuff[13]&0x8f)|0x40;
			else
			SendBuff[13]=(SendBuff[13]&0x8f);
			for(i=0;i<96;i++)
			{
				INT32ToBCD(TmpBuff[k+pos]*10,&SendBuff[SendLen],3);//
				SendLen=SendLen+3;
				k++;
				if(k>=t[6])
				{
					SendBuff[13]=(SendBuff[13]&0x8f)|0x2f;
					i++;
					break;
				}
			}
			EC();
			TP();
			FrameTailCreate_Send();
		}
		return 1;
	}

	if(t[5]==2)
	{
		if(i==0xff)
		{
			t[0]=0x30;
			t[1]=0;
			t[6]=48;
		}
		memcpy(&SendBuff[SendLen],t,7);
		SendLen=SendLen+7;
		pos=((t[1]>>4)*10)+(t[1]&0x0f);
		pos=pos*4;
		if(t[0]==0x00)pos=pos+0;
		if(t[0]==0x15)pos=pos+1;
		if(t[0]==0x30)pos=pos+2;
		if(t[0]==0x45)pos=pos+3;
		if(pos!=0)
			pos=pos-1;
		while((k/2)<t[6])
		{
			SendBuff[SendLen+1]=((((k+pos)/4)/10)<<4)+(((k+pos)/4)%10);
			j=SendLen;
			if(k==0)
			SendBuff[13]=(SendBuff[13]&0x8f)|0x40;
			else
			SendBuff[13]=(SendBuff[13]&0x8f);
			for(i=0;i<96;i++)
			{
				INT32ToBCD(TmpBuff[k+pos]*10,&SendBuff[SendLen],3);//30
				SendLen=SendLen+3;
				k+=2;
				if((k/2)>=t[6])
				{
				i++;
					SendBuff[13]=(SendBuff[13]&0x8f)|0x2f;
					break;
				}
			}
			EC();
			TP();
			FrameTailCreate_Send();
		}
		return 1;
	}

	if(t[5]==3)
	{
		if(i==0xff)
		{
			t[0]=0;
			t[1]=1;
			t[6]=24;
		}
		memcpy(&SendBuff[SendLen],t,7);
		SendLen=SendLen+7;
		pos=((t[1]>>4)*10)+(t[1]&0x0f);
		pos=pos*4;
		if(t[0]==0x00)pos=pos+0;
		if(t[0]==0x15)pos=pos+1;
		if(t[0]==0x30)pos=pos+2;
		if(t[0]==0x45)pos=pos+3;
		if(pos!=0)
			pos=pos-1;
		for(i=0;i<t[6];i++)
		{
			INT32ToBCD(TmpBuff[j+pos]*10,&SendBuff[SendLen],3);//60
			SendLen=SendLen+3;
			j+=4;
		}
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}

INT8U Set_Level2_F97(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{

	INT8U MiDu,i,j,k=105;
	INT8U pos;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	switch(F)
	{
		case 97:k=105;break;
		case 98:k=106;break;
		case 99:k=107;break;
		case 100:k=108;break;
	}
	if(!Read_Day_ZjQuXian(t,TmpBuff,P,k))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}

	MiDu=0;
	j=0;
	k=0;
	if(t[5]==0)
	{
	}
	if(t[5]==1)
	{
		if(i==0xff)
		{
			t[0]=0x15;
			t[1]=0;
			t[6]=96;

		}
		memcpy(&SendBuff[SendLen],t,7);
		SendLen=SendLen+7;
		pos=((t[1]>>4)*10)+(t[1]&0x0f);
		pos=pos*4;
		if(t[0]==0x00)pos=pos+0;
		if(t[0]==0x15)pos=pos+1;
		if(t[0]==0x30)pos=pos+2;
		if(t[0]==0x45)pos=pos+3;
		if(pos!=0)
			pos=pos-1;
		while(k<t[6])
		{
			SendBuff[SendLen+1]=((((k+pos)/4)/10)<<4)+(((k+pos)/4)%10);
			j=SendLen;
			if(k==0)
			SendBuff[13]=(SendBuff[13]&0x8f)|0x40;
			else
			SendBuff[13]=(SendBuff[13]&0x8f);
			for(i=0;i<96;i++)
			{
				INT32ToBCD(TmpBuff[k+pos]*100,&SendBuff[SendLen],4);//60
				SendLen=SendLen+4;

				k++;
				if(k>=t[6])
				{
					SendBuff[13]=(SendBuff[13]&0x8f)|0x2f;
					i++;
					break;
				}
			}
			EC();
			TP();
			FrameTailCreate_Send();
			//delay(80);
		}
		return 1;
	}

	if(t[5]==2)
	{
		if(i==0xff)
		{
			t[0]=0x30;
			t[1]=0;
			t[6]=48;
		}
		memcpy(&SendBuff[SendLen],t,7);
		SendLen=SendLen+7;
		pos=((t[1]>>4)*10)+(t[1]&0x0f);
		pos=pos*4;
		if(t[0]==0x00)pos=pos+0;
		if(t[0]==0x15)pos=pos+1;
		if(t[0]==0x30)pos=pos+2;
		if(t[0]==0x45)pos=pos+3;
		if(pos!=0)
			pos=pos-1;
		while((k/2)<t[6])
		{
			SendBuff[SendLen+1]=((((k+pos)/4)/10)<<4)+(((k+pos)/4)%10);
			j=SendLen;
			if(k==0)
			SendBuff[13]=(SendBuff[13]&0x8f)|0x40;
			else
			SendBuff[13]=(SendBuff[13]&0x8f);
			for(i=0;i<96;i++)
			{
				INT32ToBCD(TmpBuff[k+pos]*100,&SendBuff[SendLen],4);//60
				SendLen=SendLen+4;
				k+=2;
				if((k/2)>=t[6])
				{
					SendBuff[13]=(SendBuff[13]&0x8f)|0x2f;
					i++;
					break;
				}
			}
			EC();
			TP();
			FrameTailCreate_Send();
			//delay(80);
		}
		return 1;
	}

	if(t[5]==3)
	{
		if(i==0xff)
		{
			t[0]=0;
			t[1]=1;
			t[6]=24;
		}
		memcpy(&SendBuff[SendLen],t,7);
		SendLen=SendLen+7;
		pos=((t[1]>>4)*10)+(t[1]&0x0f);
		pos=pos*4;
		if(t[0]==0x00)pos=pos+0;
		if(t[0]==0x15)pos=pos+1;
		if(t[0]==0x30)pos=pos+2;
		if(t[0]==0x45)pos=pos+3;
		if(pos!=0)
			pos=pos-1;
		for(i=0;i<t[6];i++)
		{
			INT32ToBCD(TmpBuff[j+pos]*100,&SendBuff[SendLen],4);//60
			SendLen=SendLen+4;
			j+=4;
		}
	}
	EC();
	TP();
	FrameTailCreate_Send();
	//delay(80);
	return 1;
}
INT8U Set_Level2_F101(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{

	INT8U MiDu,i,j,k=109;
	INT8U pos;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	switch(F)
	{
		case 101:k=109;break;
		case 102:k=110;break;
		case 103:k=111;break;
		case 104:k=112;break;
	}
	while(!RtuDataAddr->autoReport)
	{
		delay(200);
	}
	if(!Read_Day_ZjQuXian(t,TmpBuff,P,k))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}

	MiDu=0;

	j=0;
	k=0;
	if(t[5]==0)
	{
	}
	if(t[5]==1)
	{
		if(i==0xff)
		{
			t[0]=0x15;
			t[1]=0;
			t[6]=96;
		}
		memcpy(&SendBuff[SendLen],t,7);
		SendLen=SendLen+7;
		pos=((t[1]>>4)*10)+(t[1]&0x0f);
		pos=pos*4;
		if(t[0]==0x00)pos=pos+0;
		if(t[0]==0x15)pos=pos+1;
		if(t[0]==0x30)pos=pos+2;
		if(t[0]==0x45)pos=pos+3;
		if(pos!=0)
			pos=pos-1;

		while(k<t[6])
		{
			//delay(80);

			SendBuff[SendLen+1]=((((k+pos)/4)/10)<<4)+(((k+pos)/4)%10);
			j=SendLen;
			if(k==0)
			SendBuff[13]=(SendBuff[13]&0x8f)|0x40;
			else
			SendBuff[13]=(SendBuff[13]&0x8f);
			for(i=0;i<96;i++)
			{
				INT32ToBCD(TmpBuff[k+pos],&SendBuff[SendLen],4);//60
				SendLen=SendLen+4;
				printf("\n\rkkkkkkkkkk==== %d",k);
				k++;
				//k=k+QxBl;
				if((k>=t[6]))
				{
					printf("\n\riiiiiiiii==== %d",i);
					SendBuff[13]=(SendBuff[13]&0x8f)|0x2f;
					i++;
					break;
				}
			}
			////EC();
			////TP();
			////FrameTailCreate_Send();
		}
		EC();
		TP();
		FrameTailCreate_Send();
		return 1;
	}

	if(t[5]==2)
	{
		if(i==0xff)
		{
			t[0]=0x30;
			t[1]=0;
			t[6]=48;
		}
		memcpy(&SendBuff[SendLen],t,7);
		SendLen=SendLen+7;
		pos=((t[1]>>4)*10)+(t[1]&0x0f);
		pos=pos*4;
		if(t[0]==0x00)pos=pos+0;
		if(t[0]==0x15)pos=pos+1;
		if(t[0]==0x30)pos=pos+2;
		if(t[0]==0x45)pos=pos+3;
		if(pos!=0)
			pos=pos-1;
		while((k/2)<t[6])
		{
			//delay(80);
			SendBuff[SendLen+1]=((((k+pos)/4)/10)<<4)+(((k+pos)/4)%10);
			j=SendLen;
			if(k==0)
			SendBuff[13]=(SendBuff[13]&0x8f)|0x40;
			else
			SendBuff[13]=(SendBuff[13]&0x8f);
			for(i=0;i<96;i++)
			{
				INT32ToBCD(TmpBuff[k+pos],&SendBuff[SendLen],4);//60
				SendLen=SendLen+4;
				k+=2;
				////k=k+2*QxBl;
				if((k/2)>=t[6])
				{
				i++;
					SendBuff[13]=(SendBuff[13]&0x8f)|0x2f;
					break;
				}
			}
			////EC();
			////TP();
			////FrameTailCreate_Send();
		}
		EC();
		TP();
		FrameTailCreate_Send();
		return 1;
	}

	//delay(80);
	if(t[5]==3)
	{
		//printf("\n\rdongjie midu is %d",t[5]);
		if(i==0xff)
		{
			t[0]=0;
			t[1]=1;
			t[6]=24;
		}
		memcpy(&SendBuff[SendLen],t,7);
		SendLen=SendLen+7;
		pos=((t[1]>>4)*10)+(t[1]&0x0f);
		pos=pos*4;
		if(t[0]==0x00)pos=pos+0;
		if(t[0]==0x15)pos=pos+1;
		if(t[0]==0x30)pos=pos+2;
		if(t[0]==0x45)pos=pos+3;
		if(pos!=0)
			pos=pos-1;
//		printf("\n\rpospospos==== %d",pos);
//		printf("\n\rshu ju dian shu==== %d",t[6]);
		for(i=0;i<t[6];i++)
		{
			if((j+pos)<96)
			{
				INT32ToBCD(TmpBuff[j+pos],&SendBuff[SendLen],4);//60
				SendLen=SendLen+4;
				j=j+4;
				//j=j+4*QxBl;
			}
		}
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F105(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{

	INT8U MiDu,i,j,k=105;
	INT8U pos;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	switch(F)
	{
		case 105:k=113;break;
		case 106:k=114;break;
		case 107:k=115;break;
		case 108:k=116;break;
	}
	while(!RtuDataAddr->autoReport)
	{
		delay(200);
	}
	if(!Read_Day_ZjQuXian(t,TmpBuff,P,k))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}

	MiDu=0;

	j=0;
	k=0;
	if(t[5]==0)
	{
	}
	if(t[5]==1)
	{
		if(i==0xff)
		{
			t[0]=0x15;
			t[1]=0;
			t[6]=96;

		}
		memcpy(&SendBuff[SendLen],t,7);
		SendLen=SendLen+7;
		pos=((t[1]>>4)*10)+(t[1]&0x0f);
		pos=pos*4;
		if(t[0]==0x00)pos=pos+0;
		if(t[0]==0x15)pos=pos+1;
		if(t[0]==0x30)pos=pos+2;
		if(t[0]==0x45)pos=pos+3;
		if(pos!=0)
			pos=pos-1;
		while(k<t[6])
		{
			//delay(80);
			SendBuff[SendLen+1]=((((k+pos)/4)/10)<<4)+(((k+pos)/4)%10);
			j=SendLen;
			if(k==0)
			SendBuff[13]=(SendBuff[13]&0x8f)|0x40;
			else
			SendBuff[13]=(SendBuff[13]&0x8f);
			for(i=0;i<96;i++)
			{
				INT32ToBCD(TmpBuff[k+pos],&SendBuff[SendLen],2);//60
				SendLen=SendLen+2;
				k++;
				if(k>=t[6])
				{
					SendBuff[13]=(SendBuff[13]&0x8f)|0x2f;
					i++;
					break;
				}
			}
			EC();
			TP();
			FrameTailCreate_Send();
		}
		return 1;
	}

	if(t[5]==2)
	{
		if(i==0xff)
		{
			t[0]=0x30;
			t[1]=0;
			t[6]=48;
		}
		memcpy(&SendBuff[SendLen],t,7);
		SendLen=SendLen+7;
		pos=((t[1]>>4)*10)+(t[1]&0x0f);
		pos=pos*4;
		if(t[0]==0x00)pos=pos+0;
		if(t[0]==0x15)pos=pos+1;
		if(t[0]==0x30)pos=pos+2;
		if(t[0]==0x45)pos=pos+3;
		if(pos!=0)
			pos=pos-1;
		while((k/2)<t[6])
		{
			//delay(80);
			SendBuff[SendLen+1]=((((k+pos)/4)/10)<<4)+(((k+pos)/4)%10);
			j=SendLen;
			if(k==0)
			SendBuff[13]=(SendBuff[13]&0x8f)|0x40;
			else
			SendBuff[13]=(SendBuff[13]&0x8f);
			for(i=0;i<96;i++)
			{
				INT32ToBCD(TmpBuff[k+pos],&SendBuff[SendLen],2);//60
				SendLen=SendLen+2;
				k+=2;
				if((k/2)>=t[6])
				{
				i++;
					SendBuff[13]=(SendBuff[13]&0x8f)|0x2f;
					break;
				}
			}
			EC();
			TP();
			FrameTailCreate_Send();
		}
		return 1;
	}

	//delay(80);
	if(t[5]==3)
	{
		if(i==0xff)
		{
			t[0]=0;
			t[1]=1;
			t[6]=24;
		}
		memcpy(&SendBuff[SendLen],t,7);
		SendLen=SendLen+7;
		pos=((t[1]>>4)*10)+(t[1]&0x0f);
		pos=pos*4;
		if(t[0]==0x00)pos=pos+0;
		if(t[0]==0x15)pos=pos+1;
		if(t[0]==0x30)pos=pos+2;
		if(t[0]==0x45)pos=pos+3;
		if(pos!=0)
			pos=pos-1;
		for(i=0;i<t[6];i++)
		{
			INT32ToBCD(TmpBuff[j+pos],&SendBuff[SendLen],2);//60
			SendLen=SendLen+2;
			j+=4;
		}
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F113(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i,j;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_XieBo(t,&XieBo_QuXian,P))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	for(j=2;j<20;j++)
	{
		INT32ToBCD(XieBo_QuXian.IAxb_Max[i],&SendBuff[SendLen],2);
		SendLen=SendLen+2;
	}
	for(j=2;j<20;j++)
	{
		memcpy(&SendBuff[SendLen],&XieBo_QuXian.IAxb_Max_Time,4);
		SendLen=SendLen+4;
	}
	memcpy(&SendBuff[SendLen],&XieBo_QuXian.IA_ZongJiBian_Max,2);
	SendLen=SendLen+2;
	memcpy(&SendBuff[SendLen],&XieBo_QuXian.IA_ZongJiBian_Max_Time,4);
	SendLen=SendLen+4;

	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F114(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i,j;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_XieBo(t,&XieBo_QuXian,P))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	for(j=2;j<20;j++)
	{
		INT32ToBCD(XieBo_QuXian.IBxb_Max[i],&SendBuff[SendLen],2);
		SendLen=SendLen+2;
	}
	for(j=2;j<20;j++)
	{
		memcpy(&SendBuff[SendLen],&XieBo_QuXian.IBxb_Max_Time,4);
		SendLen=SendLen+4;
	}
	memcpy(&SendBuff[SendLen],&XieBo_QuXian.IB_ZongJiBian_Max,2);
	SendLen=SendLen+2;
	memcpy(&SendBuff[SendLen],&XieBo_QuXian.IB_ZongJiBian_Max_Time,4);
	SendLen=SendLen+4;

	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F115(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i,j;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_XieBo(t,&XieBo_QuXian,P))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	for(j=2;j<20;j++)
	{
		INT32ToBCD(XieBo_QuXian.ICxb_Max[i],&SendBuff[SendLen],2);
		SendLen=SendLen+2;
	}
	for(j=2;j<20;j++)
	{
		memcpy(&SendBuff[SendLen],&XieBo_QuXian.ICxb_Max_Time,4);
		SendLen=SendLen+4;
	}
	memcpy(&SendBuff[SendLen],&XieBo_QuXian.IC_ZongJiBian_Max,2);
	SendLen=SendLen+2;
	memcpy(&SendBuff[SendLen],&XieBo_QuXian.IC_ZongJiBian_Max_Time,4);
	SendLen=SendLen+4;

	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F116(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i,j;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_XieBo(t,&XieBo_QuXian,P))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	for(j=2;j<20;j++)
	{
		INT32ToBCD(XieBo_QuXian.UA_Hanyoulv_Max[i],&SendBuff[SendLen],2);
		SendLen=SendLen+2;
	}
	for(j=2;j<20;j++)
	{
		memcpy(&SendBuff[SendLen],&XieBo_QuXian.UA_Hanyoulv_Max_Time,4);
		SendLen=SendLen+4;
	}
	memcpy(&SendBuff[SendLen],&XieBo_QuXian.UA_ZongJiBianLv_Max,2);
	SendLen=SendLen+2;
	memcpy(&SendBuff[SendLen],&XieBo_QuXian.UA_ZongJiBianLv_Max_Time,4);
	SendLen=SendLen+4;

	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F117(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i,j;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_XieBo(t,&XieBo_QuXian,P))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	for(j=2;j<20;j++)
	{
		INT32ToBCD(XieBo_QuXian.UB_Hanyoulv_Max[i],&SendBuff[SendLen],2);
		SendLen=SendLen+2;
	}
	for(j=2;j<20;j++)
	{
		memcpy(&SendBuff[SendLen],&XieBo_QuXian.UB_Hanyoulv_Max_Time,4);
		SendLen=SendLen+4;
	}
	memcpy(&SendBuff[SendLen],&XieBo_QuXian.UB_ZongJiBianLv_Max,2);
	SendLen=SendLen+2;
	memcpy(&SendBuff[SendLen],&XieBo_QuXian.UB_ZongJiBianLv_Max_Time,4);
	SendLen=SendLen+4;

	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F118(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i,j;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_XieBo(t,&XieBo_QuXian,P))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	for(j=2;j<20;j++)
	{
		INT32ToBCD(XieBo_QuXian.UC_Hanyoulv_Max[i],&SendBuff[SendLen],2);
		SendLen=SendLen+2;
	}
	for(j=2;j<20;j++)
	{
		memcpy(&SendBuff[SendLen],&XieBo_QuXian.UC_Hanyoulv_Max_Time,4);
		SendLen=SendLen+4;
	}
	memcpy(&SendBuff[SendLen],&XieBo_QuXian.UC_ZongJiBianLv_Max,2);
	SendLen=SendLen+2;
	memcpy(&SendBuff[SendLen],&XieBo_QuXian.UC_ZongJiBianLv_Max_Time,4);
	SendLen=SendLen+4;

	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F121(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i,j;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_XieBo(t,&XieBo_QuXian,P))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	SendBuff[SendLen++]=19;
	SendBuff[SendLen++]=XieBo_QuXian.U_ZongJiBian_UCount;
	for(j=2;j<20;j++)
	{
		INT32ToBCD(XieBo_QuXian.U_GeCi_UCount[i],&SendBuff[SendLen],2);
		SendLen=SendLen+2;
	}
	SendBuff[SendLen++]=XieBo_QuXian.U_ZongJiBian_ICount;
	for(j=2;j<20;j++)
	{
		memcpy(&SendBuff[SendLen],&XieBo_QuXian.U_GeCi_ICount[i],2);
		SendLen=SendLen+2;
	}

	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F122(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i,j;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_XieBo(t,&XieBo_QuXian,P))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	SendBuff[SendLen++]=19;
	SendBuff[SendLen++]=XieBo_QuXian.V_ZongJiBian_UCount;
	for(j=2;j<20;j++)
	{
		INT32ToBCD(XieBo_QuXian.V_GeCi_UCount[i],&SendBuff[SendLen],2);
		SendLen=SendLen+2;
	}
	SendBuff[SendLen++]=XieBo_QuXian.V_ZongJiBian_ICount;
	for(j=2;j<20;j++)
	{
		memcpy(&SendBuff[SendLen],&XieBo_QuXian.V_GeCi_ICount[i],2);
		SendLen=SendLen+2;
	}

	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F123(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i,j;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_XieBo(t,&XieBo_QuXian,P))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	SendBuff[SendLen++]=19;
	SendBuff[SendLen++]=XieBo_QuXian.W_ZongJiBian_UCount;
	for(j=2;j<20;j++)
	{
		INT32ToBCD(XieBo_QuXian.W_GeCi_UCount[i],&SendBuff[SendLen],2);
		SendLen=SendLen+2;
	}
	SendBuff[SendLen++]=XieBo_QuXian.W_ZongJiBian_ICount;
	for(j=2;j<20;j++)
	{
		memcpy(&SendBuff[SendLen],&XieBo_QuXian.W_GeCi_ICount[i],2);
		SendLen=SendLen+2;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F161(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT16U i;
	MkLevel2Head(P,F,FRM);
	i=t[0];
	printf("\n\rt[0] ==%x t[1]===%x t[2]==%x",t[0],t[1],t[2]);
	printf("\n\r");
	if(!Read_Day_ClHisDianneng(t,&Tmp_DD_BS_Value,P))
	{
		if(i!=0xff)
			//SendNAK(F,P,0x0d);
			SendALLNAK();
			return 0;
	}
	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&Tmp_DD_BS_Value.Chao_Time.BCD01,5);
	SendLen=SendLen+5;
	SendBuff[SendLen++]=4;
	SendBuff[SendLen++]=0;
	INT32ToBCD(Tmp_DD_BS_Value.Z_P_All_S,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
		SendBuff[SendLen++]=0;
		INT32ToBCD(Tmp_DD_BS_Value.Z_P_F_S[i],&SendBuff[SendLen],4);
		SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F162(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT16U i;
	MkLevel2Head(P,F,FRM);
	i=t[0];
	//printf("\n\rt[0] ==%x t[1]===%x t[2]==%x",t[0],t[1],t[2]);
	//printf("\n\r");
	if(!Read_Day_ClHisDianneng(t,&Tmp_DD_BS_Value,P))
	{
		if(i!=0xff)
			//SendNAK(F,P,0x0d);
			SendALLNAK();
			return 0;
	}
	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&Tmp_DD_BS_Value.Chao_Time.BCD01,5);
	SendLen=SendLen+5;
	SendBuff[SendLen++]=4;

	INT32ToBCD(Tmp_DD_BS_Value.Z_Q_All_S,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_BS_Value.Z_Q_F_S[i],&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F163(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_ClHisDianneng(t,&Tmp_DD_BS_Value,P))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&Tmp_DD_BS_Value.Chao_Time.BCD01,5);
	SendLen=SendLen+5;
	SendBuff[SendLen++]=4;
	SendBuff[SendLen++]=0;
	INT32ToBCD(Tmp_DD_BS_Value.F_P_All_S,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
		SendBuff[SendLen++]=0;
		INT32ToBCD(Tmp_DD_BS_Value.F_P_F_S[i],&SendBuff[SendLen],4);
		SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F164(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_ClHisDianneng(t,&Tmp_DD_BS_Value,P))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&Tmp_DD_BS_Value.Chao_Time.BCD01,5);
	SendLen=SendLen+5;
	SendBuff[SendLen++]=4;

	INT32ToBCD(Tmp_DD_BS_Value.F_Q_All_S,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_BS_Value.F_Q_F_S[i],&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F165(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT16U i;
	MkLevel2Head(P,F,FRM);
	i=t[0];
	//printf("\n\rt[0] ==%x t[1]===%x t[2]==%x",t[0],t[1],t[2]);
	//printf("\n\r");
	if(!Read_Day_ClHisDianneng(t,&Tmp_DD_BS_Value,P))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&Tmp_DD_BS_Value.Chao_Time.BCD01,5);
	SendLen=SendLen+5;
	SendBuff[SendLen++]=4;

	INT32ToBCD(Tmp_DD_BS_Value.X1_Q_All,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_BS_Value.X1_F_Q[i],&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F166(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_ClHisDianneng(t,&Tmp_DD_BS_Value,P))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&Tmp_DD_BS_Value.Chao_Time.BCD01,5);
	SendLen=SendLen+5;
	SendBuff[SendLen++]=4;

	INT32ToBCD(Tmp_DD_BS_Value.X2_Q_All,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_BS_Value.X2_F_Q[i],&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F167(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_ClHisDianneng(t,&Tmp_DD_BS_Value,P))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&Tmp_DD_BS_Value.Chao_Time.BCD01,5);
	SendLen=SendLen+5;
	SendBuff[SendLen++]=4;

	INT32ToBCD(Tmp_DD_BS_Value.X3_Q_All,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_BS_Value.X3_F_Q[i],&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F168(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT16U i;
	MkLevel2Head(P,F,FRM);
	i=t[0];
	//printf("\n\rt[0] ==%x t[1]===%x t[2]==%x",t[0],t[1],t[2]);
	//printf("\n\r");
	if(!Read_Day_ClHisDianneng(t,&Tmp_DD_BS_Value,P))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&Tmp_DD_BS_Value.Chao_Time.BCD01,5);
	SendLen=SendLen+5;
	SendBuff[SendLen++]=4;

	INT32ToBCD(Tmp_DD_BS_Value.X4_Q_All,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_BS_Value.X4_F_Q[i],&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F177(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Yue_ClHisDianneng(&Tmp_DD_BS_Value,P,t))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}

	memcpy(&SendBuff[SendLen],t,2);
	SendLen=SendLen+2;
	memcpy(&SendBuff[SendLen],&Tmp_DD_BS_Value.Chao_Time.BCD01,5);
	SendLen=SendLen+5;
	SendBuff[SendLen++]=4;
	SendBuff[SendLen++]=0;
	INT32ToBCD(Tmp_DD_BS_Value.Z_P_All_S,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	SendBuff[SendLen++]=0;
	INT32ToBCD(Tmp_DD_BS_Value.Z_P_F_S[i],&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F178(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Yue_ClHisDianneng(&Tmp_DD_BS_Value,P,t))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	memcpy(&SendBuff[SendLen],t,2);
	SendLen=SendLen+2;
	memcpy(&SendBuff[SendLen],&Tmp_DD_BS_Value.Chao_Time.BCD01,5);
	SendLen=SendLen+5;
	SendBuff[SendLen++]=4;

	INT32ToBCD(Tmp_DD_BS_Value.Z_Q_All_S,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_BS_Value.Z_Q_F_S[i],&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F179(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Yue_ClHisDianneng(&Tmp_DD_BS_Value,P,t))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}

	memcpy(&SendBuff[SendLen],t,2);
	SendLen=SendLen+2;
	memcpy(&SendBuff[SendLen],&Tmp_DD_BS_Value.Chao_Time.BCD01,5);
	SendLen=SendLen+5;
	SendBuff[SendLen++]=4;
	SendBuff[SendLen++]=0;
	INT32ToBCD(Tmp_DD_BS_Value.F_P_All_S,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	SendBuff[SendLen++]=0;
	INT32ToBCD(Tmp_DD_BS_Value.F_P_F_S[i],&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F180(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Yue_ClHisDianneng(&Tmp_DD_BS_Value,P,t))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}

	memcpy(&SendBuff[SendLen],t,2);
	SendLen=SendLen+2;
	memcpy(&SendBuff[SendLen],&Tmp_DD_BS_Value.Chao_Time.BCD01,5);
	SendLen=SendLen+5;
	SendBuff[SendLen++]=4;

	INT32ToBCD(Tmp_DD_BS_Value.F_Q_All_S,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_BS_Value.F_Q_F_S[i],&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F181(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Yue_ClHisDianneng(&Tmp_DD_BS_Value,P,t))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	memcpy(&SendBuff[SendLen],t,2);
	SendLen=SendLen+2;
	memcpy(&SendBuff[SendLen],&Tmp_DD_BS_Value.Chao_Time.BCD01,5);
	SendLen=SendLen+5;
	SendBuff[SendLen++]=4;
	INT32ToBCD(Tmp_DD_BS_Value.X1_Q_All,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_BS_Value.X1_F_Q[i],&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F182(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Yue_ClHisDianneng(&Tmp_DD_BS_Value,P,t))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}

	memcpy(&SendBuff[SendLen],t,2);
	SendLen=SendLen+2;
	memcpy(&SendBuff[SendLen],&Tmp_DD_BS_Value.Chao_Time.BCD01,5);
	SendLen=SendLen+5;
	SendBuff[SendLen++]=4;

	INT32ToBCD(Tmp_DD_BS_Value.X2_Q_All,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_BS_Value.X2_F_Q[i],&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F183(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Yue_ClHisDianneng(&Tmp_DD_BS_Value,P,t))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	memcpy(&SendBuff[SendLen],t,2);
	SendLen=SendLen+2;
	memcpy(&SendBuff[SendLen],&Tmp_DD_BS_Value.Chao_Time.BCD01,5);
	SendLen=SendLen+5;
	SendBuff[SendLen++]=4;
	INT32ToBCD(Tmp_DD_BS_Value.X3_Q_All,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_BS_Value.X3_F_Q[i],&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F184(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Yue_ClHisDianneng(&Tmp_DD_BS_Value,P,t))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	memcpy(&SendBuff[SendLen],t,2);
	SendLen=SendLen+2;
	memcpy(&SendBuff[SendLen],&Tmp_DD_BS_Value.Chao_Time.BCD01,5);
	SendLen=SendLen+5;
	SendBuff[SendLen++]=4;
	INT32ToBCD(Tmp_DD_BS_Value.X4_Q_All,&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
	INT32ToBCD(Tmp_DD_BS_Value.X4_F_Q[i],&SendBuff[SendLen],4);
	SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F185(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_ClXuLiang(t,&Tmp_DD_Xl_Value,P))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Chao_Time.BCD01,sizeof(RtuDataAddr->Day_DD_BS_Value[P-1].Chao_Time));
	SendLen=SendLen+5;
	SendBuff[SendLen++]=4;
	INT32ToBCD(Tmp_DD_Xl_Value.Z_P_X_All,&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Time_Z_P_X_All[0],sizeof(Tmp_DD_Xl_Value.Time_Z_P_X_All));
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
		INT32ToBCD(Tmp_DD_Xl_Value.Z_P_X_F[i],&SendBuff[SendLen],3);
		SendLen=SendLen+3;
		memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Time_Z_P_X_F[i][0],sizeof(Tmp_DD_Xl_Value.Time_Z_P_X_F[i]));
		SendLen=SendLen+4;

	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F186(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_ClXuLiang(t,&Tmp_DD_Xl_Value,P))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}

	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Chao_Time.BCD01,sizeof(RtuDataAddr->Day_DD_BS_Value[P-1].Chao_Time));
	SendLen=SendLen+5;
	SendBuff[SendLen++]=4;
	INT32ToBCD(Tmp_DD_Xl_Value.Z_Q_X_All,&SendBuff[SendLen],3);
	SendLen=SendLen+3;

	memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Time_Z_Q_X_All[0],sizeof(Tmp_DD_Xl_Value.Time_Z_Q_X_All));
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
		INT32ToBCD(Tmp_DD_Xl_Value.Z_Q_X_F[i],&SendBuff[SendLen],3);
		SendLen=SendLen+3;
		memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Time_Z_Q_X_F[i][0],sizeof(Tmp_DD_Xl_Value.Time_Z_Q_X_F[i]));
		SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F187(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_ClXuLiang(t,&Tmp_DD_Xl_Value,P))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}
	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Chao_Time.BCD01,sizeof(RtuDataAddr->Day_DD_BS_Value[P-1].Chao_Time));
	SendLen=SendLen+5;
	SendBuff[SendLen++]=4;
	INT32ToBCD(Tmp_DD_Xl_Value.F_P_X_All,&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Time_F_P_X_All[0],sizeof(Tmp_DD_Xl_Value.Time_F_P_X_All));
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
		INT32ToBCD(Tmp_DD_Xl_Value.F_P_X_F[i],&SendBuff[SendLen],3);
		SendLen=SendLen+3;
		memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Time_F_P_X_F[i][0],sizeof(Tmp_DD_Xl_Value.Time_F_P_X_F[i]));
		SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level2_F188(INT8U F,INT8U P,INT8U *t,INT8U FRM)
{
	INT8U i;
	i=t[0];
	MkLevel2Head(P,F,FRM);
	if(!Read_Day_ClXuLiang(t,&Tmp_DD_Xl_Value,P))
	{
	if(i!=0xff)
		//SendNAK(F,P,0x0d);
		SendALLNAK();
		return 0;
	}

	memcpy(&SendBuff[SendLen],t,3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Chao_Time.BCD01,sizeof(RtuDataAddr->Day_DD_BS_Value[P-1].Chao_Time));
	SendLen=SendLen+5;
	SendBuff[SendLen++]=4;
	INT32ToBCD(Tmp_DD_Xl_Value.F_Q_X_All,&SendBuff[SendLen],3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Time_F_Q_X_All[0],sizeof(Tmp_DD_Xl_Value.Time_F_Q_X_All));
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
		INT32ToBCD(Tmp_DD_Xl_Value.F_Q_X_F[i],&SendBuff[SendLen],3);
		SendLen=SendLen+3;
		memcpy(&SendBuff[SendLen],&Tmp_DD_Xl_Value.Time_F_Q_X_F[i][0],sizeof(Tmp_DD_Xl_Value.Time_F_Q_X_F[i]));
		SendLen=SendLen+4;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
