/*
 * level3fun.c
 *
 *  Created on: 2009-12-16
 *      Author: www
 */
#include "level3fun.h"

void CallThreelevelData()
{
	INT8U k;
	NeedTp=0;
	if(Tmp130Buff[13]&0x80)
	{
		NeedTp=1;
	}
	GetDa(Tmp130Buff[14],Tmp130Buff[15]);
	GetDt(Tmp130Buff[16],Tmp130Buff[17]);
	if(DT[1]==1)
	{
		ReadEveHead=Tmp130Buff[19];
		ReadEveTail=Tmp130Buff[18];
		printf("\n\r\n\r\n\rReadEveHead====%d  ReadEveTail===%d\n\r\n\r\n\r",ReadEveHead,ReadEveTail);
		//XXPrint("\n\r\n\r\n\rReadEveHead====%d  ReadEveTail===%d\n\r\n\r\n\r",ReadEveHead,ReadEveTail);
		k=0;
		while(ReadEveHead!=ReadEveTail)
		{
			Set_Importnet_eve(k++);
		}
		delay(100);
	}
	if(DT[2]==1)
	{
		ReadEveHead=Tmp130Buff[19];
		ReadEveTail=Tmp130Buff[18];
		printf("\n\r\n\r\n\rReadEveHead====%d  ReadEveTail===%d\n\r\n\r\n\r",ReadEveHead,ReadEveTail);
		//XXPrint("\n\r\n\r\n\rReadEveHead====%d  ReadEveTail===%d\n\r\n\r\n\r",ReadEveHead,ReadEveTail);
		k=0;
		while(ReadEveHead!=ReadEveTail)
		{
			Set_normal_eve(k++);
		}
		delay(100);
	}
}

void Set_Importnet_eve(INT8U B)
{
	INT8U FirFin,i,j;
	//XXPrint("\r\n%s","������Ҫ�¼�");
	FirFin=0;
	FrameHeadCreate(0x84);
	SendBuff[SendLen++]=0x0e;//afn
	if(B==0)FirFin=0x40;
	if(((ReadEveHead+256-ReadEveTail)%256)<=5)
	{
		FirFin=FirFin|0x20;
	}
	SendBuff[SendLen++]=FirFin|(seq&0x0f);//seq��һ�壬��������
	SendBuff[SendLen++]=0;//Tmp130Buff[14];//da1e
	SendBuff[SendLen++]=0;//Tmp130Buff[15];//da2
	SendBuff[SendLen++]=1;//Tmp130Buff[16];//dt1
	SendBuff[SendLen++]=0;//Tmp130Buff[17];//dt2
	SendBuff[SendLen++]=RtuDataAddr->EC1;
	SendBuff[SendLen++]=RtuDataAddr->EC2;
	//XXPrint("\n\rImportant RtuDataAddr->EC1==%d",RtuDataAddr->EC1);
	//XXPrint("\n\rNormal RtuDataAddr->EC2==%d",RtuDataAddr->EC2);
	if((((ReadEveHead+256-ReadEveTail)%256)<=5))
	{
		SendBuff[SendLen++]=ReadEveTail;
		SendBuff[SendLen++]=ReadEveHead;
	}
	else
	{
		SendBuff[SendLen++]=ReadEveTail;
		SendBuff[SendLen++]=ReadEveTail+5;
	}
	for(j=0;j<5;j++)
	{
		memcpy(&Tmp_Event_Save,&RtuDataAddr->M_Event_Save[ReadEveHead-1].UseFlag,sizeof(Tmp_Event_Save));
//		Flash_ReadData(Event_Save_Page,512+ReadEveTail ,1 ,sizeof(Tmp_Event_Save), &Tmp_Event_Save.UseFlag);
		SendBuff[SendLen++]=Tmp_Event_Save.Event.Buff[0];
		SendBuff[SendLen++]=Tmp_Event_Save.Event.Buff[1];
		if(Tmp_Event_Save.Event.Buff[0]<=64)
		for(i=0;i<Tmp_Event_Save.Event.Buff[1];i++)
		{
			SendBuff[SendLen++]=Tmp_Event_Save.Event.Buff[2+i];
		}
		ReadEveHead--;
		if(ReadEveTail==ReadEveHead)break;
	}
	EC();
	TP();
	FrameTailCreate_Send();
}

void Set_normal_eve(INT8U B)
{
	INT8U FirFin,i,j;
	DebugOut("\r\n%s","����һ���¼�");
	FirFin=0;
	FrameHeadCreate(0x84);
	SendBuff[SendLen++]=0x0e;//afn
	if(B==0)FirFin=0x40;
	if(((ReadEveHead+256-ReadEveTail)%256)<=5)
	{
		FirFin=FirFin|0x20;
	}
	SendBuff[SendLen++]=FirFin|(seq&0x0f);//seq��һ�壬��������
	SendBuff[SendLen++]=0;//Tmp130Buff[14];//da1e
	SendBuff[SendLen++]=0;//Tmp130Buff[15];//da2
	SendBuff[SendLen++]=2;//Tmp130Buff[16];//dt1
	SendBuff[SendLen++]=0;//Tmp130Buff[17];//dt2
	SendBuff[SendLen++]=RtuDataAddr->EC1;
	SendBuff[SendLen++]=RtuDataAddr->EC2;
	if((((ReadEveHead+256-ReadEveTail)%256)<=5))
	{
		SendBuff[SendLen++]=ReadEveTail;
		SendBuff[SendLen++]=ReadEveHead;
	}
	else
	{
		SendBuff[SendLen++]=ReadEveTail;
		SendBuff[SendLen++]=ReadEveTail+5;
	}
	for(j=0;j<5;j++)
	{
		memcpy(&Tmp_Event_Save,&RtuDataAddr->S_Event_Save[ReadEveHead-1].UseFlag,sizeof(Tmp_Event_Save));
	//	Flash_ReadData(Event_Save_Page,768+ReadEveTail ,1 ,sizeof(Tmp_Event_Save), &Tmp_Event_Save.UseFlag);
		SendBuff[SendLen++]=Tmp_Event_Save.Event.Buff[0];
		SendBuff[SendLen++]=Tmp_Event_Save.Event.Buff[1];
		if(Tmp_Event_Save.Event.Buff[0]<=64)
			for(i=0;i<Tmp_Event_Save.Event.Buff[1];i++)
			{
				SendBuff[SendLen++]=Tmp_Event_Save.Event.Buff[2+i];
			}
		ReadEveHead--;
		if(ReadEveTail==ReadEveHead)break;
	}
	EC();
	TP();
	FrameTailCreate_Send();
}

int  AutoSendThreeLevelData(INT8U F)
{
	INT8U i;
	SendLen=0;
	DebugOut("\r\n%s","���������ϱ��¼�");
	memset(SendBuff,0,FrameSize);
	SendBuff[SendLen++]=0x68;
	SendBuff[SendLen++]=0;
	SendBuff[SendLen++]=0;
	SendBuff[SendLen++]=0;
	SendBuff[SendLen++]=0;
	SendBuff[SendLen++]=0x68;
	SendBuff[SendLen++]=0xc4;
	SendBuff[SendLen++]=Asdu130Addr[0];
	SendBuff[SendLen++]=Asdu130Addr[1];
	SendBuff[SendLen++]=Asdu130Addr[2];
	SendBuff[SendLen++]=Asdu130Addr[3];
	///////////////////////////////////////////////////////////
	SendBuff[SendLen++]=MSA;
	SendBuff[SendLen++]=0x0e;
	SendBuff[SendLen++]=0x60|(seq&0x0f);
	SendBuff[SendLen++]=0;
	SendBuff[SendLen++]=0;
	if(F==1)
	{
		SendBuff[SendLen++]=1;
		SendBuff[SendLen++]=0;
		SendBuff[SendLen++]=RtuDataAddr->EC1;
		SendBuff[SendLen++]=RtuDataAddr->EC2;
		SendBuff[SendLen++]=RtuDataAddr->EC1old;
		SendBuff[SendLen++]=RtuDataAddr->EC1old+1;
		memcpy(&Tmp_Event_Save,&RtuDataAddr->M_Event_Save[RtuDataAddr->EC1old].UseFlag,sizeof(Tmp_Event_Save));
	//	Flash_ReadData(Event_Save_Page,512+EC1old ,1 ,sizeof(Tmp_Event_Save), &Tmp_Event_Save.UseFlag);
		SendBuff[SendLen++]=Tmp_Event_Save.Event.Buff[0];
		SendBuff[SendLen++]=Tmp_Event_Save.Event.Buff[1];
		for(i=0;i<Tmp_Event_Save.Event.Buff[1];i++)
		{
			SendBuff[SendLen++]=Tmp_Event_Save.Event.Buff[2+i];
		}
		RtuDataAddr->EC1old++;
	}
	if(F==2)
	{
		SendBuff[SendLen++]=2;
		SendBuff[SendLen++]=0;
		SendBuff[SendLen++]=RtuDataAddr->EC1;
		SendBuff[SendLen++]=RtuDataAddr->EC2;
		SendBuff[SendLen++]=RtuDataAddr->EC2old;
		SendBuff[SendLen++]=RtuDataAddr->EC2old+1;
		memcpy(&Tmp_Event_Save,&RtuDataAddr->S_Event_Save[RtuDataAddr->EC2old].UseFlag,sizeof(Tmp_Event_Save));
//		Flash_ReadData(Event_Save_Page,768+EC2old ,1 ,sizeof(Tmp_Event_Save), &Tmp_Event_Save.UseFlag);
		SendBuff[SendLen++]=Tmp_Event_Save.Event.Buff[0];
		SendBuff[SendLen++]=Tmp_Event_Save.Event.Buff[1];
		for(i=0;i<Tmp_Event_Save.Event.Buff[1];i++)
		{
			SendBuff[SendLen++]=Tmp_Event_Save.Event.Buff[2+i];
		}
		RtuDataAddr->EC2old++;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	if(Tmp_Event_Save.Event.Err14.ERCNo==14)
	{
		return 1;
	}
	return 0;
}
