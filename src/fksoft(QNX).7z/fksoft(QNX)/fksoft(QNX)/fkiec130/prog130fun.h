#ifndef PROG130FUN_H_
#define PROG130FUN_H_
#include "base130fun.h"
#include "level1fun.h"
#include "level2fun.h"
#include "level3fun.h"
#include "setfun.h"
#include "controlfun.h"
#include "update.h"

void Deal130Protocol();
void init130pro();
void GetNormal();
void LinkTest();
void LinkControl(INT8U F);
void DataTrans();
void AskTwoLevelData();
void AskOneLevelData();
void RemoteAnswer();
void ResetControl();
void Deal130Protocol();
void Get_Data_Process();

#endif /*PROG130FUN_H_*/

