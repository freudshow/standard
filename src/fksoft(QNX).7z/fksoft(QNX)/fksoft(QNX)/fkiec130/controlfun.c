/*
 * controlfun.c
 *
 *  Created on: 2009-12-16
 *      Author: www
 */
#include "controlfun.h"

void SaveZhongwen()
{
	SaveFile((INT8U *)"/nand/save/fkzhongwen.sav",(INT8U *)RtuDataAddr->FkZhongWen,sizeof(RtuDataAddr->FkZhongWen));
}
INT16U DoControl(INT8U F,INT8U P)
{
	INT8U i=0;
	INT16U Result=4;
	//GetDa(Tmp130Buff[14],Tmp130Buff[15]);
	GetDa(Tmp130Buff[Resolve_Pos],Tmp130Buff[Resolve_Pos+1]);
	DebugOut("   P=%d   F=%d",P,F);
	switch (F)
	{
	case 1:
		//printf("\n\rBaoDian_TiChu_Gaojing_Tou===%d",RtuDataAddr->Fk_Control_Set_now.BaoDian_TiChu_Gaojing_Tou);
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			Result=Result+1;
			SendALLNAK();
			break;
		}
		ControlHead();
		for(i=1;i<=Control_Lunci_Max;i++)
		{
			if(DA[i]==1)
			{
				RtuDataAddr->FuKong_Control_Value.F1_Control_Para[i-1].Alarm_Dealy_Set=(Tmp130Buff[18]>>4)&0x0f;
				RtuDataAddr->FuKong_Control_Value.F1_Control_Para[i-1].Xian_Dian_Delay_Set=Tmp130Buff[18]&0x0f;
				RtuDataAddr->FuKong_Control_Value.F1_Control_Para[i-1].Valid=1;
			}
		}
//		Pr(DebugComm,"send1 %d %d",SendLen,RecDataLen);
		sprintf((char *)RtuDataAddr->SendMessage,"�������øı�\n�ִ���բͶ��");
		memcpy(&SendBuff[SendLen],&Tmp130Buff[14],4);
		SendLen=SendLen+4;
		SendBuff[SendLen++]=0;
		Save_Fk_Control_para_Set();
		ControlTail();
		Result=Result+1;
		break;
	case 2:
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			SendALLNAK();
			break;
		}
		ControlHead();
		for(i=1;i<=Control_Lunci_Max;i++)
		{
			if(DA[i]==1)
			{
				RtuDataAddr->FuKong_Control_Value.F1_Control_Para[i-1].Valid=0;
				RtuDataAddr->FuKong_Control_Value.F1_Control_Para[i-1].Alarm_Dealy_Set=0;
				RtuDataAddr->FuKong_Control_Value.F1_Control_Para[i-1].Xian_Dian_Delay_Set=0;
			}
		}
		sprintf((char *)RtuDataAddr->SendMessage,"�������øı�\n�ִκ�բ");
		memcpy(&SendBuff[SendLen],&Tmp130Buff[14],4);
		SendLen=SendLen+4;
		SendBuff[SendLen++]=0;
		Save_Fk_Control_para_Set();
		ControlTail();
		break;
	case 9:
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			Result=Result+2;
			SendALLNAK();
			break;
		}
		ControlHead();
		for(i=1;i<=ZongJia_Max;i++)
		{
			if(DA[i]==1)
			{
				RtuDataAddr->FuKong_Control_Value.F9_Control_Para[i-1].Valid=1;
				RtuDataAddr->FuKong_Control_Value.F9_Control_Para[i-1].ShiDuan_Tou_Set=Tmp130Buff[18];
				RtuDataAddr->FuKong_Control_Value.F9_Control_Para[i-1].ShiDuan_Tou_FangAn_No=Tmp130Buff[19];
				RtuDataAddr->FuKong_Control_Value.F9_Control_Para[i-1].Alarm_Time=0;
			}
		}
		sprintf((char *)RtuDataAddr->SendMessage,"�������øı�\nʱ�ι���Ͷ��");
		memcpy(&SendBuff[SendLen],&Tmp130Buff[14],4);
		SendLen=SendLen+4;
		SendBuff[SendLen++]=0;
		Save_Fk_Control_para_Set();
		ControlTail();
		Result=Result+2;
		break;
	case 10:
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			SendALLNAK();
			break;
		}
		ControlHead();
		for(i=1;i<=ZongJia_Max;i++)
		{
			if(DA[i]==1)
			{
				RtuDataAddr->FuKong_Control_Value.F10_Control_Para[i-1].Valid=1;
			}
		}
		sprintf((char *)RtuDataAddr->SendMessage,"�������øı�\n���ݹ���Ͷ��");
		memcpy(&SendBuff[SendLen],&Tmp130Buff[14],4);
		SendLen=SendLen+4;
		SendBuff[SendLen++]=0;
		Save_Fk_Control_para_Set();
		ControlTail();
		break;
	case 11:
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			SendALLNAK();
			break;
		}
		ControlHead();
		for(i=1;i<=ZongJia_Max;i++)
		{
			if(DA[i]==1)
			{
				RtuDataAddr->FuKong_Control_Value.F11_Control_Para[i-1].Valid=1;
			}
		}
		sprintf((char *)RtuDataAddr->SendMessage,"�������øı�\nӪҵ��ͣ��Ͷ��");
		memcpy(&SendBuff[SendLen],&Tmp130Buff[14],4);
		SendLen=SendLen+4;
		SendBuff[SendLen++]=0;
		Save_Fk_Control_para_Set();
		ControlTail();
		break;
	case 12:
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			Result=Result+8;
			SendALLNAK();
			break;
		}
		ControlHead();
		for(i=1;i<=ZongJia_Max;i++)
		{
			if(DA[i]==1)
			{
				RtuDataAddr->FuKong_Control_Value.F12_Control_Para[i-1].Valid=1;
				RtuDataAddr->FuKong_Control_Value.F12_Control_Para[i-1].Gonglv_Xiafu_HuaCXha_Time=Tmp130Buff[18];
				RtuDataAddr->FuKong_Control_Value.F12_Control_Para[i-1].Gonglv_Xiafu_HuaCXha_XiShu=Tmp130Buff[19];
				RtuDataAddr->FuKong_Control_Value.F12_Control_Para[i-1].KongHou_ZongJIa_Dongjie=Tmp130Buff[20];
				//liujia
				RtuDataAddr->FuKong_Control_Value.F12_Control_Para[i-1].Gonglv_Xiafu_Kongzhi_Time=Tmp130Buff[21];
				RtuDataAddr->FuKong_Control_Value.F12_Control_Para[i-1].Gonglv_Xiafu_Gaojing_Time1=Tmp130Buff[22];
				RtuDataAddr->FuKong_Control_Value.F12_Control_Para[i-1].Gonglv_Xiafu_Gaojing_Time2=Tmp130Buff[23];
				RtuDataAddr->FuKong_Control_Value.F12_Control_Para[i-1].Gonglv_Xiafu_Gaojing_Time3=Tmp130Buff[24];
				RtuDataAddr->FuKong_Control_Value.F12_Control_Para[i-1].Gonglv_Xiafu_Gaojing_Time4=Tmp130Buff[25];
			}
		}
		sprintf((char *)RtuDataAddr->SendMessage,"�������øı�\n��ǰ�����¸���Ͷ��");
		memcpy(&SendBuff[SendLen],&Tmp130Buff[14],4);
		SendLen=SendLen+4;
		SendBuff[SendLen++]=0;
		Save_Fk_Control_para_Set();
		ControlTail();
		Result=Result+8;
		break;
	case 15:
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			SendALLNAK();
			break;
		}
		ControlHead();
		for(i=1;i<=ZongJia_Max;i++)
		{
			if(DA[i]==1)
			{
				RtuDataAddr->FuKong_Control_Value.F15_Control_Para[i-1].Valid=1;
				//printf("\n\rRtuDataAddr->FuKong_Control_Value.F15_Control_Para[i-1].Valid=%d ",RtuDataAddr->FuKong_Control_Value.F15_Control_Para[i-1].Valid);

			}
		}
		sprintf((char *)RtuDataAddr->SendMessage,"�������øı�\n�µ��Ͷ��");
		memcpy(&SendBuff[SendLen],&Tmp130Buff[14],4);
		SendLen=SendLen+4;
		SendBuff[SendLen++]=0;
		Save_Fk_Control_para_Set();
		ControlTail();
		break;
	case 16:
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			SendALLNAK();
			break;
		}
		ControlHead();
		for(i=1;i<=ZongJia_Max;i++)
		{
			if(DA[i]==1)
			{
				RtuDataAddr->FuKong_Control_Value.F16_Control_Para[i-1].Valid=1;
			}
		}
		sprintf((char *)RtuDataAddr->SendMessage,"�������øı�\n�����Ͷ��");
		memcpy(&SendBuff[SendLen],&Tmp130Buff[14],4);
		SendLen=SendLen+4;
		SendBuff[SendLen++]=0;
		Save_Fk_Control_para_Set();
		ControlTail();
		break;
	case 17:
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			SendALLNAK();
			break;
		}
		ControlHead();
		for(i=1;i<=ZongJia_Max;i++)
		{
			if(DA[i]==1)
			{
				RtuDataAddr->FuKong_Control_Value.F9_Control_Para[i-1].Valid=0;
			}
		}
		sprintf((char *)RtuDataAddr->SendMessage,"�������øı�\nʱ�ι��ؽ��");
		memcpy(&SendBuff[SendLen],&Tmp130Buff[14],4);
		SendLen=SendLen+4;
		SendBuff[SendLen++]=0;
		Save_Fk_Control_para_Set();
		ControlTail();
		break;
	case 18:
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			SendALLNAK();
			break;
		}
		ControlHead();
		for(i=1;i<=ZongJia_Max;i++)
		{
			if(DA[i]==1)
			{
				RtuDataAddr->FuKong_Control_Value.F10_Control_Para[i-1].Valid=0;
			}
		}
		sprintf((char *)RtuDataAddr->SendMessage,"�������øı�\n���ݹ��ؽ��");
		memcpy(&SendBuff[SendLen],&Tmp130Buff[14],4);
		SendLen=SendLen+4;
		SendBuff[SendLen++]=0;
		Save_Fk_Control_para_Set();
		ControlTail();
		break;
	case 19:
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			SendALLNAK();
			break;
		}
		ControlHead();
		for(i=1;i<=ZongJia_Max;i++)
		{
			if(DA[i]==1)
			{
				RtuDataAddr->FuKong_Control_Value.F11_Control_Para[i-1].Valid=0;
			}
		}
		sprintf((char *)RtuDataAddr->SendMessage,"�������øı�\nӪҵ��ͣ�ؽ��");
		memcpy(&SendBuff[SendLen],&Tmp130Buff[14],4);
		SendLen=SendLen+4;
		SendBuff[SendLen++]=0;
		Save_Fk_Control_para_Set();
		ControlTail();
		break;
	case 20:
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			SendALLNAK();
			break;
		}
		ControlHead();
		for(i=1;i<=ZongJia_Max;i++)
		{
			if(DA[i]==1)
			{
				RtuDataAddr->FuKong_Control_Value.F12_Control_Para[i-1].Valid=0;
			}
		}
		sprintf((char *)RtuDataAddr->SendMessage,"�������øı�\n��ǰ�����¸��ؽ��");
		memcpy(&SendBuff[SendLen],&Tmp130Buff[14],4);
		SendLen=SendLen+4;
		SendBuff[SendLen++]=0;
		Save_Fk_Control_para_Set();
		ControlTail();
		break;
	case 23:
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			SendALLNAK();
			break;
		}
		ControlHead();
		for(i=1;i<=ZongJia_Max;i++)
		{
			if(DA[i]==1)
			{
				RtuDataAddr->FuKong_Control_Value.F15_Control_Para[i-1].Valid=0;
			}
		}
		sprintf((char *)RtuDataAddr->SendMessage,"�������øı�\n�µ�ؽ��");
		memcpy(&SendBuff[SendLen],&Tmp130Buff[14],4);
		SendLen=SendLen+4;
		SendBuff[SendLen++]=0;
		Save_Fk_Control_para_Set();
		ControlTail();
		break;
	case 24:
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			SendALLNAK();
			break;
		}
		ControlHead();
		for(i=1;i<=ZongJia_Max;i++)
		{
			if(DA[i]==1)
			{
				RtuDataAddr->FuKong_Control_Value.F16_Control_Para[i-1].Valid=0;
			}
		}
		sprintf((char *)RtuDataAddr->SendMessage,"�������øı�\n����ؽ��");
		memcpy(&SendBuff[SendLen],&Tmp130Buff[14],4);
		SendLen=SendLen+4;
		SendBuff[SendLen++]=0;
		Save_Fk_Control_para_Set();
		ControlTail();
		break;
	case 25:
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			Result=Result+1;
			SendALLNAK();
			break;
		}
		ControlHead();
		RtuDataAddr->FuKong_Control_Value.F25_Control_Para.Valid=1;
		RtuDataAddr->FuKong_Control_Value.F25_Control_Para.BaoDian_Delay_Time=Tmp130Buff[18];
		RtuDataAddr->FuKong_Control_Value.F25_Control_Para.Dalay_Time=0;
		sprintf((char *)RtuDataAddr->SendMessage,"�������øı�\n�ն˱���Ͷ��");
		memcpy(&SendBuff[SendLen],&Tmp130Buff[14],4);
		SendLen=SendLen+4;
		SendBuff[SendLen++]=0;
		Save_Fk_Control_para_Set();
		ControlTail();
		Result=Result+1;
		break;
	case 26:
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			SendALLNAK();
			break;
		}
		ControlHead();
		RtuDataAddr->FuKong_Control_Value.F26_Control_Para.Valid=1;
		RtuDataAddr->Fk_Control_Value_now.Now_CuiFei_Gaojing_Stat=1<<i;
		sprintf((char *)RtuDataAddr->SendMessage,"�������øı�\n�߷Ѹ澯Ͷ��");
		memcpy(&SendBuff[SendLen],&Tmp130Buff[14],4);
		SendLen=SendLen+4;
		SendBuff[SendLen++]=0;
		Save_Fk_Control_para_Set();
		ControlTail();
		break;
	case 27:
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			SendALLNAK();
			break;
		}
		ControlHead();
		RtuDataAddr->FuKong_Control_Value.F27_Control_Para.Valid=1;
		sprintf((char *)RtuDataAddr->SendMessage,"�������øı�");
		memcpy(&SendBuff[SendLen],&Tmp130Buff[14],4);
		SendLen=SendLen+4;
		SendBuff[SendLen++]=0;
		Save_Fk_Control_para_Set();
		ControlTail();
		break;
	case 28:
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			SendALLNAK();
			break;
		}
		ControlHead();
		RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid=1;
		sprintf((char *)RtuDataAddr->SendMessage,"�������øı�\n�ն��޳�Ͷ��");
		memcpy(&SendBuff[SendLen],&Tmp130Buff[14],4);
		SendLen=SendLen+4;
		SendBuff[SendLen++]=0;
		Save_Fk_Control_para_Set();
		ControlTail();
		break;
	case 29:
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			SendALLNAK();
			break;
		}
		ControlHead();
		RtuDataAddr->FuKong_Control_Value.F29_Control_Para.Valid=1;
		sprintf((char *)RtuDataAddr->SendMessage,"�������øı�");
		memcpy(&SendBuff[SendLen],&Tmp130Buff[14],4);
		SendLen=SendLen+4;
		SendBuff[SendLen++]=0;
		Save_Fk_Control_para_Set();
		ControlTail();
		break;
	case 31:
		ControlHead();
		SetTime(&Tmp130Buff[18]);
		sprintf((char *)RtuDataAddr->SendMessage,"�������øı�");
		memcpy(&SendBuff[SendLen],&Tmp130Buff[14],4);
		SendLen=SendLen+4;
		SendBuff[SendLen++]=0;
		ControlTail();
		Result=Result+6;
		break;
	case 32:
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			Result=Result+2+Tmp130Buff[19];
			SendALLNAK();
			break;
		}
		ControlHead();
		sprintf((char *)RtuDataAddr->SendMessage,"�������øı�\n������Ϣ�ı�");
		RtuDataAddr->FkZhongWen[RtuDataAddr->Fm_Save_Eve.ZWNo].Valid=1;
		RtuDataAddr->FkZhongWen[RtuDataAddr->Fm_Save_Eve.ZWNo].Stat=Tmp130Buff[18];
		RtuDataAddr->FkZhongWen[RtuDataAddr->Fm_Save_Eve.ZWNo].len=Tmp130Buff[19];
		memset(RtuDataAddr->FkZhongWen[RtuDataAddr->Fm_Save_Eve.ZWNo].HZXinXi,0,sizeof(RtuDataAddr->FkZhongWen[RtuDataAddr->Fm_Save_Eve.ZWNo].HZXinXi));
		memcpy(RtuDataAddr->FkZhongWen[RtuDataAddr->Fm_Save_Eve.ZWNo].HZXinXi,&Tmp130Buff[20],RtuDataAddr->FkZhongWen[RtuDataAddr->Fm_Save_Eve.ZWNo].len);
		RtuDataAddr->Fm_Save_Eve.ZWNo=RtuDataAddr->Fm_Save_Eve.ZWNo%10;
		SaveZhongwen();
		RtuDataAddr->Fm_Save_Eve.ZWNo=(RtuDataAddr->Fm_Save_Eve.ZWNo+1)%10;
		Fm25cl64_Write(&RtuDataAddr->Fm_Save_Eve.EC1,sizeof(RtuDataAddr->Fm_Save_Eve),Fm_Save_Eve_Offset);
		memcpy(&SendBuff[SendLen],&Tmp130Buff[14],4);
		SendLen=SendLen+4;
		SendBuff[SendLen++]=0;
		Save_Fk_Control_para_Set();
		ControlTail();
		Result=Result+2+RtuDataAddr->FkZhongWen[RtuDataAddr->Fm_Save_Eve.ZWNo].len;
		break;
	case 33:
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			SendALLNAK();
			break;
		}
		ControlHead();
		RtuDataAddr->FuKong_Control_Value.F25_Control_Para.Valid=0;
		RtuDataAddr->FuKong_Control_Value.F25_Control_Para.Dalay_Time=0;
		sprintf((char *)RtuDataAddr->SendMessage,"�������øı�\n�ն˱�����");
		memcpy(&SendBuff[SendLen],&Tmp130Buff[14],4);
		SendLen=SendLen+4;
		SendBuff[SendLen++]=0;
		Save_Fk_Control_para_Set();
		ControlTail();
		break;
	case 34:
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			SendALLNAK();
			break;
		}
		ControlHead();
		RtuDataAddr->FuKong_Control_Value.F26_Control_Para.Valid=0;
		sprintf((char *)RtuDataAddr->SendMessage,"�������øı�\n�߷Ѹ澯���");
		RtuDataAddr->Fk_Control_Value_now.Now_CuiFei_Gaojing_Stat=RtuDataAddr->Fk_Control_Value_now.Now_CuiFei_Gaojing_Stat&(0xff^(1<<i));
		memcpy(&SendBuff[SendLen],&Tmp130Buff[14],4);
		SendLen=SendLen+4;
		SendBuff[SendLen++]=0;
		Save_Fk_Control_para_Set();
		ControlTail();
		break;
	case 35:
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			SendALLNAK();
			break;
		}
		ControlHead();
		RtuDataAddr->FuKong_Control_Value.F27_Control_Para.Valid=0;
		sprintf((char *)RtuDataAddr->SendMessage,"�������øı�");
		memcpy(&SendBuff[SendLen],&Tmp130Buff[14],4);
		SendLen=SendLen+4;
		SendBuff[SendLen++]=0;
		Save_Fk_Control_para_Set();
		ControlTail();
		break;
	case 36:
		ControlHead();
		RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid=0;
		sprintf((char *)RtuDataAddr->SendMessage,"�������øı�\n�ն��޳����");
		memcpy(&SendBuff[SendLen],&Tmp130Buff[14],4);
		SendLen=SendLen+4;
		SendBuff[SendLen++]=0;
		Save_Fk_Control_para_Set();
		ControlTail();
		break;
	case 37:
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			SendALLNAK();
			break;
		}
		ControlHead();
		RtuDataAddr->FuKong_Control_Value.F29_Control_Para.Valid=0;
		sprintf((char *)RtuDataAddr->SendMessage,"�������øı�\n��ֹ�ն������ϱ�");
		memcpy(&SendBuff[SendLen],&Tmp130Buff[14],4);
		SendLen=SendLen+4;
		SendBuff[SendLen++]=0;
		Save_Fk_Control_para_Set();
		ControlTail();
		break;
	case 38:
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			SendALLNAK();
			break;
		}
		ControlHead();
		RtuDataAddr->FuKong_Control_Value.F38_Control_Para.Valid=1;
		sprintf((char *)RtuDataAddr->SendMessage,"�������øı�\n��������");
		RtuDataAddr->GprsNowActive=1;
		memcpy(&SendBuff[SendLen],&Tmp130Buff[14],4);
		SendLen=SendLen+4;
		SendBuff[SendLen++]=0;
//		Save_Fk_Control_para_Set();
		ControlTail();
		break;
//liujia
	case 39:
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			SendALLNAK();
			break;
		}
		ControlHead();
		RtuDataAddr->FuKong_Control_Value.F39_Control_Para.Valid=1;
		sprintf((char *)RtuDataAddr->SendMessage,"�������øı�\n�����ն˶Ͽ�����");
		//RtuDataAddr->Gprs_ok = 0;
		//RtuDataAddr->linked_ok=0;
		memcpy(&SendBuff[SendLen],&Tmp130Buff[14],4);
		SendLen=SendLen+4;
		SendBuff[SendLen++]=0;
		Save_Fk_Control_para_Set();
		ControlTail();
		break;
	case 41:
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			Result=Result+2;
			SendALLNAK();
			break;
		}
		ControlHead();
		sprintf((char *)RtuDataAddr->SendMessage,"�������øı�");
		memcpy(&SendBuff[SendLen],&Tmp130Buff[14],4);
		SendLen=SendLen+4;
		SendBuff[SendLen++]=0;
		Save_Fk_Control_para_Set();
		ControlTail();
		Result=Result+2;
		break;
	case 42:
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			Result=Result+2;
			SendALLNAK();
			break;
		}
		ControlHead();
		sprintf((char *)RtuDataAddr->SendMessage,"�������øı�");
		memcpy(&SendBuff[SendLen],&Tmp130Buff[14],4);
		SendLen=SendLen+4;
		SendBuff[SendLen++]=0;
		Save_Fk_Control_para_Set();
		ControlTail();
		Result=Result+2;
		break;
//liujia
	case 49:
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			Result=Result+1;
			SendALLNAK();
			break;
		}
		ControlHead();
		RtuDataAddr->FuKong_Control_Value.F49_Control_Para.Valid=1;
		sprintf((char *)RtuDataAddr->SendMessage,"�������øı�\n����ָ��ͨ�Ŷ˿���ͣ����");
		RtuDataAddr->FuKong_Control_Value.F49_Control_Para.ZhongduanPort=Tmp130Buff[18];
		memcpy(&SendBuff[SendLen],&Tmp130Buff[14],4);
		SendLen=SendLen+4;
		SendBuff[SendLen++]=0;
		Save_Fk_Control_para_Set();
		ControlTail();
		Result=Result+1;
		break;
	case 50:
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			Result=Result+1;
			SendALLNAK();
			break;
		}
		ControlHead();
		RtuDataAddr->FuKong_Control_Value.F49_Control_Para.Valid=0;
		sprintf((char *)RtuDataAddr->SendMessage,"�������øı�\n����ָ��ͨ�Ŷ˿ڻָ�����");
		memcpy(&SendBuff[SendLen],&Tmp130Buff[14],4);
		SendLen=SendLen+4;
		SendBuff[SendLen++]=0;
		Save_Fk_Control_para_Set();
		ControlTail();
		Result=Result+1;
		break;
	case 51:
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			Result=Result+1;
			SendALLNAK();
			break;
		}
		ControlHead();
		RtuDataAddr->FuKong_Control_Value.F49_Control_Para.Valid=0;
		sprintf((char *)RtuDataAddr->SendMessage,"�������øı�\n����ָ��ͨ�Ŷ˿����³���");
		memcpy(&SendBuff[SendLen],&Tmp130Buff[14],4);
		SendLen=SendLen+4;
		SendBuff[SendLen++]=0;
		Save_Fk_Control_para_Set();
		ControlTail();
		Result=Result+1;
		break;
	case 52:
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			Result=Result+1;
			SendALLNAK();
			break;
		}
		ControlHead();
		RtuDataAddr->FuKong_Control_Value.F52_Control_Para.Valid=1;
		sprintf((char *)RtuDataAddr->SendMessage,"�������øı�\n��ʼ��ָ��ͨ�Ŷ˿��µ�ȫ���м�·����Ϣ");
		memcpy(&SendBuff[SendLen],&Tmp130Buff[14],4);
		SendLen=SendLen+4;
		SendBuff[SendLen++]=0;
		Save_Fk_Control_para_Set();
		ControlTail();
		Result=Result+1;
		break;
	case 53:
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			Result=Result+1;
			SendALLNAK();
			break;
		}
		ControlHead();
		RtuDataAddr->FuKong_Control_Value.F53_Control_Para.Valid=1;
		sprintf((char *)RtuDataAddr->SendMessage,"�������øı�\nɾ��ָ��ͨ�Ŷ˿��µ�ȫ�����");
		memcpy(&SendBuff[SendLen],&Tmp130Buff[14],4);
		SendLen=SendLen+4;
		SendBuff[SendLen++]=0;
		Save_Fk_Control_para_Set();
		ControlTail();
		Result=Result+1;
		break;
	default:
		SendALLNAK();
		break;
	}
	AlArmReportBegin();
//	OutScreen();
	AlArmReportEnd();
	return Result;
}
void ControlHead()
{
	FrameHeadCreate(0x80);
	SendBuff[SendLen++]=0;//afn
	SendBuff[SendLen++]=0x60|(seq&0x0f);//seq
	SendBuff[SendLen++]=0;//Tmp130Buff[14];//da1e
	SendBuff[SendLen++]=0;//Tmp130Buff[15];//da2
	SendBuff[SendLen++]=4;//Tmp130Buff[16];//dt1
	SendBuff[SendLen++]=0;//Tmp130Buff[17];//dt2
	SendBuff[SendLen++]=0x05;//

}
void ControlTail()
{
	EC();
	TP();
	AlArmReportEnd();
//	FrameTailCreate_Send();
SendALLACK();
}
void ControlSet()
{
	INT8U j;
	Resolve_Pos=14;
	while(Resolve_Pos<(RecDataLen-10))//���볤��Ϊ16ʱʹ��
	{
		memset(DA,0,65);
		memset(DT,0,255);
		GetDa(Tmp130Buff[Resolve_Pos],Tmp130Buff[Resolve_Pos+1]);
		GetDt(Tmp130Buff[Resolve_Pos+2],Tmp130Buff[Resolve_Pos+3]);
		for(j=0;j<248;j++)
		{
			if(DT[j]==1)
			{
				Resolve_Pos=Resolve_Pos+DoControl(j,0);
			}
		}
	}
}
