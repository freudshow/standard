#include "prog130fun.h"
#include "ppp.h"

INT8U				ATCmd[256];
INT16U				ATHead,ATTail;
const char verstr[]={"VER-STRING-FLG=005.002.217.004"__DATE__" "__TIME__};
int getCsq()
{
	int kk, ll;
	FILE *fp2=NULL;
	char fpstr[1024];
	fp2 = fopen("/user/gprs_conn.log","r");
	if (fp2!=NULL)
	{
		while(!feof(fp2))
		{
			memset(fpstr,0,1024);
			fgets(fpstr,1024,fp2);
			if(strncmp(fpstr,"+CSQ:",5)==0)
			{
				if (sscanf(fpstr,"+CSQ:%d,%d", &kk, &ll) == 2) {
					break;
				}
			}
		}
		fclose(fp2);
	}
	return kk;
}

INT8U   PARSE_CMD(int argc, char * argv[])
{
	INT8U  proc_name[32] = "";
	if(argc < 2)return (FALSE);
	PORT_ID = atoi(argv[1]);
	sprintf((char *)proc_name, "%s %d", argv[0], PORT_ID);
	if((attach = name_attach(NULL, (char *)proc_name,0))  == NULL)
	{
		return (FALSE);
	}
	return (TRUE);
}

void markver()//��Ŀ������б�ʶ�����汾��Ϣ
{
	printf("\n%s\n", verstr);
}

int setupTimer()
{
	struct sigevent event;
	struct itimerspec itime;
	timer_t                 timer_id;
   	int                     chid;
	chid = ChannelCreate(0);

   event.sigev_notify = SIGEV_PULSE;
   event.sigev_coid = ConnectAttach(ND_LOCAL_NODE, 0,chid,_NTO_SIDE_CHANNEL, 0);
   event.sigev_priority = getprio(0);
   event.sigev_code = MY_PULSE_CODE;
   timer_create(CLOCK_REALTIME, &event, &timer_id);

   itime.it_value.tv_sec = 1;
   /* 500 million nsecs = .5 secs */
   itime.it_value.tv_nsec = 0;//500000000;
   itime.it_interval.tv_sec = 1;
   /* 500 million nsecs = .5 secs */
   itime.it_interval.tv_nsec = 0;//500000000;
   timer_settime(timer_id, 0, &itime, NULL);
   return chid;
}
///////////////////////////////////////////
//�������ܣ������˳�ǰ����
//���ã�ϵͳ����
//������sa����
//�˳���
///////////////////////////////////////////
void QuitProcess(int signo)
{
	fclose(Gwfp);
	ExitThread();
	system("slay pppd");
	delay(100);
	RtuDataAddr->stPortPara[PORT_ID].PID=0;
//	timer_delete(chid);
   	name_detach(attach, 0);
   	DebugOut("fk130 quit");
	exit(0);
}
void InitGpio()
{

	if (!PortOpened) {
		OpenGPIO();
	}
	GpioEnable(1,26);
	GpioEnable(1,25);
}

unsigned char  init_port(unsigned int PORT)
{
	unsigned char tmp[128];
	memset(tmp,0,128);
	sprintf((char *)tmp,"stty </dev/ser%d baud=9600 par=none stopb=1 bits=8",PORT);
	fprintf(stderr, "ComPortpara %s ok!\n",tmp);
	system((char *)tmp);
	memset(tmp,0,128);
	sprintf((char *)tmp,"/dev/ser%d",PORT);
	delay(500);
	if (ComPort>0)
		close(ComPort);
	ComPort = open((char *)tmp, O_RDWR);
	if (ComPort < 0 )
	{
		fprintf(stderr, "\nERROR: Open ComPort %s error!\n", tmp);
		return 0;
	}
	fprintf(stderr, "\nOK: Open ComPort %s ok!\n",tmp);
	return 1;

}
void initM22()
{
	RtuDataAddr->linked_ok=0;
	system("slay pppd");
	if (!PortOpened) {
		OpenGPIO();
	}
	//GpioEnable(1,25);//�¼���
/*	GpioSet(1,26);//�¼���
	GpioSet(1,25);  //�¼���
    delay(10);
	GpioClear(1,25);//�¼���
	delay(4000);
	GpioSet(1,25);//�¼���
*/
	GpioClear(1,25);
	delay(5000);
	GpioSet(1,25);
	delay(1000);
	GpioSet(1,26);
	delay(50);
	GpioClear(1,26);
	delay(500);
	GpioSet(1,26);
}
int Test_WirelessModule()
{
	int pa27,pb17,pb18,pb26,pb27;
	if (!PortOpened) {
		OpenGPIO();
	}
	pa27=(in32(port1+0x3c)>>27)&0x01;
	pb17=(in32(port2+0x3c)>>17)&0x01;
	pb18=(in32(port2+0x3c)>>18)&0x01;
	pb26=(in32(port2+0x3c)>>26)&0x01;
	pb27=(in32(port2+0x3c)>>27)&0x01;
	//printf("\n\r pa27=%d  pb17=%d  pb18=%d  pb26=%d  pb27=%d", pa27,pb17,pb18,pb26,pb27);
	//--------------------------------
	// ����ģ������     ���嶨��û��ȷ��
	//*type = 1;// GPRS����
	//--------------------------------

	if((pa27==1)&&(pb17==1)&&(pb18==1)&&(pb26==1)&&(pb27==1))//û�в���ͨѶ��
	{
		RtuDataAddr->FkComm_Value.Netselect = 0;
		return 0;
	}
	if((pa27==1)&&(pb17==0)&&(pb18==0)&&(pb26==0)&&(pb27==0))//GPRS����
	{
		RtuDataAddr->FkComm_Value.Netselect = 2;
		return 1;
	}
	if((pa27==0)&&(pb17==0)&&(pb18==0)&&(pb26==0)&&(pb27==0))//��̫����
	{
		RtuDataAddr->FkComm_Value.Netselect = 1;
		return 2;
	}
	RtuDataAddr->FkComm_Value.Netselect = 0;
	return 0;
}

void initgprsid()
{
	out32(port1,AT91C_PIO_PA27);  //�¼���
	//out32(port1 +0x10, AT91C_PIO_PA27);
	//out32(port1 +0x30, AT91C_PIO_PA27);
    out32(port1+0x20,AT91C_PIO_PA27);//�¼���

    out32(port2,AT91C_PIO_PB17);  //�¼���
   // out32(port2+0x10,AT91C_PIO_PB17);//�¼���
   // out32(port2+0x30,AT91C_PIO_PB17);//�¼���
    out32(port2+0x20,AT91C_PIO_PB17);//�¼���

    out32(port2,AT91C_PIO_PB18);  //�¼���
    //out32(port2+0x10,AT91C_PIO_PB18);//�¼���
    //out32(port2+0x30,AT91C_PIO_PB18);//�¼���
    out32(port2+0x20,AT91C_PIO_PB18);//�¼���

    out32(port2,AT91C_PIO_PB26);  //�¼���
    //out32(port2+0x10,AT91C_PIO_PB26);//�¼���
    //out32(port2+0x30,AT91C_PIO_PB26);//�¼���
    out32(port2+0x20,AT91C_PIO_PB26);//�¼���

    out32(port2,AT91C_PIO_PB27);  //�¼���
   // out32(port2+0x10,AT91C_PIO_PB27);//�¼���
   // out32(port2+0x30,AT91C_PIO_PB27);//�¼���
    out32(port2+0x20,AT91C_PIO_PB27);//�¼���

}

INT8U GetStrInclude(INT8U *D)
{
	INT16U i,j,k;
	j=strlen((char *)D);
	k=ATTail;
	while(ATHead!=k)
	{
		for(i=0;i<j;i++)
		{
			if(toupper(TmpBuf[k+i])!=toupper(D[i]))
			{
				k=(k+1)%FrameSize;
				break;
			}
		}
		if(i==j)
		{
			return 1;
		}
	}
	return 0;
}

INT16U  AT_CMD(INT8U *Data,INT16U Ms,INT16U Num,INT8U *CmpStr1,INT8U *CmpStr2)
{
	INT16U	i,j,count;
	int len;
	ATHead=0;
	ATTail=0;

	memset(TmpBuf,0,FrameSize);
	CleardeadCount();
	SelfheartCount = 0;
	//SetSpiLed(NETSEND);
	for(j=0;j<1;j++)
	{
		printf("\r\nS[%s",Data);
		write(ComPort,Data,strlen((char *)Data));
		delay(Ms+(j*100));
		count=0;
		while(1)
		{
			delay(100);
			CleardeadCount();
			SelfheartCount = 0;
			len = read(ComPort,TmpBuf,200);
			if(len > 0)
			{
				for(i=0;i<len;i++)
				{
					TmpBuf[ATHead]=TmpBuf[i];
					ATHead=(ATHead+1)%FrameSize;
					count=0;
				}
				if(GetStrInclude(CmpStr1))
				{
					return 1;//ok
				}
				if(GetStrInclude(CmpStr2))
				{
					return 2;//error
				}
				OSTimeDly(50);
				count++;
				if(count>=Num)
				{
					break;
				}
			}else
				return 2;
		}
	}
	return 0;
}
int GetDuanXinHao()
{
	int i,k;
	if(ATHead>10)
	{
		for(i=0;i<ATHead;i++)
		{
			if((TmpBuf[i]=='+')&&(TmpBuf[i+1]=='C')&&(TmpBuf[i+2]=='M')&&(TmpBuf[i+3]=='T')&&(TmpBuf[i+4]=='I')&&(TmpBuf[i+5]==':')&&(TmpBuf[i+6]==' ')&&(TmpBuf[i+7]=='S')&&(TmpBuf[i+8]=='M')&&(TmpBuf[i+9]==',')&&(TmpBuf[i+10]==' '))
				break;
		}
		if(sscanf((char *)&TmpBuf[i],"+CMTI: SM, %d",&k)==1)
		{
			return k;
		}
	}
	return 2;//����ϢĬ�ϴ洢��SIM����
}
void DuanXinJiHuo()
{
	int m;
	memset(ATCmd,0,256);
	sprintf((char *)ATCmd,"AT+CMGF=1");
	if(AT_CMD(ATCmd,200,2,(INT8U *)"OK",(INT8U *)"ERROR")==1)
	{
		printf("\n\rAT+CMGF   return  ok !!!!!!!");
		printf("\n\r");
		memset(ATCmd,0,256);
		sprintf((char *)ATCmd,"AT+CNMI=2,1,0,0,0");
		if(AT_CMD(ATCmd,200,2,(INT8U *)"OK",(INT8U *)"ERROR")==1)
		{
			m=GetDuanXinHao();
			printf("\n\r duanxinhaoma is %d",m);
			memset(ATCmd,0,256);
			sprintf((char *)ATCmd,"AT+CMGR=m");
			printf("\r\n TemBuf  is  %s",&TmpBuf[0]);
		}
	}
}
int main(int argc, char *argv[])
{

	int porttmp;
	int err;
	int cnt=0;
	int ercno=0;
	struct sigaction sa1;
	TS ts;
	int PassLost;
	INT8U Min=0;
	FK_130_Link_Ok=0;
	PassLost=0;

	markver();

	if(OpenMem())return EXIT_FAILURE;
	if(RtuDataAddr->mem_len!=sizeof(RTimeData))
	{
		return EXIT_FAILURE;
	}
	if(!PARSE_CMD(argc, argv))
	{
		DebugOut("\n Bad command format. Type 'use exe_name' for help!\n\r");
		return EXIT_FAILURE;
	}
	InitGpio();
	initgprsid();
	sa1.sa_handler = QuitProcess;
	sigemptyset(&sa1.sa_mask);
	sa1.sa_flags = 0;
	sigaction(SIGTERM, &sa1,NULL);
	sigaction(SIGSYS, &sa1,NULL);
	sigaction(SIGPWR, &sa1,NULL);
	sigaction(SIGKILL, &sa1,NULL);
	sigaction(SIGQUIT, &sa1,NULL);
	sigaction(SIGILL, &sa1,NULL);
	sigaction(SIGINT, &sa1,NULL);
	sigaction(SIGHUP, &sa1,NULL);
	sigaction(SIGABRT, &sa1,NULL);
	sigaction(SIGBUS, &sa1,NULL);

	RtuDataAddr->stPortPara[PORT_ID].PID=getpid();
	RecTail=RecHead=0;
	RtuDataAddr->Gprs_ok = 0;
	RtuDataAddr->autoReport=1;
	while(RtuDataAddr->Dev_Init_OK==0)
	{
		CleardeadCount();
		delay(1000);
	}
	memcpy(&CommPara.Valid,&RtuDataAddr->FkComm_Value.F3_Set_Para.Valid,sizeof(CommPara));

	init130pro();
	RtuDataAddr->GprsRedialBetween=0xff00;
	//-----------------------
	err =0;
	AutoFlg=0;
	porttmp = (CommPara.PortMaster[1]<<8)+CommPara.PortMaster[0];
	DebugOut("\n\r IP: %d.%d.%d.%d port:%d apn:%s",CommPara.IPMaster[0],
												 CommPara.IPMaster[1],
												 CommPara.IPMaster[2],
												 CommPara.IPMaster[3],
												 porttmp,
												 CommPara.APN);

	memcpy(&CommPara.Valid,&RtuDataAddr->FkComm_Value.F3_Set_Para.Valid,sizeof(CommPara));
	memset(PppAPN,0,16);
	initApn(PORT_ID);//��¼��ʼAPN
	SelfheartCount = 0;
	CreatThread();
	reconnect = 0;
	Gwfp = NULL;
	Gwfp =  fopen("/nand/fk130.log","a+");
	//-----------------------
	for (;;)
	{
		TSGet(&ts);
		CleardeadCount();
		SelfheartCount = 0;
		memcpy(&CommPara.Valid,&RtuDataAddr->FkComm_Value.F3_Set_Para.Valid,sizeof(CommPara));
		delay(50);

		Test_WirelessModule();						//1�����ͨ�ŷ�ʽ��gprs��ʽ����̫����ʽ
		ProcessDial();								//2�����ţ�������վ����
		if(RtuDataAddr->Fk130RestartNum > 5)		//3���жϽ����������������ڶֵϵͳ����
		{
			fprintf(stderr,"\n\r restart num %d",RtuDataAddr->Fk130RestartNum);
			RtuDataAddr->Fk130RestartNum =0;
			system("shutdown");
			delay(5000);
		}
		if ((RtuDataAddr->Gprs_ok==0)&&(reconnect>3))//4���ж�������վ���������ڶֵ��Ҫ��������
		{
			fprintf(stderr,"\n\rbreak iec130 reconnect is %d",reconnect);
			RtuDataAddr->Fk130RestartNum ++;
			break;
		}
		if (RtuDataAddr->Gprs_ok != 1)				//5���ж�����״̬�����������²������Ӵ���
		{
			RtuDataAddr->Gprs_ok = 0;
			continue;
		}
		GetNormal();								//6�����¼���߼���ַ��׼����½
		SelfheartCount = 0;
		if ((ts.Sec % 10)==0)
		{
			if(RtuDataAddr->linked_ok==0)
			{
				LinkControl(1);//��½
				cnt++;
				DebugOut("cnt--------------->>>%d ",cnt);
				RtuDataAddr->LinkCalc++;
				delay(2000);
			}
			if(RtuDataAddr->LinkCalc >= 5)
			{
				fprintf(stderr,"\n\r chongxin lianjie jianli lianlu ");
				RtuDataAddr->linked_ok = 0;
				RtuDataAddr->LinkCalc  = 0;
				FK_130_Link_Ok	 = 0;
				RtuDataAddr->Gprs_ok=0;
				RtuDataAddr->Fk130RestartNum =0;
				continue;
			}
		}
		Get_Data_Process();
		if (RtuDataAddr->linked_ok==1)
		{
			RtuDataAddr->Fk130RestartNum =0;
			if(ts.Minute!=Min)
			{
				autoReportOneLevelData();
				mydelay(3);//����洢�ļ��������ϱ���ͻ����֤�Դ��ļ����ϱ�
				autoReportTwoLevelData();
				HeartBeat_Count++;
				RtuDataAddr->HungUpTime++;
				Min=ts.Minute;
			}
		}
		//if(RtuDataAddr->FkComm_Value.F8_Set_Para.Valid==1)
		{
			//if((RtuDataAddr->FkComm_Value.F8_Set_Para.GPRS_MODE&0x01)==1)
			{
				if(RtuDataAddr->FkComm_Value.F1_Set_Para.Heart_Beat<=0)
					RtuDataAddr->FkComm_Value.F1_Set_Para.Heart_Beat = 2;
				if(HeartBeat_Count>=RtuDataAddr->FkComm_Value.F1_Set_Para.Heart_Beat)
				{
					LinkControl(3);
					HeartBeat_Count=0;
					RtuDataAddr->LinkCalc++;
					DebugOut("\n\r RtuDataAddr->LinkCalc= %d",RtuDataAddr->LinkCalc);
				}
			}
		}
		if((RtuDataAddr->EC1old!=RtuDataAddr->EC1)&&(RtuDataAddr->linked_ok==1))
		{
			if(RtuDataAddr->FuKong_Control_Value.F29_Control_Para.Valid==1)
			{
				DebugOut("\r\n������Ҫ�¼�");
				ercno=AutoSendThreeLevelData(1);
				if ((RtuDataAddr->batflag == 1)&&(ercno==1))
				{
					delay(30);
					DebugOut("\n\r tingdian chongxin lianjie jianli lianlu ");
					RtuDataAddr->linked_ok = 0;
					RtuDataAddr->LinkCalc  = 0;
					FK_130_Link_Ok	 = 0;
					RtuDataAddr->Gprs_ok=0;
					RtuDataAddr->Fk130RestartNum =0;
				}
			}
		}
	}
   	name_detach(attach, 0);
 	return EXIT_SUCCESS;
}
