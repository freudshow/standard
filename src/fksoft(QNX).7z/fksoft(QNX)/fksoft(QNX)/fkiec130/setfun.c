/*
 * setfun.c
 *
 *  Created on: 2009-12-16
 *      Author: www
 */
#include "setfun.h"
extern INT8U SendTaskData(INT8U P,INT8U F,INT8U *t);
extern void INT16_A5(INT16U Value,unsigned char * bcd);
void SetDaDt(INT8U P,INT8U F)
{
	SendBuff[SendLen++]=SetDa1(P);
	SendBuff[SendLen++]=SetDa2(P);
	SendBuff[SendLen++]=SetDt1(F);
	SendBuff[SendLen++]=SetDt2(F);

}
// void Create_Data_Type03(INT32S S,INT8U *Dest)
// long GetdataType03(INT8U *S)

void SaveGouDianEve(INT8U ZjNo,F47_Set_Stru seted,long OldDD)
{
	if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)
	{
		if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[2]&0x04)//��Ҫ�Բ������ý����¼���¼
		{
			SaveEveBegin(19);
			RtuDataAddr->Event_Save.Event.Err19.ERCNo=19;
			RtuDataAddr->Event_Save.Event.Err19.len=31;
			RtuDataAddr->Event_Save.Event.Err19.ZjNo=ZjNo+1;
			memcpy(RtuDataAddr->Event_Save.Event.Err19.DanHao,seted.Gou_DIan_DanHao,4);
			RtuDataAddr->Event_Save.Event.Err19.Zj_Sx_BiaoZhi=seted.zhuijia_Shuaxin;
			memcpy(RtuDataAddr->Event_Save.Event.Err19.Gou_DD,seted.Gou_DIan_Value,4);
			memcpy(RtuDataAddr->Event_Save.Event.Err19.Bj_Men,seted.Alarm_Men,4);
			memcpy(RtuDataAddr->Event_Save.Event.Err19.TZ_Men,seted.TiaoZha_Men,4);
			Create_Data_Type03(OldDD,RtuDataAddr->Event_Save.Event.Err19.Old_DD);
			Create_Data_Type03(GetdataType03(RtuDataAddr->Zj_Control_Value[ZjNo-1].New_DianLiang),RtuDataAddr->Event_Save.Event.Err19.New_DD);
			if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[2]&0x04)//��Ҫ�¼�
			{
				SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err19.Occur_Time.BCD01,1,19);
			}
			else//һ���¼�
			{
				SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err19.Occur_Time.BCD01,2,19);
			}
		}
	}
}
void SetPara()
{
	Resolve_Pos=14;
	AlArmReportBeginNoDly();
	AlArmReportEnd();
	delay(5);
//#if USEPASSWD16
#if 1
	while(Resolve_Pos<(RecDataLen-10))//���볤��Ϊ16ʱʹ��
#else
	while(Resolve_Pos<(RecDataLen))//���볤��Ϊ2ʱʹ��
#endif

	{
		printf("\n\r SetPara While Resolve_Pos=%d",Resolve_Pos);
		Resolve_Pos=Resolve_Pos+SendSet(&Tmp130Buff[Resolve_Pos]);
	}
}
void TaskCalc()
{
	INT8U i,j;//Pro130SetMax
	INT16U Tmp_Resolve_Pos;
	Tmp_Resolve_Pos=14;
	AllReportHead=0;
	AllReportTail=0;
	while(Tmp_Resolve_Pos<(RecDataLen+6))
	{
		GetDa(Tmp130Buff[Tmp_Resolve_Pos],Tmp130Buff[Tmp_Resolve_Pos+1]);
		GetDt(Tmp130Buff[Tmp_Resolve_Pos+2],Tmp130Buff[Tmp_Resolve_Pos+3]);
		for(i=0;i<64;i++)
		{
			if(DA[i]==1)
			{
				for(j=0;j<255;j++)
				{
					if(DT[j]==1)
					{
					AllReportHead++;
					}
				}
			}
		}
		Tmp_Resolve_Pos+=4;
	}
}
void CallTaskData()
{
	INT8U i,j;
	TaskCalc();
	Resolve_Pos=14;
	while(Resolve_Pos<(RecDataLen+6))
	{
		GetDa(Tmp130Buff[Resolve_Pos],Tmp130Buff[Resolve_Pos+1]);
		GetDt(Tmp130Buff[Resolve_Pos+2],Tmp130Buff[Resolve_Pos+3]);
		for(i=0;i<64;i++)
		{
			if(DA[i]==1)
			{
				for(j=0;j<255;j++)
				{
					if(DT[j]==1)
					{
						Resolve_Pos=Resolve_Pos+SendTaskData(i,j,&Tmp130Buff[Resolve_Pos+4]);
					}
				}
			}
		}
		Resolve_Pos+=4;
	}
	return;
}
void CallSetPara()
{
	INT16U TmpSendlen;
	FrameHeadCreate(0x88);
	SendBuff[SendLen++]=0x0a;//afn
	SendBuff[SendLen++]=0x60|(seq&0x0f);//seq
	Resolve_Pos=14;
	TmpSendlen=SendLen;
	while(Resolve_Pos<(RecDataLen+6))// 14   21
	{
		Resolve_Pos=Resolve_Pos+CallSet(&Tmp130Buff[Resolve_Pos]);
		printf("\n\r Resolve_Pos %d",Resolve_Pos);
	}
	if(TmpSendlen==SendLen)
	{
		goto nodata;
	}
	EC();
	TP();
	FrameTailCreate_Send();
	return;
	nodata:
	//SendNAK(TmpF,TmpP,4);
	SendALLNAK();
	return;
}
INT16U SendSet(INT8U *s)
{
	INT8U i,j;
	INT16U Result;
	Result=4;
	FrameHeadCreate(0x80);
	SendBuff[SendLen++]=0;//afn
	SendBuff[SendLen++]=0x60|(seq&0x0f);//seq
	SendBuff[SendLen++]=0;//Tmp130Buff[14];//da1e
	SendBuff[SendLen++]=0;//Tmp130Buff[15];//da2
	SendBuff[SendLen++]=4;//Tmp130Buff[16];//dt1
	SendBuff[SendLen++]=0;//Tmp130Buff[17];//dt2
	SendBuff[SendLen++]=0x04;//��������
	memset(DA,0,65);
	memset(DT,0,255);
	GetDa(s[0],s[1]);
	GetDt(s[2],s[3]);
	CeLiangChg=0;
	ZongJiaChg=0;
	TaskChg=0;
	ZongJiaSetChg=0;
	ControlChg=0;
	//AlArmReportBeginNoDly();
	//printf("\n\r AlArmReportBeginNoDly !!!!!");

	for(i=0;i<65;i++)
	{
		if(DA[i]==1)
		{
			for(j=0;j<249;j++)
			{
				if(DT[j]==1)
				{
					TmpF=j;TmpP=i;
					printf("  P=%d F=%d",i,j);
					switch(j)
					{
					//---------------��֧�ֵ�
					case 30:
						Result=Result+GetF30(1,j,i,&s[Result]);
						break;
					case 31:
						Result=Result+GetF31(1,j,i,&s[Result]);
						break;
					case 35:
						Result=Result+GetF35(1,j,i,&s[Result]);
						break;
					case 37:
						Result=Result+GetF37(1,j,i,&s[Result]);
						break;
					//----------------------
					case 1:
						Result=Result+GetF1(1,j,i,&s[Result]);
						break;
					case 3:
						Result=Result+GetF3(1,j,i,&s[Result]);
						break;
					case 4:
						Result=Result+GetF4(1,j,i,&s[Result]);
						break;
					case 8:
						Result=Result+GetF8(1,j,i,&s[Result]);
						break;
					case 9:
						Result=Result+GetF9(1,j,i,&s[Result]);
						break;
					case 10:
						Result=Result+GetF10(1,j,i,&s[Result]);
						break;
					case 11:
						Result=Result+GetF11(1,j,i,&s[Result]);
						break;
					case 21:
						Result=Result+GetF21(1,j,i,&s[Result]);
						break;
					//case 27:
					//	Result=Result+GetF27(1,j,i,&s[Result]);
						//break;

						/*
					case 62:
						Result=Result+GetF62(1,j,i,&s[Result]);
						break;
						*/
					case 65:
						Result=Result+GetF65(1,j,i,&s[Result]);
						break;
					case 66:
						Result=Result+GetF66(1,j,i,&s[Result]);
						break;
					case 67:
						Result=Result+GetF67(1,j,i,&s[Result]);
						break;
					case 68:
						Result=Result+GetF68(1,j,i,&s[Result]);
						break;
					case 2:
						Result=Result+GetF2(1,j,i,&s[Result]);
						break;
					case 5:
						Result=Result+GetF5(1,j,i,&s[Result]);
						break;
					case 6:
						Result=Result+GetF6(1,j,i,&s[Result]);
						break;
					case 7:
						Result=Result+GetF7(1,j,i,&s[Result]);
						break;
					case 12:
						Result=Result+GetF12(1,j,i,&s[Result]);
						break;
					case 13:
						Result=Result+GetF13(1,j,i,&s[Result]);
						break;
					case 14:
						Result=Result+GetF14(1,j,i,&s[Result]);
						break;
					case 15:
						Result=Result+GetF15(1,j,i,&s[Result]);
						break;
					case 16:
						Result=Result+GetF16(1,j,i,&s[Result]);
						break;
					case 17:
						Result=Result+GetF17(1,j,i,&s[Result]);
						printf("\n\r Result17 == %d",Result);
						break;
					case 18:
						Result=Result+GetF18(1,j,i,&s[Result]);
						break;
					case 19:
						Result=Result+GetF19(1,j,i,&s[Result]);
						printf("\n\r Result19 == %d",Result);
						break;
					case 20:
						Result=Result+GetF20(1,j,i,&s[Result]);
						break;
					case 22:
						Result=Result+GetF22(1,j,i,&s[Result]);
						break;
					case 23:
						Result=Result+GetF23(1,j,i,&s[Result]);
						break;
					case 24:
						Result=Result+GetF24(1,j,i,&s[Result]);
						break;
					case 25:
						Result=Result+GetF25(1,j,i,&s[Result]);
						break;
					case 26:
						Result=Result+GetF26(1,j,i,&s[Result]);
						break;
					case 28:
						Result=Result+GetF28(1,j,i,&s[Result]);
						break;
					case 29:
						Result=Result+GetF29(1,j,i,&s[Result]);
						break;
					case 33:
						Result=Result+GetNewF33(1,j,i,&s[Result]);
						break;
//liujia
					case 34:
						Result=Result+GetF34(1,j,i,&s[Result]);
						break;
					case 36:
						Result=Result+GetF36(1,j,i,&s[Result]);
						break;
					case 38:
						Result=Result+GetF38(1,j,i,&s[Result]);
						break;
					case 39:
						Result=Result+GetF39(1,j,i,&s[Result]);
						break;
					case 41:
						Result=Result+GetF41(1,j,i,&s[Result]);
						break;
					case 42:
						Result=Result+GetF42(1,j,i,&s[Result]);
						break;
					case 43:
						Result=Result+GetF43(1,j,i,&s[Result]);
						printf("\n\r Result43 == %d",Result);
						break;
					case 44:
						Result=Result+GetF44(1,j,i,&s[Result]);
						break;
					case 45:
						Result=Result+GetF45(1,j,i,&s[Result]);
						printf("\n\r Result45 == %d",Result);
						break;
					case 46:
						Result=Result+GetF46(1,j,i,&s[Result]);
						break;
					case 47:
						Result=Result+GetF47(1,j,i,&s[Result]);
						break;
					case 48:
						Result=Result+GetF48(1,j,i,&s[Result]);
						break;
					case 49:
						Result=Result+GetF49(1,j,i,&s[Result]);
						printf("\n\r Result49 == %d",Result);
						break;
					case 57:
						Result=Result+GetF57(1,j,i,&s[Result]);
						printf("\n\r Result57 == %d",Result);
						break;
					case 58:
						Result=Result+GetF58(1,j,i,&s[Result]);
						break;
					case 59:
						Result=Result+GetF59(1,j,i,&s[Result]);
						break;
					case 60:
						Result=Result+GetF60(1,j,i,&s[Result]);
						break;
					case 61:
						Result=Result+GetF61(1,j,i,&s[Result]);
						break;
					case 73:
						Result=Result+GetF73(1,j,i,&s[Result]);
						break;
					case 74:
						Result=Result+GetF74(1,j,i,&s[Result]);
						break;
					case 75:
						Result=Result+GetF75(1,j,i,&s[Result]);
						break;
					case 76:
						Result=Result+GetF76(1,j,i,&s[Result]);
						break;
					case 81:
						Result=Result+GetF81(1,j,i,&s[Result]);
						break;
					case 82:
						Result=Result+GetF82(1,j,i,&s[Result]);
						break;
					case 83:
						Result=Result+GetF83(1,j,i,&s[Result]);
						break;
					}
				}
			}
		}
	}
	if(TaskChg==1)
	{
		TaskChg=0;
		Save_Task_Set();
	}
	if(CeLiangChg==1)
	{
		CeLiangChg=0;
		Save_Cl_MenXian_Set();
	}
	if(ZongJiaChg==1)
	{
		ZongJiaChg=0;
		Save_Zj_Control_Set();
	}
	if(ZongJiaSetChg==1)
	{
		ZongJiaSetChg=0;
		Save_Zongjia_Set();
	}
	if(ControlChg==1)
	{
		ControlChg=0;
		Save_Fk_Control_Set();
	}
	EC();
	TP();

	//AlArmReportEnd();
//	FrameTailCreate_Send();
	SendALLACK();
	return Result;
}
INT16U CallSet(INT8U *s)
{
	INT8U i,j;
	INT16U Result;
	Result=0;
	memset(DA,0,65);
	memset(DT,0,255);
	GetDa(s[0],s[1]);
	GetDt(s[2],s[3]);
	for(i=0;i<65;i++)
	{
		if(DA[i]==1)
		{
			for(j=0;j<249;j++)
			{
				if(DT[j]==1)
				{
					TmpF=j;TmpP=i;
					DebugOut("   P=%d F=%d",i,j);
					switch(j)
					{
					//---------------��֧�ֵ�
					case 30:
						Result=Result+GetF30(0,j,i,s);
						break;
					case 31:
						Result=Result+GetF31(0,j,i,s);
						break;
					case 34:
						Result=Result+GetF34(0,j,i,s);
						break;
					case 35:
						Result=Result+GetF35(0,j,i,s);
						break;
					case 37:
						Result=Result+GetF37(0,j,i,s);
						break;
					//----------------------
					case 1:
						Result=Result+GetF1(0,j,i,s);
						break;
					case 3:
						Result=Result+GetF3(0,j,i,s);
						break;
					case 4:
						Result=Result+GetF4(0,j,i,s);
						break;
					case 8:
						Result=Result+GetF8(0,j,i,s);
						break;
					case 9:
						Result=Result+GetF9(0,j,i,s);
						break;
					case 10:
						Result=Result+GetF10(0,j,i,s);
						break;
					case 11:
						Result=Result+GetF11(0,j,i,s);
						break;
					case 21:
						Result=Result+GetF21(0,j,i,s);
						break;
					//case 27:
						//Result=Result+GetF27(0,j,i,s);
						//break;
						/*
					case 62:
						Result=Result+GetF62(0,j,i,s);
						break;*/
					case 65:
						Result=Result+GetF65(0,j,i,s);
						break;
					case 66:
						Result=Result+GetF66(0,j,i,s);
						break;
					case 67:
						Result=Result+GetF67(0,j,i,s);
						break;
					case 68:
						Result=Result+GetF68(0,j,i,s);
						break;


					case 2:
						Result=Result+GetF2(0,j,i,s);
						break;
					case 5:
						Result=Result+GetF5(0,j,i,s);
						break;
					case 6:
						Result=Result+GetF6(0,j,i,s);
						break;
					case 7:
						Result=Result+GetF7(0,j,i,s);
						break;
					case 12:
						Result=Result+GetF12(0,j,i,s);
						break;
					case 13:
						Result=Result+GetF13(0,j,i,s);
						break;
					case 14:
						Result=Result+GetF14(0,j,i,s);
						break;
					case 15:
						Result=Result+GetF15(0,j,i,s);
						break;
					case 16:
						Result=Result+GetF16(0,j,i,s);
						break;
					case 17:
						printf("\n\r Call F17");
						Result=Result+GetF17(0,j,i,s);
						break;
					case 18:
						Result=Result+GetF18(0,j,i,s);
						break;
					case 19:
						printf("\n\r Call F19");
						Result=Result+GetF19(0,j,i,s);
						break;
					case 20:
						Result=Result+GetF20(0,j,i,s);
						break;
					case 22:
						Result=Result+GetF22(0,j,i,s);
						break;
					case 23:
						Result=Result+GetF23(0,j,i,s);
						break;
					case 24:
						Result=Result+GetF24(0,j,i,s);
						break;
					case 25:
						Result=Result+GetF25(0,j,i,s);
						break;
					case 26:
						Result=Result+GetF26(0,j,i,s);
						break;
					case 28:
						Result=Result+GetF28(0,j,i,s);
						break;
					case 29:
						Result=Result+GetF29(0,j,i,s);
						break;
					case 33:
						Result=Result+ GetNewF33(0,j,i,s);
						break;
					case 36:
						Result=Result+ GetF36(0,j,i,s);
						break;
					case 38:
						Result=Result+ GetF38(0,j,i,s);
						break;
					case 39:
						Result=Result+ GetF39(0,j,i,s);
						break;
					case 41:
						Result=Result+GetF41(0,j,i,s);
						break;
					case 42:
						Result=Result+GetF42(0,j,i,s);
						break;
					case 43:
						printf("\n\r Call F43");
						Result=Result+GetF43(0,j,i,s);
						break;
					case 44:
						Result=Result+GetF44(0,j,i,s);
						break;
					case 45:
						Result=Result+GetF45(0,j,i,s);
						break;
					case 46:
						Result=Result+GetF46(0,j,i,s);
						break;
					case 47:
						Result=Result+GetF47(0,j,i,s);
						break;
					case 48:
						Result=Result+GetF48(0,j,i,s);
						break;
					case 49:
						printf("\n\r Call F49");
						Result=Result+GetF49(0,j,i,s);
						break;
					case 57:
						Result=Result+GetF57(0,j,i,s);
						break;
					case 58:
						Result=Result+GetF58(0,j,i,s);
						break;
					case 59:
						Result=Result+GetF59(0,j,i,s);
						break;
					case 60:
						Result=Result+GetF60(0,j,i,s);
						break;
					case 61:
						Result=Result+GetF61(0,j,i,s);
						break;
					case 73:
						Result=Result+GetF73(0,j,i,s);
						break;
					case 74:
						Result=Result+GetF74(0,j,i,s);
						break;
					case 75:
						Result=Result+GetF75(0,j,i,s);
						break;
					case 76:
						Result=Result+GetF76(0,j,i,s);
						break;
					case 81:
						Result=Result+GetF81(0,j,i,s);
						break;
					case 82:
						Result=Result+GetF82(0,j,i,s);
						break;
					case 83:
						Result=Result+GetF83(0,j,i,s);
						break;
					default:
						Result=Result+4;
						break;
					}
				}
			}
		}
	}
	if (Result == 0)
		return 4;
	return Result;
}
INT8U GetF30(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		SendBuff[SendLen++]=1;
		return 1;
	}
	if(Set==0)//��ȡ���ñ���
	{
		return 4;
	}
	return 1;
}
INT8U GetF31(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		SendBuff[SendLen++]=1;
		return (Data[0]*6+1);
	}
	if(Set==0)//��ȡ���ñ���
	{
		return 4;
	}
	return 1;
}
INT8U GetF34(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		SendBuff[SendLen++]=1;
		return (Data[0]*6+1);
	}
	if(Set==0)//��ȡ���ñ���
	{
		return 4;
	}
	return 1;
}
INT8U GetF35(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		SendBuff[SendLen++]=1;
		return (Data[0]*2+1);
	}
	if(Set==0)//��ȡ���ñ���
	{
		return 4;
	}
	return 1;
}
INT8U GetF37(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		SendBuff[SendLen++]=1;
		return (Data[6]*4+7);
	}
	if(Set==0)//��ȡ���ñ���
	{
		return 4;
	}
	return 1;
}
INT8U GetF1(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			return 6;
		}
		RtuDataAddr->FkComm_Value.F1_Set_Para.Valid=1;
		memcpy(&RtuDataAddr->FkComm_Value.F1_Set_Para.RTS_Time,Data,6);
		RtuDataAddr->FkComm_Value.F1_Set_Para.Heart_Beat = Data[5];
		Save_CommSet();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(0,0,1,0);
		RtuDataAddr->SetChanged[1]=1;
		return 6;
	}
	if(Set==0)//��ȡ���ñ���
	{
		if(RtuDataAddr->FkComm_Value.F1_Set_Para.Valid==1)//�����ڴ��Ѿ������ʼ��Ϊ1������Ҫ���Ρ�
		{
			SetDaDt(P,F);
			memcpy(&SendBuff[SendLen],&RtuDataAddr->FkComm_Value.F1_Set_Para.RTS_Time,sizeof(RtuDataAddr->FkComm_Value.F1_Set_Para)-1);
			SendLen=SendLen+sizeof(RtuDataAddr->FkComm_Value.F1_Set_Para)-1;
		}
		return 4;
	}
	return 1;
}
INT8U GetF2(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	INT8U i,len;
	len=0;
	if(Set==1)//��վ��������
	{
		RtuDataAddr->FkComm_Value.F2_Set_Para.Valid=1;
		RtuDataAddr->FkComm_Value.F2_Set_Para.ZhongDuan_Num=Data[0];
		len++;
		for(i=0;i<(RtuDataAddr->FkComm_Value.F2_Set_Para.ZhongDuan_Num&0x7f);i++)
		{
			RtuDataAddr->FkComm_Value.F2_Set_Para.Addr[i*2]=Data[1+i*2];
			RtuDataAddr->FkComm_Value.F2_Set_Para.Addr[i*2+1]=Data[2+i*2];
			len+=2;
		}
		Save_CommSet();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(0,0,2,0);
		RtuDataAddr->SetChanged[2]=1;
		return len;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->FkComm_Value.F2_Set_Para.Valid==1)//Ϊ�����ά��վ�вⲻ�����ݣ��������Ρ�
		{
			SetDaDt(P,F);
			SendBuff[SendLen++]=RtuDataAddr->FkComm_Value.F2_Set_Para.ZhongDuan_Num;
			for(i=0;i<(RtuDataAddr->FkComm_Value.F2_Set_Para.ZhongDuan_Num&0x7f);i++)
			{
				SendBuff[SendLen++]=RtuDataAddr->FkComm_Value.F2_Set_Para.Addr[i*2];
				SendBuff[SendLen++]=RtuDataAddr->FkComm_Value.F2_Set_Para.Addr[i*2+1];
			}
		}
		return 4;
	}
	return 1;
}
INT8U GetF3(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	unsigned char ipold[4];
	unsigned char port[2];
	if(Set==1)//��վ��������
	{
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			return sizeof(RtuDataAddr->FkComm_Value.F3_Set_Para)-1;
		}
		RtuDataAddr->FkComm_Value.F3_Set_Para.Valid=1;
		memcpy(ipold,RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster,4);
		memcpy(port,RtuDataAddr->FkComm_Value.F3_Set_Para.PortMaster,2);
		memcpy(&RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[0],Data,sizeof(RtuDataAddr->FkComm_Value.F3_Set_Para)-1);
		Save_CommSet();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(0,0,4,0);
		RtuDataAddr->SetChanged[3]=1;
		if((strncmp((char *)ipold,(char *)RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster,4)!=0)||(strncmp((char *)port,(char *)RtuDataAddr->FkComm_Value.F3_Set_Para.PortMaster,2)!=0))
		{
			RtuDataAddr->Gprs_ok = 0;
		}
		return sizeof(RtuDataAddr->FkComm_Value.F3_Set_Para)-1;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->FkComm_Value.F3_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			memcpy(&SendBuff[SendLen],&RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[0],sizeof(RtuDataAddr->FkComm_Value.F3_Set_Para)-1);
			SendLen=SendLen+sizeof(RtuDataAddr->FkComm_Value.F3_Set_Para)-1;
		}
		return 4;
	}
	return 1;
}
INT8U GetF4(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			return sizeof(RtuDataAddr->FkComm_Value.F4_Set_Para)-1;
		}
		RtuDataAddr->FkComm_Value.F4_Set_Para.Valid=1;
		memcpy(&RtuDataAddr->FkComm_Value.F4_Set_Para.Zhuzhan_tel[0],Data,sizeof(RtuDataAddr->FkComm_Value.F4_Set_Para)-1);
		Save_CommSet();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(0,0,8,0);
		RtuDataAddr->SetChanged[4]=1;
		return sizeof(RtuDataAddr->FkComm_Value.F4_Set_Para)-1;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->FkComm_Value.F4_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			memcpy(&SendBuff[SendLen],&RtuDataAddr->FkComm_Value.F4_Set_Para.Zhuzhan_tel[0],sizeof(RtuDataAddr->FkComm_Value.F4_Set_Para)-1);
			SendLen=SendLen+sizeof(RtuDataAddr->FkComm_Value.F4_Set_Para)-1;
		}
		return 4;
	}
	return 1;
}
INT8U GetF5(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			return sizeof(RtuDataAddr->FkComm_Value.F5_Set_Para)-1;
		}
		RtuDataAddr->FkComm_Value.F5_Set_Para.Valid=1;
		memcpy(&RtuDataAddr->FkComm_Value.F5_Set_Para.XiaoXi_Renzheng_FangAN,Data,sizeof(RtuDataAddr->FkComm_Value.F5_Set_Para)-1);
		Save_CommSet();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(0,0,0x10,0);
		RtuDataAddr->SetChanged[5]=1;
		return sizeof(RtuDataAddr->FkComm_Value.F5_Set_Para)-1;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->FkComm_Value.F5_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			memcpy(&SendBuff[SendLen],&RtuDataAddr->FkComm_Value.F5_Set_Para.XiaoXi_Renzheng_FangAN,sizeof(RtuDataAddr->FkComm_Value.F5_Set_Para)-1);
			SendLen=SendLen+sizeof(RtuDataAddr->FkComm_Value.F5_Set_Para)-1;
		}
		return 4;
	}
	return 1;
}
INT8U GetF6(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			return sizeof(RtuDataAddr->FkComm_Value.F6_Set_Para)-1;
		}
		RtuDataAddr->FkComm_Value.F6_Set_Para.Valid=1;
		memcpy(&RtuDataAddr->FkComm_Value.F6_Set_Para.Group1[0],Data,sizeof(RtuDataAddr->FkComm_Value.F6_Set_Para)-1);
		Save_CommSet();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(0,0,0x20,0);
		RtuDataAddr->SetChanged[6]=1;
		return sizeof(RtuDataAddr->FkComm_Value.F6_Set_Para)-1;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->FkComm_Value.F6_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			memcpy(&SendBuff[SendLen],&RtuDataAddr->FkComm_Value.F6_Set_Para.Group1[0],sizeof(RtuDataAddr->FkComm_Value.F6_Set_Para)-1);
			SendLen=SendLen+sizeof(RtuDataAddr->FkComm_Value.F6_Set_Para)-1;
		}
		return 4;
	}
	return 1;
}
INT8U GetF7(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	//int plength = 0;
	int index = 0;
	unsigned char tmp[128];
	memset(tmp,0,128);
	if(Set==1)//��վ��������
	{
		RtuDataAddr->FkInput_Value.F7_Set_Para.Valid=1;
		memcpy(&RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[0],Data,21);
		index = 21;

		memcpy(RtuDataAddr->FkInput_Value.F7_Set_Para.UserName,Data+index,RtuDataAddr->FkInput_Value.F7_Set_Para.UserNameLength);
		index = index + RtuDataAddr->FkInput_Value.F7_Set_Para.UserNameLength;

		RtuDataAddr->FkInput_Value.F7_Set_Para.PassWordLength = Data[index];
		index = index +1;
		memcpy(RtuDataAddr->FkInput_Value.F7_Set_Para.PassWord,Data+index,RtuDataAddr->FkInput_Value.F7_Set_Para.PassWordLength);

		index = index + RtuDataAddr->FkInput_Value.F7_Set_Para.PassWordLength;
		memcpy(RtuDataAddr->FkInput_Value.F7_Set_Para.ZhenTingPort,Data+index,2);

		Save_Input_Set();
		printf("\n\rip: %d.%d.%d.%d",RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[0],
				RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[1],
				RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[2],
				RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[3]);
		sprintf((char *)tmp,"ifconfig en0 %d.%d.%d.%d up",
		RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[0]
		,RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[1]
		,RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[2]
		,RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[3]);
		system((char *)tmp);

		memset(tmp,0,128);
		sprintf((char *)tmp,"echo \"ifconfig en0 %d.%d.%d.%d up\" > /etc/rc.d/ip.sh",RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[0]
		,RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[1]
		,RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[2]
		,RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[3]);
		system((char *)tmp);
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(0,0,0x40,0);
		RtuDataAddr->SetChanged[7]=1;
		return index+2;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->FkInput_Value.F7_Set_Para.Valid==1)
		{
			RtuDataAddr->FkInput_Value.F7_Set_Para.PassWordLength = 20;
			RtuDataAddr->FkInput_Value.F7_Set_Para.UserNameLength = 20;
			SetDaDt(P,F);
			memcpy(&SendBuff[SendLen],&RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[0],sizeof(RtuDataAddr->FkInput_Value.F7_Set_Para)-1);
			SendLen=SendLen+sizeof(RtuDataAddr->FkInput_Value.F7_Set_Para)-1;
		}
		return 4;
	}
	return 1;
}

INT8U GetF8(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			return sizeof(RtuDataAddr->FkComm_Value.F8_Set_Para)-1;
		}
		RtuDataAddr->FkComm_Value.F8_Set_Para.Valid=1;
		memcpy(&RtuDataAddr->FkComm_Value.F8_Set_Para.GPRS_MODE,Data,sizeof(RtuDataAddr->FkComm_Value.F8_Set_Para)-1);
		Save_CommSet();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(0,0,0x80,0);
		RtuDataAddr->SetChanged[8]=1;
		return sizeof(RtuDataAddr->FkComm_Value.F8_Set_Para)-1;
	}

	if(Set==0)//��ȡ���ñ���
	{
		if(RtuDataAddr->FkComm_Value.F8_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			memcpy(&SendBuff[SendLen],&RtuDataAddr->FkComm_Value.F8_Set_Para.GPRS_MODE,sizeof(RtuDataAddr->FkComm_Value.F8_Set_Para)-1);
			SendLen=SendLen+sizeof(RtuDataAddr->FkComm_Value.F8_Set_Para)-1;
		}
		return 4;
	}
	return 1;
}
INT8U GetF9(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			return sizeof(RtuDataAddr->Event_Value.F9_Set_Para)-1;
		}
		RtuDataAddr->Event_Value.F9_Set_Para.Valid=1;
		memcpy(&RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[0],Data,sizeof(RtuDataAddr->Event_Value.F9_Set_Para)-1);
		Save_Event_Set();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(0,0,0x01,1);
		RtuDataAddr->SetChanged[9]=1;
		return sizeof(RtuDataAddr->Event_Value.F9_Set_Para)-1;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			memcpy(&SendBuff[SendLen],&RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[0],sizeof(RtuDataAddr->Event_Value.F9_Set_Para)-1);
			SendLen=SendLen+sizeof(RtuDataAddr->Event_Value.F9_Set_Para)-1;
		}
		return 4;
	}
	return 1;
}
/////////////////////////////////////////////////////////////////////////////
INT8U GetF10(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	INT16U Num,NO,i,j,count;
	INT16U check_num,check_No;
	count=0;
	if(Set==1)//��վ��������
	{
		memcpy(&RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num,&Data[0],2);
		Num=RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num;
		if(Num>DD_Device_Max)
		{
			goto errorr;
		}
		RtuDataAddr->FkInput_Value.F10_Set_Para.Valid=1;
		j=2;
		for(i=0;i<Num;i++)
		{
			if(Data[j]>DD_Device_Max)goto errorr;
			memcpy(&NO,&Data[j],2);
			memcpy(&RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[NO-1].No,&Data[j],sizeof(RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[NO-1]));
			if(RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[NO-1].CeLiangNo>CeLiangPoint_Max)
			{
				goto errorr;
			}
			j=j+27;
		}
		j=0;
		for(i=0;i<DD_Device_Max;i++)
		{
			if((RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].CeLiangNo>=1)
			&&(RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].CeLiangNo<=DD_Device_Max))
			{
				j++;
			}
		}
		RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num = j;
		Save_Input_Set();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(0,0,2,1);
		RtuDataAddr->SetChanged[10]=1;
		return (RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num*27)+2;

errorr:
		RtuDataAddr->FkInput_Value.F10_Set_Para.Valid=0;
		SetDaDt(P,F);
		SendBuff[SendLen++]=1;
		return ((Num*27)+2);
	}
	if(Set==0)//��ȡ���ñ���
	{
		memcpy(&check_num,&Data[4],2);
		if((check_num>DD_Device_Max)||(check_num<1))
			check_num=DD_Device_Max;
		if(RtuDataAddr->FkInput_Value.F10_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			memcpy(&SendBuff[SendLen],&RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num,2);
			SendLen=SendLen+2;
			for(i=0;i<check_num;i++)
			{
				memcpy(&check_No,&Data[6+i*2],2);
				for(j=0;j<DD_Device_Max;j++)
				{
					if(check_No==(j+1))
					{
						if(RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[j].No==check_No)
						{
							memcpy(&SendBuff[SendLen],&RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[check_No-1].No,27);
							SendLen=SendLen+27;
							count++;
						}
						else
						{
							memset(&SendBuff[SendLen],0xEE,27);
							SendLen=SendLen+27;
							count++;
						}
					}
				}
			}
			if(count==0)
			{
				SendLen=SendLen-2;
				return 4+2*(check_num+1);
			}
			else
			  return (4+2*(count+1));
	  }
	  else
	  {
			return 4+2*(check_num+1) ;
	  }
	}
	return 1;
}

INT8U GetF11(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	INT8U Num,i,j,count;
	INT8U check_num,check_No;
	check_num = 0;
	check_No = 0;
	count=0;
    j=0;
	if(Set==1)//��վ��������
	{
		printf("\n\r Set F11 P=%d",P);
		RtuDataAddr->FkComm_Value.F11_Set_Para.Valid=0;
		Num=Data[0];
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			return (Num*5+1);
		}
		if(Num>MaiChong_Max)
		{
			goto errorr;
		}
		RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong_Num=Num;
		j=1;
		for(i=0;i<Num;i++)
		{
//			Print(DebugComm,"set P=%d ",P);
			memcpy(&RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong[i].InputNo,&Data[j],sizeof(RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong[i]));
			if(RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong[i].CeLiangNo>CeLiangPoint_Max)
			{
				goto errorr;
			}
			j=j+5;
		}
		RtuDataAddr->FkComm_Value.F11_Set_Para.Valid=1;
		Save_CommSet();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(0,0,4,1);
		RtuDataAddr->SetChanged[11]=1;
		return (RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong_Num*5)+1;
errorr:
//		Print(DebugComm,"err P=%d ",P);
		RtuDataAddr->FkComm_Value.F11_Set_Para.Valid=0;
		SetDaDt(P,F);
		SendBuff[SendLen++]=1;
		return (Num*5)+1;
	}
	if(Set==0)//��ȡ���ñ���
	{

		memcpy(&check_num,&Data[4],1);
		if((check_num>MaiChong_Max)||(check_num<1))
			check_num=MaiChong_Max;
		printf("\n\r Get F11  check num = %d",check_num);
		if(RtuDataAddr->FkComm_Value.F11_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
//			Print(DebugComm,"get P=%d ",P);
			SendBuff[SendLen++]=RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong_Num;
			//SendBuff[SendLen++]=check_num;
			for(i=0;i<check_num;i++)
			{
				check_No = 0;
				memcpy(&check_No,&Data[5+i],1);
				count++;
				for(j=0;j<MaiChong_Max;j++)
				{
					if(j==(check_No-1))
					{
						if(RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong[j].CeLiangNo!=0)
						{
							memcpy(&SendBuff[SendLen],&RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong[j].InputNo,5);
							SendLen=SendLen+5;
							//count++;
						}
						else
						{
							memset(&SendBuff[SendLen],0xEE,5);
							SendLen=SendLen+5;
							//count++;
						}
					}
				}
			}
			return (4+count+1);
		}
		else
		{
			return 4+(check_num+1);
		}

	}
	return 1;
}
INT8U GetF12(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			return sizeof(RtuDataAddr->FkInput_Value.F12_Set_Para)-1;
		}
		RtuDataAddr->FkInput_Value.F12_Set_Para.Valid=1;
		memcpy(&RtuDataAddr->FkInput_Value.F12_Set_Para.YxIn,Data,sizeof(RtuDataAddr->FkInput_Value.F12_Set_Para)-1);
		Save_Input_Set();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(0,0,8,1);
		RtuDataAddr->SetChanged[12]=1;
		return sizeof(RtuDataAddr->FkInput_Value.F12_Set_Para)-1;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->FkInput_Value.F12_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			memcpy(&SendBuff[SendLen],&RtuDataAddr->FkInput_Value.F12_Set_Para.YxIn,sizeof(RtuDataAddr->FkInput_Value.F12_Set_Para)-1);
			SendLen=SendLen+sizeof(RtuDataAddr->FkInput_Value.F12_Set_Para)-1;
		}
		return 4;
	}
	return 1;
}
INT8U GetF13(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			return ((Data[0]*3)+1);
		}
		RtuDataAddr->FkInput_Value.F13_Set_Para.Valid=0;
		SetDaDt(P,F);
		SendBuff[SendLen++]=1;
		CreateErr03(0,0,0x10,1);
		RtuDataAddr->SetChanged[13]=1;
		return ((Data[0]*3)+1);
	}
	if(Set==0)//��ȡ���ñ���
	{
		printf("\n\r in GetF13");
		return 4;
	}
	return 1;
}
INT8U GetF14(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	INT8U i,j,k,l,m,count,n;
	INT8U check_num,check_No;
	check_num = 0;
	check_No = 0;
	count=0;
	if(Set==1)//��վ��������
	{
		if(Data[0]>ZongJia_Max)goto e;
		RtuDataAddr->ZongJia_Value.F14_Set_Para.Valid=1;
		RtuDataAddr->ZongJia_Value.F14_Set_Para.Zongjia_Num=Data[0];
		k=1;
		for(i=0;i<RtuDataAddr->ZongJia_Value.F14_Set_Para.Zongjia_Num;i++)
		{
			m=Data[k];
			RtuDataAddr->ZongJia_Value.F14_Set_Para.Zj_set[m-1].ZjNo=Data[k++];
			RtuDataAddr->ZongJia_Value.F14_Set_Para.Zj_set[m-1].CeLiangNum=Data[k++];
			printf("\n\rRtuDataAddr->ZongJia_Value.F14_Set_Para.Zj_set[m-1].CeLiangNum==%d",RtuDataAddr->ZongJia_Value.F14_Set_Para.Zj_set[m-1].CeLiangNum);
			for(l=0;l<RtuDataAddr->ZongJia_Value.F14_Set_Para.Zj_set[m-1].CeLiangNum;l++)
			{
				RtuDataAddr->ZongJia_Value.F14_Set_Para.Zj_set[m-1].Stat[l]=Data[k++];
				printf("\n\rRtuDataAddr->ZongJia_Value.F14_Set_Para.Zj_set[m-1].Stat[%d]==%d",l,RtuDataAddr->ZongJia_Value.F14_Set_Para.Zj_set[m-1].Stat[l]);
				if((RtuDataAddr->ZongJia_Value.F14_Set_Para.Zj_set[m-1].Stat[l]&0x3f)>CeLiangPoint_Max)
				{
					RtuDataAddr->ZongJia_Value.F14_Set_Para.Valid=0;
					goto e;
				}
			}
		}
		l=0;
		for(i=0;i<ZongJia_Max;i++)
		{
			if((RtuDataAddr->ZongJia_Value.F14_Set_Para.Zj_set[i].ZjNo>0)&&(RtuDataAddr->ZongJia_Value.F14_Set_Para.Zj_set[i].ZjNo<=ZongJia_Max))
			{
				l++;
			}
		}
		RtuDataAddr->ZongJia_Value.F14_Set_Para.Zongjia_Num=l;
		Save_Zongjia_Set();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(0,0,0x20,1);
		RtuDataAddr->SetChanged[14]=1;
		return k;
e:
		k=1;
		for(i=0;i<Data[0];i++)
		{
			j=Data[k++];
			n=Data[k++];
			for(l=0;l<n;l++)
			{
				m=Data[k++];
			}
		}
		SetDaDt(P,F);
		SendBuff[SendLen++]=1;
		return k;
	}
	if(Set==0)//��ȡ���ñ���
	{
		memcpy(&check_num,&Data[4],1);
		if((check_num>ZongJia_Max)||(check_num<1))
			check_num=ZongJia_Max;
		if(RtuDataAddr->ZongJia_Value.F14_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			SendBuff[SendLen++]=RtuDataAddr->ZongJia_Value.F14_Set_Para.Zongjia_Num;
			//SendBuff[SendLen++]=check_num;
			for(i=0;i<check_num;i++)
			{
				check_No = 0;
				count++;
				printf("\n\rcountcountcount==%d",count);
				memcpy(&check_No,&Data[5+i],1);
				for(j=0;j<ZongJia_Max;j++)
				{
					if((j+1)==check_No)
					{
						if(RtuDataAddr->ZongJia_Value.F14_Set_Para.Zj_set[j].ZjNo==check_No)
						{
							SendBuff[SendLen++]=RtuDataAddr->ZongJia_Value.F14_Set_Para.Zj_set[j].ZjNo;
							SendBuff[SendLen++]=RtuDataAddr->ZongJia_Value.F14_Set_Para.Zj_set[j].CeLiangNum;
							for(l=0;l<RtuDataAddr->ZongJia_Value.F14_Set_Para.Zj_set[j].CeLiangNum;l++)
							{
								SendBuff[SendLen++]=RtuDataAddr->ZongJia_Value.F14_Set_Para.Zj_set[j].Stat[l];

							}
							//count++;
						}/*
						else
						{
							SendBuff[SendLen++]=(j+1);
							SendBuff[SendLen++]=0;
							//for(l=0;l<RtuDataAddr->ZongJia_Value.F14_Set_Para.Zj_set[j].CeLiangNum;l++)
							{
								SendBuff[SendLen++]=0xee;
							}
							//count++;
						}*/
					}

				}
			}
			return (4+count+1);
		}
		else
		{
			return 4+(check_num+1);
		}

	}
	return 1;
}

INT8U GetF15(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{//RtuDataAddr->Event_Value
	INT8U i,j,k,count;
	INT8U check_num,check_No;
	count=0;
	check_num = 0;
	check_No = 0;
	if(Set==1)//��վ��������
	{
		RtuDataAddr->Event_Value.F15_Set_Para.Valid=1;
		k=0;
		RtuDataAddr->Event_Value.F15_Set_Para.P_ALL_ChaDong_Num=Data[k++];
		if(RtuDataAddr->Event_Value.F15_Set_Para.P_ALL_ChaDong_Num>ChaDong_Zu_Mx)
		{
			RtuDataAddr->Event_Value.F15_Set_Para.Valid=0;
			goto e;
		}
		for(i=0;i<RtuDataAddr->Event_Value.F15_Set_Para.P_ALL_ChaDong_Num;i++)
		{
			memcpy(&RtuDataAddr->Event_Value.F15_Set_Para.P_All_set[i].P_All_Cd_GroupNo,&Data[k],sizeof(RtuDataAddr->Event_Value.F15_Set_Para.P_All_set[i]));
			k=k+sizeof(RtuDataAddr->Event_Value.F15_Set_Para.P_All_set[i]);
			if((RtuDataAddr->Event_Value.F15_Set_Para.P_All_set[i].CanZhao_No>ZongJia_Max)||(RtuDataAddr->Event_Value.F15_Set_Para.P_All_set[i].DuiBi_No>ZongJia_Max))
			{
				RtuDataAddr->Event_Value.F15_Set_Para.Valid=0;
				goto e;
			}
		}
		Save_Event_Set();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(0,0,0x40,1);
		RtuDataAddr->SetChanged[15]=1;
		return k;
e:
		SetDaDt(P,F);
		SendBuff[SendLen++]=1;
		CreateErr03(0,0,0x40,1);
		return (Data[0]*9)+1;
	}
	if(Set==0)//��ȡ���ñ���
	{
		memcpy(&check_num,&Data[4],1);
		if(RtuDataAddr->Event_Value.F15_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			SendBuff[SendLen++]=RtuDataAddr->Event_Value.F15_Set_Para.P_ALL_ChaDong_Num;

			for(i=0;i<check_num;i++)
			{
				check_No = 0;
				count++;
				memcpy(&check_No,&Data[5+i],1);
				for(j=0;j<ChaDong_Zu_Mx;j++)
				{
					if((j+1)==check_No)
					{
						if(RtuDataAddr->Event_Value.F15_Set_Para.P_All_set[j].P_All_Cd_GroupNo==check_No)
						{
							memcpy(&SendBuff[SendLen],&RtuDataAddr->Event_Value.F15_Set_Para.P_All_set[j].P_All_Cd_GroupNo,9);
							SendLen=SendLen+9;
							//count++;
						}
						else
						{
							memset(&SendBuff[SendLen],0xEE,9);
							SendLen=SendLen+9;
							//count++;
						}
					}
				}

			}
			return (4+count+1);
		}
		else
			return 4+(check_num+1);
	}
	return 1;
}

INT8U GetF16(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			return sizeof(RtuDataAddr->FkComm_Value.F16_Set_Para)-1;
		}
		RtuDataAddr->FkComm_Value.F16_Set_Para.Valid=1;
		memcpy(&RtuDataAddr->FkComm_Value.F16_Set_Para.User_Name[0],Data,sizeof(RtuDataAddr->FkComm_Value.F16_Set_Para)-1);
		Save_CommSet();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(0,0,0x80,1);
		RtuDataAddr->SetChanged[16]=1;
		return sizeof(RtuDataAddr->FkComm_Value.F16_Set_Para)-1;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->FkComm_Value.F16_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			memcpy(&SendBuff[SendLen],&RtuDataAddr->FkComm_Value.F16_Set_Para.User_Name[0],sizeof(RtuDataAddr->FkComm_Value.F16_Set_Para)-1);
			SendLen=SendLen+sizeof(RtuDataAddr->FkComm_Value.F16_Set_Para)-1;
		}
		return 4;
	}
	return 1;
}

INT8U GetF17(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{//Fk_Control_Set_Value
	if(Set==1)//��վ��������
	{
		printf("\n\r Set F17 P=%d",P);

		//if((RtuDataAddr->Fk_Control_Set_now.BaoDian_TiChu_Gaojing_Tou>>1)&0x01==0x01)
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			printf("\n\r return 2");
			return sizeof(RtuDataAddr->Fk_Control_Set_Value.F17_Set_Para)-1;
		}
		RtuDataAddr->Fk_Control_Set_Value.F17_Set_Para.Valid=1;
		memcpy(&RtuDataAddr->Fk_Control_Set_Value.F17_Set_Para.Bao_An_DingZhi[0],Data,sizeof(RtuDataAddr->Fk_Control_Set_Value.F17_Set_Para)-1);
		Save_Fk_Control_Set();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(0,0,1,2);
		RtuDataAddr->SetChanged[17]=1;
		return sizeof(RtuDataAddr->Fk_Control_Set_Value.F17_Set_Para)-1;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->Fk_Control_Set_Value.F17_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			memcpy(&SendBuff[SendLen],&RtuDataAddr->Fk_Control_Set_Value.F17_Set_Para.Bao_An_DingZhi[0],sizeof(RtuDataAddr->Fk_Control_Set_Value.F17_Set_Para)-1);
			SendLen=SendLen+sizeof(RtuDataAddr->Fk_Control_Set_Value.F17_Set_Para)-1;
		}
		return 4;
	}
	return 1;
}

INT8U GetF19(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		printf("\n\r Set F19 P=%d",P);
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			return sizeof(RtuDataAddr->Fk_Control_Set_Value.F19_Set_Para)-1;
		}
		RtuDataAddr->Fk_Control_Set_Value.F19_Set_Para.Valid=1;
		memcpy(&RtuDataAddr->Fk_Control_Set_Value.F19_Set_Para.ZD_GK_DZ_FDXS,Data,sizeof(RtuDataAddr->Fk_Control_Set_Value.F19_Set_Para)-1);
		//printf("\n\rRtuDataAddr->Fk_Control_Set_Value.F19_Set_Para.ZD_GK_DZ_FDXS==%d ",RtuDataAddr->Fk_Control_Set_Value.F19_Set_Para.ZD_GK_DZ_FDXS);
		//printf("\n\r");
		Save_Fk_Control_Set();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(0,0,4,2);
		RtuDataAddr->SetChanged[19]=1;
		return sizeof(RtuDataAddr->Fk_Control_Set_Value.F19_Set_Para)-1;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->Fk_Control_Set_Value.F19_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			memcpy(&SendBuff[SendLen],&RtuDataAddr->Fk_Control_Set_Value.F19_Set_Para.ZD_GK_DZ_FDXS,sizeof(RtuDataAddr->Fk_Control_Set_Value.F19_Set_Para)-1);
			SendLen=SendLen+sizeof(RtuDataAddr->Fk_Control_Set_Value.F19_Set_Para)-1;
		}
		return 4;
	}
	return 1;
}

INT8U GetF18(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			return sizeof(RtuDataAddr->Fk_Control_Set_Value.F18_Set_Para)-1;
		}
		RtuDataAddr->Fk_Control_Set_Value.F18_Set_Para.Valid=1;
		memcpy(&RtuDataAddr->Fk_Control_Set_Value.F18_Set_Para.ZD_GK_SD[0],&Data[0],sizeof(RtuDataAddr->Fk_Control_Set_Value.F18_Set_Para)-1);
		Save_Fk_Control_Set();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(0,0,2,2);
		RtuDataAddr->SetChanged[18]=1;
		return sizeof(RtuDataAddr->Fk_Control_Set_Value.F18_Set_Para)-1;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->Fk_Control_Set_Value.F18_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			memcpy(&SendBuff[SendLen],&RtuDataAddr->Fk_Control_Set_Value.F18_Set_Para.ZD_GK_SD[0],sizeof(RtuDataAddr->Fk_Control_Set_Value.F18_Set_Para)-1);
			SendLen=SendLen+sizeof(RtuDataAddr->Fk_Control_Set_Value.F18_Set_Para)-1;
		}
		return 4;
	}
	return 1;
}

INT8U GetF20(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			return sizeof(RtuDataAddr->Fk_Control_Set_Value.F20_Set_Para)-1;
		}
		RtuDataAddr->Fk_Control_Set_Value.F20_Set_Para.Valid=1;
		memcpy(&RtuDataAddr->Fk_Control_Set_Value.F20_Set_Para.ZD_Yue_DK_DZ_FD,Data,sizeof(RtuDataAddr->Fk_Control_Set_Value.F20_Set_Para)-1);
		Save_Fk_Control_Set();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(0,0,8,2);
		RtuDataAddr->SetChanged[20]=1;
		return sizeof(RtuDataAddr->Fk_Control_Set_Value.F20_Set_Para)-1;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->Fk_Control_Set_Value.F20_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			memcpy(&SendBuff[SendLen],&RtuDataAddr->Fk_Control_Set_Value.F20_Set_Para.ZD_Yue_DK_DZ_FD,sizeof(RtuDataAddr->Fk_Control_Set_Value.F20_Set_Para)-1);
			SendLen=SendLen+sizeof(RtuDataAddr->Fk_Control_Set_Value.F20_Set_Para)-1;
		}
		return 4;
	}
	return 1;
}

INT8U GetF21(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			return sizeof(RtuDataAddr->FkInput_Value.F21_Set_Para)-1;
		}
		RtuDataAddr->FkInput_Value.F21_Set_Para.Valid=1;
		memcpy(&RtuDataAddr->FkInput_Value.F21_Set_Para.ZDuan_Dn_FLv_sD[0],Data,sizeof(RtuDataAddr->FkInput_Value.F21_Set_Para)-1);
		Save_Input_Set();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(0,0,0x10,2);
		RtuDataAddr->SetChanged[21]=1;
		return sizeof(RtuDataAddr->FkInput_Value.F21_Set_Para)-1;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->FkInput_Value.F21_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			memcpy(&SendBuff[SendLen],&RtuDataAddr->FkInput_Value.F21_Set_Para.ZDuan_Dn_FLv_sD[0],sizeof(RtuDataAddr->FkInput_Value.F21_Set_Para)-1);
			SendLen=SendLen+sizeof(RtuDataAddr->FkInput_Value.F21_Set_Para)-1;
		}
		return 4;
	}
	return 1;
}

INT8U GetF22(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	int FLVn;
	if(Set==1)//��վ��������
	{
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			return sizeof(RtuDataAddr->FkInput_Value.F22_Set_Para)-1;
		}
		RtuDataAddr->FkInput_Value.F22_Set_Para.Valid=1;
		FLVn = Data[0];
		memcpy(&RtuDataAddr->FkInput_Value.F22_Set_Para.FeLv_Num,Data,FLVn*4+1);
		Save_Input_Set();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(0,0,0x20,2);
		RtuDataAddr->SetChanged[22]=1;
		return sizeof(RtuDataAddr->FkInput_Value.F22_Set_Para)-1;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->FkInput_Value.F22_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			FLVn = RtuDataAddr->FkInput_Value.F22_Set_Para.FeLv_Num;
			memcpy(&SendBuff[SendLen],&RtuDataAddr->FkInput_Value.F22_Set_Para.FeLv_Num,FLVn*4+1);
			SendLen=SendLen+sizeof(RtuDataAddr->FkInput_Value.F22_Set_Para)-1;
		}
		return 4;
	}
	return 1;
}

INT8U GetF23(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			return sizeof(RtuDataAddr->Fk_Control_Set_Value.F23_Set_Para)-1;
		}
		RtuDataAddr->Fk_Control_Set_Value.F23_Set_Para.Valid=1;
		memcpy(&RtuDataAddr->Fk_Control_Set_Value.F23_Set_Para.ZDuan_Dneng_cuif[0],Data,sizeof(RtuDataAddr->Fk_Control_Set_Value.F23_Set_Para)-1);
		Save_Fk_Control_Set();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(0,0,0x40,2);
		RtuDataAddr->SetChanged[23]=1;
		return sizeof(RtuDataAddr->Fk_Control_Set_Value.F23_Set_Para)-1;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->Fk_Control_Set_Value.F23_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			memcpy(&SendBuff[SendLen],&RtuDataAddr->Fk_Control_Set_Value.F23_Set_Para.ZDuan_Dneng_cuif[0],sizeof(RtuDataAddr->Fk_Control_Set_Value.F23_Set_Para)-1);
			SendLen=SendLen+sizeof(RtuDataAddr->Fk_Control_Set_Value.F23_Set_Para)-1;
		}
		return 4;
	}
	return 1;
}

INT8U GetF24(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{//  ȡ���ò�������
	if(Set==1)//��վ��������
	{
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			return sizeof(RtuDataAddr->Fk_Control_Set_Value.F24_Set_Para)-1;
		}
		RtuDataAddr->Fk_Control_Set_Value.F24_Set_Para.Valid=1;
		memcpy(&RtuDataAddr->Fk_Control_Set_Value.F24_Set_Para.Zhong_Duan_ChaoBiao_Jiange,Data,sizeof(RtuDataAddr->Fk_Control_Set_Value.F24_Set_Para)-1);
		Save_Fk_Control_Set();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(0,0,0x80,2);
		RtuDataAddr->SetChanged[24]=1;
		return sizeof(RtuDataAddr->Fk_Control_Set_Value.F24_Set_Para)-1;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->Fk_Control_Set_Value.F24_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			memcpy(&SendBuff[SendLen],&RtuDataAddr->Fk_Control_Set_Value.F24_Set_Para.Zhong_Duan_ChaoBiao_Jiange,sizeof(RtuDataAddr->Fk_Control_Set_Value.F24_Set_Para)-1);
			SendLen=SendLen+sizeof(RtuDataAddr->Fk_Control_Set_Value.F24_Set_Para)-1;
		}
		return 4;
	}
	return 1;
}

INT8U GetF25(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		if((P>CeLiangPoint_Max)||(RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1))
		{
			goto e;
		}

		RtuDataAddr->Cl_MenXian_Value[P-1].F25_Set_Para.Valid=1;
		memcpy(&RtuDataAddr->Cl_MenXian_Value[P-1].F25_Set_Para.V_BeiLv[0],Data,sizeof(RtuDataAddr->Cl_MenXian_Value[P-1].F25_Set_Para)-1);
		CeLiangChg=1;
//		Save_Cl_MenXian_Set();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(0,0,0x01,3);
		RtuDataAddr->SetChanged[25]=1;

		return sizeof(RtuDataAddr->Cl_MenXian_Value[P-1].F25_Set_Para)-1;
e:
		SetDaDt(P,F);
		SendBuff[SendLen++]=1;
		return sizeof(RtuDataAddr->Cl_MenXian_Value[0].F25_Set_Para)-1;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->Cl_MenXian_Value[P-1].F25_Set_Para.Valid==1)
		{
//		Print(DebugComm,"get P=%d ",P);
			SetDaDt(P,F);
			memcpy(&SendBuff[SendLen],&RtuDataAddr->Cl_MenXian_Value[P-1].F25_Set_Para.V_BeiLv[0],sizeof(RtuDataAddr->Cl_MenXian_Value[P-1].F25_Set_Para)-1);
			SendLen=SendLen+sizeof(RtuDataAddr->Cl_MenXian_Value[P-1].F25_Set_Para)-1;
		}
		return 4;
	}
	return 1;
}

INT8U GetF26(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		if((P>CeLiangPoint_Max)||(RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1))
		{
			goto e;
		}
		RtuDataAddr->Cl_MenXian_Value[P-1].F26_Set_Para.Valid=1;
		memcpy(&RtuDataAddr->Cl_MenXian_Value[P-1].F26_Set_Para.V_He_ge_S[0],Data,sizeof(RtuDataAddr->Cl_MenXian_Value[P-1].F26_Set_Para)-1);
		CeLiangChg=1;
//		Save_Cl_MenXian_Set();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(0,0,2,3);
		RtuDataAddr->SetChanged[26]=1;
		return sizeof(RtuDataAddr->Cl_MenXian_Value[P-1].F26_Set_Para)-1;
e:
		SetDaDt(P,F);
		SendBuff[SendLen++]=1;
		return sizeof(RtuDataAddr->Cl_MenXian_Value[0].F26_Set_Para)-1;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->Cl_MenXian_Value[P-1].F26_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			memcpy(&SendBuff[SendLen],&RtuDataAddr->Cl_MenXian_Value[P-1].F26_Set_Para.V_He_ge_S[0],sizeof(RtuDataAddr->Cl_MenXian_Value[P-1].F26_Set_Para)-1);
			SendLen=SendLen+sizeof(RtuDataAddr->Cl_MenXian_Value[P-1].F26_Set_Para)-1;
		}
		return 4;
	}
	return 1;
}

INT8U GetF27(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{//  ȡ���ò�������   ����ģ��������   F27 ���ܸ�Ϊ   �� ������ͭ������
	INT8U i,j,k;
	if(Set==1)//��վ��������
	{
		if((P>CeLiangPoint_Max)||(RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1))
		{
			goto e;
		}
		k=0;
		RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.Valid=1;
		RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJie_Num=Data[k++];
		for(i=0;i<RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJie_Num;i++)
		{
			RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.XinXiBiaoSHi[i]=Data[k++];
			RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]=Data[k++];
		}
		CeLiangChg=1;
//		Save_Cl_MenXian_Set();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(0,0,4,3);
		RtuDataAddr->SetChanged[27]=1;

		return k;
e:
		k=0;
		j=Data[k++];
		for(i=0;i<j;i++)
		{
			k++;
			k++;
		}
		SetDaDt(P,F);
		SendBuff[SendLen++]=1;
		return k;
	}
	if(Set==0)//��ȡ���ñ���
	{
		if(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			SendBuff[SendLen++]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJie_Num;
			for(i=0;i<RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJie_Num;i++)
			{
				SendBuff[SendLen++]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.XinXiBiaoSHi[i];
				SendBuff[SendLen++]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i];
			}
		}
		return 4;
	}
	return 1;
}
int BCDTo_INT32(unsigned char *S,unsigned char len)
{
	int i;
	int Result=0;
	//printf("\n\r$$$$$$$$$$$$$$$$$$$s=%d ",*S);
	for(i=len;i>0;i--)
	{
		if(i==len)
		{
			Result=(Result*10)+((S[i-1]>>4)&0x7);//����λȡ����λת��Ϊ��λ
			Result=(Result*10)+(S[i-1]&0xf);//����λת��Ϊ��λ+��λ
			//printf("\n\r++++++++++++++++Result=%d ",Result);
		}
		else
		{
			Result=(Result*10)+((S[i-1]>>4)&0xf);//����λת��Ϊ��λ
			Result=(Result*10)+(S[i-1]&0xf);//����λת��Ϊ����λ+����λ
		}
	}
	//printf("\n\r++++++++++++++++Result=%d ",Result);
	if(S[len-1]&0x80)//����Ǹ�ֵ��result����1000,0000����Ϊ1��Ϊ��ֵ��
	{
		return 0-Result;
	}
	return Result;

}

INT8U GetF28(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	unsigned char BCD[2];
	if(Set==1)//��վ��������
	{
		if((P>CeLiangPoint_Max)||(RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1))
		{
			goto e;
		}
		RtuDataAddr->Cl_MenXian_Value[P-1].F28_Set_Para.Valid=1;
		RtuDataAddr->Cl_MenXian_Value[P-1].F28_Set_Para.CosFenDuan_Xian1=BCDTo_INT32(Data,2);
		RtuDataAddr->Cl_MenXian_Value[P-1].F28_Set_Para.CosFenDuan_Xian2=BCDTo_INT32(&Data[2],2);
		printf("\n\rRtuDataAddr->Cl_MenXian_Value[%d].F28_Set_Para.CosFenDuan_Xian1==%d",P-1,RtuDataAddr->Cl_MenXian_Value[P-1].F28_Set_Para.CosFenDuan_Xian1);
		printf("\n\rRtuDataAddr->Cl_MenXian_Value[%d].F28_Set_Para.CosFenDuan_Xian2==%d",P-1,RtuDataAddr->Cl_MenXian_Value[P-1].F28_Set_Para.CosFenDuan_Xian2);

		printf("\n\r");
		CeLiangChg=1;
//		Save_Cl_MenXian_Set();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(0,0,8,3);
		RtuDataAddr->SetChanged[28]=1;
		return 4;
e:
		SetDaDt(P,F);
		SendBuff[SendLen++]=1;
		return sizeof(RtuDataAddr->Cl_MenXian_Value[0].F28_Set_Para)-1;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->Cl_MenXian_Value[P-1].F28_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			INT16_A5(RtuDataAddr->Cl_MenXian_Value[P-1].F28_Set_Para.CosFenDuan_Xian1,BCD);
			memcpy(&SendBuff[SendLen],BCD,2);
			SendLen=SendLen+2;
			INT16_A5(RtuDataAddr->Cl_MenXian_Value[P-1].F28_Set_Para.CosFenDuan_Xian2,BCD);
			memcpy(&SendBuff[SendLen],BCD,2);
			SendLen=SendLen+2;
		}
		return 4;
	}
	return 1;
}
INT8U GetF29(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{//
	INT8U i;
	if(Set==1)//��վ��������
	{
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
		{
			return  sizeof(F29_Set_Stru)-1;
		}
		RtuDataAddr->Fk_Control_Set_Value.F29_Set_Para[P-1].Valid=1;
		memcpy(&RtuDataAddr->Fk_Control_Set_Value.F29_Set_Para[P-1].JuBianHao[0],Data,sizeof(F29_Set_Stru)-1);
		Save_Fk_Control_Set();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(0,0,0x10,3);
		RtuDataAddr->SetChanged[29]=1;
		return sizeof(F29_Set_Stru)-1;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->Fk_Control_Set_Value.F29_Set_Para[P-1].Valid==1)
		{
			SetDaDt(P,F);
			printf("\n\r Point %d bianhao:%s",P-1,RtuDataAddr->Fk_Control_Set_Value.F29_Set_Para[P-1].JuBianHao);
			for(i=0;i<12;i++)
				SendBuff[SendLen++]=RtuDataAddr->Fk_Control_Set_Value.F29_Set_Para[P-1].JuBianHao[i];
			//memcpy(&SendBuff[SendLen],&RtuDataAddr->Fk_Control_Set_Value.F29_Set_Para[P-1].JuBianHao[0],(sizeof(F29_Set_Stru)-1));
			printf("\n\rsizeof(F29_Set_Stru)==%d SendBuff[SendLen]:%s",sizeof(F29_Set_Stru),&SendBuff[SendLen]);
			printf("\n\r");
			SendLen=(SendLen+sizeof(F29_Set_Stru)-1);
		}
		return 4;
	}
	if(Set==0)//��ȡ���ñ���
	{
		return 4;
	}
	return 1;
}
/*INT8U GetF30(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{//  ȡ���ò�������
	if(Set==1)//��վ��������
	{
		if(P>CeLiangPoint_Max)
		{
			goto e;
		}
		RtuDataAddr->Cl_MenXian_Value[P-1].F30_Set_Para.Valid=1;
		RtuDataAddr->Cl_MenXian_Value[P-1].F30_Set_Para.UnbalanceMen=Data[0];
		CeLiangChg=1;
//		Save_Cl_MenXian_Set();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(0,0,0x20,3);
		RtuDataAddr->SetChanged[30]=1;
		return sizeof(RtuDataAddr->Cl_MenXian_Value[P-1].F30_Set_Para)-1;
e:
		SetDaDt(P,F);
		SendBuff[SendLen++]=1;
		return sizeof(RtuDataAddr->Cl_MenXian_Value[0].F30_Set_Para)-1;
	}
	if(Set==0)//��ȡ���ñ���
	{
		if(RtuDataAddr->Cl_MenXian_Value[P-1].F30_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F30_Set_Para.UnbalanceMen;
			SendLen++;
		}
		return 4;
	}
	return 1;
}*/
INT8U GetNewF33(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	INT8U BlockNum,m;
	int i,j,k,index;
	int count=0;
	INT8U check_num,check_No;
	check_num = 0;
	check_No = 0;
	BlockNum = 0;m=0;index=0;
	if(Set==1)
	{
		RtuDataAddr->FkInput_Value.New_F33_Set_Para.Valid=1;
		BlockNum = Data[0];
		RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai_Num=BlockNum;
		index = 1;
		for(i=0;i<BlockNum;i++)
		{
			memcpy(&RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[i],&Data[index],14);
			/*printf("\n\r riqi  %x %x %x %x",RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[i].ChaoBiaoDay_RiQi[0],
					RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[i].ChaoBiaoDay_RiQi[1],
					RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[i].ChaoBiaoDay_RiQi[2],
					RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[i].ChaoBiaoDay_RiQi[3]);
			printf("\n\r");*/
			m = RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[i].YunXuChaoBiaoShiDuan_Num;
			for(j=0;j<m;j++)
			{
				memcpy(&RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[i].YunXuChaoBiaoShiDuan[j],&Data[index+14],4);
				index = index + 4;
			}
			index = index +14;
		}
		Save_Input_Set();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(0,0,0x01,4);
		RtuDataAddr->SetChanged[33]=1;
		return index;
	}
	if(Set==0)
	{
		memcpy(&check_num,&Data[4],1);
		if((check_num>31)||(check_num<1))
			check_num=31;
		if(RtuDataAddr->FkInput_Value.New_F33_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			SendBuff[SendLen++]=RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai_Num;

			for(i=0;i<check_num;i++)
			{
				check_No = 0;
				memcpy(&check_No,&Data[5+i],1);
				count++;
				for(k=0;k<31;k++)
				{
					//if((k+1)==check_No)
					{
						//printf("\n\rk+1===%d,check_No==%d",k+1,check_No);
						if(RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[k].PortNo==check_No)
						{
							memcpy(&SendBuff[SendLen],&RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[k],14);
							/*printf("\n\r get riq %x  %x  %x  %x  k=%d",RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[k].ChaoBiaoDay_RiQi[0],
									RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[k].ChaoBiaoDay_RiQi[1],
									RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[k].ChaoBiaoDay_RiQi[2],
									RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[k].ChaoBiaoDay_RiQi[3], k);
							printf("\n\r");*/
							SendLen=SendLen+14;
							m = RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[k].YunXuChaoBiaoShiDuan_Num;
							for(j=0;j<m;j++)
							{
								memcpy(&SendBuff[SendLen],&RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[k].YunXuChaoBiaoShiDuan[j],4);
								SendLen=SendLen+4;
							}
							//count++;
						}/*
						else
						{
							memset(&SendBuff[SendLen],0xee,14);
							SendLen=SendLen+14;
							//m = 0;
							//for(j=0;j<m;j++)
							{
								memset(&SendBuff[SendLen],0xee,4);
								SendLen=SendLen+4;
							}
							count++;
						}*/
					}
				}
			}
			printf("\n\rcount==%d",count);
			return (4+1+count);
		}
		else
			return (4+1+check_num);
	}
	return 1;
}
INT8U GetF33(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{//ȡ����F33
	if(Set==1)//��վ��������
	{
		if((P>ZongJia_Max)||(RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1))
		{
			goto e;
		}
		RtuDataAddr->ZongJia_Value.F33_Set_Para[P-1].Valid=1;
		memcpy(&RtuDataAddr->ZongJia_Value.F33_Set_Para[P-1].ZongJia_P_DongJie_Midu,Data,sizeof(RtuDataAddr->ZongJia_Value.F33_Set_Para[P-1])-1);
		ZongJiaSetChg=1;
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(0,0,1,4);
		RtuDataAddr->SetChanged[33]=1;
		return sizeof(RtuDataAddr->ZongJia_Value.F33_Set_Para[P-1])-1;
e:
		SetDaDt(P,F);
		SendBuff[SendLen++]=1;
		return sizeof(RtuDataAddr->ZongJia_Value.F33_Set_Para[0])-1;
	}
	if(Set==0)//��ȡ���ñ���
	{
		if(RtuDataAddr->ZongJia_Value.F33_Set_Para[P-1].Valid==1)
		{
			SetDaDt(P,F);
			memcpy(&SendBuff[SendLen],&RtuDataAddr->ZongJia_Value.F33_Set_Para[P-1].ZongJia_P_DongJie_Midu,sizeof(RtuDataAddr->ZongJia_Value.F33_Set_Para[P-1])-1);
			SendLen=SendLen+sizeof(RtuDataAddr->ZongJia_Value.F33_Set_Para[P-1])-1;
		}
		return 4;
	}
	return 1;
}
/*INT8U GetF34(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{//��Ч
	if(Set==1)//��վ��������
	{
		RtuDataAddr->FkInput_Value.F34_Set_Para.Valid=1;
		SetDaDt(P,F);
		SendBuff[SendLen++]=1;
		//		CreateErr03(0,0,0x10,1);
		RtuDataAddr->SetChanged[34]=1;
		return (Data[0]*3)+1;
	}
	if(Set==0)//��ȡ���ñ���
	{
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		return 4;
	}
	return 1;
}*/
INT8U GetF36(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		if (RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)
			return 4;
		RtuDataAddr->Fk_Control_Set_Value.F36_Set_Para.Valid=1;
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		memcpy(RtuDataAddr->Fk_Control_Set_Value.F36_Set_Para.Yue_LiuLiang_MenXian,Data,4);
		Save_Fk_Control_Set();
		CreateErr03(0,0,0x08,4);
		RtuDataAddr->SetChanged[36]=1;
		return (4);
	}
	if(Set==0)//��ȡ���ñ���
	{

		//if(RtuDataAddr->Fk_Control_Set_Value.F36_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			memcpy(&SendBuff[SendLen],&RtuDataAddr->Fk_Control_Set_Value.F36_Set_Para.Yue_LiuLiang_MenXian,4);
			SendLen=SendLen+4;
		}
		return 4;
	}
	return 1;
}
INT8U GetF38(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
		INT8U BigCNum,MinCNum,GroupNum,infoClassNum;
		int i,j,index,count,u;
		j=0;
		INT8U check_num,check_xiaoleihao,check_daleihao;
		check_num = 0;check_xiaoleihao=0; check_daleihao=0;index=0,count=0;u =0;
		BigCNum = 0;MinCNum=0;GroupNum = 0;infoClassNum=0;
		count=0;
		if(Set==1)
		{
			RtuDataAddr->FkInput_Value.F38_Set_Para.Valid=1;
			BigCNum = Data[0];
			GroupNum = Data[1];
			RtuDataAddr->FkInput_Value.F38_Set_Para.User_DaLeiHao = BigCNum;
			RtuDataAddr->FkInput_Value.F38_Set_Para.ZuShu = GroupNum;
			index = 2;
			for(i=0;i<GroupNum;i++)
			{
				MinCNum = Data[index];
				infoClassNum = Data[index+1];
				RtuDataAddr->FkInput_Value.F38_Set_Para.Set[i].User_XiaoLeiHao = MinCNum;
				RtuDataAddr->FkInput_Value.F38_Set_Para.Set[i].XinXiLei_ZuShu = infoClassNum;
				memcpy(&RtuDataAddr->FkInput_Value.F38_Set_Para.Set[i].XinXiLeiYuan_BiaoZhi,&Data[index+2],infoClassNum );
				index=index+infoClassNum+2;
			}
			Save_Input_Set();
			SetDaDt(P,F);
			SendBuff[SendLen++]=0;
			CreateErr03(0,0,0x20,4);
			RtuDataAddr->SetChanged[38]=1;
			return index;
		}
		if(Set==0)//��ȡ���ñ���
		{
			memcpy(&check_num,&Data[5],1);
			if(RtuDataAddr->FkInput_Value.F38_Set_Para.Valid==1)
			{

				memcpy(&check_daleihao,&Data[4],1);
				if(check_daleihao==RtuDataAddr->FkInput_Value.F38_Set_Para.User_DaLeiHao)
				{
					SetDaDt(P,F);
					SendBuff[SendLen++]=RtuDataAddr->FkInput_Value.F38_Set_Para.User_DaLeiHao;
					SendBuff[SendLen++]=RtuDataAddr->FkInput_Value.F38_Set_Para.ZuShu;

					for(i=0;i<check_num;i++)
					{
						count++;
						check_xiaoleihao = 0;
						//printf("\n\rget  i %d check_num %d",i,check_num);
						//printf("\n\rget zushu %d ",RtuDataAddr->FkInput_Value.F38_Set_Para.ZuShu);

						memcpy(&check_xiaoleihao,&Data[6+i],1);
						//printf("\n\rget check_xiaoLeiHao %d",check_xiaoleihao);
						for(j=0;j<RtuDataAddr->FkInput_Value.F38_Set_Para.ZuShu;j++)
						{
						//	printf("\n\rget User_XiaoLeiHao %d",RtuDataAddr->FkInput_Value.F38_Set_Para.Set[j].User_XiaoLeiHao);
							if(RtuDataAddr->FkInput_Value.F38_Set_Para.Set[j].User_XiaoLeiHao==check_xiaoleihao)
							{
								SendBuff[SendLen++]=RtuDataAddr->FkInput_Value.F38_Set_Para.Set[j].User_XiaoLeiHao;
								SendBuff[SendLen++]=RtuDataAddr->FkInput_Value.F38_Set_Para.Set[j].XinXiLei_ZuShu;
								infoClassNum=RtuDataAddr->FkInput_Value.F38_Set_Para.Set[j].XinXiLei_ZuShu;
								//printf("\n\rget infoClassNum %d",infoClassNum);
								memcpy(&SendBuff[SendLen],&RtuDataAddr->FkInput_Value.F38_Set_Para.Set[j].XinXiLeiYuan_BiaoZhi,infoClassNum );
								SendLen=SendLen+infoClassNum;
								//count++;
								break;
							}
						}
					}
					if(j==RtuDataAddr->FkInput_Value.F38_Set_Para.ZuShu)
					{
						SendBuff[SendLen++]=check_xiaoleihao;
						SendBuff[SendLen++]=0xee;
						infoClassNum=0xee;
						memset(&SendBuff[SendLen],0xee,infoClassNum );
						SendLen=SendLen+infoClassNum;
						count++;
					}
					return (4+2+count);
				}
				else
				{
					return (4+2+check_num);
				}
			}
			else
			{
				return (4+2+check_num);
			}
		}
		return 1;
}
INT8U GetF39(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	INT8U BigCNum,MinCNum,GroupNum,infoClassNum;
	int i,j=0,index;
	int count=0;
	INT8U check_num,check_xiaoleihao,check_daleihao;
	check_num = 0;check_xiaoleihao=0; check_daleihao=0;index=0,count=0;
	BigCNum = 0;MinCNum=0;GroupNum = 0;infoClassNum=0;
	if(Set==1)
	{
		RtuDataAddr->FkInput_Value.F39_Set_Para.Valid=1;
		BigCNum = Data[0];
		GroupNum = Data[1];
		RtuDataAddr->FkInput_Value.F39_Set_Para.User_DaLeiHao = BigCNum;
		RtuDataAddr->FkInput_Value.F39_Set_Para.ZuShu = GroupNum;
		index = 2;
		for(i=0;i<GroupNum;i++)
		{
			MinCNum = Data[index];
			infoClassNum = Data[index+1];
			RtuDataAddr->FkInput_Value.F39_Set_Para.Set[i].User_XiaoLeiHao = MinCNum;
			RtuDataAddr->FkInput_Value.F39_Set_Para.Set[i].XinXiLei_ZuShu = infoClassNum;
			memcpy(&RtuDataAddr->FkInput_Value.F39_Set_Para.Set[i].XinXiLeiYuan_BiaoZhi,&Data[index+2],infoClassNum );
			index=index+infoClassNum+2;
		}
		Save_Input_Set();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(0,0,0x40,4);
		RtuDataAddr->SetChanged[39]=1;
		return index;
	}
	if(Set==0)//��ȡ���ñ���
	{
		memcpy(&check_num,&Data[5],1);
		if(RtuDataAddr->FkInput_Value.F39_Set_Para.Valid==1)
		{
			memcpy(&check_daleihao,&Data[4],1);
			if(check_daleihao==RtuDataAddr->FkInput_Value.F39_Set_Para.User_DaLeiHao)
			{
				SetDaDt(P,F);
				SendBuff[SendLen++]=RtuDataAddr->FkInput_Value.F39_Set_Para.User_DaLeiHao;
				SendBuff[SendLen++]=RtuDataAddr->FkInput_Value.F39_Set_Para.ZuShu;
				for(i=0;i<check_num;i++)
				{
					check_xiaoleihao = 0;
					count++;
					memcpy(&check_xiaoleihao,&Data[6+i],1);
					for(j=0;j<RtuDataAddr->FkInput_Value.F39_Set_Para.ZuShu;j++)
					{
						if(RtuDataAddr->FkInput_Value.F39_Set_Para.Set[i].User_XiaoLeiHao==check_xiaoleihao)
						{
							SendBuff[SendLen++]=RtuDataAddr->FkInput_Value.F39_Set_Para.Set[i].User_XiaoLeiHao;
							SendBuff[SendLen++]=RtuDataAddr->FkInput_Value.F39_Set_Para.Set[i].XinXiLei_ZuShu;
							infoClassNum=RtuDataAddr->FkInput_Value.F39_Set_Para.Set[i].XinXiLei_ZuShu;
							memcpy(&SendBuff[SendLen],&RtuDataAddr->FkInput_Value.F39_Set_Para.Set[i].XinXiLeiYuan_BiaoZhi,infoClassNum );
							SendLen=SendLen+infoClassNum;
							//count++;
							break;
						}
					}
				}
				if(j==RtuDataAddr->FkInput_Value.F39_Set_Para.ZuShu)
				{
					SendBuff[SendLen++]=check_xiaoleihao;
					SendBuff[SendLen++]=0xee;
					infoClassNum=0xee;
					memset(&SendBuff[SendLen],0xee,infoClassNum );
					SendLen=SendLen+infoClassNum;
					count++;
				}
				return (4+2+count);
			}
			else
			{
				return (4+2+check_num);
			}
		}
		else
			return (4+2+check_num);
	}
	return 1;
}
INT8U GetF41(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	INT8U i,j,k,l;
	if(Set==1)//��վ��������
	{
		if(P>ZongJia_Max)
		{
			goto e;
		}
		k=0;
		RtuDataAddr->Zj_Control_Value[P-1].F41_Set_Para.Valid=1;
		RtuDataAddr->Zj_Control_Value[P-1].F41_Set_Para.Fang_An_Biaozhi=Data[k++];
		for(i=0;i<3;i++)
		{
			if((RtuDataAddr->Zj_Control_Value[P-1].F41_Set_Para.Fang_An_Biaozhi&(1<<i))==(1<<i))//fang an
			{
				RtuDataAddr->Zj_Control_Value[P-1].F41_Set_Para.ShiDuan_DingZhi[i].ShiDuanHao=Data[k++];
				for(j=0;j<8;j++)
				{
					if((RtuDataAddr->Zj_Control_Value[P-1].F41_Set_Para.ShiDuan_DingZhi[i].ShiDuanHao&(1<<j))==(1<<j))
					{
						RtuDataAddr->Zj_Control_Value[P-1].F41_Set_Para.ShiDuan_DingZhi[i].ShiDG_DingZhi[j][0]=Data[k++];
						RtuDataAddr->Zj_Control_Value[P-1].F41_Set_Para.ShiDuan_DingZhi[i].ShiDG_DingZhi[j][1]=Data[k++];
					}
				}
			}
		}
		ZongJiaChg=1;
//		Save_Zj_Control_Set();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(SetDa1(P),SetDa2(P),1,5);
		RtuDataAddr->SetChanged[41]=1;
		return k;
e:
		k=0;
		j=Data[k++];
		for(i=0;i<3;i++)
		{
			if((j&(1<<i))==(1<<i))//fang an
			{
				l=Data[k++];
				for(j=0;j<8;j++)
				{
					if((l&(1<<j))==(1<<j))
					{
						k++;
						k++;
					}
				}
			}
		}
		SetDaDt(P,F);
		SendBuff[SendLen++]=1;
		return k;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->Zj_Control_Value[P-1].F41_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			SendBuff[SendLen++]=RtuDataAddr->Zj_Control_Value[P-1].F41_Set_Para.Fang_An_Biaozhi;
			for(i=0;i<3;i++)
			{
				if((RtuDataAddr->Zj_Control_Value[P-1].F41_Set_Para.Fang_An_Biaozhi&(1<<i))==(1<<i))//fang an
				{
					SendBuff[SendLen++]=RtuDataAddr->Zj_Control_Value[P-1].F41_Set_Para.ShiDuan_DingZhi[i].ShiDuanHao;
					for(j=0;j<8;j++)
					{
						if((RtuDataAddr->Zj_Control_Value[P-1].F41_Set_Para.ShiDuan_DingZhi[i].ShiDuanHao&(1<<j))==(1<<j))
						{
							SendBuff[SendLen++]=RtuDataAddr->Zj_Control_Value[P-1].F41_Set_Para.ShiDuan_DingZhi[i].ShiDG_DingZhi[j][0];
							SendBuff[SendLen++]=RtuDataAddr->Zj_Control_Value[P-1].F41_Set_Para.ShiDuan_DingZhi[i].ShiDG_DingZhi[j][1];
						}
					}
				}
			}
		}
		return 4;
	}
	return 1;
}

INT8U GetF42(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		if(P>ZongJia_Max)
		{
			goto e;
		}
		RtuDataAddr->Zj_Control_Value[P-1].F42_Set_Para.Valid=1;
		memcpy(&RtuDataAddr->Zj_Control_Value[P-1].F42_Set_Para.ChangXiu_DingZhi[0],Data,sizeof(RtuDataAddr->Zj_Control_Value[P-1].F42_Set_Para)-1);
		ZongJiaChg=1;
//		Save_Zj_Control_Set();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(SetDa1(P),SetDa2(P),2,5);
		RtuDataAddr->SetChanged[42]=1;
		return sizeof(RtuDataAddr->Zj_Control_Value[P-1].F42_Set_Para)-1;
e:
		SetDaDt(P,F);
		SendBuff[SendLen++]=1;
		return sizeof(RtuDataAddr->Zj_Control_Value[0].F42_Set_Para)-1;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->Zj_Control_Value[P-1].F42_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			memcpy(&SendBuff[SendLen],&RtuDataAddr->Zj_Control_Value[P-1].F42_Set_Para.ChangXiu_DingZhi[0],sizeof(RtuDataAddr->Zj_Control_Value[P-1].F42_Set_Para)-1);
			SendLen=SendLen+sizeof(RtuDataAddr->Zj_Control_Value[P-1].F42_Set_Para)-1;
		}
		return 4;
	}
	return 1;
}

INT8U GetF43(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		if(P>ZongJia_Max)
		{
			goto e;
		}
		RtuDataAddr->Zj_Control_Value[P-1].F43_Set_Para.Valid=1;
		memcpy(&RtuDataAddr->Zj_Control_Value[P-1].F43_Set_Para.DongLv_HuaCha_Time,Data,sizeof(RtuDataAddr->Zj_Control_Value[P-1].F43_Set_Para)-1);
		ZongJiaChg=1;
//		Save_Zj_Control_Set();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(SetDa1(P),SetDa2(P),4,5);
		RtuDataAddr->SetChanged[43]=1;
		return sizeof(RtuDataAddr->Zj_Control_Value[P-1].F43_Set_Para)-1;
e:
		SetDaDt(P,F);
		SendBuff[SendLen++]=1;
		return sizeof(RtuDataAddr->Zj_Control_Value[0].F43_Set_Para)-1;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->Zj_Control_Value[P-1].F43_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			memcpy(&SendBuff[SendLen],&RtuDataAddr->Zj_Control_Value[P-1].F43_Set_Para.DongLv_HuaCha_Time,sizeof(RtuDataAddr->Zj_Control_Value[P-1].F43_Set_Para)-1);
			SendLen=SendLen+sizeof(RtuDataAddr->Zj_Control_Value[P-1].F43_Set_Para)-1;
		}
		return 4;
	}
	return 1;
}

INT8U GetF44(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		if(P>ZongJia_Max)
		{
			goto e;
		}
		RtuDataAddr->Zj_Control_Value[P-1].F44_Set_Para.Valid=1;
		memcpy(&RtuDataAddr->Zj_Control_Value[P-1].F44_Set_Para.BaoTing_Start[0],Data,sizeof(RtuDataAddr->Zj_Control_Value[P-1].F44_Set_Para)-1);
		ZongJiaChg=1;
//		Save_Zj_Control_Set();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(SetDa1(P),SetDa2(P),8,5);
		RtuDataAddr->SetChanged[44]=1;
		return sizeof(RtuDataAddr->Zj_Control_Value[P-1].F44_Set_Para)-1;
e:
		SetDaDt(P,F);
		SendBuff[SendLen++]=1;
		return sizeof(RtuDataAddr->Zj_Control_Value[0].F44_Set_Para)-1;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->Zj_Control_Value[P-1].F44_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			memcpy(&SendBuff[SendLen],&RtuDataAddr->Zj_Control_Value[P-1].F44_Set_Para.BaoTing_Start[0],sizeof(RtuDataAddr->Zj_Control_Value[P-1].F44_Set_Para)-1);
			SendLen=SendLen+sizeof(RtuDataAddr->Zj_Control_Value[P-1].F44_Set_Para)-1;
		}
		return 4;
	}
	return 1;
}

INT8U GetF45(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		if(P>ZongJia_Max)
		{
			goto e;
		}
		RtuDataAddr->Zj_Control_Value[P-1].F45_Set_Para.Valid=1;
		memcpy(&RtuDataAddr->Zj_Control_Value[P-1].F45_Set_Para.GongKong_Lunci_Biaozhi,Data,sizeof(RtuDataAddr->Zj_Control_Value[P-1].F45_Set_Para)-1);
		if(RtuDataAddr->Zj_Control_Value[P-1].F45_Set_Para.GongKong_Lunci_Biaozhi==0)
		{
			RtuDataAddr->Zj_Control_Value[P-1].F45_Set_Para.Valid=0;
		}
		ZongJiaChg=1;
//		Save_Zj_Control_Set();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(SetDa1(P),SetDa2(P),0x10,5);
		RtuDataAddr->SetChanged[45]=1;
		return sizeof(RtuDataAddr->Zj_Control_Value[P-1].F45_Set_Para)-1;
e:
		SetDaDt(P,F);
		SendBuff[SendLen++]=1;
		return sizeof(RtuDataAddr->Zj_Control_Value[0].F45_Set_Para)-1;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->Zj_Control_Value[P-1].F45_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			memcpy(&SendBuff[SendLen],&RtuDataAddr->Zj_Control_Value[P-1].F45_Set_Para.GongKong_Lunci_Biaozhi,sizeof(RtuDataAddr->Zj_Control_Value[P-1].F45_Set_Para)-1);
			SendLen=SendLen+sizeof(RtuDataAddr->Zj_Control_Value[P-1].F45_Set_Para)-1;
		}
		return 4;
	}
	return 1;
}

INT8U GetF46(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		if(P>ZongJia_Max)
		{
			goto e;
		}
		RtuDataAddr->Zj_Control_Value[P-1].F46_Set_Para.Valid=1;
		memcpy(&RtuDataAddr->Zj_Control_Value[P-1].F46_Set_Para.Yue_DIan_Liang_Kong[0],Data,sizeof(RtuDataAddr->Zj_Control_Value[P-1].F46_Set_Para)-1);
		ZongJiaChg=1;
//		Save_Zj_Control_Set();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(SetDa1(P),SetDa2(P),0x20,5);
		RtuDataAddr->SetChanged[46]=1;
		return sizeof(RtuDataAddr->Zj_Control_Value[P-1].F46_Set_Para)-1;
e:
		SetDaDt(P,F);
		SendBuff[SendLen++]=1;
		return sizeof(RtuDataAddr->Zj_Control_Value[0].F46_Set_Para)-1;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->Zj_Control_Value[P-1].F46_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			memcpy(&SendBuff[SendLen],&RtuDataAddr->Zj_Control_Value[P-1].F46_Set_Para.Yue_DIan_Liang_Kong[0],sizeof(RtuDataAddr->Zj_Control_Value[P-1].F46_Set_Para)-1);
			SendLen=SendLen+sizeof(RtuDataAddr->Zj_Control_Value[P-1].F46_Set_Para)-1;
		}
		return 4;
	}
	return 1;
}

INT8U GetF47(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
  	//long t1,t2,t3;
	unsigned char DanHaoTmp[4];
	if(Set==1)//��վ��������
	{
		if(P>ZongJia_Max)
		{
			goto e;
		}
		RtuDataAddr->Zj_Control_Value[P-1].F47_Set_Para.Valid=1;
		memcpy(DanHaoTmp,RtuDataAddr->Zj_Control_Value[P-1].F47_Set_Para.Gou_DIan_DanHao ,4);
		memcpy(&RtuDataAddr->Zj_Control_Value[P-1].F47_Set_Para.Gou_DIan_DanHao[0],Data,sizeof(RtuDataAddr->Zj_Control_Value[P-1].F47_Set_Para)-1);
		/*if(RtuDataAddr->Real_Zj_Value[P-1].ShengYuDianLiang<0)
		{
			RtuDataAddr->Real_Zj_Value[P-1].ShengYuDianLiang=0;
		}*/
		Create_Data_Type03(RtuDataAddr->Real_Zj_Value[P-1].ShengYuDianLiang,RtuDataAddr->Zj_Control_Value[P-1].Old_DianLiang );

		if (memcmp(DanHaoTmp,RtuDataAddr->Zj_Control_Value[P-1].F47_Set_Para.Gou_DIan_DanHao,4)!=0)
		{
			if(RtuDataAddr->Zj_Control_Value[P-1].F47_Set_Para.zhuijia_Shuaxin==0x55)
			{
				RtuDataAddr->Real_Zj_Value[P-1].ShengYuDianLiang=RtuDataAddr->Real_Zj_Value[P-1].ShengYuDianLiang+GetdataType03(RtuDataAddr->Zj_Control_Value[P-1].F47_Set_Para.Gou_DIan_Value);
			}
		}
		if(	RtuDataAddr->Zj_Control_Value[P-1].F47_Set_Para.zhuijia_Shuaxin==0xaa)
		{
			RtuDataAddr->Real_Zj_Value[P-1].ShengYuDianLiang=GetdataType03(RtuDataAddr->Zj_Control_Value[P-1].F47_Set_Para.Gou_DIan_Value);
		}
		RtuDataAddr->Zj_Control_Value[P-1].F47_Set_Para.zhuijia_Shuaxin=0xaa;
		ZongJiaChg=1;
		Create_Data_Type03(RtuDataAddr->Real_Zj_Value[P-1].ShengYuDianLiang,RtuDataAddr->Zj_Control_Value[P-1].New_DianLiang );
		SaveGouDianEve(P,RtuDataAddr->Zj_Control_Value[P-1].F47_Set_Para,GetdataType03(RtuDataAddr->Zj_Control_Value[P-1].Old_DianLiang));
		Save_Zj_Control_Set();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(SetDa1(P),SetDa2(P),0x40,5);
		RtuDataAddr->SetChanged[47]=1;
		return sizeof(RtuDataAddr->Zj_Control_Value[P-1].F47_Set_Para)-1;
e:
		SetDaDt(P,F);
		SendBuff[SendLen++]=1;
		return sizeof(RtuDataAddr->Zj_Control_Value[0].F47_Set_Para)-1;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->Zj_Control_Value[P-1].F47_Set_Para.Valid==1)//�˴��������ε�����γ��վ���й�����·�ʱ�����в�F23��F47���вⲻ�ɹ����·����ɹ���
		{
			SetDaDt(P,F);
			memcpy(&SendBuff[SendLen],&RtuDataAddr->Zj_Control_Value[P-1].F47_Set_Para.Gou_DIan_DanHao[0],sizeof(RtuDataAddr->Zj_Control_Value[P-1].F47_Set_Para)-1);
			SendLen=SendLen+sizeof(RtuDataAddr->Zj_Control_Value[P-1].F47_Set_Para)-1;
		}
		return 4;
	}
	return 1;
}
INT8U GetF48(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		if(P>ZongJia_Max)
		{
			goto e;
		}
//		Zj_Control_Value[P-1].F47_Set_Para.Valid=1;

		RtuDataAddr->Zj_Control_Value[P-1].F48_Set_Para.Valid=1;
		//printf("\n\r Valid==%d zjno==%d",RtuDataAddr->Zj_Control_Value[P-1].F48_Set_Para.Valid,P-1);
		memcpy(&RtuDataAddr->Zj_Control_Value[P-1].F48_Set_Para.DianKong_Lunci_Biaozhi,Data,sizeof(RtuDataAddr->Zj_Control_Value[P-1].F48_Set_Para)-1);
		if(RtuDataAddr->Zj_Control_Value[P-1].F48_Set_Para.DianKong_Lunci_Biaozhi==0)
			RtuDataAddr->Zj_Control_Value[P-1].F48_Set_Para.Valid=0;
		//printf("\n\r $$$$$Valid==%d zjno==%d",RtuDataAddr->Zj_Control_Value[P-1].F48_Set_Para.Valid,P-1);
		ZongJiaChg=1;
//		Save_Zj_Control_Set();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(SetDa1(P),SetDa2(P),0x80,5);
		RtuDataAddr->SetChanged[48]=1;
		return sizeof(RtuDataAddr->Zj_Control_Value[P-1].F48_Set_Para)-1;
e:
		SetDaDt(P,F);
		SendBuff[SendLen++]=1;
		return sizeof(RtuDataAddr->Zj_Control_Value[0].F48_Set_Para)-1;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->Zj_Control_Value[P-1].F48_Set_Para.Valid==1)
		{
			//printf("\n\r 6666666");
			SetDaDt(P,F);
			memcpy(&SendBuff[SendLen],&RtuDataAddr->Zj_Control_Value[P-1].F48_Set_Para.DianKong_Lunci_Biaozhi,sizeof(RtuDataAddr->Zj_Control_Value[P-1].F48_Set_Para)-1);
			SendLen=SendLen+sizeof(RtuDataAddr->Zj_Control_Value[P-1].F48_Set_Para)-1;
		}
		return 4;
	}
	return 1;
}

INT8U GetF49(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		//printf("\n\r Set F49 P=%d",P);
		if(P>ZongJia_Max)
		{
			goto e;
		}
		RtuDataAddr->Fk_Control_Set_Value.F49_Set_Para[P-1].Valid=1;
		memcpy(&RtuDataAddr->Fk_Control_Set_Value.F49_Set_Para[P-1].GK_Alarm_Time,Data,sizeof(RtuDataAddr->Fk_Control_Set_Value.F49_Set_Para[P-1])-1);
		ControlChg=1;
		//Save_Fk_Control_Set();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(0,0,1,6);
		RtuDataAddr->SetChanged[49]=1;
		return sizeof(RtuDataAddr->Fk_Control_Set_Value.F49_Set_Para[P-1])-1;
e:
		SetDaDt(P,F);
		SendBuff[SendLen++]=1;
		return sizeof(RtuDataAddr->Fk_Control_Set_Value.F49_Set_Para[0])-1;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->Fk_Control_Set_Value.F49_Set_Para[P-1].Valid==1)
		{
			SetDaDt(P,F);
			if ((P>=1)&&(P<=4))
			{
				memcpy(&SendBuff[SendLen],&RtuDataAddr->Fk_Control_Set_Value.F49_Set_Para[P-1].GK_Alarm_Time,sizeof(RtuDataAddr->Fk_Control_Set_Value.F49_Set_Para[P-1])-1);
				SendLen=SendLen+sizeof(RtuDataAddr->Fk_Control_Set_Value.F49_Set_Para[P-1])-1;
			}else
			{
				memset(&SendBuff[SendLen],0x00,1);
				SendLen=SendLen + 1;
			}
		}
		return 4;
	}
	return 1;
}

INT8U GetF57(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		RtuDataAddr->Fk_Control_Set_Value.F57_Set_Para.Valid=1;
		memcpy(&RtuDataAddr->Fk_Control_Set_Value.F57_Set_Para.ZD_Voice_Enable,Data,sizeof(RtuDataAddr->Fk_Control_Set_Value.F57_Set_Para)-1);
		Save_Fk_Control_Set();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(0,0,1,7);
		RtuDataAddr->SetChanged[57]=1;
		return sizeof(RtuDataAddr->Fk_Control_Set_Value.F57_Set_Para)-1;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->Fk_Control_Set_Value.F57_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			memcpy(&SendBuff[SendLen],&RtuDataAddr->Fk_Control_Set_Value.F57_Set_Para.ZD_Voice_Enable,sizeof(RtuDataAddr->Fk_Control_Set_Value.F57_Set_Para)-1);
			SendLen=SendLen+sizeof(RtuDataAddr->Fk_Control_Set_Value.F57_Set_Para)-1;
		}
		return 4;
	}
	return 1;
}

INT8U GetF58(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		RtuDataAddr->Fk_Control_Set_Value.F58_Set_Para.Valid=1;
		memcpy(&RtuDataAddr->Fk_Control_Set_Value.F58_Set_Para.ZDuan_Auto_BaoDian,Data,sizeof(RtuDataAddr->Fk_Control_Set_Value.F58_Set_Para)-1);
		Save_Fk_Control_Set();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(0,0,2,7);
		RtuDataAddr->SetChanged[58]=1;
		return sizeof(RtuDataAddr->Fk_Control_Set_Value.F58_Set_Para)-1;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->Fk_Control_Set_Value.F58_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			memcpy(&SendBuff[SendLen],&RtuDataAddr->Fk_Control_Set_Value.F58_Set_Para.ZDuan_Auto_BaoDian,sizeof(RtuDataAddr->Fk_Control_Set_Value.F58_Set_Para)-1);
			SendLen=SendLen+sizeof(RtuDataAddr->Fk_Control_Set_Value.F58_Set_Para)-1;
		}
		return 4;
	}
	return 1;
}

INT8U GetF59(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		RtuDataAddr->Event_Value.F59_Set_Para.Valid=1;
		memcpy(&RtuDataAddr->Event_Value.F59_Set_Para.DD_ChaoCha_Men,&Data[0],sizeof(RtuDataAddr->Event_Value.F59_Set_Para));
		Save_Event_Set();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(0,0,4,7);
		RtuDataAddr->SetChanged[59]=1;
		return 4;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->Event_Value.F59_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			memcpy(&SendBuff[SendLen],&RtuDataAddr->Event_Value.F59_Set_Para.DD_ChaoCha_Men,sizeof(RtuDataAddr->Event_Value.F59_Set_Para)-1);
			SendLen=SendLen+sizeof(RtuDataAddr->Event_Value.F59_Set_Para)-1;
		}
		return 4;
	}
	return 1;
}

INT8U GetF60(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	//INT8U i;
	if(Set==1)//��վ��������
	{
		/*RtuDataAddr->FkInput_Value.F60_Set_Para.Valid=1;
		memcpy(&RtuDataAddr->FkInput_Value.F60_Set_Para.All_QiBian_DYaHy_S,&Data[0],6);
		for(i=2;i<20;i+=2)
		{
			memcpy(&RtuDataAddr->FkInput_Value.F60_Set_Para.XIeBo_DYXieBoLv_S[i],&Data[6],2);
		}
		for(i=3;i<20;i+=2)
		{
			memcpy(&RtuDataAddr->FkInput_Value.F60_Set_Para.XIeBo_DYXieBoLv_S[i],&Data[24],2);
		}
		memcpy(&RtuDataAddr->FkInput_Value.F60_Set_Para.All_QiBian_DLiu_YX_S,&Data[42],2);
		for(i=2;i<20;i+=2)
		{
			memcpy(&RtuDataAddr->FkInput_Value.F60_Set_Para.XIeBo_DL_YX_S[i],&Data[44],2);
		}
		for(i=3;i<20;i+=2)
		{
			memcpy(&RtuDataAddr->FkInput_Value.F60_Set_Para.XIeBo_DL_YX_S[i],&Data[62],2);
		}
		Save_Input_Set();
		SetDaDt(P,F);
		CreateErr03(0,0,8,7);
		RtuDataAddr->SetChanged[60]=1;*/
		SendBuff[SendLen++]=1;
		return 80;
	}
	if(Set==0)//��ȡ���ñ���
	{
	/*		SetDaDt(P,F);
	memset(&SendBuff[SendLen],0,44);
	SendLen=SendLen+44;
		*/
		/*if(RtuDataAddr->FkInput_Value.F60_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			memcpy(&SendBuff[SendLen],&RtuDataAddr->FkInput_Value.F60_Set_Para.All_QiBian_DYaHy_S,6);
			SendLen=SendLen+6;
			for(i=2;i<20;i+=2)
			{
				memcpy(&SendBuff[SendLen],&RtuDataAddr->FkInput_Value.F60_Set_Para.XIeBo_DYXieBoLv_S[i],2);
				SendLen=SendLen+2;
			}
			for(i=3;i<20;i+=2)
			{
				memcpy(&SendBuff[SendLen],&RtuDataAddr->FkInput_Value.F60_Set_Para.XIeBo_DYXieBoLv_S[i],2);
				SendLen=SendLen+2;
			}
			memcpy(&SendBuff[SendLen],&RtuDataAddr->FkInput_Value.F60_Set_Para.All_QiBian_DLiu_YX_S,2);
				SendLen=SendLen+2;
			for(i=2;i<20;i+=2)
			{
				memcpy(&SendBuff[SendLen],&RtuDataAddr->FkInput_Value.F60_Set_Para.XIeBo_DL_YX_S[i],2);
				SendLen=SendLen+2;
			}
			for(i=3;i<20;i+=2)
			{
				memcpy(&SendBuff[SendLen],&RtuDataAddr->FkInput_Value.F60_Set_Para.XIeBo_DL_YX_S[i],2);
				SendLen=SendLen+2;
			}
		}*/
	return 4;
	}
	return 1;
}

INT8U GetF61(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		SetDaDt(P,F);
		SendBuff[SendLen++]=1;
		RtuDataAddr->SetChanged[61]=1;
		//		CreateErr03(0,0,0x10,7);
		return 1;
	}
	if(Set==0)//��ȡ���ñ���
	{
	/*		SetDaDt(P,F);
		*/		return 4;
	}
	return 1;
}

/*INT8U GetF62(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		RtuDataAddr->FkComm_Value.F62_Set_Para.Valid=1;
		memcpy(&RtuDataAddr->FkComm_Value.F62_Set_Para.GPRS_MODE,Data,sizeof(RtuDataAddr->FkComm_Value.F62_Set_Para)-1);
		Save_CommSet();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(0,0,0x20,7);
		RtuDataAddr->SetChanged[62]=1;
		return sizeof(RtuDataAddr->FkComm_Value.F62_Set_Para)-1;
	}
	if(Set==0)//��ȡ���ñ���
	{
		if(RtuDataAddr->FkComm_Value.F62_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			memcpy(&SendBuff[SendLen],&RtuDataAddr->FkComm_Value.F62_Set_Para.GPRS_MODE,sizeof(RtuDataAddr->FkComm_Value.F62_Set_Para)-1);
			SendLen=SendLen+sizeof(RtuDataAddr->FkComm_Value.F62_Set_Para)-1;
		}
		return 4;
	}
	return 1;
}
*/
INT8U GetF63(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		RtuDataAddr->FkComm_Value.F63_Set_Para.Valid=1;
		memcpy(&RtuDataAddr->FkComm_Value.F63_Set_Para.LiuLiang,Data,sizeof(RtuDataAddr->FkComm_Value.F63_Set_Para)-1);
		Save_CommSet();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(0,0,0x40,7);
		RtuDataAddr->SetChanged[63]=1;
		return sizeof(RtuDataAddr->FkComm_Value.F63_Set_Para)-1;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->FkComm_Value.F63_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			memcpy(&SendBuff[SendLen],&RtuDataAddr->FkComm_Value.F63_Set_Para.LiuLiang,sizeof(RtuDataAddr->FkComm_Value.F63_Set_Para)-1);
			SendLen=SendLen+sizeof(RtuDataAddr->FkComm_Value.F63_Set_Para)-1;
		}
		return 4;
	}
	return 1;
}

INT8U GetF65(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	INT8U i,j,k;
	if(Set==1)//��վ��������
	{
		if((P>Task_Max)||(RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1))
		{
			goto e;
		}
		k=0;
		RtuDataAddr->Task_Value[P-1].F65_Set_Para.Valid=1;
		RtuDataAddr->Task_Value[P-1].F65_Set_Para.FaSong_ZhouQi=Data[k++];
		memcpy(&RtuDataAddr->Task_Value[P-1].F65_Set_Para.Ji_Zhun_Shi_Jian[0],&Data[k],sizeof(RtuDataAddr->Task_Value[P-1].F65_Set_Para.Ji_Zhun_Shi_Jian));
		k=k+sizeof(RtuDataAddr->Task_Value[P-1].F65_Set_Para.Ji_Zhun_Shi_Jian);
		RtuDataAddr->Task_Value[P-1].F65_Set_Para.Qu_Xian_ChouQu_BeiLv=Data[k++];
		RtuDataAddr->Task_Value[P-1].F65_Set_Para.ShuJv_DanYuan_Num=Data[k++];
		for(i=0;i<RtuDataAddr->Task_Value[P-1].F65_Set_Para.ShuJv_DanYuan_Num;i++)
		{
			memcpy(&RtuDataAddr->Task_Value[P-1].F65_Set_Para.DanYuan_BiaoShi[i][0],&Data[k],4);
			k=k+4;
		}
		TaskChg=1;
//		Save_Task_Set();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(SetDa1(P),SetDa2(P),1,8);
		RtuDataAddr->SetChanged[65]=1;
		return k;
e:
		k=0;
		k++;
		k=k+sizeof(RtuDataAddr->Task_Value[0].F65_Set_Para.Ji_Zhun_Shi_Jian);
		k++;
		j=Data[k++];
		for(i=0;i<j;i++)
		{
			k=k+4;
		}
		SetDaDt(P,F);
		SendBuff[SendLen++]=1;
		return k;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->Task_Value[P-1].F65_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			SendBuff[SendLen++]=RtuDataAddr->Task_Value[P-1].F65_Set_Para.FaSong_ZhouQi;
			memcpy(&SendBuff[SendLen],&RtuDataAddr->Task_Value[P-1].F65_Set_Para.Ji_Zhun_Shi_Jian[0],sizeof(RtuDataAddr->Task_Value[P-1].F65_Set_Para.Ji_Zhun_Shi_Jian));
			SendLen=SendLen+sizeof(RtuDataAddr->Task_Value[P-1].F65_Set_Para.Ji_Zhun_Shi_Jian);
			SendBuff[SendLen++]=RtuDataAddr->Task_Value[P-1].F65_Set_Para.Qu_Xian_ChouQu_BeiLv;
			SendBuff[SendLen++]=RtuDataAddr->Task_Value[P-1].F65_Set_Para.ShuJv_DanYuan_Num;
			for(i=0;i<RtuDataAddr->Task_Value[P-1].F65_Set_Para.ShuJv_DanYuan_Num;i++)
			{
				memcpy(&SendBuff[SendLen],&RtuDataAddr->Task_Value[P-1].F65_Set_Para.DanYuan_BiaoShi[i][0],4);
				SendLen=SendLen+4;
			}
		}
		return 4;
	}
	return 1;
}

INT8U GetF66(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	INT8U i,j,k;
	if(Set==1)//��վ��������
	{
		if((P>Task_Max)||(RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1))
		{
			goto e;
		}
		k=0;
		RtuDataAddr->Task_Value[P-1].F66_Set_Para.Valid=1;
		RtuDataAddr->Task_Value[P-1].F66_Set_Para.FaSong_ZhouQi=Data[k++];
		memcpy(&RtuDataAddr->Task_Value[P-1].F66_Set_Para.Ji_Zhun_Shi_Jian[0],&Data[k],sizeof(RtuDataAddr->Task_Value[P-1].F66_Set_Para.Ji_Zhun_Shi_Jian));
		k=k+sizeof(RtuDataAddr->Task_Value[P-1].F66_Set_Para.Ji_Zhun_Shi_Jian);
		RtuDataAddr->Task_Value[P-1].F66_Set_Para.Qu_Xian_ChouQu_BeiLv=Data[k++];
		RtuDataAddr->Task_Value[P-1].F66_Set_Para.ShuJv_DanYuan_Num=Data[k++];
		for(i=0;i<RtuDataAddr->Task_Value[P-1].F66_Set_Para.ShuJv_DanYuan_Num;i++)
		{
			memcpy(&RtuDataAddr->Task_Value[P-1].F66_Set_Para.DanYuan_BiaoShi[i][0],&Data[k],4);
			k=k+4;
		}
		TaskChg=1;
//		Save_Task_Set();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(SetDa1(P),SetDa2(P),2,8);
		RtuDataAddr->SetChanged[66]=1;
		return k;
e:
		k=0;
		k++;
		k=k+sizeof(RtuDataAddr->Task_Value[0].F65_Set_Para.Ji_Zhun_Shi_Jian);
		k++;
		j=Data[k++];
		for(i=0;i<j;i++)
		{
			k=k+4;
		}
		SetDaDt(P,F);
		SendBuff[SendLen++]=1;
		return k;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->Task_Value[P-1].F66_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			SendBuff[SendLen++]=RtuDataAddr->Task_Value[P-1].F66_Set_Para.FaSong_ZhouQi;
			memcpy(&SendBuff[SendLen],&RtuDataAddr->Task_Value[P-1].F66_Set_Para.Ji_Zhun_Shi_Jian[0],sizeof(RtuDataAddr->Task_Value[P-1].F66_Set_Para.Ji_Zhun_Shi_Jian));
			SendLen=SendLen+sizeof(RtuDataAddr->Task_Value[P-1].F66_Set_Para.Ji_Zhun_Shi_Jian);
			SendBuff[SendLen++]=RtuDataAddr->Task_Value[P-1].F66_Set_Para.Qu_Xian_ChouQu_BeiLv;
			SendBuff[SendLen++]=RtuDataAddr->Task_Value[P-1].F66_Set_Para.ShuJv_DanYuan_Num;
			for(i=0;i<RtuDataAddr->Task_Value[P-1].F66_Set_Para.ShuJv_DanYuan_Num;i++)
			{
				memcpy(&SendBuff[SendLen],&RtuDataAddr->Task_Value[P-1].F66_Set_Para.DanYuan_BiaoShi[i][0],4);
				SendLen=SendLen+4;
			}
		}
		return 4;
	}
	return 1;
}

INT8U GetF67(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		if((P>Task_Max)||(RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1))
		{
			goto e;
		}
		RtuDataAddr->Task_Value[P-1].F67_Set_Para.Valid=1;
		RtuDataAddr->Task_Value[P-1].F67_Set_Para.type_1_Task_Enable=Data[0];
		TaskChg=1;
//		Save_Task_Set();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(SetDa1(P),SetDa2(P),4,8);
		RtuDataAddr->SetChanged[67]=1;
		return 1;
e:
		SetDaDt(P,F);
		SendBuff[SendLen++]=1;
		return 1;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->Task_Value[P-1].F67_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			SendBuff[SendLen++]=RtuDataAddr->Task_Value[P-1].F67_Set_Para.type_1_Task_Enable;
		}
		return 4;
	}
	return 1;
}

INT8U GetF68(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		if((P>Task_Max)||(RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1))
		{
			goto e;
		}
		RtuDataAddr->Task_Value[P-1].F68_Set_Para.Valid=1;
		RtuDataAddr->Task_Value[P-1].F68_Set_Para.type_2_Task_Enable=Data[0];
		TaskChg=1;
//		Save_Task_Set();
		SetDaDt(P,F);
		SendBuff[SendLen++]=0;
		CreateErr03(SetDa1(P),SetDa2(P),8,8);
		RtuDataAddr->SetChanged[68]=1;
		return 1;
e:
		SetDaDt(P,F);
		SendBuff[SendLen++]=1;
		return 1;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->Task_Value[P-1].F68_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			SendBuff[SendLen++]=RtuDataAddr->Task_Value[P-1].F68_Set_Para.type_2_Task_Enable;
		}
		return 4;
	}
	return 1;
}

INT8U GetF73(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		SetDaDt(P,F);
		SendBuff[SendLen++]=1;
		RtuDataAddr->SetChanged[73]=1;
		return 48;
	}
	if(Set==0)//��ȡ���ñ���
	{
		return 4;
	}
	return 1;
}

INT8U GetF74(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		SetDaDt(P,F);
		SendBuff[SendLen++]=1;
		//		CreateErr03(0,0,2,9);
		RtuDataAddr->SetChanged[74]=1;
		return 10;
	}
	if(Set==0)//��ȡ���ñ���
	{
	/*		SetDaDt(P,F);
	memset(&SendBuff[SendLen],0,27);
	SendLen=SendLen+10;
		*/		return 4;
	}
	return 1;
}

INT8U GetF75(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		SetDaDt(P,F);
		SendBuff[SendLen++]=1;
		//		CreateErr03(0,0,4,9);
		RtuDataAddr->SetChanged[75]=1;
		return 16;
	}
	if(Set==0)//��ȡ���ñ���
	{
	/*		SetDaDt(P,F);
	memset(&SendBuff[SendLen],0,27);
	SendLen=SendLen+16;
		*/		return 4;
	}
	return 1;
}

INT8U GetF76(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		SetDaDt(P,F);
		SendBuff[SendLen++]=1;
		//		CreateErr03(0,0,8,9);
		RtuDataAddr->SetChanged[76]=1;
		return 1;
	}
	if(Set==0)//��ȡ���ñ���
	{
	/*		SetDaDt(P,F);
	SendBuff[SendLen++]=0;
		*/		return 4;
	}
	return 1;
}

INT8U GetF81(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		SetDaDt(P,F);
		SendBuff[SendLen++]=1;
		//		CreateErr03(0,0,1,10);
		RtuDataAddr->SetChanged[81]=1;
		return 4;
	}
	if(Set==0)//��ȡ���ñ���
	{
	/*		SetDaDt(P,F);
		*/		return 4;
	}
	return 1;
}

INT8U GetF82(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		SetDaDt(P,F);
		SendBuff[SendLen++]=1;
		//		CreateErr03(0,0,2,10);
		RtuDataAddr->SetChanged[82]=1;
		return 4;
	}
	if(Set==0)//��ȡ���ñ���
	{
	/*		SetDaDt(P,F);
		*/		return 4;
	}
	return 1;
}

INT8U GetF83(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	if(Set==1)//��վ��������
	{
		SetDaDt(P,F);
		SendBuff[SendLen++]=1;
		//		CreateErr03(0,0,4,10);
		RtuDataAddr->SetChanged[83]=1;
		return 1;
	}
	if(Set==0)//��ȡ���ñ���
	{
	/*		SetDaDt(P,F);
		*/		return 4;
	}
	return 1;
}
