#ifndef CONTROLFUN_H_
#define CONTROLFUN_H_
#include "base130fun.h"

void ControlTail();
void ControlHead();
void SaveZhongwen();
INT16U DoControl(INT8U F,INT8U P);
void ControlSet();
#endif /*CONTROLFUN_H_*/
