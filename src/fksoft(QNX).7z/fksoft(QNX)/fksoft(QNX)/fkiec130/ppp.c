/*
 * ppp.c
 *
 *  Created on: 2010-3-17
 *      Author: fzh
 *      Description: PPPΪfkiec130���̵��ӹ���ģ��
 *      			  ���ӿں���Ϊ   		ProcessDial()
 *      			 APN��ʼ���ӿں���	initApn()
 *      function:    ����PPPЭ�鲦�š�TCPIPЭ���������Ӽ�⼰���������ݵ��շ�
 */
#include "ppp.h"
#define   ETH_NAME "ppp0"
void FrameSend()
{
	int i;
	int ok = 0;

	for (i=0;i<5;i++)
	{
		CleardeadCount();
		SelfheartCount = 0;
		if (SendData(client_s)<0)
			delay(500);
		else
		{
			ok = 1;
			break;
		}
	}
	/*if (ok ==0)
	{
		RtuDataAddr->Gprs_ok = 0;//����ʧ��֮���������ߡ�
		RtuDataAddr->ModuleType=0;//��ʼֵΪ0��0��ʾGPRSͨ�ŷ�ʽ��3��ʾ��̫��ͨ�ŷ�ʽ��
	}*/
}
int tryifconfig()
{
	  int   sock;
	  struct   sockaddr_in   sin;
	  struct   ifreq   ifr;

	  sock   =   socket(AF_INET,   SOCK_DGRAM,   0);
	  if   (sock   ==   -1)
	  {
		  return   -1;
	  }
	  strncpy(ifr.ifr_name,   ETH_NAME,   IFNAMSIZ);
	  ifr.ifr_name[IFNAMSIZ   -   1]   =   0;
	  if (ioctl(sock,   SIOCGIFADDR,   &ifr)   <   0)
	  {
		  if(close(sock) == -1)
			printf("\n\r tryifconfig: fail to close !!!");
		  return   -1;
	  }
	  memcpy(&sin,   &ifr.ifr_addr,   sizeof(sin));
	  if (sin.sin_addr.s_addr >0)
	  {
		  sprintf(RtuDataAddr->pppip,"%s",inet_ntoa(sin.sin_addr));
		  close(sock);
		  return 1;
	  }
	  return -1;
}
void *clearpro(void* param)
{
	struct thread_param* par;
	par = (struct thread_param*)param;
	while(par->run)
	{
		RtuDataAddr->stPortPara[par->port_id].uiDeadCount = 0;
		if (SelfheartCount > 30)
			break;
		delay(1000);
		SelfheartCount++;
	}
	pthread_exit((void *)par->run);
	return NULL;
}
void mydelay(int s)
{
	int i;
	for(i=0; i<s; i++)
	{
		SelfheartCount = 0;
		CleardeadCount();
		delay(1000);
	}
}
int write_apn()
{
	FILE *fp = NULL;

	fp=fopen("/etc/ppp/gprs-connect-chat","w");
	if (fp==NULL)
		return 0;
	fprintf(fp,"TIMEOUT        3\n");
	fprintf(fp,"ABORT        \'\\nBUSY\\r\'\n");
	fprintf(fp,"ABORT        \'\\nNO ANSWER\\r\'\n");
	fprintf(fp,"ABORT        \'\\nRINGING\\r\\n\\r\\nRINGING\\r\'\n");
	fprintf(fp,"\'\' \\rAT\n");
	fprintf(fp,"\'OK-+++\\c-OK\'    ATZ\n");
	fprintf(fp,"TIMEOUT        5\n");
	fprintf(fp,"OK        AT+CSQ\n");
	fprintf(fp,"OK        AT+CGDCONT=1,\"IP\",\"%s\"\n",CommPara.APN);
	fprintf(fp,"OK        ATDT*99***1#\n");
	fprintf(fp,"CONNECT \'\'\n");
	fclose(fp);
	return 1;
}

int RevData(int client)
{
	ssize_t  rc;
	int n,rcn;
	unsigned char c, *buffer;
	unsigned int pointer;
	int flag = 1;
	rcn = 0;
	buffer = RecBuf;
	pointer = RecHead;

	ioctl(client,FIONREAD ,&rcn);
	//DebugOut("\n\r receive length first = %d",rcn);
	//if (rcn >0)
	//	DebugOut("\n\r receive length = %d",rcn);
	for(n=0; n<rcn ;n++)
	{
		if ((rc = recv(client, &c, 1,0)) == 1)
		{
			if (flag==1)
			{
				//DebugOut("\n\r Receive Data--------------------------(%d bytes)\n\r",rcn);
				flag =2;
			}
			buffer[pointer] = c;
			pointer = (pointer + 1)%FrameSize;
			//DebugOut("%02x ",c);
		}
		else if (rc == 0)
			{
				if (n == 0)
					return 0;
				else
					break;
			} else
			{
				if (errno == EINTR)
					continue;
				return -1;
			}
	}
	if (n > 0)
	{
		RecHead = (RecHead + n)%FrameSize;
		DebugOut("\n\r ");
	}
	return n;

}
int SendData(int client)
{
	int n;
	size_t  nleft;
	ssize_t nwritten;
	unsigned char *buffer;

	n = SendLen;
	nleft = SendLen;
	buffer = SendBuff;
	nwritten = 0;
	while( nleft > 0)
	{
		//DebugOut("\n\r Send Data--------------------------(%d bytes)\n\r",nleft);
		nwritten = send(client, buffer, nleft,0);
		if (nwritten<= 0)
		{
			if (errno == EINTR)
				nwritten = 0;
			else{
				fprintf(stderr,"\n\rnleft33====%d,nwritten======%d",nleft,nwritten);
				return -1;
			}

		}
		nleft -= nwritten;
		buffer += nwritten;
	}
	//n = SendLen;
	SendLen = 0;
	/*if (n > 0)
	{
		for(i=0; i<n; i++)
			DebugOut("%02x ",SendBuff[i]);
		DebugOut("\n\r ");
	}*/
	return n;
}
void CreatThread()
{
    param.run = 1;
    param.port_id = portid;
    pthread_create(&thread_clear, NULL, clearpro, &param);	    /*�����߳�*/
}
void ExitThread()
{
	param.run = 0;												/*�߳��˳�*/
}
int GetConnect(char *ip,int port)
{
	struct sockaddr_in servaddr;
	int ret,client,ifdelay;
	unsigned long ul = 1;
	ret=-1;
    mydelay(1);
    DebugOut("\n\r Begin build TCPIP connect");
	DebugOut("\n\r ip =%s  port =%d",ip,port);

	bzero(&servaddr,sizeof(servaddr));
	servaddr.sin_family=AF_INET;
	servaddr.sin_port=htons(port);
	inet_aton(ip,&servaddr.sin_addr);

	client = 0;
    if((client = socket(AF_INET,SOCK_STREAM,0))<0)
    {
    	close(client);
    	DebugOut( "\n\r create socket error!\n " );
        return -1;
    }
	DebugOut("\n\r connect socket is %d\n\r",client);
	ret = connect(client,(struct sockaddr*)&servaddr,sizeof(servaddr));

	ioctl(client, FIONBIO, (unsigned long*)&ul);
	if(ret < 0)
	{
		close(client);
		DebugOut("\n\r socket connect errs =%d",errno );
		return -1;
	}
 	ifdelay = 1;
	ret = setsockopt(client,IPPROTO_TCP,TCP_NODELAY,&ifdelay,sizeof(int));//ȡ��Э��ջ��ʱ�㷨
	if (ret == -1)
	{
		printf("Couldn't setsockopt(TCP_NODELAY)\n");
	}
	DebugOut("\n\r socket connect OK  re= %d",ret);
	DebugOut("\n\r  ");
	return client;
}
void PPProcess()
{
	int i = 0;
	/*system("ppp-off");
	mydelay(3);
	system("pppd call disgprs > /user/gprs_conn.log &");
	mydelay(8);
	system("ppp-on");
*/
    system("slay pppd");
    mydelay(10);
    system("rm /var/run/*.tdb");
    mydelay(2);
    system("pppd call gprs &");
	memset(RtuDataAddr->pppip,0,16);
    while(1)
    {
    	if (tryifconfig()==1)
    	{
    		printf("\n\r get ip !!");
    		printf("\n\r pppip: %s",RtuDataAddr->pppip);
    		break;
    	}
    	SelfheartCount = 0;
		CleardeadCount();
    	i++;
    	if (i>40)
    		break;
		delay(1000);
    }
	delay(500);
	return;
}
void initdata()
{
	RecTail = RecHead = 0;
	RtuDataAddr->WirelessModuleType=0;
	RtuDataAddr->CommSetChanged=0;
	RtuDataAddr->Gprs_Moduleok=0;
	RtuDataAddr->linked_ok=0;
	RtuDataAddr->GprsCSQ=0;
	RtuDataAddr->Gprs_ok=0;
	return;
}
void initApn(unsigned char id)
{
	memcpy(PppAPN,CommPara.APN,16);
	DebugOut("\n\r PppAPN %s",PppAPN);
	apnSetOk = 1;
	portid = id;
}
void GetMasterPara(char* ip_p,int* port_p)
{
	unsigned char bport[2];
	memset(bport,0,2);
	sprintf(ip_p,"%d.%d.%d.%d",CommPara.IPMaster[0],
							   CommPara.IPMaster[1],
							   CommPara.IPMaster[2],
							   CommPara.IPMaster[3]);

	bport[0] = CommPara.PortMaster[0];
	bport[1] = CommPara.PortMaster[1];
	*port_p = (bport[1]<<8) + bport[0];

	if(strncmp(PppAPN, (char *)CommPara.APN,16)!= 0)
	{
		if (write_apn()==1)
			initApn(portid);
	}
	return;
}
void ProcessDial()
{
	char ip[20];
	int port;
	unsigned char tmp[128];
	memset(tmp,0,128);
	memset(ip,0,20);
	if((RtuDataAddr->Gprs_ok == 0&&(RtuDataAddr->batflag == 0)))
	{
		DebugOut("\n\r Begin dialmodem ...");
		DebugOut("\n\r ");
		RtuDataAddr->ModuleType = 0 ;
		if (RtuDataAddr->FkComm_Value.Netselect == 2)//gprsͨ�ŷ�ʽ
		{
			printf("\n\r --------reconnetc is %d -----",reconnect);
			if (reconnect==0)
			{
				printf("\n\r --------init mc37i!---------");
				printf("\n\r ");
				initM22();//��ʼ����������
				mydelay(16);
			}
			GetMasterPara(ip,&port);//���IP��ַ�Ͷ˿ں�
			mydelay(3);
			PPProcess();
			reconnect++;
			printf("\n\r reconnect is %d",reconnect);
		}
		/*if(RtuDataAddr->FkComm_Value.Netselect == 1)//��̫��ͨ�ŷ�ʽ
		{
			sprintf((char *)tmp,"ifconfig en0 %d.%d.%d.%d up &",RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[0]
			,RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[1]
			,RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[2]
			,RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[3]);
			rc=system((char *)tmp);
			if( rc == -1 )
			{
				printf( "shell could not be run\n" );
			}
	    }*/

		GetMasterPara(ip,&port);
		initdata();
		client_s = 0;
		client_s = GetConnect(ip,port);
		if (client_s > 0)
		{
			RtuDataAddr->Gprs_ok = 1;
			RtuDataAddr->GprsCSQ=24;
		}
	}
	if (RtuDataAddr->Gprs_ok == 1)
	{
		if(RtuDataAddr->FkComm_Value.Netselect == 2)
			RtuDataAddr->ModuleType=1;
		else
			if(RtuDataAddr->FkComm_Value.Netselect == 1)
				RtuDataAddr->ModuleType=3;
		reconnect = 0;
		CleardeadCount();
		SelfheartCount = 0;
		RevData(client_s);
	}
}
