#include "level1fun.h"
unsigned char   MACAdd[6];//�ն�MAC��ַ1--6��
INT16U P1=1;
INT16U P2=2;
INT8U TestTwo[16];
extern INT8U CallTwoDataProc(INT8U F,INT8U P,INT8U QxBl,INT8U *S,INT8U FRM);
extern int SelfheartCount;
INT8U ReportOneLevelData(INT8U i)
{
	INT8U j,k,l;
	INT8U Min,Hour,Day,Month,zqdw,zqvalue;
	DebugOut("%s","\r\n1�����������ϱ� ");
	////if(RtuDataAddr->FuKong_Control_Value.F29_Control_Para.Valid==1)
	{
			if(RtuDataAddr->Task_Value[i].F67_Set_Para.Valid==1)
			{
				if(RtuDataAddr->Task_Value[i].F67_Set_Para.type_1_Task_Enable==0x55)
				{
					if(RtuDataAddr->Task_Value[i].F65_Set_Para.Valid==1)
					{
						if(testTime(RtuDataAddr->Task_Value[i].F65_Set_Para.Ji_Zhun_Shi_Jian))
						{
							TS ts;
							TSGet(&ts);
							Min=(RtuDataAddr->Task_Value[i].F65_Set_Para.Ji_Zhun_Shi_Jian[1]>>4)*10;
							Min=Min+RtuDataAddr->Task_Value[i].F65_Set_Para.Ji_Zhun_Shi_Jian[1]&0x0f;
							Hour=(RtuDataAddr->Task_Value[i].F65_Set_Para.Ji_Zhun_Shi_Jian[2]>>4)*10;
							Hour=Hour+RtuDataAddr->Task_Value[i].F65_Set_Para.Ji_Zhun_Shi_Jian[2]&0x0f;
							Day=(RtuDataAddr->Task_Value[i].F65_Set_Para.Ji_Zhun_Shi_Jian[3]>>4)*10;
							Day=Day+RtuDataAddr->Task_Value[i].F65_Set_Para.Ji_Zhun_Shi_Jian[3]&0x0f;
							Month=((RtuDataAddr->Task_Value[i].F65_Set_Para.Ji_Zhun_Shi_Jian[4]>>4)&1)*10;
							Month=Month+RtuDataAddr->Task_Value[i].F65_Set_Para.Ji_Zhun_Shi_Jian[4]&0x0f;
							zqdw=RtuDataAddr->Task_Value[i].F65_Set_Para.FaSong_ZhouQi>>6;
							zqvalue=RtuDataAddr->Task_Value[i].F65_Set_Para.FaSong_ZhouQi&0x3f;
							DebugOut("\r\n%s%d  %d %d %d ","���������ϱ�", i,zqdw,zqvalue,task1_Delay_Count[i]);
							if(zqdw==0)
							{
								if(zqvalue!=0)
								if(((ts.Minute+60-task1_Delay_Count[i])%zqvalue)==0)
								{
									task1_Delay_Count[i]=ts.Minute;
								}
							}
							if(zqdw==1)
							{
								if(zqvalue!=0)
								if(((ts.Hour+24-task1_Delay_Count[i])%zqvalue)==0)
								{
									task1_Delay_Count[i]=ts.Hour;
								}
							}
							if(zqdw==2)
							{
								if(zqvalue!=0)
								if(((ts.Day+31-task1_Delay_Count[i])%zqvalue)==0)
								{
									task1_Delay_Count[i]=ts.Day;
								}
							}
							if(zqdw==3)
							{
								if(zqvalue!=0)
								if(((ts.Month+12-task1_Delay_Count[i])%zqvalue)==0)
								{
									task1_Delay_Count[i]=ts.Month;
								}
							}
							NeedTp=0;
							for(j=0;j<RtuDataAddr->Task_Value[i].F65_Set_Para.ShuJv_DanYuan_Num;j++)
							{
								GetDa(RtuDataAddr->Task_Value[i].F65_Set_Para.DanYuan_BiaoShi[j][0],RtuDataAddr->Task_Value[i].F65_Set_Para.DanYuan_BiaoShi[j][1]);
								GetDt(RtuDataAddr->Task_Value[i].F65_Set_Para.DanYuan_BiaoShi[j][2],RtuDataAddr->Task_Value[i].F65_Set_Para.DanYuan_BiaoShi[j][3]);
								for(k=0;k<64;k++)
								{
									if(DA[k]==1)
									{
										for(l=0;l<255;l++)
										{
											if(DT[l]==1)
											{
												CallOneDataProc(l,k,RtuDataAddr->Task_Value[i].F65_Set_Para.Qu_Xian_ChouQu_BeiLv,0xc4);
											}
										}
									}
								}
								delay(120);
							}
						}
					}
				}
			}

	}
	DebugOut("\r\n%s ","���������ϱ�����");
		return 1;

}
INT8U ReportTwoLevelData(INT8U i,INT8U *S)
{
	INT8U j,k,l;
	INT8U Min,Hour,Day,Month,zqdw,zqvalue;
	delay(1000);

	DebugOut("\r\n%s ","�������������ϱ�");
	////if(RtuDataAddr->FuKong_Control_Value.F29_Control_Para.Valid==1)
	{
			if(RtuDataAddr->Task_Value[i].F68_Set_Para.Valid==1)
			{
				if(RtuDataAddr->Task_Value[i].F68_Set_Para.type_2_Task_Enable==0x55)
				{
					if(RtuDataAddr->Task_Value[i].F66_Set_Para.Valid==1)
					{
						if(testTime(RtuDataAddr->Task_Value[i].F66_Set_Para.Ji_Zhun_Shi_Jian))
						{
							TS ts;
							TSGet(&ts);
							Min=(S[0]>>4)*10;
							Min=Min+S[0]&0x0f;
							Hour=(S[1]>>4)*10;
							Hour=Hour+S[1]&0x0f;
							Day=(S[2]>>4)*10;
							Day=Day+S[2]&0x0f;
							Month=((S[3]>>4)&1)*10;
							Month=Month+S[3]&0x0f;
							zqdw=RtuDataAddr->Task_Value[i].F66_Set_Para.FaSong_ZhouQi>>6;
							zqvalue=RtuDataAddr->Task_Value[i].F66_Set_Para.FaSong_ZhouQi&0x3f;
							DebugOut("\r\n%s%d  %d %d %d ","���������ϱ�", i,zqdw,zqvalue,task2_Delay_Count[i]);
							if(zqdw==0)
							{
								if(zqvalue!=0)
									if(((ts.Minute+60-task2_Delay_Count[i])%zqvalue)==0)
									{
										task2_Delay_Count[i]=ts.Minute;
									}
							}
							if(zqdw==1)
							{
								if(zqvalue!=0)
									if(((ts.Hour+24-task2_Delay_Count[i])%zqvalue)==0)
									{
										task2_Delay_Count[i]=ts.Hour;
									}
							}
							if(zqdw==2)
							{
								if(zqvalue!=0)
									if(((ts.Day+31-task2_Delay_Count[i])%zqvalue)==0)
									{
										task2_Delay_Count[i]=ts.Day;
									}
							}
							if(zqdw==3)
							{
								if(zqvalue!=0)
									if(((ts.Month+12-task2_Delay_Count[i])%zqvalue)==0)
									{
										task2_Delay_Count[i]=ts.Month;
									}
							}
							for(j=0;j<RtuDataAddr->Task_Value[i].F66_Set_Para.ShuJv_DanYuan_Num;j++)
							{
								GetDa(RtuDataAddr->Task_Value[i].F66_Set_Para.DanYuan_BiaoShi[j][0],RtuDataAddr->Task_Value[i].F66_Set_Para.DanYuan_BiaoShi[j][1]);
								GetDt(RtuDataAddr->Task_Value[i].F66_Set_Para.DanYuan_BiaoShi[j][2],RtuDataAddr->Task_Value[i].F66_Set_Para.DanYuan_BiaoShi[j][3]);
								for(k=0;k<64;k++)
								{
									if(DA[k]==1)
									{
										for(l=0;l<255;l++)
										{
											if(DT[l]==1)
											{
												if(
												(l<=12)
												||((l>=25)&&(l<=31))
												||((l>=41)&&(l<=43))
												||((l>=45)&&(l<=50))
												||(l==53)
												||(l==57)
												||(l==58)
												||(l==59))
												{
													TestTwo[3]=0;
													TestTwo[4]=0;
													TestTwo[5]=0;
													TestTwo[6]=0;

													if(ts.Day==1)
													{
														if(ts.Month==1)
														{
															TestTwo[0]=((31/10)<<4)+(31%10);
															TestTwo[1]=((12/10)<<4)+(12%10);
															TestTwo[2]=((((ts.Year-1)%100)/10)<<4)+((ts.Year-1)%10);
														}
														else
															if(ts.Month==2||ts.Month==4||ts.Month==6||ts.Month==8||ts.Month==9||ts.Month==11)
															{
																TestTwo[0]=((31/10)<<4)+(31%10);
																TestTwo[1]=((((ts.Month-1)/10)<<4)+((ts.Month-1)%10));
																TestTwo[2]=(((ts.Year%100)/10)<<4)+(ts.Year%10);
															}
															else
																if(ts.Month==3)
																{
																	TestTwo[0]=((28/10)<<4)+(28%10);
																	TestTwo[1]=((((ts.Month-1)/10)<<4)+((ts.Month-1)%10));
																	TestTwo[2]=(((ts.Year%100)/10)<<4)+(ts.Year%10);
																}
																else
																	if(ts.Month==5||ts.Month==7||ts.Month==10||ts.Month==12)
																	{
																		TestTwo[0]=((30/10)<<4)+(30%10);
																		TestTwo[1]=((((ts.Month-1)/10)<<4)+((ts.Month-1)%10));
																		TestTwo[2]=(((ts.Year%100)/10)<<4)+(ts.Year%10);
																	}
													}
													else
													{
														TestTwo[0]=(((ts.Day-1)/10)<<4)+((ts.Day-1)%10);
														TestTwo[1]=(((ts.Month/10)<<4)+(ts.Month%10));
														TestTwo[2]=(((ts.Year%100)/10)<<4)+(ts.Year%10);
													}
												}
												if(
												((l>=17)&&(l<=24))
												||((l>=33)&&(l<=38))
												||(l==44)
												||(l==51)
												||(l==52)
												||(l==54)
												||((l>=60)&&(l<=66)))
												{
													TestTwo[2]=0;
													TestTwo[3]=0;
													TestTwo[4]=0;
													TestTwo[5]=0;
													TestTwo[6]=0;
													if(ts.Month==1)
													{
														TestTwo[0]=((12/10)<<4)+(12%10);
														TestTwo[1]=((((ts.Year-1)%100)/10)<<4)+((ts.Year-1)%10);
													}
													else
													{
														TestTwo[0]=((((ts.Month-1)/10)<<4)+((ts.Month-1)%10));
														TestTwo[1]=(((ts.Year%100)/10)<<4)+(ts.Year%10);
													}
												}
												if((l>=73)&&(l<=108))
													{
													TestTwo[0]=((ts.Minute/10)<<4)+(ts.Minute%10);
													TestTwo[1]=((ts.Hour/10)<<4)+(ts.Hour%10);
													TestTwo[2]=((ts.Day/10)<<4)+(ts.Day%10);
													TestTwo[3]=(((ts.Month/10)<<4)+(ts.Month%10));
													TestTwo[4]=(((ts.Year%100)/10)<<4)+(ts.Year%10);
													TestTwo[5]=1;
													TestTwo[6]=96;
												}
												CallTwoDataProc(l,k,RtuDataAddr->Task_Value[i].F66_Set_Para.Qu_Xian_ChouQu_BeiLv,TestTwo,0xc4);
											}
										}
									}
								}
								delay(100);
							}
						}
					}
				}
			}
	}
	return 1;
}


INT8U TaskDataProc(INT8U F,INT8U P,INT8U QxBl,INT8U *S,INT8U FRM)
{
	switch(F)
	{
		case 1:// �ն˰汾��Ϣ
			ReportOneLevelData(P);
			return 0;
			break;
		case 2://�ն�֧�ֵ����롢�����ͨ�Ŷ˿�����
			ReportTwoLevelData(P,S);
			return 5;
			break;
		default:
		SendNAK(F,P,0x0b);
			break;
	}
	return 1;
}

INT8U zhongduanxinxiProc(INT8U F,INT8U P,INT8U QxBl,INT8U FRM)
{
	DebugOut("\r\n%s p=%d f=%d ","AFN=09  ���󡢷����ն����ü���Ϣ",P,F);
	switch (F)
	{
	case 1:// �ն˰汾��Ϣ
		return Set_F1(F,P,FRM);
		break;
	case 2://�ն�֧�ֵ����롢�����ͨ�Ŷ˿�����
		return Set_F2(F,P,FRM);
		break;
	case 3://�ն�֧�ֵ���������
		return Set_F3(F,P,FRM);
		break;
	case 4://�ն�֧�ֵĲ�������
		return Set_F4(F,P,FRM);
		break;
	case 5://�ն�֧�ֵĿ�������
		return Set_F5(F,P,FRM);
		break;
	case 6://�ն�֧�ֵ�һ����������
		return Set_F6(F,P,FRM);
		break;
	case 7://�ն�֧�ֵĶ�����������
		return Set_F7(F,P,FRM);
		break;
	case 8://�ն�֧�ֵ��¼���¼����
		return Set_F8(F,P,FRM);
		break;
	default:
	SendNAK(F,P,0x09);
		break;
	}
	return 1;
}


INT8U SendTaskData(INT8U P,INT8U F,INT8U *t)
{
	INT8U i;
	i=TaskDataProc(F,P,1,t,0x88);
	return i;
}
/***********************************************************************
*�����ն����ü���Ϣ��AFN=09H��
*���ú���:();
*�ص�����:��
***********************************************************************/
void Sendzhongduanxinxi(INT8U F,INT8U P)
{
	zhongduanxinxiProc(F,P,1,0x88);
	return;
}
void zhongduanxinxiCalc()
{
	INT8U i,j;//Pro130SetMax
	INT16U Tmp_Resolve_Pos;
	Tmp_Resolve_Pos=14;
	AllReportHead=0;
	AllReportTail=0;
	while(Tmp_Resolve_Pos<(RecDataLen+6))
	{
		GetDa(Tmp130Buff[Tmp_Resolve_Pos],Tmp130Buff[Tmp_Resolve_Pos+1]);
		GetDt(Tmp130Buff[Tmp_Resolve_Pos+2],Tmp130Buff[Tmp_Resolve_Pos+3]);
		for(i=0;i<64;i++)
		{
			if(DA[i]==1)
			{
				for(j=0;j<255;j++)
				{
					if(DT[j]==1)
					{
					AllReportHead++;
					}
				}
			}
		}
		Tmp_Resolve_Pos+=4;
	}
}
/***********************************************************************
*�����ն����ü���Ϣ��AFN=09H��
*���ú���:();
*�ص�����:��
***********************************************************************/
INT8U Callzhongduanxinxi()
{
	INT8U i,j;//Pro130SetMax
	zhongduanxinxiCalc();
	Resolve_Pos=14;
	while(Resolve_Pos<(RecDataLen+6))
	{
		GetDa(Tmp130Buff[Resolve_Pos],Tmp130Buff[Resolve_Pos+1]);
		GetDt(Tmp130Buff[Resolve_Pos+2],Tmp130Buff[Resolve_Pos+3]);
		for(i=0;i<64;i++)
		{
			if(DA[i]==1)
			{
				for(j=0;j<255;j++)
				{
					if(DT[j]==1)
					{
						Sendzhongduanxinxi(j,i);
					}
				}
			}
		}
		Resolve_Pos+=4;
	}
	return 1;
}
void CallOnelevelDataCalc()
{
	INT8U i,j;//Pro130SetMax
	INT16U Tmp_Resolve_Pos;
	Tmp_Resolve_Pos=14;
	AllReportHead=0;
	AllReportTail=0;
	while(Tmp_Resolve_Pos<(RecDataLen+6))
	{
		GetDa(Tmp130Buff[Tmp_Resolve_Pos],Tmp130Buff[Tmp_Resolve_Pos+1]);
		GetDt(Tmp130Buff[Tmp_Resolve_Pos+2],Tmp130Buff[Tmp_Resolve_Pos+3]);
		for(i=0;i<64;i++)
		{
			if(DA[i]==1)
			{
				for(j=0;j<255;j++)
				{
					if(DT[j]==1)
					{
					AllReportHead++;
					}
				}
			}
		}
		Tmp_Resolve_Pos+=4;
	}
}

void MksetHead(INT8U P,INT8U F,INT8U FRM)
{
	FrameHeadCreate(FRM);
	SendBuff[SendLen++]=0x09;//afn
	if(NeedTp)
		SendBuff[SendLen++]=(TestFirFin(F,P)|(seq&0x0f))|0x80;//seq
	else
		SendBuff[SendLen++]=(TestFirFin(F,P)|(seq&0x0f))&0x7f;//seq
	SendBuff[SendLen++]=SetDa1(P);//Tmp130Buff[14];//da1e
	SendBuff[SendLen++]=SetDa2(P);//Tmp130Buff[15];//da2
	SendBuff[SendLen++]=SetDt1(F);//Tmp130Buff[16];//dt1
	SendBuff[SendLen++]=SetDt2(F);//Tmp130Buff[17];//dt2
}
/*********************************************************************8
4.9.2.3.1	F1���ն˰汾��Ϣ
��������	���ݸ�ʽ	�ֽ���
���̴���	ASCII	4
�豸���	ASCII	8
�ն������汾��	ASCII	4
�ն������������ڣ�������	���ݸ�ʽ20	3
�ն�����������Ϣ��	ASCII	11
***********************************************************************/
INT8U Set_F1(INT8U F,INT8U P,INT8U FRM)
{
	MksetHead(P,F,FRM);
	memcpy(&SendBuff[SendLen],CoLtd,4);
	SendLen=SendLen+4;
	memcpy(&SendBuff[SendLen],RtuDataAddr->FkComm_Value.DevCode,8);
	SendLen=SendLen+8;
	memcpy(&SendBuff[SendLen],RtuDataAddr->ucsysVER,4);
	SendLen=SendLen+4;
	memcpy(&SendBuff[SendLen],ProgDate,3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],RongLiang,11);
	SendLen=SendLen+11;
	memcpy(&SendBuff[SendLen],XieyiVer,4);
	SendLen=SendLen+4;
	memcpy(&SendBuff[SendLen],HwVer,4);
	SendLen=SendLen+4;
	memcpy(&SendBuff[SendLen],HwDate,3);
	SendLen=SendLen+3;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_F2(INT8U F,INT8U P,INT8U FRM)
{
	MksetHead(P,F,FRM);
	SendBuff[SendLen]=MaiChong_Max;
	SendLen=SendLen+1;
	SendBuff[SendLen]=Yx_Max;
	SendLen=SendLen+1;
	SendBuff[SendLen]=Zhiliu_Max;
	SendLen=SendLen+1;
	SendBuff[SendLen]=Control_Lunci_Max;
	SendLen=SendLen+1;
	SendBuff[SendLen++]=(DD_Device_Max)&0xff;
	SendBuff[SendLen++]=(DD_Device_Max>>8)&0xff;
	SendBuff[SendLen++]=(FrameSize)&0xff;
	SendBuff[SendLen++]=(FrameSize>>8)&0xff;
	SendBuff[SendLen++]=(FrameSize)&0xff;
	SendBuff[SendLen++]=(FrameSize>>8)&0xff;
	memset(MACAdd,1,6);
	memcpy(&SendBuff[SendLen],MACAdd,6);
	SendLen=SendLen+6;

	SendBuff[SendLen]=PORTNum;
	SendLen=SendLen+1;
	SendBuff[SendLen++]=(P1)&0xff;
	SendBuff[SendLen++]=(P1>>8)&0xff;
	SendBuff[SendLen++]=(BaudMax)&0xff;
	SendBuff[SendLen++]=(BaudMax>>8)&0xff;
	SendBuff[SendLen++]=(BaudMax>>16)&0xff;
	SendBuff[SendLen++]=(BaudMax>>24)&0xff;

	SendBuff[SendLen]=DD_Device_Max;
	SendLen=SendLen+2;;
	SendBuff[SendLen++]=(FrameSize)&0xff;
	SendBuff[SendLen++]=(FrameSize>>8)&0xff;
	SendBuff[SendLen++]=(FrameSize)&0xff;
	SendBuff[SendLen++]=(FrameSize>>8)&0xff;
	SendBuff[SendLen++]=(P2)&0xff;
	SendBuff[SendLen++]=(P2>>8)&0xff;
	SendBuff[SendLen++]=(BaudMax)&0xff;
	SendBuff[SendLen++]=(BaudMax>>8)&0xff;
	SendBuff[SendLen++]=(BaudMax>>16)&0xff;
	SendBuff[SendLen++]=(BaudMax>>24)&0xff;
	SendBuff[SendLen]=DD_Device_Max;
	SendLen=SendLen+2;
	SendBuff[SendLen++]=(FrameSize)&0xff;
	SendBuff[SendLen++]=(FrameSize>>8)&0xff;
	SendBuff[SendLen++]=(FrameSize)&0xff;
	SendBuff[SendLen++]=(FrameSize>>8)&0xff;
		EC();
		TP();
		FrameTailCreate_Send();
	return 1;
}
INT8U Set_F3(INT8U F,INT8U P,INT8U FRM)
{
	MksetHead(P,F,FRM);
	SendBuff[SendLen++]=(CeLiangPoint_Max)&0xff;
	SendBuff[SendLen++]=(CeLiangPoint_Max>>8)&0xff;
	SendBuff[SendLen]=ZongJia_Max;
	SendLen++;
	SendBuff[SendLen]=Task_Max;
	SendLen++;
	SendBuff[SendLen]=ChaDong_Zu_Mx;
	SendLen++;
	SendBuff[SendLen]=FeiLvNum;
	SendLen++;
	SendBuff[SendLen]=DongjieM_Max;
	SendLen++;
	SendBuff[SendLen]=DongjieMP_Max;
	SendLen++;
	SendBuff[SendLen]=DongjieMQ_Max;
	SendLen++;
	SendBuff[SendLen]=DongjieMPALL_Max;
	SendLen++;
	SendBuff[SendLen]=DongjieMQALL_Max;
	SendLen++;
	SendBuff[SendLen]=Max_Day_SaveQuXian;
	SendLen++;
	SendBuff[SendLen]=Max_Yue_Save;
	SendLen++;
	SendBuff[SendLen]=ShiDuan_Tou_FangAn_Max;
	SendLen++;
	SendBuff[SendLen]=XieBoNum;
	SendLen++;
	SendBuff[SendLen]=WugongBuchang;
	SendLen++;
	SendBuff[SendLen]=JizhongChao;
	SendLen++;
	SendBuff[SendLen++]=(Daleihao_Max)&0xff;
	SendBuff[SendLen++]=(Daleihao_Max>>8)&0xff;
	SendBuff[SendLen]=Xiaoleihao0;
	SendLen++;
	SendBuff[SendLen]=Xiaoleihao1;
	SendLen++;
	SendBuff[SendLen]=Xiaoleihao2;
	SendLen++;
	SendBuff[SendLen]=Xiaoleihao3;
	SendLen++;
	SendBuff[SendLen]=Xiaoleihao4;
	SendLen++;
	SendBuff[SendLen]=Xiaoleihao5;
	SendLen++;
	SendBuff[SendLen]=Xiaoleihao6;
	SendLen++;
	SendBuff[SendLen]=Xiaoleihao7;
	SendLen++;
	SendBuff[SendLen]=Xiaoleihao8;
	SendLen++;
	SendBuff[SendLen]=Xiaoleihao9;
	SendLen++;
	SendBuff[SendLen]=Xiaoleihao10;
	SendLen++;
	SendBuff[SendLen]=Xiaoleihao11;
	SendLen++;
	SendBuff[SendLen]=Xiaoleihao12;
	SendLen++;
	SendBuff[SendLen]=Xiaoleihao13;
	SendLen++;
	SendBuff[SendLen]=Xiaoleihao14;
	SendLen++;
	SendBuff[SendLen]=Xiaoleihao15;
	SendLen++;

		EC();
		TP();
		FrameTailCreate_Send();
	return 1;
}
INT8U Set_F4(INT8U F,INT8U P,INT8U FRM)
{
	MksetHead(P,F,FRM);
	SendBuff[SendLen]=9;//֧�ֵ���Ϣ������
	SendLen=SendLen+1;

	SendBuff[SendLen]=0x0d;//1-8
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x2F;//9-16
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x4F;//17-24
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x1B;//25-32
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x69;//33-40
	SendLen=SendLen+1;
	SendBuff[SendLen]=0xFF;//41-48
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x01;//49-56
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x05;//57-64
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x0F;//65-72
	SendLen=SendLen+1;
		EC();
		TP();
		FrameTailCreate_Send();
	return 1;
}
INT8U Set_F5(INT8U F,INT8U P,INT8U FRM)
{
	MksetHead(P,F,FRM);
	SendBuff[SendLen]=7;//֧�ֵ���Ϣ������
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x03;//
	SendLen=SendLen+1;
	SendBuff[SendLen]=0xCF;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0xCF;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0xDB;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x7B;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x00;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x07;
	SendLen=SendLen+1;

	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_F6(INT8U F,INT8U P,INT8U FRM)
{ int i=0;
	MksetHead(P,F,FRM);
	SendBuff[SendLen]=0x06;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x00;
	SendLen=SendLen+1;

	SendBuff[SendLen]=0x15;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0xFE;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x03;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x7F;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x0F;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x07;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x00;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x01;
	SendLen=SendLen+1;
	for(i=0;i<13;i++)
	{
		SendBuff[SendLen]=0x00;
		SendLen=SendLen+1;
	}
	SendBuff[SendLen]=0x20;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x15;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0xFE;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x03;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x7F;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x0F;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x07;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x00;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x01;
	SendLen=SendLen+1;
	for(i=0;i<13;i++)
	{
		SendBuff[SendLen]=0x00;
		SendLen=SendLen+1;
	}
	SendBuff[SendLen]=0x20;
	SendLen=SendLen+1;

	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_F7(INT8U F,INT8U P,INT8U FRM)
{
	MksetHead(P,F,FRM);
	SendBuff[SendLen]=0x06;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x00;
	SendLen=SendLen+1;

	SendBuff[SendLen]=0xe;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0xF3;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x0D;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0xF7;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x03;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x1F;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x08;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x3F;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x00;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x00;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x0F;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x11;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x7F;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0xFF;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x01;
	SendLen=SendLen+1;

	SendBuff[SendLen]=0xe;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0xF3;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x0D;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0xF7;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x03;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x1F;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x08;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x3F;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x00;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x00;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x0F;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x11;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x7F;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0xFF;
	SendLen=SendLen+1;
	SendBuff[SendLen]=0x01;
	SendLen=SendLen+1;

	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_F8(INT8U F,INT8U P,INT8U FRM)
{
	MksetHead(P,F,FRM);
	memcpy(&SendBuff[SendLen],&RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[0],8);
	SendLen=SendLen+8;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
/***********************************************************************
*4.9	����1�����ݣ�AFN=0CH��
*���ú���:AskTwoLevelData();
*�ص�����:��
***********************************************************************/
INT8U CallOnelevelData()
{
	INT8U i,j;//Pro130SetMax
	CallOnelevelDataCalc();
	Resolve_Pos=14;
	while(Resolve_Pos<(RecDataLen+6))
	{
		GetDa(Tmp130Buff[Resolve_Pos],Tmp130Buff[Resolve_Pos+1]);
		GetDt(Tmp130Buff[Resolve_Pos+2],Tmp130Buff[Resolve_Pos+3]);
		for(i=0;i<64;i++)
		{
			if(DA[i]==1)
			{
				for(j=0;j<255;j++)
				{
					if(DT[j]==1)
					{
						DebugOut("   P=%d  F=%d",i,j);
						SendOneLevelData(j,i);
					}
				}
			}
		}
		Resolve_Pos+=4;
		delay(100);
	}
	return 1;
}


INT8U autoReportOneLevelData()
{
	INT8U i,j,k,l;
	INT8U Min,Hour,Day,Month,zqdw,zqvalue,delta=0;
	DebugOut("%s","\r\nһ�����������ϱ� ");
	AutoFlg=0;
	////if(RtuDataAddr->FuKong_Control_Value.F29_Control_Para.Valid==1)
	{
		for(i=0;i<Task_Max;i++)
		{
			SelfheartCount = 0;
			if(RtuDataAddr->Task_Value[i].F67_Set_Para.Valid==1)
			{
				if(RtuDataAddr->Task_Value[i].F67_Set_Para.type_1_Task_Enable==0x55)
				{
					if(RtuDataAddr->Task_Value[i].F65_Set_Para.Valid==1)
					{
						if(testTime(RtuDataAddr->Task_Value[i].F65_Set_Para.Ji_Zhun_Shi_Jian))
						{
							TS ts;
							TSGet(&ts);
							Min=(RtuDataAddr->Task_Value[i].F65_Set_Para.Ji_Zhun_Shi_Jian[1]>>4)*10;
							Min=Min+RtuDataAddr->Task_Value[i].F65_Set_Para.Ji_Zhun_Shi_Jian[1]&0x0f;
							Hour=(RtuDataAddr->Task_Value[i].F65_Set_Para.Ji_Zhun_Shi_Jian[2]>>4)*10;
							Hour=Hour+RtuDataAddr->Task_Value[i].F65_Set_Para.Ji_Zhun_Shi_Jian[2]&0x0f;
							Day=(RtuDataAddr->Task_Value[i].F65_Set_Para.Ji_Zhun_Shi_Jian[3]>>4)*10;
							Day=Day+RtuDataAddr->Task_Value[i].F65_Set_Para.Ji_Zhun_Shi_Jian[3]&0x0f;
							Month=((RtuDataAddr->Task_Value[i].F65_Set_Para.Ji_Zhun_Shi_Jian[4]>>4)&1)*10;
							Month=Month+RtuDataAddr->Task_Value[i].F65_Set_Para.Ji_Zhun_Shi_Jian[4]&0x0f;
							zqdw=RtuDataAddr->Task_Value[i].F65_Set_Para.FaSong_ZhouQi>>6;
							zqvalue=RtuDataAddr->Task_Value[i].F65_Set_Para.FaSong_ZhouQi&0x3f;
							DebugOut("\r\n%s%d  %d %d %d ","һ�����������ϱ�", i,zqdw,zqvalue,task1_Delay_Count[i]);
							if(zqdw==0)
							{
								printf("\n\rts.Minute=%d,task2_Delay_Count[i]=%d",ts.Minute,task1_Delay_Count[i]);
								if(zqvalue!=0)
								if(((ts.Minute+60-task1_Delay_Count[i])%zqvalue)!=0)
								{
									continue;
								}
								else
								{
									task1_Delay_Count[i]=ts.Minute;
								}
							}
							if(zqdw==1)
							{
								printf("\n\rts.Hour=%d,task2_Delay_Count[i]=%d",ts.Hour,task1_Delay_Count[i]);
								if(zqvalue!=0)
									if(zqvalue==1)
									{
										if(ts.Hour>task1_Delay_Count[i])
											delta=ts.Hour-task1_Delay_Count[i];
										if(ts.Hour<task1_Delay_Count[i])
											delta=task1_Delay_Count[i]-ts.Hour;
										if((delta==1)||((delta!=0)&&(task1_Delay_Count[i]==0)))
											task1_Delay_Count[i]=ts.Hour;
										else{
//											if(delta!=0)
//												task1_Delay_Count[i]=0;
//											continue;
											if(delta!=0)
											{
												task1_Delay_Count[i]=ts.Hour;
											}
											else
												continue;
										}

									}else
									{
										//if(((ts.Hour+24-task1_Delay_Count[i])%zqvalue)!=0)
										if((((ts.Hour+24-task1_Delay_Count[i])%24)!=zqvalue)&&((ts.Hour+24-task1_Delay_Count[i])%24<zqvalue))
										{
											continue;
										}
										else
										{
											task1_Delay_Count[i]=ts.Hour;
										}
									}
							}
							if(zqdw==2)
							{
								printf("\n\rts.Day=%d,task2_Delay_Count[i]=%d",ts.Day,task1_Delay_Count[i]);
								if(zqvalue!=0)
									if(zqvalue==1)
									{
										if(ts.Day>task1_Delay_Count[i])
											delta=ts.Day-task1_Delay_Count[i];
										if(ts.Day<task1_Delay_Count[i])
											delta=task1_Delay_Count[i]-ts.Day;
										if((delta==1)||task1_Delay_Count[i]==0)
											task1_Delay_Count[i]=ts.Day;
										else{
											if(delta!=0)
												task1_Delay_Count[i]=ts.Day;
											else
												continue;
										}
									}else
									{
										//if(((ts.Day+31-task1_Delay_Count[i])%zqvalue)!=0)
										if((((ts.Day+31-task1_Delay_Count[i])%31)!=zqvalue)&&((ts.Day+31-task1_Delay_Count[i])%31<zqvalue))
										{
											continue;
										}
										else
										{
											task1_Delay_Count[i]=ts.Day;
										}
									}

							}
							if(zqdw==3)
							{
								printf("\n\rts.Month=%d,task2_Delay_Count[i]=%d",ts.Month,task1_Delay_Count[i]);
								if(zqvalue!=0)
									if(zqvalue==1)
									{
										if(ts.Month>task1_Delay_Count[i])
											delta=ts.Month-task1_Delay_Count[i];
										if(ts.Month<task1_Delay_Count[i])
											delta=task1_Delay_Count[i]-ts.Month;
										if((delta==1)||task1_Delay_Count[i]==0)
											task1_Delay_Count[i]=ts.Month;
										else{
											if(delta!=0)
												task1_Delay_Count[i]=0;
											continue;
										}
									}else
									{
										//if(((ts.Month+12-task1_Delay_Count[i])%zqvalue)!=0)
										if((((ts.Month+12-task1_Delay_Count[i])%12)!=zqvalue)&&((ts.Month+12-task1_Delay_Count[i])%12<zqvalue))
										{
											continue;
										}
										else
										{
											task1_Delay_Count[i]=ts.Month;
										}
									}
							}
							NeedTp=0;
							////FrameHeadCreate(0xc4);
							////SendBuff[SendLen++]=0x0c;//afn
							////SendBuff[SendLen++]=0x60 |(seq&0x0f);//seq

							for(j=0;j<RtuDataAddr->Task_Value[i].F65_Set_Para.ShuJv_DanYuan_Num;j++)
							{
								SelfheartCount = 0;
								if ((j%2)==0)
								{
									FrameHeadCreate(0xc4);
									SendBuff[SendLen++]=0x0c;//afn
									SendBuff[SendLen++]=0x60 |(seq&0x0f);//seq
								}

								GetDa(RtuDataAddr->Task_Value[i].F65_Set_Para.DanYuan_BiaoShi[j][0],RtuDataAddr->Task_Value[i].F65_Set_Para.DanYuan_BiaoShi[j][1]);
								GetDt(RtuDataAddr->Task_Value[i].F65_Set_Para.DanYuan_BiaoShi[j][2],RtuDataAddr->Task_Value[i].F65_Set_Para.DanYuan_BiaoShi[j][3]);
								printf("\r\n**************************5***********************************\r\n");
								for(k=0;k<64;k++)
								{
									if(DA[k]==1)
									{
										for(l=0;l<255;l++)
										{
											if(DT[l]==1)
											{//���ձ���
												SelfheartCount = 0;
												printf("\r\n**************************6***********************************\r\n");
												AutoFlg=1;
												SendBuff[SendLen++]=SetDa1(k);//Tmp130Buff[14];//da1e
												SendBuff[SendLen++]=SetDa2(k);//Tmp130Buff[15];//da2
												SendBuff[SendLen++]=SetDt1(l);//Tmp130Buff[16];//dt1
												SendBuff[SendLen++]=SetDt2(l);//Tmp130Buff[17];//dt2
												//CelectTaskData(l,k,RtuDataAddr->Task_Value[i].F65_Set_Para.Qu_Xian_ChouQu_BeiLv,0xc4);
												CallOneDataProc(l,k,RtuDataAddr->Task_Value[i].F65_Set_Para.Qu_Xian_ChouQu_BeiLv,0xc4);
												delay(30);
											}
										}
									}
								}
								delay(200);
								if ((((j+1)%2==0)||(j==(RtuDataAddr->Task_Value[i].F65_Set_Para.ShuJv_DanYuan_Num-1)))&& (AutoFlg==1))
								{
									EC();
									TP();
									FrameTailCreate_Send();
								}
							}
							////EC();
							////TP();
							////FrameTailCreate_Send();
						}
					}
				}
			}
		}
	}
	DebugOut("\r\n%s ","һ�����������ϱ�����");
		return 1;

}
void CelectTaskData(INT8U F,INT8U P,INT8U QxBl,INT8U FRM)
{
	TS ts;
	switch (F)
	{
		case 2:
			TSGet(&ts);
			MkHead(P,F,FRM);
			SendBuff[SendLen++]=((ts.Sec/10)<<4)+(ts.Sec%10);
			SendBuff[SendLen++]=((ts.Minute/10)<<4)+(ts.Minute%10);
			SendBuff[SendLen++]=((ts.Hour/10)<<4)+(ts.Hour%10);
			SendBuff[SendLen++]=((ts.Day/10)<<4)+(ts.Day%10);
			if(ts.Week==0)
				SendBuff[SendLen++]=((ts.Month/10)<<4)+(ts.Month%10)+0xe0;
			else
				SendBuff[SendLen++]=((ts.Month/10)<<4)+(ts.Month%10)+(ts.Week<<5);
			SendBuff[SendLen++]=(((ts.Year%100)/10)<<4)+(ts.Year%10);
			break;
		case 4:
			MkHead(P,F,FRM);
			SendBuff[SendLen]=0;
			if(RtuDataAddr->FuKong_Control_Value.F29_Control_Para.Valid==1)
				SendBuff[SendLen]=1;
			else
				SendBuff[SendLen]=2;
			if(RtuDataAddr->FuKong_Control_Value.F27_Control_Para.Valid==1)
				SendBuff[SendLen]=SendBuff[SendLen]|0x04;
			else
				SendBuff[SendLen]=SendBuff[SendLen]|0x8;
			SendLen++;
			break;
	}
}
INT8U CallOneDataProc(INT8U F,INT8U P,INT8U QxBl,INT8U FRM)
{
	DebugOut("\r\n%s p=%d f=%d ","����һ������",P,F);
	switch (F)
	{
	case 2://�ն�����ʱ��
		return Set_Level1_F2(F,P,FRM);
		break;
	case 3://�ն˲���״̬
		return Set_Level1_F3(F,P,FRM);
		break;
	case 4://�ն�ͨ��״̬
		return Set_Level1_F4(F,P,FRM);
		break;
	case 5://�ն˿�������״̬
		return Set_Level1_F5(F,P,FRM);
		break;
	case 6://�ն˵�ǰ����״̬
		return Set_Level1_F6(F,P,FRM);
		break;
	case 7://�ն��¼���������ǰֵ
		return Set_Level1_F7(F,P,FRM);
		break;
	case 8://�ն��¼���־״̬
		return Set_Level1_F8(F,P,FRM);
		break;
	case 9://�ն�״̬������λ��־
		return Set_Level1_F9(F,P,FRM);
		break;
	case 10://�ն�����վ���ա�����ͨ������
		return Set_Level1_F10(F,P,FRM);
		break;
	case 11://�ն˼��г���״̬��Ϣ
		return Set_Level1_F11(F,P,FRM);
		break;
	case 17://��ǰ�ܼ��й�����
		return Set_Level1_F17(F,P,FRM);
		break;
	case 18://��ǰ�ܼ��޹�����
		return Set_Level1_F18(F,P,FRM);
		break;
	case 19://�����ܼ��й����������ܡ�����1~M��
		return Set_Level1_F19(F,P,FRM);
		break;
	case 20://�����ܼ��޹����������ܡ�����1~M��
		return Set_Level1_F20(F,P,FRM);
		break;
	case 21://�����ܼ��й����������ܡ�����1~M��
		return Set_Level1_F21(F,P,FRM);
		break;
	case 22://�����ܼ��޹����������ܡ�����1~M��
		return Set_Level1_F22(F,P,FRM);
		break;
	case 23://�ն˵�ǰʣ��������ѣ�
		return Set_Level1_F23(F,P,FRM);
		break;
	case 24://��ǰ�����¸��ؿغ��ܼ��й����ʶ���ֵ
		return Set_Level1_F24(F,P,FRM);
		break;
	case 25://��ǰ���༰����/�޹����ʡ����������������ѹ��������������������ڹ���
		return Set_Level1_F25(F,P,FRM);
		break;
	case 26://A��B��C�������ͳ�����ݼ����һ�ζ����¼
		return Set_Level1_F26(F,P,FRM);
		break;
	case 27://���ܱ�����ʱ����̴��������һ�β���ʱ��
		return Set_Level1_F27(F,P,FRM);
		break;
	case 28://�������״̬�ּ����λ��־
		return Set_Level1_F28(F,P,FRM);
		break;
	case 33://��ǰ������/�޹�����ʾֵ��һ/�������޹�����ʾֵ���ܡ�����1~M��
		return Set_Level1_F33(F,P,FRM);
		break;
	case 34://��ǰ������/�޹�����ʾֵ����/�������޹�����ʾֵ���ܡ�����1~M��
		return Set_Level1_F34(F,P,FRM);
		break;
	case 35://����������/�޹��������������ʱ�䣨�ܡ�����1~M��
		return Set_Level1_F35(F,P,FRM);
		break;
	case 36://���·�����/�޹��������������ʱ�䣨�ܡ�����1~M��
		return Set_Level1_F36(F,P,FRM);
		break;
	case 37://����������/�޹�����ʾֵ��һ/�������޹�����ʾֵ���ܡ�����1~M��
		return Set_Level1_F37(F,P,FRM);
		break;
	case 38://���·�����/�޹�����ʾֵ����/�������޹�����ʾֵ���ܡ�����1~M��
		return Set_Level1_F38(F,P,FRM);
		break;
	case 39://����������/�޹��������������ʱ�䣨�ܡ�����1~M��
		return Set_Level1_F39(F,P,FRM);
		break;
	case 40://���·�����/�޹��������������ʱ�䣨�ܡ�����1~M��
		return Set_Level1_F40(F,P,FRM);
		break;
	case 41://���������й����������ܡ�����1~M��
		return Set_Level1_F41(F,P,FRM);
		break;
	case 42://���������޹����������ܡ�����1~M��
		return Set_Level1_F42(F,P,FRM);
		break;
	case 43://���շ����й����������ܡ�����1~M��
		return Set_Level1_F43(F,P,FRM);
		break;
	case 44://���շ����޹����������ܡ�����1~M��
		return Set_Level1_F44(F,P,FRM);
		break;
	case 45://���������й����������ܡ�����1~M��
		return Set_Level1_F45(F,P,FRM);
		break;
	case 46://���������޹����������ܡ�����1~M��
		return Set_Level1_F46(F,P,FRM);
		break;
	case 47://���·����й����������ܡ�����1~M��
		return Set_Level1_F47(F,P,FRM);
		break;
	case 48://���·����޹����������ܡ�����1~M��
		return Set_Level1_F48(F,P,FRM);
		break;
	case 49://��ǰ��ѹ��������λ��
		return Set_Level1_F49(F,P,FRM);
		break;
	case 57://��ǰA��B��C�����ѹ������2~N��г����Чֵ
		return Set_Level1_F57(F,P,FRM);
		break;
	case 58://��ǰA��B��C�����ѹ������2~N��г��������
		return Set_Level1_F58(F,P,FRM);
		break;
	case 65://��ǰ������Ͷ��״̬
		return Set_Level1_F65(F,P,FRM);
		break;
	case 66://��ǰ�������ۼƲ���Ͷ��ʱ��ʹ���
		return Set_Level1_F66(F,P,FRM);
		break;
	case 67://���ա����µ������ۼƲ������޹�������
		return Set_Level1_F67(F,P,FRM);
		break;
	case 73://ֱ��ģ����ʵʱ����
		return Set_Level1_F73(F,P,FRM);
		break;
	case 81://Сʱ�����ܼ��й�����
		return Set_Level1_F81(F,P,FRM);
		break;
	case 82://Сʱ�����ܼ��޹�����
		return Set_Level1_F82(F,P,FRM);
		break;
	case 83://Сʱ�����ܼ��й��ܵ�����
		return Set_Level1_F83(F,P,FRM);
		break;
	case 84://Сʱ�����ܼ��޹��ܵ�����
		return Set_Level1_F84(F,P,FRM);
		break;
	case 89://Сʱ�����й�����
		return Set_Level1_F89(F,P,QxBl,FRM);
		break;
	case 90://Сʱ����A���й�����
		return Set_Level1_F91(F,P,QxBl,FRM);
		break;
	case 91://Сʱ����B���й�����
		return Set_Level1_F91(F,P,QxBl,FRM);
		break;
	case 92://Сʱ����C���й�����
		return Set_Level1_F92(F,P,QxBl,FRM);
		break;
	case 93://Сʱ�����޹�����
		return Set_Level1_F93(F,P,QxBl,FRM);
		break;
	case 94://Сʱ����A���޹�����
		return Set_Level1_F94(F,P,QxBl,FRM);
		break;
	case 95://Сʱ����B���޹�����
		return Set_Level1_F95(F,P,QxBl,FRM);
		break;
	case 96://Сʱ����C���޹�����
		return Set_Level1_F96(F,P,QxBl,FRM);
		break;
	case 97://Сʱ����A���ѹ
		return Set_Level1_F97(F,P,QxBl,FRM);
		break;
	case 98://Сʱ����B���ѹ
		return Set_Level1_F98(F,P,QxBl,FRM);
		break;
	case 99://Сʱ����C���ѹ
		return Set_Level1_F99(F,P,QxBl,FRM);
		break;
	case 100://Сʱ����A�����
		return Set_Level1_F100(F,P,QxBl,FRM);
		break;
	case 101://Сʱ����B�����
		return Set_Level1_F101(F,P,QxBl,FRM);
		break;
	case 102://Сʱ����C�����
		return Set_Level1_F102(F,P,QxBl,FRM);
		break;
	case 103://Сʱ�����������
		return Set_Level1_F103(F,P,QxBl,FRM);
		break;
	case 105://Сʱ���������й��ܵ�����
		return Set_Level1_F105(F,P,QxBl,FRM);
		break;
	case 106://Сʱ���������޹��ܵ�����
		return Set_Level1_F106(F,P,QxBl,FRM);
		break;
	case 107://Сʱ���ᷴ���й��ܵ�����
		return Set_Level1_F107(F,P,QxBl,FRM);
		break;
	case 108://Сʱ���ᷴ���޹��ܵ�����
		return Set_Level1_F108(F,P,QxBl,FRM);
		break;
	case 109://Сʱ���������й��ܵ���ʾֵ
		return Set_Level1_F109(F,P,QxBl,FRM);
		break;
	case 110://Сʱ���������޹��ܵ���ʾֵ
		return Set_Level1_F110(F,P,QxBl,FRM);
		break;
	case 111://Сʱ���ᷴ���й��ܵ���ʾֵ
		return Set_Level1_F111(F,P,QxBl,FRM);
		break;
	case 112://Сʱ���ᷴ���޹��ܵ���ʾֵ
		return Set_Level1_F112(F,P,QxBl,FRM);
		break;
	case 113://Сʱ�����ܹ�������
		return Set_Level1_F113(F,P,QxBl,FRM);
		break;
	case 114://Сʱ����A�๦������
		return Set_Level1_F114(F,P,QxBl,FRM);
		break;
	case 115://Сʱ����B�๦������
		return Set_Level1_F115(F,P,QxBl,FRM);
		break;
	case 116://Сʱ����C�๦������
		return Set_Level1_F116(F,P,QxBl,FRM);
		break;
	case 129://��ǰ�����й�����ʾֵ���ܡ�����1--M��
		return Set_Level1_F129(F,P,FRM);
		break;
	case 130://��ǰ�����޹�������޹�1������ʾֵ���ܡ�����1--M��
		return Set_Level1_F130(F,P,FRM);
		break;
	case 131://��ǰ�����й�����ʾֵ���ܡ�����1--M��
		return Set_Level1_F131(F,P,FRM);
		break;
	case 132://��ǰ�����޹�������޹�1������ʾֵ���ܡ�����1--M��
		return Set_Level1_F132(F,P,FRM);
		break;
	case 133://��ǰһ�����޹����ܡ�����1--M��
		return Set_Level1_F133(F,P,FRM);
		break;
	case 134://��ǰ�������޹����ܡ�����1--M��
		return Set_Level1_F134(F,P,FRM);
		break;
	case 135://��ǰ�������޹����ܡ�����1--M��
		return Set_Level1_F135(F,P,FRM);
		break;
	case 136://��ǰ�������޹����ܡ�����1--M��
		return Set_Level1_F136(F,P,FRM);
		break;
	case 145://���������й��������������ʱ�䣨�ܡ�����1--M��
		return Set_Level1_F145(F,P,FRM);
		break;
	case 147://���·����й��������������ʱ�䣨�ܡ�����1--M��
		return Set_Level1_F147(F,P,FRM);
	case 166://
		return Set_Level1_F166(F,P,FRM);
		break;
	default:
	SendNAK(F,P,0x0c);
		break;
	}
	return 1;
}
void MkHead(INT8U P,INT8U F,INT8U FRM)
{
	SendBuff[SendLen++]=SetDa1(P);//Tmp130Buff[14];//da1e
	SendBuff[SendLen++]=SetDa2(P);//Tmp130Buff[15];//da2
	SendBuff[SendLen++]=SetDt1(F);//Tmp130Buff[16];//dt1
	SendBuff[SendLen++]=SetDt2(F);//Tmp130Buff[17];//dt2

}

void MkLevel1Head(INT8U P,INT8U F,INT8U FRM)
{
	FrameHeadCreate(FRM);
	SendBuff[SendLen++]=0x0c;//afn
	if(NeedTp)
		SendBuff[SendLen++]=(TestFirFin(F,P)|(seq&0x0f))|0x80;//seq
	else
		SendBuff[SendLen++]=(TestFirFin(F,P)|(seq&0x0f))&0x7f;//seq
	SendBuff[SendLen++]=SetDa1(P);//Tmp130Buff[14];//da1e
	SendBuff[SendLen++]=SetDa2(P);//Tmp130Buff[15];//da2
	SendBuff[SendLen++]=SetDt1(F);//Tmp130Buff[16];//dt1
	SendBuff[SendLen++]=SetDt2(F);//Tmp130Buff[17];//dt2
	//XXPrint("\n\r P  %x   F  %x",P,F);
}

/***********************************************************************
*4.9	����1�����ݣ�AFN=0CH��
*���ú���:CallOnelevelData();
*�ص�����:��
***********************************************************************/
void SendOneLevelData(INT8U F,INT8U P)
{
	CallOneDataProc(F,P,1,0x88);
	return;
}
INT8U memc(INT8U *Dest, INT8U *Src,INT16U len)
{
	INT8U i;
	for(i=0;i<len;i++)
	{
		Dest[i]=Src[len-i-1];
	}
	return 1;
}
/*********************************************************************8
4.9.2.3.1	F1���ն˰汾��Ϣ
��������	���ݸ�ʽ	�ֽ���
���̴���	ASCII	4
�豸���	ASCII	8
�ն������汾��	ASCII	4
�ն������������ڣ�������	���ݸ�ʽ20	3
�ն�����������Ϣ��	ASCII	11
***********************************************************************/
#ifndef BJJiChao
INT8U Set_Level1_F1(INT8U F,INT8U P,INT8U FRM)
{
	MkLevel1Head(P,F,FRM);
	memcpy(&SendBuff[SendLen],CoLtd,4);
	SendLen=SendLen+4;
	memcpy(&SendBuff[SendLen],RtuDataAddr->FkComm_Value.DevCode,8);
	SendLen=SendLen+8;
	memcpy(&SendBuff[SendLen],ProgVer,4);
	SendLen=SendLen+4;
	memcpy(&SendBuff[SendLen],ProgDate,3);
	SendLen=SendLen+3;
	memcpy(&SendBuff[SendLen],RongLiang,11);
	SendLen=SendLen+11;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
#endif
/*********************************************************************8
4.9.2.3.2	F2���ն�����ʱ��
��������	���ݸ�ʽ	�ֽ���
�ն�����ʱ��	���ݸ�ʽ01	6
***********************************************************************/
INT8U Set_Level1_F2(INT8U F,INT8U P,INT8U FRM)
{
	TS ts;
	TSGet(&ts);
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	SendBuff[SendLen++]=((ts.Sec/10)<<4)+(ts.Sec%10);
	SendBuff[SendLen++]=((ts.Minute/10)<<4)+(ts.Minute%10);
	SendBuff[SendLen++]=((ts.Hour/10)<<4)+(ts.Hour%10);
	SendBuff[SendLen++]=((ts.Day/10)<<4)+(ts.Day%10);
	if(ts.Week==0)
	{
		SendBuff[SendLen++]=((ts.Month/10)<<4)+(ts.Month%10)+0xe0;
	}
	else
	{
		SendBuff[SendLen++]=((ts.Month/10)<<4)+(ts.Month%10)+(ts.Week<<5);
	}
	SendBuff[SendLen++]=(((ts.Year%100)/10)<<4)+(ts.Year%10);
	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
#ifndef BJJiChao
/***********************************************************************
4.9.2.3.3	F3���ն˲���״̬
��������	���ݸ�ʽ	�ֽ���
����ӳ���	BS248	31
D0~D247��Ӧ4.5���ò�����AFN=04H�������е�F1~F248������Ĳ�������"1"���ն����и����������"0"���ն��޸������ݡ�
***************************************************************************/
INT8U Set_Level1_F3(INT8U F,INT8U P,INT8U FRM)
{
	GetSetStat();
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	memcpy(&SendBuff[SendLen],SetAvailable,31);
	SendLen=SendLen+31;
	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
/********************************************************************
4.9.2.3.4	F4���ն�ͨ��״̬
��������	�ֽ���
D7	D6	D5	D4	D3	D2	D1	D0
����	����	�����M��ֹͨ��	�����M��ֹ�����ϱ�	1
�����M��ֹ�����ϱ���
D1	D0	˵��
0	0	��Ч
0	1	���������ϱ�
1	0	��ֹ�����ϱ�
1	1	��Ч
�����M��ֹͨ����
D3	D2	˵��
0	0	��Ч
0	1	����ͨ��
1	0	��ֹͨ��
1	1	��Ч
*********************************************************************/
INT8U Set_Level1_F4(INT8U F,INT8U P,INT8U FRM)
{
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	SendBuff[SendLen]=0;
	if(RtuDataAddr->FuKong_Control_Value.F29_Control_Para.Valid==1)
	{
		SendBuff[SendLen]=1;
	}
	else
	{
		SendBuff[SendLen]=2;
	}

	if(RtuDataAddr->FuKong_Control_Value.F27_Control_Para.Valid==1)
	{
		SendBuff[SendLen]=SendBuff[SendLen]|0x04;
	}
	else
	{
		SendBuff[SendLen]=SendBuff[SendLen]|0x8;
	}
	SendLen++;
	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
/********************************************************************8
4.9.2.3.5	F5���ն˿�������״̬
��������	���ݸ�ʽ	�ֽ���	˵��
���硢�޳��ʹ߷Ѹ澯Ͷ��״̬	BS8	1
�ܼ�����Ч��־λ	BS8	1
���ض�ֵ������	BIN	1	�ܼ���1
����ʱ����Ч��־λ	BS8	1
����״̬	BS8	1
���״̬	BS8	1
�����ִ�״̬	BS8	1
����ִ�״̬	BS8	1
����	����	����	����
���ض�ֵ������	BIN	1	�ܼ���n
����ʱ����Ч��־λ	BS8	1
����״̬	BS8	1
���״̬	BS8	1
�����ִ�״̬	BS8	1
����ִ�״̬	BS8	1
���硢�޳��ʹ߷Ѹ澯״̬��D0~D2��λ��ʾ����"1"��Ͷ�룬��"0"�������
--D0������״̬
--D1���޳�״̬
--D2���߷Ѹ澯״̬
--D3~D7�����á�

  �ܼ�����Ч��־λ��D0~D7��λ��ʾ1~8�ܼ��飻��"1"����������Ӧ�ܼ���Ŀ�������״̬����"0"����������Ӧ�ܼ���Ŀ�������״̬��Wyh?
  ���ض�ֵ�����ţ�D0~D1����ʾ��Ͷ��Ĺ��ض�ֵ�����š�D2~D7�����á�
  ����ʱ����Ч��־λ��D0~D7��λ��ʾ1~8ʱ�ο�Ͷ�����Чʱ�Σ���"1"����Ч����"0"����Ч��
  ����״̬��D0~D7��λ��ʾ����"1"��Ͷ�룬��"0"�������
  --D0��ʱ�ο�
  --D1�����ݿ�
  --D2��Ӫҵ��ͣ��
  --D3����ǰ�����¸���
  --D4~D7�����á�
  ���״̬��D0~D7��λ��ʾ����"1"��Ͷ�룬��"0"�������
  --D0���µ��
  --D1�������
  --D2-D7�����á�
  �����ִ�״̬��D0~D7��λ��ʾ1~8�ִο��صĹ����ܿ�״̬����"1"���ܿأ���"0"�����ܿأ�
  ����ִ�״̬��D0~D7��λ��ʾ1~8�ִο��صĵ���ܿ�״̬����"1"���ܿأ���"0"�����ܿء�
***********************************************************************/
INT8U Set_Level1_F5(INT8U F,INT8U P,INT8U FRM)
{
	INT8U i;
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	SendBuff[SendLen++]=RtuDataAddr->Fk_Control_Set_now.BaoDian_TiChu_Gaojing_Tou;
	SendBuff[SendLen++]=RtuDataAddr->Fk_Control_Set_now.ZongJia_Valid;
	for(i=0;i<ZongJia_Max;i++)
	{
		if(RtuDataAddr->Fk_Control_Set_now.ZongJia_Valid&(1<<i))
		{
			SendBuff[SendLen++]=RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[i].FangAnNo;
			SendBuff[SendLen++]=RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[i].GongKong_YouXiao;
			SendBuff[SendLen++]=RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[i].GongKong_Stat;
			SendBuff[SendLen++]=RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[i].DianKong_Stat;
			SendBuff[SendLen++]=RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[i].GongKongLunCi_Stat;
			SendBuff[SendLen++]=RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[i].DianKongLunCi_Stat;
		}
	}
	if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
	return 1;
}
/********************************************************************8
4.9.2.3.6	F6���ն˵�ǰ����״̬
��������	���ݸ�ʽ	�ֽ���	˵��
ң����բ���״̬	BS8	1
��ǰ�߷Ѹ澯״̬	BS8	1
�ܼ�����Ч��־λ	BS8	1
��ǰ���ض�ֵ	���ݸ�ʽ02	2	�ܼ���1
��ǰ�����¸��ظ���ϵ��	���ݸ�ʽ04	1
������բ���״̬	BS8	1
�µ����բ���״̬	BS8	1
�������բ���״̬	BS8	1
����Խ�޸澯״̬	BS8	1
���Խ�޸澯״̬	BS8	1
����	����	����	����
��ǰ���ض�ֵ	���ݸ�ʽ02	2	�ܼ���n
��ǰ�����¸��ظ���ϵ��	���ݸ�ʽ04	1
������բ���״̬	BS8	1
�µ����բ���״̬	BS8	1
�������բ���״̬	BS8	1
����Խ�޸澯״̬	BS8	1
���Խ�޸澯״̬	BS8	1
ң����բ���״̬��D0~D7�ֱ�λ��ʾ�ն�1~8�ִ�ң����բ���״̬��
��"1"����բ״̬����"0"����բ״̬��
��ǰ�߷Ѹ澯״̬����D0��ʾ�ն˵�ǰ�Ƿ��ڴ߷Ѹ澯״̬��
��"1"���ն˴��ڴ߷Ѹ澯״̬����"0"���ն�δ���ڴ߷Ѹ澯״̬��
�ܼ�����Ч��־λ��D0~D7��λ��ʾ1~8�ܼ��飻��"1"����������Ӧ�ܼ���ĵ�ǰ����״̬��
��"0"����������Ӧ�ܼ���ĵ�ǰ����״̬��
������բ���״̬��D0~D7�ֱ��ʾ�ն�1~8�ִι�����բ���״̬��
��"1"�����ڹ�����բ״̬����"0"��δ���ڹ�����բ״̬��
�µ����բ���״̬��D0~D7�ֱ��ʾ�ն�1~8�ִ��µ����բ���״̬��
��"1"�������µ����բ״̬����"0"��δ�����µ����բ״̬��
�������բ���״̬��D0~D7�ֱ��ʾ�ն�1~8�ִι������բ���״̬��
��"1"�����ڹ������բ״̬����"0"��δ���ڹ������բ״̬��
����Խ�޸澯״̬����λ��ʾ����"1"������ĳ�ֹ���Խ�޸澯״̬����"0"��δ������Ӧ״̬��
--D0��ʱ�ο�
--D1�����ݿ�
--D2��Ӫҵ��ͣ��
--D3����ǰ�����¸���
--D4~D7�����á�
���Խ�޸澯״̬����λ��ʾ����"1"������ĳ�ֵ��Խ�޸澯״̬����"0"��δ������Ӧ״̬��
--D0���µ��
--D1�������
--D2~D7�����á�
***********************************************************************/
INT8U Set_Level1_F6(INT8U F,INT8U P,INT8U FRM)
{
	INT8U i;
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	SendBuff[SendLen++]=RtuDataAddr->Fk_Control_Value_now.Yaokong_TiaoZha_Stat;
	SendBuff[SendLen++]=RtuDataAddr->Fk_Control_Value_now.Now_CuiFei_Gaojing_Stat;
	SendBuff[SendLen++]=RtuDataAddr->Fk_Control_Value_now.ZongJia_Valid_Stat;
	for(i=0;i<ZongJia_Max;i++)
	{
		if(RtuDataAddr->Fk_Control_Value_now.ZongJia_Valid_Stat&(1<<i))
		{
			memcpy(&SendBuff[SendLen],&RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].Now_GongKong_DingZhi[0],2);
			SendLen=SendLen+2;
			SendBuff[SendLen++]=RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].Now_GomhLv_Xiafukong_xishu;
			//SendBuff[SendLen++]=RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].GongKong_Tiaozha_Stat;
//			//XXPrint("\n\rF6-GongKongStattmp[%d]==%d  YueDianKong_Tiaozha_Stat==%d  GouDiankong_TiaoZha_Stat==%d GongKongYuexian_Alarm_Stat==%d  DianKongYuexian_Alarm_Stat==%d",
//												i,RtuDataAddr->GongKongStattmp[i],
//												RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].YueDianKong_Tiaozha_Stat,
//												RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].GouDiankong_TiaoZha_Stat,
//												RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].GongKongYuexian_Alarm_Stat,
//												RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].DianKongYuexian_Alarm_Stat);

			SendBuff[SendLen++]=RtuDataAddr->GongKongStattmp[i];
			SendBuff[SendLen++]=RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].YueDianKong_Tiaozha_Stat;
			SendBuff[SendLen++]=RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].GouDiankong_TiaoZha_Stat;
			SendBuff[SendLen++]=RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].GongKongYuexian_Alarm_Stat;
			SendBuff[SendLen++]=RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].DianKongYuexian_Alarm_Stat;
		}
	}
	if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
	return 1;
}
/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F7(INT8U F,INT8U P,INT8U FRM)
{
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	SendBuff[SendLen++]=RtuDataAddr->EC1;
	SendBuff[SendLen++]=RtuDataAddr->EC2;
	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F8(INT8U F,INT8U P,INT8U FRM)
{
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	memcpy(&SendBuff[SendLen],RtuDataAddr->ERCBiaoZhi,8);
	SendLen=SendLen+8;
	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F9(INT8U F,INT8U P,INT8U FRM)
{
	unsigned char yx[5],i;
	unsigned char NOwYx=0;
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	yx[0] = RtuDataAddr->NowYx>>3 &0x01;
	yx[1] = RtuDataAddr->NowYx>>2 &0x01;
	yx[2] = RtuDataAddr->NowYx>>1 &0x01;
	yx[3] = RtuDataAddr->NowYx>>0 &0x01;
	//yx[4] = RtuDataAddr->NowYx>>6 &0x01;
	//yx[5] = RtuDataAddr->NowYx>>5 &0x01;
	yx[4] = RtuDataAddr->NowYx>>4 &0x01;

	for(i=0;i<5;i++)
		NOwYx = NOwYx | yx[i]<<i;
	SendBuff[SendLen++]=NOwYx;
	yx[0] = RtuDataAddr->Yx_Changed>>3 &0x01;
	yx[1] = RtuDataAddr->Yx_Changed>>2 &0x01;
	yx[2] = RtuDataAddr->Yx_Changed>>1 &0x01;
	yx[3] = RtuDataAddr->Yx_Changed>>0 &0x01;
	yx[4] = RtuDataAddr->Yx_Changed>>4 &0x01;
	NOwYx = 0;
	for(i=0;i<5;i++)
		NOwYx = NOwYx | yx[i]<<i;
	SendBuff[SendLen++]=NOwYx;
	RtuDataAddr->Yx_Changed=0;
	if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
	return 1;
}

INT8U Set_Level1_F10(INT8U F,INT8U P,INT8U FRM)
{
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	SendBuff[SendLen++]=(RtuDataAddr->Fm_Save_Eve.DayLiuLiang)&0xff;
	SendBuff[SendLen++]=(RtuDataAddr->Fm_Save_Eve.DayLiuLiang>>8)&0xff;
	SendBuff[SendLen++]=(RtuDataAddr->Fm_Save_Eve.DayLiuLiang>>16)&0xff;
	SendBuff[SendLen++]=(RtuDataAddr->Fm_Save_Eve.DayLiuLiang>>24)&0xff;
	SendBuff[SendLen++]=(RtuDataAddr->Fm_Save_Eve.yueLiuLiang)&0xff;
	SendBuff[SendLen++]=(RtuDataAddr->Fm_Save_Eve.yueLiuLiang>>8)&0xff;
	SendBuff[SendLen++]=(RtuDataAddr->Fm_Save_Eve.yueLiuLiang>>16)&0xff;
	SendBuff[SendLen++]=(RtuDataAddr->Fm_Save_Eve.yueLiuLiang>>24)&0xff;

	if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level1_F11(INT8U F,INT8U P,INT8U FRM)
{
	////if(AutoFlg==0)
	////	MkLevel1Head(P,F,FRM);
	////if (AutoFlg!=0) return 1;
	////	EC();
	////	TP();
	////	FrameTailCreate_Send();
	////SendNAK(F,P,0x0c);
	return 0;
}
/**********************************************************************
��������	���ݸ�ʽ	��λ	�ֽ���
��ǰ�ܼ��й�����	���ݸ�ʽ02	kW	2
***********************************************************************/
INT8U Set_Level1_F17(INT8U F,INT8U P,INT8U FRM)
{
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	//XXPrint("\n\rF17-P %d  zjno %d",RtuDataAddr->Real_Zj_Value[P-1].P,P-1);
	Create_Data_Type02(RtuDataAddr->Real_Zj_Value[P-1].P,&SendBuff[SendLen]);
	SendLen=SendLen+2;

	if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
	return 1;
}
/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F18(INT8U F,INT8U P,INT8U FRM)
{
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	Create_Data_Type02(RtuDataAddr->Real_Zj_Value[P-1].Q,&SendBuff[SendLen]);
	SendLen=SendLen+2;

	if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
	return 1;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F19(INT8U F,INT8U P,INT8U FRM)
{
	INT8U i;
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	SendBuff[SendLen++]=FeiLvNum;
	//XXPrint("\n\rF19-P_ALL %d  Day %d",RtuDataAddr->Real_Zj_Value[P-1].P_All,RtuDataAddr->Day_Zj_Value[P-1].P_All);
	Create_Data_Type03((RtuDataAddr->Real_Zj_Value[P-1].P_All-RtuDataAddr->Day_Zj_Value[P-1].P_All),&SendBuff[SendLen]);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
		Create_Data_Type03((RtuDataAddr->Real_Zj_Value[P-1].P_F[i]-RtuDataAddr->Day_Zj_Value[P-1].P_F[i]),&SendBuff[SendLen]);
		SendLen=SendLen+4;
	}
	if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
	return 1;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F20(INT8U F,INT8U P,INT8U FRM)
{
	INT8U i;
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	SendBuff[SendLen++]=FeiLvNum;
	Create_Data_Type03((RtuDataAddr->Real_Zj_Value[P-1].Q_All-RtuDataAddr->Day_Zj_Value[P-1].Q_All),&SendBuff[SendLen]);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
		Create_Data_Type03((RtuDataAddr->Real_Zj_Value[P-1].Q_F[i]-RtuDataAddr->Day_Zj_Value[P-1].Q_F[i]),&SendBuff[SendLen]);
		SendLen=SendLen+4;
	}
	if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
	return 1;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F21(INT8U F,INT8U P,INT8U FRM)
{
	INT8U i;
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	SendBuff[SendLen++]=FeiLvNum;
	Create_Data_Type03((RtuDataAddr->Real_Zj_Value[P-1].P_All-RtuDataAddr->Yue_Zj_Value[P-1].P_All),&SendBuff[SendLen]);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
		Create_Data_Type03((RtuDataAddr->Real_Zj_Value[P-1].P_F[i]-RtuDataAddr->Yue_Zj_Value[P-1].P_F[i]),&SendBuff[SendLen]);
		SendLen=SendLen+4;
	}

	if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
	return 1;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F22(INT8U F,INT8U P,INT8U FRM)
{
	INT8U i;
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	SendBuff[SendLen++]=FeiLvNum;
	Create_Data_Type03((RtuDataAddr->Real_Zj_Value[P-1].Q_All-RtuDataAddr->Yue_Zj_Value[P-1].Q_All),&SendBuff[SendLen]);
	SendLen=SendLen+4;
	for(i=0;i<FeiLvNum;i++)
	{
		Create_Data_Type03((RtuDataAddr->Real_Zj_Value[P-1].Q_F[i]-RtuDataAddr->Yue_Zj_Value[P-1].Q_F[i]),&SendBuff[SendLen]);
		SendLen=SendLen+4;
	}

	if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
	return 1;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F23(INT8U F,INT8U P,INT8U FRM)
{
	//long temp;
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	//if(RtuDataAddr->Zj_Control_Value[P-1].F47_Set_Para.Valid==1)//�˴��������ε�����γ��վ���й�����·�ʱ�����в�F23��F47���вⲻ�ɹ����·����ɹ���
	{
		//temp=GetdataType03(RtuDataAddr->Zj_Control_Value[P-1].F47_Set_Para.Gou_DIan_Value);
		Create_Data_Type03(RtuDataAddr->Real_Zj_Value[P-1].ShengYuDianLiang,&SendBuff[SendLen]);
		SendLen=SendLen+4;
	}

	if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
	return 1;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F24(INT8U F,INT8U P,INT8U FRM)
{///////��ʱ�������ն˲�֧�ֹ����¸��ؿغ��ܼ��й����ʶ���ֵ
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	SendLen=SendLen+2;

	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F25(INT8U F,INT8U P,INT8U FRM)
{
		INT32U PS,PSA,PSB,PSC;
		float PS1,PSA1,PSB1,PSC1;
		if(AutoFlg==0)
			MkLevel1Head(P,F,FRM);
		//if(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Valid==1)
		{
			PS1=sqrt((RtuDataAddr->DD_Device_BiaoShi_Value[P-1].P/10)*(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].P/10)
				+ (RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Q/10)*(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Q/10));
			PS=(INT32U)PS1;
			PS=PS*10;
			PSA1=sqrt((RtuDataAddr->DD_Device_BiaoShi_Value[P-1].PA/10)*(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].PA/10)
				+ (RtuDataAddr->DD_Device_BiaoShi_Value[P-1].QA/10)*(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].QA/10));
			PSA=(INT32U)PSA1;
			PSA=PSA*10;
			PSB1=sqrt((RtuDataAddr->DD_Device_BiaoShi_Value[P-1].PB/10)*(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].PB/10)
				+ (RtuDataAddr->DD_Device_BiaoShi_Value[P-1].QB/10)*(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].QB/10));
			PSB=(INT32U)PSB1;
			PSB=PSB*10;
			PSC1=sqrt((RtuDataAddr->DD_Device_BiaoShi_Value[P-1].PC/10)*(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].PC/10)
				 + (RtuDataAddr->DD_Device_BiaoShi_Value[P-1].QC/10)*(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].QC/10));
			PSC=(INT32U)PSC1;
			PSC=PSC*10;
			memcpy(&SendBuff[SendLen],&RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Chao_Time.BCD01,sizeof(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Chao_Time));
			SendLen=SendLen+sizeof(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Chao_Time);
			//XXPrint("\n\r F25- P %d  %d",RtuDataAddr->DD_Device_BiaoShi_Value[P-1].P,P-1);

			//if(RtuDataAddr->z_P_all[P-1]>0)
			//	INT32ToBCD(72000,&SendBuff[SendLen],3);
			//else
				INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].P,&SendBuff[SendLen],3);
			SendLen=SendLen+3;
			INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].PA,&SendBuff[SendLen],3);
			SendLen=SendLen+3;
			INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].PB,&SendBuff[SendLen],3);
			SendLen=SendLen+3;
			INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].PC,&SendBuff[SendLen],3);
			SendLen=SendLen+3;

			INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Q,&SendBuff[SendLen],3);
			SendLen=SendLen+3;
			INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].QA,&SendBuff[SendLen],3);
			SendLen=SendLen+3;
			INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].QB,&SendBuff[SendLen],3);
			SendLen=SendLen+3;
			INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].QC,&SendBuff[SendLen],3);
			SendLen=SendLen+3;

			INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Cos,&SendBuff[SendLen],2);
			SendLen=SendLen+2;
			INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].CosA,&SendBuff[SendLen],2);
			SendLen=SendLen+2;
			INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].CosB,&SendBuff[SendLen],2);
			SendLen=SendLen+2;
			INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].CosC,&SendBuff[SendLen],2);
			SendLen=SendLen+2;

			INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].VA,&SendBuff[SendLen],2);
			SendLen=SendLen+2;
			INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].VB,&SendBuff[SendLen],2);
			SendLen=SendLen+2;
			INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].VC,&SendBuff[SendLen],2);
			SendLen=SendLen+2;
			INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[P-1].IA*10),&SendBuff[SendLen],3);
			SendLen=SendLen+3;
			INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[P-1].IB*10),&SendBuff[SendLen],3);
			SendLen=SendLen+3;
			INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[P-1].IC*10),&SendBuff[SendLen],3);
			SendLen=SendLen+3;
			INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[P-1].IL*10),&SendBuff[SendLen],3);
			SendLen=SendLen+3;

			INT32ToBCD(PS,&SendBuff[SendLen],3);
			SendLen=SendLen+3;
			INT32ToBCD(PSA,&SendBuff[SendLen],3);
			SendLen=SendLen+3;
			INT32ToBCD(PSB,&SendBuff[SendLen],3);
			SendLen=SendLen+3;
			INT32ToBCD(PSC,&SendBuff[SendLen],3);
			SendLen=SendLen+3;

			if (AutoFlg!=0) return 1;
			EC();
			TP();
			FrameTailCreate_Send();
			return 1;
		}
			////SendNAK(F,P,0x0c);
		return 0;
}
#endif
/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F26(INT8U F,INT8U P,INT8U FRM)
{//DD_Device_BianLiang_Shuju_Value
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	if(RtuDataAddr->DD_BianLiang_Shuju[P-1].Valid==1)
	{
		memcpy(&SendBuff[SendLen],&RtuDataAddr->DD_BianLiang_Shuju[P-1].Chao_Time.BCD01,5);
		SendLen=SendLen+5;
		memcpy(&SendBuff[SendLen],&RtuDataAddr->DD_BianLiang_Shuju[P-1].Duanxiang_All,52);
		SendLen=SendLen+52;

		if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
		return 1;
	}
	////SendNAK(F,P,0x0c);
	////return 0;
	memset(&SendBuff[SendLen],0xee,57);
	SendLen = SendLen + 57;
	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F27(INT8U F,INT8U P,INT8U FRM)
{//DD_Device_CanLiang_Shuju_Value
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	if(RtuDataAddr->DD_BianLiang_Shuju[P-1].Valid==1)
	{
		memcpy(&SendBuff[SendLen],&RtuDataAddr->DD_BianLiang_Shuju[P-1].Chao_Time.BCD01,5);
		SendLen=SendLen+5;
		/*******************************************�˴�����ʱ�䴦��********************************/
		memcpy(&SendBuff[SendLen],&RtuDataAddr->DD_BianLiang_Shuju[P-1].NowDB_Time.BCDSec,6);
		SendLen=SendLen+6;
//liujia �����¶���ı����кö�û�и�ֵ     ������
		memcpy(&SendBuff[SendLen],RtuDataAddr->DD_BianLiang_Shuju[P-1].BatteryTime,4);
		SendLen=SendLen+4;
		memcpy(&SendBuff[SendLen],RtuDataAddr->DD_BianLiang_Shuju[P-1].ProgNum,3);
		SendLen=SendLen+3;
		memcpy(&SendBuff[SendLen],RtuDataAddr->DD_BianLiang_Shuju[P-1].LastProg_Time,6);
		SendLen=SendLen+6;
		memcpy(&SendBuff[SendLen],RtuDataAddr->DD_BianLiang_Shuju[P-1].DbQingNum,3);
		SendLen=SendLen+3;
		memcpy(&SendBuff[SendLen],RtuDataAddr->DD_BianLiang_Shuju[P-1].LastDbQing_Time,6);
		SendLen=SendLen+6;
		memcpy(&SendBuff[SendLen],RtuDataAddr->DD_BianLiang_Shuju[P-1].ZeroNum,3);
		SendLen=SendLen+3;
		memcpy(&SendBuff[SendLen],RtuDataAddr->DD_BianLiang_Shuju[P-1].LastZero_Time,6);
		SendLen=SendLen+6;
		memcpy(&SendBuff[SendLen],RtuDataAddr->DD_BianLiang_Shuju[P-1].EventQingNum,3);
		SendLen=SendLen+3;
		memcpy(&SendBuff[SendLen],RtuDataAddr->DD_BianLiang_Shuju[P-1].LastEventQing_Time,6);
		SendLen=SendLen+6;
		memcpy(&SendBuff[SendLen],RtuDataAddr->DD_BianLiang_Shuju[P-1].JiaoshiNum,3);
		SendLen=SendLen+3;
		memcpy(&SendBuff[SendLen],RtuDataAddr->DD_BianLiang_Shuju[P-1].LastJiaoshi_Time,6);
		SendLen=SendLen+6;

		if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
		return 1;
	}
		////SendNAK(F,P,0x0c);
	////return 0;
	memset(&SendBuff[SendLen],0xee,60);
	SendLen = SendLen + 60;
	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level1_F28(INT8U F,INT8U P,INT8U FRM)
{//DD_Device_CanLiang_Shuju_Value
	int i;
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	if(RtuDataAddr->DD_BianLiang_Shuju[P-1].Valid==1)
	{
		memcpy(&SendBuff[SendLen],&RtuDataAddr->DD_BianLiang_Shuju[P-1].Chao_Time.BCD01,5);
		SendLen=SendLen+5;
		for(i=0;i<7;i++)
		{
			memcpy(&SendBuff[SendLen],&RtuDataAddr->DD_BianLiang_Shuju[P-1].Dianbiaostat_Flag[i][0],1);
			SendLen=SendLen+1;
			memcpy(&SendBuff[SendLen],&RtuDataAddr->DD_BianLiang_Shuju[P-1].Dianbiaostat_Flag[i][1],1);
			SendLen=SendLen+1;
		}
		for(i=0;i<7;i++)
		{
			memcpy(&SendBuff[SendLen],&RtuDataAddr->DD_BianLiang_Shuju[P-1].Dian_biao_stat[i][0],1);
			SendLen=SendLen+1;
			memcpy(&SendBuff[SendLen],&RtuDataAddr->DD_BianLiang_Shuju[P-1].Dian_biao_stat[i][1],1);
			SendLen=SendLen+1;
		}

		if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
		return 1;
	}
	////SendNAK(F,P,0x0c);
	////return 0;
	memset(&SendBuff[SendLen],0xee,33);
	SendLen = SendLen + 33;
	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}

/**********************************************************************
***********************************************************************/
/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F33(INT8U F,INT8U P,INT8U FRM)
{
	INT8U i;
	if (AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	if(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Valid==1)
	{
		memcpy(&SendBuff[SendLen],&RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Chao_Time.BCD01,sizeof(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Chao_Time));
		SendLen=SendLen+5;
		SendBuff[SendLen++]=4;

		if(RtuDataAddr->z_P_all[P-1]>0)
		{
			//RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Z_P_All = RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Z_P_All*10 + RtuDataAddr->z_P_all[P-1];
			INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Z_P_All)*10,&SendBuff[SendLen],5);
			//INT32ToBCD((2160)*10,&SendBuff[SendLen],5);
		}
		else
		{
			SendBuff[SendLen++]=0;//liujia
			INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Z_P_All,&SendBuff[SendLen],4);
		}
		//XXPrint("\n\r F33- Z_P_ALL %d",RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Z_P_All);
		//INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Z_P_All,&SendBuff[SendLen],4);//�����й���
		SendLen=SendLen+4;
		for(i=0;i<FeiLvNum;i++)
		{
			SendBuff[SendLen++]=0;
			INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Z_P_F[i],&SendBuff[SendLen],4);//�����й���4����
			SendLen=SendLen+4;
		}
		INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Z_Q_All,&SendBuff[SendLen],4);//�����޹���
		SendLen=SendLen+4;
		for(i=0;i<FeiLvNum;i++)
		{
			INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Z_Q_F[i],&SendBuff[SendLen],4);//�����޹�4����
			SendLen=SendLen+4;
		}
		INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].X1_Q_All,&SendBuff[SendLen],4);//һ�����޹���
		SendLen=SendLen+4;
		for(i=0;i<FeiLvNum;i++)
		{
			INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].X1_F_Q[i],&SendBuff[SendLen],4);//һ�����޹�4����
			SendLen=SendLen+4;
		}
		INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].X4_Q_All,&SendBuff[SendLen],4);//�������޹���
		SendLen=SendLen+4;
		for(i=0;i<FeiLvNum;i++)
		{
			INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].X4_F_Q[i],&SendBuff[SendLen],4);//�������޹�4����
			SendLen=SendLen+4;
		}
		if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
		return 1;
	}
		////SendNAK(F,P,0x0c);
	////return 0;
	memset(&SendBuff[SendLen],0xee,5);
	SendLen = SendLen + 5;
	SendBuff[SendLen++]=4;
	memset(&SendBuff[SendLen],0xee,85);
	SendLen = SendLen + 85;
	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F34(INT8U F,INT8U P,INT8U FRM)
{
	INT8U i;
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	if(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Valid==1)
	{
		memcpy(&SendBuff[SendLen],&RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Chao_Time.BCD01,sizeof(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Chao_Time));
		SendLen=SendLen+5;
		SendBuff[SendLen++]=4;
		SendBuff[SendLen++]=0;//liujia
		INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].F_P_All,&SendBuff[SendLen],4);
		SendLen=SendLen+4;
		for(i=0;i<FeiLvNum;i++)
		{
			SendBuff[SendLen++]=0;
			INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].F_P_F[i],&SendBuff[SendLen],4);
			SendLen=SendLen+4;
		}

		INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].F_Q_All,&SendBuff[SendLen],4);
		SendLen=SendLen+4;
		for(i=0;i<FeiLvNum;i++)
		{
			INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].F_Q_F[i],&SendBuff[SendLen],4);
			SendLen=SendLen+4;
		}

		INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].X2_Q_All,&SendBuff[SendLen],4);
		SendLen=SendLen+4;
		for(i=0;i<FeiLvNum;i++)
		{
			INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].X2_F_Q[i],&SendBuff[SendLen],4);
			SendLen=SendLen+4;
		}

		INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].X3_Q_All,&SendBuff[SendLen],4);
		SendLen=SendLen+4;
		for(i=0;i<FeiLvNum;i++)
		{
			INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].X3_F_Q[i],&SendBuff[SendLen],4);
			SendLen=SendLen+4;
		}

		if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
		return 1;
	}
		////SendNAK(F,P,0x0c);
	////return 0;
	memset(&SendBuff[SendLen],0xee,5);
	SendLen = SendLen + 5;
	SendBuff[SendLen++]=4;
	memset(&SendBuff[SendLen],0xee,85);
	SendLen = SendLen + 85;
	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F35(INT8U F,INT8U P,INT8U FRM)
{
	INT8U i;
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);

	//if(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].Valid==1)
	{
		memcpy(&SendBuff[SendLen],&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].Chao_Time.BCD01,sizeof(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].Chao_Time));
		SendLen=SendLen+5;
		SendBuff[SendLen++]=4;

		//XXPrint("F35-Z_P_X_All %d  %d",RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].Z_P_X_All,P-1);
		//if(RtuDataAddr->z_P_all[P-1]>0)
		//	INT32ToBCD(72000,&SendBuff[SendLen],3);
		//else
			INT32ToBCD(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].Z_P_X_All,&SendBuff[SendLen],3);
		SendLen=SendLen+3;
		for(i=0;i<FeiLvNum;i++)
		{
			INT32ToBCD(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].Z_P_X_F[i],&SendBuff[SendLen],3);
			SendLen=SendLen+3;
		}
		memcpy(&SendBuff[SendLen],&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].Time_Z_P_X_All[0],4);
		SendLen=SendLen+4;
		for(i=0;i<FeiLvNum;i++)
		{
			memcpy(&SendBuff[SendLen],&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].Time_Z_P_X_F[i][0],4);
			SendLen=SendLen+4;
		}

		INT32ToBCD(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].Z_Q_X_All,&SendBuff[SendLen],3);
		SendLen=SendLen+3;
		for(i=0;i<FeiLvNum;i++)
		{
			INT32ToBCD(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].Z_Q_X_F[i],&SendBuff[SendLen],3);
			SendLen=SendLen+3;
		}

		memcpy(&SendBuff[SendLen],&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].Time_Z_Q_X_All[0],sizeof(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].Time_Z_Q_X_All));
		SendLen=SendLen+4;
		for(i=0;i<FeiLvNum;i++)
		{
			memcpy(&SendBuff[SendLen],&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].Time_Z_Q_X_F[i][0],sizeof(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].Time_Z_Q_X_F[i]));
			SendLen=SendLen+4;
		}

		if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
		return 1;
	}
		////SendNAK(F,P,0x0c);
	////return 0;
}

INT8U Set_Level1_F145(INT8U F,INT8U P,INT8U FRM)
{
	INT8U i;
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	if(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].Valid==1)
	{
		memcpy(&SendBuff[SendLen],&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].Chao_Time.BCD01,sizeof(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].Chao_Time));
		SendLen=SendLen+5;
		SendBuff[SendLen++]=4;
		INT32ToBCD(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].Z_P_X_All,&SendBuff[SendLen],3);
		SendLen=SendLen+3;
		memcpy(&SendBuff[SendLen],&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].Time_Z_P_X_All[0],4);
		SendLen=SendLen+4;
		/*for(i=0;i<FeiLvNum;i++)
		{
			INT32ToBCD(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].Z_P_X_F[i],&SendBuff[SendLen],3);
			SendLen=SendLen+3;
		}
		for(i=0;i<FeiLvNum;i++)
		{
			memcpy(&SendBuff[SendLen],&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].Time_Z_P_X_F[i][0],4);
			SendLen=SendLen+4;
		}*/
		for(i=0;i<FeiLvNum;i++)
		{
			INT32ToBCD(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].Z_P_X_F[i],&SendBuff[SendLen],3);
			SendLen=SendLen+3;
			memcpy(&SendBuff[SendLen],&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].Time_Z_P_X_F[i][0],4);
			SendLen=SendLen+4;
		}

		if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
		return 1;
	}
		////SendNAK(F,P,0x0c);
	////return 0;
	memset(&SendBuff[SendLen],0xee,5);
	SendLen = SendLen + 5;
	SendBuff[SendLen++]=4;
	memset(&SendBuff[SendLen],0xee,35);
	SendLen = SendLen + 35;
	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
INT8U Set_Level1_F147(INT8U F,INT8U P,INT8U FRM)
{
	INT8U i;
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	if(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].Valid==1)
	{
		memcpy(&SendBuff[SendLen],&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].Chao_Time.BCD01,sizeof(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].Chao_Time));
		SendLen=SendLen+5;
		SendBuff[SendLen++]=4;
		INT32ToBCD(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].F_P_X_All,&SendBuff[SendLen],3);
		SendLen=SendLen+3;
		memcpy(&SendBuff[SendLen],&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].Time_F_P_X_All[0],4);
		SendLen=SendLen+4;
		/*for(i=0;i<FeiLvNum;i++)
		{
			INT32ToBCD(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].F_P_X_F[i],&SendBuff[SendLen],3);
			SendLen=SendLen+3;
		}
		for(i=0;i<FeiLvNum;i++)
		{
			memcpy(&SendBuff[SendLen],&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].Time_F_P_X_F[i][0],4);
			SendLen=SendLen+4;
		}*/
		for(i=0;i<FeiLvNum;i++)
		{
			INT32ToBCD(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].F_P_X_F[i],&SendBuff[SendLen],3);
			SendLen=SendLen+3;
			memcpy(&SendBuff[SendLen],&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].Time_F_P_X_F[i][0],4);
			SendLen=SendLen+4;
		}

		if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
		return 1;
	}
		////SendNAK(F,P,0x0c);
	////return 0;
	memset(&SendBuff[SendLen],0xee,5);
	SendLen = SendLen + 5;
	SendBuff[SendLen++]=4;
	memset(&SendBuff[SendLen],0xee,35);
	SendLen = SendLen + 35;
	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F36(INT8U F,INT8U P,INT8U FRM)
{
	INT8U i;
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	if(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].Valid==1)
	{
		memcpy(&SendBuff[SendLen],&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].Chao_Time.BCD01,sizeof(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Chao_Time));
		SendLen=SendLen+5;
		SendBuff[SendLen++]=4;
		INT32ToBCD(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].F_P_X_All,&SendBuff[SendLen],3);
		SendLen=SendLen+3;
		for(i=0;i<FeiLvNum;i++)
		{
			INT32ToBCD(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].F_P_X_F[i],&SendBuff[SendLen],3);
			SendLen=SendLen+3;
		}

		memcpy(&SendBuff[SendLen],&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].Time_F_P_X_All[0],sizeof(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].Time_F_P_X_All));
		SendLen=SendLen+4;
		for(i=0;i<FeiLvNum;i++)
		{
			memcpy(&SendBuff[SendLen],&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].Time_F_P_X_F[i][0],sizeof(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].Time_F_P_X_F[i]));
			SendLen=SendLen+4;
		}

		INT32ToBCD(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].F_Q_X_All,&SendBuff[SendLen],3);
		SendLen=SendLen+3;
		for(i=0;i<FeiLvNum;i++)
		{
			INT32ToBCD(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].F_Q_X_F[i],&SendBuff[SendLen],3);
			SendLen=SendLen+3;
		}

		memcpy(&SendBuff[SendLen],&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].Time_F_Q_X_All[0],sizeof(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].Time_F_Q_X_All));
		SendLen=SendLen+4;
		for(i=0;i<FeiLvNum;i++)
		{
			memcpy(&SendBuff[SendLen],&RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].Time_F_Q_X_F[i][0],sizeof(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].Time_F_Q_X_F[i]));
			SendLen=SendLen+4;
		}

		if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
		return 1;
	}
		////SendNAK(F,P,0x0c);
	////return 0;
	memset(&SendBuff[SendLen],0xee,5);
	SendLen = SendLen + 5;
	SendBuff[SendLen++]=4;
	memset(&SendBuff[SendLen],0xee,70);
	SendLen = SendLen + 70;
	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}

#ifndef BJJiChao
/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F37(INT8U F,INT8U P,INT8U FRM)
{
	INT8U i;
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	if(RtuDataAddr->Yue_DD_BS_Value[P-1].Valid==1)
	{
		memcpy(&SendBuff[SendLen],&RtuDataAddr->Yue_DD_BS_Value[P-1].Chao_Time.BCD01,5);
		SendLen=SendLen+5;
		SendBuff[SendLen++]=4;
		SendBuff[SendLen++]=0;//liujia
		INT32ToBCD(RtuDataAddr->Yue_DD_BS_Value[P-1].Z_P_All,&SendBuff[SendLen],5);
		SendLen=SendLen+4;
		for(i=0;i<FeiLvNum;i++)
		{
			SendBuff[SendLen++]=0;
			INT32ToBCD(RtuDataAddr->Yue_DD_BS_Value[P-1].Z_P_F[i],&SendBuff[SendLen],5);
			SendLen=SendLen+4;
		}

		INT32ToBCD(RtuDataAddr->Yue_DD_BS_Value[P-1].Z_Q_All,&SendBuff[SendLen],4);
		SendLen=SendLen+4;
		for(i=0;i<FeiLvNum;i++)
		{
			INT32ToBCD(RtuDataAddr->Yue_DD_BS_Value[P-1].Z_Q_F[i],&SendBuff[SendLen],4);
			SendLen=SendLen+4;
		}

		INT32ToBCD(RtuDataAddr->Yue_DD_BS_Value[P-1].X1_Q_All,&SendBuff[SendLen],4);
		SendLen=SendLen+4;
		for(i=0;i<FeiLvNum;i++)
		{
			INT32ToBCD(RtuDataAddr->Yue_DD_BS_Value[P-1].X1_F_Q[i],&SendBuff[SendLen],4);
			SendLen=SendLen+4;
		}

		INT32ToBCD(RtuDataAddr->Yue_DD_BS_Value[P-1].X4_Q_All,&SendBuff[SendLen],4);
		SendLen=SendLen+4;
		for(i=0;i<FeiLvNum;i++)
		{
			INT32ToBCD(RtuDataAddr->Yue_DD_BS_Value[P-1].X4_F_Q[i],&SendBuff[SendLen],4);
			SendLen=SendLen+4;
		}

		if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
		return 1;
	}
		////SendNAK(F,P,0x0c);
	////return 0;
	memset(&SendBuff[SendLen],0xee,5);
	SendLen = SendLen + 5;
	SendBuff[SendLen++]=4;
	memset(&SendBuff[SendLen],0xee,85);
	SendLen = SendLen + 85;
	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F38(INT8U F,INT8U P,INT8U FRM)
{
	INT8U i;
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	if(RtuDataAddr->Yue_DD_BS_Value[P-1].Valid==1)
	{
		memcpy(&SendBuff[SendLen],&RtuDataAddr->Yue_DD_BS_Value[P-1].Chao_Time.BCD01,5);
		SendLen=SendLen+5;
		SendBuff[SendLen++]=4;
		SendBuff[SendLen++]=0;//liujia
		INT32ToBCD(RtuDataAddr->Yue_DD_BS_Value[P-1].F_P_All,&SendBuff[SendLen],5);
		SendLen=SendLen+4;
		for(i=0;i<FeiLvNum;i++)
		{
			SendBuff[SendLen++]=0;
			INT32ToBCD(RtuDataAddr->Yue_DD_BS_Value[P-1].F_P_F[i],&SendBuff[SendLen],5);
			SendLen=SendLen+4;
		}

		INT32ToBCD(RtuDataAddr->Yue_DD_BS_Value[P-1].F_Q_All,&SendBuff[SendLen],4);
		SendLen=SendLen+4;
		for(i=0;i<FeiLvNum;i++)
		{
			INT32ToBCD(RtuDataAddr->Yue_DD_BS_Value[P-1].F_Q_F[i],&SendBuff[SendLen],4);
			SendLen=SendLen+4;
		}

		INT32ToBCD(RtuDataAddr->Yue_DD_BS_Value[P-1].X2_Q_All,&SendBuff[SendLen],4);
		SendLen=SendLen+4;
		for(i=0;i<FeiLvNum;i++)
		{
			INT32ToBCD(RtuDataAddr->Yue_DD_BS_Value[P-1].X2_F_Q[i],&SendBuff[SendLen],4);
			SendLen=SendLen+4;
		}

		INT32ToBCD(RtuDataAddr->Yue_DD_BS_Value[P-1].X3_Q_All,&SendBuff[SendLen],4);
		SendLen=SendLen+4;
		for(i=0;i<FeiLvNum;i++)
		{
			INT32ToBCD(RtuDataAddr->Yue_DD_BS_Value[P-1].X3_F_Q[i],&SendBuff[SendLen],4);
			SendLen=SendLen+4;
		}

		if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
		return 1;
	}
		////SendNAK(F,P,0x0c);
	////return 0;
	memset(&SendBuff[SendLen],0xee,5);
	SendLen = SendLen + 5;
	SendBuff[SendLen++]=4;
	memset(&SendBuff[SendLen],0xee,85);
	SendLen = SendLen + 85;
	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F39(INT8U F,INT8U P,INT8U FRM)
{
	INT8U i;
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	if(RtuDataAddr->Yue_DD_Xl_Value[P-1].Valid==1)
	{
		memcpy(&SendBuff[SendLen],&RtuDataAddr->Yue_DD_Xl_Value[P-1].Chao_Time.BCD01,sizeof(RtuDataAddr->Yue_DD_Xl_Value[P-1].Chao_Time));
		SendLen=SendLen+5;
		SendBuff[SendLen++]=4;
		INT32ToBCD(RtuDataAddr->Yue_DD_Xl_Value[P-1].Z_P_X_All,&SendBuff[SendLen],3);
		SendLen=SendLen+3;
		for(i=0;i<FeiLvNum;i++)
		{
			INT32ToBCD(RtuDataAddr->Yue_DD_Xl_Value[P-1].Z_P_X_F[i],&SendBuff[SendLen],3);
			SendLen=SendLen+3;
		}

		memcpy(&SendBuff[SendLen],&RtuDataAddr->Yue_DD_Xl_Value[P-1].Time_Z_P_X_All[0],sizeof(RtuDataAddr->Yue_DD_Xl_Value[P-1].Time_Z_P_X_All));
		SendLen=SendLen+4;
		for(i=0;i<FeiLvNum;i++)
		{
			memcpy(&SendBuff[SendLen],&RtuDataAddr->Yue_DD_Xl_Value[P-1].Time_Z_P_X_F[i][0],sizeof(RtuDataAddr->Yue_DD_Xl_Value[P-1].Time_Z_P_X_F[i]));
			SendLen=SendLen+4;
		}

		INT32ToBCD(RtuDataAddr->Yue_DD_Xl_Value[P-1].Z_Q_X_All,&SendBuff[SendLen],3);
		SendLen=SendLen+3;
		for(i=0;i<FeiLvNum;i++)
		{
			INT32ToBCD(RtuDataAddr->Yue_DD_Xl_Value[P-1].Z_Q_X_F[i],&SendBuff[SendLen],3);
			SendLen=SendLen+3;
		}

		memcpy(&SendBuff[SendLen],&RtuDataAddr->Yue_DD_Xl_Value[P-1].Time_Z_Q_X_All[0],sizeof(RtuDataAddr->Yue_DD_Xl_Value[P-1].Time_Z_Q_X_All));
		SendLen=SendLen+4;
		for(i=0;i<FeiLvNum;i++)
		{
			memcpy(&SendBuff[SendLen],&RtuDataAddr->Yue_DD_Xl_Value[P-1].Time_Z_Q_X_F[i][0],sizeof(RtuDataAddr->Yue_DD_Xl_Value[P-1].Time_Z_Q_X_F[i]));
			SendLen=SendLen+4;
		}

		if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
		return 1;
	}
		////SendNAK(F,P,0x0c);
	////return 0;
	memset(&SendBuff[SendLen],0xee,5);
	SendLen = SendLen + 5;
	SendBuff[SendLen++]=4;
	memset(&SendBuff[SendLen],0xee,70);
	SendLen = SendLen + 70;
	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F40(INT8U F,INT8U P,INT8U FRM)
{
	INT8U i;
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	if(RtuDataAddr->Yue_DD_Xl_Value[P-1].Valid==1)
	{
		memcpy(&SendBuff[SendLen],&RtuDataAddr->Yue_DD_Xl_Value[P-1].Chao_Time.BCD01,sizeof(RtuDataAddr->Yue_DD_Xl_Value[P-1].Chao_Time));
		SendLen=SendLen+5;
		SendBuff[SendLen++]=4;
		INT32ToBCD(RtuDataAddr->Yue_DD_Xl_Value[P-1].F_P_X_All,&SendBuff[SendLen],3);
		SendLen=SendLen+3;
		for(i=0;i<FeiLvNum;i++)
		{
			INT32ToBCD(RtuDataAddr->Yue_DD_Xl_Value[P-1].F_P_X_F[i],&SendBuff[SendLen],3);
			SendLen=SendLen+3;
		}

		memcpy(&SendBuff[SendLen],&RtuDataAddr->Yue_DD_Xl_Value[P-1].Time_F_P_X_All[0],sizeof(RtuDataAddr->Yue_DD_Xl_Value[P-1].Time_F_P_X_All));
		SendLen=SendLen+4;
		for(i=0;i<FeiLvNum;i++)
		{
			memcpy(&SendBuff[SendLen],&RtuDataAddr->Yue_DD_Xl_Value[P-1].Time_F_P_X_F[i][0],sizeof(RtuDataAddr->Yue_DD_Xl_Value[P-1].Time_F_P_X_F[i]));
			SendLen=SendLen+4;
		}

		INT32ToBCD(RtuDataAddr->Yue_DD_Xl_Value[P-1].F_Q_X_All,&SendBuff[SendLen],3);
		SendLen=SendLen+3;
		for(i=0;i<FeiLvNum;i++)
		{
			INT32ToBCD(RtuDataAddr->Yue_DD_Xl_Value[P-1].F_Q_X_F[i],&SendBuff[SendLen],3);
			SendLen=SendLen+3;
		}

		memcpy(&SendBuff[SendLen],&RtuDataAddr->Yue_DD_Xl_Value[P-1].Time_F_Q_X_All[0],sizeof(RtuDataAddr->Yue_DD_Xl_Value[P-1].Time_F_Q_X_All));
		SendLen=SendLen+4;
		for(i=0;i<FeiLvNum;i++)
		{
			memcpy(&SendBuff[SendLen],&RtuDataAddr->Yue_DD_Xl_Value[P-1].Time_F_Q_X_F[i][0],sizeof(RtuDataAddr->Yue_DD_Xl_Value[P-1].Time_F_Q_X_F[i]));
			SendLen=SendLen+4;
		}

		if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
		return 1;
	}
		////SendNAK(F,P,0x0c);
	////return 0;
	memset(&SendBuff[SendLen],0xee,5);
	SendLen = SendLen + 5;
	SendBuff[SendLen++]=4;
	memset(&SendBuff[SendLen],0xee,70);
	SendLen = SendLen + 70;
	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F41(INT8U F,INT8U P,INT8U FRM)
{
	INT8U i;
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	if(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Valid==1)
	{
		SendBuff[SendLen++]=FeiLvNum;
		//XXPrint("\n\rF41-P_ALL %d  Day %d",RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Z_P_All,RtuDataAddr->Day_DD_BS_Value[P-1].Z_P_All);
		//XXPrint("\n\rF41-p_all %d  zjno %d",RtuDataAddr->z_P_all[P-1],P);
		if(RtuDataAddr->z_P_all[P-1]>0)
		{
			//RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Z_P_All = RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Z_P_All*10 + RtuDataAddr->z_P_all[P-1];
			INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Z_P_All-RtuDataAddr->Day_DD_BS_Value[P-1].Z_P_All)*10000,&SendBuff[SendLen],4);
		}
		else{
			INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Z_P_All-RtuDataAddr->Day_DD_BS_Value[P-1].Z_P_All)*100,&SendBuff[SendLen],4);
		}
		SendLen=SendLen+4;
		for(i=0;i<FeiLvNum;i++)
		{
			INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Z_P_F[i]-RtuDataAddr->Day_DD_BS_Value[P-1].Z_P_F[i])*100,&SendBuff[SendLen],4);
			SendLen=SendLen+4;
		}

		if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
		return 1;
	}
		////SendNAK(F,P,0x0c);
	////return 0;
	memset(&SendBuff[SendLen],0xee,5);
	SendLen = SendLen + 5;
	SendBuff[SendLen++]=4;
	memset(&SendBuff[SendLen],0xee,20);
	SendLen = SendLen + 20;
	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F42(INT8U F,INT8U P,INT8U FRM)
{
	INT8U i;
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	if(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Valid==1)
	{
		SendBuff[SendLen++]=4;
		INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Z_Q_All-RtuDataAddr->Day_DD_BS_Value[P-1].Z_Q_All)*100,&SendBuff[SendLen],4);
		SendLen=SendLen+4;
		for(i=0;i<FeiLvNum;i++)
		{
			INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Z_Q_F[i]-RtuDataAddr->Day_DD_BS_Value[P-1].Z_Q_F[i])*100,&SendBuff[SendLen],4);
			SendLen=SendLen+4;
		}

		if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
		return 1;
	}
		////SendNAK(F,P,0x0c);
	////return 0;
	memset(&SendBuff[SendLen],0xee,5);
	SendLen = SendLen + 5;
	SendBuff[SendLen++]=4;
	memset(&SendBuff[SendLen],0xee,20);
	SendLen = SendLen + 20;
	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F43(INT8U F,INT8U P,INT8U FRM)
{
	INT8U i;
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	if(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Valid==1)
	{
		SendBuff[SendLen++]=4;
		INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[P-1].F_P_All-RtuDataAddr->Day_DD_BS_Value[P-1].F_P_All)*100,&SendBuff[SendLen],4);
		SendLen=SendLen+4;
		for(i=0;i<FeiLvNum;i++)
		{
			INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[P-1].F_P_F[i]-RtuDataAddr->Day_DD_BS_Value[P-1].F_P_F[i])*100,&SendBuff[SendLen],4);
			SendLen=SendLen+4;
		}

		if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
		return 1;
	}
		////SendNAK(F,P,0x0c);
	////return 0;
	memset(&SendBuff[SendLen],0xee,5);
	SendLen = SendLen + 5;
	SendBuff[SendLen++]=4;
	memset(&SendBuff[SendLen],0xee,20);
	SendLen = SendLen + 20;
	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F44(INT8U F,INT8U P,INT8U FRM)
{
	INT8U i;
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	if(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Valid==1)
	{
		SendBuff[SendLen++]=4;
		INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[P-1].F_Q_All-RtuDataAddr->Day_DD_BS_Value[P-1].F_Q_All)*100,&SendBuff[SendLen],4);
		SendLen=SendLen+4;
		for(i=0;i<FeiLvNum;i++)
		{
			INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[P-1].F_Q_F[i]-RtuDataAddr->Day_DD_BS_Value[P-1].F_Q_F[i])*100,&SendBuff[SendLen],4);
			SendLen=SendLen+4;
		}

		if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
		return 1;
	}
		////SendNAK(F,P,0x0c);
	////return 0;
	memset(&SendBuff[SendLen],0xee,5);
	SendLen = SendLen + 5;
	SendBuff[SendLen++]=4;
	memset(&SendBuff[SendLen],0xee,20);
	SendLen = SendLen + 20;
	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F45(INT8U F,INT8U P,INT8U FRM)
{
	INT8U i;
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	if(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Valid==1)
	{
		SendBuff[SendLen++]=4;
		INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Z_P_All-RtuDataAddr->Yue_DD_BS_Value[P-1].Z_P_All)*100,&SendBuff[SendLen],4);
		SendLen=SendLen+4;
		for(i=0;i<FeiLvNum;i++)
		{
			INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Z_P_F[i]-RtuDataAddr->Yue_DD_BS_Value[P-1].Z_P_F[i])*100,&SendBuff[SendLen],4);
			SendLen=SendLen+4;
		}

		if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
		return 1;
	}
		////SendNAK(F,P,0x0c);
	////return 0;
	memset(&SendBuff[SendLen],0xee,5);
	SendLen = SendLen + 5;
	SendBuff[SendLen++]=4;
	memset(&SendBuff[SendLen],0xee,20);
	SendLen = SendLen + 20;
	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F46(INT8U F,INT8U P,INT8U FRM)
{
	INT8U i;
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	if(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Valid==1)
	{
		SendBuff[SendLen++]=4;
		INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Z_Q_All-RtuDataAddr->Yue_DD_BS_Value[P-1].Z_Q_All)*100,&SendBuff[SendLen],4);
		SendLen=SendLen+4;
		for(i=0;i<FeiLvNum;i++)
		{
			INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Z_Q_F[i]-RtuDataAddr->Yue_DD_BS_Value[P-1].Z_Q_F[i])*100,&SendBuff[SendLen],4);
			SendLen=SendLen+4;
		}

		if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
		return 1;
	}
		////SendNAK(F,P,0x0c);
	////return 0;
	memset(&SendBuff[SendLen],0xee,5);
	SendLen = SendLen + 5;
	SendBuff[SendLen++]=4;
	memset(&SendBuff[SendLen],0xee,20);
	SendLen = SendLen + 20;
	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}


/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F47(INT8U F,INT8U P,INT8U FRM)
{
	INT8U i;
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	if(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Valid==1)
	{
		SendBuff[SendLen++]=4;
		INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[P-1].F_P_All-RtuDataAddr->Yue_DD_BS_Value[P-1].F_P_All)*100,&SendBuff[SendLen],4);
		SendLen=SendLen+4;
		for(i=0;i<FeiLvNum;i++)
		{
			INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[P-1].F_P_F[i]-RtuDataAddr->Yue_DD_BS_Value[P-1].F_P_F[i])*100,&SendBuff[SendLen],4);
			SendLen=SendLen+4;
		}

		if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
		return 1;
	}
		////SendNAK(F,P,0x0c);
	////return 0;
	memset(&SendBuff[SendLen],0xee,5);
	SendLen = SendLen + 5;
	SendBuff[SendLen++]=4;
	memset(&SendBuff[SendLen],0xee,20);
	SendLen = SendLen + 20;
	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}


/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F48(INT8U F,INT8U P,INT8U FRM)
{
	INT8U i;
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	if(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Valid==1)
	{
		SendBuff[SendLen++]=4;
		INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[P-1].F_Q_All-RtuDataAddr->Yue_DD_BS_Value[P-1].F_Q_All)*100,&SendBuff[SendLen],4);
		SendLen=SendLen+4;
		for(i=0;i<FeiLvNum;i++)
		{
			INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[P-1].F_Q_F[i]-RtuDataAddr->Yue_DD_BS_Value[P-1].F_Q_F[i])*100,&SendBuff[SendLen],4);
			SendLen=SendLen+4;
		}

		if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
		return 1;
	}
		////SendNAK(F,P,0x0c);
	////return 0;
	memset(&SendBuff[SendLen],0xee,5);
	SendLen = SendLen + 5;
	SendBuff[SendLen++]=4;
	memset(&SendBuff[SendLen],0xee,20);
	SendLen = SendLen + 20;
	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}


/**********************************************************************
***********************************************************************/

INT8U Set_Level1_F49(INT8U F,INT8U P,INT8U FRM)//��Ч
{
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	if(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].Valid==1)
	{
		INT32ToBCD(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].UAJ,&SendBuff[SendLen],2);
		SendLen=SendLen+2;
		INT32ToBCD(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].UBJ,&SendBuff[SendLen],2);
		SendLen=SendLen+2;
		INT32ToBCD(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].UCJ,&SendBuff[SendLen],2);
		SendLen=SendLen+2;
		INT32ToBCD(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].IAJ,&SendBuff[SendLen],2);
		SendLen=SendLen+2;
		INT32ToBCD(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].IBJ,&SendBuff[SendLen],2);
		SendLen=SendLen+2;
		INT32ToBCD(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[P-1].ICJ,&SendBuff[SendLen],2);
		SendLen=SendLen+2;

		if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
		return 1;
	}

	////SendNAK(F,P,0x0c);
	////return 0;
	memset(&SendBuff[SendLen],0xee,12);
	SendLen = SendLen + 12;
	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
//liujia
INT8U Set_Level1_F57(INT8U F,INT8U P,INT8U FRM)
{
/*	INT8U i;
	MkLevel1Head(P,F,FRM);
	if(RtuDataAddr->AllXBo.Valid==1)
	{
		SendBuff[SendLen++]=19;

		//memcpy(&RtuDataAddr->AllXBo.UAxb[2],&SendBuff[SendLen],sizeof(INT32U)*18);
		//memcpy(&RtuDataAddr->AllXBo.UBxb[2],&SendBuff[SendLen],sizeof(INT32U)*18);
		//memcpy(&RtuDataAddr->AllXBo.UCxb[2],&SendBuff[SendLen],sizeof(INT32U)*18);
		//memcpy(&RtuDataAddr->AllXBo.IAxb[2],&SendBuff[SendLen],sizeof(INT32U)*18);
		//memcpy(&RtuDataAddr->AllXBo.IBxb[2],&SendBuff[SendLen],sizeof(INT32U)*18);
		//memcpy(&RtuDataAddr->AllXBo.ICxb[2],&SendBuff[SendLen],sizeof(INT32U)*18);

		for(i=2;i<20;i++)
		{
			INT32ToBCD(RtuDataAddr->AllXBo.UAxb[i],&SendBuff[SendLen],2);
			SendLen=SendLen+2;
		}
		for(i=2;i<20;i++)
		{
			INT32ToBCD(RtuDataAddr->AllXBo.UBxb[i],&SendBuff[SendLen],2);
			SendLen=SendLen+2;
		}
		for(i=2;i<20;i++)
		{
			INT32ToBCD(RtuDataAddr->AllXBo.UCxb[i],&SendBuff[SendLen],2);
			SendLen=SendLen+2;
		}
		for(i=2;i<20;i++)
		{
			INT32ToBCD(RtuDataAddr->AllXBo.IAxb[i],&SendBuff[SendLen],2);
			SendLen=SendLen+2;
		}
		for(i=2;i<20;i++)
		{
			INT32ToBCD(RtuDataAddr->AllXBo.IBxb[i],&SendBuff[SendLen],2);
			SendLen=SendLen+2;
		}
		for(i=2;i<20;i++)
		{
			INT32ToBCD(RtuDataAddr->AllXBo.ICxb[i],&SendBuff[SendLen],2);
			SendLen=SendLen+2;
		}

		EC();
		TP();
		FrameTailCreate_Send();
		return 1;
	}*/
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	////SendNAK(F,P,0x0c);
	////return 0;
	SendBuff[SendLen++]=19;
	memset(&SendBuff[SendLen],0xee,216);
	SendLen = SendLen + 216;
	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F58(INT8U F,INT8U P,INT8U FRM)
{
/*	INT8U i;
	MkLevel1Head(P,F,FRM);
	if(RtuDataAddr->AllXBo.Valid==1)
	{
		SendBuff[SendLen++]=19;

		//memcpy(&RtuDataAddr->AllXBo.UA_Hanyoulv[2],&SendBuff[SendLen],sizeof(INT32U)*18);
		//memcpy(&RtuDataAddr->AllXBo.UB_Hanyoulv[2],&SendBuff[SendLen],sizeof(INT32U)*18);
		//memcpy(&RtuDataAddr->AllXBo.UC_Hanyoulv[2],&SendBuff[SendLen],sizeof(INT32U)*18);
		//memcpy(&RtuDataAddr->AllXBo.IA_Hanyoulv[2],&SendBuff[SendLen],sizeof(INT32U)*18);
		//memcpy(&RtuDataAddr->AllXBo.IB_Hanyoulv[2],&SendBuff[SendLen],sizeof(INT32U)*18);
		//memcpy(&RtuDataAddr->AllXBo.IC_Hanyoulv[2],&SendBuff[SendLen],sizeof(INT32U)*18);

		for(i=2;i<20;i++)
		{
			INT32ToBCD(RtuDataAddr->AllXBo.UA_Hanyoulv[i],&SendBuff[SendLen],2);
			SendLen=SendLen+2;
		}
		for(i=2;i<20;i++)
		{
			INT32ToBCD(RtuDataAddr->AllXBo.UB_Hanyoulv[i],&SendBuff[SendLen],2);
			SendLen=SendLen+2;
		}
		for(i=2;i<20;i++)
		{
			INT32ToBCD(RtuDataAddr->AllXBo.UC_Hanyoulv[i],&SendBuff[SendLen],2);
			SendLen=SendLen+2;
		}
		for(i=2;i<20;i++)
		{
			INT32ToBCD(RtuDataAddr->AllXBo.IA_Hanyoulv[i],&SendBuff[SendLen],2);
			SendLen=SendLen+2;
		}
		for(i=2;i<20;i++)
		{
			INT32ToBCD(RtuDataAddr->AllXBo.IB_Hanyoulv[i],&SendBuff[SendLen],2);
			SendLen=SendLen+2;
		}
		for(i=2;i<20;i++)
		{
			INT32ToBCD(RtuDataAddr->AllXBo.IC_Hanyoulv[i],&SendBuff[SendLen],2);
			SendLen=SendLen+2;
		}

		EC();
		TP();
		FrameTailCreate_Send();
		return 1;
	}*/
	////if(AutoFlg==0)
	////	MkLevel1Head(P,F,FRM);
	////SendNAK(F,P,0x0c);
	return 0;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F65(INT8U F,INT8U P,INT8U FRM)//��Ч
{
	////if(AutoFlg==0)
	////	MkLevel1Head(P,F,FRM);
	////SendNAK(F,P,0x0c);
	return 0;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F66(INT8U F,INT8U P,INT8U FRM)//��Ч
{
	////if(AutoFlg==0)
	////	MkLevel1Head(P,F,FRM);
	////SendNAK(F,P,0x0c);
	return 0;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F67(INT8U F,INT8U P,INT8U FRM)//��Ч
{
	////if(AutoFlg==0)
	////	MkLevel1Head(P,F,FRM);
	////SendNAK(F,P,0x0c);
	return 0;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F73(INT8U F,INT8U P,INT8U FRM)//��Ч
{
	////if(AutoFlg==0)
	////	MkLevel1Head(P,F,FRM);
	////SendNAK(F,P,0x0c);
	return 0;
}
/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F81(INT8U F,INT8U P,INT8U FRM)
{
	INT8U i;
	TS ts;
	TSGet(&ts);
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	i=((ts.Hour+23)%24);
	SendBuff[SendLen]=((i/10)<<4)+(i%10);
	if(RtuDataAddr->ZongJia_Value.F33_Set_Para[P-1].Valid==1)
	{
		switch(RtuDataAddr->ZongJia_Value.F33_Set_Para[P-1].ZongJia_P_DongJie_Midu)
		{
		case 0:
			SendBuff[SendLen]=SendBuff[SendLen];
			SendLen++;
//liujia ��F81--F116���붳���ܶ��йأ�ʱ��ȫ����Ϊ�����ֽ�
			SendBuff[SendLen]=RtuDataAddr->ZongJia_Value.F33_Set_Para[P-1].ZongJia_P_DongJie_Midu;
			SendLen++;
			break;
		case 1:
			SendBuff[SendLen]=SendBuff[SendLen]|0x40;
			SendLen++;
			SendBuff[SendLen]=RtuDataAddr->ZongJia_Value.F33_Set_Para[P-1].ZongJia_P_DongJie_Midu;
			SendLen++;
			Create_Data_Type02(RtuDataAddr->OldHour_Zj_Value[0][P-1].P,&SendBuff[SendLen]);//15
			SendLen=SendLen+2;
			Create_Data_Type02(RtuDataAddr->OldHour_Zj_Value[1][P-1].P,&SendBuff[SendLen]);//30
			SendLen=SendLen+2;
			Create_Data_Type02(RtuDataAddr->OldHour_Zj_Value[2][P-1].P,&SendBuff[SendLen]);//45
			SendLen=SendLen+2;
			Create_Data_Type02(RtuDataAddr->OldHour_Zj_Value[3][P-1].P,&SendBuff[SendLen]);//00
			SendLen=SendLen+2;
			break;
		case 2:
			SendBuff[SendLen]=SendBuff[SendLen]|0x80;
			SendLen++;
			SendBuff[SendLen]=RtuDataAddr->ZongJia_Value.F33_Set_Para[P-1].ZongJia_P_DongJie_Midu;
			SendLen++;
			Create_Data_Type02(RtuDataAddr->OldHour_Zj_Value[1][P-1].P,&SendBuff[SendLen]);//30
			SendLen=SendLen+2;
			Create_Data_Type02(RtuDataAddr->OldHour_Zj_Value[3][P-1].P,&SendBuff[SendLen]);//00
			SendLen=SendLen+2;
			break;
		case 3:
			SendBuff[SendLen]=SendBuff[SendLen]|0xc0;
			SendLen++;
			SendBuff[SendLen]=RtuDataAddr->ZongJia_Value.F33_Set_Para[P-1].ZongJia_P_DongJie_Midu;
			SendLen++;
			Create_Data_Type02(RtuDataAddr->OldHour_Zj_Value[3][P-1].P,&SendBuff[SendLen]);//00
			SendLen=SendLen+2;
			break;
		}

		if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
		return 1;
	}
		////SendNAK(F,P,0x0c);
	////return 0;
	memset(&SendBuff[SendLen],0xee,10);
	SendLen = SendLen + 10;
	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F82(INT8U F,INT8U P,INT8U FRM)
{
	INT8U i;
	TS ts;
	TSGet(&ts);
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	i=((ts.Hour+23)%24);
	SendBuff[SendLen]=((i/10)<<4)+(i%10);
	if(RtuDataAddr->ZongJia_Value.F33_Set_Para[P-1].Valid==1)
	{
		switch(RtuDataAddr->ZongJia_Value.F33_Set_Para[P-1].ZongJia_Q_DongJie_Midu)
		{
		case 0:
			SendBuff[SendLen]=SendBuff[SendLen];
			SendLen++;
			SendBuff[SendLen]=RtuDataAddr->ZongJia_Value.F33_Set_Para[P-1].ZongJia_Q_DongJie_Midu;
			SendLen++;
			break;
		case 1:
			SendBuff[SendLen]=SendBuff[SendLen]|0x40;
			SendLen++;
			SendBuff[SendLen]=RtuDataAddr->ZongJia_Value.F33_Set_Para[P-1].ZongJia_Q_DongJie_Midu;
			SendLen++;
			Create_Data_Type02(RtuDataAddr->OldHour_Zj_Value[0][P-1].Q,&SendBuff[SendLen]);//15
			SendLen=SendLen+2;
			Create_Data_Type02(RtuDataAddr->OldHour_Zj_Value[1][P-1].Q,&SendBuff[SendLen]);//30
			SendLen=SendLen+2;
			Create_Data_Type02(RtuDataAddr->OldHour_Zj_Value[2][P-1].Q,&SendBuff[SendLen]);//45
			SendLen=SendLen+2;
			Create_Data_Type02(RtuDataAddr->OldHour_Zj_Value[3][P-1].Q,&SendBuff[SendLen]);//00
			SendLen=SendLen+2;
			break;
		case 2:
			SendBuff[SendLen]=SendBuff[SendLen]|0x80;
			SendLen++;
			SendBuff[SendLen]=RtuDataAddr->ZongJia_Value.F33_Set_Para[P-1].ZongJia_Q_DongJie_Midu;
			SendLen++;
			Create_Data_Type02(RtuDataAddr->OldHour_Zj_Value[1][P-1].Q,&SendBuff[SendLen]);//30
			SendLen=SendLen+2;
			Create_Data_Type02(RtuDataAddr->OldHour_Zj_Value[3][P-1].Q,&SendBuff[SendLen]);//00
			SendLen=SendLen+2;
			break;
		case 3:
			SendBuff[SendLen]=SendBuff[SendLen]|0xc0;
			SendLen++;
			SendBuff[SendLen]=RtuDataAddr->ZongJia_Value.F33_Set_Para[P-1].ZongJia_Q_DongJie_Midu;
			SendLen++;
			Create_Data_Type02(RtuDataAddr->OldHour_Zj_Value[3][P-1].Q,&SendBuff[SendLen]);//00
			SendLen=SendLen+2;
			break;
		}

		if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
		return 1;
	}
		////SendNAK(F,P,0x0c);
	////return 0;
	memset(&SendBuff[SendLen],0xee,10);
	SendLen = SendLen + 10;
	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F83(INT8U F,INT8U P,INT8U FRM)
{
	INT8U i;
	TS ts;
	TSGet(&ts);
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	i=((ts.Hour+23)%24);
	SendBuff[SendLen]=((i/10)<<4)+(i%10);
	if(RtuDataAddr->ZongJia_Value.F33_Set_Para[P-1].Valid==1)
	{
		switch(RtuDataAddr->ZongJia_Value.F33_Set_Para[P-1].ZongJia_P_DD_DJie_Midu)
		{
		case 0:
			SendBuff[SendLen]=SendBuff[SendLen];
			SendLen++;
			SendBuff[SendLen]=RtuDataAddr->ZongJia_Value.F33_Set_Para[P-1].ZongJia_P_DD_DJie_Midu;
			SendLen++;
			break;
		case 1:
			SendBuff[SendLen]=SendBuff[SendLen]|0x40;
			SendLen++;
			SendBuff[SendLen]=RtuDataAddr->ZongJia_Value.F33_Set_Para[P-1].ZongJia_P_DD_DJie_Midu;
			SendLen++;
			Create_Data_Type03(RtuDataAddr->OldHour_Zj_Value[0][P-1].P_All,&SendBuff[SendLen]);//15
			SendLen=SendLen+4;
			Create_Data_Type03(RtuDataAddr->OldHour_Zj_Value[1][P-1].P_All,&SendBuff[SendLen]);//30
			SendLen=SendLen+4;
			Create_Data_Type03(RtuDataAddr->OldHour_Zj_Value[2][P-1].P_All,&SendBuff[SendLen]);//45
			SendLen=SendLen+4;
			Create_Data_Type03(RtuDataAddr->OldHour_Zj_Value[3][P-1].P_All,&SendBuff[SendLen]);//00
			SendLen=SendLen+4;
			break;
		case 2:
			SendBuff[SendLen]=SendBuff[SendLen]|0x80;
			SendLen++;
			SendBuff[SendLen]=RtuDataAddr->ZongJia_Value.F33_Set_Para[P-1].ZongJia_P_DD_DJie_Midu;
			SendLen++;
			Create_Data_Type03(RtuDataAddr->OldHour_Zj_Value[1][P-1].P_All,&SendBuff[SendLen]);//30
			SendLen=SendLen+4;
			Create_Data_Type03(RtuDataAddr->OldHour_Zj_Value[3][P-1].P_All,&SendBuff[SendLen]);//00
			SendLen=SendLen+4;
			break;
		case 3:
			SendBuff[SendLen]=SendBuff[SendLen]|0xc0;
			SendLen++;
			SendBuff[SendLen]=RtuDataAddr->ZongJia_Value.F33_Set_Para[P-1].ZongJia_P_DD_DJie_Midu;
			SendLen++;
			Create_Data_Type03(RtuDataAddr->OldHour_Zj_Value[3][P-1].P_All,&SendBuff[SendLen]);//00
			SendLen=SendLen+4;
			break;
		}

		if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
		return 1;
	}
		////SendNAK(F,P,0x0c);
	////return 0;
	memset(&SendBuff[SendLen],0xee,18);
	SendLen = SendLen + 18;
	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F84(INT8U F,INT8U P,INT8U FRM)
{
	INT8U i;
	TS ts;
	TSGet(&ts);
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	i=((ts.Hour+23)%24);
	SendBuff[SendLen]=((i/10)<<4)+(i%10);
	if(RtuDataAddr->ZongJia_Value.F33_Set_Para[P-1].Valid==1)
	{
		switch(RtuDataAddr->ZongJia_Value.F33_Set_Para[P-1].ZongJia_Q_DD_DJie_Midu)
		{
		case 0:
			SendBuff[SendLen]=SendBuff[SendLen];
			SendLen++;
			SendBuff[SendLen]=RtuDataAddr->ZongJia_Value.F33_Set_Para[P-1].ZongJia_Q_DD_DJie_Midu;
			SendLen++;
			break;
		case 1:
			SendBuff[SendLen]=SendBuff[SendLen]|0x40;
			SendLen++;
			SendBuff[SendLen]=RtuDataAddr->ZongJia_Value.F33_Set_Para[P-1].ZongJia_Q_DD_DJie_Midu;
			SendLen++;
			Create_Data_Type03(RtuDataAddr->OldHour_Zj_Value[0][P-1].Q_All,&SendBuff[SendLen]);//15
			SendLen=SendLen+4;
			Create_Data_Type03(RtuDataAddr->OldHour_Zj_Value[1][P-1].Q_All,&SendBuff[SendLen]);//30
			SendLen=SendLen+4;
			Create_Data_Type03(RtuDataAddr->OldHour_Zj_Value[2][P-1].Q_All,&SendBuff[SendLen]);//45
			SendLen=SendLen+4;
			Create_Data_Type03(RtuDataAddr->OldHour_Zj_Value[3][P-1].Q_All,&SendBuff[SendLen]);//00
			SendLen=SendLen+4;
			break;
		case 2:
			SendBuff[SendLen]=SendBuff[SendLen]|0x80;
			SendLen++;
			SendBuff[SendLen]=RtuDataAddr->ZongJia_Value.F33_Set_Para[P-1].ZongJia_Q_DD_DJie_Midu;
			SendLen++;
			Create_Data_Type03(RtuDataAddr->OldHour_Zj_Value[1][P-1].Q_All,&SendBuff[SendLen]);//30
			SendLen=SendLen+4;
			Create_Data_Type03(RtuDataAddr->OldHour_Zj_Value[3][P-1].Q_All,&SendBuff[SendLen]);//00
			SendLen=SendLen+4;
			break;
		case 3:
			SendBuff[SendLen]=SendBuff[SendLen]|0xc0;
			SendLen++;
			SendBuff[SendLen]=RtuDataAddr->ZongJia_Value.F33_Set_Para[P-1].ZongJia_Q_DD_DJie_Midu;
			SendLen++;
			Create_Data_Type03(RtuDataAddr->OldHour_Zj_Value[3][P-1].Q_All,&SendBuff[SendLen]);//00
			SendLen=SendLen+4;
			break;
		}

		if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
		return 1;
	}
		////SendNAK(F,P,0x0c);
	////return 0;
	memset(&SendBuff[SendLen],0xee,18);
	SendLen = SendLen + 18;
	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
#endif
/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F89(INT8U F,INT8U P,INT8U QxBl,INT8U FRM)
{
	INT8U i;
	TS ts;
	TSGet(&ts);
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	i=((ts.Hour+23)%24);
	SendBuff[SendLen]=((i/10)<<4)+(i%10);
	for(i=0;i<RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJie_Num;i++)
	{
		if(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.XinXiBiaoSHi[i]==89)
		{
			switch(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl)
			{
			case 0:
				SendBuff[SendLen]=SendBuff[SendLen];
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				break;
			case 1:
				SendBuff[SendLen]=SendBuff[SendLen]|0x40;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[0][P-1].P,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].P,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[2][P-1].P,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].P,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				break;
			case 2:
				SendBuff[SendLen]=SendBuff[SendLen]|0x80;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].P,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].P,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				break;
			case 3:
				SendBuff[SendLen]=SendBuff[SendLen]|0xc0;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].P,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				break;
			}
			break;
		}
	}

	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F90(INT8U F,INT8U P,INT8U QxBl,INT8U FRM)//��Ч
{
	INT8U i;
	TS ts;
	TSGet(&ts);
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	i=((ts.Hour+23)%24);
	SendBuff[SendLen]=((i/10)<<4)+(i%10);
	for(i=0;i<RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJie_Num;i++)
	{
		if(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.XinXiBiaoSHi[i]==90)
		{
			switch(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl)
			{
			case 0:
				SendBuff[SendLen]=SendBuff[SendLen];
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				break;
			case 1:
				SendBuff[SendLen]=SendBuff[SendLen]|0x40;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[0][P-1].PA,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].PA,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[2][P-1].PA,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].PA,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				break;
			case 2:
				SendBuff[SendLen]=SendBuff[SendLen]|0x80;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].PA,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].PA,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				break;
			case 3:
				SendBuff[SendLen]=SendBuff[SendLen]|0xc0;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].PA,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				break;
			}
			break;
		}
	}

	if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
	return 1;
}
/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F91(INT8U F,INT8U P,INT8U QxBl,INT8U FRM)//��Ч
{
	INT8U i;
	TS ts;
	TSGet(&ts);
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	i=((ts.Hour+23)%24);
	SendBuff[SendLen]=((i/10)<<4)+(i%10);
	for(i=0;i<RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJie_Num;i++)
	{
		if(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.XinXiBiaoSHi[i]==91)
		{
			switch(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl)
			{
			case 0:
				SendBuff[SendLen]=SendBuff[SendLen];
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				break;
			case 1:
				SendBuff[SendLen]=SendBuff[SendLen]|0x40;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[0][P-1].PB,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].PB,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[2][P-1].PB,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].PB,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				break;
			case 2:
				SendBuff[SendLen]=SendBuff[SendLen]|0x80;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].PB,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].PB,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				break;
			case 3:
				SendBuff[SendLen]=SendBuff[SendLen]|0xc0;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].PB,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				break;
			}
			break;
		}
	}

	if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
	return 1;
}
/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F92(INT8U F,INT8U P,INT8U QxBl,INT8U FRM)//��Ч
{
	INT8U i;
	TS ts;
	TSGet(&ts);
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	i=((ts.Hour+23)%24);
	SendBuff[SendLen]=((i/10)<<4)+(i%10);
	for(i=0;i<RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJie_Num;i++)
	{
		if(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.XinXiBiaoSHi[i]==92)
		{
			switch(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl)
			{
			case 0:
				SendBuff[SendLen]=SendBuff[SendLen];
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				break;
			case 1:
				SendBuff[SendLen]=SendBuff[SendLen]|0x40;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[0][P-1].PC,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].PC,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[2][P-1].PC,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].PC,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				break;
			case 2:
				SendBuff[SendLen]=SendBuff[SendLen]|0x80;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].PC,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].PC,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				break;
			case 3:
				SendBuff[SendLen]=SendBuff[SendLen]|0xc0;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].PC,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				break;
			}
			break;
		}
	}

	if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
	return 1;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F93(INT8U F,INT8U P,INT8U QxBl,INT8U FRM)
{
	INT8U i;
	TS ts;
	TSGet(&ts);
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	i=((ts.Hour+23)%24);
	SendBuff[SendLen]=((i/10)<<4)+(i%10);
	for(i=0;i<RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJie_Num;i++)
	{
		if(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.XinXiBiaoSHi[i]==93)
		{
			switch(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl)
			{
			case 0:
				SendBuff[SendLen]=SendBuff[SendLen];
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				break;
			case 1:
				SendBuff[SendLen]=SendBuff[SendLen]|0x40;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[0][P-1].Q,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].Q,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[2][P-1].Q,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].Q,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				break;
			case 2:
				SendBuff[SendLen]=SendBuff[SendLen]|0x80;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].Q,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].Q,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				break;
			case 3:
				SendBuff[SendLen]=SendBuff[SendLen]|0xc0;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].Q,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				break;
			}
			break;
		}
	}

	if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
	return 1;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F94(INT8U F,INT8U P,INT8U QxBl,INT8U FRM)//��Ч
{
	INT8U i;
	TS ts;
	TSGet(&ts);
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	i=((ts.Hour+23)%24);
	SendBuff[SendLen]=((i/10)<<4)+(i%10);
	for(i=0;i<RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJie_Num;i++)
	{
		if(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.XinXiBiaoSHi[i]==94)
		{
			switch(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl)
			{
			case 0:
				SendBuff[SendLen]=SendBuff[SendLen];
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				break;
			case 1:
				SendBuff[SendLen]=SendBuff[SendLen]|0x40;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[0][P-1].QA,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].QA,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[2][P-1].QA,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].QA,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				break;
			case 2:
				SendBuff[SendLen]=SendBuff[SendLen]|0x80;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].QA,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].QA,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				break;
			case 3:
				SendBuff[SendLen]=SendBuff[SendLen]|0xc0;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].QA,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				break;
			}
			break;
		}
	}

	if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
	return 1;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F95(INT8U F,INT8U P,INT8U QxBl,INT8U FRM)//��Ч
{
	INT8U i;
	TS ts;
	TSGet(&ts);
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	i=((ts.Hour+23)%24);
	SendBuff[SendLen]=((i/10)<<4)+(i%10);
	for(i=0;i<RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJie_Num;i++)
	{
		if(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.XinXiBiaoSHi[i]==95)
		{
			switch(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl)
			{
			case 0:
				SendBuff[SendLen]=SendBuff[SendLen];
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				break;
			case 1:
				SendBuff[SendLen]=SendBuff[SendLen]|0x40;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[0][P-1].QB,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].QB,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[2][P-1].QB,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].QB,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				break;
			case 2:
				SendBuff[SendLen]=SendBuff[SendLen]|0x80;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].QB,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].QB,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				break;
			case 3:
				SendBuff[SendLen]=SendBuff[SendLen]|0xc0;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].QB,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				break;
			}
			break;
		}
	}

	if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
	return 1;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F96(INT8U F,INT8U P,INT8U QxBl,INT8U FRM)//��Ч
{
	INT8U i;
	TS ts;
	TSGet(&ts);
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	i=((ts.Hour+23)%24);
	SendBuff[SendLen]=((i/10)<<4)+(i%10);
	for(i=0;i<RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJie_Num;i++)
	{
		if(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.XinXiBiaoSHi[i]==95)
		{
			switch(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl)
			{
			case 0:
				SendBuff[SendLen]=SendBuff[SendLen];
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				break;
			case 1:
				SendBuff[SendLen]=SendBuff[SendLen]|0x40;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[0][P-1].QC,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].QC,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[2][P-1].QC,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].QC,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				break;
			case 2:
				SendBuff[SendLen]=SendBuff[SendLen]|0x80;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].QC,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].QC,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				break;
			case 3:
				SendBuff[SendLen]=SendBuff[SendLen]|0xc0;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].QC,&SendBuff[SendLen],3);
				SendLen=SendLen+3;
				break;
			}
			break;
		}
	}

	if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
	return 1;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F97(INT8U F,INT8U P,INT8U QxBl,INT8U FRM)//��Ч
{
	INT8U i;
	TS ts;
	TSGet(&ts);
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	i=((ts.Hour+23)%24);
	SendBuff[SendLen]=((i/10)<<4)+(i%10);
	for(i=0;i<RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJie_Num;i++)
	{
		if(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.XinXiBiaoSHi[i]==97)
		{
			switch(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl)
			{
			case 0:
				SendBuff[SendLen]=SendBuff[SendLen];
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				break;
			case 1:
				SendBuff[SendLen]=SendBuff[SendLen]|0x40;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[0][P-1].VA,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].VA,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[2][P-1].VA,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].VA,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				break;
			case 2:
				SendBuff[SendLen]=SendBuff[SendLen]|0x80;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].VA,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].VA,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				break;
			case 3:
				SendBuff[SendLen]=SendBuff[SendLen]|0xc0;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].VA,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				break;
			}
			break;
		}
	}

	if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
	return 1;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F98(INT8U F,INT8U P,INT8U QxBl,INT8U FRM)//��Ч
{
	INT8U i;
	TS ts;
	TSGet(&ts);
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	i=((ts.Hour+23)%24);
	SendBuff[SendLen]=((i/10)<<4)+(i%10);
	for(i=0;i<RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJie_Num;i++)
	{
		if(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.XinXiBiaoSHi[i]==98)
		{
			switch(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl)
			{
			case 0:
				SendBuff[SendLen]=SendBuff[SendLen];
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				break;
			case 1:
				SendBuff[SendLen]=SendBuff[SendLen]|0x40;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[0][P-1].VB,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].VB,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[2][P-1].VB,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].VB,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				break;
			case 2:
				SendBuff[SendLen]=SendBuff[SendLen]|0x80;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].VB,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].VB,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				break;
			case 3:
				SendBuff[SendLen]=SendBuff[SendLen]|0xc0;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].VB,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				break;
			}
			break;
		}
	}

	if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
	return 1;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F99(INT8U F,INT8U P,INT8U QxBl,INT8U FRM)//��Ч
{
	INT8U i;
	TS ts;
	TSGet(&ts);
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	i=((ts.Hour+23)%24);
	SendBuff[SendLen]=((i/10)<<4)+(i%10);
	for(i=0;i<RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJie_Num;i++)
	{
		if(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.XinXiBiaoSHi[i]==99)
		{
			switch(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl)
			{
			case 0:
				SendBuff[SendLen]=SendBuff[SendLen];
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				break;
			case 1:
				SendBuff[SendLen]=SendBuff[SendLen]|0x40;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[0][P-1].VC,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].VC,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[2][P-1].VC,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].VC,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				break;
			case 2:
				SendBuff[SendLen]=SendBuff[SendLen]|0x80;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].VC,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].VC,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				break;
			case 3:
				SendBuff[SendLen]=SendBuff[SendLen]|0xc0;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].VC,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				break;
			}
			break;
		}
	}

	if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
	return 1;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F100(INT8U F,INT8U P,INT8U QxBl,INT8U FRM)//��Ч
{
	INT8U i;
	TS ts;
	TSGet(&ts);
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	i=((ts.Hour+23)%24);
	SendBuff[SendLen]=((i/10)<<4)+(i%10);
	for(i=0;i<RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJie_Num;i++)
	{
		if(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.XinXiBiaoSHi[i]==100)
		{
			switch(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl)
			{
			case 0:
				SendBuff[SendLen]=SendBuff[SendLen];
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				break;
			case 1:
				SendBuff[SendLen]=SendBuff[SendLen]|0x40;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[0][P-1].IA,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].IA,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[2][P-1].IA,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].IA,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				break;
			case 2:
				SendBuff[SendLen]=SendBuff[SendLen]|0x80;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].IA,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].IA,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				break;
			case 3:
				SendBuff[SendLen]=SendBuff[SendLen]|0xc0;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].IA,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				break;
			}
			break;
		}
	}

	if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
	return 1;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F101(INT8U F,INT8U P,INT8U QxBl,INT8U FRM)//��Ч
{
	INT8U i;
	TS ts;
	TSGet(&ts);
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	i=((ts.Hour+23)%24);
	SendBuff[SendLen]=((i/10)<<4)+(i%10);
	for(i=0;i<RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJie_Num;i++)
	{
		if(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.XinXiBiaoSHi[i]==101)
		{
			switch(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl)
			{
			case 0:
				SendBuff[SendLen]=SendBuff[SendLen];
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				break;
			case 1:
				SendBuff[SendLen]=SendBuff[SendLen]|0x40;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[0][P-1].IB,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].IB,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[2][P-1].IB,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].IB,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				break;
			case 2:
				SendBuff[SendLen]=SendBuff[SendLen]|0x80;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].IB,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].IB,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				break;
			case 3:
				SendBuff[SendLen]=SendBuff[SendLen]|0xc0;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].IB,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				break;
			}
			break;
		}
	}

	if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
	return 1;
}
/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F102(INT8U F,INT8U P,INT8U QxBl,INT8U FRM)//��Ч
{
	INT8U i;
	TS ts;
	TSGet(&ts);
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	i=((ts.Hour+23)%24);
	SendBuff[SendLen]=((i/10)<<4)+(i%10);
	for(i=0;i<RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJie_Num;i++)
	{
		if(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.XinXiBiaoSHi[i]==102)
		{
			switch(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl)
			{
			case 0:
				SendBuff[SendLen]=SendBuff[SendLen];
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				break;
			case 1:
				SendBuff[SendLen]=SendBuff[SendLen]|0x40;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[0][P-1].IC,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].IC,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[2][P-1].IC,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].IC,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				break;
			case 2:
				SendBuff[SendLen]=SendBuff[SendLen]|0x80;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].IC,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].IC,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				break;
			case 3:
				SendBuff[SendLen]=SendBuff[SendLen]|0xc0;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].IC,&SendBuff[SendLen],2);
				SendLen=SendLen+2;
				break;
			}
			break;
		}
	}

	if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
	return 1;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F103(INT8U F,INT8U P,INT8U QxBl,INT8U FRM)//��Ч
{
	////if(AutoFlg==0)
	////	MkLevel1Head(P,F,FRM);
	////SendNAK(F,P,0x0c);
	return 0;
}

#ifndef BJJiChao

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F105(INT8U F,INT8U P,INT8U QxBl,INT8U FRM)
{
	INT8U i;
	TS ts;
	TSGet(&ts);
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	i=((ts.Hour+23)%24);
	SendBuff[SendLen]=((i/10)<<4)+(i%10);
	for(i=0;i<RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJie_Num;i++)
	{
		if(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.XinXiBiaoSHi[i]==105)
		{
			switch(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl)
			{
			case 0:
				SendBuff[SendLen]=SendBuff[SendLen];
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				break;
			case 1:
				SendBuff[SendLen]=SendBuff[SendLen]|0x40;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[0][P-1].Z_P_All*100,&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].Z_P_All*100,&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[2][P-1].Z_P_All*100,&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].Z_P_All*100,&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				break;
			case 2:
				SendBuff[SendLen]=SendBuff[SendLen]|0x80;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD((RtuDataAddr->OldHour_DD_BS_Value[0][P-1].Z_P_All+RtuDataAddr->OldHour_DD_BS_Value[1][P-1].Z_P_All)*100,&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				INT32ToBCD((RtuDataAddr->OldHour_DD_BS_Value[2][P-1].Z_P_All+RtuDataAddr->OldHour_DD_BS_Value[3][P-1].Z_P_All)*100,&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				break;
			case 3:
				SendBuff[SendLen]=SendBuff[SendLen]|0xc0;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD((RtuDataAddr->OldHour_DD_BS_Value[0][P-1].Z_P_All+RtuDataAddr->OldHour_DD_BS_Value[1][P-1].Z_P_All
					+RtuDataAddr->OldHour_DD_BS_Value[2][P-1].Z_P_All+RtuDataAddr->OldHour_DD_BS_Value[3][P-1].Z_P_All)*100,&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				break;
			}
			break;
		}
	}

	if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
	return 1;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F106(INT8U F,INT8U P,INT8U QxBl,INT8U FRM)
{
	INT8U i;
	TS ts;
	TSGet(&ts);
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	i=((ts.Hour+23)%24);
	SendBuff[SendLen]=((i/10)<<4)+(i%10);
	for(i=0;i<RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJie_Num;i++)
	{
		if(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.XinXiBiaoSHi[i]==106)
		{
			switch(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl)
			{
			case 0:
				SendBuff[SendLen]=SendBuff[SendLen];
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				break;
			case 1:
				SendBuff[SendLen]=SendBuff[SendLen]|0x40;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[0][P-1].Z_Q_All*100,&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].Z_Q_All*100,&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[2][P-1].Z_Q_All*100,&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].Z_Q_All*100,&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				break;
			case 2:
				SendBuff[SendLen]=SendBuff[SendLen]|0x80;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD((RtuDataAddr->OldHour_DD_BS_Value[0][P-1].Z_Q_All+RtuDataAddr->OldHour_DD_BS_Value[1][P-1].Z_Q_All)*100,&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				INT32ToBCD((RtuDataAddr->OldHour_DD_BS_Value[2][P-1].Z_Q_All+RtuDataAddr->OldHour_DD_BS_Value[3][P-1].Z_Q_All)*100,&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				break;
			case 3:
				SendBuff[SendLen]=SendBuff[SendLen]|0xc0;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD((RtuDataAddr->OldHour_DD_BS_Value[0][P-1].Z_Q_All+RtuDataAddr->OldHour_DD_BS_Value[1][P-1].Z_Q_All
					+RtuDataAddr->OldHour_DD_BS_Value[2][P-1].Z_Q_All+RtuDataAddr->OldHour_DD_BS_Value[3][P-1].Z_Q_All)*100,&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				break;
			}
			break;
		}
	}

	if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
	return 1;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F107(INT8U F,INT8U P,INT8U QxBl,INT8U FRM)
{
	INT8U i;
	TS ts;
	TSGet(&ts);
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	i=((ts.Hour+23)%24);
	SendBuff[SendLen]=((i/10)<<4)+(i%10);
	for(i=0;i<RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJie_Num;i++)
	{
		if(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.XinXiBiaoSHi[i]==107)
		{
			switch(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl)
			{
			case 0:
				SendBuff[SendLen]=SendBuff[SendLen];
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				break;
			case 1:
				SendBuff[SendLen]=SendBuff[SendLen]|0x40;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[0][P-1].F_P_All*100,&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].F_P_All*100,&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[2][P-1].F_P_All*100,&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].F_P_All*100,&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				break;
			case 2:
				SendBuff[SendLen]=SendBuff[SendLen]|0x80;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD((RtuDataAddr->OldHour_DD_BS_Value[0][P-1].F_P_All+RtuDataAddr->OldHour_DD_BS_Value[1][P-1].F_P_All)*100,&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				INT32ToBCD((RtuDataAddr->OldHour_DD_BS_Value[2][P-1].F_P_All+RtuDataAddr->OldHour_DD_BS_Value[3][P-1].F_P_All)*100,&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				break;
			case 3:
				SendBuff[SendLen]=SendBuff[SendLen]|0xc0;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD((RtuDataAddr->OldHour_DD_BS_Value[0][P-1].F_P_All+RtuDataAddr->OldHour_DD_BS_Value[1][P-1].F_P_All
					+RtuDataAddr->OldHour_DD_BS_Value[2][P-1].F_P_All+RtuDataAddr->OldHour_DD_BS_Value[3][P-1].F_P_All)*100,&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				break;
			}
			break;
		}
	}

	if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
	return 1;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F108(INT8U F,INT8U P,INT8U QxBl,INT8U FRM)
{
	INT8U i;
	TS ts;
	TSGet(&ts);
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	i=((ts.Hour+23)%24);
	SendBuff[SendLen]=((i/10)<<4)+(i%10);
	for(i=0;i<RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJie_Num;i++)
	{
		if(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.XinXiBiaoSHi[i]==108)
		{
			switch(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl)
			{
			case 0:
				SendBuff[SendLen]=SendBuff[SendLen];
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				break;
			case 1:
				SendBuff[SendLen]=SendBuff[SendLen]|0x40;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[0][P-1].F_Q_All*100,&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].F_Q_All*100,&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[2][P-1].F_Q_All*100,&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].F_Q_All*100,&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				break;
			case 2:
				SendBuff[SendLen]=SendBuff[SendLen]|0x80;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD((RtuDataAddr->OldHour_DD_BS_Value[0][P-1].F_Q_All+RtuDataAddr->OldHour_DD_BS_Value[1][P-1].F_Q_All)*100,&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				INT32ToBCD((RtuDataAddr->OldHour_DD_BS_Value[2][P-1].F_Q_All+RtuDataAddr->OldHour_DD_BS_Value[3][P-1].F_Q_All)*100,&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				break;
			case 3:
				SendBuff[SendLen]=SendBuff[SendLen]|0xc0;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD((RtuDataAddr->OldHour_DD_BS_Value[0][P-1].F_Q_All+RtuDataAddr->OldHour_DD_BS_Value[1][P-1].F_Q_All
					+RtuDataAddr->OldHour_DD_BS_Value[2][P-1].F_Q_All+RtuDataAddr->OldHour_DD_BS_Value[3][P-1].F_Q_All)*100,&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				break;
			}
			break;
		}
	}

	if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
	return 1;
}
#endif
/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F109(INT8U F,INT8U P,INT8U QxBl,INT8U FRM)
{
	INT8U i;
	TS ts;
	TSGet(&ts);
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	i=((ts.Hour+23)%24);
	SendBuff[SendLen]=((i/10)<<4)+(i%10);
	for(i=0;i<RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJie_Num;i++)
	{
		if(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.XinXiBiaoSHi[i]==109)
		{
			switch(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl)
			{
			case 0:
				SendBuff[SendLen]=SendBuff[SendLen];
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				break;
			case 1:
				SendBuff[SendLen]=SendBuff[SendLen]|0x40;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[0][P-1].Z_P_F[0],&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].Z_P_F[0],&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[2][P-1].Z_P_F[0],&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].Z_P_F[0],&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				break;
			case 2:
				SendBuff[SendLen]=SendBuff[SendLen]|0x80;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].Z_P_F[0],&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].Z_P_F[0],&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				break;
			case 3:
				SendBuff[SendLen]=SendBuff[SendLen]|0xc0;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].Z_P_F[0],&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				break;
			}
			break;
		}
	}

	if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
	return 1;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F110(INT8U F,INT8U P,INT8U QxBl,INT8U FRM)
{
	INT8U i;
	TS ts;
	TSGet(&ts);
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	i=((ts.Hour+23)%24);
	SendBuff[SendLen]=((i/10)<<4)+(i%10);
	for(i=0;i<RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJie_Num;i++)
	{
		if(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.XinXiBiaoSHi[i]==110)
		{
			switch(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl)
			{
			case 0:
				SendBuff[SendLen]=SendBuff[SendLen];
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				break;
			case 1:
				SendBuff[SendLen]=SendBuff[SendLen]|0x40;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[0][P-1].Z_Q_F[0],&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].Z_Q_F[0],&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[2][P-1].Z_Q_F[0],&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].Z_Q_F[0],&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				break;
			case 2:
				SendBuff[SendLen]=SendBuff[SendLen]|0x80;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].Z_Q_F[0],&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].Z_Q_F[0],&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				break;
			case 3:
				SendBuff[SendLen]=SendBuff[SendLen]|0xc0;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].Z_Q_F[0],&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				break;
			}
			break;
		}
	}

	if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
	return 1;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F111(INT8U F,INT8U P,INT8U QxBl,INT8U FRM)
{
	INT8U i;
	TS ts;
	TSGet(&ts);
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	i=((ts.Hour+23)%24);
	SendBuff[SendLen]=((i/10)<<4)+(i%10);
	for(i=0;i<RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJie_Num;i++)
	{
		if(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.XinXiBiaoSHi[i]==111)
		{
			switch(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl)
			{
			case 0:
				SendBuff[SendLen]=SendBuff[SendLen];
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				break;
			case 1:
				SendBuff[SendLen]=SendBuff[SendLen]|0x40;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[0][P-1].F_P_F[0],&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].F_P_F[0],&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[2][P-1].F_P_F[0],&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].F_P_F[0],&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				break;
			case 2:
				SendBuff[SendLen]=SendBuff[SendLen]|0x80;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].F_P_F[0],&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].F_P_F[0],&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				break;
			case 3:
				SendBuff[SendLen]=SendBuff[SendLen]|0xc0;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].F_P_F[0],&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				break;
			}
			break;
		}
	}

	if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
	return 1;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F112(INT8U F,INT8U P,INT8U QxBl,INT8U FRM)
{
	INT8U i;
	TS ts;
	TSGet(&ts);
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	i=((ts.Hour+23)%24);
	SendBuff[SendLen]=((i/10)<<4)+(i%10);
	for(i=0;i<RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJie_Num;i++)
	{
		if(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.XinXiBiaoSHi[i]==112)
		{
			switch(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl)
			{
			case 0:
				SendBuff[SendLen]=SendBuff[SendLen];
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				break;
			case 1:
				SendBuff[SendLen]=SendBuff[SendLen]|0x40;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[0][P-1].F_Q_F[0],&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].F_Q_F[0],&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[2][P-1].F_Q_F[0],&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].F_Q_F[0],&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				break;
			case 2:
				SendBuff[SendLen]=SendBuff[SendLen]|0x80;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].F_Q_F[0],&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].F_Q_F[0],&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				break;
			case 3:
				SendBuff[SendLen]=SendBuff[SendLen]|0xc0;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].F_Q_F[0],&SendBuff[SendLen],4);
				SendLen=SendLen+4;
				break;
			}
			break;
		}
	}

	if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
	return 1;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F113(INT8U F,INT8U P,INT8U QxBl,INT8U FRM)
{
	INT8U i;
	TS ts;
	TSGet(&ts);
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	i=((ts.Hour+23)%24);
	SendBuff[SendLen]=((i/10)<<4)+(i%10);
	for(i=0;i<RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJie_Num;i++)
	{
		if(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.XinXiBiaoSHi[i]==113)
		{
			switch(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl)
			{
			case 0:
				SendBuff[SendLen]=SendBuff[SendLen];
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				break;
			case 1:
				SendBuff[SendLen]=SendBuff[SendLen]|0x40;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[0][P-1].Cos,&SendBuff[SendLen],2);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].Cos,&SendBuff[SendLen],2);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[2][P-1].Cos,&SendBuff[SendLen],2);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].Cos,&SendBuff[SendLen],2);
				SendLen=SendLen+4;
				break;
			case 2:
				SendBuff[SendLen]=SendBuff[SendLen]|0x80;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].Cos,&SendBuff[SendLen],2);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].Cos,&SendBuff[SendLen],2);
				SendLen=SendLen+4;
				break;
			case 3:
				SendBuff[SendLen]=SendBuff[SendLen]|0xc0;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].Cos,&SendBuff[SendLen],2);
				SendLen=SendLen+4;
				break;
			}
			break;
		}
	}

	if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
	return 1;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F114(INT8U F,INT8U P,INT8U QxBl,INT8U FRM)
{
	INT8U i;
	TS ts;
	TSGet(&ts);
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	i=((ts.Hour+23)%24);
	SendBuff[SendLen]=((i/10)<<4)+(i%10);
	for(i=0;i<RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJie_Num;i++)
	{
		if(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.XinXiBiaoSHi[i]==114)
		{
			switch(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl)
			{
			case 0:
				SendBuff[SendLen]=SendBuff[SendLen];
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				break;
			case 1:
				SendBuff[SendLen]=SendBuff[SendLen]|0x40;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[0][P-1].CosA,&SendBuff[SendLen],2);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].CosA,&SendBuff[SendLen],2);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[2][P-1].CosA,&SendBuff[SendLen],2);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].CosA,&SendBuff[SendLen],2);
				SendLen=SendLen+4;
				break;
			case 2:
				SendBuff[SendLen]=SendBuff[SendLen]|0x80;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].CosA,&SendBuff[SendLen],2);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].CosA,&SendBuff[SendLen],2);
				SendLen=SendLen+4;
				break;
			case 3:
				SendBuff[SendLen]=SendBuff[SendLen]|0xc0;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].CosA,&SendBuff[SendLen],2);
				SendLen=SendLen+4;
				break;
			}
			break;
		}
	}

	if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
	return 1;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F115(INT8U F,INT8U P,INT8U QxBl,INT8U FRM)
{
	INT8U i;
	TS ts;
	TSGet(&ts);
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	i=((ts.Hour+23)%24);
	SendBuff[SendLen]=((i/10)<<4)+(i%10);
	for(i=0;i<RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJie_Num;i++)
	{
		if(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.XinXiBiaoSHi[i]==115)
		{
			switch(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl)
			{
			case 0:
				SendBuff[SendLen]=SendBuff[SendLen];
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				break;
			case 1:
				SendBuff[SendLen]=SendBuff[SendLen]|0x40;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[0][P-1].CosB,&SendBuff[SendLen],2);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].CosB,&SendBuff[SendLen],2);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[2][P-1].CosB,&SendBuff[SendLen],2);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].CosB,&SendBuff[SendLen],2);
				SendLen=SendLen+4;
				break;
			case 2:
				SendBuff[SendLen]=SendBuff[SendLen]|0x80;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].CosB,&SendBuff[SendLen],2);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].CosB,&SendBuff[SendLen],2);
				SendLen=SendLen+4;
				break;
			case 3:
				SendBuff[SendLen]=SendBuff[SendLen]|0xc0;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].CosB,&SendBuff[SendLen],2);
				SendLen=SendLen+4;
				break;
			}
			break;
		}
	}

	if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
	return 1;
}

/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F116(INT8U F,INT8U P,INT8U QxBl,INT8U FRM)
{
	INT8U i;
	TS ts;
	TSGet(&ts);
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	i=((ts.Hour+23)%24);
	SendBuff[SendLen]=((i/10)<<4)+(i%10);
	for(i=0;i<RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJie_Num;i++)
	{
		if(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.XinXiBiaoSHi[i]==116)
		{
			switch(RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl)
			{
			case 0:
				SendBuff[SendLen]=SendBuff[SendLen];
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				break;
			case 1:
				SendBuff[SendLen]=SendBuff[SendLen]|0x40;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[0][P-1].CosC,&SendBuff[SendLen],2);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].CosC,&SendBuff[SendLen],2);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[2][P-1].CosC,&SendBuff[SendLen],2);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].CosC,&SendBuff[SendLen],2);
				SendLen=SendLen+4;
				break;
			case 2:
				SendBuff[SendLen]=SendBuff[SendLen]|0x80;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[1][P-1].CosC,&SendBuff[SendLen],2);
				SendLen=SendLen+4;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].CosC,&SendBuff[SendLen],2);
				SendLen=SendLen+4;
				break;
			case 3:
				SendBuff[SendLen]=SendBuff[SendLen]|0xc0;
				SendLen++;
				SendBuff[SendLen]=RtuDataAddr->Cl_MenXian_Value[P-1].F27_Set_Para.DongJieMiDu[i]*QxBl;
				SendLen++;
				INT32ToBCD(RtuDataAddr->OldHour_DD_BS_Value[3][P-1].CosC,&SendBuff[SendLen],2);
				SendLen=SendLen+4;
				break;
			}
			break;
		}
	}

	if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
	return 1;
}
/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F129(INT8U F,INT8U P,INT8U FRM)
{
	INT8U i;
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	if(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Valid==1)
	{
		///////////////make f1
		memcpy(&SendBuff[SendLen],&RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Chao_Time.BCD01,sizeof(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Chao_Time));
		SendLen=SendLen+5;
		SendBuff[SendLen++]=4;
		SendBuff[SendLen++]=0;
		INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Z_P_All,&SendBuff[SendLen],4);//�����й���
		SendLen=SendLen+4;
		for(i=0;i<FeiLvNum;i++)
		{
			SendBuff[SendLen++]=0;
			INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Z_P_F[i],&SendBuff[SendLen],4);//�����й���4����
			SendLen=SendLen+4;
		}
		if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
		return 1;
	}
		////SendNAK(F,P,0x0c);
	////return 0;
	memset(&SendBuff[SendLen],0xee,5);
	SendLen = SendLen + 5;
	SendBuff[SendLen++]=4;
	memset(&SendBuff[SendLen],0xee,25);
	SendLen = SendLen + 25;
	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F130(INT8U F,INT8U P,INT8U FRM)
{
	INT8U i;
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	if(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Valid==1)
	{
		///////////////make f1
		memcpy(&SendBuff[SendLen],&RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Chao_Time.BCD01,sizeof(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Chao_Time));
		SendLen=SendLen+5;
		SendBuff[SendLen++]=4;
		INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Z_Q_All,&SendBuff[SendLen],4);//�����޹���
		SendLen=SendLen+4;
		for(i=0;i<FeiLvNum;i++)
		{
			INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Z_Q_F[i],&SendBuff[SendLen],4);//�����޹�4����
			SendLen=SendLen+4;
		}

		if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
		return 1;
	}
		////SendNAK(F,P,0x0c);
	////return 0;
	memset(&SendBuff[SendLen],0xee,5);
	SendLen = SendLen + 5;
	SendBuff[SendLen++]=4;
	memset(&SendBuff[SendLen],0xee,20);
	SendLen = SendLen + 20;
	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F131(INT8U F,INT8U P,INT8U FRM)
{
	INT8U i;
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	if(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Valid==1)
	{
		///////////////make f1
		memcpy(&SendBuff[SendLen],&RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Chao_Time.BCD01,sizeof(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Chao_Time));
		SendLen=SendLen+5;
		SendBuff[SendLen++]=4;
		SendBuff[SendLen++]=0;
		INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].F_P_All,&SendBuff[SendLen],4);
		SendLen=SendLen+4;
		for(i=0;i<FeiLvNum;i++)
		{
			SendBuff[SendLen++]=0;
			INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].F_P_F[i],&SendBuff[SendLen],4);
			SendLen=SendLen+4;
		}
		if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
		return 1;
	}
		////SendNAK(F,P,0x0c);
	////return 0;
	memset(&SendBuff[SendLen],0xee,5);
	SendLen = SendLen + 5;
	SendBuff[SendLen++]=4;
	memset(&SendBuff[SendLen],0xee,25);
	SendLen = SendLen + 25;
	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F132(INT8U F,INT8U P,INT8U FRM)
{
	INT8U i;
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	if(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Valid==1)
	{
		///////////////make f1
		memcpy(&SendBuff[SendLen],&RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Chao_Time.BCD01,sizeof(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Chao_Time));
		SendLen=SendLen+5;
		SendBuff[SendLen++]=4;
		INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].F_Q_All,&SendBuff[SendLen],4);
		SendLen=SendLen+4;
		for(i=0;i<FeiLvNum;i++)
		{
			INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].F_Q_F[i],&SendBuff[SendLen],4);
			SendLen=SendLen+4;
		}

		if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
		return 1;
	}
		////SendNAK(F,P,0x0c);
	////return 0;
	memset(&SendBuff[SendLen],0xee,5);
	SendLen = SendLen + 5;
	SendBuff[SendLen++]=4;
	memset(&SendBuff[SendLen],0xee,20);
	SendLen = SendLen + 20;
	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F133(INT8U F,INT8U P,INT8U FRM)
{
	INT8U i;
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	if(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Valid==1)
	{
		///////////////make f1
		memcpy(&SendBuff[SendLen],&RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Chao_Time.BCD01,sizeof(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Chao_Time));
		SendLen=SendLen+5;
		SendBuff[SendLen++]=4;

		INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].X1_Q_All,&SendBuff[SendLen],4);//һ�����޹���
		SendLen=SendLen+4;
		for(i=0;i<FeiLvNum;i++)
		{
			INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].X1_F_Q[i],&SendBuff[SendLen],4);//һ�����޹�4����
			SendLen=SendLen+4;
		}

		if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
		return 1;
	}
		////SendNAK(F,P,0x0c);
	////return 0;
	memset(&SendBuff[SendLen],0xee,5);
	SendLen = SendLen + 5;
	SendBuff[SendLen++]=4;
	memset(&SendBuff[SendLen],0xee,20);
	SendLen = SendLen + 20;
	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F134(INT8U F,INT8U P,INT8U FRM)
{
	INT8U i;
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	if(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Valid==1)
	{
		///////////////make f1
		memcpy(&SendBuff[SendLen],&RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Chao_Time.BCD01,sizeof(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Chao_Time));
		SendLen=SendLen+5;
		SendBuff[SendLen++]=4;
		INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].X2_Q_All,&SendBuff[SendLen],4);
		SendLen=SendLen+4;
		for(i=0;i<FeiLvNum;i++)
		{
			INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].X2_F_Q[i],&SendBuff[SendLen],4);
			SendLen=SendLen+4;
		}

		if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
		return 1;
	}
		////SendNAK(F,P,0x0c);
	////return 0;
	memset(&SendBuff[SendLen],0xee,5);
	SendLen = SendLen + 5;
	SendBuff[SendLen++]=4;
	memset(&SendBuff[SendLen],0xee,20);
	SendLen = SendLen + 20;
	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F135(INT8U F,INT8U P,INT8U FRM)
{
	INT8U i;
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	if(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Valid==1)
	{
		///////////////make f1
		memcpy(&SendBuff[SendLen],&RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Chao_Time.BCD01,sizeof(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Chao_Time));
		SendLen=SendLen+5;
		SendBuff[SendLen++]=4;
		INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].X3_Q_All,&SendBuff[SendLen],4);
		SendLen=SendLen+4;
		for(i=0;i<FeiLvNum;i++)
		{
			INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].X3_F_Q[i],&SendBuff[SendLen],4);
			SendLen=SendLen+4;
		}

		if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
		return 1;
	}
		////SendNAK(F,P,0x0c);
	////return 0;
	memset(&SendBuff[SendLen],0xee,5);
	SendLen = SendLen + 5;
	SendBuff[SendLen++]=4;
	memset(&SendBuff[SendLen],0xee,20);
	SendLen = SendLen + 20;
	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
/**********************************************************************
***********************************************************************/
INT8U Set_Level1_F136(INT8U F,INT8U P,INT8U FRM)
{
	INT8U i;
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	if(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Valid==1)
	{
		///////////////make f1
		memcpy(&SendBuff[SendLen],&RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Chao_Time.BCD01,sizeof(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Chao_Time));
		SendLen=SendLen+5;
		SendBuff[SendLen++]=4;

		INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].X4_Q_All,&SendBuff[SendLen],4);//�������޹���
		SendLen=SendLen+4;
		for(i=0;i<FeiLvNum;i++)
		{
			INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].X4_F_Q[i],&SendBuff[SendLen],4);//�������޹�4����
			SendLen=SendLen+4;
		}

		if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
		return 1;
	}
		////SendNAK(F,P,0x0c);
	////return 0;
	memset(&SendBuff[SendLen],0xee,5);
	SendLen = SendLen + 5;
	SendBuff[SendLen++]=4;
	memset(&SendBuff[SendLen],0xee,20);
	SendLen = SendLen + 20;
	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}


void INT16_A8(INT16U Value,unsigned char * bcd)
{
	bcd[1]=(Value/1000)<<4;
	Value=Value%1000;
	bcd[1]=bcd[1]|(Value/100);
	Value=Value%100;
	bcd[0]=(Value/10)<<4;
	Value=Value%10;
	bcd[0]=bcd[0]|(Value);
}
INT8U Set_Level1_F166(INT8U F,INT8U P,INT8U FRM)
{
	unsigned char BCD[2];
	if(AutoFlg==0)
		MkLevel1Head(P,F,FRM);
	if(RtuDataAddr->DD_BianLiang_Shuju[P-1].Valid==1)
	{
		memcpy(&SendBuff[SendLen],&RtuDataAddr->DD_BianLiang_Shuju[P-1].Chao_Time.BCD01,sizeof(RtuDataAddr->DD_Device_BiaoShi_Value[P-1].Chao_Time));
		SendLen=SendLen+5;
		memcpy(&SendBuff[SendLen],RtuDataAddr->DD_BianLiang_Shuju[P-1].JiaoshiNum,2);
		SendLen=SendLen+2;
		memcpy(&SendBuff[SendLen],&RtuDataAddr->DD_BianLiang_Shuju[P-1].LastJiaoshi_Time[1],5);
		SendLen=SendLen+5;
		INT16_A8(RtuDataAddr->ShiDuanBianHuaCount,BCD);
		memcpy(&SendBuff[SendLen],BCD,2);
		SendLen=SendLen+2;
		memcpy(&SendBuff[SendLen],RtuDataAddr->Last_ShiDuanChange_Time,5);
		SendLen=SendLen+5;

		if (AutoFlg!=0) return 1;
		EC();
		TP();
		FrameTailCreate_Send();
		return 1;
	}
	////SendNAK(F,P,0x0c);
	////return 0;
	memset(&SendBuff[SendLen],0xee,19);
	SendLen = SendLen + 19;
	if (AutoFlg!=0) return 1;
	EC();
	TP();
	FrameTailCreate_Send();
	return 1;
}
