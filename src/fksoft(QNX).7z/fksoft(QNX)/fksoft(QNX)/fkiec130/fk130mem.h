#ifndef FK130MEM_H_
#define FK130MEM_H_
#include <fkbase/memdef.h>
#include <fkbase/fkbasefun.h>

#define DebugOut if(RtuDataAddr->TASK130DBON)printf

#define AT91C_PIO_PA27        (1 <<  27) // Pin Controlled by PA27  //GPRS_ID0
#define AT91C_PIO_PB17        (1 <<  17) // Pin Controlled by PA27  //GPRS_ID1
#define AT91C_PIO_PB18       (1 <<  18) // Pin Controlled by PA27  //GPRS_ID2
#define AT91C_PIO_PB26        (1 <<  26) // Pin Controlled by PA27  //GPRS_ID3
#define AT91C_PIO_PB27        (1 <<  27) // Pin Controlled by PA27  //GPRS_ID4
RTimeData  *RtuDataAddr;//�ڴ湲��������ָ��
name_attach_t *attach;
int ComPort;
int 	dscr;
struct 	sockaddr_in server;

//liujia
unsigned char   XieyiVer[5];
unsigned char   HwVer[5];
unsigned char	HwDate[4];

unsigned char 	Asdu130Addr[5];
unsigned char 	CoLtd[5];
unsigned char	DevCode[9];
unsigned char	ProgVer[5];
unsigned char	ProgDate[4];
unsigned char	RongLiang[12];

unsigned char 	Tmp130Buff[FrameSize];
unsigned char	seq;
unsigned char	task1_Delay_Count[Task_Max];
unsigned char	task2_Delay_Count[Task_Max];
unsigned int 	SendLen;
unsigned char 	NeedTp;
unsigned char	DA[65],DT[255];//103��Լ������Ϣ//���DA[64]������δ��������һ��Ҳ�ﲻ�����˴�ע�⣬���޸�
unsigned char   Passwd[16];
unsigned int 	RecDataLen;
unsigned char 	TpBuff[6],MSA;
unsigned char	HeartBeat_Count;
unsigned int	Resolve_Pos;
unsigned char	SetAvailable[31];
unsigned char	RecBuf[FrameSize];
unsigned char	SendBuff[FrameSize];
unsigned int	RecTail;
unsigned int	RecHead;
unsigned int	AllReportHead,AllReportTail;
unsigned char DaySaving;
unsigned char Gprs_Moduleok;
unsigned char WirelessModuleType;
unsigned char linked_ok;
////////����ʹ��
unsigned char 	FK_130_Link_Ok;
unsigned char 	ReadEveHead,ReadEveTail;
INT8U PORT_ID;
WirelessPara		CommPara;
int ComPort;
INT8U				TmpBuf[FrameSize];
INT8U     AutoFlg;			//�Զ����ͱ�־ 1 �Զ�
#endif /*FK130MEM_H_*/
