/*
 * ppp.h
 *
 *  Created on: 2010-3-17
 *      Author: Administrator
 */

#ifndef PPP_H_
#define PPP_H_
#include "base130fun.h"
#include <netinet/tcp.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <sys/ioctl.h>
#include <stdio.h>
#include <string.h>
#include <net/if.h>
#include <netinet/in.h>
#include <arpa/inet.h>


extern unsigned int 	SendLen;
extern unsigned int		RecTail,RecHead;
extern unsigned char	RecBuf[FrameSize];
extern unsigned char	SendBuff[FrameSize];
struct thread_param{
	int run;
	unsigned char port_id;
};
extern void initM22();
void ProcessDial();
void initApn(unsigned char id);
void initdata();
void GetMasterPara(char* ip_p,int* port_p);
void PPProcess();
int  GetConnect(char *ip,int port);
int  SendData(int client);
int  RevData(int client);
int  write_apn();
void mydelay(int s);
int  tryifconfig();
void CreatThread();
void ExitThread();
int  getCsq();
unsigned char portid;
char PppAPN[16];
int  apnSetOk;
int  client_s;
int  reconnect;
int SelfheartCount;
struct thread_param param;
pthread_t thread_clear;
void *clearpro();
#endif /* PPP_H_ */
