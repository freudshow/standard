/*
 * base130fun.c
 *
 *  Created on: 2009-12-16
 *      Author: www
 */
#include "base130fun.h"
extern void FrameSend();
const INT8U CMP8U[9]=
{
	0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80
};

/*****************************************************
 *��������:   PARSE_CMD
 *��������:   ����������,��ý������ơ��߼��˿ں�
 *�������:   main
 *�������:   �����в���
 *�������:   TRUE-�����кϷ�,FALSE-�����зǷ�
 *****************************************************/

/***********************************************************
*130 ͨѶ��Լ���ݽ��ռ��������ֺ���
*���ã�Pro130Comm(void)
*����������
***************************************************************/
INT8U CheckSum130(INT8U *buf,INT16U len)
{
	INT16U i;
	INT8U ret=0;
	for(i=0;i<len;i++)
	{
		ret=ret+buf[i];
	}
	return ret;
}
INT8U SaveControlSet()
{
	FILE *fp;
	sem_wait(&RtuDataAddr->UseFileFlg);
	fp=fopen("/config/p130set.set","w");
	if(fp!=NULL)
	{
//		fwrite(&RtuDataAddr->FkSet_Value,sizeof(RtuDataAddr->FkSet_Value),1,fp);
		fclose(fp);
		sem_post(&RtuDataAddr->UseFileFlg);
		return TRUE;
	}
	sem_post(&RtuDataAddr->UseFileFlg);
	return FALSE;
}

void ReadFrame()
{
	int len,i;
	unsigned char TmpBuf[256];
	memset(TmpBuf,0,256);
	if(FK_130_Link_Ok==0)return;
	len=read(dscr ,TmpBuf,200);
	if(len>0)
	{
//		fprintf(stderr,"\r\nrec ");
		for(i=0;i<len;i++)
		{
			RecBuf[RecHead]=TmpBuf[i];
//			fprintf(stderr,"[%x]",TmpBuf[i]);
			RecHead=(RecHead+1)%FrameSize;
		}
	}
	else
	{
		if(errno!=11)
		{
			close(dscr);
			FK_130_Link_Ok=0;
		}
		else
		{
//		fprintf(stderr,"\r\n%d",errno);
//		perror(" no is ");
		}
	}
}


unsigned char	user_init_io(const char *IP,unsigned int PORT)
{
//#if USENET
	unsigned char connectcount=0;
  	struct hostent *hp;
  	struct sockaddr_in server;
 	struct timeval timeset;
	int on;
  	int rcxid;
  	FK_130_Link_Ok = 0;
  	/* Name socket using wildcards */
 // 	fprintf(stderr,"\r\n%s %d ",IP,PORT);
  	delay(1000);
 //  	fprintf(stderr,"\r\n%s %d ",IP,PORT);
  	server.sin_family = AF_INET;
   	server.sin_port = htons(PORT);
 	dscr = socket(AF_INET, SOCK_STREAM, 0);
   	if(dscr<0) {
   	  	perror("opening stream socket");
     	delay(1000);
     	return EXIT_FAILURE;
   	}
	on=1;
   	setsockopt(dscr,SOL_SOCKET,SO_REUSEADDR,(char *) &on,sizeof(on));
	timeset.tv_sec=1;
	timeset.tv_usec=100000;
   	setsockopt(dscr,SOL_SOCKET,SO_RCVTIMEO, &timeset,sizeof(timeset));

   	hp = gethostbyname(IP);
 //  	fprintf(stderr,"\r\n%s ",IP);
 	fcntl(dscr,F_SETFL,O_NONBLOCK);
   	memcpy(&server.sin_addr,hp->h_addr,hp->h_length);
   	connectcount=0;
   	while(1)
   	{
	   	rcxid=connect(dscr,(struct sockaddr *)&server, sizeof(server));
 //	  	fprintf(stderr,"\r\nconnect = %d %d ",rcxid,errno);
 	 	if(rcxid < 0)
	   	{
  //		   	perror("connecting stream socket error");
  		   	if(errno==256)
  		   	{
    	 		FK_130_Link_Ok=1;
 		  		return 1;
  		   	}
  		   	connectcount++;
   		   	delay(500);
 		   	if(connectcount>10)
  		   	{
  		   	delay(500);
  		   	close(dscr);
  		 	return 0;
  		   	}
 	  	}
 	  	else
 	  	{
   	 		FK_130_Link_Ok=1;
 	  		return 1;
 	  	}
 	 	delay(100);
   	}
   	delay(1000);
   	return 1;
/*#else
	unsigned char tmp[128];
	sprintf(tmp,"stty </dev/ser0 baud=9600 par=none stopb=1 bits=8");
	fprintf(stderr, "ComPortpara %s ok!\n",tmp);
	system(tmp);
	sprintf(tmp,"/dev/ser0");
	delay(500);
	ComPort = open(tmp, O_RDWR);
	if (ComPort < 0 )
	{
		fprintf(stderr, "\nERROR: Open ComPort %s error!\n", tmp);
		return 0;
	}
	fprintf(stderr, "\nOK: Open ComPort %s ok!\n",tmp);
	return 1;
#endif
*/
}
INT8U 	TimeComp(INT8U *s)
{
	return 0;
}
INT16U CalcCRC(INT8U *pBuff,INT16U len,INT16U  wPsw)
{
	INT16U i,j;
	INT16U W_RslCRC,W_Reg;
	INT8U B_Tmp;
	union
	{
		INT16U W_Reg;
		INT8U B_Reg[2];
	}U_Reg;
	W_RslCRC = 0;
	for(i=0;i<len;i++)
	{
		W_RslCRC = W_RslCRC ^(INT16U )pBuff[i];
		for (j=0; j<8; j++)
		{
			W_Reg = W_RslCRC & 0x0001;
			W_RslCRC >>= 1;
			if (W_Reg)  W_RslCRC = W_RslCRC ^ wPsw;
		}
	}
	U_Reg.W_Reg = W_RslCRC;
	B_Tmp = U_Reg.B_Reg[0];
	U_Reg.B_Reg[0] = U_Reg.B_Reg[1];
	U_Reg.B_Reg[1] = B_Tmp;
	W_RslCRC = U_Reg.W_Reg;
	return W_RslCRC;
}
void EC()
{
	if(RtuDataAddr->EC1old!=RtuDataAddr->EC1)
	{
		SendBuff[6]=SendBuff[6]|0x20;
		SendBuff[SendLen++]=RtuDataAddr->EC1;
		SendBuff[SendLen++]=RtuDataAddr->EC2;
	}
	else
	{
		SendBuff[6]=SendBuff[6]&0xdf;
	}

}
INT8U SetDa1(INT8U Value)
{
	INT8U Result=1;
	if(Value==0)return 0;
	Value=Value-1;
	Result=Result<<(Value%8);
	return Result;
}
INT8U SetDa2(INT8U Value)
{
	INT8U Result=1;
	if(Value==0)return 0;
	Value=Value-1;
	Result=Result<<(Value/8);
	return Result;
}
void Create_Data_Type15(INT8U *Dest)
{
	TS ts;
	TSGet(&ts);
	Dest[0]=((ts.Minute/10)<<4)+(ts.Minute%10);
	Dest[1]=((ts.Hour/10)<<4)+(ts.Hour%10);
	Dest[2]=((ts.Day/10)<<4)+(ts.Day%10);
	Dest[3]=((ts.Month/10)<<4)+(ts.Month%10);
	Dest[4]=(((ts.Year%100)/10)<<4)+(ts.Year%10);
}
INT8U SetDt1(INT8U Value)
{
	INT8U Result=1;
	Value=Value-1;
	Result=Result<<(Value%8);
	return Result;
}

INT8U SetDt2(INT8U Value)
{
	Value=Value-1;
	return Value/8;
}
void TP()
{
	TS ts;
	TSGet(&ts);
	if(NeedTp)
	{
		SendBuff[13]=SendBuff[13]|0x80;
		memcpy(&SendBuff[SendLen],TpBuff,6);
		SendLen=SendLen+6;
	}
	else
	{
		SendBuff[13]=SendBuff[13]&0x7f;
	}
}
void GetDa(INT8U Da1,INT8U Da2)
{
	INT8U i,j;
	memset(DA,0,65);
	if((Da1==0)&&(Da2==0))
	{
		DA[0]=1;
		return;
	}
	if((Da1==0xff)&&(Da2==0xff))
	{
		memset(DA,1,65);
	}
	for(i=0;i<8;i++)
	{
		if(Da2&CMP8U[i])//1
		{
			for(j=0;j<8;j++)
			{
				if(Da1&CMP8U[j])
				{
					DA[i*8+j+1]=1;
				}
			}
		}
	}
}
INT8U testTime(INT8U *s )
{
	TS ts;
	INT8U Sec,Min,Hour,Day,Month,Year;
	TSGet(&ts);
	Sec=(s[0]>>4)*10;
	Sec=Sec+s[0]&0x0f;
	Min=(s[1]>>4)*10;
	Min=Min+s[1]&0x0f;
	Hour=(s[2]>>4)*10;
	Hour=Hour+s[2]&0x0f;
	Day=(s[3]>>4)*10;
	Day=Day+s[3]&0x0f;
	Month=((s[4]>>4)&1)*10;
	Month=Month+s[4]&0x0f;
	Year=((s[5]>>4)&1)*10;
	Year=Year+s[5]&0x0f;
	if((ts.Year%100)>Year)
	{
		return 1;
	}
	else
	{
		if((ts.Year%100)<Year)
		{
			return 0;
		}
		else
		{
			if(ts.Month>Month)
			{
				return 1;
			}
			else
			{
				if(ts.Month<Month)
				{
					return 0;
				}
				else
				{
					if(ts.Day>Day)
					{
						return 1;
					}
					else
					{
						if(ts.Day<Day)
						{
							return 0;
						}
						else
						{
							if(ts.Hour>Hour)
							{
								return 1;
							}
							else
							{
								if(ts.Hour<Hour)
								{
									return 0;
								}
								else
								{
									if(ts.Minute>Min)
									{
										return 1;
									}
									else
									{
										return 0;
									}
								}
							}
						}
					}
				}
			}
		}
	}
}
INT8U TestFirFin(INT8U DtNo,INT8U DaNo)
{
	INT8U Temp,i;
		Temp=0;
		i=0;
		if(AllReportTail==0)
		{
			Temp=0x40;
		}
		if((AllReportTail+1)==AllReportHead)
		{
			Temp=Temp|0x20;
		}
		AllReportTail=AllReportTail+1;
	/*INT8U Temp,i;
//	return 0x60;
	Temp=0x40;
	if(DtNo!=0)
		for(i=0;i<DtNo;i++)
		{
			if(DT[i])Temp=0;
		}
		if(DaNo!=0)
			for(i=0;i<DaNo;i++)
			{
				if(DA[i])Temp=0;
			}
			Temp=Temp|0x20;
			for(i=DtNo+1;i<249;i++)
			{
				if(DT[i])
				{
					Temp=Temp&0xdf;
					break;
				}
			}
			for(i=DaNo+1;i<64;i++)
			{
				if(DA[i])
				{
					Temp=Temp&0xdf;
					break;
				}
			}
			*/
			return Temp;
}
void GetDt(INT8U Dt1,INT8U Dt2)
{
	INT8U i;
	int dtx = 0;
	memset(DT,0,255);
	for(i=0;i<8;i++)
	{
		if(Dt1&CMP8U[i])
		{
			dtx = Dt2*8+i+1;
			if (dtx >254)
				continue;
			DT[Dt2*8+i+1]=1;
		}
	}
}
void FrameHeadCreate(INT8U PRM)
{
	SendLen=0;
	memset(SendBuff,0,FrameSize);
	SendBuff[SendLen++]=0x68;
	SendBuff[SendLen++]=0;
	SendBuff[SendLen++]=0;
	SendBuff[SendLen++]=0;
	SendBuff[SendLen++]=0;
	SendBuff[SendLen++]=0x68;
	SendBuff[SendLen++]=PRM;
	SendBuff[SendLen++]=Asdu130Addr[0];
	SendBuff[SendLen++]=Asdu130Addr[1];
	SendBuff[SendLen++]=Asdu130Addr[2];
	SendBuff[SendLen++]=Asdu130Addr[3];
	SendBuff[SendLen++]=Asdu130Addr[4];
}
void FrameTailCreate_Send()
{
	INT16U temp,i;
	temp=SendLen;
	temp=temp-6;
	temp=(temp<<2)|0x02;
	SendBuff[1]=temp&0xff;
	SendBuff[2]=(temp>>8)&0xff;
	SendBuff[3]=temp&0xff;
	SendBuff[4]=(temp>>8)&0xff;
	SendBuff[SendLen]=CheckSum130(&SendBuff[6],SendLen-6);
	SendLen++;
	//SendBuff[SendLen]=0x16;
	SendBuff[SendLen++]=0x16;
	DebugOut("\r\n send:::::::");
	for(i=0;i<SendLen;i++)
	{
		DebugOut(" %02x",SendBuff[i]);
	}
	DebugOut("\r\n");
	//if((Tmp130Buff[6]&0x0f)!=4)
		FrameSend();
	seq++;
}
void SendNAK(INT8U F,INT8U P,INT8U AFN)
{
	DebugOut("\r\nSending NAK");
	FrameHeadCreate(0x89);
	SendBuff[SendLen++]=0x00;//afn
	SendBuff[SendLen++]=0x60|(seq&0x0f);//seq
	SendBuff[SendLen++]=0;//Tmp130Buff[14];//da1e
	SendBuff[SendLen++]=0;//Tmp130Buff[15];//da2
	SendBuff[SendLen++]=4;//Tmp130Buff[16];//dt1
	SendBuff[SendLen++]=0;//Tmp130Buff[17];//dt2
	SendBuff[SendLen++]=AFN;//��������
	SendBuff[SendLen++]=SetDa1(P);//Tmp130Buff[14];//da1e
	SendBuff[SendLen++]=SetDa2(P);//Tmp130Buff[15];//da2
	SendBuff[SendLen++]=SetDt1(F);//Tmp130Buff[16];//dt1
	SendBuff[SendLen++]=SetDt2(F);//Tmp130Buff[17];//dt2
	SendBuff[SendLen++]=1;
	EC();
	TP();
	FrameTailCreate_Send();
}
void SendALLNAK()
{
	DebugOut("\r\nENTER sendallnak");
	FrameHeadCreate(0x80);
	SendBuff[SendLen++]=0;//afn
	SendBuff[SendLen++]=0x60|(seq&0x0f);//seq
	SendBuff[SendLen++]=0;//Tmp130Buff[14];//da1e
	SendBuff[SendLen++]=0;//Tmp130Buff[15];//da2
	SendBuff[SendLen++]=2;//Tmp130Buff[16];//dt1
	SendBuff[SendLen++]=0;//Tmp130Buff[17];//dt2
	EC();
	TP();
	FrameTailCreate_Send();

}
void SendALLACK()
{
	FrameHeadCreate(0x80);
	SendBuff[SendLen++]=0;//afn
	SendBuff[SendLen++]=0x60|(seq&0x0f);//seq
	SendBuff[SendLen++]=0;//Tmp130Buff[14];//da1e
	SendBuff[SendLen++]=0;//Tmp130Buff[15];//da2
	SendBuff[SendLen++]=1;//Tmp130Buff[16];//dt1
	SendBuff[SendLen++]=0;//Tmp130Buff[17];//dt2
	EC();
	TP();
	FrameTailCreate_Send();

}

void Zdrenzheng()
{
	INT8U i;
	GetDa(Tmp130Buff[14],Tmp130Buff[15]);
	GetDt(Tmp130Buff[16],Tmp130Buff[17]);
	FrameHeadCreate(0x80);
	if(DT[1]==1)
	{
		memcpy(Passwd,&Tmp130Buff[18],16);
	};
	SendBuff[SendLen++]=0x06;
	SendBuff[SendLen++]=0x60|(seq&0x0f);
	SendBuff[SendLen++]=0;
	SendBuff[SendLen++]=0;
	SendBuff[SendLen++]=2;
	SendBuff[SendLen++]=0;
	for(i=0;i<16;i++)
	{
		SendBuff[SendLen++]=Passwd[i];
	}
	TP();
	FrameTailCreate_Send();
}
void Create_Data_Type02(INT32S S,INT8U *Dest)
{
	INT32S Temp,i;
	if(abs(S)<1000)
	{
		Temp=abs(S)%1000;//,1000w
		i=Temp/100;
		Dest[1]=i|0xe0;
		i=Temp%100;
		Dest[0]=((i/10)<<4)+(i%10);
		if(S<0)
		{
			Dest[1]=Dest[1]|0x10;
		}
		return;
	}
	if(abs(S)<10000)
	{
		Temp=abs(S)%10000;//
		i=Temp/1000;
		Dest[1]=i|0xc0;
		i=(Temp%1000)/10;
		Dest[0]=((i/10)<<4)+(i%10);
		if(S<0)
		{
			Dest[1]=Dest[1]|0x10;
		}
		return;
	}
	if(abs(S)<100000)
	{
		Temp=abs(S)%100000;//
		i=Temp/10000;
		Dest[1]=i|0xa0;
		i=(Temp%10000)/100;
		Dest[0]=((i/10)<<4)+(i%10);
		if(S<0)
		{
			Dest[1]=Dest[1]|0x10;
		}
		return;
	}
	if(abs(S)<1000000)
	{
		Temp=abs(S)%1000000;//
		i=Temp/100000;
		Dest[1]=i|0x80;
		i=(Temp%100000)/1000;
		Dest[0]=((i/10)<<4)+(i%10);
		if(S<0)
		{
			Dest[1]=Dest[1]|0x10;
		}
		return;
	}
	if(abs(S)<10000000)
	{
		Temp=abs(S)%10000000;//
		i=Temp/1000000;
		Dest[1]=i|0x60;
		i=(Temp%1000000)/10000;
		Dest[0]=((i/10)<<4)+(i%10);
		if(S<0)
		{
			Dest[1]=Dest[1]|0x10;
		}
		return;
	}
	if(abs(S)<100000000)
	{
		Temp=abs(S)%100000000;//
		i=Temp/10000000;
		Dest[1]=i|0x40;
		i=(Temp%10000000)/100000;
		Dest[0]=((i/10)<<4)+(i%10);
		if(S<0)
		{
			Dest[1]=Dest[1]|0x10;
		}
		return;
	}
	if(abs(S)<1000000000)
	{
		Temp=abs(S)%1000000000;//
		i=Temp/100000000;
		Dest[1]=i|0x20;
		i=(Temp%100000000)/1000000;
		Dest[0]=((i/10)<<4)+(i%10);
		if(S<0)
		{
			Dest[1]=Dest[1]|0x10;
		}
		return;
	}
}
void Create_Data_Type03(INT32S S,INT8U *Dest)
{
	INT32S Temp,i;
	if(abs(S)<10000000)
	{
		Temp=abs(S)%10000000;//,1000w
		i=Temp/1000000;
		Dest[3]=i;
		i=Temp%1000000;
		i=i/10000;
		Dest[2]=((i/10)<<4)+(i%10);
		i=Temp%10000;
		i=i/100;
		Dest[1]=((i/10)<<4)+(i%10);
		i=Temp%100;
		Dest[0]=((i/10)<<4)+(i%10);
		if(S<0)
		{
			Dest[3]=Dest[3]|0x10;
		}
		return;
	}
	else
	{
		Temp=(abs(S)/1000)%10000000;//,1000w
		i=Temp/1000000;
		Dest[3]=i|0x40;
		i=Temp%1000000;
		i=i/10000;
		Dest[2]=((i/10)<<4)+(i%10);
		i=Temp%10000;
		i=i/100;
		Dest[1]=((i/10)<<4)+(i%10);
		i=Temp%100;
		Dest[0]=((i/10)<<4)+(i%10);
		if(S<0)
		{
			Dest[3]=Dest[3]|0x10;
		}
		return;
	}
}
long GetdataType03(INT8U *S)
{
	long t;
	t=S[3]&0x0f;
	t=(t*10)+((S[2]>>4)&0x0f);
	t=(t*10)+(S[2]&0x0f);
	t=(t*10)+((S[1]>>4)&0x0f);
	t=(t*10)+(S[1]&0x0f);
	t=(t*10)+((S[0]>>4)&0x0f);
	t=(t*10)+(S[0]&0x0f);
	if(S[3]&0x40)
	{
		t=t*1000;
	}
	if(S[3]&0x10)
	{
		t=0-t;
	}
	return t;
}
INT32S GetDataType02(INT8U *S)
{
	INT32S Temp;
	INT8U T1;
	Temp=S[1]&0x0f;
	Temp=Temp*100;
	Temp=Temp+((S[0]>>4)*10)+(S[0]&0x0f);
	T1=S[1]>>5;
	if(T1==0)Temp=Temp*100000000;
	if(T1==1)Temp=Temp*10000000;
	if(T1==2)Temp=Temp*1000000;
	if(T1==3)Temp=Temp*100000;
	if(T1==4)Temp=Temp*10000;
	if(T1==5)Temp=Temp*1000;
	if(T1==6)Temp=Temp*100;
	if(T1==7)Temp=Temp*10;
	T1=S[1]>>4;
	if(T1&1)
	{
		Temp=0-Temp;
	}
	return Temp;
}

void GetSetStat()
{
	INT8U i;
	memset(SetAvailable,0,31);
	//FkComm_Value
	if(RtuDataAddr->FkComm_Value.F1_Set_Para.Valid==1)SetAvailable[0]=SetAvailable[0]|0x01;
	if(RtuDataAddr->FkComm_Value.F2_Set_Para.Valid==1)SetAvailable[0]=SetAvailable[0]|0x02;
	if(RtuDataAddr->FkComm_Value.F3_Set_Para.Valid==1)SetAvailable[0]=SetAvailable[0]|0x04;
	if(RtuDataAddr->FkComm_Value.F4_Set_Para.Valid==1)SetAvailable[0]=SetAvailable[0]|0x08;
	if(RtuDataAddr->FkComm_Value.F5_Set_Para.Valid==1)SetAvailable[0]=SetAvailable[0]|0x10;
	if(RtuDataAddr->FkComm_Value.F6_Set_Para.Valid==1)SetAvailable[0]=SetAvailable[0]|0x20;
	if(RtuDataAddr->FkInput_Value.F7_Set_Para.Valid==1)SetAvailable[0]=SetAvailable[0]|0x40;
	if(RtuDataAddr->FkComm_Value.F8_Set_Para.Valid==1)SetAvailable[0]=SetAvailable[0]|0x80;

	if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)SetAvailable[1]=SetAvailable[1]|0x01;
	if(RtuDataAddr->FkInput_Value.F10_Set_Para.Valid==1)SetAvailable[1]=SetAvailable[1]|0x02;
	if(RtuDataAddr->FkComm_Value.F11_Set_Para.Valid==1)SetAvailable[1]=SetAvailable[1]|0x04;
	if(RtuDataAddr->FkInput_Value.F12_Set_Para.Valid==1)SetAvailable[1]=SetAvailable[1]|0x08;
	if(RtuDataAddr->ZongJia_Value.F14_Set_Para.Valid==1)SetAvailable[1]=SetAvailable[1]|0x20;
	if(RtuDataAddr->Event_Value.F15_Set_Para.Valid==1)SetAvailable[1]=SetAvailable[1]|0x40;
	if(RtuDataAddr->FkComm_Value.F16_Set_Para.Valid==1)SetAvailable[1]=SetAvailable[1]|0x80;

	if(RtuDataAddr->Fk_Control_Set_Value.F17_Set_Para.Valid==1)SetAvailable[2]=SetAvailable[2]|0x01;
	if(RtuDataAddr->Fk_Control_Set_Value.F18_Set_Para.Valid==1)SetAvailable[2]=SetAvailable[2]|0x02;
	if(RtuDataAddr->Fk_Control_Set_Value.F19_Set_Para.Valid==1)SetAvailable[2]=SetAvailable[2]|0x04;
	if(RtuDataAddr->Fk_Control_Set_Value.F20_Set_Para.Valid==1)SetAvailable[2]=SetAvailable[2]|0x08;
	if(RtuDataAddr->FkInput_Value.F21_Set_Para.Valid==1)SetAvailable[2]=SetAvailable[2]|0x10;
	if(RtuDataAddr->FkInput_Value.F22_Set_Para.Valid==1)SetAvailable[2]=SetAvailable[2]|0x20;
	if(RtuDataAddr->Fk_Control_Set_Value.F23_Set_Para.Valid==1)SetAvailable[2]=SetAvailable[2]|0x40;
	if(RtuDataAddr->Fk_Control_Set_Value.F24_Set_Para.Valid==1)SetAvailable[2]=SetAvailable[2]|0x80;

	for(i=0;i<CeLiangPoint_Max;i++)
	{
		if(RtuDataAddr->Cl_MenXian_Value[i].F25_Set_Para.Valid==1)SetAvailable[3]=SetAvailable[3]|0x01;
		if(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.Valid==1)SetAvailable[3]=SetAvailable[3]|0x02;
		if(RtuDataAddr->Cl_MenXian_Value[i].F27_Set_Para.Valid==1)SetAvailable[3]=SetAvailable[3]|0x04;
		if(RtuDataAddr->Cl_MenXian_Value[i].F28_Set_Para.Valid==1)SetAvailable[3]=SetAvailable[3]|0x08;
		if(RtuDataAddr->Fk_Control_Set_Value.F29_Set_Para[i].Valid==1)SetAvailable[3]=SetAvailable[3]|0x10;
	}

	if(RtuDataAddr->FkInput_Value.New_F33_Set_Para.Valid==1)SetAvailable[4]=SetAvailable[4]|0x01;
	if(RtuDataAddr->Fk_Control_Set_Value.F36_Set_Para.Valid==1)SetAvailable[4]=SetAvailable[4]|0x08;
	if(RtuDataAddr->FkInput_Value.F38_Set_Para.Valid==1)SetAvailable[4]=SetAvailable[4]|0x20;
	if(RtuDataAddr->FkInput_Value.F39_Set_Para.Valid==1)SetAvailable[4]=SetAvailable[4]|0x40;
	//Fk_Control_Set_Value
	for(i=0;i<Control_Lunci_Max;i++)
	{
		if(RtuDataAddr->Fk_Control_Set_Value.F49_Set_Para[i].Valid==1)SetAvailable[6]=SetAvailable[6]|0x01;
	}
	//Event_Value
	if(RtuDataAddr->Fk_Control_Set_Value.F57_Set_Para.Valid==1)SetAvailable[7]=SetAvailable[7]|0x01;
	if(RtuDataAddr->Fk_Control_Set_Value.F58_Set_Para.Valid==1)SetAvailable[7]=SetAvailable[7]|0x02;
	if(RtuDataAddr->Event_Value.F59_Set_Para.Valid==1)SetAvailable[7]=SetAvailable[7]|0x04;
	//Zj_Control_Value
	for(i=0;i<ZongJia_Max;i++)
	{
		if(RtuDataAddr->Zj_Control_Value[i].F41_Set_Para.Valid==1)SetAvailable[5]=SetAvailable[5]|0x01;
		if(RtuDataAddr->Zj_Control_Value[i].F42_Set_Para.Valid==1)SetAvailable[5]=SetAvailable[5]|0x02;
		if(RtuDataAddr->Zj_Control_Value[i].F43_Set_Para.Valid==1)SetAvailable[5]=SetAvailable[5]|0x04;
		if(RtuDataAddr->Zj_Control_Value[i].F44_Set_Para.Valid==1)SetAvailable[5]=SetAvailable[5]|0x08;
		if(RtuDataAddr->Zj_Control_Value[i].F45_Set_Para.Valid==1)SetAvailable[5]=SetAvailable[5]|0x10;
		if(RtuDataAddr->Zj_Control_Value[i].F46_Set_Para.Valid==1)SetAvailable[5]=SetAvailable[5]|0x20;
		if(RtuDataAddr->Zj_Control_Value[i].F47_Set_Para.Valid==1)SetAvailable[5]=SetAvailable[5]|0x40;
		if(RtuDataAddr->Zj_Control_Value[i].F48_Set_Para.Valid==1)SetAvailable[5]=SetAvailable[5]|0x80;
	}
	//Task_Value
	for(i=0;i<Task_Max;i++)
	{
		if(RtuDataAddr->Task_Value[i].F65_Set_Para.Valid==1)SetAvailable[8]=SetAvailable[8]|0x01;
		if(RtuDataAddr->Task_Value[i].F66_Set_Para.Valid==1)SetAvailable[8]=SetAvailable[8]|0x02;
		if(RtuDataAddr->Task_Value[i].F67_Set_Para.Valid==1)SetAvailable[8]=SetAvailable[8]|0x04;
		if(RtuDataAddr->Task_Value[i].F68_Set_Para.Valid==1)SetAvailable[8]=SetAvailable[8]|0x08;
	}
}
void CreateErr01(unsigned char flag,unsigned char *Ver_New,unsigned char *Ver_Old)
{
	if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)
	{
		if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[0]&0x01)//��Ҫ�Բ������ý����¼���¼
		{
			RtuDataAddr->Event_Save.Event.Err1.ERCNo=1;
			RtuDataAddr->Event_Save.Event.Err1.len=14;
			RtuDataAddr->Event_Save.Event.Err1.BiaoZhi=flag;//0x01;
			memcpy(RtuDataAddr->Event_Save.Event.Err1.Old_Ver,Ver_Old,4);//ProgVer
			memcpy(RtuDataAddr->Event_Save.Event.Err1.New_Ver,Ver_New,4);//ProgVer
			if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[0]&0x01)//��Ҫ�¼�
			{
				SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err1.Occur_Time.BCD01,1,1);
			}
			else//һ���¼�
			{
				SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err1.Occur_Time.BCD01,2,1);
			}
		}
	}
}
void CreateErr03(INT8U Da1,INT8U Da2,INT8U Dt1,INT8U Dt2)
{
	//���������¼�¼�Err3
	if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)
	{
		if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[0]&0x04)//��Ҫ�Բ������ý����¼���¼
		{
			RtuDataAddr->Event_Save.Event.Err3.ERCNo=3;
			RtuDataAddr->Event_Save.Event.Err3.len=10;
			RtuDataAddr->Event_Save.Event.Err3.QiDong_Addr=MSA;
			RtuDataAddr->Event_Save.Event.Err3.DanYuan[0]=Da1;
			RtuDataAddr->Event_Save.Event.Err3.DanYuan[1]=Da2;
			RtuDataAddr->Event_Save.Event.Err3.DanYuan[2]=Dt1;
			RtuDataAddr->Event_Save.Event.Err3.DanYuan[3]=Dt2;
			if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[0]&0x04)//��Ҫ�¼�
			{
				SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err3.Occur_Time.BCD01,1,3);
			}
			else//һ���¼�
			{
				SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err3.Occur_Time.BCD01,2,3);
			}
		}
	}
}
void CreateErr4()
{
	INT8U i;
	if(RtuDataAddr->FkInput_Value.F12_Set_Para.Valid==1)
	{
		for(i=0;i<8;i++)
		{
			if(RtuDataAddr->Yx_Changed&(1<<i))
			{
				if(RtuDataAddr->FkInput_Value.F12_Set_Para.YxIn&(1<<i))
				{
					RtuDataAddr->Event_Save.Event.Err4.ERCNo=4;
					RtuDataAddr->Event_Save.Event.Err4.len=7;
					RtuDataAddr->Event_Save.Event.Err4.Chg_Stat=RtuDataAddr->Yx_Changed;
					RtuDataAddr->Event_Save.Event.Err4.New_Stat=RtuDataAddr->NowYx;
					RtuDataAddr->OldYx=RtuDataAddr->NowYx;

					// ������Լ�� û��״̬���澯��־���ݶ�����״̬��ȫ���澯
					//if(RtuDataAddr->FkInput_Value.F12_Set_Para.YxEvent&(1<<i))
					{
						SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err4.Occur_Time.BCD01,1,4);
						break;
					}
					//else
					//{
					//	SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err4.Occur_Time.BCD01,2,4);
					//	break;
					//}
				}
			}
		}
	}
}
void CreateErr5()
{
}
void CreateErr6()
{
}
void CreateErr7()
{
}
void CreateErr8()
{
}
void CreateErr9()
{
}
void CreateErr10()
{
}
void CreateErr11()
{
}
void CreateErr12()
{
}
void CreateErr13()
{
}
void CreateErr14(INT8U Flag)
{
	if(Flag)//�ϵ硢ʧ���־
	{
		memcpy(&RtuDataAddr->Event_Save.Event.Err14.Ting_Time.BCD01,RtuDataAddr->Fm_Save_Eve.TdTime,5);
		RtuDataAddr->Event_Save.Event.Err14.Shang_Time.BCD01=RtuDataAddr->Fm_Save_Eve.SdTime[0];
		RtuDataAddr->Event_Save.Event.Err14.Shang_Time.BCD02=RtuDataAddr->Fm_Save_Eve.SdTime[1];
		RtuDataAddr->Event_Save.Event.Err14.Shang_Time.BCD03=RtuDataAddr->Fm_Save_Eve.SdTime[2];
		RtuDataAddr->Event_Save.Event.Err14.Shang_Time.BCD04=RtuDataAddr->Fm_Save_Eve.SdTime[3];
		RtuDataAddr->Event_Save.Event.Err14.Shang_Time.BCD05=RtuDataAddr->Fm_Save_Eve.SdTime[4];
	}
	else
	{
		memcpy(&RtuDataAddr->Event_Save.Event.Err14.Shang_Time.BCD01,RtuDataAddr->Fm_Save_Eve.SdTime,5);
		RtuDataAddr->Event_Save.Event.Err14.Ting_Time.BCD01=RtuDataAddr->Fm_Save_Eve.TdTime[0];
		RtuDataAddr->Event_Save.Event.Err14.Ting_Time.BCD02=RtuDataAddr->Fm_Save_Eve.TdTime[1];
		RtuDataAddr->Event_Save.Event.Err14.Ting_Time.BCD03=RtuDataAddr->Fm_Save_Eve.TdTime[2];
		RtuDataAddr->Event_Save.Event.Err14.Ting_Time.BCD04=RtuDataAddr->Fm_Save_Eve.TdTime[3];
		RtuDataAddr->Event_Save.Event.Err14.Ting_Time.BCD05=RtuDataAddr->Fm_Save_Eve.TdTime[4];
	}
	if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)
	{
		if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[1]&0x20)//��Ҫ�Բ������ý����¼���¼
		{
			if((RtuDataAddr->Event_Save.Event.Err14.Ting_Time.BCD05!=0)&&(RtuDataAddr->Event_Save.Event.Err14.Ting_Time.BCD04!=0)&&(RtuDataAddr->Event_Save.Event.Err14.Ting_Time.BCD03!=0))
			{
				RtuDataAddr->Event_Save.Event.Err14.ERCNo=14;
				RtuDataAddr->Event_Save.Event.Err14.len=10;
				if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[1]&0x20)//��Ҫ�¼�
				{
					memcpy(&RtuDataAddr->M_Event_Save[RtuDataAddr->Fm_Save_Eve.EC1].UseFlag,&RtuDataAddr->Event_Save.UseFlag,sizeof(RtuDataAddr->Event_Save));
					RtuDataAddr->Fm_Save_Eve.EC1 = (RtuDataAddr->Fm_Save_Eve.EC1 + 1)%256;
					Fm25cl64_Write(&RtuDataAddr->Fm_Save_Eve.EC1,sizeof(RtuDataAddr->Fm_Save_Eve),Fm_Save_Eve_Offset);
					RtuDataAddr->EC1=RtuDataAddr->Fm_Save_Eve.EC1;
					RtuDataAddr->Event_Save.UseFlag=0;
					RtuDataAddr->ERCBiaoZhi[1]=0x20;
					SaveFile((INT8U *)"/nand/save/Merc1.dat",&RtuDataAddr->M_Event_Save[0].UseFlag,sizeof(RtuDataAddr->M_Event_Save));
				}
				else//һ���¼�
				{
					memcpy(&RtuDataAddr->S_Event_Save[RtuDataAddr->Fm_Save_Eve.EC2].UseFlag,&RtuDataAddr->Event_Save.UseFlag,sizeof(RtuDataAddr->Event_Save));
					RtuDataAddr->Fm_Save_Eve.EC2 = (RtuDataAddr->Fm_Save_Eve.EC2 + 1)%256;
					RtuDataAddr->EC2=RtuDataAddr->Fm_Save_Eve.EC2;
					Fm25cl64_Write(&RtuDataAddr->Fm_Save_Eve.EC1,sizeof(RtuDataAddr->Fm_Save_Eve),Fm_Save_Eve_Offset);
					RtuDataAddr->Event_Save.UseFlag=0;
					RtuDataAddr->ERCBiaoZhi[1]=0x20;
					SaveFile((INT8U *)"/nand/save/Serc1.dat",&RtuDataAddr->S_Event_Save[0].UseFlag,sizeof(RtuDataAddr->S_Event_Save));
				}
			}

		}
	}
}
void CreateErr20(INT16U CrcValue)
{
	if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)
	{
		if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[2]&0x08)//��Ҫ�Բ������ý����¼���¼
		{
			RtuDataAddr->Event_Save.Event.Err20.ERCNo=20;
			RtuDataAddr->Event_Save.Event.Err20.len=8;
			RtuDataAddr->Event_Save.Event.Err20.Msa_Add=MSA;
			RtuDataAddr->Event_Save.Event.Err20.PW[0]=CrcValue>>8;
			RtuDataAddr->Event_Save.Event.Err20.PW[1]=CrcValue>>8;
			if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[2]&0x08)//��Ҫ�¼�
			{
				SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err20.Occur_Time.BCD01,1,20);
			}
			else//һ���¼�
			{
				SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err20.Occur_Time.BCD01,2,20);
			}
		}
	}
}
