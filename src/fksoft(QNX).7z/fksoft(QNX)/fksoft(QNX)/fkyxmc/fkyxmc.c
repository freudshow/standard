#include "fkyxmc.h"
const char verstr[]={"VER-STRING-FLG=012.002.217.004"__DATE__" "__TIME__};
RTimeData  *RtuDataAddr;//�ڴ湲��������ָ��
INT8U PORT_ID;
int ledold=0;
int fp;
int device=0;
spi_devinfo_t cfg;
INT8U MaiCongStat;
INT8U MaiCongLed;
name_attach_t *attach;
INT8U b1,b2;
void CreateErr4()
{
	unsigned char i,j;
	unsigned char yx[5];
	unsigned char NOwYx,Yx_Changed;
	if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)
	{
		if (RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[0]&0x08 )
		{//F8 �ն��¼���¼����  ��Er4 �ж�״̬����λ��¼��Ч
			memset(yx,0,5);
			memset(&NOwYx,0,1);
			yx[0] = RtuDataAddr->NowYx>>3 &0x01;
			yx[1] = RtuDataAddr->NowYx>>2 &0x01;
			yx[2] = RtuDataAddr->NowYx>>1 &0x01;
			yx[3] = RtuDataAddr->NowYx>>0 &0x01;
			//yx[4] = RtuDataAddr->NowYx>>6 &0x01;
			//yx[5] = RtuDataAddr->NowYx>>5 &0x01;
			yx[4] = RtuDataAddr->NowYx>>4 &0x01;

			for(j=0;j<5;j++)
				NOwYx = NOwYx | yx[j]<<j;
			memset(yx,0,5);
			memset(&Yx_Changed,0,1);
			yx[0] = RtuDataAddr->Yx_Changed>>3 &0x01;
			yx[1] = RtuDataAddr->Yx_Changed>>2 &0x01;
			yx[2] = RtuDataAddr->Yx_Changed>>1 &0x01;
			yx[3] = RtuDataAddr->Yx_Changed>>0 &0x01;
			//yx[4] = RtuDataAddr->Yx_Changed>>6 &0x01;
			//yx[5] = RtuDataAddr->Yx_Changed>>5 &0x01;
			yx[4] = RtuDataAddr->Yx_Changed>>4 &0x01;

			for(j=0;j<5;j++)
				Yx_Changed = Yx_Changed | yx[j]<<j;
			for(i =0;i<8;i++)
			{
				if(Yx_Changed&(1<<i))//�ж���һ��ң���б�λ
				{
					//if(RtuDataAddr->FkInput_Value.F12_Set_Para.YxIn&(1<<i))//���Ժ���ʱ���¼��������ɴ˴�
					{// F12�ն�״̬���������  ���ϵͳ���øõ�ң����Ч
						RtuDataAddr->Event_Save.Event.Err4.ERCNo=4;
						RtuDataAddr->Event_Save.Event.Err4.len=7;
						RtuDataAddr->Event_Save.Event.Err4.Chg_Stat=Yx_Changed;
						RtuDataAddr->Event_Save.Event.Err4.New_Stat=NOwYx;
						RtuDataAddr->OldYx=RtuDataAddr->NowYx;
						if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[0]&0x08)
						{//F8 �ն��¼���¼����  ��Er4 �ж�״̬����λ��¼�¼��ȼ�Ϊ��Ҫ�¼�
							SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err4.Occur_Time.BCD01,1,4);
							break;
						}
						else//�¼��ȼ�Ϊһ���¼�
						{
							SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err4.Occur_Time.BCD01,2,4);
							break;
						}
					}
				}
			}
		}
	}
}
void DoYxChanged()
{
	INT16U old;
	old=GetYx();

	RtuDataAddr->NowYx = (old>>2)&0x01f;//�¼���

	MaiCongStat=(old>>7)&0x03;//�¼���
	MaiCongLed=old&0x03;
	//-------------
	b1 = (MaiCongStat >>1)&0x01;
	b2 = MaiCongStat & 0x01;
	MaiCongStat = (b2<<1) | b1;
	b1=0;b2=0;
	b1 = (MaiCongLed >>1)&0x01;
	b2 = MaiCongLed & 0x01;
	MaiCongLed = (b2<<1) | b1;
	//-------------
	if(b1==0)
	{
		SetSpiLed(PSTEP_LED);
	}
	else
	{
		ClearSpiLed(PSTEP_LED);
	}

	if(b2==0)
		SetSpiLed(QSTEP_LED);
	else
		ClearSpiLed(QSTEP_LED);
	if(RtuDataAddr->OldYx!=RtuDataAddr->NowYx)
	{
		RtuDataAddr->Yx_Changed=RtuDataAddr->Yx_Changed|(RtuDataAddr->NowYx^RtuDataAddr->OldYx);
		printf("\n\rNowYx==%x OldYx===%x",RtuDataAddr->NowYx,RtuDataAddr->OldYx);
		printf("\n\r YxChang %x",RtuDataAddr->Yx_Changed);
		CreateErr4();//ң�ű�λ��¼
		RtuDataAddr->OldYx=RtuDataAddr->NowYx;
	}
}
void markver()//��Ŀ������б�ʶ�����汾��Ϣ
{
	printf("\n%s\n", verstr);
}
void Impulse_init()
{
	unsigned short i;
	for (i=0;i<2;i++)//�¼���
	{
		RtuDataAddr->MaiChongVar[i].ImpulseNum = RtuDataAddr->FM_Save_ZDValue.MaiCong[i];
		RtuDataAddr->MaiChongVar[i].real_ImpulseCounter = 0;
		RtuDataAddr->MaiChongVar[i].DurTime = 0;
		RtuDataAddr->MaiChongVar[i].State_Old = 0;
		RtuDataAddr->MaiChongVar[i].State_Now = 0;
	}
	MaiCongStat = 0;
}
void Impulse_process()
{
	unsigned short i;
	for(i=0;i<2;i++)//�¼���
	{
		RtuDataAddr->MaiChongVar[i].State_Now = (MaiCongStat>>i)&0x1;
		if(RtuDataAddr->MaiChongVar[i].State_Now != RtuDataAddr->MaiChongVar[i].State_Old)
		{
			RtuDataAddr->MaiChongVar[i].DurTime = 0;
		}

		//if(RtuDataAddr->MaiChongVar[i].DurTime == QUDOU_TIME_COUNTE)
		if(RtuDataAddr->MaiChongVar[i].State_Now == 1)
		{
			//if(RtuDataAddr->MaiChongVar[i].State_Now == 1)
			if(RtuDataAddr->MaiChongVar[i].DurTime == QUDOU_TIME_COUNTE)
			{
				RtuDataAddr->MaiChongVar[i].ImpulseNum++;
				RtuDataAddr->MaiChongVar[i].real_ImpulseCounter++;
				RtuDataAddr->FM_Save_ZDValue.MaiCong[i]=RtuDataAddr->MaiChongVar[i].ImpulseNum;
			}
		}
		RtuDataAddr->MaiChongVar[i].DurTime++;
		if(RtuDataAddr->MaiChongVar[i].DurTime > 240)
		{
			RtuDataAddr->MaiChongVar[i].DurTime = 240;
		}
		RtuDataAddr->MaiChongVar[i].State_Old = RtuDataAddr->MaiChongVar[i].State_Now;
	}
}
signed int Get_BianBi(unsigned char ClNo)
{
	signed int I,V;
	if(RtuDataAddr->Cl_MenXian_Value[ClNo].F25_Set_Para.Valid==1)
	{
		I=RtuDataAddr->Cl_MenXian_Value[ClNo].F25_Set_Para.I_BeiLv[1];
		I=(I<<8)+RtuDataAddr->Cl_MenXian_Value[ClNo].F25_Set_Para.I_BeiLv[0];
		V=RtuDataAddr->Cl_MenXian_Value[ClNo].F25_Set_Para.V_BeiLv[1];
		V=(V<<8)+RtuDataAddr->Cl_MenXian_Value[ClNo].F25_Set_Para.V_BeiLv[0];
		return I*V;
	}
	else
	{
		return 1;
	}
return 1;
}
void PQ_Caculate(int i,TS ts)
{
unsigned char j,k;
unsigned int changdd;
signed   int beilv;
long temp1,temp2;

if(RtuDataAddr->MaiCongSetPara.Valid==1)
{
	    //for(i=0;i<2;i++)
		{
			if(RtuDataAddr->MaiCongSetPara.MaiChong[i].InputNo==0)
				return;
		  	j = RtuDataAddr->MaiCongSetPara.MaiChong[i].CeLiangNo-1;//�������
			beilv = Get_BianBi(j)*100;

			changdd = RtuDataAddr->MaiCongSetPara.MaiChong[i].Changhu[1];
			changdd = (changdd<<8)+RtuDataAddr->MaiCongSetPara.MaiChong[i].Changhu[0];//���峣��

			if(changdd==0)
				return;
			k = RtuDataAddr->MaiCongSetPara.MaiChong[i].InputNo-1;//����˿ں�
			if(k>=2)
					return;
			//RtuDataAddr->MaiChongVar[k].real_ImpulseCounter = 120;
			if ((RtuDataAddr->MaiCongSetPara.MaiChong[i].Stat==0)||(RtuDataAddr->MaiCongSetPara.MaiChong[i].Stat==2))
			{
				//RtuDataAddr->DD_Device_BiaoShi_Value[j].P  = (3600 * beilv * RtuDataAddr->MaiChongVar[k].real_ImpulseCounter /60 /changdd)*100;
				temp1=3600 * RtuDataAddr->MaiChongVar[k].real_ImpulseCounter;
				temp2=(temp1*100)/60 /changdd;
				RtuDataAddr->DD_Device_BiaoShi_Value[j].P=(100)*temp2;
				if(RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[j].Z_P_X_All < RtuDataAddr->DD_Device_BiaoShi_Value[j].P)
					RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[j].Z_P_X_All = RtuDataAddr->DD_Device_BiaoShi_Value[j].P;//*Get_BianBi(j);
				RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[j].Valid = 1;
				//printf("\n\r temp1 ===%d  temp2===%d P====%d",temp1,temp2,RtuDataAddr->DD_Device_BiaoShi_Value[j].P);
				//RtuDataAddr->DD_Device_BiaoShi_Value[j].P  = (beilv)*((3600 * RtuDataAddr->MaiChongVar[k].real_ImpulseCounter*100)/(60*changdd)); //(3600 * beilv * RtuDataAddr->MaiChongVar[k].real_ImpulseCounter /60 /changdd)*100;
				//printf("\n\r mc p %d ",RtuDataAddr->DD_Device_BiaoShi_Value[j].P);
			}
			temp1=0;
			temp2=0;
			if ((RtuDataAddr->MaiCongSetPara.MaiChong[i].Stat==1)||(RtuDataAddr->MaiCongSetPara.MaiChong[i].Stat==3))
			{
				temp1=3600 * RtuDataAddr->MaiChongVar[k].real_ImpulseCounter;
				temp2=(temp1*100)/60 /changdd;
				RtuDataAddr->DD_Device_BiaoShi_Value[j].Q=(100)*temp2;
				if (RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[j].Z_Q_X_All < RtuDataAddr->DD_Device_BiaoShi_Value[j].Q)
					RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[j].Z_Q_X_All=RtuDataAddr->DD_Device_BiaoShi_Value[j].Q;//*Get_BianBi(j);
				RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[j].Valid = 1;
				//printf("\n\r temp1 ===%d  temp2===%d Q====%d",temp1,temp2,RtuDataAddr->DD_Device_BiaoShi_Value[j].Q);
				//RtuDataAddr->DD_Device_BiaoShi_Value[j].P  = (beilv)*((3600 * RtuDataAddr->MaiChongVar[k].real_ImpulseCounter*100)/(60*changdd)); //(3600 * beilv * RtuDataAddr->MaiChongVar[k].real_ImpulseCounter /60 /changdd)*100;
				//printf("\n\r mc Q %d ",RtuDataAddr->DD_Device_BiaoShi_Value[j].Q);
				//RtuDataAddr->DD_Device_BiaoShi_Value[j].Q  = (3600 * beilv * RtuDataAddr->MaiChongVar[k].real_ImpulseCounter/60 /changdd)*100;
			}

		}
	}
}
void DD_Caculate(TS ts)
{
  unsigned char i,j,k;
  unsigned int changdd;
  signed   int beilv;
  if(RtuDataAddr->MaiCongSetPara.Valid==1)
  {
	  for(i=0;i<2;i++)
	  {
	 	if(RtuDataAddr->MaiCongSetPara.MaiChong[i].InputNo==0)
	 		continue;
  		j=RtuDataAddr->MaiCongSetPara.MaiChong[i].CeLiangNo-1;
		beilv = Get_BianBi(j)*10;
		changdd=RtuDataAddr->MaiCongSetPara.MaiChong[i].Changhu[1];
		changdd=(changdd<<8)+RtuDataAddr->MaiCongSetPara.MaiChong[i].Changhu[0];//���峣��
    	if(changdd==0)continue;
    	k=RtuDataAddr->MaiCongSetPara.MaiChong[i].InputNo-1;
     	if(k>2)continue;
		 	if(RtuDataAddr->MaiCongSetPara.MaiChong[i].Stat==0)
		 	{
		 		//RtuDataAddr->DD_Device_BiaoShi_Value[j].Z_P_All = RtuDataAddr->MaiChongVar[k].ImpulseNum*100/ changdd ;
		 		RtuDataAddr->DD_Device_BiaoShi_Value[j].Z_P_All = RtuDataAddr->MaiChongVar[k].ImpulseNum*1000/ changdd ;
		 		RtuDataAddr->z_P_all[j] =1;
	       		RtuDataAddr->DIANDU[ts.Sec] = RtuDataAddr->MaiChongVar[k].ImpulseNum ;
	       		//RtuDataAddr->DD_Device_BiaoShi_Value[j].Z_P_All = RtuDataAddr->DD_Device_BiaoShi_Value[j].Z_P_All*10 ;;//+(RtuDataAddr->MaiChongVar[k].ImpulseNum%10);
	       		//printf("\n\rfkyxmc changdd==%d  RtuDataAddr->MaiChongVar[%d].ImpulseNum===%d",changdd,k,RtuDataAddr->MaiChongVar[k].ImpulseNum);
	       		//printf("\n\rfkyxmc RtuDataAddr->DD_Device_BiaoShi_Value[%d].Z_P_All===%d",j,RtuDataAddr->DD_Device_BiaoShi_Value[j].Z_P_All);
		 	}
		 	if(RtuDataAddr->MaiCongSetPara.MaiChong[i].Stat==2)
		 	{
		 		RtuDataAddr->DD_Device_BiaoShi_Value[j].F_P_All = RtuDataAddr->MaiChongVar[k].ImpulseNum*100 / changdd ;
		 		RtuDataAddr->f_P_all[j] = 1;
		 		RtuDataAddr->DIANDU[ts.Sec] = RtuDataAddr->MaiChongVar[k].ImpulseNum ;
		 		RtuDataAddr->DD_Device_BiaoShi_Value[j].F_P_All=RtuDataAddr->DD_Device_BiaoShi_Value[j].F_P_All;//+(RtuDataAddr->MaiChongVar[k].ImpulseNum%10);
		 	}
	  	 	if(RtuDataAddr->MaiCongSetPara.MaiChong[i].Stat==1)
	  	 	{
	 	 		RtuDataAddr->DD_Device_BiaoShi_Value[j].Z_Q_All = RtuDataAddr->MaiChongVar[k].ImpulseNum*100 / changdd ;
	 	 		RtuDataAddr->z_Q_all[j] = 1;
	 	 		RtuDataAddr->DIANDU[ts.Sec] = RtuDataAddr->MaiChongVar[k].ImpulseNum ;
	 	 		RtuDataAddr->DD_Device_BiaoShi_Value[j].Z_Q_All=RtuDataAddr->DD_Device_BiaoShi_Value[j].Z_Q_All+(RtuDataAddr->MaiChongVar[k].ImpulseNum%10);
	   	 	}
	  	 	if(RtuDataAddr->MaiCongSetPara.MaiChong[i].Stat==3)
	  	 	{
	 	 		RtuDataAddr->DD_Device_BiaoShi_Value[j].F_Q_All = RtuDataAddr->MaiChongVar[k].ImpulseNum*100 / changdd ;
	 	 		RtuDataAddr->f_Q_all[j]= 1;
	 	 		RtuDataAddr->DIANDU[ts.Sec] = RtuDataAddr->MaiChongVar[k].ImpulseNum ;
	 	 		RtuDataAddr->DD_Device_BiaoShi_Value[j].F_Q_All=RtuDataAddr->DD_Device_BiaoShi_Value[j].F_Q_All+(RtuDataAddr->MaiChongVar[k].ImpulseNum%10);
	  	 	}
			RtuDataAddr->DD_Device_BiaoShi_Value[j].Valid=1;
 		}
	}
}
void ImpulseCaculate(TS ts,INT8U i)
{
  INT8U clno = 0;
  DD_Caculate(ts);
  //if (ts.Minute != myImpulseMin)	  // ÿ 1 ���Ӽ���һ�Σ�����ȫ�ֹ��ʱ�����ֵ
 // for(i=0;i<2;i++)
  {
	  if (SecCounter[i] >=60)//���ʱ�ﵽһ���Ӻ�ʼ����1���ӹ���
	  {
		  SecCounter[i] = 0;
		  myImpulseMin = ts.Minute;
		  PQ_Caculate(i,ts);
		  RtuDataAddr->FM_Save_ZDValue.MaiCong[i] = RtuDataAddr->MaiChongVar[i].ImpulseNum ;
		  RtuDataAddr->MaiChongVar[i].real_ImpulseCounter =0;//ʵʱ���������������
		  SecCounterQing[i] = 0;
	  }
	  if (SecCounterQing[i]>=59)
	  {
		  clno = RtuDataAddr->MaiCongSetPara.MaiChong[i].CeLiangNo-1;
		  RtuDataAddr->DD_Device_BiaoShi_Value[clno].P = 0;
		  RtuDataAddr->DD_Device_BiaoShi_Value[clno].Q = 0;
		  //printf("\n\rP[%d] = %d",clno,RtuDataAddr->DD_Device_BiaoShi_Value[clno].P);
		  SecCounterQing[i] = 0;
	  }
  }
}
INT8U   PARSE_CMD(int argc, char * argv[])
{
	INT8U  proc_name[32] = "";

	DataSaveDbg("cmdline=%d,%s %s\r\n", argc, argv[0], argv[1]);
	if(argc < 2)return (FALSE);
	PORT_ID = atoi(argv[1]);
	sprintf((char *)proc_name, "%s %d", argv[0], PORT_ID);
	if((attach = name_attach(NULL, (char *)proc_name,0))  == NULL)
	{
		fprintf(stderr, "ERR:'%s' runed,cann't regist: %s\r\n", proc_name, strerror(errno));
		return (FALSE);
	}
	return (TRUE);
}
void QuitProcess(int signo)
{
	delay(100);
	RtuDataAddr->stPortPara[PORT_ID].PID=0;
   	name_detach(attach, 0);
   	fprintf(stderr,"fkyxmc quit");
	exit(0);
}
int main(int argc, char *argv[]) {
	struct sigaction sa1;
	INT8U Min,i;
	TS ts;
	INT8U NowMin;
	INT8U OldSecond;

	markver();
	if(OpenMem())return EXIT_FAILURE;
	fprintf(stderr,"\r\n %d %d ",RtuDataAddr->mem_len,sizeof(RTimeData));
	if(RtuDataAddr->mem_len!=sizeof(RTimeData))
	{
		fprintf( stderr, "base mem uncompared prog will exit %d :\n",sizeof(RTimeData));
		return EXIT_FAILURE;
	}
	if(!PARSE_CMD(argc, argv))
	{
		DataSaveDbg("\n Bad command format. Type 'use exe_name' for help!\n\r");
		return EXIT_FAILURE;
	}
	sa1.sa_handler = QuitProcess;
	sigemptyset(&sa1.sa_mask);
	sa1.sa_flags = 0;
	sigaction(SIGTERM, &sa1,NULL);
	sigaction(SIGSYS, &sa1,NULL);
	sigaction(SIGPWR, &sa1,NULL);
	sigaction(SIGKILL, &sa1,NULL);
	sigaction(SIGQUIT, &sa1,NULL);
	sigaction(SIGILL, &sa1,NULL);
	sigaction(SIGINT, &sa1,NULL);
	sigaction(SIGHUP, &sa1,NULL);
	sigaction(SIGABRT, &sa1,NULL);
	sigaction(SIGBUS, &sa1,NULL);
	RtuDataAddr->stPortPara[PORT_ID].PID=getpid();
	Min=0;
	if (!PortOpened) {
		OpenGPIO();
	}
	for(i=0;i<8;i++)
	{
		RtuDataAddr->z_P_all[i]=0;
		RtuDataAddr->f_P_all[i]=0;
		RtuDataAddr->z_Q_all[i]=0;
		RtuDataAddr->f_Q_all[i]=0;
	}

	while(RtuDataAddr->Dev_Init_OK==0)
	{
		CleardeadCount();
		delay(1000);
	}
	TSGet(&ts);
	OldSecond=ts.Sec;
	myImpulseMin = ts.Minute;
 	Impulse_init();
 	SecCounter[0] =SecCounter[1] = SecCounterQing[0] = SecCounterQing[1] = 0;
   	for (;;)
   	{
   		memcpy(&RtuDataAddr->MaiCongSetPara.Valid,&RtuDataAddr->FkComm_Value.F11_Set_Para.Valid,sizeof(RtuDataAddr->MaiCongSetPara));
 		CleardeadCount();
		TSGet(&ts);
		DoYxChanged();
		Impulse_process();//������·�������룬ȥ��ʱ��Ϊ��׼���ж�ȷʵ�������壬ʵʱ����������������������
		delay(2);

        if(ts.Sec!=OldSecond)
		{
        	for (i=0;i<2;i++)
        	{
        		if (RtuDataAddr->MaiChongVar[i].real_ImpulseCounter>0)//һ��ʵʱ�������
            	{
            		SecCounter[i]++;//�������ʼ��ʱ
            	}else
            		SecCounterQing[i]++;
    			ImpulseCaculate(ts,i);
    			OldSecond=ts.Sec;
        	}
		}
		NowMin=ts.Minute;
     }
  	name_detach(attach, 0);
 	return EXIT_SUCCESS;
}
