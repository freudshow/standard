#ifndef FKSET_H_
#define FKSET_H_

#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <ctype.h>
#include <time.h>
#include <signal.h>
#include <sys/sched.h>
#include <semaphore.h>
#include <process.h>
#include <sys/neutrino.h>
#include <sys/netmgr.h>
#include <errno.h>
#include <hw/inout.h>
#include <fkbase/memtype.h>
#include <fkbase/fkbasefun.h>


void markver();//��Ŀ������б�ʶ�����汾��Ϣ
void AT24Write(INT8U addr,INT8U data);
void modify_uip(INT8U ch,INT8U *s);
void modify_q(INT8U ch,INT8U *s);
void CommandProcess(int argc, char *argv[]);
#endif /* FKSET_H_ */
