/*
 * diskload.h
 *
 *  Created on: 2009-12-16
 *      Author: Administrator
 */

#ifndef DISKLOAD_H_
#define DISKLOAD_H_

#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <share.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/dcmd_blk.h>
#include <sys/iofunc.h>
#include <sys/netmgr.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <unistd.h>

#define COLWIDTH_FSYS	19
#define COLWIDTH_MOUNT	16
#define COLWIDTH_TYPE	16
#define COUNT_SIZES 4

#define FSYS_FROM_ARGV	0					/* Filesystems given as argv[] */

#define diskMODE			(O_ACCMODE | O_NONBLOCK)
#define POTENTIAL_FSYS(_m)	(S_ISBLK(_m) || S_ISDIR(_m) || S_ISREG(_m))

#define NO_UNIQ_FILTER	((struct df_unique *)-1)

/* Used for the display information */
#define STRING_SIZE	64

struct df_config {
	ulong_t blksize;
	int flagP;
	int flagN;
	int flagG;
	char *adjust;
	int mode;
};
struct df_storage {
	int fd;
	char name[2][PATH_MAX];
	struct statvfs vfs;
};
struct df_unique {
	struct df_unique *link;
	dev_t dev;
	ino_t ino;
};

typedef struct {
	struct df_config cfg;
	struct df_storage data;
	struct df_unique *uniq;
} df_globals_t;

struct df_humanformat {
	char abbreviation;
	fsblkcnt_t size;
};
int display(struct df_config *cfg, struct df_storage *data);

int disk_load(char * path);

#endif /* DISKLOAD_H_ */
