#include "diskload.h"
/*
 *  Convert a native file-system block count to a known target count.
 *  Attempt to minimise the chances of under/over-flow.
 */
static int humanreadable;
static struct df_humanformat sizes[COUNT_SIZES];
static fsblkcnt_t convertblks(fsblkcnt_t nblks, ulong_t blksz, ulong_t target);
static char *trimname(char *name, int trailing);
static void trimnames(struct df_storage *data);
static int unique(struct df_unique **head, struct stat *st);
static int pair(int *fd, struct stat *st, int fdlist[], int numfds);
static void convertsize(fsblkcnt_t sizein, int size, char *stringout);
static int process(df_globals_t *df);
static int multiprocess(df_globals_t *df, char *path, char *by);
static fsblkcnt_t convertblks(fsblkcnt_t nblks, ulong_t blksz, ulong_t target) {
	if (blksz == target || nblks == 0)
		return (nblks);
	if (blksz == 0)
		return (0);
	if (target % blksz)
		return (nblks * blksz / target);
	return ((blksz < target) ? nblks / (target / blksz) : nblks * (blksz / target));
}

/*
 *  Perform a pretty-format of the given filesystem/device names (to
 *  strip the local node name so as to not consume display bandwidth).
 */
static char *trimname(char *name, int trailing) {
	static char nodename[256];
	static int nodenmlen = -1;
	int ejected, len;

	if (nodenmlen == -1) {
		nodenmlen
				= ((nodenmlen = netmgr_ndtostr(ND2S_DIR_SHOW, ND_LOCAL_NODE, nodename, sizeof(nodename))) >= 2) ? nodenmlen - 2 : 0;
	}
	ejected = (name[0] == '(') ? 1 : 0;
	if (nodenmlen != 0) {
		if (!strncmp(&name[ejected], nodename, nodenmlen))
			memmove(&name[ejected], &name[ejected + nodenmlen], strlen(&name[ejected]) - nodenmlen + 1);
	}
	if (trailing) {
		if ((len = strlen(&name[ejected])) > ejected + 1)
			memmove(&name[len - 1], &name[len], ejected + 1);
	}
	return (name);
}

static void trimnames(struct df_storage *data) {
	trimname(data->name[0], 0);
	trimname(data->name[1], 0);
}

/*
 *  Check that the currently investigated filesystem is unique (we will
 *  encounter duplicate entries for mounted block filesystems, for example).
 *  The (dev,ino) pair of the final target is used as the uniqueness value.
 */
static int unique(struct df_unique **head, struct stat *st) {
	struct df_unique *u;

	if (*head != NO_UNIQ_FILTER && st->st_dev != 0 && st->st_ino != 0) {
		for (u = *head; u != NULL; u = u->link) {
			if (u->dev == st->st_dev && u->ino == st->st_ino)
				return (0);
		}
		if ((u = malloc(sizeof(struct df_unique))) != NULL) {
			u->dev = st->st_dev, u->ino = st->st_ino;
			u->link = *head, *head = u;
		}
	}
	return (!0);
}

/*
 *  Try and match the appropriate union mount entry back with its
 *  MOUNTED_BY/MOUNTED_ON counterpart (the correct operation depends
 *  on each IO manager properly implementing the stat dev/rdev fields).
 */
static int pair(int *fd, struct stat *st, int fdlist[], int numfds) {
	struct stat st2;
	int fd2, i, matched, swap;

	matched = 0, swap = fd != NULL;
	for (i = 0; i < numfds; ++i) {
		fd2 = fdlist[i];
		if (!matched && (matched = fstat(fd2, &st2) != -1 && ((swap && st->st_rdev == st2.st_dev) || (!swap && st->st_dev
				== st2.st_rdev))) && swap) {
			fdlist[i] = *fd, *fd = fd2;
			memcpy(st, &st2, sizeof(struct stat));
		}
		close(fdlist[i]);
	}
	return (matched);
}

/* Convert our numbers to string for use with human readable format.  If not set to human readable, convert them straight to strings */
static void convertsize(fsblkcnt_t sizein, int size, char *stringout) {
	int i = 0;
	int fractional = 0;
	if (humanreadable && sizein > 0) {
		for (i = 0; i < COUNT_SIZES; i++) {
			/* If we can still go another unit up */
			if (i < COUNT_SIZES - 1) {
				/* See if the next unit minimum is bigger than our size */
				if (sizes[i + 1].size > sizein) {
					/* If it is, i points to our unit size */
					break;
				}
			} else {
				break;
			}
		}
		/* Calculate the decimal place by grabbing the number (multiply by 10, then subtract the first bit) */
		fractional = ((sizein * 10) / sizes[i].size) - ((sizein / sizes[i].size) * 10);

		/* Rebase our units */
		sizein = sizein / sizes[i].size;

		/* If we're more than 10, do a round up if required by using the calcuated fraction */
		if (sizein > 10 && fractional >= 5)
			sizein++;
	}

	if (stringout == NULL) {
		exit(EXIT_FAILURE);
	}

	/* Bytes don't need units */
	if (i == 0)
		snprintf(stringout, size, "%9u", sizein);
	else {
		if (sizein < 10) {
			snprintf(stringout, size, "%6u.%u%c", sizein, fractional, sizes[i].abbreviation);
		} else {
			snprintf(stringout, size, "%8u%c", sizein, sizes[i].abbreviation);
		}
	}
}

/*
 *  Display a title or an error or the filesystem information.  All output
 *  from "df" is via this routine.
 */
int display(struct df_config *cfg, struct df_storage *data) {
	fsblkcnt_t total, used, avail;
	char sztotal[STRING_SIZE];
	char szused[STRING_SIZE];
	char szavail[STRING_SIZE];
	int capacity;

	int blockmulti = 1;
	total = convertblks(data->vfs.f_blocks, data->vfs.f_frsize, cfg->blksize);
	used = convertblks(data->vfs.f_blocks - data->vfs.f_bavail, data->vfs.f_frsize, cfg->blksize);
	avail = convertblks(data->vfs.f_bavail, data->vfs.f_frsize, cfg->blksize);

	/* This will be used to rebase the units from blocks to bytes */
	if (humanreadable) {
		blockmulti = cfg->blksize;
	}

	convertsize(total * blockmulti, STRING_SIZE, sztotal);
	convertsize(used * blockmulti, STRING_SIZE, szused);
	convertsize(avail * blockmulti, STRING_SIZE, szavail);
	capacity = (total != 0) ? (used * 100 + total - 1) / total : 100;
	//printf("%-*.*s    %s %s %s %7d%%  %-*.*s\n", COLWIDTH_FSYS, COLWIDTH_FSYS, data->name[0], sztotal, szused, szavail, capacity, COLWIDTH_MOUNT, COLWIDTH_MOUNT, data->name[1]);
	return capacity;
}

/*
 *  Process the next filesystem provided by the iterator method.  Check
 *  that it is either a filesystem itself or suitable for hosting one.
 *  Navigate the MOUNTED_ON/BY hierarchy to identify what level should
 *  be queried and displayed, potentially modifying the name and/or fd.
 */
static int process(df_globals_t *df) {
	struct stat st;
	int fds[24], *ptrfds, numfds, result;
	char mntpath[PATH_MAX];

	if (fstat(df->data.fd, &st) == -1 || !POTENTIAL_FSYS(st.st_mode)) {
	} else {
		if (devctl(df->data.fd, DCMD_FSYS_MOUNTED_BY, mntpath, sizeof(mntpath), NULL) == EOK) {
			if (_connect_fd(0, mntpath, 0, diskMODE, SH_DENYNO, _IO_CONNECT_OPEN, !0, 0, _FTYPE_ANY, _IO_CONNECT_EXTRA_NONE, 0, NULL, 0, NULL, NULL, (numfds
					= sizeof(fds) / sizeof(fds[0]), &numfds), (ptrfds = fds, &ptrfds)) == -1) {
				sprintf(df->data.name[1], "(%s)", mntpath);
			} else if (pair(&df->data.fd, &st, fds, numfds)) {
				strcpy(df->data.name[1], mntpath);
			} else {
				sprintf(df->data.name[1], "(%s)", mntpath);
			}
		} else {
			if (devctl(df->data.fd, DCMD_FSYS_MOUNTED_AT, mntpath, sizeof(mntpath), NULL) == EOK) {
				strcpy(df->data.name[0], mntpath);
			}
			if (devctl(df->data.fd, DCMD_FSYS_MOUNTED_ON, mntpath, sizeof(mntpath), NULL) == EOK) {
				if (_connect_fd(0, mntpath, 0, diskMODE, SH_DENYNO, _IO_CONNECT_OPEN, !0, 0, _FTYPE_ANY, _IO_CONNECT_EXTRA_NONE, 0, NULL, 0, NULL, NULL, (numfds
						= sizeof(fds) / sizeof(fds[0]), &numfds), (ptrfds = fds, &ptrfds)) == -1) {
					strcpy(df->data.name[1], df->data.name[0]);
					strcpy(df->data.name[0], mntpath);
				} else if (pair(NULL, &st, fds, numfds) || numfds == 1) {
					strcpy(df->data.name[1], df->data.name[0]);
					strcpy(df->data.name[0], mntpath);
				} else {
					sprintf(df->data.name[1], "(%s)", df->data.name[0]);
					strcpy(df->data.name[0], mntpath);
				}
			} else {
				strcpy(df->data.name[1], "");
			}
		}
		if (unique(&df->uniq, &st)) {
			trimnames(&df->data);
			if (fstatvfs(df->data.fd, &df->data.vfs) != -1) {
				result = display(&df->cfg, &df->data);
			}
		}
	}
	return (result);
}

/*
 *  Process the next pathname (possibly non-unique) provided by the
 *  iterator method.  Simply get all the managers who service this
 *  pathname and process them sequentially.
 */
static int multiprocess(df_globals_t *df, char *path, char *by) {
	int fds[24], *ptrfds, numfds, i, result;
	char mntpath[PATH_MAX];
	result = 0;
	strncpy(df->data.name[0], path, sizeof(df->data.name[0]));
	df->data.name[0][sizeof(df->data.name[0]) - 1] = '\0';
	numfds = 1;
	ptrfds = fds;
	if (_connect_fd(	0, path, 0, diskMODE,
						SH_DENYNO, _IO_CONNECT_OPEN, !0, 0,
						_FTYPE_ANY, _IO_CONNECT_EXTRA_NONE, 0, NULL,
						0, NULL, NULL, (numfds	= sizeof(fds) / sizeof(fds[0]), &numfds),
						(ptrfds = fds, &ptrfds)
						) == -1) {
	} else {
		result = ENOENT;
		for (i = 0; i < numfds; ++i) {
			if (by == NULL || (devctl(fds[i], DCMD_FSYS_MOUNTED_BY, mntpath, sizeof(mntpath), NULL) == EOK
					&& !strcmp(by, trimname(mntpath, !0)))) {
				strcpy(df->data.name[0], path);
				df->data.fd = fds[i];
				result = process(df);
			}
			close(df->data.fd);
		}
	}
	return (result);
}

int disk_load(char * path) {
	df_globals_t df;
	int result;
	df.cfg.blksize = 512, df.cfg.flagP = df.cfg.flagN = df.cfg.flagG = 0;
	df.cfg.adjust = (df.cfg.flagG) ? "" : ((df.cfg.flagP && df.cfg.blksize == 512) ? " " : "");
	df.cfg.mode = FSYS_FROM_ARGV;
	df.uniq = NO_UNIQ_FILTER;

	result = multiprocess(&df, path, NULL);
	return result;
}
