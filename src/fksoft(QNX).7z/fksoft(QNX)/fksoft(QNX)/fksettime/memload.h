#ifndef MEMLOAD_H_
#define MEMLOAD_H_
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdint.h>

int mem_load(void );

#endif /* CPULOAD_H_ */
