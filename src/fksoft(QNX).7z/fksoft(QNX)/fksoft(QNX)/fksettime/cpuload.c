/* Y o u r   D e s c r i p t i o n                       */
/*                            AppBuilder Photon Code Lib */
/*                                         Version 2.03  */

/* Standard headers */
#include "cpuload.h"
int cpu_load(void )

	{
	int id;
	unsigned int load;
	_Uint64t start,stop;
	_Uint64t tmp,ms,second;


	ms = 1000000;//=1000us * 1000ns
	second = ms * 1000;
	id = ClockId(1, 1);
    ClockTime(id, NULL, &start);
    sleep(1);//��ʱһ����
    ClockTime(id, NULL, &stop);
    tmp = stop-start;
    if (tmp > second) {
		printf("tmp=%d\n",tmp);
		tmp = second;
    }
    tmp = (second - tmp)*100;
    load =  (tmp / second);
    return load;
	}

