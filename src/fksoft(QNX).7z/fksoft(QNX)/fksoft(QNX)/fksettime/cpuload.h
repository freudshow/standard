#ifndef CPULOAD_H_
#define CPULOAD_H_
#include <stdlib.h>
#include <stdio.h>
#include <hw/inout.h>
#include <sched.h>
#include <pthread.h>
#include <inttypes.h>
#include <time.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/neutrino.h>

int cpu_load(void );

#endif /* CPULOAD_H_ */
