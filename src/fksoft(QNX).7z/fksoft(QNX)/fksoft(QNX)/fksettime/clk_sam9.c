
#include "clk_sam9.h"
static int fd = -1;
unsigned int rtc_addr;
static int i2c_read(unsigned char reg, unsigned char val[], unsigned char num);
static int i2c_write(unsigned char reg, unsigned char val[], unsigned char num);
static int i2c_read(unsigned char reg, unsigned char val[], unsigned char num)
{
    iov_t           siov[2], riov[2];
    i2c_sendrecv_t  hdr;

    hdr.slave.addr = rtc_addr;
    hdr.slave.fmt = I2C_ADDRFMT_7BIT;
    hdr.send_len = 1;
    hdr.recv_len = num;
    hdr.stop = 1;

    SETIOV(&siov[0], &hdr, sizeof(hdr));
    SETIOV(&siov[1], &reg, sizeof(reg));

    SETIOV(&riov[0], &hdr, sizeof(hdr));
    SETIOV(&riov[1], val, num);

    return devctlv(fd, DCMD_I2C_SENDRECV, 2, 2, siov, riov, NULL);
}


static int i2c_write(unsigned char reg, unsigned char val[], unsigned char num)
{
    iov_t           siov[3];
    i2c_send_t      hdr;
#if DEBUG > 0
    fprintf(stderr,"addr=%02x data=%02x len=%d\n",reg,val[0],num);
#endif
    hdr.slave.addr = rtc_addr;
    hdr.slave.fmt = I2C_ADDRFMT_7BIT;
    hdr.len = num + 1;
    hdr.stop = 1;

    SETIOV(&siov[0], &hdr, sizeof(hdr));
    SETIOV(&siov[1], &reg, sizeof(reg));
    SETIOV(&siov[2], val, num);

    return devctlv(fd, DCMD_I2C_SEND, 3, 0, siov, NULL, NULL);
}

int
init_rtc(void)
{
    fd = open(I2C_DEVNAME, O_RDWR);
    if (fd < 0) {
        printf("Unable to open I2C device\n");
        printf("Unable to open I2C device\n");
        return -1;
    }
    return 0;
}


int
fini_rtc(void)
{
    close(fd);
    return 0;
}


int
get_rtc(struct tm *tm)
{
    unsigned char   date[7]={0};
	if (rtc_addr == 0x51 ) { // RTC8563
		do {
			i2c_read(2, date, 7);
			usleep(100);
		} while(date[0] & 0x80);
		date[0]	 &= 0x7f;
		date[1]	 &= 0x7f;
		date[2]	 &= 0x3f;
		date[3]	 &= 0x3f;
		date[4]  &= 0x07;
	#if DEBUG > 0
		fprintf(stderr,"\nget:",date[i]);
		for (i=0;i<7;i++)
			fprintf(stderr,"%02x ",date[i]);
	#endif


		tm->tm_sec 	= BCD2BIN(date[SECOND]);
		tm->tm_min 	= BCD2BIN(date[MINUTE]);
		tm->tm_hour	= BCD2BIN(date[HOUR]);
		tm->tm_mday	= BCD2BIN(date[MDAY]);
		tm->tm_wday = date[WDAY];
		tm->tm_mon	= BCD2BIN(date[MONTH] & 0x1f) - 1;
		tm->tm_year	= BCD2BIN(date[YEAR]);
		if (date[5] & 0x80) { //19xx
		} else {			  //20xx
			tm->tm_year	+= 100;
		}
	} else {				//RTC8025
		do {
			i2c_read(0, date, 7);
			usleep(100);
		} while(date[0] & 0x80);


	#if DEBUG > 0
		fprintf(stderr,"\nget:",date[i]);
		for (i=0;i < 7;i++)
			fprintf(stderr,"%02x ",date[i]);
	#endif


		tm->tm_sec 	= BCD2BIN(date[0]& 0x7f);
		tm->tm_min 	= BCD2BIN(date[1]& 0x7f);
		tm->tm_hour	= BCD2BIN(date[2]& 0x3f);
		tm->tm_wday = BCD2BIN(date[3]& 0x07);
		tm->tm_mday	= BCD2BIN(date[4]& 0x3f);
		tm->tm_mon	= BCD2BIN(date[5] & 0x1f) - 1;
		tm->tm_year	= BCD2BIN(date[6]);
		tm->tm_year	+= 100;
	}
    return(0);
}

int
set_rtc(struct tm *tm)
{
    unsigned char   date[7],i;
	if (rtc_addr == 0x51 ) { // RTC8563

		date[SECOND] = BIN2BCD(tm->tm_sec); /* implicitly clears stop bit */
		date[MINUTE] = BIN2BCD(tm->tm_min);
		date[HOUR]   = BIN2BCD(tm->tm_hour);
		date[MDAY]   = BIN2BCD(tm->tm_mday);
		date[WDAY]   = BIN2BCD(tm->tm_wday);
		date[MONTH]  = BIN2BCD(tm->tm_mon +1);
		if (tm->tm_year < 100) {
			date[MONTH]  |= 0x80;
		}
		date[YEAR]  = BIN2BCD((tm->tm_year) % 100);
#if DEBUG > 0
		fprintf(stderr,"\nset:",date[i]);
		for (i=0;i<7;i++)
			fprintf(stderr,"%02x ",date[i]);
#endif
	    	for (i=0;i<7;i++) {
	    		i2c_write(i+2, &date[i], 1);
	    		usleep(100);
	    	}
    } else {				//RTC8025

        date[0]  = BIN2BCD(tm->tm_sec); /* implicitly clears stop bit */
        date[1]  = BIN2BCD(tm->tm_min);
        date[2]  = BIN2BCD(tm->tm_hour);
        date[3]  = BIN2BCD(tm->tm_wday);
        date[4]  = BIN2BCD(tm->tm_mday);
       	date[5]  = BIN2BCD(tm->tm_mon +1);
       	date[6]  = BIN2BCD((tm->tm_year) % 100);


    #if DEBUG > 0
    	fprintf(stderr,"\nset:",date[i]);
    	for (i=0;i<7;i++)
    		fprintf(stderr,"%02x ",date[i]);
    	fprintf(stderr,"\n");
    #endif
	i2c_write(0, date, 7);
    }
    return(0);
}
