#include "memload.h"

int mem_load(void)
{

	int						fd;
	unsigned int			stat_size;
	unsigned int			total;
	struct stat64			st;
	char buffer[10]={"/./proc\0"};



	if ((fd = open64(buffer, O_RDONLY)) == -1) {
		exit(-1);
	}

	if (fstat64(fd, &st) == -1)
		exit(-1);
	stat_size = (unsigned int)(st.st_size/1024/1024);
	total = 32-stat_size;
	total *= 100;
	total = total /32;
	close(fd);
	return total;
}
