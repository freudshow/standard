#ifndef CLK_SAM9_H_
#define CLK_SAM9_H_

#include <time.h>
#include <fcntl.h>
#include <fkbase/i2c.h>
#include <stdio.h>

#define SECOND       0   /* 00-59 */
#define MINUTE       1   /* 00-59 */
#define HOUR         2   /* 0-1/00-23 */
#define MDAY         3   /* 01-31 */
#define WDAY         4   /* 01-07 */
#define MONTH        5   /* 01-12 */
#define YEAR         6   /* 00-99 */
#define CTRL         9

#define I2C_DEVNAME  "/dev/i2c0"

#define BIN2BCD(A)	(((((A) % 10000)/1000) << 12) + ((((A) % 1000)/100) << 8) + ((((A) % 100)/10) << 4) + ((A) % 10))
#define BCD2BIN(A)	((((A) & 0xf000) >> 12) * 1000 + (((A) & 0xf00) >> 8) * 100 + (((A) & 0xf0) >> 4) * 10 + ((A) & 0x0f))

extern int init_rtc(void);
extern int fini_rtc(void);
extern int get_rtc(struct tm *tm);
extern int set_rtc(struct tm *tm);



#endif /* CLK_SAM9_H_ */
