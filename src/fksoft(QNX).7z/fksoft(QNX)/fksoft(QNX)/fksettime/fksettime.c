#include "fksettime.h"
pthread_t thread_rtc;
unsigned int rtc_addr=0x32; // RTC 8025T
name_attach_t       *attach;
RTimeData           *RtuDataAddr;//�ڴ湲��������ָ��
INT8U       PORT_ID;

void *thread3()//����rtcʱ������
{
	struct timespec  cur;
	struct tm *p;
	struct sched_param param;

//���ø����ȼ�
	//sched_getparam(0, &param);
	//param.sched_priority = 100;
	//pthread_setschedparam(pthread_self( ),SCHED_FIFO,&param);

	init_rtc();			//��ʼ��i2c
	clock_gettime(CLOCK_REALTIME, &cur);
	p = localtime(&cur.tv_sec);
	p->tm_isdst = -1;	//��ֹ����ʱ
	set_rtc(p);
	fini_rtc();

	sched_getparam(0, &param);
	param.sched_priority = 10;
	pthread_setschedparam(pthread_self( ),SCHED_FIFO,&param);
	RtuDataAddr->settime1=0;
	RtuDataAddr->settime2=0;
	pthread_exit(NULL);
}

int AdjustTime()
{
	long rate = 10000; //����ʱ�䣬����
	long maxsec = 600; //���ʱ����
	struct timespec new, cur;
	struct tm *p,*p1,*p2,local_time;
	long sec, usec;
	int rc = -1;
	time_t timevar,timevar1,timevar2;

	if(init_rtc()){						//��ʼ��i2c
		return 0;
	}
	p = &local_time;
	memset(p, 0, sizeof(*p));
	p->tm_isdst = -1;		//��ֹ����ʱ
	p1 = &local_time;
	memset(p1, 0, sizeof(*p1));
	p1->tm_isdst = -1;		//��ֹ����ʱ
	p2 = &local_time;
	memset(p2, 0, sizeof(*p2));
	p2->tm_isdst = -1;		//��ֹ����ʱ

	get_rtc((struct tm *)p1);
	delay(1000);
	get_rtc((struct tm *)p2);
	delay(1000);
	get_rtc((struct tm *)p);
	delay(1000);
	printf("rtc get: current RTC time is %d/%d/%d %d:%d:%d \n",
			p->tm_year + 1900,
			p->tm_mon + 1,
			p->tm_mday,
			p->tm_hour,
			p->tm_min,
			p->tm_sec);

	timevar = mktime(p);
	timevar1 = mktime(p1);
	timevar2 = mktime(p2);
	if ((timevar2-timevar1>5) || (timevar2-timevar1<0))
	{
		fprintf(stderr,"\n\r rtc get error0");
		return 0;
	}
	if ((timevar-timevar1>5) || (timevar-timevar1<0))
	{
		fprintf(stderr,"\n\r rtc get error1");
		return 0;
	}
	if ((timevar-timevar2>5) || (timevar-timevar2<0))
	{
		fprintf(stderr,"\n\r rtc get error2");
		return 0;
	}
	new.tv_nsec = 0;
	new.tv_sec = timevar;
	clock_gettime(CLOCK_REALTIME, &cur);
	printf("new=%ld,old=%ld\n",new.tv_sec,cur.tv_sec);
	if ((sec = new.tv_sec - cur.tv_sec) >= -maxsec && sec <= maxsec)
	{
		struct _clockadjust adj;
		printf("           rtc read: attempting slow adjust (delta = %ld sec.)\n",sec);
			usec = new.tv_sec * 1000000 + new.tv_nsec / 1000;
			usec -= cur.tv_sec * 1000000 + cur.tv_nsec / 1000;
		printf("            usec=%d\n",usec);

		adj.tick_nsec_inc = 1000L * (usec / rate);
		adj.tick_count = rate;
		printf("          rtc read: Adjusting clock %ld000 nsec\n",usec);
		printf("          rtc read: (%ld nsec per tick over %ld ticks)\n",adj.tick_nsec_inc,adj.tick_count);
		rc = ClockAdjust(CLOCK_REALTIME, &adj, NULL);

		return 1;
	}
	else
	{
		return 0;
	}
	fini_rtc();
	return 1;
}
///******************************************************************************************************************
///* �������ƣ�PARSE_CMD()
////* ��    �ܣ�������
///* ��ڲ�������
///* ���ڲ�������
///*******************************************************************************************************************/
INT8U   PARSE_CMD(int argc, char * argv[])
{
	INT8U  proc_name[32] = "";

	//printf("cmdline=%d,%s %s\r\n", argc, argv[0], argv[1]);
	if(argc < 2)return (FALSE);
	PORT_ID = atoi(argv[1]);
	sprintf((char *)proc_name, "%s %d", argv[0], PORT_ID);
	if((attach = name_attach(NULL, (char *)proc_name,0))  == NULL)
	{
		fprintf(stderr, "ERR:'%s' runed,cann't regist: %s\r\n", proc_name, strerror(errno));
		return (FALSE);
	}
	return (TRUE);
}
///******************************************************************************************************************
///* �������ƣ�QuitProcess()
///* ��    �ܣ�
///* ��ڲ�������
///* ���ڲ�������
///*******************************************************************************************************************/
void QuitProcess(int signo)
{
	delay(100);
	RtuDataAddr->stPortPara[PORT_ID].PID=0;
   	name_detach(attach, 0);
   	fprintf(stderr,"fksettime quit");
	exit(0);
}
int main(int argc, char *argv[]) {

	int NowDay;
	int checktime;
	TS ts;
	struct sigaction sa1;
	struct sched_param param;

	sched_getparam(0, &param);
	param.sched_priority = 5;
	pthread_setschedparam(pthread_self(), SCHED_FIFO, &param);

	if (OpenMem())
		return EXIT_FAILURE;
	if (RtuDataAddr->mem_len != sizeof(RTimeData)) {
		fprintf(stderr, "base mem uncompared prog will exit %d :\n", sizeof(RTimeData));
		return EXIT_FAILURE;
	}
	if (!PARSE_CMD(argc, argv)) {
		return EXIT_FAILURE;
	}
	//////////////////////////////////////////////////////////////////////////
	sa1.sa_handler = QuitProcess;
	sigemptyset(&sa1.sa_mask);
	sa1.sa_flags = 0;
	sigaction(SIGTERM, &sa1, NULL);
	sigaction(SIGSYS, &sa1, NULL);
	sigaction(SIGPWR, &sa1, NULL);
	sigaction(SIGKILL, &sa1, NULL);
	sigaction(SIGQUIT, &sa1, NULL);
	sigaction(SIGILL, &sa1, NULL);
	sigaction(SIGINT, &sa1, NULL);
	sigaction(SIGHUP, &sa1, NULL);
	sigaction(SIGABRT, &sa1, NULL);
	sigaction(SIGBUS, &sa1, NULL);
	RtuDataAddr->stPortPara[PORT_ID].PID = getpid();
	RtuDataAddr->settime1=0;
	RtuDataAddr->settime2=0;
	while(RtuDataAddr->Dev_Init_OK==0)
	{
		CleardeadCount();
		delay(1000);
	}
	TSGet(&ts);
	NowDay=ts.Day;
	checktime = 0;
	while(1)
	{
		delay(500);
		CleardeadCount();
		TSGet(&ts);
		if((NowDay!=ts.Day)&&(ts.Hour==0)&&(ts.Minute==0)&&(ts.Sec==0))
		{
			sched_getparam(0, &param);
			param.sched_priority = 100;
			pthread_setschedparam(pthread_self( ),SCHED_FIFO,&param);
			printf("\n\r check time");
			printf("\n\r check time");
			AdjustTime();
			checktime = 1;
			sched_getparam(0, &param);
			param.sched_priority = 5;
			pthread_setschedparam(pthread_self(), SCHED_FIFO, &param);
		}
		if (ts.Minute ==0) checktime = 0;
		if((RtuDataAddr->settime1==1)||(RtuDataAddr->settime2==1))
		{
			//�������ȼ�Ϊ���
			sched_getparam(0, &param);
			param.sched_priority = 100;
			pthread_setschedparam(pthread_self( ),SCHED_FIFO,&param);
			system("rtc -s sam9");
			//�������ȼ�Ϊ���
			sched_getparam(0, &param);
			param.sched_priority = 5;
			pthread_setschedparam(pthread_self(), SCHED_FIFO, &param);
		}
		NowDay = ts.Day;
		RtuDataAddr->cpu = cpu_load();
	    RtuDataAddr->mem = mem_load();
		RtuDataAddr->sys = disk_load("/dev/fs0p1");
		RtuDataAddr->data = disk_load("/nand");
	}
	return EXIT_SUCCESS;
}
