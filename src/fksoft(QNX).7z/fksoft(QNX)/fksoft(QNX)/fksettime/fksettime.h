#ifndef FKSETTIME_H_
#define FKSETTIME_H_
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <ctype.h>
#include <time.h>
#include <stdint.h>
#include <signal.h>
#include <sys/sched.h>
#include <semaphore.h>
#include <process.h>
#include <sys/neutrino.h>
#include <sys/netmgr.h>
#include <sys/dispatch.h>
#include <errno.h>
#include <netdb.h>
#include <hw/inout.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <math.h>
#include <termios.h>
#include <fkbase/memdef.h>
#include <fkbase/fkbasefun.h>
#include "cpuload.h"
#include "memload.h"
#include "diskload.h"
#include "clk_sam9.h"
void *thread3();//����rtcʱ������
INT8U   PARSE_CMD(int argc, char * argv[]);
void QuitProcess(int signo);

#endif /* FKSETTIME_H_ */
