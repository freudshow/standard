#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <ctype.h>
#include <time.h>
#include <stdint.h>
#include <signal.h>
#include <sys/sched.h>
#include <semaphore.h>
#include <process.h>
#include <sys/neutrino.h>
#include <sys/netmgr.h>
#include <sys/dispatch.h>
#include <errno.h>
#include <netdb.h>
#include <hw/inout.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <math.h>
#include <termios.h>
#include <fkbase/memdef.h>
#include <fkbase/fkbasefun.h>
#include <fkbase/spi-master.h>
#include <fkbase/memtype.h>
#include <includes.h>
#include "ser.h"
#include <fkxiebo.h>

typedef unsigned long long     	INT64U;                   /* Unsigned 64 bit quantity    */
typedef signed long long  		INT64S;                   /* Unsigned 64 bit quantity    */

const char verstr[]={"VER-STRING-FLG=014.002.217.004"__DATE__" "__TIME__};
#define NUM_FFT  64
#define EXP_FFT  6    //(2)6=64
INT32S REC[128];
name_attach_t       *attach;
RTimeData           *RtuDataAddr;//�ڴ湲��������ָ��
INT8U       		PORT_ID;
Data_Type_17		xb_Time;
INT32U UA_Zong_Hanyoulv,UB_Zong_Hanyoulv,UC_Zong_Hanyoulv;
INT64U IA_Zongjibian,IB_Zongjibian,IC_Zongjibian,UA_Zongjibian,UB_Zongjibian,UC_Zongjibian;
typedef struct
{
   INT32S Real;
   INT32S Imag;
}Lisan;

typedef struct
{
   INT32U x;
   INT32S y;
}SData;//����x�ͺ���ֵy�Ľṹ
typedef struct
{
    INT8U  HZpoint;
    INT32U HZBuff[16];

}hzxg;

hzxg HZall;
#if (NUM_FFT == 64)
const INT32S sin_tab[64]  = {     0,   3212,   6393,   9512,  12539,  15446,  18204,  20787,  23170,   25329,  27245,  28898,  30273,  31356,  32137,  32609,
                              32767,  32609,  32137,  31356,  30273,  28898,  27245,  25329,  23170,   20787,  18204,  15446,  12539,   9512,   6393,   3212,
                                  0,  -3212,  -6393,  -9512, -12539, -15446, -18204, -20787, -23170,  -25329, -27245, -28898, -30273, -31356, -32137, -32609,
                             -32767, -32609, -32137, -31356, -30273, -28898, -27245, -25329, -23170,  -20787, -18204, -15446, -12539,  -9512,  -6393,  -3212};

const INT32S cos_tab[64]  = {  32767,  32609,  32137,  31356,  30273,  28898,  27245,  25329,  23170,   20787,  18204,  15446,  12539,   9512,   6393,   3212,
                                  0,  -3212,  -6393,  -9512, -12539, -15446, -18204, -20787, -23170,  -25329, -27245, -28898, -30273, -31356, -32137, -32609,
                             -32767, -32609, -32137, -31356, -30273, -28898, -27245, -25329, -23170,  -20787, -18204, -15446, -12539,  -9512,  -6393,  -3212,
                                  0,   3212,   6393,   9512,  12539,  15446,  18204,  20787,  23170,   25329,  27245,  28898,  30273,  31356,  32137,  32609};





const INT8U DXTable[64] =  {
							0 ,	32,	16,	48,
							8 ,	40,	24,	56,
							4 ,	36,	20,	52,
							12,	44,	28,	60,
							2 ,	34,	18,	50,
							10,	42,	26,	58,
							6 ,	38,	22,	54,
							14,	46,	30,	62,

							1 ,	33,	17,	49,
							9 ,	41,	25,	57,
							5 ,	37,	21,	53,
							13,	45,	29,	61,
							3 ,	35,	19,	51,
							11,	43,	27,	59,
							7 ,	39,	23,	55,
							15,	47,	31,	63
						  };


#endif
#if (NUM_FFT == 128)
const INT16S sin_tab[128]={
0,			1608,		3212,		4808,		6393,		7962,		9512,		11039,
12539,		14010,		15446,		16846,		18204,		19519,		20787,		22005,
23170,		24279,		25329,		26319,		27245,		28105,		28898,		29621,
30273,		30852,		31356,		31785,		32137,		32412,		32609,		32728,
32767,		32728,		32609,		32412,		32137,		31785,		31356,		30852,
30273,		29621,		28898,		28105,		27245,		26319,		25329,		24279,
23170,		22005,		20787,		19519,		18204,		16846,		15446,		14010,
12539,		11039,		9512,		7962,		6393,		4808,		3212,		1608,
0,			-1608,		-3212,		-4808,		-6393,		-7962,		-9512,		-11039,
-12539,		-14010,		-15446,		-16846,		-18204,		-19519,		-20787,		-22005,
-23170,		-24279,		-25329,		-26319,		-27245,		-28105,		-28898,		-29621,
-30273,		-30852,		-31356,		-31785,		-32137,		-32412,		-32609,		-32728,
-32767,		-32728,		-32609,		-32412,		-32137,		-31785,		-31356,		-30852,
-30273,		-29621,		-28898,		-28105,		-27245,		-26319,		-25329,		-24279,
-23170,		-22005,		-20787,		-19519,		-18204,		-16846,		-15446,		-14010,
-12539,		-11039,		-9512,		-7962,		-6393,		-4808,		-3212,		-1608
};

const INT16S cos_tab[128]={
32767,		32728,		32609,		32412,		32137,		31785,		31356,		30852,
30273,		29621,		28898,		28105,		27245,		26319,		25329,		24279,
23170,		22005,		20787,		19519,		18204,		16846,		15446,		14010,
12539,		11039,		9512,		7962,		6393,		4808,		3212,		1608,
0,			-1608,		-3212,		-4808,		-6393,		-7962,		-9512,		-11039,
-12539,		-14010,		-15446,		-16846,		-18204,		-19519,		-20787,		-22005,
-23170,		-24279,		-25329,		-26319,		-27245,		-28105,		-28898,		-29621,
-30273,		-30852,		-31356,		-31785,		-32137,		-32412,		-32609,		-32728,
-32767,		-32728,		-32609,		-32412,		-32137,		-31785,		-31356,		-30852,
-30273,		-29621,		-28898,		-28105,		-27245,		-26319,		-25329,		-24279,
-23170,		-22005,		-20787,		-19519,		-18204,		-16846,		-15446,		-14010,
-12539,		-11039,		-9512,		-7962,		-6393,		-4808,		-3212,		-1608,
0,			1608,		3212,		4808,		6393,		7962,		9512,		11039,
12539,		14010,		15446,		16846,		18204,		19519,		20787,		22005,
23170,		24279,		25329,		26319,		27245,		28105,		28898,		29621,
30273,		30852,		31356,		31785,		32137,		32412,		32609,		32728
};


const INT8U DXTable[128]={
							0 ,	64,	32,	96 ,16,	80,	48,112,
							8 ,	72,	40,	104,24,	88,	56,120,
							4 ,	68,	36,	100,20,	84,	52,116,
							12,	76,	44,	108,28,	92,	60,124,
							2 ,	66,	34,	98 ,18,	82,	50,114,
							10,	74,	42,	106,26,	90,	58,122,
							6 ,	70,	38,	102,22,	86,	54,118,
							14,	78,	46,	110,30,	94,	62,126,
							1 ,	65,	33,	97 ,17,	81,	49,113,
							9 ,	73,	41,	105,25,	89,	57,121,
							5 ,	69,	37,	101,21,	85,	53,117,
							13,	77,	45,	109,29,	93,	61,125,
							3 ,	67,	35,	99 ,19,	83,	51,115,
							11,	75,	43,	107,27,	91,	59,123,
							7 ,	71,	39,	103,23,	87,	55,119,
							15,	79,	47,	111,31,	95,	63,127
						  };



#endif
//�������ƣ�PARSE_CMD()
//��    �ܣ�������
//��ڲ�������
//���ڲ�������
INT8U   PARSE_CMD(int argc, char * argv[])
{
	char  proc_name[32] = "";

	//printf("cmdline=%d,%s %s\r\n", argc, argv[0], argv[1]);
	if(argc < 2)return (FALSE);
	PORT_ID = atoi(argv[1]);
	sprintf(proc_name, "%s %d", argv[0], PORT_ID);
	if((attach = name_attach(NULL, proc_name,0))  == NULL)
	{
		fprintf(stderr, "ERR:'%s' runed,cann't regist: %s\r\n", proc_name, strerror(errno));
		return (FALSE);
	}
	return (TRUE);
}
//******************************************************************************************************************
//* �������ƣ�QuitProcess()
//* ��    �ܣ�
//* ��ڲ�������
//* ���ڲ�������
void QuitProcess(int signo)
{
	delay(100);
	RtuDataAddr->stPortPara[PORT_ID].PID=0;
   	name_detach(attach, 0);
   	fprintf(stderr,"fkxiebo quit");
	exit(0);
}
INT32S ATTRead(INT8U spi, INT32U addr, INT32U len, INT8U *buf, INT16U to) {
	INT32U i;
	INT32S rec;
	int cnt = 0;

	cmd[cnt++] = addr & 0x7f;
	spi_cmdread(fp, device, cmd, cnt, buf, len);
	rec = 0;
	for (i = 0; i < len; i++) {
		rec = (rec << 8) | buf[i];
	}
	return rec;
}

INT32S ATTWrite(INT8U spi, INT32U addr, INT32U len, INT8U *buf, INT16U to) {
	INT32U i;
	int cnt = 0;
	int num;

	if ((addr == 0xC3) || (addr == 0xC6) || (addr == 0xC9) || (addr == 0xD3)) {
		cmd[cnt++] = addr | 0xC0; //д��������
	} else
		cmd[cnt++] = addr | 0x80; //д����У������
	for (i = 0; i < len; i++) {
		cmd[cnt++] = buf[i];
	}
	num = spi_write(fp, device, cmd, cnt);
	return 0;
}
//*******************************************/
////////////////Ƶ�ʴ�����С����//////////////
//ԭ����Ϊ�˱�֤Ƶ�ʵ�׼ȷ�ԣ���Ƶ�ʽ�����16��ȡƽ��
//�������������⣬Ƶ����Ӧ��
//Ϊ�˱�֤��ʱ����Ӧ���������С����
//��ڲ�������������Ƶ��˲ʱֵ
//���ڲ�������������г����ֵ�����Ƶ��
//*******************************************/
INT32U XBhz(INT32U *hz,INT32U temphz)
{
	INT8U  i,j;
	INT32U SumHz;

	SumHz =0;
	j = sizeof(hz);

	for(i=0;i<j;i++)
	SumHz = SumHz + hz[i];

	SumHz = SumHz/j;

	if((abs(SumHz - temphz)) > 1000)      //�������1HZ
		return temphz;                    //����˲ʱ��Ƶ��
	else
		return SumHz;                     //���򷵻�ƽ��Ƶ��

}
/***********************************************************/
//fft�㷨��
//*��ڲ�������������Ժ�Ĳ����㣬���ڲ�����ʵ���鲿
/***********************************************************/
void FFT_Test(INT32S *dataR,Lisan *some)
{
    int k,L,j,b,p,i,temp;

    INT32S TR,TI;
    INT32S XRC,XRS,XIC,XIS,AXRI,SXRI;
    INT32S dataI[NUM_FFT];

    memset(dataI,0,sizeof(dataI));

    for(L=1;L<=EXP_FFT;++L) {   /* for(1) */
        b=1;
        i=L-1;
        if (i>0)
        	b=b<<(i);
        for(j=0;j<=b-1;j++) {   /* for(2) */
            p=1;
            i=EXP_FFT-L;
            if (i>0)
                p=p<<(i);
            p=p*j;
            for(k=j;k<NUM_FFT;k+=(b << 1)) {  /* for(3) */

                TR=dataR[k];
                TI=dataI[k];
                temp=k+b;

				XRC=((INT64S)dataR[temp]*cos_tab[p])>>15;
				XRS=((INT64S)dataR[temp]*sin_tab[p])>>15;
				XIC=((INT64S)dataI[temp]*cos_tab[p])>>15;
                XIS=((INT64S)dataI[temp]*sin_tab[p])>>15;

                AXRI=XRC+XIS;
                SXRI=XRS-XIC;
                dataR[k]=TR+AXRI;//(XRC+XIS);
                dataI[k]=TI-SXRI;//(XRS-XIC);
                dataR[temp]=TR-AXRI;//(XRC+XIS);
                dataI[temp]=TI+SXRI;//(XRS-XIC);


            }
        }
    }

    for(i=0;i<20;i++)
	{ /* ֻ��Ҫ20�����µ�г�����з��� */
      some[i].Real = dataR[i];
      some[i].Imag = dataI[i];
	}
}

/******************************************************************************/
/**************************  fft  *********************************************/
/*****������������������***********/
/******************************************************************************/
void fft_daoxu(INT32S *dataR)
{

   INT8U a,b,i;
   INT32S Temp;
   for(i=1;i<NUM_FFT;i++)
   {
   	a = i;
   	b = DXTable[i];
   	if(b > a)
   	{
   	  Temp = dataR[a];
   	  dataR[a]=dataR[b];
   	  dataR[b]=Temp;
   	}
   }

}
//*****************�������ղ�ֵ**************************
void chazhilage(INT32S *piRetValue,INT32S *iValue)
{
   INT16U i,j,p;
   INT32U fADSampleInterval,Xtemp;
   INT32U fFFtNeedInterval;


   INT64S Temp;

   INT32S Temp1,Temp2,Temp3;

   INT32U real_hz;
   SData sData[3];

   if(RtuDataAddr->RES.RES_F<4000)
	   RtuDataAddr->RES.RES_F=5000;

   real_hz = RtuDataAddr->RES.RES_F;

   fADSampleInterval =   3125;  //(100 * (1000/5000) /64) * 1000 =0.3125 *1000 ms
   fFFtNeedInterval  =   15625000/real_hz;  //��50Hzʱ��ֵ��Ĳ�����ӦΪ3200Hz����ô����ǰƵ��Ϊ55Hz���ֵ��Ĳ����� �� 3200*55/50; ��50Hz��ӦADƵ�ʼĴ�����0x19999��


   j=0;

   for(i=1; i<=NUM_FFT; i++) //fft�ĵ���
   {

	 Xtemp = fFFtNeedInterval * i;     //Ŀǰ��Ҫ���x ����

	 if( (Xtemp%3125) > 1562)//(3125/2))
	 p =  Xtemp /3125 ;    //�� p �������㣬�Լ��� p + 1�� �� p + 2   ������ ֮�䡣
     else
     {

       p =  Xtemp /3125 ;

       if(p >1)
       p = p-1;
	   else
	   p = 1;

     }

	 if(p<1) p=1;

	 sData[0].x = p * 3125;
	 sData[1].x = (p+1) * 3125;
	 sData[2].x = (p+2) * 3125;

	 sData[0].y = iValue[p];
	 sData[1].y = iValue[p+1];
	 sData[2].y = iValue[p+2];

     /*�������������������ֵ�ֳ�Ϊ�����߲�ֵ��
       y= y1*(x-x2)(x-x3)/(x1-x2)(x1-x3)  + y2*(x-x1)(x-x3)/(x2-x1)(x2-x3) +y3*(x-x1)(x-x2)/(x3-x1(x3-x2)
      ���У�(x1,y1)��(x2,y2)��(x3,y3)Ϊ������������,(x,y)ΪҪ��õĵ�
     */
     Temp1 = (INT32S)(Xtemp-sData[0].x);
     Temp2 = (INT32S)(Xtemp-sData[1].x);
     Temp3 = (INT32S)(Xtemp-sData[2].x);

     Temp  = (INT64S)Temp2*Temp3*iValue[p]/(3125*3125*2) + (INT64S)Temp1*Temp3*iValue[p+1]/(-3125*3125)+
             (INT64S)Temp1*Temp2*iValue[p+2]/(3125*3125*2) ;

     piRetValue[j++]=  Temp;
    	/*
       Print(DebugComm,"\r\n sData[0].x=%d\r\n",sData[0].x);
       Print(DebugComm,"\r\n sData[0].y=%d\r\n",sData[0].y);
       Print(DebugComm,"\r\n sData[1].x=%d\r\n",sData[1].x);
       Print(DebugComm,"\r\n sData[1].y=%d\r\n",sData[1].y);


       Print(DebugComm,"\r\n x=%d\r\n",Xtemp);
       Print(DebugComm,"\r\n y=%d\r\n",piRetValue[j-1]);
       */

	 }
}
//ffttest  �ܺ���
//��ڲ�������ɢ������
//���ڲ�����г��
void ffttest(INT32S *pointbuf,INT32U *xb)
{
	INT8U i;
	INT32U tempasd;
    INT32S temp1,temp2;

	INT32S chazhibuf[64];   //64��fft
	Lisan allsome[20];
	TS ts;
	TSGet(&ts);

	chazhilage(chazhibuf,pointbuf);
	fft_daoxu(chazhibuf);
	FFT_Test(chazhibuf,allsome);

	for(i=0;i<20;i++)
	{
		temp1 = (allsome[i].Real)*559/(Kua + RtuDataAddr->display_xiu[8]*2);
		temp2 = (allsome[i].Imag)*559/(Kua + RtuDataAddr->display_xiu[8]*2);
		tempasd =(INT64U) (temp1*temp1+temp2*temp2) ;
		xb[i]=sqrt(tempasd);
	}
}
void XIEBO_YUEXIAN_Calc()
{
	INT16U ZongJiBian_UHanyoulvSX,JiCi_UHanyoulvSX,OuCi_UHanyoulvSX,ZongJiBian_ISX,NCixiebo_ISX[20];
	INT8U i;
	if(RtuDataAddr->FkInput_Value.F60_Set_Para.Valid==1)
	{
		//�����ܻ����ѹ����������
		ZongJiBian_UHanyoulvSX=((RtuDataAddr->FkInput_Value.F60_Set_Para.All_QiBian_DYaHy_S[1]>>4)*10)+
			(RtuDataAddr->FkInput_Value.F60_Set_Para.All_QiBian_DYaHy_S[1]&0x0f);
		ZongJiBian_UHanyoulvSX=(ZongJiBian_UHanyoulvSX*100)+((RtuDataAddr->FkInput_Value.F60_Set_Para.All_QiBian_DYaHy_S[0]>>4)*10)+
			(RtuDataAddr->FkInput_Value.F60_Set_Para.All_QiBian_DYaHy_S[0]&0x0f);
		//�������г����ѹ����������
		JiCi_UHanyoulvSX=((RtuDataAddr->FkInput_Value.F60_Set_Para.O_XieBo_DYaHy_S[1]>>4)*10)+
			(RtuDataAddr->FkInput_Value.F60_Set_Para.O_XieBo_DYaHy_S[1]&0x0f);
		JiCi_UHanyoulvSX=(JiCi_UHanyoulvSX*100)+((RtuDataAddr->FkInput_Value.F60_Set_Para.O_XieBo_DYaHy_S[0]>>4)*10)+
			(RtuDataAddr->FkInput_Value.F60_Set_Para.O_XieBo_DYaHy_S[0]&0x0f);
		//����ż��г����ѹ����������
		OuCi_UHanyoulvSX=((RtuDataAddr->FkInput_Value.F60_Set_Para.E_XieBo_DYaHanyou_S[1]>>4)*10)+
			(RtuDataAddr->FkInput_Value.F60_Set_Para.E_XieBo_DYaHanyou_S[1]&0x0f);
		OuCi_UHanyoulvSX=(OuCi_UHanyoulvSX*100)+((RtuDataAddr->FkInput_Value.F60_Set_Para.E_XieBo_DYaHanyou_S[0]>>4)*10)+
			(RtuDataAddr->FkInput_Value.F60_Set_Para.E_XieBo_DYaHanyou_S[0]&0x0f);
		//�����ܻ��������Чֵ����
		ZongJiBian_ISX=(((RtuDataAddr->FkInput_Value.F60_Set_Para.All_QiBian_DLiu_YX_S[1]>>4)&0x07)*10)+
			(RtuDataAddr->FkInput_Value.F60_Set_Para.All_QiBian_DLiu_YX_S[1]&0x0f);
		ZongJiBian_ISX=(ZongJiBian_ISX*100)+((RtuDataAddr->FkInput_Value.F60_Set_Para.All_QiBian_DLiu_YX_S[0]>>4)*10)+
			(RtuDataAddr->FkInput_Value.F60_Set_Para.All_QiBian_DLiu_YX_S[0]&0x0f);
		for(i=2;i<20;i++)
		{//����2--19��г��������Чֵ����
			NCixiebo_ISX[i]=(((RtuDataAddr->FkInput_Value.F60_Set_Para.XIeBo_DL_YX_S[i][1]>>4)&0x07)*10)+
				(RtuDataAddr->FkInput_Value.F60_Set_Para.XIeBo_DL_YX_S[i][1]&0x0f);
			NCixiebo_ISX[i]=(NCixiebo_ISX[i]*100)+((RtuDataAddr->FkInput_Value.F60_Set_Para.XIeBo_DL_YX_S[i][0]>>4)*10)+
				(RtuDataAddr->FkInput_Value.F60_Set_Para.XIeBo_DL_YX_S[i][0]&0x0f);
		}
//��ʼͳ�Ƹ���Խ���ۼ�ʱ��
		if(UA_Zong_Hanyoulv>ZongJiBian_UHanyoulvSX)
		{
			RtuDataAddr->F121_real_Value.ZongJiBian_UCount++;
		}
		if(UB_Zong_Hanyoulv>ZongJiBian_UHanyoulvSX)
		{
			RtuDataAddr->F122_real_Value.ZongJiBian_UCount++;
		}
		if(UC_Zong_Hanyoulv>ZongJiBian_UHanyoulvSX)
		{
			RtuDataAddr->F123_real_Value.ZongJiBian_UCount++;
		}
		for(i=3;i<20;i+=2)
		{
			if(RtuDataAddr->AllXBo.UA_Hanyoulv[i]>JiCi_UHanyoulvSX)
			{
				RtuDataAddr->F121_real_Value.GeCi_UCount[i]++;
			}
			if(RtuDataAddr->AllXBo.UB_Hanyoulv[i]>JiCi_UHanyoulvSX)
			{
				RtuDataAddr->F122_real_Value.GeCi_UCount[i]++;
			}
			if(RtuDataAddr->AllXBo.UC_Hanyoulv[i]>JiCi_UHanyoulvSX)
			{
				RtuDataAddr->F123_real_Value.GeCi_UCount[i]++;
			}
		}
		for(i=2;i<20;i+=2)
		{
			if(RtuDataAddr->AllXBo.UA_Hanyoulv[i]>OuCi_UHanyoulvSX)
			{
				RtuDataAddr->F121_real_Value.GeCi_UCount[i]++;
			}
			if(RtuDataAddr->AllXBo.UB_Hanyoulv[i]>OuCi_UHanyoulvSX)
			{
				RtuDataAddr->F122_real_Value.GeCi_UCount[i]++;
			}
			if(RtuDataAddr->AllXBo.UC_Hanyoulv[i]>OuCi_UHanyoulvSX)
			{
				RtuDataAddr->F123_real_Value.GeCi_UCount[i]++;
			}
		}
		if(IA_Zongjibian>ZongJiBian_ISX)
		{
			RtuDataAddr->F121_real_Value.ZongJiBian_ICount++;
		}
		if(IB_Zongjibian>ZongJiBian_ISX)
		{
			RtuDataAddr->F122_real_Value.ZongJiBian_ICount++;
		}
		if(IC_Zongjibian>ZongJiBian_ISX)
		{
			RtuDataAddr->F123_real_Value.ZongJiBian_ICount++;
		}
		for(i=2;i<20;i++)
		{
			if(RtuDataAddr->AllXBo.IAxb[i]>NCixiebo_ISX[i])
			{
				RtuDataAddr->F121_real_Value.GeCi_ICount[i]++;
			}
			if(RtuDataAddr->AllXBo.IBxb[i]>NCixiebo_ISX[i])
			{
				RtuDataAddr->F122_real_Value.GeCi_ICount[i]++;
			}
			if(RtuDataAddr->AllXBo.ICxb[i]>NCixiebo_ISX[i])
			{
				RtuDataAddr->F123_real_Value.GeCi_ICount[i]++;
			}
		}
	}
}
void XIEBO_MAX_Calc()
{
	INT8U i;
	for(i=2;i<20;i++)
	{
		RtuDataAddr->AllXBo.UA_Hanyoulv[i]=(double)RtuDataAddr->AllXBo.UAxb[i]/(double)RtuDataAddr->AllXBo.UAxb[1]*100;//2--19��A��г����ѹ������
		RtuDataAddr->AllXBo.UB_Hanyoulv[i]=(double)RtuDataAddr->AllXBo.UBxb[i]/(double)RtuDataAddr->AllXBo.UBxb[1]*100;//2--19��B��г����ѹ������
		RtuDataAddr->AllXBo.UC_Hanyoulv[i]=(double)RtuDataAddr->AllXBo.UCxb[i]/(double)RtuDataAddr->AllXBo.UCxb[1]*100;//2--19��C��г����ѹ������
		RtuDataAddr->AllXBo.IA_Hanyoulv[i]=(double)RtuDataAddr->AllXBo.IAxb[i]/(double)RtuDataAddr->AllXBo.IAxb[1]*100;//2--19��A��г������������
		RtuDataAddr->AllXBo.IB_Hanyoulv[i]=(double)RtuDataAddr->AllXBo.IBxb[i]/(double)RtuDataAddr->AllXBo.IBxb[1]*100;//2--19��B��г������������
		RtuDataAddr->AllXBo.IC_Hanyoulv[i]=(double)RtuDataAddr->AllXBo.ICxb[i]/(double)RtuDataAddr->AllXBo.ICxb[1]*100;//2--19��C��г������������

		IA_Zongjibian=IA_Zongjibian+(RtuDataAddr->AllXBo.IAxb[i])*(RtuDataAddr->AllXBo.IAxb[i]);
		IB_Zongjibian=IB_Zongjibian+(RtuDataAddr->AllXBo.IBxb[i])*(RtuDataAddr->AllXBo.IBxb[i]);
		IC_Zongjibian=IC_Zongjibian+(RtuDataAddr->AllXBo.ICxb[i])*(RtuDataAddr->AllXBo.ICxb[i]);

		UA_Zongjibian=UA_Zongjibian+(RtuDataAddr->AllXBo.UAxb[i])*(RtuDataAddr->AllXBo.UAxb[i]);
		UB_Zongjibian=UB_Zongjibian+(RtuDataAddr->AllXBo.UBxb[i])*(RtuDataAddr->AllXBo.UBxb[i]);
		UC_Zongjibian=UC_Zongjibian+(RtuDataAddr->AllXBo.UCxb[i])*(RtuDataAddr->AllXBo.UCxb[i]);
	}
	IA_Zongjibian=IA_Zongjibian/18;
	IA_Zongjibian=sqrt(IA_Zongjibian);//����A���ܻ������
	IB_Zongjibian=IB_Zongjibian/18;
	IB_Zongjibian=sqrt(IB_Zongjibian);//����B���ܻ������
	IC_Zongjibian=IC_Zongjibian/18;
	IC_Zongjibian=sqrt(IC_Zongjibian);//����C���ܻ������

	UA_Zongjibian=UA_Zongjibian/18;
	UA_Zongjibian=sqrt(UA_Zongjibian);
	UA_Zong_Hanyoulv=(double)(UA_Zongjibian)/(double)(RtuDataAddr->AllXBo.UAxb[1])*100;//����A���ܻ����ѹ������
	UB_Zongjibian=UB_Zongjibian/18;
	UB_Zongjibian=sqrt(UB_Zongjibian);
	UB_Zong_Hanyoulv=(double)(UB_Zongjibian)/(double)(RtuDataAddr->AllXBo.UBxb[1])*100;//����B���ܻ����ѹ������
	UC_Zongjibian=UC_Zongjibian/18;
	UC_Zongjibian=sqrt(UC_Zongjibian);
	UC_Zong_Hanyoulv=(double)(UC_Zongjibian)/(double)(RtuDataAddr->AllXBo.UCxb[1])*100;//����B���ܻ����ѹ������
	for(i=2;i<20;i++)
	{
		if(RtuDataAddr->AllXBo.IAxb[i]>RtuDataAddr->IAxb_Max[i])
		{//U��2--19�ε���г�����ֵ������ʱ��
			RtuDataAddr->IAxb_Max[i]=RtuDataAddr->AllXBo.IAxb[i];
			memcpy(&RtuDataAddr->IAxb_Max_Time[i],&xb_Time,sizeof(xb_Time));
		}
		if(RtuDataAddr->AllXBo.IBxb[i]>RtuDataAddr->IBxb_Max[i])
		{//V��2--19�ε���г�����ֵ������ʱ��
			RtuDataAddr->IBxb_Max[i]=RtuDataAddr->AllXBo.IBxb[i];
			memcpy(&RtuDataAddr->IBxb_Max_Time[i],&xb_Time,sizeof(xb_Time));
		}
		if(RtuDataAddr->AllXBo.ICxb[i]>RtuDataAddr->ICxb_Max[i])
		{//W��2--19�ε���г�����ֵ������ʱ��
			RtuDataAddr->ICxb_Max[i]=RtuDataAddr->AllXBo.ICxb[i];
			memcpy(&RtuDataAddr->ICxb_Max_Time[i],&xb_Time,sizeof(xb_Time));
		}
		if(IA_Zongjibian>RtuDataAddr->IA_ZongJiBian_Max)
		{
			RtuDataAddr->IA_ZongJiBian_Max=IA_Zongjibian;
			memcpy(&RtuDataAddr->IA_ZongJiBian_Max_Time,&xb_Time,sizeof(xb_Time));
		}
		if(IB_Zongjibian>RtuDataAddr->IB_ZongJiBian_Max)
		{
			RtuDataAddr->IB_ZongJiBian_Max=IB_Zongjibian;
			memcpy(&RtuDataAddr->IB_ZongJiBian_Max_Time,&xb_Time,sizeof(xb_Time));
		}
		if(IC_Zongjibian>RtuDataAddr->IC_ZongJiBian_Max)
		{
			RtuDataAddr->IC_ZongJiBian_Max=IC_Zongjibian;
			memcpy(&RtuDataAddr->IC_ZongJiBian_Max_Time,&xb_Time,sizeof(xb_Time));
		}
		if(RtuDataAddr->AllXBo.UA_Hanyoulv[i]>RtuDataAddr->UA_Hanyoulv_Max[i])
		{
			RtuDataAddr->UA_Hanyoulv_Max[i]=RtuDataAddr->AllXBo.UA_Hanyoulv[i];
			memcpy(&RtuDataAddr->UA_Hanyoulv_Max_Time[i],&xb_Time,sizeof(xb_Time));
		}
		if(RtuDataAddr->AllXBo.UB_Hanyoulv[i]>RtuDataAddr->UB_Hanyoulv_Max[i])
		{
			RtuDataAddr->UB_Hanyoulv_Max[i]=RtuDataAddr->AllXBo.UB_Hanyoulv[i];
			memcpy(&RtuDataAddr->UB_Hanyoulv_Max_Time[i],&xb_Time,sizeof(xb_Time));
		}
		if(RtuDataAddr->AllXBo.UC_Hanyoulv[i]>RtuDataAddr->UC_Hanyoulv_Max[i])
		{
			RtuDataAddr->UC_Hanyoulv_Max[i]=RtuDataAddr->AllXBo.UC_Hanyoulv[i];
			memcpy(&RtuDataAddr->UC_Hanyoulv_Max_Time[i],&xb_Time,sizeof(xb_Time));
		}
		if(UA_Zong_Hanyoulv>RtuDataAddr->UA_ZongJiBianLv_Max)
		{
			RtuDataAddr->UA_ZongJiBianLv_Max=UA_Zong_Hanyoulv;
			memcpy(&RtuDataAddr->UA_ZongJiBianLv_Max_Time,&xb_Time,sizeof(xb_Time));
		}
		if(UB_Zong_Hanyoulv>RtuDataAddr->UB_ZongJiBianLv_Max)
		{
			RtuDataAddr->UB_ZongJiBianLv_Max=UB_Zong_Hanyoulv;
			memcpy(&RtuDataAddr->UB_ZongJiBianLv_Max_Time,&xb_Time,sizeof(xb_Time));
		}
		if(UC_Zong_Hanyoulv>RtuDataAddr->UC_ZongJiBianLv_Max)
		{
			RtuDataAddr->UC_ZongJiBianLv_Max=UC_Zong_Hanyoulv;
			memcpy(&RtuDataAddr->UC_ZongJiBianLv_Max_Time,&xb_Time,sizeof(xb_Time));
		}
	}
}
void Save_Min15_XieBo()
{
	TS ts;
	TSGet(&ts);
	char name[128];
	memcpy(RtuDataAddr->Min_15_XieBo_Value.IAxb_Max,RtuDataAddr->IAxb_Max,sizeof(INT32U)*20);
	memcpy(RtuDataAddr->Min_15_XieBo_Value.IBxb_Max,RtuDataAddr->IBxb_Max,sizeof(INT32U)*20);
	memcpy(RtuDataAddr->Min_15_XieBo_Value.ICxb_Max,RtuDataAddr->ICxb_Max,sizeof(INT32U)*20);
	memcpy(RtuDataAddr->Min_15_XieBo_Value.IAxb_Max_Time,RtuDataAddr->IAxb_Max_Time,sizeof(RtuDataAddr->IAxb_Max_Time)*20);
	memcpy(RtuDataAddr->Min_15_XieBo_Value.IBxb_Max_Time,RtuDataAddr->IBxb_Max_Time,sizeof(RtuDataAddr->IBxb_Max_Time)*20);
	memcpy(RtuDataAddr->Min_15_XieBo_Value.ICxb_Max_Time,RtuDataAddr->ICxb_Max_Time,sizeof(RtuDataAddr->ICxb_Max_Time)*20);

	memcpy(RtuDataAddr->Min_15_XieBo_Value.UA_Hanyoulv_Max,RtuDataAddr->UA_Hanyoulv_Max,sizeof(RtuDataAddr->UA_Hanyoulv_Max)*20);
	memcpy(RtuDataAddr->Min_15_XieBo_Value.UB_Hanyoulv_Max,RtuDataAddr->UB_Hanyoulv_Max,sizeof(RtuDataAddr->UB_Hanyoulv_Max)*20);
	memcpy(RtuDataAddr->Min_15_XieBo_Value.UC_Hanyoulv_Max,RtuDataAddr->UC_Hanyoulv_Max,sizeof(RtuDataAddr->UC_Hanyoulv_Max)*20);
	memcpy(RtuDataAddr->Min_15_XieBo_Value.UA_Hanyoulv_Max_Time,RtuDataAddr->UA_Hanyoulv_Max_Time,sizeof(RtuDataAddr->UA_Hanyoulv_Max_Time)*20);
	memcpy(RtuDataAddr->Min_15_XieBo_Value.UB_Hanyoulv_Max_Time,RtuDataAddr->UB_Hanyoulv_Max_Time,sizeof(RtuDataAddr->UB_Hanyoulv_Max_Time)*20);
	memcpy(RtuDataAddr->Min_15_XieBo_Value.UC_Hanyoulv_Max_Time,RtuDataAddr->UC_Hanyoulv_Max_Time,sizeof(RtuDataAddr->UC_Hanyoulv_Max_Time)*20);

	memcpy(RtuDataAddr->Min_15_XieBo_Value.U_GeCi_UCount,RtuDataAddr->F121_real_Value.GeCi_UCount,sizeof(RtuDataAddr->F121_real_Value.GeCi_UCount)*20);
	memcpy(RtuDataAddr->Min_15_XieBo_Value.U_GeCi_ICount,RtuDataAddr->F121_real_Value.GeCi_ICount,sizeof(RtuDataAddr->F121_real_Value.GeCi_ICount)*20);
	memcpy(RtuDataAddr->Min_15_XieBo_Value.V_GeCi_UCount,RtuDataAddr->F122_real_Value.GeCi_UCount,sizeof(RtuDataAddr->F122_real_Value.GeCi_UCount)*20);
	memcpy(RtuDataAddr->Min_15_XieBo_Value.V_GeCi_ICount,RtuDataAddr->F122_real_Value.GeCi_ICount,sizeof(RtuDataAddr->F122_real_Value.GeCi_ICount)*20);
	memcpy(RtuDataAddr->Min_15_XieBo_Value.W_GeCi_UCount,RtuDataAddr->F123_real_Value.GeCi_UCount,sizeof(RtuDataAddr->F123_real_Value.GeCi_UCount)*20);
	memcpy(RtuDataAddr->Min_15_XieBo_Value.W_GeCi_ICount,RtuDataAddr->F123_real_Value.GeCi_ICount,sizeof(RtuDataAddr->F123_real_Value.GeCi_ICount)*20);
	RtuDataAddr->Min_15_XieBo_Value.U_ZongJiBian_UCount=RtuDataAddr->F121_real_Value.ZongJiBian_UCount;
	RtuDataAddr->Min_15_XieBo_Value.U_ZongJiBian_ICount=RtuDataAddr->F121_real_Value.ZongJiBian_ICount;
	RtuDataAddr->Min_15_XieBo_Value.V_ZongJiBian_UCount=RtuDataAddr->F122_real_Value.ZongJiBian_UCount;
	RtuDataAddr->Min_15_XieBo_Value.V_ZongJiBian_ICount=RtuDataAddr->F122_real_Value.ZongJiBian_ICount;
	RtuDataAddr->Min_15_XieBo_Value.W_ZongJiBian_UCount=RtuDataAddr->F123_real_Value.ZongJiBian_UCount;
	RtuDataAddr->Min_15_XieBo_Value.W_ZongJiBian_ICount=RtuDataAddr->F123_real_Value.ZongJiBian_ICount;

	RtuDataAddr->Min_15_XieBo_Value.IA_ZongJiBian_Max=RtuDataAddr->IA_ZongJiBian_Max;
	RtuDataAddr->Min_15_XieBo_Value.IB_ZongJiBian_Max=RtuDataAddr->IB_ZongJiBian_Max;
	RtuDataAddr->Min_15_XieBo_Value.IC_ZongJiBian_Max=RtuDataAddr->IC_ZongJiBian_Max;
	memcpy(&RtuDataAddr->Min_15_XieBo_Value.IA_ZongJiBian_Max_Time.BCD01,&RtuDataAddr->IA_ZongJiBian_Max_Time.BCD01,sizeof(RtuDataAddr->IA_ZongJiBian_Max_Time));
	memcpy(&RtuDataAddr->Min_15_XieBo_Value.IB_ZongJiBian_Max_Time.BCD01,&RtuDataAddr->IB_ZongJiBian_Max_Time.BCD01,sizeof(RtuDataAddr->IB_ZongJiBian_Max_Time));
	memcpy(&RtuDataAddr->Min_15_XieBo_Value.IC_ZongJiBian_Max_Time.BCD01,&RtuDataAddr->IC_ZongJiBian_Max_Time.BCD01,sizeof(RtuDataAddr->IC_ZongJiBian_Max_Time));

	RtuDataAddr->Min_15_XieBo_Value.UA_ZongJiBianLv_Max=RtuDataAddr->UA_ZongJiBianLv_Max;
	RtuDataAddr->Min_15_XieBo_Value.UB_ZongJiBianLv_Max=RtuDataAddr->UB_ZongJiBianLv_Max;
	RtuDataAddr->Min_15_XieBo_Value.UC_ZongJiBianLv_Max=RtuDataAddr->UC_ZongJiBianLv_Max;
	memcpy(&RtuDataAddr->Min_15_XieBo_Value.UA_ZongJiBianLv_Max_Time.BCD01,&RtuDataAddr->UA_ZongJiBianLv_Max_Time.BCD01,sizeof(RtuDataAddr->UA_ZongJiBianLv_Max_Time));
	memcpy(&RtuDataAddr->Min_15_XieBo_Value.UB_ZongJiBianLv_Max_Time.BCD01,&RtuDataAddr->UB_ZongJiBianLv_Max_Time.BCD01,sizeof(RtuDataAddr->UB_ZongJiBianLv_Max_Time));
	memcpy(&RtuDataAddr->Min_15_XieBo_Value.UC_ZongJiBianLv_Max_Time.BCD01,&RtuDataAddr->UC_ZongJiBianLv_Max_Time.BCD01,sizeof(RtuDataAddr->UC_ZongJiBianLv_Max_Time));
	RtuDataAddr->Min_15_XieBo_Value.UA_ZongJiBianLv_Max_Time=RtuDataAddr->UA_ZongJiBianLv_Max_Time;
	RtuDataAddr->Min_15_XieBo_Value.UB_ZongJiBianLv_Max_Time=RtuDataAddr->UB_ZongJiBianLv_Max_Time;
	RtuDataAddr->Min_15_XieBo_Value.UC_ZongJiBianLv_Max_Time=RtuDataAddr->UC_ZongJiBianLv_Max_Time;

	sprintf(name,"/nand/save/xb%02d%02d.dat",ts.Month,ts.Day);
	SaveFile((INT8U *)name,&RtuDataAddr->Min_15_XieBo_Value.Valid,sizeof(RtuDataAddr->Min_15_XieBo_Value));
}
void Read_Min15_Xiebo()
{
	char name[128];
	TS ts;
	TSGet(&ts);
	sprintf(name,"/nand/save/xb%02d%02d.dat",ts.Month,ts.Day);
	if(!ReadFile((INT8U *)name,&RtuDataAddr->Min_15_XieBo_Value.Valid,sizeof(RtuDataAddr->Min_15_XieBo_Value)))
	{
		memset(&RtuDataAddr->Min_15_XieBo_Value,0,sizeof(RtuDataAddr->Min_15_XieBo_Value));
	}
}
void Init_XieBo()
{
	RtuDataAddr->IA_ZongJiBian_Max=0;
	RtuDataAddr->IB_ZongJiBian_Max=0;
	RtuDataAddr->IC_ZongJiBian_Max=0;
	RtuDataAddr->UA_ZongJiBianLv_Max=0;
	RtuDataAddr->UB_ZongJiBianLv_Max=0;
	RtuDataAddr->UC_ZongJiBianLv_Max=0;
	memset(RtuDataAddr->IAxb_Max,0,sizeof(RtuDataAddr->IAxb_Max));
	memset(RtuDataAddr->IBxb_Max,0,sizeof(RtuDataAddr->IBxb_Max));
	memset(RtuDataAddr->ICxb_Max,0,sizeof(RtuDataAddr->ICxb_Max));
	memset(RtuDataAddr->UA_Hanyoulv_Max,0,sizeof(RtuDataAddr->UA_Hanyoulv_Max));
	memset(RtuDataAddr->UB_Hanyoulv_Max,0,sizeof(RtuDataAddr->UB_Hanyoulv_Max));
	memset(RtuDataAddr->UC_Hanyoulv_Max,0,sizeof(RtuDataAddr->UC_Hanyoulv_Max));

	memset(RtuDataAddr->IAxb_Max_Time,0,sizeof(RtuDataAddr->IAxb_Max_Time)*20);
	memset(RtuDataAddr->IBxb_Max_Time,0,sizeof(RtuDataAddr->IBxb_Max_Time)*20);
	memset(RtuDataAddr->ICxb_Max_Time,0,sizeof(RtuDataAddr->ICxb_Max_Time)*20);

	memset(&RtuDataAddr->IA_ZongJiBian_Max_Time,0,sizeof(RtuDataAddr->IA_ZongJiBian_Max_Time));
	memset(&RtuDataAddr->IB_ZongJiBian_Max_Time,0,sizeof(RtuDataAddr->IB_ZongJiBian_Max_Time));
	memset(&RtuDataAddr->IC_ZongJiBian_Max_Time,0,sizeof(RtuDataAddr->IC_ZongJiBian_Max_Time));

	memset(RtuDataAddr->UA_Hanyoulv_Max_Time,0,sizeof(RtuDataAddr->UA_Hanyoulv_Max_Time)*20);
	memset(RtuDataAddr->UB_Hanyoulv_Max_Time,0,sizeof(RtuDataAddr->UB_Hanyoulv_Max_Time)*20);
	memset(RtuDataAddr->UC_Hanyoulv_Max_Time,0,sizeof(RtuDataAddr->UC_Hanyoulv_Max_Time)*20);

	memset(&RtuDataAddr->UA_ZongJiBianLv_Max_Time,0,sizeof(RtuDataAddr->UA_ZongJiBianLv_Max_Time));
	memset(&RtuDataAddr->UB_ZongJiBianLv_Max_Time,0,sizeof(RtuDataAddr->UB_ZongJiBianLv_Max_Time));
	memset(&RtuDataAddr->UC_ZongJiBianLv_Max_Time,0,sizeof(RtuDataAddr->UC_ZongJiBianLv_Max_Time));
}
void markver()//��Ŀ������б�ʶ�����汾��Ϣ
{
	printf("\n%s\n", verstr);
}
int main(int argc, char *argv[])
{
    INT32U test;
    INT8U okflag,temp[3],OldMinute;
	TS ts;
	int i=0;
	struct sigaction sa1;
	markver();
    if(OpenMem())
    	return EXIT_FAILURE;
    if(RtuDataAddr->mem_len!=sizeof(RTimeData))
    {
    	return EXIT_FAILURE;
    }
 	if(!PARSE_CMD(argc, argv))
	{
		return EXIT_FAILURE;
	}
 	sa1.sa_handler = QuitProcess;
	sigemptyset(&sa1.sa_mask);
	sa1.sa_flags = 0;
	sigaction(SIGTERM, &sa1,NULL);
	sigaction(SIGSYS, &sa1,NULL);
	sigaction(SIGPWR, &sa1,NULL);
	sigaction(SIGKILL, &sa1,NULL);
	sigaction(SIGQUIT, &sa1,NULL);
	sigaction(SIGILL, &sa1,NULL);
	sigaction(SIGINT, &sa1,NULL);
	sigaction(SIGHUP, &sa1,NULL);
	sigaction(SIGABRT, &sa1,NULL);
	sigaction(SIGBUS, &sa1,NULL);
	RtuDataAddr->stPortPara[PORT_ID].PID=getpid();

	TSGet(&ts);
	OldMinute=ts.Minute;
	Read_Min15_Xiebo();
	Init_XieBo();
	while(1)
	{
		delay(100);
		CleardeadCount();
		TSGet(&ts);
		if(ts.Minute!=OldMinute)
		{
			CleardeadCount();
			xb_Time.BCD01 = ((ts.Minute / 10) << 4) + (ts.Minute % 10);
			xb_Time.BCD02 = ((ts.Hour / 10) << 4) + (ts.Hour % 10);
			xb_Time.BCD03 = ((ts.Day / 10) << 4) + (ts.Day % 10);
			xb_Time.BCD04 = ((ts.Month / 10) << 4) + (ts.Month % 10);

			test=ATTRead(SPI1,0x3e,3,temp,0);//У�����ݼĴ���
			if((test==0x16BC73)||(test==0x043C73))    //У����
				okflag=1;
			if(okflag!=1)
				continue;

			//ATT7022C();  //7022C�ɼ���ѹ����////���ڽ�������ɼ��������д7022c��ͻ

			//Ƶ�ʲ��ֵĴ���//
			test = REC[0x1C]*100/8192;
			if( (test>5600)||(test<4400) )   //45hz --- 55hz֮��
				HZall.HZBuff[HZall.HZpoint]  = 5000;
		    else
		        HZall.HZBuff[HZall.HZpoint]  = test;
		    HZall.HZpoint = (HZall.HZpoint + 1) & 0xf;

		    delay(200);
		    REC[0x1C]=ATTRead(SPI1,0x1C,3,temp,0);

		    test = REC[0x1C]*100/8192;
			if( (test>5600)||(test<4400) )   //45hz --- 55hz֮��
				HZall.HZBuff[HZall.HZpoint]  = 5000;
		    else
		        HZall.HZBuff[HZall.HZpoint]  = test;

			RtuDataAddr->RES.RES_F = XBhz(HZall.HZBuff,HZall.HZBuff[HZall.HZpoint]); //Ƶ��
		    HZall.HZpoint = (HZall.HZpoint + 1) & 0xf;
			//END Ƶ��//

		    //--------------��ʼ����FFT�任------------------
		    ffttest(RtuDataAddr->XBpoint.ua,RtuDataAddr->AllXBo.UAxb);//����A��2-19��г����ѹ
		    ffttest(RtuDataAddr->XBpoint.ub,RtuDataAddr->AllXBo.UBxb);//����B��2-19��г����ѹ
		    ffttest(RtuDataAddr->XBpoint.uc,RtuDataAddr->AllXBo.UCxb);//����C��2-19��г����ѹ
		    ffttest(RtuDataAddr->XBpoint.ia,RtuDataAddr->AllXBo.IAxb);//����A��2-19��г������
		    ffttest(RtuDataAddr->XBpoint.ib,RtuDataAddr->AllXBo.IBxb);//����B��2-19��г������
		    ffttest(RtuDataAddr->XBpoint.ic,RtuDataAddr->AllXBo.ICxb);//����C��2-19��г������

		    DBXieboPr(stderr,"\n\r-----------------------xiebo start");
		    for(i=0;i<20;i++){
		    	CleardeadCount();
			    DBXieboPr(stderr,"\n\rRtuDataAddr->AllXBo.UAxb[%d]=%d",i,RtuDataAddr->AllXBo.UAxb[i]);
			    DBXieboPr(stderr,"\n\rRtuDataAddr->AllXBo.UBxb[%d]=%d",i,RtuDataAddr->AllXBo.UBxb[i]);
			    DBXieboPr(stderr,"\n\rRtuDataAddr->AllXBo.UCxb[%d]=%d",i,RtuDataAddr->AllXBo.UCxb[i]);
		    }
		    DBXieboPr(stderr,"\n\r-----------------------xiebo end");

		    XIEBO_MAX_Calc();//г�����ֵ������ʱ�����
		    XIEBO_YUEXIAN_Calc();//г��Խ��ͳ�Ƽ���
			RtuDataAddr->AllXBo.Valid=1;
			OldMinute=ts.Minute;
			if(OldMinute%15==0)
			{
				//ͳ��ֵ����ֵ������ʱ�䱣�浽ÿ�յ���ʱ�ļ���   ����xb0224.dat
				Save_Min15_XieBo();
			}
		}
	}
	return EXIT_SUCCESS;
}
