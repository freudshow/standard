/*
 * fkxiebo.h
 *
 *  Created on: 2010-2-21
 *      Author: www
 */

#ifndef FKXIEBO_H_
#define FKXIEBO_H_
#define DBXieboPr if(RtuDataAddr->XIEBOPRT)fprintf
int device = 0;
unsigned char cmd[1024];
name_attach_t       *attach;
RTimeData           *RtuDataAddr;//�ڴ湲��������ָ��
INT8U       PORT_ID;

int fp = -1;

#endif /* FKXIEBO_H_ */
