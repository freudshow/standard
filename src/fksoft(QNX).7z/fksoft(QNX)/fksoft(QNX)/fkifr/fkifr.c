
#include "ifr.h"
extern int write_apn();
#define AT91C_PIO_PB16        (1 <<  16) // Pin Controlled by PA27  //�װ忪�ص�Դ���
const char verstr[]={"VER-STRING-FLG=006.002.217.004"__DATE__" "__TIME__};
//-----------------------------------------------------------------------------------
//��¼�װ�ͣ��
void SetPowerOff2file(int flag)
{
	FILE *fp;
	fp = NULL;
	fp = fopen("/user/poweroff.inf","w+");
	if (fp!=NULL)
	{
		fprintf(fp,"poweroff=%d",flag);//�װ��Դ poweroff=1 ��ʾ����ǰ�װ�ͣ��    poweroff=0��ʾ����ǰ�װ�ûͣ��
		fclose(fp);
	}
}
int GetPowerOffFile()
{
	char strtmp[50];
	FILE *fp;
	int flag=1;
	fp = NULL;
	fp = fopen("/user/poweroff.inf","r");
	if (fp!=NULL)
	{
		memset(strtmp,0,50);
		fgets(strtmp,50,fp);
		sscanf(strtmp,"poweroff=%d",&flag);//�װ��Դ poweroff=1 ��ʾ����ǰ�װ�ͣ��    poweroff=0��ʾ����ǰ�װ�ûͣ��
		fclose(fp);
	}
	return flag;
}

//---------------ͣ�ϵ��ж�-----------------------------------------------------------
void setboardpowerio()
{
	out32(port2,AT91C_PIO_PB16);     //���װ��ԴIOʹ��
	out32(port2+0x20,AT91C_PIO_PB16);//����ֻ��
}
void CreateErr14(INT8U Flag)
{
	if (Flag==1)
		fprintf(stderr,"\n\rTingDian in CreateErr14");
	else
		fprintf(stderr,"\n\rShangDian in CreateErr14");
	//if (Flag==1)//�ϵ�
	{//��¼ͣ�ϵ��¼�
		if((RtuDataAddr->Fm_Save_Eve.TdTime[0]!=0)&&(RtuDataAddr->Fm_Save_Eve.TdTime[1]!=0)&&(RtuDataAddr->Fm_Save_Eve.TdTime[2]!=0)&&(RtuDataAddr->Fm_Save_Eve.TdTime[3]!=0))
		{
			//printf("\n\r RtuDataAddr->Fm_Save_Eve.TdTime[0]  [1]  [2]  [3] %02x %02x %02x %02x",RtuDataAddr->Fm_Save_Eve.TdTime[0],RtuDataAddr->Fm_Save_Eve.TdTime[1],RtuDataAddr->Fm_Save_Eve.TdTime[2],RtuDataAddr->Fm_Save_Eve.TdTime[3]);
			memcpy(&RtuDataAddr->Event_Save.Event.Err14.Ting_Time.BCD01, RtuDataAddr->Fm_Save_Eve.TdTime, 5);
			memcpy(&RtuDataAddr->Event_Save.Event.Err14.Shang_Time.BCD01, RtuDataAddr->Fm_Save_Eve.SdTime, 5);
			RtuDataAddr->Event_Save.Event.Err14.ERCNo = 14;
			RtuDataAddr->Event_Save.Event.Err14.len = 10;
			RtuDataAddr->Event_Save.UseFlag = 0;
			RtuDataAddr->ERCBiaoZhi[1] = 0x20;
			if (RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[1] & 0x20)//��Ҫ�¼�
			{
				memcpy(&RtuDataAddr->M_Event_Save[RtuDataAddr->Fm_Save_Eve.EC1].UseFlag, &RtuDataAddr->Event_Save.UseFlag, sizeof(RtuDataAddr->Event_Save));
				RtuDataAddr->Fm_Save_Eve.EC1 = (RtuDataAddr->Fm_Save_Eve.EC1 + 1)%256;
				RtuDataAddr->EC1 = RtuDataAddr->Fm_Save_Eve.EC1;
				Fm25cl64_Write(&RtuDataAddr->Fm_Save_Eve.EC1, sizeof(RtuDataAddr->Fm_Save_Eve), Fm_Save_Eve_Offset);
				SaveFile((INT8U *) "/nand/save/Merc1.dat", &RtuDataAddr->M_Event_Save[0].UseFlag, sizeof(RtuDataAddr->M_Event_Save));
			}
			else//һ���¼�
			{
				memcpy(&RtuDataAddr->S_Event_Save[RtuDataAddr->Fm_Save_Eve.EC2].UseFlag, &RtuDataAddr->Event_Save.UseFlag, sizeof(RtuDataAddr->Event_Save));
				RtuDataAddr->Fm_Save_Eve.EC2 = (RtuDataAddr->Fm_Save_Eve.EC2 + 1)%256;
				RtuDataAddr->EC2 = RtuDataAddr->Fm_Save_Eve.EC2;
				Fm25cl64_Write(&RtuDataAddr->Fm_Save_Eve.EC2, sizeof(RtuDataAddr->Fm_Save_Eve), Fm_Save_Eve_Offset);
				SaveFile((INT8U *) "/nand/save/Serc1.dat", &RtuDataAddr->S_Event_Save[0].UseFlag, sizeof(RtuDataAddr->S_Event_Save));
			}
		}
	}
}
void JugePowerEvent(TS ts)
{
	if(((in32(port2+0x3c)>>16)&0x01)==0)//ͣ��
		RtuDataAddr->batflag = 1;
	else
		RtuDataAddr->batflag = 0;
	//fprintf(stderr,"\n\rRtuDataAddr->batflag===%d ",RtuDataAddr->batflag);
	//fprintf(stderr,"\n\rRtuDataAddr->BoardElecState===%d ",RtuDataAddr->BoardElecState);
	if (RtuDataAddr->batflag != RtuDataAddr->BoardElecState)
	{
		//fprintf(stderr,"\n\r----in JugePowerEvent batflag=%d  BoardElecState=%d",RtuDataAddr->batflag,RtuDataAddr->BoardElecState);
		RtuDataAddr->BoardElecState = RtuDataAddr->batflag;
		if (RtuDataAddr->batflag == 1)
		{
			//ͣ���¼�
				SetPowerOff2file(1);//�ն˵װ�ͣ���¼���ļ�
				fprintf(stderr,"\n\r\n\r\n\r\n\r\n\r tingdian!");
				RtuDataAddr->PowerOFFMessage = 1;
				RtuDataAddr->PowerOnMessage = 0;
				RtuDataAddr->Fm_Save_Eve.TdTime[0] = ((ts.Minute / 10) << 4) + (ts.Minute % 10);
				RtuDataAddr->Fm_Save_Eve.TdTime[1] = ((ts.Hour / 10) << 4) + (ts.Hour % 10);
				RtuDataAddr->Fm_Save_Eve.TdTime[2] = ((ts.Day / 10) << 4) + (ts.Day % 10);
				RtuDataAddr->Fm_Save_Eve.TdTime[3] = ((ts.Month / 10) << 4) + (ts.Month % 10);
				RtuDataAddr->Fm_Save_Eve.TdTime[4] = (((ts.Year % 100) / 10) << 4) + (ts.Year % 10);
				CreateErr14(1);
		}else
		{
			//�ϵ��¼�
				SetPowerOff2file(0);//�ն˵װ��ϵ��¼���ļ�
				fprintf(stderr,"\n\r\n\r\n\r\n\r\n\r shangdian!");
				RtuDataAddr->PowerOnMessage = 1;
				RtuDataAddr->PowerOFFMessage = 0;
				RtuDataAddr->Fm_Save_Eve.SdTime[0] = ((ts.Minute / 10) << 4) + (ts.Minute % 10);
				RtuDataAddr->Fm_Save_Eve.SdTime[1] = ((ts.Hour / 10) << 4) + (ts.Hour % 10);
				RtuDataAddr->Fm_Save_Eve.SdTime[2] = ((ts.Day / 10) << 4) + (ts.Day % 10);
				RtuDataAddr->Fm_Save_Eve.SdTime[3] = ((ts.Month / 10) << 4) + (ts.Month % 10);
				RtuDataAddr->Fm_Save_Eve.SdTime[4] = (((ts.Year % 100) / 10) << 4) + (ts.Year % 10);
				if (RtuDataAddr->Event_Value.F9_Set_Para.Valid == 1)
					CreateErr14(0);
		}
	}
}
//---------------------------------------------------------------------------
void SendStrToifr(unsigned char *str,unsigned short Len)
{   int size,i;
	CleardeadCount();
	//printf("\r\n send data=");
    for(i=0;i<Len;i++)
    {
    	IfrDebugOut("%x ",str[i]);
    }
	size=write(ComPort,str,Len);
	//printf("\n\rsize=%d",size);
    if(size<Len)
    	IfrDebugOut("send data failure!! size=%d \n\r",size);
    else
    	IfrDebugOut("\n\r send data success!!size=%d \n\r",size);
 	delay(500);
}
unsigned char ReceiveFromifr(unsigned char *str)
{
	unsigned char i;
	unsigned short pos = 0;
	int len;
	unsigned char TmpBuf[256];
	i=0;
	while(1)
	{
		delay(50);
		len = read(ComPort,TmpBuf,200);
		IfrDebugOut("\n\rReceiveFromifr len ==%d",len);
		if(len<=0)
			break;
		else
		{
			//SetSpiLed(SET_LED);//xin jia shang de
			//IfrDebugOut("\n Receive data length = %d\n\r",len);
		}
		for(i=0;i<len;i++)
		{
			str[pos]=TmpBuf[i];
			pos=(pos+1)%IFRBUF_MAX;
			ifrRecHead=(ifrRecHead+1)%IFRBUF_MAX;
			IfrDebugOut("%x ",TmpBuf[i]);
		}
		delay(300);
	}
	return pos;
}
unsigned char CheckSumifr(unsigned char *buf,INT16U len)
{
	INT16U i;
	unsigned char ret=0;
	for(i=0;i<len;i++)
	{
		ret=ret+buf[i];
	}
	return ret;
}
void IfrHeadCreate(unsigned char PRM)
{
	IfrSned=0;
	memset(TrnifrBuff,0,IFRBUF_MAX);
	TrnifrBuff[IfrSned++]=0x68;
	TrnifrBuff[IfrSned++]=0;
	TrnifrBuff[IfrSned++]=0;
	TrnifrBuff[IfrSned++]=0;
	TrnifrBuff[IfrSned++]=0;
	TrnifrBuff[IfrSned++]=0x68;
	TrnifrBuff[IfrSned++]=PRM;
	TrnifrBuff[IfrSned++]=Asdu130Addr[2];
	TrnifrBuff[IfrSned++]=Asdu130Addr[3];
}
void IfrTailCreate_Send()
{
	unsigned int temp;
	temp=IfrSned;
	temp=temp-6;
	TrnifrBuff[1]=temp&0xff;
	TrnifrBuff[2]=(temp>>8)&0xff;
	TrnifrBuff[3]=temp&0xff;
	TrnifrBuff[4]=(temp>>8)&0xff;
	TrnifrBuff[IfrSned]=CheckSumifr(&TrnifrBuff[6],IfrSned-6);
	IfrSned++;
	TrnifrBuff[IfrSned++]=0x16;
	SendStrToifr(TrnifrBuff,IfrSned);
}
void SendACK(unsigned char Flag)
{
	unsigned int tmpsend,temp,i;
	tmpsend=0;
	memset(TrnifrBuff,0,IFRBUF_MAX);
	TrnifrBuff[tmpsend++]=0x68;
	TrnifrBuff[tmpsend++]=0;
	TrnifrBuff[tmpsend++]=0;
	TrnifrBuff[tmpsend++]=0;
	TrnifrBuff[tmpsend++]=0;
	TrnifrBuff[tmpsend++]=0x68;
	TrnifrBuff[tmpsend++]=0x80;
	TrnifrBuff[tmpsend++]=Asdu130Addr[2];
	TrnifrBuff[tmpsend++]=Asdu130Addr[3];
	TrnifrBuff[tmpsend++]=0;//afn
	TrnifrBuff[tmpsend++]=0;//Tmp130Buff[14];//da1
	TrnifrBuff[tmpsend++]=Flag;//Tmp130Buff[15];//da2
	temp=tmpsend;
	for(i=0;i<temp;i++)
		printf("%x",TrnifrBuff[i]);
	temp=temp-6;
	TrnifrBuff[1]=temp&0xff;
	TrnifrBuff[2]=(temp>>8)&0xff;
	TrnifrBuff[3]=temp&0xff;
	TrnifrBuff[4]=(temp>>8)&0xff;
	TrnifrBuff[tmpsend]=CheckSumifr(&TrnifrBuff[6],tmpsend-6);
	tmpsend++;
	TrnifrBuff[tmpsend++]=0x16;
	SendStrToifr(TrnifrBuff,tmpsend);
}
INT8U SetDa1(INT8U Value)
{
	INT8U Result=1;
	if(Value==0)return 0;
	Value=Value-1;
	Result=Result<<(Value%8);
	return Result;
}
INT8U SetDa2(INT8U Value)
{
	INT8U Result=1;
	if(Value==0)return 0;
	Value=Value-1;
	Result=Result<<(Value/8);
	return Result;
}
INT8U SetDt1(INT8U Value)
{
	INT8U Result=1;
	Value=Value-1;
	Result=Result<<(Value%8);
	return Result;
}

INT8U SetDt2(INT8U Value)
{
	Value=Value-1;
	return Value/8;
}
void FrameHeadCreate(INT8U PRM)
{
	SendLen=0;
	memset(SendBuff,0,FrameSize);
	SendBuff[SendLen++]=0x68;
	SendBuff[SendLen++]=0;
	SendBuff[SendLen++]=0;
	SendBuff[SendLen++]=0;
	SendBuff[SendLen++]=0;
	SendBuff[SendLen++]=0x68;
	SendBuff[SendLen++]=PRM;
	SendBuff[SendLen++]=Asdu130Addr[0];
	SendBuff[SendLen++]=Asdu130Addr[1];
	SendBuff[SendLen++]=Asdu130Addr[2];
	SendBuff[SendLen++]=Asdu130Addr[3];
	SendBuff[SendLen++]=Asdu130Addr[4];
}
INT8U CheckSum130(INT8U *buf,INT16U len)
{
	INT16U i;
	INT8U ret=0;
	for(i=0;i<len;i++)
	{
		ret=ret+buf[i];
	}
	return ret;
}
void FrameTailCreate_Send()
{
	INT16U temp,i;
	temp=SendLen;
	temp=temp-6;
	temp=(temp<<2)|1;
	SendBuff[1]=temp&0xff;
	SendBuff[2]=(temp>>8)&0xff;
	SendBuff[3]=temp&0xff;
	SendBuff[4]=(temp>>8)&0xff;
	SendBuff[SendLen]=CheckSum130(&SendBuff[6],SendLen-6);
	SendLen++;
	SendBuff[SendLen++]=0x16;
	fprintf(DebugComm,"\r\n��Լ����");
	for(i=0;i<SendLen;i++)
	{
		fprintf(DebugComm," %x",SendBuff[i]);
	}
	if((Tmp130Buff[6]&0x0f)!=4)
	//FrameSend(SendLen);//����ʱȥ�������е��ԡ�
	seq++;
}
void EC()
{
	if(EC1old!=EC1)
	{
		SendBuff[6]=SendBuff[6]|0x20;
		SendBuff[SendLen++]=EC1;
		SendBuff[SendLen++]=EC2;
	}
	else
	{
		SendBuff[6]=SendBuff[6]&0xdf;
	}

}
void TP()
{
	TS ts;
	TSGet(&ts);
	if(NeedTp)
	{
		SendBuff[13]=SendBuff[13]|0x80;
		memcpy(&SendBuff[SendLen],TpBuff,6);
		SendLen=SendLen+6;
	}
	else
	{
		SendBuff[13]=SendBuff[13]&0x7f;
/*		SendBuff[13]=SendBuff[13]|0x80;
		SendBuff[SendLen++]=seq;
		SendBuff[SendLen++]=(ts.Sec/10)*16+(ts.Sec%10);
		SendBuff[SendLen++]=(ts.Minute/10)*16+(ts.Minute%10);
		SendBuff[SendLen++]=(ts.Hour/10)*16+(ts.Hour%10);
		SendBuff[SendLen++]=(ts.Day/10)*16+(ts.Day%10);
		SendBuff[SendLen++]=RtuDataAddr->FkComm_Value.F1_Set_Para.QiDong_FaSong_Yanshi;
*/	}

}
void SendNAK(INT8U F,INT8U P,INT8U AFN)
{
	fprintf(DebugComm,"\r\nSending NAK");
	FrameHeadCreate(0x89);
	SendBuff[SendLen++]=0x00;//afn
	SendBuff[SendLen++]=0x60|(seq&0x0f);//seq
	SendBuff[SendLen++]=0;//Tmp130Buff[14];//da1e
	SendBuff[SendLen++]=0;//Tmp130Buff[15];//da2
	SendBuff[SendLen++]=4;//Tmp130Buff[16];//dt1
	SendBuff[SendLen++]=0;//Tmp130Buff[17];//dt2
	SendBuff[SendLen++]=AFN;//��������
	SendBuff[SendLen++]=SetDa1(P);//Tmp130Buff[14];//da1e
	SendBuff[SendLen++]=SetDa2(P);//Tmp130Buff[15];//da2
	SendBuff[SendLen++]=SetDt1(F);//Tmp130Buff[16];//dt1
	SendBuff[SendLen++]=SetDt2(F);//Tmp130Buff[17];//dt2
	SendBuff[SendLen++]=1;
	EC();
	TP();
	FrameTailCreate_Send();
}
void SetF1(unsigned char Set,unsigned char F,unsigned char P)
{
	if(Set==1)//��վ��������
	{
		RtuDataAddr->FkComm_Value.F1_Set_Para.Valid=1;
		RtuDataAddr->FkComm_Value.F1_Set_Para.Heart_Beat=TmpifrBuff[17];
		Save_CommSet();
		SetChanged[1]=1;
		SendACK(1);
		return;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->FkComm_Value.F1_Set_Para.Valid==1)
		{
			IfrHeadCreate(0x80);
			TrnifrBuff[IfrSned++]=0x0a;//AFN
			TrnifrBuff[IfrSned++]=0x01;//F
			TrnifrBuff[IfrSned++]=0x00;//p
			IfrSned=IfrSned+5;
			TrnifrBuff[IfrSned++]=RtuDataAddr->FkComm_Value.F1_Set_Para.Heart_Beat;
			//memcpy(&TrnifrBuff[IfrSned],&RtuDataAddr->FkComm_Value.F1_Set_Para.RTS_Time,sizeof(RtuDataAddr->FkComm_Value.F1_Set_Para)-1);
			//IfrSned=IfrSned+sizeof(RtuDataAddr->FkComm_Value.F1_Set_Para)-1;
			IfrTailCreate_Send();
		}
		//else
		{
			//SendACK(2);
		}
		//ClearSpiLed(SET_LED);//xin jia shang de
		return;
	}
}
void SetF3(INT8U Set,INT8U F,INT8U P)
{
	if(Set==1)//��վ��������
	{
		RtuDataAddr->FkComm_Value.F3_Set_Para.Valid=1;
		memcpy(&RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[0],&TmpifrBuff[12],6);
		memcpy(&RtuDataAddr->FkComm_Value.F3_Set_Para.APN[0],&TmpifrBuff[36],16);
		write_apn();
		Save_CommSet();
		SetChanged[3]=1;
		SendACK(1);
		return;
	}
	if(Set==0)//��ȡ���ñ���
	{

		//if(RtuDataAddr->FkComm_Value.F3_Set_Para.Valid==1)
		{
			IfrHeadCreate(0x80);
			TrnifrBuff[IfrSned++]=0x0a;
			TrnifrBuff[IfrSned++]=0x03;
			TrnifrBuff[IfrSned++]=0x00;
			//memcpy(&TrnifrBuff[IfrSned],&RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[0],sizeof(RtuDataAddr->FkComm_Value.F3_Set_Para)-1);
			//IfrSned=IfrSned+sizeof(RtuDataAddr->FkComm_Value.F3_Set_Para)-1;
			memcpy(&TrnifrBuff[IfrSned],&RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[0],6);
			IfrSned=IfrSned+6;
			IfrSned=IfrSned+18;
			memcpy(&TrnifrBuff[IfrSned],&RtuDataAddr->FkComm_Value.F3_Set_Para.APN[0],16);
			IfrSned=IfrSned+16;
			IfrTailCreate_Send();
		}
		//else
		{
		//	SendACK(2);
		}
		return;
	}
}
void SetF4(INT8U Set,INT8U F,INT8U P)
{
	if(Set==1)//��վ��������
	{
		RtuDataAddr->FkComm_Value.F4_Set_Para.Valid=1;
		memcpy(&RtuDataAddr->FkComm_Value.F4_Set_Para.Zhuzhan_tel[0],&TmpifrBuff[12],sizeof(RtuDataAddr->FkComm_Value.F4_Set_Para)-1);
		Save_CommSet();
		SetChanged[4]=1;
		SendACK(1);

		return;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->FkComm_Value.F4_Set_Para.Valid==1)
		{
			IfrHeadCreate(0x80);
			TrnifrBuff[IfrSned++]=0x0a;
			TrnifrBuff[IfrSned++]=0x04;
			TrnifrBuff[IfrSned++]=0x00;
			memcpy(&TrnifrBuff[IfrSned],&RtuDataAddr->FkComm_Value.F4_Set_Para.Zhuzhan_tel[0],sizeof(RtuDataAddr->FkComm_Value.F4_Set_Para)-1);
			IfrSned=IfrSned+sizeof(RtuDataAddr->FkComm_Value.F4_Set_Para)-1;
			IfrTailCreate_Send();
		}
		//else
		{
		//	SendACK(2);
		}
		return;
	}
}
void SetF9(INT8U Set,INT8U F,INT8U P)
{
	if(Set==1)//��վ��������
	{
		RtuDataAddr->Event_Value.F9_Set_Para.Valid=1;
		memcpy(&RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[0],&TmpifrBuff[12],sizeof(RtuDataAddr->Event_Value.F9_Set_Para)-1);
		Save_Event_Set();
		SetChanged[9]=1;
		SendACK(1);
		return;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)
		{
			IfrHeadCreate(0x80);
			TrnifrBuff[IfrSned++]=0x0a;
			TrnifrBuff[IfrSned++]=0x09;
			TrnifrBuff[IfrSned++]=0x00;
			memcpy(&TrnifrBuff[IfrSned],&RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[0],sizeof(RtuDataAddr->Event_Value.F9_Set_Para)-1);
			IfrSned=IfrSned+sizeof(RtuDataAddr->Event_Value.F9_Set_Para)-1;
			IfrTailCreate_Send();
		}
		//else
		{
		//	SendACK(2);
		}
		return;
	}
}
void SetF10(INT8U Set,INT8U F,INT8U P)
{
	INT16U Num,i,j;
	if(Set==1)//��վ��������
	{
		Num=TmpifrBuff[12];
		if(Num>DD_Device_Max)
		{
			goto errorr;
		}
		RtuDataAddr->FkInput_Value.F10_Set_Para.Valid=1;
		RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num=Num;
		j=1;
		if(TmpifrBuff[12+j]>DD_Device_Max)goto errorr;
		RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[TmpifrBuff[13+j]-1].No=TmpifrBuff[12+j];
		RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[TmpifrBuff[13+j]-1].CeLiangNo=TmpifrBuff[13+j];
		memcpy(&RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[TmpifrBuff[13+j]-1].BaudAndPort,&TmpifrBuff[14+j],14);

		j=0;
		for(i=0;i<DD_Device_Max;i++)
		{
			if((RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].CeLiangNo>=1)
			&&(RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].CeLiangNo<=DD_Device_Max))
			{
				j++;
			}
		}
		RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num=j;
		Save_Input_Set();
		SetChanged[10]=1;
		SendACK(1);
		return ;

errorr:
RtuDataAddr->FkInput_Value.F10_Set_Para.Valid=0;
		return ;
	}
	if(Set==0)//��ȡ���ñ���
	{
		IfrHeadCreate(0x80);
		TrnifrBuff[IfrSned++]=0x0a;
		TrnifrBuff[IfrSned++]=0x0a;
		TrnifrBuff[IfrSned++]=P;
		TrnifrBuff[IfrSned++]=RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num;
		TrnifrBuff[IfrSned++]=RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[P-1].No;
		TrnifrBuff[IfrSned++]=RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[P-1].CeLiangNo;
		memcpy(&TrnifrBuff[IfrSned],&RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[P-1].BaudAndPort,14);
		IfrSned=IfrSned+14;
		IfrTailCreate_Send();
		return ;
	}
}
void SetF14(INT8U Set,INT8U F,INT8U P)
{

	INT8U i,k,l,m;
	if(Set==1)//��վ��������
	{
		if(TmpifrBuff[12]>ZongJia_Max)goto e;
		RtuDataAddr->ZongJia_Value.F14_Set_Para.Valid=1;
		RtuDataAddr->ZongJia_Value.F14_Set_Para.Zongjia_Num=TmpifrBuff[12];
		k=1;
		for(i=0;i<RtuDataAddr->ZongJia_Value.F14_Set_Para.Zongjia_Num;i++)
		{
			m=TmpifrBuff[12+k];
			RtuDataAddr->ZongJia_Value.F14_Set_Para.Zj_set[m-1].ZjNo=TmpifrBuff[12+k];
			k++;
			RtuDataAddr->ZongJia_Value.F14_Set_Para.Zj_set[m-1].CeLiangNum=TmpifrBuff[12+k];
			k++;
			for(l=0;l<RtuDataAddr->ZongJia_Value.F14_Set_Para.Zj_set[m-1].CeLiangNum;l++)
			{
				RtuDataAddr->ZongJia_Value.F14_Set_Para.Zj_set[m-1].Stat[l]=TmpifrBuff[12+k];
				k++;
				if((RtuDataAddr->ZongJia_Value.F14_Set_Para.Zj_set[m-1].Stat[l]&0x3f)>CeLiangPoint_Max)
				{
					RtuDataAddr->ZongJia_Value.F14_Set_Para.Valid=0;
					goto e;
				}
			}
		}
		l=0;
		for(i=0;i<ZongJia_Max;i++)
		{
			if((RtuDataAddr->ZongJia_Value.F14_Set_Para.Zj_set[i].ZjNo>0)&&(RtuDataAddr->ZongJia_Value.F14_Set_Para.Zj_set[i].ZjNo<=ZongJia_Max))
			{
				l++;
			}
		}
		RtuDataAddr->ZongJia_Value.F14_Set_Para.Zongjia_Num=l;
		Save_Zongjia_Set();

		SetChanged[14]=1;
		SendACK(1);
		return ;
e:
		RtuDataAddr->ZongJia_Value.F14_Set_Para.Valid=0;
		k=1;
		return ;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->ZongJia_Value.F14_Set_Para.Valid==1)
		{
			IfrHeadCreate(0x80);
			TrnifrBuff[IfrSned++]=0x0a;
			TrnifrBuff[IfrSned++]=0x14;
			TrnifrBuff[IfrSned++]=0x00;

			TrnifrBuff[IfrSned++]=RtuDataAddr->ZongJia_Value.F14_Set_Para.Zongjia_Num;
			for(i=0;i<RtuDataAddr->ZongJia_Value.F14_Set_Para.Zongjia_Num;i++)
			{
				TrnifrBuff[IfrSned++]=RtuDataAddr->ZongJia_Value.F14_Set_Para.Zj_set[i].ZjNo;
				TrnifrBuff[IfrSned++]=RtuDataAddr->ZongJia_Value.F14_Set_Para.Zj_set[i].CeLiangNum;
				for(l=0;l<RtuDataAddr->ZongJia_Value.F14_Set_Para.Zj_set[i].CeLiangNum;l++)
				{
					TrnifrBuff[IfrSned++]=RtuDataAddr->ZongJia_Value.F14_Set_Para.Zj_set[i].Stat[l];
				}
			}

			IfrTailCreate_Send();
		}
		//else
		{
		//	SendACK(2);
		}
		return ;
	}

}
void SetF11(INT8U Set,INT8U F,INT8U P)
{
	INT8U Num,i,j;
	INT8U AFN;
	if(Set==1)//��վ��������
	{
		AFN=TmpifrBuff[9];
		RtuDataAddr->FkComm_Value.F11_Set_Para.Valid=0;
		Num=TmpifrBuff[12];
		if(Num>MaiChong_Max)
		{
			goto errorr;
		}
		RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong_Num=Num;
		j=1;
		for(i=0;i<Num;i++)
		{
			memcpy(&RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong[i].InputNo,&TmpifrBuff[12+j],sizeof(RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong[i]));
			if(RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong[i].CeLiangNo>CeLiangPoint_Max)
			{
				goto errorr;
			}
			j=j+5;
		}
		RtuDataAddr->FkComm_Value.F11_Set_Para.Valid=1;
#if maichong
		memcpy(&RtuDataAddr->MaiCongSetPara.Valid,&RtuDataAddr->FkComm_Value.F11_Set_Para.Valid,sizeof(RtuDataAddr->MaiCongSetPara));
#endif
		Save_CommSet();
		SetChanged[11]=1;
		SendACK(1);//����ȷ��
		return ;
errorr:
		RtuDataAddr->FkComm_Value.F11_Set_Para.Valid=0;
		SendNAK(F,P,AFN);//���ͷ���
		return ;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->FkComm_Value.F11_Set_Para.Valid==1)
		{
			IfrHeadCreate(0x80);
			TrnifrBuff[IfrSned++]=0x0a;
			TrnifrBuff[IfrSned++]=11;
			TrnifrBuff[IfrSned++]=0x00;
			SendBuff[SendLen++]=RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong_Num;
			for(i=0;i<RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong_Num;i++)
			{
				memcpy(&TrnifrBuff[IfrSned],&RtuDataAddr->FkComm_Value.F11_Set_Para.MaiChong[i].InputNo,5);
				IfrSned=IfrSned+5;
			}
			IfrTailCreate_Send();
		}
		//else
		{
		//	SendACK(2);
		}
		return ;
	}
}
void SetF12(INT8U Set,INT8U F,INT8U P)
{
	if(Set==1)//��վ��������
	{
		RtuDataAddr->FkInput_Value.F12_Set_Para.Valid=1;
		memcpy(&RtuDataAddr->FkInput_Value.F12_Set_Para.YxIn,&TmpifrBuff[12],2);
		Save_CommSet();
		SetChanged[12]=1;
		SendACK(1);
		return;
	}
	if(Set==0)//��ȡ���ñ���
	{

		//if(RtuDataAddr->FkInput_Value.F12_Set_Para.Valid==1)
		{
			IfrHeadCreate(0x80);
			TrnifrBuff[IfrSned++]=0x0a;
			TrnifrBuff[IfrSned++]=12;
			TrnifrBuff[IfrSned++]=0x00;
			memcpy(&TrnifrBuff[IfrSned],&RtuDataAddr->FkInput_Value.F12_Set_Para.YxIn,2);
			IfrSned=IfrSned+2;
			IfrTailCreate_Send();
		}
		//else
		{
		//	SendACK(2);
		}
		return;
	}
}
void SetF62(INT8U Set,INT8U F,INT8U P)
{
	if(Set==1)//��վ��������
	{
		RtuDataAddr->FkComm_Value.F8_Set_Para.Valid=1;
		memcpy(&RtuDataAddr->FkComm_Value.F8_Set_Para.GPRS_MODE,&TmpifrBuff[12],sizeof(RtuDataAddr->FkComm_Value.F8_Set_Para)-4);
		Save_CommSet();
		SetChanged[8]=1;
		SendACK(1);
		return;
	}
	if(Set==0)//��ȡ���ñ���
	{
		IfrHeadCreate(0x80);
		TrnifrBuff[IfrSned++]=0x0a;
		TrnifrBuff[IfrSned++]=0x62;
		TrnifrBuff[IfrSned++]=0x00;
		memcpy(&TrnifrBuff[IfrSned],&RtuDataAddr->FkComm_Value.F8_Set_Para.GPRS_MODE,sizeof(RtuDataAddr->FkComm_Value.F8_Set_Para)-4);
		IfrSned=IfrSned+sizeof(RtuDataAddr->FkComm_Value.F8_Set_Para)-4;
		IfrTailCreate_Send();
	}
}
void SetF24(INT8U Set,INT8U F,INT8U P)
{
	if(Set==1)//��վ��������
	{
		RtuDataAddr->FkInput_Value.New_F33_Set_Para.Valid=1;
		RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai_Num=3;
		RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[0].PortNo=1;
		RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[1].PortNo=2;
		RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[2].PortNo=3;
		memcpy(&RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[0].ChaoBiaoJianGe,&TmpifrBuff[12],1);
		memcpy(&RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[1].ChaoBiaoJianGe,&TmpifrBuff[12],1);
		memcpy(&RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[2].ChaoBiaoJianGe,&TmpifrBuff[12],1);
		Save_CommSet();
		SetChanged[24]=1;
		SendACK(1);
		return;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->Fk_Control_Set_Value.F24_Set_Para.Valid==1)
		{
			IfrHeadCreate(0x80);
			TrnifrBuff[IfrSned++]=0x0a;
			TrnifrBuff[IfrSned++]=24;
			TrnifrBuff[IfrSned++]=0x00;
			if(RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[0].ChaoBiaoJianGe!=0)
				TrnifrBuff[IfrSned++]=RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[0].ChaoBiaoJianGe;
			else
				TrnifrBuff[IfrSned++]=5;
			IfrTailCreate_Send();
		}
		//else
		{
		//	SendACK(2);
		}
		return;
	}
}
void SetF84(INT8U Set,INT8U F,INT8U P)
{
	if(Set==1)//��վ��������
	{
		RtuDataAddr->FkComm_Value.GB22601991[0]=TmpifrBuff[12];
		RtuDataAddr->FkComm_Value.GB22601991[1]=TmpifrBuff[13];
		RtuDataAddr->FkComm_Value.ADDR[0]=TmpifrBuff[14];
		RtuDataAddr->FkComm_Value.ADDR[1]=TmpifrBuff[15];
		Save_CommSet();
		SetChanged[84]=1;
		SendACK(1);
		return;
	}
	if(Set==0)//��ȡ���ñ���
	{
		IfrHeadCreate(0x80);
		TrnifrBuff[IfrSned++]=0x0a;
		TrnifrBuff[IfrSned++]=84;
		TrnifrBuff[IfrSned++]=0x00;
		TrnifrBuff[IfrSned++]=RtuDataAddr->FkComm_Value.GB22601991[0];//1
		TrnifrBuff[IfrSned++]=RtuDataAddr->FkComm_Value.GB22601991[1];//0
		TrnifrBuff[IfrSned++]=RtuDataAddr->FkComm_Value.ADDR[0];
		TrnifrBuff[IfrSned++]=RtuDataAddr->FkComm_Value.ADDR[1];
		IfrTailCreate_Send();
	}
}
//���������ʼ��
void SetF78(INT8U Set,INT8U F,INT8U P)
{
	if(Set==1)//��վ��������
	{
		memset(&RtuDataAddr->FkInput_Value.F10_Set_Para.Valid, 0, sizeof(RtuDataAddr->FkInput_Value.F10_Set_Para));
		memcpy(&RtuDataAddr->Meter_Para.Valid, &RtuDataAddr->FkInput_Value.F10_Set_Para.Valid, sizeof(RtuDataAddr->FkInput_Value.F10_Set_Para));
		Save_CommSet();
		SendACK(1);
		return;
	}
}
//BCDת��Ϊ32λ����
INT32S BCD_INT32(INT8U *buf, INT8U len) {
	INT32S i;
	INT32S Result = 0;
	for (i = len; i > 0; i--) {
		Result = (Result * 10) + ((buf[i - 1] >> 4) & 0xf);
		Result = (Result * 10) + (buf[i - 1] & 0xf);
	}
	return Result;
}
void SetF56(INT8U Set,INT8U F,INT8U P)
{
	INT16U Meternum,metnum=0;
	int baud,i=0;
	INT8U BaudAndPort;
	INT8U AFN;
	//����ʱ���
	if(Set==1)//��վ��������
	{
		AFN=TmpifrBuff[9];
		Meternum=(TmpifrBuff[13]<<8)+TmpifrBuff[12];
		if (Meternum>0)
			metnum=Meternum-1;

		if (Meternum>=DD_Device_Max)
		{
			SendNAK(F,P,AFN);
			   return;
		}
		RtuDataAddr->FkInput_Value.F10_Set_Para.Valid=1;
		RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num=Meternum;
		RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[metnum].No=metnum+1;
		for(i=Meternum;i<DD_Device_Max;i++){
			RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].No=0;
			printf("\n\rNONONO==%d",RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].No);
		}

		RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[metnum].CeLiangNo=metnum+1;
		RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[metnum].Addr[0]=TmpifrBuff[14];
		RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[metnum].Addr[1]=TmpifrBuff[15];
		RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[metnum].Addr[2]=TmpifrBuff[16];
		RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[metnum].Addr[3]=TmpifrBuff[17];
		RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[metnum].Addr[4]=TmpifrBuff[18];
		RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[metnum].Addr[5]=TmpifrBuff[19];
		RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[metnum].GuiYue_Type=BCD_INT32(&TmpifrBuff[20],1);
		baud=(TmpifrBuff[23]<<8)+TmpifrBuff[22];
		switch(baud)
		{
			case 600:
				BaudAndPort=1;
			break;
			case 1200:
				BaudAndPort=2;
			break;
			case 2400:
				BaudAndPort=3;
			break;
			case 4800:
				BaudAndPort=4;
			break;
			case 7200:
				BaudAndPort=5;
			break;
			case 9600:
				BaudAndPort=6;
			break;
			case 19200:
				BaudAndPort=7;
			break;
			default:
				BaudAndPort=2;
			break;

		}
		RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[metnum].BaudAndPort=(BaudAndPort<<5)|TmpifrBuff[21];
		printf("\n\rMetet_jiaoliu_Num==%d",RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num);
		Save_Input_Set();
		SendACK(1);
		return ;
	}
}
//�ն˰汾��Ϣ�� PPP ��ַ
void SetF98(INT8U Set,INT8U F,INT8U P)
{
	INT8U PPPIP[4],VER[2];
	int ip1,ip2,ip3,ip4,ver1,ver2;
	memset(PPPIP,0,4);
	memset(VER,0,2);
	if(Set==0)//��ȡ���ñ���
	{
		sscanf(RtuDataAddr->pppip,"%d.%d.%d.%d",&ip1,&ip2,&ip3,&ip4);
		PPPIP[0] = ip1;
		PPPIP[1] = ip2;
		PPPIP[2] = ip3;
		PPPIP[3] = ip4;
		sscanf((char *)RtuDataAddr->ucsysVER,"%d.%d",&ver1,&ver2);
		VER[0] = ver1;
		VER[1] = ver2;
		IfrHeadCreate(0x80);
		TrnifrBuff[IfrSned++]=0x0a;
		TrnifrBuff[IfrSned++]=0x98;
		TrnifrBuff[IfrSned++]=0x00;
		TrnifrBuff[IfrSned++]=PPPIP[0];
		TrnifrBuff[IfrSned++]=PPPIP[1];
		TrnifrBuff[IfrSned++]=PPPIP[2];
		TrnifrBuff[IfrSned++]=PPPIP[3];

		TrnifrBuff[IfrSned++]=VER[0];
		TrnifrBuff[IfrSned++]=VER[1];
		printf("\n\r pppip------------------  %d.%d.%d.%d",PPPIP[0],PPPIP[1],PPPIP[2],PPPIP[3]);
		printf("\n\r verinf-----------------  %c.%c",VER[0],VER[1]);
		IfrTailCreate_Send();
		return;
	}
}
void SetifrPara(unsigned char Flag,unsigned char F,unsigned char P)
{
	switch(F)
	{
		case 1:
		SetF1(Flag,F,P);//�ն� ͨѶ�������ã���������//����
		break;
		case 3:
		SetF3(Flag,F,P);//��վ IP �˿ں�  apn//����
		break;
		case 4:
		SetF4(Flag,F,P);//��վ �绰 ���� ����
		break;
		break;
		case 10:
		SetF10(Flag,F,P);//���ò��������//����
		break;
		case 11:
		SetF11(Flag,F,P);//����
		break;
		case 12:
		SetF12(Flag,F,P);//״̬�� ����//����
		case 14:
		SetF14(Flag,F,P);//�ܼ������
		break;
		case 24:
		SetF24(Flag,F,P);//�������//����
		break;
		case 56:
		SetF56(Flag,F,P);//�����������
		break;
		case 62:
		SetF62(Flag,F,P);//����ר������ģʽ//����
		break;
		case 78:
		SetF78(Flag,F,P);//ɾ�����в����㣬�����������ʼ��//����
		break;
		case 84:
		SetF84(Flag,F,P);//�ն˵�ַ����:���������룬�ն�id//����
		break;
		case 98:
		SetF98(Flag,F,P);//��ȡ�����汾�����Ż�ȡ��IP//����
		break;
		default:
		SendACK(2);
		return ;
	}
	return;
}
void AskifrData()
{
	switch(TmpifrBuff[9])//AFN
	{
	case 04:
		SetifrPara(1,TmpifrBuff[10],TmpifrBuff[11]);//�ն˲�������
		IfrDebugOut("\r\n Zhongduan Canshu SET Finish!");
		break;
	case 0x0a:
		SetifrPara(0,TmpifrBuff[10],TmpifrBuff[11]);//�ն˲����в�
		IfrDebugOut("\r\n Zhongduan Canshu Call Finish!");
		break;
	default:
		SendACK(2);
		break;
	}
}
void DealifrProtocol()
{
	if((TmpifrBuff[7]==0xff)&&(TmpifrBuff[8]==0xff))
	{
		if((TmpifrBuff[6]&0x0f)==10)
		{
			IfrDebugOut("\r\n AskifrData11111");
			 AskifrData();
		     return;
		}
	}
	else
	{
		if(Asdu130Addr[2]!=TmpifrBuff[7]);
		{
			return;
		}
		if(Asdu130Addr[3]!=TmpifrBuff[8])
		{
			return;
		}
		if((TmpifrBuff[6]&0x0f)==10)
		{
			IfrDebugOut("\r\n AskifrData222222");
			AskifrData();
		    return;
		}
	}

}
//68 c 0 c 0 68 a 1 0 4 1 0 1 1 1 0 1 1 15 16
void Get_ifr_Data_Process()
{
	unsigned int len,i;
	IfrDebugOut("\r\nGet_ifr_Data start��\n\r");
	while(((ifrRecHead+IFRBUF_MAX-ifrRecTail)%IFRBUF_MAX)>=6)
	{
		if((RecifrBuff[ifrRecTail]==0x68)&&(RecifrBuff[(ifrRecTail+5)%IFRBUF_MAX]==0x68))
		{
			len=RecifrBuff[(ifrRecTail+2)%IFRBUF_MAX];//RecifrBuff[2]��ֵ��Ҳ���ǳ��ȵĸ��ֽڡ�
			len=(len<<8)+RecifrBuff[(ifrRecTail+1)%IFRBUF_MAX];//RecifrBuff[1]��ֵ��Ҳ���ǳ��ȵĵ��ֽڡ�
			if((((ifrRecHead+IFRBUF_MAX-ifrRecTail)%IFRBUF_MAX)>=(len+8)))
			{
				memset(TmpifrBuff,0,IFRBUF_MAX);
				for(i=0;i<len+8;i++)
				{
					TmpifrBuff[i]=RecifrBuff[ifrRecTail];
					ifrRecTail=(ifrRecTail+1)%IFRBUF_MAX;
				}
				IfrDebugOut("\r\n len=%d check=%x   %x ",len,CheckSumifr(&TmpifrBuff[6],len),TmpifrBuff[len+6]);
				if(CheckSumifr(&TmpifrBuff[6],len)==TmpifrBuff[len+6])
				{
					IfrDebugOut("\r\nREC=");
					for(i=0;i<len+8;i++)
					{
						IfrDebugOut("%x ",TmpifrBuff[i]);
					}
					DealifrProtocol();
				}
			}
			else
			{
				break;
			}
		}
		else
		{
			ifrRecTail=(ifrRecTail+1)%IFRBUF_MAX;
		}
	}
}
void markver()//��Ŀ������б�ʶ�����汾��Ϣ
{
	printf("\n%s\n", verstr);
}
unsigned char   PARSE_CMD(int argc, char * argv[])
{
	unsigned char  proc_name[32] = "";
	if(argc < 2)return (FALSE);
	PORT_ID = atoi(argv[1]);
	sprintf((char *)proc_name, "%s %d", argv[0], PORT_ID);
	if((attach = name_attach(NULL, (char *)proc_name,0))== NULL)
	{
		return (FALSE);
	}
	return (TRUE);
}
int write_apn()
{
	FILE *fp = NULL;

	fp=fopen("/etc/ppp/gprs-connect-chat","w");
	if (fp==NULL)
		return 0;
	fprintf(fp,"TIMEOUT        3\n");
	fprintf(fp,"ABORT        \'\\nBUSY\\r\'\n");
	fprintf(fp,"ABORT        \'\\nNO ANSWER\\r\'\n");
	fprintf(fp,"ABORT        \'\\nRINGING\\r\\n\\r\\nRINGING\\r\'\n");
	fprintf(fp,"\'\' \\rAT\n");
	fprintf(fp,"\'OK-+++\\c-OK\'    ATZ\n");
	fprintf(fp,"TIMEOUT        5\n");
	fprintf(fp,"OK        AT+CSQ\n");
	fprintf(fp,"OK        AT+CGDCONT=1,\"IP\",\"%s\"\n",RtuDataAddr->FkComm_Value.F3_Set_Para.APN);
	fprintf(fp,"OK        ATDT*99***1#\n");
	fprintf(fp,"CONNECT \'\'\n");
	fclose(fp);
	return 1;
}
void QuitProcess(int signo)
{
	delay(100);
	RtuDataAddr->stPortPara[PORT_ID].PID=0;
   	name_detach(attach, 0);
   	fprintf(stderr,"fkifr quit");
	exit(0);
}
/******************************************************************************************************************
* �������ƣ�IOInit()
* ��    �ܣ�      ��ʱ��TIOB1��Ҫ��IO
* ��ڲ�������
* ���ڲ�������
*******************************************************************************************************************/
void IOInit(void)
{
	//BaseTIOB1Io = mmap_device_io(0x10,0xFFFFF800); //AT91C_BASE_PIOC
	if (!PortOpened) {
		OpenGPIO();  //quxiaogpio
	}  //quxiaogpio
    out32(port3+4,AT91C_PIO_PC7);  //ʹ������TIOB1
    ////out32(port2+4,AT91C_PIO_PB10|AT91C_PIO_PB11);  //ʹ������USAR
}
/******************************************************************************************************************
* �������ƣ�TC1_Init()
* ��    �ܣ�      ���ö�ʱ��TIOB1
* ��ڲ�������
* ���ڲ�������
*******************************************************************************************************************/
void TC1_Init(void)
{
	int tmp;
	BasePMCTc1= mmap_device_io(0x20,0xfffffc00);
    tmp = in32(BasePMCTc1+0x18);       //read PMC State
    out32(BasePMCTc1+0x10,tmp|0x40000);//enable TimeCount1

    BaseTC1   = mmap_device_io(0x100,0xFFFA0040);
	out32(BaseTC1+4,0x4f00c400);

	out32(BaseTC1+0x1c,0x51a);//38khz
	out32(BaseTC1+0x18,0x28d);
	out32(BaseTC1,0x5);
}
void CommInit(void)
{
	unsigned char tmp[128];
	int flags,flags2,flags3;
    unsigned char id;
    id=4;
    memset(tmp,0,128);
	sprintf((char *)tmp,"stty </dev/ser%d baud=1200 par=none stopb=1 bits=8",id);
	system((char *)tmp);
	memset(tmp,0,128);
	sprintf((char *)tmp,"/dev/ser%d",id);
	ComRedPort = open((char *)tmp, O_RDWR );
	//printf("\n\rIFR ComRedPort==%d id==%d",ComRedPort,id);
	if (ComRedPort < 0 )
	{
		return;
	}
	tcflush(ComRedPort,TCIOFLUSH);
	flags=fcntl(ComRedPort,F_GETFL);
	flags=flags|O_NONBLOCK;
	flags3=fcntl(ComRedPort,F_SETFL,flags);
	flags2=fcntl(ComRedPort,F_GETFL);
}
void initdata()
{
	ifrRecTail = 0;
	ifrRecHead = 0;
	memset(RecifrBuff,0,IFRBUF_MAX);
	memset(TrnifrBuff,0,IFRBUF_MAX);
}
int main(int argc, char *argv[])
{
	struct sigaction sa1;
    unsigned char tmp[64];
    memset(tmp,0,64);
    TS ts;
    markver();
    if(OpenMem())return EXIT_FAILURE;

    if(RtuDataAddr->mem_len!=sizeof(RTimeData))
    {
      return EXIT_FAILURE;
    }
    if(!PARSE_CMD(argc, argv))
    {
    	IfrDebugOut("\n Bad command format. Type 'use exe_name' for help!\n\r");
	    return EXIT_FAILURE;
    }
	if(PORT_ID<TCP_IP_START)//ser port open
	{
		sprintf((char *)tmp,
			"stty </dev/ser%d baud=%d par=%s stopb=%d bits=%d",
			PORT_ID-SER_START,
			1200,
			"even",
			1,
			8
			);
		system((char *)tmp);
		memset(tmp,0,64);
		sprintf((char *)tmp,"/dev/ser%d",PORT_ID-SER_START);
		//printf("\n\r IFR ComPort==%d",PORT_ID-SER_START);
		delay(500);
		ComPort = open((char *)tmp, O_RDWR);
		if (ComPort < 0 )
		{
			return EXIT_FAILURE;
		}
		fcntl(ComPort,F_SETFL,O_NONBLOCK);
	}
    sa1.sa_handler = QuitProcess;
    sigemptyset(&sa1.sa_mask);
    sa1.sa_flags = 0;
    sigaction(SIGTERM, &sa1,NULL);
    sigaction(SIGSYS, &sa1,NULL);
    sigaction(SIGPWR, &sa1,NULL);
    sigaction(SIGKILL, &sa1,NULL);
    sigaction(SIGQUIT, &sa1,NULL);
    sigaction(SIGILL, &sa1,NULL);
    sigaction(SIGINT, &sa1,NULL);
    sigaction(SIGHUP, &sa1,NULL);
    sigaction(SIGABRT, &sa1,NULL);
    sigaction(SIGBUS, &sa1,NULL);
    RtuDataAddr->stPortPara[PORT_ID].PID=getpid();
    while(RtuDataAddr->Dev_Init_OK==0)
    {
    	CleardeadCount();
    	delay(1000);
    }
    if (GetPowerOffFile()==1)//���� 1 ��ʾ����ǰ�װ�ͣ�磬�ն˽�����ͣ/�ϵ��¼�
    	RtuDataAddr->BoardElecState = 1;
    else					 //���� 0  ��ʾ����ǰ�װ��е�(shutdown����ϵͳ����) �ն˲��������¼�
    	RtuDataAddr->BoardElecState = 0;
	//RtuDataAddr->BoardElecState = 1;
	RtuDataAddr->PowerOnMessage = 1;
	RtuDataAddr->PowerOFFMessage = 0;
    CleardeadCount();
	IOInit();   //�����������
	TC1_Init(); //�����������
	CommInit();
    setboardpowerio();
	delay(1000);
	while(1)
	{
		initdata();					//��ʼ��������
		CleardeadCount();
		ReceiveFromifr(RecifrBuff);//���ռ�����������
	    delay(100);
		Get_ifr_Data_Process();    //���������Ĳ�������Ӧ
		TSGet(&ts);
		JugePowerEvent(ts);
	}
	return EXIT_SUCCESS;
}
