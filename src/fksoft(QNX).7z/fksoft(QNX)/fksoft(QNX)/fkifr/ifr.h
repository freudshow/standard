#ifndef FKIFR_H_
#define FKIFR_H_
#endif
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <ctype.h>
#include <time.h>
#include <stdint.h>
#include <signal.h>
#include <sys/sched.h>
#include <semaphore.h>
#include <process.h>
#include <sys/neutrino.h>
#include <sys/netmgr.h>
#include <sys/dispatch.h>
#include <errno.h>
#include <netdb.h>
#include <hw/inout.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <math.h>
#include <termios.h>
#include <fkbase/memdef.h>
#include <fkbase/fkbasefun.h>

#define IfrDebugOut if(RtuDataAddr->IFRDBON)printf
#define	 DebugComm				stderr
#define	 PORTNO_MAX				32		         //Ŀǰ�����������ͨ���˿ں�
#define  IFRBUF_MAX             512
#define AT91C_PIO_PC7        (1 << 7)  // Pin Controlled by PC7
#define AT91C_PIO_PB10       (1 << 10) // Pin Controlled by PB10
#define AT91C_PIO_PB11       (1 << 11) // Pin Controlled by PB11

int         ComRedPort;
int         ComPort;

uintptr_t BasePMCTc1;
uintptr_t BaseTC1;
INT8U       RecifrBuff[IFRBUF_MAX];    //���������ù�Լ���ձ��Ļ�����
INT8U       TmpifrBuff[IFRBUF_MAX];
INT8U       TrnifrBuff[IFRBUF_MAX];    //���������÷��ͱ��Ļ�����
INT16U		ifrRecTail;
INT16U		ifrRecHead;
INT8U 		Asdu130Addr[5];
INT8U 		SetChanged[256];
INT8U		SendBuff[FrameSize];
INT8U       PORT_ID;
INT16U      IfrSned;
INT16U 	    SendLen;
INT8U		seq;
INT8U 	    TpBuff[6];////,MSA;
INT8U 		Tmp130Buff[FrameSize];
INT8U		EC1=0,EC2=0,EC1old=0,EC2old=0;////,ReadEveHead,ReadEveTail;
INT8U 	    NeedTp;
WirelessPara		CommPara;
name_attach_t       *attach;
RTimeData           *RtuDataAddr;//�ڴ湲��������ָ��
