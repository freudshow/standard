#ifndef FKSPIOP_H_
#define FKSPIOP_H_
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <ctype.h>
#include <time.h>
#include <signal.h>
#include <sys/sched.h>
#include <semaphore.h>
#include <process.h>
#include <sys/neutrino.h>
#include <sys/netmgr.h>
#include <sys/dispatch.h>
#include <errno.h>
#include <netdb.h>
#include <hw/inout.h>
#include <fkbase/spi-master.h>

#include <netinet/in.h>
#include <sys/time.h>
#include <math.h>
#include <fkbase/memdef.h>
#include <fkbase/fkbasefun.h>
#define DataSaveDbg if(RtuDataAddr->DATASAVEDBON)printf

extern RTimeData  *RtuDataAddr;//�ڴ湲��������ָ��
extern  INT8U PORT_ID;
extern  INT16U ledold;
extern int setupTimer();
extern void QuitProcess(int signo);
extern int fp;
extern int device;
extern spi_devinfo_t cfg;
extern name_attach_t *attach;
#define Dlt645Dbg fprintf
INT8U CheckMem(INT8U *s,INT16U len);
void Fm25_Write(unsigned char *Array,int Length,int Addr);
void Fm25_Read(unsigned char *Array,int Length,int Addr);
void InitGpio();
void showled();

#endif /*FKSPIOP_H_*/
