/*
 * fkspifun.c
 *
 *  Created on: Dec 16, 2009
 *      Author: ln
 */
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <ctype.h>
#include <time.h>
#include <signal.h>
#include <sys/sched.h>
#include <semaphore.h>
#include <process.h>
#include <sys/neutrino.h>
#include <sys/netmgr.h>
#include <sys/dispatch.h>
#include <errno.h>
#include <netdb.h>
#include <hw/inout.h>
#include <fkbase/spi-master.h>

#include <netinet/in.h>
#include <sys/time.h>
#include <math.h>
#include <fkbase/memdef.h>
#include <fkbase/fkbasefun.h>
#include "fkspifun.h"
#define DataSaveDbg if(RtuDataAddr->DATASAVEDBON)printf

RTimeData  *RtuDataAddr;//�ڴ湲��������ָ��
INT8U PORT_ID;
INT16U ledold=0;
int setupTimer();
void QuitProcess(int signo);
int fp;
int device=0;
spi_devinfo_t cfg;
name_attach_t *attach;
#define Dlt645Dbg fprintf
INT8U CheckMem(INT8U *s,INT16U len)
{
	INT16U i;
	INT8U C;
	C=0;
	for(i=0;i<len-4;i++)
	{
		C=C+s[i];
	}
	return C;
}
int SaveFMdata()
{
	int re;
	FILE *fp = 0;
	fp = fopen("/nand/save/realdata.dat", "w");
	if (fp != NULL) {
		fseek(fp, 0, SEEK_SET);
		re = fwrite(RtuDataAddr->FM_Save_buff,8000, 1,fp);
		fclose(fp);
	} else {
		re = 0;
	}
	return re;
}
int ReadFMdata()
{
	FILE *fp = NULL;
	INT8U re;
	fp = fopen("/nand/save/realdata.dat", "r");
	if (fp != NULL) {
		fseek(fp, 0, SEEK_SET);
		re = fread(RtuDataAddr->FM_Save_buff,8000,1,fp);
		fclose(fp);
	} else {
		memset(RtuDataAddr->FM_Save_buff, 0, 8000);//liuliu???
		SaveFMdata();
		re = 0;
	}
	return re;
}
void Fm25_Write(unsigned char *Array,int Length,int Addr)
{
	/*SaveFile("/nand/save/realdata.dat",Array,8000);*/
#if 1
	int re = 0;
	int cnt=0;
	Array[cnt++]=6;
	spi_write(fp,0,Array,cnt);
	cnt=0;
	Array[cnt++]=2;
	Array[cnt++]=((Addr>>8) & 0xff);
	Array[cnt++]=(Addr & 0xff);
	re = spi_write(fp,0,Array,Length+3);
	//printf("\n\r fm write re is %d",re);
#endif
}
void Fm25_Read(unsigned char *Array,int Length,int Addr)
{
#if 0
	if(!ReadFile("/nand/save/realdata.dat",Array,8000))
	{
		memset(Array,0,8000);
		Fm25_Write(Array,8000,0);
	}
#endif
#if 1
	int re;
	int cnt=0;
	unsigned char cmd[32];
	memset(cmd,0,32);
	cmd[cnt++]=3;
	cmd[cnt++]=((Addr>>8) & 0xff);
	cmd[cnt++]=(Addr & 0xff);
	re = spi_cmdread(fp,0,cmd,cnt,&Array[Addr+3],Length);
	//printf("\n\r fm read re is %d",re);
#endif
}
void InitGpio()
{
	if (!PortOpened) {
		OpenGPIO();  //quxiaogpio
	}
	GpioDisable(1,12);
	GpioDisable(1,13);
	GpioDisable(1,14);
	GpioDisable(1,15);
	GpioDisable(1,16);
	GpioDisable(1,17);
	GpioDisable(1,18);
	GpioDisable(1,19);
	GpioDisable(1,20);
	GpioDisable(1,21);
	GpioEnable(1,22);
	//GpioEnable(1,28);
	GpioInEnable(1,28);
	//GpioEnable(2,28);//1
	//GpioEnable(2,29);//2     //YX7
//	GpioEnable(2,30);//3     //YX8
	//GpioEnable(2,31);//4
	//GpioEnable(1,6);//5����
	//GpioEnable(1,7);//6����
	//GpioEnable(2,27);//7����
	//GpioEnable(1,8);//8����
	//GpioEnable(1,5);//9����
	//GpioEnable(1,4);//10
	//GpioEnable(2,10);//11
	//GpioEnable(1,20);//12
	//GpioEnable(2,16);//13����
	//GpioEnable(2,18);//14����
	//GpioEnable(2,17);//14����
}
void showled()
{
	int disp;
	INT16U Leddd;
	INT8U buf[2];
	Leddd = ledold^RtuDataAddr->leddisp;
	ledold=RtuDataAddr->leddisp;
	//disp=RtuDataAddr->leddisp>>16;
	disp=RtuDataAddr->leddisp;
	disp=disp^0xffff;
	buf[0] = (disp>>8)&0xff;
	buf[1] = disp&0xff;
	spi_write(fp,1,buf,2);
}
