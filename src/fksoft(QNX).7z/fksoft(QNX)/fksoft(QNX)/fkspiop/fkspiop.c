#include "fkspifun.h"
const char verstr[]={"VER-STRING-FLG=010.002.217.004"__DATE__" "__TIME__};
extern int ReadFMdata();
extern int SaveFMdata();
INT8U   PARSE_CMD(int argc, char * argv[])
{
	char  proc_name[32] = "";

	DataSaveDbg("cmdline=%d,%s %s\r\n", argc, argv[0], argv[1]);
	if(argc < 2)return (FALSE);
	PORT_ID = atoi(argv[1]);
	sprintf(proc_name, "%s %d", argv[0], PORT_ID);
	if((attach = name_attach(NULL, proc_name,0))  == NULL)
	{
		fprintf(stderr, "ERR:'%s' runed,cann't regist: %s\r\n", proc_name, strerror(errno));
		return (FALSE);
	}
	return (TRUE);
}
void QuitProcess(int signo)
{
	delay(100);
	RtuDataAddr->stPortPara[PORT_ID].PID=0;
   	name_detach(attach, 0);
   	fprintf(stderr,"fkspiop quit");
	exit(0);
}
void markver()//��Ŀ������б�ʶ�����汾��Ϣ
{
	printf("\n%s\n", verstr);
}

int main(int argc, char *argv[]) {
	struct sigaction sa1;
	INT8U Min;
	TS ts;
	int j;
	unsigned char batflag;
	INT8U NowMin;
	markver();
	if(OpenMem())return EXIT_FAILURE;
	if(RtuDataAddr->mem_len!=sizeof(RTimeData))
	{
		fprintf( stderr, "base mem uncompared prog will exit %d :\n",sizeof(RTimeData));
		return EXIT_FAILURE;
	}
	if(!PARSE_CMD(argc, argv))
	{
		//printf("\n Bad command format. Type 'use exe_name' for help!\n\r");
		return EXIT_FAILURE;
	}
	//////////////////////////////////////////////////////////////////////////
	sa1.sa_handler = QuitProcess;
	sigemptyset(&sa1.sa_mask);
	sa1.sa_flags = 0;
	sigaction(SIGTERM, &sa1,NULL);
	sigaction(SIGSYS, &sa1,NULL);
	sigaction(SIGPWR, &sa1,NULL);
	sigaction(SIGKILL, &sa1,NULL);
	sigaction(SIGQUIT, &sa1,NULL);
	sigaction(SIGILL, &sa1,NULL);
	sigaction(SIGINT, &sa1,NULL);
	sigaction(SIGHUP, &sa1,NULL);
	sigaction(SIGABRT, &sa1,NULL);
	sigaction(SIGBUS, &sa1,NULL);
	RtuDataAddr->stPortPara[PORT_ID].PID=getpid();
	Min=0;
	fp = spi_open("/dev/spi0");
	//-------device 0
	spi_getdevinfo(fp,0,&cfg);
	cfg.cfg.mode=cfg.cfg.mode|SPI_MODE_CKPHASE_HALF;//|SPI_MODE_CSHOLD_HIGH;
	//cfg.cfg.clock_rate = 200000;
	spi_setcfg(fp, 0, &cfg.cfg);
	spi_getdevinfo(fp,0,&cfg);
	//fprintf(stderr,"\nfkspiop.c 1:cfg.name=%s cfg.device=%d cfg.clock_rate=%d cfg.mode=%x\n",cfg.name,cfg.device,cfg.cfg.clock_rate,cfg.cfg.mode);

	//-------device 1
	OSTimeDly(500);
	spi_getdevinfo(fp,1,&cfg);
	cfg.cfg.mode=cfg.cfg.mode|SPI_MODE_CKPHASE_HALF;//|SPI_MODE_CSHOLD_HIGH;
	//cfg.cfg.clock_rate = 200000;
	spi_setcfg(fp, 1, &cfg.cfg);
	spi_getdevinfo(fp,1,&cfg);
	//fprintf(stderr,"\nfkspiop.c 2:cfg.name=%s cfg.device=%d cfg.clock_rate=%d cfg.mode=%x\n",cfg.name,cfg.device,cfg.cfg.clock_rate,cfg.cfg.mode);

	//-------device 2
	OSTimeDly(500);
	spi_getdevinfo(fp,2,&cfg);
	cfg.cfg.mode=cfg.cfg.mode|SPI_MODE_CKPHASE_HALF;//|SPI_MODE_CSHOLD_HIGH;
	//cfg.cfg.clock_rate = 200000;
	spi_setcfg(fp, 2, &cfg.cfg);
	spi_getdevinfo(fp,2,&cfg);
	//fprintf(stderr,"\nfkspiop.c 1:cfg.name=%s cfg.device=%d cfg.clock_rate=%d cfg.mode=%x\n",cfg.name,cfg.device,cfg.cfg.clock_rate,cfg.cfg.mode);

	OSTimeDly(500);
	TSGet(&ts);
	NowMin=ts.Minute;
	j=0;
	InitGpio();
	//Fm25_Read(&RtuDataAddr->FM_Save_buff[0],8000,0);
	//printf("\n\r read fm data %d",ReadFMdata());
	ReadFMdata();
	RtuDataAddr->EC1=RtuDataAddr->Fm_Save_Eve.EC1;
	RtuDataAddr->EC2=RtuDataAddr->Fm_Save_Eve.EC2;
	RtuDataAddr->Fm_Init_OK=1;
	batflag = 0;
	//ResetAddr = mmap_device_io( 4,0xfffffd08 );
	//out32(ResetAddr,0xa5000801);
   	for (;;)
   	{
 		CleardeadCount();
		TSGet(&ts);
		showled();
		if(ts.Minute%15==0)
		{
			sem_wait(&RtuDataAddr->UseFMFileFlg);
			SaveFMdata();
			TSGet(&ts);
			RtuDataAddr->FM_Changed=0;
			sem_post(&RtuDataAddr->UseFMFileFlg);
		}

		if ((RtuDataAddr->batflag==1)&&(RtuDataAddr->batflag!=batflag))
		{
			sem_wait(&RtuDataAddr->UseFMFileFlg);
			SaveFMdata();
			TSGet(&ts);
			RtuDataAddr->FM_Changed=0;
			sem_post(&RtuDataAddr->UseFMFileFlg);
		}
		batflag = RtuDataAddr->batflag;
		delay(20);
     }
  	name_detach(attach, 0);
 	return EXIT_SUCCESS;
}



