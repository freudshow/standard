#include "fkcontrol.h"
const char verstr[]={"VER-STRING-FLG=003.002.217.004"__DATE__" "__TIME__};
INT8U GLvKong_flag[8];
INT8U YingYeKong_flag[8];
INT8U ChangXiuKong_flag[8];
INT8U ShiDuan_flag[8];
INT8U GouFirstFlag[8][4];
INT8U YueFirstFlag[8][4];
INT8U y=0,diankongptr=0;
void OutScreen()
{
}
void Create_Data_Type02(INT32S S,INT8U *Dest)
{
	INT32S Temp,i;
	if(abs(S)<1000)
	{
		Temp=abs(S)%1000;//,1000w
		i=Temp/100;
		Dest[1]=i|0xe0;
		i=Temp%100;
		Dest[0]=((i/10)<<4)+(i%10);
		if(S<0)
		{
			Dest[1]=Dest[1]|0x10;
		}
		return;
	}
	if(abs(S)<10000)
	{
		Temp=abs(S)%10000;//
		i=Temp/1000;
		Dest[1]=i|0xc0;
		i=(Temp%1000)/10;
		Dest[0]=((i/10)<<4)+(i%10);
		if(S<0)
		{
			Dest[1]=Dest[1]|0x10;
		}
		return;
	}
	if(abs(S)<100000)
	{
		Temp=abs(S)%100000;//
		i=Temp/10000;
		Dest[1]=i|0xa0;
		i=(Temp%10000)/100;
		Dest[0]=((i/10)<<4)+(i%10);
		if(S<0)
		{
			Dest[1]=Dest[1]|0x10;
		}
		return;
	}
	if(abs(S)<1000000)
	{
		Temp=abs(S)%1000000;//
		i=Temp/100000;
		Dest[1]=i|0x80;
		i=(Temp%100000)/1000;
		Dest[0]=((i/10)<<4)+(i%10);
		if(S<0)
		{
			Dest[1]=Dest[1]|0x10;
		}
		return;
	}
	if(abs(S)<10000000)
	{
		Temp=abs(S)%10000000;//
		i=Temp/1000000;
		Dest[1]=i|0x60;
		i=(Temp%1000000)/10000;
		Dest[0]=((i/10)<<4)+(i%10);
		if(S<0)
		{
			Dest[1]=Dest[1]|0x10;
		}
		return;
	}
	if(abs(S)<100000000)
	{
		Temp=abs(S)%100000000;//
		i=Temp/10000000;
		Dest[1]=i|0x40;
		i=(Temp%10000000)/100000;
		Dest[0]=((i/10)<<4)+(i%10);
		if(S<0)
		{
			Dest[1]=Dest[1]|0x10;
		}
		return;
	}
	if(abs(S)<1000000000)
	{
		Temp=abs(S)%1000000000;//
		i=Temp/100000000;
		Dest[1]=i|0x20;
		i=(Temp%100000000)/1000000;
		Dest[0]=((i/10)<<4)+(i%10);
		if(S<0)
		{
			Dest[1]=Dest[1]|0x10;
		}
		return;
	}
}
void Create_Data_Type03(INT32S S,INT8U *Dest)
{
	INT32S Temp,i;
	if(abs(S)<10000000)
	{
		Temp=abs(S)%10000000;//,1000w
		i=Temp/1000000;
		Dest[3]=i;
		i=Temp%1000000;
		i=i/10000;
		Dest[2]=((i/10)<<4)+(i%10);
		i=Temp%10000;
		i=i/100;
		Dest[1]=((i/10)<<4)+(i%10);
		i=Temp%100;
		Dest[0]=((i/10)<<4)+(i%10);
		if(S<0)
		{
			Dest[3]=Dest[3]|0x10;
		}
		return;
	}
	else
	{
		Temp=(abs(S)/1000)%10000000;//,1000w
		i=Temp/1000000;
		Dest[3]=i|0x40;
		i=Temp%1000000;
		i=i/10000;
		Dest[2]=((i/10)<<4)+(i%10);
		i=Temp%10000;
		i=i/100;
		Dest[1]=((i/10)<<4)+(i%10);
		i=Temp%100;
		Dest[0]=((i/10)<<4)+(i%10);
		if(S<0)
		{
			Dest[3]=Dest[3]|0x10;
		}
		return;
	}
}

INT32S GetDataType02(INT8U *S)
{
	INT32S Temp;
	INT8U T1;
	Temp=S[1]&0x0f;
	Temp=Temp*100;
	Temp=Temp+((S[0]>>4)*10)+(S[0]&0x0f);
	T1=S[1]>>5;
	//printf("\n\r T1=======%d",T1);
	if(T1==0)Temp=Temp*100000000;
	if(T1==1)Temp=Temp*10000000;
	if(T1==2)Temp=Temp*1000000;
	if(T1==3)Temp=Temp*100000;
	if(T1==4)Temp=Temp*10000;
	if(T1==5)Temp=Temp*1000;
	if(T1==6)Temp=Temp*100;
	if(T1==7)Temp=Temp*10;

	T1=S[1]>>4;
	if(T1&1)
	{
		Temp=0-Temp;
	}
	return Temp;
}
long GetdataType03(INT8U *S)
{
	long t;
	t=S[3]&0x0f;
	t=(t*10)+((S[2]>>4)&0x0f);
	t=(t*10)+(S[2]&0x0f);
	t=(t*10)+((S[1]>>4)&0x0f);
	t=(t*10)+(S[1]&0x0f);
	t=(t*10)+((S[0]>>4)&0x0f);
	t=(t*10)+(S[0]&0x0f);
	if(S[3]&0x40)
	{
		t=t*1000;
	}
	if(S[3]&0x10)
	{
		t=0-t;
	}
	return t;
}

void TiaozhaControl()
{
	INT32S i,j;
	out8(ControlPtr+2,0xaa);
	delay(200);
  	for(i=0;i<4;i++)
	{
		if(((RtuDataAddr->NowControl>>i)&0x1)||((RtuDataAddr->DianControlTmp>>i)&0x1))
		{
		  //printf("\n\r iiiiii=== %d",i);
		  //printf("\n\r");
          switch(i)
          {
			  case 0:
				  out8(ControlPtr+0x10,1);
				  ClearSpiLed(LUNCI1);//gai
				 // printf("\n\raaaaaaaaaaaaaaaa");
				  break;
			  case 1:
				  out8(ControlPtr+0x12,1);
				  ClearSpiLed(LUNCI2);//gai
				 // printf("\n\r bbbbbbbbbbbbbbbb");
				  break;
			  case 2:
				  out8(ControlPtr+0x14,1);
				  ClearSpiLed(LUNCI3);//gai
				  break;
			  case 3:
				  out8(ControlPtr+0x16,1);
				  ClearSpiLed(LUNCI4);//gai
				  break;
			  default: break;

          }
		}
	}

	for(j=0;j<ZongJia_Max;j++)
	{
		for(i=0;i<4;i++)
		{
			//printf("\n\r--------------------->1111111");
			//printf("\n\r YingYeKong_flag[j]========%d",YingYeKong_flag[j]);
			//printf("\n\r GongKongStat========%d",RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[j].GongKongStat);
			if(((RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[j].GongKongStat>>i)&0x01)&&(((GLvKong_flag[j]>>i)&0x01)||((YingYeKong_flag[j]>>i)&0x01)||((ChangXiuKong_flag[j]>>i)&0x01)||((ShiDuan_flag[j]>>i)&0x01)))
			{
			  //printf("\n\r iiiiii=== %d",i);
			  //printf("\n\r");
			  switch(i)
			  {
				  case 0:
					  out8(ControlPtr+0x10,1);
					  ClearSpiLed(LUNCI1);//gai
					  if((GLvKong_flag[j]>>i)&0x01)
						  GLvKong_flag[j]=GLvKong_flag[j]&0xe;
					  else
						  if((YingYeKong_flag[j]>>i)&0x01)
							  YingYeKong_flag[j]=YingYeKong_flag[j]&0xe;
						  else
							  if((ChangXiuKong_flag[j]>>i)&0x01)
								  ChangXiuKong_flag[j]=ChangXiuKong_flag[j]&0xe;
							  else
								  if((ShiDuan_flag[j]>>i)&0x01)
									  ShiDuan_flag[j]=ShiDuan_flag[j]&0xe;
					  RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[j].GongKongStat=0;
					  break;
				  case 1:
					  out8(ControlPtr+0x12,1);
					  ClearSpiLed(LUNCI2);//gai
					  if((GLvKong_flag[j]>>i)&0x01)
						  GLvKong_flag[j]=GLvKong_flag[j]&0xd;
					  else
						  if((YingYeKong_flag[j]>>i)&0x01)
							  YingYeKong_flag[j]=YingYeKong_flag[j]&0xd;
						  else
							  if((ChangXiuKong_flag[j]>>i)&0x01)
								  ChangXiuKong_flag[j]=ChangXiuKong_flag[j]&0xd;
							  else
								  if((ShiDuan_flag[j]>>i)&0x01)
									  ShiDuan_flag[j]=ShiDuan_flag[j]&0xd;
					  RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[j].GongKongStat=0;
					  break;
				  case 2:
					  out8(ControlPtr+0x14,1);
					  ClearSpiLed(LUNCI3);//gai
					  if((GLvKong_flag[j]>>i)&0x01)
						  GLvKong_flag[j]=GLvKong_flag[j]&0xb;
					  else
						  if((YingYeKong_flag[j]>>i)&0x01)
							  YingYeKong_flag[j]=YingYeKong_flag[j]&0xb;
						  else
							  if((ChangXiuKong_flag[j]>>i)&0x01)
								  ChangXiuKong_flag[j]=ChangXiuKong_flag[j]&0xb;
							  else
								  if((ShiDuan_flag[j]>>i)&0x01)
									  ShiDuan_flag[j]=ShiDuan_flag[j]&0xb;
					  RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[j].GongKongStat=0;
					  break;
				  case 3:
					  out8(ControlPtr+0x16,1);
					  ClearSpiLed(LUNCI4);//gai
					  if((GLvKong_flag[j]>>i)&0x01)
						  GLvKong_flag[j]=GLvKong_flag[j]&0x7;
					  else
						  if((YingYeKong_flag[j]>>i)&0x01)
							  YingYeKong_flag[j]=YingYeKong_flag[j]&0x7;
						  else
							  if((ChangXiuKong_flag[j]>>i)&0x01)
								  ChangXiuKong_flag[j]=ChangXiuKong_flag[j]&0x7;
							  else
								  if((ShiDuan_flag[j]>>i)&0x01)
									  ShiDuan_flag[j]=ShiDuan_flag[j]&0x7;
					  RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[j].GongKongStat=0;
					  break;
				  default: break;
			  }
			  break;
			}
		}
		//printf("\n\r--------------------->2222222");
		//printf("\n\r YingYeKong_flag[j]========%d",YingYeKong_flag[j]);
	}
	delay(2000);
	out8(ControlPtr+2,0);
}
void ClearControl()
{
	out8(ControlPtr+2,0xaa);
	OSTimeDly(50);
	out8(ControlPtr+0x10,0);
	out8(ControlPtr+0x12,0);
	out8(ControlPtr+0x14,0);
	out8(ControlPtr+0x16,0);
	OSTimeDly(200);
	out8(ControlPtr+2,0);
}
void initAllShiDuan()
{
	INT8U i,Temp,SdNo;
	INT16U NinCountTemp;
	NinCountTemp=0;
	SdNo=0;
	for(i=0;i<8;i++)
	{
		RtuDataAddr->All_ShiD_Value[i].startMin=0;
		RtuDataAddr->All_ShiD_Value[i].endMin=0;
		RtuDataAddr->All_ShiD_Value[i].Valid=0;
	}
	for(i=0;i<12;i++)
	{

		Sd48[i*4]=RtuDataAddr->Fk_Control_Set_Value.F18_Set_Para.ZD_GK_SD[i]&0x03;
		Sd48[i*4+1]=(RtuDataAddr->Fk_Control_Set_Value.F18_Set_Para.ZD_GK_SD[i]>>2)&0x03;
		Sd48[i*4+2]=(RtuDataAddr->Fk_Control_Set_Value.F18_Set_Para.ZD_GK_SD[i]>>4)&0x03;
		Sd48[i*4+3]=(RtuDataAddr->Fk_Control_Set_Value.F18_Set_Para.ZD_GK_SD[i]>>6)&0x03;

	}

	Temp=Sd48[0];
	RtuDataAddr->All_ShiD_Value[SdNo].startMin=0;
	for(i=0;i<48;i++)
	{
		if((Temp==0)||(Temp==3))
		{
			RtuDataAddr->All_ShiD_Value[SdNo].Valid=0;
		}
		else
		{
			RtuDataAddr->All_ShiD_Value[SdNo].Valid=1;
		}
		if(Temp!=Sd48[i])
		{
			RtuDataAddr->All_ShiD_Value[SdNo].endMin=NinCountTemp;
			Temp=Sd48[i];
			//printf("\n\rendMin=%d ",RtuDataAddr->All_ShiD_Value[SdNo].endMin);

			SdNo++;
			RtuDataAddr->All_ShiD_Value[SdNo].startMin=NinCountTemp;

			//printf("\n\rstartMin=%d ",RtuDataAddr->All_ShiD_Value[SdNo].startMin);
			//printf("\n\r");

		}
		NinCountTemp+=30;
		if(SdNo>=8)break;
	}
	RtuDataAddr->All_ShiD_Value[SdNo].endMin=NinCountTemp;
}
void initShiDuan(INT8U P)
{
	INT16U NinCountTemp;
	INT8U i,SdNo;
	NinCountTemp=0;
	SdNo=0;
	for(i=0;i<8;i++)
	{
		RtuDataAddr->ShiD_Kong_Value[P].Shiduan_value[i].Valid=0;
		RtuDataAddr->ShiD_Kong_Value[P].Shiduan_value[i].startMin=RtuDataAddr->All_ShiD_Value[i].startMin;
		RtuDataAddr->ShiD_Kong_Value[P].Shiduan_value[i].endMin=RtuDataAddr->All_ShiD_Value[i].endMin;
		RtuDataAddr->ShiD_Kong_Value[P].Shiduan_value[i].DingZhi=0;
	}
	for(i=0;i<8;i++)
	{
		if(RtuDataAddr->All_ShiD_Value[i].Valid==1)
		{
			RtuDataAddr->ShiD_Kong_Value[P].Shiduan_value[i].Valid=1;
		}
	}
}
void InitControlNow()
{
	INT8U i;
	RtuDataAddr->Fk_Control_Value_now.Valid=0;
	if((RtuDataAddr->Fk_Control_Value_now.Yaokong_TiaoZha_Stat!=0)
	||(RtuDataAddr->Fk_Control_Value_now.Now_CuiFei_Gaojing_Stat!=0))
	{
		RtuDataAddr->Fk_Control_Value_now.Valid=1;
	}
	for(i=0;i<ZongJia_Max;i++)
	{
		if((RtuDataAddr->FuKong_Control_Value.F9_Control_Para[i].Valid==1)||//ʱ�ι���Ͷ��
			(RtuDataAddr->FuKong_Control_Value.F10_Control_Para[i].Valid==1)||//���ݿ�
			(RtuDataAddr->FuKong_Control_Value.F11_Control_Para[i].Valid==1)||//Ӫҵ��ͣ��
			(RtuDataAddr->FuKong_Control_Value.F12_Control_Para[i].Valid==1)||//��ǰ�����¸���
			(RtuDataAddr->FuKong_Control_Value.F15_Control_Para[i].Valid==1)||//�µ�����
			(RtuDataAddr->FuKong_Control_Value.F16_Control_Para[i].Valid==1))//��������
		{
			//printf("\n\rzjno==%d F16 ==%d",i,RtuDataAddr->FuKong_Control_Value.F16_Control_Para[i].Valid);
			RtuDataAddr->Fk_Control_Value_now.Valid=1;
			RtuDataAddr->Fk_Control_Value_now.ZongJia_Valid_Stat=
			RtuDataAddr->Fk_Control_Value_now.ZongJia_Valid_Stat|(1<<i);
			//printf("\n\rZongJia_Valid_Stat==%x",RtuDataAddr->Fk_Control_Value_now.ZongJia_Valid_Stat);
		}
		else
		{
			//RtuDataAddr->Fk_Control_Value_now.ZongJia_Valid_Stat=RtuDataAddr->Fk_Control_Value_now.ZongJia_Valid_Stat&((1<<i)^0xff);
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].GongKong_Tiaozha_Stat=0;
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].YueDianKong_Tiaozha_Stat=0;
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].GouDiankong_TiaoZha_Stat=0;
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].GongKongYuexian_Alarm_Stat=0;
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].DianKongYuexian_Alarm_Stat=0;
		}
	}
}
void InitControlSet()
{
	INT8U i,DianKongStat,GongKongStat;
	DianKongStat=0;
	GongKongStat=0;
	if(RtuDataAddr->FuKong_Control_Value.F25_Control_Para.Valid==1)//�ն˱���Ͷ��
	{
		RtuDataAddr->Fk_Control_Set_now.BaoDian_TiChu_Gaojing_Tou=1;
		//SetSpiLed(BAODIAN_LED);
	}
	else
	{
		//ClearSpiLed(BAODIAN_LED);
		RtuDataAddr->Fk_Control_Set_now.BaoDian_TiChu_Gaojing_Tou=0;
	}
	if(RtuDataAddr->FuKong_Control_Value.F28_Control_Para.Valid==1)//�ն��޳�Ͷ��
	{
		RtuDataAddr->Fk_Control_Set_now.BaoDian_TiChu_Gaojing_Tou=
		RtuDataAddr->Fk_Control_Set_now.BaoDian_TiChu_Gaojing_Tou|0x02;
	}
	else
	{
		RtuDataAddr->Fk_Control_Set_now.BaoDian_TiChu_Gaojing_Tou=
		RtuDataAddr->Fk_Control_Set_now.BaoDian_TiChu_Gaojing_Tou&0x0d;
	}
	if(RtuDataAddr->FuKong_Control_Value.F26_Control_Para.Valid==1)//�߷Ѹ澯Ͷ��
	{
		RtuDataAddr->Fk_Control_Set_now.BaoDian_TiChu_Gaojing_Tou=RtuDataAddr->Fk_Control_Set_now.BaoDian_TiChu_Gaojing_Tou|0x04;
		RtuDataAddr->Fk_Control_Value_now.Now_CuiFei_Gaojing_Stat=1;
	}
	else
	{
		RtuDataAddr->Fk_Control_Set_now.BaoDian_TiChu_Gaojing_Tou=RtuDataAddr->Fk_Control_Set_now.BaoDian_TiChu_Gaojing_Tou&0xfb;
		RtuDataAddr->Fk_Control_Value_now.Now_CuiFei_Gaojing_Stat=0;
	}
	for(i=0;i<ZongJia_Max;i++)
	{
		if(((RtuDataAddr->Zj_Control_Value[i].F45_Set_Para.Valid==1)//���ؿ����۴�
			&&(RtuDataAddr->Fk_Control_Set_Value.F49_Set_Para[i].Valid==1))//���ظ澯ʱ��
			||(RtuDataAddr->Zj_Control_Value[i].F48_Set_Para.Valid==1))//��ؿ����۴�
		{
			if(
				((RtuDataAddr->Fk_Control_Set_Value.F19_Set_Para.Valid==1)//�ն˹���ʱ�ζ�ֵ����ϵ��
				&&(RtuDataAddr->Fk_Control_Set_Value.F18_Set_Para.Valid==1))||//�ն˹���ʱ��
				(RtuDataAddr->Zj_Control_Value[i].F43_Set_Para.Valid==1)||//�����¸���
				(RtuDataAddr->Zj_Control_Value[i].F42_Set_Para.Valid==1)||//���ݿ�
				(RtuDataAddr->Zj_Control_Value[i].F44_Set_Para.Valid==1)||//Ӫҵ��ͣ��
				(RtuDataAddr->Zj_Control_Value[i].F46_Set_Para.Valid==1)||//�µ�����
				(RtuDataAddr->Zj_Control_Value[i].F47_Set_Para.Valid==1)//��������
				)
			{
				//printf("\n\rzjno==%d F47 ==%d",i,RtuDataAddr->Zj_Control_Value[i].F47_Set_Para.Valid);
				RtuDataAddr->Fk_Control_Set_now.Valid=1;
				RtuDataAddr->Fk_Control_Set_now.ZongJia_Valid=RtuDataAddr->Fk_Control_Set_now.ZongJia_Valid|(1<<i);
				//printf("\n\rZongJia_Valid==%x",RtuDataAddr->Fk_Control_Set_now.ZongJia_Valid);
				RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[i].GongKongLunCi_Stat=RtuDataAddr->Zj_Control_Value[i].F45_Set_Para.GongKong_Lunci_Biaozhi;//ShiD_Kong_Value[ZjNo].LunCi;
				RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[i].DianKongLunCi_Stat=RtuDataAddr->Zj_Control_Value[i].F48_Set_Para.DianKong_Lunci_Biaozhi;//ShiD_Kong_Value[ZjNo].LunCi;
				if((RtuDataAddr->FuKong_Control_Value.F9_Control_Para[i].Valid==1)||
					(RtuDataAddr->FuKong_Control_Value.F10_Control_Para[i].Valid==1)||
					(RtuDataAddr->FuKong_Control_Value.F11_Control_Para[i].Valid==1)||
					(RtuDataAddr->FuKong_Control_Value.F12_Control_Para[i].Valid==1))
				{
					GongKongStat=1;
				}
				else
				{
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].GongKong_Tiaozha_Stat=0;
				}
				if(RtuDataAddr->FuKong_Control_Value.F9_Control_Para[i].Valid==1)//ʱ�ι���Ͷ��
				{
					RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[i].FangAnNo = (RtuDataAddr->FuKong_Control_Value.F9_Control_Para[i].ShiDuan_Tou_FangAn_No&0x03);
					RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[i].GongKong_Stat=RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[i].GongKong_Stat|0x01;
				}
				else
				{
					RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[i].GongKong_Stat=RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[i].GongKong_Stat&0xfe;
				}
				if(RtuDataAddr->FuKong_Control_Value.F10_Control_Para[i].Valid==1)//���ݿ�
				{
					RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[i].GongKong_Stat=RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[i].GongKong_Stat|0x02;
				}
				else
				{
					RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[i].GongKong_Stat=RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[i].GongKong_Stat&0xfd;
				}
				if(RtuDataAddr->FuKong_Control_Value.F11_Control_Para[i].Valid==1)//Ӫҵ��ͣ��
				{
					RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[i].GongKong_Stat=RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[i].GongKong_Stat|0x04;
				}
				else
				{
					RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[i].GongKong_Stat=RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[i].GongKong_Stat&0xfb;
				}
				if(RtuDataAddr->FuKong_Control_Value.F12_Control_Para[i].Valid==1)//��ǰ�����¸���
				{
					RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[i].GongKong_Stat=RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[i].GongKong_Stat|0x08;
				}
				else
				{
					RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[i].GongKong_Stat=RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[i].GongKong_Stat&0xf7;
				}
				if((RtuDataAddr->FuKong_Control_Value.F15_Control_Para[i].Valid==1)
				||(RtuDataAddr->FuKong_Control_Value.F16_Control_Para[i].Valid==1))
				{
					DianKongStat=1;
				}
				else
				{
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].YueDianKong_Tiaozha_Stat=0;
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].GouDiankong_TiaoZha_Stat=0;
				}
				if(RtuDataAddr->FuKong_Control_Value.F15_Control_Para[i].Valid==1)//�µ�����
				{
					RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[i].DianKong_Stat=RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[i].DianKong_Stat|0x01;
				}
				else
				{
					RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[i].DianKong_Stat=RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[i].DianKong_Stat&0xfe;
				}
				if(RtuDataAddr->FuKong_Control_Value.F16_Control_Para[i].Valid==1)//��������
				{
					RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[i].DianKongLunCi_Stat=RtuDataAddr->Zj_Control_Value[i].F48_Set_Para.DianKong_Lunci_Biaozhi;
					RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[i].DianKong_Stat=RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[i].DianKong_Stat|0x02;
				}
				else
				{
					RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[i].DianKong_Stat=RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[i].DianKong_Stat&0xfd;
				}
			}
			else
			{
				RtuDataAddr->Fk_Control_Set_now.ZongJia_Valid=RtuDataAddr->Fk_Control_Set_now.ZongJia_Valid&((1<<i)^0xff);
				RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[i].GongKong_Stat=0;
				RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[i].DianKong_Stat=0;
			}
		}
		else
		{
			RtuDataAddr->Fk_Control_Set_now.ZongJia_Valid=RtuDataAddr->Fk_Control_Set_now.ZongJia_Valid&((1<<i)^0xff);
			RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[i].GongKongLunCi_Stat=RtuDataAddr->Zj_Control_Value[i].F45_Set_Para.GongKong_Lunci_Biaozhi;//ShiD_Kong_Value[ZjNo].LunCi;
			RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[i].DianKongLunCi_Stat=RtuDataAddr->Zj_Control_Value[i].F48_Set_Para.DianKong_Lunci_Biaozhi;//ShiD_Kong_Value[ZjNo].LunCi;
		}
	}
	if(GongKongStat==1)
	{
		SetSpiLed(GKACT);
		//ClearSpiLed(All_LunCi);//gai
	}
	else
	{
		ClearSpiLed(GKACT);
	}
	if(DianKongStat==1)
	{
		SetSpiLed(DKACT);
		//ClearSpiLed(All_LunCi);//gai
	}
	else
	{
		ClearSpiLed(DKACT);
	}
}
INT8U ControlLunCiSet(INT8U NeedControl,INT8U MinCount)
{
	INT8U i,re;
	INT16U Timecount;
	Timecount=0;
	re=0;

	for(i=0;i<Control_Lunci_Max;i++)
	{
		if((NeedControl&(1<<i))==(1<<i))
		{
			Timecount=Timecount+RtuDataAddr->Fk_Control_Set_Value.F49_Set_Para[i].GK_Alarm_Time;
			if(MinCount>=Timecount)
			{
				re=re|(1<<i);
			}
			else
			{
				DBControlPr("\r\n��բ״̬%d %d %x",Timecount,MinCount,re);
				return re;
			}
		}
	}
	DBControlPr("\r\n��բ״̬%d %d %x",Timecount,MinCount,re);
	return re;
}
INT8U DoGouDiankong(INT8U ZjNo,INT8U OldMin,TS ts)
{
	//signed int OneMin_DianLiang=0;
	int men,sheng,i;
	//DBControlPr("DoGouDiankong...");
	if(RtuDataAddr->FuKong_Control_Value.F16_Control_Para[ZjNo].Valid!=1)
	{
		RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GouDiankong_TiaoZha_Stat=0;
		RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GouDianControlStatTmp=0;
		RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GouDianKongTime=0;
		memset(&GouFirstFlag[ZjNo][0],0,4);
	}
	else
	{
		if((RtuDataAddr->Zj_Control_Value[ZjNo].F47_Set_Para.Valid==1))//����ز���
			//&&(RtuDataAddr->Zj_Control_Value[ZjNo].F48_Set_Para.Valid==1)  )//��ؿ����۴�
		{
			RtuDataAddr->Gou_Dian_Kong_Value[ZjNo].LunCi=RtuDataAddr->Zj_Control_Value[ZjNo].F48_Set_Para.DianKong_Lunci_Biaozhi;
			RtuDataAddr->Gou_Dian_Kong_Value[ZjNo].GouDianLiangZhi=GetdataType03(&RtuDataAddr->Zj_Control_Value[ZjNo].F47_Set_Para.Gou_DIan_Value[0]);
			men = GetdataType03(&RtuDataAddr->Zj_Control_Value[ZjNo].F47_Set_Para.Alarm_Men[0]);
			RtuDataAddr->Gou_Dian_Kong_Value[ZjNo].BaoJingMen=men;
			RtuDataAddr->Gou_Dian_Kong_Value[ZjNo].TiaozhaMen=GetdataType03(&RtuDataAddr->Zj_Control_Value[ZjNo].F47_Set_Para.TiaoZha_Men[0]);
		}
		else
		{
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GouDiankong_TiaoZha_Stat=0;
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].DianKongYuexian_Alarm_Stat=0;
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GouDianControlStatTmp=0;
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GouDianKongTime=0;
			memset(&GouFirstFlag[ZjNo][0],0,4);
			return 0;
		}
		DBControlPr("In Gou dian kong ");
		men = RtuDataAddr->Gou_Dian_Kong_Value[ZjNo].TiaozhaMen;
		sheng=RtuDataAddr->Real_Zj_Value[ZjNo].ShengYuDianLiang;

		//CTPrint("\n\rGOUDIAN- men =%d   sheng =%d  baojingmen = %d",men,sheng,RtuDataAddr->Gou_Dian_Kong_Value[ZjNo].BaoJingMen);
		DBControlPr("\n\rGOUDIAN- men =%d   sheng =%d  baojingmen = %d",men,sheng,RtuDataAddr->Gou_Dian_Kong_Value[ZjNo].BaoJingMen);

		if(sheng<=men)
		{
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GouDianControlStatTmp=
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GouDiankong_TiaoZha_Stat
			=RtuDataAddr->Gou_Dian_Kong_Value[ZjNo].LunCi;
			DBControlPr("\n\rGouDiankong_TiaoZha_Stat===%d",RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GouDiankong_TiaoZha_Stat);
			//CTPrint("\n\rGouDiankong_TiaoZha_Stat===%d",RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GouDiankong_TiaoZha_Stat);

			if(OldMin!=ts.Minute)RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GouDianKongTime++;
			DBControlPr("\n\rdiankongptr==%d",diankongptr);
			if(OldMin!=ts.Minute)
			{
				for(i=diankongptr;i<4;i++)
					if(RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GouDianControlStatTmp&(0x01<<(i)))
					{
						RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GouDianControlStatTmp=RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GouDianControlStatTmp&(0x01<<(i));
						DBControlPr("\n\ri===%d",i);
						break;
					}
				RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].DianKongYuexian_Alarm_Stat=0;
				//if(RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GouDianControlStatTmp)
					//RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].DianKongYuexian_Alarm_Stat=
					//	RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].DianKongYuexian_Alarm_Stat|0x02;
				diankongptr=i+1;
				if(diankongptr>=4)
					diankongptr=0;
			}

			if(RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GouDianKongTime>=200)
				RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GouDianKongTime=200;
		}
		else
		{
			if(RtuDataAddr->Real_Zj_Value[ZjNo].ShengYuDianLiang<=RtuDataAddr->Gou_Dian_Kong_Value[ZjNo].BaoJingMen)
			{//ִ�и澯
				sprintf((char *)RtuDataAddr->SendMessage,"�ܼ���%d����ظ澯\n������ %dKwh\n��ǰ���� %dKwh\n�澯����%dKwh"
				,ZjNo+1
				,RtuDataAddr->Gou_Dian_Kong_Value[ZjNo].GouDianLiangZhi
				,RtuDataAddr->Real_Zj_Value[ZjNo].P_All
				,RtuDataAddr->Gou_Dian_Kong_Value[ZjNo].BaoJingMen);
				OutScreen();
				RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].DianKongYuexian_Alarm_Stat=RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].DianKongYuexian_Alarm_Stat|0x02;
				//printf("\n\rRtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[%d].DianKongYuexian_Alarm_Stat==%d",ZjNo,RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].DianKongYuexian_Alarm_Stat);
				RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GouDiankong_TiaoZha_Stat=0;
				RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GouDianControlStatTmp=0;
				RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GouDianKongTime=0;

			}
			else
			{
				sprintf((char *)RtuDataAddr->SendMessage,"�ܼ���%d�����Ͷ��\n������ %dKwh\n��ǰ���� %dKwh"
				,ZjNo+1
				,RtuDataAddr->Gou_Dian_Kong_Value[ZjNo].GouDianLiangZhi
				,RtuDataAddr->Real_Zj_Value[ZjNo].P_All);
				OutScreen();
				RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].DianKongYuexian_Alarm_Stat=RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].DianKongYuexian_Alarm_Stat&0xfd;

				RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GouDiankong_TiaoZha_Stat=0;
				RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GouDianControlStatTmp=0;
				RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GouDianKongTime=0;
			}
			diankongptr=0;
			memset(&GouFirstFlag[ZjNo][0],0,4);
		}
	}
	return 0;
}
INT8U DoYueDianKong(INT8U ZjNo,INT8U OldMin,INT8U OldMonth,TS ts)
{
	INT32U t;
	INT8U xs=0,i;

	//if(OldMonth!=ts.Month)
	//	RtuDataAddr->FuKong_Control_Value.F15_Control_Para[ZjNo].Valid=0;

	if(RtuDataAddr->FuKong_Control_Value.F15_Control_Para[ZjNo].Valid!=1)
	{
		RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YueDianKong_Tiaozha_Stat=0;
		RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YueDianControlStatTmp=0;
		RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YueDianKongTime=0;
		memset(&YueFirstFlag[ZjNo][0],0,4);
	}
	else
	{
		if((RtuDataAddr->Zj_Control_Value[ZjNo].F46_Set_Para.Valid==1))//�µ����ض�ֵ
			//&&(RtuDataAddr->Zj_Control_Value[ZjNo].F48_Set_Para.Valid==1)  )//��ؿ����۴�
		{
			DBControlPr("In Yue dian kong ");
			t=GetdataType03(&RtuDataAddr->Zj_Control_Value[ZjNo].F46_Set_Para.Yue_DIan_Liang_Kong[0]);
			if(RtuDataAddr->Fk_Control_Set_Value.F20_Set_Para.Valid==1)
			{
				if(RtuDataAddr->Fk_Control_Set_Value.F20_Set_Para.ZD_Yue_DK_DZ_FD&0x80)
				{
					xs=100-(((RtuDataAddr->Fk_Control_Set_Value.F20_Set_Para.ZD_Yue_DK_DZ_FD>>4)&0x07)*10)+(RtuDataAddr->Fk_Control_Set_Value.F20_Set_Para.ZD_Yue_DK_DZ_FD&0x0f);
				}
				else
				{
					xs=100+(((RtuDataAddr->Fk_Control_Set_Value.F20_Set_Para.ZD_Yue_DK_DZ_FD>>4)&0x07)*10)+(RtuDataAddr->Fk_Control_Set_Value.F20_Set_Para.ZD_Yue_DK_DZ_FD&0x0f);
				}
			}
			else
				xs=100;
			t=t*xs/100;
			RtuDataAddr->Yue_Dian_Kong_Value[ZjNo].DingZhi=t;
			RtuDataAddr->Yue_Dian_Kong_Value[ZjNo].LunCi=RtuDataAddr->Zj_Control_Value[ZjNo].F48_Set_Para.DianKong_Lunci_Biaozhi;
		}
		else
		{
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YueDianKong_Tiaozha_Stat=0;
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YueDianControlStatTmp=0;
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YueDianKongTime=0;
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].DianKongYuexian_Alarm_Stat=0;
			memset(&YueFirstFlag[ZjNo][0],0,4);
			return 1;
		}
		DBControlPr("\n\rRtuDataAddr->Real_Zj_Value[%d].P_All=%d",ZjNo,RtuDataAddr->Real_Zj_Value[ZjNo].P_All);
		DBControlPr("\n\rRtuDataAddr->Yue_Zj_Value[%d].P_All=%d",ZjNo,RtuDataAddr->Yue_Zj_Value[ZjNo].P_All);
		DBControlPr("\n\rRtuDataAddr->Yue_Dian_Kong_Value[%d].DingZhi=%d",ZjNo,RtuDataAddr->Yue_Dian_Kong_Value[ZjNo].DingZhi);
		if((RtuDataAddr->Real_Zj_Value[ZjNo].P_All-RtuDataAddr->Yue_Zj_Value[ZjNo].P_All)>=RtuDataAddr->Yue_Dian_Kong_Value[ZjNo].DingZhi)
		{//ִ�п���
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YueDianControlStatTmp=
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YueDianKong_Tiaozha_Stat=RtuDataAddr->Yue_Dian_Kong_Value[ZjNo].LunCi;
			if(OldMin!=ts.Minute)RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YueDianKongTime++;
			if(OldMin!=ts.Minute)
			{
				for(i=diankongptr;i<4;i++)
					if(RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YueDianControlStatTmp&(0x01<<(i)))
					{
						RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YueDianControlStatTmp=RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YueDianControlStatTmp&(0x01<<(i));
						break;
					}
				RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].DianKongYuexian_Alarm_Stat=0;
				//if(RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YueDianControlStatTmp)
				//	RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].DianKongYuexian_Alarm_Stat=RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].DianKongYuexian_Alarm_Stat|0x01;
				diankongptr=i+1;
				if(diankongptr>=4)
					diankongptr=0;
			}

			if(RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YueDianKongTime>200)
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YueDianKongTime=200;
		}
		else
		{
			if((RtuDataAddr->Real_Zj_Value[ZjNo].P_All-RtuDataAddr->Yue_Zj_Value[ZjNo].P_All)>=(RtuDataAddr->Yue_Dian_Kong_Value[ZjNo].DingZhi*0.8))
			{//ִ�и澯
				RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].DianKongYuexian_Alarm_Stat=RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].DianKongYuexian_Alarm_Stat|0x01;
			}
			else
			{
				RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].DianKongYuexian_Alarm_Stat=RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].DianKongYuexian_Alarm_Stat&0xfe;
			}
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YueDianKong_Tiaozha_Stat=0;
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YueDianControlStatTmp=0;
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YueDianKongTime=0;
			memset(&YueFirstFlag[ZjNo][0],0,4);
			diankongptr=0;
		}
	}
	return 1;
}
INT8U DoGlvControl(INT8U ZjNo,INT8U OldMin,TS ts)
{
	INT8U j,k,i;
	INT32S DingZhi,tmpba;
	GKT1=0;
	j=0;
	i=0;
	if(RtuDataAddr->FuKong_Control_Value.F12_Control_Para[ZjNo].Valid!=1)
	{
		RtuDataAddr->Gonglv_XiaFu_Value[ZjNo].Valid=0;
		RtuDataAddr->Gonglv_XiaFu_Value[ZjNo].HuaChaTime=0;
		RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongStat=0;
		//RtuDataAddr->GongKongStattmp[ZjNo]=0;
		RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GonglVKongTiaoTime=0;
		RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GonglVKongTime=0;
		RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongStat=0;
		RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKong_Tiaozha_Stat=0;
		GLvKong_flag[ZjNo]=0;
		//printf("\n\r gonglv kong RtuDataAddr->GongKongStattmp[ZjNo]=0!!!");
		return 0;
	}
	else
	{
		tmpba=GetDataType02(RtuDataAddr->Fk_Control_Set_Value.F17_Set_Para.Bao_An_DingZhi);
		//if(tmpba!=0)
		{
			//������ֵ�Ƿ�Ϊ0
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongLeiBie=0x08;
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YingYeKongStat=0;
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YingYeKongTiaoTime=0;
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YingYeKongTime=0;
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ChangXiuKongStat=0;
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ChangXiuKongTiaoTime=0;
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ChangXiuKongTime=0;
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ShiDuanKongStat=0;
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ShiDuanKongTiaoTime=0;
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ShiDuanKongTime=0;

			RtuDataAddr->Gonglv_XiaFu_Value[ZjNo].LunCi=RtuDataAddr->Zj_Control_Value[ZjNo].F45_Set_Para.GongKong_Lunci_Biaozhi;
			if(RtuDataAddr->Gonglv_XiaFu_Value[ZjNo].Valid!=1)
			{
				DBControlPr("\r\nZj_Control_Value[ZjNo].F45_Set_Para.Valid=%d",RtuDataAddr->Zj_Control_Value[ZjNo].F45_Set_Para.Valid);
				if(RtuDataAddr->Zj_Control_Value[ZjNo].F45_Set_Para.Valid==1)//���ؿ����۴�
				{
					if(RtuDataAddr->FuKong_Control_Value.F12_Control_Para[ZjNo].Gonglv_Xiafu_HuaCXha_Time<=0)
						RtuDataAddr->FuKong_Control_Value.F12_Control_Para[ZjNo].Gonglv_Xiafu_HuaCXha_Time=2;
				    RtuDataAddr->Gonglv_XiaFu_Value[ZjNo].HuaChaTime=RtuDataAddr->FuKong_Control_Value.F12_Control_Para[ZjNo].Gonglv_Xiafu_HuaCXha_Time;
				   //printf("\n\rRtuDataAddr->Zj_HC_Buff[%d].GLRecCount===%d",ZjNo,RtuDataAddr->Zj_HC_Buff[ZjNo].GLRecCount);

				   if(RtuDataAddr->Zj_HC_Buff[ZjNo].GLRecCount>RtuDataAddr->FuKong_Control_Value.F12_Control_Para[ZjNo].Gonglv_Xiafu_HuaCXha_Time)
					{
						RtuDataAddr->Zj_HC_Buff[ZjNo].Tail=(RtuDataAddr->Zj_HC_Buff[ZjNo].Head+70-RtuDataAddr->Gonglv_XiaFu_Value[ZjNo].HuaChaTime)%70;
						while(RtuDataAddr->Zj_HC_Buff[ZjNo].Tail!=RtuDataAddr->Zj_HC_Buff[ZjNo].Head)
						{
							GKT1=GKT1+RtuDataAddr->Zj_HC_Buff[ZjNo].P_Buff[RtuDataAddr->Zj_HC_Buff[ZjNo].Tail];
							RtuDataAddr->Zj_HC_Buff[ZjNo].Tail=(RtuDataAddr->Zj_HC_Buff[ZjNo].Tail+1)%70;
							j++;
						}
						if(j!=0)//�����¸��ػ���ʱ������ܼ����ƽ������
						{
							GKT1=((GKT1*10)/j);
						}
						else
						{
							GKT1=RtuDataAddr->Zj_HC_Buff[ZjNo].P_Buff[RtuDataAddr->Zj_HC_Buff[ZjNo].Tail]*10;
						}
						//CTPrint("\n\rXIAFU GKT1===%d",GKT1);
						//printf("\n\rXIAFU GKT1===%d",GKT1);
						RtuDataAddr->Gonglv_XiaFu_Value[ZjNo].DingZhi=GKT1;
						RtuDataAddr->Gonglv_XiaFu_Value[ZjNo].Valid=1;
						return 1;
					}
					return 1;
				}
			}
			else
			{

				k=RtuDataAddr->FuKong_Control_Value.F12_Control_Para[ZjNo].Gonglv_Xiafu_HuaCXha_XiShu;
				if(k&0x80)
				{
					k=(((k>>4)&0x07)*10)+(k&0x0f);
					k=100-k;
				}
				else
				{
					k=(((k>>4)&0x07)*10)+(k&0x0f);
					k=100+k;
				}
				RtuDataAddr->Gonglv_XiaFu_Value[ZjNo].XiaFuDingZhi_xishu=k;
				DingZhi=(RtuDataAddr->Gonglv_XiaFu_Value[ZjNo].DingZhi*k)/100;
				Create_Data_Type02(DingZhi/10,&RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].Now_GongKong_DingZhi[0]);//�����¸�ϵ����ƽ�����ʼ����¸��ض�ֵ
				RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].Now_GomhLv_Xiafukong_xishu=RtuDataAddr->FuKong_Control_Value.F12_Control_Para[ZjNo].Gonglv_Xiafu_HuaCXha_XiShu;
				GKT1=RtuDataAddr->Real_Zj_Value[ZjNo].P;
				//DBControlPr("now glv=%d dingzhi=%d %d",GKT1,DingZhi,ZjNo);
				//CTPrint("\n\rXIAFU- dingzhi===%d  GKT1 =%d  ZjNo = %d baoan = %d",DingZhi,GKT1,ZjNo,tmpba);
				//printf("\n\rXIAFU- DingZhi===%d  GKT1===%d",DingZhi,GKT1);
				if(DingZhi<(tmpba))//sun
				{
					DingZhi=tmpba;
				}
				if(DingZhi<=0)return 1;
				if((GKT1*10)>=DingZhi)
				{
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKong_Tiaozha_Stat=RtuDataAddr->Gonglv_XiaFu_Value[ZjNo].LunCi;
					if(GLvKong_flag[ZjNo]==0)
					{
						GLvKong_flag[ZjNo]=RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKong_Tiaozha_Stat;
					}
					for(i=0;i<Control_Lunci_Max;i++)
					{
						if(GLvKong_flag[ZjNo]&(1<<i))
							break;
					}
					if(OldMin!=ts.Minute)RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GonglVKongTime++;
					if(RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GonglVKongTime>200)RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GonglVKongTime=200;
					if(RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKong_Tiaozha_Stat!=0)
						if(OldMin!=ts.Minute)
							RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GonglVKongTiaoTime++;

					if(RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GonglVKongTiaoTime>200)
						RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GonglVKongTiaoTime=200;
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongTiaoTime = RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GonglVKongTiaoTime;
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongYuexian_Alarm_Stat= RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongYuexian_Alarm_Stat|0x08;
					if(RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GonglVKongTime>=RtuDataAddr->Fk_Control_Set_Value.F49_Set_Para[i].GK_Alarm_Time)
					{
						RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongStat=(1<<i);
						RtuDataAddr->GongKongStattmp[ZjNo]=RtuDataAddr->GongKongStattmp[ZjNo]|(1<<i);
						//printf("\n\rxiafakong---RtuDataAddr->GongKongStattmp[%d]=%d",ZjNo,RtuDataAddr->GongKongStattmp[ZjNo]);
						RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongYuexian_Alarm_Stat=0;
						RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GonglVKongTime=0;
						////////////////////////////////////////////////////////////////////
					}
				}
				else
				{
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKong_Tiaozha_Stat=0;//Gonglv_XiaFu_Value[ZjNo].LunCi&(Gonglv_XiaFu_Value[ZjNo].LunCi^0xff);
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongTiaoTime=0;
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongStat=0;//Gonglv_XiaFu_Value[ZjNo].LunCi&(Gonglv_XiaFu_Value[ZjNo].LunCi^0xff);
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GonglVKongTime=0;
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongStat=0;
					//RtuDataAddr->GongKongStattmp[ZjNo]=0;
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GonglVKongTiaoTime=0;//Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GonglVKongTime;
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongYuexian_Alarm_Stat=0;//Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongYuexian_Alarm_Stat|0x01;
					GLvKong_flag[ZjNo]=0;
				}
				return 1;
			}
		}
	}
	return 1;
}
INT8U DoYingYeControl(INT8U ZjNo,INT8U OldMin,TS ts)
{
	INT8U Y,M,D,j,i;
	INT32U temp,tmpba;
	GKT1=0;
	j=0;
	i=0;
	if(RtuDataAddr->FuKong_Control_Value.F11_Control_Para[ZjNo].Valid!=1)
	{
		RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YingYeKongStat=0;
		RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YingYeKongTiaoTime=0;
		RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YingYeKongTime=0;
		RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongStat=0;
		RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongStat=0;
		//RtuDataAddr->GongKongStattmp[ZjNo]=0;
		RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKong_Tiaozha_Stat=0;
		YingYeKong_flag[ZjNo]=0;
		return 0;
	}
	else
	{
		tmpba=GetDataType02(RtuDataAddr->Fk_Control_Set_Value.F17_Set_Para.Bao_An_DingZhi);//sun
		//if(tmpba!=0)//sun
		{
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongLeiBie=0x04;
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ChangXiuKongStat=0;
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ChangXiuKongTiaoTime=0;
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ChangXiuKongTime=0;
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ShiDuanKongStat=0;
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ShiDuanKongTiaoTime=0;
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ShiDuanKongTime=0;

			if((RtuDataAddr->Zj_Control_Value[ZjNo].F44_Set_Para.Valid==1)
				&&(RtuDataAddr->Zj_Control_Value[ZjNo].F45_Set_Para.Valid==1)  )//���ؿ����۴�
			{
				Y=(RtuDataAddr->Zj_Control_Value[ZjNo].F44_Set_Para.BaoTing_Start[2]>>4)*10+(RtuDataAddr->Zj_Control_Value[ZjNo].F44_Set_Para.BaoTing_Start[2]&0x0f);
				M=(RtuDataAddr->Zj_Control_Value[ZjNo].F44_Set_Para.BaoTing_Start[1]>>4)*10+(RtuDataAddr->Zj_Control_Value[ZjNo].F44_Set_Para.BaoTing_Start[1]&0x0f);
				D=(RtuDataAddr->Zj_Control_Value[ZjNo].F44_Set_Para.BaoTing_Start[0]>>4)*10+(RtuDataAddr->Zj_Control_Value[ZjNo].F44_Set_Para.BaoTing_Start[0]&0x0f);
				RtuDataAddr->YingyeBaoting_Value[ZjNo].Day_start=Y*372+M*31+D;

				Y=(RtuDataAddr->Zj_Control_Value[ZjNo].F44_Set_Para.BaoTing_End[2]>>4)*10+(RtuDataAddr->Zj_Control_Value[ZjNo].F44_Set_Para.BaoTing_End[2]&0x0f);
				M=(RtuDataAddr->Zj_Control_Value[ZjNo].F44_Set_Para.BaoTing_End[1]>>4)*10+(RtuDataAddr->Zj_Control_Value[ZjNo].F44_Set_Para.BaoTing_End[1]&0x0f);
				D=(RtuDataAddr->Zj_Control_Value[ZjNo].F44_Set_Para.BaoTing_End[0]>>4)*10+(RtuDataAddr->Zj_Control_Value[ZjNo].F44_Set_Para.BaoTing_End[0]&0x0f);
				RtuDataAddr->YingyeBaoting_Value[ZjNo].Day_End=Y*372+M*31+D;
				RtuDataAddr->YingyeBaoting_Value[ZjNo].DingZhi=GetDataType02(&RtuDataAddr->Zj_Control_Value[ZjNo].F44_Set_Para.BaoTing_Kong_Dingzhi[0]);
				RtuDataAddr->YingyeBaoting_Value[ZjNo].LunCi=RtuDataAddr->Zj_Control_Value[ZjNo].F45_Set_Para.GongKong_Lunci_Biaozhi;
			}
			else
			{
				RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YingYeKongStat=0;
				RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YingYeKongTiaoTime=0;
				RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YingYeKongTime=0;
				RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongStat=0;
				RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongStat=0;
				RtuDataAddr->GongKongStattmp[ZjNo]=0;
				//printf("\n\r yingye RtuDataAddr->GongKongStattmp[ZjNo]=0!!!");
				return 0;
			}

			temp=(ts.Year%100)*372+ts.Month*31+ts.Day;
			//printf("\n\ryingyedaoting- temp=%d Day_start=%d Day_End=%d",temp,RtuDataAddr->YingyeBaoting_Value[ZjNo].Day_start,RtuDataAddr->YingyeBaoting_Value[ZjNo].Day_End);
			//CTPrint("\n\ryingyedaoting- temp=%d Day_start=%d Day_End=%d",temp,RtuDataAddr->YingyeBaoting_Value[ZjNo].Day_start,RtuDataAddr->YingyeBaoting_Value[ZjNo].Day_End);

			Create_Data_Type02(RtuDataAddr->YingyeBaoting_Value[ZjNo].DingZhi/10,&RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].Now_GongKong_DingZhi[0]);
			if((temp>=RtuDataAddr->YingyeBaoting_Value[ZjNo].Day_start)&&(temp<RtuDataAddr->YingyeBaoting_Value[ZjNo].Day_End))
			{
				if(RtuDataAddr->Zj_HC_Buff[ZjNo].GLRecCount>RtuDataAddr->Zj_Control_Value[ZjNo].F43_Set_Para.DongLv_HuaCha_Time)
				{
					if(RtuDataAddr->Zj_Control_Value[ZjNo].F43_Set_Para.Valid!=1)
						RtuDataAddr->Zj_Control_Value[ZjNo].F43_Set_Para.DongLv_HuaCha_Time=2;
					RtuDataAddr->Zj_HC_Buff[ZjNo].Tail=(RtuDataAddr->Zj_HC_Buff[ZjNo].Head+70-RtuDataAddr->Zj_Control_Value[ZjNo].F43_Set_Para.DongLv_HuaCha_Time)%70;
					while(RtuDataAddr->Zj_HC_Buff[ZjNo].Tail!=RtuDataAddr->Zj_HC_Buff[ZjNo].Head)
					{
						GKT1=GKT1+RtuDataAddr->Zj_HC_Buff[ZjNo].P_Buff[RtuDataAddr->Zj_HC_Buff[ZjNo].Tail];
						RtuDataAddr->Zj_HC_Buff[ZjNo].Tail=(RtuDataAddr->Zj_HC_Buff[ZjNo].Tail+1)%70;
						j++;
					}

					if(j!=0)//�����¸��ػ���ʱ������ܼ����ƽ������
					{
						GKT1=(GKT1/j)*10;
					}
					else
					{
						GKT1=RtuDataAddr->Zj_HC_Buff[ZjNo].P_Buff[RtuDataAddr->Zj_HC_Buff[ZjNo].Tail]*10;
					}
				}
				if(RtuDataAddr->YingyeBaoting_Value[ZjNo].DingZhi<(tmpba))//sun
					RtuDataAddr->YingyeBaoting_Value[ZjNo].DingZhi=	tmpba;//sun
				//printf("\n\ryingyebaoting- GKT1==%d DingZhi==%d",GKT1,RtuDataAddr->YingyeBaoting_Value[ZjNo].DingZhi);
				//CTPrint("\n\ryingyebaoting- GKT1==%d DingZhi==%d",GKT1,RtuDataAddr->YingyeBaoting_Value[ZjNo].DingZhi);
				if(GKT1>=(RtuDataAddr->YingyeBaoting_Value[ZjNo].DingZhi))//sun
				{
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKong_Tiaozha_Stat=RtuDataAddr->YingyeBaoting_Value[ZjNo].LunCi;
					if(YingYeKong_flag[ZjNo]==0)
					{
						YingYeKong_flag[ZjNo]=RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKong_Tiaozha_Stat;
					}
					for(i=0;i<Control_Lunci_Max;i++)
					{
						if(YingYeKong_flag[ZjNo]&(1<<i))
							break;
					}
					if(OldMin!=ts.Minute)RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YingYeKongTime++;
					if(RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YingYeKongTime>200)
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YingYeKongTime=200;
					if(RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YingYeKongStat!=0)
					if(OldMin!=ts.Minute)RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YingYeKongTiaoTime++;
					if(RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YingYeKongTiaoTime>200)
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YingYeKongTiaoTime=200;
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongTiaoTime=RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YingYeKongTiaoTime;
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongYuexian_Alarm_Stat=RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongYuexian_Alarm_Stat|0x04;
					if(RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YingYeKongTime>=RtuDataAddr->Fk_Control_Set_Value.F49_Set_Para[i].GK_Alarm_Time)
					{
						RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongStat=RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongStat|(1<<i);
						RtuDataAddr->GongKongStattmp[ZjNo]=RtuDataAddr->GongKongStattmp[ZjNo]|(1<<i);
						RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongYuexian_Alarm_Stat=0;
						RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YingYeKongTime=0;
						//printf("\n\ryingye---RtuDataAddr->GongKongStattmp[%d]=%d",ZjNo,RtuDataAddr->GongKongStattmp[ZjNo]);
					}
				}
				else
				{
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKong_Tiaozha_Stat=0;//YingyeBaoting_Value[ZjNo].LunCi&(YingyeBaoting_Value[ZjNo].LunCi^0xff);
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongTiaoTime=0;
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YingYeKongStat=0;//YingyeBaoting_Value[ZjNo].LunCi&(YingyeBaoting_Value[ZjNo].LunCi^0xff);
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YingYeKongTime=0;
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YingYeKongTiaoTime=0;
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongStat=0;
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongStat=0;
					RtuDataAddr->GongKongStattmp[ZjNo]=0;
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongYuexian_Alarm_Stat=0;//Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongYuexian_Alarm_Stat|0x01;
					YingYeKong_flag[ZjNo]=0;
					//printf("\n\r yingye 2 RtuDataAddr->GongKongStattmp[ZjNo]=0!!!");
				}
				return 1;
			}
			else
			{
				RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKong_Tiaozha_Stat=0;//YingyeBaoting_Value[ZjNo].LunCi&(YingyeBaoting_Value[ZjNo].LunCi^0xff);
				RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongTiaoTime=0;
				RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YingYeKongStat=0;//YingyeBaoting_Value[ZjNo].LunCi&(YingyeBaoting_Value[ZjNo].LunCi^0xff);
				RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YingYeKongTime=0;
				RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].YingYeKongTiaoTime=0;
				RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongStat=0;
				RtuDataAddr->GongKongStattmp[ZjNo]=0;
				RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongYuexian_Alarm_Stat=0;//Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongYuexian_Alarm_Stat|0x01;
				YingYeKong_flag[ZjNo]=0;
				//printf("\n\r yingye 3 RtuDataAddr->GongKongStattmp[ZjNo]=0!!!");
			}
			return 1;
		}
	}
	return 1;
}
INT8U DoChangXiuControl(INT8U ZjNo,INT8U OldMin,TS ts)
{
	INT8U Min,Hour,j,i;
	INT8U h;
	INT32U tmpba;
	j=0;
	i=0;
	GKT1=0;
	if(RtuDataAddr->FuKong_Control_Value.F10_Control_Para[ZjNo].Valid!=1)
	{
		RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ChangXiuKongStat=0;
		RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ChangXiuKongTiaoTime=0;
		RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ChangXiuKongTime=0;
		RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongStat=0;
		RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongStat=0;
		//RtuDataAddr->GongKongStattmp[ZjNo]=0;
		RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKong_Tiaozha_Stat=0;
		ChangXiuKong_flag[ZjNo]=0;
		return 0;
	}
	else
	{
		tmpba=GetDataType02(RtuDataAddr->Fk_Control_Set_Value.F17_Set_Para.Bao_An_DingZhi);//sun
		//if(tmpba!=0)//sun
		{
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongLeiBie=0x02;
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ShiDuanKongStat=0;
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ShiDuanKongTiaoTime=0;
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ShiDuanKongTime=0;
			if((RtuDataAddr->Zj_Control_Value[ZjNo].F42_Set_Para.Valid==1)//���ݹ��ز���
				&&(RtuDataAddr->Zj_Control_Value[ZjNo].F45_Set_Para.Valid==1))//���ؿ����۴�
			{
				RtuDataAddr->changxiu_Kong_Value[ZjNo].DingZhi=GetDataType02(&RtuDataAddr->Zj_Control_Value[ZjNo].F42_Set_Para.ChangXiu_DingZhi[0]);
				RtuDataAddr->changxiu_Kong_Value[ZjNo].LunCi=RtuDataAddr->Zj_Control_Value[ZjNo].F45_Set_Para.GongKong_Lunci_Biaozhi;

				Min=RtuDataAddr->Zj_Control_Value[ZjNo].F42_Set_Para.XianDian_Start_Time[0];
				Min=((Min>>4)*10)+(Min&0x0f);
				Hour=RtuDataAddr->Zj_Control_Value[ZjNo].F42_Set_Para.XianDian_Start_Time[1];
				Hour=((Hour>>4)*10)+(Hour&0x0f);

				RtuDataAddr->changxiu_Kong_Value[ZjNo].Xiandian_Start=Hour*60+Min;
				RtuDataAddr->changxiu_Kong_Value[ZjNo].Xiandian_End=(Hour*60+Min)+(RtuDataAddr->Zj_Control_Value[ZjNo].F42_Set_Para.XianDian_Delay_Time*30);
				RtuDataAddr->changxiu_Kong_Value[ZjNo].XianDianWeek=RtuDataAddr->Zj_Control_Value[ZjNo].F42_Set_Para.XianDian_Day;
			}
			h=ts.Week;
			if(h==0)h=7;
			//printf("\n\rCHANGXIU- Xiandian_Start==%d Xiandian_End==%d XianDianWeek==%d h=%d",RtuDataAddr->changxiu_Kong_Value[ZjNo].Xiandian_Start,RtuDataAddr->changxiu_Kong_Value[ZjNo].Xiandian_End,RtuDataAddr->changxiu_Kong_Value[ZjNo].XianDianWeek,h);
			//CTPrint("\n\rCHANGXIU- Xiandian_Start==%d Xiandian_End==%d XianDianWeek==%d h=%d",RtuDataAddr->changxiu_Kong_Value[ZjNo].Xiandian_Start,RtuDataAddr->changxiu_Kong_Value[ZjNo].Xiandian_End,RtuDataAddr->changxiu_Kong_Value[ZjNo].XianDianWeek,h);

			if(RtuDataAddr->changxiu_Kong_Value[ZjNo].XianDianWeek&(1<<h))//���޵���
			{
				if(((ts.Hour*60+ts.Minute)>=RtuDataAddr->changxiu_Kong_Value[ZjNo].Xiandian_Start)&&
					((ts.Hour*60+ts.Minute)<RtuDataAddr->changxiu_Kong_Value[ZjNo].Xiandian_End))//�޵�ʱ�䷶Χ��
				{
					Create_Data_Type02(RtuDataAddr->changxiu_Kong_Value[ZjNo].DingZhi/10,&RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].Now_GongKong_DingZhi[0]);
					if(RtuDataAddr->Zj_HC_Buff[ZjNo].GLRecCount>RtuDataAddr->Zj_Control_Value[ZjNo].F43_Set_Para.DongLv_HuaCha_Time)
					{
						if(RtuDataAddr->Zj_Control_Value[ZjNo].F43_Set_Para.Valid!=1)
							RtuDataAddr->Zj_Control_Value[ZjNo].F43_Set_Para.DongLv_HuaCha_Time=2;
						RtuDataAddr->Zj_HC_Buff[ZjNo].Tail=(RtuDataAddr->Zj_HC_Buff[ZjNo].Head+70-RtuDataAddr->Zj_Control_Value[ZjNo].F43_Set_Para.DongLv_HuaCha_Time)%70;
						while(RtuDataAddr->Zj_HC_Buff[ZjNo].Tail!=RtuDataAddr->Zj_HC_Buff[ZjNo].Head)
						{
							GKT1=GKT1+RtuDataAddr->Zj_HC_Buff[ZjNo].P_Buff[RtuDataAddr->Zj_HC_Buff[ZjNo].Tail];
							RtuDataAddr->Zj_HC_Buff[ZjNo].Tail=(RtuDataAddr->Zj_HC_Buff[ZjNo].Tail+1)%70;
							j++;
						}

						if(j!=0)//�����¸��ػ���ʱ������ܼ����ƽ������
						{
							GKT1=(GKT1/j)*10;
						}
						else
						{
							GKT1=RtuDataAddr->Zj_HC_Buff[ZjNo].P_Buff[RtuDataAddr->Zj_HC_Buff[ZjNo].Tail]*10;
						}
					}
					if(RtuDataAddr->changxiu_Kong_Value[ZjNo].DingZhi<tmpba)//sun
						RtuDataAddr->changxiu_Kong_Value[ZjNo].DingZhi=tmpba;//sun
					//printf("\n\rCHANGXIU- GKT1==%d DingZhi==%D",GKT1,RtuDataAddr->changxiu_Kong_Value[ZjNo].DingZhi);

					//CTPrint("\n\rCHANGXIU- GKT1==%d DingZhi==%D",GKT1,RtuDataAddr->changxiu_Kong_Value[ZjNo].DingZhi);

					if(GKT1>=(RtuDataAddr->changxiu_Kong_Value[ZjNo].DingZhi))//sun
					{
						RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKong_Tiaozha_Stat=RtuDataAddr->changxiu_Kong_Value[ZjNo].LunCi;
						if(ChangXiuKong_flag[ZjNo]==0)
						{
							ChangXiuKong_flag[ZjNo]=RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKong_Tiaozha_Stat;
						}
						for(i=0;i<Control_Lunci_Max;i++)
						{
							if(ChangXiuKong_flag[ZjNo]&(1<<i))
								break;
						}
						if(OldMin!=ts.Minute)RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ChangXiuKongTime++;
						if(RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ChangXiuKongTime>200)
						RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ChangXiuKongTime=200;
						if(RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ChangXiuKongStat!=0)
						if(OldMin!=ts.Minute)RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ChangXiuKongTiaoTime++;
						if(RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ChangXiuKongTiaoTime>200)
						RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ChangXiuKongTiaoTime=200;
						RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongTiaoTime=RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ChangXiuKongTiaoTime;
						RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongYuexian_Alarm_Stat=RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongYuexian_Alarm_Stat|0x02;

						if(RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ChangXiuKongTime>=RtuDataAddr->Fk_Control_Set_Value.F49_Set_Para[i].GK_Alarm_Time)
						{
							RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongStat=RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongStat|(1<<i);

							RtuDataAddr->GongKongStattmp[ZjNo]=RtuDataAddr->GongKongStattmp[ZjNo]|(1<<i);
							//printf("\n\rchangxiu---RtuDataAddr->GongKongStattmp[%d]=%d",ZjNo,RtuDataAddr->GongKongStattmp[ZjNo]);
							//printf("\n\rRtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongStat===%d",RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongStat);
							RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongYuexian_Alarm_Stat=0;
							RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ChangXiuKongTime=0;
						}
					}
					else
					{
						RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKong_Tiaozha_Stat=0;
						RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongTiaoTime=0;
						RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ChangXiuKongStat=0;
						RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ChangXiuKongTime=0;
						RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongTiaoTime=0;
						RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongStat=0;
						RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongStat=0;
						//RtuDataAddr->GongKongStattmp[ZjNo]=0;
						RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongYuexian_Alarm_Stat=0;//Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongYuexian_Alarm_Stat|0x01;
						ChangXiuKong_flag[ZjNo]=0;
					}
				}
				else
				{
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKong_Tiaozha_Stat=0;
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongTiaoTime=0;
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ChangXiuKongStat=0;
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ChangXiuKongTime=0;
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongTiaoTime=0;
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongStat=0;
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongStat=0;
					RtuDataAddr->GongKongStattmp[ZjNo]=0;
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongYuexian_Alarm_Stat=0;//Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongYuexian_Alarm_Stat|0x01;
					ChangXiuKong_flag[ZjNo]=0;
					//printf("\n\r changxiu 1 RtuDataAddr->GongKongStattmp[ZjNo]=0!!!");
				}
			}
			return 1;
		}
	}
	return 1;
}
INT8U DoShiDuanControl(INT8U ZjNo,INT8U OldMin,TS ts)
{
	INT8U i,j,k;
	INT16U timetmp;
	INT32U Temp,T1,tmpba;
	timetmp=0;
	GKT1=0;
	j=0;
	k=0;
	if(RtuDataAddr->FuKong_Control_Value.F9_Control_Para[ZjNo].Valid!=1)
	{
		RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ShiDuanKongStat=0;
		RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ShiDuanKongTiaoTime=0;
		RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ShiDuanKongTime=0;
		RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongStat=0;
		RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongStat=0;
		//RtuDataAddr->GongKongStattmp[ZjNo]=0;
		RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKong_Tiaozha_Stat=0;
		ShiDuan_flag[ZjNo]=0;
		//printf("\n\r shiduan kong RtuDataAddr->GongKongStattmp[ZjNo]=0!!!");
		return 0;
	}
	else
	{
		tmpba=GetDataType02(RtuDataAddr->Fk_Control_Set_Value.F17_Set_Para.Bao_An_DingZhi);//sun
		//if(tmpba!=0)//sun
		{
			RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongLeiBie=0x01;
			initAllShiDuan();
			initShiDuan(ZjNo);
			if(//(RtuDataAddr->Fk_Control_Set_Value.F19_Set_Para.Valid==1)�ն˹���ʱ�ζ�ֵ����ϵ��
				(RtuDataAddr->Fk_Control_Set_Value.F18_Set_Para.Valid==1)//�ն˹���ʱ��
				&&(RtuDataAddr->Zj_Control_Value[ZjNo].F45_Set_Para.Valid==1))//���ؿ����۴�
			{
				DBControlPr("In Shi Duan kong ");
				//printf("\n\r  begin  begin !!!!1");
				RtuDataAddr->ShiD_Kong_Value[ZjNo].Valid=1;
				RtuDataAddr->ShiD_Kong_Value[ZjNo].FangAnNo=RtuDataAddr->FuKong_Control_Value.F9_Control_Para[ZjNo].ShiDuan_Tou_FangAn_No&0x03;
				RtuDataAddr->ShiD_Kong_Value[ZjNo].LunCi=RtuDataAddr->Zj_Control_Value[ZjNo].F45_Set_Para.GongKong_Lunci_Biaozhi;
				Temp=RtuDataAddr->Fk_Control_Set_Value.F19_Set_Para.ZD_GK_DZ_FDXS;
				Temp=(((Temp>>4)&0x07)*10)+(Temp&0x0f);
				if(RtuDataAddr->Fk_Control_Set_Value.F19_Set_Para.Valid==1)
				{
					if((RtuDataAddr->Fk_Control_Set_Value.F19_Set_Para.ZD_GK_DZ_FDXS&0x80)==0x80)
					{
						RtuDataAddr->ShiD_Kong_Value[ZjNo].DingZhi_xishu=100-Temp;
					}
					else
					{
						RtuDataAddr->ShiD_Kong_Value[ZjNo].DingZhi_xishu=100+Temp;
					}
				}else
					RtuDataAddr->ShiD_Kong_Value[ZjNo].DingZhi_xishu=100;
				RtuDataAddr->ShiD_Kong_Value[ZjNo].ShiduanBiaozhi=0;
				for(i=0;i<8;i++)
				{
					RtuDataAddr->ShiD_Kong_Value[ZjNo].Shiduan_value[i].DingZhi=GetDataType02(&RtuDataAddr->Zj_Control_Value[ZjNo].F41_Set_Para.ShiDuan_DingZhi[RtuDataAddr->ShiD_Kong_Value[ZjNo].FangAnNo].ShiDG_DingZhi[i][0]);
					T1=RtuDataAddr->ShiD_Kong_Value[ZjNo].Shiduan_value[i].DingZhi;
					T1=(T1*RtuDataAddr->ShiD_Kong_Value[ZjNo].DingZhi_xishu)/100;
					RtuDataAddr->ShiD_Kong_Value[ZjNo].Shiduan_value[i].DingZhi=T1;
					DBControlPr("\n\rshiduandingzhi====%d",RtuDataAddr->ShiD_Kong_Value[ZjNo].Shiduan_value[i].DingZhi);
					if(RtuDataAddr->ShiD_Kong_Value[ZjNo].Shiduan_value[i].Valid==1)
					{
						RtuDataAddr->ShiD_Kong_Value[ZjNo].ShiduanBiaozhi=RtuDataAddr->ShiD_Kong_Value[ZjNo].ShiduanBiaozhi|(1<<i);
					}
				}
				RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[ZjNo].FangAnNo=RtuDataAddr->ShiD_Kong_Value[ZjNo].FangAnNo;
				RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[ZjNo].GongKong_YouXiao
				=RtuDataAddr->ShiD_Kong_Value[ZjNo].ShiduanBiaozhi
				&RtuDataAddr->FuKong_Control_Value.F9_Control_Para[ZjNo].ShiDuan_Tou_Set;
			}
			timetmp=(ts.Hour*60)+ts.Minute;

			for(i=0;i<8;i++)
			{
				if((timetmp>=RtuDataAddr->ShiD_Kong_Value[ZjNo].Shiduan_value[i].startMin)&&(timetmp<RtuDataAddr->ShiD_Kong_Value[ZjNo].Shiduan_value[i].endMin))
				{
					NowSdNo=i;
					break;
				}
			}
			//printf("\n\rSHIDUAN-  NowSdNo===%d GongKong_YouXiao==%d",NowSdNo,RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[ZjNo].GongKong_YouXiao);
			DBControlPr("\n\rSHIDUAN- NowSdNo===%d GongKong_YouXiao==%d",NowSdNo,RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[ZjNo].GongKong_YouXiao);

			if(RtuDataAddr->Fk_Control_Set_now.ZongJia_C_S_Set[ZjNo].GongKong_YouXiao&(1<<NowSdNo))
			{
				Create_Data_Type02(RtuDataAddr->ShiD_Kong_Value[ZjNo].Shiduan_value[NowSdNo].DingZhi/10,&RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].Now_GongKong_DingZhi[0]);
				RtuDataAddr->ShiD_Kong_Value[ZjNo].NowShiDuan=NowSdNo;
				if(RtuDataAddr->Zj_Control_Value[ZjNo].F43_Set_Para.Valid!=1)
					RtuDataAddr->Zj_Control_Value[ZjNo].F43_Set_Para.DongLv_HuaCha_Time=2;
				if(RtuDataAddr->Zj_HC_Buff[ZjNo].GLRecCount>RtuDataAddr->Zj_Control_Value[ZjNo].F43_Set_Para.DongLv_HuaCha_Time)
				{
					RtuDataAddr->Zj_HC_Buff[ZjNo].Tail=(RtuDataAddr->Zj_HC_Buff[ZjNo].Head+70-RtuDataAddr->Zj_Control_Value[ZjNo].F43_Set_Para.DongLv_HuaCha_Time)%70;
					while(RtuDataAddr->Zj_HC_Buff[ZjNo].Tail!=RtuDataAddr->Zj_HC_Buff[ZjNo].Head)
					{
						GKT1=GKT1+RtuDataAddr->Zj_HC_Buff[ZjNo].P_Buff[RtuDataAddr->Zj_HC_Buff[ZjNo].Tail];
						RtuDataAddr->Zj_HC_Buff[ZjNo].Tail=(RtuDataAddr->Zj_HC_Buff[ZjNo].Tail+1)%70;
						j++;
					}
					if(j!=0)//�����¸��ػ���ʱ������ܼ����ƽ������
					{
						GKT1=(GKT1/j)*10;
					}
					else
					{
						GKT1=RtuDataAddr->Zj_HC_Buff[ZjNo].P_Buff[RtuDataAddr->Zj_HC_Buff[ZjNo].Tail]*10;
					}
				}

	            if(RtuDataAddr->ShiD_Kong_Value[ZjNo].Shiduan_value[NowSdNo].DingZhi<(tmpba))//sun
	            	RtuDataAddr->ShiD_Kong_Value[ZjNo].Shiduan_value[NowSdNo].DingZhi=tmpba;//sun

	            //printf("\n\r SHIDUAN- GKT1==%d DingZhi==%d",GKT1,RtuDataAddr->ShiD_Kong_Value[ZjNo].Shiduan_value[NowSdNo].DingZhi);

	            DBControlPr("\n\r SHIDUAN- GKT1==%d DingZhi==%d",GKT1,RtuDataAddr->ShiD_Kong_Value[ZjNo].Shiduan_value[NowSdNo].DingZhi);

	            if(GKT1>=(RtuDataAddr->ShiD_Kong_Value[ZjNo].Shiduan_value[NowSdNo].DingZhi))
				{
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKong_Tiaozha_Stat=RtuDataAddr->ShiD_Kong_Value[ZjNo].LunCi;

	            	if(ShiDuan_flag[ZjNo]==0)
					{
						ShiDuan_flag[ZjNo]=RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKong_Tiaozha_Stat;
					}
					for(k=0;k<Control_Lunci_Max;k++)
					{
						if(ShiDuan_flag[ZjNo]&(1<<k))
							break;
					}
					if(OldMin!=ts.Minute)RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ShiDuanKongTime++;
					if(RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ShiDuanKongTime>200)
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ShiDuanKongTime=200;
					if(OldMin!=ts.Minute)RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ShiDuanKongTiaoTime++;
					if(RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ShiDuanKongTiaoTime>200)
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ShiDuanKongTiaoTime=200;
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongTiaoTime=RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ShiDuanKongTiaoTime;
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongYuexian_Alarm_Stat=RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongYuexian_Alarm_Stat|0x01;
					if(RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ShiDuanKongTime>=RtuDataAddr->Fk_Control_Set_Value.F49_Set_Para[k].GK_Alarm_Time)
					{
						//printf("\n\r111GongKongStattmp[%d]==%d ",ZjNo,RtuDataAddr->GongKongStattmp[ZjNo]);
						//printf("\n\r");
						RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongStat=RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongStat|(1<<k);
						RtuDataAddr->GongKongStattmp[ZjNo]=RtuDataAddr->GongKongStattmp[ZjNo]|(1<<k);
						//printf("\n\rshiduan GongKongStattmp[%d]==%d ",ZjNo,RtuDataAddr->GongKongStattmp[ZjNo]);
						//printf("\n\r");
						RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongYuexian_Alarm_Stat=0;
						RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ShiDuanKongTime=0;
					}
				}
				else
				{
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKong_Tiaozha_Stat=0;//ShiD_Kong_Value[ZjNo].LunCi&(ShiD_Kong_Value[ZjNo].LunCi^0xff);
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongTiaoTime=0;
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ShiDuanKongStat=0;//ShiD_Kong_Value[ZjNo].LunCi&(ShiD_Kong_Value[ZjNo].LunCi^0xff);
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ShiDuanKongTime=0;
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongStat=0;
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongStat=0;
					//RtuDataAddr->GongKongStattmp[ZjNo]=0;
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ShiDuanKongTiaoTime=0;//Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ShiDuanKongTime;
					RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongYuexian_Alarm_Stat=0;
					ShiDuan_flag[ZjNo]=0;
				}
			}
			else
			{

				RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKong_Tiaozha_Stat=0;//ShiD_Kong_Value[ZjNo].LunCi&(ShiD_Kong_Value[ZjNo].LunCi^0xff);
				RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongTiaoTime=0;
				RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ShiDuanKongStat=0;//ShiD_Kong_Value[ZjNo].LunCi&(ShiD_Kong_Value[ZjNo].LunCi^0xff);
				RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ShiDuanKongTime=0;
				RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongStat=0;
				RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongStat=0;
				RtuDataAddr->GongKongStattmp[ZjNo]=0;
				RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ShiDuanKongTiaoTime=0;//Fk_Control_Value_now.ZongJia_C_Set[ZjNo].ShiDuanKongTime;
				RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[ZjNo].GongKongYuexian_Alarm_Stat=0;
				ShiDuan_flag[ZjNo]=0;
				//printf("\n\r shiduan 1 RtuDataAddr->GongKongStattmp[ZjNo]=0!!!");
			}
			return 1;
		}
	}
	return 1;
}
INT8U DoLunCiControl(INT8U LunCiNo,INT8U OldMin,TS ts)
{
	if(RtuDataAddr->FuKong_Control_Value.F1_Control_Para[LunCiNo].Valid==1)
	{
		 //ClearSpiLed(All_LunCi);//gai
		//printf("\n\rRtuDataAddr->Fk_Control_Value_now.YK_AlarmTime[%d]==%d",LunCiNo,RtuDataAddr->Fk_Control_Value_now.YK_AlarmTime[LunCiNo]);
		if(RtuDataAddr->Fk_Control_Value_now.YK_AlarmTime[LunCiNo]<=RtuDataAddr->FuKong_Control_Value.F1_Control_Para[LunCiNo].Alarm_Dealy_Set)
		{
			RtuDataAddr->Fk_Control_Value_now.Yaokong_Alarm_Stat=RtuDataAddr->Fk_Control_Value_now.Yaokong_Alarm_Stat|(1<<LunCiNo);
			//printf("\n\rRtuDataAddr->Fk_Control_Value_now.Yaokong_Alarm_Stat===%d",RtuDataAddr->Fk_Control_Value_now.Yaokong_Alarm_Stat);
		}
		else
		{
			RtuDataAddr->Fk_Control_Value_now.Yaokong_Alarm_Stat=0;
		}

		if(RtuDataAddr->FuKong_Control_Value.F1_Control_Para[LunCiNo].Alarm_Dealy_Set==0)
		{
			if(RtuDataAddr->FuKong_Control_Value.F1_Control_Para[LunCiNo].Xian_Dian_Delay_Set==0)
			{
				if(OldMin!=ts.Minute)RtuDataAddr->Fk_Control_Value_now.YK_TiaoZhaTime[LunCiNo]++;
				if(OldMin!=ts.Minute)RtuDataAddr->Fk_Control_Value_now.YK_AlarmTime[LunCiNo]++;
				RtuDataAddr->Fk_Control_Value_now.Yaokong_TiaoZha_Stat=RtuDataAddr->Fk_Control_Value_now.Yaokong_TiaoZha_Stat|(1<<LunCiNo);
			}
			else
			{
				if(OldMin!=ts.Minute)RtuDataAddr->Fk_Control_Value_now.YK_TiaoZhaTime[LunCiNo]++;
				if(OldMin!=ts.Minute)RtuDataAddr->Fk_Control_Value_now.YK_AlarmTime[LunCiNo]++;
				if((RtuDataAddr->FuKong_Control_Value.F1_Control_Para[LunCiNo].Xian_Dian_Delay_Set*30)<RtuDataAddr->Fk_Control_Value_now.YK_TiaoZhaTime[LunCiNo])
				{
					RtuDataAddr->FuKong_Control_Value.F1_Control_Para[LunCiNo].Valid=0;
					RtuDataAddr->Fk_Control_Value_now.YK_TiaoZhaTime[LunCiNo]=RtuDataAddr->FuKong_Control_Value.F1_Control_Para[LunCiNo].Xian_Dian_Delay_Set*30;
					RtuDataAddr->Fk_Control_Value_now.Yaokong_TiaoZha_Stat=RtuDataAddr->Fk_Control_Value_now.Yaokong_TiaoZha_Stat&(0xff^(1<<LunCiNo));
				}
				else
				{
					RtuDataAddr->Fk_Control_Value_now.Yaokong_TiaoZha_Stat=RtuDataAddr->Fk_Control_Value_now.Yaokong_TiaoZha_Stat|(1<<LunCiNo);
				}
			}
		}
		else
		{
			if(RtuDataAddr->Fk_Control_Value_now.YK_AlarmTime[LunCiNo]>=RtuDataAddr->FuKong_Control_Value.F1_Control_Para[LunCiNo].Alarm_Dealy_Set)
			{
				if(OldMin!=ts.Minute)RtuDataAddr->Fk_Control_Value_now.YK_AlarmTime[LunCiNo]++;

				if(RtuDataAddr->FuKong_Control_Value.F1_Control_Para[LunCiNo].Xian_Dian_Delay_Set==0)
				{
					if(OldMin!=ts.Minute)RtuDataAddr->Fk_Control_Value_now.YK_TiaoZhaTime[LunCiNo]++;
					RtuDataAddr->Fk_Control_Value_now.Yaokong_TiaoZha_Stat=RtuDataAddr->Fk_Control_Value_now.Yaokong_TiaoZha_Stat|(1<<LunCiNo);
				}
				else
				{
					if(OldMin!=ts.Minute)RtuDataAddr->Fk_Control_Value_now.YK_TiaoZhaTime[LunCiNo]++;
					if((RtuDataAddr->FuKong_Control_Value.F1_Control_Para[LunCiNo].Xian_Dian_Delay_Set*30)<RtuDataAddr->Fk_Control_Value_now.YK_TiaoZhaTime[LunCiNo])
					{
						RtuDataAddr->FuKong_Control_Value.F1_Control_Para[LunCiNo].Valid=0;
						RtuDataAddr->Fk_Control_Value_now.YK_TiaoZhaTime[LunCiNo]=RtuDataAddr->FuKong_Control_Value.F1_Control_Para[LunCiNo].Xian_Dian_Delay_Set*30;
						RtuDataAddr->Fk_Control_Value_now.Yaokong_TiaoZha_Stat=RtuDataAddr->Fk_Control_Value_now.Yaokong_TiaoZha_Stat&(0xff^(1<<LunCiNo));
					}
					else
					{
						RtuDataAddr->Fk_Control_Value_now.Yaokong_TiaoZha_Stat=RtuDataAddr->Fk_Control_Value_now.Yaokong_TiaoZha_Stat|(1<<LunCiNo);
					}
				}
			}
			else
			{
				if(OldMin!=ts.Minute)RtuDataAddr->Fk_Control_Value_now.YK_AlarmTime[LunCiNo]++;
				RtuDataAddr->Fk_Control_Value_now.Yaokong_TiaoZha_Stat=RtuDataAddr->Fk_Control_Value_now.Yaokong_TiaoZha_Stat&(0xff^(1<<LunCiNo));
			}
		}
	}
	else
	{
		RtuDataAddr->Fk_Control_Value_now.YK_TiaoZhaTime[LunCiNo]=0;
		RtuDataAddr->Fk_Control_Value_now.YK_AlarmTime[LunCiNo]=0;
		RtuDataAddr->Fk_Control_Value_now.Yaokong_TiaoZha_Stat=RtuDataAddr->Fk_Control_Value_now.Yaokong_TiaoZha_Stat&(0xff^(1<<LunCiNo));
		RtuDataAddr->Fk_Control_Value_now.Yaokong_Alarm_Stat=RtuDataAddr->Fk_Control_Value_now.Yaokong_Alarm_Stat&(0xff^(1<<LunCiNo));
		//ClearSpiLed(All_LunCi);
		//printf("\n\ryunxihezha!!!!!!!!");
	}
	return 1;
}
INT8U DoBaoDianControl(INT8U OldMin,TS ts)
{
	INT8U t;
	if(RtuDataAddr->FuKong_Control_Value.F25_Control_Para.Valid==1)
	{
		if(RtuDataAddr->FuKong_Control_Value.F25_Control_Para.BaoDian_Delay_Time==0)
		{
			SetSpiLed(LUNCI1);SetSpiLed(LUNCI2);SetSpiLed(LUNCI3);SetSpiLed(LUNCI4);
			//ClearSpiLed(LUNCI1);ClearSpiLed(LUNCI2);ClearSpiLed(LUNCI3);ClearSpiLed(LUNCI4);//gai
			t=RtuDataAddr->Fk_Control_Value_now.Now_CuiFei_Gaojing_Stat;
			memset(&RtuDataAddr->Fk_Control_Value_now.Valid,0,sizeof(RtuDataAddr->Fk_Control_Value_now));
			RtuDataAddr->Fk_Control_Value_now.Now_CuiFei_Gaojing_Stat=t;
			return 1;
		}
		else
		{
			if((RtuDataAddr->FuKong_Control_Value.F25_Control_Para.BaoDian_Delay_Time*30)>RtuDataAddr->FuKong_Control_Value.F25_Control_Para.Dalay_Time)
			{
				if(OldMin!=ts.Minute)RtuDataAddr->FuKong_Control_Value.F25_Control_Para.Dalay_Time++;
				SetSpiLed(LUNCI1);SetSpiLed(LUNCI2);SetSpiLed(LUNCI3);SetSpiLed(LUNCI4);
				//ClearSpiLed(LUNCI1);ClearSpiLed(LUNCI2);ClearSpiLed(LUNCI3);ClearSpiLed(LUNCI4);//gai
				t=RtuDataAddr->Fk_Control_Value_now.Now_CuiFei_Gaojing_Stat;
				memset(&RtuDataAddr->Fk_Control_Value_now.Valid,0,sizeof(RtuDataAddr->Fk_Control_Value_now));
				RtuDataAddr->Fk_Control_Value_now.Now_CuiFei_Gaojing_Stat=t;
				return 1;
			}
			else
			{
				RtuDataAddr->FuKong_Control_Value.F25_Control_Para.Valid=0;
				t=RtuDataAddr->Fk_Control_Value_now.Now_CuiFei_Gaojing_Stat;
				memset(&RtuDataAddr->Fk_Control_Value_now.Valid,0,sizeof(RtuDataAddr->Fk_Control_Value_now));
				RtuDataAddr->Fk_Control_Value_now.Now_CuiFei_Gaojing_Stat=t;
				return 1;
			}
		}
	}
	else
	{
		return 0;
	}
}
void DoCuiFeiControl(INT8U OldMin,TS ts)
{
	if(RtuDataAddr->Fk_Control_Value_now.Now_CuiFei_Gaojing_Stat==1)
	{
		//if(OldMin==ts.Minute)
		//	return;
		if(ts.Sec%5==0)
		{

			GaoJingBegin();
			GaoJingEnd();
		}

	}
}
void AlArmOut(INT8U OldMin,TS ts)
{
	INT8U i;
	if(RtuDataAddr->Fk_Control_Value_now.Yaokong_Alarm_Stat)
	{
		//if(OldMin==ts.Minute)
		//	return;
		if(ts.Sec%5==0)
		{
			GaoJingBegin();
			GaoJingEnd();
		}

	}
	for(i=0;i<ZongJia_Max;i++)
	{
		if(RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].DianKongYuexian_Alarm_Stat||RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].GongKongYuexian_Alarm_Stat)
		{
			//if(OldMin==ts.Minute)
			//	return;
			if(ts.Sec%5==0)
			{
				GaoJingBegin();
				GaoJingEnd();
			}

		}
	}
}

void ControlOut(INT8U OldMin,TS ts)
{
	INT8U i,k,NowGongKongOut;
	int j;
	j=0;
	Data_Type_15 TmpTime;
	RtuDataAddr->NowControl=0;
	RtuDataAddr->NowKongControl=0;
	RtuDataAddr->NowDianControl=0;
	RtuDataAddr->DianControlTmp=0;
	NowGongKongOut=0;
	if(RtuDataAddr->Fk_Control_Value_now.Yaokong_TiaoZha_Stat!=0)
	{
		RtuDataAddr->NowControl=RtuDataAddr->Fk_Control_Value_now.Yaokong_TiaoZha_Stat;
	}
	for(i=0;i<ZongJia_Max;i++)
	{
		RtuDataAddr->NowKongControl=RtuDataAddr->NowKongControl|RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].GongKong_Tiaozha_Stat;
		RtuDataAddr->NowDianControl=RtuDataAddr->NowDianControl|RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].GouDiankong_TiaoZha_Stat;
		RtuDataAddr->NowDianControl=RtuDataAddr->NowDianControl|RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].YueDianKong_Tiaozha_Stat;
		RtuDataAddr->DianControlTmp=RtuDataAddr->DianControlTmp|RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].GouDianControlStatTmp;
		RtuDataAddr->DianControlTmp=RtuDataAddr->DianControlTmp|RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].YueDianControlStatTmp;
	}
	for(i=0;i<Control_Lunci_Max;i++)
	{
		if(((RtuDataAddr->NowKongControl)==0)&&((RtuDataAddr->NowDianControl)==0)&&(((RtuDataAddr->NowControl>>i)&0x01)==0))
		{
			if(i==0){SetSpiLed(LUNCI1);}//gai
			if(i==1){SetSpiLed(LUNCI2);}//gai
			if(i==2){SetSpiLed(LUNCI3);}//gai
			if(i==3){SetSpiLed(LUNCI4);}//gai
		}
	}
	for(i=0;i<ZongJia_Max;i++)
	{
		if(RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].GongKong_Tiaozha_Stat==0)
		{
			memset(RtuDataAddr->Tmp_Solve_Event.GongKongTStat[i],0,sizeof(RtuDataAddr->Tmp_Solve_Event.GongKongTStat[i]));
			memset(RtuDataAddr->Tmp_Solve_Event.GongKongTTime[i],0,sizeof(RtuDataAddr->Tmp_Solve_Event.GongKongTTime[i]));
			memset(RtuDataAddr->Tmp_Solve_Event.GongKongPOld[i],0,sizeof(RtuDataAddr->Tmp_Solve_Event.GongKongPOld[i]));
			memset(RtuDataAddr->Tmp_Solve_Event.GongKongOccorTime[i],0,sizeof(RtuDataAddr->Tmp_Solve_Event.GongKongOccorTime[i]));
		}
	}
	if(OldMin!=ts.Minute)///////////////////////////////////////////////////////////////////////////
	{
		for(i=0;i<ZongJia_Max;i++)
		{
			if(RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].GongKong_Tiaozha_Stat==0)
			{
				memset(RtuDataAddr->Tmp_Solve_Event.GongKongTStat[i],0,sizeof(RtuDataAddr->Tmp_Solve_Event.GongKongTStat[i]));
				memset(RtuDataAddr->Tmp_Solve_Event.GongKongTTime[i],0,sizeof(RtuDataAddr->Tmp_Solve_Event.GongKongTTime[i]));
				memset(RtuDataAddr->Tmp_Solve_Event.GongKongPOld[i],0,sizeof(RtuDataAddr->Tmp_Solve_Event.GongKongPOld[i]));
				memset(RtuDataAddr->Tmp_Solve_Event.GongKongOccorTime[i],0,sizeof(RtuDataAddr->Tmp_Solve_Event.GongKongOccorTime[i]));
				continue;
			}
			for(k=0;k<Control_Lunci_Max;k++)
			{
				if(RtuDataAddr->Tmp_Solve_Event.GongKongTStat[i][k])
				{
					RtuDataAddr->Tmp_Solve_Event.GongKongTTime[i][k]++;
					if(RtuDataAddr->Tmp_Solve_Event.GongKongTTime[i][k]>=200)
						RtuDataAddr->Tmp_Solve_Event.GongKongTTime[i][k]=200;
				}
			}
			for(j=0;j<Control_Lunci_Max;j++)
			{
				if((RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].GongKongStat&(1<<j))==(1<<j))
				{
					if(RtuDataAddr->Tmp_Solve_Event.GongKongTStat[i][j]!=(RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].GongKongStat&(1<<j)))
					{
						RtuDataAddr->Day_Save_Value.ZD_Day_stat.GongK_T++;
						RtuDataAddr->Yue_Save_Value.ZD_Yue_stat.GongK_T++;
						RtuDataAddr->Tmp_Solve_Event.GongKongTStat[i][j]=(RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].GongKongStat)&(1<<j);
						RtuDataAddr->Tmp_Solve_Event.GongKongPOld[i][j]=RtuDataAddr->Real_Zj_Value[i].P;
						RtuDataAddr->Tmp_Solve_Event.GongKongTTime[i][j]=1;
						RtuDataAddr->Tmp_Solve_Event.GongKongOccorTime[i][j].BCD01=((ts.Minute/10)<<4)+(ts.Minute%10);
						RtuDataAddr->Tmp_Solve_Event.GongKongOccorTime[i][j].BCD02=((ts.Hour/10)<<4)+(ts.Hour%10);
						RtuDataAddr->Tmp_Solve_Event.GongKongOccorTime[i][j].BCD03=((ts.Day/10)<<4)+(ts.Day%10);
						RtuDataAddr->Tmp_Solve_Event.GongKongOccorTime[i][j].BCD04=((ts.Month/10)<<4)+(ts.Month%10);
						RtuDataAddr->Tmp_Solve_Event.GongKongOccorTime[i][j].BCD05=(((ts.Year%100)/10)<<4)+(ts.Year%10);
					}
					break;
				}
				else
					if(RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].GongKong_Tiaozha_Stat&(1<<j)==0)
					{
						RtuDataAddr->Tmp_Solve_Event.GongKongTStat[i][j]=0;
						RtuDataAddr->Tmp_Solve_Event.GongKongPOld[i][j]=0;
						RtuDataAddr->Tmp_Solve_Event.GongKongTTime[i][j]=0;
						RtuDataAddr->Tmp_Solve_Event.GongKongOccorTime[i][j].BCD01=0;
						RtuDataAddr->Tmp_Solve_Event.GongKongOccorTime[i][j].BCD02=0;
						RtuDataAddr->Tmp_Solve_Event.GongKongOccorTime[i][j].BCD03=0;
						RtuDataAddr->Tmp_Solve_Event.GongKongOccorTime[i][j].BCD04=0;
						RtuDataAddr->Tmp_Solve_Event.GongKongOccorTime[i][j].BCD05=0;
					}
			}
		}
		for(i=0;i<Control_Lunci_Max;i++)
		{
			if(RtuDataAddr->Fk_Control_Value_now.Yaokong_TiaoZha_Stat&(1<<i))
			{
				if((RtuDataAddr->Tmp_Solve_Event.lunCiYkTZ&(1<<i))==0)
				{
					RtuDataAddr->Day_Save_Value.ZD_Day_stat.Yk_T++;
					RtuDataAddr->Yue_Save_Value.ZD_Yue_stat.Yk_T++;
					//printf("\n\r tiaozhaNum is %d",RtuDataAddr->Day_Save_Value.ZD_Day_stat.Yk_T);
					//printf("\n\r");
					RtuDataAddr->Tmp_Solve_Event.lunCiYkTZ=RtuDataAddr->Tmp_Solve_Event.lunCiYkTZ|(1<<i);
					RtuDataAddr->Tmp_Solve_Event.YkOccorTime[i].BCD01=((ts.Minute/10)<<4)+(ts.Minute%10);
					RtuDataAddr->Tmp_Solve_Event.YkOccorTime[i].BCD02=((ts.Hour/10)<<4)+(ts.Hour%10);
					RtuDataAddr->Tmp_Solve_Event.YkOccorTime[i].BCD03=((ts.Day/10)<<4)+(ts.Day%10);
					RtuDataAddr->Tmp_Solve_Event.YkOccorTime[i].BCD04=((ts.Month/10)<<4)+(ts.Month%10);
					RtuDataAddr->Tmp_Solve_Event.YkOccorTime[i].BCD05=(((ts.Year%100)/10)<<4)+(ts.Year%10);
					RtuDataAddr->Tmp_Solve_Event.YkPOld[i]=RtuDataAddr->Real_Zj_Value[0].P;
					RtuDataAddr->Tmp_Solve_Event.YkTime[i]=1;
				}
				else
				{
					RtuDataAddr->Tmp_Solve_Event.YkTime[i]++;
					if(RtuDataAddr->Tmp_Solve_Event.YkTime[i]>200)RtuDataAddr->Tmp_Solve_Event.YkTime[i]=200;
				}
			}
			else
			{
				RtuDataAddr->Tmp_Solve_Event.YkTime[i]=0;
				RtuDataAddr->Tmp_Solve_Event.lunCiYkTZ=RtuDataAddr->Tmp_Solve_Event.lunCiYkTZ&(0xff^(1<<i));
			}
			if(RtuDataAddr->Tmp_Solve_Event.YkTime[i]==3)
			{
				if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)
				{
					if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[0]&0x10)//��Ҫ�Բ������ý����¼���¼
					{
						RtuDataAddr->Event_Save.Event.Err5.ERCNo=5;
						RtuDataAddr->Event_Save.Event.Err5.len=10;
						memcpy(&RtuDataAddr->Event_Save.Event.Err5.Occur_Time.BCD01,&RtuDataAddr->Tmp_Solve_Event.YkOccorTime[i].BCD01,5);
						RtuDataAddr->Event_Save.Event.Err5.LunCi=1<<i;
						Create_Data_Type02(RtuDataAddr->Tmp_Solve_Event.YkPOld[i],&RtuDataAddr->Event_Save.Event.Err5.P[0]);
						Create_Data_Type02(RtuDataAddr->Real_Zj_Value[i].P,&RtuDataAddr->Event_Save.Event.Err5.Delay_2_P[0]);
						if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[0]&0x10)//��Ҫ�¼�
						{
							SaveEveBuff(&TmpTime.BCD01,1,5);
						}
						else//һ���¼�
						{
							SaveEveBuff(&TmpTime.BCD01,2,5);
						}
					}
				}
			}
		}
		//�����¼�����
		for(i=0;i<ZongJia_Max;i++)
		{
			if(RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].GongKong_Tiaozha_Stat==0)continue;
			for(j=0;j<Control_Lunci_Max;j++)
			{
				if(RtuDataAddr->Tmp_Solve_Event.GongKongTTime[i][j]==3)
				{
					if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)
					{
						if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[0]&0x20)//��Ҫ�Բ������ý����¼���¼
						{
							RtuDataAddr->Event_Save.Event.Err6.ERCNo=6;
							RtuDataAddr->Event_Save.Event.Err6.len=14;
							memcpy(&RtuDataAddr->Event_Save.Event.Err6.Occur_Time.BCD01,&RtuDataAddr->Tmp_Solve_Event.GongKongOccorTime[i][j].BCD01,5);
							RtuDataAddr->Event_Save.Event.Err6.ZongJIaNo=i+1;
							RtuDataAddr->Event_Save.Event.Err6.LunCi=RtuDataAddr->Tmp_Solve_Event.GongKongTStat[i][j];
							RtuDataAddr->Event_Save.Event.Err6.KongLeiBie=RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].GongKongLeiBie;
							Create_Data_Type02(RtuDataAddr->Tmp_Solve_Event.GongKongPOld[i][j],&RtuDataAddr->Event_Save.Event.Err6.P_Old[0]);
							Create_Data_Type02(RtuDataAddr->Real_Zj_Value[i].P,&RtuDataAddr->Event_Save.Event.Err6.Delay_2_P[0]);
							memcpy(&RtuDataAddr->Event_Save.Event.Err6.P_DingZhi[0],&RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].Now_GongKong_DingZhi[0],2);
							if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[0]&0x20)//��Ҫ�¼�
							{
								SaveEveBuff(&TmpTime.BCD01,1,6);
							}
							else//һ���¼�
							{
								SaveEveBuff(&TmpTime.BCD01,2,6);
							}
						}
					}
				}
			}
		}
		for(i=0;i<ZongJia_Max;i++)
		{
			//printf("\n\r stat is %d ",RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].DianKongYuexian_Alarm_Stat);
			//printf("\n\r");
			if(RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].DianKongYuexian_Alarm_Stat==0)
			{
				RtuDataAddr->Tmp_Solve_Event.GoudianAlmStat[i]=0;continue;
			}

			if(RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].DianKongYuexian_Alarm_Stat&0x02)
			{
				if((RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].DianKongYuexian_Alarm_Stat&0x02)!=(RtuDataAddr->Tmp_Solve_Event.GoudianAlmStat[i]&0x02))
				{
					RtuDataAddr->Tmp_Solve_Event.GoudianAlmStat[i]=RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].DianKongYuexian_Alarm_Stat;
	  				if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)
					{
						if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[2]&0x40)
						{
							//printf("\n\r Begin Err23 !!!!\n\r\n\r");
							RtuDataAddr->Event_Save.Event.Err23.ERCNo=23;
							RtuDataAddr->Event_Save.Event.Err23.len=16;
							RtuDataAddr->Event_Save.Event.Err23.ZjNo=i+1;
							RtuDataAddr->Event_Save.Event.Err23.LunCi=RtuDataAddr->Gou_Dian_Kong_Value[i].LunCi;
							RtuDataAddr->Event_Save.Event.Err23.KongLeiBie=2;
							Create_Data_Type03(RtuDataAddr->Real_Zj_Value[i].ShengYuDianLiang,&RtuDataAddr->Event_Save.Event.Err23.DD_Old[0]);
							Create_Data_Type03(RtuDataAddr->Gou_Dian_Kong_Value[i].TiaozhaMen,&RtuDataAddr->Event_Save.Event.Err23.DD_DingZhi[0]);
							if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[2]&0x40)//��Ҫ�¼�
							{
								SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err23.Occur_Time.BCD01,1,23);
							}
							else//һ���¼�
							{
								SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err23.Occur_Time.BCD01,2,23);
							}
						}
					}
				}
			}
			else
				if(RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].DianKongYuexian_Alarm_Stat&0x01)
				{
					if((RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].DianKongYuexian_Alarm_Stat&0x01)!=(RtuDataAddr->Tmp_Solve_Event.GoudianAlmStat[i]&0x01))
					{
						RtuDataAddr->Tmp_Solve_Event.GoudianAlmStat[i]=RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].DianKongYuexian_Alarm_Stat;
		  				if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)
						{
							if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[2]&0x40)
							{
								RtuDataAddr->Event_Save.Event.Err23.ERCNo=23;
								RtuDataAddr->Event_Save.Event.Err23.len=16;
								RtuDataAddr->Event_Save.Event.Err23.ZjNo=i+1;
								RtuDataAddr->Event_Save.Event.Err23.LunCi=RtuDataAddr->Yue_Dian_Kong_Value[i].LunCi;
								RtuDataAddr->Event_Save.Event.Err23.KongLeiBie=1;
								Create_Data_Type03((RtuDataAddr->Real_Zj_Value[i].P_All-RtuDataAddr->Yue_Zj_Value[i].P_All),&RtuDataAddr->Event_Save.Event.Err23.DD_Old[0]);
								memcpy(&RtuDataAddr->Event_Save.Event.Err23.DD_DingZhi[0],&RtuDataAddr->Zj_Control_Value[i].F46_Set_Para.Yue_DIan_Liang_Kong[0],4);
								if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[2]&0x40)//��Ҫ�¼�
								{
									SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err23.Occur_Time.BCD01,1,23);
								}
								else//һ���¼�
								{
									SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err23.Occur_Time.BCD01,2,23);
								}
							}
						}
					}
				}
		}
		for(i=0;i<ZongJia_Max;i++)
		{
			if(RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].GouDiankong_TiaoZha_Stat==0)
			{
				RtuDataAddr->Tmp_Solve_Event.GoudianTStat[i]=0;continue;
			}
			//if(RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].GouDiankong_TiaoZha_Stat!=RtuDataAddr->Tmp_Solve_Event.GoudianTStat[i])
			for(j=0;j<Control_Lunci_Max;j++)
			{
				if((RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].GouDianControlStatTmp&(0x01<<j))&&(GouFirstFlag[i][j]==0))
				{
					GouFirstFlag[i][j]=1;
					RtuDataAddr->Day_Save_Value.ZD_Day_stat.Gou_DK_T++;
					RtuDataAddr->Yue_Save_Value.ZD_Yue_stat.Gou_DK_T++;
					RtuDataAddr->Tmp_Solve_Event.GoudianTStat[i]=RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].GouDiankong_TiaoZha_Stat;
					if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)
					{
						if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[0]&0x40)//��Ҫ�Բ������ý����¼���¼
						{
							RtuDataAddr->Event_Save.Event.Err7.ERCNo=7;
							RtuDataAddr->Event_Save.Event.Err7.len=16;
							RtuDataAddr->Event_Save.Event.Err7.ZongJIaNo=i+1;
							RtuDataAddr->Event_Save.Event.Err7.LunCi=0x01<<j;
							RtuDataAddr->Event_Save.Event.Err7.KongLeiBie=2;
							Create_Data_Type03(RtuDataAddr->Real_Zj_Value[i].ShengYuDianLiang,&RtuDataAddr->Event_Save.Event.Err7.DD_Old[0]);
							memcpy(&RtuDataAddr->Event_Save.Event.Err7.DD_DingZhi[0],&RtuDataAddr->Zj_Control_Value[i].F47_Set_Para.TiaoZha_Men[0],4);

							if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[0]&0x40)//��Ҫ�¼�
							{
								SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err7.Occur_Time.BCD01,1,7);
							}
							else//һ���¼�
							{
								SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err7.Occur_Time.BCD01,2,7);
							}
						}
					}
				}
			}

		}
		for(i=0;i<ZongJia_Max;i++)
		{
			if(RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].YueDianKong_Tiaozha_Stat==0)
			{
				RtuDataAddr->Tmp_Solve_Event.YueDianTStat[i]=RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].YueDianKong_Tiaozha_Stat;
				continue;
			}
			for(j=0;j<Control_Lunci_Max;j++)
			{
				if((RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].YueDianControlStatTmp&(0x01<<j))&&(YueFirstFlag[i][j]==0))
				{

					YueFirstFlag[i][j]=1;
					RtuDataAddr->Day_Save_Value.ZD_Day_stat.Yue_DK_T++;
					RtuDataAddr->Yue_Save_Value.ZD_Yue_stat.Yue_DK_T++;
					RtuDataAddr->Tmp_Solve_Event.YueDianTStat[i]=RtuDataAddr->Fk_Control_Value_now.ZongJia_C_Set[i].YueDianKong_Tiaozha_Stat;
					if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)
					{
						if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[0]&0x40)//��Ҫ�Բ������ý����¼���¼
						{
							RtuDataAddr->Event_Save.Event.Err7.ERCNo=7;
							RtuDataAddr->Event_Save.Event.Err7.len=16;
							RtuDataAddr->Event_Save.Event.Err7.ZongJIaNo=i+1;
							RtuDataAddr->Event_Save.Event.Err7.LunCi=0x01<<j;
							RtuDataAddr->Event_Save.Event.Err7.KongLeiBie=1;
							Create_Data_Type03((RtuDataAddr->Real_Zj_Value[i].P_All-RtuDataAddr->Yue_Zj_Value[i].P_All),&RtuDataAddr->Event_Save.Event.Err7.DD_Old[0]);
							memcpy(&RtuDataAddr->Event_Save.Event.Err7.DD_DingZhi[0],&RtuDataAddr->Zj_Control_Value[i].F46_Set_Para.Yue_DIan_Liang_Kong[0],4);
							if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[0]&0x40)//��Ҫ�¼�
							{
								SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err7.Occur_Time.BCD01,1,7);
							}
							else//һ���¼�
							{
								SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err7.Occur_Time.BCD01,2,7);
							}
						}
					}
				}
			}

		}
		TiaozhaControl();
		ClearControl();
	}
}
INT8U   PARSE_CMD(int argc, char * argv[])
{
	INT8U  proc_name[32] = "";
	if(argc < 2)return (FALSE);
	PORT_ID = atoi(argv[1]);
	sprintf((char *)proc_name, "%s %d", argv[0], PORT_ID);
	if((attach = name_attach(NULL, (char *)proc_name,0))  == NULL)
	{
		fprintf(stderr, "ERR:'%s' runed,cann't regist: %s\r\n", proc_name, strerror(errno));
		return (FALSE);
	}
	return (TRUE);
}
void QuitProcess(int signo)
{
	fclose(CTfp);
	delay(100);
	RtuDataAddr->stPortPara[PORT_ID].PID=0;
   	name_detach(attach, 0);
   	fprintf(stderr,"fkcontrol quit");
	exit(0);
}
void markver()//��Ŀ������б�ʶ�����汾��Ϣ
{
	printf("\n%s\n", verstr);
}
int main(int argc, char *argv[]) {
	struct sigaction sa1;
	uintptr_t BatIO;
	INT8U Now_Min , NowHour;
	INT8U Old_Month;
	int i,BatOffCount;
	TS ts;
	memset(GLvKong_flag,0,8);
	memset(YingYeKong_flag,0,8);
	memset(ChangXiuKong_flag,0,8);
	memset(ShiDuan_flag,0,8);
	memset(GouFirstFlag,0,32);
	memset(YueFirstFlag,0,32);
	markver();
	if(OpenMem())return EXIT_FAILURE;
	if(RtuDataAddr->mem_len!=sizeof(RTimeData))
	{
		fprintf( stderr, "base mem uncompared prog will exit %d :\n",sizeof(RTimeData));
		return EXIT_FAILURE;
	}
	if(!PARSE_CMD(argc, argv))
	{
		return EXIT_FAILURE;
	}
	sa1.sa_handler = QuitProcess;
	sigemptyset(&sa1.sa_mask);
	sa1.sa_flags = 0;
	sigaction(SIGTERM, &sa1,NULL);
	sigaction(SIGSYS, &sa1,NULL);
	sigaction(SIGPWR, &sa1,NULL);
	sigaction(SIGKILL, &sa1,NULL);
	sigaction(SIGQUIT, &sa1,NULL);
	sigaction(SIGILL, &sa1,NULL);
	sigaction(SIGINT, &sa1,NULL);
	sigaction(SIGHUP, &sa1,NULL);
	sigaction(SIGABRT, &sa1,NULL);
	sigaction(SIGBUS, &sa1,NULL);
	RtuDataAddr->stPortPara[PORT_ID].PID=getpid();//�˿�ͨѶ����
	while(RtuDataAddr->Dev_Init_OK==0)
	{
		CleardeadCount();
		delay(1000);
	}
	CleardeadCount();
	for(i=0;i<CeLiangPoint_Max;i++)
	{
		RtuDataAddr->CL_ERR[i].Old_PDD=RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_All;
	}
 	TSGet(&ts);
	Now_Min=ts.Minute;
	NowHour = ts.Hour;
	Old_Month=ts.Month;
	BatOffCount=0;
	ControlAvailble=0;
 	OpenControl();
 	//notx_count = 0;//�Զ������ն�����վ������ͨѶʱ�����
 	if(AlarmOpened==0)
 		OpenAlarm();

	CTfp = NULL;
	CTfp =  fopen("/nand/fkcontrol.log","a+");
 	for (;;)
   	{
 		delay(1000);
       	CleardeadCount();
		TSGet(&ts);
		if(Now_Min!=ts.Minute)
		{
			ControlAvailble++;
			if(RtuDataAddr->batflag == 1)
			{
				BatOffCount++;
				if(BatOffCount>=3)
				{
					BatOffCount=0;
					BatIO = mmap_device_io(0x10,0x5000000A);//�رյ��
					out8(BatIO,0);
				}
			}
			if (RtuDataAddr->batflag == 0)
				BatOffCount = 0;
		}
		if(ControlAvailble<2)
		{
			Now_Min = ts.Minute;
			continue;
		}
		else
			ControlAvailble=15;

		//-------------------------------------------------
		//�Զ������ж�
		/*if (NowHour != ts.Hour)
		{
			RtuDataAddr->NoFrameCount
			if (RtuDataAddr->Gprs_ok == 1)
			{
				notx_count++;
				if (notx_count>=RtuDataAddr->Fk_Control_Set_Value.F58_Set_Para.ZDuan_Auto_BaoDian)
				{
					printf("\n\r ----------zidong bao dian ----------------");
					continue;
				}
			}else
				notx_count = 0;
		}*/
		//-------------------------------------------------
		InitControlSet();
		InitControlNow();
		DoCuiFeiControl(Now_Min,ts);

		if(DoBaoDianControl(Now_Min,ts))
		{
			Now_Min=ts.Minute;
			continue;
		}
		for(i=0;i<ZongJia_Max;i++)
		{
			DoGouDiankong(i,Now_Min,ts);//���й���ؼ���
			DoYueDianKong(i,Now_Min,Old_Month,ts);//�����µ�ؼ���
			if((RtuDataAddr->FuKong_Control_Value.F11_Control_Para[i].Valid!=1)&&
			   (RtuDataAddr->FuKong_Control_Value.F10_Control_Para[i].Valid!=1)&&
			   (RtuDataAddr->FuKong_Control_Value.F9_Control_Para[i].Valid!=1)&&
			   (RtuDataAddr->FuKong_Control_Value.F12_Control_Para[i].Valid!=1))
			{
				RtuDataAddr->GongKongStattmp[i]=0;
			}

			if(DoGlvControl(i,Now_Min,ts))continue;//�����¸��ؼ��㣬���п��ƺ󣬲��ٽ�����������
			if(DoYingYeControl(i,Now_Min,ts))continue;//Ӫҵ��ͣ�ؿ��ƣ����п��ƺ󣬲��ٽ�����������
			if(DoChangXiuControl(i,Now_Min,ts))continue;//���ݿؿ��ƣ����п��ƺ󣬲��ٽ�����������
			if(DoShiDuanControl(i,Now_Min,ts))continue;//ʱ�οؿ��ƣ����п��ƺ󣬲��ٽ�����������
		}
		for(i=0;i<Control_Lunci_Max;i++)
		{
			DoLunCiControl(i,Now_Min,ts);//�ִο������
		}
		AlArmOut(Now_Min,ts);
		ControlOut(Now_Min,ts);
		Now_Min=ts.Minute;
		if (ts.Month!=Old_Month)
			Old_Month=ts.Month;
   	}
  	name_detach(attach, 0);
 	return EXIT_SUCCESS;
}
