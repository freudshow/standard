#ifndef FKCONTROL_H_
#define FKCONTROL_H_
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <ctype.h>
#include <time.h>
#include <stdint.h>
#include <signal.h>
#include <sys/sched.h>
#include <semaphore.h>
#include <process.h>
#include <sys/neutrino.h>
#include <sys/netmgr.h>
#include <sys/dispatch.h>
#include <errno.h>
#include <netdb.h>
#include <hw/inout.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <math.h>
#include <fkbase/memdef.h>
#include <fkbase/fkbasefun.h>

#define DBControlPr if(RtuDataAddr->CONTROLDBON)printf
FILE *CTfp;
#define CTPrint(...) fprintf(CTfp, __VA_ARGS__);fflush(CTfp);

RTimeData  *RtuDataAddr;//�ڴ湲��������ָ��
name_attach_t *attach;
INT8U 	PORT_ID;
INT8U 	ControlAvailble;
INT8U	Sd48[48];
INT32S	GKT1,GKT2,GKT3;
INT8U   NowSdNo;

int setupTimer();
void QuitProcess(int signo);
void OutScreen();
void Create_Data_Type02(INT32S S,INT8U *Dest);
void Create_Data_Type03(INT32S S,INT8U *Dest);
INT32S GetDataType02(INT8U *S);
long GetdataType03(INT8U *S);
void TiaozhaControl();
void ClearControl();
void initAllShiDuan();
void initShiDuan(INT8U P);
void InitControlNow();
void InitControlSet();
INT8U ControlLunCiSet(INT8U NeedControl,INT8U MinCount);
INT8U DoGouDiankong(INT8U ZjNo,INT8U OldMin,TS ts);
INT8U DoYueDianKong(INT8U ZjNo,INT8U OldMin,INT8U OldMonth,TS ts);
INT8U DoGlvControl(INT8U ZjNo,INT8U OldMin,TS ts);
INT8U DoYingYeControl(INT8U ZjNo,INT8U OldMin,TS ts);
INT8U DoChangXiuControl(INT8U ZjNo,INT8U OldMin,TS ts);
INT8U DoShiDuanControl(INT8U ZjNo,INT8U OldMin,TS ts);
INT8U DoLunCiControl(INT8U LunCiNo,INT8U OldMin,TS ts);
INT8U DoBaoDianControl(INT8U OldMin,TS ts);
void DoCuiFeiControl(INT8U OldMin,TS ts);
void ControlOut(INT8U OldMin,TS ts);

#endif /*FKCONTROL_H_*/
