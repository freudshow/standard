#include "fkset.h"
 #include <time.h>
#include <fkbase/fkbasefun.h>
RTimeData  *RtuDataAddr;//�ڴ湲��������ָ��
INT8U PORT_ID;
INT8U xiuzhengbuff[1024];
const char verstr[]={"VER-STRING-FLG=009.002.217.004"__DATE__" "__TIME__};


void markver()//��Ŀ������б�ʶ�����汾��Ϣ
{
	printf("\n%s\n", verstr);
}

void AT24Write(INT8U addr,INT8U data)
{
	xiuzhengbuff[addr]=data;
}
/********************************************************/
void modify_uip(INT8U ch,INT8U *s)
{
    INT8U i;
    INT32S temp[16];
    if(MODE == 04)
    {
      RtuDataAddr->display_xiu[0] = (RtuDataAddr->REC[0x01]/1100 - Kpa)/2 ;
      if( (abs(RtuDataAddr->display_xiu[0]))>PABCMAXXIU )
      {
       RtuDataAddr->display_xiu[0] =0;
       fprintf(stderr,"\r\npa ��������\r\n");
      }


      RtuDataAddr->display_xiu[1] = (RtuDataAddr->REC[0x02]/1100 - Kpb)/2  ;
      if( (abs(RtuDataAddr->display_xiu[1]))>PABCMAXXIU )
      {
       RtuDataAddr->display_xiu[1] =0;
       fprintf(stderr,"\r\npb ��������\r\n");
      }

      RtuDataAddr->display_xiu[2] = (RtuDataAddr->REC[0x03]/1100 - Kpc)/2 ;
      if( (abs(RtuDataAddr->display_xiu[2]))>PABCMAXXIU )
      {
       RtuDataAddr->display_xiu[2] =0;
       fprintf(stderr,"\r\npc ��������\r\n");
      }


      RtuDataAddr->display_xiu[3] = (RtuDataAddr->REC[0x04]/330 -  Kpz)/2 ;
      if( (abs(RtuDataAddr->display_xiu[3]))>PABCMAXXIU )
      {
       RtuDataAddr->display_xiu[3] =0;
       fprintf(stderr,"\r\npz ��������\r\n");
      }


      RtuDataAddr->display_xiu[8]  = (RtuDataAddr->REC[0x0D]/220 - Kua)/2 ;
      if( (abs(RtuDataAddr->display_xiu[8]))>UABCMAXXIU )
      {
       RtuDataAddr->display_xiu[8] =0;
       fprintf(stderr,"\r\nua ��������\r\n");
      }

      RtuDataAddr->display_xiu[9]  = (RtuDataAddr->REC[0x0E]/220 - Kub)/2 ;
      if( (abs(RtuDataAddr->display_xiu[9]))>UABCMAXXIU )
      {
       RtuDataAddr->display_xiu[9] =0;
       fprintf(stderr,"\r\nub ��������\r\n");
      }


      RtuDataAddr->display_xiu[10] = (RtuDataAddr->REC[0x0F]/220 - Kuc)/2 ;
      if( (abs(RtuDataAddr->display_xiu[10]))>UABCMAXXIU )
      {
       RtuDataAddr->display_xiu[10] =0;
       fprintf(stderr,"\r\nuc ��������\r\n");
      }


      RtuDataAddr->display_xiu[11] = (RtuDataAddr->REC[0x10]/500 - Kia)/2 ;
      if( (abs(RtuDataAddr->display_xiu[11]))>IABCMAXXIU )
      {
       RtuDataAddr->display_xiu[11] =0;
       fprintf(stderr,"\r\nIa ��������\r\n");
      }

   	  RtuDataAddr->display_xiu[12] = (RtuDataAddr->REC[0x11]/500 - Kib)/2 ;
      if( (abs(RtuDataAddr->display_xiu[12]))>IABCMAXXIU )
      {
       RtuDataAddr->display_xiu[12] =0;
       fprintf(stderr,"\r\nIB ��������\r\n");
      }

      RtuDataAddr->display_xiu[13] = (RtuDataAddr->REC[0x12]/500 - Kic)/2 ;
      if( (abs(RtuDataAddr->display_xiu[13]))>IABCMAXXIU )
      {
       RtuDataAddr->display_xiu[13] =0;
       fprintf(stderr,"\r\nIC ��������\r\n");
      }

      RtuDataAddr->display_xiu[14] = (RtuDataAddr->REC[0x29]/500 - Ki0)/2 ;
      if( (abs(RtuDataAddr->display_xiu[14]))>IABCMAXXIU )
      {
       RtuDataAddr->display_xiu[14] =0;
       fprintf(stderr,"\r\nIo ��������\r\n");
      }


      /////д����/////
      AT24Write(80,0x1);
	  AT24Write(81,0x36);
	  AT24Write(82,0x05);
	  AT24Write(83,0x35);
	  AT24Write(84,0x35);
	  AT24Write(85,0x05);
      /////////////////

    	for(i=0;i<4;i++)
       		//AT24Write(i,display_xiu[i]);
       	   {
       	   	AT24Write(20+2*i,RtuDataAddr->display_xiu[i]&0xff);
       	   	AT24Write(21+2*i,(RtuDataAddr->display_xiu[i]&0xff00)>>8);

       	   	if(RtuDataAddr->display_xiu[i]>127)
       	   	temp[i]=127;
       	   	else if(RtuDataAddr->display_xiu[i]<-128)
       	   	temp[i]=-128;
       	   	else
       	   	temp[i]= RtuDataAddr->display_xiu[i]&0xff;

       	   	AT24Write(i,temp[i]);

       	   }

    	for(i=8;i<16;i++)
       	   {
       	   	AT24Write(20+2*i,RtuDataAddr->display_xiu[i]&0xff);
       	   	AT24Write(21+2*i,(RtuDataAddr->display_xiu[i]&0xff00)>>8);

       	   	if(RtuDataAddr->display_xiu[i]>127)
       	   	temp[i]=127;
       	   	else
       	   	if(RtuDataAddr->display_xiu[i]<-128)
       	   	temp[i]=-128;
       	   	else
       	   	temp[i]= RtuDataAddr->display_xiu[i]&0xff;

       	   	AT24Write(i,temp[i]);
       	   }

       		RtuDataAddr->mod_uip_flag = 1 ;
    }


    if(MODE == 03)
    {


       		RtuDataAddr->display_xiu[0] = (RtuDataAddr->REC[0x01]/433 - Kpa)/2 ;
			if( (abs(RtuDataAddr->display_xiu[0]))>PABCMAXXIU )
			{
			RtuDataAddr->display_xiu[0] =0;
			fprintf(stderr,"\r\npa ��������\r\n");
			}

    		RtuDataAddr->display_xiu[2] = (RtuDataAddr->REC[0x03]/433 - Kpc)/2 ;
			if( (abs(RtuDataAddr->display_xiu[2]))>PABCMAXXIU )
			{
			RtuDataAddr->display_xiu[2] =0;
			fprintf(stderr,"\r\npc ��������\r\n");
			}

    		RtuDataAddr->display_xiu[3] = (RtuDataAddr->REC[0x04]*10/866 -  Kpz)/2  ;
			if( (abs(RtuDataAddr->display_xiu[3]))>PABCMAXXIU )
			{
			RtuDataAddr->display_xiu[3] =0;
			fprintf(stderr,"\r\npz ��������\r\n");
			}

           	RtuDataAddr->display_xiu[8]  = (RtuDataAddr->REC[0x0D]/100 - Kua)/2 ;
			if( (abs(RtuDataAddr->display_xiu[8]))>UABCMAXXIU )
			{
			RtuDataAddr->display_xiu[8] =0;
			fprintf(stderr,"\r\nUA ��������\r\n");
			}

	    	RtuDataAddr->display_xiu[10] = (RtuDataAddr->REC[0x0F]/100 - Kuc)/2 ;
			if( (abs(RtuDataAddr->display_xiu[10]))>UABCMAXXIU )
			{
			RtuDataAddr->display_xiu[10] =0;
			fprintf(stderr,"\r\nUc ��������\r\n");
			}

	    	RtuDataAddr->display_xiu[11] = (RtuDataAddr->REC[0x10]/500 - Kia)/2 ;
			if( (abs(RtuDataAddr->display_xiu[11]))>IABCMAXXIU )
			{
			RtuDataAddr->display_xiu[11] =0;
			fprintf(stderr,"\r\nIA ��������\r\n");
			}

  		  	RtuDataAddr->display_xiu[13] = (RtuDataAddr->REC[0x12]/500 - Kic)/2 ;
			if( (abs(RtuDataAddr->display_xiu[13]))>IABCMAXXIU )
			{
			RtuDataAddr->display_xiu[13] =0;
			fprintf(stderr,"\r\nIC ��������\r\n");
			}

 	      /////д����/////
	      AT24Write(80,0x1);
		  AT24Write(81,0x36);
		  AT24Write(82,0x05);
		  AT24Write(83,0x35);
		  AT24Write(84,0x35);
		  AT24Write(85,0x05);
	      /////////////////

	    	for(i=0;i<4;i++)
	       	   {
	       	   	AT24Write(20+2*i,RtuDataAddr->display_xiu[i]&0xff);
	       	   	AT24Write(21+2*i,(RtuDataAddr->display_xiu[i]&0xff00)>>8);

		       	if(RtuDataAddr->display_xiu[i]>127)
		   	   	temp[i]=127;
		   	   	else if(RtuDataAddr->display_xiu[i]<-128)
		   	   	temp[i]=-128;
		   	   	else
		   	   	temp[i]= RtuDataAddr->display_xiu[i]&0xff;

		   	   	AT24Write(i,temp[i]);
	       	   }

	    	for(i=8;i<16;i++)
	       	   {
	       	   	AT24Write(20+2*i,RtuDataAddr->display_xiu[i]&0xff);
	       	   	AT24Write(21+2*i,(RtuDataAddr->display_xiu[i]&0xff00)>>8);

		       	if(RtuDataAddr->display_xiu[i]>127)
		   	   	temp[i]=127;
		   	   	else if(RtuDataAddr->display_xiu[i]<-128)
		   	   	temp[i]=-128;
		   	   	else
		   	   	temp[i]= RtuDataAddr->display_xiu[i]&0xff;

		   	   	AT24Write(i,temp[i]);

	       	   }

       		RtuDataAddr->mod_uip_flag = 1 ;
    }
    SaveFile((INT8U *)"/config/xiuvalue.set",xiuzhengbuff,sizeof(xiuzhengbuff));
}

void modify_q(INT8U ch,INT8U *s)
{
    INT8U i;
    INT32S temp[16];
  if(MODE == 04)
  {

	  	    RtuDataAddr->display_xiu[4] = (RtuDataAddr->REC[0x05]/1100 - Kqa)/2 ;
			if( (abs(RtuDataAddr->display_xiu[4]))>PABCMAXXIU )
			{
			RtuDataAddr->display_xiu[4] =0;
			fprintf(stderr,"\r\nQa ��������\r\n");
			}

    		RtuDataAddr->display_xiu[5] = (RtuDataAddr->REC[0x06]/1100 - Kqb)/2 ;
			if( (abs(RtuDataAddr->display_xiu[5]))>PABCMAXXIU )
			{
			RtuDataAddr->display_xiu[5] =0;
			fprintf(stderr,"\r\nQB ��������\r\n");
			}

	    	RtuDataAddr->display_xiu[6] = (RtuDataAddr->REC[0x07]/1100 - Kqc)/2 ;
			if( (abs(RtuDataAddr->display_xiu[6]))>PABCMAXXIU )
			{
			RtuDataAddr->display_xiu[6] =0;
			fprintf(stderr,"\r\nQC ��������\r\n");
			}

	    	RtuDataAddr->display_xiu[7] = (RtuDataAddr->REC[0x08]/330 -  Kqz)/2 ;
			if( (abs(RtuDataAddr->display_xiu[7]))>PABCMAXXIU )
			{
			RtuDataAddr->display_xiu[7] =0;
			fprintf(stderr,"\r\nQZ ��������\r\n");
			}
			/////д����/////
			AT24Write(90,0x1);
			AT24Write(91,0x36);
			AT24Write(92,0x05);
			AT24Write(93,0x35);
			AT24Write(94,0x35);
			AT24Write(95,0x05);
			/////////////////

        	for(i=4;i<8;i++)
	       	{
	       	   	AT24Write(20+2*i,RtuDataAddr->display_xiu[i]&0xff);
	       	   	AT24Write(21+2*i,(RtuDataAddr->display_xiu[i]&0xff00)>>8);

		       	if(RtuDataAddr->display_xiu[i]>127)
		   	   	temp[i]=127;
		   	   	else if(RtuDataAddr->display_xiu[i]<-128)
		   	   	temp[i]=-128;
		   	   	else
		   	   	temp[i]= RtuDataAddr->display_xiu[i]&0xff;

		   	   	AT24Write(i,temp[i]);


	       	}
       		RtuDataAddr->mod_q_flag = 1 ;
  }
  if(MODE == 03)

  {

     	    RtuDataAddr->display_xiu[4] = (RtuDataAddr->REC[0x05]/433 - Kqa)/2 ;
			if( (abs(RtuDataAddr->display_xiu[4]))>PABCMAXXIU )
			{
			RtuDataAddr->display_xiu[4] =0;
			fprintf(stderr,"\r\nQa ��������\r\n");
			}

    		RtuDataAddr->display_xiu[6] = (RtuDataAddr->REC[0x07]/433 - Kqc)/2 ;
			if( (abs(RtuDataAddr->display_xiu[6]))>PABCMAXXIU )
			{
			RtuDataAddr->display_xiu[6] =0;
			fprintf(stderr,"\r\nQC ��������\r\n");
			}

	    	RtuDataAddr->display_xiu[7] = (RtuDataAddr->REC[0x08]*10/866 -  Kqz)/2 ;
			if( (abs(RtuDataAddr->display_xiu[7]))>PABCMAXXIU )
			{
			RtuDataAddr->display_xiu[7] =0;
			fprintf(stderr,"\r\nQa ��������\r\n");
			}

 			/////д����/////
			AT24Write(90,0x1);
			AT24Write(91,0x36);
			AT24Write(92,0x05);
			AT24Write(93,0x35);
			AT24Write(94,0x35);
			AT24Write(95,0x05);
			/////////////////


        	for(i=4;i<8;i++)
	       	{
	       	   	AT24Write(20+2*i,RtuDataAddr->display_xiu[i]&0xff);
	       	   	AT24Write(21+2*i,(RtuDataAddr->display_xiu[i]&0xff00)>>8);

		       	if(RtuDataAddr->display_xiu[i]>127)
		   	   	temp[i]=127;
		   	   	else if(RtuDataAddr->display_xiu[i]<-128)
		   	   	temp[i]=-128;
		   	   	else
		   	   	temp[i]= RtuDataAddr->display_xiu[i]&0xff;

		   	   	AT24Write(i,temp[i]);


	       	}

       		RtuDataAddr->mod_q_flag = 1 ;
  }
    SaveFile((INT8U *)"/config/xiuvalue.set",xiuzhengbuff,sizeof(xiuzhengbuff));
}
int write_apn()
{
	FILE *fp = NULL;

	fp=fopen("/etc/ppp/gprs-connect-chat","w");
	if (fp==NULL)
		return 0;
	fprintf(fp,"TIMEOUT        3\n");
	fprintf(fp,"ABORT        \'\\nBUSY\\r\'\n");
	fprintf(fp,"ABORT        \'\\nNO ANSWER\\r\'\n");
	fprintf(fp,"ABORT        \'\\nRINGING\\r\\n\\r\\nRINGING\\r\'\n");
	fprintf(fp,"\'\' \\rAT\n");
	fprintf(fp,"\'OK-+++\\c-OK\'    ATZ\n");
	fprintf(fp,"TIMEOUT        5\n");
	fprintf(fp,"OK        AT+CSQ\n");
	fprintf(fp,"OK        AT+CGDCONT=1,\"IP\",\"%s\"\n",RtuDataAddr->FkComm_Value.F3_Set_Para.APN);
	fprintf(fp,"OK        ATDT*99***1#\n");
	fprintf(fp,"CONNECT \'\'\n");
	fclose(fp);
	return 1;
}
int ASCToBCD(unsigned char * ASC, int Len, unsigned char *Ret) {
	int i, j, k;
	if (ASC != NULL) {
		for (i = 0; i < Len; i++) {
			if (ASC[i] <= '9')
				ASC[i] = ASC[i] - '0';
			else
				ASC[i] = ASC[i] - '7';
		}
		if (Len % 2 == 0) {
			//unsigned char *Ret=new char[Len/2+1];
			memset(Ret, 0, Len / 2 + 1);
			for (j = 0, k = 0; j < Len / 2; j++) {
				*(Ret + j) = (ASC[k] << 4) | ASC[k + 1];
				k++;
				k++;
			}
			//return Ret;
		}

	}
	return 0;
}
void CommandProcess(int argc, char *argv[])
{
	int temp1,temp2,temp3,temp4,temp5,i=0;
	FILE *fp;
	INT8U tmp[128];
    int m;
    m=0;
	uintptr_t BatIO;
	//---------------------------------------------------------------------------------
	struct tm tmpsec;
	struct timespec rtime;
	if (strcmp("test1",argv[1])==0)
	{
		INT8U name[128];
		INT8U ret66;
		sprintf((char *)name,"/nand/save/DayF2730Save%02d%02d.dat",12,1);
		//printf("read /nand/save/DayF2730Save%02x%02x.dat",11,4);
		ret66=ReadFile(name,(INT8U *)&RtuDataAddr->TF27_28_29_30_Mem[0].valid,sizeof(RtuDataAddr->TF27_28_29_30_Mem));
		if(ret66==0)
		{
			//memcpy(Dest,&RtuDataAddr->TF27_28_29_30_Mem[0].valid,sizeof(F27_28_29_30_level_stru));
			//printf("\n\r �������Խ�����ۼ�ʱ�� %d",RtuDataAddr->TF27_28_29_30_Mem[0].ISL_Count);
			printf("\n\r UA SS COUNT %d",RtuDataAddr->TF27_28_29_30_Mem[0].USSU_Count);
			printf("\n\r UA XX COUNT %d",RtuDataAddr->TF27_28_29_30_Mem[0].UXXU_Count);
			printf("\n\r UA S  COUNT %d",RtuDataAddr->TF27_28_29_30_Mem[0].USU_Count);
			printf("\n\r UA X  COUNT %d",RtuDataAddr->TF27_28_29_30_Mem[0].UXU_Count);
			printf("\n\r UA HEGCOUNT %d",RtuDataAddr->TF27_28_29_30_Mem[0].UHGU_Count);

			printf("\n\r UB SS COUNT %d",RtuDataAddr->TF27_28_29_30_Mem[0].USSV_Count);
			printf("\n\r UB XX COUNT %d",RtuDataAddr->TF27_28_29_30_Mem[0].UXXV_Count);
			printf("\n\r UB S  COUNT %d",RtuDataAddr->TF27_28_29_30_Mem[0].USV_Count);
			printf("\n\r UB X  COUNT %d",RtuDataAddr->TF27_28_29_30_Mem[0].UXV_Count);
			printf("\n\r UB HEGCOUNT %d",RtuDataAddr->TF27_28_29_30_Mem[0].UHGV_Count);

			printf("\n\r UC SS COUNT %d",RtuDataAddr->TF27_28_29_30_Mem[0].USSW_Count);
			printf("\n\r UC XX COUNT %d",RtuDataAddr->TF27_28_29_30_Mem[0].UXXW_Count);
			printf("\n\r UC S  COUNT %d",RtuDataAddr->TF27_28_29_30_Mem[0].USW_Count);
			printf("\n\r UC X  COUNT %d",RtuDataAddr->TF27_28_29_30_Mem[0].UXW_Count);
			printf("\n\r UC HEGCOUNT %d",RtuDataAddr->TF27_28_29_30_Mem[0].UHGW_Count);
			printf("\n\r -----------------------------------------------------------------");

			printf("\n\r UA Max %d   TIME : %x-%x-%x",RtuDataAddr->TF27_28_29_30_Mem[0].DUUMAX, RtuDataAddr->TF27_28_29_30_Mem[0].DUUMAX_TIME[2],RtuDataAddr->TF27_28_29_30_Mem[0].DUUMAX_TIME[1],RtuDataAddr->TF27_28_29_30_Mem[0].DUUMAX_TIME[0]);
			printf("\n\r UB Max %d   TIME : %x-%x-%x",RtuDataAddr->TF27_28_29_30_Mem[0].DUVMAX, RtuDataAddr->TF27_28_29_30_Mem[0].DUVMAX_TIME[2],RtuDataAddr->TF27_28_29_30_Mem[0].DUVMAX_TIME[1],RtuDataAddr->TF27_28_29_30_Mem[0].DUVMAX_TIME[0]);
			printf("\n\r UC Max %d   TIME : %x-%x-%x",RtuDataAddr->TF27_28_29_30_Mem[0].DUWMAX, RtuDataAddr->TF27_28_29_30_Mem[0].DUWMAX_TIME[2],RtuDataAddr->TF27_28_29_30_Mem[0].DUWMAX_TIME[1],RtuDataAddr->TF27_28_29_30_Mem[0].DUWMAX_TIME[0]);
			printf("\n\r -----------------------------------------------------------------");
			printf("\n\r UA min %d",RtuDataAddr->YF27_28_29_30_Mem[i].DUUMIN);

			int iid;
			unsigned char type;
			for(iid=0;iid<8;iid++)
			{
				if (RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[iid].GuiYue_Type == JiaoLiuType)
				{
					type = RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[iid].GuiYue_Type;
					printf("\n\r guiyue=%d iid=%d  celiangno = %d",type,iid,RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[iid].CeLiangNo);
				}
			}
			fprintf(stderr,"\n\r-  UA=%d",RtuDataAddr->FkDdRealData.VA);
			fprintf(stderr,"\n\r-  UB=%d",RtuDataAddr->FkDdRealData.VB);
			fprintf(stderr,"\n\r-  UC=%d",RtuDataAddr->FkDdRealData.VC);
		}
		else
			printf("\n\r  read erro");
		return;
	}
//�ʼ�С�Ʋ����¼�
	if(strcmp("led",argv[1])==0)
	{
		sscanf(argv[2],"%d",&temp1);
		if (temp1==1)
		{
			ClearSpiLed(LUNCI1);
			ClearSpiLed(LUNCI2);
			ClearSpiLed(LUNCI3);
			ClearSpiLed(LUNCI4);
			SetSpiLed(GKACT);
			SetSpiLed(DKACT);
			SetSpiLed(ALARM_LED);
		}
		if (temp1==0)
		{
			SetSpiLed(0);SetSpiLed(1);SetSpiLed(2);SetSpiLed(3);
			ClearSpiLed(GKACT);ClearSpiLed(DKACT);
			ClearSpiLed(ALARM_LED);
		}
		return;
	}
//����led�Ʋ��Խ���
	if(strcmp("ykon",argv[1])==0)
	{
		system("po -1 0x50000002 0xaa");
		delay(200);
		system("po -1 0x50000010 1");
		system("po -1 0x50000012 1");
		system("po -1 0x50000014 1");
		system("po -1 0x50000016 1");
		system("po -1 0x50000008 1");
		system("po -1 0x50000006 1");
		return;
	}
	if(strcmp("ykoff",argv[1])==0)
	{
		system("po -1 0x50000010 0");
		system("po -1 0x50000012 0");
		system("po -1 0x50000014 0");
		system("po -1 0x50000016 0");
		system("po -1 0x50000008 0");
		system("po -1 0x50000006 0");
		return;
	}
	if (strcmp("meter", argv[1]) == 0) {
		//fkset meter 2 1 1 1200 1 000000000001
		//fkset meter ��������   �������   �˿ں�   ������   ��Լ    ��ַ
		INT8U dizhi[12]={0},metaddr[6];
		memset(dizhi,0,12);
		if (argc == 2) {
		} else {
			int no,meter,port,baud,type;
			if (sscanf(argv[2], "%d", &no)) {
				if (no>CeLiangPoint_Max)
				{
					return;
				}
				RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num=no;
			}
			if (sscanf(argv[3], "%d",&meter)) {
				if (meter==0)
				{
					meter=1;
				}
				RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[meter-1].CeLiangNo=meter;
			}
			if (sscanf(argv[4], "%d", &port)) {
			}
			if (sscanf(argv[5], "%d",&baud)) {

			}
			if (sscanf(argv[6], "%d",&type)) {
				RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[meter-1].GuiYue_Type=type;
			}
			if (sscanf(argv[2], "%d-%d-%d-%d-%d", &no,&meter,&port,&baud,&type)) {

			}
				RtuDataAddr->FkInput_Value.F10_Set_Para.Valid=1;

				RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[meter-1].BaudAndPort=((baud/600)<<5)|port;
			if (argc >= 7){
				memset(metaddr,0,6);
				for(i=0;i<12;i++)
					dizhi[i]='0';
				for(i=0;i<strlen(argv[7]);i++)
					dizhi[11-i]=argv[7][strlen(argv[7])-i-1];
				ASCToBCD(dizhi,12,&metaddr[0]);
			}
				for(i=0;i<6;i++)
					RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[meter-1].Addr[i]=metaddr[5-i];
				printf("point meterno=%d,baud=%d port=%d type=%d,addr=%02x%02x%02x%02x%02x%02x\n\r",
						RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[meter-1].CeLiangNo,
						(RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[meter-1].BaudAndPort>>5)*600,
						RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[meter-1].BaudAndPort&0x1f,
						RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[meter-1].GuiYue_Type,
						RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[meter-1].Addr[5],
						RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[meter-1].Addr[4],
						RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[meter-1].Addr[3],
						RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[meter-1].Addr[2],
						RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[meter-1].Addr[1],
						RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[meter-1].Addr[0]);
				Save_Input_Set();

			}
		return;
		}
	if(strcmp("time",argv[1])==0)
	{
		if (argc==2)
		{
			TS ts;
			TSGet(&ts);
			printf("\n\rsystem time is: %d-%d-%d %d:%d",ts.Year,ts.Month,ts.Day,ts.Hour,ts.Minute);
			return;
		}else
		{
			m=sscanf(argv[2],"%d-%d-%d-%d-%d",&temp1,&temp2,&temp3,&temp4,&temp5);
			printf("\n\r m=========%d",m);
			if(sscanf(argv[2],"%d-%d-%d-%d-%d",&temp1,&temp2,&temp3,&temp4,&temp5)==5)
			{
				tmpsec.tm_sec = 0;
				tmpsec.tm_min = temp5;
				tmpsec.tm_hour = temp4;
				tmpsec.tm_mday = temp3;
				tmpsec.tm_mon = temp2 - 1;
				tmpsec.tm_year = temp1 - 1900;
				printf("\n\ryear=%d   month=%d   day=%d hour=%d  min=%d",tmpsec.tm_year,tmpsec.tm_mon,tmpsec.tm_mday,tmpsec.tm_hour,tmpsec.tm_min);
				printf("\n\r");
				rtime.tv_sec = mktime(&tmpsec);
				printf("\n\rrtime.tv_sec ===%lld",rtime.tv_sec );
				rtime.tv_nsec = 500* 10000 ;clock_settime(CLOCK_REALTIME,&rtime);
				RtuDataAddr->settime2=1;
				return;
			}
		}
	}
	//---------------------------------------------------------------------------------
	if(strcmp("bat",argv[1])==0)
	{
		sscanf(argv[2],"%d",&temp1);
		if (temp1)
		{
			BatIO = mmap_device_io(0x10,0x5000000A);//�򿪵��
			out8(BatIO,1);
		}else
		{
			BatIO = mmap_device_io(0x10,0x5000000A);//�رյ��
			out8(BatIO,0);
		}
		return;
		//printf("out8 %d\n",temp1);
	}

	if(strcmp("ip",argv[1])==0)
	{
		if(argc==2)
		{
			temp1=RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[0];
			temp2=RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[1];
			temp3=RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[2];
			temp4=RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[3];
			temp5=RtuDataAddr->FkComm_Value.F3_Set_Para.PortMaster[1];
			temp5=(temp5<<8)+RtuDataAddr->FkComm_Value.F3_Set_Para.PortMaster[0];
			fprintf(stderr,"\r\nip %d.%d.%d.%d:%d\r\n",temp1,temp2,temp3,temp4,temp5);
		}
		else
		{
			if(sscanf(argv[2],"%d.%d.%d.%d:%d",&temp1,&temp2,&temp3,&temp4,&temp5)==5)
			{
				fprintf(stderr,"\r\nset ip %d.%d.%d.%d:%d\r\n",temp1,temp2,temp3,temp4,temp5);
				if((RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[0]!=temp1)||(RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[1]!=temp2)
					||(RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[2]!=temp3)||(RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[3]!=temp4)
					||(RtuDataAddr->FkComm_Value.F3_Set_Para.PortMaster[1]!=temp5>>8)||(RtuDataAddr->FkComm_Value.F3_Set_Para.PortMaster[0]!=temp5&0xff))
					RtuDataAddr->Gprs_ok=0;

				RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[0]=temp1;
				RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[1]=temp2;
				RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[2]=temp3;
				RtuDataAddr->FkComm_Value.F3_Set_Para.IPMaster[3]=temp4;
				RtuDataAddr->FkComm_Value.F3_Set_Para.PortMaster[1]=temp5>>8;
				RtuDataAddr->FkComm_Value.F3_Set_Para.PortMaster[0]=temp5&0xff;
				RtuDataAddr->FkComm_Value.F3_Set_Para.Valid=1;

			}
		}
	}

	if(strcmp("netip",argv[1])==0)
	{
		unsigned char tmp[128];
		memset(tmp,0,128);
		if(argc==2)
		{
			temp1=RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[0];
			temp2=RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[1];
			temp3=RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[2];
			temp4=RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[3];

			fprintf(stderr,"\r\nnetip %d.%d.%d.%d\r\n",temp1,temp2,temp3,temp4);
		}
		else
		{
			if(sscanf(argv[2],"%d.%d.%d.%d",&temp1,&temp2,&temp3,&temp4)==4)
			{
				fprintf(stderr,"\r\nset netip %d.%d.%d.%d\r\n",temp1,temp2,temp3,temp4);
				if((RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[0]!=temp1)||(RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[1]!=temp2)
					||(RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[2]!=temp3)||(RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[3]!=temp4))
					RtuDataAddr->Gprs_ok=0;

				RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[0]=temp1;
				RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[1]=temp2;
				RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[2]=temp3;
				RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[3]=temp4;

				sprintf((char *)tmp,"ifconfig en0 %d.%d.%d.%d up",
				RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[0]
				,RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[1]
				,RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[2]
				,RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[3]);
				system((char *)tmp);

				memset(tmp,0,128);
				sprintf((char *)tmp,"echo \"ifconfig en0 %d.%d.%d.%d up\" > /etc/rc.d/ip.sh",RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[0]
				,RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[1]
				,RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[2]
				,RtuDataAddr->FkInput_Value.F7_Set_Para.IPMaster[3]);
				system((char *)tmp);
				RtuDataAddr->FkInput_Value.F7_Set_Para.Valid=1;
			}
		}
	}
	if (strcmp("test1",argv[1])==0)
	{
		INT8U name[128];
		INT8U ret66;
		sprintf((char *)name,"/nand/save/DayF2730Save%02d%02d.dat",11,4);
		//printf("read /nand/save/DayF2730Save%02x%02x.dat",11,4);
		ret66=ReadFile(name,(INT8U *)&RtuDataAddr->TF27_28_29_30_Mem[0].valid,sizeof(RtuDataAddr->TF27_28_29_30_Mem));
		if(ret66==0)
		{
			//memcpy(Dest,&RtuDataAddr->TF27_28_29_30_Mem[0].valid,sizeof(F27_28_29_30_level_stru));
			//printf("\n\r �������Խ�����ۼ�ʱ�� %d",RtuDataAddr->TF27_28_29_30_Mem[0].ISL_Count);
			printf("\n\r UA SS COUNT %d",RtuDataAddr->TF27_28_29_30_Mem[0].USSU_Count);
			printf("\n\r UA XX COUNT %d",RtuDataAddr->TF27_28_29_30_Mem[0].UXXU_Count);
			printf("\n\r UA S  COUNT %d",RtuDataAddr->TF27_28_29_30_Mem[0].USU_Count);
			printf("\n\r UA X  COUNT %d",RtuDataAddr->TF27_28_29_30_Mem[0].UXU_Count);
			printf("\n\r UA HEGCOUNT %d",RtuDataAddr->TF27_28_29_30_Mem[0].UHGU_Count);

			printf("\n\r UB SS COUNT %d",RtuDataAddr->TF27_28_29_30_Mem[0].USSV_Count);
			printf("\n\r UB XX COUNT %d",RtuDataAddr->TF27_28_29_30_Mem[0].UXXV_Count);
			printf("\n\r UB S  COUNT %d",RtuDataAddr->TF27_28_29_30_Mem[0].USV_Count);
			printf("\n\r UB X  COUNT %d",RtuDataAddr->TF27_28_29_30_Mem[0].UXV_Count);
			printf("\n\r UB HEGCOUNT %d",RtuDataAddr->TF27_28_29_30_Mem[0].UHGV_Count);

			printf("\n\r UC SS COUNT %d",RtuDataAddr->TF27_28_29_30_Mem[0].USSW_Count);
			printf("\n\r UC XX COUNT %d",RtuDataAddr->TF27_28_29_30_Mem[0].UXXW_Count);
			printf("\n\r UC S  COUNT %d",RtuDataAddr->TF27_28_29_30_Mem[0].USW_Count);
			printf("\n\r UC X  COUNT %d",RtuDataAddr->TF27_28_29_30_Mem[0].UXW_Count);
			printf("\n\r UC HEGCOUNT %d",RtuDataAddr->TF27_28_29_30_Mem[0].UHGW_Count);

		}
		else
			printf("\n\r  read erro");
		return;
	}
  	if(strcmp("task",argv[1])==0)
	{
		int i,j=0;
		int k=0;
		printf("\n\rF65 TASK:");
		for (i = 0; i < Task_Max; i++)
		{
			if (RtuDataAddr->Task_Value[i].F65_Set_Para.Valid == 1)
			{
				printf("\n\r  FaSong_ZhouQi:%02x,  Ji_Zhun_Shi_Jian:",
					RtuDataAddr->Task_Value[i].F65_Set_Para.FaSong_ZhouQi);
				for(k=0;k<6;k++)
					printf("%02x ",RtuDataAddr->Task_Value[i].F65_Set_Para.Ji_Zhun_Shi_Jian[k]);
				printf("BiaoShiNum: %02x ",RtuDataAddr->Task_Value[i].F65_Set_Para.ShuJv_DanYuan_Num);
				printf("Beilv: %d ",RtuDataAddr->Task_Value[i].F65_Set_Para.Qu_Xian_ChouQu_BeiLv);
				for(j=0;j<RtuDataAddr->Task_Value[i].F65_Set_Para.ShuJv_DanYuan_Num;j++)
				{
					printf("DA[%d]:%02x %02x ",j,RtuDataAddr->Task_Value[i].F65_Set_Para.DanYuan_BiaoShi[j][0],RtuDataAddr->Task_Value[i].F65_Set_Para.DanYuan_BiaoShi[j][1]);
					printf("DT[%d]:%02x %02x ",j,RtuDataAddr->Task_Value[i].F65_Set_Para.DanYuan_BiaoShi[j][2],RtuDataAddr->Task_Value[i].F65_Set_Para.DanYuan_BiaoShi[j][3]);
				}
			}
		}
		printf("\n\rF66 TASK:");
		for (i = 0; i < Task_Max; i++)
		{
			printf("\n\rTask_Value[%d].F68_Set_Para.Valid==%d",i,RtuDataAddr->Task_Value[i].F68_Set_Para.Valid);
			printf("\n\rTask_Value[%d].F68_Set_Para.type_2_Task_Enable==%x",i,RtuDataAddr->Task_Value[i].F68_Set_Para.type_2_Task_Enable);
			if (RtuDataAddr->Task_Value[i].F66_Set_Para.Valid == 1)
			{
				printf("\n\r  FaSong_ZhouQi:%02x,  Ji_Zhun_Shi_Jian:",
					RtuDataAddr->Task_Value[i].F66_Set_Para.FaSong_ZhouQi);
				for(k=0;k<6;k++)
					printf("%02x ",RtuDataAddr->Task_Value[i].F66_Set_Para.Ji_Zhun_Shi_Jian[k]);
				printf("BiaoShiNum: %02x ",RtuDataAddr->Task_Value[i].F66_Set_Para.ShuJv_DanYuan_Num);
				printf("Beilv: %d ",RtuDataAddr->Task_Value[i].F66_Set_Para.Qu_Xian_ChouQu_BeiLv);
				for(j=0;j<RtuDataAddr->Task_Value[i].F66_Set_Para.ShuJv_DanYuan_Num;j++)
				{
					printf("DA[%d]:%02x %02x ",j,RtuDataAddr->Task_Value[i].F66_Set_Para.DanYuan_BiaoShi[j][0],RtuDataAddr->Task_Value[i].F66_Set_Para.DanYuan_BiaoShi[j][1]);
					printf("DT[%d]:%02x %02x \n\r",j,RtuDataAddr->Task_Value[i].F66_Set_Para.DanYuan_BiaoShi[j][2],RtuDataAddr->Task_Value[i].F66_Set_Para.DanYuan_BiaoShi[j][3]);
				}
			}
		}
		return;
	}
	if(strcmp("id",argv[1])==0)
	{
		if(argc==2)
		{
			temp1=RtuDataAddr->FkComm_Value.GB22601991[0];
			temp2=RtuDataAddr->FkComm_Value.GB22601991[1];
			temp3=RtuDataAddr->FkComm_Value.ADDR[1];
			temp3=(temp3<<8)+RtuDataAddr->FkComm_Value.ADDR[0];
			fprintf(stderr,"\r\nid %x-%x-%04x\r\n",temp2,temp1,temp3);
		}
		else
		{
			fprintf(stderr,"%s ",argv[2]);
			if(sscanf(argv[2],"%x-%x-%04x",&temp2,&temp1,&temp3)==3)
			{
			fprintf(stderr,"\r\nset id %x-%x-%04x\r\n",temp2,temp1,temp3);
			RtuDataAddr->FkComm_Value.GB22601991[0]=temp1;
			RtuDataAddr->FkComm_Value.GB22601991[1]=temp2;
			RtuDataAddr->FkComm_Value.ADDR[1]=(temp3>>8)&0xff;
			RtuDataAddr->FkComm_Value.ADDR[0]=temp3&0xff;
			}
		}
	}
	if (strcmp("hrt", argv[1]) == 0) {
		int HeartBeat;
		if (argc == 2) {
			printf("\n\r");
			HeartBeat = RtuDataAddr->FkComm_Value.F1_Set_Para.Heart_Beat;
			fprintf(stderr, "\n\rHeart %d\n\r", HeartBeat);
		} else {
			if (sscanf(argv[2], "%d",&HeartBeat)) {

				RtuDataAddr->FkComm_Value.F1_Set_Para.Heart_Beat=HeartBeat;
				printf("\n\r");
				printf("Heart %d", HeartBeat);
				printf("\n\r");
				Save_CommSet();
			}
		}
		return;
	}
	if (strcmp("mettm", argv[1]) == 0) {
		int MeterTime,prt;
		if (argc == 2) {
			printf("\n\r");
			if(RtuDataAddr->FkInput_Value.New_F33_Set_Para.Valid==1){
				MeterTime = RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[0].ChaoBiaoJianGe;
				fprintf(stderr, "\n\rRead Time1 %d\n\r", MeterTime);
				MeterTime = RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[1].ChaoBiaoJianGe;
				fprintf(stderr, "\n\rRead Time2 %d\n\r", MeterTime);
				MeterTime = RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[2].ChaoBiaoJianGe;
				fprintf(stderr, "\n\rRead Time3 %d\n\r", MeterTime);
			}else
			{
				MeterTime = 5;
				fprintf(stderr, "\n\rRead Time1 %d\n\r", MeterTime);
				fprintf(stderr, "\n\rRead Time2 %d\n\r", MeterTime);
				fprintf(stderr, "\n\rRead Time3 %d\n\r", MeterTime);
			}
		} else {
			if (sscanf(argv[2], "%d-%d",&prt,&MeterTime)) {
				RtuDataAddr->FkInput_Value.New_F33_Set_Para.Valid=1;
				RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai_Num=3;
				RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[prt-1].PortNo=prt;
				RtuDataAddr->FkInput_Value.New_F33_Set_Para.CanShuKuai[prt-1].ChaoBiaoJianGe=MeterTime;
				printf("\n\r");
				printf("Read Time %d", MeterTime);
				printf("\n\r");
				Save_Input_Set();
			}
		}
		return;
	}
	if (strcmp("sv", argv[1]) == 0) {
		unsigned char sv[32];
		memset(sv,0,32);
		if (argc == 2) {
			printf("\n\r");
			memcpy(sv,RtuDataAddr->ucsysVER,sizeof(RtuDataAddr->ucsysVER));
			fprintf(stderr, "\n\rSoftware Version is  %s\n\r", sv);
		}
		return;
	}
	if (strcmp("look", argv[1]) == 0)
	{
		int baud=1200;
		if (argc == 2)
		{
			printf("\n\rindex  ConnectType  baud   port    Address\n\r");
			for(i=0;i<RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num;i++)
			{
				switch((RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].BaudAndPort>>5)&0x07)
				{
					case 1:
						baud=600;
						break;
					case 2:
						baud=1200;
						break;
					case 3:
						baud=2400;
						break;
					case 4:
						baud=4800;
						break;
					case 5:
						baud=7200;
						break;
					case 6:
						baud=9600;
						break;
					case 7:
						baud=19200;
						break;
					default:
						baud=(RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].BaudAndPort>>5)&0x07;
						break;
				}
				printf("%d      %d            %d     %d     %02x%02x%02x%02x%02x%02x\n\r",
				RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].CeLiangNo,
				RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].GuiYue_Type,
				baud,
				RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].BaudAndPort&0x1f,
				RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Addr[5],
				RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Addr[4],
				RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Addr[3],
				RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Addr[2],
				RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Addr[1],
				RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].Addr[0]);
			}
		}
		return;
	}
	/////////////////////////////////////////////////////////
	//��ʾ���ɵ�ֵ   �鿴��ѹ��������
	if(strcmp("jccheck",argv[1])==0)
	{
		float fUa=0, fUb=0, fUc=0, fIa=0, fIb=0, fIc=0, fPa=0, fPb=0, fPc=0 ,fP=0;
		float jdUa=0, jdUb=0, jdUc=0, jdIa=0, jdIb=0, jdIc=0, jdPa=0, jdPb=0, jdPc=0, jdP=0;
		int flagUa=0, flagUb=0, flagUc=0, flagIa=0, flagIb=0, flagIc=0, flagPa=0, flagPb=0, flagPc=0;
		int   flagP=0;
		if (RtuDataAddr->RES.RES_JXFS == 04)//��������
		{
			printf("\n\r*************************************************************************\n\r");
			printf("\n\r    FuKong Diban U I P jingdu  **3 xiang 4 xian**  220v 5A 60\n\r");
			printf("\n\r*************************************************************************\n\r");

			fUa=(float)RtuDataAddr->FkDdRealData.VA/10;
			fUb=(float)RtuDataAddr->FkDdRealData.VB/10;
			fUc=(float)RtuDataAddr->FkDdRealData.VC/10;

			fIa=(float)RtuDataAddr->FkDdRealData.IA/100;
			fIb=(float)RtuDataAddr->FkDdRealData.IB/100;
			fIc=(float)RtuDataAddr->FkDdRealData.IC/100;

			fPa=(float)RtuDataAddr->FkDdRealData.PA/10000;
			fPb=(float)RtuDataAddr->FkDdRealData.PB/10000;
			fPc=(float)RtuDataAddr->FkDdRealData.PC/10000;
			fP=(float)RtuDataAddr->FkDdRealData.P/10000;

			if((jdUa=(fUa-100)/100)<0) jdUa=-jdUa;
			if((jdUb=(fUb-100)/100)<0) jdUb=-jdUb;
			if((jdUc=(fUc-100)/100)<0) jdUc=-jdUc;
			if(jdUa<=0.005) flagUa=1;
			if(jdUb<=0.005) flagUb=1;
			if(jdUc<=0.005) flagUc=1;

			if((jdIa=(fIa-5)/5)<0) jdIa=-jdIa;
			if((jdIb=(fIb-5)/5)<0) jdIb=-jdIb;
			if((jdIc=(fIc-5)/5)<0) jdIc=-jdIc;
			if(jdIa<=0.005) flagIa=1;
			if(jdIb<=0.005) flagIb=1;
			if(jdIc<=0.005) flagIc=1;

			if((jdPa=(fPa-0.433)/0.433)<0) jdPa=-jdPa;
			if((jdPb=(fPb-0.433)/0.433)<0) jdPb=-jdPb;
			if((jdPc=(fPc-0.433)/0.433)<0) jdPc=-jdPc;
			if((jdP=(fP-0.866)/0.866)<0) jdP=-jdP;
			if(jdPa<=0.005) flagPa=1;
			if(jdPb<=0.005) flagPb=1;
			if(jdPc<=0.005) flagPc=1;
			if(jdP<=0.005) flagP=1;

			printf("\n\rUa=%5.1f  V    JingDu=%5.1f", fUa, (float)((int)(jdUa*10*100))/10);
			if(flagUa == 1)
				printf("    OK! \n\r");
			else
				printf("    ERROR! \n\r");
			printf("\n\rUb=%5.1f  V    JingDu=%5.1f", fUb, (float)((int)(jdUb*10*100))/10);
			if(flagUb == 1)
				printf("    OK! \n\r");
			else
				printf("    ERROR! \n\r");
			printf("\n\rUc=%5.1f  V    JingDu=%5.1f", fUc, (float)((int)(jdUc*10*100))/10);
			if(flagUc == 1)
				printf("    OK! \n\r");
			else
				printf("    ERROR! \n\r");

			printf("\n\r Ia=%5.4f  A    JingDu=%5.1f", fIa, (float)((int)(jdIa*10*100))/10);
			if(flagIa == 1)
				printf("    OK! \n\r");
			else
				printf("    ERROR! \n\r");
			printf("\n\r Ib=%5.4f  A    JingDu=%5.1f", fIa, (float)((int)(jdIb*10*100))/10);
			if(flagIb == 1)
				printf("    OK! \n\r");
			else
				printf("    ERROR! \n\r");
			printf("\n\r Ic=%5.4f  A    JingDu=%5.1f", fIc, (float)((int)(jdIc*10*100))/10);
			if(flagIc == 1)
				printf("    OK! \n\r");
			else
				printf("    ERROR! \n\r");

			printf("\n\r Pa=%5.4f kw   JingDu=%5.1f",fPa, (float)((int)(jdPa*10*100))/10);
			if(flagPa == 1)
				printf("    OK! \n\r");
			else
				printf("    ERROR! \n\r");
			printf("\n\r Pb=%5.4f kw   JingDu=%5.1f",fPb, (float)((int)(jdPb*10*100))/10);
			if(flagPb == 1)
				printf("    OK! \n\r");
			else
				printf("    ERROR! \n\r");
			printf("\n\r Pc=%5.4f kw   JingDu=%5.1f",fPc, (float)((int)(jdPc*10*100))/10);
			if(flagPc == 1)
				printf("    OK! \n\r");
			else
				printf("    ERROR! \n\r");

			printf("\n\r P=%5.4f kw    JingDu=%5.1f",fP, (float)((int)(jdP*10*100))/10);
			if(flagP == 1)
				printf("    OK! \n\r");
			else
				printf("    ERROR! \n\r");

			printf("\n\r");
		}
		else if(RtuDataAddr->RES.RES_JXFS == 03)//��������
		{
			printf("\n\r*************************************************************************\n\r");
			printf("\n\r    FuKong Diban U I P JingDu  **3 xiang 3 xian** 100v 5A 0\n\r");
			printf("\n\r*************************************************************************\n\r");


			fUa=(float)RtuDataAddr->FkDdRealData.VA/10;
			fUc=(float)RtuDataAddr->FkDdRealData.VC/10;

			fIa=(float)RtuDataAddr->FkDdRealData.IA/100;
			fIc=(float)RtuDataAddr->FkDdRealData.IC/100;

			fPa=(float)RtuDataAddr->FkDdRealData.PA/10000;
			fPc=(float)RtuDataAddr->FkDdRealData.PC/10000;
			fP=(float)RtuDataAddr->FkDdRealData.P/10000;

			if((jdUa=(fUa-100)/100)<0) jdUa=-jdUa;
			if((jdUc=(fUc-100)/100)<0) jdUc=-jdUc;
			if(jdUa<=0.005) flagUa=1;
			if(jdUc<=0.005) flagUc=1;

			if((jdIa=(fIa-5)/5)<0) jdIa=-jdIa;
			if((jdIc=(fIc-5)/5)<0) jdIc=-jdIc;
			if(jdIa<=0.005) flagIa=1;
			if(jdIc<=0.005) flagIc=1;

			if((jdPa=(fPa-0.433)/0.433)<0) jdPa=-jdPa;
			if((jdPc=(fPc-0.433)/0.433)<0) jdPc=-jdPc;
			if((jdP=(fP-0.866)/0.866)<0) jdP=-jdP;
			if(jdPa<=0.005) flagPa=1;
			if(jdPc<=0.005) flagPc=1;
			if(jdP<=0.005) flagP=1;

			printf("\n\rUab=%5.1f  V    JingDu=%5.1f", fUa, (float)((int)(jdUa*10*100))/10);
			if(flagUa == 1)
				printf("    OK! \n\r");
			else
				printf("    ERROR! \n\r");
			printf("\n\rUcb=%5.1f  V    JingDu=%5.1f", fUc, (float)((int)(jdUc*10*100))/10);
			if(flagUc == 1)
				printf("    OK! \n\r");
			else
				printf("    ERROR! \n\r");

			printf("\n\r Ia=%5.4f  A   JingDu=%5.1f", fIa, (float)((int)(jdIa*10*100))/10);
			if(flagIa == 1)
				printf("    OK! \n\r");
			else
				printf("    ERROR! \n\r");

			printf("\n\r Ic=%5.4f  A   JingDu=%5.1f", fIc, (float)((int)(jdIc*10*100))/10);
			if(flagIc == 1)
				printf("    OK! \n\r");
			else
				printf("    ERROR! \n\r");

			printf("\n\r Pa=%5.4f kw   JingDu=%5.1f",fPa, (float)((int)(jdPa*10*100))/10);
			if(flagPa == 1)
				printf("    OK! \n\r");
			else
				printf("    ERROR! \n\r");
			printf("\n\r Pc=%5.4f kw   JingDu=%5.1f",fPc, (float)((int)(jdPc*10*100))/10);
			if(flagPc == 1)
				printf("    OK! \n\r");
			else
				printf("    ERROR! \n\r");

			printf("\n\r P=%5.4f kw    JingDu=%5.1f",fP, (float)((int)(jdP*10*100))/10);
			if(flagP == 1)
				printf("    OK! \n\r");
			else
				printf("    ERROR! \n\r");

			printf("\n\r");
		}
		else
			printf("\n\rJie xian fang shi error!!!!!");
		return;
	}

	if(strcmp("dl",argv[1])==0)
	{
		if(argc==2)
		{
			fprintf(stderr,"\r\ndl %d\r\n",RtuDataAddr->Real_Zj_Value[0].P_All);
		}
		else
		{
			fprintf(stderr,"%s ",argv[2]);
			if(sscanf(argv[2],"%d",&RtuDataAddr->Real_Zj_Value[0].P_All)==1)
			{
			fprintf(stderr,"\r\nset dl %d\r\n",RtuDataAddr->Real_Zj_Value[0].P_All);
			}
		}

		return;
	}
	if(strcmp("eve",argv[1])==0)
	{
		if(argc>2)
		{
			 RtuDataAddr->DD_Device_BiaoShi_Value[0].Valid = 1;
			 sscanf(argv[2],"%d",&RtuDataAddr->DD_Device_BiaoShi_Value[0].Z_P_All);
			 printf("\n\r Z-P-ALL %d",RtuDataAddr->DD_Device_BiaoShi_Value[0].Z_P_All);
		}
		return;
	}
	if(strcmp("xf",argv[1])==0)
	{
		if(argc==2)
		{
			fprintf(stderr,"\r\n P_All  %d\r\n",RtuDataAddr->Real_Zj_Value[2].P_All);
		}
		else
		{
			sscanf(argv[2],"%d",&RtuDataAddr->Real_Zj_Value[2].P_All);
			fprintf(stderr,"\r\n set xf P_ALL = %d\r\n",RtuDataAddr->Real_Zj_Value[2].P_All);
		}
		return;
	}
	/////////////////////////////////////////////////////
	if(strcmp("apn",argv[1])==0)
	{
		if(argc==2)
		{
			fprintf(stderr,"\r\napn %s\r\n",RtuDataAddr->FkComm_Value.F3_Set_Para.APN);
		}
		else
		{
			memset(RtuDataAddr->FkComm_Value.F3_Set_Para.APN,0,sizeof(RtuDataAddr->FkComm_Value.F3_Set_Para.APN));
			memcpy(RtuDataAddr->FkComm_Value.F3_Set_Para.APN,argv[2],strlen(argv[2]));
			write_apn();
			fprintf(stderr,"\r\nset apn %s\r\n",RtuDataAddr->FkComm_Value.F3_Set_Para.APN);
		}
	}
	if(strcmp("code",argv[1])==0)
	{
		if(argc==2)
		{
			fprintf(stderr,"\r\ncode %s \r\n",RtuDataAddr->FkComm_Value.DevCode);
		}
		else
		{
			memset(RtuDataAddr->FkComm_Value.DevCode,0,sizeof(RtuDataAddr->FkComm_Value.DevCode));
			memcpy(RtuDataAddr->FkComm_Value.DevCode,argv[2],strlen(argv[2]));
			fprintf(stderr,"\r\nset code %s\r\n",RtuDataAddr->FkComm_Value.DevCode);
		}
	}

	if (strcmp("net",argv[1])==0)
	{
		if (argc==2)
			fprintf(stderr,"\r\n NetSelect %d\r\n",RtuDataAddr->FkComm_Value.Netselect);
		else
		{
			sscanf(argv[2],"%d",&temp1);
			switch (temp1)
			{
				case 1:
					RtuDataAddr->FkComm_Value.Netselect = 1;//��̫��
					break;
				case 2:
					RtuDataAddr->FkComm_Value.Netselect = 2;//����ģ��
					break;
				default:
					RtuDataAddr->FkComm_Value.Netselect = 0;//��Ч�����
					break;
			}
		}
	}
	if (strcmp("f8",argv[1])==0)
	{
		if (argc==2)
		{
			fprintf(stderr,"\r\nf8 valid = %d",RtuDataAddr->FkComm_Value.F8_Set_Para.Valid);
			fprintf(stderr,"\r\nf8 gprsmode = %d",RtuDataAddr->FkComm_Value.F8_Set_Para.GPRS_MODE);
		}else
		{
			sscanf(argv[2],"%d",&temp1);
			if (temp1 == 1)
			{
				RtuDataAddr->FkComm_Value.F8_Set_Para.Valid = 1;
				RtuDataAddr->FkComm_Value.F8_Set_Para.GPRS_MODE = 1;
				fprintf(stderr,"\r\nf8 valid = %d",RtuDataAddr->FkComm_Value.F8_Set_Para.Valid);
				fprintf(stderr,"\r\nf8 gprsmode = %d",RtuDataAddr->FkComm_Value.F8_Set_Para.GPRS_MODE);
			}
		}
	}
	if(strcmp("d",argv[1])==0)
	{
		if(argc==2)
		{
			fprintf(stderr,"\r\n WIRELESSDBON %d\r\n",RtuDataAddr->WIRELESSDBON);
			fprintf(stderr,"\r\n TASK130DBON %d\r\n",RtuDataAddr->TASK130DBON);
			fprintf(stderr,"\r\n DATASAVEDBON %d\r\n",RtuDataAddr->DATASAVEDBON);
			fprintf(stderr,"\r\n DLT645DBON %d\r\n",RtuDataAddr->DLT645DBON);
			fprintf(stderr,"\r\n DATACALCDBON %d\r\n",RtuDataAddr->DATACALCDBON);
			fprintf(stderr,"\r\n DBON %d\r\n",RtuDataAddr->DBON);
			fprintf(stderr,"\r\n SYSTENDBON %d\r\n",RtuDataAddr->SYSTENDBON);
			fprintf(stderr,"\r\n IFRDBON %d\r\n",RtuDataAddr->IFRDBON);
			fprintf(stderr,"\r\n CONTROLDBON %d\r\n",RtuDataAddr->CONTROLDBON);
			return;
		}
		else
		{
			sscanf(argv[2],"%d",&temp1);
			switch(temp1)
			{
				case 10:
					RtuDataAddr->WIRELESSDBON=0;
					RtuDataAddr->TASK130DBON=0;
					RtuDataAddr->DATASAVEDBON=0;
					RtuDataAddr->DLT645DBON=0;
					RtuDataAddr->DATACALCDBON=0;
					RtuDataAddr->DBON=0;
					RtuDataAddr->SYSTENDBON=0;
					RtuDataAddr->IFRDBON=0;
					RtuDataAddr->CONTROLDBON=0;
					RtuDataAddr->XIEBOPRT=0;
				break;
				case 1:
					RtuDataAddr->WIRELESSDBON=1;
				break;
				case 2:
					RtuDataAddr->TASK130DBON=1;
				break;
				case 3:
					RtuDataAddr->DATASAVEDBON=1;
				break;
				case 4:
					RtuDataAddr->DLT645DBON=1;
				break;
				case 5:
					RtuDataAddr->DATACALCDBON=1;
				break;
				case 6:
					RtuDataAddr->DBON=1;
				break;
				case 7:
					RtuDataAddr->SYSTENDBON=1;
					break;
				case 8:
					RtuDataAddr->IFRDBON=1;
				break;
				case 9:
					RtuDataAddr->CONTROLDBON=1;
				break;
				case 11:
					RtuDataAddr->XIEBOPRT=1;
				break;

			}
			return ;
		}
	}
	if(strcmp("seton",argv[1])==0)
	{
		RtuDataAddr->Setting=1;
		return;
	}
	if(strcmp("setoff",argv[1])==0)
	{
		RtuDataAddr->Setting=0;
		return;
	}
	if(strcmp("test",argv[1])==0)
	{
		RtuDataAddr->FkJcXiu=6;
		return;
	}
	if(strcmp("mc",argv[1])==0)
	{
		RtuDataAddr->FkJcXiu=7;
		return;
	}
	if(strcmp("mpp",argv[1])==0)
	{
		RtuDataAddr->FkJcXiu=1;
		return;
	}
	if(strcmp("mpa",argv[1])==0)
	{
		RtuDataAddr->FkJcXiu=2;
		return;
	}
	if(strcmp("mpb",argv[1])==0)
	{
		RtuDataAddr->FkJcXiu=3;
		return;
	}
	if(strcmp("mpc",argv[1])==0)
	{
		RtuDataAddr->FkJcXiu=4;
		return;
	}
	if(strcmp("qing",argv[1])==0)
	{
		RtuDataAddr->FkJcXiu=5;
		return;
	}
	if(strcmp("resetdata",argv[1])==0)
	{
		RtuDataAddr->ResetdataSet = 1;
		return;
	}
	if(strcmp("resettx",argv[1])==0)
	{
		RtuDataAddr->ResetSetSet = 1;
		return;
	}
	if(strcmp("resetset",argv[1])==0)
	{
		RtuDataAddr->ResetSetSet2 = 1;
		return;
	}
	if(strcmp("readspi",argv[1])==0)
	{
		//printf("\n\r fkset readspi ");
		RtuDataAddr->FkJcXiu=8;
		return;
	}
	if(strcmp("tstfile",argv[1])==0)
	{
		if(argc==2)
		{
			fprintf(stderr,"\r\napn sdhfjksdfhsdjkafhskadfhkjsdaf");
			return;
		}
		else
		{
			for(i=0;i<100;i++)
			{
				tmp[i]=(i%10)+0x30;
			}
			sscanf(argv[2],"%d",&temp1);
			fp=fopen("/usr/config/test.sav","wb+");
			if(fp!=NULL)
			{
				fprintf(stderr,"\r\nset sdgfgsdfgsdjfgsdjfg!!!!!!!!!!!!!!!!!!!!!!!!! ");
				fseek(fp,temp1,SEEK_SET);
				fwrite(tmp,100,1,fp);
				fclose(fp);
				return ;
			}
			else
			{
				fp=fopen("/usr/config/test.sav","w");
				fseek(fp,temp1,SEEK_SET);
				fwrite(tmp,100,1,fp);
				fclose(fp);
				return ;
			}
		return;
		}
	}
	if(argc>2)
	{
		SaveFKSet();
	}
	return;
}

int main(int argc, char *argv[])
{
	//markver();
	//ThreadCtl(_NTO_TCTL_IO, 0);
 	if(OpenMem())
 		return EXIT_FAILURE;
	if(RtuDataAddr->mem_len!=sizeof(RTimeData))
	{
		fprintf( stderr, "base mem uncompared prog will exit:\n");
		return EXIT_FAILURE;
	}
	if(argc==1)
	{
		fprintf(stderr,"\r\n fkset [Command] [options]");
		fprintf(stderr,"\r\n Command:");
		fprintf(stderr,"\r\n ip address   example fkset ip 192.168.1.1:7001");
		fprintf(stderr,"\r\n id           example fkset id 35-02-1");
		fprintf(stderr,"\r\n apn          example fkset apn cmnet");
		fprintf(stderr,"\r\n");
	}
	else
	{
		CommandProcess(argc, argv);
	}
 	return EXIT_SUCCESS;
}
/*sin [options]... [command]...

Options:
 -l seconds    Loop with seconds pause between loops
 -n nodename   Get information from nodename
 -p pid        Select processes by process id
 -P pattern    Select processes by name
 -r            Select processes with at least one ready thread
 -s sid        Select processes by session id
 -S type       Sort by {mem, name, pid, sid, time}
 -u uid        Select processes by user id

Command: (only first 2 characters need be entered)
   args cpu       env     fds     files  interrupts memory
   net  registers signals threads timers users      info

 * */
