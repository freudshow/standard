#ifndef FKBASEFUN_H_
#define FKBASEFUN_H_
#include "basetype.h"
#include "memdef.h"
#include "stdio.h"
#include "zlib.h"
#include <hw/inout.h>
extern const char ver_time[];
extern uintptr_t port1,port2,port3,port4 ,ControlPtr,AlarmPtr,resetptr;
extern char PortOpened,LedOpened,YxStatOpened,AlarmOpened;
extern RTimeData  *RtuDataAddr;
extern INT8U PORT_ID;
extern void CleardeadCount();

extern INT8U CreateMem();
extern INT8U OpenMem();
extern void TSGet(TS *ts);
extern void TSSet(TS ts);
extern void SetTime(INT8U *Data);

extern INT8U *INT32ToBCD(INT32S S,INT8U *D,INT8U len);
extern INT8U SaveFile(INT8U *FileName,INT8U *source,int size);
extern INT8U ReadFile(INT8U *FileName,INT8U *source,int size);
extern void Fm25cl64_Write(INT8U *Array,INT16U Length,INT16U Addr);
extern void Fm25cl64_Read(INT8U *Array,INT16U Length,INT16U Addr);

extern void SaveEveBegin(INT8U i);
extern void SetECBiaoZhi(INT8U *s,INT16U No);
extern void SaveEveBuff(INT8U *TimeDest,INT8U FMLevel,INT8U ERCNo);
extern void SaveEveBuff_ER17(INT8U FMLevel, INT8U ERCNo);
extern void OpenGPIO();
extern void OpenControl();
extern void OpenAlarm();
extern void GpioEnable(unsigned char PSele,unsigned char PinSele);
extern void GpioInEnable(unsigned char PSele,unsigned char PinSele);
extern void GpioDisable(unsigned char PSele,unsigned char PinSele);
extern void GpioSet(unsigned char PSele,unsigned char PinSele);
extern void GpioClear(unsigned char PSele,unsigned char PinSele);
extern void ClearSpiLed(int i);
extern void SetSpiLed(int i);

extern int GetYx();
extern void Sev_Data_Type_17(TS ts,INT8U *Dest);
extern void Sev_Data_Type_15(TS ts,INT8U *Dest);
extern INT8U	FeiLvNo (const TS ts_t);
extern void initCanshu();
extern INT8U SaveFKSet();
////////////////////////////////////////////
//�������ܣ���ȡϵͳ�����ļ�
//���ã�main����ʱ
//��������
//�˳����쳣�жϣ����³�������ʧ�ܡ�
///////////////////////////////////////////
extern INT8U  ReadConfig();
extern void	Save_Input_Set();
extern void 	Save_CommSet();
extern void 	Save_Task_Set();
extern void 	Save_Zj_Control_Set();
extern void 	Save_Event_Set();
extern void 	Save_Fk_Control_Set();
extern void 	Save_Cl_MenXian_Set();
extern void 	Save_Zongjia_Set();
extern INT8U Save_Fk_Control_para_Set();
extern INT8U Read_Fk_Control_para_Set();


extern void Fengming_off(void);
extern void Fengming_On(void);
extern void AlArmReportBegin();
extern void AlArmReportEnd();
extern void AlArmReportBeginNoDly();
extern void GaoJingBegin();
extern void GaoJingEnd();

#endif /*FKBASEFUN_H_*/
