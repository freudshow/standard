/*
 * fkbasefun.c
 *
 *  Created on: Dec 16, 2009
 *      Author: ln
 */

#include "basetype.h"
#include "memdef.h"
#include "stdio.h"
#include "zlib.h"
#include <hw/inout.h>
const char ver_time[] = { " "__DATE__" "__TIME__ };
uintptr_t port1, port2, port3, port4, ControlPtr, AlarmPtr,resetptr;
char PortOpened = 0, LedOpened = 0, YxStatOpened = 0, AlarmOpened = 0;
;
extern RTimeData *RtuDataAddr;
extern INT8U PORT_ID;
void CleardeadCount() {
	RtuDataAddr->stPortPara[PORT_ID].uiDeadCount = 0;//�˿�ͨѶ���ã�
}

INT8U CreateMem() {
	int fd;
	fd = shm_open("/dev/shm/plc_mem", O_RDWR | O_CREAT, 0777);
	if (fd == -1) {
		fprintf(stderr, "\nERROR: Open share memory failed:%s!\n", strerror(errno));
		return 1;
	}
	if (ftruncate(fd, sizeof(RTimeData)) == -1) {
		fprintf(stderr, "ltrunc : %s\n", strerror(errno));
		return 1;
	}

	RtuDataAddr = mmap(0, sizeof(RTimeData), PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
	if (RtuDataAddr == MAP_FAILED) {
		fprintf(stderr, "mmap failed: %s\n", strerror(errno));
		return 1;
	}
	close(fd);
	return 0;
}
INT8U OpenMem() {
	int fd;
	fd = shm_open("/dev/shm/plc_mem", O_RDWR, 0777);
	if (fd == -1) {
		fprintf(stderr, "\nERROR: Open share memory failed:%s!\n", strerror(errno));
		return 1;
	}
	RtuDataAddr = mmap(0, sizeof(RTimeData), PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
	if (RtuDataAddr == MAP_FAILED) {
		fprintf(stderr, "mmap failed: %s\n", strerror(errno));
		return 1;
	}
	//fprintf( stderr, "mmap shared ok:111\n");
	close(fd);
	return 0;
}
void TSGet(TS *ts) {
	struct tm tmp_tm;
	time_t time_of_day;
	time_of_day = time(NULL);
	localtime_r(&time_of_day, &tmp_tm);
	ts->Year = tmp_tm.tm_year + 1900;
	ts->Month = tmp_tm.tm_mon + 1;
	ts->Day = tmp_tm.tm_mday;
	ts->Hour = tmp_tm.tm_hour;
	ts->Minute = tmp_tm.tm_min;
	ts->Sec = tmp_tm.tm_sec;
	ts->Week = tmp_tm.tm_wday;

}
void TSSet(TS ts) {
	struct tm tmpsec;
	struct timespec rtime;
	tmpsec.tm_sec = ts.Sec;
	tmpsec.tm_min = ts.Minute;
	tmpsec.tm_hour = ts.Hour;
	tmpsec.tm_mday = ts.Day;
	tmpsec.tm_mon = ts.Month - 1;
	tmpsec.tm_year = ts.Year - 1900;
	rtime.tv_sec = mktime(&tmpsec);
	rtime.tv_nsec = 500* 10000 ;clock_settime(CLOCK_REALTIME,&rtime);
	RtuDataAddr->settime2=1;

}
void SetTime(INT8U *Data) {
	TS ts;
	ts.Year = ((Data[5] >> 4) * 10) + (Data[5] & 0x0f);
	ts.Year = ts.Year + 2000;
	ts.Month = (((Data[4] >> 4) & 0x01) * 10) + (Data[4] & 0x0f);
	ts.Day = ((Data[3] >> 4) * 10) + (Data[3] & 0x0f);
	ts.Week = Data[4] >> 5;
	ts.Hour = ((Data[2] >> 4) * 10) + (Data[2] & 0x0f);
	ts.Minute = ((Data[1] >> 4) * 10) + (Data[1] & 0x0f);
	ts.Sec = ((Data[0] >> 4) * 10) + (Data[0] & 0x0f);
	TSSet(ts);

}

INT8U *INT32ToBCD(INT32S S, INT8U *D, INT8U len) {
	INT8U i;
	INT32S Temp;
	INT16U j = 1;
	Temp = abs(S);
	for (i = 0; i < len; i++) {
		j = Temp % 100;
		D[i] = (j / 10);
		D[i] = (D[i] << 4) + (j % 10);
		Temp = Temp / 100;
	}
	if (S < 0) {
		D[len - 1] = D[len - 1] | 0x80;
	}
	return D;
}
;
INT8U SaveFile(INT8U *FileName, INT8U *source, int size) {
	FILE *fp;
	INT8U res;
	sem_wait(&RtuDataAddr->UseFileFlg);
	fp = gzopen((char *) FileName, "w");
	if (fp != NULL) {
		gzseek(fp, 0, SEEK_SET);
		gzwrite(fp, source, size);
		gzclose(fp);
		res = 0;
	} else {
		res = 1;
	}
	sem_post(&RtuDataAddr->UseFileFlg);
	return res;
}
INT8U ReadFile(INT8U *FileName, INT8U *source, int size) {
	FILE *fp = NULL;
	INT8U res;
	sem_wait(&RtuDataAddr->UseFileFlg);
	fp = gzopen((char *) FileName, "r");
	if (fp != NULL) {
		gzseek(fp, 0, SEEK_SET);
		gzread(fp, source, size);
		gzclose(fp);
		res = 0;
	} else {
		memset(source, 0, size);
		res = 1;
	}
	sem_post(&RtuDataAddr->UseFileFlg);
	return res;
}
void Fm25cl64_Write(INT8U *Array, INT16U Length, INT16U Addr) {
	sem_wait(&RtuDataAddr->UseFMFileFlg);
	memcpy(&RtuDataAddr->FM_Save_buff[Addr + 3], Array, Length);
	RtuDataAddr->FM_Changed++;
	sem_post(&RtuDataAddr->UseFMFileFlg);
}
void Fm25cl64_Read(INT8U *Array, INT16U Length, INT16U Addr) {
	sem_wait(&RtuDataAddr->UseFMFileFlg);
	memcpy(Array, &RtuDataAddr->FM_Save_buff[Addr + 3], Length);
	sem_post(&RtuDataAddr->UseFMFileFlg);
}

void SaveEveBegin(INT8U i) {
	//	Event_Save.UseFlag=1;
}
void SetECBiaoZhi(INT8U *s, INT16U No) {
	s[No / 8] = s[No / 8] | (1 << (No % 8));
}
void SaveEveBuff(INT8U *TimeDest, INT8U FMLevel, INT8U ERCNo) {
	TS ts;
	TSGet(&ts);
	TimeDest[0] = ((ts.Minute / 10) << 4) + (ts.Minute % 10);
	TimeDest[1] = ((ts.Hour / 10) << 4) + (ts.Hour % 10);
	TimeDest[2] = ((ts.Day / 10) << 4) + (ts.Day % 10);
	TimeDest[3] = ((ts.Month / 10) << 4) + (ts.Month % 10);
	TimeDest[4] = (((ts.Year % 100) / 10) << 4) + (ts.Year % 10);
	if (FMLevel == 1) {

		memcpy(&RtuDataAddr->M_Event_Save[RtuDataAddr->Fm_Save_Eve.EC1].UseFlag, &RtuDataAddr->Event_Save.UseFlag, sizeof(RtuDataAddr->Event_Save));
		//printf("\n\rRtuDataAddr->M_Event_Save[%d].Buff[9]===%d",RtuDataAddr->Fm_Save_Eve.EC1,RtuDataAddr->M_Event_Save[RtuDataAddr->Fm_Save_Eve.EC1].Event.Buff[9]);

		RtuDataAddr->Fm_Save_Eve.EC1 = (RtuDataAddr->Fm_Save_Eve.EC1 + 1)%256;
		Fm25cl64_Write(&RtuDataAddr->Fm_Save_Eve.EC1, sizeof(RtuDataAddr->Fm_Save_Eve), Fm_Save_Eve_Offset);
		RtuDataAddr->EC1 = RtuDataAddr->Fm_Save_Eve.EC1;
		SaveFile((INT8U *) "/nand/save/Merc1.dat", &RtuDataAddr->M_Event_Save[0].UseFlag, sizeof(RtuDataAddr->M_Event_Save));

	} else {
		memcpy(&RtuDataAddr->S_Event_Save[RtuDataAddr->Fm_Save_Eve.EC2].UseFlag, &RtuDataAddr->Event_Save.UseFlag, sizeof(RtuDataAddr->Event_Save));
		RtuDataAddr->Fm_Save_Eve.EC2 = (RtuDataAddr->Fm_Save_Eve.EC2 + 1)%256;
		Fm25cl64_Write(&RtuDataAddr->Fm_Save_Eve.EC2, sizeof(RtuDataAddr->Fm_Save_Eve), Fm_Save_Eve_Offset);
		RtuDataAddr->EC2 = RtuDataAddr->Fm_Save_Eve.EC2;
		SaveFile((INT8U *) "/nand/save/Serc1.dat", &RtuDataAddr->S_Event_Save[0].UseFlag, sizeof(RtuDataAddr->S_Event_Save));
	}

	RtuDataAddr->ERCBiaoZhi[(ERCNo - 1) / 8] = RtuDataAddr->ERCBiaoZhi[(ERCNo - 1) / 8] | (1 << ((ERCNo - 1) % 8));
}
void SaveEveBuff_ER17(INT8U FMLevel, INT8U ERCNo) {

	if (FMLevel == 1) {

		memcpy(&RtuDataAddr->M_Event_Save[RtuDataAddr->Fm_Save_Eve.EC1].UseFlag, &RtuDataAddr->Event_Save.UseFlag, sizeof(RtuDataAddr->Event_Save));
		//printf("\n\rRtuDataAddr->M_Event_Save[%d].Buff[9]===%d",RtuDataAddr->Fm_Save_Eve.EC1,RtuDataAddr->M_Event_Save[RtuDataAddr->Fm_Save_Eve.EC1].Event.Buff[9]);

		RtuDataAddr->Fm_Save_Eve.EC1 = (RtuDataAddr->Fm_Save_Eve.EC1 + 1)%256;;
		Fm25cl64_Write(&RtuDataAddr->Fm_Save_Eve.EC1, sizeof(RtuDataAddr->Fm_Save_Eve), Fm_Save_Eve_Offset);
		RtuDataAddr->EC1 = RtuDataAddr->Fm_Save_Eve.EC1;
		SaveFile((INT8U *) "/nand/save/Merc1.dat", &RtuDataAddr->M_Event_Save[0].UseFlag, sizeof(RtuDataAddr->M_Event_Save));

	} else {
		memcpy(&RtuDataAddr->S_Event_Save[RtuDataAddr->Fm_Save_Eve.EC2].UseFlag, &RtuDataAddr->Event_Save.UseFlag, sizeof(RtuDataAddr->Event_Save));
		RtuDataAddr->Fm_Save_Eve.EC2 = (RtuDataAddr->Fm_Save_Eve.EC2 + 1)%256;
		Fm25cl64_Write(&RtuDataAddr->Fm_Save_Eve.EC2, sizeof(RtuDataAddr->Fm_Save_Eve), Fm_Save_Eve_Offset);
		RtuDataAddr->EC2 = RtuDataAddr->Fm_Save_Eve.EC2;
		SaveFile((INT8U *) "/nand/save/Serc1.dat", &RtuDataAddr->S_Event_Save[0].UseFlag, sizeof(RtuDataAddr->S_Event_Save));
	}

	RtuDataAddr->ERCBiaoZhi[(ERCNo - 1) / 8] = RtuDataAddr->ERCBiaoZhi[(ERCNo - 1) / 8] | (1 << ((ERCNo - 1) % 8));
}
void OpenGPIO() {
	port1 = mmap_device_io(0x200, AT91C_BASE_PIOA);
	port2 = mmap_device_io(0x200, AT91C_BASE_PIOB);
	port3 = mmap_device_io(0x200, AT91C_BASE_PIOC);
	PortOpened = 1;
}
void OpenControl() {
	ControlPtr = mmap_device_io(0x06, 0x50000000);

}
void OpenAlarm() {
	AlarmPtr = mmap_device_io(0x02, 0x50000006);
	AlarmOpened = 1;
}
void GpioEnable(unsigned char PSele, unsigned char PinSele) {
	switch (PSele) {
	case 1:
		out32(port1 + PIO_PER, 1 << PinSele);
		out32(port1 + PIO_OER, 1 << PinSele);
		break;
	case 2:
		out32(port2 + PIO_PER, 1 << PinSele);
		out32(port2 + PIO_OER, 1 << PinSele);
		break;
	case 3:
		out32(port3 + PIO_PER, 1 << PinSele);
		out32(port3 + PIO_OER, 1 << PinSele);
		break;
	}
}
void GpioInEnable(unsigned char PSele, unsigned char PinSele) {
	switch (PSele) {
	case 1:
		out32(port1 + PIO_PER, 1 << PinSele);
		out32(port1 + PIO_IFER, 1 << PinSele);
		break;
	case 2:
		out32(port2 + PIO_PER, 1 << PinSele);
		out32(port2 + PIO_IFER, 1 << PinSele);
		break;
	case 3:
		out32(port3 + PIO_PER, 1 << PinSele);
		out32(port3 + PIO_IFER, 1 << PinSele);
		break;
	}
}
void GpioDisable(unsigned char PSele, unsigned char PinSele) {
	switch (PSele) {
	case 1:
		out32(port1 + PIO_PDR, 1 << PinSele);
		out32(port1 + PIO_ODR, 1 << PinSele);
		break;
	case 2:
		out32(port2 + PIO_PDR, 1 << PinSele);
		out32(port2 + PIO_ODR, 1 << PinSele);
		break;
	case 3:
		out32(port3 + PIO_PDR, 1 << PinSele);
		out32(port3 + PIO_ODR, 1 << PinSele);
		break;
	}
}
void GpioSet(unsigned char PSele, unsigned char PinSele) {
	switch (PSele) {
	case 1:
		out32(port1 + PIO_SODR, 1 << PinSele);
		break;
	case 2:
		out32(port2 + PIO_SODR, 1 << PinSele);
		break;
	case 3:
		out32(port3 + PIO_SODR, 1 << PinSele);
		break;
	}
}
void GpioClear(unsigned char PSele, unsigned char PinSele) {
	switch (PSele) {
	case 1:
		out32(port1 + PIO_CODR, 1 << PinSele);
		break;
	case 2:
		out32(port2 + PIO_CODR, 1 << PinSele);
		break;
	case 3:
		out32(port3 + PIO_CODR, 1 << PinSele);
		break;
	}
}
void ClearSpiLed(int i) {
	RtuDataAddr->leddisp = RtuDataAddr->leddisp & ((1 << i) ^ 0xffffffff);
}
void SetSpiLed(int i) {
	RtuDataAddr->leddisp = RtuDataAddr->leddisp | (1 << i);
}
int GetYx() {
	int stat,stat1;
	if (!PortOpened) {
		OpenGPIO();  //quxiaogpio
	}
	if (!YxStatOpened) {
		GpioInEnable(1, 11);
		GpioInEnable(1, 10);
		GpioInEnable(1, 9);
		GpioInEnable(1, 8);
		GpioInEnable(1, 7);
		GpioInEnable(1, 6);
		GpioInEnable(1, 5);

		GpioInEnable(2, 29);
		GpioInEnable(2, 30);
		YxStatOpened = 1;
	}
	stat = in32(port1 + PIO_PDSR) >> 5;//�¼���
	stat1= in32(port2 + PIO_PDSR) >>29;
	stat1 = stat1 & 0x03;
	stat = stat |(stat1<<7);

	stat = stat & 0x1ff;//�¼���
	return stat ^ 0x1ff;//�¼���
}
void Sev_Data_Type_17(TS ts, INT8U *Dest) {
	Dest[0] = ((ts.Minute / 10) << 4) + (ts.Minute % 10);
	Dest[1] = ((ts.Hour / 10) << 4) + (ts.Hour % 10);
	Dest[2] = ((ts.Day / 10) << 4) + (ts.Day % 10);
	Dest[3] = ((ts.Month / 10) << 4) + (ts.Month % 10);
}
void Sev_Data_Type_15(TS ts, INT8U *Dest) {
	Dest[0] = ((ts.Minute / 10) << 4) + (ts.Minute % 10);
	Dest[1] = ((ts.Hour / 10) << 4) + (ts.Hour % 10);
	Dest[2] = ((ts.Day / 10) << 4) + (ts.Day % 10);
	Dest[3] = ((ts.Month / 10) << 4) + (ts.Month % 10);
	Dest[4] = (((ts.Year % 100) / 10) << 4) + (ts.Year % 10);
}
INT8U FeiLvNo(const TS ts_t) {
	INT8U Byte;
	if (RtuDataAddr->FkInput_Value.F21_Set_Para.Valid == 1) {
		if ((ts_t.Minute >= 0) && (ts_t.Minute < 30))//&&(ts_t.Minute == 0)
		{
			Byte = RtuDataAddr->FkInput_Value.F21_Set_Para.ZDuan_Dn_FLv_sD[ts_t.Hour*2];
			return (((Byte ) > FeiLvNum) ? 0x01 : (Byte ));
		}
		if ((ts_t.Minute >= 30) && (ts_t.Minute < 60)) {
			Byte = RtuDataAddr->FkInput_Value.F21_Set_Para.ZDuan_Dn_FLv_sD[ts_t.Hour*2+1];
			return (((Byte )  > FeiLvNum) ? 0x01 : (Byte ));
		}
	} else {
		return 0x01;
	}
	return 0x01;
}
void initCanshu() {
	INT8U i;
	RtuDataAddr->FkComm_Value.F1_Set_Para.Valid = 1;
	RtuDataAddr->FkComm_Value.F1_Set_Para.RTS_Time = 10;
	RtuDataAddr->FkComm_Value.F1_Set_Para.QiDong_FaSong_Yanshi = 1;
	RtuDataAddr->FkComm_Value.F1_Set_Para.ChongDong_XiangYing[0] = 0;
	RtuDataAddr->FkComm_Value.F1_Set_Para.ChongDong_XiangYing[1] = 0;
	RtuDataAddr->FkComm_Value.F1_Set_Para.CON_Stat = 0x03;
	RtuDataAddr->FkComm_Value.F1_Set_Para.Heart_Beat = 5;

	memset(&RtuDataAddr->FkComm_Value.F2_Set_Para.Valid, 0, sizeof(RtuDataAddr->FkComm_Value.F2_Set_Para));
	memset(&RtuDataAddr->FkComm_Value.F4_Set_Para.Valid, 0, sizeof(RtuDataAddr->FkComm_Value.F4_Set_Para));
	memset(&RtuDataAddr->FkComm_Value.F5_Set_Para.Valid, 0, sizeof(RtuDataAddr->FkComm_Value.F5_Set_Para));
	memset(&RtuDataAddr->FkComm_Value.F16_Set_Para.Valid, 0, sizeof(RtuDataAddr->FkComm_Value.F16_Set_Para));

	memset(&RtuDataAddr->FkComm_Value.F3_Set_Para.Valid,0,sizeof(RtuDataAddr->FkComm_Value.F3_Set_Para));
	//��ʼ��apn
	RtuDataAddr->FkComm_Value.F3_Set_Para.APN[0]='C';
	RtuDataAddr->FkComm_Value.F3_Set_Para.APN[1]='M';
	RtuDataAddr->FkComm_Value.F3_Set_Para.APN[2]='N';
	RtuDataAddr->FkComm_Value.F3_Set_Para.APN[3]='E';
	RtuDataAddr->FkComm_Value.F3_Set_Para.APN[4]='T';
	//��ʼ������
	RtuDataAddr->FkComm_Value.F8_Set_Para.Valid = 1;
	RtuDataAddr->FkComm_Value.F8_Set_Para.GPRS_MODE = 1;
	RtuDataAddr->FkComm_Value.F8_Set_Para.BeiDongJihuo = 0;
	RtuDataAddr->FkComm_Value.F8_Set_Para.WUTongXinDuan = 1;
	RtuDataAddr->FkComm_Value.F8_Set_Para.ZaiXian_ChongBo[0] = 30;
	RtuDataAddr->FkComm_Value.F8_Set_Para.ZaiXian_ChongBo[1] = 0;
	RtuDataAddr->FkComm_Value.F8_Set_Para.ShiDuanBiaoZhi[0]=0;
	RtuDataAddr->FkComm_Value.F8_Set_Para.ShiDuanBiaoZhi[1]=0;
	RtuDataAddr->FkComm_Value.F8_Set_Para.ShiDuanBiaoZhi[2]=0;
///////////////////////////////////////////////////////////

	memset(&RtuDataAddr->FkInput_Value.F7_Set_Para.Valid, 0, sizeof(RtuDataAddr->FkInput_Value.F7_Set_Para));
	memset(&RtuDataAddr->FkInput_Value.F10_Set_Para.Valid, 0, sizeof(RtuDataAddr->FkInput_Value.F10_Set_Para));
	//��ʼ��һ����������
	RtuDataAddr->FkInput_Value.F10_Set_Para.Valid=1;
	RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num=1;
	RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[0].Addr[0]=0x01;
	RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[0].GuiYue_Type=JiaoLiuType;
	RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[0].CeLiangNo=1;
	RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[0].No=1;
	RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[0].BaudAndPort=0x41;
	//��ʼ������
	memcpy(&RtuDataAddr->Meter_Para.Valid, &RtuDataAddr->FkInput_Value.F10_Set_Para.Valid, sizeof(RtuDataAddr->FkInput_Value.F10_Set_Para));

	RtuDataAddr->ZongJia_Value.F14_Set_Para.Valid = 0;

	memset(&RtuDataAddr->ZongJia_Value.F14_Set_Para.Valid, 0, sizeof(RtuDataAddr->ZongJia_Value.F14_Set_Para));
	for (i = 0; i < ZongJia_Max; i++)
		memset(&RtuDataAddr->ZongJia_Value.F33_Set_Para[i].Valid, 0, sizeof(RtuDataAddr->ZongJia_Value.F33_Set_Para[i]));

	for (i = 0; i < CeLiangPoint_Max; i++) {
		memset(&RtuDataAddr->Cl_MenXian_Value[i].F25_Set_Para.Valid, 0, sizeof(RtuDataAddr->Cl_MenXian_Value[i].F25_Set_Para));
		memset(&RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.Valid, 0, sizeof(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para));
		memset(&RtuDataAddr->Cl_MenXian_Value[i].F27_Set_Para.Valid, 0, sizeof(RtuDataAddr->Cl_MenXian_Value[i].F27_Set_Para));
		memset(&RtuDataAddr->Cl_MenXian_Value[i].F28_Set_Para.Valid, 0, sizeof(RtuDataAddr->Cl_MenXian_Value[i].F28_Set_Para));
	}
	memset(&RtuDataAddr->Fk_Control_Set_Value.F17_Set_Para.Valid, 0, sizeof(RtuDataAddr->Fk_Control_Set_Value.F17_Set_Para));
	memset(&RtuDataAddr->Fk_Control_Set_Value.F18_Set_Para.Valid, 0, sizeof(RtuDataAddr->Fk_Control_Set_Value.F18_Set_Para));
	memset(&RtuDataAddr->Fk_Control_Set_Value.F19_Set_Para.Valid, 0, sizeof(RtuDataAddr->Fk_Control_Set_Value.F19_Set_Para));
	memset(&RtuDataAddr->Fk_Control_Set_Value.F20_Set_Para.Valid, 0, sizeof(RtuDataAddr->Fk_Control_Set_Value.F20_Set_Para));
	memset(&RtuDataAddr->Fk_Control_Set_Value.F23_Set_Para.Valid, 0, sizeof(RtuDataAddr->Fk_Control_Set_Value.F23_Set_Para));
	memset(&RtuDataAddr->Fk_Control_Set_Value.F24_Set_Para.Valid, 0, sizeof(RtuDataAddr->Fk_Control_Set_Value.F24_Set_Para));
	for(i=0;i<8;i++)
		memset(&RtuDataAddr->Fk_Control_Set_Value.F29_Set_Para[i].Valid, 0, sizeof(F29_Set_Stru));
	for (i = 0; i < Control_Lunci_Max; i++)
		memset(&RtuDataAddr->Fk_Control_Set_Value.F49_Set_Para[i].Valid, 0, sizeof(RtuDataAddr->Fk_Control_Set_Value.F49_Set_Para[i]));

	memset(&RtuDataAddr->Fk_Control_Set_Value.F57_Set_Para.Valid, 0, sizeof(RtuDataAddr->Fk_Control_Set_Value.F57_Set_Para));
	memset(&RtuDataAddr->Fk_Control_Set_Value.F58_Set_Para.Valid, 0, sizeof(RtuDataAddr->Fk_Control_Set_Value.F58_Set_Para));

	//memset(&RtuDataAddr->Event_Value.F8_Set_Para.Valid, 0, sizeof(RtuDataAddr->Event_Value.F8_Set_Para));
	memset(&RtuDataAddr->Event_Value.F9_Set_Para.Valid, 0, sizeof(RtuDataAddr->Event_Value.F9_Set_Para));
	////////////////////////////////////////////////////////////////////////////////
	memset(&RtuDataAddr->Event_Value.F15_Set_Para.Valid, 0, sizeof(RtuDataAddr->Event_Value.F15_Set_Para));
	memset(&RtuDataAddr->Event_Value.F59_Set_Para.Valid, 0, sizeof(RtuDataAddr->Event_Value.F59_Set_Para));

	for (i = 0; i < ZongJia_Max; i++) {
		memset(&RtuDataAddr->Zj_Control_Value[i].F41_Set_Para.Valid, 0, sizeof(RtuDataAddr->Zj_Control_Value[i].F41_Set_Para));
		memset(&RtuDataAddr->Zj_Control_Value[i].F42_Set_Para.Valid, 0, sizeof(RtuDataAddr->Zj_Control_Value[i].F42_Set_Para));
		memset(&RtuDataAddr->Zj_Control_Value[i].F43_Set_Para.Valid, 0, sizeof(RtuDataAddr->Zj_Control_Value[i].F43_Set_Para));
		memset(&RtuDataAddr->Zj_Control_Value[i].F44_Set_Para.Valid, 0, sizeof(RtuDataAddr->Zj_Control_Value[i].F44_Set_Para));
		//memset(&RtuDataAddr->Zj_Control_Value[i].F45_Set_Para.Valid, 0, sizeof(RtuDataAddr->Zj_Control_Value[i].F45_Set_Para));
		RtuDataAddr->Zj_Control_Value[i].F45_Set_Para.Valid=1;
		RtuDataAddr->Zj_Control_Value[i].F45_Set_Para.GongKong_Lunci_Biaozhi=15;
		memset(&RtuDataAddr->Zj_Control_Value[i].F46_Set_Para.Valid, 0, sizeof(RtuDataAddr->Zj_Control_Value[i].F46_Set_Para));
		memset(&RtuDataAddr->Zj_Control_Value[i].F47_Set_Para.Valid, 0, sizeof(RtuDataAddr->Zj_Control_Value[i].F47_Set_Para));
		//memset(&RtuDataAddr->Zj_Control_Value[i].F48_Set_Para.Valid, 0, sizeof(RtuDataAddr->Zj_Control_Value[i].F48_Set_Para));
		RtuDataAddr->Zj_Control_Value[i].F48_Set_Para.Valid=1;
		RtuDataAddr->Zj_Control_Value[i].F48_Set_Para.DianKong_Lunci_Biaozhi=15;
		memset(&RtuDataAddr->Zj_Control_Value[i].Old_DianLiang,0,4);
		memset(&RtuDataAddr->Zj_Control_Value[i].New_DianLiang,0,4);

	}
	for (i = 0; i < Task_Max; i++) {
		memset(&RtuDataAddr->Task_Value[i].F65_Set_Para.Valid, 0, sizeof(RtuDataAddr->Task_Value[i].F65_Set_Para));
		memset(&RtuDataAddr->Task_Value[i].F66_Set_Para.Valid, 0, sizeof(RtuDataAddr->Task_Value[i].F66_Set_Para));
		memset(&RtuDataAddr->Task_Value[i].F67_Set_Para.Valid, 0, sizeof(RtuDataAddr->Task_Value[i].F67_Set_Para));
		memset(&RtuDataAddr->Task_Value[i].F68_Set_Para.Valid, 0, sizeof(RtuDataAddr->Task_Value[i].F68_Set_Para));
	}
	memset(&RtuDataAddr->FuKong_Control_Value.Asdu130Addr[0], 0, sizeof(RtuDataAddr->FuKong_Control_Value));
}
INT8U SaveFKSet() {
	FILE *fp;
	INT8U i;
	INT8U re;
	fprintf(stderr, "step 8");
	sem_wait(&RtuDataAddr->UseFileFlg);
	re = 0;
	fp = fopen("/config/p130set.set", "w");
	if (fp != NULL) {
		fseek(fp, 0, SEEK_SET);
		re  = fwrite(&RtuDataAddr->FkComm_Value, sizeof(RtuDataAddr->FkComm_Value), 1, fp);
		if (re!=1) {fclose(fp);return 0;}
		re = fwrite(&RtuDataAddr->FkInput_Value, sizeof(RtuDataAddr->FkInput_Value), 1, fp);
		if (re!=1) {fclose(fp);return 0;}
		re = fwrite(&RtuDataAddr->ZongJia_Value, sizeof(RtuDataAddr->ZongJia_Value), 1, fp);
		if (re!=1) {fclose(fp);return 0;}
		re = fwrite(&RtuDataAddr->Fk_Control_Set_Value, sizeof(RtuDataAddr->Fk_Control_Set_Value), 1, fp);
		if (re!=1) {fclose(fp);return 0;}
		re = fwrite(&RtuDataAddr->Event_Value, sizeof(RtuDataAddr->Event_Value), 1, fp);
		for (i = 0; i < CeLiangPoint_Max; i++)
		{
			re = fwrite(&RtuDataAddr->Cl_MenXian_Value[i], sizeof(RtuDataAddr->Cl_MenXian_Value[i]), 1, fp);
			if (re!=1) {fclose(fp);return 0;}
		}
		for (i = 0; i < ZongJia_Max; i++)
		{
			re = fwrite(&RtuDataAddr->Zj_Control_Value[i], sizeof(RtuDataAddr->Zj_Control_Value[i]), 1, fp);
			if (re!=1) {fclose(fp);return 0;}
		}
		for (i = 0; i < Task_Max; i++)
		{
			re = fwrite(&RtuDataAddr->Task_Value[i], sizeof(RtuDataAddr->Task_Value[i]), 1, fp);
			if (re!=1) {fclose(fp);return 0;}
		}
		fclose(fp);
		sem_post(&RtuDataAddr->UseFileFlg);
		return TRUE;
	}
	sem_post(&RtuDataAddr->UseFileFlg);
	return FALSE;
}
////////////////////////////////////////////
//�������ܣ���ȡϵͳ�����ļ�
//���ã�main����ʱ
//��������
//�˳����쳣�жϣ����³�������ʧ�ܡ�
///////////////////////////////////////////
int readitem(FILE* fp,void *buf,size_t size)
{
	size_t re;
	re  = fread(buf, size, 1, fp);
	if (re!=1)
	{
		return 0;
	}
	return 1;
}
INT8U ReadConfig() {
	INT16U i,count=0;
	int flag = 0;
	FILE *fp = NULL;
	INT8U fdExist = 0;
	size_t re,size;
	sem_wait(&RtuDataAddr->UseFileFlg);
	re = size = 0;
	for(count=0;count<3;count++)
	{
		delay (1000);
		flag = 0;
		if (fp!=NULL)
			fclose(fp);
		fp = NULL;
		fp = fopen("/config/p130set.set", "r");
		if (fp != NULL) { //����������
			fdExist = 1;
			fseek(fp, 0, SEEK_SET);
			size = sizeof(RtuDataAddr->FkComm_Value);
			if (readitem(fp,&RtuDataAddr->FkComm_Value,size)!=1) continue;

			size = sizeof(RtuDataAddr->FkInput_Value);
			if (readitem(fp,&RtuDataAddr->FkInput_Value,size)!=1) continue;

			size = sizeof(RtuDataAddr->ZongJia_Value);
			if (readitem(fp,&RtuDataAddr->ZongJia_Value,size)!=1) continue;

			size = sizeof(RtuDataAddr->Fk_Control_Set_Value);
			if (readitem(fp,&RtuDataAddr->Fk_Control_Set_Value,size)!=1) continue;

			size = sizeof(RtuDataAddr->Event_Value);
			if (readitem(fp,&RtuDataAddr->Event_Value,size)!=1) continue;

			for (i = 0; i < CeLiangPoint_Max; i++)
			{
				size = sizeof(RtuDataAddr->Cl_MenXian_Value[i]);
				if (readitem(fp,&RtuDataAddr->Cl_MenXian_Value[i],size)!=1) flag = 1;
			}
			for (i = 0; i < ZongJia_Max; i++)
			{
				size = sizeof(RtuDataAddr->Zj_Control_Value[i]);
				if (readitem(fp,&RtuDataAddr->Zj_Control_Value[i],size)!=1) flag = 1;
			}
			for (i = 0; i < Task_Max; i++)
			{
				size = sizeof(RtuDataAddr->Task_Value[i]);
				if (readitem(fp,&RtuDataAddr->Task_Value[i],size)!=1) flag = 1;
			}
			fclose(fp);
			if (flag ==1)
			{
				continue;
			}
			sem_post(&RtuDataAddr->UseFileFlg);
			return TRUE;
		}
	}
	//�������ļ���д���ֵ
	initCanshu();
	sem_post(&RtuDataAddr->UseFileFlg);
	return SaveFKSet();
}
void Save_Input_Set() {
	SaveFKSet();
}
void Save_CommSet() {
	SaveFKSet();
}
void Save_Task_Set() {
	SaveFKSet();
}
void Save_Zj_Control_Set() {
	SaveFKSet();
}
void Save_Event_Set() {
	SaveFKSet();
}
void Save_Fk_Control_Set() {
	SaveFKSet();
}
void Save_Cl_MenXian_Set() {
	SaveFKSet();
}
void Save_Zongjia_Set() {
	SaveFKSet();
}
INT8U Save_Fk_Control_para_Set() {
	FILE *fp;
	sem_wait(&RtuDataAddr->UseFileFlg);
	fp = fopen("/config/p130ctl.set", "w");
	if (fp != NULL) {
		fseek(fp, 0, SEEK_SET);
		fwrite(&RtuDataAddr->FuKong_Control_Value.Asdu130Addr[0], sizeof(RtuDataAddr->FuKong_Control_Value), 1, fp);
		fclose(fp);
		sem_post(&RtuDataAddr->UseFileFlg);
		return TRUE;
	}
	sem_post(&RtuDataAddr->UseFileFlg);
	return FALSE;
}
INT8U Read_Fk_Control_para_Set() {
	FILE *fp;
	sem_wait(&RtuDataAddr->UseFileFlg);
	fp = fopen("/config/p130ctl.set", "r");
	if (fp != NULL) {
		fseek(fp, 0, SEEK_SET);
		fread(&RtuDataAddr->FuKong_Control_Value.Asdu130Addr[0], sizeof(RtuDataAddr->FuKong_Control_Value), 1, fp);
		fclose(fp);
		sem_post(&RtuDataAddr->UseFileFlg);
		return TRUE;
	}
	sem_post(&RtuDataAddr->UseFileFlg);
	return FALSE;
}

void Fengming_off(void) {
	if (AlarmOpened == 0)
		OpenAlarm();
	out8(AlarmPtr, 0);
	ClearSpiLed(ALARM_LED);
	//SetSpiLed(ALarmSet);
}
void Fengming_On(void) {
	TS tsd;
	TSGet(&tsd);
	OSTimeDly(100);
	if (AlarmOpened == 0)
		OpenAlarm();
	out8(AlarmPtr, 1);
	SetSpiLed(ALARM_LED);
	if (RtuDataAddr->Fk_Control_Set_Value.F57_Set_Para.Valid == 1) {
		if (RtuDataAddr->Fk_Control_Set_Value.F57_Set_Para.ZD_Voice_Enable[tsd.Hour / 8] & (1 << (tsd.Hour % 8))) {
			//ClearSpiLed(ALarmSet);
		}
	}
	OSTimeDly(100);

}
void GaoJingBegin()//�澯�̵���
{
	out8(ControlPtr+0x8,1);
	SetSpiLed(ALARM_LED);
	OSTimeDly(100);
}
void GaoJingEnd()
{
	out8(ControlPtr+0x8,0);
	ClearSpiLed(ALARM_LED);
}
void AlArmReportBegin() {
	Fengming_On();
	delay(1000);
}
void AlArmReportEnd() {
	Fengming_off();
}
void AlArmReportBeginNoDly() {
	Fengming_On();
	delay(1000);
}

