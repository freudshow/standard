#ifndef MEMDEF_H_
#define MEMDEF_H_

#include "memtype.h"

#endif /*MEMDEF_H_*/
