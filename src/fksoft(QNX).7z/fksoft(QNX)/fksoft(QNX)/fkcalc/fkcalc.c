#include "fkcalcfun.h"
const char verstr[]={"VER-STRING-FLG=002.002.217.004"__DATE__" "__TIME__};

INT8U a_ussx_last_time[CeLiangPoint_Max];//Խ�����޳���ʱ��,���=3���϶�ΪԽ�����ޣ���ͬ��
INT8U a_uxxx_last_time[CeLiangPoint_Max];//Խ�����޳���ʱ��
INT8U b_ussx_last_time[CeLiangPoint_Max];//Խ�����޳���ʱ��
INT8U b_uxxx_last_time[CeLiangPoint_Max];//Խ�����޳���ʱ��
INT8U c_ussx_last_time[CeLiangPoint_Max];//Խ�����޳���ʱ��
INT8U c_uxxx_last_time[CeLiangPoint_Max];//Խ�����޳���ʱ��

void TimeGetType17(INT8U *D,TS ts)
{
	D[0]=ts.Minute/10;
	D[0]=(D[0]<<4)+(ts.Minute%10);
	D[1]=ts.Hour/10;
	D[1]=(D[1]<<4)+(ts.Hour%10);
	D[2]=ts.Day/10;
	D[2]=(D[2]<<4)+(ts.Day%10);
	D[3]=ts.Month/10;
	D[3]=(D[3]<<4)+(ts.Month%10);
}
void TimeGetType18(INT8U *D,TS ts)
{
	D[0]=ts.Minute/10;
	D[0]=(D[0]<<4)+(ts.Minute%10);
	D[1]=ts.Hour/10;
	D[1]=(D[1]<<4)+(ts.Hour%10);
	D[2]=ts.Day/10;
	D[2]=(D[2]<<4)+(ts.Day%10);
}

void TimeGetType20(INT8U *D,TS ts)
{
	D[0]=ts.Day/10;
	D[0]=(D[0]<<4)+(ts.Day%10);
	D[1]=ts.Month/10;
	D[1]=(D[1]<<4)+(ts.Month%10);
	D[2]=ts.Year/10;
	D[3]=(D[3]<<4)+(ts.Year%10);
}

INT32U MaxValue(INT32U a,INT32U b,INT32U c)
{
	INT32U t;
	t=a;
	if(t<b)t=b;
	if(t<c)t=c;
	return t;
}
INT32U MinValue(INT32U a,INT32U b,INT32U c)
{
	INT32U t;
	t = a;
	if (b<t) t= b;
	if (c<t) t= c;
	return t;
}
INT32S Get_BianBi(INT8U ClNo)
{
	INT32S I,V;
	if(RtuDataAddr->Cl_MenXian_Value[ClNo].F25_Set_Para.Valid==1)
	{
		I=RtuDataAddr->Cl_MenXian_Value[ClNo].F25_Set_Para.I_BeiLv[1];
		I=(I<<8)+RtuDataAddr->Cl_MenXian_Value[ClNo].F25_Set_Para.I_BeiLv[0];
		V=RtuDataAddr->Cl_MenXian_Value[ClNo].F25_Set_Para.V_BeiLv[1];
		V=(V<<8)+RtuDataAddr->Cl_MenXian_Value[ClNo].F25_Set_Para.V_BeiLv[0];
		return I*V;
	}
	else
	{
		return 1;
	}
return 1;
}

void	Calc_Day_Bs_zj()
{
	INT8U Num,i;

	for(Num=0;Num<CeLiangPoint_Max;Num++)
	{
		RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[Num].Z_P_All_S=RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[Num].Z_P_F_S[i]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_F[i];
		}
		RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[Num].F_P_All_S=RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[Num].F_P_F_S[i]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_F[i];
		}
		RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[Num].Z_Q_All_S=RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[Num].Z_Q_F_S[i]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_F[i];
		}
		RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[Num].F_Q_All_S=RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[Num].F_Q_F_S[i]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_F[i];
		}
		RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[Num].Z_P_All_D=RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_All-RtuDataAddr->Day_DD_BS_Value[Num].Z_P_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[Num].Z_P_F_D[i]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_F[i]-RtuDataAddr->Day_DD_BS_Value[Num].Z_P_F[i];
		}
		RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[Num].F_P_All_D=RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_All-RtuDataAddr->Day_DD_BS_Value[Num].F_P_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[Num].F_P_F_D[i]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_F[i]-RtuDataAddr->Day_DD_BS_Value[Num].F_P_F[i];
		}
		RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[Num].Z_Q_All_D=RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_All-RtuDataAddr->Day_DD_BS_Value[Num].Z_Q_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[Num].Z_Q_F_D[i]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_F[i]-RtuDataAddr->Day_DD_BS_Value[Num].Z_Q_F[i];
		}
		RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[Num].F_Q_All_D=RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_All-RtuDataAddr->Day_DD_BS_Value[Num].F_Q_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Day_Save_Value.Cl_His_DianNeng[Num].F_Q_F_D[i]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_F[i]-RtuDataAddr->Day_DD_BS_Value[Num].F_Q_F[i];
		}
	}
	for(Num=0;Num<ZongJia_Max;Num++)
	{
		RtuDataAddr->Day_Save_Value.Zj_His_DianNeng[Num].Z_P_All_S=RtuDataAddr->Real_Zj_Value[Num].P_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Day_Save_Value.Zj_His_DianNeng[Num].Z_P_F_S[i]=RtuDataAddr->Real_Zj_Value[Num].P_F[i];
		}
		RtuDataAddr->Day_Save_Value.Zj_His_DianNeng[Num].Z_Q_All_S=RtuDataAddr->Real_Zj_Value[Num].Q_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Day_Save_Value.Zj_His_DianNeng[Num].Z_Q_F_S[i]=RtuDataAddr->Real_Zj_Value[Num].Q_F[i];
		}
		RtuDataAddr->Day_Save_Value.Zj_His_DianNeng[Num].Z_P_All_D=RtuDataAddr->Real_Zj_Value[Num].P_All-RtuDataAddr->Day_Zj_Value[Num].P_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Day_Save_Value.Zj_His_DianNeng[Num].Z_P_F_D[i]=RtuDataAddr->Real_Zj_Value[Num].P_F[i]-RtuDataAddr->Day_Zj_Value[Num].P_F[i];
		}
		RtuDataAddr->Day_Save_Value.Zj_His_DianNeng[Num].Z_Q_All_D=RtuDataAddr->Real_Zj_Value[Num].Q_All-RtuDataAddr->Day_Zj_Value[Num].Q_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Day_Save_Value.Zj_His_DianNeng[Num].Z_Q_F_D[i]=RtuDataAddr->Real_Zj_Value[Num].Q_F[i]-RtuDataAddr->Day_Zj_Value[Num].Q_F[i];
		}
	}
}
void	Calc_Yue_Bs_zj()
{
	INT8U Num,i;
	for(Num=0;Num<CeLiangPoint_Max;Num++)
	{
		RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[Num].Z_P_All_S=RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[Num].Z_P_F_S[i]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_F[i];
		}
		RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[Num].F_P_All_S=RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[Num].F_P_F_S[i]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_F[i];
		}
		RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[Num].Z_Q_All_S=RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[Num].Z_Q_F_S[i]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_F[i];
		}
		RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[Num].F_Q_All_S=RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[Num].F_Q_F_S[i]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_F[i];
		}
		RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[Num].Z_P_All_D=RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_All-RtuDataAddr->Yue_DD_BS_Value[Num].Z_P_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[Num].Z_P_F_D[i]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_P_F[i]-RtuDataAddr->Yue_DD_BS_Value[Num].Z_P_F[i];
		}
		RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[Num].F_P_All_D=RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_All-RtuDataAddr->Yue_DD_BS_Value[Num].F_P_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[Num].F_P_F_D[i]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_P_F[i]-RtuDataAddr->Yue_DD_BS_Value[Num].F_P_F[i];
		}
		RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[Num].Z_Q_All_D=RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_All-RtuDataAddr->Yue_DD_BS_Value[Num].Z_Q_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[Num].Z_Q_F_D[i]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].Z_Q_F[i]-RtuDataAddr->Yue_DD_BS_Value[Num].Z_Q_F[i];
		}
		RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[Num].F_Q_All_D=RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_All-RtuDataAddr->Yue_DD_BS_Value[Num].F_Q_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Yue_Save_Value.Cl_His_DianNeng[Num].F_Q_F_D[i]=RtuDataAddr->DD_Device_BiaoShi_Value[Num].F_Q_F[i]-RtuDataAddr->Yue_DD_BS_Value[Num].F_Q_F[i];
		}
	}
	for(Num=0;Num<ZongJia_Max;Num++)
	{
		RtuDataAddr->Yue_Save_Value.Zj_His_DianNeng[Num].Z_P_All_S=RtuDataAddr->Real_Zj_Value[Num].P_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Yue_Save_Value.Zj_His_DianNeng[Num].Z_P_F_S[i]=RtuDataAddr->Real_Zj_Value[Num].P_F[i];
		}
		RtuDataAddr->Yue_Save_Value.Zj_His_DianNeng[Num].Z_Q_All_S=RtuDataAddr->Real_Zj_Value[Num].Q_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Yue_Save_Value.Zj_His_DianNeng[Num].Z_Q_F_S[i]=RtuDataAddr->Real_Zj_Value[Num].Q_F[i];
		}
		RtuDataAddr->Yue_Save_Value.Zj_His_DianNeng[Num].Z_P_All_D=RtuDataAddr->Real_Zj_Value[Num].P_All-RtuDataAddr->Yue_Zj_Value[Num].P_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Yue_Save_Value.Zj_His_DianNeng[Num].Z_P_F_D[i]=RtuDataAddr->Real_Zj_Value[Num].P_F[i]-RtuDataAddr->Yue_Zj_Value[Num].P_F[i];
		}
		RtuDataAddr->Yue_Save_Value.Zj_His_DianNeng[Num].Z_Q_All_D=RtuDataAddr->Real_Zj_Value[Num].Q_All-RtuDataAddr->Yue_Zj_Value[Num].Q_All;
		for(i=0;i<FeiLvNum;i++)
		{
			RtuDataAddr->Yue_Save_Value.Zj_His_DianNeng[Num].Z_Q_F_D[i]=RtuDataAddr->Real_Zj_Value[Num].Q_F[i]-RtuDataAddr->Yue_Zj_Value[Num].Q_F[i];
		}
	}
}
void CalcShengyuDianliang()
{
	INT8U ZjNo;
	signed int OneMin_DianLiang=0;

	for(ZjNo=0;ZjNo<RtuDataAddr->ZongJia_Value.F14_Set_Para.Zongjia_Num;ZjNo++)
	{
		if(ZjNo>ZongJia_Max)return;
		if((RtuDataAddr->Zj_Control_Value[ZjNo].F47_Set_Para.Valid==1))//����ز���
			//&&(RtuDataAddr->Zj_Control_Value[ZjNo].F48_Set_Para.Valid==1)  )//��ؿ����۴�
		{
			OneMin_DianLiang = RtuDataAddr->Real_Zj_Value[ZjNo].P_All-RtuDataAddr->Gou_Dian_Kong_Value[ZjNo].LastMin_DianLiang;
			/*printf("\n\r onemin %d   P-all %d  LastMin %d  ZjNo %d  sheng %d",OneMin_DianLiang,
															RtuDataAddr->Real_Zj_Value[ZjNo].P_All,
															RtuDataAddr->Gou_Dian_Kong_Value[ZjNo].LastMin_DianLiang,ZjNo,
															RtuDataAddr->Real_Zj_Value[ZjNo].ShengYuDianLiang);*/

			if((firstflag==0)&&(RtuDataAddr->Real_Zj_Value[ZjNo].P_All!=0))
			{
				firstflag=1;
				OneMin_DianLiang=0;
			}
			RtuDataAddr->Gou_Dian_Kong_Value[ZjNo].LastMin_DianLiang=RtuDataAddr->Real_Zj_Value[ZjNo].P_All;
			//RtuDataAddr->LastDianliang_Value[ZjNo].LastMin_DianLiang=RtuDataAddr->Gou_Dian_Kong_Value[ZjNo].LastMin_DianLiang;
			if(OneMin_DianLiang>=0)
				RtuDataAddr->Real_Zj_Value[ZjNo].ShengYuDianLiang = RtuDataAddr->Real_Zj_Value[ZjNo].ShengYuDianLiang-OneMin_DianLiang;
		}
	}
}
void Zj_Data_Calc()
{
	INT8U i,j,Point,l;
	signed int  shengyu;
	signed int shengyu1[8];

	if(RtuDataAddr->ZongJia_Value.F14_Set_Para.Valid!=1)
	{
		for(i=0;i<8;i++)
			shengyu1[i]=RtuDataAddr->FM_Save_ZjValue.ZjData[i].ShengYuDianLiang;

		memset(&RtuDataAddr->Real_Zj_Value,0,sizeof(RtuDataAddr->Real_Zj_Value));

		for(i=0;i<8;i++)
			RtuDataAddr->FM_Save_ZjValue.ZjData[i].ShengYuDianLiang=shengyu1[i];
		return;
	}
	if(RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num>CeLiangPoint_Max)
	{
		RtuDataAddr->FkInput_Value.F10_Set_Para.Metet_jiaoliu_Num=CeLiangPoint_Max;
	}
	for(j=0;j<RtuDataAddr->ZongJia_Value.F14_Set_Para.Zongjia_Num;j++)
	{
		if(j>ZongJia_Max)return;
		shengyu=RtuDataAddr->Real_Zj_Value[j].ShengYuDianLiang;
		memset(&RtuDataAddr->Real_Zj_Value[j].Valid,0,sizeof(RtuDataAddr->Real_Zj_Value[j]));
		RtuDataAddr->Real_Zj_Value[j].ShengYuDianLiang=shengyu;

		for(i=0;i<RtuDataAddr->ZongJia_Value.F14_Set_Para.Zj_set[j].CeLiangNum;i++)
		{
			if(i>CeLiangPoint_Max){return;}
			Point=RtuDataAddr->ZongJia_Value.F14_Set_Para.Zj_set[j].Stat[i]&0x3f;
			if(RtuDataAddr->DD_Device_BiaoShi_Value[Point].Valid!=1)
			{
				RtuDataAddr->Real_Zj_Value[j].Valid=0;
				break;
			}
			if(Point>CeLiangPoint_Max){return;}
			RtuDataAddr->Real_Zj_Value[j].Valid=1;

			if(RtuDataAddr->ZongJia_Value.F14_Set_Para.Zj_set[j].Stat[i]&0x80)
			{
				RtuDataAddr->Real_Zj_Value[j].P=RtuDataAddr->Real_Zj_Value[j].P-RtuDataAddr->DD_Device_BiaoShi_Value[Point].P*Get_BianBi(Point)/10;
				RtuDataAddr->Real_Zj_Value[j].Q=RtuDataAddr->Real_Zj_Value[j].Q-RtuDataAddr->DD_Device_BiaoShi_Value[Point].Q*Get_BianBi(Point)/10;

				if(RtuDataAddr->ZongJia_Value.F14_Set_Para.Zj_set[j].Stat[i]&0x40)
				{
					if(RtuDataAddr->f_P_all[Point-1]>0)
					{//�����ʱ����
						//RtuDataAddr->DD_Device_BiaoShi_Value[Point-1].F_P_All = RtuDataAddr->DD_Device_BiaoShi_Value[Point].F_P_All*10 + RtuDataAddr->f_P_all[Point];
						RtuDataAddr->Real_Zj_Value[j].P_All=RtuDataAddr->Real_Zj_Value[j].P_All-RtuDataAddr->DD_Device_BiaoShi_Value[Point].F_P_All*Get_BianBi(Point)/1000;
					}else
						RtuDataAddr->Real_Zj_Value[j].P_All=RtuDataAddr->Real_Zj_Value[j].P_All-RtuDataAddr->DD_Device_BiaoShi_Value[Point].F_P_All*Get_BianBi(Point)/100;
					for(l=0;l<FeiLvNum;l++)
					{
						RtuDataAddr->Real_Zj_Value[j].P_F[l]=RtuDataAddr->Real_Zj_Value[j].P_F[l]-RtuDataAddr->DD_Device_BiaoShi_Value[Point].F_P_F[l]*Get_BianBi(Point)/100;
					}
					RtuDataAddr->Real_Zj_Value[j].Q_All=RtuDataAddr->Real_Zj_Value[j].Q_All-RtuDataAddr->DD_Device_BiaoShi_Value[Point].F_Q_All*Get_BianBi(Point)/100;
					for(l=0;l<FeiLvNum;l++)
					{
						RtuDataAddr->Real_Zj_Value[j].Q_F[l]=RtuDataAddr->Real_Zj_Value[j].Q_F[l]-RtuDataAddr->DD_Device_BiaoShi_Value[Point].F_Q_F[l]*Get_BianBi(Point)/100;
					}
				}
				else
				{
					if(RtuDataAddr->z_P_all[Point]>0)
					{//�����ʱ����
						//RtuDataAddr->DD_Device_BiaoShi_Value[Point].Z_P_All = RtuDataAddr->DD_Device_BiaoShi_Value[Point].Z_P_All*10 + RtuDataAddr->z_P_all[Point];
						RtuDataAddr->Real_Zj_Value[j].P_All=RtuDataAddr->Real_Zj_Value[j].P_All-RtuDataAddr->DD_Device_BiaoShi_Value[Point].Z_P_All*Get_BianBi(Point)/1000;
					}else
						RtuDataAddr->Real_Zj_Value[j].P_All=RtuDataAddr->Real_Zj_Value[j].P_All-RtuDataAddr->DD_Device_BiaoShi_Value[Point].Z_P_All*Get_BianBi(Point)/100;
					for(l=0;l<FeiLvNum;l++)
					{
						RtuDataAddr->Real_Zj_Value[j].P_F[l]=RtuDataAddr->Real_Zj_Value[j].P_F[l]-RtuDataAddr->DD_Device_BiaoShi_Value[Point].Z_P_F[l]*Get_BianBi(Point)/100;
					}
					RtuDataAddr->Real_Zj_Value[j].Q_All=RtuDataAddr->Real_Zj_Value[j].Q_All-RtuDataAddr->DD_Device_BiaoShi_Value[Point].Z_Q_All*Get_BianBi(Point)/100;
					for(l=0;l<FeiLvNum;l++)
					{
						RtuDataAddr->Real_Zj_Value[j].Q_F[l]=RtuDataAddr->Real_Zj_Value[j].Q_F[l]-RtuDataAddr->DD_Device_BiaoShi_Value[Point].Z_Q_F[l]*Get_BianBi(Point)/100;
					}
				}
			}
			else
			{
				RtuDataAddr->Real_Zj_Value[j].P=RtuDataAddr->Real_Zj_Value[j].P+RtuDataAddr->DD_Device_BiaoShi_Value[Point].P*Get_BianBi(Point)/10;
				RtuDataAddr->Real_Zj_Value[j].Q=RtuDataAddr->Real_Zj_Value[j].Q+RtuDataAddr->DD_Device_BiaoShi_Value[Point].Q*Get_BianBi(Point)/10;

				if(RtuDataAddr->ZongJia_Value.F14_Set_Para.Zj_set[j].Stat[i]&0x40)
				{
					if(RtuDataAddr->f_P_all[Point]>0)
					{//�����ʱ����
						//RtuDataAddr->DD_Device_BiaoShi_Value[Point].F_P_All = RtuDataAddr->DD_Device_BiaoShi_Value[Point].F_P_All*10 + RtuDataAddr->f_P_all[Point];
						RtuDataAddr->Real_Zj_Value[j].P_All=RtuDataAddr->Real_Zj_Value[j].P_All+RtuDataAddr->DD_Device_BiaoShi_Value[Point].F_P_All*Get_BianBi(Point)/1000;
					}else
						RtuDataAddr->Real_Zj_Value[j].P_All=RtuDataAddr->Real_Zj_Value[j].P_All+RtuDataAddr->DD_Device_BiaoShi_Value[Point].F_P_All*Get_BianBi(Point)/100;
					for(l=0;l<FeiLvNum;l++)
					{
						RtuDataAddr->Real_Zj_Value[j].P_F[l]=RtuDataAddr->Real_Zj_Value[j].P_F[l]+RtuDataAddr->DD_Device_BiaoShi_Value[Point].F_P_F[l]*Get_BianBi(Point)/100;
					}
					RtuDataAddr->Real_Zj_Value[j].Q_All=RtuDataAddr->Real_Zj_Value[j].Q_All+RtuDataAddr->DD_Device_BiaoShi_Value[Point].F_Q_All*Get_BianBi(Point)/100;
					for(l=0;l<FeiLvNum;l++)
					{
						RtuDataAddr->Real_Zj_Value[j].Q_F[l]=RtuDataAddr->Real_Zj_Value[j].Q_F[l]+RtuDataAddr->DD_Device_BiaoShi_Value[Point].F_Q_F[l]*Get_BianBi(Point)/100;
					}
				}
				else
				{
					if(RtuDataAddr->z_P_all[Point]>0)
					{//�����ʱ����
						//RtuDataAddr->DD_Device_BiaoShi_Value[Point].Z_P_All = RtuDataAddr->DD_Device_BiaoShi_Value[Point].Z_P_All*10 + RtuDataAddr->z_P_all[Point];
						RtuDataAddr->Real_Zj_Value[j].P_All=RtuDataAddr->Real_Zj_Value[j].P_All+RtuDataAddr->DD_Device_BiaoShi_Value[Point].Z_P_All*Get_BianBi(Point)/1000;
					}else
						RtuDataAddr->Real_Zj_Value[j].P_All=RtuDataAddr->Real_Zj_Value[j].P_All+RtuDataAddr->DD_Device_BiaoShi_Value[Point].Z_P_All*Get_BianBi(Point)/100;

					for(l=0;l<FeiLvNum;l++)
					{
						RtuDataAddr->Real_Zj_Value[j].P_F[l]=RtuDataAddr->Real_Zj_Value[j].P_F[l]+RtuDataAddr->DD_Device_BiaoShi_Value[Point].Z_P_F[l]*Get_BianBi(Point)/100;
					}
					RtuDataAddr->Real_Zj_Value[j].Q_All=RtuDataAddr->Real_Zj_Value[j].Q_All+RtuDataAddr->DD_Device_BiaoShi_Value[Point].Z_Q_All*Get_BianBi(Point)/100;
					for(l=0;l<FeiLvNum;l++)
					{
						RtuDataAddr->Real_Zj_Value[j].Q_F[l]=RtuDataAddr->Real_Zj_Value[j].Q_F[l]+RtuDataAddr->DD_Device_BiaoShi_Value[Point].Z_Q_F[l]*Get_BianBi(Point)/100;
					}
				}
			}
		}
		//-------------------��ʣ�����
		//CalcShengyuDianliang(j);
	    //----------------------------
	}
}
//�ܼ��黬���--------------
void SaveZjHcBuff()
{
	INT8U j;
	for(j=0;j<ZongJia_Max;j++)
	{
		if(RtuDataAddr->Real_Zj_Value[j].Valid==1)
		{
			RtuDataAddr->Zj_HC_Buff[j].RecCount++;
			RtuDataAddr->Zj_HC_Buff[j].GLRecCount++;
			RtuDataAddr->Zj_HC_Buff[j].ChaDongHead++;
			RtuDataAddr->Zj_HC_Buff[j].P_Buff[RtuDataAddr->Zj_HC_Buff[j].Head]=RtuDataAddr->Real_Zj_Value[j].P;
			RtuDataAddr->Zj_HC_Buff[j].P_DDBuff[RtuDataAddr->Zj_HC_Buff[j].Head]=RtuDataAddr->Real_Zj_Value[j].P_All;
			RtuDataAddr->Zj_HC_Buff[j].Head=(RtuDataAddr->Zj_HC_Buff[j].Head+1)%70;
		}
	}
}
void Get_Now_type18(Data_Type_18 *Dest)
{
	TS ts;
	TSGet(&ts);
	Dest->BCD01=((ts.Minute/10)<<4)+(ts.Minute%10);
	Dest->BCD02=((ts.Hour/10)<<4)+(ts.Hour%10);
	Dest->BCD03=((ts.Day/10)<<4)+(ts.Day%10);
}
void Cl_Xl_Calc()
{
	INT8U i,j;
	for(i=0;i<CeLiangPoint_Max;i++)
	{
	if(RtuDataAddr->DD_Device_BiaoShi_Value[i].Valid!=1)continue;
		RtuDataAddr->CL_XL_JX[i][RtuDataAddr->Cl_Xl_Head].P_All=RtuDataAddr->DD_Device_BiaoShi_Value[i].P;
		RtuDataAddr->CL_XL_JX[i][RtuDataAddr->Cl_Xl_Head].P_U=RtuDataAddr->DD_Device_BiaoShi_Value[i].PA;
		RtuDataAddr->CL_XL_JX[i][RtuDataAddr->Cl_Xl_Head].P_V=RtuDataAddr->DD_Device_BiaoShi_Value[i].PB;
		RtuDataAddr->CL_XL_JX[i][RtuDataAddr->Cl_Xl_Head].P_W=RtuDataAddr->DD_Device_BiaoShi_Value[i].PC;
	}
	for(i=0;i<CeLiangPoint_Max;i++)
	{
		if(RtuDataAddr->DD_Device_BiaoShi_Value[i].Valid!=1)continue;
		RtuDataAddr->Now_CL_XL_JX[i].P_All=0;
		RtuDataAddr->Now_CL_XL_JX[i].P_U=0;
		RtuDataAddr->Now_CL_XL_JX[i].P_V=0;
		RtuDataAddr->Now_CL_XL_JX[i].P_W=0;
		for(j=0;j<15;j++)
		{
			RtuDataAddr->Now_CL_XL_JX[i].P_All=RtuDataAddr->Now_CL_XL_JX[i].P_All+RtuDataAddr->CL_XL_JX[i][j].P_All;
			RtuDataAddr->Now_CL_XL_JX[i].P_U=RtuDataAddr->Now_CL_XL_JX[i].P_U+RtuDataAddr->CL_XL_JX[i][j].P_U;
			RtuDataAddr->Now_CL_XL_JX[i].P_V=RtuDataAddr->Now_CL_XL_JX[i].P_V+RtuDataAddr->CL_XL_JX[i][j].P_V;
			RtuDataAddr->Now_CL_XL_JX[i].P_W=RtuDataAddr->Now_CL_XL_JX[i].P_W+RtuDataAddr->CL_XL_JX[i][j].P_W;
		}
		RtuDataAddr->Now_CL_XL_JX[i].P_All=RtuDataAddr->Now_CL_XL_JX[i].P_All/15;
		RtuDataAddr->Now_CL_XL_JX[i].P_U=RtuDataAddr->Now_CL_XL_JX[i].P_U/15;
		RtuDataAddr->Now_CL_XL_JX[i].P_V=RtuDataAddr->Now_CL_XL_JX[i].P_V/15;
		RtuDataAddr->Now_CL_XL_JX[i].P_W=RtuDataAddr->Now_CL_XL_JX[i].P_W/15;
	}

	RtuDataAddr->Cl_Xl_Head=(RtuDataAddr->Cl_Xl_Head+1)%15;
}
void Day_Data_Calc()
{
	INT8U i,Ch;
	Ch=0;
#if FKJiaoCai
	if((RtuDataAddr->FkDdRealData.VA>SD_Men)
	||(RtuDataAddr->FkDdRealData.VB>SD_Men)
	||(RtuDataAddr->FkDdRealData.VC>SD_Men))
	{
		RtuDataAddr->Day_Save_Value.ZD_Day_stat.GD_Time++;
		RtuDataAddr->Yue_Save_Value.ZD_Yue_stat.GD_Time++;
	}
	if((RtuDataAddr->FkDdRealData.VA<=SD_Men)
	&&(RtuDataAddr->FkDdRealData.VB<=SD_Men)
	&&(RtuDataAddr->FkDdRealData.VC<=SD_Men))
	{
		////////////////////////////////////ʲô��û��
	}
	if((RtuDataAddr->Fm_Save_Eve.FKTmp.VA<=SD_Men)
	&&(RtuDataAddr->Fm_Save_Eve.FKTmp.VB<=SD_Men)
	&&(RtuDataAddr->Fm_Save_Eve.FKTmp.VC<=SD_Men))
	{
		RtuDataAddr->Fm_Save_Eve.FKTmp.Duanxiang_Time++;
		Ch=1;
	}
	if(RtuDataAddr->Fm_Save_Eve.FKTmp.VA<=SD_Men)
	{
		RtuDataAddr->Fm_Save_Eve.FKTmp.A_Duan_Time++;
		Ch=1;
	}
	if(RtuDataAddr->Fm_Save_Eve.FKTmp.VB<=SD_Men)
	{
		RtuDataAddr->Fm_Save_Eve.FKTmp.B_Duan_Time++;
		Ch=1;
	}
	if(RtuDataAddr->Fm_Save_Eve.FKTmp.VC<=SD_Men)
	{
		RtuDataAddr->Fm_Save_Eve.FKTmp.C_Duan_Time++;
		Ch=1;
	}
	if(Ch==1)
	{
	//		Fm25cl64_Write(&Fm_Save_Eve.EC1,sizeof(Fm_Save_Eve),Fm_Save_Eve_Offset);
	}
#endif
	for(i=0;i<ZongJia_Max;i++)
	{
		if(RtuDataAddr->Real_Zj_Value[i].Valid!=1)continue;
		if(RtuDataAddr->Real_Zj_Value[i].P>RtuDataAddr->Day_Save_Value.Zj_Stat[i].MaxP)
		{
			RtuDataAddr->Day_Save_Value.Zj_Stat[i].MaxP=RtuDataAddr->Real_Zj_Value[i].P;
			Get_Now_type18(&RtuDataAddr->Day_Save_Value.Zj_Stat[i].MaxP_Time);
		}
		if(RtuDataAddr->Real_Zj_Value[i].P<RtuDataAddr->Day_Save_Value.Zj_Stat[i].MinP)
		{
			RtuDataAddr->Day_Save_Value.Zj_Stat[i].MinP=RtuDataAddr->Real_Zj_Value[i].P;
			Get_Now_type18(&RtuDataAddr->Day_Save_Value.Zj_Stat[i].MinP_Time);
		}
		if(RtuDataAddr->Real_Zj_Value[i].P==0)
		{
			RtuDataAddr->Day_Save_Value.Zj_Stat[i].P_Zero_Calc++;
		}
		RtuDataAddr->Day_Save_Value.Zj_Stat[i].Valid=1;
	}
	for(i=0;i<CeLiangPoint_Max;i++)
	{
		if(RtuDataAddr->DD_Device_BiaoShi_Value[i].Valid!=1)continue;
		memcpy(&RtuDataAddr->Day_Save_Value.Cl_Stat[i].Duanxiang_All,&RtuDataAddr->DD_BianLiang_Shuju[i].Duanxiang_All,2);
		if(RtuDataAddr->DD_Device_BiaoShi_Value[i].P>RtuDataAddr->Day_Save_Value.Cl_Stat[i].P_All)
		{
			RtuDataAddr->Day_Save_Value.Cl_Stat[i].P_All=RtuDataAddr->DD_Device_BiaoShi_Value[i].P;
			Get_Now_type18(&RtuDataAddr->Day_Save_Value.Cl_Stat[i].P_All_Time);
		}
		if(RtuDataAddr->DD_Device_BiaoShi_Value[i].PA>RtuDataAddr->Day_Save_Value.Cl_Stat[i].P_U)
		{
			RtuDataAddr->Day_Save_Value.Cl_Stat[i].P_U=RtuDataAddr->DD_Device_BiaoShi_Value[i].PA;
			Get_Now_type18(&RtuDataAddr->Day_Save_Value.Cl_Stat[i].P_U_Time);
		}
		if(RtuDataAddr->DD_Device_BiaoShi_Value[i].PB>RtuDataAddr->Day_Save_Value.Cl_Stat[i].P_V)
		{
			RtuDataAddr->Day_Save_Value.Cl_Stat[i].P_V=RtuDataAddr->DD_Device_BiaoShi_Value[i].PB;
			Get_Now_type18(&RtuDataAddr->Day_Save_Value.Cl_Stat[i].P_V_Time);
		}
		if(RtuDataAddr->DD_Device_BiaoShi_Value[i].PC>RtuDataAddr->Day_Save_Value.Cl_Stat[i].P_W)
		{
			RtuDataAddr->Day_Save_Value.Cl_Stat[i].P_W=RtuDataAddr->DD_Device_BiaoShi_Value[i].PC;
			Get_Now_type18(&RtuDataAddr->Day_Save_Value.Cl_Stat[i].P_W_Time);
		}
		if((RtuDataAddr->DD_Device_BiaoShi_Value[i].P)==0){RtuDataAddr->Day_Save_Value.Cl_Stat[i].P_Zero_Time++;};
		if((RtuDataAddr->DD_Device_BiaoShi_Value[i].PA)==0){RtuDataAddr->Day_Save_Value.Cl_Stat[i].PU_Zero_Time++;};
		if((RtuDataAddr->DD_Device_BiaoShi_Value[i].PB)==0){RtuDataAddr->Day_Save_Value.Cl_Stat[i].PV_Zero_Time++;};
		if((RtuDataAddr->DD_Device_BiaoShi_Value[i].PC)==0){RtuDataAddr->Day_Save_Value.Cl_Stat[i].PW_Zero_Time++;};
		if(RtuDataAddr->Now_CL_XL_JX[i].P_All>RtuDataAddr->Day_Save_Value.Cl_Stat[i].P_All_XL)
		{
			RtuDataAddr->Day_Save_Value.Cl_Stat[i].P_All_XL=RtuDataAddr->Now_CL_XL_JX[i].P_All;
			Get_Now_type18(&RtuDataAddr->Day_Save_Value.Cl_Stat[i].P_All_XL_Time);
		}
		if(RtuDataAddr->Now_CL_XL_JX[i].P_U>RtuDataAddr->Day_Save_Value.Cl_Stat[i].P_U_XL)
		{
			RtuDataAddr->Day_Save_Value.Cl_Stat[i].P_U_XL=RtuDataAddr->Now_CL_XL_JX[i].P_U;
			Get_Now_type18(&RtuDataAddr->Day_Save_Value.Cl_Stat[i].P_U_XL_Time);
		}
		if(RtuDataAddr->Now_CL_XL_JX[i].P_V>RtuDataAddr->Day_Save_Value.Cl_Stat[i].P_V_XL)
		{
			RtuDataAddr->Day_Save_Value.Cl_Stat[i].P_V_XL=RtuDataAddr->Now_CL_XL_JX[i].P_V;
			Get_Now_type18(&RtuDataAddr->Day_Save_Value.Cl_Stat[i].P_V_XL_Time);
		}
		if(RtuDataAddr->Now_CL_XL_JX[i].P_W>RtuDataAddr->Day_Save_Value.Cl_Stat[i].P_W_XL)
		{
			RtuDataAddr->Day_Save_Value.Cl_Stat[i].P_W_XL=RtuDataAddr->Now_CL_XL_JX[i].P_W;
			Get_Now_type18(&RtuDataAddr->Day_Save_Value.Cl_Stat[i].P_W_XL_Time);
		}
		RtuDataAddr->Day_Save_Value.Cl_Stat[i].Valid=1;
	}
}
void Yue_Data_Calc()
{
	INT8U i;
	for(i=0;i<ZongJia_Max;i++)
	{
		if(RtuDataAddr->Real_Zj_Value[i].Valid!=1)continue;
		if(RtuDataAddr->Real_Zj_Value[i].P>RtuDataAddr->Yue_Save_Value.Zj_Stat[i].MaxP)
		{
			RtuDataAddr->Yue_Save_Value.Zj_Stat[i].MaxP=RtuDataAddr->Real_Zj_Value[i].P;
			Get_Now_type18(&RtuDataAddr->Yue_Save_Value.Zj_Stat[i].MaxP_Time);
		}
		if(RtuDataAddr->Real_Zj_Value[i].P<RtuDataAddr->Yue_Save_Value.Zj_Stat[i].MinP)
		{
			RtuDataAddr->Yue_Save_Value.Zj_Stat[i].MinP=RtuDataAddr->Real_Zj_Value[i].P;
			Get_Now_type18(&RtuDataAddr->Yue_Save_Value.Zj_Stat[i].MinP_Time);
		}
		if(RtuDataAddr->Real_Zj_Value[i].P==0)
		{
			RtuDataAddr->Yue_Save_Value.Zj_Stat[i].P_Zero_Calc++;
		}
		RtuDataAddr->Yue_Save_Value.Zj_Stat[i].Valid=1;
	}
	for(i=0;i<CeLiangPoint_Max;i++)
	{
		if(RtuDataAddr->DD_Device_BiaoShi_Value[i].Valid!=1)continue;
		if(RtuDataAddr->DD_Device_BiaoShi_Value[i].P>RtuDataAddr->Yue_Save_Value.Cl_Stat[i].P_All)
		{
			RtuDataAddr->Yue_Save_Value.Cl_Stat[i].P_All=RtuDataAddr->DD_Device_BiaoShi_Value[i].P;
			Get_Now_type18(&RtuDataAddr->Yue_Save_Value.Cl_Stat[i].P_All_Time);
		}
		if(RtuDataAddr->DD_Device_BiaoShi_Value[i].PA>RtuDataAddr->Yue_Save_Value.Cl_Stat[i].P_U)
		{
			RtuDataAddr->Yue_Save_Value.Cl_Stat[i].P_U=RtuDataAddr->DD_Device_BiaoShi_Value[i].PA;
			Get_Now_type18(&RtuDataAddr->Yue_Save_Value.Cl_Stat[i].P_U_Time);
		}
		if(RtuDataAddr->DD_Device_BiaoShi_Value[i].PB>RtuDataAddr->Yue_Save_Value.Cl_Stat[i].P_V)
		{
			RtuDataAddr->Yue_Save_Value.Cl_Stat[i].P_V=RtuDataAddr->DD_Device_BiaoShi_Value[i].PB;
			Get_Now_type18(&RtuDataAddr->Yue_Save_Value.Cl_Stat[i].P_V_Time);
		}
		if(RtuDataAddr->DD_Device_BiaoShi_Value[i].PC>RtuDataAddr->Yue_Save_Value.Cl_Stat[i].P_W)
		{
			RtuDataAddr->Yue_Save_Value.Cl_Stat[i].P_W=RtuDataAddr->DD_Device_BiaoShi_Value[i].PC;
			Get_Now_type18(&RtuDataAddr->Yue_Save_Value.Cl_Stat[i].P_W_Time);
		}
		if((RtuDataAddr->DD_Device_BiaoShi_Value[i].P)==0){RtuDataAddr->Yue_Save_Value.Cl_Stat[i].P_Zero_Time++;};
		if((RtuDataAddr->DD_Device_BiaoShi_Value[i].PA)==0){RtuDataAddr->Yue_Save_Value.Cl_Stat[i].PU_Zero_Time++;};
		if((RtuDataAddr->DD_Device_BiaoShi_Value[i].PB)==0){RtuDataAddr->Yue_Save_Value.Cl_Stat[i].PV_Zero_Time++;};
		if((RtuDataAddr->DD_Device_BiaoShi_Value[i].PC)==0){RtuDataAddr->Yue_Save_Value.Cl_Stat[i].PW_Zero_Time++;};
		if(RtuDataAddr->Now_CL_XL_JX[i].P_All>RtuDataAddr->Yue_Save_Value.Cl_Stat[i].P_All_XL)
		{
			RtuDataAddr->Yue_Save_Value.Cl_Stat[i].P_All_XL=RtuDataAddr->Now_CL_XL_JX[i].P_All;
			Get_Now_type18(&RtuDataAddr->Yue_Save_Value.Cl_Stat[i].P_All_XL_Time);
		}
		if(RtuDataAddr->Now_CL_XL_JX[i].P_U>RtuDataAddr->Yue_Save_Value.Cl_Stat[i].P_U_XL)
		{
			RtuDataAddr->Yue_Save_Value.Cl_Stat[i].P_U_XL=RtuDataAddr->Now_CL_XL_JX[i].P_U;
			Get_Now_type18(&RtuDataAddr->Yue_Save_Value.Cl_Stat[i].P_U_XL_Time);
		}
		if(RtuDataAddr->Now_CL_XL_JX[i].P_V>RtuDataAddr->Yue_Save_Value.Cl_Stat[i].P_V_XL)
		{
			RtuDataAddr->Yue_Save_Value.Cl_Stat[i].P_V_XL=RtuDataAddr->Now_CL_XL_JX[i].P_V;
			Get_Now_type18(&RtuDataAddr->Yue_Save_Value.Cl_Stat[i].P_V_XL_Time);
		}
		if(RtuDataAddr->Now_CL_XL_JX[i].P_W>RtuDataAddr->Yue_Save_Value.Cl_Stat[i].P_W_XL)
		{
			RtuDataAddr->Yue_Save_Value.Cl_Stat[i].P_W_XL=RtuDataAddr->Now_CL_XL_JX[i].P_W;
			Get_Now_type18(&RtuDataAddr->Yue_Save_Value.Cl_Stat[i].P_W_XL_Time);
		}
		RtuDataAddr->Yue_Save_Value.Cl_Stat[i].Valid=1;
	}
}
void CalcTingZouErr()
{
	INT8U i;
	for(i=0;i<CeLiangPoint_Max;i++)
	{
		if(RtuDataAddr->Event_Value.F59_Set_Para.Valid!=1)continue;
		if(RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_All <=0)continue;
		if(RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_All==RtuDataAddr->CL_ERR[i].Old_PDD)
		{
			//���ܱ�ͣ��
			TingZhouCount[i] = TingZhouCount[i] + 1;
			if (TingZhouCount[i] >= (RtuDataAddr->Event_Value.F59_Set_Para.DD_Ting_Men*15))
			{//ͣ��ʱ�䳬��ֵ
				//��¼�¼�
				//CAPrint("\n\r tingzou Old_PDD[%d] ===%d Z_P_All[%d]===%d\n\r",i,RtuDataAddr->CL_ERR[i].Old_PDD,i,RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_All);
				if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)
				{
					if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[3]&0x20)//��Ҫ�Բ������ý����¼���¼
					{
						RtuDataAddr->Event_Save.Event.Err30.ERCNo=30;
						RtuDataAddr->Event_Save.Event.Err30.len=13;
						RtuDataAddr->Event_Save.Event.Err30.ClNo[0]=(RtuDataAddr->Meter_Para.Dian_Meter[i].CeLiangNo&0xff);
						RtuDataAddr->Event_Save.Event.Err30.ClNo[1]=(((RtuDataAddr->Meter_Para.Dian_Meter[i].CeLiangNo>>8)&0xff))|0x80;
						RtuDataAddr->Event_Save.Event.Err30.Old_ShiZhi[0]=0;
						INT32ToBCD(RtuDataAddr->CL_ERR[i].Old_PDD,&RtuDataAddr->Event_Save.Event.Err30.Old_ShiZhi[1],4);

						RtuDataAddr->Event_Save.Event.Err30.Fazhi=RtuDataAddr->Event_Value.F59_Set_Para.DD_Ting_Men;//������ͣ�߷�ֵ

						if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[3]&0x20)//��Ҫ�¼�
						{
							SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err30.Occur_Time.BCD01,1,30);
						}
						else//һ���¼�
						{
							SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err30.Occur_Time.BCD01,2,30);
						}
					}
				}
				RtuDataAddr->CL_ERR[i].Old_PDD=RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_All;
				TingZhouCount[i] = 0;
			}
		}
		else
		{
			TingZhouCount[i] = 0;
		}
	}
}
void CalcDiannengErr()
{
	INT8U i;
	int feizoucha = 0;
	for(i=0;i<CeLiangPoint_Max;i++)
	{
		RtuDataAddr->CL_ERR[i].FlyValue=((RtuDataAddr->Event_Value.F59_Set_Para.DD_FeiZou_Men>>4)*10)
		+(RtuDataAddr->Event_Value.F59_Set_Para.DD_FeiZou_Men&0x0f);
		RtuDataAddr->CL_ERR[i].FlyValue=RtuDataAddr->CL_ERR[i].FlyValue*10;

		RtuDataAddr->CL_ERR[i].OverValue=((RtuDataAddr->Event_Value.F59_Set_Para.DD_ChaoCha_Men>>4)*10)
		+(RtuDataAddr->Event_Value.F59_Set_Para.DD_ChaoCha_Men&0x0f);
		RtuDataAddr->CL_ERR[i].OverValue=RtuDataAddr->CL_ERR[i].OverValue*10;

		if(RtuDataAddr->DD_Device_BiaoShi_Value[i].Valid!=1)continue;

		//printf("\n\r\n\rOld_PDD[%d] ===%d Z_P_All[%d]===%d\n\r",i,RtuDataAddr->CL_ERR[i].Old_PDD,i,RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_All);
		//CAPrint("\n\r Old_PDD[%d] ===%d Z_P_All[%d]===%d\n\r",i,RtuDataAddr->CL_ERR[i].Old_PDD,i,RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_All);

		if(RtuDataAddr->CL_ERR[i].Old_PDD>RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_All)
		{
			//���ܱ�ʾ���½�
			//CAPrint("\n\r rxiajiang Old_PDD[%d] ===%d Z_P_All[%d]===%d\n\r",i,RtuDataAddr->CL_ERR[i].Old_PDD,i,RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_All);

			if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)
			{
				if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[3]&0x04)//��Ҫ�Բ������ý����¼���¼
				{
					printf("\n\r Err27 happen !!!!!");
					RtuDataAddr->Event_Save.Event.Err27.ERCNo=27;
					RtuDataAddr->Event_Save.Event.Err27.len=17;
					RtuDataAddr->Event_Save.Event.Err27.ClNo[0]=(RtuDataAddr->Meter_Para.Dian_Meter[i].CeLiangNo&0xff);
					RtuDataAddr->Event_Save.Event.Err27.ClNo[1]=((RtuDataAddr->Meter_Para.Dian_Meter[i].CeLiangNo>>8)&0xff)|0x80;
					RtuDataAddr->Event_Save.Event.Err27.Old_ShiZhi[0]=0;
					INT32ToBCD(RtuDataAddr->CL_ERR[i].Old_PDD,&RtuDataAddr->Event_Save.Event.Err27.Old_ShiZhi[1],4);//??�½�ǰ�����й�����ֵ
					RtuDataAddr->Event_Save.Event.Err27.New_ShiZhi[0]=0;
					INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_All,&RtuDataAddr->Event_Save.Event.Err27.New_ShiZhi[1],4);//�½��������й�����ֵ
					if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[3]&0x04)//��Ҫ�¼�
					{
						SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err27.Occur_Time.BCD01,1,27);
					}
					else//һ���¼�
					{
						SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err27.Occur_Time.BCD01,2,27);
					}
				}
			}
			RtuDataAddr->CL_ERR[i].Old_PDD=RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_All;
		}
		else
		{
			if(RtuDataAddr->Event_Value.F59_Set_Para.Valid!=1)
				continue;

			if (RtuDataAddr->CL_ERR[i].Old_PDD>0)
			{
				feizoucha = RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_All-RtuDataAddr->CL_ERR[i].Old_PDD;
				if(feizoucha >= RtuDataAddr->CL_ERR[i].FlyValue)
				{
					//���ܱ�����
					//CAPrint("\n\rfeizou Old_PDD[%d] ===%d Z_P_All[%d]===%d\n\r",i,RtuDataAddr->CL_ERR[i].Old_PDD,i,RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_All);

					if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)
					{
						if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[3]&0x10)//��Ҫ�Բ������ý����¼���¼
						{
							RtuDataAddr->Event_Save.Event.Err29.ERCNo=29;
							RtuDataAddr->Event_Save.Event.Err29.len=18;
							RtuDataAddr->Event_Save.Event.Err29.ClNo[0]=(RtuDataAddr->Meter_Para.Dian_Meter[i].CeLiangNo)&0xff;
							RtuDataAddr->Event_Save.Event.Err29.ClNo[1]=((RtuDataAddr->Meter_Para.Dian_Meter[i].CeLiangNo>>8)&0xff)|0x80;

							RtuDataAddr->Event_Save.Event.Err29.Old_ShiZhi[0]=0;
							INT32ToBCD(RtuDataAddr->CL_ERR[i].Old_PDD,&RtuDataAddr->Event_Save.Event.Err29.Old_ShiZhi[1],4);

							RtuDataAddr->Event_Save.Event.Err29.New_ShiZhi[0]=0;
							INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_All,&RtuDataAddr->Event_Save.Event.Err29.New_ShiZhi[1],4);

							RtuDataAddr->Event_Save.Event.Err29.Fazhi=RtuDataAddr->Event_Value.F59_Set_Para.DD_FeiZou_Men;//���������߷�ֵ

							if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[3]&0x10)//��Ҫ�¼�
							{
								SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err29.Occur_Time.BCD01,1,29);
							}
							else//һ���¼�
							{
								SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err29.Occur_Time.BCD01,2,29);
							}
						}
					}
					RtuDataAddr->CL_ERR[i].Old_PDD=RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_All;
				}
			}
		}

		RtuDataAddr->CL_ERR[i].Old_PDD=RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_All;
	}

}
/*
void F27_28_29_30Calc()
{
	INT16U US,UX,UD,USS,UXX,UVWXZ,VCalc,VValue,VMax,VMin;
	INT16S ISS,IS,IValue,IMax,ICalc,ABCXZ,IMin;
	INT32U SSS,SS,PS;
	float PS1;
	TS ts;
	INT8U i;
	TSGet(&ts);
	for(i=0;i<CeLiangPoint_Max;i++)
	{
		if(RtuDataAddr->DD_Device_BiaoShi_Value[i].Valid!=1)continue;
		if(RtuDataAddr->DD_Device_BiaoShi_Value[i].Cos<RtuDataAddr->Cl_MenXian_Value[i].F28_Set_Para.CosFenDuan_Xian1)//�¼� ���㹦�������ۼ�ʱ��
		{

			RtuDataAddr->YF27_28_29_30_Mem[i].QuDuan1_Count++;
			//CAPrint("\n\rRtuDataAddr->YF27_28_29_30_Mem[%d].QuDuan1_Count===%d",i,RtuDataAddr->YF27_28_29_30_Mem[i].QuDuan1_Count);
		}
		if((RtuDataAddr->DD_Device_BiaoShi_Value[i].Cos>=RtuDataAddr->Cl_MenXian_Value[i].F28_Set_Para.CosFenDuan_Xian1)
				&&(RtuDataAddr->DD_Device_BiaoShi_Value[i].Cos<RtuDataAddr->Cl_MenXian_Value[i].F28_Set_Para.CosFenDuan_Xian2))//�¼� ���㹦�������ۼ�ʱ��
		{
			RtuDataAddr->YF27_28_29_30_Mem[i].QuDuan2_Count++;
			//CAPrint("\n\rRtuDataAddr->YF27_28_29_30_Mem[%d].QuDuan2_Count===%d",i,RtuDataAddr->YF27_28_29_30_Mem[i].QuDuan2_Count);
		}
		if(RtuDataAddr->DD_Device_BiaoShi_Value[i].Cos>=RtuDataAddr->Cl_MenXian_Value[i].F28_Set_Para.CosFenDuan_Xian2)//�¼� ���㹦�������ۼ�ʱ��
		{
			RtuDataAddr->YF27_28_29_30_Mem[i].QuDuan3_Count++;
			//CAPrint("\n\rRtuDataAddr->YF27_28_29_30_Mem[%d].QuDuan3_Count===%d",i,RtuDataAddr->YF27_28_29_30_Mem[i].QuDuan3_Count);
		}


		if(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.Valid==1)
		{
			US=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_S[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_S[1]&0x0f);
			US=(US*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_S[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_S[0]&0x0f);

			UX=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_X[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_X[1]&0x0f);
			UX=(UX*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_X[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_X[0]&0x0f);

			UD=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_Duan_Men[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_Duan_Men[1]&0x0f);
			UD=(UD*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_Duan_Men[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_Duan_Men[0]&0x0f);

			USS=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_SS[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_SS[1]&0x0f);
			USS=(USS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_SS[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_SS[0]&0x0f);

			UXX=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_XX[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_XX[1]&0x0f);
			UXX=(UXX*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_XX[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_XX[0]&0x0f);

				ISS=(((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_SS[2]>>4)&0x07)*10)+
					(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_SS[2]&0x0f);
				ISS=(ISS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_SS[1]>>4)*10)+
					(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_SS[1]&0x0f);
				ISS=(ISS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_SS[0]>>4)*10)+
					(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_SS[0]&0x0f);

				IS=(((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_S[2]>>4)&0x07)*10)+
					(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_S[2]&0x0f);
				IS=(IS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_S[1]>>4)*10)+
					(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_S[1]&0x0f);
				IS=(IS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_S[0]>>4)*10)+
					(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_S[0]&0x0f);
//�յ�ѹ
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA>RtuDataAddr->F27_28_29_30_Mem[i].DUUMAX)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].DUUMAX=RtuDataAddr->DD_Device_BiaoShi_Value[i].VA;
				TimeGetType18(RtuDataAddr->F27_28_29_30_Mem[i].DUUMAX_TIME,ts);
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB>RtuDataAddr->F27_28_29_30_Mem[i].DUVMAX)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].DUVMAX=RtuDataAddr->DD_Device_BiaoShi_Value[i].VB;
				TimeGetType18(RtuDataAddr->F27_28_29_30_Mem[i].DUVMAX_TIME,ts);
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC>RtuDataAddr->F27_28_29_30_Mem[i].DUWMAX)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].DUWMAX=RtuDataAddr->DD_Device_BiaoShi_Value[i].VC;
				TimeGetType18(RtuDataAddr->F27_28_29_30_Mem[i].DUWMAX_TIME,ts);
			}

//�µ�ѹ
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA>RtuDataAddr->YF27_28_29_30_Mem[i].DUUMAX)
			{
				RtuDataAddr->YF27_28_29_30_Mem[i].DUUMAX=RtuDataAddr->DD_Device_BiaoShi_Value[i].VA;
				TimeGetType18(RtuDataAddr->YF27_28_29_30_Mem[i].DUUMAX_TIME,ts);
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB>RtuDataAddr->YF27_28_29_30_Mem[i].DUVMAX)
			{
				RtuDataAddr->YF27_28_29_30_Mem[i].DUVMAX=RtuDataAddr->DD_Device_BiaoShi_Value[i].VB;
				TimeGetType18(RtuDataAddr->YF27_28_29_30_Mem[i].DUVMAX_TIME,ts);
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC>RtuDataAddr->YF27_28_29_30_Mem[i].DUWMAX)
			{
				RtuDataAddr->YF27_28_29_30_Mem[i].DUWMAX=RtuDataAddr->DD_Device_BiaoShi_Value[i].VC;
				TimeGetType18(RtuDataAddr->YF27_28_29_30_Mem[i].DUWMAX_TIME,ts);
			}
//��ƽ����ѹ
			if(RtuDataAddr->F27_28_29_30_Mem[i].DUUAVE==0)
				RtuDataAddr->F27_28_29_30_Mem[i].DUUAVE=RtuDataAddr->DD_Device_BiaoShi_Value[i].VA;
			else
				RtuDataAddr->F27_28_29_30_Mem[i].DUUAVE=(RtuDataAddr->F27_28_29_30_Mem[i].DUUAVE+RtuDataAddr->DD_Device_BiaoShi_Value[i].VA)/2;

			if(RtuDataAddr->F27_28_29_30_Mem[i].DUVAVE==0)
				RtuDataAddr->F27_28_29_30_Mem[i].DUVAVE=RtuDataAddr->DD_Device_BiaoShi_Value[i].VB;
			else
				RtuDataAddr->F27_28_29_30_Mem[i].DUVAVE=(RtuDataAddr->F27_28_29_30_Mem[i].DUVAVE+RtuDataAddr->DD_Device_BiaoShi_Value[i].VB)/2;

			if(RtuDataAddr->F27_28_29_30_Mem[i].DUWAVE==0)
				RtuDataAddr->F27_28_29_30_Mem[i].DUWAVE=RtuDataAddr->DD_Device_BiaoShi_Value[i].VC;
			else
				RtuDataAddr->F27_28_29_30_Mem[i].DUWAVE=(RtuDataAddr->F27_28_29_30_Mem[i].DUWAVE+RtuDataAddr->DD_Device_BiaoShi_Value[i].VC)/2;

			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA<RtuDataAddr->F27_28_29_30_Mem[i].DUUMIN)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].DUUMIN=RtuDataAddr->DD_Device_BiaoShi_Value[i].VA;
				TimeGetType18(RtuDataAddr->F27_28_29_30_Mem[i].DUUMIN_TIME,ts);
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB<RtuDataAddr->F27_28_29_30_Mem[i].DUVMIN)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].DUVMIN=RtuDataAddr->DD_Device_BiaoShi_Value[i].VB;
				TimeGetType18(RtuDataAddr->F27_28_29_30_Mem[i].DUVMIN_TIME,ts);
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC<RtuDataAddr->F27_28_29_30_Mem[i].DUWMIN)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].DUWMIN=RtuDataAddr->DD_Device_BiaoShi_Value[i].VC;
				TimeGetType18(RtuDataAddr->F27_28_29_30_Mem[i].DUWMIN_TIME,ts);
			}
//��ƽ����ѹ
			if(RtuDataAddr->YF27_28_29_30_Mem[i].DUUAVE==0)
				RtuDataAddr->YF27_28_29_30_Mem[i].DUUAVE=RtuDataAddr->DD_Device_BiaoShi_Value[i].VA;
			else
				RtuDataAddr->YF27_28_29_30_Mem[i].DUUAVE=(RtuDataAddr->YF27_28_29_30_Mem[i].DUUAVE+RtuDataAddr->DD_Device_BiaoShi_Value[i].VA)/2;

			if(RtuDataAddr->YF27_28_29_30_Mem[i].DUVAVE==0)
				RtuDataAddr->YF27_28_29_30_Mem[i].DUVAVE=RtuDataAddr->DD_Device_BiaoShi_Value[i].VB;
			else
				RtuDataAddr->YF27_28_29_30_Mem[i].DUVAVE=(RtuDataAddr->YF27_28_29_30_Mem[i].DUVAVE+RtuDataAddr->DD_Device_BiaoShi_Value[i].VB)/2;

			if(RtuDataAddr->YF27_28_29_30_Mem[i].DUWAVE==0)
				RtuDataAddr->YF27_28_29_30_Mem[i].DUWAVE=RtuDataAddr->DD_Device_BiaoShi_Value[i].VC;
			else
				RtuDataAddr->YF27_28_29_30_Mem[i].DUWAVE=(RtuDataAddr->YF27_28_29_30_Mem[i].DUWAVE+RtuDataAddr->DD_Device_BiaoShi_Value[i].VC)/2;

			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA<RtuDataAddr->YF27_28_29_30_Mem[i].DUUMIN)
			{
				RtuDataAddr->YF27_28_29_30_Mem[i].DUUMIN=RtuDataAddr->DD_Device_BiaoShi_Value[i].VA;
				TimeGetType18(RtuDataAddr->YF27_28_29_30_Mem[i].DUUMIN_TIME,ts);
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB<RtuDataAddr->YF27_28_29_30_Mem[i].DUVMIN)
			{
				RtuDataAddr->YF27_28_29_30_Mem[i].DUVMIN=RtuDataAddr->DD_Device_BiaoShi_Value[i].VB;
				TimeGetType18(RtuDataAddr->YF27_28_29_30_Mem[i].DUVMIN_TIME,ts);
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC<RtuDataAddr->YF27_28_29_30_Mem[i].DUWMIN)
			{
				RtuDataAddr->YF27_28_29_30_Mem[i].DUWMIN=RtuDataAddr->DD_Device_BiaoShi_Value[i].VC;
				TimeGetType18(RtuDataAddr->YF27_28_29_30_Mem[i].DUWMIN_TIME,ts);
			}
//�յ���
			if(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IA)>abs(RtuDataAddr->F27_28_29_30_Mem[i].DI_U_MAX))
			{
				RtuDataAddr->F27_28_29_30_Mem[i].DI_U_MAX=RtuDataAddr->DD_Device_BiaoShi_Value[i].IA;
				TimeGetType18(RtuDataAddr->F27_28_29_30_Mem[i].DIUMAX_TIME,ts);
			}
			if(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IB)>abs(RtuDataAddr->F27_28_29_30_Mem[i].DI_V_MAX))
			{
				RtuDataAddr->F27_28_29_30_Mem[i].DI_V_MAX=RtuDataAddr->DD_Device_BiaoShi_Value[i].IB;
				TimeGetType18(RtuDataAddr->F27_28_29_30_Mem[i].DIVMAX_TIME,ts);
			}
			if(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IC)>abs(RtuDataAddr->F27_28_29_30_Mem[i].DI_W_MAX))
			{
				RtuDataAddr->F27_28_29_30_Mem[i].DI_W_MAX=RtuDataAddr->DD_Device_BiaoShi_Value[i].IC;
				TimeGetType18(RtuDataAddr->F27_28_29_30_Mem[i].DIWMAX_TIME,ts);
			}
//�µ���
			if(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IA)>abs(RtuDataAddr->YF27_28_29_30_Mem[i].DI_U_MAX))
			{
				RtuDataAddr->YF27_28_29_30_Mem[i].DI_U_MAX=RtuDataAddr->DD_Device_BiaoShi_Value[i].IA;
				TimeGetType18(RtuDataAddr->YF27_28_29_30_Mem[i].DIUMAX_TIME,ts);
			}
			if(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IB)>abs(RtuDataAddr->YF27_28_29_30_Mem[i].DI_V_MAX))
			{
				RtuDataAddr->YF27_28_29_30_Mem[i].DI_V_MAX=RtuDataAddr->DD_Device_BiaoShi_Value[i].IB;
				TimeGetType18(RtuDataAddr->YF27_28_29_30_Mem[i].DIVMAX_TIME,ts);
			}
			if(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IC)>abs(RtuDataAddr->YF27_28_29_30_Mem[i].DI_W_MAX))
			{
				RtuDataAddr->YF27_28_29_30_Mem[i].DI_W_MAX=RtuDataAddr->DD_Device_BiaoShi_Value[i].IC;
				TimeGetType18(RtuDataAddr->YF27_28_29_30_Mem[i].DIWMAX_TIME,ts);
			}
//�ա���Խ�ޡ���ƽ����ۼ�ʱ��
			//CAPrint("\n\rUSS==%d  celiangNo=%d  VA=%d  VB=%d  VC=%d",USS,i,RtuDataAddr->DD_Device_BiaoShi_Value[i].VA,RtuDataAddr->DD_Device_BiaoShi_Value[i].VB,RtuDataAddr->DD_Device_BiaoShi_Value[i].VC);
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA>USS)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].USSU_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].USSU_Count++;
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA>US)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].USU_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].USU_Count++;
				//CAPrint("\n\rA---RtuDataAddr->YF27_28_29_30_Mem[%d].USU_Count==%d",i,RtuDataAddr->YF27_28_29_30_Mem[i].USU_Count);
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA<UXX)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].UXXU_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].UXXU_Count++;
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA<UX)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].UXU_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].UXU_Count++;
			}
			if((RtuDataAddr->DD_Device_BiaoShi_Value[i].VA>UX)&&(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA<US))
			{
				RtuDataAddr->F27_28_29_30_Mem[i].UHGU_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].UHGU_Count++;
			}

			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB>USS)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].USSV_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].USSV_Count++;
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB>US)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].USV_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].USV_Count++;
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB<UXX)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].UXXV_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].UXXV_Count++;
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB<UX)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].UXV_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].UXV_Count++;
			}
			if((RtuDataAddr->DD_Device_BiaoShi_Value[i].VB>UX)&&(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB<US))
			{
				RtuDataAddr->F27_28_29_30_Mem[i].UHGV_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].UHGV_Count++;
			}

			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC>USS)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].USSW_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].USSW_Count++;
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC>US)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].USW_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].USW_Count++;
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC<UXX)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].UXXW_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].UXXW_Count++;
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC<UX)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].UXW_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].UXW_Count++;
			}
			if((RtuDataAddr->DD_Device_BiaoShi_Value[i].VC>UX)&&(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC<US))
			{
				RtuDataAddr->F27_28_29_30_Mem[i].UHGW_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].UHGW_Count++;
			}
			//CAPrint("\n\rabs(ISS)==%d  celiangNo=%d  IA=%d  IB=%d  IC=%d",abs(ISS),i,RtuDataAddr->DD_Device_BiaoShi_Value[i].IA,RtuDataAddr->DD_Device_BiaoShi_Value[i].IB,RtuDataAddr->DD_Device_BiaoShi_Value[i].IC);
			if(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IA)*100>abs(ISS))
			{
				RtuDataAddr->F27_28_29_30_Mem[i].ISSU_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].ISSU_Count++;
			}
			if(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IA)*100>abs(IS))
			{
				RtuDataAddr->F27_28_29_30_Mem[i].ISU_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].ISU_Count++;
				//CAPrint("\n\rA---RtuDataAddr->YF27_28_29_30_Mem[%d].ISU_Count==%d",i,RtuDataAddr->YF27_28_29_30_Mem[i].ISU_Count);
			}
			if(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IB)*100>abs(ISS))
			{
				RtuDataAddr->F27_28_29_30_Mem[i].ISSV_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].ISSV_Count++;
			}
			if(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IB)*100>abs(IS))
			{
				RtuDataAddr->F27_28_29_30_Mem[i].ISV_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].ISV_Count++;
				//CAPrint("\n\rB---RtuDataAddr->YF27_28_29_30_Mem[%d].ISV_Count==%d",i,RtuDataAddr->YF27_28_29_30_Mem[i].ISV_Count);
			}
			if(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IC)*100>abs(ISS))
			{
				RtuDataAddr->F27_28_29_30_Mem[i].ISSW_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].ISSW_Count++;
			}
			if(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IC)*100>abs(IS))
			{
				RtuDataAddr->F27_28_29_30_Mem[i].ISW_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].ISW_Count++;
				//CAPrint("\n\rC---RtuDataAddr->YF27_28_29_30_Mem[%d].ISW_Count==%d",i,RtuDataAddr->YF27_28_29_30_Mem[i].ISW_Count);
			}
			SSS=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[2]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[2]&0x0f);
			SSS=(SSS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[1]&0x0f);
			SSS=(SSS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[0]&0x0f);
			SSS=SSS;
			SS=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[2]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[2]&0x0f);
			SS=(SS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[1]&0x0f);
			SS=(SS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[0]&0x0f);
			SS=SS;
			PS1=sqrt((RtuDataAddr->DD_Device_BiaoShi_Value[i].P/10)*(RtuDataAddr->DD_Device_BiaoShi_Value[i].P/10)
			 + (RtuDataAddr->DD_Device_BiaoShi_Value[i].Q/10)*(RtuDataAddr->DD_Device_BiaoShi_Value[i].Q/10));
			 PS=(INT32U)PS1;
			 PS=PS*10;
			DataCalcDbg("\r\n%s%d,S=%d SSS=%d SS=%d","������",i+1,PS,SSS,SS);

			if(PS>SSS)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].S_SS_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].S_SS_Count++;
			}
			else
			if(PS>SS)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].S_S_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].S_S_Count++;
			}
			UVWXZ=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.U3_Unbalance_Value[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.U3_Unbalance_Value[1]&0x0f);
			UVWXZ=(UVWXZ*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.U3_Unbalance_Value[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.U3_Unbalance_Value[0]&0x0f);

			ABCXZ=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I3_Unbalance_Value[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I3_Unbalance_Value[1]&0x0f);
			ABCXZ=(ABCXZ*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I3_Unbalance_Value[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I3_Unbalance_Value[0]&0x0f);

			VCalc=(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA+RtuDataAddr->DD_Device_BiaoShi_Value[i].VB+RtuDataAddr->DD_Device_BiaoShi_Value[i].VC)/3;
			ICalc=(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IA)+abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IB)+abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IC))/3;
			VMax=MaxValue(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA,RtuDataAddr->DD_Device_BiaoShi_Value[i].VB,RtuDataAddr->DD_Device_BiaoShi_Value[i].VC);
			IMax=MaxValue(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IA),abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IB),abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IC));
			VMin = MinValue(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA,RtuDataAddr->DD_Device_BiaoShi_Value[i].VB,RtuDataAddr->DD_Device_BiaoShi_Value[i].VC);
			IMin = MinValue(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IA),abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IB),abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IC));
			DataCalcDbg("\r\n%s%d,UVWXZ=%d ABCXZ=%d VMin=%d,IMin=%d","������",i+1,UVWXZ,ABCXZ,VMin,IMin);
			VValue=0;
			if(VMax!=0)
			{
				VValue = ((VMax - VMin)*1000)/VMax;//��ѹ��ƽ��ȼ���
				if(VValue>UVWXZ)
				{
					RtuDataAddr->F27_28_29_30_Mem[i].V_UNBALANCE_Count++;
					RtuDataAddr->YF27_28_29_30_Mem[i].V_UNBALANCE_Count++;
				}
			}
			IValue=0;
			if(IMax!=0)
			{
				IValue = ((IMax - IMin)*1000)/IMax;//������ƽ��ȼ���
				if(IValue>abs(ABCXZ))
				{
					RtuDataAddr->F27_28_29_30_Mem[i].I_UNBALANCE_Count++;
					RtuDataAddr->YF27_28_29_30_Mem[i].I_UNBALANCE_Count++;
				}
			}
		}
	}
}*/
void F27_28_29_30Calc()
{
	INT16U US,UX,UD,USS,UXX,UVWXZ,VCalc,VValue,VMax,VMin;
	INT16S ISS,IS,IValue,IMax,ICalc,ABCXZ,IMin;
	INT32U SSS,SS,PS;
	float PS1;
	TS ts;
	INT8U i;
	TSGet(&ts);
	for(i=0;i<CeLiangPoint_Max;i++)
	{
		if(RtuDataAddr->DD_Device_BiaoShi_Value[i].Valid!=1)continue;
		if(RtuDataAddr->DD_Device_BiaoShi_Value[i].Cos<RtuDataAddr->Cl_MenXian_Value[i].F28_Set_Para.CosFenDuan_Xian1)//�¼� ���㹦�������ۼ�ʱ��
		{
			RtuDataAddr->YF27_28_29_30_Mem[i].QuDuan1_Count++;
			//CAPrint("\n\rRtuDataAddr->YF27_28_29_30_Mem[%d].QuDuan1_Count===%d",i,RtuDataAddr->YF27_28_29_30_Mem[i].QuDuan1_Count);
		}
		if((RtuDataAddr->DD_Device_BiaoShi_Value[i].Cos>=RtuDataAddr->Cl_MenXian_Value[i].F28_Set_Para.CosFenDuan_Xian1)
				&&(RtuDataAddr->DD_Device_BiaoShi_Value[i].Cos<RtuDataAddr->Cl_MenXian_Value[i].F28_Set_Para.CosFenDuan_Xian2))//�¼� ���㹦�������ۼ�ʱ��
		{
			RtuDataAddr->YF27_28_29_30_Mem[i].QuDuan2_Count++;
			//CAPrint("\n\rRtuDataAddr->YF27_28_29_30_Mem[%d].QuDuan2_Count===%d",i,RtuDataAddr->YF27_28_29_30_Mem[i].QuDuan2_Count);
		}
		if(RtuDataAddr->DD_Device_BiaoShi_Value[i].Cos>=RtuDataAddr->Cl_MenXian_Value[i].F28_Set_Para.CosFenDuan_Xian2)//�¼� ���㹦�������ۼ�ʱ��
		{
			RtuDataAddr->YF27_28_29_30_Mem[i].QuDuan3_Count++;
			//CAPrint("\n\rRtuDataAddr->YF27_28_29_30_Mem[%d].QuDuan3_Count===%d",i,RtuDataAddr->YF27_28_29_30_Mem[i].QuDuan3_Count);
		}

		if(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.Valid==1)
		{
			US=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_S[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_S[1]&0x0f);
			US=(US*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_S[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_S[0]&0x0f);

			UX=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_X[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_X[1]&0x0f);
			UX=(UX*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_X[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_X[0]&0x0f);

			UD=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_Duan_Men[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_Duan_Men[1]&0x0f);
			UD=(UD*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_Duan_Men[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_Duan_Men[0]&0x0f);

			USS=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_SS[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_SS[1]&0x0f);
			USS=(USS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_SS[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_SS[0]&0x0f);

			UXX=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_XX[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_XX[1]&0x0f);
			UXX=(UXX*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_XX[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_XX[0]&0x0f);

			ISS=(((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_SS[2]>>4)&0x07)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_SS[2]&0x0f);
			ISS=(ISS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_SS[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_SS[1]&0x0f);
			ISS=(ISS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_SS[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_SS[0]&0x0f);

			IS=(((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_S[2]>>4)&0x07)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_S[2]&0x0f);
			IS=(IS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_S[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_S[1]&0x0f);
			IS=(IS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_S[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_S[0]&0x0f);
//�յ�ѹ
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA>RtuDataAddr->F27_28_29_30_Mem[i].DUUMAX)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].DUUMAX=RtuDataAddr->DD_Device_BiaoShi_Value[i].VA;
				TimeGetType18(RtuDataAddr->F27_28_29_30_Mem[i].DUUMAX_TIME,ts);
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB>RtuDataAddr->F27_28_29_30_Mem[i].DUVMAX)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].DUVMAX=RtuDataAddr->DD_Device_BiaoShi_Value[i].VB;
				TimeGetType18(RtuDataAddr->F27_28_29_30_Mem[i].DUVMAX_TIME,ts);
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC>RtuDataAddr->F27_28_29_30_Mem[i].DUWMAX)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].DUWMAX=RtuDataAddr->DD_Device_BiaoShi_Value[i].VC;
				TimeGetType18(RtuDataAddr->F27_28_29_30_Mem[i].DUWMAX_TIME,ts);
			}

//�µ�ѹ
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA>RtuDataAddr->YF27_28_29_30_Mem[i].DUUMAX)
			{
				RtuDataAddr->YF27_28_29_30_Mem[i].DUUMAX=RtuDataAddr->DD_Device_BiaoShi_Value[i].VA;
				TimeGetType18(RtuDataAddr->YF27_28_29_30_Mem[i].DUUMAX_TIME,ts);
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB>RtuDataAddr->YF27_28_29_30_Mem[i].DUVMAX)
			{
				RtuDataAddr->YF27_28_29_30_Mem[i].DUVMAX=RtuDataAddr->DD_Device_BiaoShi_Value[i].VB;
				TimeGetType18(RtuDataAddr->YF27_28_29_30_Mem[i].DUVMAX_TIME,ts);
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC>RtuDataAddr->YF27_28_29_30_Mem[i].DUWMAX)
			{
				RtuDataAddr->YF27_28_29_30_Mem[i].DUWMAX=RtuDataAddr->DD_Device_BiaoShi_Value[i].VC;
				TimeGetType18(RtuDataAddr->YF27_28_29_30_Mem[i].DUWMAX_TIME,ts);
			}
//��ƽ����ѹ
			if(RtuDataAddr->F27_28_29_30_Mem[i].DUUAVE==0)
				RtuDataAddr->F27_28_29_30_Mem[i].DUUAVE=RtuDataAddr->DD_Device_BiaoShi_Value[i].VA;
			else
				RtuDataAddr->F27_28_29_30_Mem[i].DUUAVE=(RtuDataAddr->F27_28_29_30_Mem[i].DUUAVE+RtuDataAddr->DD_Device_BiaoShi_Value[i].VA)/2;

			if(RtuDataAddr->F27_28_29_30_Mem[i].DUVAVE==0)
				RtuDataAddr->F27_28_29_30_Mem[i].DUVAVE=RtuDataAddr->DD_Device_BiaoShi_Value[i].VB;
			else
				RtuDataAddr->F27_28_29_30_Mem[i].DUVAVE=(RtuDataAddr->F27_28_29_30_Mem[i].DUVAVE+RtuDataAddr->DD_Device_BiaoShi_Value[i].VB)/2;

			if(RtuDataAddr->F27_28_29_30_Mem[i].DUWAVE==0)
				RtuDataAddr->F27_28_29_30_Mem[i].DUWAVE=RtuDataAddr->DD_Device_BiaoShi_Value[i].VC;
			else
				RtuDataAddr->F27_28_29_30_Mem[i].DUWAVE=(RtuDataAddr->F27_28_29_30_Mem[i].DUWAVE+RtuDataAddr->DD_Device_BiaoShi_Value[i].VC)/2;
//����С��ѹ
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA<RtuDataAddr->F27_28_29_30_Mem[i].DUUMIN)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].DUUMIN=RtuDataAddr->DD_Device_BiaoShi_Value[i].VA;
				TimeGetType18(RtuDataAddr->F27_28_29_30_Mem[i].DUUMIN_TIME,ts);
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB<RtuDataAddr->F27_28_29_30_Mem[i].DUVMIN)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].DUVMIN=RtuDataAddr->DD_Device_BiaoShi_Value[i].VB;
				TimeGetType18(RtuDataAddr->F27_28_29_30_Mem[i].DUVMIN_TIME,ts);
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC<RtuDataAddr->F27_28_29_30_Mem[i].DUWMIN)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].DUWMIN=RtuDataAddr->DD_Device_BiaoShi_Value[i].VC;
				TimeGetType18(RtuDataAddr->F27_28_29_30_Mem[i].DUWMIN_TIME,ts);
			}
//��ƽ����ѹ
			if(RtuDataAddr->YF27_28_29_30_Mem[i].DUUAVE==0)
				RtuDataAddr->YF27_28_29_30_Mem[i].DUUAVE=RtuDataAddr->DD_Device_BiaoShi_Value[i].VA;
			else
				RtuDataAddr->YF27_28_29_30_Mem[i].DUUAVE=(RtuDataAddr->YF27_28_29_30_Mem[i].DUUAVE+RtuDataAddr->DD_Device_BiaoShi_Value[i].VA)/2;

			if(RtuDataAddr->YF27_28_29_30_Mem[i].DUVAVE==0)
				RtuDataAddr->YF27_28_29_30_Mem[i].DUVAVE=RtuDataAddr->DD_Device_BiaoShi_Value[i].VB;
			else
				RtuDataAddr->YF27_28_29_30_Mem[i].DUVAVE=(RtuDataAddr->YF27_28_29_30_Mem[i].DUVAVE+RtuDataAddr->DD_Device_BiaoShi_Value[i].VB)/2;

			if(RtuDataAddr->YF27_28_29_30_Mem[i].DUWAVE==0)
				RtuDataAddr->YF27_28_29_30_Mem[i].DUWAVE=RtuDataAddr->DD_Device_BiaoShi_Value[i].VC;
			else
				RtuDataAddr->YF27_28_29_30_Mem[i].DUWAVE=(RtuDataAddr->YF27_28_29_30_Mem[i].DUWAVE+RtuDataAddr->DD_Device_BiaoShi_Value[i].VC)/2;
//����С��ѹ
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA<RtuDataAddr->YF27_28_29_30_Mem[i].DUUMIN)
			{
				RtuDataAddr->YF27_28_29_30_Mem[i].DUUMIN=RtuDataAddr->DD_Device_BiaoShi_Value[i].VA;
				TimeGetType18(RtuDataAddr->YF27_28_29_30_Mem[i].DUUMIN_TIME,ts);
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB<RtuDataAddr->YF27_28_29_30_Mem[i].DUVMIN)
			{
				RtuDataAddr->YF27_28_29_30_Mem[i].DUVMIN=RtuDataAddr->DD_Device_BiaoShi_Value[i].VB;
				TimeGetType18(RtuDataAddr->YF27_28_29_30_Mem[i].DUVMIN_TIME,ts);
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC<RtuDataAddr->YF27_28_29_30_Mem[i].DUWMIN)
			{
				RtuDataAddr->YF27_28_29_30_Mem[i].DUWMIN=RtuDataAddr->DD_Device_BiaoShi_Value[i].VC;
				TimeGetType18(RtuDataAddr->YF27_28_29_30_Mem[i].DUWMIN_TIME,ts);
			}
//�յ���
			if(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IA)>abs(RtuDataAddr->F27_28_29_30_Mem[i].DI_U_MAX))
			{
				RtuDataAddr->F27_28_29_30_Mem[i].DI_U_MAX=RtuDataAddr->DD_Device_BiaoShi_Value[i].IA;
				TimeGetType18(RtuDataAddr->F27_28_29_30_Mem[i].DIUMAX_TIME,ts);
			}
			if(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IB)>abs(RtuDataAddr->F27_28_29_30_Mem[i].DI_V_MAX))
			{
				RtuDataAddr->F27_28_29_30_Mem[i].DI_V_MAX=RtuDataAddr->DD_Device_BiaoShi_Value[i].IB;
				TimeGetType18(RtuDataAddr->F27_28_29_30_Mem[i].DIVMAX_TIME,ts);
			}
			if(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IC)>abs(RtuDataAddr->F27_28_29_30_Mem[i].DI_W_MAX))
			{
				RtuDataAddr->F27_28_29_30_Mem[i].DI_W_MAX=RtuDataAddr->DD_Device_BiaoShi_Value[i].IC;
				TimeGetType18(RtuDataAddr->F27_28_29_30_Mem[i].DIWMAX_TIME,ts);
			}
//�µ���
			if(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IA)>abs(RtuDataAddr->YF27_28_29_30_Mem[i].DI_U_MAX))
			{
				RtuDataAddr->YF27_28_29_30_Mem[i].DI_U_MAX=RtuDataAddr->DD_Device_BiaoShi_Value[i].IA;
				TimeGetType18(RtuDataAddr->YF27_28_29_30_Mem[i].DIUMAX_TIME,ts);
			}
			if(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IB)>abs(RtuDataAddr->YF27_28_29_30_Mem[i].DI_V_MAX))
			{
				RtuDataAddr->YF27_28_29_30_Mem[i].DI_V_MAX=RtuDataAddr->DD_Device_BiaoShi_Value[i].IB;
				TimeGetType18(RtuDataAddr->YF27_28_29_30_Mem[i].DIVMAX_TIME,ts);
			}
			if(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IC)>abs(RtuDataAddr->YF27_28_29_30_Mem[i].DI_W_MAX))
			{
				RtuDataAddr->YF27_28_29_30_Mem[i].DI_W_MAX=RtuDataAddr->DD_Device_BiaoShi_Value[i].IC;
				TimeGetType18(RtuDataAddr->YF27_28_29_30_Mem[i].DIWMAX_TIME,ts);
			}
//��ѹ�ϸ���
//�ա���Խ�ޡ���ƽ����ۼ�ʱ��
			//CAPrint("\n\rUSS==%d  celiangNo=%d  VA=%d  VB=%d  VC=%d",USS,i,RtuDataAddr->DD_Device_BiaoShi_Value[i].VA,RtuDataAddr->DD_Device_BiaoShi_Value[i].VB,RtuDataAddr->DD_Device_BiaoShi_Value[i].VC);
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA>USS)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].USSU_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].USSU_Count++;
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA>US)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].USU_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].USU_Count++;
				//CAPrint("\n\rA---RtuDataAddr->YF27_28_29_30_Mem[%d].USU_Count==%d",i,RtuDataAddr->YF27_28_29_30_Mem[i].USU_Count);
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA<UXX)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].UXXU_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].UXXU_Count++;
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA<UX)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].UXU_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].UXU_Count++;
			}
			if((RtuDataAddr->DD_Device_BiaoShi_Value[i].VA>UX)&&(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA<US))
			{
				RtuDataAddr->F27_28_29_30_Mem[i].UHGU_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].UHGU_Count++;
			}

			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB>USS)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].USSV_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].USSV_Count++;
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB>US)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].USV_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].USV_Count++;
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB<UXX)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].UXXV_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].UXXV_Count++;
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB<UX)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].UXV_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].UXV_Count++;
			}
			if((RtuDataAddr->DD_Device_BiaoShi_Value[i].VB>UX)&&(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB<US))
			{
				RtuDataAddr->F27_28_29_30_Mem[i].UHGV_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].UHGV_Count++;
			}

			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC>USS)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].USSW_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].USSW_Count++;
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC>US)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].USW_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].USW_Count++;
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC<UXX)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].UXXW_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].UXXW_Count++;
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC<UX)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].UXW_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].UXW_Count++;
			}
			if((RtuDataAddr->DD_Device_BiaoShi_Value[i].VC>UX)&&(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC<US))
			{
				RtuDataAddr->F27_28_29_30_Mem[i].UHGW_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].UHGW_Count++;
			}
			//CAPrint("\n\rabs(ISS)==%d  celiangNo=%d  IA=%d  IB=%d  IC=%d",abs(ISS),i,RtuDataAddr->DD_Device_BiaoShi_Value[i].IA,RtuDataAddr->DD_Device_BiaoShi_Value[i].IB,RtuDataAddr->DD_Device_BiaoShi_Value[i].IC);
			if(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IA)*100>abs(ISS))
			{
				RtuDataAddr->F27_28_29_30_Mem[i].ISSU_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].ISSU_Count++;
			}
			if(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IA)*100>abs(IS))
			{
				RtuDataAddr->F27_28_29_30_Mem[i].ISU_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].ISU_Count++;
				//CAPrint("\n\rA---RtuDataAddr->YF27_28_29_30_Mem[%d].ISU_Count==%d",i,RtuDataAddr->YF27_28_29_30_Mem[i].ISU_Count);
			}
			if(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IB)*100>abs(ISS))
			{
				RtuDataAddr->F27_28_29_30_Mem[i].ISSV_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].ISSV_Count++;
			}
			if(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IB)*100>abs(IS))
			{
				RtuDataAddr->F27_28_29_30_Mem[i].ISV_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].ISV_Count++;
				//CAPrint("\n\rB---RtuDataAddr->YF27_28_29_30_Mem[%d].ISV_Count==%d",i,RtuDataAddr->YF27_28_29_30_Mem[i].ISV_Count);
			}
			if(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IC)*100>abs(ISS))
			{
				RtuDataAddr->F27_28_29_30_Mem[i].ISSW_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].ISSW_Count++;
			}
			if(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IC)*100>abs(IS))
			{
				RtuDataAddr->F27_28_29_30_Mem[i].ISW_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].ISW_Count++;
				//CAPrint("\n\rC---RtuDataAddr->YF27_28_29_30_Mem[%d].ISW_Count==%d",i,RtuDataAddr->YF27_28_29_30_Mem[i].ISW_Count);
			}
			SSS=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[2]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[2]&0x0f);
			SSS=(SSS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[1]&0x0f);
			SSS=(SSS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[0]&0x0f);
			SSS=SSS;
			SS=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[2]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[2]&0x0f);
			SS=(SS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[1]&0x0f);
			SS=(SS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[0]&0x0f);
			SS=SS;
			PS1=sqrt((RtuDataAddr->DD_Device_BiaoShi_Value[i].P/10)*(RtuDataAddr->DD_Device_BiaoShi_Value[i].P/10)
			 + (RtuDataAddr->DD_Device_BiaoShi_Value[i].Q/10)*(RtuDataAddr->DD_Device_BiaoShi_Value[i].Q/10));
			 PS=(INT32U)PS1;
			 PS=PS*10;
			DataCalcDbg("\r\n%s%d,S=%d SSS=%d SS=%d","������",i+1,PS,SSS,SS);

			if(PS>SSS)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].S_SS_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].S_SS_Count++;
			}
			else
			if(PS>SS)
			{
				RtuDataAddr->F27_28_29_30_Mem[i].S_S_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].S_S_Count++;
			}
			UVWXZ=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.U3_Unbalance_Value[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.U3_Unbalance_Value[1]&0x0f);
			UVWXZ=(UVWXZ*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.U3_Unbalance_Value[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.U3_Unbalance_Value[0]&0x0f);

			ABCXZ=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I3_Unbalance_Value[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I3_Unbalance_Value[1]&0x0f);
			ABCXZ=(ABCXZ*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I3_Unbalance_Value[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I3_Unbalance_Value[0]&0x0f);

			VCalc=(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA+RtuDataAddr->DD_Device_BiaoShi_Value[i].VB+RtuDataAddr->DD_Device_BiaoShi_Value[i].VC)/3;
			ICalc=(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IA)+abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IB)+abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IC))/3;
			VMax=MaxValue(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA,RtuDataAddr->DD_Device_BiaoShi_Value[i].VB,RtuDataAddr->DD_Device_BiaoShi_Value[i].VC);
			IMax=MaxValue(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IA),abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IB),abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IC));
			VMin = MinValue(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA,RtuDataAddr->DD_Device_BiaoShi_Value[i].VB,RtuDataAddr->DD_Device_BiaoShi_Value[i].VC);
			IMin = MinValue(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IA),abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IB),abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IC));
			DataCalcDbg("\r\n%s%d,UVWXZ=%d ABCXZ=%d VMin=%d,IMin=%d","������",i+1,UVWXZ,ABCXZ,VMin,IMin);
			VValue=0;
			if(VMax!=0)
			{
				VValue = ((VMax - VMin)*1000)/VMax;//��ѹ��ƽ��ȼ���
				if(VValue>UVWXZ)
				{
					RtuDataAddr->F27_28_29_30_Mem[i].V_UNBALANCE_Count++;
					RtuDataAddr->YF27_28_29_30_Mem[i].V_UNBALANCE_Count++;
				}
			}
			IValue=0;
			if(IMax!=0)
			{
				IValue = ((IMax - IMin)*1000)/IMax;//������ƽ��ȼ���
				if(IValue>abs(ABCXZ))
				{
					RtuDataAddr->F27_28_29_30_Mem[i].I_UNBALANCE_Count++;
					RtuDataAddr->YF27_28_29_30_Mem[i].I_UNBALANCE_Count++;
				}
			}
		}
	}
}

void F27_28_35_36Calc()
{
	INT16U US,UX,UD,USS,UXX,UVWXZ,VCalc,VValue,VMax;
	INT16S ISS,IS,IValue,IMax,ICalc,ABCXZ;
	INT32U SSS,SS,PS;
	float PS1;
	TS ts;
	INT8U i;
	INT8U a_ussx_flag;
	INT8U a_uxxx_flag;
	INT8U b_ussx_flag;
	INT8U b_uxxx_flag;
	INT8U c_ussx_flag;
	INT8U c_uxxx_flag;
	TSGet(&ts);
	unsigned int runtime;
	for(i=0;i<CeLiangPoint_Max;i++)
	{
		if(RtuDataAddr->DD_Device_BiaoShi_Value[i].Valid!=1)continue;//������1(i=0)��Ϊ����������ѹ�ϸ���,valid����Զ��=1�� ��Ӱ��ϸ��������ɼ�
		if(RtuDataAddr->DD_Device_BiaoShi_Value[i].Cos<RtuDataAddr->Cl_MenXian_Value[i].F28_Set_Para.CosFenDuan_Xian1)//�¼� ���㹦�������ۼ�ʱ��
		{
			RtuDataAddr->YF27_28_29_30_Mem[i].QuDuan1_Count++;
		}
		if((RtuDataAddr->DD_Device_BiaoShi_Value[i].Cos>=RtuDataAddr->Cl_MenXian_Value[i].F28_Set_Para.CosFenDuan_Xian1)
				&&(RtuDataAddr->DD_Device_BiaoShi_Value[i].Cos<RtuDataAddr->Cl_MenXian_Value[i].F28_Set_Para.CosFenDuan_Xian2))//�¼� ���㹦�������ۼ�ʱ��
		{
			RtuDataAddr->YF27_28_29_30_Mem[i].QuDuan2_Count++;
		}
		if(RtuDataAddr->DD_Device_BiaoShi_Value[i].Cos>=RtuDataAddr->Cl_MenXian_Value[i].F28_Set_Para.CosFenDuan_Xian2)//�¼� ���㹦�������ۼ�ʱ��
		{
			RtuDataAddr->YF27_28_29_30_Mem[i].QuDuan3_Count++;
		}
		DataCalcDbg("\n\rHEGE TongJi RtuDataAddr->Cl_MenXian_Value[%d].F26_Set_Para.Valid=%d\n\r",i,RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.Valid);
		if(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.Valid==1)
		{
			US=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_S[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_S[1]&0x0f);
			US=(US*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_S[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_S[0]&0x0f);

			UX=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_X[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_X[1]&0x0f);
			UX=(UX*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_X[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_X[0]&0x0f);

			UD=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_Duan_Men[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_Duan_Men[1]&0x0f);
			UD=(UD*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_Duan_Men[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_Duan_Men[0]&0x0f);

			USS=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_SS[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_SS[1]&0x0f);
			USS=(USS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_SS[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_SS[0]&0x0f);

			UXX=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_XX[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_XX[1]&0x0f);
			UXX=(UXX*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_XX[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_XX[0]&0x0f);

			ISS=(((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_SS[2]>>4)&0x07)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_SS[2]&0x0f);
			ISS=(ISS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_SS[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_SS[1]&0x0f);
			ISS=(ISS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_SS[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_SS[0]&0x0f);

			IS=(((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_S[2]>>4)&0x07)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_S[2]&0x0f);
			IS=(IS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_S[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_S[1]&0x0f);
			IS=(IS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_S[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_S[0]&0x0f);
			//-------------------------------------------------------------�յ�ѹ���ֵ������ʱ��---------------
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA>RtuDataAddr->F27_28_29_30_Mem[i].DUUMAX)//UA���ֵ�жϣ���¼����ʱ�� //FkDdRealData
			{
				RtuDataAddr->F27_28_29_30_Mem[i].DUUMAX=RtuDataAddr->DD_Device_BiaoShi_Value[i].VA;
				TimeGetType18(RtuDataAddr->F27_28_29_30_Mem[i].DUUMAX_TIME,ts);
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB>RtuDataAddr->F27_28_29_30_Mem[i].DUVMAX)//Ub���ֵ�жϣ���¼����ʱ�� //FkDdRealData
			{
				RtuDataAddr->F27_28_29_30_Mem[i].DUVMAX=RtuDataAddr->DD_Device_BiaoShi_Value[i].VB;
				TimeGetType18(RtuDataAddr->F27_28_29_30_Mem[i].DUVMAX_TIME,ts);
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC>RtuDataAddr->F27_28_29_30_Mem[i].DUWMAX)//Uc���ֵ�жϣ���¼����ʱ�� //FkDdRealData
			{
				RtuDataAddr->F27_28_29_30_Mem[i].DUWMAX=RtuDataAddr->DD_Device_BiaoShi_Value[i].VC;
				TimeGetType18(RtuDataAddr->F27_28_29_30_Mem[i].DUWMAX_TIME,ts);
			}
			//-------------------------------------------------------------�µ�ѹ���ֵ������ʱ��---------------
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA>RtuDataAddr->YF27_28_29_30_Mem[i].DUUMAX)//UA���ֵ //FkDdRealData
			{
				RtuDataAddr->YF27_28_29_30_Mem[i].DUUMAX=RtuDataAddr->DD_Device_BiaoShi_Value[i].VA;
				TimeGetType18(RtuDataAddr->YF27_28_29_30_Mem[i].DUUMAX_TIME,ts);
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB>RtuDataAddr->YF27_28_29_30_Mem[i].DUVMAX) //Ub���ֵ //FkDdRealData
			{
				RtuDataAddr->YF27_28_29_30_Mem[i].DUVMAX=RtuDataAddr->DD_Device_BiaoShi_Value[i].VB;
				TimeGetType18(RtuDataAddr->YF27_28_29_30_Mem[i].DUVMAX_TIME,ts);
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC>RtuDataAddr->YF27_28_29_30_Mem[i].DUWMAX) //Uc���ֵ //FkDdRealData
			{
				RtuDataAddr->YF27_28_29_30_Mem[i].DUWMAX=RtuDataAddr->DD_Device_BiaoShi_Value[i].VC;
				TimeGetType18(RtuDataAddr->YF27_28_29_30_Mem[i].DUWMAX_TIME,ts);
			}
			//-------------------------------------------------------------�յ�ѹ��Сֵ������ʱ��---------------
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA<RtuDataAddr->F27_28_29_30_Mem[i].DUUMIN)//UA��Сֵ�жϣ���¼����ʱ�� //FkDdRealData
			{
				RtuDataAddr->F27_28_29_30_Mem[i].DUUMIN=RtuDataAddr->DD_Device_BiaoShi_Value[i].VA;
				TimeGetType18(RtuDataAddr->F27_28_29_30_Mem[i].DUUMIN_TIME,ts);
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB<RtuDataAddr->F27_28_29_30_Mem[i].DUVMIN)//Ub��Сֵ //FkDdRealData
			{
				RtuDataAddr->F27_28_29_30_Mem[i].DUVMIN=RtuDataAddr->DD_Device_BiaoShi_Value[i].VB;
				TimeGetType18(RtuDataAddr->F27_28_29_30_Mem[i].DUVMIN_TIME,ts);
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC<RtuDataAddr->F27_28_29_30_Mem[i].DUWMIN)//Uc��Сֵ //FkDdRealData
			{
				RtuDataAddr->F27_28_29_30_Mem[i].DUWMIN=RtuDataAddr->DD_Device_BiaoShi_Value[i].VC;
				TimeGetType18(RtuDataAddr->F27_28_29_30_Mem[i].DUWMIN_TIME,ts);
			}
			//-------------------------------------------------------------�µ�ѹ��Сֵ������ʱ��---------------
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA<RtuDataAddr->YF27_28_29_30_Mem[i].DUUMIN)//Ua��Сֵ //FkDdRealData
			{
				RtuDataAddr->YF27_28_29_30_Mem[i].DUUMIN=RtuDataAddr->DD_Device_BiaoShi_Value[i].VA;
				TimeGetType18(RtuDataAddr->YF27_28_29_30_Mem[i].DUUMIN_TIME,ts);
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB<RtuDataAddr->YF27_28_29_30_Mem[i].DUVMIN)//Ub��Сֵ //FkDdRealData
			{
				RtuDataAddr->YF27_28_29_30_Mem[i].DUVMIN=RtuDataAddr->DD_Device_BiaoShi_Value[i].VB;
				TimeGetType18(RtuDataAddr->YF27_28_29_30_Mem[i].DUVMIN_TIME,ts);
			}
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC<RtuDataAddr->YF27_28_29_30_Mem[i].DUWMIN)//Uc��Сֵ //FkDdRealData
			{
				RtuDataAddr->YF27_28_29_30_Mem[i].DUWMIN=RtuDataAddr->DD_Device_BiaoShi_Value[i].VC;
				TimeGetType18(RtuDataAddr->YF27_28_29_30_Mem[i].DUWMIN_TIME,ts);
			}
			//------------------------------------------------------------�յ������ֵ������ʱ��----------------
			if(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IA)>abs(RtuDataAddr->F27_28_29_30_Mem[i].DI_U_MAX))//IA���ֵ�жϣ���¼����ʱ��
			{
				RtuDataAddr->F27_28_29_30_Mem[i].DI_U_MAX=RtuDataAddr->DD_Device_BiaoShi_Value[i].IA;
				TimeGetType18(RtuDataAddr->F27_28_29_30_Mem[i].DIUMAX_TIME,ts);
			}
			if(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IB)>abs(RtuDataAddr->F27_28_29_30_Mem[i].DI_V_MAX))//IB���ֵ
			{
				RtuDataAddr->F27_28_29_30_Mem[i].DI_V_MAX=RtuDataAddr->DD_Device_BiaoShi_Value[i].IB;
				TimeGetType18(RtuDataAddr->F27_28_29_30_Mem[i].DIVMAX_TIME,ts);
			}
			if(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IC)>abs(RtuDataAddr->F27_28_29_30_Mem[i].DI_W_MAX))//IC���ֵ
			{
				RtuDataAddr->F27_28_29_30_Mem[i].DI_W_MAX=RtuDataAddr->DD_Device_BiaoShi_Value[i].IC;
				TimeGetType18(RtuDataAddr->F27_28_29_30_Mem[i].DIWMAX_TIME,ts);
			}
			//--------------------------------------------------------- �µ������ֵ������ʱ��-------------------
			if(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IA)>abs(RtuDataAddr->YF27_28_29_30_Mem[i].DI_U_MAX))//IA���ֵ
			{
				RtuDataAddr->YF27_28_29_30_Mem[i].DI_U_MAX=RtuDataAddr->DD_Device_BiaoShi_Value[i].IA;
				TimeGetType18(RtuDataAddr->YF27_28_29_30_Mem[i].DIUMAX_TIME,ts);
			}
			if(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IB)>abs(RtuDataAddr->YF27_28_29_30_Mem[i].DI_V_MAX))//IB���ֵ
			{
				RtuDataAddr->YF27_28_29_30_Mem[i].DI_V_MAX=RtuDataAddr->DD_Device_BiaoShi_Value[i].IB;
				TimeGetType18(RtuDataAddr->YF27_28_29_30_Mem[i].DIVMAX_TIME,ts);
			}
			if(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IC)>abs(RtuDataAddr->YF27_28_29_30_Mem[i].DI_W_MAX))//IC���ֵ
			{
				RtuDataAddr->YF27_28_29_30_Mem[i].DI_W_MAX=RtuDataAddr->DD_Device_BiaoShi_Value[i].IC;
				TimeGetType18(RtuDataAddr->YF27_28_29_30_Mem[i].DIWMAX_TIME,ts);
			}

			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA>USS)//---------------------------------�ж�UAԽ�����޷���//FkDdRealData
				a_ussx_flag = 1;
			else
				a_ussx_flag = 0;

			if(a_ussx_flag == 1)
				a_ussx_last_time[i] +=1;
			else
				a_ussx_last_time[i] -=1;

			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA<UXX)//---------------------------------�ж�UAԽ�����޷���//FkDdRealData
				a_uxxx_flag = 1;
			else
				a_uxxx_flag = 0;

			if(a_uxxx_flag == 1)
				a_uxxx_last_time[i] +=1;
			else
				a_uxxx_last_time[i] -=1;

			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB>USS)//---------------------------------�ж�UBԽ�����޷���//FkDdRealData
				b_ussx_flag = 1;
			else
				b_ussx_flag = 0;

			if(b_ussx_flag == 1)
				b_ussx_last_time[i] +=1;
			else
				b_ussx_last_time[i] -=1;

			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB<UXX)//---------------------------------�ж�UBԽ�����޷���//FkDdRealData
				b_uxxx_flag = 1;
			else
				b_uxxx_flag = 0;

			if(b_uxxx_flag == 1)
				b_uxxx_last_time[i] +=1;
			else
				b_uxxx_last_time[i] -=1;

			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC>USS)//---------------------------------�ж�UCԽ�����޷���//FkDdRealData
				c_ussx_flag = 1;
			else
				c_ussx_flag = 0;

			if(c_ussx_flag == 1)
				c_ussx_last_time[i] +=1;
			else
				c_ussx_last_time[i] -=1;

			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC<UXX)//---------------------------------�ж�UCԽ�����޷���//FkDdRealData
				c_uxxx_flag = 1;
			else
				c_uxxx_flag = 0;

			if(c_uxxx_flag == 1)
				c_uxxx_last_time[i] +=1;
			else
				c_uxxx_last_time[i] -=1;

			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA>US)//------------�ж�UAԽ����
			{
				RtuDataAddr->F27_28_29_30_Mem[i].U_A_Sum += RtuDataAddr->DD_Device_BiaoShi_Value[i].VA;//FkDdRealData
				RtuDataAddr->F27_28_29_30_Mem[i].USU_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].USU_Count++;
				if((RtuDataAddr->DD_Device_BiaoShi_Value[i].VA>USS) &&(a_ussx_last_time[i] >= 3))
				{
					RtuDataAddr->F27_28_29_30_Mem[i].USSU_Count +=3;
					RtuDataAddr->YF27_28_29_30_Mem[i].USSU_Count +=3;
					a_ussx_last_time[i] = 0;
				}
			}
			else
			{
				if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA<UX)//--------�ж�UAԽ����
				{
					RtuDataAddr->F27_28_29_30_Mem[i].U_A_Sum += RtuDataAddr->DD_Device_BiaoShi_Value[i].VA;//FkDdRealData
					RtuDataAddr->F27_28_29_30_Mem[i].UXU_Count++;
					RtuDataAddr->YF27_28_29_30_Mem[i].UXU_Count++;
					if((RtuDataAddr->DD_Device_BiaoShi_Value[i].VA<UXX) && (a_uxxx_last_time[i] >= 3))
					{
						RtuDataAddr->F27_28_29_30_Mem[i].UXXU_Count +=3;
						RtuDataAddr->YF27_28_29_30_Mem[i].UXXU_Count +=3;
						a_uxxx_last_time[i] = 0;
					}
				}
				else							   //---------UA�ϸ��ѹ
				{
					RtuDataAddr->F27_28_29_30_Mem[i].U_A_Sum += RtuDataAddr->DD_Device_BiaoShi_Value[i].VA;//FkDdRealData
					RtuDataAddr->F27_28_29_30_Mem[i].UHGU_Count++;
					RtuDataAddr->YF27_28_29_30_Mem[i].UHGU_Count++;
				}
			}
			DataCalcDbg("RtuDataAddr->F27_28_29_30_Mem[%d].UHGU_Count=%d\r\n",i,RtuDataAddr->F27_28_29_30_Mem[i].UHGU_Count);
			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB>US)//------------�ж�UbԽ����
			{
				RtuDataAddr->F27_28_29_30_Mem[i].U_B_Sum += RtuDataAddr->DD_Device_BiaoShi_Value[i].VB;//FkDdRealData
				RtuDataAddr->F27_28_29_30_Mem[i].USV_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].USV_Count++;
				if((RtuDataAddr->DD_Device_BiaoShi_Value[i].VB>USS) && (b_ussx_last_time[i] >= 3))
				{
					RtuDataAddr->F27_28_29_30_Mem[i].USSV_Count +=3;
					RtuDataAddr->YF27_28_29_30_Mem[i].USSV_Count +=3;
					b_ussx_last_time[i] = 0;
				}
			}
			else
			{
				if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB<UX)//--------�ж�UBԽ����
				{
					RtuDataAddr->F27_28_29_30_Mem[i].U_B_Sum += RtuDataAddr->DD_Device_BiaoShi_Value[i].VB;//FkDdRealData
					RtuDataAddr->F27_28_29_30_Mem[i].UXV_Count++;
					RtuDataAddr->YF27_28_29_30_Mem[i].UXV_Count++;
					if((RtuDataAddr->DD_Device_BiaoShi_Value[i].VB<UXX) && (b_uxxx_last_time[i] >= 3))
					{
					    RtuDataAddr->F27_28_29_30_Mem[i].UXXV_Count +=3;
						RtuDataAddr->YF27_28_29_30_Mem[i].UXXV_Count +=3;
						b_uxxx_last_time[i] = 0;
					}
				}
				else							   //---------UB�ϸ��ѹ
				{
					RtuDataAddr->F27_28_29_30_Mem[i].U_B_Sum += RtuDataAddr->DD_Device_BiaoShi_Value[i].VB;//FkDdRealData
					RtuDataAddr->F27_28_29_30_Mem[i].UHGV_Count++;
					RtuDataAddr->YF27_28_29_30_Mem[i].UHGV_Count++;
				}
			}

			if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC>US)//------------�ж�UcԽ����
			{
				RtuDataAddr->F27_28_29_30_Mem[i].U_C_Sum += RtuDataAddr->DD_Device_BiaoShi_Value[i].VC;//FkDdRealData
				RtuDataAddr->F27_28_29_30_Mem[i].USW_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].USW_Count++;
				if((RtuDataAddr->DD_Device_BiaoShi_Value[i].VC>USS) && (c_ussx_last_time[i] >= 3))//FkDdRealData
				{
					RtuDataAddr->F27_28_29_30_Mem[i].USSW_Count +=3;
					RtuDataAddr->YF27_28_29_30_Mem[i].USSW_Count +=3;
					c_ussx_last_time[i] = 0;
				}
			}
			else
			{
				if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC<UX)//---------�ж�UCԽ����
				{
					RtuDataAddr->F27_28_29_30_Mem[i].U_B_Sum += RtuDataAddr->DD_Device_BiaoShi_Value[i].VC;
					RtuDataAddr->F27_28_29_30_Mem[i].UXW_Count++;
					RtuDataAddr->YF27_28_29_30_Mem[i].UXW_Count++;
					if((RtuDataAddr->DD_Device_BiaoShi_Value[i].VC<UXX) && (c_uxxx_last_time[i] >= 3))//FkDdRealData
					{
						RtuDataAddr->F27_28_29_30_Mem[i].UXXW_Count +=3;
						RtuDataAddr->YF27_28_29_30_Mem[i].UXXW_Count +=3;
						c_uxxx_last_time[i] = 0;
					}
				}
				else							   //---------UC�ϸ��ѹ
				{
					RtuDataAddr->F27_28_29_30_Mem[i].U_C_Sum += RtuDataAddr->DD_Device_BiaoShi_Value[i].VC;//FkDdRealData
					RtuDataAddr->F27_28_29_30_Mem[i].UHGW_Count++;
					RtuDataAddr->YF27_28_29_30_Mem[i].UHGW_Count++;
				}
			}
			//--------------------------------------------------------------------------------������ʱ��
			runtime=RtuDataAddr->F27_28_29_30_Mem[0].UHGU_Count
					  +RtuDataAddr->F27_28_29_30_Mem[0].USU_Count+RtuDataAddr->F27_28_29_30_Mem[0].UXU_Count;

			DataCalcDbg("Run time runtime=%d\r\n",runtime);
			DataCalcDbg("A [%d].UHGU_Count=%d\r\n",i,RtuDataAddr->F27_28_29_30_Mem[i].UHGU_Count);
			DataCalcDbg("B [%d].UHGV_Count=%d\r\n",i,RtuDataAddr->F27_28_29_30_Mem[i].UHGV_Count);
			DataCalcDbg("C [%d].UHGW_Count=%d\r\n",i,RtuDataAddr->F27_28_29_30_Mem[i].UHGW_Count);
			if(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IA)*100>abs(ISS))//�ж�IAԽ�������ۼ�ʱ��
			{
				RtuDataAddr->F27_28_29_30_Mem[i].ISSU_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].ISSU_Count++;
			}
			else if(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IA)*100>abs(IS))//�ж�IAԽ�����ۼ�ʱ��
				{
					RtuDataAddr->F27_28_29_30_Mem[i].ISU_Count++;
					RtuDataAddr->YF27_28_29_30_Mem[i].ISU_Count++;
				}
			if(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IB)*100>abs(ISS))//�ж�IBԽ�������ۼ�ʱ��
			{
				RtuDataAddr->F27_28_29_30_Mem[i].ISSV_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].ISSV_Count++;
			}
			else if(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IB)*100>abs(IS))//�ж�IbԽ�����ۼ�ʱ��
				{
					RtuDataAddr->F27_28_29_30_Mem[i].ISV_Count++;
					RtuDataAddr->YF27_28_29_30_Mem[i].ISV_Count++;
				}
			if(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IC)*100>abs(ISS))//�ж�ICԽ�������ۼ�ʱ��
			{
				RtuDataAddr->F27_28_29_30_Mem[i].ISSW_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].ISSW_Count++;
			}
			else if(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IC)*100>abs(IS))//�ж�IcԽ�����ۼ�ʱ��
				{
					RtuDataAddr->F27_28_29_30_Mem[i].ISW_Count++;
					RtuDataAddr->YF27_28_29_30_Mem[i].ISW_Count++;
				}

			SSS=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[2]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[2]&0x0f);
			SSS=(SSS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[1]&0x0f);
			SSS=(SSS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[0]&0x0f);
			SSS=SSS;//���ڹ���������ֵ
			SS=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[2]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[2]&0x0f);
			SS=(SS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[1]&0x0f);
			SS=(SS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[0]&0x0f);
			SS=SS;  //���ڹ�������ֵ
			PS1=sqrt((RtuDataAddr->DD_Device_BiaoShi_Value[i].P/10)*(RtuDataAddr->DD_Device_BiaoShi_Value[i].P/10)
			 + (RtuDataAddr->DD_Device_BiaoShi_Value[i].Q/10)*(RtuDataAddr->DD_Device_BiaoShi_Value[i].Q/10));
			 PS=(INT32U)PS1;
			 PS=PS*10;
			DataCalcDbg("\r\n%s%d,S=%d SSS=%d SS=%d",
			"������",
			i+1,
			PS,
			SSS,
			SS);

			if(PS>SSS)//���ڹ���Խ�������ۼ�
			{
				RtuDataAddr->F27_28_29_30_Mem[i].S_SS_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].S_SS_Count++;
			}
			else
			if(PS>SS) //���ڹ���Խ�����ۼ�
			{
				RtuDataAddr->F27_28_29_30_Mem[i].S_S_Count++;
				RtuDataAddr->YF27_28_29_30_Mem[i].S_S_Count++;
			}
			//����ƽ����ѹ
			RtuDataAddr->F27_28_29_30_Mem[i].DUUAVE = RtuDataAddr->F27_28_29_30_Mem[i].U_A_Sum/(RtuDataAddr->F27_28_29_30_Mem[i].USU_Count+RtuDataAddr->F27_28_29_30_Mem[i].UXU_Count+RtuDataAddr->F27_28_29_30_Mem[i].UHGU_Count);
			RtuDataAddr->F27_28_29_30_Mem[i].DUVAVE = RtuDataAddr->F27_28_29_30_Mem[i].U_B_Sum/(RtuDataAddr->F27_28_29_30_Mem[i].USV_Count+RtuDataAddr->F27_28_29_30_Mem[i].UXV_Count+RtuDataAddr->F27_28_29_30_Mem[i].UHGV_Count);
			RtuDataAddr->F27_28_29_30_Mem[i].DUWAVE = RtuDataAddr->F27_28_29_30_Mem[i].U_C_Sum/(RtuDataAddr->F27_28_29_30_Mem[i].USW_Count+RtuDataAddr->F27_28_29_30_Mem[i].UXW_Count+RtuDataAddr->F27_28_29_30_Mem[i].UHGW_Count);

			RtuDataAddr->YF27_28_29_30_Mem[i].DUUAVE = RtuDataAddr->YF27_28_29_30_Mem[i].U_A_Sum/(RtuDataAddr->YF27_28_29_30_Mem[i].USU_Count+RtuDataAddr->YF27_28_29_30_Mem[i].UXU_Count+RtuDataAddr->YF27_28_29_30_Mem[i].UHGU_Count);
			RtuDataAddr->YF27_28_29_30_Mem[i].DUVAVE = RtuDataAddr->YF27_28_29_30_Mem[i].U_B_Sum/(RtuDataAddr->YF27_28_29_30_Mem[i].USV_Count+RtuDataAddr->YF27_28_29_30_Mem[i].UXV_Count+RtuDataAddr->YF27_28_29_30_Mem[i].UHGV_Count);
			RtuDataAddr->YF27_28_29_30_Mem[i].DUWAVE = RtuDataAddr->YF27_28_29_30_Mem[i].U_C_Sum/(RtuDataAddr->YF27_28_29_30_Mem[i].USW_Count+RtuDataAddr->YF27_28_29_30_Mem[i].UXW_Count+RtuDataAddr->YF27_28_29_30_Mem[i].UHGW_Count);


			UVWXZ=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.U3_Unbalance_Value[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.U3_Unbalance_Value[1]&0x0f);
			UVWXZ=(UVWXZ*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.U3_Unbalance_Value[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.U3_Unbalance_Value[0]&0x0f);
			ABCXZ=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I3_Unbalance_Value[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I3_Unbalance_Value[1]&0x0f);
			ABCXZ=(ABCXZ*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I3_Unbalance_Value[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I3_Unbalance_Value[0]&0x0f);

			VCalc=(RtuDataAddr->FkDdRealData.VA+RtuDataAddr->FkDdRealData.VB+RtuDataAddr->FkDdRealData.VC)/3;
			ICalc=(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IA)+abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IB)+abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IC))/3;
			VMax=MaxValue(RtuDataAddr->FkDdRealData.VA,RtuDataAddr->FkDdRealData.VB,RtuDataAddr->FkDdRealData.VC);

			IMax=MaxValue(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IA),abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IB),abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IC));
			DataCalcDbg("\r\n%s%d,UVWXZ=%d ABCXZ=%d VCalc=%d,ICalc=%d",
			"������",
			i+1,
			UVWXZ,
			ABCXZ,
			VCalc,
			ICalc);

			VValue=0;
			if(VCalc!=0)
			{
				VValue=((VMax-VCalc)*1000)/VCalc;
				if(VValue>UVWXZ)
				{
					RtuDataAddr->F27_28_29_30_Mem[i].V_UNBALANCE_Count++;
					RtuDataAddr->YF27_28_29_30_Mem[i].V_UNBALANCE_Count++;
				}
			}
			IValue=0;
			if(ICalc!=0)
			{
				IValue=((IMax-ICalc)*1000)/ICalc;
				if(IValue>abs(ABCXZ))
				{
					RtuDataAddr->F27_28_29_30_Mem[i].I_UNBALANCE_Count++;
					RtuDataAddr->YF27_28_29_30_Mem[i].I_UNBALANCE_Count++;
				}
			}
		}
	}
}
void IHuiLuYiChang()
{
	//������·�쳣����ָ���������ģ�Err9

	INT8U Flag=0;
	INT16S ICalc=0;

	ICalc=(abs(RtuDataAddr->FkDdRealData.IA)+abs(RtuDataAddr->FkDdRealData.IB)+abs(RtuDataAddr->FkDdRealData.IC))/3;
	if((RtuDataAddr->FkDdRealData.IA<0)||(RtuDataAddr->FkDdRealData.PA<0))
	{
		Flag=0x01;
		Flag|=0xc0;//��������
	}
	if((RtuDataAddr->FkDdRealData.IB<0)||(RtuDataAddr->FkDdRealData.PB<0))
	{
		Flag|=0x02;
		Flag|=0xc0;//��������
	}
	if((RtuDataAddr->FkDdRealData.IC<0)||(RtuDataAddr->FkDdRealData.PC<0))
	{
		Flag|=0x04;
		Flag|=0xc0;//��������
	}
	if((abs(RtuDataAddr->FkDdRealData.IA)<(ICalc*0.8))||(abs(RtuDataAddr->FkDdRealData.IB)<(ICalc*0.8))||(abs(RtuDataAddr->FkDdRealData.IC)<(ICalc*0.8)))
	{
		if(abs(RtuDataAddr->FkDdRealData.IA)<(ICalc*0.8))
		{
			Flag=0x01;
			if(abs(RtuDataAddr->FkDdRealData.IA)==0)
				Flag|=0x80;//������·
			else
				Flag|=0x40;//������·
		}
		if(abs(RtuDataAddr->FkDdRealData.IB)<(ICalc*0.8))
		{
			Flag|=0x02;
			if(abs(RtuDataAddr->FkDdRealData.IB)==0)
				Flag|=0x80;//������·
			else
				Flag|=0x40;//������·
		}
		if(abs(RtuDataAddr->FkDdRealData.IC)<(ICalc*0.8))
		{
			Flag|=0x04;
			if(abs(RtuDataAddr->FkDdRealData.IC)==0)
				Flag|=0x80;//������·
			else
				Flag|=0x40;//������·
		}
		if(Flag&0x80)Flag=Flag&0x8f;
	}

	if(RtuDataAddr->ERRJiaoCai!=Flag)
	{
		if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)
		{
			if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[1]&0x01)//��Ҫ�¼�
			{
				RtuDataAddr->Event_Save.Event.Err9.ERCNo=9;
				RtuDataAddr->Event_Save.Event.Err9.len=28;
				if(Flag!=0)
				{
					RtuDataAddr->Event_Save.Event.Err9.Cl_No[0]=(1)&0xff;
					RtuDataAddr->Event_Save.Event.Err9.Cl_No[1]=(((1)>>8)&0xff)|0x80;
					RtuDataAddr->Event_Save.Event.Err9.BiaoZhi=Flag;
				}
				else
				{
					RtuDataAddr->Event_Save.Event.Err9.Cl_No[0]=(1)&0xff;
					RtuDataAddr->Event_Save.Event.Err9.Cl_No[1]=((1)>>8)&0xff;
					RtuDataAddr->Event_Save.Event.Err9.BiaoZhi=RtuDataAddr->ERRJiaoCai;
				}
				INT32ToBCD(RtuDataAddr->FkDdRealData.VA,&RtuDataAddr->Event_Save.Event.Err9.UA[0],2);
				INT32ToBCD(RtuDataAddr->FkDdRealData.VB,&RtuDataAddr->Event_Save.Event.Err9.UB[0],2);
				INT32ToBCD(RtuDataAddr->FkDdRealData.VC,&RtuDataAddr->Event_Save.Event.Err9.UC[0],2);
				INT32ToBCD((RtuDataAddr->FkDdRealData.IA*10),&RtuDataAddr->Event_Save.Event.Err9.IA[0],3);
				INT32ToBCD((RtuDataAddr->FkDdRealData.IB*10),&RtuDataAddr->Event_Save.Event.Err9.IB[0],3);
				INT32ToBCD((RtuDataAddr->FkDdRealData.IC*10),&RtuDataAddr->Event_Save.Event.Err9.IC[0],3);
				RtuDataAddr->Event_Save.Event.Err9.PDD[0]=0;
				INT32ToBCD(RtuDataAddr->FkDdRealData.Z_P_All,&RtuDataAddr->Event_Save.Event.Err9.PDD[1],4);
				if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[1]&0x01)//��Ҫ�¼�
				{
					SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err9.Occur_Time.BCD01,1,9);
				}
				else//һ���¼�
				{
					SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err9.Occur_Time.BCD01,2,9);
				}

			}
		}
		RtuDataAddr->ERRJiaoCai=Flag;
	}
}
void XiangXuYiChang()
{
	//�����쳣�жϣ���ָ���������ģ�Err11
	INT8U TmpFkStat;
	TmpFkStat=0;
	if((RtuDataAddr->FkMaxXuliang.FKStat>>3)&0x01)
		TmpFkStat=1;
	else
		TmpFkStat=0;
	if(RtuDataAddr->ERR11JiaoCai!=TmpFkStat)
	{
		if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)
		{
			if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[1]&0x04)//��Ҫ�¼�
			{
				if(TmpFkStat!=0)
				{
					RtuDataAddr->Event_Save.Event.Err11.ERCNo=11;
					RtuDataAddr->Event_Save.Event.Err11.len=24;
					RtuDataAddr->Event_Save.Event.Err11.Cl_No[0]=(1)&0xff;
					RtuDataAddr->Event_Save.Event.Err11.Cl_No[1]=(((1)>>8)&0xff)|0x80;
				}
				else
				{
					RtuDataAddr->Event_Save.Event.Err11.ERCNo=11;
					RtuDataAddr->Event_Save.Event.Err11.len=24;
					RtuDataAddr->Event_Save.Event.Err11.Cl_No[0]=(1)&0xff;
					RtuDataAddr->Event_Save.Event.Err11.Cl_No[1]=((1)>>8)&0xff;
				}

				INT32ToBCD(RtuDataAddr->FkMaxXuliang.UAJ,&RtuDataAddr->Event_Save.Event.Err11.UAj[0],2);
				INT32ToBCD(RtuDataAddr->FkMaxXuliang.UBJ,&RtuDataAddr->Event_Save.Event.Err11.UBj[0],2);
				INT32ToBCD(RtuDataAddr->FkMaxXuliang.UCJ,&RtuDataAddr->Event_Save.Event.Err11.UCj[0],2);
				INT32ToBCD(RtuDataAddr->FkMaxXuliang.IAJ,&RtuDataAddr->Event_Save.Event.Err11.IAj[0],2);
				INT32ToBCD(RtuDataAddr->FkMaxXuliang.IBJ,&RtuDataAddr->Event_Save.Event.Err11.IBj[0],2);
				INT32ToBCD(RtuDataAddr->FkMaxXuliang.ICJ,&RtuDataAddr->Event_Save.Event.Err11.ICj[0],2);
				RtuDataAddr->Event_Save.Event.Err11.PDD[0]=0;
				INT32ToBCD(RtuDataAddr->FkDdRealData.Z_P_All,&RtuDataAddr->Event_Save.Event.Err11.PDD[1],4);
				if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[1]&0x04)//��Ҫ�¼�
				{
					SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err11.Occur_Time.BCD01,1,11);
				}
				else//һ���¼�
				{
					SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err11.Occur_Time.BCD01,2,11);
				}

			}
		}
		RtuDataAddr->ERR11JiaoCai=TmpFkStat;
	}
}
void HeGeTongJi()
{
	INT16U US,UX,UD,USS,UXX,UED,IED,UVWXZ,U0Time,VCalc,VValue,VMax,VMin;
	INT16S ISS,IS,I0S,ABCXZ,IValue,IMax,ICalc,IMin;
	INT32U SSS,SS,PS;
	float PS1;
	INT8U Flag;
	INT16U i;
	TS ts;
	for(i=0;i<CeLiangPoint_Max;i++)
	{
		if(RtuDataAddr->DD_Device_BiaoShi_Value[i].Valid!=1)continue;
		if(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.Valid==1)
		{
			US=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_S[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_S[1]&0x0f);
			US=(US*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_S[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_S[0]&0x0f);
			UX=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_X[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_X[1]&0x0f);
			UX=(UX*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_X[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_X[0]&0x0f);
			UD=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_Duan_Men[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_Duan_Men[1]&0x0f);
			UD=(UD*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_Duan_Men[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_Duan_Men[0]&0x0f);
			USS=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_SS[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_SS[1]&0x0f);
			USS=(USS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_SS[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_SS[0]&0x0f);
			UXX=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_XX[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_XX[1]&0x0f);
			UXX=(UXX*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_XX[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.V_He_ge_XX[0]&0x0f);
			ISS=(((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_SS[2]>>4)&0x07)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_SS[2]&0x0f);
			ISS=(ISS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_SS[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_SS[1]&0x0f);
			ISS=(ISS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_SS[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_SS[0]&0x0f);
			IS=(((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_S[2]>>4)&0x07)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_S[2]&0x0f);
			IS=(IS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_S[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_S[1]&0x0f);
			IS=(IS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_S[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_S[0]&0x0f);
			SSS=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[2]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[2]&0x0f);
			SSS=(SSS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[1]&0x0f);
			SSS=(SSS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[0]&0x0f);
			SSS=SSS;
			SS=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[2]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[2]&0x0f);
			SS=(SS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[1]&0x0f);
			SS=(SS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[0]&0x0f);
			SS=SS;
//////////��ѹԽ�޼�¼Err24
			Flag=0;
			DataCalcDbg("\r\n%s%d,VA=%d Vb=%d Vc=%d us=%d ux=%d ud=%d Uss=%d Uxx=%d ״̬=%d",
			"������",i+1,
			RtuDataAddr->DD_Device_BiaoShi_Value[i].VA,
			RtuDataAddr->DD_Device_BiaoShi_Value[i].VB,
			RtuDataAddr->DD_Device_BiaoShi_Value[i].VC,
			US,UX,UD,USS,UXX,RtuDataAddr->DD_ZuiDa_Xuliang_Shuju[i].FKStat);
			if((RtuDataAddr->DD_Device_BiaoShi_Value[i].VA>USS)||(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB>USS)||(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC>USS))
			{
				if((RtuDataAddr->DD_Device_BiaoShi_Value[i].VA>USS))Flag=0x01;
				if((RtuDataAddr->DD_Device_BiaoShi_Value[i].VB>USS))Flag|=0x02;
				if((RtuDataAddr->DD_Device_BiaoShi_Value[i].VC>USS))Flag|=0x04;
				Flag|=0x40;
			}
			else
			{
				if((RtuDataAddr->DD_Device_BiaoShi_Value[i].VA<UXX)||(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB<UXX)||(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC<UXX))
				{
					if((RtuDataAddr->DD_Device_BiaoShi_Value[i].VA<UXX))Flag=0x01;
					if((RtuDataAddr->DD_Device_BiaoShi_Value[i].VB<UXX))Flag|=0x02;
					if((RtuDataAddr->DD_Device_BiaoShi_Value[i].VC<UXX))Flag|=0x04;
					Flag|=0x80;
				}
			}
			if(RtuDataAddr->UHeGeErr[i])
			{
				if((RtuDataAddr->DD_Device_BiaoShi_Value[i].VA<US)&&(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA>UX)
					&&(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB<US)&&(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB>UX)
					&&(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC<US)&&(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC>UX))
				{
					if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)
					{
						if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[2]&0x80)//��Ҫ�¼�
						{
							RtuDataAddr->Event_Save.Event.Err24.ERCNo=24;
							RtuDataAddr->Event_Save.Event.Err24.len=14;
							RtuDataAddr->Event_Save.Event.Err24.CeliangNo[0]=(i+1)&0xff;
							RtuDataAddr->Event_Save.Event.Err24.CeliangNo[1]=((i+1)>>8)&0xff;
							RtuDataAddr->Event_Save.Event.Err24.Flag=RtuDataAddr->UHeGeErr[i];
							INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA,&RtuDataAddr->Event_Save.Event.Err24.UA[0],2);
							INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB,&RtuDataAddr->Event_Save.Event.Err24.UB[0],2);
							INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC,&RtuDataAddr->Event_Save.Event.Err24.UC[0],2);
							if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[2]&0x80)//��Ҫ�¼�
							{
								SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err24.Occur_Time.BCD01,1,24);
							}
							else//һ���¼�
							{
								SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err24.Occur_Time.BCD01,2,24);
							}
						}
					RtuDataAddr->UHeGeErr[i]=0;
					}
				}
			}
			if(Flag!=0)
			{
				if(RtuDataAddr->UHeGeErr[i]!=Flag)
				{
					RtuDataAddr->UHeGeErr[i]=Flag;
					if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)
					{
						if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[2]&0x80)//��Ҫ�¼�
						{
							RtuDataAddr->Event_Save.Event.Err24.ERCNo=24;
							RtuDataAddr->Event_Save.Event.Err24.len=14;
							RtuDataAddr->Event_Save.Event.Err24.CeliangNo[0]=(i+1)&0xff;
							RtuDataAddr->Event_Save.Event.Err24.CeliangNo[1]=(((i+1)>>8)&0xff)|0x80;
							RtuDataAddr->Event_Save.Event.Err24.Flag=Flag;
							INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA,&RtuDataAddr->Event_Save.Event.Err24.UA[0],2);
							INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB,&RtuDataAddr->Event_Save.Event.Err24.UB[0],2);
							INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC,&RtuDataAddr->Event_Save.Event.Err24.UC[0],2);
							if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[2]&0x80)//��Ҫ�¼�
							{
								SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err24.Occur_Time.BCD01,1,24);
							}
							else//һ���¼�
							{
								SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err24.Occur_Time.BCD01,2,24);
							}
						}
					}
				}
			}
/////////��ѹ��·�쳣Err10
			if(RtuDataAddr->Cl_MenXian_Value[i].F25_Set_Para.Valid==1)
			{
				//���ѹ
				UED=((RtuDataAddr->Cl_MenXian_Value[i].F25_Set_Para.E_Ding_V[1]>>4)*10)+
					(RtuDataAddr->Cl_MenXian_Value[i].F25_Set_Para.E_Ding_V[1]&0x0f);
				UED=(UED*100)+((RtuDataAddr->Cl_MenXian_Value[i].F25_Set_Para.E_Ding_V[0]>>4)*10)+
					(RtuDataAddr->Cl_MenXian_Value[i].F25_Set_Para.E_Ding_V[0]&0x0f);
				//������
				IED=((RtuDataAddr->Cl_MenXian_Value[i].F25_Set_Para.Max_I>>4)*10)+
					(RtuDataAddr->Cl_MenXian_Value[i].F25_Set_Para.Max_I&0x0f);
				IED=IED*10;
				DataCalcDbg("\r\n%s%d,UED=%d IED=%d","������",i+1,UED,IED);// d 9
				Flag=0;
				DataCalcDbg("\n\rshiya panduan celiangNo %d VA=%d,VB=%d,VC=%d,UED=%d",i+1,RtuDataAddr->DD_Device_BiaoShi_Value[i].VA,RtuDataAddr->DD_Device_BiaoShi_Value[i].VB,RtuDataAddr->DD_Device_BiaoShi_Value[i].VC,UED);
				if((RtuDataAddr->DD_Device_BiaoShi_Value[i].VA<=(UED*0.7))||(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB<=(UED*0.7))||(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC<=(UED*0.7)))// 0.6
				{//�����������ж���˴�Ϊ  78% 0.78   //����ר����˵��   0.6
					if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA<=(UED*0.7))//0.6
					{
						//if((abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IA)*10)>25)// ���߸�Ϊ  !=0
						if((abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IA)*10)!= 0)
						{
							Flag|=0x01;//A��
							Flag|=0x80;//ʧѹ
						}
					}
					if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB<=(UED*0.7))//0.6
					{
						//if((abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IB)*10)>25)// ���߸�Ϊ  !=0
						if((abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IB)*10)!= 0)
						{
							Flag|=0x02;//B��
							Flag|=0x80;//ʧѹ
						}
					}
					if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC<=(UED*0.7))//0.6
					{
						//if((abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IC)*10)>25)// ���߸�Ϊ  !=0
						if((abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IC)*10)!= 0)
						{
							Flag|=0x04;//C��
							Flag|=0x80;//ʧѹ
						}
					}
					DataCalcDbg("\n\r %s Flag %02x","ʧѹ�¼�  ",Flag);
				}
				DataCalcDbg("\n\r shiya Flag----%d",Flag);
				JugeDianYaEven(Flag,i,&RtuDataAddr->ERR10_1HeGeErr[i]);

				Flag = 0;
				if((RtuDataAddr->DD_Device_BiaoShi_Value[i].VA<(UD))||(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB<(UD))||(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC<(UD)))
				{//ԭ��������   UED*0.60    ��Ϊ  UD
					if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA<(UD))
					{
						if((abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IA)*10)<=25)
						{
							Flag|=0x01;//A��
							Flag|=0x40;//����
						}
					}
					if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB<(UD))
					{
						if((abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IB)*10)<=25)
						{
							Flag|=0x02;//B
							Flag|=0x40;
						}
					}
					if(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC<(UD))
					{
						if((abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IC)*10)<=25)
						{
							Flag|=0x04;
							Flag|=0x40;
						}
					}
				}
				JugeDianYaEven(Flag,i,&RtuDataAddr->ERR10_2HeGeErr[i]);
			}
//////////����Խ�޼�¼�¼�Err25
			ISS=(((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_SS[2]>>4)&0x07)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_SS[2]&0x0f);
			ISS=(ISS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_SS[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_SS[1]&0x0f);
			ISS=(ISS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_SS[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_SS[0]&0x0f);
			//�����������
			IS=(((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_S[2]>>4)&0x07)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_S[2]&0x0f);
			IS=(IS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_S[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_S[1]&0x0f);
			IS=(IS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_S[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I_S[0]&0x0f);

			//���������
			I0S=(((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.U0I_S[2]>>4)&0x07)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.U0I_S[2]&0x0f);
			I0S=(I0S*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.U0I_S[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.U0I_S[1]&0x0f);
			I0S=(I0S*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.U0I_S[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.U0I_S[0]&0x0f);
			//�����������

			Flag=0;
			DataCalcDbg("\r\n%s%d,IA=%d Ib=%d Ic=%d ISS=%d IS=%d I0S=%d",
			"������",i+1,
			RtuDataAddr->DD_Device_BiaoShi_Value[i].IA,
			RtuDataAddr->DD_Device_BiaoShi_Value[i].IB,
			RtuDataAddr->DD_Device_BiaoShi_Value[i].IC,
			ISS,IS,I0S);

			//if((RtuDataAddr->DD_Device_BiaoShi_Value[i].IA>ISS)||(RtuDataAddr->DD_Device_BiaoShi_Value[i].IB>ISS)||(RtuDataAddr->DD_Device_BiaoShi_Value[i].IC>ISS))
			if((abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IA)*10>abs(ISS))||(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IB)*10>abs(ISS))||(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IC)*10>abs(ISS)))
			{
				if((abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IA)*10>abs(ISS)))Flag=0x01;
				if((abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IB)*10>abs(ISS)))Flag|=0x02;
				if((abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IC)*10>abs(ISS)))Flag|=0x04;
				Flag|=0x40;
			}
			else
			{
				//if((RtuDataAddr->DD_Device_BiaoShi_Value[i].IA>IS)||(RtuDataAddr->DD_Device_BiaoShi_Value[i].IB>IS)||(RtuDataAddr->DD_Device_BiaoShi_Value[i].IC>IS))
				if((abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IA)*10>abs(IS))||(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IB)*10>abs(IS))||(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IC)*10>abs(IS)))
				{
					if((abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IA)*10>abs(IS)))Flag=0x01;
					if((abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IB)*10>abs(IS)))Flag|=0x02;
					if((abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IC)*10>abs(IS)))Flag|=0x04;
					Flag|=0x80;
				}
			}
			if(RtuDataAddr->IHeGeErr[i])
			{
				if((abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IA)*10<abs(IS))&&(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IB)*10<abs(IS))&&(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IC)*10<abs(IS)))
				{
					if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)
					{
						if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[3]&0x01)//��Ҫ�¼�
						{
							RtuDataAddr->Event_Save.Event.Err25.ERCNo=25;
							RtuDataAddr->Event_Save.Event.Err25.len=17;
							RtuDataAddr->Event_Save.Event.Err25.CeliangNo[0]=(i+1)&0xff;
							RtuDataAddr->Event_Save.Event.Err25.CeliangNo[1]=((i+1)>>8)&0xff;
							RtuDataAddr->Event_Save.Event.Err25.Flag=RtuDataAddr->IHeGeErr[i];
							INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[i].IA*10),&RtuDataAddr->Event_Save.Event.Err25.IA[0],3);
							INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[i].IB*10),&RtuDataAddr->Event_Save.Event.Err25.IB[0],3);
							INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[i].IC*10),&RtuDataAddr->Event_Save.Event.Err25.IC[0],3);
							if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[3]&0x01)//��Ҫ�¼�
							{
								SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err25.Occur_Time.BCD01,1,25);
							}
							else//һ���¼�
							{
								SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err25.Occur_Time.BCD01,2,25);
							}
						}
					}
					RtuDataAddr->IHeGeErr[i]=0;
				}
			}
			if(Flag!=0)
			{
				if(RtuDataAddr->IHeGeErr[i]!=Flag)
				{
					RtuDataAddr->IHeGeErr[i]=Flag;
					if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)
					{
						if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[3]&0x01)//��Ҫ�¼�
						{
							RtuDataAddr->Event_Save.Event.Err25.ERCNo=25;
							RtuDataAddr->Event_Save.Event.Err25.len=17;
							RtuDataAddr->Event_Save.Event.Err25.CeliangNo[0]=(i+1)&0xff;
							RtuDataAddr->Event_Save.Event.Err25.CeliangNo[1]=(((i+1)>>8)&0xff)|0x80;
							RtuDataAddr->Event_Save.Event.Err25.Flag=Flag;
							INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[i].IA*10),&RtuDataAddr->Event_Save.Event.Err25.IA[0],3);
							INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[i].IB*10),&RtuDataAddr->Event_Save.Event.Err25.IB[0],3);
							INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[i].IC*10),&RtuDataAddr->Event_Save.Event.Err25.IC[0],3);
							if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[3]&0x01)//��Ҫ�¼�
							{
								SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err25.Occur_Time.BCD01,1,25);
							}
							else//һ���¼�
							{
								SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err25.Occur_Time.BCD01,2,25);
							}
						}
					}
				}
			}
//////////���ڹ���Խ�޼�¼�¼�Err26
			SSS=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[2]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[2]&0x0f);
			SSS=(SSS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[1]&0x0f);
			SSS=(SSS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS[0]&0x0f);
			SSS=SSS;
			SS=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[2]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[2]&0x0f);
			SS=(SS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[1]&0x0f);
			SS=(SS*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S[0]&0x0f);
			SS=SS;

			PS1=sqrt((RtuDataAddr->DD_Device_BiaoShi_Value[i].P/10)*(RtuDataAddr->DD_Device_BiaoShi_Value[i].P/10)
			 + (RtuDataAddr->DD_Device_BiaoShi_Value[i].Q/10)*(RtuDataAddr->DD_Device_BiaoShi_Value[i].Q/10));
			 PS=(INT32U)PS1;
			 PS=PS*10;
			DataCalcDbg("\r\n%s%d,S=%d SSS=%d SS=%d","������",i+1,PS,SSS,SS);
			if(PS>SSS)
			{
				if(RtuDataAddr->SHeGeErr[i]!=2)
				{
					RtuDataAddr->SHeGeErr[i]=2;
					if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)
					{
						if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[3]&0x02)//��Ҫ�¼�
						{
							RtuDataAddr->Event_Save.Event.Err26.ERCNo=26;
							RtuDataAddr->Event_Save.Event.Err26.len=14;
							RtuDataAddr->Event_Save.Event.Err26.ClNo[0]=(i+1)&0xff;
							RtuDataAddr->Event_Save.Event.Err26.ClNo[1]=(((i+1)>>8)&0xff)|0x80;
							RtuDataAddr->Event_Save.Event.Err26.Flag=0x40;
							memcpy(RtuDataAddr->Event_Save.Event.Err26.New_SSET,RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_SS,3);
							RtuDataAddr->Event_Save.Event.Err26.Old_S[0]=(((PS%100)/10)<<4)+PS%10;
							RtuDataAddr->Event_Save.Event.Err26.Old_S[1]=(((PS%10000)/1000)<<4)+(PS/100)%10;
							RtuDataAddr->Event_Save.Event.Err26.Old_S[2]=(((PS%1000000)/100000)<<4)+(PS/10000)%10;
							if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[3]&0x02)//��Ҫ�¼�
							{
								SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err26.Occur_Time.BCD01,1,26);
							}
							else//һ���¼�
							{
								SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err26.Occur_Time.BCD01,2,26);
							}
						}
					}
				}
			}
			else
			{
				if(PS>SS)
				{
					if(RtuDataAddr->SHeGeErr[i]!=1)
					{
						RtuDataAddr->SHeGeErr[i]=1;
						if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)
						{
							if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[3]&0x02)//��Ҫ�¼�
							{
								RtuDataAddr->Event_Save.Event.Err26.ERCNo=26;
								RtuDataAddr->Event_Save.Event.Err26.ClNo[0]=(i+1)&0xff;
								RtuDataAddr->Event_Save.Event.Err26.ClNo[1]=(((i+1)>>8)&0xff)|0x80;
								RtuDataAddr->Event_Save.Event.Err26.Flag=0x80;
								memcpy(RtuDataAddr->Event_Save.Event.Err26.New_SSET,RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S,3);
								RtuDataAddr->Event_Save.Event.Err26.Old_S[0]=(((PS%100)/10)<<4)+PS%10;
								RtuDataAddr->Event_Save.Event.Err26.Old_S[1]=(((PS%10000)/1000)<<4)+(PS/100)%10;
								RtuDataAddr->Event_Save.Event.Err26.Old_S[2]=(((PS%1000000)/100000)<<4)+(PS/10000)%10;
								if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[3]&0x02)//��Ҫ�¼�
								{
									SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err26.Occur_Time.BCD01,1,26);
								}
								else//һ���¼�
								{
									SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err26.Occur_Time.BCD01,2,26);
								}

							}
						}
					}
				}
				else
				{
					if(RtuDataAddr->SHeGeErr[i]!=0)
					{
						if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)
						{
							if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[3]&0x02)//��Ҫ�¼�
							{
								RtuDataAddr->Event_Save.Event.Err26.ERCNo=26;
								RtuDataAddr->Event_Save.Event.Err26.len=14;
								RtuDataAddr->Event_Save.Event.Err26.ClNo[0]=(i+1)&0xff;
								RtuDataAddr->Event_Save.Event.Err26.ClNo[1]=(((i+1)>>8)&0xff);
								RtuDataAddr->Event_Save.Event.Err26.Flag=RtuDataAddr->SHeGeErr[i];
								memcpy(RtuDataAddr->Event_Save.Event.Err26.New_SSET,RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.S_S,3);

								RtuDataAddr->Event_Save.Event.Err26.Old_S[0]=(((PS%100)/10)<<4)+PS%10;
								RtuDataAddr->Event_Save.Event.Err26.Old_S[1]=(((PS%10000)/1000)<<4)+(PS/100)%10;
								RtuDataAddr->Event_Save.Event.Err26.Old_S[2]=(((PS%1000000)/100000)<<4)+(PS/10000)%10;
								if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[3]&0x02)//��Ҫ�¼�
								{
									SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err26.Occur_Time.BCD01,1,26);
								}
								else//һ���¼�
								{
									SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err26.Occur_Time.BCD01,2,26);
								}
							}
						}
						RtuDataAddr->SHeGeErr[i]=0;
					}
				}
			}
//////////��ѹ/������ƽ���¼�Err17
			UVWXZ=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.U3_Unbalance_Value[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.U3_Unbalance_Value[1]&0x0f);
			UVWXZ=(UVWXZ*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.U3_Unbalance_Value[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.U3_Unbalance_Value[0]&0x0f);

			ABCXZ=((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I3_Unbalance_Value[1]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I3_Unbalance_Value[1]&0x0f);
			ABCXZ=(ABCXZ*100)+((RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I3_Unbalance_Value[0]>>4)*10)+
				(RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.I3_Unbalance_Value[0]&0x0f);

			VCalc=(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA+RtuDataAddr->DD_Device_BiaoShi_Value[i].VB+RtuDataAddr->DD_Device_BiaoShi_Value[i].VC)/3;
			ICalc=(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IA)+abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IB)+abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IC))/3;
			VMax=MaxValue(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA,RtuDataAddr->DD_Device_BiaoShi_Value[i].VB,RtuDataAddr->DD_Device_BiaoShi_Value[i].VC);
			IMax=MaxValue(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IA),abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IB),abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IC));
			VMin = MinValue(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA,RtuDataAddr->DD_Device_BiaoShi_Value[i].VB,RtuDataAddr->DD_Device_BiaoShi_Value[i].VC);
			IMin = MinValue(abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IA),abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IB),abs(RtuDataAddr->DD_Device_BiaoShi_Value[i].IC));

			Flag=0;
			DataCalcDbg("\r\n%s%d,UVWXZ=%d ABCXZ=%d VMin=%d,IMin=%d ��VMax=%d , IMax=%d",
			"������",i+1,UVWXZ,ABCXZ,VMin,IMin,VMax,IMax);
			VValue=0;
			if(VMax!=0)
			{
				VValue = ((VMax - VMin)*1000)/VMax;//��ѹ��ƽ��ȼ���
				if(VValue>UVWXZ)
				{
					Flag|=0x01;
				}
				if (VValue>RtuDataAddr->YF27_28_29_30_Mem[i].V_UNBALANCE_Max )
				{
					RtuDataAddr->YF27_28_29_30_Mem[i].V_UNBALANCE_Max = VValue;
					TSGet(&ts);
					TimeGetType17(RtuDataAddr->YF27_28_29_30_Mem[i].V_UNBALANCE_MaxTime,ts);
				}
			}
			IValue=0;
			if(IMax!=0)
			{
				IValue = ((IMax - IMin)*1000)/IMax;//������ƽ��ȼ���
				if(IValue>ABCXZ)
				{
					Flag|=0x02;
				}
				if (IValue>abs(RtuDataAddr->YF27_28_29_30_Mem[i].I_UNBALANCE_Max ))
				{
					RtuDataAddr->YF27_28_29_30_Mem[i].I_UNBALANCE_Max = IValue;
					TSGet(&ts);
					TimeGetType17(RtuDataAddr->YF27_28_29_30_Mem[i].I_UNBALANCE_MaxTime,ts);
				}
			}
			DataCalcDbg("\n\r Err17 Flag = %02x BHeGeErr=%d",Flag,RtuDataAddr->BHeGeErr[i]);
			if(RtuDataAddr->BHeGeErr[i])
			{
				if(Flag==0)
				{
					if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)
					{
						if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[2]&0x01)//��Ҫ�¼�
						{
							DataCalcDbg("\n\r Err17 huifu  !!!");
							RtuDataAddr->Event_Save.Event.Err17.ERCNo=17;
							RtuDataAddr->Event_Save.Event.Err17.len=27;
							RtuDataAddr->Event_Save.Event.Err17.CeliangNo[0]=(i+1)&0xff;
							RtuDataAddr->Event_Save.Event.Err17.CeliangNo[1]=((i+1)>>8)&0xff;
							RtuDataAddr->Event_Save.Event.Err17.Flag=RtuDataAddr->BHeGeErr[i];
							INT32ToBCD(VValue,&RtuDataAddr->Event_Save.Event.Err17.UBalance[0],2);
							INT32ToBCD(IValue,&RtuDataAddr->Event_Save.Event.Err17.IBalance[0],2);
							INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA,&RtuDataAddr->Event_Save.Event.Err17.UA[0],2);
							INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB,&RtuDataAddr->Event_Save.Event.Err17.UB[0],2);
							INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC,&RtuDataAddr->Event_Save.Event.Err17.UC[0],2);
							INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[i].IA*10),&RtuDataAddr->Event_Save.Event.Err17.IA[0],3);
							INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[i].IB*10),&RtuDataAddr->Event_Save.Event.Err17.IB[0],3);
							INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[i].IC*10),&RtuDataAddr->Event_Save.Event.Err17.IC[0],3);
							if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[2]&0x01)//��Ҫ�¼�
							{
								SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err17.Occur_Time.BCD01,1,17);
							}
							else//һ���¼�
							{
								SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err17.Occur_Time.BCD01,2,17);
							}
						}
					RtuDataAddr->BHeGeErr[i]=0;
					}
				}
			}
			if(Flag!=0)
			{
				if(RtuDataAddr->BHeGeErr[i]!=Flag)
				{
					RtuDataAddr->BHeGeErr[i]=Flag;
					if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)
					{
						if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[2]&0x01)//��Ҫ�¼�
						{
							DataCalcDbg("\n\r Err17 Hapen  !!!");
							RtuDataAddr->Event_Save.Event.Err17.ERCNo=17;
							RtuDataAddr->Event_Save.Event.Err17.len=27;

							RtuDataAddr->Event_Save.Event.Err17.CeliangNo[0]=(i+1)&0xff;
							RtuDataAddr->Event_Save.Event.Err17.CeliangNo[1]=(((i+1)>>8)&0xff)|0x80;
							RtuDataAddr->Event_Save.Event.Err17.Flag=Flag;
							INT32ToBCD(VValue,&RtuDataAddr->Event_Save.Event.Err17.UBalance[0],2);
							INT32ToBCD(IValue,&RtuDataAddr->Event_Save.Event.Err17.IBalance[0],2);
							INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA,&RtuDataAddr->Event_Save.Event.Err17.UA[0],2);
							INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB,&RtuDataAddr->Event_Save.Event.Err17.UB[0],2);
							INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC,&RtuDataAddr->Event_Save.Event.Err17.UC[0],2);
							INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[i].IA*10),&RtuDataAddr->Event_Save.Event.Err17.IA[0],3);
							INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[i].IB*10),&RtuDataAddr->Event_Save.Event.Err17.IB[0],3);
							INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[i].IC*10),&RtuDataAddr->Event_Save.Event.Err17.IC[0],3);
							if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[2]&0x01)//��Ҫ�¼�
							{
								SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err17.Occur_Time.BCD01,1,17);
							}
							else//һ���¼�
							{
								SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err17.Occur_Time.BCD01,2,17);
							}
						}
					}
				}
			}
			U0Time=RtuDataAddr->Cl_MenXian_Value[i].F26_Set_Para.LianXu_ShiYa;
		}
	}
}
void JugeDianYaEven(unsigned char  Flag ,int i,unsigned char *OldErr)
{
	if(Flag)
	{
		DataCalcDbg("\n\r %s OldErr Flag %d  %d","��ѹ��·�쳣�¼�����  ",Flag,*OldErr);
		if(*OldErr!=Flag)
		{
			*OldErr=Flag;
			if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)
			{
				if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[1]&0x02)//��Ҫ�¼�
				{
					DataCalcDbg("\n\r Err10 Hapen  !!!");
					RtuDataAddr->Event_Save.Event.Err10.ERCNo=10;
					RtuDataAddr->Event_Save.Event.Err10.len=28;
					RtuDataAddr->Event_Save.Event.Err10.Cl_No[0]=(i+1)&0xff;
					RtuDataAddr->Event_Save.Event.Err10.Cl_No[1]=(((i+1)>>8)&0xff)|0x80;

					RtuDataAddr->Event_Save.Event.Err10.BiaoZhi=Flag;

					INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA,&RtuDataAddr->Event_Save.Event.Err10.UA[0],2);
					INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB,&RtuDataAddr->Event_Save.Event.Err10.UB[0],2);
					INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC,&RtuDataAddr->Event_Save.Event.Err10.UC[0],2);

					INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[i].IA*10),&RtuDataAddr->Event_Save.Event.Err10.IA[0],3);
					INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[i].IB*10),&RtuDataAddr->Event_Save.Event.Err10.IB[0],3);
					INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[i].IC*10),&RtuDataAddr->Event_Save.Event.Err10.IC[0],3);
					RtuDataAddr->Event_Save.Event.Err10.PDD[0]=0;
					INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_All,&RtuDataAddr->Event_Save.Event.Err10.PDD[1],4);
					if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[1]&0x02)//��Ҫ�¼�
					{
						SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err10.Occur_Time.BCD01,1,10);
					}
					else//һ���¼�
					{
						SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err10.Occur_Time.BCD01,2,10);
					}
				}
			}
		}
	}
	//////////////////////////////////////////////////////////////////////////////
	else
	{
		if(*OldErr)
		{
			if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)
			{
				if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[1]&0x02)//��Ҫ�¼�
				{
					DataCalcDbg("\n\r Err10 Huifu  !!!");
					RtuDataAddr->Event_Save.Event.Err10.ERCNo=10;
					RtuDataAddr->Event_Save.Event.Err10.len=28;
					RtuDataAddr->Event_Save.Event.Err10.Cl_No[0]=(i+1)&0xff;
					RtuDataAddr->Event_Save.Event.Err10.Cl_No[1]=((i+1)>>8)&0xff;
					RtuDataAddr->Event_Save.Event.Err10.BiaoZhi=*OldErr;
					INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[i].VA,&RtuDataAddr->Event_Save.Event.Err10.UA[0],2);
					INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[i].VB,&RtuDataAddr->Event_Save.Event.Err10.UB[0],2);
					INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[i].VC,&RtuDataAddr->Event_Save.Event.Err10.UC[0],2);
					INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[i].IA*10),&RtuDataAddr->Event_Save.Event.Err10.IA[0],3);
					INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[i].IB*10),&RtuDataAddr->Event_Save.Event.Err10.IB[0],3);
					INT32ToBCD((RtuDataAddr->DD_Device_BiaoShi_Value[i].IC*10),&RtuDataAddr->Event_Save.Event.Err10.IC[0],3);
					RtuDataAddr->Event_Save.Event.Err10.PDD[0]=0;
					INT32ToBCD(RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_All,&RtuDataAddr->Event_Save.Event.Err10.PDD[1],4);
					if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[1]&0x02)//��Ҫ�¼�
					{
						SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err10.Occur_Time.BCD01,1,10);
					}
					else//һ���¼�
					{
						SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err10.Occur_Time.BCD01,2,10);
					}
				}
				*OldErr=Flag;
			}
		}
	}
}
INT8U   PARSE_CMD(int argc, char * argv[])
{
	char  proc_name[32] = "";
	if(argc < 2)return (FALSE);
	PORT_ID = atoi(argv[1]);
	sprintf(proc_name, "%s %d", argv[0], PORT_ID);
	if((attach = name_attach(NULL, proc_name,0))  == NULL)
	{
		fprintf(stderr, "ERR:'%s' runed,cann't regist: %s\r\n", proc_name, strerror(errno));
		return (FALSE);
	}
	return (TRUE);
}
void QuitProcess(int signo)
{
	fclose(CAfp);
	delay(100);
	RtuDataAddr->stPortPara[PORT_ID].PID=0;
   	name_detach(attach, 0);
   	fprintf(stderr,"fkCalc quit");
	exit(0);
}
void markver()//��Ŀ������б�ʶ�����汾��Ϣ
{
	printf("\n%s\n", verstr);
}
void CreateErr32()
{
	if(RtuDataAddr->Event_Value.F9_Set_Para.Valid==1)
	{
		if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Rec_Valid[3]&0x80)//��Ҫ�Բ������ý����¼���¼
		{
			RtuDataAddr->Event_Save.Event.Err32.ERCNo=32;
			RtuDataAddr->Event_Save.Event.Err32.len=13;
			RtuDataAddr->Event_Save.Event.Err32.Now_LiuLiang[3]=(RtuDataAddr->Fm_Save_Eve.yueLiuLiang>>24)&0xff;
			RtuDataAddr->Event_Save.Event.Err32.Now_LiuLiang[2]=(RtuDataAddr->Fm_Save_Eve.yueLiuLiang>>16)&0xff;
			RtuDataAddr->Event_Save.Event.Err32.Now_LiuLiang[1]=(RtuDataAddr->Fm_Save_Eve.yueLiuLiang>>8)&0xff;
			RtuDataAddr->Event_Save.Event.Err32.Now_LiuLiang[0]=(RtuDataAddr->Fm_Save_Eve.yueLiuLiang)&0xff;
			RtuDataAddr->Event_Save.Event.Err32.Set_LiuLiang[3]=RtuDataAddr->Fk_Control_Set_Value.F36_Set_Para.Yue_LiuLiang_MenXian[3];
			RtuDataAddr->Event_Save.Event.Err32.Set_LiuLiang[2]=RtuDataAddr->Fk_Control_Set_Value.F36_Set_Para.Yue_LiuLiang_MenXian[2];
			RtuDataAddr->Event_Save.Event.Err32.Set_LiuLiang[1]=RtuDataAddr->Fk_Control_Set_Value.F36_Set_Para.Yue_LiuLiang_MenXian[1];
			RtuDataAddr->Event_Save.Event.Err32.Set_LiuLiang[0]=RtuDataAddr->Fk_Control_Set_Value.F36_Set_Para.Yue_LiuLiang_MenXian[0];
			if(RtuDataAddr->Event_Value.F9_Set_Para.Event_Level[3]&0x80)//��Ҫ�¼�
			{
				SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err32.Occur_Time.BCD01,1,32);
			}
			else//һ���¼�
			{
				SaveEveBuff(&RtuDataAddr->Event_Save.Event.Err32.Occur_Time.BCD01,2,32);
			}
		}
	}
}
void Liuliang()
{
	unsigned int Yue_LiuLiang_MenXian;
	Yue_LiuLiang_MenXian=RtuDataAddr->Fk_Control_Set_Value.F36_Set_Para.Yue_LiuLiang_MenXian[3]<<24;
	Yue_LiuLiang_MenXian=Yue_LiuLiang_MenXian+(RtuDataAddr->Fk_Control_Set_Value.F36_Set_Para.Yue_LiuLiang_MenXian[2]<<16);
	Yue_LiuLiang_MenXian=Yue_LiuLiang_MenXian+(RtuDataAddr->Fk_Control_Set_Value.F36_Set_Para.Yue_LiuLiang_MenXian[1]<<8);
	Yue_LiuLiang_MenXian=Yue_LiuLiang_MenXian+(RtuDataAddr->Fk_Control_Set_Value.F36_Set_Para.Yue_LiuLiang_MenXian[0]);
	if (Yue_LiuLiang_MenXian >0)
	{
		if(RtuDataAddr->Fm_Save_Eve.yueLiuLiang>=Yue_LiuLiang_MenXian)
		{
			Liuliang_flag=1;
			if(Liuliang_flag!=Liuliang_oldflag)
			{
				CreateErr32();
				Liuliang_oldflag=Liuliang_flag;
			}
		}
		else
		{
			Liuliang_flag=0;
			Liuliang_oldflag=0;
		}
	}
}
void SaveZJLastMin_DianLiang()
{
	SaveFile((INT8U *)"/nand/save/zjlastmin_dianliang.sav",(INT8U *)RtuDataAddr->LastDianliang_Value,sizeof(RtuDataAddr->LastDianliang_Value));
}
void ReadZJLastMin_DianLiang()
{
	if(ReadFile((INT8U *)"/nand/save/zjlastmin_dianliang.sav",(INT8U *)RtuDataAddr->LastDianliang_Value,sizeof(RtuDataAddr->LastDianliang_Value)))
	{
		memset(RtuDataAddr->LastDianliang_Value,0,sizeof(RtuDataAddr->LastDianliang_Value));
		SaveZJLastMin_DianLiang();
	}
}
void mydelay(int s)
{
	int i;
	for(i=0; i<s; i++)
	{
		CleardeadCount();
		delay(1000);
	}
}
void InitDay_U_MaxMin(TS ts)//��ʼ����ͳ�����ݣ���ѹ�����Сֵ������ʱ�䣬ͳ�Ƽ�������
{
	unsigned char i;
	for(i=0;i<CeLiangPoint_Max;i++)
	{
		RtuDataAddr->F27_28_29_30_Mem[i].DUUMAX = RtuDataAddr->DD_Device_BiaoShi_Value[i].VA;//FkDdRealData
		TimeGetType18(RtuDataAddr->F27_28_29_30_Mem[i].DUUMAX_TIME,ts);
		RtuDataAddr->F27_28_29_30_Mem[i].DUVMAX = RtuDataAddr->DD_Device_BiaoShi_Value[i].VB;
		TimeGetType18(RtuDataAddr->F27_28_29_30_Mem[i].DUVMAX_TIME,ts);
		RtuDataAddr->F27_28_29_30_Mem[i].DUWMAX = RtuDataAddr->DD_Device_BiaoShi_Value[i].VC;
		TimeGetType18(RtuDataAddr->F27_28_29_30_Mem[i].DUWMAX_TIME,ts);

		RtuDataAddr->F27_28_29_30_Mem[i].DUUMIN = RtuDataAddr->DD_Device_BiaoShi_Value[i].VA;
		TimeGetType18(RtuDataAddr->F27_28_29_30_Mem[i].DUUMIN_TIME,ts);
		RtuDataAddr->F27_28_29_30_Mem[i].DUVMIN = RtuDataAddr->DD_Device_BiaoShi_Value[i].VB;
		TimeGetType18(RtuDataAddr->F27_28_29_30_Mem[i].DUVMIN_TIME,ts);
		RtuDataAddr->F27_28_29_30_Mem[i].DUWMIN = RtuDataAddr->DD_Device_BiaoShi_Value[i].VC;
		TimeGetType18(RtuDataAddr->F27_28_29_30_Mem[i].DUWMIN_TIME,ts);
		RtuDataAddr->F27_28_29_30_Mem[i].USSU_Count =0;
		RtuDataAddr->F27_28_29_30_Mem[i].USU_Count =0;
		RtuDataAddr->F27_28_29_30_Mem[i].UXXU_Count =0;
		RtuDataAddr->F27_28_29_30_Mem[i].UXU_Count =0;
		RtuDataAddr->F27_28_29_30_Mem[i].UHGU_Count =0;
		RtuDataAddr->F27_28_29_30_Mem[i].USSV_Count =0;
		RtuDataAddr->F27_28_29_30_Mem[i].USV_Count =0;
		RtuDataAddr->F27_28_29_30_Mem[i].UXXV_Count =0;
		RtuDataAddr->F27_28_29_30_Mem[i].UXV_Count =0;
		RtuDataAddr->F27_28_29_30_Mem[i].UHGV_Count =0;
		RtuDataAddr->F27_28_29_30_Mem[i].USSW_Count =0;
		RtuDataAddr->F27_28_29_30_Mem[i].USW_Count =0;
		RtuDataAddr->F27_28_29_30_Mem[i].UXXW_Count =0;
		RtuDataAddr->F27_28_29_30_Mem[i].UXW_Count =0;
		RtuDataAddr->F27_28_29_30_Mem[i].UHGW_Count =0;
		RtuDataAddr->F27_28_29_30_Mem[i].U_A_Sum = 0;
		RtuDataAddr->F27_28_29_30_Mem[i].U_B_Sum = 0;
		RtuDataAddr->F27_28_29_30_Mem[i].U_C_Sum = 0;
		RtuDataAddr->F27_28_29_30_Mem[i].V_UNBALANCE_Count =0;
	}
}
void InitYu_U_MaxMin(TS ts)//��ʼ����ͳ�����ݣ���ѹ�����Сֵ������ʱ�䣬ͳ�Ƽ�������
{
	unsigned char i;
	for(i=0;i<CeLiangPoint_Max;i++)
	{
		RtuDataAddr->YF27_28_29_30_Mem[i].DUUMAX = RtuDataAddr->DD_Device_BiaoShi_Value[i].VA;
		TimeGetType18(RtuDataAddr->YF27_28_29_30_Mem[i].DUUMAX_TIME,ts);
		RtuDataAddr->YF27_28_29_30_Mem[i].DUVMAX = RtuDataAddr->DD_Device_BiaoShi_Value[i].VB;
		TimeGetType18(RtuDataAddr->YF27_28_29_30_Mem[i].DUVMAX_TIME,ts);
		RtuDataAddr->YF27_28_29_30_Mem[i].DUWMAX = RtuDataAddr->DD_Device_BiaoShi_Value[i].VC;
		TimeGetType18(RtuDataAddr->YF27_28_29_30_Mem[i].DUWMAX_TIME,ts);

		RtuDataAddr->YF27_28_29_30_Mem[i].DUUMIN = RtuDataAddr->DD_Device_BiaoShi_Value[i].VA;
		TimeGetType18(RtuDataAddr->YF27_28_29_30_Mem[i].DUUMIN_TIME,ts);
		RtuDataAddr->YF27_28_29_30_Mem[i].DUVMIN = RtuDataAddr->DD_Device_BiaoShi_Value[i].VB;
		TimeGetType18(RtuDataAddr->YF27_28_29_30_Mem[i].DUVMIN_TIME,ts);
		RtuDataAddr->YF27_28_29_30_Mem[i].DUWMIN = RtuDataAddr->DD_Device_BiaoShi_Value[i].VC;
		TimeGetType18(RtuDataAddr->YF27_28_29_30_Mem[i].DUWMIN_TIME,ts);
		RtuDataAddr->YF27_28_29_30_Mem[i].USSU_Count =0;
		RtuDataAddr->YF27_28_29_30_Mem[i].USU_Count =0;
		RtuDataAddr->YF27_28_29_30_Mem[i].UXXU_Count =0;
		RtuDataAddr->YF27_28_29_30_Mem[i].UXU_Count =0;
		RtuDataAddr->YF27_28_29_30_Mem[i].UHGU_Count =0;
		RtuDataAddr->YF27_28_29_30_Mem[i].USSV_Count =0;
		RtuDataAddr->YF27_28_29_30_Mem[i].USV_Count =0;
		RtuDataAddr->YF27_28_29_30_Mem[i].UXXV_Count =0;
		RtuDataAddr->YF27_28_29_30_Mem[i].UXV_Count =0;
		RtuDataAddr->YF27_28_29_30_Mem[i].UHGV_Count =0;
		RtuDataAddr->YF27_28_29_30_Mem[i].USSW_Count =0;
		RtuDataAddr->YF27_28_29_30_Mem[i].USW_Count =0;
		RtuDataAddr->YF27_28_29_30_Mem[i].UXXW_Count =0;
		RtuDataAddr->YF27_28_29_30_Mem[i].UXW_Count =0;
		RtuDataAddr->YF27_28_29_30_Mem[i].UHGW_Count =0;
		RtuDataAddr->YF27_28_29_30_Mem[i].U_A_Sum = 0;
		RtuDataAddr->YF27_28_29_30_Mem[i].U_B_Sum = 0;
		RtuDataAddr->YF27_28_29_30_Mem[i].U_C_Sum = 0;
		RtuDataAddr->YF27_28_29_30_Mem[i].V_UNBALANCE_Count =0;
	}
}

void GetPoint0Value()// ��ȡ������0���ն˱�������������
{
	int i,point;
	for (i=0;i<DD_Device_Max;i++)
	{
		//fprintf(stderr,"\n\r F10-PARA Meter[%d].guiyue = %d",i,RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].GuiYue_Type);
		if (RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].GuiYue_Type == JiaoLiuType)
		//if (RtuDataAddr->Meter_Para.Dian_Meter[i].GuiYue_Type == JiaoLiuType)
		{
			//point = RtuDataAddr->Meter_Para.Dian_Meter[i].CeLiangNo - 1;
			//fprintf(stderr,"\n\r F10-PARA Meter[%d].guiyue = 2",i);
			point = RtuDataAddr->FkInput_Value.F10_Set_Para.Dian_Meter[i].CeLiangNo -1;
			RtuDataAddr->DD_Device_BiaoShi_Value[point].VA = RtuDataAddr->FkDdRealData.VA;
			RtuDataAddr->DD_Device_BiaoShi_Value[point].VB = RtuDataAddr->FkDdRealData.VB;
			RtuDataAddr->DD_Device_BiaoShi_Value[point].VC = RtuDataAddr->FkDdRealData.VC;
			RtuDataAddr->DD_Device_BiaoShi_Value[point].IA = RtuDataAddr->FkDdRealData.IA;
			RtuDataAddr->DD_Device_BiaoShi_Value[point].IB = RtuDataAddr->FkDdRealData.IB;
			RtuDataAddr->DD_Device_BiaoShi_Value[point].IC = RtuDataAddr->FkDdRealData.IC;
			RtuDataAddr->DD_Device_BiaoShi_Value[point].Cos = RtuDataAddr->FkDdRealData.Cos;
			RtuDataAddr->DD_Device_BiaoShi_Value[point].CosA = RtuDataAddr->FkDdRealData.CosA;
			RtuDataAddr->DD_Device_BiaoShi_Value[point].CosB = RtuDataAddr->FkDdRealData.CosB;
			RtuDataAddr->DD_Device_BiaoShi_Value[point].CosC = RtuDataAddr->FkDdRealData.CosC;
			RtuDataAddr->DD_Device_BiaoShi_Value[point].P = RtuDataAddr->FkDdRealData.P;
			RtuDataAddr->DD_Device_BiaoShi_Value[point].PA = RtuDataAddr->FkDdRealData.PA;
			RtuDataAddr->DD_Device_BiaoShi_Value[point].PB = RtuDataAddr->FkDdRealData.PB;
			RtuDataAddr->DD_Device_BiaoShi_Value[point].PC = RtuDataAddr->FkDdRealData.PC;
			RtuDataAddr->DD_Device_BiaoShi_Value[point].Q = RtuDataAddr->FkDdRealData.Q;
			RtuDataAddr->DD_Device_BiaoShi_Value[point].QA = RtuDataAddr->FkDdRealData.QA;
			RtuDataAddr->DD_Device_BiaoShi_Value[point].QB = RtuDataAddr->FkDdRealData.QB;
			RtuDataAddr->DD_Device_BiaoShi_Value[point].QC = RtuDataAddr->FkDdRealData.QC;
			break;
		}
	}
}
INT8U CompDate(INT8U Day,INT8U BCDay)
{
	INT8U tday = ((BCDay & 0xf0) >> 4) *10 + (BCDay & 0x0f);
	if (Day == tday)
	    return 0;
	else
		return 1;
}
//ͳ�������ݳ�ʼ��                        ���ȴ��ļ��ж�ȡʵʱ�����ͳ����ֵ���������ʱ����Ч������ʹ��
//														     ������ݴ洢ʱ�����ֵ����ʱ����Ч������ʼ��ͳ����ֵΪ��ǰ��ֵ
void InitDayTongji()
{
	TS nowts;
	SAVETONGJI_TYPE    filedata;
	INT8U i;
	INT8U baddata = 0;
	TSGet(&nowts);
	ReadFile((INT8U *)"/nand/save/tongji_day.tmp",(INT8U *)&filedata,sizeof(SAVETONGJI_TYPE));
	if ((nowts.Year==filedata.SaveTime.Year)&&(nowts.Month==filedata.SaveTime.Month)&&(nowts.Day ==filedata.SaveTime.Day))//CompDate(nowts,filedata.SaveTime)==1)
	{//�ж�����ʱ����Ч  �˶� �ꡢ�¡���
		fprintf(stderr,"\n\r read day-tmp data is ok!!");
		for(i=0;i<CeLiangPoint_Max;i++)
		{//�ж���ֵ����ʱ���Ƿ���Ч���˶� ��
			if ((CompDate(nowts.Day ,filedata.TongjiData[i].DUUMAX_TIME[2])==1)||
				(CompDate(nowts.Day ,filedata.TongjiData[i].DUUMIN_TIME[2])==1)||
				(CompDate(nowts.Day ,filedata.TongjiData[i].DUVMAX_TIME[2])==1)||
				(CompDate(nowts.Day ,filedata.TongjiData[i].DUVMIN_TIME[2])==1)||
				(CompDate(nowts.Day ,filedata.TongjiData[i].DUWMAX_TIME[2])==1)||
				(CompDate(nowts.Day ,filedata.TongjiData[i].DUWMIN_TIME[2])==1)
			   )
			{
				fprintf(stderr,"\n\r but day-tmp %d point is bad!! ",i);
				fprintf(stderr,"\n\r [ nowts.day=%d   UA-MAXDAY %x]",nowts.Day,filedata.TongjiData[i].DUUMAX_TIME[2]);
				fprintf(stderr,"\n\r [ nowts.day=%d   UA-MINDAY %x]",nowts.Day,filedata.TongjiData[i].DUUMIN_TIME[2]);
				fprintf(stderr,"\n\r [ nowts.day=%d   UB-MAXDAY %x]",nowts.Day,filedata.TongjiData[i].DUVMAX_TIME[2]);
				fprintf(stderr,"\n\r [ nowts.day=%d   UB-MINDAY %x]",nowts.Day,filedata.TongjiData[i].DUVMIN_TIME[2]);
				fprintf(stderr,"\n\r [ nowts.day=%d   UC-MAXDAY %x]",nowts.Day,filedata.TongjiData[i].DUWMAX_TIME[2]);
				fprintf(stderr,"\n\r [ nowts.day=%d   UC-MINDAY %x]",nowts.Day,filedata.TongjiData[i].DUWMIN_TIME[2]);

				baddata = 1;
				break;
			}
			RtuDataAddr->F27_28_29_30_Mem[i] = filedata.TongjiData[i];
		}
		if (baddata==1)
		{
			fprintf(stderr,"\n\r baddata !! INITDAY tongji");
			InitDay_U_MaxMin(nowts);
		}
	}else
	{
		InitDay_U_MaxMin(nowts);
		fprintf(stderr,"\n\r Save time is wrong !! INITDAY tongji [%d-%d-%d]",filedata.SaveTime.Year,filedata.SaveTime.Month,filedata.SaveTime.Day);
		fprintf(stderr,"\n\r nowtime [%d-%d-%d]",nowts.Year,nowts.Month,nowts.Day);
	}
	return;
}
//ͳ�������ݳ�ʼ��                        ���ȴ��ļ��ж�ȡʵʱ�����ͳ����ֵ���������ʱ����Ч������ʹ��
//														     ������ݴ洢ʱ�����ֵ����ʱ����Ч������ʼ��ͳ����ֵΪ��ǰ��ֵ
void InitYueTongji()
{
	TS nowts;
	SAVETONGJI_TYPE    filedata;
	INT8U i;
	TSGet(&nowts);
	ReadFile((INT8U *)"/nand/save/tongji_yue.tmp",(INT8U *)&filedata,sizeof(SAVETONGJI_TYPE));
	if ((nowts.Year==filedata.SaveTime.Year)&&(nowts.Month==filedata.SaveTime.Month))
	{//�ж�����ʱ����Ч   �˶� �� ����
		for(i=0;i<CeLiangPoint_Max;i++)
		{
			RtuDataAddr->YF27_28_29_30_Mem[i] = filedata.TongjiData[i];
		}
	}else
	{
		InitYu_U_MaxMin(nowts);
	}
	return;
}

int main(int argc, char *argv[]) {
	struct sigaction sa1;
	INT8U Min,Day,Month,i;//,CalcCount;
	TS ts;
	MeterCalc=0;
	//CalcCount = 0;

	markver();
	if(OpenMem())return EXIT_FAILURE;
	if(RtuDataAddr->mem_len!=sizeof(RTimeData))
	{
		DataCalcDbg(  "base mem uncompared prog will exit %d :\n",sizeof(RTimeData));
		return EXIT_FAILURE;
	}
	DataCalcDbg("step2");
	if(!PARSE_CMD(argc, argv))
	{
		return EXIT_FAILURE;
	}
	DataCalcDbg("step3");
	sa1.sa_handler = QuitProcess;
	sigemptyset(&sa1.sa_mask);
	sa1.sa_flags = 0;
	sigaction(SIGTERM, &sa1,NULL);
	sigaction(SIGSYS, &sa1,NULL);
	sigaction(SIGPWR, &sa1,NULL);
	sigaction(SIGKILL, &sa1,NULL);
	sigaction(SIGQUIT, &sa1,NULL);
	sigaction(SIGILL, &sa1,NULL);
	sigaction(SIGINT, &sa1,NULL);
	sigaction(SIGHUP, &sa1,NULL);
	sigaction(SIGABRT, &sa1,NULL);
	sigaction(SIGBUS, &sa1,NULL);
	DataCalcDbg("step4@@@@@");
	RtuDataAddr->stPortPara[PORT_ID].PID=getpid();

 	while(RtuDataAddr->Dev_Init_OK==0)
	{
		CleardeadCount();
		delay(1000);
	}
	for(i=0;i<CeLiangPoint_Max;i++)
	{
		a_ussx_last_time[i] = 0;
		a_uxxx_last_time[i] = 0;
		b_ussx_last_time[i] = 0;
		b_uxxx_last_time[i] = 0;
		c_ussx_last_time[i] = 0;
		c_uxxx_last_time[i] = 0;

		RtuDataAddr->CL_ERR[i].Old_PDD=RtuDataAddr->DD_Device_BiaoShi_Value[i].Z_P_All;
		TingZhouCount[i] = 0;
	}
	for(i=0;i<ZongJia_Max;i++)
	{
		RtuDataAddr->Gou_Dian_Kong_Value[i].LastMin_DianLiang=RtuDataAddr->Real_Zj_Value[i].P_All;
	}
	RtuDataAddr->ERRJiaoCai=0;
	RtuDataAddr->ERR11JiaoCai=0;
	memset(RtuDataAddr->ERR10_1HeGeErr,0,CeLiangPoint_Max);
	memset(RtuDataAddr->ERR10_2HeGeErr,0,CeLiangPoint_Max);
	CAfp = NULL;
	CAfp =  fopen("/nand/fkcalc.log","a+");

	mydelay(5);
	TSGet(&ts);
	Min = ts.Minute;
	Day = ts.Day;
	Month = ts.Month;
	GetPoint0Value();
	InitDayTongji();
	InitYueTongji();
  	for (;;)
   	{
  		CleardeadCount();
		TSGet(&ts);
		Zj_Data_Calc();
		HeGeTongJi();
		Liuliang();

		if(ts.Minute!=Min)
		{//1����
			GetPoint0Value();
			XiangXuYiChang();//��7022B�Ĵ����ж������쳣�¼�
			IHuiLuYiChang();  //�жϽ������������͹���������������·�쳣�¼�
			CalcShengyuDianliang();//�����ܼ���Ͷ����ʱ��ʣ�����
			MeterCalc++;
			SaveZjHcBuff();
			//F27_28_29_30Calc();//ԭ�������ѹ�ϸ�����
			F27_28_35_36Calc();//��������ѹ�ϸ�����
			Cl_Xl_Calc();
			Day_Data_Calc();
			Yue_Data_Calc();
			Min=ts.Minute;
			CalcTingZouErr();
			CalcDiannengErr();
		}
//		if(ts.Day!=Day)
//		{
//			InitDay_U_MaxMin(ts);
//			Day=ts.Day;
//		}
//		if(ts.Month!=Month)
//		{
//			InitYu_U_MaxMin(ts);
//			Month=ts.Month;
//		}

  		delay(1000);
       	CleardeadCount();
   	}
  	name_detach(attach, 0);
 	return EXIT_SUCCESS;
}
