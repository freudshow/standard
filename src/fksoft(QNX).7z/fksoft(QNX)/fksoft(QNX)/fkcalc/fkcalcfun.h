#ifndef FKCALCFUN_H_
#define FKCALCFUN_H_
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <ctype.h>
#include <time.h>
#include <signal.h>
#include <sys/sched.h>
#include <semaphore.h>
#include <process.h>
#include <sys/neutrino.h>
#include <sys/netmgr.h>
#include <sys/dispatch.h>
#include <errno.h>
#include <netdb.h>
#include <hw/inout.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <math.h>
#include <fkbase/memdef.h>
#include <fkbase/fkbasefun.h>

#define DataCalcDbg if(RtuDataAddr->DATACALCDBON)printf

FILE *CAfp;
#define CAPrint(...) fprintf(CAfp, __VA_ARGS__);fflush(CAfp);
typedef struct
{
	F27_28_29_30_level_stru   TongjiData[CeLiangPoint_Max];
	TS                        SaveTime;
}SAVETONGJI_TYPE;
RTimeData  *RtuDataAddr;//�ڴ湲��������ָ��
name_attach_t *attach;
INT8U PORT_ID;
INT16U MeterCalc;
INT8U TmpFkStat,UFkStat;
INT32U IJA,IJB,IJC,UJA,UJB,UJC;

INT8U Liuliang_flag=0;
INT8U Liuliang_oldflag=0;
INT8U TingZhouCount[8];
INT8U firstflag=0;
int setupTimer();
void QuitProcess(int signo);
void TimeGetType18(INT8U *D,TS ts);
void TimeGetType20(INT8U *D,TS ts);
INT32U MaxValue(INT32U a,INT32U b,INT32U c);
INT32S Get_BianBi(INT8U ClNo);
void Calc_Day_Bs_zj();
void Calc_Yue_Bs_zj();
void Zj_Data_Calc();
//�ܼ��黬���--------------
void SaveZjHcBuff();
void Get_Now_type18(Data_Type_18 *Dest);
void Cl_Xl_Calc();
void Day_Data_Calc();
void Yue_Data_Calc();
void JugeDianYaEven(unsigned char  Flag ,int i,unsigned char *OldErr);
void CalcDiannengErr();
void F27_28_29_30Calc();
void F27_28_35_36Calc();
void HeGeTongJi();

#endif /*FKCALCFUN_H_*/
