/*
 * erc.h
 *
 *  Created on: 2010-3-13
 *      Author: Administrator
 */

#ifndef ERC_H_
#define ERC_H_
#include "datatype_ext.h"

typedef struct
{
	unsigned char ERCNo;
	unsigned char len;
	Data_Type_15 Occur_Time;
	unsigned char BiaoZhi;
	unsigned char Old_Ver[4];
	unsigned char New_Ver[4];
}ERC1;
typedef struct
{
	unsigned char ERCNo;
	unsigned char len;
	Data_Type_15 Occur_Time;
	unsigned char BiaoZhi;
}ERC2;
typedef struct
{
	unsigned char ERCNo;
	unsigned char len;
	Data_Type_15 Occur_Time;
	unsigned char QiDong_Addr;
	unsigned char DanYuan[4];
}ERC3;
typedef struct
{
	unsigned char ERCNo;
	unsigned char len;
	Data_Type_15 Occur_Time;
	unsigned char Chg_Stat;
	unsigned char New_Stat;
}ERC4;
typedef struct
{
	unsigned char ERCNo;
	unsigned char len;
	Data_Type_15 Occur_Time;
	unsigned char LunCi;
	unsigned char P[2];
	unsigned char Delay_2_P[2];
}ERC5;
typedef struct
{
	unsigned char ERCNo;
	unsigned char len;
	Data_Type_15 Occur_Time;
	unsigned char ZongJIaNo;
	unsigned char LunCi;
	unsigned char KongLeiBie;
	unsigned char P_Old[2];
	unsigned char Delay_2_P[2];
	unsigned char P_DingZhi[2];
}ERC6;
typedef struct
{
	unsigned char ERCNo;
	unsigned char len;
	Data_Type_15 Occur_Time;
	unsigned char ZongJIaNo;
	unsigned char LunCi;
	unsigned char KongLeiBie;
	unsigned char DD_Old[4];
	unsigned char DD_DingZhi[4];
}ERC7;
typedef struct
{
	unsigned char ERCNo;
	unsigned char len;
	Data_Type_15 Occur_Time;
	unsigned char ClNo[2];
	unsigned char BiaoZhi;
}ERC8;
typedef struct
{
	unsigned char ERCNo;
	unsigned char len;
	Data_Type_15 Occur_Time;
	unsigned char ClNo[2];
	unsigned char BiaoZhi;
	unsigned char UA[2];
	unsigned char UB[2];
	unsigned char UC[2];
	unsigned char IA[3];
	unsigned char IB[3];
	unsigned char IC[3];
	unsigned char PDD[5];
}ERC9;
typedef struct
{
	unsigned char ERCNo;
	unsigned char len;
	Data_Type_15 Occur_Time;
	unsigned char ClNo[2];
	unsigned char BiaoZhi;
	unsigned char UA[2];
	unsigned char UB[2];
	unsigned char UC[2];
	unsigned char IA[3];
	unsigned char IB[3];
	unsigned char IC[3];
	unsigned char PDD[5];
}ERC10;
typedef struct
{
	unsigned char ERCNo;
	unsigned char len;
	Data_Type_15 Occur_Time;
	unsigned char ClNo[2];
	unsigned char UAj[2];
	unsigned char UBj[2];
	unsigned char UCj[2];
	unsigned char IAj[2];
	unsigned char IBj[2];
	unsigned char ICj[2];
	unsigned char PDD[5];
}ERC11;
typedef struct
{
	unsigned char ERCNo;
	unsigned char len;
	Data_Type_15 Occur_Time;
	unsigned char ClNo[2];
}ERC12;
typedef struct
{
	unsigned char ERCNo;
	unsigned char len;
	Data_Type_15 Occur_Time;
	unsigned char ClNo[2];
	unsigned char Biaozhi;
}ERC13;
typedef struct
{
	unsigned char ERCNo;
	unsigned char len;
	Data_Type_15 Ting_Time;
	Data_Type_15 Shang_Time;
}ERC14;
typedef struct
{
	unsigned char ERCNo;
	unsigned char len;
	Data_Type_15 Occur_Time;
	unsigned char ClNo[2];
	unsigned char Flag;
	unsigned char UBalance[2];
	unsigned char IBalance[2];
	unsigned char UA[2];
	unsigned char UB[2];
	unsigned char UC[2];
	unsigned char IA[3];
	unsigned char IB[3];
	unsigned char IC[3];
}ERC17;
typedef struct
{
	unsigned char ERCNo;
	unsigned char len;
	Data_Type_15 Occur_Time;
	unsigned char ZjNo;
	unsigned char DanHao[4];
	unsigned char Zj_Sx_BiaoZhi;
	unsigned char Gou_DD[4];
	unsigned char Bj_Men[4];
	unsigned char TZ_Men[4];
	unsigned char Old_DD[4];
	unsigned char New_DD[4];
}ERC19;
typedef struct
{
	unsigned char ERCNo;
	unsigned char len;
	Data_Type_15 Occur_Time;
	unsigned char PW[2];
	unsigned char Msa_Add;
}ERC20;
typedef struct
{
	unsigned char ERCNo;
	unsigned char len;
	Data_Type_15 Occur_Time;
	unsigned char Code;
}ERC21;
typedef struct
{
	unsigned char ERCNo;
	unsigned char len;
	Data_Type_15 Occur_Time;
	unsigned char ChaDongZuHao;
	unsigned char DuiBiP_DD[4];
	unsigned char CanZhaoP_DD[4];
	unsigned char XiangDuiPianCha;
	unsigned char JueDuiPianCha[4];
	unsigned char ClBuff[64];
}ERC22;
typedef struct
{
	unsigned char ERCNo;
	unsigned char len;
	Data_Type_15 Occur_Time;
	unsigned char ClNo[2];
	unsigned char Flag;
	unsigned char UA[2];
	unsigned char UB[2];
	unsigned char UC[2];
}ERC24;
typedef struct
{
	unsigned char ERCNo;
	unsigned char len;
	Data_Type_15 Occur_Time;
	unsigned char ClNo[2];
	unsigned char Flag;
	unsigned char IA[3];
	unsigned char IB[3];
	unsigned char IC[3];
}ERC25;
typedef struct
{
	unsigned char ERCNo;
	unsigned char len;
	Data_Type_15 Occur_Time;
	unsigned char ClNo[2];
	unsigned char Flag;
	unsigned char Curr_S[3];
	unsigned char S_SS[3];
}ERC26;
typedef struct
{
	unsigned char ERCNo;
	unsigned char len;
	Data_Type_15 Occur_Time;
	unsigned char ClNo[2];
	unsigned char Old_ShiZhi[5];
	unsigned char New_ShiZhi[5];
}ERC27;
typedef struct
{
	unsigned char ERCNo;
	unsigned char len;
	Data_Type_15 Occur_Time;
	unsigned char ClNo[2];
	unsigned char Old_ShiZhi[5];
	unsigned char New_ShiZhi[5];
	unsigned char Fazhi;
}ERC28;
typedef struct
{
	unsigned char ERCNo;
	unsigned char len;
	Data_Type_15 Occur_Time;
	unsigned char ClNo[2];
	unsigned char Old_ShiZhi[5];
	unsigned char New_ShiZhi[5];
	unsigned char Fazhi;
}ERC29;
typedef struct
{
	unsigned char ERCNo;
	unsigned char len;
	Data_Type_15 Occur_Time;
	unsigned char ClNo[2];
	unsigned char Old_ShiZhi[5];
	unsigned char Fazhi;
}ERC30;
typedef struct
{
	unsigned char ERCNo;
	unsigned char len;
	Data_Type_15 Occur_Time;
	unsigned char ClNo[2];
	unsigned char Last_OK[5];
	unsigned char Last_Value_P[5];
	unsigned char Last_Value_Q[4];
}ERC31;
typedef struct
{
	unsigned char ERCNo;
	unsigned char len;
	Data_Type_15 Occur_Time;
	unsigned char Now_LiuLiang[4];
	unsigned char Set_LiuLiang[4];
}ERC32;
typedef struct
{
	unsigned char ERCNo;
	unsigned char len;
	Data_Type_15 Occur_Time;
	unsigned char ClNo[2];
	unsigned char statChg[14];
	unsigned char statN[14];
}ERC33;
typedef struct
{
	unsigned char ERCNo;
	unsigned char len;
	Data_Type_15 Occur_Time;
	unsigned char Local[4];
}ERC60;
typedef union{
	unsigned char Buff[128];
	ERC1 Err1;
	ERC2 Err2;
	ERC3 Err3;
	ERC4 Err4;
	ERC5 Err5;
	ERC6 Err6;
	ERC7 Err7;
	ERC8 Err8;
	ERC9 Err9;
	ERC10 Err10;
	ERC11 Err11;
	ERC12 Err12;
	ERC13 Err13;
	ERC14 Err14;
	ERC17 Err17;
	ERC19 Err19;
	ERC20 Err20;
	ERC21 Err21;
	ERC22 Err22;
	ERC24 Err24;
	ERC25 Err25;
	ERC26 Err26;
	ERC27 Err27;
	ERC28 Err28;
	ERC29 Err29;
	ERC30 Err30;
	ERC31 Err31;
	ERC32 Err32;
	ERC33 Err33;
	ERC60 Err60;
}ERC;

typedef struct SErcSave
{
	INT8U			EC1,EC2,EC1old,EC2old;		//�¼�������
	ERC				ImpEvent[256];			//��Ҫ�¼�
	ERC				NorEvent[256];			//��ͨ�¼�
	INT8U			ERCBiaoZhi[8];
}ErcSave;

#endif /* ERC_H_ */
