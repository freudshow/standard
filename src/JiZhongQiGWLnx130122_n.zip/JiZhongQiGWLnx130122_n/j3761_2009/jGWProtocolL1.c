/*
 *
 *   ������Լ�ӿں�������
 *       ������Լ���Ĵ���ģ����ýӿں����������Ӧ��������
 *       ������Լ���Ĵ���ģ����ýӿں�����������վ�·�����
 *
 *///-------------------------------------------------------------

#include "time.h"
#include <sys/mman.h>
#include <unistd.h>
#include "jGWProtocol.h"
//#include "inc/init.h"
#include "../jBase/inc/pubfunction.h"
#include "innerPubVar.h"

//extern void TSGet(TS *ts);
extern void TSSet(TS ts);
extern void TimeAdd(TS *ts, INT16U unit, int step);
extern int IsEqual(TS *ts0, TS *ts1);
extern INT32S BCD_INT32(INT8U *buf, INT8U len);
extern void INT32U_BCD(INT32S data, INT8U *buf, INT8U len);


//��ȡ��������й������޹������ݣ����������Detect_pointNum������ţ�Postive_flag�������־��is_youGong�й��޹����ʱ�־
INT32S Calculate_total_GongLv_Curr(INT8U Detect_pointNum, INT16U Postive_flag,
		INT8U is_youGong)
{
	INT32S _result = 0;//�������ݵ�ֵ
	INT8U temp_result[4];//��ǰһ����������й����ʣ�2���ֽ�
	INT8U CJQno, MeterNo, MeterType;
	INT16U i, IsDataFlag,tmp,tmp2;
	INT8U Temp_FilePath[60], tempManyData[DataLenMax];

	SdPrintf(YNPrint,PreFix,"Calculate_total_GongLv_Curr=%d\n\r",Detect_pointNum);
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[Detect_pointNum].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[Detect_pointNum].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[Detect_pointNum].Type;

	LDType=2;
	memset(temp_result,0x00,4);
	memset(Temp_FilePath,0,60);
	sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",Detect_pointNum+1);
	ReadFile((char *) Temp_FilePath, &smfile,sizeof(SMFiles),Jproginfo);
	if ((MeterType == 9) || (MeterType == 6)) {//�����
		IsDataFlag = 0;
		if (smfile.sm.CaijiQiNo==CJQno&&smfile.sm.MeterNo==MeterNo) {
			IsDataFlag = 1;
			memset(tempManyData, 0, sizeof(tempManyData));
			if (is_youGong)//��ȡ��������й��������ݣ���ӦF17��ȡ����
			{
				if (!Postive_flag) {
					GetManyData(0,smfile.sm.datas, &tempManyData[0],
							0xb6, 0x31);
				} else {
					GetManyData(0,smfile.sm.datas, &tempManyData[0],
							0xb6, 0x31);
				}
			} else//��ȡ��������޹��������ݣ���ӦF18��ȡ����
			{
				if (!Postive_flag) {
					GetManyData(0,smfile.sm.datas, &tempManyData[0],
							0xb6, 0x41);
				} else {
					GetManyData(0,smfile.sm.datas, &tempManyData[0],
							0xb6, 0x41);
				}
			}
			memcpy(&temp_result[0], &tempManyData[0], 4);
		}
	}else {//�๦�ܱ�
		IsDataFlag = 0;
		if (smfile.sm.CaijiQiNo==CJQno&&smfile.sm.MeterNo==MeterNo) {
			IsDataFlag = 1;
			memset(tempManyData, 0, sizeof(tempManyData));
			if (is_youGong)//��ȡ��������й��������ݣ���ӦF17��ȡ����
			{
				if (Postive_flag) {
					GetManyData(0,smfile.sm.datas, &tempManyData[0],
							0xb6, 0x3f);
				} else {
					GetManyData(0,smfile.sm.datas, &tempManyData[0],
							0xb6, 0x3f);
				}
			} else//��ȡ��������޹��������ݣ���ӦF18��ȡ����
			{
				if (Postive_flag) {
					GetManyData(0,smfile.sm.datas, &tempManyData[0],
							0xb6, 0x4f);
				} else {
					GetManyData(0,smfile.sm.datas, &tempManyData[0],
							0xb6, 0x4f);
				}
			}
			memcpy(&temp_result[0], &tempManyData[0], 4);
		}
	}

	//temp_result[0]=0x00;temp_result[1]=0x30;temp_result[2]=0x03;
	SdPrintf(YNPrint,PreFix,"result=%02x-%02x-%02x-%02x\n\r",temp_result[0],temp_result[1],temp_result[2],temp_result[3]);
	if (is_youGong)
	{
		for(i=0;i<3;i++)
			if (temp_result[i]==OxXX)
				temp_result[i]=0x00;
		_result=BCD_INT32(&temp_result[0],3);
		SdPrintf(YNPrint,PreFix,"result=%d\n\r",_result);
	}
	else
	{
		for(i=0;i<2;i++)
			if (temp_result[i]==OxXX)
				temp_result[i]=0x00;
		_result=BCD_INT32(&temp_result[0],3);
		SdPrintf(YNPrint,PreFix,"result=%d\n\r",_result);
	}

	memcpy(&tmp,&JSetPara_AFN04_3761_2009->Point[Detect_pointNum].f25.V_BeiLv[0],2);
	memcpy(&tmp2,&JSetPara_AFN04_3761_2009->Point[Detect_pointNum].f25.I_BeiLv[0],2);
	_result=_result*tmp*tmp2;
	SdPrintf(YNPrint,PreFix,"result00000000=%d---%d---%d\n\r",_result,tmp,tmp2);
	return _result;//���ط������ĺ�����ݽ��
}

INT16U Level1Data_Curr_F17_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ�ܼ��й�����
{
	INT8U tmp_i = P - 1;//��ʱ��ѭ������
	INT8U tmp_j;
	FP64 youGong_result = 0.0;//��ǰ���й�����
	INT8U Detect_pointNum;//�������
	INT8U Postive_flag; //����/�����й����� 0:����1:����
	INT8U Sub_flag; //��/���������־ 0:�ӣ�1:��
	INT8U type2Msg[2];
	memset(type2Msg,0x00,2);
	for (tmp_j = 0; tmp_j < JSetPara_AFN04_3761_2009->group2.f14.Group[tmp_i].PointNum; tmp_j++)//�Թ����ڴ���������ò�����������з���
	{
		Detect_pointNum = (JSetPara_AFN04_3761_2009->group2.f14.Group[tmp_i].Index_Flag[tmp_j])
				& 0x3f; //D0~D5
		Postive_flag = (JSetPara_AFN04_3761_2009->group2.f14.Group[tmp_i].Index_Flag[tmp_j]) >> 6
				& 0x01; //D6
		Sub_flag = (JSetPara_AFN04_3761_2009->group2.f14.Group[tmp_i].Index_Flag[tmp_j]) >> 7
				& 0x01; //D7

		if (!Sub_flag) {
			youGong_result += Calculate_total_GongLv_Curr(Detect_pointNum,
					Postive_flag, 1);
		} else {
			youGong_result -= Calculate_total_GongLv_Curr(Detect_pointNum,
					Postive_flag, 1);
		}
	}
	Double2TypeA2(youGong_result, type2Msg);

//	if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));//����1�����ݵı���ͷ

	memcpy(&SendBuff[SendIndex], &type2Msg[0], 2);
	SendIndex = SendIndex + 2;

//	if (AutoFlg!=0) return 1;	EC();
//	TP();
//	FrameTailCreate_Send(0);//���ͱ���β��������
	return 1;
}

INT16U Level1Data_Curr_F18_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ�ܼ��޹�����
{
	INT8U tmp_i = P - 1;//��ʱ��ѭ������
	INT8U tmp_j;
	FP64 youGong_result = 0.0; //��ǰ���޹�����
	INT8U Detect_pointNum; //�������
	INT8U Postive_flag; //����/�����й����� 0:����1:����
	INT8U Sub_flag; //��/���������־ 0:�ӣ�1:��
	INT8U type2Msg[2];
	memset(type2Msg,0x00,2);
	for (tmp_j = 0; tmp_j < JSetPara_AFN04_3761_2009->group2.f14.Group[tmp_i].PointNum; tmp_j++)//�Թ����ڴ���������ò�����������з���
	{
		Detect_pointNum = (JSetPara_AFN04_3761_2009->group2.f14.Group[tmp_i].Index_Flag[tmp_j])
				& 0x3f; //D0~D5
		Postive_flag = (JSetPara_AFN04_3761_2009->group2.f14.Group[tmp_i].Index_Flag[tmp_j]) >> 6
				& 0x01; //D6
		Sub_flag = (JSetPara_AFN04_3761_2009->group2.f14.Group[tmp_i].Index_Flag[tmp_j]) >> 7
				& 0x01; //D7

		if (!Sub_flag) {
			youGong_result += Calculate_total_GongLv_Curr(Detect_pointNum,
					Postive_flag, 0);
		} else {
			youGong_result -= Calculate_total_GongLv_Curr(Detect_pointNum,
					Postive_flag, 0);
		}
	}
	Double2TypeA2(youGong_result, type2Msg);//ת�����ݸ�ʽ2����

//	if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));//����1�����ݵı���ͷ

	memcpy(&SendBuff[SendIndex], &type2Msg[0], 2);
	SendIndex = SendIndex + 2;

//	if (AutoFlg!=0)
//		return 1;
//	EC();
//	TP();
//	FrameTailCreate_Send(0);//���ͱ���β��������
	return 1;
}

INT16U Level1Data_Curr_F25_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ���༰����/�޹����ʡ����������������ѹ��������������������ڹ���
{

	TS ts;
	int i;
	SdPrintf(YNPrint,PreFix,"set:%02x F:%02x P:%02x \n", Set, F, P);
	SdPrintf(YNPrint,PreFix,"JSetPara_AFN04_3761_2009->group2.f10[P-1].ConnectType=%d  JSetPara_AFN04_3761_2009->group2.f10[P-1].port=%d\n",
			JSetPara_AFN04_3761_2009->group2.f10[P-1].ConnectType,JSetPara_AFN04_3761_2009->group2.f10[P-1].port);
	if(JSetPara_AFN04_3761_2009->group2.f10[P-1].ConnectType==2 && JSetPara_AFN04_3761_2009->group2.f10[P-1].port==1)
	{
		//���ڴ����
		SdPrintf(YNPrint,PreFix,"-----------Level1Data_Curr_F25_Get  JC from memory----------------------------------------\n");
		SetDataFlag97(0xb6, 0x30, Jproginfo->RealData.flg97[0].flg.Dataflag);
		SetDataFlag97(0xb6, 0x31, Jproginfo->RealData.flg97[1].flg.Dataflag);
		SetDataFlag97(0xb6, 0x32, Jproginfo->RealData.flg97[2].flg.Dataflag);
		SetDataFlag97(0xb6, 0x33, Jproginfo->RealData.flg97[3].flg.Dataflag);

		SetDataFlag97(0xb6, 0x40, Jproginfo->RealData.flg97[4].flg.Dataflag);
		SetDataFlag97(0xb6, 0x41, Jproginfo->RealData.flg97[5].flg.Dataflag);
		SetDataFlag97(0xb6, 0x42, Jproginfo->RealData.flg97[6].flg.Dataflag);
		SetDataFlag97(0xb6, 0x43, Jproginfo->RealData.flg97[7].flg.Dataflag);

		SetDataFlag97(0xb6, 0x50, Jproginfo->RealData.flg97[8].flg.Dataflag);
		SetDataFlag97(0xb6, 0x51, Jproginfo->RealData.flg97[9].flg.Dataflag);
		SetDataFlag97(0xb6, 0x52, Jproginfo->RealData.flg97[10].flg.Dataflag);
		SetDataFlag97(0xb6, 0x53, Jproginfo->RealData.flg97[11].flg.Dataflag);

		SetDataFlag97(0xb6, 0x11, Jproginfo->RealData.flg97[12].flg.Dataflag);
		SetDataFlag97(0xb6, 0x12, Jproginfo->RealData.flg97[13].flg.Dataflag);
		SetDataFlag97(0xb6, 0x13, Jproginfo->RealData.flg97[14].flg.Dataflag);
		SetDataFlag97(0xb6, 0x21, Jproginfo->RealData.flg97[15].flg.Dataflag);
		SetDataFlag97(0xb6, 0x22, Jproginfo->RealData.flg97[16].flg.Dataflag);
		SetDataFlag97(0xb6, 0x23, Jproginfo->RealData.flg97[17].flg.Dataflag);

		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.P, &Jproginfo->RealData.flg97[0].datas[0],3);
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.PA, &Jproginfo->RealData.flg97[1].datas[0],3);
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.PB, &Jproginfo->RealData.flg97[2].datas[0],3);
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.PC, &Jproginfo->RealData.flg97[3].datas[0],3);

		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.Q, &Jproginfo->RealData.flg97[4].datas[0],3);
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.QA, &Jproginfo->RealData.flg97[5].datas[0],3);
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.QB, &Jproginfo->RealData.flg97[6].datas[0],3);
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.QC, &Jproginfo->RealData.flg97[7].datas[0],3);

		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.Cos, &Jproginfo->RealData.flg97[8].datas[0],2);
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.CosA, &Jproginfo->RealData.flg97[9].datas[0],2);
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.CosB, &Jproginfo->RealData.flg97[10].datas[0],2);
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.CosC, &Jproginfo->RealData.flg97[11].datas[0],2);

		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.VA, &Jproginfo->RealData.flg97[12].datas[0],2);
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.VB, &Jproginfo->RealData.flg97[13].datas[0],2);
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.VC, &Jproginfo->RealData.flg97[14].datas[0],2);
//		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.IA*10, &Jproginfo->RealData.flg97[15].datas[0],3);
//		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.IB*10, &Jproginfo->RealData.flg97[16].datas[0],3);
//		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.IC*10, &Jproginfo->RealData.flg97[17].datas[0],3);
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.IA, &Jproginfo->RealData.flg97[15].datas[0],3);//LQQ
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.IB, &Jproginfo->RealData.flg97[16].datas[0],3);//LQQ
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.IC, &Jproginfo->RealData.flg97[17].datas[0],3);//LQQ
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.IL, &Jproginfo->RealData.flg97[18].datas[0],3);//LQQ

		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.S, &Jproginfo->RealData.flg97[19].datas[0],3);
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.SA, &Jproginfo->RealData.flg97[20].datas[0],3);
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.SB, &Jproginfo->RealData.flg97[21].datas[0],3);
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.SC, &Jproginfo->RealData.flg97[22].datas[0],3);
		Jproginfo->RealData.CurFlgCount = 23;
		for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		{
			SdPrintf(YNPrint," ","i: %d   datas[0] %02x %02x %02x %02x\n",
						i,
						Jproginfo->RealData.flg97[i].datas[0],
						Jproginfo->RealData.flg97[i].datas[1],
						Jproginfo->RealData.flg97[i].datas[2],
						Jproginfo->RealData.flg97[i].datas[3]);
		}
		TSGet(&ts);
//		MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
		INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[0].datas[0], 3);
		SendIndex = SendIndex + 3;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[1].datas[0], 3);
		SendIndex = SendIndex + 3;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[2].datas[0], 3);
		SendIndex = SendIndex + 3;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[3].datas[0], 3);
		SendIndex = SendIndex + 3;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[4].datas[0], 3);
		SendIndex = SendIndex + 3;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[5].datas[0], 3);
		SendIndex = SendIndex + 3;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[6].datas[0], 3);
		SendIndex = SendIndex + 3;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[7].datas[0], 3);
		SendIndex = SendIndex + 3;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[8].datas[0], 2);
		SendIndex = SendIndex + 2;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[9].datas[0], 2);
		SendIndex = SendIndex + 2;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[10].datas[0], 2);
		SendIndex = SendIndex + 2;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[11].datas[0], 2);
		SendIndex = SendIndex + 2;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[12].datas[0], 2);
		SendIndex = SendIndex + 2;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[13].datas[0], 2);
		SendIndex = SendIndex + 2;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[14].datas[0], 2);
		SendIndex = SendIndex + 2;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[15].datas[0], 3);
		SendIndex = SendIndex + 3;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[16].datas[0], 3);
		SendIndex = SendIndex + 3;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[17].datas[0], 3);
		SendIndex = SendIndex + 3;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[18].datas[0], 3);//�������
		SendIndex = SendIndex + 3;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[19].datas[0], 3);
		SendIndex = SendIndex + 3;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[20].datas[0], 3);
		SendIndex = SendIndex + 3;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[21].datas[0], 3);
		SendIndex = SendIndex + 3;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[22].datas[0], 3);
		SendIndex = SendIndex + 3;
	}else
	{
		//���ļ����
		INT8U CJQno, MeterNo, MeterType;
		INT16U IsDataFlag,dftype;
		INT8U Temp_FilePath[60];
		TS ts;
		CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
		MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
		MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
		TSGet(&ts);

		int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
		if (portn == LocalCommPort)
			portn=CarrWavePort;
//		if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));

		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
		sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",P);
		if ((MeterType == 9) || (MeterType == 6))
		{
			dftype=1;//comm
		}
		else
		{
			dftype=1;
		}
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
		if(IsDataFlag==1)
		{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb6,0x30,0,3,4,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,62);
				SendIndex=SendIndex+62;
				//SendNAK(F, P, 0x0d);
				//return 0;
			}
			else
			{
				SendIndex = SendIndex + 12;
				IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb6,0x40,0,3,4,0,0,0,0,dftype);
				SendIndex = SendIndex + 12;
				IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb6,0x50,0,2,4,0,0,0,0,dftype);
				SendIndex = SendIndex + 8;
				IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb6,0x11,0,2,3,0,0,0,0,dftype);
				SendIndex = SendIndex + 6;
				IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb6,0x21,0,3,3,0,0,0,0,dftype);
				SendIndex = SendIndex + 9;
				IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x00,0x31,0,3,1,0,0,0,0,0);
				SendIndex = SendIndex + 3;
				IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x00,0x50,0,3,4,0,0,0,0,dftype);
				SendIndex = SendIndex + 12;
			}
		}
		else
		{
			memset(&SendBuff[SendIndex],OxXX,62);
			SendIndex=SendIndex+62;
			//SendNAK(F, P, 0x0d);
			//return 0;
		}

		//if (AutoFlg!=0)
		//	return 1;
//		EC();
//		TP();
//		FrameTailCreate_Send(0);
	}
	return 1;
}

void setjiaocai26(TS ts)
{
	INT8U timebcd[4];
	INT32U_BCD(ts.Minute,&timebcd[0],1);
	INT32U_BCD(ts.Hour,&timebcd[1],1);
	INT32U_BCD(ts.Day,&timebcd[2],1);
	INT32U_BCD(ts.Month,&timebcd[3],1);

	memset(&SendBuff[SendIndex],0,8 );
	SendIndex = SendIndex + 8;
	memset(&SendBuff[SendIndex],0,12 );
	SendIndex = SendIndex + 12;
	memcpy(&SendBuff[SendIndex],timebcd,4 );
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex],timebcd,4 );
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex],timebcd,4 );
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex],timebcd,4 );
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex],timebcd,4 );
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex],timebcd,4 );
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex],timebcd,4 );
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex],timebcd,4 );
	SendIndex = SendIndex + 4;

}
INT16U Level1Data_Curr_F26_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//A��B��C�������ͳ�����ݼ����һ�ζ����¼
{
	INT8U CJQno, MeterNo, MeterType,dsj;
	INT16U IsDataFlag,dftype;
	INT32U tmp;
	INT8U Temp_FilePath[60];
	TS ts;
	int ifjiaocai;
	
	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	SdPrintf(YNPrint,PreFix,"F26: portn=%d\n",portn);
	if (portn == LocalCommPort)
		portn=CarrWavePort;
	if (portn==1)
		ifjiaocai = 1;

	SdPrintf(YNPrint,PreFix, "F26: portn=%d,LocalCommPort=%d\n",portn,LocalCommPort);

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);

	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;

	sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",P);

	dftype=1;//comm

	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);

	SdPrintf(YNPrint,PreFix, "F26: P=%4d,MeterType=%d,IsDataFlag=%d\n",P,MeterType,IsDataFlag);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb3,0x10,0,2,4,0,0,0,0,dftype);
		if (IsDataFlag == 0)// b3 10 �ܶ������      b311 A��������		 b312 B��������  	b313 C��������
		{
			if (ifjiaocai==0)
			{
				memset(&SendBuff[SendIndex],OxXX,52);
				SendIndex=SendIndex+52;
			}else
				setjiaocai26(ts);
		}
		else
		{
			int duan_a,duan_b,duan_c;
			duan_a = BCD_INT32(&SendBuff[SendIndex+2],2);
			duan_b = BCD_INT32(&SendBuff[SendIndex+4],2);
			duan_c = BCD_INT32(&SendBuff[SendIndex+6],2);
			SdPrintf(YNPrint,PreFix,"F26==== �˴δ���   A=%d  B=%d   C=%d",duan_a,duan_b,duan_c);
			if (JSetPara_AFN04_3761_2009->group2.f10[P-1].ConnectType==30)
			{
				tmp=BCD_INT32(&SendBuff[SendIndex+2],2)+BCD_INT32(&SendBuff[SendIndex+4],2)+BCD_INT32(&SendBuff[SendIndex+6],2);
				SdPrintf(YNPrint,PreFix,"F26==== �����ܴ���=%d",tmp);
				INT32U_BCD(tmp,&SendBuff[SendIndex],2);
			}
			SendIndex = SendIndex + 8;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb3,0x20,0,3,4,0,0,0,0,dftype);
							// b3 20 �ܶ���ʱ��      b321 A�����ʱ��		 b322 B�����ʱ��  	b323 C�����ʱ��
			if (JSetPara_AFN04_3761_2009->group2.f10[P-1].ConnectType==30)
			{
				tmp=BCD_INT32(&SendBuff[SendIndex+3],3)+BCD_INT32(&SendBuff[SendIndex+6],3)+BCD_INT32(&SendBuff[SendIndex+9],3);
				INT32U_BCD(tmp,&SendBuff[SendIndex],3);
			}
			SendIndex = SendIndex + 12;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb3,0x30,1,4,4,0,0,0,0,dftype);
			dsj=0;			// b3 30���һ�ζ�����ʼʱ��      b331 A��		 b332 B�� 	b333 C��
			if (JSetPara_AFN04_3761_2009->group2.f10[P-1].ConnectType==30)
			{
				dsj=1;
				tmp=BCD_INT32(&SendBuff[SendIndex+4],4);
				if (BCD_INT32(&SendBuff[SendIndex+8],4)>tmp)
				{
					tmp=BCD_INT32(&SendBuff[SendIndex+8],4);
					dsj=2;
				}
				if (BCD_INT32(&SendBuff[SendIndex+12],4)>tmp)
				{
					tmp=BCD_INT32(&SendBuff[SendIndex+12],4);
					dsj=3;
				}
				if (dsj==1)
				{
					memcpy(&SendBuff[SendIndex],&SendBuff[SendIndex+4],4);
				}
				if (dsj==2)
				{
					memcpy(&SendBuff[SendIndex],&SendBuff[SendIndex+8],4);
				}
				if (dsj==3)
				{
					memcpy(&SendBuff[SendIndex],&SendBuff[SendIndex+12],4);
				}
			}
			SendIndex = SendIndex + 16;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb3,0x40,1,4,4,0,0,0,0,dftype);
			dsj=0;			// b3 40 ���һ�ζ������ʱ��		A��			B��		C��
			if (JSetPara_AFN04_3761_2009->group2.f10[P-1].ConnectType==30)
			{
				dsj=1;
				tmp=BCD_INT32(&SendBuff[SendIndex+4],4);
				if (BCD_INT32(&SendBuff[SendIndex+8],4)>tmp)
				{
					tmp=BCD_INT32(&SendBuff[SendIndex+8],4);
					dsj=2;
				}
				if (BCD_INT32(&SendBuff[SendIndex+12],4)>tmp)
				{
					tmp=BCD_INT32(&SendBuff[SendIndex+12],4);
					dsj=3;
				}
				if (dsj==1)
				{
					memcpy(&SendBuff[SendIndex],&SendBuff[SendIndex+4],4);
				}
				if (dsj==2)
				{
					memcpy(&SendBuff[SendIndex],&SendBuff[SendIndex+8],4);
				}
				if (dsj==3)
				{
					memcpy(&SendBuff[SendIndex],&SendBuff[SendIndex+12],4);
				}
			}
			SendIndex = SendIndex + 16;
		}
	}
	else
	{
		if (ifjiaocai==0)
		{
			memset(&SendBuff[SendIndex],OxXX,52);
			SendIndex=SendIndex+52;
		}else
			setjiaocai26(ts);
	}
	return 1;
}
void setjiaocai27(TS ts)
{
	INT8U timebcd[6];
	INT32U_BCD(ts.Sec,&timebcd[0],1);
	INT32U_BCD(ts.Minute,&timebcd[1],1);
	INT32U_BCD(ts.Hour,&timebcd[2],1);
	INT32U_BCD(ts.Day,&timebcd[3],1);
	INT32U_BCD(ts.Month,&timebcd[4],1);
	INT32U_BCD(ts.Year-2000,&timebcd[5],1);

	memcpy(&SendBuff[SendIndex],timebcd,6);
	SendIndex = SendIndex + 6;
	memset(&SendBuff[SendIndex],0,4);
	SendIndex = SendIndex + 4;
	memset(&SendBuff[SendIndex],0,3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex],timebcd,6);//
	SendIndex = SendIndex + 6;
	memset(&SendBuff[SendIndex],0,3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex],timebcd,6);
	SendIndex = SendIndex + 6;
	memset(&SendBuff[SendIndex],0,3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex],timebcd,6);//
	SendIndex = SendIndex + 6;
	memset(&SendBuff[SendIndex],0,3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex],timebcd,6);//
	SendIndex = SendIndex + 6;
	memset(&SendBuff[SendIndex],0,3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex],timebcd,6);//
	SendIndex = SendIndex + 6;
}
INT16U Level1Data_Curr_F27_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���ܱ�����ʱ�ӡ���̴����������һ�β���ʱ��
{
	INT8U CJQno, MeterNo, MeterType;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60];
	int ifjiaocai=0;
	TS ts;
	
	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
	if (portn==1)
	{
		ifjiaocai = 1;
	}

	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;

	sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",P);

	dftype=1;//comm

	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xc0,0x11,0,3,1,0,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			if (ifjiaocai==0)
			{
				memset(&SendBuff[SendIndex],OxXX,55);
				SendIndex=SendIndex+55;
			}
			else
			{
				setjiaocai27(ts);
			}
		}
		else
		{
			SendIndex = SendIndex + 3;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xc0,0x10,1,3,1,0,0,0,0,dftype);//YYMMDD
			SendIndex = SendIndex + 3;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb2,0x14,0,4,1,0,0,0,0,dftype);
			SendIndex = SendIndex + 4;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb2,0x12,0,3,1,0,0,0,0,dftype);
			SendIndex = SendIndex + 3;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb2,0x10,0,6,1,0,0,0,0,dftype);
			SendIndex = SendIndex + 6;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x00,0x44,0,3,1,0,0,0,0,dftype);
			SendIndex = SendIndex + 3;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x00,0x45,0,6,1,0,0,0,0,dftype);
			SendIndex = SendIndex + 6;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb2,0x13,0,3,1,0,0,0,0,dftype);
			SendIndex = SendIndex + 3;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb2,0x11,0,6,1,0,0,0,0,dftype);
			SendIndex = SendIndex + 6;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x00,0x40,0,3,1,0,0,0,0,dftype);
			SendIndex = SendIndex + 3;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x00,0x41,0,6,1,0,0,0,0,dftype);
			SendIndex = SendIndex + 6;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x00,0x42,0,3,1,0,0,0,0,dftype);
			SendIndex = SendIndex + 3;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x00,0x43,0,6,1,0,0,0,0,dftype);
			SendIndex = SendIndex + 6;
		}
	}
	else
	{
		if (ifjiaocai==0)
		{
			memset(&SendBuff[SendIndex],OxXX,55);
			SendIndex=SendIndex+55;
		}
		else
		{
			setjiaocai27(ts);
		}
	}
	return 1;
}

INT16U Level1Data_Curr_F28_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//�������״̬�ּ����λ��־
{
	int CjqNo,MeterNo,MeterType,i,j;
	INT8U Temp_FilePath[60], tempManyData[DataLenMax],chgflg;
	INT16U StatB[7],Stat[7],StatChg[7],tmp;
	memset(StatChg,0,7*sizeof(INT16U));
	TS ts;
	TS ts2;
	
	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;
		
	chgflg=0;
	tmp=0;
	CjqNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	ts=Jdatafileinfo->data485[portn-1].ts;
	ts2=ts;
	TimeDecrease(&ts2,3,1);
	memset(&StatB,0,sizeof(StatB));
	memset(&Stat,0,sizeof(Stat));
//	if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	LDType=2;
	memset(Temp_FilePath,0,60);
	memset(&smfileold,0,sizeof(SMFiles));
	memset(&smfile,0,sizeof(SMFiles));
	sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/last.dat",P);
	ReadFile((char *) Temp_FilePath, &smfileold,sizeof(SMFiles),Jproginfo);
	memset(Temp_FilePath,0,60);
	sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",P);
	ReadFile((char *) Temp_FilePath, &smfile,sizeof(SMFiles),Jproginfo);
	if(smfileold.sm.CaijiQiNo==CjqNo&&smfileold.sm.MeterNo==MeterNo)
	{
		memset(tempManyData,0,sizeof(tempManyData));
		GetManyData(0,smfileold.sm.datas,&tempManyData[0],0xc0,0x20);
		memcpy(&StatB[0],&tempManyData[0],2);
		memset(tempManyData,0,sizeof(tempManyData));
		GetManyData(0,smfileold.sm.datas,&tempManyData[0],0xc0,0x21);
		memcpy(&StatB[1],&tempManyData[0],2);
		for(j=0;j<5;j++)
		{
			memset(tempManyData,0,sizeof(tempManyData));
			GetManyData(0,smfileold.sm.datas,&tempManyData[0],0x00,0x63+j);
			memcpy(&StatB[2+j],&tempManyData[0],2);
		}
	}
	if(smfile.sm.CaijiQiNo==CjqNo&&smfile.sm.MeterNo==MeterNo)
	{
		memset(tempManyData,0,sizeof(tempManyData));
		GetManyData(0,smfile.sm.datas,&tempManyData[0],0xc0,0x20);
		memcpy(&Stat[0],&tempManyData[0],2);
		memset(tempManyData,0,sizeof(tempManyData));
		GetManyData(0,smfile.sm.datas,&tempManyData[0],0xc0,0x21);
		memcpy(&Stat[1],&tempManyData[0],2);
		for(j=0;j<5;j++)
		{
			memset(tempManyData,0,sizeof(tempManyData));
			GetManyData(0,smfile.sm.datas,&tempManyData[0],0x00,0x63+j);
			memcpy(&Stat[2+j],&tempManyData[0],2);
		}
	}

	for (i=0;i<7;i++)
	{
		tmp=CmpOneByte(StatB[i]&0xff,Stat[i]&0xff);
		StatChg[i]=tmp&0xff;
		tmp=CmpOneByte((StatB[i]>>8)&0xff,(Stat[i]>>8)&0xff);
		StatChg[i]=StatChg[i]|(tmp<<8);
		for(i=0;i<7;i++)
		{
			memcpy(&SendBuff[SendIndex],&StatChg[i],2);
			SendIndex=SendIndex+2;
		}
		for(i=0;i<7;i++)
		{
			memcpy(&SendBuff[SendIndex],&Stat[i],2);
			SendIndex=SendIndex+2;
		}
	}
//	if (AutoFlg!=0) return 1;EC();
//	TP();
//	FrameTailCreate_Send(0);

	return 1;
}

INT16U Level1Data_Curr_F29_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ A��B��C������/�����й�����ʾֵ������޹� 1/2 ����ʾֵ
{
	TS ts;
	TSGet(&ts);
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	memset(&SendBuff[SendIndex],0,10);
	SendIndex=SendIndex+10;
	return 1;
}

INT16U Level1Data_Curr_F31_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ A��B��C������/�����й�����ʾֵ������޹� 1/2 ����ʾֵ
{
	INT8U CJQno, MeterNo, MeterType;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60];
	TS ts;

	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
	if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port==1)
	{
		INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;

		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.A_Z_P_All/64, &SendBuff[SendIndex], 4);
		SendIndex = SendIndex + 4;
		SendBuff[SendIndex] = 0;
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.A_F_P_All/64, &SendBuff[SendIndex], 4);
		SendIndex = SendIndex + 4;
		SendBuff[SendIndex] = 0;
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.A_Z_Q_All/64, &SendBuff[SendIndex], 4);
		SendIndex = SendIndex + 4;
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.A_F_Q_All/64, &SendBuff[SendIndex], 4);
		SendIndex = SendIndex + 4;

		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.B_Z_P_All/64, &SendBuff[SendIndex], 4);
		SendIndex = SendIndex + 4;
		SendBuff[SendIndex] = 0;
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.B_F_P_All/64, &SendBuff[SendIndex], 4);
		SendIndex = SendIndex + 4;
		SendBuff[SendIndex] = 0;
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.B_Z_Q_All/64, &SendBuff[SendIndex], 4);
		SendIndex = SendIndex + 4;
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.B_F_Q_All/64, &SendBuff[SendIndex], 4);
		SendIndex = SendIndex + 4;

		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.C_Z_P_All/64, &SendBuff[SendIndex], 4);
		SendIndex = SendIndex + 4;
		SendBuff[SendIndex] = 0;
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.C_F_P_All/64, &SendBuff[SendIndex], 4);
		SendIndex = SendIndex + 4;
		SendBuff[SendIndex] = 0;
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.C_Z_Q_All/64, &SendBuff[SendIndex], 4);
		SendIndex = SendIndex + 4;
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.C_F_Q_All/64, &SendBuff[SendIndex], 4);
		SendIndex = SendIndex + 4;
		return 1;
	}

	INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;

	sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",P);
	dftype=1;
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
	if(IsDataFlag==1)
	{
		//------------------------------A
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xff,0xc0,0,4,1,1,0,0,0,dftype);
		if (IsDataFlag==0)
		{
			SdPrintf(YNPrint,PreFix,"F31 du ffc0 error");
			memset(&SendBuff[SendIndex],0,5);
		}
		SendIndex=SendIndex+5;

		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xff,0xc1,0,4,1,1,0,0,0,dftype);
		if (IsDataFlag==0)
			memset(&SendBuff[SendIndex],0,5);
		SendIndex=SendIndex+5;

		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xff,0xc2,0,4,1,0,0,0,0,dftype);
		if (IsDataFlag==0)
			memset(&SendBuff[SendIndex],0,4);
		SendIndex=SendIndex+4;

		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xff,0xc3,0,4,1,0,0,0,0,dftype);
		if (IsDataFlag==0)
			memset(&SendBuff[SendIndex],0,4);
		SendIndex=SendIndex+4;
		//------------------------------B
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xff,0xc4,0,4,1,1,0,0,0,dftype);
		if (IsDataFlag==0)
			memset(&SendBuff[SendIndex],0,5);
		SendIndex=SendIndex+5;

		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xff,0xc5,0,4,1,1,0,0,0,dftype);
		if (IsDataFlag==0)
			memset(&SendBuff[SendIndex],0,5);
		SendIndex=SendIndex+5;

		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xff,0xc6,0,4,1,0,0,0,0,dftype);
		if (IsDataFlag==0)
			memset(&SendBuff[SendIndex],0,4);
		SendIndex=SendIndex+4;

		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xff,0xc7,0,4,1,0,0,0,0,dftype);
		if (IsDataFlag==0)
			memset(&SendBuff[SendIndex],0,4);
		SendIndex=SendIndex+4;
		//------------------------------C
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xff,0xc8,0,4,1,1,0,0,0,dftype);
		if (IsDataFlag==0)
			memset(&SendBuff[SendIndex],0,5);
		SendIndex=SendIndex+5;

		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xff,0xc9,0,4,1,1,0,0,0,dftype);
		if (IsDataFlag==0)
			memset(&SendBuff[SendIndex],0,5);
		SendIndex=SendIndex+5;

		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xff,0xcA,0,4,1,0,0,0,0,dftype);
		if (IsDataFlag==0)
			memset(&SendBuff[SendIndex],0,4);
		SendIndex=SendIndex+4;

		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xff,0xcB,0,4,1,0,0,0,0,dftype);
		if (IsDataFlag==0)
			memset(&SendBuff[SendIndex],0,4);
		SendIndex=SendIndex+4;

	}
	else
	{
		memset(&SendBuff[SendIndex],0,54);
		SendIndex=SendIndex+54;
	}
	return 1;
}
INT16U Level1Data_Curr_F32_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��һ������ A��B��C������/�����й�����ʾֵ������޹� 1/2 ����ʾֵ
{
	INT8U CJQno, MeterNo, MeterType;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60];
	TS ts;

	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
	TimeDecrease(&ts,5,1);
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	sprintf((char *) Temp_FilePath, "/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
	dftype=1;
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
	if (IsDataFlag==1)
	{
		//------------------------------A
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xff,0xc0,0,4,1,1,0,0,0,dftype);
		if (IsDataFlag==0)
		{
			SdPrintf(YNPrint,PreFix,"F32 du ffc0 error");
			memset(&SendBuff[SendIndex],0,5);
		}
		SendIndex=SendIndex+5;

		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xff,0xc1,0,4,1,1,0,0,0,dftype);
		if (IsDataFlag==0)
			memset(&SendBuff[SendIndex],0,5);
		SendIndex=SendIndex+5;

		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xff,0xc2,0,4,1,0,0,0,0,dftype);
		if (IsDataFlag==0)
			memset(&SendBuff[SendIndex],0,4);
		SendIndex=SendIndex+4;

		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xff,0xc3,0,4,1,0,0,0,0,dftype);
		if (IsDataFlag==0)
			memset(&SendBuff[SendIndex],0,4);
		SendIndex=SendIndex+4;
		//------------------------------B
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xff,0xc4,0,4,1,1,0,0,0,dftype);
		if (IsDataFlag==0)
			memset(&SendBuff[SendIndex],0,5);
		SendIndex=SendIndex+5;

		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xff,0xc5,0,4,1,1,0,0,0,dftype);
		if (IsDataFlag==0)
			memset(&SendBuff[SendIndex],0,5);
		SendIndex=SendIndex+5;

		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xff,0xc6,0,4,1,0,0,0,0,dftype);
		if (IsDataFlag==0)
			memset(&SendBuff[SendIndex],0,4);
		SendIndex=SendIndex+4;

		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xff,0xc7,0,4,1,0,0,0,0,dftype);
		if (IsDataFlag==0)
			memset(&SendBuff[SendIndex],0,4);
		SendIndex=SendIndex+4;
		//------------------------------C
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xff,0xc8,0,4,1,1,0,0,0,dftype);
		if (IsDataFlag==0)
			memset(&SendBuff[SendIndex],0,5);
		SendIndex=SendIndex+5;

		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xff,0xc9,0,4,1,1,0,0,0,dftype);
		if (IsDataFlag==0)
			memset(&SendBuff[SendIndex],0,5);
		SendIndex=SendIndex+5;

		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xff,0xcA,0,4,1,0,0,0,0,dftype);
		if (IsDataFlag==0)
			memset(&SendBuff[SendIndex],0,4);
		SendIndex=SendIndex+4;

		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xff,0xcB,0,4,1,0,0,0,0,dftype);
		if (IsDataFlag==0)
			memset(&SendBuff[SendIndex],0,4);
		SendIndex=SendIndex+4;

	}
	else
	{
		memset(&SendBuff[SendIndex],0,59);
		SendIndex=SendIndex+59;
	}
	return 1;
}

INT16U Level1Data_Curr_F33_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ������/�޹�����ʾֵ       9.22
{
	INT8U CJQno, MeterNo, MeterType;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],i;
	TS ts;
	
	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
//	if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port==1)
	{
		INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
	}else
	{
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
	}
	SendBuff[SendIndex++] = FeiLvNum;//������

	sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",P);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x90,0x10,0,4,5,1,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,85);
			SendIndex=SendIndex+85;
			//SendNAK(F, P, 0x0d);
			//return 0;
		}
		else
		{
			for(i=0;i<5;i++)
			{
				if((SendBuff[(SendIndex+1)+i*5]==OxXX)&&
				   (SendBuff[(SendIndex+2)+i*5]==OxXX)&&
				   (SendBuff[(SendIndex+3)+i*5]==OxXX)&&
				   (SendBuff[(SendIndex+4)+i*5]==OxXX))
						memset(&SendBuff[SendIndex+0+i*5],OxXX,5);
			}
			SendIndex = SendIndex + 25;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x10,0,4,5,0,0,0,0,dftype);
			SendIndex = SendIndex + 20;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x30,0,4,5,0,0,0,0,dftype);
			SendIndex = SendIndex + 20;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x40,0,4,5,0,0,0,0,dftype);
			SendIndex = SendIndex + 20;
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,85);
		SendIndex=SendIndex+85;
		//SendNAK(F, P, 0x0d);
		//return 0;
	}
//	if (AutoFlg!=0) return 1;
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 1;
}

INT16U Level1Data_Curr_F34_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ������/�޹�����ʾֵ      9.22
{
	INT8U CJQno, MeterNo, MeterType;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],i;
	TS ts;
	
	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
//	if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port==1)
	{
		INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
	}else
	{
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
	}

	SendBuff[SendIndex++] = FeiLvNum;
	sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",P);
	printf("\n Level1Data_Curr_F34_Get: %s\n",Temp_FilePath);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x90,0x20,0,4,5,1,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,85);
			SendIndex=SendIndex+85;
			//SendNAK(F, P, 0x0d);
			//return 0;
		}
		else
		{
			for(i=0;i<5;i++)
			{
				if((SendBuff[(SendIndex+1)+i*5]==OxXX)&&
				   (SendBuff[(SendIndex+2)+i*5]==OxXX)&&
				   (SendBuff[(SendIndex+3)+i*5]==OxXX)&&
				   (SendBuff[(SendIndex+4)+i*5]==OxXX))
						memset(&SendBuff[SendIndex+0+i*5],OxXX,5);
			}
			SendIndex = SendIndex + 25;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x20,0,4,5,0,0,0,0,dftype);
			SendIndex = SendIndex + 20;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x50,0,4,5,0,0,0,0,dftype);
			SendIndex = SendIndex + 20;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x60,0,4,5,0,0,0,0,dftype);
			SendIndex = SendIndex + 20;
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,85);
		SendIndex=SendIndex+85;
		//SendNAK(F, P, 0x0d);
		//return 0;
	}
//	if (AutoFlg!=0) return 1;
//	EC();
//	TP();
//	FrameTailCreate_Send(0);

	return 1;
}
INT16U Level1Data_Curr_F35_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//����������/�޹��������������ʱ��      9.22
{
	INT8U CJQno, MeterNo, MeterType;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60];
	TS ts;
	
	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
	//if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port==1)
	{
		INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
	}else
	{
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
	}

	SendBuff[SendIndex++] = FeiLvNum;
	sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",P);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
	if(IsDataFlag==1)
	{
		SdPrintf(YNPrint,PreFix, "F35:ConnectType[%d]=%d\n",P-1,JSetPara_AFN04_3761_2009->group2.f10[P-1].ConnectType);
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa0,0x1f,0,15,1,0,0,0,0,dftype);
			if(IsDataFlag==0) memset(&SendBuff[SendIndex],OxXX,15);
  			SendIndex = SendIndex + 15;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb0,0x1f,0,20,1,0,0,0,0,dftype);
			if(IsDataFlag==0) memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex = SendIndex + 20;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa1,0x1f,0,15,1,0,0,0,0,dftype);
			if(IsDataFlag==0) memset(&SendBuff[SendIndex],OxXX,15);
			SendIndex = SendIndex + 15;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb1,0x1f,0,20,1,0,0,0,0,dftype);
			if(IsDataFlag==0) memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex = SendIndex + 20;
	}
	else
		{
		memset(&SendBuff[SendIndex],OxXX,70);
		SendIndex=SendIndex+70;
		//SendNAK(F, P, 0x0d);
		//return 0;
	}
	//if (AutoFlg!=0) return 1;
//	//EC();
//	//TP();
//	//FrameTailCreate_Send(0);
	return 1;
}

INT16U Level1Data_Curr_F36_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���·�����/�޹��������������ʱ��     9.22
{
	INT8U CJQno, MeterNo, MeterType;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60];
	TS ts;

	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
	//if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port==1)
	{
		INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
	}else
	{
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
	}

	SendBuff[SendIndex++] = FeiLvNum;
	sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",P);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
	if(IsDataFlag==1)
	{
		SdPrintf(YNPrint,PreFix, "F36:ConnectType[%d]=%d\n",P-1,JSetPara_AFN04_3761_2009->group2.f10[P-1].ConnectType);
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa0,0x2f,0,15,1,0,0,0,0,dftype);
		if(IsDataFlag==0) memset(&SendBuff[SendIndex],0,15);
		SendIndex = SendIndex + 15;
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb0,0x2f,0,20,1,0,0,0,0,dftype);
		if(IsDataFlag==0) memset(&SendBuff[SendIndex],0,20);
		SendIndex = SendIndex + 20;
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa1,0x2f,0,15,1,0,0,0,0,dftype);
		if(IsDataFlag==0) memset(&SendBuff[SendIndex],0,15);
		SendIndex = SendIndex + 15;
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb1,0x2f,0,20,1,0,0,0,0,dftype);
		if(IsDataFlag==0) memset(&SendBuff[SendIndex],0,20);
		SendIndex = SendIndex + 20;
	}
	else
	{
		memset(&SendBuff[SendIndex],0,70);
		SendIndex=SendIndex+70;
		//SendNAK(F, P, 0x0d);
		//return 0;
	}
//	if (AutoFlg!=0) return 1; EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 1;
}

INT16U Level1Data_Curr_F37_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���£���һ�����գ�������/�޹�����ʾֵ��һ/�������޹�����ʾֵ���ܡ�����1��M��
{
	INT8U CJQno, MeterNo, MeterType;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60];
	TS ts;

	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = 4;
	TimeDecrease(&ts,5,1);
	sprintf((char *) Temp_FilePath, "/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
	dftype=1;
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
	if (IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x90,0x10,0,4,5,1,0,0,0,dftype);
		if (IsDataFlag==0)
		{
			memset(&SendBuff[SendIndex],0,25);
		}
		SendIndex=SendIndex+25;
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x10,0,4,5,0,0,0,0,dftype);
		if (IsDataFlag==0)
		{
			memset(&SendBuff[SendIndex],0,20);
		}
		SendIndex=SendIndex+20;

		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x30,0,4,5,0,0,0,0,dftype);//һ����
		if (IsDataFlag==0)
		{
			memset(&SendBuff[SendIndex],0,20);
		}
		SendIndex=SendIndex+20;
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x40,0,4,5,0,0,0,0,dftype);//������
		if (IsDataFlag==0)
		{
			memset(&SendBuff[SendIndex],0,20);
		}
		SendIndex=SendIndex+20;
	}
	else
	{
		memset(&SendBuff[SendIndex],0,85);
		SendIndex=SendIndex+85;
	}
	return 1;
}
INT16U Level1Data_Curr_F38_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���£���һ�����գ�������/�޹�����ʾֵ����/�������޹�����ʾֵ���ܡ�����1��M��
{
	INT8U CJQno, MeterNo, MeterType;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60];
	TS ts;

	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = 4;
	TimeDecrease(&ts,5,1);
	sprintf((char *) Temp_FilePath, "/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
	dftype=1;
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
	if (IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x90,0x20,0,4,5,1,0,0,0,dftype);
		if (IsDataFlag==0)
		{
			memset(&SendBuff[SendIndex],0,25);
		}
		SendIndex=SendIndex+25;
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x20,0,4,5,0,0,0,0,dftype);
		if (IsDataFlag==0)
		{
			memset(&SendBuff[SendIndex],0,20);
		}
		SendIndex=SendIndex+20;

		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x50,0,4,5,0,0,0,0,dftype);//������
		if (IsDataFlag==0)
		{
			memset(&SendBuff[SendIndex],0,20);
		}
		SendIndex=SendIndex+20;
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x60,0,4,5,0,0,0,0,dftype);//������
		if (IsDataFlag==0)
		{
			memset(&SendBuff[SendIndex],0,20);
		}
		SendIndex=SendIndex+20;
	}
	else
	{
		memset(&SendBuff[SendIndex],0,85);
		SendIndex=SendIndex+85;
	}
	return 1;
}
INT16U Level1Data_Curr_F39_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���£���һ�����գ�������/�޹��������������ʱ�䣨�ܡ�����1��M��
{
	INT8U CJQno, MeterNo, MeterType;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60];
	TS ts;

	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = 4;
	TimeDecrease(&ts,5,1);
	sprintf((char *) Temp_FilePath, "/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
	dftype=1;
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
	if (IsDataFlag==1)
	{
		SdPrintf(YNPrint,PreFix, "\nF39:ConnectType[%d]=%d\n",P-1,JSetPara_AFN04_3761_2009->group2.f10[P-1].ConnectType);
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa0,0x1f,0,15,1,0,0,0,0,dftype);
		if(IsDataFlag==0) memset(&SendBuff[SendIndex],0,15);
		SendIndex = SendIndex + 15;
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb0,0x1f,0,20,1,0,0,0,0,dftype);
		if(IsDataFlag==0) memset(&SendBuff[SendIndex],0,20);
		SendIndex = SendIndex + 20;
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa1,0x1f,0,15,1,0,0,0,0,dftype);
		if(IsDataFlag==0) memset(&SendBuff[SendIndex],0,15);
		SendIndex = SendIndex + 15;
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb1,0x1f,0,20,1,0,0,0,0,dftype);
		if(IsDataFlag==0) memset(&SendBuff[SendIndex],0,20);
		SendIndex = SendIndex + 20;

	}
	else
	{
		memset(&SendBuff[SendIndex],0,70);
		SendIndex=SendIndex+70;
	}
	return 1;
}
INT16U Level1Data_Curr_F40_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���£���һ�����գ�������/�޹��������������ʱ�䣨�ܡ�����1��M��
{
	INT8U CJQno, MeterNo, MeterType;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60];
	TS ts;

	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = 4;
	TimeDecrease(&ts,5,1);
	sprintf((char *) Temp_FilePath, "/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
	dftype=1;
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
	if (IsDataFlag==1)
	{
		SdPrintf(YNPrint,PreFix, "\nF40:ConnectType[%d]=%d\n",P-1,JSetPara_AFN04_3761_2009->group2.f10[P-1].ConnectType);
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa0,0x2f,0,15,1,0,0,0,0,dftype);
		if(IsDataFlag==0) memset(&SendBuff[SendIndex],0,15);
		SendIndex = SendIndex + 15;
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb0,0x2f,0,20,1,0,0,0,0,dftype);
		if(IsDataFlag==0) memset(&SendBuff[SendIndex],0,20);
		SendIndex = SendIndex + 20;
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa1,0x2f,0,15,1,0,0,0,0,dftype);
		if(IsDataFlag==0) memset(&SendBuff[SendIndex],0,15);
		SendIndex = SendIndex + 15;
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb1,0x2f,0,20,1,0,0,0,0,dftype);
		if(IsDataFlag==0) memset(&SendBuff[SendIndex],0,20);
		SendIndex = SendIndex + 20;
	}
	else
	{
		memset(&SendBuff[SendIndex],0,70);
		SendIndex=SendIndex+70;
	}
	return 1;
}

INT16U Level1Data_Curr_F41_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)
{
	INT16U i,IsDataFlag,j,dftype,dflg;
	INT8U Temp_FilePath[60],tempManyData[50],tempData[50],CJQno,MeterNo,MeterType;
	INT32S tmp[5],tmp2=0,tmp3=0;
	TS ts;
	for(i=0;i<5;i++)
		tmp[i]=0;

	TSGet(&ts);
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	//if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	SendBuff[SendIndex++]=FeiLvNum;

	//��������
	IsDataFlag=0;
	LDType=2;
	dflg=0;
	memset(Temp_FilePath,0x00,60);
	sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&tempManyData[0],CJQno,MeterNo,0x90,0x10,0,4,5,0,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 0;
		}
		else
		{
			dflg=1;
			memcpy(&tmp2,&JSetPara_AFN04_3761_2009->Point[P-1].f25.V_BeiLv[0] ,2);
			memcpy(&tmp3,&JSetPara_AFN04_3761_2009->Point[P-1].f25.I_BeiLv[0],2);
			tmp2=1;
			tmp3=1;
			for(j=0;j<5;j++)
			{
				tmp[j]=BCD_INT32(&tempManyData[0+j*4], 4)*100;
			}
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,20);
		SendIndex=SendIndex+20;
		//SendNAK(F, P, 0x0d);
		//return 0;
	}
	if (dflg==1)
	{
		IsDataFlag=0;
		memset(Temp_FilePath,0x00,60);
		sprintf((char *)Temp_FilePath,"/nand/DataCurr/%04d/curr.dat",P);
		if ((MeterType == 9) || (MeterType == 6))
		{
			dftype=1;//comm
		}
		else
		{
			dftype=1;
		}
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
		if(IsDataFlag==1)
		{
			IsDataFlag=getMetersData(MeterType,&tempManyData[0],CJQno,MeterNo,0x90,0x10,0,4,5,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,20);
				SendIndex=SendIndex+20;
				//SendNAK(F, P, 0x0d);
				//return 0;
			}
			else
			{
				memcpy(&tmp2,&JSetPara_AFN04_3761_2009->Point[P-1].f25.V_BeiLv[0],2);
				memcpy(&tmp3,&JSetPara_AFN04_3761_2009->Point[P-1].f25.I_BeiLv[0],2);
				tmp2=1;
				tmp3=1;
				for(j=0;j<5;j++)
				{
					tmp[j]=(BCD_INT32(&tempManyData[0+j*4], 4)*100)-tmp[j];
					INT32U_BCD(tmp[j], &tempData[0], 4);
					memcpy(&SendBuff[SendIndex],&tempData[0],4);
					SendIndex=SendIndex+4;
				}
			}
		}
		else
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 0;
		}
	}
	//if (AutoFlg!=0) return 1; EC();
	//TP();
	//FrameTailCreate_Send(0);
	return 1;
}

INT16U Level1Data_Curr_F42_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)
{
	INT16U i,IsDataFlag,j,dftype,dflg;
	INT8U Temp_FilePath[60],tempManyData[50],tempData[50],CJQno,MeterNo,MeterType;
	INT32S tmp[5],tmp2=0,tmp3=0;
	TS ts;
	for(i=0;i<5;i++)
		tmp[i]=0;

	TSGet(&ts);
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	//if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	SendBuff[SendIndex++]=FeiLvNum;

	//��������
	IsDataFlag=0;
	LDType=2;
	dflg=0;
	memset(Temp_FilePath,0x00,60);
	sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&tempManyData[0],CJQno,MeterNo,0x91,0x10,0,4,5,0,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 0;
		}
		else
		{
			dflg=1;
			memcpy(&tmp2,&JSetPara_AFN04_3761_2009->Point[P-1].f25.V_BeiLv[0],2);
			memcpy(&tmp3,&JSetPara_AFN04_3761_2009->Point[P-1].f25.I_BeiLv[0],2);
			tmp2=1;
			tmp3=1;
			for(j=0;j<5;j++)
			{
				tmp[j]=BCD_INT32(&tempManyData[0+j*4], 4)*100;
			}
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,20);
		SendIndex=SendIndex+20;
		//SendNAK(F, P, 0x0d);
		//return 0;
	}
	if (dflg==1)
	{
		IsDataFlag=0;
		memset(Temp_FilePath,0x00,60);
		sprintf((char *)Temp_FilePath,"/nand/DataCurr/%04d/curr.dat",P);
		if ((MeterType == 9) || (MeterType == 6))
		{
			dftype=1;//comm
		}
		else
		{
			dftype=1;
		}
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
		if(IsDataFlag==1)
		{
			IsDataFlag=getMetersData(MeterType,&tempManyData[0],CJQno,MeterNo,0x91,0x10,0,4,5,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,20);
				SendIndex=SendIndex+20;
				//SendNAK(F, P, 0x0d);
				//return 0;
			}
			else
			{
				memcpy(&tmp2,&JSetPara_AFN04_3761_2009->Point[P-1].f25.V_BeiLv[0],2);
				memcpy(&tmp3,&JSetPara_AFN04_3761_2009->Point[P-1].f25.I_BeiLv[0],2);
				tmp2=1;
				tmp3=1;
				for(j=0;j<5;j++)
				{
					tmp[j]=(BCD_INT32(&tempManyData[0+j*4], 4)*100)-tmp[j];
					INT32U_BCD(tmp[j], &tempData[0], 4);
					memcpy(&SendBuff[SendIndex],&tempData[0],4);
					SendIndex=SendIndex+4;
				}
			}
		}
		else
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 0;
		}
	}
	//if (AutoFlg!=0) return 1; EC();
	//TP();
	//FrameTailCreate_Send(0);
	return 1;
}

INT16U Level1Data_Curr_F43_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)
{
	INT16U i,IsDataFlag,j,dftype,dflg;
	INT8U Temp_FilePath[60],tempManyData[50],tempData[50],CJQno,MeterNo,MeterType;
	INT32S tmp[5],tmp2=0,tmp3=0;
	TS ts;
	for(i=0;i<5;i++)
		tmp[i]=0;
		

	TSGet(&ts);
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	//if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	SendBuff[SendIndex++]=FeiLvNum;

	//��������
	IsDataFlag=0;
	LDType=2;
	dflg=0;
	memset(Temp_FilePath,0x00,60);
	sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&tempManyData[0],CJQno,MeterNo,0x90,0x20,0,4,5,0,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 0;
		}
		else
		{
			dflg=1;
			memcpy(&tmp2,&JSetPara_AFN04_3761_2009->Point[P-1].f25.V_BeiLv[0],2);
			memcpy(&tmp3,&JSetPara_AFN04_3761_2009->Point[P-1].f25.I_BeiLv[0],2);
			tmp2=1;
			tmp3=1;
			for(j=0;j<5;j++)
			{
				tmp[j]=BCD_INT32(&tempManyData[0+j*4], 4)*100;
			}
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,20);
		SendIndex=SendIndex+20;
		//SendNAK(F, P, 0x0d);
		//return 0;
	}
	if (dflg==1)
	{
		IsDataFlag=0;
		memset(Temp_FilePath,0x00,60);
		sprintf((char *)Temp_FilePath,"/nand/DataCurr/%04d/curr.dat",P);
		if ((MeterType == 9) || (MeterType == 6))
		{
			dftype=1;//comm
		}
		else
		{
			dftype=1;
		}
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
		if(IsDataFlag==1)
		{
			IsDataFlag=getMetersData(MeterType,&tempManyData[0],CJQno,MeterNo,0x90,0x20,0,4,5,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,20);
				SendIndex=SendIndex+20;
				//SendNAK(F, P, 0x0d);
				//return 0;
			}
			else
			{
				memcpy(&tmp2,&JSetPara_AFN04_3761_2009->Point[P-1].f25.V_BeiLv[0],2);
				memcpy(&tmp3,&JSetPara_AFN04_3761_2009->Point[P-1].f25.I_BeiLv[0],2);
				tmp2=1;
				tmp3=1;
				for(j=0;j<5;j++)
				{
					tmp[j]=(BCD_INT32(&tempManyData[0+j*4], 4)*100)-tmp[j];
					INT32U_BCD(tmp[j], &tempData[0], 4);
					memcpy(&SendBuff[SendIndex],&tempData[0],4);
					SendIndex=SendIndex+4;
				}
			}
		}
		else
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 0;
		}
	}
	//if (AutoFlg!=0) return 1; EC();
	//TP();
	//FrameTailCreate_Send(0);
	return 1;
}

INT16U Level1Data_Curr_F44_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)
{
	INT16U i,IsDataFlag,j,dftype,dflg;
	INT8U Temp_FilePath[60],tempManyData[50],tempData[50],CJQno,MeterNo,MeterType;
	INT32S tmp[5],tmp2=0,tmp3=0;
	TS ts;
	for(i=0;i<5;i++)
		tmp[i]=0;

	TSGet(&ts);
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	//if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	SendBuff[SendIndex++]=FeiLvNum;

	//��������
	IsDataFlag=0;
	LDType=2;
	dflg=0;
	memset(Temp_FilePath,0x00,60);
	sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&tempManyData[0],CJQno,MeterNo,0x91,0x20,0,4,5,0,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 0;
		}
		else
		{
			dflg=1;
			memcpy(&tmp2,&JSetPara_AFN04_3761_2009->Point[P-1].f25.V_BeiLv[0],2);
			memcpy(&tmp3,&JSetPara_AFN04_3761_2009->Point[P-1].f25.I_BeiLv[0],2);
			tmp2=1;
			tmp3=1;
			for(j=0;j<5;j++)
			{
				tmp[j]=BCD_INT32(&tempManyData[0+j*4], 4)*100;
			}
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,20);
		SendIndex=SendIndex+20;
		//SendNAK(F, P, 0x0d);
		//return 0;
	}
	if(dflg==1)
	{
		IsDataFlag=0;
		memset(Temp_FilePath,0x00,60);
		sprintf((char *)Temp_FilePath,"/nand/DataCurr/%04d/curr.dat",P);
		if ((MeterType == 9) || (MeterType == 6))
		{
			dftype=1;//comm
		}
		else
		{
			dftype=1;
		}
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
		if(IsDataFlag==1)
		{
			IsDataFlag=getMetersData(MeterType,&tempManyData[0],CJQno,MeterNo,0x91,0x20,0,4,5,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,20);
				SendIndex=SendIndex+20;
				//SendNAK(F, P, 0x0d);
				//return 0;
			}
			else
			{
				memcpy(&tmp2,&JSetPara_AFN04_3761_2009->Point[P-1].f25.V_BeiLv[0],2);
				memcpy(&tmp3,&JSetPara_AFN04_3761_2009->Point[P-1].f25.I_BeiLv[0],2);
				tmp2=1;
				tmp3=1;
				for(j=0;j<5;j++)
				{
					tmp[j]=(BCD_INT32(&tempManyData[0+j*4], 4)*100)-tmp[j];
					INT32U_BCD(tmp[j], &tempData[0], 4);
					memcpy(&SendBuff[SendIndex],&tempData[0],4);
					SendIndex=SendIndex+4;
				}
			}
		}
		else
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 0;
		}
	}
	//if (AutoFlg!=0) return 1; EC();
	//TP();
	//FrameTailCreate_Send(0);
	return 1;
}

INT16U Level1Data_Curr_F45_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)
{
	INT16U i,IsDataFlag,j,dftype,dflg;
	INT8U Temp_FilePath[60],tempManyData[50],tempData[50],CJQno,MeterNo,MeterType;
	INT32S tmp[5],tmp2=0,tmp3=0;
	TS ts;
	for(i=0;i<5;i++)
		tmp[i]=0;

	TSGet(&ts);
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	//if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	SendBuff[SendIndex++]=FeiLvNum;

	//��������
	IsDataFlag=0;
	LDType=2;
	dflg=0;
	memset(Temp_FilePath,0x00,60);
	sprintf((char *)Temp_FilePath,"/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,3);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&tempManyData[0],CJQno,MeterNo,0x90,0x10,0,4,5,0,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 0;
		}
		else
		{
			dflg=1;
			memcpy(&tmp2,&JSetPara_AFN04_3761_2009->Point[P-1].f25.V_BeiLv[0],2);
			memcpy(&tmp3,&JSetPara_AFN04_3761_2009->Point[P-1].f25.I_BeiLv[0],2);
			tmp2=1;
			tmp3=1;
			for(j=0;j<5;j++)
			{
				tmp[j]=BCD_INT32(&tempManyData[0+j*4], 4)*100;
			}
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,20);
		SendIndex=SendIndex+20;
		//SendNAK(F, P, 0x0d);
		//return 0;
	}
	if(dflg==1)
	{
		IsDataFlag=0;
		memset(Temp_FilePath,0x00,60);
		sprintf((char *)Temp_FilePath,"/nand/DataCurr/%04d/curr.dat",P);
		if ((MeterType == 9) || (MeterType == 6))
		{
			dftype=1;//comm
		}
		else
		{
			dftype=1;
		}
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
		if(IsDataFlag==1)
		{
			IsDataFlag=getMetersData(MeterType,&tempManyData[0],CJQno,MeterNo,0x90,0x10,0,4,5,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,20);
				SendIndex=SendIndex+20;
				//SendNAK(F, P, 0x0d);
				//return 0;
			}
			else
			{
				memcpy(&tmp2,&JSetPara_AFN04_3761_2009->Point[P-1].f25.V_BeiLv[0],2);
				memcpy(&tmp3,&JSetPara_AFN04_3761_2009->Point[P-1].f25.I_BeiLv[0],2);
				tmp2=1;
				tmp3=1;
				for(j=0;j<5;j++)
				{
					tmp[j]=(BCD_INT32(&tempManyData[0+j*4], 4)*100)-tmp[j];
					INT32U_BCD(tmp[j], &tempData[0], 4);
					memcpy(&SendBuff[SendIndex],&tempData[0],4);
					SendIndex=SendIndex+4;
				}
			}
		}
		else
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 0;
		}
	}
//	if (AutoFlg!=0) return 1;
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 1;
}

INT16U Level1Data_Curr_F46_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)
{
	INT16U i,IsDataFlag,j,dftype,dflg;
	INT8U Temp_FilePath[60],tempManyData[50],tempData[50],CJQno,MeterNo,MeterType;
	INT32S tmp[5],tmp2=0,tmp3=0;
	TS ts;
	for(i=0;i<5;i++)
		tmp[i]=0;

	TSGet(&ts);
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	//if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	SendBuff[SendIndex++]=FeiLvNum;

	//��������
	IsDataFlag=0;
	LDType=2;
	dflg=0;
	memset(Temp_FilePath,0x00,60);
	sprintf((char *)Temp_FilePath,"/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,3);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&tempManyData[0],CJQno,MeterNo,0x91,0x10,0,4,5,0,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 0;
		}
		else
		{
			dflg=1;
			memcpy(&tmp2,&JSetPara_AFN04_3761_2009->Point[P-1].f25.V_BeiLv[0],2);
			memcpy(&tmp3,&JSetPara_AFN04_3761_2009->Point[P-1].f25.I_BeiLv[0],2);
			tmp2=1;
			tmp3=1;
			for(j=0;j<5;j++)
			{
				tmp[j]=BCD_INT32(&tempManyData[0+j*4], 4)*100;
			}
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,20);
		SendIndex=SendIndex+20;
		//SendNAK(F, P, 0x0d);
		//return 0;
	}
	if (dflg==1)
	{
		IsDataFlag=0;
		memset(Temp_FilePath,0x00,60);
		sprintf((char *)Temp_FilePath,"/nand/DataCurr/%04d/curr.dat",P);
		if ((MeterType == 9) || (MeterType == 6))
		{
			dftype=1;//comm
		}
		else
		{
			dftype=1;
		}
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
		if(IsDataFlag==1)
		{
			IsDataFlag=getMetersData(MeterType,&tempManyData[0],CJQno,MeterNo,0x91,0x10,0,4,5,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,20);
				SendIndex=SendIndex+20;
				//SendNAK(F, P, 0x0d);
				//return 0;
			}
			else
			{
				memcpy(&tmp2,&JSetPara_AFN04_3761_2009->Point[P-1].f25.V_BeiLv[0],2);
				memcpy(&tmp3,&JSetPara_AFN04_3761_2009->Point[P-1].f25.I_BeiLv[0],2);
				tmp2=1;
				tmp3=1;
				for(j=0;j<5;j++)
				{
					tmp[j]=(BCD_INT32(&tempManyData[0+j*4], 4)*100)-tmp[j];
					INT32U_BCD(tmp[j], &tempData[0], 4);
					memcpy(&SendBuff[SendIndex],&tempData[0],4);
					SendIndex=SendIndex+4;
				}
			}
		}
		else
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 0;
		}
	}
//	if (AutoFlg!=0) return 1; EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 1;
}

INT16U Level1Data_Curr_F47_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)
{
	INT16U i,IsDataFlag,j,dftype,dflg;
	INT8U Temp_FilePath[60],tempManyData[50],tempData[50],CJQno,MeterNo,MeterType;
	INT32S tmp[5],tmp2=0,tmp3=0;
	TS ts;
	for(i=0;i<5;i++)
		tmp[i]=0;

	TSGet(&ts);
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	//if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	SendBuff[SendIndex++]=FeiLvNum;

	//��������
	IsDataFlag=0;
	LDType=2;
	dflg=0;
	memset(Temp_FilePath,0x00,60);
	sprintf((char *)Temp_FilePath,"/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,3);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&tempManyData[0],CJQno,MeterNo,0x90,0x20,0,4,5,0,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 0;
		}
		else
		{
			dflg=1;
			memcpy(&tmp2,&JSetPara_AFN04_3761_2009->Point[P-1].f25.V_BeiLv[0],2);
			memcpy(&tmp3,&JSetPara_AFN04_3761_2009->Point[P-1].f25.I_BeiLv[0],2);
			tmp2=1;
			tmp3=1;
			for(j=0;j<5;j++)
			{
				tmp[j]=BCD_INT32(&tempManyData[0+j*4], 4)*100;
			}
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,20);
		SendIndex=SendIndex+20;
		//SendNAK(F, P, 0x0d);
		//return 0;
	}
	if (dflg==1)
	{
		IsDataFlag=0;
		memset(Temp_FilePath,0x00,60);
		sprintf((char *)Temp_FilePath,"/nand/DataCurr/%04d/curr.dat",P);
		if ((MeterType == 9) || (MeterType == 6))
		{
			dftype=1;//comm
		}
		else
		{
			dftype=1;
		}
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
		if(IsDataFlag==1)
		{
			IsDataFlag=getMetersData(MeterType,&tempManyData[0],CJQno,MeterNo,0x90,0x20,0,4,5,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,20);
				SendIndex=SendIndex+20;
				//SendNAK(F, P, 0x0d);
				//return 0;
			}
			else
			{
				memcpy(&tmp2,&JSetPara_AFN04_3761_2009->Point[P-1].f25.V_BeiLv[0],2);
				memcpy(&tmp3,&JSetPara_AFN04_3761_2009->Point[P-1].f25.I_BeiLv[0],2);
				tmp2=1;
				tmp3=1;
				for(j=0;j<5;j++)
				{
					tmp[j]=(BCD_INT32(&tempManyData[0+j*4], 4)*100)-tmp[j];
					INT32U_BCD(tmp[j], &tempData[0], 4);
					memcpy(&SendBuff[SendIndex],&tempData[0],4);
					SendIndex=SendIndex+4;
				}
			}
		}
		else
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 0;
		}
	}
	//if (AutoFlg!=0) return 1; EC();
	//TP();
	//FrameTailCreate_Send(0);
	return 1;
}

INT16U Level1Data_Curr_F48_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)
{
	INT16U i,IsDataFlag,j,dftype,dflg;
	INT8U Temp_FilePath[60],tempManyData[50],tempData[50],CJQno,MeterNo,MeterType;
	INT32S tmp[5],tmp2=0,tmp3=0;
	TS ts;
	for(i=0;i<5;i++)
		tmp[i]=0;

	TSGet(&ts);
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	//if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	SendBuff[SendIndex++]=FeiLvNum;

	//��������
	IsDataFlag=0;
	LDType=2;
	dflg=0;
	memset(Temp_FilePath,0x00,60);
	sprintf((char *)Temp_FilePath,"/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,3);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&tempManyData[0],CJQno,MeterNo,0x91,0x20,0,4,5,0,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 0;
		}
		else
		{
			dflg=1;
			memcpy(&tmp2,&JSetPara_AFN04_3761_2009->Point[P-1].f25.V_BeiLv[0],2);
			memcpy(&tmp3,&JSetPara_AFN04_3761_2009->Point[P-1].f25.I_BeiLv[0],2);
			tmp2=1;
			tmp3=1;
			for(j=0;j<5;j++)
			{
				tmp[j]=BCD_INT32(&tempManyData[0+j*4], 4)*100;
			}
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,20);
		SendIndex=SendIndex+20;
		//SendNAK(F, P, 0x0d);
		//return 0;
	}
	if(dflg==1)
	{
		IsDataFlag=0;
		memset(Temp_FilePath,0x00,60);
		sprintf((char *)Temp_FilePath,"/nand/DataCurr/%04d/curr.dat",P);
		if ((MeterType == 9) || (MeterType == 6))
		{
			dftype=1;//comm
		}
		else
		{
			dftype=1;
		}
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
		if(IsDataFlag==1)
		{
			IsDataFlag=getMetersData(MeterType,&tempManyData[0],CJQno,MeterNo,0x91,0x20,0,4,5,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,20);
				SendIndex=SendIndex+20;
				//SendNAK(F, P, 0x0d);
				//return 0;
			}
			else
			{
				memcpy(&tmp2,&JSetPara_AFN04_3761_2009->Point[P-1].f25.V_BeiLv[0],2);
				memcpy(&tmp3,&JSetPara_AFN04_3761_2009->Point[P-1].f25.I_BeiLv[0],2);
				tmp2=1;
				tmp3=1;
				for(j=0;j<5;j++)
				{
					tmp[j]=(BCD_INT32(&tempManyData[0+j*4], 4)*100)-tmp[j];
					INT32U_BCD(tmp[j], &tempData[0], 4);
					memcpy(&SendBuff[SendIndex],&tempData[0],4);
					SendIndex=SendIndex+4;
				}
			}
		}
		else
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 0;
		}
	}
//	if (AutoFlg!=0) return 1; EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 1;
}

INT16U Level1Data_Curr_F49_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ��ѹ��������λ��
{
	INT8U CJQno, MeterNo, MeterType;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60];
	TS ts;
	
	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
	//if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;

	SendBuff[SendIndex++] = FeiLvNum;
	sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",P);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x00,0x21,0,3,2,0,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
//			memset(&SendBuff[SendIndex],OxXX,12); //F49gai
//			SendIndex=SendIndex+12;
//			//SendNAK(F, P, 0x0d);
//			//return 0;

			INT32U_BCD(Jdatafileinfo->jc.RES.RES_UAJ ,&SendBuff[SendIndex],2);
			SendIndex=SendIndex+2;
			INT32U_BCD(Jdatafileinfo->jc.RES.RES_UBJ,&SendBuff[SendIndex],2);
			SendIndex=SendIndex+2;
			INT32U_BCD(Jdatafileinfo->jc.RES.RES_UCJ,&SendBuff[SendIndex],2);
			SendIndex=SendIndex+2;
			INT32U_BCD(Jdatafileinfo->jc.RES.RES_IAJ,&SendBuff[SendIndex],2);
			SendIndex=SendIndex+2;
			INT32U_BCD(Jdatafileinfo->jc.RES.RES_IBJ,&SendBuff[SendIndex],2);
			SendIndex=SendIndex+2;
			INT32U_BCD(Jdatafileinfo->jc.RES.RES_ICJ,&SendBuff[SendIndex],2);
			SendIndex=SendIndex+2;

		}
		else
		{
			SendIndex = SendIndex + 6;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x00,0x01,0,3,2,0,0,0,0,dftype);
			SendIndex = SendIndex + 6;
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,12);
		SendIndex=SendIndex+12;
		//SendNAK(F, P, 0x0d);
		//return 0;
	}
//	if (AutoFlg!=0) return 1; EC();
//	TP();
//	FrameTailCreate_Send(0);

	return 1;
}

INT16U Level1Data_Curr_F73_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)
{
	//songjian
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));//����1�����ݵı���ͷ
	SendBuff[SendIndex++] = Jproginfo->BeiYong[0];
	SendBuff[SendIndex++] = Jproginfo->BeiYong[1];
	SdPrintf(YNPrint,PreFix,"Level1Data_Curr_F73_Get   Jproginfo->BeiYong[1][0] = %02x%02x\n",Jproginfo->BeiYong[1],Jproginfo->BeiYong[0]);
	//EC();
	//TP();
	//FrameTailCreate_Send(0);//���ͱ���β��������
	//return 1;
	return 1;
}



INT16U Level1Data_Curr_F97_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)			//Сʱ����A���ѹ    9.23
{
	INT16U IsDataFlag;
	TS ts;
	INT8U Temp_FilePath[60];
	INT8U CJQno,MeterNo,MeterType,midu;

	TSGet(&ts);

	//if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));

	SendBuff[SendIndex]=((ts.Hour/10)<<4)+(ts.Hour%10);
	SendIndex=SendIndex+1;
	SendBuff[SendIndex]=1;			//�����ܶȣ�4���㶳������
	SendIndex=SendIndex+1;

	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;

	ts.Sec=0;
	ts.Hour = (ts.Hour+23)%24;
	for(midu=0;midu<4;midu++) {		//15�֣�30�֣�45�֣�0��
		ts.Minute=((midu+1)*15)%60;
		if(midu == 3)  {
			ts.Hour = (ts.Hour+25)%24;
		}
		IsDataFlag=0;
		memset(Temp_FilePath,0,60);
		sprintf((char *)Temp_FilePath,"/nand/DataHour/%04d%02d%02d/%04d/%04d%02d%02d%02d%02d.dat",
			ts.Year,ts.Month,ts.Day,P,ts.Year,ts.Month,ts.Day,ts.Hour,ts.Minute);
		SdPrintf(YNPrint,PreFix, "\nF97��Сʱ�����ļ�=%s",Temp_FilePath);

		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);//��ȡ�ļ� �洢��ȫ�ֱ��� smfile ��
		if(IsDataFlag==1)
		{//ָ���ļ���ȡ�ɹ�
			SdPrintf(YNPrint,PreFix, "F97���ļ���ȡ�ɹ�\n");
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb6,0x11,0,2,1,0,0,0,0,1);
			if (IsDataFlag == 0)
			{//������û���ҵ�����
				SdPrintf(YNPrint,PreFix, "\nF97��������û�ҵ��� ��b6 11��");
				memset(&SendBuff[SendIndex],0,2);
			}
			SendIndex=SendIndex+2;
		}
		else
		{//�ļ���ȡʧ��
			SdPrintf(YNPrint,PreFix, "F97��-----------�ļ���ȡʧ��\n");
			memset(&SendBuff[SendIndex],0,2);
			SendIndex=SendIndex+2;
		}

	}
//	if (AutoFlg!=0) return 1;
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 1;
}

INT16U Level1Data_Curr_F98_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)			//Сʱ����B���ѹ 9.23
{
	INT16U IsDataFlag;
	TS ts;
	INT8U Temp_FilePath[60];
	INT8U CJQno,MeterNo,MeterType,midu;

	TSGet(&ts);
	ts.Minute=0;
	ts.Sec=0;

	//if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));

	SendBuff[SendIndex]=((ts.Hour/10)<<4)+(ts.Hour%10);
	SendIndex=SendIndex+1;
	SendBuff[SendIndex]=1;			//�����ܶȣ�1Сʱ��������
	SendIndex=SendIndex+1;

	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;


	ts.Sec=0;
	ts.Hour = (ts.Hour+23)%24;
	for(midu=0;midu<4;midu++) {		//15�֣�30�֣�45�֣�0��
		ts.Minute=((midu+1)*15)%60;
		if(midu == 3)  {
			ts.Hour = (ts.Hour+25)%24;
		}
		IsDataFlag=0;
		memset(Temp_FilePath,0,60);
		sprintf((char *)Temp_FilePath,"/nand/DataHour/%04d%02d%02d/%04d/%04d%02d%02d%02d%02d.dat",
			ts.Year,ts.Month,ts.Day,P,ts.Year,ts.Month,ts.Day,ts.Hour,ts.Minute);
		SdPrintf(YNPrint,PreFix, "\nF98��Сʱ�����ļ�=%s",Temp_FilePath);

		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);//��ȡ�ļ� �洢��ȫ�ֱ��� smfile ��
		if(IsDataFlag==1)
		{//ָ���ļ���ȡ�ɹ�
			SdPrintf(YNPrint,PreFix, "F98���ļ���ȡ�ɹ�\n");
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb6,0x12,0,2,1,0,0,0,0,1);
			if (IsDataFlag == 0)
			{//������û���ҵ�����
				SdPrintf(YNPrint,PreFix, "\nF98��������û�ҵ��� ��b6 11��");
				memset(&SendBuff[SendIndex],0,2);
			}
			SendIndex=SendIndex+2;
		}
		else
		{//�ļ���ȡʧ��
			SdPrintf(YNPrint,PreFix, "F98��-----------�ļ���ȡʧ��\n");
			memset(&SendBuff[SendIndex],0,2);
			SendIndex=SendIndex+2;
		}
	}
	//if (AutoFlg!=0) return 1;
	//EC();
	//TP();
	//FrameTailCreate_Send(0);
	return 1;
}


INT16U Level1Data_Curr_F99_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)			//Сʱ����C���ѹ  9.23
{
	INT16U IsDataFlag;
	TS ts;
	INT8U Temp_FilePath[60];
	INT8U CJQno,MeterNo,MeterType,midu;

	TSGet(&ts);
	ts.Minute=0;
	ts.Sec=0;

	//if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));

	SendBuff[SendIndex]=((ts.Hour/10)<<4)+(ts.Hour%10);
	SendIndex=SendIndex+1;
	SendBuff[SendIndex]=1;			//�����ܶȣ�1Сʱ��������
	SendIndex=SendIndex+1;

	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;

	ts.Sec=0;
	ts.Hour = (ts.Hour+23)%24;
	for(midu=0;midu<4;midu++) {		//15�֣�30�֣�45�֣�0��
		ts.Minute=((midu+1)*15)%60;
		if(midu == 3)  {
			ts.Hour = (ts.Hour+25)%24;
		}
		IsDataFlag=0;
		memset(Temp_FilePath,0,60);
		sprintf((char *)Temp_FilePath,"/nand/DataHour/%04d%02d%02d/%04d/%04d%02d%02d%02d%02d.dat",
			ts.Year,ts.Month,ts.Day,P,ts.Year,ts.Month,ts.Day,ts.Hour,ts.Minute);
		SdPrintf(YNPrint,PreFix, "F99��Сʱ�����ļ�=%s",Temp_FilePath);

		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);//��ȡ�ļ� �洢��ȫ�ֱ��� smfile ��
		if(IsDataFlag==1)
		{//ָ���ļ���ȡ�ɹ�
			SdPrintf(YNPrint,PreFix, "F99���ļ���ȡ�ɹ�\n");
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb6,0x13,0,2,1,0,0,0,0,1);
			if (IsDataFlag == 0)
			{//������û���ҵ�����
				SdPrintf(YNPrint,PreFix, "\nF99��������û�ҵ��� ��b6 11��");
				memset(&SendBuff[SendIndex],0,2);
			}
			SendIndex=SendIndex+2;
		}
		else
		{//�ļ���ȡʧ��
			SdPrintf(YNPrint,PreFix, "F99��-----------�ļ���ȡʧ��\n");
			memset(&SendBuff[SendIndex],0,2);
			SendIndex=SendIndex+2;
		}
	}
	//if (AutoFlg!=0) return 1;
	//EC();
	//TP();
	//FrameTailCreate_Send(0);
	return 1;
}

INT16U Level1Data_Curr_F100_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)			//Сʱ����A�����  9.23
{
	INT16U IsDataFlag;
	TS ts;
	INT8U Temp_FilePath[60];
	INT8U CJQno,MeterNo,MeterType,midu;

	TSGet(&ts);
	ts.Minute=0;
	ts.Sec=0;

	//if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));

	SendBuff[SendIndex]=((ts.Hour/10)<<4)+(ts.Hour%10);
	SendIndex=SendIndex+1;
	SendBuff[SendIndex]=1;			//�����ܶȣ�1Сʱ��������
	SendIndex=SendIndex+1;

	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;

	ts.Sec=0;
	ts.Hour = (ts.Hour+23)%24;
	for(midu=0;midu<4;midu++) {		//15�֣�30�֣�45�֣�0��
		ts.Minute=((midu+1)*15)%60;
		if(midu == 3)  {
			ts.Hour = (ts.Hour+25)%24;
		}
		IsDataFlag=0;
		memset(Temp_FilePath,0,60);
		sprintf((char *)Temp_FilePath,"/nand/DataHour/%04d%02d%02d/%04d/%04d%02d%02d%02d%02d.dat",
			ts.Year,ts.Month,ts.Day,P,ts.Year,ts.Month,ts.Day,ts.Hour,ts.Minute);
		SdPrintf(YNPrint,PreFix, "\nF100��Сʱ�����ļ�=%s",Temp_FilePath);

		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);//��ȡ�ļ� �洢��ȫ�ֱ��� smfile ��
		if(IsDataFlag==1)
		{//ָ���ļ���ȡ�ɹ�
			SdPrintf(YNPrint,PreFix, "F100���ļ���ȡ�ɹ�\n");
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb6,0x21,0,3,1,0,0,0,0,1);
			if (IsDataFlag == 0)
			{//������û���ҵ�����
				SdPrintf(YNPrint,PreFix, "\nF100��������û�ҵ��� ��b6 11��");
				memset(&SendBuff[SendIndex],0,3);
			}
			SendIndex=SendIndex+3;
		}
		else
		{//�ļ���ȡʧ��
			SdPrintf(YNPrint,PreFix, "F100��-----------�ļ���ȡʧ��\n");
			memset(&SendBuff[SendIndex],0,3);
			SendIndex=SendIndex+3;
		}
	}
	//if (AutoFlg!=0) return 1;
	//EC();
	//TP();
	//FrameTailCreate_Send(0);
	return 1;
}

INT16U Level1Data_Curr_F101_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)			//Сʱ����B�����   9.23
{
	INT16U IsDataFlag;
	TS ts;
	INT8U Temp_FilePath[60];
	INT8U CJQno,MeterNo,MeterType,midu;

	TSGet(&ts);
	ts.Minute=0;
	ts.Sec=0;

	//if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));

	SendBuff[SendIndex]=((ts.Hour/10)<<4)+(ts.Hour%10);
	SendIndex=SendIndex+1;
	SendBuff[SendIndex]=1;			//�����ܶȣ�1Сʱ��������
	SendIndex=SendIndex+1;

	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;

	ts.Sec=0;
	ts.Hour = (ts.Hour+23)%24;
	for(midu=0;midu<4;midu++) {		//15�֣�30�֣�45�֣�0��
		ts.Minute=((midu+1)*15)%60;
		if(midu == 3)  {
			ts.Hour = (ts.Hour+25)%24;
		}
		IsDataFlag=0;
		memset(Temp_FilePath,0,60);
		sprintf((char *)Temp_FilePath,"/nand/DataHour/%04d%02d%02d/%04d/%04d%02d%02d%02d%02d.dat",
			ts.Year,ts.Month,ts.Day,P,ts.Year,ts.Month,ts.Day,ts.Hour,ts.Minute);
		SdPrintf(YNPrint,PreFix, "\nF101��Сʱ�����ļ�=%s",Temp_FilePath);

		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);//��ȡ�ļ� �洢��ȫ�ֱ��� smfile ��
		if(IsDataFlag==1)
		{//ָ���ļ���ȡ�ɹ�
			SdPrintf(YNPrint,PreFix, "F101���ļ���ȡ�ɹ�\n");
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb6,0x22,0,3,1,0,0,0,0,1);
			if (IsDataFlag == 0)
			{//������û���ҵ�����
				SdPrintf(YNPrint,PreFix, "\nF101��������û�ҵ��� ��b6 11��");
				memset(&SendBuff[SendIndex],0,3);
			}
			SendIndex=SendIndex+3;
		}
		else
		{//�ļ���ȡʧ��
			SdPrintf(YNPrint,PreFix, "F101��-----------�ļ���ȡʧ��\n");
			memset(&SendBuff[SendIndex],0,3);
			SendIndex=SendIndex+3;
		}
	}
	//if (AutoFlg!=0) return 1;
	//EC();
	//TP();
	//FrameTailCreate_Send(0);
	return 1;
}
INT16U Level1Data_Curr_F102_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)			//Сʱ����C�����   9.23
{
	INT16U IsDataFlag;
	TS ts;
	INT8U Temp_FilePath[60];
	INT8U CJQno,MeterNo,MeterType,midu;

	TSGet(&ts);
	ts.Minute=0;
	ts.Sec=0;

	//if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));

	SendBuff[SendIndex]=((ts.Hour/10)<<4)+(ts.Hour%10);
	SendIndex=SendIndex+1;
	SendBuff[SendIndex]=1;			//�����ܶȣ�1Сʱ��������
	SendIndex=SendIndex+1;

	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;

	ts.Sec=0;
	ts.Hour = (ts.Hour+23)%24;
	for(midu=0;midu<4;midu++) {		//15�֣�30�֣�45�֣�0��
		ts.Minute=((midu+1)*15)%60;
		if(midu == 3)  {
			ts.Hour = (ts.Hour+25)%24;
		}
		IsDataFlag=0;
		memset(Temp_FilePath,0,60);
		sprintf((char *)Temp_FilePath,"/nand/DataHour/%04d%02d%02d/%04d/%04d%02d%02d%02d%02d.dat",
			ts.Year,ts.Month,ts.Day,P,ts.Year,ts.Month,ts.Day,ts.Hour,ts.Minute);
		SdPrintf(YNPrint,PreFix, "\nF102��Сʱ�����ļ�=%s",Temp_FilePath);

		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);//��ȡ�ļ� �洢��ȫ�ֱ��� smfile ��
		if(IsDataFlag==1)
		{//ָ���ļ���ȡ�ɹ�
			SdPrintf(YNPrint,PreFix, "F102���ļ���ȡ�ɹ�\n");
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb6,0x23,0,3,1,0,0,0,0,1);
			if (IsDataFlag == 0)
			{//������û���ҵ�����
				SdPrintf(YNPrint,PreFix, "\nF102��������û�ҵ��� ��b6 11��");
				memset(&SendBuff[SendIndex],0,3);
			}
			SendIndex=SendIndex+3;
		}
		else
		{//�ļ���ȡʧ��
			SdPrintf(YNPrint,PreFix, "F102��-----------�ļ���ȡʧ��\n");
			memset(&SendBuff[SendIndex],0,3);
			SendIndex=SendIndex+3;
		}
	}
	//if (AutoFlg!=0) return 1;
	//EC();
	//TP();
	//FrameTailCreate_Send(0);
	return 1;
}

INT16U Level1Data_Curr_F129_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ�����й�����ʾֵ
{
	INT8U CJQno, MeterNo, MeterType;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],i;
	TS ts;
	SdPrintf(YNPrint,PreFix,"Level1Data_Curr_F129_Get\n");
	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
	//if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port==1)
	{
		INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
	}else
	{
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
	}

	SendBuff[SendIndex++] = FeiLvNum;
	sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",P);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x90,0x10,0,4,5,1,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,25);
			SendIndex=SendIndex+25;
			//SendNAK(F, P, 0x0d);
			//return 0;
		}
		else
		{
			for(i=0;i<5;i++)
			{
				if((SendBuff[(SendIndex+1)+i*5]==OxXX)&&
				   (SendBuff[(SendIndex+2)+i*5]==OxXX)&&
				   (SendBuff[(SendIndex+3)+i*5]==OxXX)&&
				   (SendBuff[(SendIndex+4)+i*5]==OxXX))
						memset(&SendBuff[SendIndex+0+i*5],OxXX,5);
			}
			SendIndex = SendIndex + 25;
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,25);
		SendIndex=SendIndex+25;
		//SendNAK(F, P, 0x0d);
		//return 0;
	}
	//if (AutoFlg!=0) return 1; EC();
	//TP();
	//FrameTailCreate_Send(0);

	return 1;
}

INT16U Level1Data_Curr_F130_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ�����޹�����ʾֵ
{
	INT8U CJQno, MeterNo, MeterType;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60];
	TS ts;
	
	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
	//if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port==1)
	{
		INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
	}else
	{
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
	}

	SendBuff[SendIndex++] = FeiLvNum;
	sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",P);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x10,0,4,5,0,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 0;
		}
		else SendIndex = SendIndex + 20;
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,20);
		SendIndex=SendIndex+20;
		//SendNAK(F, P, 0x0d);
		//return 0;
	}
	//if (AutoFlg!=0) return 1; EC();
	//TP();
	//FrameTailCreate_Send(0);

	return 1;
}

INT16U Level1Data_Curr_F131_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ�����й�����ʾֵ
{
	INT8U CJQno, MeterNo, MeterType;
	INT16U IsDataFlag,dftype,i;
	INT8U Temp_FilePath[60];
	TS ts;
	
	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
	//if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port==1)
	{
		INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
	}else
	{
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
	}

	SendBuff[SendIndex++] = FeiLvNum;
	sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",P);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x90,0x20,0,4,5,1,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,25);
			SendIndex=SendIndex+25;
			//SendNAK(F, P, 0x0d);
			//return 0;
		}
		else
		{
			for(i=0;i<5;i++)
			{
				if((SendBuff[(SendIndex+1)+i*5]==OxXX)&&
				   (SendBuff[(SendIndex+2)+i*5]==OxXX)&&
				   (SendBuff[(SendIndex+3)+i*5]==OxXX)&&
				   (SendBuff[(SendIndex+4)+i*5]==OxXX))
						memset(&SendBuff[SendIndex+0+i*5],OxXX,5);
			}
			SendIndex = SendIndex + 25;
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,25);
		SendIndex=SendIndex+25;
		//SendNAK(F, P, 0x0d);
		//return 0;
	}
	//if (AutoFlg!=0) return 1; EC();
	//TP();
	//FrameTailCreate_Send(0);

	return 1;
}

INT16U Level1Data_Curr_F132_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ�����޹�������޹�1������ʾֵ
{
	INT8U CJQno, MeterNo, MeterType;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60];
	TS ts;
	
	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
	//if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port==1)
	{
		INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
	}else
	{
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
	}

	SendBuff[SendIndex++] = FeiLvNum;
	sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",P);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x20,0,4,5,0,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 0;
		}
		else SendIndex = SendIndex + 20;
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,20);
		SendIndex=SendIndex+20;
		//SendNAK(F, P, 0x0d);
		//return 0;
	}
	//if (AutoFlg!=0) return 1; EC();
	//TP();
	//FrameTailCreate_Send(0);

	return 1;
}

INT16U Level1Data_Curr_F133_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰһ�����޹�����ʾֵ
{
	INT8U CJQno, MeterNo, MeterType;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60];
	TS ts;
	
	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
	//if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port==1)
	{
		INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
	}else
	{
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
	}

	SendBuff[SendIndex++] = FeiLvNum;
	sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",P);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x30,0,4,5,0,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 0;
		}
		else SendIndex = SendIndex + 20;
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,20);
		SendIndex=SendIndex+20;
		//SendNAK(F, P, 0x0d);
		//return 0;
	}
	//if (AutoFlg!=0) return 1; EC();
	//TP();
	//FrameTailCreate_Send(0);

	return 1;
}

INT16U Level1Data_Curr_F134_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ�������޹�����ʾֵ
{
	INT8U CJQno, MeterNo, MeterType;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60];
	TS ts;
	
	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
	//if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port==1)
	{
		INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
	}else
	{
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
	}

	SendBuff[SendIndex++] = FeiLvNum;
	sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",P);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x50,0,4,5,0,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 0;
		}
		else SendIndex = SendIndex + 20;
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,20);
		SendIndex=SendIndex+20;
		//SendNAK(F, P, 0x0d);
		//return 0;
	}
	//if (AutoFlg!=0) return 1; EC();
	//TP();
	//FrameTailCreate_Send(0);

	return 1;
}

INT16U Level1Data_Curr_F135_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ�������޹�����ʾֵ
{
	INT8U CJQno, MeterNo, MeterType;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60];
	TS ts;
	
	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
	//if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port==1)
	{
		INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
	}else
	{
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
	}

	SendBuff[SendIndex++] = FeiLvNum;
	sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",P);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x60,0,4,5,0,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 0;
		}
		else SendIndex = SendIndex + 20;
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,20);
		SendIndex=SendIndex+20;
		//SendNAK(F, P, 0x0d);
		//return 0;
	}
	//if (AutoFlg!=0) return 1; EC();
	//TP();
	//FrameTailCreate_Send(0);

	return 1;
}

INT16U Level1Data_Curr_F136_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ�������޹�����ʾֵ
{
	INT8U CJQno, MeterNo, MeterType;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60];
	TS ts;
	
	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
	//if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port==1)
	{
		INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
	}else
	{
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
	}

	SendBuff[SendIndex++] = FeiLvNum;
	sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",P);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x40,0,4,5,0,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 0;
		}
		else SendIndex = SendIndex + 20;
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,20);
		SendIndex=SendIndex+20;
		//SendNAK(F, P, 0x0d);
		//return 0;
	}
	//if (AutoFlg!=0) return 1; EC();
	//TP();
	//FrameTailCreate_Send(0);

	return 1;
}
//-------------------------------------------------
int Stat_day_Curve_OneLevel(INT16U F,INT16U P,INT8U *Data,INT8U DI1,INT8U DI0,INT8U beg,INT8U size,INT8U DIN,INT8U BeX)
{
	INT16U IsDataFlag;
	TS ts;
	INT8U Temp_FilePath[60];
	INT8U CJQno,MeterNo,MeterType,midu;

	TSGet(&ts);

	SendBuff[SendIndex]=((ts.Hour/10)<<4)+(ts.Hour%10);
	SendIndex=SendIndex+1;
	SendBuff[SendIndex]=1;			//�����ܶȣ�4���㶳������
	SendIndex=SendIndex+1;

	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;

	ts.Sec=0;
	ts.Hour = (ts.Hour+23)%24;
	for(midu=0;midu<4;midu++) {		//15�֣�30�֣�45�֣�0��
		ts.Minute=((midu+1)*15)%60;
		if(midu == 3)  {
			ts.Hour = (ts.Hour+25)%24;
		}
		IsDataFlag=0;
		memset(Temp_FilePath,0,60);
		sprintf((char *)Temp_FilePath,"/nand/DataHour/%04d%02d%02d/%04d/%04d%02d%02d%02d%02d.dat",
			ts.Year,ts.Month,ts.Day,P,ts.Year,ts.Month,ts.Day,ts.Hour,ts.Minute);
		SdPrintf(YNPrint,PreFix, "\nF97��Сʱ�����ļ�=%s",Temp_FilePath);

		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);//��ȡ�ļ� �洢��ȫ�ֱ��� smfile ��
		if(IsDataFlag==1)
		{//ָ���ļ���ȡ�ɹ�
			SdPrintf(YNPrint,PreFix, "F97���ļ���ȡ�ɹ�\n");
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,DI1,DI0,beg,size,DIN,0,0,0,0,1);
			if (IsDataFlag == 0)
			{//������û���ҵ�����
				SdPrintf(YNPrint,PreFix, "\nF97��������û�ҵ��� ��b6 11��");
				memset(&SendBuff[SendIndex],0x00,size);
			}
			SendIndex=SendIndex+size;
		}
		else
		{//�ļ���ȡʧ��
			SdPrintf(YNPrint,PreFix, "F97��-----------�ļ���ȡʧ��\n");
			memset(&SendBuff[SendIndex],0x00,size);
			SendIndex=SendIndex+size;
		}
	}
	return 1;
}
INT16U Level1Data_Curr_F89_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve_OneLevel(F,P,Data,0xb6,0x30,0,3,1,0);
}
INT16U Level1Data_Curr_F90_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve_OneLevel(F,P,Data,0xb6,0x31,3,3,1,0);
}
INT16U Level1Data_Curr_F91_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve_OneLevel(F,P,Data,0xb6,0x32,6,3,1,0);
}
INT16U Level1Data_Curr_F92_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve_OneLevel(F,P,Data,0xb6,0x33,9,3,1,0);
}
INT16U Level1Data_Curr_F93_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve_OneLevel(F,P,Data,0xb6,0x40,0,3,1,0);
}
INT16U Level1Data_Curr_F94_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve_OneLevel(F,P,Data,0xb6,0x41,3,3,1,0);
}
INT16U Level1Data_Curr_F95_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve_OneLevel(F,P,Data,0xb6,0x42,6,3,1,0);
}
INT16U Level1Data_Curr_F96_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve_OneLevel(F,P,Data,0xb6,0x43,9,3,1,0);
}

INT16U Level1Data_Curr_F103_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve_OneLevel(F,P,Data,0xb6,0x24,0,3,1,0);
}

int Stat_day_Elc_Curve_l1(INT16U F,INT16U P,INT8U *Data,INT8U DI1,INT8U DI0,INT8U size,INT8U DIN,INT8U BeX)		//9.24 �����й��ܵ���������
{
	INT32S tmp=0,tmp2=0,tmp3=0;
	INT16U IsDataFlag,fd,dftype,tmpindx;
	TS ts,ts2;
	int i;
	INT8U tempManyData[50],tempData[50];
	INT8U Temp_FilePath[60];
	INT8U CJQno,MeterNo,MeterType,midu;
	int min = 15;
	TSGet(&ts);
	ts2 = ts;
	dftype = 1;
	tmpindx=SendIndex;
	TimeDecrease(&ts2,2,min);
	SendBuff[SendIndex]=((ts.Hour/10)<<4)+(ts.Hour%10);
	SendIndex=SendIndex+1;
	SendBuff[SendIndex]=1;			//�����ܶȣ�4���㶳������
	SendIndex=SendIndex+1;

	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	fd = 0;
	ts.Sec=0;
	ts.Hour = (ts.Hour+23)%24;
	for(midu=0;midu<4;midu++) {		//15�֣�30�֣�45�֣�0��
		ts.Minute=((midu+1)*15)%60;
		if(midu == 3)  {
			ts.Hour = (ts.Hour+25)%24;
		}
		IsDataFlag=0;
		memset(Temp_FilePath,0,60);
		sprintf((char *)Temp_FilePath,"/nand/DataHour/%04d%02d%02d/%04d/%04d%02d%02d%02d%02d.dat",
			ts.Year,ts.Month,ts.Day,P,ts.Year,ts.Month,ts.Day,ts.Hour,ts.Minute);
		SdPrintf(YNPrint,PreFix, "\nF97��Сʱ�����ļ�=%s",Temp_FilePath);

		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);//��ȡ�ļ� �洢��ȫ�ֱ��� smfile ��
		if(IsDataFlag==1)
		{//ָ���ļ���ȡ�ɹ�
			IsDataFlag=getMetersData(MeterType,&tempManyData[0],CJQno,MeterNo,DI1,DI0,0,size,DIN,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				for(i=0;i<BeX;i++)
					SendBuff[SendIndex++]=0x00;
				memset(&SendBuff[SendIndex],0x00,size);
				SendIndex=SendIndex+size;

				TimeAdd(&ts,2,min);
				TimeAdd(&ts2,2,min);
				continue;
			}
			for(i=0;i<BeX;i++)
				SendBuff[SendIndex++]=0x00;
			memcpy(&tmp2,&JSetPara_AFN04_3761_2009->Point[P-1].f25.V_BeiLv[0],2);
			memcpy(&tmp3,&JSetPara_AFN04_3761_2009->Point[P-1].f25.I_BeiLv[0],2);
			tmp=BCD_INT32(&tempManyData[0], size)*tmp2*tmp3;
			SdPrintf(YNPrint,PreFix, "  DataHour __tmp1=%d\n\r",tmp);
		}
		else
		{//�ļ���ȡʧ��

			for(i=0;i<BeX;i++)
				SendBuff[SendIndex++]=0x00;
			memset(&SendBuff[SendIndex],0x00,size);
			SendIndex=SendIndex+size;

			TimeAdd(&ts,2,min);
			TimeAdd(&ts2,2,min);
			continue;
		}

		IsDataFlag=0;
		sprintf((char *)Temp_FilePath,"/nand/DataHour/%04d%02d%02d/%04d/%04d%02d%02d%02d%02d.dat",
				ts2.Year,ts2.Month,ts2.Day,P,ts2.Year,ts2.Month,ts2.Day,ts2.Hour,ts2.Minute);
		SdPrintf(YNPrint,PreFix, "  F97,F98����2��DataHour:Temp_FilePath=%s\n\r",Temp_FilePath);
		if((MeterType==9)|| (MeterType==6)){
			dftype=1;//comm
		}
		else
		{
			dftype=1;
		}
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
		if(IsDataFlag==1)
		{
			IsDataFlag=getMetersData(MeterType,&tempManyData[0],CJQno,MeterNo,DI1,DI0,0,size,DIN,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				for(i=0;i<BeX;i++)
					SendBuff[SendIndex++]=0x00;
				memset(&SendBuff[SendIndex],0x00,size);
				SendIndex=SendIndex+size;
				TimeAdd(&ts,2,min);
				TimeAdd(&ts2,2,min);
				continue;
			}
			for(i=0;i<BeX;i++)
				SendBuff[SendIndex++]=0x00;
			memcpy(&tmp2,&JSetPara_AFN04_3761_2009->Point[P-1].f25.V_BeiLv[0],2);
			memcpy(&tmp3,&JSetPara_AFN04_3761_2009->Point[P-1].f25.I_BeiLv[0],2);
			tmp=tmp-(BCD_INT32(&tempManyData[0], size)*tmp2*tmp3);
			if (tmp<0)
				tmp=tmp*(-1);

			SdPrintf(YNPrint,PreFix, "  F97,F98���ߣ�DataDay:tmp2=%d\n\r",BCD_INT32(&tempManyData[0], size));
			SdPrintf(YNPrint,PreFix, "  F97,F98  V_BeiLv=%d  :  I_BeiLv=%d   ��tmp=%d\n\r",tmp2,tmp3,tmp);
			INT32U_BCD(tmp, &tempData[0], size);
			SdPrintf(YNPrint,PreFix, "  F97,F98  tempData=%02x_%02x_%02x_%02x \n\r",tempData[0],tempData[1],tempData[2],tempData[3]);
			memcpy(&SendBuff[SendIndex],&tempData[0],size);
			SendIndex=SendIndex+size;
		}
		else
		{
			for(i=0;i<BeX;i++)
				SendBuff[SendIndex++]=0x00;
			memset(&SendBuff[SendIndex],0x00,size);
			SendIndex=SendIndex+size;
			TimeAdd(&ts,2,min);
			TimeAdd(&ts2,2,min);
			continue;
		}
		TimeAdd(&ts,2,min);
		TimeAdd(&ts2,2,min);
	}
	return 1;
}
INT16U Level1Data_Curr_F105_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data)//�����������й��ܵ�����
{
	return Stat_day_Elc_Curve_l1(F,P,Data,0x90,0x10,4,1,0);
}
INT16U Level1Data_Curr_F106_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Elc_Curve_l1(F,P,Data,0x91,0x10,4,1,0);
}

INT16U Level1Data_Curr_F107_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data)//�����㷴���й��ܵ���������
{
	return Stat_day_Elc_Curve_l1(F,P,Data,0x90,0x20,4,1,0);
}
INT16U Level1Data_Curr_F108_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data)//�����㷴���޹��ܵ���������
{
	return Stat_day_Elc_Curve_l1(F,P,Data,0x91,0x20,4,1,0);
}
INT16U Level1Data_Curr_F109_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve_OneLevel(F,P,Data,0x90,0x10,0,4,1,0);
}
INT16U Level1Data_Curr_F110_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve_OneLevel(F,P,Data,0x91,0x10,0,4,1,0);
}
INT16U Level1Data_Curr_F111_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve_OneLevel(F,P,Data,0x90,0x20,0,4,1,0);
}
INT16U Level1Data_Curr_F112_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve_OneLevel(F,P,Data,0x91,0x20,0,4,1,0);
}
INT16U Level1Data_Curr_F113_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve_OneLevel(F,P,Data,0xb6,0x50,0,2,1,0);
}
INT16U Level1Data_Curr_F114_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve_OneLevel(F,P,Data,0xb6,0x51,2,2,1,0);
}
INT16U Level1Data_Curr_F115_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve_OneLevel(F,P,Data,0xb6,0x52,4,2,1,0);
}
INT16U Level1Data_Curr_F116_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve_OneLevel(F,P,Data,0xb6,0x53,6,2,1,0);
}


//--------------------------------------------

INT16U Level1Data_Curr_F137_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ�����й�����ʾֵ
{
	INT8U CJQno, MeterNo, MeterType;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],i;
	TS ts;
	SdPrintf(YNPrint,PreFix,"Level1Data_Curr_F137_Get\n");
	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = 4;
	TimeDecrease(&ts, 5, 1);
	sprintf((char *) Temp_FilePath, "/nand/DataMonth/%04d/%02d.dat",P, ts.Month);
	dftype=1;
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
	if(IsDataFlag==1)
	{
//		INT32U_BCD(smfile.ts.Minute, &SendBuff[SendIndex], 1);
//		SendIndex++;
//		INT32U_BCD(smfile.ts.Hour, &SendBuff[SendIndex], 1);
//		SendIndex++;
//		INT32U_BCD(smfile.ts.Day, &SendBuff[SendIndex], 1);
//		SendIndex++;
//		INT32U_BCD(smfile.ts.Month, &SendBuff[SendIndex], 1);
//		SendIndex++;
//		INT32U_BCD(smfile.ts.Year%100, &SendBuff[SendIndex], 1);
//		SendIndex++;
		//SendBuff[SendIndex++] = FeiLvNum;
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x90,0x10,0,4,5,1,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],0,25);
			SendIndex=SendIndex+25;
		}
		else
		{

			for(i=0;i<5;i++)
			{
				if((SendBuff[(SendIndex+1)+i*5]==OxXX)&&
				   (SendBuff[(SendIndex+2)+i*5]==OxXX)&&
				   (SendBuff[(SendIndex+3)+i*5]==OxXX)&&
				   (SendBuff[(SendIndex+4)+i*5]==OxXX))
						memset(&SendBuff[SendIndex+0+i*5],0,5);
			}
			SendIndex = SendIndex + 25;
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],0,25);
		SendIndex=SendIndex+25;
		//SendNAK(F, P, 0x0d);
		//return 0;
	}
	//if (AutoFlg!=0) return 1; EC();
	//TP();
	//FrameTailCreate_Send(0);

	return 1;
}

INT16U Level1Data_Curr_F138_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ�����޹�����ʾֵ
{
	INT8U CJQno, MeterNo, MeterType;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60];
	TS ts;

	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = 4;
	TimeDecrease(&ts, 5, 1);
	sprintf((char *) Temp_FilePath, "/nand/DataMonth/%04d/%02d.dat",P, ts.Month);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x10,0,4,5,0,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],0,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 0;
		}
		else SendIndex = SendIndex + 20;
	}
	else
	{
		memset(&SendBuff[SendIndex],0,20);
		SendIndex=SendIndex+20;
		//SendNAK(F, P, 0x0d);
		//return 0;
	}
	//if (AutoFlg!=0) return 1; EC();
	//TP();
	//FrameTailCreate_Send(0);

	return 1;
}

INT16U Level1Data_Curr_F139_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ�����й�����ʾֵ
{
	INT8U CJQno, MeterNo, MeterType;
	INT16U IsDataFlag,dftype,i;
	INT8U Temp_FilePath[60];
	TS ts;

	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = 4;
	TimeDecrease(&ts, 5, 1);
	sprintf((char *) Temp_FilePath, "/nand/DataMonth/%04d/%02d.dat",P, ts.Month);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x90,0x20,0,4,5,1,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],0,25);
			SendIndex=SendIndex+25;
			//SendNAK(F, P, 0x0d);
			//return 0;
		}
		else
		{
			for(i=0;i<5;i++)
			{
				if((SendBuff[(SendIndex+1)+i*5]==OxXX)&&
				   (SendBuff[(SendIndex+2)+i*5]==OxXX)&&
				   (SendBuff[(SendIndex+3)+i*5]==OxXX)&&
				   (SendBuff[(SendIndex+4)+i*5]==OxXX))
						memset(&SendBuff[SendIndex+0+i*5],0,5);
			}
			SendIndex = SendIndex + 25;
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],0,25);
		SendIndex=SendIndex+25;
		//SendNAK(F, P, 0x0d);
		//return 0;
	}
	//if (AutoFlg!=0) return 1; EC();
	//TP();
	//FrameTailCreate_Send(0);

	return 1;
}

INT16U Level1Data_Curr_F140_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ�����޹�������޹�1������ʾֵ
{
	INT8U CJQno, MeterNo, MeterType;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60];
	TS ts;

	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = 4;
	TimeDecrease(&ts, 5, 1);
	sprintf((char *) Temp_FilePath, "/nand/DataMonth/%04d/%02d.dat",P, ts.Month);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x20,0,4,5,0,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],0,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 0;
		}
		else SendIndex = SendIndex + 20;
	}
	else
	{
		memset(&SendBuff[SendIndex],0,20);
		SendIndex=SendIndex+20;
		//SendNAK(F, P, 0x0d);
		//return 0;
	}
	//if (AutoFlg!=0) return 1; EC();
	//TP();
	//FrameTailCreate_Send(0);

	return 1;
}

INT16U Level1Data_Curr_F141_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰһ�����޹�����ʾֵ
{
	INT8U CJQno, MeterNo, MeterType;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60];
	TS ts;

	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = 4;
	TimeDecrease(&ts, 5, 1);
	sprintf((char *) Temp_FilePath, "/nand/DataMonth/%04d/%02d.dat",P, ts.Month);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x30,0,4,5,0,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],0,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 0;
		}
		else SendIndex = SendIndex + 20;
	}
	else
	{
		memset(&SendBuff[SendIndex],0,20);
		SendIndex=SendIndex+20;
		//SendNAK(F, P, 0x0d);
		//return 0;
	}
	//if (AutoFlg!=0) return 1; EC();
	//TP();
	//FrameTailCreate_Send(0);

	return 1;
}

INT16U Level1Data_Curr_F142_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ�������޹�����ʾֵ
{
	INT8U CJQno, MeterNo, MeterType;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60];
	TS ts;

	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = 4;
	TimeDecrease(&ts, 5, 1);
	sprintf((char *) Temp_FilePath, "/nand/DataMonth/%04d/%02d.dat",P, ts.Month);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x50,0,4,5,0,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],0,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 0;
		}
		else SendIndex = SendIndex + 20;
	}
	else
	{
		memset(&SendBuff[SendIndex],0,20);
		SendIndex=SendIndex+20;
		//SendNAK(F, P, 0x0d);
		//return 0;
	}
	//if (AutoFlg!=0) return 1; EC();
	//TP();
	//FrameTailCreate_Send(0);

	return 1;
}

INT16U Level1Data_Curr_F143_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ�������޹�����ʾֵ
{
	INT8U CJQno, MeterNo, MeterType;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60];
	TS ts;

	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = 4;
	TimeDecrease(&ts, 5, 1);
	sprintf((char *) Temp_FilePath, "/nand/DataMonth/%04d/%02d.dat",P, ts.Month);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x60,0,4,5,0,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],0,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 0;
		}
		else SendIndex = SendIndex + 20;
	}
	else
	{
		memset(&SendBuff[SendIndex],0,20);
		SendIndex=SendIndex+20;
		//SendNAK(F, P, 0x0d);
		//return 0;
	}
	//if (AutoFlg!=0) return 1; EC();
	//TP();
	//FrameTailCreate_Send(0);

	return 1;
}

INT16U Level1Data_Curr_F144_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//�����������޹�����ʾֵ
{
	INT8U CJQno, MeterNo, MeterType;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60];
	TS ts;

	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = 4;
	TimeDecrease(&ts, 5, 1);

	sprintf((char *) Temp_FilePath, "/nand/DataMonth/%04d/%02d.dat",P, ts.Month);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x40,0,4,5,0,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],0,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 0;
		}
		else SendIndex = SendIndex + 20;
	}
	else
	{
		memset(&SendBuff[SendIndex],0,20);
		SendIndex=SendIndex+20;
		//SendNAK(F, P, 0x0d);
		//return 0;
	}
	//if (AutoFlg!=0) return 1; EC();
	//TP();
	//FrameTailCreate_Send(0);

	return 1;
}

//----------------------------------------------------------------------------

INT16U Level1Data_Curr_F145_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���������й��������������ʱ��
{
	INT8U CJQno, MeterNo, MeterType,j;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60];
	TS ts;
	
	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
	//if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port==1)
	{
		INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
	}else{
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
	}


	SendBuff[SendIndex++] = FeiLvNum;
	sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",P);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
	if(IsDataFlag==1)
	{
		for(j=0;j<5;j++)
		{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa0,0x10,j*3,3,1,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,7);
				SendIndex=SendIndex+7;
				//SendNAK(F, P, 0x0d);
				//return 0;
			}
			else
			{
				SendIndex = SendIndex + 3;
				IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb0,0x10,j*4,4,1,0,0,0,0,dftype);
				SendIndex = SendIndex + 4;
			}
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,35);
		SendIndex=SendIndex+35;
		//SendNAK(F, P, 0x0d);
		//return 0;
	}
	//if (AutoFlg!=0) return 1; EC();
	//TP();
	//FrameTailCreate_Send(0);
	return 1;
}

INT16U Level1Data_Curr_F146_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���������޹��������������ʱ��
{
	INT8U CJQno, MeterNo, MeterType,j;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60];
	TS ts;
	
	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
//	if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port==1)
	{
		INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
	}else{
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
	}

	SendBuff[SendIndex++] = FeiLvNum;
	sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",P);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
	if(IsDataFlag==1)
	{
		for(j=0;j<5;j++)
		{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa1,0x10,j*3,3,1,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,7);
				SendIndex=SendIndex+7;
				//SendNAK(F, P, 0x0d);
				//return 0;
			}
			else
			{
				SendIndex = SendIndex + 3;
				IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb1,0x10,j*4,4,1,0,0,0,0,dftype);
				SendIndex = SendIndex + 4;
			}
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,35);
		SendIndex=SendIndex+35;
		//SendNAK(F, P, 0x0d);
		//return 0;
	}
//	if (AutoFlg!=0) return 1; EC();
//	TP();
//	FrameTailCreate_Send(0);

	return 1;
}

INT16U Level1Data_Curr_F147_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���·����й��������������ʱ��
{
	INT8U CJQno, MeterNo, MeterType,j;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60];
	TS ts;
	
	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
//	if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port==1)
	{
		INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
	}else{
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
	}

	SendBuff[SendIndex++] = FeiLvNum;
	sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",P);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
	if(IsDataFlag==1)
	{
		for(j=0;j<5;j++)
		{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa0,0x20,j*3,3,1,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,7);
				SendIndex=SendIndex+7;
				//SendNAK(F, P, 0x0d);
				//return 0;
			}
			else
			{
				SendIndex = SendIndex + 3;
				IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb0,0x20,j*4,4,1,0,0,0,0,dftype);
				SendIndex = SendIndex + 4;
			}
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,35);
		SendIndex=SendIndex+35;
	}
	return 1;
}

INT16U Level1Data_Curr_F148_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���·����޹��������������ʱ��
{

	INT8U CJQno, MeterNo, MeterType,j;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60];
	TS ts;

	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
//	if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port==1)
	{
		INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
	}else{
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
	}

	SendBuff[SendIndex++] = FeiLvNum;
	sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",P);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
	if(IsDataFlag==1)
	{
		for(j=0;j<5;j++)
		{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa1,0x20,j*3,3,1,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],0,7);
				SendIndex=SendIndex+7;
				//SendNAK(F, P, 0x0d);
				//return 0;
			}
			else
			{
				SendIndex = SendIndex + 3;
				IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb1,0x20,j*4,4,1,0,0,0,0,dftype);
				SendIndex = SendIndex + 4;
			}
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,35);
		SendIndex=SendIndex+35;
	}
	return 1;
//	INT8U CJQno, MeterNo, MeterType;
//	INT16U IsDataFlag,dftype;
//	INT8U Temp_FilePath[60];
//	TS ts;
//
//	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
//	if (portn == LocalCommPort)
//		portn=CarrWavePort;
//
//	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
//	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
//	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
//	TSGet(&ts);
//	TimeDecrease(&ts,5,1);
//	sprintf((char *) Temp_FilePath, "/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
//	dftype=1;
//	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
//	if (IsDataFlag==1)
//	{
//		INT32U_BCD(smfile.ts.Minute, &SendBuff[SendIndex], 1);
//		SendIndex++;
//		INT32U_BCD(smfile.ts.Hour, &SendBuff[SendIndex], 1);
//		SendIndex++;
//		INT32U_BCD(smfile.ts.Day, &SendBuff[SendIndex], 1);
//		SendIndex++;
//		INT32U_BCD(smfile.ts.Month, &SendBuff[SendIndex], 1);
//		SendIndex++;
//		INT32U_BCD(smfile.ts.Year%100, &SendBuff[SendIndex], 1);
//		SendIndex++;
//		SendBuff[SendIndex++] = 4;
//
//		fprintf(stderr,"\nF149:ConnectType[%d]=%d\n",P-1,JSetPara_AFN04_3761_2009->group2.f10[P-1].ConnectType);
//		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa1,0x20,0,3,1,0,0,0,0,dftype);
//		if(IsDataFlag==0) memset(&SendBuff[SendIndex],0,3);
//		SendIndex = SendIndex + 3;
//		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb1,0x20,0,4,1,0,0,0,0,dftype);
//		if(IsDataFlag==0) memset(&SendBuff[SendIndex],0,4);
//		SendIndex = SendIndex + 4;
//
//		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa1,0x21,0,3,1,0,0,0,0,dftype);
//		if(IsDataFlag==0) memset(&SendBuff[SendIndex],0,3);
//		SendIndex = SendIndex + 3;
//		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb1,0x21,0,4,1,0,0,0,0,dftype);
//		if(IsDataFlag==0) memset(&SendBuff[SendIndex],0,4);
//		SendIndex = SendIndex + 4;
//
//		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa1,0x22,0,3,1,0,0,0,0,dftype);
//		if(IsDataFlag==0) memset(&SendBuff[SendIndex],0,3);
//		SendIndex = SendIndex + 3;
//		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb1,0x22,0,4,1,0,0,0,0,dftype);
//		if(IsDataFlag==0) memset(&SendBuff[SendIndex],0,4);
//		SendIndex = SendIndex + 4;
//
//		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa1,0x23,0,3,1,0,0,0,0,dftype);
//		if(IsDataFlag==0) memset(&SendBuff[SendIndex],0,3);
//		SendIndex = SendIndex + 3;
//		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb1,0x23,0,4,1,0,0,0,0,dftype);
//		if(IsDataFlag==0) memset(&SendBuff[SendIndex],0,4);
//		SendIndex = SendIndex + 4;
//
//		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa1,0x24,0,3,1,0,0,0,0,dftype);
//		if(IsDataFlag==0) memset(&SendBuff[SendIndex],0,3);
//		SendIndex = SendIndex + 3;
//		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb1,0x24,0,4,1,0,0,0,0,dftype);
//		if(IsDataFlag==0) memset(&SendBuff[SendIndex],0,4);
//		SendIndex = SendIndex + 4;
//	}
//	else
//	{
//		memset(&SendBuff[SendIndex],OxXX,41);
//		SendIndex=SendIndex+41;
//	}
//	return 1;
}

//-------------------------------------------------------------------------------------------
INT16U Level1Data_Curr_F149_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���������й��������������ʱ��
{
	INT8U CJQno, MeterNo, MeterType;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60];
	TS ts;
	int j=0;
	SdPrintf(YNPrint,PreFix, "F149:ConnectType[%d]=%d\n",P-1,JSetPara_AFN04_3761_2009->group2.f10[P-1].ConnectType);
	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);

	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	TimeDecrease(&ts,5,1);
	sprintf((char *) Temp_FilePath, "/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
	dftype=1;
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
	SendBuff[SendIndex++] = 4;
	if (IsDataFlag==1)
	{
		for(j=0;j<5;j++)
		{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa0,0x10,j*3,3,1,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],0,7);
				SendIndex=SendIndex+7;
			}
			else
			{
				SendIndex = SendIndex + 3;
				IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb0,0x10,j*4,4,1,0,0,0,0,dftype);
				SendIndex = SendIndex + 4;
			}
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],0,35);
		SendIndex=SendIndex+35;
	}
	return 1;
}

INT16U Level1Data_Curr_F150_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���������޹��������������ʱ��
{
	INT8U CJQno, MeterNo, MeterType;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60];
	TS ts;
	int j=0;
	SdPrintf(YNPrint,PreFix, "F150:ConnectType[%d]=%d\n",P-1,JSetPara_AFN04_3761_2009->group2.f10[P-1].ConnectType);
	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	TimeDecrease(&ts,5,1);
	sprintf((char *) Temp_FilePath, "/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
	dftype=1;
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
	SendBuff[SendIndex++] = 4;
	if (IsDataFlag==1)
	{
		for(j=0;j<5;j++)
		{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa1,0x10,j*3,3,1,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],0,7);
				SendIndex=SendIndex+7;
			}
			else
			{
				SendIndex = SendIndex + 3;
				IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb1,0x10,j*4,4,1,0,0,0,0,dftype);
				SendIndex = SendIndex + 4;
			}
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],0,35);
		SendIndex=SendIndex+35;
	}
	return 1;
}

INT16U Level1Data_Curr_F151_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���·����й��������������ʱ��
{
	INT8U CJQno, MeterNo, MeterType,j;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60];
	TS ts;
	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;
	SdPrintf(YNPrint,PreFix, "\nF151:ConnectType[%d]=%d\n",P-1,JSetPara_AFN04_3761_2009->group2.f10[P-1].ConnectType);
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
//	if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;

	SendBuff[SendIndex++] = FeiLvNum;
	TimeDecrease(&ts,5,1);
	sprintf((char *) Temp_FilePath, "/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
	if(IsDataFlag==1)
	{
		for(j=0;j<5;j++)
		{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa0,0x20,j*3,3,1,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],0,7);
				SendIndex=SendIndex+7;
			}
			else
			{
				SendIndex = SendIndex + 3;
				IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb0,0x20,j*4,4,1,0,0,0,0,dftype);
				SendIndex = SendIndex + 4;
			}
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],0,35);
		SendIndex=SendIndex+35;
		//SendNAK(F, P, 0x0d);
		//return 0;
	}
//	if (AutoFlg!=0) return 1; EC();
//	TP();
//	FrameTailCreate_Send(0);

	return 1;
}

INT16U Level1Data_Curr_F152_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���·����޹��������������ʱ��
{
	INT8U CJQno, MeterNo, MeterType,j;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60];
	TS ts;
	SdPrintf(YNPrint,PreFix, "\nF152:ConnectType[%d]=%d\n",P-1,JSetPara_AFN04_3761_2009->group2.f10[P-1].ConnectType);
	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
//	if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;

	SendBuff[SendIndex++] = FeiLvNum;
	TimeDecrease(&ts,5,1);
	sprintf((char *) Temp_FilePath, "/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
	if(IsDataFlag==1)
	{
		for(j=0;j<5;j++)
		{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa1,0x20,j*3,3,1,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],0,7);
				SendIndex=SendIndex+7;
				//SendNAK(F, P, 0x0d);
				//return 0;
			}
			else
			{
				SendIndex = SendIndex + 3;
				IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb1,0x20,j*4,4,1,0,0,0,0,dftype);
				SendIndex = SendIndex + 4;
			}
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,35);
		SendIndex=SendIndex+35;
		//SendNAK(F, P, 0x0d);
		//return 0;
	}
//	if (AutoFlg!=0) return 1; EC();
//	TP();
//	FrameTailCreate_Send(0);

	return 1;
}
//---------------------------------------------------------------------------------------


INT16U Level1Data_Curr_F153_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ�����й�����ʾֵ
{
	INT8U CJQno, MeterNo, MeterType;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],i;
	TS ts;
	SdPrintf(YNPrint,PreFix,"Level1Data_Curr_F153_Get");
	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
	//if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port==1)
	{
		INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
		if(Jdatafileinfo->JcPara_645.runSQu.FangAn!=0)
		{
			memset(&SendBuff[SendIndex],0,25);
			SendIndex=SendIndex+25;
			return 1;
		}
	}else
	{
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
	}
	SendBuff[SendIndex++] = FeiLvNum;
	sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",P);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x90,0x10,0,4,5,1,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,25);
			SendIndex=SendIndex+25;
			//SendNAK(F, P, 0x0d);
			//return 0;
		}
		else
		{
			for(i=0;i<5;i++)
			{
				if((SendBuff[(SendIndex+1)+i*5]==OxXX)&&
				   (SendBuff[(SendIndex+2)+i*5]==OxXX)&&
				   (SendBuff[(SendIndex+3)+i*5]==OxXX)&&
				   (SendBuff[(SendIndex+4)+i*5]==OxXX))
						memset(&SendBuff[SendIndex+0+i*5],OxXX,5);
			}
			SendIndex = SendIndex + 25;
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,25);
		SendIndex=SendIndex+25;
	}
	return 1;
}

INT16U Level1Data_Curr_F154_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ�����й�����ʾֵ
{
	INT8U CJQno, MeterNo, MeterType;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],i;
	TS ts;
	SdPrintf(YNPrint,PreFix,"Level1Data_Curr_F154_Get\n");
	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
	//if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port==1)
	{
		INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
		SendBuff[SendIndex++] = FeiLvNum;
		if(Jdatafileinfo->JcPara_645.runSQu.FangAn!=1)
		{
			memset(&SendBuff[SendIndex],0,25);
			SendIndex=SendIndex+25;
			return 1;
		}
	}else
	{
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
	}
	SendBuff[SendIndex++] = FeiLvNum;
	sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",P);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x90,0x10,0,4,5,1,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,25);
			SendIndex=SendIndex+25;
			//SendNAK(F, P, 0x0d);
			//return 0;
		}
		else
		{
			for(i=0;i<5;i++)
			{
				if((SendBuff[(SendIndex+1)+i*5]==OxXX)&&
				   (SendBuff[(SendIndex+2)+i*5]==OxXX)&&
				   (SendBuff[(SendIndex+3)+i*5]==OxXX)&&
				   (SendBuff[(SendIndex+4)+i*5]==OxXX))
						memset(&SendBuff[SendIndex+0+i*5],OxXX,5);
			}
			SendIndex = SendIndex + 25;
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,25);
		SendIndex=SendIndex+25;
	}
	return 1;
}

INT16U Level1Data_Curr_F155_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ�����й�����ʾֵ
{
	INT8U CJQno, MeterNo, MeterType;
	TS ts;
	SdPrintf(YNPrint,PreFix,"Level1Data_Curr_F155_Get");
	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
	if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port==1)
	{
		INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
		SendBuff[SendIndex++] = FeiLvNum;
		memset(&SendBuff[SendIndex],0,25);
		SendIndex=SendIndex+25;
	}
	return 1;
}

INT16U Level1Data_Curr_F156_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ�����й�����ʾֵ
{
	INT8U CJQno, MeterNo, MeterType;
	TS ts;
	SdPrintf(YNPrint,PreFix,"Level1Data_Curr_F156_Get");
	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
	if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port==1)
	{
		INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
		SendBuff[SendIndex++] = FeiLvNum;
		memset(&SendBuff[SendIndex],0,25);
		SendIndex=SendIndex+25;
	}
	return 1;
}
INT16U Level1Data_Curr_F157_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ�����й�����ʾֵ
{
	INT8U CJQno, MeterNo, MeterType;
	TS ts;
	SdPrintf(YNPrint,PreFix,"Level1Data_Curr_F157_Get");
	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
	if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port==1)
	{
		INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
		SendBuff[SendIndex++] = FeiLvNum;
		memset(&SendBuff[SendIndex],0,25);
		SendIndex=SendIndex+25;
	}
	return 1;
}

INT16U Level1Data_Curr_F158_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ�����й�����ʾֵ
{
	INT8U CJQno, MeterNo, MeterType;
	TS ts;
	SdPrintf(YNPrint,PreFix,"Level1Data_Curr_F158_Get");
	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
	if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port==1)
	{
		INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
		SendBuff[SendIndex++] = FeiLvNum;
		memset(&SendBuff[SendIndex],0,25);
		SendIndex=SendIndex+25;
	}
	return 1;
}
INT16U Level1Data_Curr_F159_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ�����й�����ʾֵ
{
	INT8U CJQno, MeterNo, MeterType;
	TS ts;
	SdPrintf(YNPrint,PreFix,"Level1Data_Curr_F159_Get\n");
	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
	if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port==1)
	{
		INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
		SendBuff[SendIndex++] = FeiLvNum;
		memset(&SendBuff[SendIndex],0,25);
		SendIndex=SendIndex+25;
	}
	return 1;
}

INT16U Level1Data_Curr_F160_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ�����й�����ʾֵ
{
	INT8U CJQno, MeterNo, MeterType;
	TS ts;
	SdPrintf(YNPrint,PreFix,"Level1Data_Curr_F160_Get");
	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
	if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port==1)
	{
		INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
		SendBuff[SendIndex++] = FeiLvNum;
		memset(&SendBuff[SendIndex],0,25);
		SendIndex=SendIndex+25;
	}
	return 1;
}

INT16U Level1Data_Curr_F161_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���ܱ�Զ�̿���ͨ�ϵ�״̬����¼
{
	INT8U CJQno, MeterNo, MeterType;

	TS ts;
	
	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;
	SdPrintf(YNPrint,PreFix,"Level1Data_Curr_F161_Get");
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
	//if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = Jdatafileinfo->ptinfo[P-1].f161.F_H_State;
	SendBuff[SendIndex++] = Jdatafileinfo->ptinfo[P-1].f161.HeZhatime[0];
	SendBuff[SendIndex++] = Jdatafileinfo->ptinfo[P-1].f161.HeZhatime[1];
	SendBuff[SendIndex++] = Jdatafileinfo->ptinfo[P-1].f161.HeZhatime[2];
	SendBuff[SendIndex++] = Jdatafileinfo->ptinfo[P-1].f161.HeZhatime[3];
	SendBuff[SendIndex++] = Jdatafileinfo->ptinfo[P-1].f161.HeZhatime[4];

	SendBuff[SendIndex++] = Jdatafileinfo->ptinfo[P-1].f161.FenZhatime[0];
	SendBuff[SendIndex++] = Jdatafileinfo->ptinfo[P-1].f161.FenZhatime[1];
	SendBuff[SendIndex++] = Jdatafileinfo->ptinfo[P-1].f161.FenZhatime[2];
	SendBuff[SendIndex++] = Jdatafileinfo->ptinfo[P-1].f161.FenZhatime[3];
	SendBuff[SendIndex++] = Jdatafileinfo->ptinfo[P-1].f161.FenZhatime[4];
	return 1;
}

INT16U Level1Data_Curr_F165_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���ܱ����ز���������ʱ��
{
	INT8U CJQno, MeterNo, MeterType;
	TS ts;
	F165_t f165;
	INT16U count = 0;
	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
//	if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;

	if(access("/nand/para/f165.par",0)==0)
	{
		NormalReadFile("/nand/para/f165.par", &f165, sizeof(F165_t),Jproginfo);
		count = f165.program_count & 0xffff;
		INT32U_BCD(count&0xff, &SendBuff[SendIndex++], 1);
		INT32U_BCD(count>>8, &SendBuff[SendIndex++], 1);
		INT32U_BCD(f165.program_ts.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(f165.program_ts.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(f165.program_ts.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(f165.program_ts.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(f165.program_ts.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;

		count = f165.weigai_count & 0xffff;
		INT32U_BCD(count&0xff, &SendBuff[SendIndex++], 1);
		INT32U_BCD(count>>8, &SendBuff[SendIndex++], 1);
		INT32U_BCD(f165.weigai_ts.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(f165.weigai_ts.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(f165.weigai_ts.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(f165.weigai_ts.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(f165.weigai_ts.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
	}
	else
	{
		memset(&SendBuff[SendIndex],0,14);
			SendIndex=SendIndex+14;
			//SendNAK(F, P, 0x0d);
			//return 0;
		}
//	if (AutoFlg!=0) return 1; EC();
//	TP();
//	FrameTailCreate_Send(0);

	return 1;
}

INT16U Level1Data_Curr_F166_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���ܱ������޸Ĵ�����ʱ��
{
	INT8U CJQno, MeterNo, MeterType;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60];
	TS ts;
	
	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
//	if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(Jdatafileinfo->data485[portn-1].ts_begin.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;

	sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",P);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;//comm
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x00,0x42,0,2,1,0,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,14);
			SendIndex=SendIndex+14;
			//SendNAK(F, P, 0x0d);
			//return 0;
		}
		else
		{
			SendIndex = SendIndex + 2;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x00,0x43,1,5,1,0,0,0,0,dftype);
			SendIndex = SendIndex + 5;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x00,0x56,0,2,1,0,0,0,0,dftype);
			SendIndex = SendIndex + 2;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x00,0x57,1,5,1,0,0,0,0,dftype);
			SendIndex = SendIndex + 5;
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,14);
		SendIndex=SendIndex+14;
		//SendNAK(F, P, 0x0d);
		//return 0;
	}
//	if (AutoFlg!=0) return 1; EC();
//	TP();
//	FrameTailCreate_Send(0);

	return 1;
}

INT16U Level1Data_Curr_F167_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���ܱ������õ���Ϣ
{
	INT8U CJQno, MeterNo, MeterType;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60];
	TS ts;
	int ifjiaocai=0;
	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);

	if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port==1)
	{
		ifjiaocai = 1;
	}
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SdPrintf(YNPrint,PreFix,"0x0C   F167------------------");

	sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",P);

	dftype=1;//comm
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x00,0x91,0,2,1,0,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			if (ifjiaocai == 0)
				memset(&SendBuff[SendIndex],OxXX,36);
			else
				memset(&SendBuff[SendIndex],0x00,36);
			SendIndex=SendIndex+36;
		}
		else
		{
			SendIndex = SendIndex + 2;
			SendBuff[SendIndex++]=0x00;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x00,0x92,0,4,1,0,0,0,0,dftype);
			SendIndex = SendIndex + 4;
			SendBuff[SendIndex++]=0x00;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x00,0x93,0,4,1,0,0,0,0,dftype);
			SendIndex = SendIndex + 4;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x00,0x94,0,4,1,0,0,0,0,dftype);
			SendIndex = SendIndex + 4;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x00,0x95,0,4,1,0,0,0,0,dftype);
			SendIndex = SendIndex + 4;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x00,0x96,0,4,1,0,0,0,0,dftype);
			SendIndex = SendIndex + 4;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x00,0x97,0,4,1,0,0,0,0,dftype);
			SendIndex = SendIndex + 4;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x00,0x98,0,4,1,0,0,0,0,dftype);
			SendIndex = SendIndex + 4;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x00,0x99,0,4,1,0,0,0,0,dftype);
			SendIndex = SendIndex + 4;
		}
	}
	else
	{
		if (ifjiaocai==0)
			memset(&SendBuff[SendIndex],OxXX,36);
		else
			memset(&SendBuff[SendIndex],0x00,36);
		SendIndex=SendIndex+36;
	}
	return 1;
}

INT16U Level1Data_Curr_F168_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���ܱ�������Ϣ
{
	INT8U CJQno, MeterNo, MeterType;
	INT16U dftype;
	INT8U Temp_FilePath[60];
	TS ts;
	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
//	if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;

	SendBuff[SendIndex++] = FeiLvNum;
	SendBuff[SendIndex++] = 0;
	sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",P);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	memset(&SendBuff[SendIndex],0,50);
	SendIndex=SendIndex+50;
	return 1;
}

/*++++++++++++++++++++++++++  //LQQ xiebo     <<<<<<<<<<  +++++++++++++++++++++++*/
INT16U Level1Data_Curr_F57_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ�����ѹ������2~n��г����Чֵ
{
		INT8U i;	TS ts;
		TSGet(&ts);
//		if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));

		{
			SendBuff[SendIndex++]=19;
			for(i=2;i<20;i++)
			{
				INT32U_BCD(Jdatafileinfo->jc.xiebo.AllXBo.UAxb[i]*10,&SendBuff[SendIndex],2);
				SendIndex=SendIndex+2;
			}
			for(i=2;i<20;i++)
			{
				INT32U_BCD(Jdatafileinfo->jc.xiebo.AllXBo.UBxb[i]*10,&SendBuff[SendIndex],2);
				SendIndex=SendIndex+2;
			}
			for(i=2;i<20;i++)
			{
				INT32U_BCD(Jdatafileinfo->jc.xiebo.AllXBo.UCxb[i]*10,&SendBuff[SendIndex],2);
				SendIndex=SendIndex+2;
			}
			for(i=2;i<20;i++)
			{
				INT32U_BCD(Jdatafileinfo->jc.xiebo.AllXBo.IAxb[i]*100,&SendBuff[SendIndex],2);
				SendIndex=SendIndex+2;
			}
			for(i=2;i<20;i++)
			{
				INT32U_BCD(Jdatafileinfo->jc.xiebo.AllXBo.IBxb[i]*100,&SendBuff[SendIndex],2);
				SendIndex=SendIndex+2;
			}
			for(i=2;i<20;i++)
			{
				INT32U_BCD(Jdatafileinfo->jc.xiebo.AllXBo.ICxb[i]*100,&SendBuff[SendIndex],2);
				SendIndex=SendIndex+2;
			}

//			EC();
//			TP();
//			FrameTailCreate_Send();
//			FrameTailCreate_Send(0);
			return 1;
		}
}
INT16U Level1Data_Curr_F58_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ�����ѹ������2~n��г��������
{
		INT8U i;	TS ts;
		TSGet(&ts);
//		if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
		{
			SendBuff[SendIndex++]=19;
			 SdPrintf(YNPrint,PreFix,"UA_HanyoulvZong=%d",(int)(Jdatafileinfo->jc.xiebo.AllXBo.UA_HanyoulvZong*10));
			 SdPrintf(YNPrint,PreFix,"UB_HanyoulvZong=%d",(int)(Jdatafileinfo->jc.xiebo.AllXBo.UB_HanyoulvZong*10));
			 SdPrintf(YNPrint,PreFix,"UC_HanyoulvZong=%d",(int)(Jdatafileinfo->jc.xiebo.AllXBo.UC_HanyoulvZong*10));
			INT32U_BCD(Jdatafileinfo->jc.xiebo.AllXBo.UA_HanyoulvZong*10,&SendBuff[SendIndex],2);
			SendIndex=SendIndex+2;
			for(i=2;i<20;i++)
			{
				INT32U_BCD(Jdatafileinfo->jc.xiebo.AllXBo.UA_Hanyoulv[i]*10,&SendBuff[SendIndex],2);
				SendIndex=SendIndex+2;
			}
			INT32U_BCD(Jdatafileinfo->jc.xiebo.AllXBo.UB_HanyoulvZong*10,&SendBuff[SendIndex],2);
			SendIndex=SendIndex+2;
			for(i=2;i<20;i++)
			{
				INT32U_BCD(Jdatafileinfo->jc.xiebo.AllXBo.UB_Hanyoulv[i]*10,&SendBuff[SendIndex],2);
				SendIndex=SendIndex+2;
			}
			INT32U_BCD(Jdatafileinfo->jc.xiebo.AllXBo.UC_HanyoulvZong*10,&SendBuff[SendIndex],2);
			SendIndex=SendIndex+2;
			for(i=2;i<20;i++)
			{
				INT32U_BCD(Jdatafileinfo->jc.xiebo.AllXBo.UC_Hanyoulv[i]*10,&SendBuff[SendIndex],2);
				SendIndex=SendIndex+2;
			}
			for(i=2;i<20;i++)
			{
				INT32U_BCD(Jdatafileinfo->jc.xiebo.AllXBo.IA_Hanyoulv[i]*10,&SendBuff[SendIndex],2);
				SendIndex=SendIndex+2;
			}
			for(i=2;i<20;i++)
			{
				INT32U_BCD(Jdatafileinfo->jc.xiebo.AllXBo.IB_Hanyoulv[i]*10,&SendBuff[SendIndex],2);
				SendIndex=SendIndex+2;
			}
			for(i=2;i<20;i++)
			{
				INT32U_BCD(Jdatafileinfo->jc.xiebo.AllXBo.IC_Hanyoulv[i]*10,&SendBuff[SendIndex],2);
				SendIndex=SendIndex+2;
			}
//			EC();
//			TP();
//			FrameTailCreate_Send(0);
			return 1;
		}
}
/*++++++++++++++++++++++++++  //xiebo     >>>>>>>>>>  +++++++++++++++++++++++*/
#ifdef SHANGHAI
//�Ϻ���F13  �ն�SIM��IMSI��
INT16U Level1Data_F13_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)
{
	INT8U imsi[15];
//	INT8U i = 0;
	memset(imsi,0,15);
	SdPrintf(YNPrint,PreFix,"Level1Data_F13_Get");
	if(access("/nand/para/IMSI.par",0)==0)
	{
//		NormalReadFile("/nand/para/IMSI.par", imsi, 15,Jproginfo);
		FILE* fp = NULL;
		fp = fopen("/nand/para/IMSI.par","r");
		fgets((char*)imsi,16,fp);
		fclose(fp);
		memcpy(&SendBuff[SendIndex], imsi, 15);
		SendIndex  += 15;
		SdPrintf(YNPrint,PreFix,"IMSI:%s",imsi);
	}else {
		memset(&SendBuff[SendIndex],0,15);
		SendIndex  += 15;
	}
	return 1;
}
INT16U Level1Data_F14_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)
{
	INT8U iccid[20];
	memset(iccid,0,20);
	SdPrintf(YNPrint,PreFix,"Level1Data_F14_Get");
	if(access("/nand/para/ICCID.par",0)==0)
	{
//		NormalReadFile("/nand/para/ICCID.par", iccid, 20,Jproginfo);
		FILE* fp = NULL;
		fp = fopen("/nand/para/ICCID.par","r");
		fgets((char*)iccid,25,fp);
		fclose(fp);
		memcpy(&SendBuff[SendIndex], iccid, 20);
		SendIndex  +=  20;
		SdPrintf(YNPrint,PreFix,"ICCID:%s",iccid);
	}else {
		memset(&SendBuff[SendIndex],0,20);
		SendIndex  +=  20;
	}
	return 1;
}
//�Ϻ���F241  ��ǰ��½ʱ��
INT16U Level1Data_F241_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data){
	INT8U logtime[25];
	TS tst;
	INT8U yy[5],MM[3],dd[3],ww[2],hh[3],mm[3],ss[3];
	memset(yy,0,5);memset(MM,0,3);memset(dd,0,3);memset(ww,0,2);memset(hh,0,3);memset(mm,0,3);memset(ss,0,3);
	memset(logtime,0,25);
	SdPrintf(YNPrint,PreFix,"Level1Data_F241_Get");
	if(access("/nand/DataAlarm/login.dat",0)==0)
	{
//		NormalReadFile("/nand/para/login.log", logtime, 6,Jproginfo);
		FILE* fp;
//		sem_wait(&Jproginfo->mainData.UseFileFlg);
		fp = fopen("/nand/DataAlarm/login.dat","r");
		memset(logtime,0,8);
		if(fp == NULL)
		{
			memset(&SendBuff[SendIndex],0,6);
			SendIndex  +=  6;
		}else {
			while(fgets((char*)logtime,125,fp) != NULL){
//				fprintf(stderr,logtime);
			}
		}
		fclose(fp);
//		sem_post(&Jproginfo->mainData.UseFileFlg);
		SdPrintf(YNPrint,PreFix,"����¼ʱ��(login.dat):%s",logtime);
		sscanf((char*)logtime,"%4s-%2s-%2s %1s %2s:%2s:%2s",yy,MM,dd,ww,hh,mm,ss);
//		sscanf((char*)logtime,"%d[^-]-%d[^-]-%d %d %d[^:]:%d[^:]:%d",
//				(int*)&tst.Year,(int*)&tst.Month,(int*)&tst.Day,
//				(int*)&tst.Week,(int*)&tst.Hour,(int*)&tst.Minute,(int*)&tst.Sec);
//		SdPrintf("logtime1:%d[^-]-%d[^-]-%d %d %d[^:]:%d[^:]:%d",tst.Year,tst.Month,tst.Day,tst.Week,tst.Hour,tst.Minute,tst.Sec);
		tst.Year= atoi((char*)yy);tst.Month=atoi((char*)MM);tst.Day=atoi((char*)dd);tst.Week=atoi((char*)ww);
		tst.Hour=atoi((char*)hh);tst.Minute=atoi((char*)mm);tst.Sec=atoi((char*)ss);
		SendBuff[SendIndex++] = ((tst.Sec / 10) << 4) + (tst.Sec % 10);
		SendBuff[SendIndex++] = ((tst.Minute / 10) << 4) + (tst.Minute % 10);
		SendBuff[SendIndex++] = ((tst.Hour / 10) << 4) + (tst.Hour % 10);
		SendBuff[SendIndex++] = ((tst.Day / 10) << 4) + (tst.Day % 10);
		if (tst.Week == 0) {
			SendBuff[SendIndex++] = ((tst.Month / 10) << 4) + (tst.Month % 10) + 0xe0;
		} else {
			SendBuff[SendIndex++] = ((tst.Month / 10) << 4) + (tst.Month % 10)
					+ (tst.Week << 5);
		}
		SendBuff[SendIndex++] = (((tst.Year % 100) / 10) << 4) + (tst.Year % 10);
		SdPrintf(YNPrint,PreFix,"logtime:%d-%d-%d %d %d:%d:%d",tst.Year,tst.Month,tst.Day,tst.Week,tst.Hour,tst.Minute,tst.Sec);

	}else {
		memset(&SendBuff[SendIndex],0,6);
		SendIndex  +=  6;
	}
	return 1;
}
//�Ϻ���F242  ��½����,���յ�½��Ϣ
INT16U Level1Data_F242_Get(INT8U Set, INT16U F,INT16U P, INT8U* Data){
	INT32U lognum=0;  //��½����
	INT8U logtime[25];
	TS tst;
    INT16U longnumindex = SendIndex;
    INT8U yy[5],MM[3],dd[3],ww[2],hh[3],mm[3],ss[3];
    memset(yy,0,5);memset(MM,0,3);memset(dd,0,3);memset(ww,0,2);memset(hh,0,3);memset(mm,0,3);memset(ss,0,3);
    memset(logtime,0,25);
//
	SendIndex += 4;
	if(access("/nand/DataAlarm/login.dat",0)==0)
	{
		FILE* fp;
//		sem_wait(&Jproginfo->mainData.UseFileFlg);
		fp = fopen("/nand/DataAlarm/login.dat","r");
		memset(logtime,0,8);
		if(fp == NULL)
		{
			memset(&SendBuff[SendIndex],0,6);
			SendIndex  +=  6;
		}else {
			while(fgets((char*)logtime,125,fp) != NULL){
				sscanf((char*)logtime,"%4s-%2s-%2s %1s %2s:%2s:%2s",yy,MM,dd,ww,hh,mm,ss);
				tst.Year= atoi((char*)yy);tst.Month=atoi((char*)MM);tst.Day=atoi((char*)dd);tst.Week=atoi((char*)ww);
				tst.Hour=atoi((char*)hh);tst.Minute=atoi((char*)mm);tst.Sec=atoi((char*)ss);
				SendBuff[SendIndex++] = ((tst.Sec / 10) << 4) + (tst.Sec % 10);
				SendBuff[SendIndex++] = ((tst.Minute / 10) << 4) + (tst.Minute % 10);
				SendBuff[SendIndex++] = ((tst.Hour / 10) << 4) + (tst.Hour % 10);
				SendBuff[SendIndex++] = ((tst.Day / 10) << 4) + (tst.Day % 10);
				if (tst.Week == 0) {
					SendBuff[SendIndex++] = ((tst.Month / 10) << 4) + (tst.Month % 10) + 0xe0;
				} else {
					SendBuff[SendIndex++] = ((tst.Month / 10) << 4) + (tst.Month % 10)
							+ (tst.Week << 5);
				}
				SendBuff[SendIndex++] = (((tst.Year % 100) / 10) << 4) + (tst.Year % 10);
				lognum ++;
				SdPrintf(YNPrint,PreFix,"��½������%d,��¼ʱ��(login.log):%s",lognum,logtime);
			}
			INT32U_BCD(lognum, &SendBuff[longnumindex], 4);
		}
		fclose(fp);
//		sem_post(&Jproginfo->mainData.UseFileFlg);

	}else {
		memset(&SendBuff[SendIndex],0,4);
		SendIndex  +=  4;
	}
	return 1;
}
//�Ϻ���F243  �ź�ǿ��
INT16U Level1Data_F243_Get(INT8U Set, INT16U F, INT16U P, INT8U* Data){
	INT32S csq_24[24];
	INT8U i = 0;
	memset(csq_24,0xEE,24);
	SdPrintf(YNPrint,PreFix,"Level1Data_F243_Get begin");
	if(access("/nand/DataAlarm/csq.dat",0)==0){
		ReadFile("/nand/DataAlarm/csq.dat",csq_24,24*sizeof(INT32S),Jproginfo);
	}
	for(i=0; i < 24; i++){
//		INT32U_BCD(csq_24[i],&SendBuff[SendIndex++],1);
		SdPrintf(YNPrint," ","%02x",csq_24[i]);
		SendBuff[SendIndex++] = csq_24[i];
	}
	SdPrintf(YNPrint,PreFix,"Level1Data_F243_Get end");
	return 1;
}
//�Ϻ���F201����ȡ���һ�γ���ʧ�ܱ�����
INT16U Level1Data_F201_Get(INT8U Set, INT16U F, INT16U P, INT8U* Data){
	INT16U rmfn=0;
	INT16U i =0 ;
	SdPrintf(YNPrint,PreFix,"�Ϻ���F201����ȡ���һ�γ���ʧ�ܱ�����(Level1Data_F201_Get)");
//	for(i=0; i< R485Max; i++){
//		rmfn += (Jdatafileinfo->data485[i].MeterNum-Jdatafileinfo->data485[i].MeterNum_CBSucc);
//	}
	for(i=0; i < PointMax; i++){
		if(Jdatafileinfo->ptinfo[i].FirRead == 0)
			rmfn++;
	}
	SdPrintf(YNPrint,PreFix,"���һ�γ���ʧ�ܱ�����:%d",rmfn);
//	memcpy((void*)&SendBuff[SendIndex],(void*)&rmfn,2);
	  SendBuff[SendIndex++] = rmfn & 0xff;
	 SendBuff[SendIndex++] = (rmfn >>8)&0xff;
	return 1;
}
//�Ϻ���F202����ȡ���һ�γ������ܱ�ʧ�ܱ���Ϣ
INT16U Level1Data_F202_Get(INT8U Set, INT16U F, INT16U P, INT8U* Data){
   INT16U	i=0;
   INT16U no_begin=0;
   INT16U no_end=0;
   INT16U num=0;
   INT16U rmfn= 0;
   INT16U rmn_need = 0;
   INT16U rmfn_index = 0;
   no_begin = (*(Data+1) <<8)+ *Data;
   no_end   = (*(Data+3) <<8)+ *(Data+2);
   SdPrintf(YNPrint,PreFix,"�Ϻ���F202����ȡ���һ�γ������ܱ�ʧ�ܱ���Ϣ(Level1Data_F202_Get)");
   SdPrintf(YNPrint,PreFix,"��ʼ���=%d,�������=%d",no_begin,no_end);
   num = no_end-no_begin+1;
   rmfn_index = SendIndex;
   SendIndex += 2;
   for(i=1; i< PointMax;i++){
	   if(Jdatafileinfo->ptinfo[i].FirRead == 0){
		   if(rmfn>= no_begin && rmfn <= no_end )
		   {
			  SendBuff[SendIndex++] = rmfn&0xff;
			  SendBuff[SendIndex++] = (rmfn>>8) & 0xff;
			  memcpy((void*)&SendBuff[SendIndex],(void*)&JSetPara_AFN04_3761_2009->group2.f10[i].PointIndex,2);
			  SendIndex += 2;
			  SendBuff[SendIndex] = 0x00;
			  switch(JSetPara_AFN04_3761_2009->group2.f10[i].baudrate){
			  case 2:
				  SendBuff[SendIndex] = (1 <<5 )&0xe0;
				  break;
			  case 4:
				  SendBuff[SendIndex] = (2 << 5) & 0xe0;
				  break;
			  case 8:
				  SendBuff[SendIndex] = (3 << 5) & 0xe0;
				  break;
			  case 16:
				  SendBuff[SendIndex] = (4 << 5) & 0xe0;
				  break;
			  case 24:
				  SendBuff[SendIndex] = (5 << 5) & 0xe0;
				  break;
			  case 32:
				  SendBuff[SendIndex] = (6 << 5) & 0xe0;
				  break;
			  case 64:
				  SendBuff[SendIndex] = (7 << 5) & 0xe0;
				  break;
			 }
			  SendBuff[SendIndex] = SendBuff[SendIndex] | (JSetPara_AFN04_3761_2009->group2.f10[i].port & 0X1F);
			  SendIndex ++ ;
			  memcpy(&SendBuff[SendIndex],
			  					&JSetPara_AFN04_3761_2009->group2.f10[i].ConnectType, 1);//ͨ��Э������ 1 97 30 2007
			  SendIndex++;
			  memcpy(&SendBuff[SendIndex],
			  					&JSetPara_AFN04_3761_2009->group2.f10[i].Address[0], 6);//ͨ�ŵ�ַ
			  SendIndex += 6;
			  memcpy(&SendBuff[SendIndex],
			  					&JSetPara_AFN04_3761_2009->group2.f10[i].CaijiqiAddress[0], 6);//�����ɼ���ͨ�ŵ�ַ
			  SendIndex += 6;
			  rmn_need++;
		   }
		   else if(rmfn > no_end)
			   break;
		   if(JSetPara_AFN04_3761_2009->group2.f10[i].Status == 1)
		   			 			   rmfn++;
	   }
   }
//   memcpy((void*)&SendBuff[rmfn_index],(void*)&rmfn,2);
   SendBuff[rmfn_index] = rmn_need & 0xff;
   SendBuff[rmfn_index+1] = (rmn_need >>8)&0xff;
   return 1;
}
#endif

