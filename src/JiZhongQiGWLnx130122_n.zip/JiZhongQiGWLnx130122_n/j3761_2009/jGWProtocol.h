/*
 *
 * ������Լ�ӿں�������
 * ������Լ���Ĵ���ģ����ýӿں����������Ӧ��������
 * ������Լ���Ĵ���ģ����ýӿں�����������վ�·�����
 *
 */

#ifndef SDINTERFACEH
#define SDINTERFACEH
#include <stdlib.h>
#include <string.h>
#include "../jBase/inc/CVariable.h"
#include "../jBase/inc/jMemory.h"

//extern int jDealDealPrint;
//extern FILE *fp;


#define  J_ACK_NAK                 0x00   //ȷ��/��
#define  J_RESET                   0x01   //��λ
#define  J_LINKTEST                0x02   //��·�ӿڼ��
#define  J_ZHONGJI                 0x03   //�м�վ����
#define  J_SETPARA                 0x04   //���ò���
#define  J_CTRLCOM                 0x05   //��������
#define  J_VERIFY                  0x06   //������֤����ԿЭ��
#define  J_BACKUP                  0x07   //����
#define  J_AUTOSEND                0x08   //���󱻼����ն������ϱ�
#define  J_QUERYPARA               0x09   //�����ն�����
#define  J_GETPARA                 0x0a   //��ѯ����
#define  J_TASKDATA                0x0b   //������������
#define  J_1LEIDATE                0x0c   //����1������(ʵʱ����)
#define  J_1LEICURR                0x1c   //����1������(��ǰ����)
#define  J_2LEIDATE                0x0d   //����2������(��ʷ����)
#define  J_3LEIDATE                0x0e   //����3������(�¼�����)
#define  J_FILETRANS               0x0f   //�ļ�����
#define  J_DATATRANS               0x10   //����ת��
#define  F_ACK_UPDATE1                0x8A   //��������Ӧ��1
#define  F_ACK_UPDATE2                0x8E   //��������Ӧ��2
#define  F_ACK_UPDATE3                0x9E   //��������Ӧ��3
#define  F_UPDATE                     0x0E   //����

#define  PACK_BYTE_NUM                200    //һ֡����ֽ�����
#define  ITEMGWCOUNT                 500    //�Ǽ�������������
//********************************GW��Լ**************************************
typedef struct {
    INT8U   iDataType;  //�������ͣ�AFN������
    INT16U  Fn;         //��Ϣ��Ԫ
	INT8U   Type;       //0 ���ʵʱ���� //1 ����
    INT16U (* setdata)(INT8U Set,INT16U F,INT16U P,INT8U *Data);
    //�������ȡ���������ݣ�Set=1����վ�·���Set=0��ȡ��������վ
}DATAGW_TYPE;//��������Ϣ
//DATAGW_TYPE DataGWList[ITEMGWCOUNT];

SMFiles smfileold;
SMFiles smfile;

extern INT16U GetUserDataZoneLen(INT8U* rcvdata);
extern INT32U ifLeaps(INT16U year);
extern INT8U Judgetstime(TS ts);
//extern void CreateSendInf(INT16U len, INT8U login);
extern INT8U CheckSumGW(INT8U *buf,INT16U len);//����У����
extern void FrameTailCreate_Send(INT8U login);//�������ͱ��ĵ�β��
extern void LinkControl(INT8U F);//������·��ⱨ��
extern void CreateGWHead(INT8U PRM,int zdflg);//��������ͷ��
extern void MkLevel1Head(INT16U P,INT16U F,INT8U FRM);//����һ�����ݵı���ͷ
extern void MkLevel2Head(INT16U P,INT16U F,INT8U FRM);//�����������ݵı���ͷ
extern void GetDa(INT8U Da1,INT8U Da2);
extern void GetDt(INT8U Dt1,INT8U Dt2);
extern INT8U SetDt1(INT8U Value);//������Ϣ���ʶ�ֽ�1
extern INT8U SetDt2(INT8U Value);//������Ϣ���ʶ�ֽ�2
extern INT8U SetDa1(INT16U Value);//�������ݱ�ʶ�ֽ�1
extern INT8U SetDa2(INT16U Value);//�������ݱ�ʶ�ֽ�2
extern void SetDaDt(INT16U P,INT16U F);
extern void EC();
extern void TP();
extern void SendALLNAK(INT8U login);//���ͷ��ϱ���2
extern void SendALLACK(INT8U login);//������Ӧ����
extern void SendNAK(INT16U F,INT16U P,INT8U AFN);//����ȷ��/���ϵı���
extern void SendSecyNAK(INT8U type,INT8U *data);//����esam�ķ��ϱ���
extern void SetDataFlag97(unsigned char DI1, unsigned char DI0, unsigned char *flags);
extern INT8U TestFirFin(INT8U DtNo, INT8U DaNo);
extern int GetManyData1(DataFlg *data,INT8U *reslutBuf,INT8U DI1,INT8U DI0);
extern INT8U GetManyData(INT8U beg,DataFlg *data,INT8U *reslutBuf,INT8U DI1,INT8U DI0);
extern INT8U getManysFile(char *file,TS ts,INT8U DataType);
extern INT8U getManysData(INT8U *Data,INT8U CJQno,INT8U MeterNo,INT8U DI1,INT8U DI0,
		INT8U beg,INT8U size,INT8U DIN,INT8U BeX,INT8U AfX,INT8U XBe,INT8U XAf,INT8U DF);
extern INT8U getMeterFile(INT8U MeterType,char *file,TS ts,INT8U DataType); //DataType 1 ʵʱ 2 ������ 3 ������
extern INT8U getMetersData(INT8U MeterType,INT8U *Data,INT8U CJQno,INT8U MeterNo,INT8U DI1,INT8U DI0,
	INT8U beg,INT8U size,INT8U DIN,INT8U BeX,INT8U AfX,INT8U XBe,INT8U XAf,INT8U DF);

extern INT16U SetPara_F0_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data);
/*���ò���*/
extern INT16U SetPara_F1_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);//�ն�����ͨ�ſ�ͨ�Ų�������
extern INT16U SetPara_F2_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U SetPara_F3_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);//��վIP��ַ�Ͷ˿�
extern INT16U SetPara_F4_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);//��վ�绰����Ͷ������ĺ���
extern INT16U SetPara_F5_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);//�ն�����ͨ����Ϣ��֤����
extern INT16U SetPara_F6_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);//�ն����ַ����
extern INT16U SetPara_F7_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);//�ն�IP��ַ�Ͷ˿�
extern INT16U SetPara_F8_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);//�ն�����ͨ�Ź�����ʽ����̫ר��������ר����
extern INT16U SetPara_F9_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);//�ն�����ͨ�Ź�����ʽ����̫ר��������ר����
extern INT16U SetPara_F10_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U SetPara_F11_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U SetPara_F12_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U SetPara_F13_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U SetPara_F14_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U SetPara_F15_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U SetPara_F16_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U SetPara_F17_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U SetPara_F18_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U SetPara_F19_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U SetPara_F20_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U SetPara_F21_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U SetPara_F22_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U SetPara_F23_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);//�ն˴߷Ѹ澯����
extern INT16U SetPara_F25_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U SetPara_F26_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U SetPara_F27_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U SetPara_F28_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U SetPara_F29_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U SetPara_F30_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U SetPara_F31_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U SetPara_F33_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);//�ն˳������в���
extern INT16U SetPara_F34_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U SetPara_F35_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U SetPara_F36_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);//�ն�����ͨ��������������
extern INT16U SetPara_F37_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);//�ն�����ͨ��������������
extern INT16U SetPara_F38_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U SetPara_F39_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U SetPara_F47_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);//////xinjia
extern INT16U SetPara_F57_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U SetPara_F59_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U SetPara_F60_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U SetPara_F61_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U SetPara_F65_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U SetPara_F66_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U SetPara_F67_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U SetPara_F68_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U SetPara_F73_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U SetPara_F74_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U SetPara_F75_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U SetPara_F76_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U SetPara_F81_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U SetPara_F82_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U SetPara_F83_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);

extern INT16U SetPara_F111_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);//��������ά����ʱ�������
extern INT16U SetPara_F112_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);//�ɼ�������ܱ���ϵ��(����ѯ)
/*//added by mqingkui*/

/*����1��ʵʱ���ݵĺ�������*/
RealTimeData tempRealTimeData;

//extern INT8U AllReportHead,AllReportTail;//jPub.h���涨��ı���

extern FP64 pow_i(double num,INT8U n);//����num��n���ݣ�����nΪ����
extern void Double2TypeA2(FP64 src,INT8U type2Msg[2]);//������ת�����ݸ�ʽ2�ı���
//��ȡ��������й������޹������ݣ����������Detect_pointNum������ţ�Postive_flag�������־��is_youGong�й��޹����ʱ�־
extern INT32S Calculate_total_GongLv(INT8U Detect_pointNum,INT16U Postive_flag,INT8U is_youGong);
extern INT32S Calculate_total_GongLv_Curr(INT8U Detect_pointNum,INT16U Postive_flag,INT8U is_youGong);

extern INT16U Level1Data_F1_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_F2_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);//�ն�����ʱ��
extern INT16U Level1Data_F3_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);//�ն˲���״̬
extern INT16U Level1Data_F4_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);//�ն�����ͨ��״̬
extern INT16U Level1Data_F5_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_F6_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_F7_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);//�ն��¼���������ǰֵ
extern INT16U Level1Data_F8_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);//�ն��¼�״̬��־
extern INT16U Level1Data_F9_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);//�ն�״̬������λ��־
extern INT16U Level1Data_F10_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);//�ն�����վ����/��ͨ������
extern INT16U Level1Data_F11_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);//�ն˼���������״̬��Ϣ

extern INT16U Level1Data_F17_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);//��ǰ�ܼ��й�����
extern INT16U Level1Data_F18_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);//��ǰ�ܼ��޹�����

extern INT16U Level1Data_F25_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_F26_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_F27_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_F28_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_F31_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);//376.1lqq
extern INT16U Level1Data_F32_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);//376.1lqq
extern INT16U Level1Data_F33_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_F34_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_F35_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);//�����й��������������ʱ��
extern INT16U Level1Data_F36_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_F37_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);//376.1lqq
extern INT16U Level1Data_F38_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);//376.1lqq
extern INT16U Level1Data_F39_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);//376.1lqq
extern INT16U Level1Data_F40_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);//376.1lqq
extern INT16U Level1Data_F49_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_F73_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_F129_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_F130_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_F131_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_F132_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_F133_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_F134_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_F135_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_F136_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_F137_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);//376.1lqq
extern INT16U Level1Data_F138_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);//376.1lqq
extern INT16U Level1Data_F139_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);//376.1lqq
extern INT16U Level1Data_F140_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);//376.1lqq
extern INT16U Level1Data_F141_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);//376.1lqq
extern INT16U Level1Data_F142_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);//376.1lqq
extern INT16U Level1Data_F143_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);//376.1lqq
extern INT16U Level1Data_F144_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);//376.1lqq
extern INT16U Level1Data_F145_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_F149_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);//376.1lqq
extern INT16U Level1Data_F146_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_F147_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_F148_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_F151_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_F161_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_F165_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_F166_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_F167_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_F168_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_F169_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_F170_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_F248_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_F12_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data);//�ն������ź�Ʒ�ʣ�����չ��
extern INT16U Level1Data_F186_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data);//�ز�ģ�����汾��

//1�൱ǰ����
#ifdef SHANGHAI
//�Ϻ���F13  �ն�SIM��IMSI��
extern INT16U Level1Data_F13_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data);
//�Ϻ���F114  �ն�SIM��ICCID��
extern INT16U Level1Data_F14_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data);
//�Ϻ���F241  ��½����
extern INT16U Level1Data_F241_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data);
//�Ϻ���F242  ��½����n  n����½ʱ��
extern INT16U Level1Data_F242_Get(INT8U Set, INT16U F, INT16U P, INT8U* Data);
//�Ϻ���F243  �ź�ǿ��
extern INT16U Level1Data_F243_Get(INT8U Set, INT16U F, INT16U P, INT8U* Data);
//�ն����½��վ����
extern INT16U Get_Level2Data_F241(INT8U Set,INT16U F,INT16U P,INT8U *Data);
//�¶����½��վ����
extern INT16U Get_Level2Data_F242(INT8U Set,INT16U F,INT16U P,INT8U *Data);
//���ź�ǿ��
extern INT16U Get_Level2Data_F243(INT8U Set,INT16U F,INT16U P,INT8U *Data);
//�ն˶Ե��ܱ�ʱ�Ӻ˶ԵĲ���
extern INT16U SetPara_F241_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data);
//�ն˶Ե��ܱ��������ƵĲ���
extern INT16U SetPara_F242_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data);
//�ն�SIM������
extern INT16U SetPara_F243_Set(INT8U Set,INT16U F, INT16U P, INT8U *Data);
//�Ϻ���F201����ȡ���һ�γ���ʧ�ܱ�����
extern INT16U Level1Data_F201_Get(INT8U Set, INT16U F, INT16U P, INT8U* Data);
//�Ϻ���F202����ȡ���һ�γ������ܱ�ʧ�ܱ���Ϣ
extern INT16U Level1Data_F202_Get(INT8U Set, INT16U F, INT16U P, INT8U* Data);
#endif
extern INT16U Level1Data_Curr_F17_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);//��ǰ�ܼ��й�����
extern INT16U Level1Data_Curr_F18_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);//��ǰ�ܼ��޹�����
extern INT16U Level1Data_Curr_F25_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data);
extern INT16U Level1Data_Curr_F26_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F27_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F28_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F29_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F31_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F32_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F33_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F34_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F35_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F36_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F37_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F38_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F39_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F40_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F41_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F42_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F43_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F44_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F45_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F46_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F47_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F48_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F49_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F57_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);//LQQ xiebo ��ǰ�����ѹ������2~n��г����Чֵ
extern INT16U Level1Data_Curr_F58_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);//LQQ xiebo
extern INT16U Level1Data_Curr_F73_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);

extern INT16U Level1Data_Curr_F89_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F90_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F91_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F92_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F93_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F94_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F95_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F96_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F97_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F98_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F99_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F100_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F101_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F102_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F103_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F105_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F106_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F107_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F108_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F109_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F110_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);

extern INT16U Level1Data_Curr_F111_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F112_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F113_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F114_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F115_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F116_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);

extern INT16U Level1Data_Curr_F129_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F130_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F131_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F132_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F133_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F134_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F135_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F136_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);

extern INT16U Level1Data_Curr_F137_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F138_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F139_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F140_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F141_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F142_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F143_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F144_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F145_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F146_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F147_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F148_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F149_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F150_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F151_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F152_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F153_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F154_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F155_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F156_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F157_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F158_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F159_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F160_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F161_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
//extern INT16U Level1Data_Curr_F162_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
//extern INT16U Level1Data_Curr_F163_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
//extern INT16U Level1Data_Curr_F164_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F165_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F166_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F167_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Level1Data_Curr_F168_Get(INT8U Set,INT16U F,INT16U P,INT8U *Data);

//2�����ݺ�����������
extern INT16U Get_Level2Data_F1(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F2(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F3(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F4(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F5(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F6(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F7(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F8(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F9(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F10(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F11(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F12(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F17(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F18(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F19(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F20(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F21(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F22(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F23(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F24(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F25(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F26(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F27(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F28(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F29(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F30(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F31(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F32(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F33(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F34(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F35(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F36(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F37(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F38(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F39(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F41(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F42(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F43(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F44(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F45(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F46(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F49(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F50(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F51(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F52(INT8U Set,INT16U F,INT16U P,INT8U *Data);//10.24
extern INT16U Get_Level2Data_F53(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F54(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F57(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F60(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F73(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F74(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F75(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F76(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F81(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F82(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F83(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F84(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F85(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F86(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F87(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F88(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F89(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F90(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F91(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F92(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F93(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F94(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F95(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F97(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F98(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F99(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F100(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F101(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F102(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F103(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F104(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F105(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F106(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F107(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F108(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F109(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F110(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F121(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F122(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F123(INT8U Set,INT16U F,INT16U P,INT8U *Data);

extern INT16U Get_Level2Data_F113(INT8U Set,INT16U F,INT16U P,INT8U *Data);//LQQ xiebo
extern INT16U Get_Level2Data_F114(INT8U Set,INT16U F,INT16U P,INT8U *Data);//LQQ xiebo
extern INT16U Get_Level2Data_F115(INT8U Set,INT16U F,INT16U P,INT8U *Data);//LQQ xiebo
extern INT16U Get_Level2Data_F116(INT8U Set,INT16U F,INT16U P,INT8U *Data);//LQQ xiebo
extern INT16U Get_Level2Data_F117(INT8U Set,INT16U F,INT16U P,INT8U *Data);//LQQ xiebo
extern INT16U Get_Level2Data_F118(INT8U Set,INT16U F,INT16U P,INT8U *Data);//LQQ xiebo

extern INT16U Get_Level2Data_F145(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F146(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F147(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F148(INT8U Set,INT16U F,INT16U P,INT8U *Data);

extern INT16U Get_Level2Data_F153(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F154(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F155(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F156(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F157(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F158(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F159(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F160(INT8U Set,INT16U F,INT16U P,INT8U *Data);

extern INT16U Get_Level2Data_F161(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F162(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F163(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F164(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F165(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F166(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F167(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F168(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F169(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F170(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F171(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F172(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F173(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F174(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F175(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F176(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F177(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F178(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F179(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F180(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F181(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F182(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F183(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F184(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F185(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F186(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F187(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F188(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F189(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F190(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F191(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F192(INT8U Set,INT16U F,INT16U P,INT8U *Data);

extern INT16U Get_Level2Data_F193(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F194(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F195(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F196(INT8U Set,INT16U F,INT16U P,INT8U *Data);

extern INT16U Get_Level2Data_F209(INT8U Set,INT16U F,INT16U P,INT8U *Data);

extern INT16U Get_Level2Data_F215(INT8U Set,INT16U F,INT16U P,INT8U *Data);//���ܱ����õ���Ϣ
extern INT16U Get_Level2Data_F216(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F225(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U Get_Level2Data_F248(INT8U Set,INT16U F,INT16U P,INT8U *Data);

//�����ն����ü���Ϣ
extern INT16U CallSetting_F01_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U CallSetting_F02_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U CallSetting_F03_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U CallSetting_F04_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U CallSetting_F05_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U CallSetting_F06_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U CallSetting_F07_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern INT16U CallSetting_F08_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data);
extern void MY_MKLevel1Head(INT8U FRM);//10.10
extern void MY_MKLevel2Head(INT8U FRM);
extern void MY_MKDataUnitFlag(INT16U P,INT8U F);


#endif

