/*
 * datadeal.h
 *
 *  Created on: 2013-1-7
 *      Author: Lizh
 */

#ifndef DATADEAL_H_
#define DATADEAL_H_


#include "innerPubVar.h"




extern INT16S DealGWProtocol();
extern void LinkControl(INT8U F);//��·�ӿڼ�ⱨ�ģ�AFN=02H��,F=1:��¼���ģ�F=2:�˳���¼���ģ�F=3:��������
extern void InitGwAddr();
extern INT16S AskOneLevelData();
extern INT16S AskTwoLevelData();
extern INT16S autoReportOneLevelData(INT8U taskno);
extern INT16S autoReportTwoLevelData(INT8U taskno);
extern INT16S AutoSendThreeLevelData(INT8U F);
extern void PrintZone();
//INT16U Confirm(INT8U* rcvdata);//void RemoteAnswer();
//INT16U Reset(INT8U* rcvdata,INT16U rcvlen,INT8U* snddata, INT16U* sndlen);//void ResetControl();
//INT16U LinkTest(INT8U* rcvdata,INT8U* snddata,INT16U* sndlen);
//INT16U AskOneLevelData(INT8U*rcvdata,INT16U rcvlen,INT8U* snddata,INT16U* sndlen);
//void AskTwoLevelData();
//void SaveJzqPara();
//void SaveMeterPara(int flg);


#endif /* DATADEAL_H_ */
