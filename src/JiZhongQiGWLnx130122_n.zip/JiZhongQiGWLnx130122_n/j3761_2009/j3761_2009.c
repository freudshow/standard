/*
 * j3761_2009.c
 *
 *  Created on: 2012-12-29
 *      Author: Lizh
 */


#include "jGWProtocol.h"
#include "datadeal.h"
#include "esam.h"
#include "j3761_2009.h"
#include "innerPubVar.h"



INT8U YNPrint = 1;

void testesam(INT16U fd)
{
//	INT8U serialNum[8];
//	fp_stm8_spi = fd;
//	AppAskSerialNumber(serialNum);
//	return ;
}

char* PreFix = "\n>>";
INT16S AutoReportLvl1Lv2data(INT8U zone,
				ParamInfo3761* pParaGroups,	ProgramInfo* JprogInfo,
				ConfigInfo* JCfgInfo,DataFileInfo* JDatafileinfo,INT8U AFN,INT16U TaskNo,
				 void(*pfunc)(INT8U* sndbuf,INT16U sndlen)){
	INT16S ret = 0;
	zone_so = zone;
	JSetPara_AFN04_3761_2009 = pParaGroups;
	Jproginfo = JprogInfo;
	Jcfginfo = JCfgInfo;
	Jdatafileinfo = JDatafileinfo;
	pBackCallFunc = pfunc;
	memset(SendBuff,0,FrameSize);
	SendIndex = 0;
	memset(SendBuff,0,FrameSize);
		SendIndex = 0;
	switch(AFN){
		case J_1LEIDATE:
			ret = autoReportOneLevelData(TaskNo);
			break;
		case J_2LEIDATE:
			ret = autoReportTwoLevelData(TaskNo);
			break;
		default:
			break;
	}
	return ret;
}
INT16S AutoReportLvl3data(INT8U zone,
				ParamInfo3761* pParaGroups,	ProgramInfo* JprogInfo,
				ConfigInfo* JCfgInfo,DataFileInfo* JDatafileinfo,INT8U Fn,
				 void(*pfunc)(INT8U* sndbuf,INT16U sndlen)){
	INT16S ret = 0;
	zone_so = zone;
	JSetPara_AFN04_3761_2009 = pParaGroups;
	Jproginfo = JprogInfo;
	Jcfginfo = JCfgInfo;
	Jdatafileinfo = JDatafileinfo;
	pBackCallFunc = pfunc;
	memset(SendBuff,0,FrameSize);
	SendIndex = 0;
	if(Fn > 0 && Fn <= 248 )
		ret = AutoSendThreeLevelData(Fn);
	else
		ret = ERR_AUTO_WRONG_FN;
	return ret;
}

INT16U LinkCtrl(ConfigInfo* JCfgInfo,INT8U *PFC,INT8U Fn,INT8U* sndbuf,INT16U* sndlen,void(*pfunc)(INT8U* sndbuf,INT16U sndlen))
{
	*sndlen = 0;
	SendIndex = 0;
//	Jproginfo = jProgInfo;
	Jcfginfo = JCfgInfo;
	pBackCallFunc = pfunc;
	memset(SendBuff,0,FrameSize);
	SdPrintf(1,"\n>>","��·�ӿڼ�ⱨ�Ŀ�ʼ(Fn=%d),",Fn);//
//	Fseq = Jproginfo->PFC;
//	Jproginfo->PFC++;
	Fseq = *PFC;
	(*PFC) ++;
	CreateGWHead(0xc9, 0);//��������ͷ
	SendBuff[SendIndex++] = 2;//Ӧ�ò㹦����AFN��2����·�ӿڼ��
	SendBuff[SendIndex++] = 0x70 | (Fseq & 0x0f);//0x70=11100000
	SendBuff[SendIndex++] = 0;//��Ϣ��DA1
	SendBuff[SendIndex++] = 0;//��Ϣ��DA2
	if (Fn == 1)//F1��¼����
	{
		//Fn��ȡ��Ϊ��DT2*8+(DT1��Чλ�����)+1
		SendBuff[SendIndex++] = 1;//��Ϣ��ԪDT1
		SendBuff[SendIndex++] = 0;//��Ϣ����DT2
	}
	if (Fn == 2)//F2�˳���¼����
	{
		SendBuff[SendIndex++] = 2;
		SendBuff[SendIndex++] = 0;
	}
	if (Fn == 3)//F3��������
	{
		SendBuff[SendIndex++] = 4;
		SendBuff[SendIndex++] = 0;
	}
	FrameTailCreate_Send(Fn);
	if(SendIndex > 0){
		memcpy(sndbuf,SendBuff,SendIndex);
		*sndlen = SendIndex;
	}
	SdPrintf(YNPrint,PreFix,"��·�ӿڼ�ⱨ�Ľ���(Fn=%d)",Fn);//
	return (J_ACK_NAK<8)|Fn;
}
/*
 * ����������վ������
 * */
INT16S processData(INT8U zone,
		ParamInfo3761* pParaGroups,	ProgramInfo* JprogInfo,ConfigInfo* JCfgInfo,DataFileInfo* JDatafileinfo,
						INT8U* rcvbuf,INT16U rcvlen,
					   INT8U* sndbuf,INT16U* sndlen,
					   void(*pfunc)(INT8U* sndbuf,INT16U sndlen))	  {
	SdPrintf(YNPrint,PreFix,"����j3761_2009 ��̬��...");
	INT16S ret = 0;
	INT16U i = 0;
	zone_so = zone;
	JSetPara_AFN04_3761_2009 = pParaGroups;
	Jproginfo = JprogInfo;
	Jcfginfo = JCfgInfo;
	Jdatafileinfo = JDatafileinfo;
	pBackCallFunc = pfunc;
//	fp_stm8_spi = hdl_spi;
	PrintZone();
	//û�б�Ҫÿ���д�spi�������ж���֤����
	SPIinit();
	SdPrintf(YNPrint,PreFix,"fp_stm8_spi=%d",fp_stm8_spi);
	memset(TempBuf,0,TEMPBUF_SIZE);
	memcpy(TempBuf,rcvbuf,rcvlen);
	*sndlen = 0;
	SdPrintf(YNPrint," ","recv:");
	for (i = 0; i < rcvlen; i++) {
		SdPrintf(YNPrint," ","%02x",TempBuf[i]);
	}

	if(rcvlen >= 6)
	{
		if(TempBuf[0] == 0x68 && TempBuf[5] == 0x68)
		{
			if(rcvlen >= 14)
			{
				DataLength =  GetUserDataZoneLen(rcvbuf);
				SdPrintf(YNPrint,PreFix,"���ĳ���=%d,���ݳ���=%d\n",rcvlen,DataLength);
				if(rcvlen >= DataLength+8){
					if (DataLength + 8>=TEMPBUF_SIZE)
					{
						ret = ERR_RCVD_TOOLONG;
					}
					else
					{
						INT16U CheckCode = 0;
						CheckCode = CheckSumGW(&TempBuf[6],DataLength);
						if (CheckCode == TempBuf[DataLength + 6])//У��ͨ��
						{
							SdPrintf(YNPrint,PreFix,"У��ͨ��");
//							for (i = 0; i < length + 8; i++) {
//								SdPrintf("%02x ",TempBuf[i]);
//							}//��������
//							SdPrintf("\n\r");
							ret =  DealGWProtocol();
							if(ret > 0 && pBackCallFunc == NULL && SendBuff != NULL)
							{
								memcpy(sndbuf,SendBuff,SendIndex);
								*sndlen = SendIndex;
							}
//							if(pfunc != NULL && sndbuf != NULL && *sndlen != 0){//���ô���Ļص�����
//								pfunc(sndbuf,*sndlen);
//							}
						} else //У��ʧ��
						{
							ret = ERR_CRC_ERROR;
						}
					}
				}
			   else
			   {
				   ret =  ERR_RCVD_LOST;
			   }
			} else {
				ret=  ERR_RCVD_LOST;
			}
		} else {
			ret = ERR_RCVD_LOST;
		}
	}
	else
		ret = ERR_RCVD_LOST;
	if (fp_stm8_spi != -1) {
			spi_close(fp_stm8_spi);
	}
	SdPrintf(YNPrint,PreFix,"�˳�j3761_2009��̬��(ret=%4x)...",ret);
	return ret;
}
