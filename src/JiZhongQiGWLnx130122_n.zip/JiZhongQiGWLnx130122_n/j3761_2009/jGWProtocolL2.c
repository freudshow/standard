/*
 *
 *   ������Լ�ӿں�������
 *       ������Լ���Ĵ���ģ����ýӿں����������Ӧ��������
 *       ������Լ���Ĵ���ģ����ýӿں�����������վ�·�����
 *
 *///-------------------------------------------------------------

#include "time.h"
#include <sys/mman.h>
#include <unistd.h>
#include "jGWProtocol.h"
//#include "inc/init.h"
#include "../jBase/inc/pubfunction.h"
#include "innerPubVar.h"

//extern void TSGet(TS *ts);
extern void TSSet(TS ts);
extern void TimeAdd(TS *ts, INT16U unit, int step);
extern int IsEqual(TS *ts0, TS *ts1);
extern INT32S BCD_INT32(INT8U *buf, INT8U len);
extern void INT32U_BCD(INT32S data, INT8U *buf, INT8U len);

INT8U            StPos;
void maketemp()
{
	SendBuff[SendIndex++]=0xee;//��
	SendBuff[SendIndex++]=0xee;//��
	SendBuff[SendIndex++]=0xee;//��

	SendBuff[SendIndex++]=0x00;//�鳭��ʱ��  8�� 14�� 23��59��59
	SendBuff[SendIndex++]=0x00;
	INT32U_BCD(0,&SendBuff[SendIndex++],1);
	INT32U_BCD(0,&SendBuff[SendIndex++],1);
	INT32U_BCD(0,&SendBuff[SendIndex++],1);

	SendBuff[SendIndex++]=FeiLvNum;

}
//2�����ݷ�������

//INT16U Get_Level2Data_F1(INT8U Set,INT16U F,INT16U P,INT8U *Data)
//{
//	INT16U IsDataFlag,dftype;
//	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType,i;
//	TS ts,ts2;
//	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
//	ts.Week=0;
//	ts2=ts;
//	StPos=0;
//	if (AutoFlg==1)
//		StPos=2;
//	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
//	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
//	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
////	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
//	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
//	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
//	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
//	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
//	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);//����ʱ��  8��14��
//	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
//	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
//	ts.Day=BCD_INT32(&Data[0]+StPos,1);
//	ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
//	ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
//	if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong
//	if(zone_so == JIANGSU)
//	{
//		SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
//		SendBuff[SendIndex++]=0x23;
//		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
//		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
//		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
//		SendBuff[SendIndex++]=FeiLvNum;
//	}
//	else{
//
//		SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
//		SendBuff[SendIndex++]=0;
//		INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
//		INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
//		INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
//		SendBuff[SendIndex++]=FeiLvNum;
//	}
//
//	//��ȡ������
//	IsDataFlag=0;
//	sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
//	if ((MeterType == 9) || (MeterType == 6))
//	{
//		dftype=1;//comm
//	}
//	else
//	{
//		dftype=1;
//	}
//	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
//	if(IsDataFlag==1)
//	{
//		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x90,0x10,0,4,5,1,0,0,0,dftype);
//		if (IsDataFlag == 0)
//		{
//			memset(&SendBuff[SendIndex],OxXX,85);
//			SendIndex=SendIndex+85;
//			//SendNAK(F, P, 0x0d);
//			//return 3;
//		}
//		else
//		{
//			for(i=0;i<5;i++)
//			{
//				if((SendBuff[(SendIndex+1)+i*5]==OxXX)&&
//				   (SendBuff[(SendIndex+2)+i*5]==OxXX)&&
//				   (SendBuff[(SendIndex+3)+i*5]==OxXX)&&
//				   (SendBuff[(SendIndex+4)+i*5]==OxXX))
//						memset(&SendBuff[SendIndex+0+i*5],OxXX,5);
//			}
//			SendIndex = SendIndex + 25;
//			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x10,0,4,5,0,0,0,0,dftype);
//			SendIndex = SendIndex + 20;
//			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x30,0,4,5,0,0,0,0,dftype);
//			SendIndex = SendIndex + 20;
//			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x40,0,4,5,0,0,0,0,dftype);
//			SendIndex = SendIndex + 20;
//		}
//	}
//	else
//	{
//		memset(&SendBuff[SendIndex],OxXX,85);
//		SendIndex=SendIndex+85;
//		//SendNAK(F, P, 0x0d);
//		//return 3;
//	}
////	EC();
////	TP();
////	FrameTailCreate_Send(0);
//	return 3;
//}

INT16U Get_Level2Data_F1(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType,i,ridongjie_d[10],dianneng[20];
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week=0;
	ts2=ts;
	StPos=0;
	if (AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	dftype=1;
	SdPrintf(YNPrint,PreFix,"AutoFlg�� %d\n", AutoFlg);
	SdPrintf(YNPrint,PreFix,"Data[0]=%d,Data[1]=%d,Data[2]=%d,Data[3]=%d,Data[4]=%d,Data[5]=%d,Data[6]=%d" , Data[0],Data[1],Data[2],Data[3],Data[4],Data[5],Data[6]);
//	if((zone_so==XINJIANG) || Jcfginfo->jzqpara.ChaoBiaoDongJieType)//dongjieyd
	if((zone_so&0x7f) == XINJIANG || Jcfginfo->jzqpara.ChaoBiaoDongJieType)
	{
		IsDataFlag=0;
		ts.Day=BCD_INT32(&Data[0]+StPos,1);
		ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
		if (AutoFlg==0) TimeAdd(&ts,4,1);
		memset(Temp_FilePath,0x00,60);
		sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);//���ļ�
		SdPrintf(YNPrint,PreFix,"F1 ���ļ��� %s\n", Temp_FilePath);
		IsDataFlag=getMeterFile(MeterType,(char *)Temp_FilePath,ts,2);
		if(IsDataFlag==1)
//		if(0)
		{
			memset(ridongjie_d, 0, 10);
			//FB01 ��Flag.cfg�� �ն���ʱ��
			IsDataFlag=getMetersData(MeterType,ridongjie_d,CJQno,MeterNo,0xFB,0x01,0,5,1,0,0,0,0,dftype);//lqq161
			SdPrintf(YNPrint,PreFix,"ridongjie_d  FB 01: ");
			for(i=0;i<10;i++)
				SdPrintf(YNPrint," ","%d", ridongjie_d[i]);

			if (IsDataFlag == 1)
			{
				SendBuff[SendIndex++]=ridongjie_d[2];//��//lqq161
				SendBuff[SendIndex++]=ridongjie_d[3];//��
				SendBuff[SendIndex++]=ridongjie_d[4];//��
				//�鳭��ʱ��  8�� 15�� 0��0��0

				SendBuff[SendIndex++]=0;
				SendBuff[SendIndex++]=0;
				INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);

				SendBuff[SendIndex++]=FeiLvNum;//���ʸ���

				memset(dianneng, 0, 20);
				IsDataFlag=getMetersData(MeterType,dianneng,CJQno,MeterNo,0xFB,0x02,0,20,1,1,0,0,0,dftype);//lqq161
				SdPrintf(YNPrint,PreFix,"SendIndex=%d 0xFB,0x02: ",SendIndex);
				for(i=0;i<20;i++)
					SdPrintf(YNPrint," ","%02x", dianneng[i]);
				if (IsDataFlag ==1)
				{
					for(i=0;i<5;i++)
					{
						if((dianneng[(i)+i*3]==OxXX)&&(dianneng[(i+1)+i*3]==OxXX)&&(dianneng[(i+2)+i*3]==OxXX)&&(dianneng[(i+3)+i*3]==OxXX))
						{
							memcpy(&SendBuff[SendIndex],&dianneng[i*4],4);
							SendIndex = SendIndex + 4;
							SendBuff[SendIndex++]=OxXX;
						}
						else
						{
							memcpy(&SendBuff[SendIndex],&dianneng[i*4],4);
							SendIndex = SendIndex + 4;
							SendBuff[SendIndex++]=0x00;
						}
					}
				}
				else
				{
					memset(&SendBuff[SendIndex],OxXX,25);
					SendIndex=SendIndex+25;
				}

				IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xFB,0x04,0,20,1,0,0,0,0,dftype);//lqq161
				SdPrintf(YNPrint,PreFix,"SendIndex=%d 0xFB,0x04: ",SendIndex);
				for(i=0;i<20;i++)		SdPrintf(YNPrint," ","%02x",SendBuff[SendIndex+i]);
				SendIndex = SendIndex + 20;

				IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xFB,0x05,0,20,1,0,0,0,0,dftype);//lqq161
				SdPrintf(YNPrint,PreFix,"SendIndex=%d 0xFB,0x05: ",SendIndex);
				for(i=0;i<20;i++)		SdPrintf(YNPrint," ","%02x", SendBuff[SendIndex+i]);
				SendIndex = SendIndex + 20;

				IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xFB,0x06,0,20,1,0,0,0,0,dftype);//lqq161
				SdPrintf(YNPrint,PreFix,"SendIndex=%d 0xFB,0x06: ",SendIndex);
				for(i=0;i<20;i++)		SdPrintf(YNPrint," ","%02x", SendBuff[SendIndex+i]);
				SendIndex = SendIndex + 20;

			}else	//zhengchang
			{
			//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
				ts2.Day=BCD_INT32(&Data[0]+StPos,1);
				ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
				ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
				if (AutoFlg==1) TimeDecrease(&ts2,4,1);
				INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);//����ʱ��  8��14��
				INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
				ts.Day=BCD_INT32(&Data[0]+StPos,1);
				ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
				ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
				if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong//10.7 ///////////////////lcy
//				if(zone_so == JIANGSU)
				if((zone_so&0x7f) == JIANGSU)
				{
					SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
					SendBuff[SendIndex++]=0x23;
					INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
					INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
					INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
					SendBuff[SendIndex++]=FeiLvNum;
				}
				else{

					SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
					SendBuff[SendIndex++]=0;
					INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
					INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
					INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
					SendBuff[SendIndex++]=FeiLvNum;
				}

				IsDataFlag=0;
				sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
				SdPrintf(YNPrint,PreFix,"F1... ���ļ��� %s\n", Temp_FilePath);
				IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
				if(IsDataFlag==1)
				{
					IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x90,0x10,0,4,5,1,0,0,0,dftype);
					if (IsDataFlag == 0)
					{
						memset(&SendBuff[SendIndex],OxXX,85);
						SendIndex=SendIndex+85;
						//SendNAK(F, P, 0x0d);
						//return 3;
					}
					else
					{
						for(i=0;i<5;i++)
						{
							if((SendBuff[(SendIndex+1)+i*5]==OxXX)&&(SendBuff[(SendIndex+2)+i*5]==OxXX)&&
							   (SendBuff[(SendIndex+3)+i*5]==OxXX)&&(SendBuff[(SendIndex+4)+i*5]==OxXX))
									memset(&SendBuff[SendIndex+0+i*5],OxXX,5);
						}
						SendIndex = SendIndex + 25;
						IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x10,0,4,5,0,0,0,0,dftype);
						SendIndex = SendIndex + 20;
						IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x30,0,4,5,0,0,0,0,dftype);
						SendIndex = SendIndex + 20;
						IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x40,0,4,5,0,0,0,0,dftype);
						SendIndex = SendIndex + 20;
					}
				}
				else
				{
					memset(&SendBuff[SendIndex],OxXX,85);
					SendIndex=SendIndex+85;
					//SendNAK(F, P, 0x0d);
					//return 3;
				}
			}
		}else
		{
			memset(&SendBuff[SendIndex],OxXX,94);
			SendIndex=SendIndex+94;
		}
	}
	else	//zhengchang
	{
	//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
		ts2.Day=BCD_INT32(&Data[0]+StPos,1);
		ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
		ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
		if (AutoFlg==1) TimeDecrease(&ts2,4,1);
		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);//����ʱ��  8��14��
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		ts.Day=BCD_INT32(&Data[0]+StPos,1);
		ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
		if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong
//		if(zone_so == JIANGSU)
		if((zone_so&0x7f) == JIANGSU)
		{
			SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
			SendBuff[SendIndex++]=0x23;
			INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
			SendBuff[SendIndex++]=FeiLvNum;
		}
		else{
			SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
			SendBuff[SendIndex++]=0;
			INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
			SendBuff[SendIndex++]=FeiLvNum;
		}

		//��ȡ������
		IsDataFlag=0;
		sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
		SdPrintf(YNPrint,PreFix,"\nF1........ ���ļ��� %s\n", Temp_FilePath);
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
		if(IsDataFlag==1)
		{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x90,0x10,0,4,5,1,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,85);
				SendIndex=SendIndex+85;
				//SendNAK(F, P, 0x0d);
				//return 3;
			}
			else
			{
				for(i=0;i<5;i++)
				{
					if((SendBuff[(SendIndex+1)+i*5]==OxXX)&&
					   (SendBuff[(SendIndex+2)+i*5]==OxXX)&&
					   (SendBuff[(SendIndex+3)+i*5]==OxXX)&&
					   (SendBuff[(SendIndex+4)+i*5]==OxXX))
							memset(&SendBuff[SendIndex+0+i*5],OxXX,5);
				}
				SendIndex = SendIndex + 25;
				IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x10,0,4,5,0,0,0,0,dftype);
				SendIndex = SendIndex + 20;
				IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x30,0,4,5,0,0,0,0,dftype);
				SendIndex = SendIndex + 20;
				IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x40,0,4,5,0,0,0,0,dftype);
				SendIndex = SendIndex + 20;
			}
		}
		else
		{
			memset(&SendBuff[SendIndex],OxXX,85);
			SendIndex=SendIndex+85;
			//SendNAK(F, P, 0x0d);
			//return 3;
		}
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 3;
}


INT16U Get_Level2Data_F2(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType,i;
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if (AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);

	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong
//	if(zone_so == JIANGSU)
	if((zone_so&0x7f) == JIANGSU)
	{
		SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
		SendBuff[SendIndex++]=0x23;
		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}
	else{

		SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
		SendBuff[SendIndex++]=0;
		INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}

	//��ȡ������
	IsDataFlag=0;

	sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x90,0x20,0,4,5,1,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,85);
			SendIndex=SendIndex+85;
			//SendNAK(F, P, 0x0d);
			//return 3;
		}
		else
		{
			for(i=0;i<5;i++)
			{
				if((SendBuff[(SendIndex+1)+i*5]==OxXX)&&
				   (SendBuff[(SendIndex+2)+i*5]==OxXX)&&
				   (SendBuff[(SendIndex+3)+i*5]==OxXX)&&
				   (SendBuff[(SendIndex+4)+i*5]==OxXX))
						memset(&SendBuff[SendIndex+0+i*5],OxXX,5);
			}
			SendIndex = SendIndex + 25;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x20,0,4,5,0,0,0,0,dftype);
			SendIndex = SendIndex + 20;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x50,0,4,5,0,0,0,0,dftype);
			SendIndex = SendIndex + 20;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x60,0,4,5,0,0,0,0,dftype);
			SendIndex = SendIndex + 20;
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,85);
		SendIndex=SendIndex+85;
		//SendNAK(F, P, 0x0d);
		//return 3;
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 3;
}
INT16U Get_Level2Data_F3(INT8U Set,INT16U F,INT16U P,INT8U *Data)		//�ն���������/�޹��������������ʱ�䣨�ܣ�����1~4��   9.22
{
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if (AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);

	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong
//	if(zone_so == JIANGSU)
	if((zone_so&0x7f) == JIANGSU)
	{
		SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
		SendBuff[SendIndex++]=0x23;
		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}
	else{

		SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
		SendBuff[SendIndex++]=0;
		INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}

	//��ȡ������
	IsDataFlag=0;

	sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
	if(IsDataFlag==1)
	{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa0,0x1f,0,15,1,0,0,0,0,dftype);
			if(IsDataFlag==0) memset(&SendBuff[SendIndex],OxXX,15);
  			SendIndex = SendIndex + 15;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb0,0x1f,0,20,1,0,0,0,0,dftype);
			if(IsDataFlag==0) memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex = SendIndex + 20;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa1,0x1f,0,15,1,0,0,0,0,dftype);
			if(IsDataFlag==0) memset(&SendBuff[SendIndex],OxXX,15);
			SendIndex = SendIndex + 15;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb1,0x1f,0,20,1,0,0,0,0,dftype);
			if(IsDataFlag==0) memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex = SendIndex + 20;
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,70);
		SendIndex=SendIndex+70;
		//SendNAK(F, P, 0x0d);
		//return 3;
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 3;
}
INT16U Get_Level2Data_F4(INT8U Set,INT16U F,INT16U P,INT8U *Data)		//�ն��ᷴ����/�޹��������������ʱ�䣨�ܣ�����1~4��   9.22
{
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if (AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);

	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong
//	if(zone_so == JIANGSU)
	if((zone_so&0x7f) == JIANGSU)
	{
		SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
		SendBuff[SendIndex++]=0x23;
		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}
	else{

		SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
		SendBuff[SendIndex++]=0;
		INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}

	//��ȡ������
	IsDataFlag=0;

	sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
	if(IsDataFlag==1)
	{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa0,0x2f,0,15,1,0,0,0,0,dftype);
			if(IsDataFlag==0) memset(&SendBuff[SendIndex],OxXX,15);
  			SendIndex = SendIndex + 15;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb0,0x2f,0,20,1,0,0,0,0,dftype);
			if(IsDataFlag==0) memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex = SendIndex + 20;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa1,0x2f,0,15,1,0,0,0,0,dftype);
			if(IsDataFlag==0) memset(&SendBuff[SendIndex],OxXX,15);
			SendIndex = SendIndex + 15;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb1,0x2f,0,20,1,0,0,0,0,dftype);
			if(IsDataFlag==0) memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex = SendIndex + 20;
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,70);
		SendIndex=SendIndex+70;
		//SendNAK(F, P, 0x0d);
		//return 3;
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
		return 3;
}

int Calculate_day_Elc(INT16U F,INT16U P,INT8U *Data,INT8U DI1,INT8U DI0,INT8U BeX)
{
	INT16U i,IsDataFlag,j,dftype,dflg;
	INT8U Temp_FilePath[60],tempManyData[50],tempData[50],CJQno,MeterNo,MeterType;
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts2=ts;
	INT32S tmp[5],tmp2=0,tmp3=0;
	for(i=0;i<5;i++)
		tmp[i]=0;
	StPos=0;
	if (AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	SendBuff[SendIndex++]=FeiLvNum;
	ts.Year = BCD_INT32(&Data[2]+StPos,1)+2000;
	ts.Month=BCD_INT32(&Data[1]+StPos,1);
	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	if (AutoFlg==0) TimeAdd(&ts,4,1);

	//��������
	IsDataFlag=0;
	LDType=2;
	dflg=0;
	memset(Temp_FilePath,0x00,60);
	sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&tempManyData[0],CJQno,MeterNo,DI1,DI0,0,4,5,0,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 3;
		}
		else
		{
			dflg=1;
			memcpy(&tmp2, &JSetPara_AFN04_3761_2009->Point[P-1].f25.V_BeiLv[0],2);
			memcpy(&tmp3,&JSetPara_AFN04_3761_2009->Point[P-1].f25.I_BeiLv[0],2);
			tmp2=1;
			tmp3=1;
			for(j=0;j<5;j++)
			{
				tmp[j]=BCD_INT32(&tempManyData[0+j*4], 4)*100;
			}
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,20);
		SendIndex=SendIndex+20;
		//SendNAK(F, P, 0x0d);
		//return 3;
	}
	if (dflg==1)
	{
		IsDataFlag=0;
		memset(Temp_FilePath,0x00,60);
		TimeDecrease(&ts,4,1);//����ǰһ�������
		sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
		if ((MeterType == 9) || (MeterType == 6))
		{
			dftype=1;//comm
		}
		else
		{
			dftype=1;
		}
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
		if(IsDataFlag==1)
		{
			IsDataFlag=getMetersData(MeterType,&tempManyData[0],CJQno,MeterNo,DI1,DI0,0,4,5,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,20);
				SendIndex=SendIndex+20;
				//SendNAK(F, P, 0x0d);
				//return 3;
			}
			else
			{
				memcpy(&tmp2,&JSetPara_AFN04_3761_2009->Point[P-1].f25.V_BeiLv[0],2);
				memcpy(&tmp3,&JSetPara_AFN04_3761_2009->Point[P-1].f25.I_BeiLv[0],2);
				tmp2=1;
				tmp3=1;
				for(j=0;j<5;j++)
				{
					for(i=0;i<BeX;i++)
						SendBuff[SendIndex++]=0x00;
					tmp[j]=tmp[j]-(BCD_INT32(&tempManyData[0+j*4], 4)*100);
					INT32U_BCD(tmp[j], &tempData[0], 4);
					memcpy(&SendBuff[SendIndex],&tempData[0],4);
					SendIndex=SendIndex+4;
				}
			}
		}
		else
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 3;
		}
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 3;
}

INT16U Get_Level2Data_F5(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Calculate_day_Elc(F,P,Data,0x90,0x10,0);
}
INT16U Get_Level2Data_F6(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Calculate_day_Elc(F,P,Data,0x91,0x10,0);
}
INT16U Get_Level2Data_F7(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Calculate_day_Elc(F,P,Data,0x90,0x20,0);
}
INT16U Get_Level2Data_F8(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Calculate_day_Elc(F,P,Data,0x91,0x20,0);
}
//INT16U Get_Level2Data_F9(INT8U Set,INT16U F,INT16U P,INT8U *Data)
//{
//	INT16U IsDataFlag,dftype;
//	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType,i;
//	TS ts,ts2;
//	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
//	ts.Week=0;
//	ts2=ts;
//	StPos=0;
//	if (AutoFlg==1)
//		StPos=2;
//	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
//	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
//	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
////	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
//	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
//	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
//	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
//	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
//	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);//����ʱ��  8��14��
//	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
//	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
//	ts.Day=BCD_INT32(&Data[0]+StPos,1);
//	ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
//	ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
//	if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong
//	if(zone_so == JIANGSU)
//	{
//		SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
//		SendBuff[SendIndex++]=0x23;
//		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
//		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
//		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
//		SendBuff[SendIndex++]=FeiLvNum;
//	}
//	else{
//
//		SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
//		SendBuff[SendIndex++]=0;
//		INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
//		INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
//		INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
//		SendBuff[SendIndex++]=FeiLvNum;
//	}
//
//	//��ȡ������
//	IsDataFlag=0;
//	sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
//	if ((MeterType == 9) || (MeterType == 6))
//	{
//		dftype=1;//comm
//	}
//	else
//	{
//		dftype=1;
//	}
//	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
//	if(IsDataFlag==1)
//	{
//		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x90,0x10,0,4,5,1,0,0,0,dftype);
//		if (IsDataFlag == 0)
//		{
//			memset(&SendBuff[SendIndex],OxXX,85);
//			SendIndex=SendIndex+85;
//			//SendNAK(F, P, 0x0d);
//			//return 3;
//		}
//		else
//		{
//			for(i=0;i<5;i++)
//			{
//				if((SendBuff[(SendIndex+1)+i*5]==OxXX)&&
//				   (SendBuff[(SendIndex+2)+i*5]==OxXX)&&
//				   (SendBuff[(SendIndex+3)+i*5]==OxXX)&&
//				   (SendBuff[(SendIndex+4)+i*5]==OxXX))
//						memset(&SendBuff[SendIndex+0+i*5],OxXX,5);
//			}
//			SendIndex = SendIndex + 25;
//			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x10,0,4,5,0,0,0,0,dftype);
//			SendIndex = SendIndex + 20;
//			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x30,0,4,5,0,0,0,0,dftype);
//			SendIndex = SendIndex + 20;
//			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x40,0,4,5,0,0,0,0,dftype);
//			SendIndex = SendIndex + 20;
//		}
//	}
//	else
//	{
//		memset(&SendBuff[SendIndex],OxXX,85);
//		SendIndex=SendIndex+85;
//		//SendNAK(F, P, 0x0d);
//		//return 3;
//	}
////	EC();
////	TP();
////	FrameTailCreate_Send(0);
//	return 3;
//}

INT16U Get_Level2Data_F9(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType,i,ridongjie_d[10],dianneng[20];
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week=0;
	ts2=ts;
	StPos=0;
	if (AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	dftype=1;
	SdPrintf(YNPrint,PreFix, "AutoFlg�� %d\n", AutoFlg);
	SdPrintf(YNPrint,PreFix, "Data[0]=%d,Data[1]=%d,Data[2]=%d,Data[3]=%d,Data[4]=%d,Data[5]=%d,Data[6]=%d" , Data[0],Data[1],Data[2],Data[3],Data[4],Data[5],Data[6]);
//	if(0)
	if(((zone_so&0x7f)==XINJIANG) || Jcfginfo->jzqpara.ChaoBiaoDongJieType)//dongjieyd

	{
		IsDataFlag=0;
		ts.Day=BCD_INT32(&Data[0]+StPos,1);
		ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
		if (AutoFlg==0) TimeAdd(&ts,4,1);
		memset(Temp_FilePath,0x00,60);
		sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);//���ļ�
		SdPrintf(YNPrint,PreFix, "\nF9 ���ļ��� %s\n", Temp_FilePath);
		IsDataFlag=getMeterFile(MeterType,(char *)Temp_FilePath,ts,2);
		if(IsDataFlag==1)
//		if(0)
		{
			memset(ridongjie_d, 0, 10);
			//FB01 ��Flag.cfg�� �ն���ʱ��
			IsDataFlag=getMetersData(MeterType,ridongjie_d,CJQno,MeterNo,0xFB,0x01,0,5,1,0,0,0,0,dftype);//lqq161
			SdPrintf(YNPrint,PreFix, "ridongjie_d  FB 01: ");
			for(i=0;i<10;i++)		SdPrintf(YNPrint," ","%d", ridongjie_d[i]);
//			if(0)
			if (IsDataFlag == 1)
			{
				SendBuff[SendIndex++]=ridongjie_d[2];//��//lqq161
				SendBuff[SendIndex++]=ridongjie_d[3];//��
				SendBuff[SendIndex++]=ridongjie_d[4];//��
				//�鳭��ʱ��  8�� 15�� 0��0��0

				SendBuff[SendIndex++]=0;
				SendBuff[SendIndex++]=0;
				INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);

				SendBuff[SendIndex++]=FeiLvNum;//���ʸ���

				memset(dianneng, 0, 20);
				IsDataFlag=getMetersData(MeterType,dianneng,CJQno,MeterNo,0xFB,0x02,0,20,1,1,0,0,0,dftype);//lqq161
				SdPrintf(YNPrint,PreFix, "\nSendIndex=%d 0xFB,0x02: ",SendIndex);
				for(i=0;i<20;i++)
					SdPrintf(YNPrint,PreFix, "%02x ", dianneng[i]);
				if (IsDataFlag ==1)
				{
					for(i=0;i<5;i++)
					{
						if((dianneng[(i)+i*3]==OxXX)&&(dianneng[(i+1)+i*3]==OxXX)&&(dianneng[(i+2)+i*3]==OxXX)&&(dianneng[(i+3)+i*3]==OxXX))
						{
							memcpy(&SendBuff[SendIndex],&dianneng[i*4],4);
							SendIndex = SendIndex + 4;
							SendBuff[SendIndex++]=OxXX;
						}
						else
						{
							memcpy(&SendBuff[SendIndex],&dianneng[i*4],4);
							SendIndex = SendIndex + 4;
							SendBuff[SendIndex++]=0x00;
						}
					}
				}
				else
				{
					memset(&SendBuff[SendIndex],OxXX,25);
					SendIndex=SendIndex+25;
				}

				IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xFB,0x04,0,20,1,0,0,0,0,dftype);//lqq161
				SdPrintf(YNPrint,PreFix, "\nSendIndex=%d 0xFB,0x04: ",SendIndex);
				for(i=0;i<20;i++)		SdPrintf(YNPrint,PreFix, "%02x ",SendBuff[SendIndex+i]);
				SendIndex = SendIndex + 20;

				IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xFB,0x05,0,20,1,0,0,0,0,dftype);//lqq161
				SdPrintf(YNPrint,PreFix, "\nSendIndex=%d 0xFB,0x05: ",SendIndex);
				for(i=0;i<20;i++)		SdPrintf(YNPrint,PreFix, "%02x ", SendBuff[SendIndex+i]);
				SendIndex = SendIndex + 20;

				IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xFB,0x06,0,20,1,0,0,0,0,dftype);//lqq161
				SdPrintf(YNPrint,PreFix, "\nSendIndex=%d 0xFB,0x06: ",SendIndex);
				for(i=0;i<20;i++)		SdPrintf(YNPrint,PreFix, "%02x ", SendBuff[SendIndex+i]);
				SendIndex = SendIndex + 20;

			}else	//zhengchang
			{
			//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
				ts2.Day=BCD_INT32(&Data[0]+StPos,1);
				ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
				ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
				if (AutoFlg==1) TimeDecrease(&ts2,4,1);
				INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);//����ʱ��  8��14��
				INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
				ts.Day=BCD_INT32(&Data[0]+StPos,1);
				ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
				ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
				if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong //10.7////////////////////////////lcy
				if((zone_so&0x7f) == JIANGSU)
				{
					SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
					SendBuff[SendIndex++]=0x23;
					INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
					INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
					INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
					SendBuff[SendIndex++]=FeiLvNum;
				}
				else{

					SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
					SendBuff[SendIndex++]=0;
					INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
					INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
					INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
					SendBuff[SendIndex++]=FeiLvNum;
				}

				IsDataFlag=0;
				sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
				SdPrintf(YNPrint,PreFix, "\nF9 ..���ļ��� %s\n", Temp_FilePath);
				IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
				if(IsDataFlag==1)
				{
					IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x90,0x10,0,4,5,1,0,0,0,dftype);
					if (IsDataFlag == 0)
					{
						memset(&SendBuff[SendIndex],OxXX,85);
						SendIndex=SendIndex+85;
						//SendNAK(F, P, 0x0d);
						//return 3;
					}
					else
					{
						for(i=0;i<5;i++)
						{
							if((SendBuff[(SendIndex+1)+i*5]==OxXX)&&(SendBuff[(SendIndex+2)+i*5]==OxXX)&&
							   (SendBuff[(SendIndex+3)+i*5]==OxXX)&&(SendBuff[(SendIndex+4)+i*5]==OxXX))
									memset(&SendBuff[SendIndex+0+i*5],OxXX,5);
						}
						SendIndex = SendIndex + 25;
						IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x10,0,4,5,0,0,0,0,dftype);
						SendIndex = SendIndex + 20;
						IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x30,0,4,5,0,0,0,0,dftype);
						SendIndex = SendIndex + 20;
						IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x40,0,4,5,0,0,0,0,dftype);
						SendIndex = SendIndex + 20;
					}
				}
				else
				{
					memset(&SendBuff[SendIndex],OxXX,85);
					SendIndex=SendIndex+85;
					//SendNAK(F, P, 0x0d);
					//return 3;
				}
			}
		}else
		{
			memset(&SendBuff[SendIndex],OxXX,94);
			SendIndex=SendIndex+94;
		}
	}
	else	//zhengchang
	{
	//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
		ts2.Day=BCD_INT32(&Data[0]+StPos,1);
		ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
		ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
		if (AutoFlg==1) TimeDecrease(&ts2,4,1);
		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);//����ʱ��  8��14��
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		ts.Day=BCD_INT32(&Data[0]+StPos,1);
		ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
		if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong
		if((zone_so&0x7f) == JIANGSU)
		{
			SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
			SendBuff[SendIndex++]=0x23;
			INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
			SendBuff[SendIndex++]=FeiLvNum;
		}
		else{
			SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
			SendBuff[SendIndex++]=0;
			INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
			SendBuff[SendIndex++]=FeiLvNum;
		}

		//��ȡ������
		IsDataFlag=0;
		sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
		SdPrintf(YNPrint,PreFix, "\nF9 ........���ļ��� %s\n", Temp_FilePath);
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
		if(IsDataFlag==1)
		{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x90,0x10,0,4,5,1,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,85);
				SendIndex=SendIndex+85;
				//SendNAK(F, P, 0x0d);
				//return 3;
			}
			else
			{
				for(i=0;i<5;i++)
				{
					if((SendBuff[(SendIndex+1)+i*5]==OxXX)&&
					   (SendBuff[(SendIndex+2)+i*5]==OxXX)&&
					   (SendBuff[(SendIndex+3)+i*5]==OxXX)&&
					   (SendBuff[(SendIndex+4)+i*5]==OxXX))
							memset(&SendBuff[SendIndex+0+i*5],OxXX,5);
				}
				SendIndex = SendIndex + 25;
				IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x10,0,4,5,0,0,0,0,dftype);
				SendIndex = SendIndex + 20;
				IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x30,0,4,5,0,0,0,0,dftype);
				SendIndex = SendIndex + 20;
				IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x40,0,4,5,0,0,0,0,dftype);
				SendIndex = SendIndex + 20;
			}
		}
		else
		{
			memset(&SendBuff[SendIndex],OxXX,85);
			SendIndex=SendIndex+85;
			//SendNAK(F, P, 0x0d);
			//return 3;
		}
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 3;
}

INT16U Get_Level2Data_F10(INT8U Set,INT16U F,INT16U P,INT8U *Data)			//9��15�ո�
{
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType,i;
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if (AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);

	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong
	if((zone_so&0x7f) == JIANGSU)
	{
		SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
		SendBuff[SendIndex++]=0x23;
		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}
	else{

		SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
		SendBuff[SendIndex++]=0;
		INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}

	//��ȡ������
	IsDataFlag=0;

	sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x90,0x20,0,4,5,1,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,85);
			SendIndex=SendIndex+85;
			//SendNAK(F, P, 0x0d);
			//return 3;
		}
		else
		{
			for(i=0;i<5;i++)
			{
				if((SendBuff[(SendIndex+1)+i*5]==OxXX)&&
				   (SendBuff[(SendIndex+2)+i*5]==OxXX)&&
				   (SendBuff[(SendIndex+3)+i*5]==OxXX)&&
				   (SendBuff[(SendIndex+4)+i*5]==OxXX))
						memset(&SendBuff[SendIndex+0+i*5],OxXX,5);
			}
			SendIndex = SendIndex + 25;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x20,0,4,5,0,0,0,0,dftype);
			SendIndex = SendIndex + 20;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x50,0,4,5,0,0,0,0,dftype);
			SendIndex = SendIndex + 20;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x60,0,4,5,0,0,0,0,dftype);
			SendIndex = SendIndex + 20;
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,85);
		SendIndex=SendIndex+85;
		//SendNAK(F, P, 0x0d);
		//return 3;
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 3;
}


INT16U Get_Level2Data_F11(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if (AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);

	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong
	if((zone_so&0x7f) == JIANGSU)
	{
		SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
		SendBuff[SendIndex++]=0x23;
		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}
	else{

		SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
		SendBuff[SendIndex++]=0;
		INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}

	//��ȡ������
	IsDataFlag=0;

	sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa0,0x10,0,15,1,0,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,70);
			SendIndex=SendIndex+70;
			//SendNAK(F, P, 0x0d);
			//return 3;
		}
		else
		{
			SendIndex = SendIndex + 15;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb0,0x10,0,20,1,0,0,0,0,dftype);
			SendIndex = SendIndex + 20;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa1,0x10,0,15,1,0,0,0,0,dftype);
			SendIndex = SendIndex + 15;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb1,0x10,0,20,1,0,0,0,0,dftype);
			SendIndex = SendIndex + 20;
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,70);
		SendIndex=SendIndex+70;
		//SendNAK(F, P, 0x0d);
		//return 3;
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 3;
}
INT16U Get_Level2Data_F12(INT8U Set,INT16U F,INT16U P,INT8U *Data)//�����շ������޹��������������ʱ��   9��15�ո�
{
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if (AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);

	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong
	if((zone_so&0x7f) == JIANGSU)
	{
		SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
		SendBuff[SendIndex++]=0x23;
		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}
	else{

		SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
		SendBuff[SendIndex++]=0;
		INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}

	//��ȡ������
	IsDataFlag=0;

	sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa0,0x20,0,15,1,0,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,70);
			SendIndex=SendIndex+70;
			//SendNAK(F, P, 0x0d);
			//return 3;
		}
		else
		{
			SendIndex = SendIndex + 15;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb0,0x20,0,20,1,0,0,0,0,dftype);
			SendIndex = SendIndex + 20;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa1,0x20,0,15,1,0,0,0,0,dftype);
			SendIndex = SendIndex + 15;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb1,0x20,0,20,1,0,0,0,0,dftype);
			SendIndex = SendIndex + 20;
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,70);
		SendIndex=SendIndex+70;
		//SendNAK(F, P, 0x0d);
		//return 3;
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
		return 3;
}

INT16U Get_Level2Data_F17(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType,i;
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if (AutoFlg==1)
		StPos=3;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Month=BCD_INT32(&Data[0]+StPos,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
	if (AutoFlg==1) TimeDecrease(&ts2,5,1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);

	ts.Month=BCD_INT32(&Data[0]+StPos,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+1,1)+2000;
	if (AutoFlg==0) TimeAdd(&ts,5,1);
	SendBuff[SendIndex++]=0;
	SendBuff[SendIndex++]=0;
	SendBuff[SendIndex++]=0x01;
	INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
	SendBuff[SendIndex++]=FeiLvNum;
	//��ȡ������
	IsDataFlag=0;

	sprintf((char *)Temp_FilePath,"/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,3);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x90,0x10,0,4,5,1,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,85);
			SendIndex=SendIndex+85;
			//SendNAK(F, P, 0x0d);
			//return 2;
		}
		else
		{
			for(i=0;i<5;i++)
			{
				if((SendBuff[(SendIndex+1)+i*5]==OxXX)&&
				   (SendBuff[(SendIndex+2)+i*5]==OxXX)&&
				   (SendBuff[(SendIndex+3)+i*5]==OxXX)&&
				   (SendBuff[(SendIndex+4)+i*5]==OxXX))
						memset(&SendBuff[SendIndex+0+i*5],OxXX,5);
			}
			SendIndex = SendIndex + 25;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x10,0,4,5,0,0,0,0,dftype);
			SendIndex = SendIndex + 20;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x30,0,4,5,0,0,0,0,dftype);
			SendIndex = SendIndex + 20;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x40,0,4,5,0,0,0,0,dftype);
			SendIndex = SendIndex + 20;
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,85);
		SendIndex=SendIndex+85;
		//SendNAK(F, P, 0x0d);
		//return 2;
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 2;
}
INT16U Get_Level2Data_F18(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType,i;
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if (AutoFlg==1)
		StPos=3;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Month=BCD_INT32(&Data[0]+StPos,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
	if (AutoFlg==1) TimeDecrease(&ts2,5,1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Month=BCD_INT32(&Data[0]+StPos,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+1,1)+2000;
	if (AutoFlg==0) TimeAdd(&ts,5,1);
	SendBuff[SendIndex++]=0;
	SendBuff[SendIndex++]=0;
	SendBuff[SendIndex++]=0x01;
	INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
	SendBuff[SendIndex++]=FeiLvNum;
	//��ȡ������
	IsDataFlag=0;

	sprintf((char *)Temp_FilePath,"/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,3);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x90,0x20,0,4,5,1,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,85);
			SendIndex=SendIndex+85;
			//SendNAK(F, P, 0x0d);
			//return 2;
		}
		else
		{
			for(i=0;i<5;i++)
			{
				if((SendBuff[(SendIndex+1)+i*5]==OxXX)&&
				   (SendBuff[(SendIndex+2)+i*5]==OxXX)&&
				   (SendBuff[(SendIndex+3)+i*5]==OxXX)&&
				   (SendBuff[(SendIndex+4)+i*5]==OxXX))
						memset(&SendBuff[SendIndex+0+i*5],OxXX,5);
			}
			SendIndex = SendIndex + 25;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x20,0,4,5,0,0,0,0,dftype);
			SendIndex = SendIndex + 20;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x50,0,4,5,0,0,0,0,dftype);
			SendIndex = SendIndex + 20;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x60,0,4,5,0,0,0,0,dftype);
			SendIndex = SendIndex + 20;
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,85);
		SendIndex=SendIndex+85;
		//SendNAK(F, P, 0x0d);
		//return 2;
	}
//	EC();//jiezhen lqq----
//	TP();
//	FrameTailCreate_Send(0);
	return 2;
}
INT16U Get_Level2Data_F19(INT8U Set,INT16U F,INT16U P,INT8U *Data)			//�¶�����ܱ�������/�޹��������������ʱ��          9.22
{
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if (AutoFlg==1)
		StPos=3;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Month=BCD_INT32(&Data[0]+StPos,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
	if (AutoFlg==1) TimeDecrease(&ts2,5,1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Month=BCD_INT32(&Data[0]+StPos,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+1,1)+2000;
	if (AutoFlg==0) TimeAdd(&ts,5,1);
	if((zone_so&0x7f) == JIANGSU)
	{
		SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
		SendBuff[SendIndex++]=0x23;
		SendBuff[SendIndex++]=0x01;
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}
	else{

		SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
		SendBuff[SendIndex++]=0;
		SendBuff[SendIndex++]=0x01;
		INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}
	//��ȡ������
	IsDataFlag=0;

	sprintf((char *)Temp_FilePath,"/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
	//printf("Temp_FilePath=%s\n\r",Temp_FilePath);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,3);
	if(IsDataFlag==1)
	{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa0,0x1f,0,15,1,0,0,0,0,dftype);
			if(IsDataFlag==0) memset(&SendBuff[SendIndex],OxXX,15);
  			SendIndex = SendIndex + 15;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb0,0x1f,0,20,1,0,0,0,0,dftype);
			if(IsDataFlag==0) memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex = SendIndex + 20;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa1,0x1f,0,15,1,0,0,0,0,dftype);
			if(IsDataFlag==0) memset(&SendBuff[SendIndex],OxXX,15);
			SendIndex = SendIndex + 15;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb1,0x1f,0,20,1,0,0,0,0,dftype);
			if(IsDataFlag==0) memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex = SendIndex + 20;
	}
	else
	{
		memset(&SendBuff[SendIndex],0x00,70);///////////////////lcy
		SendIndex=SendIndex+70;
		//SendNAK(F, P, 0x0d);
		//return 2;
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 2;
}

INT16U Get_Level2Data_F20(INT8U Set,INT16U F,INT16U P,INT8U *Data)						//�¶�����ܱ�������/�޹��������������ʱ��    9.22
{
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if (AutoFlg==1)
		StPos=3;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Month=BCD_INT32(&Data[0]+StPos,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
	if (AutoFlg==1) TimeDecrease(&ts2,5,1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Month=BCD_INT32(&Data[0]+StPos,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+1,1)+2000;
	if (AutoFlg==0) TimeAdd(&ts,5,1);
	if((zone_so&0x7f) == JIANGSU)
	{
		SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
		SendBuff[SendIndex++]=0x23;
		SendBuff[SendIndex++]=0x01;
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}
	else{

		SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
		SendBuff[SendIndex++]=0;
		SendBuff[SendIndex++]=0x01;
		INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}
	//��ȡ������
	IsDataFlag=0;

	sprintf((char *)Temp_FilePath,"/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
	//printf("Temp_FilePath=%s\n\r",Temp_FilePath);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,3);
	if(IsDataFlag==1)
	{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa0,0x2f,0,15,1,0,0,0,0,dftype);
			if(IsDataFlag==0) memset(&SendBuff[SendIndex],OxXX,15);
  			SendIndex = SendIndex + 15;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb0,0x2f,0,20,1,0,0,0,0,dftype);
			if(IsDataFlag==0) memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex = SendIndex + 20;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa1,0x2f,0,15,1,0,0,0,0,dftype);
			if(IsDataFlag==0) memset(&SendBuff[SendIndex],OxXX,15);
			SendIndex = SendIndex + 15;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb1,0x2f,0,20,1,0,0,0,0,dftype);
			if(IsDataFlag==0) memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex = SendIndex + 20;
	}
	else
	{
		memset(&SendBuff[SendIndex],0x00,70);/////////////////////////////lcy
		SendIndex=SendIndex+70;
		//SendNAK(F, P, 0x0d);
		//return 2;
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 2;
}

int Calculate_mon_Elc(INT16U F,INT16U P,INT8U *Data,INT8U DI1,INT8U DI0,INT8U BeX)
{
	INT16U i,IsDataFlag,j,dftype,dflg;
	INT8U Temp_FilePath[60],tempManyData[50],tempData[50],CJQno,MeterNo,MeterType;
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts2=ts;
	INT32S tmp[5],tmp2=0,tmp3=0;
	for(i=0;i<5;i++)
		tmp[i]=0;
	StPos=0;
	if (AutoFlg==1)
		StPos=3;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Month=BCD_INT32(&Data[0]+StPos,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
	SdPrintf(YNPrint,PreFix,"=============F21   AutoFlg=%d",AutoFlg);
	if (AutoFlg==1) TimeDecrease(&ts2,5,1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	SendBuff[SendIndex++]=FeiLvNum;
	ts.Year = BCD_INT32(&Data[1]+StPos,1)+2000;
	ts.Month=BCD_INT32(&Data[0]+StPos,1);

	if (AutoFlg==0) TimeAdd(&ts,5,1);
	//��������
	IsDataFlag=0;
	LDType=2;
	dflg=0;

	memset(Temp_FilePath,0x00,60);

	sprintf((char *)Temp_FilePath,"/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
	SdPrintf(YNPrint,PreFix,"P==%d ts.Month=%d  %s", P, ts.Month,Temp_FilePath);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,3);
	SdPrintf(YNPrint,PreFix,"IsDataFlag == %d\n",IsDataFlag);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&tempManyData[0],CJQno,MeterNo,DI1,DI0,0,4,5,0,0,0,0,dftype);
		SdPrintf(YNPrint,PreFix,"============IsDataFlag == %d---------------\n",IsDataFlag);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
		}
		else
		{
			dflg=1;
			memcpy(&tmp2,&JSetPara_AFN04_3761_2009->Point[P-1].f25.V_BeiLv[0],2);
			memcpy(&tmp3,&JSetPara_AFN04_3761_2009->Point[P-1].f25.I_BeiLv[0],2);
			tmp2=1;
			tmp3=1;
			for(j=0;j<5;j++)
			{
				tmp[j]=BCD_INT32(&tempManyData[0+j*4], 4)*100;
			}
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,20);
		SendIndex=SendIndex+20;
		//SendNAK(F, P, 0x0d);
		//return 2;
	}
	if (dflg==1)
	{
		IsDataFlag=0;
		memset(Temp_FilePath,0x00,60);
		//if (AutoFlg==1)
		//	TimeDecrease(&ts,5,1);
		sprintf((char *)Temp_FilePath,"/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
		SdPrintf(YNPrint,PreFix,"------%s",Temp_FilePath);
		if ((MeterType == 9) || (MeterType == 6))
		{
			dftype=1;//comm
		}
		else
		{
			dftype=1;
		}
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,3);
		if(IsDataFlag==1)
		{
			IsDataFlag=getMetersData(MeterType,&tempManyData[0],CJQno,MeterNo,DI1,DI0,0,4,5,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,20);
				SendIndex=SendIndex+20;
				//SendNAK(F, P, 0x0d);
				//return 2;
			}
			else
			{
				INT32S ttt=0;
				memcpy(&tmp2,&JSetPara_AFN04_3761_2009->Point[P-1].f25.V_BeiLv[0],2);
				memcpy(&tmp3,&JSetPara_AFN04_3761_2009->Point[P-1].f25.I_BeiLv[0],2);
				for(j=0;j<5;j++)
				{
					for(i=0;i<BeX;i++)
						SendBuff[SendIndex++]=0x00;
					ttt = BCD_INT32(&tempManyData[0+j*4], 4)*100;
					SdPrintf(YNPrint,PreFix,"============tmp[%d]=%d - tmp2[%d]=%d",j,tmp[j],j,ttt);
					tmp[j]=tmp[j]-ttt;//(BCD_INT32(&tempManyData[0]+j*4, 4)*100);
					INT32U_BCD(tmp[j], &tempData[0], 4);
					memcpy(&SendBuff[SendIndex],&tempData[0],4);
					SendIndex=SendIndex+4;
				}
			}
		}
		else
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 2;
		}
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 2;
}

INT16U Get_Level2Data_F21(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{//�����й�������  �¶���   9010
	return Calculate_mon_Elc(F,P,Data,0x90,0x10,0);
}
INT16U Get_Level2Data_F22(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{//�����޹������� �¶��� 9110
	return Calculate_mon_Elc(F,P,Data,0x91,0x10,0);
}
INT16U Get_Level2Data_F23(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{//�����й������� Լ���� 9020
	return Calculate_mon_Elc(F,P,Data,0x90,0x20,0);
}
INT16U Get_Level2Data_F24(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{//�����޹������� �¶���
	return Calculate_mon_Elc(F,P,Data,0x91,0x20,0);
}
INT16U Get_Level2Data_F25(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{//
	//INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
	TS ts,ts2;
	INT8U temp[60];
	ExdTongJi exdtj;
	memset(temp,0,60);
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if (AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
	//if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong//fzh

	memset(Temp_FilePath,0x00,60);
	sprintf((char *)Temp_FilePath,"/nand/DataRiTongJi/%04d/d%02d.dat",P,ts.Day);//,ts.Month);
	SdPrintf(YNPrint,PreFix,"Get_Level2Data_F25 Temp_FilePath=%s\n\r",Temp_FilePath);

	INT8U TempBuf[60];
	memset(TempBuf,0,60);
	sprintf((char*)TempBuf,"/nand/DataCurr/%04d/curr.dat",P);
	if (ReadFile((char *)TempBuf, &smfile,sizeof(SMFiles),Jproginfo) == 1)
		memset(&smfile,0,sizeof(SMFiles));

	if (access((char*)Temp_FilePath, 0) == 0)
	{
		ReadFile((char *)Temp_FilePath,&exdtj,sizeof(ExdTongJi),Jproginfo);

		if(FindFlginFile(&smfile,0xB6, 0x30,Jproginfo) &&
			((FindFlginFile(&smfile,0xB6, 0x11,Jproginfo) && FindFlginFile(&smfile,0xB6, 0x21,Jproginfo)) ||
			(FindFlginFile(&smfile,0xB6, 0x12,Jproginfo) && FindFlginFile(&smfile,0xB6, 0x22,Jproginfo)) ||
			(FindFlginFile(&smfile,0xB6, 0x13,Jproginfo) && FindFlginFile(&smfile,0xB6, 0x23,Jproginfo))))
		{
			INT32U_BCD(exdtj.P_MAX,&SendBuff[SendIndex],3);
			SendIndex=SendIndex+3;
			memcpy(&SendBuff[SendIndex],&exdtj.P_MAX_TIME,3);
			SendIndex=SendIndex+3;
		}else{
			if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port!=1)
				memset(&SendBuff[SendIndex],OxXX,6);
			else
				memset(&SendBuff[SendIndex],0,6);
			SendIndex=SendIndex+6;
		}

		if(FindFlginFile(&smfile,0xb6, 0x31,Jproginfo)&&
			(FindFlginFile(&smfile,0xB6, 0x11,Jproginfo) && FindFlginFile(&smfile,0xB6, 0x21,Jproginfo)))
		{
			INT32U_BCD(exdtj.PA_MAX,&SendBuff[SendIndex],3);
			SendIndex=SendIndex+3;
			memcpy(&SendBuff[SendIndex],&exdtj.PA_MAX_TIME,3);
			SendIndex=SendIndex+3;
		}else{
			if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port!=1)
				memset(&SendBuff[SendIndex],OxXX,6);
			else
				memset(&SendBuff[SendIndex],0,6);
			SendIndex=SendIndex+6;
		}

		if(FindFlginFile(&smfile,0xb6, 0x32,Jproginfo)&&
			(FindFlginFile(&smfile,0xB6, 0x12,Jproginfo) && FindFlginFile(&smfile,0xB6, 0x22,Jproginfo)))
		{
			INT32U_BCD(exdtj.PB_MAX,&SendBuff[SendIndex],3);
			SendIndex=SendIndex+3;
			memcpy(&SendBuff[SendIndex],&exdtj.PB_MAX_TIME,3);
			SendIndex=SendIndex+3;
		}else{
			if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port!=1)
				memset(&SendBuff[SendIndex],OxXX,6);
			else
				memset(&SendBuff[SendIndex],0,6);
			SendIndex=SendIndex+6;
		}

		if(FindFlginFile(&smfile,0xb6, 0x33,Jproginfo)&&
			(FindFlginFile(&smfile,0xB6, 0x13,Jproginfo) && FindFlginFile(&smfile,0xB6, 0x23,Jproginfo)))
		{
			INT32U_BCD(exdtj.PC_MAX,&SendBuff[SendIndex],3);
			SendIndex=SendIndex+3;
			memcpy(&SendBuff[SendIndex],&exdtj.PC_MAX_TIME,3);
			SendIndex=SendIndex+3;
		}else{
			if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port!=1)
				memset(&SendBuff[SendIndex],OxXX,6);
			else
				memset(&SendBuff[SendIndex],0,6);
			SendIndex=SendIndex+6;
		}

		if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port!=1)
		{
			if(FindFlginFile(&smfile,0xB6, 0x30,Jproginfo) &&
				((FindFlginFile(&smfile,0xB6, 0x11,Jproginfo) && FindFlginFile(&smfile,0xB6, 0x21,Jproginfo)) ||
				(FindFlginFile(&smfile,0xB6, 0x12,Jproginfo) && FindFlginFile(&smfile,0xB6, 0x22,Jproginfo)) ||
				(FindFlginFile(&smfile,0xB6, 0x13,Jproginfo) && FindFlginFile(&smfile,0xB6, 0x23,Jproginfo))))
			{
				if((!FindFlginFile(&smfile,0xB6, 0x13,Jproginfo) && !FindFlginFile(&smfile,0xB6, 0x23,Jproginfo)))
				{
					memset(&SendBuff[SendIndex],0xee,2);
					SendIndex=SendIndex+2;
				}else{
					SendBuff[SendIndex++] = exdtj.P_Zero_Time&0xff;
					SendBuff[SendIndex++]=(exdtj.P_Zero_Time>>8)&0xff;
				}
			}else{
				memset(&SendBuff[SendIndex],0xee,2);
				SendIndex=SendIndex+2;
			}
		}else{
			memset(&SendBuff[SendIndex], 0, 2);
			SendIndex=SendIndex+2;
		}
		if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port!=1)
		{
			if(FindFlginFile(&smfile,0xB6, 0x31,Jproginfo)&&
				FindFlginFile(&smfile,0xB6, 0x11,Jproginfo) &&
				FindFlginFile(&smfile,0xB6, 0x21,Jproginfo))
			{
				if((!FindFlginFile(&smfile,0xB6, 0x13,Jproginfo) && !FindFlginFile(&smfile,0xB6, 0x23,Jproginfo)))
				{
					memset(&SendBuff[SendIndex],0xee,2);
					SendIndex=SendIndex+2;
				}else{
					SendBuff[SendIndex++] = exdtj.PA_Zero_Time&0xff;
					SendBuff[SendIndex++]=(exdtj.PA_Zero_Time>>8)&0xff;
				}
			}else{
				memset(&SendBuff[SendIndex],0xee,2);
				SendIndex=SendIndex+2;
			}
		}else{
			memset(&SendBuff[SendIndex], 0, 2);
			SendIndex=SendIndex+2;
		}

		if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port!=1)
		{
			if(FindFlginFile(&smfile,0xB6, 0x32,Jproginfo)&&
				FindFlginFile(&smfile,0xB6, 0x12,Jproginfo) &&
				FindFlginFile(&smfile,0xB6, 0x22,Jproginfo))
			{
				SendBuff[SendIndex++] = exdtj.PB_Zero_Time&0xff;
				SendBuff[SendIndex++]=(exdtj.PB_Zero_Time>>8)&0xff;
			}else{
				memset(&SendBuff[SendIndex],0xee,2);
				SendIndex=SendIndex+2;
			}
		}else{
			memset(&SendBuff[SendIndex], 0, 2);
			SendIndex=SendIndex+2;
		}

		if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port!=1)
		{
			if(FindFlginFile(&smfile,0xB6, 0x33,Jproginfo)&&
				FindFlginFile(&smfile,0xB6, 0x13,Jproginfo) &&
				FindFlginFile(&smfile,0xB6, 0x23,Jproginfo))
			{
				SendBuff[SendIndex++] = exdtj.PC_Zero_Time&0xff;
				SendBuff[SendIndex++]=(exdtj.PC_Zero_Time>>8)&0xff;
			}else{
				memset(&SendBuff[SendIndex],0xee,2);
				SendIndex=SendIndex+2;
			}
		}else{
			memset(&SendBuff[SendIndex], 0, 2);
			SendIndex=SendIndex+2;
		}
	}
	else
	{
		if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port!=1)
			memset(&SendBuff[SendIndex],OxXX,32);
		else
			memset(&SendBuff[SendIndex],0,32);
		SendIndex=SendIndex+32;
	}
	return 3;
}
//��������󼰷���ʱ��
INT16U Get_Level2Data_F26(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	//INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
	TS ts,ts2;
	INT8U temp[60];
	ExdTongJi exdtj;
	memset(temp,0,60);
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if (AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
	//if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong//fzh

	memset(Temp_FilePath,0x00,60);
	sprintf((char *)Temp_FilePath,"/nand/DataRiTongJi/%04d/d%02d.dat",P,ts.Day);//,ts.Month);
	SdPrintf(YNPrint,PreFix,"Get_Level2Data_F26 Temp_FilePath=%s\n\r",Temp_FilePath);
	if (access((char*)Temp_FilePath, 0) == 0)
	{
		ReadFile((char *)Temp_FilePath,&exdtj,sizeof(ExdTongJi),Jproginfo);

		INT32U_BCD(exdtj.P_All_XL,&SendBuff[SendIndex],3);
		SendIndex=SendIndex+3;
		memcpy(&SendBuff[SendIndex],&exdtj.P_All_XL_Time,3);
		SendIndex=SendIndex+3;
		INT32U_BCD(exdtj.P_U_XL,&SendBuff[SendIndex],3);
		SendIndex=SendIndex+3;
		memcpy(&SendBuff[SendIndex],&exdtj.P_U_XL_Time,3);
		SendIndex=SendIndex+3;
		INT32U_BCD(exdtj.P_V_XL,&SendBuff[SendIndex],3);
		SendIndex=SendIndex+3;
		memcpy(&SendBuff[SendIndex],&exdtj.P_V_XL_Time,3);
		SendIndex=SendIndex+3;
		INT32U_BCD(exdtj.P_W_XL,&SendBuff[SendIndex],3);
		SendIndex=SendIndex+3;
		memcpy(&SendBuff[SendIndex],&exdtj.P_W_XL_Time,3);
		SendIndex=SendIndex+3;
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,24);
		SendIndex=SendIndex+24;
	}
	return 3;
}
INT16U Get_Level2Data_F27(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
		TS ts,ts2;
		INT8U Temp_FilePath[60];
		ExdTongJi exdtj;
		ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
		ts.Week = 0;
		ts2=ts;
		StPos=0;
		if (AutoFlg==1)
			StPos=2;

		ts2.Day=BCD_INT32(&Data[0]+StPos,1);
		ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
		ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
		if (AutoFlg==1) TimeDecrease(&ts2,4,1);
		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		ts.Day=BCD_INT32(&Data[0]+StPos,1);
		//��ȡ������
		//if (AutoFlg==0) TimeAdd(&ts,4,1);//fzh

		memset(&exdtj, 0, sizeof(exdtj));
		memset(Temp_FilePath,0x00,60);
		sprintf((char*)Temp_FilePath,"/nand/DataRiTongJi/%04d/d%02d.dat",P,ts.Day);
		SdPrintf(YNPrint,PreFix,"Get_Level2Data_F27 Temp_FilePath=%s\n\r",Temp_FilePath);

		INT8U TempBuf[60];
		memset(TempBuf,0,60);
		sprintf((char*)TempBuf,"/nand/DataCurr/%04d/curr.dat",P);
		if (ReadFile((char *)TempBuf, &smfile,sizeof(SMFiles),Jproginfo) == 1)
			memset(&smfile,0,sizeof(SMFiles));

		if (access((char*)Temp_FilePath, 0) == 0)
		{
			if (ReadFile((char*)Temp_FilePath,(char *) &exdtj, sizeof(exdtj),Jproginfo)==1)
			{
				memset(&SendBuff[SendIndex],OxXX,66);
				SendIndex=SendIndex+66;
			}
			else
			{
				SdPrintf(YNPrint,PreFix, "\nF27:Get_Level2Data_F27 USSU=%d,UXXU=%d,USU=%d,UXU=%d\n",exdtj.USSU_Count,exdtj.UXXU_Count,exdtj.USU_Count,exdtj.UXU_Count);
				if(FindFlginFile(&smfile,0xB6, 0x11,Jproginfo)){
					SendBuff[SendIndex++]=exdtj.USSU_Count&0xff;			//��ԼҪ������BIN
					SendBuff[SendIndex++]=(exdtj.USSU_Count>>8)&0xff;
					SendBuff[SendIndex++]=exdtj.UXXU_Count&0xff;
					SendBuff[SendIndex++]=(exdtj.UXXU_Count>>8)&0xff;
					SendBuff[SendIndex++]=exdtj.USU_Count&0xff;
					SendBuff[SendIndex++]=(exdtj.USU_Count>>8)&0xff;
					SendBuff[SendIndex++]=exdtj.UXU_Count&0xff;
					SendBuff[SendIndex++]=(exdtj.UXU_Count>>8)&0xff;
					SendBuff[SendIndex++]=exdtj.UHGU_Count&0xff;
					SendBuff[SendIndex++]=(exdtj.UHGU_Count>>8)&0xff;
				}else{
					memset(&SendBuff[SendIndex],OxXX,10);
					SendIndex=SendIndex+10;
				}
				if(FindFlginFile(&smfile,0xB6, 0x12,Jproginfo)){
					SendBuff[SendIndex++]=exdtj.USSV_Count&0xff;
					SendBuff[SendIndex++]=(exdtj.USSV_Count>>8)&0xff;
					SendBuff[SendIndex++]=exdtj.UXXV_Count&0xff;
					SendBuff[SendIndex++]=(exdtj.UXXV_Count>>8)&0xff;
					SendBuff[SendIndex++]=exdtj.USV_Count&0xff;
					SendBuff[SendIndex++]=(exdtj.USV_Count>>8)&0xff;
					SendBuff[SendIndex++]=exdtj.UXV_Count&0xff;
					SendBuff[SendIndex++]=(exdtj.UXV_Count>>8)&0xff;
					SendBuff[SendIndex++]=exdtj.UHGV_Count&0xff;
					SendBuff[SendIndex++]=(exdtj.UHGV_Count>>8)&0xff;
				}else{
					memset(&SendBuff[SendIndex],OxXX,10);
					SendIndex=SendIndex+10;
				}
				if(FindFlginFile(&smfile,0xB6, 0x13,Jproginfo)){
					SendBuff[SendIndex++]=exdtj.USSW_Count&0xff;
					SendBuff[SendIndex++]=(exdtj.USSW_Count>>8)&0xff;
					SendBuff[SendIndex++]=exdtj.UXXW_Count&0xff;
					SendBuff[SendIndex++]=(exdtj.UXXW_Count>>8)&0xff;
					SendBuff[SendIndex++]=exdtj.USW_Count&0xff;
					SendBuff[SendIndex++]=(exdtj.USW_Count>>8)&0xff;
					SendBuff[SendIndex++]=exdtj.UXW_Count&0xff;
					SendBuff[SendIndex++]=(exdtj.UXW_Count>>8)&0xff;
					SendBuff[SendIndex++]=exdtj.UHGW_Count&0xff;
					SendBuff[SendIndex++]=(exdtj.UHGW_Count>>8)&0xff;
				}else{
					memset(&SendBuff[SendIndex],OxXX,10);
					SendIndex=SendIndex+10;
				}
//				memcpy(&SendBuff[SendIndex],&exdtj.USSU_Count,30);
//				SendIndex=SendIndex+30;
				if(FindFlginFile(&smfile,0xB6, 0x11,Jproginfo)){
					INT32U_BCD(exdtj.DUUMAX,&SendBuff[SendIndex],2);
					SendIndex=SendIndex+2;
					memcpy(&SendBuff[SendIndex],&exdtj.DUUMAX_TIME[0],3);
					SendIndex=SendIndex+3;
					INT32U_BCD(exdtj.DUUMIN,&SendBuff[SendIndex],2);
					SendIndex=SendIndex+2;
					memcpy(&SendBuff[SendIndex],&exdtj.DUUMIN_TIME[0],3);
					SendIndex=SendIndex+3;
				}else{
					memset(&SendBuff[SendIndex],OxXX,10);
					SendIndex=SendIndex+10;
				}

				if(FindFlginFile(&smfile,0xB6, 0x12,Jproginfo)){
					INT32U_BCD(exdtj.DUVMAX,&SendBuff[SendIndex],2);
					SendIndex=SendIndex+2;
					memcpy(&SendBuff[SendIndex],&exdtj.DUVMAX_TIME[0],3);
					SendIndex=SendIndex+3;
					INT32U_BCD(exdtj.DUVMIN,&SendBuff[SendIndex],2);
					SendIndex=SendIndex+2;
					memcpy(&SendBuff[SendIndex],&exdtj.DUVMIN_TIME[0],3);
					SendIndex=SendIndex+3;
				}else{
					memset(&SendBuff[SendIndex],OxXX,10);
					SendIndex=SendIndex+10;
				}
				if(FindFlginFile(&smfile,0xB6, 0x13,Jproginfo)){
					INT32U_BCD(exdtj.DUWMAX,&SendBuff[SendIndex],2);
					SendIndex=SendIndex+2;
					memcpy(&SendBuff[SendIndex],&exdtj.DUWMAX_TIME[0],3);
					SendIndex=SendIndex+3;
					INT32U_BCD(exdtj.DUWMIN,&SendBuff[SendIndex],2);
					SendIndex=SendIndex+2;
					memcpy(&SendBuff[SendIndex],&exdtj.DUWMIN_TIME[0],3);
					SendIndex=SendIndex+3;
				}else{
					memset(&SendBuff[SendIndex],OxXX,10);
					SendIndex=SendIndex+10;
				}
				if(FindFlginFile(&smfile,0xB6, 0x11,Jproginfo)){
					INT32U_BCD(exdtj.DUUAVE,&SendBuff[SendIndex],2);
					SendIndex=SendIndex+2;
				}else{
					memset(&SendBuff[SendIndex],OxXX,2);
					SendIndex=SendIndex+2;
				}
				if(FindFlginFile(&smfile,0xB6, 0x12,Jproginfo)){
					INT32U_BCD(exdtj.DUVAVE,&SendBuff[SendIndex],2);
					SendIndex=SendIndex+2;
				}else{
					memset(&SendBuff[SendIndex],OxXX,2);
					SendIndex=SendIndex+2;
				}
				if(FindFlginFile(&smfile,0xB6, 0x13,Jproginfo)){
					INT32U_BCD(exdtj.DUWAVE,&SendBuff[SendIndex],2);
					SendIndex=SendIndex+2;
				}else{
					memset(&SendBuff[SendIndex],OxXX,2);
					SendIndex=SendIndex+2;
				}
			}
		}
		else
		{
			memset(&SendBuff[SendIndex],OxXX,66);
			SendIndex=SendIndex+66;
		}
	return 3;
}

INT16U Get_Level2Data_F28(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	//INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
	TS ts,ts2;
	INT8U temp[60];
	ExdTongJi exdtj;
	memset(temp,0,60);
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if (AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
	//if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong//fzh

	memset(Temp_FilePath,0x00,60);
	sprintf((char *)Temp_FilePath,"/nand/DataRiTongJi/%04d/d%02d.dat",P,ts.Day);//,ts.Month);
	SdPrintf(YNPrint,PreFix,"Get_Level2Data_F28 Temp_FilePath=%s\n\r",Temp_FilePath);

	INT8U TempBuf[60];
	memset(TempBuf,0,60);
	sprintf((char*)TempBuf,"/nand/DataCurr/%04d/curr.dat",P);
	if (ReadFile((char *)TempBuf, &smfile,sizeof(SMFiles),Jproginfo) == 1)
		memset(&smfile,0,sizeof(SMFiles));
	if (access((char*)Temp_FilePath, 0) == 0)
	{
		ReadFile((char *)Temp_FilePath,&exdtj,sizeof(ExdTongJi),Jproginfo);

		if(FindFlginFile(&smfile,0xB6, 0x21,Jproginfo)){
			INT32U_BCD(exdtj.I_UNBALANCE_Count,&SendBuff[SendIndex],2);
			SendIndex=SendIndex+2;
		}else{
			memset(&SendBuff[SendIndex],OxXX,2);
			SendIndex=SendIndex+2;
		}
		if(FindFlginFile(&smfile,0xB6, 0x11,Jproginfo)){
			INT32U_BCD(exdtj.V_UNBALANCE_Count,&SendBuff[SendIndex],2);
			SendIndex=SendIndex+2;
		}else{
			memset(&SendBuff[SendIndex],OxXX,2);
			SendIndex=SendIndex+2;
		}
		if(FindFlginFile(&smfile,0xB6, 0x21,Jproginfo)){
			INT32U_BCD(exdtj.I_UNBALANCE_Max,&SendBuff[SendIndex],2);
			SendIndex=SendIndex+2;
			memcpy(&SendBuff[SendIndex],&exdtj.I_UNBALANCE_MaxTime,3);
			SendIndex=SendIndex+3;
		}else{
			memset(&SendBuff[SendIndex],OxXX,5);
			SendIndex=SendIndex+5;
		}
		if(FindFlginFile(&smfile,0xB6, 0x11,Jproginfo)){
			INT32U_BCD(exdtj.V_UNBALANCE_Max,&SendBuff[SendIndex],2);
			SendIndex=SendIndex+2;
			memcpy(&SendBuff[SendIndex],&exdtj.V_UNBALANCE_MaxTime,3);
			SendIndex=SendIndex+3;
		}else{
			memset(&SendBuff[SendIndex],OxXX,5);
			SendIndex=SendIndex+5;
		}
	}else
	{
		memset(&SendBuff[SendIndex],OxXX,14);
		SendIndex=SendIndex+14;
	}
	return 3;
}
INT16U Get_Level2Data_F29(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
	TS ts,ts2;
	INT8U temp[60];
	ExdTongJi exdtj;
	memset(temp,0,60);
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if (AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
	//if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong//fzh

	memset(Temp_FilePath,0x00,60);
	sprintf((char *)Temp_FilePath,"/nand/DataRiTongJi/%04d/d%02d.dat",P,ts.Day);
	SdPrintf(YNPrint,PreFix,"Get_Level2Data_F29 Temp_FilePath=%s\n\r",Temp_FilePath);

	INT8U TempBuf[60];
	memset(TempBuf,0,60);
	sprintf((char*)TempBuf,"/nand/DataCurr/%04d/curr.dat",P);
	if (ReadFile((char *)TempBuf, &smfile,sizeof(SMFiles),Jproginfo) == 1)
		memset(&smfile,0,sizeof(SMFiles));

	if (access((char*)Temp_FilePath, 0) == 0)
	{
		ReadFile((char *)Temp_FilePath,&exdtj,sizeof(ExdTongJi),Jproginfo);
		if(FindFlginFile(&smfile,0xB6, 0x21,Jproginfo)){
			INT32U_BCD(exdtj.ISSU_Count,&SendBuff[SendIndex],2);//IA������
			SendIndex=SendIndex+2;
			INT32U_BCD(exdtj.ISU_Count,&SendBuff[SendIndex],2);//IA����
			SendIndex=SendIndex+2;
		}else{
			memset(&SendBuff[SendIndex],OxXX,4);
			SendIndex=SendIndex+4;
		}

		if(FindFlginFile(&smfile,0xB6, 0x22,Jproginfo)){
		INT32U_BCD(exdtj.ISSV_Count,&SendBuff[SendIndex],2);//IB������
		SendIndex=SendIndex+2;
		INT32U_BCD(exdtj.ISV_Count,&SendBuff[SendIndex],2);//IB����
		SendIndex=SendIndex+2;
		}else{
			memset(&SendBuff[SendIndex],OxXX,4);
			SendIndex=SendIndex+4;
		}
		if(FindFlginFile(&smfile,0xB6, 0x23,Jproginfo)){
			INT32U_BCD(exdtj.ISSW_Count,&SendBuff[SendIndex],2);//IC������
			SendIndex=SendIndex+2;
			INT32U_BCD(exdtj.ISW_Count,&SendBuff[SendIndex],2);//IC����
			SendIndex=SendIndex+2;
			INT32U_BCD(exdtj.ISL_Count,&SendBuff[SendIndex],2);//I0����
			SendIndex=SendIndex+2;
		}else{
			memset(&SendBuff[SendIndex],OxXX,6);
			SendIndex=SendIndex+6;
		}

		if(FindFlginFile(&smfile,0xB6, 0x21,Jproginfo)){
			INT32U_BCD(exdtj.DI_U_MAX,&SendBuff[SendIndex],3);//IA���ֵ
			SendIndex=SendIndex+3;
			memcpy(&SendBuff[SendIndex],&exdtj.DIUMAX_TIME[0],3);//����ʱ��
			SendIndex=SendIndex+3;
		}else{
			memset(&SendBuff[SendIndex],OxXX,6);
			SendIndex=SendIndex+6;
		}
		if(FindFlginFile(&smfile,0xB6, 0x22,Jproginfo)){
			INT32U_BCD(exdtj.DI_V_MAX,&SendBuff[SendIndex],3);//IB���ֵ
			SendIndex=SendIndex+3;
			memcpy(&SendBuff[SendIndex],&exdtj.DIVMAX_TIME[0],3);//����ʱ��
			SendIndex=SendIndex+3;
		}else{
			memset(&SendBuff[SendIndex],OxXX,6);
			SendIndex=SendIndex+6;
		}
		if(FindFlginFile(&smfile,0xB6, 0x23,Jproginfo)){
			INT32U_BCD(exdtj.DI_W_MAX,&SendBuff[SendIndex],3);//IC���ֵ
			SendIndex=SendIndex+3;
			memcpy(&SendBuff[SendIndex],&exdtj.DIWMAX_TIME[0],3);//����ʱ��
			SendIndex=SendIndex+3;
		}else{
			memset(&SendBuff[SendIndex],OxXX,6);
			SendIndex=SendIndex+6;
		}
		if(FindFlginFile(&smfile,0xB6, 0x23,Jproginfo)){
			INT32U_BCD(exdtj.DI_L_MAX,&SendBuff[SendIndex],3);//I0���ֵ
			SendIndex=SendIndex+3;
			memcpy(&SendBuff[SendIndex],&exdtj.DILMAX_TIME[0],3);//����ʱ��
			SendIndex=SendIndex+3;
		}else{
			memset(&SendBuff[SendIndex],OxXX,6);
			SendIndex=SendIndex+6;
		}
	}else
	{
		memset(&SendBuff[SendIndex],OxXX,38);
		SendIndex=SendIndex+38;
	}
	return 3;
}


INT16U Get_Level2Data_F30(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	//INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
	TS ts,ts2;
	INT8U temp[60];
	ExdTongJi exdtj;
	memset(temp,0,60);
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if (AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
	//if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong//fzh

	memset(Temp_FilePath,0x00,60);
	sprintf((char *)Temp_FilePath,"/nand/DataRiTongJi/%04d/d%02d.dat",P,ts.Day);//,ts.Month);
	SdPrintf(YNPrint,PreFix,"Get_Level2Data_F30 Temp_FilePath=%s\n\r",Temp_FilePath);
	if (access((char*)Temp_FilePath, 0) == 0)
	{
		ReadFile((char *)Temp_FilePath,&exdtj,sizeof(ExdTongJi),Jproginfo);

		INT32U_BCD(exdtj.S_SS_Count,&SendBuff[SendIndex],2);
		SendIndex=SendIndex+2;
		INT32U_BCD(exdtj.S_S_Count,&SendBuff[SendIndex],2);
		SendIndex=SendIndex+2;
	}else
	{
		memset(&SendBuff[SendIndex],OxXX,4);
		SendIndex=SendIndex+4;
	}
	return 3;
}
INT16U Get_Level2Data_F31(INT8U Set,INT16U F,INT16U P,INT8U *Data)// �ո�����ͳ��
{
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	ExdTongJi exdtj;
	INT8U Temp_FilePath[60];
	StPos=0;
	if (AutoFlg==1)
		StPos=2;

	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Year = BCD_INT32(&Data[2]+StPos,1)+2000;
	ts.Month=BCD_INT32(&Data[1]+StPos,1);
	ts.Day=BCD_INT32(&Data[0]+StPos,1);

	memset(&exdtj, 0, sizeof(exdtj));
	memset(Temp_FilePath,0,60);
	sprintf((char*)Temp_FilePath,"/nand/DataRiTongJi/%04d/d%02d.dat",P,ts.Day);
	SdPrintf(YNPrint,PreFix,"Get_Level2Data_F31 Temp_FilePath=%s\n\r",Temp_FilePath);
	if(access((char *)Temp_FilePath,0)==0)
	{
		ReadFile((char *)Temp_FilePath,&exdtj,sizeof(ExdTongJi),Jproginfo);

		INT32U_BCD(exdtj.FuZaiLV_Max ,&SendBuff[SendIndex], 2);
		SendIndex = SendIndex + 2;
		memcpy(&SendBuff[SendIndex],exdtj.FuZaiLV_MaxTime,3);
		SendIndex = SendIndex + 3;
		INT32U_BCD(exdtj.FuZaiLV_Min ,&SendBuff[SendIndex], 2);
		SendIndex = SendIndex + 2;
		memcpy(&SendBuff[SendIndex],exdtj.FuZaiLV_MinTime,3);
		SendIndex = SendIndex + 3;
	}
	else
	{
		memset(&SendBuff[SendIndex],0,10);
		SendIndex=SendIndex+10;
	}

	return 3;
}
void setjiaocai32(TS ts)
{
	INT8U timebcd[4];
	INT32U_BCD(ts.Minute,&timebcd[0],1);
	INT32U_BCD(ts.Hour,&timebcd[1],1);
	INT32U_BCD(ts.Day,&timebcd[2],1);
	INT32U_BCD(ts.Month,&timebcd[3],1);

	memset(&SendBuff[SendIndex],0,8 );
	SendIndex = SendIndex + 8;
	memset(&SendBuff[SendIndex],0,12 );
	SendIndex = SendIndex + 12;
	memcpy(&SendBuff[SendIndex],timebcd,4 );
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex],timebcd,4 );
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex],timebcd,4 );
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex],timebcd,4 );
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex],timebcd,4 );
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex],timebcd,4 );
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex],timebcd,4 );
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex],timebcd,4 );
	SendIndex = SendIndex + 4;

}
INT16U Get_Level2Data_F32(INT8U Set,INT16U F,INT16U P,INT8U *Data)////////////////////lcy
{
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
	TS ts,ts2;
	INT8U temp[60];
	INT8U dsj;
	INT32U tmp;
	int ifjiaocai=0;
	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	SdPrintf(YNPrint,PreFix, "F32: portn=%d\n",portn);
	if (portn == LocalCommPort)
		portn=CarrWavePort;
	if (portn==1)
		ifjiaocai = 1;

	memset(temp,0,60);
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if (AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong
	if((zone_so&0x7f) == JIANGSU)
	{
		SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
		SendBuff[SendIndex++]=0x23;
		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	}
	else{

		SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
		SendBuff[SendIndex++]=0;
		INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
	}

	//��ȡ������
	IsDataFlag=0;

	sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
	SdPrintf(YNPrint,PreFix,"Temp_FilePath=%s\n\r",Temp_FilePath);
	dftype=1;//comm
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
	SdPrintf(YNPrint,PreFix,"F32  ========IsDataFlag= %d",IsDataFlag);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb3,0x10,0,2,4,0,0,0,0,dftype);
		if (IsDataFlag == 0)// b3 10 �ܶ������      b311 A��������		 b312 B��������  	b313 C��������
		{
			if (ifjiaocai==0)
			{
				memset(&SendBuff[SendIndex],OxXX,52);
				SendIndex=SendIndex+52;
			}else
				setjiaocai32(ts);
		}
		else
		{
			int duan_a,duan_b,duan_c;
			duan_a = BCD_INT32(&SendBuff[SendIndex+2],2);
			duan_b = BCD_INT32(&SendBuff[SendIndex+4],2);
			duan_c = BCD_INT32(&SendBuff[SendIndex+6],2);
			SdPrintf(YNPrint,PreFix,"F26==== �˴δ���   A=%d  B=%d   C=%d",duan_a,duan_b,duan_c);
			if (JSetPara_AFN04_3761_2009->group2.f10[P-1].ConnectType==30)
			{
				tmp=BCD_INT32(&SendBuff[SendIndex+2],2)+BCD_INT32(&SendBuff[SendIndex+4],2)+BCD_INT32(&SendBuff[SendIndex+6],2);
				SdPrintf(YNPrint,PreFix,"F26==== �����ܴ���=%d",tmp);
				INT32U_BCD(tmp,&SendBuff[SendIndex],2);
			}
			SendIndex = SendIndex + 8;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb3,0x20,0,3,4,0,0,0,0,dftype);
							// b3 20 �ܶ���ʱ��      b321 A�����ʱ��		 b322 B�����ʱ��  	b323 C�����ʱ��
			if (JSetPara_AFN04_3761_2009->group2.f10[P-1].ConnectType==30)
			{
				tmp=BCD_INT32(&SendBuff[SendIndex+3],3)+BCD_INT32(&SendBuff[SendIndex+6],3)+BCD_INT32(&SendBuff[SendIndex+9],3);
				INT32U_BCD(tmp,&SendBuff[SendIndex],3);
			}
			SendIndex = SendIndex + 12;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb3,0x30,1,4,4,0,0,0,0,dftype);
			dsj=0;			// b3 30���һ�ζ�����ʼʱ��      b331 A��		 b332 B�� 	b333 C��
			if (JSetPara_AFN04_3761_2009->group2.f10[P-1].ConnectType==30)
			{
				dsj=1;
				tmp=BCD_INT32(&SendBuff[SendIndex+4],4);
				if (BCD_INT32(&SendBuff[SendIndex+8],4)>tmp)
				{
					tmp=BCD_INT32(&SendBuff[SendIndex+8],4);
					dsj=2;
				}
				if (BCD_INT32(&SendBuff[SendIndex+12],4)>tmp)
				{
					tmp=BCD_INT32(&SendBuff[SendIndex+12],4);
					dsj=3;
				}
				if (dsj==1)
				{
					memcpy(&SendBuff[SendIndex],&SendBuff[SendIndex+4],4);
				}
				if (dsj==2)
				{
					memcpy(&SendBuff[SendIndex],&SendBuff[SendIndex+8],4);
				}
				if (dsj==3)
				{
					memcpy(&SendBuff[SendIndex],&SendBuff[SendIndex+12],4);
				}
			}
			SendIndex = SendIndex + 16;
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb3,0x40,1,4,4,0,0,0,0,dftype);
			dsj=0;			// b3 40 ���һ�ζ������ʱ��		A��			B��		C��
			if (JSetPara_AFN04_3761_2009->group2.f10[P-1].ConnectType==30)
			{
				dsj=1;
				tmp=BCD_INT32(&SendBuff[SendIndex+4],4);
				if (BCD_INT32(&SendBuff[SendIndex+8],4)>tmp)
				{
					tmp=BCD_INT32(&SendBuff[SendIndex+8],4);
					dsj=2;
				}
				if (BCD_INT32(&SendBuff[SendIndex+12],4)>tmp)
				{
					tmp=BCD_INT32(&SendBuff[SendIndex+12],4);
					dsj=3;
				}
				if (dsj==1)
				{
					memcpy(&SendBuff[SendIndex],&SendBuff[SendIndex+4],4);
				}
				if (dsj==2)
				{
					memcpy(&SendBuff[SendIndex],&SendBuff[SendIndex+8],4);
				}
				if (dsj==3)
				{
					memcpy(&SendBuff[SendIndex],&SendBuff[SendIndex+12],4);
				}
			}
			SendIndex = SendIndex + 16;
		}
	}
	else
	{
		if (ifjiaocai==0)
		{
			memset(&SendBuff[SendIndex],OxXX,52);
			SendIndex=SendIndex+52;
		}else
			setjiaocai32(ts);
	}
	return 3;
}

INT16U Get_Level2Data_F33(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	INT16U IsDataFlag;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
	TS ts,ts2;
	ExdTongJi exdtj;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if (AutoFlg==1)
		StPos=3;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Month=BCD_INT32(&Data[0]+StPos,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
	if (AutoFlg==1) TimeDecrease(&ts2,5,1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Year = BCD_INT32(&Data[1]+StPos,1)+2000;
	ts.Month=BCD_INT32(&Data[0]+StPos,1);
	//��������
	IsDataFlag=0;
	//if (AutoFlg==0) TimeAdd(&ts,5,1);//fzh
	memset(Temp_FilePath,0x00,60);

	sprintf((char *)Temp_FilePath,"/nand/DataYueTongJi/%04d/m%02d.dat",P,ts.Month);//,ts.Month);
	SdPrintf(YNPrint,PreFix,"Get_Level2Data_F33 Temp_FilePath=%s\n\r",Temp_FilePath);
	INT8U TempBuf[60];
	memset(TempBuf,0,60);
	sprintf((char*)TempBuf,"/nand/DataCurr/%04d/curr.dat",P);
	if (ReadFile((char *)TempBuf, &smfile,sizeof(SMFiles),Jproginfo) == 1)
		memset(&smfile,0,sizeof(SMFiles));
	//Yue_Save_ALL  f33_yuesave;
	if (access((char*)Temp_FilePath, 0) == 0)
	{
		ReadFile((char *)Temp_FilePath,&exdtj,sizeof(ExdTongJi),Jproginfo);
		if(FindFlginFile(&smfile,0xB6, 0x30,Jproginfo) &&
			((FindFlginFile(&smfile,0xB6, 0x11,Jproginfo) && FindFlginFile(&smfile,0xB6, 0x21,Jproginfo)) ||
			(FindFlginFile(&smfile,0xB6, 0x12,Jproginfo) && FindFlginFile(&smfile,0xB6, 0x22,Jproginfo)) ||
			(FindFlginFile(&smfile,0xB6, 0x13,Jproginfo) && FindFlginFile(&smfile,0xB6, 0x23,Jproginfo))))
		{
			INT32U_BCD(exdtj.P_MAX,&SendBuff[SendIndex],3);
			SendIndex=SendIndex+3;
			memcpy(&SendBuff[SendIndex],&exdtj.P_MAX_TIME,3);
			SendIndex=SendIndex+3;
		}else{
			if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port!=1)
				memset(&SendBuff[SendIndex],OxXX,6);
			else
				memset(&SendBuff[SendIndex],0,6);
			SendIndex=SendIndex+6;
		}

		if(FindFlginFile(&smfile,0xb6, 0x31,Jproginfo)&&
			(FindFlginFile(&smfile,0xB6, 0x11,Jproginfo) && FindFlginFile(&smfile,0xB6, 0x21,Jproginfo)))
		{
			INT32U_BCD(exdtj.PA_MAX,&SendBuff[SendIndex],3);
			SendIndex=SendIndex+3;
			memcpy(&SendBuff[SendIndex],&exdtj.PA_MAX_TIME,3);
			SendIndex=SendIndex+3;
		}else{
			if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port!=1)
				memset(&SendBuff[SendIndex],OxXX,6);
			else
				memset(&SendBuff[SendIndex],0,6);
			SendIndex=SendIndex+6;
		}

		if(FindFlginFile(&smfile,0xB6, 0x32,Jproginfo)&&
			(FindFlginFile(&smfile,0xB6, 0x12,Jproginfo) && FindFlginFile(&smfile,0xB6, 0x22,Jproginfo)))
		{
			INT32U_BCD(exdtj.PB_MAX,&SendBuff[SendIndex],3);
			SendIndex=SendIndex+3;
			memcpy(&SendBuff[SendIndex],&exdtj.PB_MAX_TIME,3);
			SendIndex=SendIndex+3;
		}else{
			if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port!=1)
				memset(&SendBuff[SendIndex],OxXX,6);
			else
				memset(&SendBuff[SendIndex],0,6);
			SendIndex=SendIndex+6;
		}
		if(FindFlginFile(&smfile,0xB6, 0x33,Jproginfo)&&
			(FindFlginFile(&smfile,0xB6, 0x13,Jproginfo) && FindFlginFile(&smfile,0xB6, 0x23,Jproginfo)))
		{
			INT32U_BCD(exdtj.PC_MAX,&SendBuff[SendIndex],3);
			SendIndex=SendIndex+3;
			memcpy(&SendBuff[SendIndex],&exdtj.PC_MAX_TIME,3);
			SendIndex=SendIndex+3;
		}else{
			if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port!=1)
				memset(&SendBuff[SendIndex],OxXX,6);
			else
				memset(&SendBuff[SendIndex],0,6);
			SendIndex=SendIndex+6;
		}

		if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port!=1)
		{
			if(FindFlginFile(&smfile,0xB6, 0x30,Jproginfo) &&
				((FindFlginFile(&smfile,0xB6, 0x11,Jproginfo) && FindFlginFile(&smfile,0xB6, 0x21,Jproginfo)) ||
				(FindFlginFile(&smfile,0xB6, 0x12,Jproginfo) && FindFlginFile(&smfile,0xB6, 0x22,Jproginfo)) ||
				(FindFlginFile(&smfile,0xB6, 0x13,Jproginfo) && FindFlginFile(&smfile,0xB6, 0x23,Jproginfo))))
			{
				if((!FindFlginFile(&smfile,0xB6, 0x13,Jproginfo) && !FindFlginFile(&smfile,0xB6, 0x23,Jproginfo)))
				{
					memset(&SendBuff[SendIndex],0xee,2);
					SendIndex=SendIndex+2;
				}else{
					SendBuff[SendIndex++]=exdtj.P_Zero_Time&0xff;
					SendBuff[SendIndex++]=(exdtj.P_Zero_Time>>8)&0xff;
				}
			}else{
				memset(&SendBuff[SendIndex],OxXX,2);
				SendIndex=SendIndex+2;
			}
		}else{
			memset(&SendBuff[SendIndex],0,2);
			SendIndex=SendIndex+2;
		}
		if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port!=1)
		{
			if(FindFlginFile(&smfile,0xb6, 0x31,Jproginfo)&&
				(FindFlginFile(&smfile,0xB6, 0x11,Jproginfo) && FindFlginFile(&smfile,0xB6, 0x21,Jproginfo)))
			{
				if((!FindFlginFile(&smfile,0xB6, 0x13,Jproginfo) && !FindFlginFile(&smfile,0xB6, 0x23,Jproginfo)))
				{
					memset(&SendBuff[SendIndex],0xee,2);
					SendIndex=SendIndex+2;
				}else{
					SendBuff[SendIndex++]=exdtj.PA_Zero_Time&0xff;
					SendBuff[SendIndex++]=(exdtj.PA_Zero_Time>>8)&0xff;
				}
			}else{
				memset(&SendBuff[SendIndex],OxXX,2);
				SendIndex=SendIndex+2;
			}
		}else
		{
			memset(&SendBuff[SendIndex],0,2);
			SendIndex=SendIndex+2;
		}
		if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port!=1)
		{
			if(FindFlginFile(&smfile,0xB6, 0x32,Jproginfo)&&
				(FindFlginFile(&smfile,0xB6, 0x12,Jproginfo) && FindFlginFile(&smfile,0xB6, 0x22,Jproginfo)))
			{
				if((!FindFlginFile(&smfile,0xB6, 0x13,Jproginfo) && !FindFlginFile(&smfile,0xB6, 0x23,Jproginfo)))
				{
					memset(&SendBuff[SendIndex],0xee,2);
					SendIndex=SendIndex+2;
				}else{
					SendBuff[SendIndex++]=exdtj.PB_Zero_Time&0xff;
					SendBuff[SendIndex++]=(exdtj.PB_Zero_Time>>8)&0xff;
				}
			}else{
				memset(&SendBuff[SendIndex],OxXX,2);
				SendIndex=SendIndex+2;
			}
		}else
		{
			memset(&SendBuff[SendIndex],0,2);
			SendIndex=SendIndex+2;
		}
		if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port!=1)
		{
			if(FindFlginFile(&smfile,0xB6, 0x33,Jproginfo)&&
				(FindFlginFile(&smfile,0xB6, 0x13,Jproginfo) && FindFlginFile(&smfile,0xB6, 0x23,Jproginfo)))
			{
				if((!FindFlginFile(&smfile,0xB6, 0x13,Jproginfo) && !FindFlginFile(&smfile,0xB6, 0x23,Jproginfo)))
				{
					memset(&SendBuff[SendIndex],0xee,2);
					SendIndex=SendIndex+2;
				}else{
					SendBuff[SendIndex++]=exdtj.PC_Zero_Time&0xff;
					SendBuff[SendIndex++]=(exdtj.PC_Zero_Time>>8)&0xff;
				}
			}else{
				memset(&SendBuff[SendIndex],OxXX,2);
				SendIndex=SendIndex+2;
			}
		}else
		{
			memset(&SendBuff[SendIndex],0,2);
			SendIndex=SendIndex+2;
		}
	}
	else
	{
		if(JSetPara_AFN04_3761_2009->group2.f10[P-1].port!=1)
			memset(&SendBuff[SendIndex],OxXX,32);
		else
			memset(&SendBuff[SendIndex],0,32);
		SendIndex=SendIndex+32;
	}
	return 2;
}
INT16U Get_Level2Data_F34(INT8U Set,INT16U F,INT16U P,INT8U *Data)         	//���ܼ������й��������������ʱ��    9.22
{
	INT16U IsDataFlag;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
//	INT8U tempManyData[50],tempManyData1[50],tempManyData2[50],tempManyData3[50];
//	INT32U temp1,temp2,temp3;
	TS ts,ts2;
	ExdTongJi exdtj;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if (AutoFlg==1)
		StPos=3;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Month=BCD_INT32(&Data[0]+StPos,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
	if (AutoFlg==1) TimeDecrease(&ts2,5,1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Year = BCD_INT32(&Data[1]+StPos,1)+2000;
	ts.Month=BCD_INT32(&Data[0]+StPos,1);
	//��������
	IsDataFlag=0;
	//if (AutoFlg==0) TimeAdd(&ts,5,1);//fzh
	memset(Temp_FilePath,0x00,60);

	sprintf((char *)Temp_FilePath,"/nand/DataYueTongJi/%04d/m%02d.dat",P,ts.Month);//,ts.Month);
	SdPrintf(YNPrint,PreFix,"Get_Level2Data_F34 Temp_FilePath=%s\n\r",Temp_FilePath);
	if (access((char*)Temp_FilePath, 0) == 0)
	{
		ReadFile((char *)Temp_FilePath,&exdtj,sizeof(ExdTongJi),Jproginfo);

		INT32U_BCD(exdtj.P_All_XL,&SendBuff[SendIndex],3);
		SendIndex=SendIndex+3;
		memcpy(&SendBuff[SendIndex],&exdtj.P_All_XL_Time,3);
		SendIndex=SendIndex+3;
		INT32U_BCD(exdtj.P_U_XL,&SendBuff[SendIndex],3);
		SendIndex=SendIndex+3;
		memcpy(&SendBuff[SendIndex],&exdtj.P_U_XL_Time,3);
		SendIndex=SendIndex+3;
		INT32U_BCD(exdtj.P_V_XL,&SendBuff[SendIndex],3);
		SendIndex=SendIndex+3;
		memcpy(&SendBuff[SendIndex],&exdtj.P_V_XL_Time,3);
		SendIndex=SendIndex+3;
		INT32U_BCD(exdtj.P_W_XL,&SendBuff[SendIndex],3);
		SendIndex=SendIndex+3;
		memcpy(&SendBuff[SendIndex],&exdtj.P_W_XL_Time,3);
		SendIndex=SendIndex+3;
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,24);
		SendIndex=SendIndex+24;
	}
	return 2;
}

INT16U Get_Level2Data_F35(INT8U Set,INT16U F,INT16U P,INT8U *Data)//�¶����µ�ѹͳ������
{
//	INT16U IsDataFlag,j,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
	//INT8U tempManyData[50],tempManyData1[50],tempManyData2[50],tempManyData3[50];
//	INT32U temp1,temp2,temp3;
	TS ts,ts2;
	ExdTongJi exdtj;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if (AutoFlg==1)
		StPos=3;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Month=BCD_INT32(&Data[0]+StPos,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
	if (AutoFlg==1) TimeDecrease(&ts2,5,1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Year = BCD_INT32(&Data[1]+StPos,1)+2000;
	ts.Month=BCD_INT32(&Data[0]+StPos,1);
	//��������
	//IsDataFlag=0;
	//if (AutoFlg==0) TimeAdd(&ts,5,1);//fzh
	memset(Temp_FilePath,0x00,60);

	//if (JSetPara_AFN04_3761_2009->group2.f10[P-1].ConnectType==2)
	//if(P==1 || P==2 || P==3)
	{
		memset(&exdtj, 0, sizeof(exdtj));
		sprintf((char*)Temp_FilePath,"/nand/DataYueTongJi/%04d/m%02d.dat",P,ts.Month);
		SdPrintf(YNPrint,PreFix,"Get_Level2Data_F35 Temp_FilePath=%s\n\r",Temp_FilePath);

		INT8U TempBuf[60];
		memset(TempBuf,0,60);
		sprintf((char*)TempBuf,"/nand/DataCurr/%04d/curr.dat",P);
		if (ReadFile((char *)TempBuf, &smfile,sizeof(SMFiles),Jproginfo) == 1)
			memset(&smfile,0,sizeof(SMFiles));

		if (access((char*)Temp_FilePath, 0) == 0)
		{
			if (ReadFile((char*)Temp_FilePath,(char *) &exdtj, sizeof(exdtj),Jproginfo)==1)
			{
				memset(&SendBuff[SendIndex],OxXX,66);
				SendIndex=SendIndex+66;
			}
			else
			{
				if(FindFlginFile(&smfile,0xB6, 0x11,Jproginfo)){
					memcpy(&SendBuff[SendIndex],&exdtj.USSU_Count,2);
					SendIndex=SendIndex+2;
					memcpy(&SendBuff[SendIndex],&exdtj.UXXU_Count,2);
					SendIndex=SendIndex+2;
					memcpy(&SendBuff[SendIndex],&exdtj.USU_Count,2);
					SendIndex=SendIndex+2;
					memcpy(&SendBuff[SendIndex],&exdtj.UXU_Count,2);
					SendIndex=SendIndex+2;
					memcpy(&SendBuff[SendIndex],&exdtj.UHGU_Count,2);
					SendIndex=SendIndex+2;
				}else{
					memset(&SendBuff[SendIndex],OxXX,10);
					SendIndex=SendIndex+10;
				}
				if(FindFlginFile(&smfile,0xB6, 0x12,Jproginfo)){
					memcpy(&SendBuff[SendIndex],&exdtj.USSV_Count,2);
					SendIndex=SendIndex+2;
					memcpy(&SendBuff[SendIndex],&exdtj.UXXV_Count,2);
					SendIndex=SendIndex+2;
					memcpy(&SendBuff[SendIndex],&exdtj.USV_Count,2);
					SendIndex=SendIndex+2;
					memcpy(&SendBuff[SendIndex],&exdtj.UXV_Count,2);
					SendIndex=SendIndex+2;
					memcpy(&SendBuff[SendIndex],&exdtj.UHGV_Count,2);
					SendIndex=SendIndex+2;
				}else{
					memset(&SendBuff[SendIndex],OxXX,10);
					SendIndex=SendIndex+10;
				}
				if(FindFlginFile(&smfile,0xB6, 0x13,Jproginfo)){
					memcpy(&SendBuff[SendIndex],&exdtj.USSW_Count,2);
					SendIndex=SendIndex+2;
					memcpy(&SendBuff[SendIndex],&exdtj.UXXW_Count,2);
					SendIndex=SendIndex+2;
					memcpy(&SendBuff[SendIndex],&exdtj.USW_Count,2);
					SendIndex=SendIndex+2;
					memcpy(&SendBuff[SendIndex],&exdtj.UXW_Count,2);
					SendIndex=SendIndex+2;
					memcpy(&SendBuff[SendIndex],&exdtj.UHGW_Count,2);
					SendIndex=SendIndex+2;
				}else{
					memset(&SendBuff[SendIndex],OxXX,10);
					SendIndex=SendIndex+10;
				}
				if(FindFlginFile(&smfile,0xB6, 0x11,Jproginfo)){
					INT32U_BCD(exdtj.DUUMAX,&SendBuff[SendIndex],2);
					SendIndex=SendIndex+2;
					memcpy(&SendBuff[SendIndex],&exdtj.DUUMAX_TIME[0],3);
					SendIndex=SendIndex+3;
					INT32U_BCD(exdtj.DUUMIN,&SendBuff[SendIndex],2);
					SendIndex=SendIndex+2;
					memcpy(&SendBuff[SendIndex],&exdtj.DUUMIN_TIME[0],3);
					SendIndex=SendIndex+3;
				}else{
					memset(&SendBuff[SendIndex],OxXX,10);
					SendIndex=SendIndex+10;
				}
				if(FindFlginFile(&smfile,0xB6, 0x12,Jproginfo)){
					INT32U_BCD(exdtj.DUVMAX,&SendBuff[SendIndex],2);
					SendIndex=SendIndex+2;
					memcpy(&SendBuff[SendIndex],&exdtj.DUVMAX_TIME[0],3);
					SendIndex=SendIndex+3;
					INT32U_BCD(exdtj.DUVMIN,&SendBuff[SendIndex],2);
					SendIndex=SendIndex+2;
					memcpy(&SendBuff[SendIndex],&exdtj.DUVMIN_TIME[0],3);
					SendIndex=SendIndex+3;
				}else{
					memset(&SendBuff[SendIndex],OxXX,10);
					SendIndex=SendIndex+10;
				}
				if(FindFlginFile(&smfile,0xB6, 0x13,Jproginfo)){
					INT32U_BCD(exdtj.DUWMAX,&SendBuff[SendIndex],2);
					SendIndex=SendIndex+2;
					memcpy(&SendBuff[SendIndex],&exdtj.DUWMAX_TIME[0],3);
					SendIndex=SendIndex+3;
					INT32U_BCD(exdtj.DUWMIN,&SendBuff[SendIndex],2);
					SendIndex=SendIndex+2;
					memcpy(&SendBuff[SendIndex],&exdtj.DUWMIN_TIME[0],3);
					SendIndex=SendIndex+3;
				}else{
					memset(&SendBuff[SendIndex],OxXX,10);
					SendIndex=SendIndex+10;
				}
				if(FindFlginFile(&smfile,0xB6, 0x11,Jproginfo)){
					INT32U_BCD(exdtj.DUUAVE,&SendBuff[SendIndex],2);
					SendIndex=SendIndex+2;
				}else{
					memset(&SendBuff[SendIndex],OxXX,2);
					SendIndex=SendIndex+2;
				}
				if(FindFlginFile(&smfile,0xB6, 0x12,Jproginfo)){
					INT32U_BCD(exdtj.DUVAVE,&SendBuff[SendIndex],2);
					SendIndex=SendIndex+2;
				}else{
					memset(&SendBuff[SendIndex],OxXX,2);
					SendIndex=SendIndex+2;
				}
				if(FindFlginFile(&smfile,0xB6, 0x13,Jproginfo)){
					INT32U_BCD(exdtj.DUWAVE,&SendBuff[SendIndex],2);
					SendIndex=SendIndex+2;
				}else{
					memset(&SendBuff[SendIndex],OxXX,2);
					SendIndex=SendIndex+2;
				}
			}
		}
		else
		{
			memset(&SendBuff[SendIndex],OxXX,66);
			SendIndex=SendIndex+66;
		}
	}
	return 2;
}
INT16U Get_Level2Data_F36(INT8U Set,INT16U F,INT16U P,INT8U *Data)//
{
	ExdTongJi exdtj;
	INT16U IsDataFlag;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if (AutoFlg==1)
		StPos=3;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Month=BCD_INT32(&Data[0]+StPos,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
	if (AutoFlg==1) TimeDecrease(&ts2,5,1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Year = BCD_INT32(&Data[1]+StPos,1)+2000;
	ts.Month=BCD_INT32(&Data[0]+StPos,1);
	//��������
	IsDataFlag=0;
	//if (AutoFlg==0) TimeAdd(&ts,5,1);//fzh
	memset(Temp_FilePath,0x00,60);

	sprintf((char *)Temp_FilePath,"/nand/DataYueTongJi/%04d/m%02d.dat",P,ts.Month);//,ts.Month);
	SdPrintf(YNPrint,PreFix,"Get_Level2Data_F36 Temp_FilePath=%s\n\r",Temp_FilePath);

	INT8U TempBuf[60];
	memset(TempBuf,0,60);
	sprintf((char*)TempBuf,"/nand/DataCurr/%04d/curr.dat",P);
	if (ReadFile((char *)TempBuf, &smfile,sizeof(SMFiles),Jproginfo) == 1)
		memset(&smfile,0,sizeof(SMFiles));
	//Yue_Save_ALL  f33_yuesave;
	if (access((char*)Temp_FilePath, 0) == 0)
	{
		ReadFile((char *)Temp_FilePath,&exdtj,sizeof(ExdTongJi),Jproginfo);
		if(FindFlginFile(&smfile,0xB6, 0x21,Jproginfo)){
			INT32U_BCD(exdtj.I_UNBALANCE_Count,&SendBuff[SendIndex],2);
			SendIndex=SendIndex+2;
		}else{
			memset(&SendBuff[SendIndex],OxXX,2);
			SendIndex=SendIndex+2;
		}
		if(FindFlginFile(&smfile,0xB6, 0x11,Jproginfo)){
			INT32U_BCD(exdtj.V_UNBALANCE_Count,&SendBuff[SendIndex],2);
			SendIndex=SendIndex+2;
		}else{
			memset(&SendBuff[SendIndex],OxXX,2);
			SendIndex=SendIndex+2;
		}
		if(FindFlginFile(&smfile,0xB6, 0x21,Jproginfo)){
			INT32U_BCD(exdtj.I_UNBALANCE_Max,&SendBuff[SendIndex],2);
			SendIndex=SendIndex+2;
			memcpy(&SendBuff[SendIndex],&exdtj.I_UNBALANCE_MaxTime,4);
			SendIndex=SendIndex+4;
		}else{
			memset(&SendBuff[SendIndex],OxXX,6);
			SendIndex=SendIndex+6;
		}
		if(FindFlginFile(&smfile,0xB6, 0x11,Jproginfo)){
			INT32U_BCD(exdtj.V_UNBALANCE_Max,&SendBuff[SendIndex],2);
			SendIndex=SendIndex+2;
			memcpy(&SendBuff[SendIndex],&exdtj.V_UNBALANCE_MaxTime,4);
			SendIndex=SendIndex+4;
		}else{
			memset(&SendBuff[SendIndex],OxXX,6);
			SendIndex=SendIndex+6;
		}
	}else
	{
		memset(&SendBuff[SendIndex],OxXX,16);
		SendIndex=SendIndex+16;
	}
	return 2;
}
INT16U Get_Level2Data_F37(INT8U Set,INT16U F,INT16U P,INT8U *Data)//
{
	ExdTongJi exdtj;
	INT16U IsDataFlag;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if (AutoFlg==1)
		StPos=3;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Month=BCD_INT32(&Data[0]+StPos,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
	if (AutoFlg==1) TimeDecrease(&ts2,5,1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Year = BCD_INT32(&Data[1]+StPos,1)+2000;
	ts.Month=BCD_INT32(&Data[0]+StPos,1);
	//��������
	IsDataFlag=0;
	//if (AutoFlg==0) TimeAdd(&ts,5,1);//fzh
	memset(Temp_FilePath,0x00,60);

	sprintf((char *)Temp_FilePath,"/nand/DataYueTongJi/%04d/m%02d.dat",P,ts.Month);//,ts.Month);
	SdPrintf(YNPrint,PreFix,"Get_Level2Data_F37 Temp_FilePath=%s\n\r",Temp_FilePath);
	//Yue_Save_ALL  f33_yuesave;
	ReadFile((char *)Temp_FilePath,&exdtj,sizeof(ExdTongJi),Jproginfo);

	INT8U TempBuf[60];
	memset(TempBuf,0,60);
	sprintf((char*)TempBuf,"/nand/DataCurr/%04d/curr.dat",P);
	if (ReadFile((char *)TempBuf, &smfile,sizeof(SMFiles),Jproginfo) == 1)
		memset(&smfile,0,sizeof(SMFiles));

	if (access((char*)Temp_FilePath, 0) == 0)
	{
		if(FindFlginFile(&smfile,0xB6, 0x21,Jproginfo)){
			INT32U_BCD(exdtj.ISSU_Count,&SendBuff[SendIndex],2);
			SendIndex=SendIndex+2;
			INT32U_BCD(exdtj.ISU_Count,&SendBuff[SendIndex],2);
			SendIndex=SendIndex+2;
		}else{
			memset(&SendBuff[SendIndex],OxXX,4);
			SendIndex=SendIndex+4;
		}
		if(FindFlginFile(&smfile,0xB6, 0x22,Jproginfo)){
			INT32U_BCD(exdtj.ISSV_Count,&SendBuff[SendIndex],2);
			SendIndex=SendIndex+2;
			INT32U_BCD(exdtj.ISV_Count,&SendBuff[SendIndex],2);
			SendIndex=SendIndex+2;
		}else{
			memset(&SendBuff[SendIndex],OxXX,4);
			SendIndex=SendIndex+4;
		}
		if(FindFlginFile(&smfile,0xB6, 0x23,Jproginfo)){
			INT32U_BCD(exdtj.ISSW_Count,&SendBuff[SendIndex],2);
			SendIndex=SendIndex+2;
			INT32U_BCD(exdtj.ISW_Count,&SendBuff[SendIndex],2);
			SendIndex=SendIndex+2;
			INT32U_BCD(exdtj.ISL_Count,&SendBuff[SendIndex],2);
			SendIndex=SendIndex+2;
		}else{
			memset(&SendBuff[SendIndex],OxXX,6);
			SendIndex=SendIndex+6;
		}
		if(FindFlginFile(&smfile,0xB6, 0x21,Jproginfo)){
			INT32U_BCD(exdtj.DI_U_MAX,&SendBuff[SendIndex],3);
			SendIndex=SendIndex+3;
			memcpy(&SendBuff[SendIndex],&exdtj.DIUMAX_TIME,3);
			SendIndex=SendIndex+3;
		}else{
			memset(&SendBuff[SendIndex],OxXX,6);
			SendIndex=SendIndex+6;
		}
		if(FindFlginFile(&smfile,0xB6, 0x22,Jproginfo)){
			INT32U_BCD(exdtj.DI_V_MAX,&SendBuff[SendIndex],3);
			SendIndex=SendIndex+3;
			memcpy(&SendBuff[SendIndex],&exdtj.DIVMAX_TIME,3);
			SendIndex=SendIndex+3;
		}else{
			memset(&SendBuff[SendIndex],OxXX,6);
			SendIndex=SendIndex+6;
		}
		if(FindFlginFile(&smfile,0xB6, 0x23,Jproginfo)){
			INT32U_BCD(exdtj.DI_W_MAX,&SendBuff[SendIndex],3);
			SendIndex=SendIndex+3;
			memcpy(&SendBuff[SendIndex],&exdtj.DIWMAX_TIME,3);
			SendIndex=SendIndex+3;
		}else{
			memset(&SendBuff[SendIndex],OxXX,6);
			SendIndex=SendIndex+6;
		}

		if(FindFlginFile(&smfile,0xB6, 0x23,Jproginfo)){
			INT32U_BCD(exdtj.DI_L_MAX,&SendBuff[SendIndex],3);
			SendIndex=SendIndex+3;
			memcpy(&SendBuff[SendIndex],&exdtj.DILMAX_TIME,3);
			SendIndex=SendIndex+3;
		}else{
			memset(&SendBuff[SendIndex],OxXX,6);
			SendIndex=SendIndex+6;
		}
	}else
	{
		memset(&SendBuff[SendIndex],OxXX,38);
		SendIndex=SendIndex+38;
	}
	return 2;
}

//�¶��������ڹ���Խ���ۼ�ʱ��
INT16U Get_Level2Data_F38(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	//INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
	TS ts,ts2;
	INT8U temp[60];
	ExdTongJi exdtj;
	memset(temp,0,60);
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if (AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��


	ts2.Month=BCD_INT32(&Data[0]+StPos,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
	if (AutoFlg==1) TimeDecrease(&ts2,5,1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Year = BCD_INT32(&Data[1]+StPos,1)+2000;
	ts.Month=BCD_INT32(&Data[0]+StPos,1);
	//if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong//fzh

	memset(Temp_FilePath,0x00,60);
	sprintf((char *)Temp_FilePath,"/nand/DataYueTongJi/%04d/m%02d.dat",P,ts.Month);
	SdPrintf(YNPrint,PreFix, " Get_Level2Data_F38 Temp_FilePath=%s\n\r",Temp_FilePath);
	if (access((char*)Temp_FilePath, 0) == 0)
	{
		ReadFile((char *)Temp_FilePath,&exdtj,sizeof(ExdTongJi),Jproginfo);

		INT32U_BCD(exdtj.S_SS_Count,&SendBuff[SendIndex],2);
		SendIndex=SendIndex+2;
		INT32U_BCD(exdtj.S_S_Count,&SendBuff[SendIndex],2);
		SendIndex=SendIndex+2;
	}else
	{
		memset(&SendBuff[SendIndex],OxXX,4);
		SendIndex=SendIndex+4;
	}
	return 3;
}

INT16U Get_Level2Data_F39(INT8U Set,INT16U F,INT16U P,INT8U *Data)//�¸�����ͳ��
{
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	ExdTongJi exdtj;
	INT8U Temp_FilePath[60];
	StPos=0;
	if (AutoFlg==1)
		StPos=2;

	ts2.Month=BCD_INT32(&Data[0]+StPos,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
	if (AutoFlg==1) TimeDecrease(&ts2,5,1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Year = BCD_INT32(&Data[1]+StPos,1)+2000;
	ts.Month=BCD_INT32(&Data[0]+StPos,1);

	memset(&exdtj, 0, sizeof(exdtj));
	memset(Temp_FilePath,0,60);
	sprintf((char*)Temp_FilePath,"/nand/DataYueTongJi/%04d/m%02d.dat",P,ts.Month);
	printf("\n Get_Level2Data_F44 Temp_FilePath=%s\n\r",Temp_FilePath);
	if(access((char *)Temp_FilePath,0)==0)
	{
		ReadFile((char *)Temp_FilePath,&exdtj,sizeof(ExdTongJi),Jproginfo);

		INT32U_BCD(exdtj.FuZaiLV_Max ,&SendBuff[SendIndex], 2);
		SendIndex = SendIndex + 2;
		memcpy(&SendBuff[SendIndex],exdtj.FuZaiLV_MaxTime,4);
		SendIndex = SendIndex + 4;
		INT32U_BCD(exdtj.FuZaiLV_Min ,&SendBuff[SendIndex], 2);
		SendIndex = SendIndex + 2;
		memcpy(&SendBuff[SendIndex],exdtj.FuZaiLV_MinTime,4);
		SendIndex = SendIndex + 4;
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,12);
		SendIndex=SendIndex+12;
	}
	return 2;
}

INT16U Get_Level2Data_F41(INT8U Set,INT16U F,INT16U P,INT8U *Data)//
{
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if (AutoFlg==1)
		StPos=2;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	memset(&SendBuff[SendIndex],OxXX,36);
	SendIndex=SendIndex+36;
	memset(&SendBuff[SendIndex],OxXX,36);
	SendIndex=SendIndex+36;
	ts.Year = BCD_INT32(&Data[2]+StPos,1)+2000;
	ts.Month=BCD_INT32(&Data[1]+StPos,1);
	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	if (AutoFlg==0) TimeAdd(&ts,4,1);
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 3;
}
INT16U Get_Level2Data_F42(INT8U Set,INT16U F,INT16U P,INT8U *Data)//
{
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if (AutoFlg==1)
		StPos=2;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	memset(&SendBuff[SendIndex],OxXX,4);
	SendIndex=SendIndex+4;
	memset(&SendBuff[SendIndex],OxXX,4);
	SendIndex=SendIndex+4;
	ts.Year = BCD_INT32(&Data[2]+StPos,1)+2000;
	ts.Month=BCD_INT32(&Data[1]+StPos,1);
	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	if (AutoFlg==0) TimeAdd(&ts,4,1);
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 3;
}
INT16U Get_Level2Data_F43(INT8U Set,INT16U F,INT16U P,INT8U *Data)//
{
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	ExdTongJi exdtj;
	INT8U Temp_FilePath[60];
	StPos=0;
	if (AutoFlg==1)
		StPos=2;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Year = BCD_INT32(&Data[2]+StPos,1)+2000;
	ts.Month=BCD_INT32(&Data[1]+StPos,1);
	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	//if (AutoFlg==0) TimeAdd(&ts,4,1);//fzh
	memset(&exdtj, 0, sizeof(exdtj));
	memset(Temp_FilePath,0,60);
	sprintf((char*)Temp_FilePath,"/nand/DataRiTongJi/%04d/d%02d.dat",P,ts.Day);
	SdPrintf(YNPrint,PreFix,"Get_Level2Data_F43 Temp_FilePath=%s\n\r",Temp_FilePath);
	if(access((char *)Temp_FilePath,0)==0)
	{
		ReadFile((char *)Temp_FilePath,&exdtj,sizeof(ExdTongJi),Jproginfo);
		SendBuff[SendIndex++]=exdtj.QuDuan1_Count&0xff;
		SendBuff[SendIndex++]=(exdtj.QuDuan1_Count>>8)&0xff;
		SendBuff[SendIndex++]=exdtj.QuDuan2_Count&0xff;
		SendBuff[SendIndex++]=(exdtj.QuDuan2_Count>>8)&0xff;
		SendBuff[SendIndex++]=exdtj.QuDuan3_Count&0xff;
		SendBuff[SendIndex++]=(exdtj.QuDuan3_Count>>8)&0xff;
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,6);
		SendIndex=SendIndex+6;
		//SendNAK(F, P, 0x0d);
		//return 3;
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 3;
}
INT16U Get_Level2Data_F44(INT8U Set,INT16U F,INT16U P,INT8U *Data)//
{

	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	ExdTongJi exdtj;
	INT8U Temp_FilePath[60];
	StPos=0;
	if (AutoFlg==1)
		StPos=2;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Month=BCD_INT32(&Data[0]+StPos,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
	if (AutoFlg==1) TimeDecrease(&ts2,5,1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Year = BCD_INT32(&Data[1]+StPos,1)+2000;
	ts.Month=BCD_INT32(&Data[0]+StPos,1);

	//if (AutoFlg==0) TimeAdd(&ts,5,1);//fzh

	memset(&exdtj, 0, sizeof(exdtj));
	memset(Temp_FilePath,0,60);
	sprintf((char*)Temp_FilePath,"/nand/DataYueTongJi/%04d/m%02d.dat",P,ts.Month);
	SdPrintf(YNPrint,PreFix,"Get_Level2Data_F44 Temp_FilePath=%s\n\r",Temp_FilePath);
	if(access((char *)Temp_FilePath,0)==0)
	{
		ReadFile((char *)Temp_FilePath,&exdtj,sizeof(ExdTongJi),Jproginfo);
		SendBuff[SendIndex++]=exdtj.QuDuan1_Count&0xff;
		SendBuff[SendIndex++]=(exdtj.QuDuan1_Count>>8)&0xff;
		SendBuff[SendIndex++]=exdtj.QuDuan2_Count&0xff;
		SendBuff[SendIndex++]=(exdtj.QuDuan2_Count>>8)&0xff;
		SendBuff[SendIndex++]=exdtj.QuDuan3_Count&0xff;
		SendBuff[SendIndex++]=(exdtj.QuDuan3_Count>>8)&0xff;
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,6);
		SendIndex=SendIndex+6;
		//SendNAK(F, P, 0x0d);
		//return 2;
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
//	TS ts,ts2;
//	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
//	ts.Week = 0;
//	ts2=ts;
//	TongJi tj;
//	INT8U Temp_FilePath[60];
//	StPos=0;
//	if (AutoFlg==1)
//		StPos=2;
////	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
//	ts2.Month=BCD_INT32(&Data[0]+StPos,1);
//	ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
//	if (AutoFlg==1) TimeDecrease(&ts2,5,1);
//	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
//	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
//	ts.Year = BCD_INT32(&Data[1]+StPos,1)+2000;
//	ts.Month=BCD_INT32(&Data[0]+StPos,1);
//
//	if (AutoFlg==0) TimeAdd(&ts,5,1);
//	sprintf((char *)Temp_FilePath,"/nand/DataAlarm/m%02d.dat",ts.Month);
//	if(access((char *)Temp_FilePath,0)==0)
//	{
//		ReadFile((char *)Temp_FilePath,&tj,sizeof(TongJi));
//		SendBuff[SendIndex++]=tj.Ys1Time&0xff;
//		SendBuff[SendIndex++]=(tj.Ys1Time>>8)&0xff;
//		SendBuff[SendIndex++]=tj.Ys2Time&0xff;
//		SendBuff[SendIndex++]=(tj.Ys2Time>>8)&0xff;
//		SendBuff[SendIndex++]=tj.Ys3Time&0xff;
//		SendBuff[SendIndex++]=(tj.Ys3Time>>8)&0xff;
//	}
//	else
//	{
//		memset(&SendBuff[SendIndex],OxXX,6);
//		SendIndex=SendIndex+6;
//		//SendNAK(F, P, 0x0d);
//		//return 2;
//	}
////	EC();
////	TP();
////	FrameTailCreate_Send(0);
	return 2;
}
INT16U Get_Level2Data_F45(INT8U Set,INT16U F,INT16U P,INT8U *Data)//
{
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week=0;
	ts2=ts;
	StPos=0;
	if (AutoFlg==1)
		StPos=2;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	memset(&SendBuff[SendIndex],0,10);
	SendIndex=SendIndex+10;
	return 3;
}

INT16U Get_Level2Data_F46(INT8U Set,INT16U F,INT16U P,INT8U *Data)//
{
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if (AutoFlg==1)
		StPos=3;//yangdong
	ts2.Month=BCD_INT32(&Data[0]+StPos,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);

	if (AutoFlg==1) TimeDecrease(&ts2,5,1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	memset(&SendBuff[SendIndex],0,10);
	SendIndex=SendIndex+10;
	return 2;
}

//�ն��չ���ʱ�䣬�ո�λ�ۼƴ���
INT16U Get_Level2Data_F49(INT8U Set,INT16U F,INT16U P,INT8U *Data)//
{
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week=0;
	ts2=ts;
	TongJi tj;
	INT8U Temp_FilePath[60];
	StPos=0;
	if (AutoFlg==1)
		StPos=2;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Year = BCD_INT32(&Data[2]+StPos,1)+2000;
	ts.Month=BCD_INT32(&Data[1]+StPos,1);
	ts.Day=BCD_INT32(&Data[0]+StPos,1);
//	if (AutoFlg==0) TimeAdd(&ts,4,1);//
	sprintf((char *)Temp_FilePath,"/nand/DataAlarm/d%02d.dat",ts.Day);
	if(access((char *)Temp_FilePath,0)==0)
	{
		ReadFile((char *)Temp_FilePath,&tj,sizeof(TongJi),Jproginfo);
		SdPrintf(YNPrint,PreFix,"tj.GdTimed=%d\n\r",tj.GdTime);
		SendBuff[SendIndex++]=tj.GdTime&0xff;
		SendBuff[SendIndex++]=(tj.GdTime>>8)&0xff;
		SendBuff[SendIndex++]=tj.ResetTime&0xff;
		SendBuff[SendIndex++]=(tj.ResetTime>>8)&0xff;
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,4);
		SendIndex=SendIndex+4;
		//SendNAK(F, P, 0x0d);
		//return 3;
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 3;
}
INT16U Get_Level2Data_F50(INT8U Set,INT16U F,INT16U P,INT8U *Data)//
{
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0,ts.Week=0;
	ts2=ts;
	INT8U CJQno,MeterNo,MeterType;
	StPos=0;
	if (AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;

	if (AutoFlg==0) TimeAdd(&ts,4,1);
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	SendBuff[SendIndex++]=0;
	SendBuff[SendIndex++]=0;
	SendBuff[SendIndex++]=0;
	SendBuff[SendIndex++]=1;
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 3;
}
INT16U Get_Level2Data_F51(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	TongJi tj;
	INT8U Temp_FilePath[60];
	StPos=0;
	if (AutoFlg==1)
		StPos=3;//yangdong
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Month=BCD_INT32(&Data[0]+StPos,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
	if (AutoFlg==1) TimeDecrease(&ts2,5,1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Year = BCD_INT32(&Data[1]+StPos,1)+2000;
	ts.Month=BCD_INT32(&Data[0]+StPos,1);
	SdPrintf(YNPrint,PreFix,"Get_Level2Data_F51 ts.Month =%d AutoFlg=%d\n", ts.Month, AutoFlg);
//	if (AutoFlg==0) TimeAdd(&ts,5,1);						//9.24
	sprintf((char *)Temp_FilePath,"/nand/DataAlarm/m%02d.dat",ts.Month);
	if(access((char *)Temp_FilePath,0)==0)
	{
		ReadFile((char *)Temp_FilePath,&tj,sizeof(TongJi),Jproginfo);
		SdPrintf(YNPrint,PreFix,"tj.GdTime=%d\n\r",tj.GdTime);
		SendBuff[SendIndex++]=tj.GdTime&0xff;
		SendBuff[SendIndex++]=(tj.GdTime>>8)&0xff;
		SendBuff[SendIndex++]=tj.ResetTime&0xff;
		SendBuff[SendIndex++]=(tj.ResetTime>>8)&0xff;
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,4);
		SendIndex=SendIndex+4;
		//SendNAK(F, P, 0x0d);
		//return 2;
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 2;
}

INT16U Get_Level2Data_F52(INT8U Set,INT16U F,INT16U P,INT8U *Data)//10.24
{
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0,ts.Week=0;
	ts2=ts;
	INT8U CJQno,MeterNo,MeterType;
	StPos=0;
	if (AutoFlg==1)
		StPos=3;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;

	if (AutoFlg==0) TimeAdd(&ts,5,1);
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Month=BCD_INT32(&Data[0]+StPos,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
	if (AutoFlg==1) TimeDecrease(&ts2,5,1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	SendBuff[SendIndex++]=0;
	SendBuff[SendIndex++]=0;
	SendBuff[SendIndex++]=0;
	SendBuff[SendIndex++]=1;
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 3;
}

INT16U Get_Level2Data_F53(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	TongJi tj;
	INT8U Temp_FilePath[60];
	StPos=0;
	if (AutoFlg==1)
		StPos=2;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);

	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);

	ts.Year = BCD_INT32(&Data[2]+StPos,1)+2000;
	ts.Month=BCD_INT32(&Data[1]+StPos,1);
	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	//if (AutoFlg==0) TimeAdd(&ts,4,1);//fzh
	SdPrintf(YNPrint,PreFix,"Get_Level2Data_F53 ts.day ==%d\n", ts.Day);
	sprintf((char *)Temp_FilePath,"/nand/DataAlarm/d%02d.dat",ts.Day);
	if(access((char *)Temp_FilePath,0)==0)
	{
		ReadFile((char *)Temp_FilePath,&tj,sizeof(TongJi),Jproginfo);
		SendBuff[SendIndex++]=tj.LiuLiang&0xff;
		SendBuff[SendIndex++]=(tj.LiuLiang>>8)&0xff;
		SendBuff[SendIndex++]=((tj.LiuLiang>>8)>>8)&0xff;
		SendBuff[SendIndex++]=(((tj.LiuLiang>>8)>>8)>>8)&0xff;
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,4);
		SendIndex=SendIndex+4;
		//SendNAK(F, P, 0x0d);
		//return 3;
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 3;
}
INT16U Get_Level2Data_F54(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	TongJi tj;
	INT8U Temp_FilePath[60];
	StPos=0;
	if (AutoFlg==1)
		StPos=3;//yangdong
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Month=BCD_INT32(&Data[0]+StPos,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);

	if (AutoFlg==1) TimeDecrease(&ts2,5,1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Year = BCD_INT32(&Data[1]+StPos,1)+2000;
	ts.Month=BCD_INT32(&Data[0]+StPos,1);

	//if (AutoFlg==0) TimeAdd(&ts,5,1);
	SdPrintf(YNPrint,PreFix,"Get_Level2Data_F54 ts.month ==%d\n", ts.Month);
	sprintf((char *)Temp_FilePath,"/nand/DataAlarm/m%02d.dat",ts.Month);
	if(access((char *)Temp_FilePath,0)==0)
	{
		ReadFile((char *)Temp_FilePath,&tj,sizeof(TongJi),Jproginfo);
		SendBuff[SendIndex++]=tj.LiuLiang&0xff;
		SendBuff[SendIndex++]=(tj.LiuLiang>>8)&0xff;
		SendBuff[SendIndex++]=((tj.LiuLiang>>8)>>8)&0xff;
		SendBuff[SendIndex++]=(((tj.LiuLiang>>8)>>8)>>8)&0xff;
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,4);
		SendIndex=SendIndex+4;
		//SendNAK(F, P, 0x0d);
		//return 2;
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 2;
}
INT16U Get_Level2Data_F57(INT8U Set,INT16U F,INT16U P,INT8U *Data)//10.24
{//
	//INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
	TS ts,ts2;
	INT8U temp[60];
	ExdTongJi exdtj;
	memset(temp,0,60);
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if (AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
	//if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong//fzh

	memset(Temp_FilePath,0x00,60);
	sprintf((char *)Temp_FilePath,"/nand/DataRiTongJi/%04d/d%02d.dat",P,ts.Day);//,ts.Month);
	SdPrintf(YNPrint,PreFix,"Get_Level2Data_F57 Temp_FilePath=%s\n\r",Temp_FilePath);
	if (access((char*)Temp_FilePath, 0) == 0)
	{
		ReadFile((char *)Temp_FilePath,&exdtj,sizeof(ExdTongJi),Jproginfo);

		INT32U_BCD(exdtj.P_MAX,&SendBuff[SendIndex],2);
		SendIndex=SendIndex+2;
		memcpy(&SendBuff[SendIndex],&exdtj.P_MAX_TIME,3);
		SendIndex=SendIndex+3;
		INT32U_BCD(exdtj.P_MIN,&SendBuff[SendIndex],2);
		SendIndex=SendIndex+2;
		memcpy(&SendBuff[SendIndex],&exdtj.P_MIN_TIME,3);
		SendIndex=SendIndex+3;

		SendBuff[SendIndex++]=exdtj.P_Zero_Time&0xff;
		SendBuff[SendIndex++]=(exdtj.P_Zero_Time>>8)&0xff;
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,12);
		SendIndex=SendIndex+12;
	}
	return 3;
}
INT16U Get_Level2Data_F60(INT8U Set,INT16U F,INT16U P,INT8U *Data) //10.24
{
	INT16U IsDataFlag;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
//	INT8U tempManyData[50],tempManyData1[50],tempManyData2[50],tempManyData3[50];
//	INT32U temp1,temp2,temp3;
	TS ts,ts2;
	ExdTongJi exdtj;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if (AutoFlg==1)
		StPos=3;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Month=BCD_INT32(&Data[0]+StPos,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
	if (AutoFlg==1) TimeDecrease(&ts2,5,1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Year = BCD_INT32(&Data[1]+StPos,1)+2000;
	ts.Month=BCD_INT32(&Data[0]+StPos,1);
	//��������
	IsDataFlag=0;
	//if (AutoFlg==0) TimeAdd(&ts,5,1);//fzh
	memset(Temp_FilePath,0x00,60);

	sprintf((char *)Temp_FilePath,"/nand/DataYueTongJi/%04d/m%02d.dat",P,ts.Month);//,ts.Month);
	SdPrintf(YNPrint,PreFix,"Get_Level2Data_F60 Temp_FilePath=%s\n\r",Temp_FilePath);
	if (access((char*)Temp_FilePath, 0) == 0)
	{
		ReadFile((char *)Temp_FilePath,&exdtj,sizeof(ExdTongJi),Jproginfo);

		INT32U_BCD(exdtj.P_MAX,&SendBuff[SendIndex],2);
		SendIndex=SendIndex+2;
		memcpy(&SendBuff[SendIndex],&exdtj.P_MAX_TIME,3);
		SendIndex=SendIndex+3;
		INT32U_BCD(exdtj.P_MIN,&SendBuff[SendIndex],2);
		SendIndex=SendIndex+2;
		memcpy(&SendBuff[SendIndex],&exdtj.P_MIN_TIME,3);
		SendIndex=SendIndex+3;

		SendBuff[SendIndex++]=exdtj.P_Zero_Time&0xff;
		SendBuff[SendIndex++]=(exdtj.P_Zero_Time>>8)&0xff;
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,12);
		SendIndex=SendIndex+12;
	}
	return 2;
}

int Calculate_ZJ_GL(INT16U F,INT16U P,INT8U *Data,INT8U DI1,INT8U DI0,INT8U qflg)
{
	INT16U k,j,IsDataFlag,dftype,tmpindx,fd,ff;
	TS ts;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;

	INT8U Temp_FilePath[60],tempManyData[50];
	INT8U CJQno,MeterNo,MeterType,MeterFlgD6,MeterFlgD7,MulPointNum;//MulPointNum�ܼ�������������
	INT32S ResulttempManyData = 0,tmp=0,tmp2=0,tmp3=0;
	INT8U type2Msg[2],tmpmet,min;
	StPos=0;
	memset(type2Msg,0x00,2);

	MulPointNum= JSetPara_AFN04_3761_2009->group2.f14.Group[P-1].PointNum;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	memcpy(&SendBuff[SendIndex],&Data[0]+StPos,7);//�ն�������������ʱ��Td_d
	tmpindx=SendIndex;
	SendIndex=SendIndex+7;
	ts.Year=BCD_INT32(&Data[4]+StPos,1)+2000;
	ts.Month=BCD_INT32(&Data[3]+StPos,1);
	ts.Day=BCD_INT32(&Data[2]+StPos,1);
	ts.Hour=BCD_INT32(&Data[1]+StPos,1);
	ts.Minute=BCD_INT32(&Data[0]+StPos,1);
	ts.Sec=0;
	if (ts.Minute>=45)
		ts.Minute=45;
	else if (ts.Minute>=30)
		ts.Minute=30;
	else if (ts.Minute>=15)
		ts.Minute=15;
	else if (ts.Minute>=0)
		ts.Minute=0;

	IsDataFlag=0;
	LDType=2;
	if(MulPointNum==0)
	{
		SdPrintf(YNPrint,PreFix,"---no point--\n\r");
		//SendNAK(F,P,0x0d);
		return 7;
	}

	if (Data[5]==1)
		min=15;
	if (Data[5]==2)
		min=30;
	if (Data[5]==3)
		min=60;
	fd=0;
	for (k=0;k<Data[6];k++)
	{
		ff=1;
		ResulttempManyData = 0;
		tmp=0;
		for(j=0;j<MulPointNum;j++)
		{
			tmpmet=JSetPara_AFN04_3761_2009->group2.f14.Group[P-1].Index_Flag[j]&0x3f;//������ D0~D5
			MeterFlgD6=(JSetPara_AFN04_3761_2009->group2.f14.Group[P-1].Index_Flag[j]>>6)&0x01;//D6 0����1����
			MeterFlgD7=(JSetPara_AFN04_3761_2009->group2.f14.Group[P-1].Index_Flag[j]>>7)&0x01;//D7 0��1��
			MeterType=JSetPara_AFN04_3761_2009->group2.f10[tmpmet].Type;//������
			CJQno=JSetPara_AFN04_3761_2009->group2.f10[tmpmet].CjqNo-1;//�ɼ�����
			MeterNo=JSetPara_AFN04_3761_2009->group2.f10[tmpmet].MeterNo;
			IsDataFlag=0;
			memset(Temp_FilePath,0x00,60);
			sprintf((char *)Temp_FilePath,"/nand/DataHour/%04d%02d%02d/%04d/%04d%02d%02d%02d%02d.dat",
				ts.Year,ts.Month,ts.Day,tmpmet+1,ts.Year,ts.Month,ts.Day,ts.Hour,ts.Minute);
			if ((MeterType == 9) || (MeterType == 6))
			{
				dftype=1;//comm
			}
			else
			{
				dftype=1;
			}
			IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
			if(IsDataFlag==1)
			{
				IsDataFlag=getMetersData(MeterType,&tempManyData[0],CJQno,MeterNo,DI1,DI0,0,3,1,0,0,0,0,dftype);
				if (IsDataFlag == 0)
				{
					ff=0;
					break;
				}

				memcpy(&tmp2,&JSetPara_AFN04_3761_2009->Point[tmpmet].f25.V_BeiLv[0],2);
				memcpy(&tmp3,&JSetPara_AFN04_3761_2009->Point[tmpmet].f25.I_BeiLv[0],2);
				tmp=BCD_INT32(&tempManyData[0], 3)*tmp2*tmp3;
			}
			else
			{
				ff=0;
				break;
			}
			if(!MeterFlgD7)
			{
				ResulttempManyData+=tmp;
			}
			else
			{
				ResulttempManyData-=tmp;

			}
		}

		if (ff==1)
		{
			if (fd==0)
			{
				INT32U_BCD(ts.Minute,&SendBuff[tmpindx],1);
				INT32U_BCD(ts.Hour,&SendBuff[tmpindx+1],1);
				INT32U_BCD(ts.Day,&SendBuff[tmpindx+2],1);
				INT32U_BCD(ts.Month,&SendBuff[tmpindx+3],1);
				INT32U_BCD((ts.Year%100),&SendBuff[tmpindx+4],1);
				SendBuff[tmpindx+5]=3;
			}
			fd++;
		}
		else
		{
			if (fd>0)
			{
				memset(&SendBuff[SendIndex],OxXX,2);
				SendIndex=SendIndex+2;
				fd++;
			}
			TimeAdd(&ts,2,min);
			continue;
		}
		SdPrintf(YNPrint,PreFix,"\n\rtemm----3333\n\r");
		if (qflg==0)
			Double2TypeA2(ResulttempManyData, type2Msg);
		else
			Double2TypeA2(ResulttempManyData, type2Msg);
		memcpy(&SendBuff[SendIndex], &type2Msg[0], 2);
		SendIndex = SendIndex + 2;
		SdPrintf(YNPrint,PreFix,"\n\rtemm----4444\n\r");
		TimeAdd(&ts,2,min);
	}
	if(fd==0)
	{
		//SendNAK(F,P,0x0d);
		return 7;
	}
	else
	{
		SendBuff[tmpindx+6]=fd;
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 7;
}

INT16U Get_Level2Data_F73(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Calculate_ZJ_GL(F,P,Data,0xb6,0x30,0);
}
INT16U Get_Level2Data_F74(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Calculate_ZJ_GL(F,P,Data,0xb6,0x40,1);
}

int Calculate_ZJ_Elc(INT16U F,INT16U P,INT8U *Data,INT8U qflg)
{
	INT16U k,j,IsDataFlag,dftype,tmpindx,fd,ff;
	TS ts;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	INT8U Temp_FilePath[60],tempManyData[50];
	INT8U CJQno,MeterNo,MeterType,MeterFlgD6,MeterFlgD7,MulPointNum;//MulPointNum�ܼ�������������
	INT32S ResulttempManyData = 0,tmp=0,tmp2=0,tmp3=0;
	INT8U type2Msg[4],tmpmet,min;
	memset(type2Msg,0x00,4);
	StPos=0;

	MulPointNum=JSetPara_AFN04_3761_2009->group2.f14.Group[P-1].PointNum;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	memcpy(&SendBuff[SendIndex],&Data[0]+StPos,7);//�ն�������������ʱ��Td_d
	tmpindx=SendIndex;
	SendIndex=SendIndex+7;
	ts.Year=BCD_INT32(&Data[4]+StPos,1)+2000;
	ts.Month=BCD_INT32(&Data[3]+StPos,1);
	ts.Day=BCD_INT32(&Data[2]+StPos,1);
	ts.Hour=BCD_INT32(&Data[1]+StPos,1);
	ts.Minute=BCD_INT32(&Data[0]+StPos,1);
	ts.Sec=0;
	if (ts.Minute>=45)
		ts.Minute=45;
	else if (ts.Minute>=30)
		ts.Minute=30;
	else if (ts.Minute>=15)
		ts.Minute=15;
	else if (ts.Minute>=0)
		ts.Minute=0;
	IsDataFlag=0;
	LDType=2;
	if(MulPointNum==0)
	{
		//SendNAK(F,P,0x0d);
		return 7;
	}

	if (Data[5]==1)
		min=15;
	if (Data[5]==2)
		min=30;
	if (Data[5]==3)
		min=60;
	fd=0;
	for (k=0;k<Data[6];k++)
	{
		ff=1;
		ResulttempManyData = 0;
		tmp=0;
		for(j=0;j<MulPointNum;j++)
		{
			tmpmet=JSetPara_AFN04_3761_2009->group2.f14.Group[P-1].Index_Flag[j]&0x3f;//������ D0~D5
			MeterFlgD6=(JSetPara_AFN04_3761_2009->group2.f14.Group[P-1].Index_Flag[j]>>6)&0x01;//D6 0����1����
			MeterFlgD7=(JSetPara_AFN04_3761_2009->group2.f14.Group[P-1].Index_Flag[j]>>7)&0x01;//D7 0��1��
			SdPrintf(YNPrint,PreFix,"D6=%d,D7=%d\n\r",MeterFlgD6,MeterFlgD7);
			MeterType= JSetPara_AFN04_3761_2009->group2.f10[tmpmet].Type;//������
			CJQno=JSetPara_AFN04_3761_2009->group2.f10[tmpmet].CjqNo-1;//�ɼ�����
			MeterNo=JSetPara_AFN04_3761_2009->group2.f10[tmpmet].MeterNo;
			IsDataFlag=0;
			memset(Temp_FilePath,0x00,60);
			sprintf((char *)Temp_FilePath,"/nand/DataHour/%04d%02d%02d/%04d/%04d%02d%02d%02d%02d.dat",
				ts.Year,ts.Month,ts.Day,tmpmet+1,ts.Year,ts.Month,ts.Day,ts.Hour,ts.Minute);
			if ((MeterType == 9) || (MeterType == 6))
			{
				dftype=1;//comm
			}
			else
			{
				dftype=1;
			}

			IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
			if(IsDataFlag==1)
			{
				if (MeterFlgD6)
				IsDataFlag=getMetersData(MeterType,&tempManyData[0],CJQno,MeterNo,0x90+qflg,0x20,0,4,1,0,0,0,0,dftype);
				else
				IsDataFlag=getMetersData(MeterType,&tempManyData[0],CJQno,MeterNo,0x90+qflg,0x10,0,4,1,0,0,0,0,dftype);
				if (IsDataFlag == 0)
				{
					ff=0;
					break;
				}

				memcpy(&tmp2,&JSetPara_AFN04_3761_2009->Point[tmpmet].f25.V_BeiLv[0],2);
				memcpy(&tmp3,&JSetPara_AFN04_3761_2009->Point[tmpmet].f25.I_BeiLv[0],2);
				tmp=BCD_INT32(&tempManyData[0], 4)*tmp2*tmp3;
				SdPrintf(YNPrint,PreFix,"tmp1=%d\n\r",tmp);
			}
			else
			{
				ff=0;
				break;
			}

			if(!MeterFlgD7)
			{
				ResulttempManyData+=tmp;
			}
			else
			{
				ResulttempManyData-=tmp;
			}
		}

		SdPrintf(YNPrint,PreFix,"tmp3=%d\n\r",ResulttempManyData);
		ResulttempManyData=ResulttempManyData/100;
		if (ff==1)
		{
			if (fd==0)
			{
				INT32U_BCD(ts.Minute,&SendBuff[tmpindx],1);
				INT32U_BCD(ts.Hour,&SendBuff[tmpindx+1],1);
				INT32U_BCD(ts.Day,&SendBuff[tmpindx+2],1);
				INT32U_BCD(ts.Month,&SendBuff[tmpindx+3],1);
				INT32U_BCD((ts.Year%100),&SendBuff[tmpindx+4],1);
				SendBuff[tmpindx+5]=3;
			}
			fd++;
		}
		else
		{
			if (fd>0)
			{
				memset(&SendBuff[SendIndex],OxXX,4);
				SendIndex=SendIndex+4;
				fd++;
			}
			TimeAdd(&ts,2,min);
			continue;
		}
		if (ResulttempManyData>0)
		{
			if (ResulttempManyData>9999999)
			{
				SdPrintf(YNPrint,PreFix,"tmp4=%d\n\r",ResulttempManyData);
				ResulttempManyData=ResulttempManyData/1000;
				INT32U_BCD(ResulttempManyData,&type2Msg[0],4);
				type2Msg[3]=type2Msg[3]|0x40;
			}
			else
			{
				SdPrintf(YNPrint,PreFix,"tmp5=%d\n\r",ResulttempManyData);
				INT32U_BCD(ResulttempManyData,&type2Msg[0],4);
				type2Msg[3]=type2Msg[3]&0x0f;
			}
		}
		else
		{
			ResulttempManyData=ResulttempManyData*(-1);
			if (ResulttempManyData>9999999)
			{
				SdPrintf(YNPrint,PreFix,"tmp6=%d\n\r",ResulttempManyData);
				ResulttempManyData=ResulttempManyData/1000;
				INT32U_BCD(ResulttempManyData,&type2Msg[0],4);
				type2Msg[3]=type2Msg[3]|0x50;
			}
			else
			{
				SdPrintf(YNPrint,PreFix,"tmp7=%d\n\r",ResulttempManyData);
				INT32U_BCD(ResulttempManyData,&type2Msg[0],4);
				type2Msg[3]=type2Msg[3]|0x10;
			}
		}
		memcpy(&SendBuff[SendIndex], &type2Msg[0], 4);
		SendIndex = SendIndex + 4;
		TimeAdd(&ts,2,min);
	}
	if(fd==0)
	{
		//SendNAK(F,P,0x0d);
		return 7;
	}
	else
	{
		SendBuff[tmpindx+6]=fd;
	}
	return 7;
}

INT16U Get_Level2Data_F75(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Calculate_ZJ_Elc(F,P,Data,0);
}
INT16U Get_Level2Data_F76(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Calculate_ZJ_Elc(F,P,Data,1);
}
int getzhouqifenzhong()
{
	int zhouqi,danwei;
	int fenzhong;
	danwei = JSetPara_AFN04_3761_2009->group9.f66[Jproginfo->BeiYong[13]].Interval>>6;
	zhouqi = JSetPara_AFN04_3761_2009->group9.f66[Jproginfo->BeiYong[13]].Interval&0x3f;
	switch (danwei)
	{
	case 0://��
		fenzhong = zhouqi;
		break;
	case 1://Сʱ
		fenzhong = zhouqi*60;
		break;
	case 2://��
		fenzhong = zhouqi*60 *24;
		break;
	default:
		fenzhong = zhouqi*60;
		break;
	}
	return fenzhong;
}
INT8U getdian(int beilv, INT8U midu)//�����ȡ����
{//�������ڷ���������jiange�������������͵���
	int jiange, min=0;
	//���������ȡ���ʺ�Ĭ�϶����ܶ�15���ӣ���������jiange������
	if ((beilv<1) || (beilv>96))
		beilv = 2;
	if (midu==1)
		min=15;
	if (midu==2)
		min=30;
	if (midu==3)
		min=60;
	SdPrintf(YNPrint,PreFix,"midu %d  min %d taskno %d  beilv %d \n",midu, min, Jproginfo->BeiYong[13],JSetPara_AFN04_3761_2009->group9.f66[Jproginfo->BeiYong[13]].R);
	jiange = (beilv * min);
	return (getzhouqifenzhong() / jiange);
}
void Daotuiyigezhouqi(INT8U *nowtime,INT8U *timebuf)
{
	TS ts;
	TSGet(&ts);
	ts.Year = BCD_INT32(&nowtime[4],1)+2000;
	ts.Month= BCD_INT32(&nowtime[3],1);
	ts.Day = BCD_INT32(&nowtime[2],1);
	ts.Hour = BCD_INT32(&nowtime[1],1);
	ts.Minute = BCD_INT32(&nowtime[0],1);
	SdPrintf(YNPrint,PreFix,"ts  %d-%d-%d %d:%d   %d", ts.Year,ts.Month, ts.Day, ts.Hour, ts.Minute,
			getzhouqifenzhong());
	TimeDecrease(&ts, 2, getzhouqifenzhong());
//	if(JSetPara_AFN04_3761_2009->group9.f66[Jproginfo->BeiYong[13]].R == 2)
	{
		if(ts.Minute>0 && ts.Minute<=30)
			ts.Minute = 30;
		else
		{
			TimeAdd(&ts, 3, 1);
			ts.Minute = 0;
		}
	}

	INT32U_BCD(ts.Minute, &timebuf[0], 1);
	INT32U_BCD(ts.Hour, &timebuf[1], 1);
	INT32U_BCD(ts.Day, &timebuf[2], 1);
	INT32U_BCD(ts.Month, &timebuf[3], 1);
	INT32U_BCD(ts.Year, &timebuf[4], 1);
	SdPrintf(YNPrint,PreFix,"timebuf  %02x-%02x-%02x %02x:%02x", timebuf[4],timebuf[3],timebuf[2],timebuf[1],timebuf[0]);
	return;
}
int Stat_day_Curve(INT16U F,INT16U P,INT8U *Data,INT8U DI1,INT8U DI0,INT8U beg,INT8U size,INT8U DIN,INT8U BeX)
{
	INT16U i,k,IsDataFlag,dftype,bg,tmpindx=0,fd,min=15;
	TS ts;
	INT16U ifjiaocai=0;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	INT8U Temp_FilePath[60],tempManyData[50];
	INT8U CJQno,MeterNo,MeterType;
	StPos=0;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	ifjiaocai = JSetPara_AFN04_3761_2009->group2.f10[P-1].ConnectType ;

	INT8U daotuiTime[5];
	INT8U beilv = 0;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	if(AutoFlg==1)
	{
		beilv= JSetPara_AFN04_3761_2009->group9.f66[Jproginfo->BeiYong[13]].R;
		memset(daotuiTime, 0, 5);
		Daotuiyigezhouqi(Data, daotuiTime);//&SendBuff[SendIndex]);
		tmpindx=SendIndex;
		SendBuff[SendIndex++] = daotuiTime[0];
		SendBuff[SendIndex++] = daotuiTime[1];
		SendBuff[SendIndex++] = daotuiTime[2];
		SendBuff[SendIndex++] = daotuiTime[3];
		SendBuff[SendIndex++] = daotuiTime[4];
		//memcpy(&SendBuff[SendIndex],&Data[0]+StPos,5);
		SdPrintf(YNPrint,PreFix,"Data[5] =%d beilv=%d  %d\n",Data[5],beilv,JSetPara_AFN04_3761_2009->group9.f66[Jproginfo->BeiYong[13]].R);
		Data[5] = 1;
		SendBuff[SendIndex++] = JSetPara_AFN04_3761_2009->group9.f66[Jproginfo->BeiYong[13]].R;//midu
		Data[6] =  getdian(beilv,Data[5]);
		SendBuff[SendIndex++] = Data[6];
		ts.Year=BCD_INT32(&daotuiTime[4],1)+2000;
		ts.Month=BCD_INT32(&daotuiTime[3],1);
		ts.Day=BCD_INT32(&daotuiTime[2],1);
		ts.Hour=BCD_INT32(&daotuiTime[1],1);
		ts.Minute=BCD_INT32(&daotuiTime[0],1);
	}else
	{
		beilv = 1;
		memcpy(&SendBuff[SendIndex],&Data[0]+StPos,7);//�ն�������������ʱ��Td_d
		tmpindx=SendIndex;
		SendIndex=SendIndex+7;
		ts.Year=BCD_INT32(&Data[4]+StPos,1)+2000;
		ts.Month=BCD_INT32(&Data[3]+StPos,1);
		ts.Day=BCD_INT32(&Data[2]+StPos,1);
		ts.Hour=BCD_INT32(&Data[1]+StPos,1);
		ts.Minute=BCD_INT32(&Data[0]+StPos,1);
	}

	ts.Sec=0;
	if (ts.Minute>=45)
		ts.Minute=45;
	else if (ts.Minute>=30)
		ts.Minute=30;
	else if (ts.Minute>=15)
		ts.Minute=15;
	else if (ts.Minute>=0)
		ts.Minute=0;
	if (Data[5]==1)
		min=15;
	if (Data[5]==2)
		min=30;
	if (Data[5]==3)
		min=60;
	fd=0;
	for (k=0;k<Data[6];k++)
	{
		IsDataFlag=0;
		memset(Temp_FilePath,0,60);
		sprintf((char *)Temp_FilePath,"/nand/DataHour/%04d%02d%02d/%04d/%04d%02d%02d%02d%02d.dat",
			ts.Year,ts.Month,ts.Day,P,ts.Year,ts.Month,ts.Day,ts.Hour,ts.Minute);
		SdPrintf(YNPrint,PreFix,"���������ļ�%d=%s",k,Temp_FilePath);
		if((MeterType==9)|| (MeterType==6))
		{
			dftype=1;//comm
			bg=0;
		}
		else
		{
			dftype=1;
			bg=beg;
		}
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);//��ȡ�ļ� �洢��ȫ�ֱ��� smfile ��
		if(IsDataFlag==1)
		{//ָ���ļ���ȡ�ɹ�
			SdPrintf(YNPrint,PreFix,"-----------�ļ���ȡ�ɹ�\n");
			IsDataFlag=getMetersData(MeterType,&tempManyData[0],CJQno,MeterNo,DI1,DI0,bg,size,DIN,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{//������û���ҵ�����
				SdPrintf(YNPrint,PreFix,"������û�ҵ��� ��%02x %02x��",DI1,DI0);
				if (fd>0)
				{
					if (ifjiaocai == 2)
					{
						for(i=0;i<BeX;i++)
							SendBuff[SendIndex++]=0x00;
						memset(&SendBuff[SendIndex],0x00,size);
					}else
					{
						for(i=0;i<BeX;i++)
							SendBuff[SendIndex++]=OxXX;
						memset(&SendBuff[SendIndex],OxXX,size);
					}
					SendIndex=SendIndex+size;
					fd++;
				}
			}
			if (fd==0)
			{
				SdPrintf(YNPrint,PreFix,"tmpindx == %d\n", tmpindx);
				INT32U_BCD(ts.Minute,&SendBuff[tmpindx],1);
				INT32U_BCD(ts.Hour,&SendBuff[tmpindx+1],1);
				INT32U_BCD(ts.Day,&SendBuff[tmpindx+2],1);
				INT32U_BCD(ts.Month,&SendBuff[tmpindx+3],1);
				INT32U_BCD((ts.Year%100),&SendBuff[tmpindx+4],1);
				if(AutoFlg==0)
					SendBuff[tmpindx+5]=Data[5];
				else
					SendBuff[tmpindx+5]=JSetPara_AFN04_3761_2009->group9.f66[Jproginfo->BeiYong[13]].R;//Data[5];
			}
			fd++;
			for(i=0;i<BeX;i++)
				SendBuff[SendIndex++]=0x00;
			memcpy(&SendBuff[SendIndex],&tempManyData[0],size);
			SendIndex=SendIndex+size;
		}
		else
		{//�ļ���ȡʧ��
			SdPrintf(YNPrint,PreFix,"-----------�ļ���ȡʧ��\n");
//			if (fd>0)
			{
				if (ifjiaocai==2)
				{
					for(i=0;i<BeX;i++)
						SendBuff[SendIndex++]=0x00;
					memset(&SendBuff[SendIndex],0x00,size);
					SendIndex=SendIndex+size;
				}else
				{
					for(i=0;i<BeX;i++)
						SendBuff[SendIndex++]=OxXX;
					memset(&SendBuff[SendIndex],OxXX,size);
					SendIndex=SendIndex+size;
				}

				fd++;
			}
		}
		TimeAdd(&ts,2,min*beilv);
	}
	if (fd==0)
	{
		for(i=0;i<BeX;i++)
			SendBuff[SendIndex++]=OxXX;
		memset(&SendBuff[SendIndex],OxXX,size*Data[6]);
		SendIndex=SendIndex+size*Data[6];
		return 7;
	}
	else
	{
		if(AutoFlg==0)
		{
			SdPrintf(YNPrint,PreFix,"AutoFlg==0  fd=%d  tmpindx=%d\n",fd,tmpindx);
			SendBuff[tmpindx+6]=fd;
		}
	}
	return 7;
}


INT16U Get_Level2Data_F81(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve(F,P,Data,0xb6,0x30,0,3,1,0);
}
INT16U Get_Level2Data_F82(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve(F,P,Data,0xb6,0x31,3,3,1,0);
}
INT16U Get_Level2Data_F83(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve(F,P,Data,0xb6,0x32,6,3,1,0);
}
INT16U Get_Level2Data_F84(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve(F,P,Data,0xb6,0x33,9,3,1,0);
}
INT16U Get_Level2Data_F85(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve(F,P,Data,0xb6,0x40,0,3,1,0);
}
INT16U Get_Level2Data_F86(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve(F,P,Data,0xb6,0x41,3,3,1,0);
}
INT16U Get_Level2Data_F87(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve(F,P,Data,0xb6,0x42,6,3,1,0);
}
INT16U Get_Level2Data_F88(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve(F,P,Data,0xb6,0x43,9,3,1,0);
}
INT16U Get_Level2Data_F89(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve(F,P,Data,0xb6,0x11,0,2,1,0);
}
INT16U Get_Level2Data_F90(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve(F,P,Data,0xb6,0x12,2,2,1,0);
}
INT16U Get_Level2Data_F91(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve(F,P,Data,0xb6,0x13,4,2,1,0);
}
INT16U Get_Level2Data_F92(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve(F,P,Data,0xb6,0x21,0,3,1,0);
}
INT16U Get_Level2Data_F93(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve(F,P,Data,0xb6,0x22,3,3,1,0);
}
INT16U Get_Level2Data_F94(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve(F,P,Data,0xb6,0x23,6,3,1,0);
}
INT16U Get_Level2Data_F95(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve(F,P,Data,0xb6,0x24,0,3,1,0);
}
int Stat_day_Elc_Curve(INT16U F,INT16U P,INT8U *Data,INT8U DI1,INT8U DI0,INT8U size,INT8U DIN,INT8U BeX)		//9.24 �����й��ܵ���������
{
	INT16U i,k,IsDataFlag,dftype,tmpindx=0,min=15;
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	INT8U Temp_FilePath[60],tempManyData[50],tempData[50];
	INT8U CJQno,MeterNo,MeterType;
	StPos=0;
	INT32S tmp=0,tmp1=0,tmp2=0,tmp3=0,result=0;
	int data1_flg=0,data2_flg=0;
	INT8U daotuiTime[5];
	INT8U beilv = 0;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	if(AutoFlg==1)
	{
		beilv= JSetPara_AFN04_3761_2009->group9.f66[Jproginfo->BeiYong[13]].R;
		memset(daotuiTime, 0, 5);
		Daotuiyigezhouqi(Data,daotuiTime);//&SendBuff[SendIndex]);
		tmpindx=SendIndex;
		SendBuff[SendIndex++] = daotuiTime[0];
		SendBuff[SendIndex++] = daotuiTime[1];
		SendBuff[SendIndex++] = daotuiTime[2];
		SendBuff[SendIndex++] = daotuiTime[3];
		SendBuff[SendIndex++] = daotuiTime[4];
		//memcpy(&SendBuff[SendIndex],&Data[0]+StPos,5);
		SdPrintf(YNPrint,PreFix,"Data[5] =%d\n",Data[5]);
		Data[5] = 1;
		SendBuff[SendIndex++] = JSetPara_AFN04_3761_2009->group9.f66[Jproginfo->BeiYong[13]].R;//midu
		Data[6] =  getdian(beilv,Data[5]);
		SendBuff[SendIndex++] = Data[6];
		ts.Year=BCD_INT32(&daotuiTime[4],1)+2000;
		ts.Month=BCD_INT32(&daotuiTime[3],1);
		ts.Day=BCD_INT32(&daotuiTime[2],1);
		ts.Hour=BCD_INT32(&daotuiTime[1],1);
		ts.Minute=BCD_INT32(&daotuiTime[0],1);
	}else
	{
		beilv = 1;
		memcpy(&SendBuff[SendIndex],&Data[0]+StPos,7);//�ն�������������ʱ��Td_d
		tmpindx=SendIndex;
		SendIndex=SendIndex+7;
		ts.Year=BCD_INT32(&Data[4]+StPos,1)+2000;
		ts.Month=BCD_INT32(&Data[3]+StPos,1);
		ts.Day=BCD_INT32(&Data[2]+StPos,1);
		ts.Hour=BCD_INT32(&Data[1]+StPos,1);
		ts.Minute=BCD_INT32(&Data[0]+StPos,1);
		if(Data[6]<0 || Data[6]>96)
			Data[6] = 4;
	}
	ts.Sec=0;
	dftype = 1;
	LDType=2;
	if (ts.Minute>=45)
		ts.Minute=45;
	else if (ts.Minute>=30)
		ts.Minute=30;
	else if (ts.Minute>=15)
		ts.Minute=15;
	else if (ts.Minute>=0)
		ts.Minute=0;
	ts2 = ts;
	TimeAdd(&ts2,2,min);
	if (Data[5]==1)
		min=15;
	if (Data[5]==2)
		min=30;
	if (Data[5]==3)
		min=60;

	for (k=0;k<Data[6];k++)
	{
		data1_flg = 0;
		data2_flg = 0;
		IsDataFlag=0;
		memset(Temp_FilePath,0,60);
		sprintf((char *)Temp_FilePath,"/nand/DataHour/%04d%02d%02d/%04d/%04d%02d%02d%02d%02d.dat",
			ts.Year,ts.Month,ts.Day,P,ts.Year,ts.Month,ts.Day,ts.Hour,ts.Minute);

		SdPrintf(YNPrint,PreFix, "  F97,F98����1��DataHour:Temp_FilePath=%s\n\r",Temp_FilePath);
		dftype=1;//comm
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
		if(IsDataFlag==1)
		{
			IsDataFlag=getMetersData(MeterType,&tempManyData[0],CJQno,MeterNo,DI1,DI0,0,size,DIN,0,0,0,0,dftype);
			if (IsDataFlag == 1)
			{
				data1_flg = 1;
				memcpy(&tmp2,&JSetPara_AFN04_3761_2009->Point[P-1].f25.V_BeiLv[0],2);
				memcpy(&tmp3,&JSetPara_AFN04_3761_2009->Point[P-1].f25.I_BeiLv[0],2);
				tmp=BCD_INT32(&tempManyData[0], size)*tmp2*tmp3;
			}else
			{
				data1_flg = 0;
				tmp = 0;
				tmp2 = 0;
				tmp3 = 0;
			}
		}

		IsDataFlag=0;
		sprintf((char *)Temp_FilePath,"/nand/DataHour/%04d%02d%02d/%04d/%04d%02d%02d%02d%02d.dat",
				ts2.Year,ts2.Month,ts2.Day,P,ts2.Year,ts2.Month,ts2.Day,ts2.Hour,ts2.Minute);
		SdPrintf(YNPrint,PreFix, "  F97,F98����2��DataHour:Temp_FilePath=%s\n\r",Temp_FilePath);

		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
		if(IsDataFlag==1)
		{
			IsDataFlag=getMetersData(MeterType,&tempManyData[0],CJQno,MeterNo,DI1,DI0,0,size,DIN,0,0,0,0,dftype);
			if (IsDataFlag == 1)
			{
				data2_flg = 1;
				memcpy(&tmp2,&JSetPara_AFN04_3761_2009->Point[P-1].f25.V_BeiLv[0],2);
				memcpy(&tmp3,&JSetPara_AFN04_3761_2009->Point[P-1].f25.I_BeiLv[0],2);
				tmp1 = BCD_INT32(&tempManyData[0], size)*tmp2*tmp3;
			}else
			{
				data2_flg = 0;
				tmp1 = 0;
				tmp2 = 0;
				tmp3 = 0;
			}
		}


		memset(tempData, 0, 50);
		if(data1_flg == 1 && data2_flg == 1)
		{
			result=tmp1-tmp;
			if (result<0)
				result=result*(-1);
		}else
			result = 0;
		for(i=0;i<BeX;i++)
			SendBuff[SendIndex++]=0x00;
		INT32U_BCD(result, &tempData[0], size);
		memcpy(&SendBuff[SendIndex],&tempData[0],size);
		SendIndex=SendIndex+size;
		TimeAdd(&ts,2,min*beilv);
		TimeAdd(&ts2,2,min*beilv);
	}
	return 7;
}

INT16U Get_Level2Data_F97(INT8U Set,INT16U F,INT16U P,INT8U *Data)//�����������й��ܵ���������
{
	return Stat_day_Elc_Curve(F,P,Data,0x90,0x10,4,1,0);
}
INT16U Get_Level2Data_F98(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Elc_Curve(F,P,Data,0x91,0x10,4,1,0);
}

INT16U Get_Level2Data_F99(INT8U Set,INT16U F,INT16U P,INT8U *Data)//�����㷴���й��ܵ���������
{
	return Stat_day_Elc_Curve(F,P,Data,0x90,0x20,4,1,0);
}
INT16U Get_Level2Data_F100(INT8U Set,INT16U F,INT16U P,INT8U *Data)//�����㷴���޹��ܵ���������
{
	return Stat_day_Elc_Curve(F,P,Data,0x91,0x20,4,1,0);
}
INT16U Get_Level2Data_F101(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve(F,P,Data,0x90,0x10,0,4,1,0);
}
INT16U Get_Level2Data_F102(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve(F,P,Data,0x91,0x10,0,4,1,0);
}
INT16U Get_Level2Data_F103(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve(F,P,Data,0x90,0x20,0,4,1,0);
}
INT16U Get_Level2Data_F104(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve(F,P,Data,0x91,0x20,0,4,1,0);
}
INT16U Get_Level2Data_F105(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve(F,P,Data,0xb6,0x50,0,2,1,0);
}
INT16U Get_Level2Data_F106(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve(F,P,Data,0xb6,0x51,2,2,1,0);
}
INT16U Get_Level2Data_F107(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve(F,P,Data,0xb6,0x52,4,2,1,0);
}
INT16U Get_Level2Data_F108(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve(F,P,Data,0xb6,0x53,6,2,1,0);
}
INT8U *INT32ToBCD(INT32S S, INT8U *D, INT8U len) {
	INT8U i;
	INT32S Temp;
	INT16U j = 1;
	Temp = abs(S);
	for (i = 0; i < len; i++) {
		j = Temp % 100;
		D[i] = (j / 10);
		D[i] = (D[i] << 4) + (j % 10);
		Temp = Temp / 100;
	}
	if (S < 0) {
		D[len - 1] = D[len - 1] | 0x80;
	}
	return D;
}
INT16U Get_Level2Data_F121(INT8U Set,INT16U F,INT16U P,INT8U *Data)//�ն��������A��г��Խ��ͳ������
{
	TS ts,ts2;
	INT8U ret;
	INT8U j;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;

	INT8U Temp_FilePath[60];
	StPos=0;
	if (AutoFlg==1)
		StPos=2;
	//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Year = BCD_INT32(&Data[2]+StPos,1)+2000;
	ts.Month=BCD_INT32(&Data[1]+StPos,1);
	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	if (AutoFlg==0) TimeAdd(&ts,4,1);

	SendBuff[SendIndex++]=19;
	sprintf((char *)Temp_FilePath,"/nand/save/xbday%02x%02x.dat",ts.Month,ts.Day);
	ret=ReadFile((char*)Temp_FilePath,
			(char *) &Jdatafileinfo->jc.xiebo.XieBo_QuXian,
			sizeof(Jdatafileinfo->jc.xiebo.XieBo_QuXian),Jproginfo);

	SendBuff[SendIndex++]=Jdatafileinfo->jc.xiebo.XieBo_QuXian.U_ZongJiBian_UCount;
	for(j=2;j<20;j++)
	{
		INT32ToBCD(Jdatafileinfo->jc.xiebo.XieBo_QuXian.U_GeCi_UCount[j],&SendBuff[SendIndex],2);
		SendIndex=SendIndex+2;
	}

	SendBuff[SendIndex++]=Jdatafileinfo->jc.xiebo.XieBo_QuXian.U_ZongJiBian_ICount;
	for(j=2;j<20;j++)
	{
		memcpy(&SendBuff[SendIndex],&Jdatafileinfo->jc.xiebo.XieBo_QuXian.U_GeCi_ICount[j],2);
		SendIndex=SendIndex+2;
	}
	return 1;
}
INT16U Get_Level2Data_F122(INT8U Set,INT16U F,INT16U P,INT8U *Data)//�ն��������B��г��Խ��ͳ������
{
	TS ts,ts2;
	INT8U ret;
	INT8U j;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;

	INT8U Temp_FilePath[60];
	StPos=0;
	if (AutoFlg==1)
		StPos=2;
	//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Year = BCD_INT32(&Data[2]+StPos,1)+2000;
	ts.Month=BCD_INT32(&Data[1]+StPos,1);
	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	if (AutoFlg==0) TimeAdd(&ts,4,1);

	SendBuff[SendIndex++]=19;
	sprintf((char *)Temp_FilePath,"/nand/save/xbday%02x%02x.dat",ts.Month,ts.Day);
	ret=ReadFile((char*)Temp_FilePath,
			(char *) &Jdatafileinfo->jc.xiebo.XieBo_QuXian,
			sizeof(Jdatafileinfo->jc.xiebo.XieBo_QuXian),Jproginfo);

	SendBuff[SendIndex++]=Jdatafileinfo->jc.xiebo.XieBo_QuXian.V_ZongJiBian_UCount;
	for(j=2;j<20;j++)
	{
		INT32ToBCD(Jdatafileinfo->jc.xiebo.XieBo_QuXian.V_GeCi_UCount[j],&SendBuff[SendIndex],2);
		SendIndex=SendIndex+2;
	}

	SendBuff[SendIndex++]=Jdatafileinfo->jc.xiebo.XieBo_QuXian.V_ZongJiBian_ICount;
	for(j=2;j<20;j++)
	{
		memcpy(&SendBuff[SendIndex],&Jdatafileinfo->jc.xiebo.XieBo_QuXian.V_GeCi_ICount[j],2);
		SendIndex=SendIndex+2;
	}
	return 1;
}
INT16U Get_Level2Data_F123(INT8U Set,INT16U F,INT16U P,INT8U *Data)//�ն��������C��г��Խ��ͳ������
{
	TS ts,ts2;
	INT8U ret;
	INT8U j;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;

	INT8U Temp_FilePath[60];
	StPos=0;
	if (AutoFlg==1)
		StPos=2;
	//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Year = BCD_INT32(&Data[2]+StPos,1)+2000;
	ts.Month=BCD_INT32(&Data[1]+StPos,1);
	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	if (AutoFlg==0) TimeAdd(&ts,4,1);

	SendBuff[SendIndex++]=19;
	sprintf((char *)Temp_FilePath,"/nand/save/xbday%02x%02x.dat",ts.Month,ts.Day);
	ret=ReadFile((char*)Temp_FilePath,
			(char *) &Jdatafileinfo->jc.xiebo.XieBo_QuXian,
			sizeof(Jdatafileinfo->jc.xiebo.XieBo_QuXian),Jproginfo);

	SendBuff[SendIndex++]=Jdatafileinfo->jc.xiebo.XieBo_QuXian.W_ZongJiBian_UCount;
	for(j=2;j<20;j++)
	{
		INT32ToBCD(Jdatafileinfo->jc.xiebo.XieBo_QuXian.W_GeCi_UCount[j],&SendBuff[SendIndex],2);
		SendIndex=SendIndex+2;
	}

	SendBuff[SendIndex++]=Jdatafileinfo->jc.xiebo.XieBo_QuXian.W_ZongJiBian_ICount;
	for(j=2;j<20;j++)
	{
		memcpy(&SendBuff[SendIndex],&Jdatafileinfo->jc.xiebo.XieBo_QuXian.W_GeCi_ICount[j],2);
		SendIndex=SendIndex+2;
	}
	return 1;
}
INT16U Get_Level2Data_F109(INT8U Set,INT16U F,INT16U P,INT8U *Data)//�������ѹ��λ������
{
	return Stat_day_Curve(F,P,Data,0x00,0x2F,0,6,1,0);
}
INT16U Get_Level2Data_F110(INT8U Set,INT16U F,INT16U P,INT8U *Data)//�����������λ������
{
	return Stat_day_Curve(F,P,Data,0x00,0x0F,0,6,1,0);
}

INT16U Get_Level2Data_F194(INT8U Set,INT16U F,INT16U P,INT8U *Data)//�¶��������޹��������������ʱ�䣨�ܣ����ʣ�
{
	INT16U IsDataFlag,j,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
	INT8U ReadFailFlag;
    TS ts,ts2,ts3,ts4,ts5;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	ts3=ts;
	ts4=ts;
	ts5=ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=3;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	dftype=1;
	ReadFailFlag=1;

	if(ReadFailFlag) {
		ts2.Month=BCD_INT32(&Data[0]+StPos,1);
		ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==1) TimeDecrease(&ts2,5,1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		ts.Month=BCD_INT32(&Data[0]+StPos,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==0) TimeAdd(&ts,5,1);
		if((zone_so&0x7f) == JIANGSU)
		{
			SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
			SendBuff[SendIndex++]=0x23;
			SendBuff[SendIndex++]=0x01;
			INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
			SendBuff[SendIndex++]=FeiLvNum;
		}
		else{

			SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
			SendBuff[SendIndex++]=0;
			SendBuff[SendIndex++]=0x01;
			INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
			SendBuff[SendIndex++]=FeiLvNum;
		}
		//��ȡ������
		IsDataFlag=0;
		memset(Temp_FilePath,0x00,60);
		sprintf((char *)Temp_FilePath,"/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
		SdPrintf(YNPrint,PreFix,"F193 ���ļ�2�� %s\n", Temp_FilePath);
		IsDataFlag=getMeterFile(MeterType,(char *)Temp_FilePath,ts,3);
		if ((MeterType == 9) || (MeterType == 6))
		{
			dftype=1;//comm
		}
		else
		{
			dftype=1;
		}
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
		if(IsDataFlag==1)
		{
			for(j=0;j<5;j++)
			{
				IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa1,0x10,j*3,3,1,0,0,0,0,dftype);
				if (IsDataFlag == 0)
				{
					memset(&SendBuff[SendIndex],OxXX,7);
					SendIndex=SendIndex+7;
					//SendNAK(F, P, 0x0d);
					//return 3;
				}
				else
				{
					SendIndex = SendIndex + 3;
					IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb1,0x10,j*4,4,1,0,0,0,0,dftype);
					SendIndex = SendIndex + 4;
				}
			}
		}
		else
		{
			memset(&SendBuff[SendIndex],0x00,35);/////////////////lcy
			SendIndex=SendIndex+35;
		}
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 2;
}

INT16U Get_Level2Data_F196(INT8U Set,INT16U F,INT16U P,INT8U *Data)	//�¶��ᷴ���޹��������������ʱ��
{
	INT16U IsDataFlag,j,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
	INT8U ReadFailFlag;
    TS ts,ts2,ts3,ts4,ts5;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	ts3=ts;
	ts4=ts;
	ts5=ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=3;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	dftype=1;
	ReadFailFlag=1;

	if(ReadFailFlag) {
		ts2.Month=BCD_INT32(&Data[0]+StPos,1);
		ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==1) TimeDecrease(&ts2,5,1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		ts.Month=BCD_INT32(&Data[0]+StPos,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==0) TimeAdd(&ts,5,1);
		if((zone_so&0x7f) == JIANGSU)
		{
			SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
			SendBuff[SendIndex++]=0x23;
			SendBuff[SendIndex++]=0x01;
			INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
			SendBuff[SendIndex++]=FeiLvNum;
		}
		else{

			SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
			SendBuff[SendIndex++]=0;
			SendBuff[SendIndex++]=0x01;
			INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
			SendBuff[SendIndex++]=FeiLvNum;
		}
		//��ȡ������
		IsDataFlag=0;
		memset(Temp_FilePath,0x00,60);
		sprintf((char *)Temp_FilePath,"/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
		SdPrintf(YNPrint,PreFix,"F193 ���ļ�2�� %s\n", Temp_FilePath);
		IsDataFlag=getMeterFile(MeterType,(char *)Temp_FilePath,ts,3);
		if ((MeterType == 9) || (MeterType == 6))
		{
			dftype=1;//comm
		}
		else
		{
			dftype=1;
		}
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
		if(IsDataFlag==1)
		{
			for(j=0;j<5;j++)
			{
				IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa1,0x20,j*3,3,1,0,0,0,0,dftype);
				if (IsDataFlag == 0)
				{
					memset(&SendBuff[SendIndex],OxXX,7);
					SendIndex=SendIndex+7;
					//SendNAK(F, P, 0x0d);
					//return 3;
				}
				else
				{
					SendIndex = SendIndex + 3;
					IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb1,0x20,j*4,4,1,0,0,0,0,dftype);
					SendIndex = SendIndex + 4;
				}
			}
		}
		else
		{
			memset(&SendBuff[SendIndex],0x00,35);////////////////lcy
			SendIndex=SendIndex+35;
		}
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 2;
}




INT16U Get_Level2Data_F209(INT8U Set,INT16U F,INT16U P,INT8U *Data)//�ն�����ܱ�Զ�̿���״̬����Ϣ
{
	INT16U dftype;
	INT8U CJQno,MeterNo,MeterType;
	TS ts,ts2;

	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;

	dftype=1;


	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong
	if((zone_so&0x7f) == JIANGSU)
	{
		SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
		SendBuff[SendIndex++]=0x23;
		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	}
	else{

		SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
		SendBuff[SendIndex++]=0;
		INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);

	}
	SendBuff[SendIndex++]=0x11;
	memset(&SendBuff[SendIndex],0,10);
	SendIndex=SendIndex+10;
	return 3;
}
INT16U Get_Level2Data_F145(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve(F,P,Data,0x91,0x30,0,4,1,0);
}
INT16U Get_Level2Data_F146(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve(F,P,Data,0x91,0x40,0,4,1,0);
}
INT16U Get_Level2Data_F147(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve(F,P,Data,0x91,0x50,0,4,1,0);
}
INT16U Get_Level2Data_F148(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	return Stat_day_Curve(F,P,Data,0x91,0x60,0,4,1,0);
}

INT16U Get_Level2Data_F153(INT8U Set,INT16U F,INT16U P,INT8U *Data)//9��15�ո�
{
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==0) TimeAdd(&ts,4,1);
	if((zone_so&0x7f) == JIANGSU)
	{
		SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
		SendBuff[SendIndex++]=0x23;
		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	}
	else{

		SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
		SendBuff[SendIndex++]=0;
		INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
	}
	//��ȡ������
	IsDataFlag=0;
	memset(Temp_FilePath,0x00,60);

	sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
	dftype=1;//comm
	SdPrintf(YNPrint,PreFix, "F153:Temp_FilePath=%s\n",Temp_FilePath);
	SdPrintf(YNPrint,PreFix,"get153 begin\n\r");
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
	SdPrintf(YNPrint,PreFix, "F153:Temp_FilePath=%s,IsDataFlag=%d\n",Temp_FilePath,IsDataFlag);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xFF,0xC0,0,4,1,1,0,0,0,dftype);
		SdPrintf(YNPrint,PreFix, "F153:IsDataFlag_c0=%d\n",IsDataFlag);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,5);
		}
		SendIndex=SendIndex+5;
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xFF,0xC4,0,4,1,1,0,0,0,dftype);
		SdPrintf(YNPrint,PreFix, "F153:IsDataFlag_c4=%d\n",IsDataFlag);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,5);
		}
		SendIndex=SendIndex+5;
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xFF,0xC8,0,4,1,1,0,0,0,dftype);
		SdPrintf(YNPrint,PreFix, "F153:IsDataFlag_c8=%d\n",IsDataFlag);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,5);
		}
		SendIndex=SendIndex+5;
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,15);
		SendIndex=SendIndex+15;
		//SendNAK(F, P, 0x0d);
		//return 3;
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	SdPrintf(YNPrint,PreFix, "F153:SendIndex=%d\n",SendIndex);
	return 3;
}
INT16U Get_Level2Data_F154(INT8U Set,INT16U F,INT16U P,INT8U *Data)//9��15�ո�
{
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==0) TimeAdd(&ts,4,1);
	if((zone_so&0x7f) == JIANGSU)
	{
		SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
		SendBuff[SendIndex++]=0x23;
		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	}
	else{

		SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
		SendBuff[SendIndex++]=0;
		INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
	}
	//��ȡ������
	IsDataFlag=0;
	memset(Temp_FilePath,0x00,60);

	sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
	dftype=1;//comm
	SdPrintf(YNPrint,PreFix,"get153 begin\n\r");
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xFF,0xC2,0,4,1,0,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,4);
		}
		SendIndex=SendIndex+4;
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xFF,0xC6,0,4,1,0,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,4);
		}
		SendIndex=SendIndex+4;
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xFF,0xCA,0,4,1,0,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,4);
		}
		SendIndex=SendIndex+4;

	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,12);
		SendIndex=SendIndex+12;
		//SendNAK(F, P, 0x0d);
		//return 3;
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 3;
}
INT16U Get_Level2Data_F155(INT8U Set,INT16U F,INT16U P,INT8U *Data)//9��15�ո�
{
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==0) TimeAdd(&ts,4,1);
	if((zone_so&0x7f) == JIANGSU)
	{
		SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
		SendBuff[SendIndex++]=0x23;
		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	}
	else{

		SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
		SendBuff[SendIndex++]=0;
		INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
	}
	//��ȡ������
	IsDataFlag=0;
	memset(Temp_FilePath,0x00,60);

	sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
	dftype=1;//comm
	SdPrintf(YNPrint,PreFix,"get153 begin\n\r");
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xFF,0xC1,0,4,1,1,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,5);

		}
		SendIndex=SendIndex+5;
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xFF,0xC5,0,4,1,1,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,5);

		}
		SendIndex=SendIndex+5;
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xFF,0xC9,0,4,1,1,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,5);

		}
		SendIndex=SendIndex+5;

	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,15);
		SendIndex=SendIndex+15;
		//SendNAK(F, P, 0x0d);
		//return 3;
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 3;
}
INT16U Get_Level2Data_F156(INT8U Set,INT16U F,INT16U P,INT8U *Data)//9��15�ո�
{
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==0) TimeAdd(&ts,4,1);
	if((zone_so&0x7f) == JIANGSU)
	{
		SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
		SendBuff[SendIndex++]=0x23;
		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	}
	else{

		SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
		SendBuff[SendIndex++]=0;
		INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
	}
	//��ȡ������
	IsDataFlag=0;
	memset(Temp_FilePath,0x00,60);

	sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
	dftype=1;//comm
	SdPrintf(YNPrint,PreFix,"get153 begin\n\r");
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xFF,0xC3,0,4,1,0,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,4);

		}
		SendIndex=SendIndex+4;
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xFF,0xC7,0,4,1,0,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,4);

		}
		SendIndex=SendIndex+4;
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xFF,0xCB,0,4,1,0,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,4);

		}
		SendIndex=SendIndex+4;

	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,12);
		SendIndex=SendIndex+12;
	}
	return 3;
}

//==================================================================�����¼���ͳ��
INT16U Get_Level2Data_F157(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{	//�¶����������������й�����ʾֵ

	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if (AutoFlg==1)
		StPos=3;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;

	ts2.Month=BCD_INT32(&Data[0]+StPos,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
	if (AutoFlg==1) TimeDecrease(&ts2,5,1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);

	ts.Month=BCD_INT32(&Data[0]+StPos,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+1,1)+2000;
	if (AutoFlg==0) TimeAdd(&ts,5,1);
	SendBuff[SendIndex++]=0;
	SendBuff[SendIndex++]=0;
	SendBuff[SendIndex++]=0x01;
	INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);

	//��ȡ������
	IsDataFlag=0;

	sprintf((char *)Temp_FilePath,"/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,3);
	if(IsDataFlag==1)
	{																		  //A�������й�����  //yangdonggai 0,5,gaicheng 0,4,1
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xff,0xc0,0,4,1,0,0,0,0,dftype);
		SendIndex = SendIndex + 5;											  //B�������й�����
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xff,0xc4,0,4,1,0,0,0,0,dftype);
		SendIndex = SendIndex + 5;											  //C�������й�����
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xff,0xc8,0,4,1,0,0,0,0,dftype);
		SendIndex = SendIndex + 5;
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,15);
		SendIndex=SendIndex+15;
	}
	return 2;
}
INT16U Get_Level2Data_F158(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{	//�¶����������������޹�����ʾֵ

	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if (AutoFlg==1)
		StPos=3;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;

	ts2.Month=BCD_INT32(&Data[0]+StPos,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
	if (AutoFlg==1) TimeDecrease(&ts2,5,1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);

	ts.Month=BCD_INT32(&Data[0]+StPos,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+1,1)+2000;
	if (AutoFlg==0) TimeAdd(&ts,5,1);
	SendBuff[SendIndex++]=0;
	SendBuff[SendIndex++]=0;
	SendBuff[SendIndex++]=0x01;
	INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);

	//��ȡ������
	IsDataFlag=0;

	sprintf((char *)Temp_FilePath,"/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,3);
	if(IsDataFlag==1)/////////////////////////////lcy
	{																		  //A�������޹�����
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xff,0xc2,0,4,1,0,0,0,0,dftype);
		SendIndex = SendIndex + 4;											  //B�������޹�����
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xff,0xc6,0,4,1,0,0,0,0,dftype);
		SendIndex = SendIndex + 4;											  //C�������޹�����
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xff,0xca,0,4,1,0,0,0,0,dftype);
		SendIndex = SendIndex + 4;
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,12);/////////////////////////////lcy
		SendIndex=SendIndex+12;
	}
	return 2;
}
INT16U Get_Level2Data_F159(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{	//�¶����������෴���й�����ʾֵ

	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if (AutoFlg==1)
		StPos=3;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;

	ts2.Month=BCD_INT32(&Data[0]+StPos,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
	if (AutoFlg==1) TimeDecrease(&ts2,5,1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);

	ts.Month=BCD_INT32(&Data[0]+StPos,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+1,1)+2000;
	if (AutoFlg==0) TimeAdd(&ts,5,1);
	SendBuff[SendIndex++]=0;
	SendBuff[SendIndex++]=0;
	SendBuff[SendIndex++]=0x01;
	INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);

	//��ȡ������
	IsDataFlag=0;

	sprintf((char *)Temp_FilePath,"/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,3);
	if(IsDataFlag==1)
	{																		  //A�෴���й�����
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xff,0xc1,0,4,1,0,0,0,0,dftype);
		SendIndex = SendIndex + 5;											  //B�෴���й�����
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xff,0xc5,0,4,1,0,0,0,0,dftype);
		SendIndex = SendIndex + 5;											  //C�෴���й�����
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xff,0xc9,0,4,1,0,0,0,0,dftype);
		SendIndex = SendIndex + 5;
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,15);
		SendIndex=SendIndex+15;
	}
	return 2;
}

INT16U Get_Level2Data_F160(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{	//�¶����������෴���޹�����ʾֵ

	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if (AutoFlg==1)
		StPos=3;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;

	ts2.Month=BCD_INT32(&Data[0]+StPos,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
	if (AutoFlg==1) TimeDecrease(&ts2,5,1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);

	ts.Month=BCD_INT32(&Data[0]+StPos,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+1,1)+2000;
	if (AutoFlg==0) TimeAdd(&ts,5,1);
	SendBuff[SendIndex++]=0;
	SendBuff[SendIndex++]=0;
	SendBuff[SendIndex++]=0x01;
	INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);

	//��ȡ������
	IsDataFlag=0;

	sprintf((char *)Temp_FilePath,"/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,3);
	if(IsDataFlag==1)//////////////////////lcy
	{																		  //A�෴���޹�����
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xff,0xc3,0,4,1,0,0,0,0,dftype);
		SendIndex = SendIndex + 4;											  //B�෴���޹�����
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xff,0xc7,0,4,1,0,0,0,0,dftype);
		SendIndex = SendIndex + 4;											  //C�෴���޹�����
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xff,0xcb,0,4,1,0,0,0,0,dftype);
		SendIndex = SendIndex + 4;
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,12);////////////////////////lcy
		SendIndex=SendIndex+12;
	}
	return 2;
}
//9��15�ոĶ�  �ն��������й�����ʾֵ���ܣ�����1-4��
INT16U Get_Level2Data_F161(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	INT16U IsDataFlag,dftype;
	INT8U ridongjie_d[10];
	INT8U dianneng[20];
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType,i;
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	TS ts10;
	ts10 = ts;
	TS ts11;
	ts11 = ts;
	TS ts12;

	INT8U Temp_FilePath1[60];
	StPos=0;
	if(AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	dftype=1;
	SdPrintf(YNPrint,PreFix,"�ն��������й�����ʾֵ");
	SdPrintf(YNPrint,PreFix,"����=%d",(zone_so&0x7f));
	if(((zone_so&0x7f)==XINJIANG) || ((zone_so&0x7f)==JIANGXI)
			|| (zone_so&0x7f) == TIANJIN || (zone_so&0x7f) == SHANGHAI ||Jcfginfo->jzqpara.ChaoBiaoDongJieType)//dongjieyd
	{
		SdPrintf(YNPrint,PreFix,"AutoFlg�� %d\n", AutoFlg);
		IsDataFlag=0;
		ts.Day=BCD_INT32(&Data[0]+StPos,1);
		ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
		ts12 = ts;
		if (AutoFlg==0) TimeAdd(&ts,4,1);
		memset(Temp_FilePath,0x00,60);
		sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);//���ļ�
		SdPrintf(YNPrint,PreFix,"F161 ���ļ��� %s\n", Temp_FilePath);
		IsDataFlag=getMeterFile(MeterType,(char *)Temp_FilePath,ts,2);
		if(IsDataFlag==1)
		{
			memset(ridongjie_d, 0, 10);
			//FB01 ��Flag.cfg�� �ն���ʱ��
			IsDataFlag=getMetersData(MeterType,ridongjie_d,CJQno,MeterNo,0xFB,0x01,0,5,1,0,0,0,0,dftype);//lqq161
			SdPrintf(YNPrint,PreFix,"ridongjie_d: ");
			for(i=0;i<10;i++)
				SdPrintf(YNPrint," ","[%d %02x]", i, ridongjie_d[i]);

//			if (0)
			if (IsDataFlag == 1)
			{
//				SendBuff[SendIndex++]=ridongjie_d[2];//��//lqq161
//				SendBuff[SendIndex++]=ridongjie_d[3];//��
//				SendBuff[SendIndex++]=ridongjie_d[4];//��
				INT32U_BCD(ts12.Day,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts12.Month,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts12.Year,&SendBuff[SendIndex++],1);
				//�鳭��ʱ��  8�� 15�� 0��0��0

				SendBuff[SendIndex++]=0;
				SendBuff[SendIndex++]=0;
				INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);

				SendBuff[SendIndex++]=FeiLvNum;//���ʸ���

				memset(dianneng, 0, 20);
				IsDataFlag=getMetersData(MeterType,dianneng,CJQno,MeterNo,0xFB,0x02,0,20,1,1,0,0,0,dftype);//lqq161

				SdPrintf(YNPrint,PreFix,"0xFB,0x02: ");
				for(i=0;i<20;i++)
					SdPrintf(YNPrint," " ,"%02x", dianneng[i]);

				if (IsDataFlag ==1)
				{
					for(i=0;i<5;i++)
					{
						if((dianneng[(i)+i*3]==OxXX)&&(dianneng[(i+1)+i*3]==OxXX)&&(dianneng[(i+2)+i*3]==OxXX)&&(dianneng[(i+3)+i*3]==OxXX))
						{
							memcpy(&SendBuff[SendIndex],&dianneng[i*4],4);
							SendIndex = SendIndex + 4;
							SendBuff[SendIndex++]=OxXX;
						}
						else
						{
							memcpy(&SendBuff[SendIndex],&dianneng[i*4],4);
							SendIndex = SendIndex + 4;
							SendBuff[SendIndex++]=0x00;
						}
					}
				}
				if (IsDataFlag == 0)
				{
					memset(&SendBuff[SendIndex],OxXX,25);
					SendIndex=SendIndex+25;
				}
			}else	//zhengchang
			{
			//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
				ts2.Day=BCD_INT32(&Data[0]+StPos,1);
				ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
				ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
				if (AutoFlg==1) TimeDecrease(&ts2,4,1);
				INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
				//if (AutoFlg==0) TimeAdd(&ts,4,1);//10.7
				if((zone_so&0x7f) == JIANGSU)
				{
					SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
					SendBuff[SendIndex++]=0x23;
					INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
					INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
					INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
					SendBuff[SendIndex++]=FeiLvNum;
				}
				else{

					SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
					SendBuff[SendIndex++]=0;
					INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
					INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
					INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
					SendBuff[SendIndex++]=FeiLvNum;
				}
				//��ȡ������
				IsDataFlag=0;
				memset(Temp_FilePath,0x00,60);
				sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
				SdPrintf(YNPrint,PreFix,"AutoFlg=%d   ..... F161 ���ļ��� %s\n", AutoFlg,Temp_FilePath);
				SdPrintf(YNPrint,PreFix,"get161 begin\n\r");
				IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
				SdPrintf(YNPrint,PreFix,"get161 end\n\r");
				if(IsDataFlag==1)
				{
					//�Ϻ���������ܵ��ܱ�����������Ϊ5��С���Ϊ1��2�����������������й�����ȡ���ܱ�������й�����(F161+F163)
					INT8U 	DaNo,XiaoNo;
					DaNo = (JSetPara_AFN04_3761_2009->group2.f10[P-1].UserType & 0xf0) >>4;		//�����
					XiaoNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].UserType & 0x0f;			//С���
					SdPrintf(YNPrint,PreFix,"�Ϻ�,����й������û����=%d,С�û����=%d,���ʸ���=%d",DaNo,XiaoNo,FeiLvNum);
					if((zone_so&0x7f) == SHANGHAI && (DaNo==5 &&(XiaoNo==1 || XiaoNo==2)))
					{
						INT8U SndBuf_9010[25];
						INT8U SndBuf_9020[25];
						INT8U tmp[5]={0x00,OxXX,OxXX,OxXX,OxXX};
						INT8U IsDataFlag1;
						INT8U IsDataFlag2;
						FP64 data_9010=0;
						FP64 data_9020=0;
						FP64 data_he = 0;

						IsDataFlag1=getMetersData(MeterType,&SndBuf_9010[0],CJQno,MeterNo,0x90,0x10,0,4,5,1,0,0,0,dftype);
						IsDataFlag2=getMetersData(MeterType,&SndBuf_9020[0],CJQno,MeterNo,0x90,0x20,0,4,5,1,0,0,0,dftype);
						SdPrintf(YNPrint,PreFix,"IsDataFlag1=%d,IsDataFlag2=%d",IsDataFlag1,IsDataFlag2);
						if(IsDataFlag1 ==0 && IsDataFlag2 == 0)
						{
							IsDataFlag = 0;
						}
						else {
							for(i=0; i<5; i++){
								data_he = 0;data_9010 = 0;data_9020=0;
								memset(&SendBuff[SendIndex+i*5],OxXX,5);
								SdPrintf(YNPrint,PreFix,
										"9010:%02x %02x %02x %02x %02x,",SndBuf_9010[i*5],
										SndBuf_9010[i*5+1],SndBuf_9010[i*5+2],
										SndBuf_9010[i*5+3],SndBuf_9010[i*5+4]);
								SdPrintf(YNPrint,PreFix,"9020:%02x %02x %02x %02x %02x",SndBuf_9020[i*5],
												SndBuf_9020[i*5+1],SndBuf_9020[i*5+2],
												SndBuf_9020[i*5+3],SndBuf_9020[i*5+4]);
								if(memcmp(&SndBuf_9010[i*5],tmp,5) != 0)
									data_9010 = BCD_INT32(&SndBuf_9010[i*5],5);
								if(memcmp(&SndBuf_9020[i*5],tmp,5) != 0)
									data_9020 = BCD_INT32(&SndBuf_9020[i*5],5);
								data_he = data_9010+data_9020;
								SdPrintf(YNPrint,PreFix,"data_9010=%f,data_9020=%f,data_he=%f",data_9010,data_9020,data_he);
								INT32U_BCD(data_he,&SendBuff[SendIndex+i*5],5);
								SdPrintf(YNPrint,PreFix,"SendBuff[%d]:%02x %02x %02x %02x %02x",SendIndex+i*5,
										SendBuff[SendIndex+i*5],SendBuff[SendIndex+i*5+1],
										SendBuff[SendIndex+i*5+2],SendBuff[SendIndex+i*5+3],SendBuff[SendIndex+i*5+4]);
							}
							IsDataFlag = 1;
						}
					}
					else {
						IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x90,0x10,0,4,5,1,0,0,0,dftype);
					}
					if (IsDataFlag == 0)
					{
						memset(&SendBuff[SendIndex],OxXX,25);
						SendIndex=SendIndex+25;
						//SendNAK(F, P, 0x0d);
						//return 3;
					}
					else
					{
						for(i=0;i<5;i++)
						{
							SdPrintf(YNPrint,PreFix,"memset,SendBuff[%d]:%02x %02x %02x %02x %02x",SendIndex+i*5,
																SendBuff[SendIndex+i*5],SendBuff[SendIndex+i*5+1],
																SendBuff[SendIndex+i*5+2],SendBuff[SendIndex+i*5+3],SendBuff[SendIndex+i*5+4]);
							if((SendBuff[(SendIndex+1)+i*5]==OxXX)&&
							   (SendBuff[(SendIndex+2)+i*5]==OxXX)&&
							   (SendBuff[(SendIndex+3)+i*5]==OxXX)&&
							   (SendBuff[(SendIndex+4)+i*5]==OxXX)){
								    fprintf(stderr,"memeset to zero");
									memset(&SendBuff[SendIndex+0+i*5],OxXX,5);

							}
						}
						SendIndex = SendIndex + 25;
					}
				}
				else
				{
					memset(&SendBuff[SendIndex],OxXX,25);
					SendIndex=SendIndex+25;
					//SendNAK(F, P, 0x0d);
					//return 3;
				}
			}
		}else
		{
			//maketemp();//hebei
			ts10.Day=BCD_INT32(&Data[0]+StPos,1);
			ts10.Month=BCD_INT32(&Data[0]+StPos+1,1);
			ts10.Year=BCD_INT32(&Data[0]+StPos+2,1);
			if (AutoFlg==1) TimeDecrease(&ts10,4,1);
			INT32U_BCD(ts10.Day,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts10.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts10.Year,&SendBuff[SendIndex++],1);
			ts11 = ts10;
			INT8U flag=0;
			for(i=0;i<31;i++)
			{
				memset(Temp_FilePath1,0x00,60);
				sprintf((char *)Temp_FilePath1,"/nand/DataDay/%04d/%02d.dat",P,ts11.Day);
				SdPrintf(YNPrint,PreFix,"--------::: %s \n",Temp_FilePath1);
				if(access((char *)Temp_FilePath1, 0)==0)
				{
					SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
					SendBuff[SendIndex++]=0;
					INT32U_BCD(ts11.Day,&SendBuff[SendIndex++],1);
					INT32U_BCD(ts11.Month,&SendBuff[SendIndex++],1);
					INT32U_BCD(ts11.Year,&SendBuff[SendIndex++],1);
					flag = 1;
					break;
				}
				TimeDecrease(&ts11,4,1);
			}
			SdPrintf(YNPrint,PreFix,"--------flag == %d \n",flag);
			TimeAdd(&ts10,4,1);
			if(flag == 0)
			{
				SdPrintf(YNPrint,PreFix,"-------------------------flg\n");
				SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
				SendBuff[SendIndex++]=0;
				INT32U_BCD(ts10.Day,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts10.Month,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts10.Year,&SendBuff[SendIndex++],1);
			}
			SendBuff[SendIndex++]=FeiLvNum;
			memset(&SendBuff[SendIndex],OxXX,25);
			SendIndex=SendIndex+25;
		}
	}
	else//������
	{
		INT16U IsDataFlag,dftype;
		INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType,i;
		TS ts,ts2;
		ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
		ts.Week = 0;
		ts2=ts;
		StPos=0;
		if(AutoFlg==1)
			StPos=2;
		CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
		MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
		MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
		ts2.Day=BCD_INT32(&Data[0]+StPos,1);
		ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
		ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
		if (AutoFlg==1) TimeDecrease(&ts2,4,1);
		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		ts.Day=BCD_INT32(&Data[0]+StPos,1);
		ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
		if (AutoFlg==0) TimeAdd(&ts,4,1);
		if((zone_so&0x7f) == JIANGSU)
		{
			SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
			SendBuff[SendIndex++]=0x23;
			INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
			SendBuff[SendIndex++]=FeiLvNum;
		}
		else{

			SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
			SendBuff[SendIndex++]=0;
			INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
			SendBuff[SendIndex++]=FeiLvNum;
		}
		//��ȡ������
		IsDataFlag=0;
		memset(Temp_FilePath,0x00,60);

		sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
		if ((MeterType == 9) || (MeterType == 6))
		{
			dftype=1;//comm
		}
		else
		{
			dftype=1;
		}
		SdPrintf(YNPrint,PreFix,"get161 begin\n\r");
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
		SdPrintf(YNPrint,PreFix,"get161 end\n\r");
		if(IsDataFlag==1)
		{
				IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x90,0x10,0,4,5,1,0,0,0,dftype);
				if (IsDataFlag == 0)
				{
					memset(&SendBuff[SendIndex],OxXX,25);
					SendIndex=SendIndex+25;
					//SendNAK(F, P, 0x0d);
					//return 3;
				}
				else
				{
					for(i=0;i<5;i++)
					{
						if((SendBuff[(SendIndex+1)+i*5]==OxXX)&&
						   (SendBuff[(SendIndex+2)+i*5]==OxXX)&&
						   (SendBuff[(SendIndex+3)+i*5]==OxXX)&&
						   (SendBuff[(SendIndex+4)+i*5]==OxXX))
								memset(&SendBuff[SendIndex+0+i*5],OxXX,5);
						AutoSucc+=1;
					}
					/*if ((SendBuff[SendIndex+1]==OxXX) && (SendBuff[SendIndex+2]==OxXX) &&
							(SendBuff[SendIndex+3]==OxXX) && (SendBuff[SendIndex+4]==OxXX))
					{
						if(AutoFlg==1) return 3;
						memset(&SendBuff[SendIndex],OxXX,25);
						//if((JSetPara_AFN04_3761_2009->group2.f10[P-1].port==CarrWavePort) || (JSetPara_AFN04_3761_2009->group2.f10[P-1].port==LocalCommPort))
						AutoSucc+=1;
					}*/
					SendIndex = SendIndex + 25;
				}
		}
		else
		{

			memset(&SendBuff[SendIndex],OxXX,25);
			SendIndex=SendIndex+25;
			//SendNAK(F, P, 0x0d);
			//return 3;
		}
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 3;
}

INT16U Get_Level2Data_F162(INT8U Set,INT16U F,INT16U P,INT8U *Data)  //�ն��������޹�������޹�1������ʾֵ���ܣ����ʣ�
{
	INT16U IsDataFlag,dftype;
	INT8U ridongjie_d[10];
	INT8U dianneng[20];
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType,i;
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	TS ts10;
	ts10 = ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	dftype=1;

	if(((zone_so&0x7f)==JIANGXI) || (zone_so&0x7f) == TIANJIN || (zone_so&0x7f) == SHANGHAI||Jcfginfo->jzqpara.ChaoBiaoDongJieType)//dongjieyd
	{
		SdPrintf(YNPrint,PreFix,"AutoFlg�� %d\n", AutoFlg);
		IsDataFlag=0;
		ts.Day=BCD_INT32(&Data[0]+StPos,1);
		ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
		if (AutoFlg==0) TimeAdd(&ts,4,1);
		memset(Temp_FilePath,0x00,60);
//		if(GUOWANGSOFTTEST)
		if( (((zone_so)>>7)&0x01) ==1)
			sprintf((char *)Temp_FilePath,"/nand/DataCurr/%04d/curr.dat",P);//���ļ�
		else
			sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);//���ļ�
		SdPrintf(YNPrint,PreFix,"F162 ���ļ��� %s\n", Temp_FilePath);
		IsDataFlag=getMeterFile(MeterType,(char *)Temp_FilePath,ts,2);
		if(IsDataFlag==1)
		{
			memset(ridongjie_d, 0, 10);
			//FB01 ��Flag.cfg�� �ն���ʱ��
			IsDataFlag=getMetersData(MeterType,ridongjie_d,CJQno,MeterNo,0xFB,0x01,0,5,1,0,0,0,0,dftype);//lqq161
//			printf("\n ridongjie_d: ");
//			for(i=0;i<10;i++)
//				printf("[%d %02x] ", i, ridongjie_d[i]);

			if (IsDataFlag == 1)
			{
				SendBuff[SendIndex++]=ridongjie_d[2];//��//lqq161
				SendBuff[SendIndex++]=ridongjie_d[3];//��
				SendBuff[SendIndex++]=ridongjie_d[4];//��
				//�鳭��ʱ��  8�� 15�� 0��0��0

				SendBuff[SendIndex++]=0;
				SendBuff[SendIndex++]=0;
				INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);

				SendBuff[SendIndex++]=FeiLvNum;//���ʸ���

				memset(dianneng, 0, 20);
				IsDataFlag=getMetersData(MeterType,dianneng,CJQno,MeterNo,0xFB,0x04,0,20,1,0,0,0,0,dftype);//lqq161

//				printf("\n 0xFB,0x04: ");
//				for(i=0;i<20;i++)
//					printf("%02x ", dianneng[i]);

				if (IsDataFlag ==1)
				{
					for(i=0;i<5;i++)
					{
						if((dianneng[(i)+i*3]==OxXX)&&(dianneng[(i+1)+i*3]==OxXX)&&(dianneng[(i+2)+i*3]==OxXX)&&(dianneng[(i+3)+i*3]==OxXX))
						{
							memcpy(&SendBuff[SendIndex],&dianneng[i*4],4);
							SendIndex = SendIndex + 4;
							//SendBuff[SendIndex++]=OxXX;
						}
						else
						{
							memcpy(&SendBuff[SendIndex],&dianneng[i*4],4);
							SendIndex = SendIndex + 4;
							//SendBuff[SendIndex++]=0x00;
						}
					}
				}
				if (IsDataFlag == 0)
				{
					memset(&SendBuff[SendIndex],OxXX,20);
					SendIndex=SendIndex+20;
				}
			}else	//zhengchang
			{
			//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
				ts2.Day=BCD_INT32(&Data[0]+StPos,1);
				ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
				ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
				if (AutoFlg==1) TimeDecrease(&ts2,4,1);
				INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
				//if (AutoFlg==0) TimeAdd(&ts,4,1);
				if((zone_so&0x7f) == JIANGSU)
				{
					SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
					SendBuff[SendIndex++]=0x23;
					INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
					INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
					INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
					SendBuff[SendIndex++]=FeiLvNum;
				}
				else{

					SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
					SendBuff[SendIndex++]=0;
					INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
					INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
					INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
					SendBuff[SendIndex++]=FeiLvNum;
				}
				//��ȡ������
				IsDataFlag=0;
				memset(Temp_FilePath,0x00,60);
				sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
				SdPrintf(YNPrint,PreFix,"AutoFlg=%d   ..... F162 ���ļ��� %s\n", AutoFlg,Temp_FilePath);
				SdPrintf(YNPrint,PreFix,"get162 begin\n\r");
				IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
				SdPrintf(YNPrint,PreFix,"get162 end\n\r");
				if(IsDataFlag==1)
				{
					IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x10,0,4,5,0,0,0,0,dftype);
					if (IsDataFlag == 0)
					{
						memset(&SendBuff[SendIndex],OxXX,20);
						SendIndex=SendIndex+20;
						//SendNAK(F, P, 0x0d);
						//return 3;
					}
					else
					{
						for(i=0;i<5;i++)
						{
							if((SendBuff[(SendIndex+1)+i*4]==OxXX)&&
							   (SendBuff[(SendIndex+2)+i*4]==OxXX)&&
							   (SendBuff[(SendIndex+3)+i*4]==OxXX)&&
							   (SendBuff[(SendIndex+4)+i*4]==OxXX))
									memset(&SendBuff[SendIndex+0+i*5],OxXX,4);
						}
						SendIndex = SendIndex + 20;
					}
				}
				else
				{
					memset(&SendBuff[SendIndex],OxXX,20);
					SendIndex=SendIndex+20;
					//SendNAK(F, P, 0x0d);
					//return 3;
				}
			}
		}else
		{
			//maketemp();
			ts10.Day=BCD_INT32(&Data[0]+StPos,1);
			ts10.Month=BCD_INT32(&Data[0]+StPos+1,1);
			ts10.Year=BCD_INT32(&Data[0]+StPos+2,1);
			if (AutoFlg==1) TimeDecrease(&ts10,4,1);
			INT32U_BCD(ts10.Day,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts10.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts10.Year,&SendBuff[SendIndex++],1);
			TimeAdd(&ts10,4,1);
			SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
			SendBuff[SendIndex++]=0;
			INT32U_BCD(ts10.Day,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts10.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts10.Year,&SendBuff[SendIndex++],1);
			SendBuff[SendIndex++]=FeiLvNum;
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
		}
	}else //������
	{
		ts2.Day=BCD_INT32(&Data[0]+StPos,1);
		ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
		ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
		if (AutoFlg==1) TimeDecrease(&ts2,4,1);
		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		if (AutoFlg==0) TimeAdd(&ts,4,1);
		if((zone_so&0x7f) == JIANGSU)
		{
			SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
			SendBuff[SendIndex++]=0x23;
			INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
			SendBuff[SendIndex++]=FeiLvNum;
		}
		else{

			SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
			SendBuff[SendIndex++]=0;
			INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
			SendBuff[SendIndex++]=FeiLvNum;
		}
		//��ȡ������
		IsDataFlag=0;
		memset(Temp_FilePath,0x00,60);

		sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
		if ((MeterType == 9) || (MeterType == 6))
		{
			dftype=1;//comm
		}
		else
		{
			dftype=1;
		}
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
		if(IsDataFlag==1)
		{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x10,0,4,5,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,20);
				SendIndex=SendIndex+20;
				//SendNAK(F, P, 0x0d);
				//return 3;
			}
			else SendIndex = SendIndex + 20;
		}
		else
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 3;
		}
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 3;
}

INT16U Get_Level2Data_F163(INT8U Set,INT16U F,INT16U P,INT8U *Data)		//�ն��ᷴ���й�����ʾֵ���ܣ����ʣ�
{
	INT16U IsDataFlag,dftype;
	INT8U  ReadFailFlag;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType,i;
	INT8U ridongjie_d[10];
	INT8U dianneng[20];
	TS ts,ts2;

	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;

	dftype=1;
	if(((zone_so&0x7f)==XINJIANG) || ((zone_so&0x7f)==JIANGXI) ||(zone_so&0x7f) == TIANJIN
			|| (zone_so&0x7f) == SHANGHAI
			||Jcfginfo->jzqpara.ChaoBiaoDongJieType)//dongjieyd
	{
		ReadFailFlag  =0;
		SdPrintf(YNPrint,PreFix,"AutoFlg�� %d\n", AutoFlg);
		IsDataFlag=0;
		ts.Day=BCD_INT32(&Data[0]+StPos,1);
		ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
		if (AutoFlg==0) TimeAdd(&ts,4,1);
		memset(Temp_FilePath,0x00,60);
		sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);//���ļ�
		SdPrintf(YNPrint,PreFix,"F163 ���ļ��� %s\n", Temp_FilePath);
		IsDataFlag=getMeterFile(MeterType,(char *)Temp_FilePath,ts,2);
		if(IsDataFlag==1)
		{
			memset(ridongjie_d, 0, 10);
			//FB01 ��Flag.cfg�� �ն���ʱ��
			IsDataFlag=getMetersData(MeterType,ridongjie_d,CJQno,MeterNo,0xFB,0x01,0,5,1,0,0,0,0,dftype);//lqq161
			SdPrintf(YNPrint,PreFix,"ridongjie_d: ");
			for(i=0;i<10;i++)
				SdPrintf(YNPrint," ","[%d %02x]", i, ridongjie_d[i]);

//			if (0)
			if (IsDataFlag == 1)
			{
				SendBuff[SendIndex++]=ridongjie_d[2];//��//lqq161
				SendBuff[SendIndex++]=ridongjie_d[3];//��
				SendBuff[SendIndex++]=ridongjie_d[4];//��
				//�鳭��ʱ��  8�� 15�� 0��0��0

				SendBuff[SendIndex++]=0;
				SendBuff[SendIndex++]=0;
				INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);

				SendBuff[SendIndex++]=FeiLvNum;//���ʸ���

				memset(dianneng, 0, 20);
				IsDataFlag=getMetersData(MeterType,dianneng,CJQno,MeterNo,0xFB,0x03,0,20,1,1,0,0,0,dftype);//lqq161

				SdPrintf(YNPrint,PreFix,"0xFB,0x03: ");
				for(i=0;i<20;i++)
					SdPrintf(YNPrint," ","%02x", dianneng[i]);

				if (IsDataFlag ==1)
				{
					for(i=0;i<5;i++)
					{
						if((dianneng[(i)+i*3]==OxXX)&&(dianneng[(i+1)+i*3]==OxXX)&&(dianneng[(i+2)+i*3]==OxXX)&&(dianneng[(i+3)+i*3]==OxXX))
						{
							memcpy(&SendBuff[SendIndex],&dianneng[i*4],4);
							SendIndex = SendIndex + 4;
							SendBuff[SendIndex++]=OxXX;
						}
						else
						{
							memcpy(&SendBuff[SendIndex],&dianneng[i*4],4);
							SendIndex = SendIndex + 4;
							SendBuff[SendIndex++]=0x00;
						}
					}
				}else	{
					memset(&SendBuff[SendIndex],OxXX,25);
					SendIndex=SendIndex+25;
				}
			}else {
				ReadFailFlag =1;
			}
		}else {			//δ�ҵ��ն�������
			ReadFailFlag=1;
		}
	}else   ReadFailFlag=1;

	if(ReadFailFlag) {
		ts2.Day=BCD_INT32(&Data[0]+StPos,1);
		ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
		ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
		if (AutoFlg==1) TimeDecrease(&ts2,4,1);
		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		ts.Day=BCD_INT32(&Data[0]+StPos,1);
		ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
		if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong

		if((zone_so&0x7f) == JIANGSU)
		{
			SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
			SendBuff[SendIndex++]=0x23;
			INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
			SendBuff[SendIndex++]=FeiLvNum;
		}
		else{

			SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
			SendBuff[SendIndex++]=0;
			INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
			SendBuff[SendIndex++]=FeiLvNum;
		}

		//��ȡ������
		IsDataFlag=0;
		memset(Temp_FilePath,0x00,60);

		sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
		if ((MeterType == 9) || (MeterType == 6))
		{
			dftype=1;//comm
		}
		else
		{
			dftype=1;
		}
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
		if(IsDataFlag==1)
		{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x90,0x20,0,4,5,1,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,25);
				SendIndex=SendIndex+25;
				//SendNAK(F, P, 0x0d);
				//return 3;
			}
			else
			{
				for(i=0;i<5;i++)
				{
					if((SendBuff[(SendIndex+1)+i*5]==OxXX)&&
					   (SendBuff[(SendIndex+2)+i*5]==OxXX)&&
					   (SendBuff[(SendIndex+3)+i*5]==OxXX)&&
					   (SendBuff[(SendIndex+4)+i*5]==OxXX))
							memset(&SendBuff[SendIndex+0+i*5],OxXX,5);
				}
				SendIndex = SendIndex + 25;
			}
		}else
		{
			memset(&SendBuff[SendIndex],OxXX,25);
			SendIndex=SendIndex+25;
			//SendNAK(F, P, 0x0d);
			//return 3;
		}
	}


//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 3;

}
INT16U Get_Level2Data_F164(INT8U Set,INT16U F,INT16U P,INT8U *Data)		//�ն��ᷴ���޹�����ʾֵ���ܣ����ʣ�
{
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType,i;
	INT8U  ReadFailFlag=0;
	INT8U ridongjie_d[10];
	INT8U dianneng[20];
	TS ts,ts2;


	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;

	dftype=1;

	if(((zone_so&0x7f)==JIANGXI) || (zone_so&0x7f) == TIANJIN || (zone_so&0x7f) == SHANGHAI ||Jcfginfo->jzqpara.ChaoBiaoDongJieType)//dongjieyd
	{
		SdPrintf(YNPrint,PreFix,"AutoFlg�� %d\n", AutoFlg);
		IsDataFlag=0;
		ts.Day=BCD_INT32(&Data[0]+StPos,1);
		ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
		if (AutoFlg==0) TimeAdd(&ts,4,1);
		memset(Temp_FilePath,0x00,60);
		sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);//���ļ�
		SdPrintf(YNPrint,PreFix,"F162 ���ļ��� %s\n", Temp_FilePath);
		IsDataFlag=getMeterFile(MeterType,(char *)Temp_FilePath,ts,2);
		if(IsDataFlag==1)
		{
			memset(ridongjie_d, 0, 10);
			//FB01 ��Flag.cfg�� �ն���ʱ��
			IsDataFlag=getMetersData(MeterType,ridongjie_d,CJQno,MeterNo,0xFB,0x01,0,5,1,0,0,0,0,dftype);//lqq161
			SdPrintf(YNPrint,PreFix,"ridongjie_d: ");
			if (IsDataFlag == 1)
			{
				SendBuff[SendIndex++]=ridongjie_d[2];//��//lqq161
				SendBuff[SendIndex++]=ridongjie_d[3];//��
				SendBuff[SendIndex++]=ridongjie_d[4];//��
				//�鳭��ʱ��  8�� 15�� 0��0��0

				SendBuff[SendIndex++]=0;
				SendBuff[SendIndex++]=0;
				INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);

				SendBuff[SendIndex++]=FeiLvNum;//���ʸ���

				memset(dianneng, 0, 20);
				IsDataFlag=getMetersData(MeterType,dianneng,CJQno,MeterNo,0xFB,0x05,0,20,1,0,0,0,0,dftype);//lqq161

				SdPrintf(YNPrint,PreFix,"0xFB,0x04: ");
				for(i=0;i<20;i++)
					SdPrintf(YNPrint," ","%02x", dianneng[i]);

				if (IsDataFlag ==1)
				{
					for(i=0;i<5;i++)
					{
						if((dianneng[(i)+i*3]==OxXX)&&(dianneng[(i+1)+i*3]==OxXX)&&(dianneng[(i+2)+i*3]==OxXX)&&(dianneng[(i+3)+i*3]==OxXX))
						{
							memcpy(&SendBuff[SendIndex],&dianneng[i*4],4);
							SendIndex = SendIndex + 4;
							//SendBuff[SendIndex++]=OxXX;
						}
						else
						{
							memcpy(&SendBuff[SendIndex],&dianneng[i*4],4);
							SendIndex = SendIndex + 4;
							//SendBuff[SendIndex++]=0x00;
						}
					}
				}
				if (IsDataFlag == 0)
				{
					memset(&SendBuff[SendIndex],OxXX,20);
					SendIndex=SendIndex+20;
				}
			}else  ReadFailFlag=1;
		}else  ReadFailFlag=1;
	}else 	ReadFailFlag=1;

	if(ReadFailFlag ==1) {
		ts2.Day=BCD_INT32(&Data[0]+StPos,1);
		ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
		ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
		if (AutoFlg==1) TimeDecrease(&ts2,4,1);
		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		ts.Day=BCD_INT32(&Data[0]+StPos,1);
		ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
		if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong
		if((zone_so&0x7f) == JIANGSU)
		{
			SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
			SendBuff[SendIndex++]=0x23;
			INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
			SendBuff[SendIndex++]=FeiLvNum;
		}
		else{

			SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
			SendBuff[SendIndex++]=0;
			INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
			SendBuff[SendIndex++]=FeiLvNum;
		}

		//��ȡ������
		IsDataFlag=0;
		memset(Temp_FilePath,0x00,60);

		sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
		if ((MeterType == 9) || (MeterType == 6))
		{
			dftype=1;//comm
		}
		else
		{
			dftype=1;
		}
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
		if(IsDataFlag==1)
		{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x20,0,4,5,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,20);
				SendIndex=SendIndex+20;
				//SendNAK(F, P, 0x0d);
				//return 3;
			}
			else SendIndex = SendIndex + 20;
		}
		else
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 3;
		}
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 3;
}
INT16U Get_Level2Data_F165(INT8U Set,INT16U F,INT16U P,INT8U *Data)			//�ն���һ�����޹�����ʾֵ���ܣ����ʣ�
{
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType,i;
	TS ts,ts2;
	INT8U  ReadFailFlag=0;
	INT8U ridongjie_d[10];
	INT8U dianneng[20];

	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;

	dftype=1;
	if(((zone_so&0x7f)==JIANGXI) || (zone_so&0x7f) == TIANJIN || (zone_so&0x7f) == SHANGHAI||Jcfginfo->jzqpara.ChaoBiaoDongJieType)//dongjieyd
	{
		SdPrintf(YNPrint,PreFix,"AutoFlg�� %d\n", AutoFlg);
		IsDataFlag=0;
		ts.Day=BCD_INT32(&Data[0]+StPos,1);
		ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
		if (AutoFlg==0) TimeAdd(&ts,4,1);
		memset(Temp_FilePath,0x00,60);
		sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);//���ļ�
		SdPrintf(YNPrint," ","F165 ���ļ��� %s\n", Temp_FilePath);
		IsDataFlag=getMeterFile(MeterType,(char *)Temp_FilePath,ts,2);
		if(IsDataFlag==1)
		{
			memset(ridongjie_d, 0, 10);
			//FB01 ��Flag.cfg�� �ն���ʱ��
			IsDataFlag=getMetersData(MeterType,ridongjie_d,CJQno,MeterNo,0xFB,0x01,0,5,1,0,0,0,0,dftype);//lqq161
			SdPrintf(YNPrint,PreFix,"ridongjie_d: ");
//			for(i=0;i<10;i++)
//				printf("[%d %02x] ", i, ridongjie_d[i]);

//			if (0)
			if (IsDataFlag == 1)
			{
				SendBuff[SendIndex++]=ridongjie_d[2];//��//lqq161
				SendBuff[SendIndex++]=ridongjie_d[3];//��
				SendBuff[SendIndex++]=ridongjie_d[4];//��
				//�鳭��ʱ��  8�� 15�� 0��0��0

				SendBuff[SendIndex++]=0;
				SendBuff[SendIndex++]=0;
				INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);

				SendBuff[SendIndex++]=FeiLvNum;//���ʸ���

				memset(dianneng, 0, 20);
				IsDataFlag=getMetersData(MeterType,dianneng,CJQno,MeterNo,0xFB,0x06,0,20,1,0,0,0,0,dftype);//lqq161

				SdPrintf(YNPrint,PreFix,"0xFB,0x06: ");
				for(i=0;i<20;i++)
					SdPrintf(YNPrint," ","%02x", dianneng[i]);

				if (IsDataFlag ==1)
				{
					for(i=0;i<5;i++)
					{
						if((dianneng[(i)+i*3]==OxXX)&&(dianneng[(i+1)+i*3]==OxXX)&&(dianneng[(i+2)+i*3]==OxXX)&&(dianneng[(i+3)+i*3]==OxXX))
						{
							memcpy(&SendBuff[SendIndex],&dianneng[i*4],4);
							SendIndex = SendIndex + 4;
							//SendBuff[SendIndex++]=OxXX;
						}
						else
						{
							memcpy(&SendBuff[SendIndex],&dianneng[i*4],4);
							SendIndex = SendIndex + 4;
							//SendBuff[SendIndex++]=0x00;
						}
					}
				}
				if (IsDataFlag == 0)
				{
					memset(&SendBuff[SendIndex],OxXX,20);
					SendIndex=SendIndex+20;
				}
			}else  ReadFailFlag=1;
		}else  ReadFailFlag=1;
	}else 	ReadFailFlag=1;

	if(ReadFailFlag ==1) {

		ts2.Day=BCD_INT32(&Data[0]+StPos,1);
		ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
		ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
		if (AutoFlg==1) TimeDecrease(&ts2,4,1);
		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		ts.Day=BCD_INT32(&Data[0]+StPos,1);
		ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
		if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong
		if((zone_so&0x7f) == JIANGSU)
		{
			SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
			SendBuff[SendIndex++]=0x23;
			INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
			SendBuff[SendIndex++]=FeiLvNum;
		}
		else{

			SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
			SendBuff[SendIndex++]=0;
			INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
			SendBuff[SendIndex++]=FeiLvNum;
		}

		//��ȡ������
		IsDataFlag=0;
		memset(Temp_FilePath,0x00,60);

		sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
		if ((MeterType == 9) || (MeterType == 6))
		{
			dftype=1;//comm
		}
		else
		{
			dftype=1;
		}
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
		if(IsDataFlag==1)
		{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x30,0,4,5,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,20);
				SendIndex=SendIndex+20;
				//SendNAK(F, P, 0x0d);
				//return 3;
			}
			else SendIndex = SendIndex + 20;
		}
		else
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 3;
		}
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 3;

}
INT16U Get_Level2Data_F166(INT8U Set,INT16U F,INT16U P,INT8U *Data)			//�ն���������޹�����ʾֵ���ܣ����ʣ�
{
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType,i;
	INT8U  ReadFailFlag=0;
	INT8U ridongjie_d[10];
	INT8U dianneng[20];
	TS ts,ts2;

	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;

	dftype=1;
	if(((zone_so&0x7f)==JIANGXI) || (zone_so&0x7f) == TIANJIN || (zone_so&0x7f) == SHANGHAI||Jcfginfo->jzqpara.ChaoBiaoDongJieType)//dongjieyd
	{
		SdPrintf(YNPrint,PreFix,"AutoFlg�� %d", AutoFlg);
		IsDataFlag=0;
		ts.Day=BCD_INT32(&Data[0]+StPos,1);
		ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
		if (AutoFlg==0) TimeAdd(&ts,4,1);
		memset(Temp_FilePath,0x00,60);
		sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);//���ļ�
		SdPrintf(YNPrint,PreFix,"F166 ���ļ��� %s\n", Temp_FilePath);
		IsDataFlag=getMeterFile(MeterType,(char *)Temp_FilePath,ts,2);
		if(IsDataFlag==1)
		{
			memset(ridongjie_d, 0, 10);
			//FB01 ��Flag.cfg�� �ն���ʱ��
			IsDataFlag=getMetersData(MeterType,ridongjie_d,CJQno,MeterNo,0xFB,0x01,0,5,1,0,0,0,0,dftype);//lqq161
			SdPrintf(YNPrint,PreFix,"ridongjie_d: ");
//			for(i=0;i<10;i++)
//				printf("[%d %02x] ", i, ridongjie_d[i]);

//			if (0)
			if (IsDataFlag == 1)
			{
				SendBuff[SendIndex++]=ridongjie_d[2];//��//lqq161
				SendBuff[SendIndex++]=ridongjie_d[3];//��
				SendBuff[SendIndex++]=ridongjie_d[4];//��
				//�鳭��ʱ��  8�� 15�� 0��0��0

				SendBuff[SendIndex++]=0;
				SendBuff[SendIndex++]=0;
				INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);

				SendBuff[SendIndex++]=FeiLvNum;//���ʸ���

				memset(dianneng, 0, 20);
				IsDataFlag=getMetersData(MeterType,dianneng,CJQno,MeterNo,0xFB,0x07,0,20,1,0,0,0,0,dftype);//lqq161

				SdPrintf(YNPrint,PreFix,"0xFB,0x07: ");
				for(i=0;i<20;i++)
					SdPrintf(YNPrint," ","%02x", dianneng[i]);

				if (IsDataFlag ==1)
				{
					for(i=0;i<5;i++)
					{
						if((dianneng[(i)+i*3]==OxXX)&&(dianneng[(i+1)+i*3]==OxXX)&&(dianneng[(i+2)+i*3]==OxXX)&&(dianneng[(i+3)+i*3]==OxXX))
						{
							memcpy(&SendBuff[SendIndex],&dianneng[i*4],4);
							SendIndex = SendIndex + 4;
							//SendBuff[SendIndex++]=OxXX;
						}
						else
						{
							memcpy(&SendBuff[SendIndex],&dianneng[i*4],4);
							SendIndex = SendIndex + 4;
							//SendBuff[SendIndex++]=0x00;
						}
					}
				}
				if (IsDataFlag == 0)
				{
					memset(&SendBuff[SendIndex],OxXX,20);
					SendIndex=SendIndex+20;
				}
			}else  ReadFailFlag=1;
		}else  ReadFailFlag=1;
	}else 	ReadFailFlag=1;

	if(ReadFailFlag ==1) {

	//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
		ts2.Day=BCD_INT32(&Data[0]+StPos,1);
		ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
		ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
		if (AutoFlg==1) TimeDecrease(&ts2,4,1);
		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		ts.Day=BCD_INT32(&Data[0]+StPos,1);
		ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
		if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong
		if((zone_so&0x7f) == JIANGSU)
		{
			SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
			SendBuff[SendIndex++]=0x23;
			INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
			SendBuff[SendIndex++]=FeiLvNum;
		}
		else{

			SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
			SendBuff[SendIndex++]=0;
			INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
			SendBuff[SendIndex++]=FeiLvNum;
		}

		//��ȡ������
		IsDataFlag=0;
		memset(Temp_FilePath,0x00,60);

		sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
		if ((MeterType == 9) || (MeterType == 6))
		{
			dftype=1;//comm
		}
		else
		{
			dftype=1;
		}
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
		if(IsDataFlag==1)
		{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x50,0,4,5,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,20);
				SendIndex=SendIndex+20;
				//SendNAK(F, P, 0x0d);
				//return 3;
			}
			else SendIndex = SendIndex + 20;
		}
		else
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 3;
		}
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 3;
}
INT16U Get_Level2Data_F167(INT8U Set,INT16U F,INT16U P,INT8U *Data)					//�ն����������޹�����ʾֵ���ܣ����ʣ�
{
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType,i;
	TS ts,ts2;
	INT8U  ReadFailFlag=0;
	INT8U ridongjie_d[10];
	INT8U dianneng[20];

	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	dftype=1;
	if(((zone_so&0x7f)==JIANGXI) || (zone_so&0x7f) == TIANJIN || (zone_so&0x7f) == SHANGHAI ||Jcfginfo->jzqpara.ChaoBiaoDongJieType)//dongjieyd
	{
		IsDataFlag=0;
		ts.Day=BCD_INT32(&Data[0]+StPos,1);
		ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
		if (AutoFlg==0) TimeAdd(&ts,4,1);
		memset(Temp_FilePath,0x00,60);
		sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);//���ļ�
		SdPrintf(YNPrint,PreFix,"F165 ���ļ��� %s\n", Temp_FilePath);
		IsDataFlag=getMeterFile(MeterType,(char *)Temp_FilePath,ts,2);
		if(IsDataFlag==1)
		{
			memset(ridongjie_d, 0, 10);
			//FB01 ��Flag.cfg�� �ն���ʱ��
			IsDataFlag=getMetersData(MeterType,ridongjie_d,CJQno,MeterNo,0xFB,0x01,0,5,1,0,0,0,0,dftype);//lqq161
			if (IsDataFlag == 1)
			{
				SendBuff[SendIndex++]=ridongjie_d[2];//��//lqq161
				SendBuff[SendIndex++]=ridongjie_d[3];//��
				SendBuff[SendIndex++]=ridongjie_d[4];//��
				//�鳭��ʱ��  8�� 15�� 0��0��0

				SendBuff[SendIndex++]=0;
				SendBuff[SendIndex++]=0;
				INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);

				SendBuff[SendIndex++]=FeiLvNum;//���ʸ���

				memset(dianneng, 0, 20);
				IsDataFlag=getMetersData(MeterType,dianneng,CJQno,MeterNo,0xFB,0x08,0,20,1,0,0,0,0,dftype);//lqq161

				SdPrintf(YNPrint,PreFix,"0xFB,0x08: ");
				for(i=0;i<20;i++)
					SdPrintf(YNPrint," ","%02x", dianneng[i]);

				if (IsDataFlag ==1)
				{
					for(i=0;i<5;i++)
					{
						if((dianneng[(i)+i*3]==OxXX)&&(dianneng[(i+1)+i*3]==OxXX)&&(dianneng[(i+2)+i*3]==OxXX)&&(dianneng[(i+3)+i*3]==OxXX))
						{
							memcpy(&SendBuff[SendIndex],&dianneng[i*4],4);
							SendIndex = SendIndex + 4;
							//SendBuff[SendIndex++]=OxXX;
						}
						else
						{
							memcpy(&SendBuff[SendIndex],&dianneng[i*4],4);
							SendIndex = SendIndex + 4;
							//SendBuff[SendIndex++]=0x00;
						}
					}
				}
				if (IsDataFlag == 0)
				{
					memset(&SendBuff[SendIndex],OxXX,20);
					SendIndex=SendIndex+20;
				}
			}else  ReadFailFlag=1;
		}else  ReadFailFlag=1;
	}else 	ReadFailFlag=1;

	if(ReadFailFlag ==1) {


	//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
		ts2.Day=BCD_INT32(&Data[0]+StPos,1);
		ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
		ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
		if (AutoFlg==1) TimeDecrease(&ts2,4,1);
		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		ts.Day=BCD_INT32(&Data[0]+StPos,1);
		ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
		if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong
		if((zone_so&0x7f) == JIANGSU)
		{
			SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
			SendBuff[SendIndex++]=0x23;
			INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
			SendBuff[SendIndex++]=FeiLvNum;
		}
		else{

			SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
			SendBuff[SendIndex++]=0;
			INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
			SendBuff[SendIndex++]=FeiLvNum;
		}

		//��ȡ������
		IsDataFlag=0;
		memset(Temp_FilePath,0x00,60);

		sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
		if ((MeterType == 9) || (MeterType == 6))
		{
			dftype=1;//comm
		}
		else
		{
			dftype=1;
		}
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
		if(IsDataFlag==1)
		{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x60,0,4,5,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,20);
				SendIndex=SendIndex+20;
				//SendNAK(F, P, 0x0d);
				//return 3;
			}
			else SendIndex = SendIndex + 20;
		}
		else
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 3;
		}
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 3;
}
INT16U Get_Level2Data_F168(INT8U Set,INT16U F,INT16U P,INT8U *Data)				//�ն����������޹�����ʾֵ���ܣ����ʣ�
{
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType,i;
	INT8U  ReadFailFlag=0;
	INT8U ridongjie_d[10];
	INT8U dianneng[20];
	TS ts,ts2;

	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	dftype=1;
	if(((zone_so&0x7f)==JIANGXI) || (zone_so&0x7f) == TIANJIN || (zone_so&0x7f) == SHANGHAI||Jcfginfo->jzqpara.ChaoBiaoDongJieType)//dongjieyd
	{
		SdPrintf(YNPrint,PreFix,"AutoFlg�� %d\n", AutoFlg);
		IsDataFlag=0;
		ts.Day=BCD_INT32(&Data[0]+StPos,1);
		ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
		if (AutoFlg==0) TimeAdd(&ts,4,1);
		memset(Temp_FilePath,0x00,60);
		sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);//���ļ�
		SdPrintf(YNPrint,PreFix,"F168 ���ļ��� %s\n", Temp_FilePath);
		IsDataFlag=getMeterFile(MeterType,(char *)Temp_FilePath,ts,2);
		if(IsDataFlag==1)
		{
			memset(ridongjie_d, 0, 10);
			//FB01 ��Flag.cfg�� �ն���ʱ��
			IsDataFlag=getMetersData(MeterType,ridongjie_d,CJQno,MeterNo,0xFB,0x01,0,5,1,0,0,0,0,dftype);//lqq161
			if (IsDataFlag == 1)
			{
				SendBuff[SendIndex++]=ridongjie_d[2];//��//lqq161
				SendBuff[SendIndex++]=ridongjie_d[3];//��
				SendBuff[SendIndex++]=ridongjie_d[4];//��
				//�鳭��ʱ��  8�� 15�� 0��0��0

				SendBuff[SendIndex++]=0;
				SendBuff[SendIndex++]=0;
				INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);

				SendBuff[SendIndex++]=FeiLvNum;//���ʸ���

				memset(dianneng, 0, 20);
				IsDataFlag=getMetersData(MeterType,dianneng,CJQno,MeterNo,0xFB,0x09,0,20,1,0,0,0,0,dftype);//lqq161

				if (IsDataFlag ==1)
				{
					for(i=0;i<5;i++)
					{
						if((dianneng[(i)+i*3]==OxXX)&&(dianneng[(i+1)+i*3]==OxXX)&&(dianneng[(i+2)+i*3]==OxXX)&&(dianneng[(i+3)+i*3]==OxXX))
						{
							memcpy(&SendBuff[SendIndex],&dianneng[i*4],4);
							SendIndex = SendIndex + 4;
							//SendBuff[SendIndex++]=OxXX;
						}
						else
						{
							memcpy(&SendBuff[SendIndex],&dianneng[i*4],4);
							SendIndex = SendIndex + 4;
							//SendBuff[SendIndex++]=0x00;
						}
					}
				}
				if (IsDataFlag == 0)
				{
					memset(&SendBuff[SendIndex],OxXX,20);
					SendIndex=SendIndex+20;
				}
			}else  ReadFailFlag=1;
		}else  ReadFailFlag=1;
	}else 	ReadFailFlag=1;

	if(ReadFailFlag ==1) {

	//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
		ts2.Day=BCD_INT32(&Data[0]+StPos,1);
		ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
		ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
		if (AutoFlg==1) TimeDecrease(&ts2,4,1);
		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		ts.Day=BCD_INT32(&Data[0]+StPos,1);
		ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
		if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong
		if((zone_so&0x7f) == JIANGSU)
		{
			SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
			SendBuff[SendIndex++]=0x23;
			INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
			SendBuff[SendIndex++]=FeiLvNum;
		}
		else{

			SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
			SendBuff[SendIndex++]=0;
			INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
			SendBuff[SendIndex++]=FeiLvNum;
		}

		//��ȡ������
		IsDataFlag=0;
		memset(Temp_FilePath,0x00,60);

		sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
		if ((MeterType == 9) || (MeterType == 6))
		{
			dftype=1;//comm
		}
		else
		{
			dftype=1;
		}
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
		if(IsDataFlag==1)
		{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x40,0,4,5,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,20);
				SendIndex=SendIndex+20;
				//SendNAK(F, P, 0x0d);
				//return 3;
			}
			else SendIndex = SendIndex + 20;
		}
		else
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 3;
		}
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 3;
}
INT16U Get_Level2Data_F169(INT8U Set,INT16U F,INT16U P,INT8U *Data)			//�����ն��������й�����ʾֵ
{
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType,i;
	INT8U ridongjie_d[10];
	INT8U dianneng[20];
	TS ts,ts2;

	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	TS ts10;
	ts10 = ts;
	if(AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	dftype = 1;
	if(((zone_so&0x7f)==XINJIANG) || ((zone_so&0x7f)==JIANGXI) || (zone_so&0x7f) == TIANJIN || (zone_so&0x7f) == SHANGHAI||Jcfginfo->jzqpara.ChaoBiaoDongJieType)//dongjieyd
	{
		IsDataFlag=0;
		ts.Day=BCD_INT32(&Data[0]+StPos,1);
		ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
//		if (AutoFlg==0) TimeAdd(&ts,4,1);
		memset(Temp_FilePath,0x00,60);
		sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);//���ļ�
		SdPrintf(YNPrint,PreFix,"F169 ���ļ��� %s\n", Temp_FilePath);
		IsDataFlag=getMeterFile(MeterType,(char *)Temp_FilePath,ts,2);
		if(IsDataFlag==1)
		{
			memset(ridongjie_d, 0, 10);
			//FB01 ��Flag.cfg�� �ն���ʱ��
			IsDataFlag=getMetersData(MeterType,ridongjie_d,CJQno,MeterNo,0xFB,0x01,0,5,1,0,0,0,0,dftype);//lqq161
			SdPrintf(YNPrint,PreFix,"ridongjie_d: ");
			for(i=0;i<10;i++)
				SdPrintf(YNPrint,PreFix,"[%d %02x]", i, ridongjie_d[i]);

			if (IsDataFlag == 1)
			{
				SendBuff[SendIndex++]=ridongjie_d[2];//��//lqq161
				SendBuff[SendIndex++]=ridongjie_d[3];//��
				SendBuff[SendIndex++]=ridongjie_d[4];//��
				//�鳭��ʱ��  8�� 15�� 0��0��0

				SendBuff[SendIndex++]=0;
				SendBuff[SendIndex++]=0;
				INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);

				SendBuff[SendIndex++]=FeiLvNum;//���ʸ���

				memset(dianneng, 0, 20);
				IsDataFlag=getMetersData(MeterType,dianneng,CJQno,MeterNo,0x94,0x1f,0,20,1,1,0,0,0,dftype);//lqq161

				SdPrintf(YNPrint,PreFix,"0x94,0x1f: ");
				for(i=0;i<20;i++)
					SdPrintf(YNPrint," ","%02x", dianneng[i]);

				if (IsDataFlag ==1)
				{
					for(i=0;i<5;i++)
					{
						if((dianneng[(i)+i*3]==OxXX)&&(dianneng[(i+1)+i*3]==OxXX)&&(dianneng[(i+2)+i*3]==OxXX)&&(dianneng[(i+3)+i*3]==OxXX))
						{
							memcpy(&SendBuff[SendIndex],&dianneng[i*4],4);
							SendIndex = SendIndex + 4;
							SendBuff[SendIndex++]=OxXX;
						}
						else
						{
							memcpy(&SendBuff[SendIndex],&dianneng[i*4],4);
							SendIndex = SendIndex + 4;
							SendBuff[SendIndex++]=0x00;
						}
					}
				}
				if (IsDataFlag == 0)
				{
					memset(&SendBuff[SendIndex],OxXX,25);
					SendIndex=SendIndex+25;
				}
			}else	//zhengchang
			{
			//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
				ts2.Day=BCD_INT32(&Data[0]+StPos,1);
				ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
				ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
				if (AutoFlg==1) TimeDecrease(&ts2,4,1);
				INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
				if (AutoFlg==0) TimeAdd(&ts,4,1);
				if((zone_so&0x7f) == JIANGSU)
				{
					SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
					SendBuff[SendIndex++]=0x23;
					INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
					INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
					INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
					SendBuff[SendIndex++]=FeiLvNum;
				}
				else{

					SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
					SendBuff[SendIndex++]=0;
					INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
					INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
					INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
					SendBuff[SendIndex++]=FeiLvNum;
				}
				//��ȡ������
				IsDataFlag=0;
				memset(Temp_FilePath,0x00,60);
				sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
				SdPrintf(YNPrint,PreFix,"AutoFlg=%d   ..... F169���ļ��� %s\n", AutoFlg,Temp_FilePath);
				SdPrintf(YNPrint,PreFix,"get161 begin\n\r");
				IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
				SdPrintf(YNPrint,PreFix,"get161 end\n\r");
				if(IsDataFlag==1)
				{
					IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x90,0x10,0,4,5,1,0,0,0,dftype);
					if (IsDataFlag == 0)
					{
						memset(&SendBuff[SendIndex],OxXX,25);
						SendIndex=SendIndex+25;
						//SendNAK(F, P, 0x0d);
						//return 3;
					}
					else
					{
						for(i=0;i<5;i++)
						{
							if((SendBuff[(SendIndex+1)+i*5]==OxXX)&&
							   (SendBuff[(SendIndex+2)+i*5]==OxXX)&&
							   (SendBuff[(SendIndex+3)+i*5]==OxXX)&&
							   (SendBuff[(SendIndex+4)+i*5]==OxXX))
									memset(&SendBuff[SendIndex+0+i*5],OxXX,5);
						}
						SendIndex = SendIndex + 25;
					}
				}
				else
				{
					memset(&SendBuff[SendIndex],OxXX,25);
					SendIndex=SendIndex+25;
					//SendNAK(F, P, 0x0d);
					//return 3;
				}
			}
		}else
		{
			ts10.Day=BCD_INT32(&Data[0]+StPos,1);
			ts10.Month=BCD_INT32(&Data[0]+StPos+1,1);
			ts10.Year=BCD_INT32(&Data[0]+StPos+2,1);
			if (AutoFlg==1) TimeDecrease(&ts10,4,1);
			INT32U_BCD(ts10.Day,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts10.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts10.Year,&SendBuff[SendIndex++],1);
			TimeAdd(&ts10,4,1);
			SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
			SendBuff[SendIndex++]=0;
			INT32U_BCD(ts10.Day,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts10.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts10.Year,&SendBuff[SendIndex++],1);
			SendBuff[SendIndex++]=FeiLvNum;
			memset(&SendBuff[SendIndex],OxXX,25);
			SendIndex=SendIndex+25;
		}
	}else//������
	{
		ts2.Day=BCD_INT32(&Data[0]+StPos,1);
		ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
		ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
		if (AutoFlg==1) TimeDecrease(&ts2,4,1);
		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		ts.Day=BCD_INT32(&Data[0]+StPos,1);
		ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
//		if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong
		if((zone_so&0x7f) == JIANGSU)
		{
			SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
			SendBuff[SendIndex++]=0x23;
			INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
			SendBuff[SendIndex++]=FeiLvNum;
		}
		else{

			SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
			SendBuff[SendIndex++]=0;
			INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
			SendBuff[SendIndex++]=FeiLvNum;
		}

		//��ȡ������
		IsDataFlag=0;
		memset(Temp_FilePath,0x00,60);

		sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
		if ((MeterType == 9) || (MeterType == 6))
		{
			dftype=1;//comm
		}
		else
		{
			dftype=1;
		}
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
		if(IsDataFlag==1)
		{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x90,0x10,0,4,5,1,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,25);
				SendIndex=SendIndex+25;
				//SendNAK(F, P, 0x0d);
				//return 3;
			}
			else
			{
				for(i=0;i<5;i++)
				{
					if((SendBuff[(SendIndex+1)+i*5]==OxXX)&&
					   (SendBuff[(SendIndex+2)+i*5]==OxXX)&&
					   (SendBuff[(SendIndex+3)+i*5]==OxXX)&&
					   (SendBuff[(SendIndex+4)+i*5]==OxXX))
							memset(&SendBuff[SendIndex+0+i*5],OxXX,5);
				}
				SendIndex = SendIndex + 25;
			}
		}
		else
		{
			memset(&SendBuff[SendIndex],OxXX,25);
			SendIndex=SendIndex+25;
			//SendNAK(F, P, 0x0d);
			//return 3;
		}
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 3;
}

INT16U Get_Level2Data_F170(INT8U Set,INT16U F,INT16U P,INT8U *Data)			//�����ն��������޹�����ʾֵ
{
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType,i;
	INT8U ridongjie_d[10];
	INT8U dianneng[20];
	TS ts,ts2;

	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	TS ts10;
	ts10 = ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	dftype = 1;
	if(((zone_so&0x7f)==JIANGXI) || (zone_so&0x7f) == TIANJIN || (zone_so&0x7f) == SHANGHAI||Jcfginfo->jzqpara.ChaoBiaoDongJieType)//dongjieyd
	{
		IsDataFlag=0;
		ts.Day=BCD_INT32(&Data[0]+StPos,1);
		ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
//		if (AutoFlg==0) TimeAdd(&ts,4,1);
		memset(Temp_FilePath,0x00,60);
		sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);//���ļ�
		SdPrintf(YNPrint,PreFix,"F170 ���ļ��� %s\n", Temp_FilePath);
		IsDataFlag=getMeterFile(MeterType,(char *)Temp_FilePath,ts,2);
		if(IsDataFlag==1)
		{
			memset(ridongjie_d, 0, 10);
			//FB01 ��Flag.cfg�� �ն���ʱ��
			IsDataFlag=getMetersData(MeterType,ridongjie_d,CJQno,MeterNo,0xFB,0x01,0,5,1,0,0,0,0,dftype);//lqq161
			if (IsDataFlag == 1)
			{
				SendBuff[SendIndex++]=ridongjie_d[2];//��//lqq161
				SendBuff[SendIndex++]=ridongjie_d[3];//��
				SendBuff[SendIndex++]=ridongjie_d[4];//��
				//�鳭��ʱ��  8�� 15�� 0��0��0

				SendBuff[SendIndex++]=0;
				SendBuff[SendIndex++]=0;
				INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);

				SendBuff[SendIndex++]=FeiLvNum;//���ʸ���

				memset(dianneng, 0, 20);
				IsDataFlag=getMetersData(MeterType,dianneng,CJQno,MeterNo,0x95,0x1f,0,20,1,0,0,0,0,dftype);//lqq161

				SdPrintf(YNPrint,PreFix,"0x95,0x1f: ");
				for(i=0;i<20;i++)
					SdPrintf(YNPrint," ","%02x", dianneng[i]);

				if (IsDataFlag ==1)
				{
					for(i=0;i<5;i++)
					{
						if((dianneng[(i)+i*3]==OxXX)&&(dianneng[(i+1)+i*3]==OxXX)&&(dianneng[(i+2)+i*3]==OxXX)&&(dianneng[(i+3)+i*3]==OxXX))
						{
							memcpy(&SendBuff[SendIndex],&dianneng[i*4],4);
							SendIndex = SendIndex + 4;
							//SendBuff[SendIndex++]=OxXX;
						}
						else
						{
							memcpy(&SendBuff[SendIndex],&dianneng[i*4],4);
							SendIndex = SendIndex + 4;
							//SendBuff[SendIndex++]=0x00;
						}
					}
				}
				if (IsDataFlag == 0)
				{
					memset(&SendBuff[SendIndex],OxXX,20);
					SendIndex=SendIndex+20;
				}
			}else	//zhengchang
			{
			//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
				ts2.Day=BCD_INT32(&Data[0]+StPos,1);
				ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
				ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
				if (AutoFlg==1) TimeDecrease(&ts2,4,1);
				INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
				if (AutoFlg==0) TimeAdd(&ts,4,1);
				if((zone_so&0x7f) == JIANGSU)
				{
					SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
					SendBuff[SendIndex++]=0x23;
					INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
					INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
					INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
					SendBuff[SendIndex++]=FeiLvNum;
				}
				else{

					SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
					SendBuff[SendIndex++]=0;
					INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
					INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
					INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
					SendBuff[SendIndex++]=FeiLvNum;
				}
				//��ȡ������
				IsDataFlag=0;
				memset(Temp_FilePath,0x00,60);
				sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
				SdPrintf(YNPrint,PreFix,"AutoFlg=%d   ..... F162 ���ļ��� %s\n", AutoFlg,Temp_FilePath);
				SdPrintf(YNPrint,PreFix,"get162 begin\n\r");
				IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
				SdPrintf(YNPrint,PreFix,"get162 end\n\r");
				if(IsDataFlag==1)
				{
					IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x10,0,4,5,0,0,0,0,dftype);
					if (IsDataFlag == 0)
					{
						memset(&SendBuff[SendIndex],OxXX,20);
						SendIndex=SendIndex+20;
						//SendNAK(F, P, 0x0d);
						//return 3;
					}
					else
					{
						for(i=0;i<5;i++)
						{
							if((SendBuff[(SendIndex+1)+i*4]==OxXX)&&
							   (SendBuff[(SendIndex+2)+i*4]==OxXX)&&
							   (SendBuff[(SendIndex+3)+i*4]==OxXX)&&
							   (SendBuff[(SendIndex+4)+i*4]==OxXX))
									memset(&SendBuff[SendIndex+0+i*5],OxXX,4);
						}
						SendIndex = SendIndex + 20;
					}
				}
				else
				{
					memset(&SendBuff[SendIndex],OxXX,20);
					SendIndex=SendIndex+20;
					//SendNAK(F, P, 0x0d);
					//return 3;
				}
			}
		}else
		{
			//maketemp();
			ts10.Day=BCD_INT32(&Data[0]+StPos,1);
			ts10.Month=BCD_INT32(&Data[0]+StPos+1,1);
			ts10.Year=BCD_INT32(&Data[0]+StPos+2,1);
			if (AutoFlg==1) TimeDecrease(&ts10,4,1);
			INT32U_BCD(ts10.Day,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts10.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts10.Year,&SendBuff[SendIndex++],1);
			TimeAdd(&ts10,4,1);
			SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
			SendBuff[SendIndex++]=0;
			INT32U_BCD(ts10.Day,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts10.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts10.Year,&SendBuff[SendIndex++],1);
			SendBuff[SendIndex++]=FeiLvNum;
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
		}
	}else //������
	{
		ts2.Day=BCD_INT32(&Data[0]+StPos,1);
		ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
		ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
		if (AutoFlg==1) TimeDecrease(&ts2,4,1);
		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		ts.Day=BCD_INT32(&Data[0]+StPos,1);
		ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
//		if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong
		if((zone_so&0x7f) == JIANGSU)
		{
			SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
			SendBuff[SendIndex++]=0x23;
			INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
			SendBuff[SendIndex++]=FeiLvNum;
		}
		else{

			SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
			SendBuff[SendIndex++]=0;
			INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
			SendBuff[SendIndex++]=FeiLvNum;
		}

		//��ȡ������
		IsDataFlag=0;
		memset(Temp_FilePath,0x00,60);
		sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);

		if ((MeterType == 9) || (MeterType == 6))
		{
			dftype=1;//comm
		}
		else
		{
			dftype=1;
		}
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
		if(IsDataFlag==1)
		{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x10,0,4,5,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,20);
				SendIndex=SendIndex+20;
				//SendNAK(F, P, 0x0d);
				//return 3;
			}
			else SendIndex = SendIndex + 20;
		}
		else
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 3;
		}
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 3;
}
//9��15�� �� 171-176
INT16U Get_Level2Data_F171(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType,i;
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong
	if((zone_so&0x7f) == JIANGSU)
	{
		SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
		SendBuff[SendIndex++]=0x23;
		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}
	else{

		SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
		SendBuff[SendIndex++]=0;
		INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}

	//��ȡ������
	IsDataFlag=0;
	memset(Temp_FilePath,0x00,60);

	sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x90,0x20,0,4,5,1,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,25);
			SendIndex=SendIndex+25;
			//SendNAK(F, P, 0x0d);
			//return 3;
		}
		else
		{
			for(i=0;i<5;i++)
			{
				if((SendBuff[(SendIndex+1)+i*5]==OxXX)&&
				   (SendBuff[(SendIndex+2)+i*5]==OxXX)&&
				   (SendBuff[(SendIndex+3)+i*5]==OxXX)&&
				   (SendBuff[(SendIndex+4)+i*5]==OxXX))
						memset(&SendBuff[SendIndex+0+i*5],OxXX,5);
			}
			SendIndex = SendIndex + 25;
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,25);
		SendIndex=SendIndex+25;
		//SendNAK(F, P, 0x0d);
		//return 3;
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 3;

}
INT16U Get_Level2Data_F172(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong
	if((zone_so&0x7f) == JIANGSU)
	{
		SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
		SendBuff[SendIndex++]=0x23;
		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}
	else{

		SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
		SendBuff[SendIndex++]=0;
		INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}

	//��ȡ������
	IsDataFlag=0;
	memset(Temp_FilePath,0x00,60);

	sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x20,0,4,5,0,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 3;
		}
		else SendIndex = SendIndex + 20;
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,20);
		SendIndex=SendIndex+20;
		//SendNAK(F, P, 0x0d);
		//return 3;
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 3;
}
INT16U Get_Level2Data_F173(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong
	if((zone_so&0x7f) == JIANGSU)
	{
		SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
		SendBuff[SendIndex++]=0x23;
		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}
	else{

		SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
		SendBuff[SendIndex++]=0;
		INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}

	//��ȡ������
	IsDataFlag=0;
	memset(Temp_FilePath,0x00,60);

	sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x30,0,4,5,0,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 3;
		}
		else SendIndex = SendIndex + 20;
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,20);
		SendIndex=SendIndex+20;
		//SendNAK(F, P, 0x0d);
		//return 3;
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 3;

}
INT16U Get_Level2Data_F174(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong
	if((zone_so&0x7f) == JIANGSU)
	{
		SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
		SendBuff[SendIndex++]=0x23;
		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}
	else{

		SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
		SendBuff[SendIndex++]=0;
		INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}

	//��ȡ������
	IsDataFlag=0;
	memset(Temp_FilePath,0x00,60);

	sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x50,0,4,5,0,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 3;
		}
		else SendIndex = SendIndex + 20;
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,20);
		SendIndex=SendIndex+20;
		//SendNAK(F, P, 0x0d);
		//return 3;
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 3;
}
INT16U Get_Level2Data_F175(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong
	if((zone_so&0x7f) == JIANGSU)
	{
		SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
		SendBuff[SendIndex++]=0x23;
		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}
	else{

		SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
		SendBuff[SendIndex++]=0;
		INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}

	//��ȡ������
	IsDataFlag=0;
	memset(Temp_FilePath,0x00,60);

	sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x60,0,4,5,0,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 3;
		}
		else SendIndex = SendIndex + 20;
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,20);
		SendIndex=SendIndex+20;
		//SendNAK(F, P, 0x0d);
		//return 3;
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 3;
}
INT16U Get_Level2Data_F176(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong
	if((zone_so&0x7f) == JIANGSU)
	{
		SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
		SendBuff[SendIndex++]=0x23;
		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}
	else{

		SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
		SendBuff[SendIndex++]=0;
		INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}

	//��ȡ������
	IsDataFlag=0;
	memset(Temp_FilePath,0x00,60);

	sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x40,0,4,5,0,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 3;
		}
		else SendIndex = SendIndex + 20;
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,20);
		SendIndex=SendIndex+20;
		//SendNAK(F, P, 0x0d);
		//return 3;
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 3;
}

INT16U Get_Level2Data_F177(INT8U Set,INT16U F,INT16U P,INT8U *Data)//�¶��������й�����ʾֵ���ܣ����ʣ�
{
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType,i;
	INT8U ridongjie_d[10];
	INT8U dianneng[20];
	INT8U ReadFailFlag=0;
	TS ts,ts2;

	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=3;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	dftype = 1;
	if(((zone_so&0x7f)==XINJIANG) ||((zone_so&0x7f)==JIANGXI) ||(zone_so&0x7f) == TIANJIN || (zone_so&0x7f) == SHANGHAI|| (zone_so&0x7f) == SHANGHAI)//dongjieyd
	{
		ts2.Month=BCD_INT32(&Data[0]+StPos,1);
		ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==1) TimeDecrease(&ts2,5,1);
		ts.Month=BCD_INT32(&Data[0]+StPos,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==0) TimeAdd(&ts,5,1);
		memset(Temp_FilePath,0x00,60);
		sprintf((char *)Temp_FilePath,"/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
		SdPrintf(YNPrint,PreFix,"F177 ���ļ��� %s\n", Temp_FilePath);
		IsDataFlag=getMeterFile(MeterType,(char *)Temp_FilePath,ts,3);
		if(IsDataFlag==1)
		{
			memset(ridongjie_d, 0, 10);
			IsDataFlag=getMetersData(MeterType,ridongjie_d,CJQno,MeterNo,0xFb,0x01,0,5,1,0,0,0,0,dftype);//lqq161
			SdPrintf(YNPrint,PreFix,"ridongjie_m: ");
			for(i=0;i<10;i++)
				SdPrintf(YNPrint,PreFix,"[%d %02x]", i, ridongjie_d[i]);

//			if (0)
			if (IsDataFlag == 1)
			{
				SendBuff[SendIndex++]=ridongjie_d[3];//��
				SendBuff[SendIndex++]=ridongjie_d[4];//��
				SendBuff[SendIndex++]=0;
				SendBuff[SendIndex++]=0;
				SendBuff[SendIndex++]=0x01;
				INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
				SendBuff[SendIndex++]=FeiLvNum;//���ʸ���

				memset(dianneng, 0, 20);

				IsDataFlag=getMetersData(MeterType,dianneng,CJQno,MeterNo,0xFb,0x02,0,20,1,1,0,0,0,dftype);//lqq161

				SdPrintf(YNPrint,PreFix,"0xFC,0x02: ");
				for(i=0;i<20;i++)
					SdPrintf(YNPrint,PreFix,"%02x", dianneng[i]);

				if (IsDataFlag ==1)
				{
					for(i=0;i<5;i++)
					{
						if((dianneng[(i)+i*3]==OxXX)&&(dianneng[(i+1)+i*3]==OxXX)&&(dianneng[(i+2)+i*3]==OxXX)&&(dianneng[(i+3)+i*3]==OxXX))
						{
							memcpy(&SendBuff[SendIndex],&dianneng[i*4],4);
							SendIndex = SendIndex + 4;
							SendBuff[SendIndex++]=OxXX;
						}
						else
						{
							memcpy(&SendBuff[SendIndex],&dianneng[i*4],4);
							SendIndex = SendIndex + 4;
							SendBuff[SendIndex++]=0x00;
						}
					}
				}
				if (IsDataFlag == 0)
				{
					memset(&SendBuff[SendIndex],OxXX,25);
					SendIndex=SendIndex+25;
				}
			}
		}else
			ReadFailFlag = 1;///////////////////////lcy
	}else
		ReadFailFlag = 1;//

	if(ReadFailFlag) {
		ts2.Month=BCD_INT32(&Data[0]+StPos,1);
		ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==1) TimeDecrease(&ts2,5,1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		ts.Month=BCD_INT32(&Data[0]+StPos,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==0) TimeAdd(&ts,5,1);
		SendBuff[SendIndex++]=0;
		SendBuff[SendIndex++]=0;
		SendBuff[SendIndex++]=0x01;
		INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
		//��ȡ������
		IsDataFlag=0;
		memset(Temp_FilePath,0x00,60);

		sprintf((char *)Temp_FilePath,"/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
		if ((MeterType == 9) || (MeterType == 6))
		{
			dftype=1;//comm
		}
		else
		{
			dftype=1;
		}
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,3);
		if(IsDataFlag==1)
		{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x90,0x10,0,4,5,1,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,25);
				SendIndex=SendIndex+25;
				//SendNAK(F, P, 0x0d);
				//return 2;
			}
			else
			{
				for(i=0;i<5;i++)
				{
					if((SendBuff[(SendIndex+1)+i*5]==OxXX)&&
					   (SendBuff[(SendIndex+2)+i*5]==OxXX)&&
					   (SendBuff[(SendIndex+3)+i*5]==OxXX)&&
					   (SendBuff[(SendIndex+4)+i*5]==OxXX))
							memset(&SendBuff[SendIndex+0+i*5],OxXX,5);
				}
				SendIndex = SendIndex + 25;
			}
		}
		else
		{
			memset(&SendBuff[SendIndex],OxXX,25);
			SendIndex=SendIndex+25;
			//SendNAK(F, P, 0x0d);
			//return 2;
		}
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 2;
}
INT16U Get_Level2Data_F178(INT8U Set,INT16U F,INT16U P,INT8U *Data)		//�¶��������޹�����ʾֵ���ܣ����ʣ�
{
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType,i;
	INT8U ridongjie_d[10];
	INT8U dianneng[20];
	INT8U ReadFailFlag=0;
	TS ts,ts2;

	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=3;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	dftype = 1;
	if(((zone_so&0x7f)==JIANGXI) || (zone_so&0x7f) == TIANJIN || (zone_so&0x7f) == SHANGHAI||Jcfginfo->jzqpara.ChaoBiaoDongJieType)//dongjieyd
	{
		SdPrintf(YNPrint,PreFix,"AutoFlg�� %d\n", AutoFlg);
		IsDataFlag=0;
		ts2.Month=BCD_INT32(&Data[0]+StPos,1);
		ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==1) TimeDecrease(&ts2,5,1);
		ts.Month=BCD_INT32(&Data[0]+StPos,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==0) TimeAdd(&ts,5,1);
		memset(Temp_FilePath,0x00,60);
		sprintf((char *)Temp_FilePath,"/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
		SdPrintf(YNPrint,PreFix,"F178���ļ��� %s\n", Temp_FilePath);
		IsDataFlag=getMeterFile(MeterType,(char *)Temp_FilePath,ts,3);
		if(IsDataFlag==1)
		{
			memset(ridongjie_d, 0, 10);
			IsDataFlag=getMetersData(MeterType,ridongjie_d,CJQno,MeterNo,0xFc,0x01,0,5,1,0,0,0,0,dftype);
			SdPrintf(YNPrint,PreFix,"ridongjie_m: ");
			for(i=0;i<10;i++)
				SdPrintf(YNPrint,PreFix,"[%d %02x]", i, ridongjie_d[i]);

//			if (0)
			if (IsDataFlag == 1)
			{
				SendBuff[SendIndex++]=ridongjie_d[3];//��
				SendBuff[SendIndex++]=ridongjie_d[4];//��
				SendBuff[SendIndex++]=0;
				SendBuff[SendIndex++]=0;
				SendBuff[SendIndex++]=0x01;
				INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
				SendBuff[SendIndex++]=FeiLvNum;//���ʸ���

				memset(dianneng, 0, 20);
				IsDataFlag=getMetersData(MeterType,dianneng,CJQno,MeterNo,0xFc,0x04,0,20,1,0,0,0,0,dftype);//lqq161

				SdPrintf(YNPrint,PreFix,"0xFc,0x04: ");
				for(i=0;i<20;i++)
					SdPrintf(YNPrint,PreFix,"%02x", dianneng[i]);

				if (IsDataFlag ==1)
				{
					for(i=0;i<5;i++)
					{
						if((dianneng[(i)+i*3]==OxXX)&&(dianneng[(i+1)+i*3]==OxXX)&&(dianneng[(i+2)+i*3]==OxXX)&&(dianneng[(i+3)+i*3]==OxXX))
						{
							memcpy(&SendBuff[SendIndex],&dianneng[i*4],4);
							SendIndex = SendIndex + 4;
						}
						else
						{
							memcpy(&SendBuff[SendIndex],&dianneng[i*4],4);
							SendIndex = SendIndex + 4;
						}
					}
				}
				if (IsDataFlag == 0)
				{
					memset(&SendBuff[SendIndex],OxXX,20);
					SendIndex=SendIndex+20;
				}
			}else ReadFailFlag=1;
		}else ReadFailFlag=1;
	}else ReadFailFlag=1;

	if(ReadFailFlag) {
		ts2.Month=BCD_INT32(&Data[0]+StPos,1);
		ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==1) TimeDecrease(&ts2,5,1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		ts.Month=BCD_INT32(&Data[0]+StPos,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==0) TimeAdd(&ts,5,1);
		SendBuff[SendIndex++]=0;
		SendBuff[SendIndex++]=0;
		SendBuff[SendIndex++]=0x01;
		INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
		//��ȡ������
		IsDataFlag=0;
		memset(Temp_FilePath,0x00,60);

		sprintf((char *)Temp_FilePath,"/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
		if ((MeterType == 9) || (MeterType == 6))
		{
			dftype=1;//comm
		}
		else
		{
			dftype=1;
		}
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,3);
		if(IsDataFlag==1)
		{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x10,0,4,5,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,20);
				SendIndex=SendIndex+20;
				//SendNAK(F, P, 0x0d);
				//return 2;
			}
			else SendIndex = SendIndex + 20;
		}
		else
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 2;
		}
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 2;
}
INT16U Get_Level2Data_F179(INT8U Set,INT16U F,INT16U P,INT8U *Data)		//�¶��ᷴ���й�����ʾֵ
{
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType,i;
	INT8U ridongjie_d[10];
	INT8U dianneng[20];
	INT8U ReadFailFlag=0;
	TS ts,ts2;

	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=3;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	dftype=1;
	if(((zone_so&0x7f)==XINJIANG) ||((zone_so&0x7f)==JIANGXI)|| (zone_so&0x7f) == TIANJIN || (zone_so&0x7f) == SHANGHAI ||Jcfginfo->jzqpara.ChaoBiaoDongJieType)//dongjieyd
	{
		ReadFailFlag  =0;
		IsDataFlag=0;
		ts2.Month=BCD_INT32(&Data[0]+StPos,1);
		ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==1) TimeDecrease(&ts2,5,1);
		ts.Month=BCD_INT32(&Data[0]+StPos,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==0) TimeAdd(&ts,5,1);
		memset(Temp_FilePath,0x00,60);
		sprintf((char *)Temp_FilePath,"/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
		SdPrintf(YNPrint,PreFix,"F179���ļ��� %s\n", Temp_FilePath);
		IsDataFlag=getMeterFile(MeterType,(char *)Temp_FilePath,ts,3);
		if(IsDataFlag==1)
		{
			memset(ridongjie_d, 0, 10);
			IsDataFlag=getMetersData(MeterType,ridongjie_d,CJQno,MeterNo,0xFc,0x01,0,5,1,0,0,0,0,dftype);//lqq161
			if (IsDataFlag == 1)
			{
				SendBuff[SendIndex++]=ridongjie_d[3];//��
				SendBuff[SendIndex++]=ridongjie_d[4];//��
				SendBuff[SendIndex++]=0;
				SendBuff[SendIndex++]=0;
				SendBuff[SendIndex++]=0x01;
				INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
				SendBuff[SendIndex++]=FeiLvNum;//���ʸ���
				memset(dianneng, 0, 20);
				IsDataFlag=getMetersData(MeterType,dianneng,CJQno,MeterNo,0xFC,0x03,0,20,1,1,0,0,0,dftype);//lqq161

				SdPrintf(YNPrint,PreFix,"0xFC,0x03: ");
				for(i=0;i<20;i++)
					SdPrintf(YNPrint,PreFix,"%02x", dianneng[i]);

				if (IsDataFlag ==1)
				{
					for(i=0;i<5;i++)
					{
						if((dianneng[(i)+i*3]==OxXX)&&(dianneng[(i+1)+i*3]==OxXX)&&(dianneng[(i+2)+i*3]==OxXX)&&(dianneng[(i+3)+i*3]==OxXX))
						{
							memcpy(&SendBuff[SendIndex],&dianneng[i*4],4);
							SendIndex = SendIndex + 4;
							SendBuff[SendIndex++]=OxXX;
						}
						else
						{
							memcpy(&SendBuff[SendIndex],&dianneng[i*4],4);
							SendIndex = SendIndex + 4;
							SendBuff[SendIndex++]=0x00;
						}
					}
				}else	{
					memset(&SendBuff[SendIndex],OxXX,25);
					SendIndex=SendIndex+25;
				}
			}else {
				ReadFailFlag =1;
			}
		}else {			//δ�ҵ��ն�������
			ReadFailFlag=1;
		}
	}else   ReadFailFlag=1;

	if(ReadFailFlag) {
		ts2.Month=BCD_INT32(&Data[0]+StPos,1);
		ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==1) TimeDecrease(&ts2,5,1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		ts.Month=BCD_INT32(&Data[0]+StPos,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==0) TimeAdd(&ts,5,1);
		SendBuff[SendIndex++]=0;
		SendBuff[SendIndex++]=0;
		SendBuff[SendIndex++]=0x01;
		INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
		//��ȡ������
		IsDataFlag=0;
		memset(Temp_FilePath,0x00,60);

		sprintf((char *)Temp_FilePath,"/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
		if ((MeterType == 9) || (MeterType == 6))
		{
			dftype=1;//comm
		}
		else
		{
			dftype=1;
		}
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,3);
		if(IsDataFlag==1)
		{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x90,0x20,0,4,5,1,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,25);
				SendIndex=SendIndex+25;
				//SendNAK(F, P, 0x0d);
				//return 2;
			}
			else
			{
				for(i=0;i<5;i++)
				{
					if((SendBuff[(SendIndex+1)+i*5]==OxXX)&&
					   (SendBuff[(SendIndex+2)+i*5]==OxXX)&&
					   (SendBuff[(SendIndex+3)+i*5]==OxXX)&&
					   (SendBuff[(SendIndex+4)+i*5]==OxXX))
							memset(&SendBuff[SendIndex+0+i*5],OxXX,5);
				}
				SendIndex = SendIndex + 25;
			}
		}
		else
		{
			memset(&SendBuff[SendIndex],OxXX,25);
			SendIndex=SendIndex+25;
			//SendNAK(F, P, 0x0d);
			//return 2;
		}
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 2;
}

INT16U Get_Level2Data_F180(INT8U Set,INT16U F,INT16U P,INT8U *Data)		//�¶��ᷴ���޹�����ʾֵ���ܣ����ʣ�
{
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType,i;
	INT8U ridongjie_d[10];
	INT8U dianneng[20];
	INT8U ReadFailFlag=0;
	TS ts,ts2;

	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=3;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;

	dftype=1;

	if(((zone_so&0x7f)==JIANGXI) || (zone_so&0x7f) == TIANJIN || (zone_so&0x7f) == SHANGHAI ||Jcfginfo->jzqpara.ChaoBiaoDongJieType)//dongjieyd
	{
		IsDataFlag=0;
		ts2.Month=BCD_INT32(&Data[0]+StPos,1);
		ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==1) TimeDecrease(&ts2,5,1);
		ts.Month=BCD_INT32(&Data[0]+StPos,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==0) TimeAdd(&ts,5,1);
		memset(Temp_FilePath,0x00,60);
		sprintf((char *)Temp_FilePath,"/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
		SdPrintf(YNPrint,PreFix,"F180 ���ļ��� %s\n", Temp_FilePath);
		IsDataFlag=getMeterFile(MeterType,(char *)Temp_FilePath,ts,3);
		if(IsDataFlag==1)
		{
			memset(ridongjie_d, 0, 10);
			IsDataFlag=getMetersData(MeterType,ridongjie_d,CJQno,MeterNo,0xFc,0x01,0,5,1,0,0,0,0,dftype);//lqq161
			if (IsDataFlag == 1)
			{
				SendBuff[SendIndex++]=ridongjie_d[3];//��
				SendBuff[SendIndex++]=ridongjie_d[4];//��
				SendBuff[SendIndex++]=0;
				SendBuff[SendIndex++]=0;
				SendBuff[SendIndex++]=0x01;
				INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
				SendBuff[SendIndex++]=FeiLvNum;//���ʸ���

				memset(dianneng, 0, 20);
				IsDataFlag=getMetersData(MeterType,dianneng,CJQno,MeterNo,0xFC,0x05,0,20,1,0,0,0,0,dftype);//lqq161

				SdPrintf(YNPrint,PreFix,"0xFC,0x05: ");
				for(i=0;i<20;i++)
					SdPrintf(YNPrint,PreFix,"%02x", dianneng[i]);

				if (IsDataFlag ==1)
				{
					for(i=0;i<5;i++)
					{
						if((dianneng[(i)+i*3]==OxXX)&&(dianneng[(i+1)+i*3]==OxXX)&&(dianneng[(i+2)+i*3]==OxXX)&&(dianneng[(i+3)+i*3]==OxXX))
						{
							memcpy(&SendBuff[SendIndex],&dianneng[i*4],4);
							SendIndex = SendIndex + 4;
							//SendBuff[SendIndex++]=OxXX;
						}
						else
						{
							memcpy(&SendBuff[SendIndex],&dianneng[i*4],4);
							SendIndex = SendIndex + 4;
							//SendBuff[SendIndex++]=0x00;
						}
					}
				}
				if (IsDataFlag == 0)
				{
					memset(&SendBuff[SendIndex],OxXX,20);
					SendIndex=SendIndex+20;
				}
			}else  ReadFailFlag=1;
		}else  ReadFailFlag=1;
	}else 	ReadFailFlag=1;

	if(ReadFailFlag ==1) {
		ts2.Month=BCD_INT32(&Data[0]+StPos,1);
		ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==1) TimeDecrease(&ts2,5,1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		ts.Month=BCD_INT32(&Data[0]+StPos,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==0) TimeAdd(&ts,5,1);
		SendBuff[SendIndex++]=0;
		SendBuff[SendIndex++]=0;
		SendBuff[SendIndex++]=0x01;
		INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
		//��ȡ������
		IsDataFlag=0;
		memset(Temp_FilePath,0x00,60);

		sprintf((char *)Temp_FilePath,"/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
		if ((MeterType == 9) || (MeterType == 6))
		{
			dftype=1;//comm
		}
		else
		{
			dftype=1;
		}
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,3);
		if(IsDataFlag==1)
		{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x20,0,4,5,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,20);
				SendIndex=SendIndex+20;
				//SendNAK(F, P, 0x0d);
				//return 2;
			}
			else SendIndex = SendIndex + 20;
		}
		else
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 2;
		}
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 2;
}
INT16U Get_Level2Data_F181(INT8U Set,INT16U F,INT16U P,INT8U *Data)		//�¶���һ�����޹�����ʾֵ���ܣ����ʣ�
{
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType,i;
	INT8U ridongjie_d[10];
	INT8U dianneng[20];
	INT8U ReadFailFlag=0;
	TS ts,ts2;

	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=3;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	dftype=1;
	if(((zone_so&0x7f)==JIANGXI) || (zone_so&0x7f) == TIANJIN || (zone_so&0x7f) == SHANGHAI ||Jcfginfo->jzqpara.ChaoBiaoDongJieType)//dongjieyd
	{
		IsDataFlag=0;
		ts2.Month=BCD_INT32(&Data[0]+StPos,1);
		ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==1) TimeDecrease(&ts2,5,1);
		ts.Month=BCD_INT32(&Data[0]+StPos,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==0) TimeAdd(&ts,5,1);
		memset(Temp_FilePath,0x00,60);
		sprintf((char *)Temp_FilePath,"/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
		SdPrintf(YNPrint,PreFix,"F181���ļ��� %s\n", Temp_FilePath);
		IsDataFlag=getMeterFile(MeterType,(char *)Temp_FilePath,ts,3);
		if(IsDataFlag==1)
		{
			memset(ridongjie_d, 0, 10);
			IsDataFlag=getMetersData(MeterType,ridongjie_d,CJQno,MeterNo,0xFc,0x01,0,5,1,0,0,0,0,dftype);//lqq161
			if (IsDataFlag == 1)
			{
				SendBuff[SendIndex++]=ridongjie_d[3];//��
				SendBuff[SendIndex++]=ridongjie_d[4];//��
				SendBuff[SendIndex++]=0;
				SendBuff[SendIndex++]=0;
				SendBuff[SendIndex++]=0x01;
				INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
				SendBuff[SendIndex++]=FeiLvNum;//���ʸ���
				memset(dianneng, 0, 20);
				IsDataFlag=getMetersData(MeterType,dianneng,CJQno,MeterNo,0xFC,0x06,0,20,1,0,0,0,0,dftype);//lqq161

				SdPrintf(YNPrint,PreFix,"0xFc,0x06: ");
				for(i=0;i<20;i++)
					SdPrintf(YNPrint," ","%02x", dianneng[i]);

				if (IsDataFlag ==1)
				{
					for(i=0;i<5;i++)
					{
						if((dianneng[(i)+i*3]==OxXX)&&(dianneng[(i+1)+i*3]==OxXX)&&(dianneng[(i+2)+i*3]==OxXX)&&(dianneng[(i+3)+i*3]==OxXX))
						{
							memcpy(&SendBuff[SendIndex],&dianneng[i*4],4);
							SendIndex = SendIndex + 4;
							//SendBuff[SendIndex++]=OxXX;
						}
						else
						{
							memcpy(&SendBuff[SendIndex],&dianneng[i*4],4);
							SendIndex = SendIndex + 4;
							//SendBuff[SendIndex++]=0x00;
						}
					}
				}
				if (IsDataFlag == 0)
				{
					memset(&SendBuff[SendIndex],OxXX,20);
					SendIndex=SendIndex+20;
				}
			}else  ReadFailFlag=1;
		}else  ReadFailFlag=1;
	}else 	ReadFailFlag=1;

	if(ReadFailFlag ==1) {
		ts2.Month=BCD_INT32(&Data[0]+StPos,1);
		ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==1) TimeDecrease(&ts2,5,1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		ts.Month=BCD_INT32(&Data[0]+StPos,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==0) TimeAdd(&ts,5,1);
		SendBuff[SendIndex++]=0;
		SendBuff[SendIndex++]=0;
		SendBuff[SendIndex++]=0x01;
		INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
		//��ȡ������
		IsDataFlag=0;
		memset(Temp_FilePath,0x00,60);

		sprintf((char *)Temp_FilePath,"/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
		if ((MeterType == 9) || (MeterType == 6))
		{
			dftype=1;//comm
		}
		else
		{
			dftype=1;
		}
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,3);
		if(IsDataFlag==1)
		{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x30,0,4,5,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,20);
				SendIndex=SendIndex+20;
				//SendNAK(F, P, 0x0d);
				//return 2;
			}
			else SendIndex = SendIndex + 20;
		}
		else
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 2;
		}
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 2;

}
INT16U Get_Level2Data_F182(INT8U Set,INT16U F,INT16U P,INT8U *Data)		//�¶���������޹�����ʾֵ���ܣ����ʣ�
{
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType,i;
	INT8U ridongjie_d[10];
	INT8U dianneng[20];
	INT8U ReadFailFlag=0;
	TS ts,ts2;

	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=3;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	dftype=1;
	if(((zone_so&0x7f)==JIANGXI) || (zone_so&0x7f) == TIANJIN || (zone_so&0x7f) == SHANGHAI ||Jcfginfo->jzqpara.ChaoBiaoDongJieType)//dongjieyd
	{
		IsDataFlag=0;
		ts2.Month=BCD_INT32(&Data[0]+StPos,1);
		ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==1) TimeDecrease(&ts2,5,1);
		ts.Month=BCD_INT32(&Data[0]+StPos,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==0) TimeAdd(&ts,5,1);
		memset(Temp_FilePath,0x00,60);
		sprintf((char *)Temp_FilePath,"/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
		SdPrintf(YNPrint,PreFix,"F182���ļ��� %s\n", Temp_FilePath);
		IsDataFlag=getMeterFile(MeterType,(char *)Temp_FilePath,ts,3);
		if(IsDataFlag==1)
		{
			memset(ridongjie_d, 0, 10);
			IsDataFlag=getMetersData(MeterType,ridongjie_d,CJQno,MeterNo,0xFc,0x01,0,5,1,0,0,0,0,dftype);//lqq161
			if (IsDataFlag == 1)
			{
				SendBuff[SendIndex++]=ridongjie_d[3];//��
				SendBuff[SendIndex++]=ridongjie_d[4];//��
				SendBuff[SendIndex++]=0;
				SendBuff[SendIndex++]=0;
				SendBuff[SendIndex++]=0x01;
				INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
				SendBuff[SendIndex++]=FeiLvNum;//���ʸ���
				memset(dianneng, 0, 20);
				IsDataFlag=getMetersData(MeterType,dianneng,CJQno,MeterNo,0xFC,0x07,0,20,1,0,0,0,0,dftype);//lqq161

				SdPrintf(YNPrint,PreFix,"0xFc,0x07: ");
				for(i=0;i<20;i++)
					SdPrintf(YNPrint,PreFix,"%02x", dianneng[i]);

				if (IsDataFlag ==1)
				{
					for(i=0;i<5;i++)
					{
						if((dianneng[(i)+i*3]==OxXX)&&(dianneng[(i+1)+i*3]==OxXX)&&(dianneng[(i+2)+i*3]==OxXX)&&(dianneng[(i+3)+i*3]==OxXX))
						{
							memcpy(&SendBuff[SendIndex],&dianneng[i*4],4);
							SendIndex = SendIndex + 4;
							//SendBuff[SendIndex++]=OxXX;
						}
						else
						{
							memcpy(&SendBuff[SendIndex],&dianneng[i*4],4);
							SendIndex = SendIndex + 4;
							//SendBuff[SendIndex++]=0x00;
						}
					}
				}
				if (IsDataFlag == 0)
				{
					memset(&SendBuff[SendIndex],OxXX,20);
					SendIndex=SendIndex+20;
				}
			}else  ReadFailFlag=1;
		}else  ReadFailFlag=1;
	}else 	ReadFailFlag=1;

	if(ReadFailFlag ==1) {
		ts2.Month=BCD_INT32(&Data[0]+StPos,1);
		ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==1) TimeDecrease(&ts2,5,1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		ts.Month=BCD_INT32(&Data[0]+StPos,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==0) TimeAdd(&ts,5,1);
		SendBuff[SendIndex++]=0;
		SendBuff[SendIndex++]=0;
		SendBuff[SendIndex++]=0x01;
		INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
		//��ȡ������
		IsDataFlag=0;
		memset(Temp_FilePath,0x00,60);

		sprintf((char *)Temp_FilePath,"/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
		if ((MeterType == 9) || (MeterType == 6))
		{
			dftype=1;//comm
		}
		else
		{
			dftype=1;
		}
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,3);
		if(IsDataFlag==1)
		{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x50,0,4,5,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,20);
				SendIndex=SendIndex+20;
				//SendNAK(F, P, 0x0d);
				//return 2;
			}
			else SendIndex = SendIndex + 20;
		}
		else
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 2;
		}
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 2;
}
INT16U Get_Level2Data_F183(INT8U Set,INT16U F,INT16U P,INT8U *Data)		//�¶����������޹�����ʾֵ���ܣ����ʣ�
{
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType,i;
	INT8U ridongjie_d[10];
	INT8U dianneng[20];
	INT8U ReadFailFlag=0;
	TS ts,ts2;

	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=3;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	dftype=1;
	if(((zone_so&0x7f)==JIANGXI) || (zone_so&0x7f) == TIANJIN || (zone_so&0x7f) == SHANGHAI ||Jcfginfo->jzqpara.ChaoBiaoDongJieType)//dongjieyd
	{
		IsDataFlag=0;
		ts2.Month=BCD_INT32(&Data[0]+StPos,1);
		ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==1) TimeDecrease(&ts2,5,1);
		ts.Month=BCD_INT32(&Data[0]+StPos,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==0) TimeAdd(&ts,5,1);
		memset(Temp_FilePath,0x00,60);
		sprintf((char *)Temp_FilePath,"/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
		SdPrintf(YNPrint,PreFix,"F183���ļ��� %s\n", Temp_FilePath);
		IsDataFlag=getMeterFile(MeterType,(char *)Temp_FilePath,ts,3);
		if(IsDataFlag==1)
		{
			memset(ridongjie_d, 0, 10);
			IsDataFlag=getMetersData(MeterType,ridongjie_d,CJQno,MeterNo,0xFc,0x01,0,5,1,0,0,0,0,dftype);//lqq161
			if (IsDataFlag == 1)
			{
				SendBuff[SendIndex++]=ridongjie_d[3];//��
				SendBuff[SendIndex++]=ridongjie_d[4];//��
				SendBuff[SendIndex++]=0;
				SendBuff[SendIndex++]=0;
				SendBuff[SendIndex++]=0x01;
				INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
				SendBuff[SendIndex++]=FeiLvNum;//���ʸ���
				memset(dianneng, 0, 20);
				IsDataFlag=getMetersData(MeterType,dianneng,CJQno,MeterNo,0xFC,0x08,0,20,1,0,0,0,0,dftype);//lqq161

				SdPrintf(YNPrint,PreFix,"0xFc,0x08: ");
				for(i=0;i<20;i++)
					SdPrintf(YNPrint," ","%02x", dianneng[i]);

				if (IsDataFlag ==1)
				{
					for(i=0;i<5;i++)
					{
						if((dianneng[(i)+i*3]==OxXX)&&(dianneng[(i+1)+i*3]==OxXX)&&(dianneng[(i+2)+i*3]==OxXX)&&(dianneng[(i+3)+i*3]==OxXX))
						{
							memcpy(&SendBuff[SendIndex],&dianneng[i*4],4);
							SendIndex = SendIndex + 4;
							//SendBuff[SendIndex++]=OxXX;
						}
						else
						{
							memcpy(&SendBuff[SendIndex],&dianneng[i*4],4);
							SendIndex = SendIndex + 4;
							//SendBuff[SendIndex++]=0x00;
						}
					}
				}
				if (IsDataFlag == 0)
				{
					memset(&SendBuff[SendIndex],OxXX,20);
					SendIndex=SendIndex+20;
				}
			}else  ReadFailFlag=1;
		}else  ReadFailFlag=1;
	}else 	ReadFailFlag=1;

	if(ReadFailFlag ==1) {
		ts2.Month=BCD_INT32(&Data[0]+StPos,1);
		ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==1) TimeDecrease(&ts2,5,1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		ts.Month=BCD_INT32(&Data[0]+StPos,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==0) TimeAdd(&ts,5,1);
		SendBuff[SendIndex++]=0;
		SendBuff[SendIndex++]=0;
		SendBuff[SendIndex++]=0x01;
		INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
		//��ȡ������
		IsDataFlag=0;
		memset(Temp_FilePath,0x00,60);

		sprintf((char *)Temp_FilePath,"/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
		if ((MeterType == 9) || (MeterType == 6))
		{
			dftype=1;//comm
		}
		else
		{
			dftype=1;
		}
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,3);
		if(IsDataFlag==1)
		{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x60,0,4,5,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,20);
				SendIndex=SendIndex+20;
				//SendNAK(F, P, 0x0d);
				//return 2;
			}
			else SendIndex = SendIndex + 20;
		}
		else
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 2;
		}
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 2;
}
INT16U Get_Level2Data_F184(INT8U Set,INT16U F,INT16U P,INT8U *Data)			//�¶����������޹�����ʾֵ���ܣ����ʣ�
{
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType,i;
	INT8U ridongjie_d[10];
	INT8U dianneng[20];
	INT8U ReadFailFlag=0;
	TS ts,ts2;

	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=3;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	dftype=1;
	if(((zone_so&0x7f)==JIANGXI) || (zone_so&0x7f) == TIANJIN || (zone_so&0x7f) == SHANGHAI ||Jcfginfo->jzqpara.ChaoBiaoDongJieType)//dongjieyd
	{

		IsDataFlag=0;
		ts2.Month=BCD_INT32(&Data[0]+StPos,1);
		ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==1) TimeDecrease(&ts2,5,1);
		ts.Month=BCD_INT32(&Data[0]+StPos,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==0) TimeAdd(&ts,5,1);
		memset(Temp_FilePath,0x00,60);
		sprintf((char *)Temp_FilePath,"/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
		SdPrintf(YNPrint,PreFix,"F184���ļ��� %s\n", Temp_FilePath);
		IsDataFlag=getMeterFile(MeterType,(char *)Temp_FilePath,ts,3);
		if(IsDataFlag==1)
		{
			memset(ridongjie_d, 0, 10);
			IsDataFlag=getMetersData(MeterType,ridongjie_d,CJQno,MeterNo,0xFc,0x01,0,5,1,0,0,0,0,dftype);//lqq161
			SdPrintf(YNPrint,PreFix," ridongjie_m: ");
			for(i=0;i<10;i++)
				SdPrintf(YNPrint," ","[%d %02x]", i, ridongjie_d[i]);

//			if (0)
			if (IsDataFlag == 1)
			{
				SendBuff[SendIndex++]=ridongjie_d[3];//��
				SendBuff[SendIndex++]=ridongjie_d[4];//��
				SendBuff[SendIndex++]=0;
				SendBuff[SendIndex++]=0;
				SendBuff[SendIndex++]=0x01;
				INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
				SendBuff[SendIndex++]=FeiLvNum;//���ʸ���
				memset(dianneng, 0, 20);
				IsDataFlag=getMetersData(MeterType,dianneng,CJQno,MeterNo,0xFC,0x09,0,20,1,0,0,0,0,dftype);//lqq161

				SdPrintf(YNPrint,PreFix," 0xFc,0x09: ");
				for(i=0;i<20;i++)
					SdPrintf(YNPrint," ","%02x", dianneng[i]);

				if (IsDataFlag ==1)
				{
					for(i=0;i<5;i++)
					{
						if((dianneng[(i)+i*3]==OxXX)&&(dianneng[(i+1)+i*3]==OxXX)&&(dianneng[(i+2)+i*3]==OxXX)&&(dianneng[(i+3)+i*3]==OxXX))
						{
							memcpy(&SendBuff[SendIndex],&dianneng[i*4],4);
							SendIndex = SendIndex + 4;
							//SendBuff[SendIndex++]=OxXX;
						}
						else
						{
							memcpy(&SendBuff[SendIndex],&dianneng[i*4],4);
							SendIndex = SendIndex + 4;
							//SendBuff[SendIndex++]=0x00;
						}
					}
				}
				if (IsDataFlag == 0)
				{
					memset(&SendBuff[SendIndex],OxXX,20);
					SendIndex=SendIndex+20;
				}
			}else  ReadFailFlag=1;
		}else  ReadFailFlag=1;
	}else 	ReadFailFlag=1;

	if(ReadFailFlag ==1) {
		ts2.Month=BCD_INT32(&Data[0]+StPos,1);
		ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==1) TimeDecrease(&ts2,5,1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		ts.Month=BCD_INT32(&Data[0]+StPos,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==0) TimeAdd(&ts,5,1);
		SendBuff[SendIndex++]=0;
		SendBuff[SendIndex++]=0;
		SendBuff[SendIndex++]=0x01;
		INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
		//��ȡ������
		IsDataFlag=0;
		memset(Temp_FilePath,0x00,60);

		sprintf((char *)Temp_FilePath,"/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
		if ((MeterType == 9) || (MeterType == 6))
		{
			dftype=1;//comm
		}
		else
		{
			dftype=1;
		}
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,3);
		if(IsDataFlag==1)
		{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x40,0,4,5,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,20);
				SendIndex=SendIndex+20;
				//SendNAK(F, P, 0x0d);
				//return 2;
			}
			else SendIndex = SendIndex + 20;
		}
		else
		{
			memset(&SendBuff[SendIndex],OxXX,20);
			SendIndex=SendIndex+20;
			//SendNAK(F, P, 0x0d);
			//return 2;
		}
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 2;
}

//�ն��������й��������������ʱ�䣨�ܣ����ʣ�
INT16U Get_Level2Data_F185(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	INT16U IsDataFlag,j,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType,i;
	INT8U ridongjie_d[10];
	INT8U ReadFailFlag;
	INT8U  TempBuff[60];
    TS ts,ts2,ts3,ts4;
    INT8U tsday=0;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;

	ts2=ts;
	ts3=ts;
	ts4=ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	dftype=1;
	if(((zone_so&0x7f)==XINJIANG) || ((zone_so&0x7f)==JIANGXI) ||(zone_so&0x7f) == TIANJIN || (zone_so&0x7f) == SHANGHAI|| Jcfginfo->jzqpara.ChaoBiaoDongJieType)//dongjieyd
	{
		ReadFailFlag  =0;

		IsDataFlag=0;
		ts.Day=BCD_INT32(&Data[0]+StPos,1);
		ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
		tsday = ts.Day;
		if (AutoFlg==0) TimeAdd(&ts,4,1);
		memset(Temp_FilePath,0x00,60);
		sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);//���ļ�
		SdPrintf(YNPrint,PreFix,"F185 ���ļ��� %s\n", Temp_FilePath);
		IsDataFlag=getMeterFile(MeterType,(char *)Temp_FilePath,ts,2);
		if(IsDataFlag==1)
		{
			memset(ridongjie_d, 0, 10);
			//FB01 ��Flag.cfg�� �ն���ʱ��
			IsDataFlag=getMetersData(MeterType,ridongjie_d,CJQno,MeterNo,0xFB,0x01,0,5,1,0,0,0,0,dftype);//lqq161
			SdPrintf(YNPrint,PreFix," ridongjie_d: ");
			for(i=0;i<10;i++)
				SdPrintf(YNPrint," ","[%d %02x]", i, ridongjie_d[i]);

//			if (0)
			if (IsDataFlag == 1)
			{
				if( ((zone_so>>7)&0x01) ==1
						&& ((((zone_so)&0x7f)==JIANGXI) || (((zone_so) & 0x7f) == TIANJIN) ))//10.12
				{
					ts4.Day=BCD_INT32(&Data[0]+StPos,1);
					ts4.Month=BCD_INT32(&Data[0]+StPos+1,1);
					ts4.Year=BCD_INT32(&Data[0]+StPos+2,1);
					INT32U_BCD(ts4.Day,&SendBuff[SendIndex++],1);
					INT32U_BCD(ts4.Month,&SendBuff[SendIndex++],1);
					INT32U_BCD(ts4.Year,&SendBuff[SendIndex++],1);
				}else
				{
					SendBuff[SendIndex++]=ridongjie_d[2];//��//lqq161
					SendBuff[SendIndex++]=ridongjie_d[3];//��
					SendBuff[SendIndex++]=ridongjie_d[4];//��
				}
				//�鳭��ʱ��  8�� 15�� 0��0��0

				SendBuff[SendIndex++]=0;
				SendBuff[SendIndex++]=0;
				INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);

				SendBuff[SendIndex++]=FeiLvNum;//���ʸ���

				IsDataFlag=getMetersData(MeterType,&TempBuff[0],CJQno,MeterNo,0xfb,0x10,0,40,1,0,0,0,0,dftype);

				if(IsDataFlag) {
					for(j=0;j<5;j++){
						memcpy(&SendBuff[SendIndex],&TempBuff[j*8],3);
						SendIndex=SendIndex+3;
						ts3.Minute = BCD_INT32(&TempBuff[j*8+3],1);
						ts3.Hour = BCD_INT32(&TempBuff[j*8+4],1);
						ts3.Day = BCD_INT32(&TempBuff[j*8+5],1);
						ts3.Month = BCD_INT32(&TempBuff[j*8+6],1);
						ts3.Year = BCD_INT32(&TempBuff[j*8+7],1);
						SdPrintf(YNPrint,PreFix, "F185: read,%d-%d-%d %d:%d\n",ts3.Year,ts3.Month,ts3.Day,ts3.Hour,ts3.Minute);

						INT32U_BCD(ts3.Minute,&TempBuff[j*8+3],1);
						INT32U_BCD(ts3.Hour,&TempBuff[j*8+4],1);
						if(tsday != ts3.Day)  ///10.27
							INT32U_BCD(tsday,&TempBuff[j*8+5],1);
						else
							INT32U_BCD(ts3.Day,&TempBuff[j*8+5],1);
						INT32U_BCD(ts3.Month,&TempBuff[j*8+6],1);
						INT32U_BCD(ts3.Year,&TempBuff[j*8+7],1);

						SdPrintf(YNPrint,PreFix, "F185: j=%d,%d-%d-%d %d:%d\n",j,TempBuff[j*8+7],TempBuff[j*8+6],TempBuff[j*8+5],TempBuff[j*8+4],TempBuff[j*8+3]);
						memcpy(&SendBuff[SendIndex],&TempBuff[j*8+3],4);
						SendIndex=SendIndex+4;
					}
				}else {
					memset(&SendBuff[SendIndex],OxXX,35);
					SendIndex=SendIndex+35;
				}
			}else	ReadFailFlag =1;
		}else  ReadFailFlag=1;
	}else   ReadFailFlag=1;

	if(ReadFailFlag) {
		ts2.Day=BCD_INT32(&Data[0]+StPos,1);
		ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
		ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
		if (AutoFlg==1) TimeDecrease(&ts2,4,1);
		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		ts.Day=BCD_INT32(&Data[0]+StPos,1);
		ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
		if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong
		if((zone_so&0x7f) == JIANGSU)
		{
			SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
			SendBuff[SendIndex++]=0x23;
			INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
			SendBuff[SendIndex++]=FeiLvNum;
		}
		else{

			SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
			SendBuff[SendIndex++]=0;
			INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
			SendBuff[SendIndex++]=FeiLvNum;
		}

		//��ȡ������
		IsDataFlag=0;
		memset(Temp_FilePath,0x00,60);

		sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);

		SdPrintf(YNPrint,PreFix, "F185: DataDay=%s\n",Temp_FilePath);
		if ((MeterType == 9) || (MeterType == 6))
		{
			dftype=1;//comm
		}
		else
		{
			dftype=1;
		}
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
		if(IsDataFlag==1)
		{
			for(j=0;j<5;j++)
			{
				IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa0,0x10,j*3,3,1,0,0,0,0,dftype);
				if (IsDataFlag == 0)
				{
					memset(&SendBuff[SendIndex],OxXX,7);
					SendIndex=SendIndex+7;
					//SendNAK(F, P, 0x0d);
					//return 3;
				}
				else
				{
					SendIndex = SendIndex + 3;
					IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb0,0x10,j*4,4,1,0,0,0,0,dftype);
					SendIndex = SendIndex + 4;
				}
			}
		}
		else
		{
			memset(&SendBuff[SendIndex],OxXX,35);
			SendIndex=SendIndex+35;
			//SendNAK(F, P, 0x0d);
			//return 3;
		}
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 3;
}


INT16U Get_Level2Data_F186(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	INT16U IsDataFlag,j,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
    TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong
	if((zone_so&0x7f) == JIANGSU)
	{
		SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
		SendBuff[SendIndex++]=0x23;
		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}
	else{

		SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
		SendBuff[SendIndex++]=0;
		INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}

	//��ȡ������
	IsDataFlag=0;
	memset(Temp_FilePath,0x00,60);

	sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
	if(IsDataFlag==1)
	{
		for(j=0;j<5;j++)
		{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa1,0x10+j,j*3,3,1,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,7);
				SendIndex=SendIndex+7;
				//SendNAK(F, P, 0x0d);
				//return 3;
			}
			else
			{
				SendIndex = SendIndex + 3;
				IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb1,0x10+j,j*4,4,1,0,0,0,0,dftype);
				SendIndex = SendIndex + 4;
			}
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,35);
		SendIndex=SendIndex+35;
		//SendNAK(F, P, 0x0d);
		//return 3;
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 3;
}



INT16U Get_Level2Data_F187(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	INT16U IsDataFlag,j,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
    TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong
	if((zone_so&0x7f) == JIANGSU)
	{
		SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
		SendBuff[SendIndex++]=0x23;
		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}
	else{

		SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
		SendBuff[SendIndex++]=0;
		INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}

	//��ȡ������
	IsDataFlag=0;
	memset(Temp_FilePath,0x00,60);

	sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
	if(IsDataFlag==1)
	{
		for(j=0;j<5;j++)
		{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa0,0x20+j,j*3,3,1,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,7);
				SendIndex=SendIndex+7;
				//SendNAK(F, P, 0x0d);
				//return 3;
			}
			else
			{
				SendIndex = SendIndex + 3;
				IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb0,0x20+j,j*4,4,1,0,0,0,0,dftype);
				SendIndex = SendIndex + 4;
			}
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,35);
		SendIndex=SendIndex+35;
		//SendNAK(F, P, 0x0d);
		//return 3;
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 3;
}



INT16U Get_Level2Data_F188(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	INT16U IsDataFlag,j,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
    TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong
	if((zone_so&0x7f) == JIANGSU)
	{
		SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
		SendBuff[SendIndex++]=0x23;
		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}
	else{

		SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
		SendBuff[SendIndex++]=0;
		INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}

	//��ȡ������
	IsDataFlag=0;
	memset(Temp_FilePath,0x00,60);

	sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
	if(IsDataFlag==1)
	{
		for(j=0;j<5;j++)
		{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa1,0x20+j,j*3,3,1,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,7);
				SendIndex=SendIndex+7;
				//SendNAK(F, P, 0x0d);
				//return 3;
			}
			else
			{
				SendIndex = SendIndex + 3;
				IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb1,0x20+j,j*4,4,1,0,0,0,0,dftype);
				SendIndex = SendIndex + 4;
			}
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,35);
		SendIndex=SendIndex+35;
		//SendNAK(F, P, 0x0d);
		//return 3;
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 3;
}



INT16U Get_Level2Data_F189(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	INT16U IsDataFlag,j,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
    TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong
	if((zone_so&0x7f) == JIANGSU)
	{
		SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
		SendBuff[SendIndex++]=0x23;
		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}
	else{

		SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
		SendBuff[SendIndex++]=0;
		INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}

	//��ȡ������
	IsDataFlag=0;
	memset(Temp_FilePath,0x00,60);

	sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
	if(IsDataFlag==1)
	{
		for(j=0;j<5;j++)
		{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa0,0x10+j,j*3,3,1,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,7);
				SendIndex=SendIndex+7;
				//SendNAK(F, P, 0x0d);
				//return 3;
			}
			else
			{
				SendIndex = SendIndex + 3;
				IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb0,0x10+j,j*4,4,1,0,0,0,0,dftype);
				SendIndex = SendIndex + 4;
			}
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,35);
		SendIndex=SendIndex+35;
		//SendNAK(F, P, 0x0d);
		//return 3;
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 3;
}


INT16U Get_Level2Data_F190(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	INT16U IsDataFlag,j,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
    TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong
	if((zone_so&0x7f) == JIANGSU)
	{
		SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
		SendBuff[SendIndex++]=0x23;
		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}
	else{

		SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
		SendBuff[SendIndex++]=0;
		INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}

	//��ȡ������
	IsDataFlag=0;
	memset(Temp_FilePath,0x00,60);

	sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
	if(IsDataFlag==1)
	{
		for(j=0;j<5;j++)
		{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa1,0x10+j,j*3,3,1,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,7);
				SendIndex=SendIndex+7;
				//SendNAK(F, P, 0x0d);
				//return 3;
			}
			else
			{
				SendIndex = SendIndex + 3;
				IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb1,0x10+j,j*4,4,1,0,0,0,0,dftype);
				SendIndex = SendIndex + 4;
			}
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,35);
		SendIndex=SendIndex+35;
		//SendNAK(F, P, 0x0d);
		//return 3;
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 3;
}



INT16U Get_Level2Data_F191(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	INT16U IsDataFlag,j,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
    TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong
	if((zone_so&0x7f) == JIANGSU)
	{
		SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
		SendBuff[SendIndex++]=0x23;
		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}
	else{

		SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
		SendBuff[SendIndex++]=0;
		INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}

	//��ȡ������
	IsDataFlag=0;
	memset(Temp_FilePath,0x00,60);

	sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
	if(IsDataFlag==1)
	{
		for(j=0;j<5;j++)
		{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa0,0x20+j,j*3,3,1,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,7);
				SendIndex=SendIndex+7;
				//SendNAK(F, P, 0x0d);
				//return 3;
			}
			else
			{
				SendIndex = SendIndex + 3;
				IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb0,0x20+j,j*4,4,1,0,0,0,0,dftype);
				SendIndex = SendIndex + 4;
			}
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,35);
		SendIndex=SendIndex+35;
		//SendNAK(F, P, 0x0d);
		//return 3;
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 3;
}



INT16U Get_Level2Data_F192(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	INT16U IsDataFlag,j,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
    TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==0) TimeAdd(&ts,4,1); //yangdong
	if((zone_so&0x7f) == JIANGSU)
	{
		SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
		SendBuff[SendIndex++]=0x23;
		INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}
	else{

		SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
		SendBuff[SendIndex++]=0;
		INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
		SendBuff[SendIndex++]=FeiLvNum;
	}

	//��ȡ������
	IsDataFlag=0;
	memset(Temp_FilePath,0x00,60);

	sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
	if(IsDataFlag==1)
	{
		for(j=0;j<5;j++)
		{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa1,0x20+j,j*3,3,1,0,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,7);
				SendIndex=SendIndex+7;
				//SendNAK(F, P, 0x0d);
				//return 3;
			}
			else
			{
				SendIndex = SendIndex + 3;
				IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb1,0x20+j,j*4,4,1,0,0,0,0,dftype);
				SendIndex = SendIndex + 4;
			}
		}
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,35);
		SendIndex=SendIndex+35;
		//SendNAK(F, P, 0x0d);
		//return 3;
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 3;
}

//�¶��������й��������������ʱ�䣨�ܣ����ʣ�
INT16U Get_Level2Data_F193(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	INT16U IsDataFlag,j,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType,i;
	INT8U ridongjie_d[10];
	INT8U ReadFailFlag;
	INT8U TempBuff[60];
    TS ts,ts2,ts3,ts4,ts5;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	ts3=ts;
	ts4=ts;
	ts5=ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=3;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	dftype=1;
//	if((zone_so==JIANGXI) ||zone_so == TIANJIN || Jcfginfo->jzqpara.ChaoBiaoDongJieType)//dongjieyd
	if((zone_so&0x7f) == JIANGXI ||(zone_so&0x7f) == TIANJIN || (zone_so&0x7f) == SHANGHAI|| Jcfginfo->jzqpara.ChaoBiaoDongJieType)//dongjieyd
	{
		ReadFailFlag  =0;

		IsDataFlag=0;
		ts2.Month=BCD_INT32(&Data[0]+StPos,1);
		ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==1) TimeDecrease(&ts2,5,1);
		ts.Month=BCD_INT32(&Data[0]+StPos,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==0) TimeAdd(&ts,5,1);
		memset(Temp_FilePath,0x00,60);
		sprintf((char *)Temp_FilePath,"/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
		SdPrintf(YNPrint,PreFix,"F193 ���ļ��� %s\n", Temp_FilePath);
		IsDataFlag=getMeterFile(MeterType,(char *)Temp_FilePath,ts,3);
		if(IsDataFlag==1)
		{
			memset(ridongjie_d, 0, 10);
			IsDataFlag=getMetersData(MeterType,ridongjie_d,CJQno,MeterNo,0xFc,0x01,0,5,1,0,0,0,0,dftype);//lqq161
			SdPrintf(YNPrint,PreFix," ridongjie_m: ");
			for(i=0;i<10;i++)
				SdPrintf(YNPrint," ","[%d %02x]", i, ridongjie_d[i]);

//			if (0)
			if (IsDataFlag == 1)
			{
				if((zone_so>>7 & 0x01)==1 && (((zone_so&0x7f)==JIANGXI)||(zone_so&0x7f) == TIANJIN))//10.12
				{
					ts4.Month=BCD_INT32(&Data[0]+StPos,1);
					ts4.Year=BCD_INT32(&Data[0]+StPos+1,1);
					INT32U_BCD(ts4.Month,&SendBuff[SendIndex++],1);
					INT32U_BCD(ts4.Year,&SendBuff[SendIndex++],1);
				}else
				{
					SendBuff[SendIndex++]=ridongjie_d[3];//��
					SendBuff[SendIndex++]=ridongjie_d[4];//��
				}
				SendBuff[SendIndex++]=0;
				SendBuff[SendIndex++]=0;
				SendBuff[SendIndex++]=0x01;
				INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
				INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
				//�鳭��ʱ��  8�� 15�� 0��0��0
				SendBuff[SendIndex++]=FeiLvNum;//���ʸ���
				IsDataFlag=getMetersData(MeterType,&TempBuff[0],CJQno,MeterNo,0xfc,0x10,0,40,1,0,0,0,0,dftype);
				if(IsDataFlag) {
					for(j=0;j<5;j++){
						memcpy(&SendBuff[SendIndex],&TempBuff[j*8],3);
						SendIndex=SendIndex+3;
						ts3.Minute = BCD_INT32(&TempBuff[j*8+3],1);
						ts3.Hour = BCD_INT32(&TempBuff[j*8+4],1);
						ts3.Day = BCD_INT32(&TempBuff[j*8+5],1);
						ts3.Month = BCD_INT32(&TempBuff[j*8+6],1);
						ts3.Year = BCD_INT32(&TempBuff[j*8+7],1);
//						SdPrintf(YNPrint,PreFix, "F193: read,%d-%d-%d %d:%d\n",ts3.Year,ts3.Month,ts3.Day,ts3.Hour,ts3.Minute);
//							TimeAdd(&ts3,4,1); //10.15
//						ts3.Day = 30;
//						ts3.Hour = 0;
//						ts3.Minute = 2;

						INT32U_BCD(ts3.Minute,&TempBuff[j*8+3],1);
						INT32U_BCD(ts3.Hour,&TempBuff[j*8+4],1);
						ts5 = ts3;
						TimeAdd(&ts5,4,1);
						if(ts5.Month == ts3.Month)
							INT32U_BCD(ts5.Day,&TempBuff[j*8+5],1);
						else
							INT32U_BCD(ts3.Day,&TempBuff[j*8+5],1);
						INT32U_BCD(ts3.Month,&TempBuff[j*8+6],1);
						INT32U_BCD(ts3.Year,&TempBuff[j*8+7],1);
//						SdPrintf(YNPrint,PreFix, "F185: j=%d,%d-%d-%d %d:%d\n",j,TempBuff[j*8+7],TempBuff[j*8+6],TempBuff[j*8+5],TempBuff[j*8+4],TempBuff[j*8+3]);

						memcpy(&SendBuff[SendIndex],&TempBuff[j*8+3],4);
						SendIndex=SendIndex+4;
					}
				}else {
					memset(&SendBuff[SendIndex],OxXX,35);
					SendIndex=SendIndex+35;
				}
			}else	ReadFailFlag =1;
		}else  ReadFailFlag=1;
	}else   ReadFailFlag=1;

	if(ReadFailFlag) {
		ts2.Month=BCD_INT32(&Data[0]+StPos,1);
		ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==1) TimeDecrease(&ts2,5,1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		ts.Month=BCD_INT32(&Data[0]+StPos,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==0) TimeAdd(&ts,5,1);
		if((zone_so&0x7f) == JIANGSU)
		{
			SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
			SendBuff[SendIndex++]=0x23;
			SendBuff[SendIndex++]=0x01;
			INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
			SendBuff[SendIndex++]=FeiLvNum;
		}
		else{

			SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
			SendBuff[SendIndex++]=0;
			SendBuff[SendIndex++]=0x01;
			INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
			SendBuff[SendIndex++]=FeiLvNum;
		}
		//��ȡ������
		IsDataFlag=0;
		memset(Temp_FilePath,0x00,60);
		sprintf((char *)Temp_FilePath,"/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
		SdPrintf(YNPrint,PreFix,"F193 ���ļ�2�� %s\n", Temp_FilePath);
		IsDataFlag=getMeterFile(MeterType,(char *)Temp_FilePath,ts,3);
		if ((MeterType == 9) || (MeterType == 6))
		{
			dftype=1;//comm
		}
		else
		{
			dftype=1;
		}
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
		if(IsDataFlag==1)
		{
			for(j=0;j<5;j++)
			{
				IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa0,0x10,j*3,3,1,0,0,0,0,dftype);
				if (IsDataFlag == 0)
				{
					memset(&SendBuff[SendIndex],OxXX,7);
					SendIndex=SendIndex+7;
					//SendNAK(F, P, 0x0d);
					//return 3;
				}
				else
				{
					SendIndex = SendIndex + 3;
					IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb0,0x10,j*4,4,1,0,0,0,0,dftype);
					SendIndex = SendIndex + 4;
				}
			}
		}
		else
		{
			memset(&SendBuff[SendIndex],OxXX,35);
			SendIndex=SendIndex+35;
			//SendNAK(F, P, 0x0d);
			//return 3;
		}
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 2;
}

INT16U Get_Level2Data_F195(INT8U Set,INT16U F,INT16U P,INT8U *Data)			//�¶��ᷴ���й��������������ʱ��
{
	INT16U IsDataFlag,j,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
	INT8U ReadFailFlag;
    TS ts,ts2,ts3,ts4,ts5;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	ts3=ts;
	ts4=ts;
	ts5=ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=3;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	dftype=1;
	ReadFailFlag=1;

	if(ReadFailFlag) {
		ts2.Month=BCD_INT32(&Data[0]+StPos,1);
		ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==1) TimeDecrease(&ts2,5,1);
		INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
		INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
		ts.Month=BCD_INT32(&Data[0]+StPos,1);
		ts.Year=BCD_INT32(&Data[0]+StPos+1,1);
		if (AutoFlg==0) TimeAdd(&ts,5,1);
		if((zone_so&0x7f) == JIANGSU)
		{
			SendBuff[SendIndex++]=0x59;//�鳭��ʱ��  8�� 14�� 23��59��59
			SendBuff[SendIndex++]=0x23;
			SendBuff[SendIndex++]=0x01;
			INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
			SendBuff[SendIndex++]=FeiLvNum;
		}
		else{

			SendBuff[SendIndex++]=0;//�鳭��ʱ��  8�� 15�� 0��0��0
			SendBuff[SendIndex++]=0;
			SendBuff[SendIndex++]=0x01;
			INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
			SendBuff[SendIndex++]=FeiLvNum;
		}
		//��ȡ������
		IsDataFlag=0;
		memset(Temp_FilePath,0x00,60);
		sprintf((char *)Temp_FilePath,"/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
		SdPrintf(YNPrint,PreFix,"F193 ���ļ�2�� %s\n", Temp_FilePath);
		IsDataFlag=getMeterFile(MeterType,(char *)Temp_FilePath,ts,3);
		if ((MeterType == 9) || (MeterType == 6))
		{
			dftype=1;//comm
		}
		else
		{
			dftype=1;
		}
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
		if(IsDataFlag==1)
		{
			for(j=0;j<5;j++)
			{
				IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xa0,0x10,j*3,3,1,0,0,0,0,dftype);
				if (IsDataFlag == 0)
				{
					memset(&SendBuff[SendIndex],OxXX,7);
					SendIndex=SendIndex+7;
					//SendNAK(F, P, 0x0d);
					//return 3;
				}
				else
				{
					SendIndex = SendIndex + 3;
					IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0xb0,0x10,j*4,4,1,0,0,0,0,dftype);
					SendIndex = SendIndex + 4;
				}
			}
		}
		else
		{
			memset(&SendBuff[SendIndex],0x00,35);////////////////lcy
			SendIndex=SendIndex+35;
		}
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 2;
}

INT16U Get_Level2Data_F248(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	int i=0,num=0;
	INT8U FirFin=0,indtmp=0,tmp1=0,tmp2=0,tmp3=0;
	INT8U CJQno, MeterNo, MeterType;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60];
	TS ts,ts2;
	StPos=0;
	//68 3E 00 3E 00 68 4B 02 35 02 00 02 0D 60 01 01 80 1E 02 11 10 19 16
	for(i=0;i<PointMax;i++)
	{
		if ( JSetPara_AFN04_3761_2009->group2.f10[i].Status!=1)
			continue;
		FirFin=0;
		if ((num%7)==0)
		{
			if(num>6)
			{
				EC();
				TP();
				FrameTailCreate_Send(0);
			}

			CreateGWHead(0x88|(PrmFlg<<6), 0);
			SendBuff[SendIndex++] = 0x0d;//afn
			if (num == 0)
				FirFin = 0x40;
			indtmp=SendIndex;
			SendBuff[SendIndex++] = FirFin | (Fseq & 0x0f);//seq��һ�壬��������
			tmp1=SendIndex;
			SendBuff[SendIndex++] |= SetDa1(i+1);
			tmp2=SendIndex;
			SendBuff[SendIndex++] |= SetDa2(i+1);
			SendBuff[SendIndex++] = SetDt1(F);
			SendBuff[SendIndex++] = SetDt2(F);

			ts2.Day=BCD_INT32(&Data[0]+StPos,1);
			ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
			ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
			INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
			ts.Day=BCD_INT32(&Data[0]+StPos,1);
			ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
			ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
			TimeAdd(&ts,4,1);
			SendBuff[SendIndex++]=0;
			SendBuff[SendIndex++]=0;
			INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
			INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);
			tmp3=SendIndex;
			SendBuff[SendIndex++] = 7;

		}
		SendBuff[tmp1] = 0xff;
		SendBuff[tmp2] = 0xff;
		SendBuff[SendIndex++] = SetDa1(i+1);
		SendBuff[SendIndex++] = SetDa2(i+1);
		SendBuff[SendIndex++] = FeiLvNum;
		CJQno = JSetPara_AFN04_3761_2009->group2.f10[i].CjqNo-1;
		MeterNo = JSetPara_AFN04_3761_2009->group2.f10[i].MeterNo;
		MeterType = JSetPara_AFN04_3761_2009->group2.f10[i].Type;
		memset(Temp_FilePath,0,60);
		sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",i+1,ts.Day);
		if ((MeterType == 9) || (MeterType == 6))
		{
			dftype=1;//comm
		}
		else
		{
			dftype=1;
		}
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,2);
		if(IsDataFlag==1)
		{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x90,0x10,0,4,5,1,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,25);
			}
			SendIndex = SendIndex + 25;
		}
		else
		{
			memset(&SendBuff[SendIndex],OxXX,25);
			SendIndex = SendIndex + 25;
		}

		num++;

	}
	if ((num%7)!=0)
	{
		SendBuff[tmp3]=(num%7);
		FirFin = FirFin | 0x20;
		SendBuff[indtmp]=FirFin | (Fseq & 0x0f);
		EC();
		TP();
		FrameTailCreate_Send(0);//���ͱ���β��������
	}
	return 3;
}

/*-----------------------------//xiebo----------------------------*/
/*INT8U Read_Day_XieBo(INT8U *t,Min_15_XieBo_Set *Dest,INT8U Point)
{
	INT8U name[128];
	INT8U ret;
	sprintf((char *)name,"/nand/save/xbday%02x%02x.dat",ts.Month,ts.Day);
//	ret=ReadFile(name,&Jdatafileinfo->jc.xiebo.XieBo_QuXian,sizeof(Min_15_XieBo_Set));
	ret=ReadFile((char*)name,(char *) &Jdatafileinfo->jc.xiebo.XieBo_QuXian, sizeof(Jdatafileinfo->jc.xiebo.XieBo_QuXian));
	if(ret==0)
		memcpy(Dest,&Jdatafileinfo->jc.xiebo.XieBo_QuXian,sizeof(Min_15_XieBo_Set));
	else
		return 0;
	return 1;
}*/
INT16U Get_Level2Data_F113(INT8U Set,INT16U F,INT16U P,INT8U *Data)//A��2~19��г�����������ֵ������ʱ��
{
	TS ts,ts2;	INT8U ret;
	INT8U j;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
//	TongJi tj;
	INT8U Temp_FilePath[60];
	StPos=0;
	if (AutoFlg==1)
		StPos=2;
	//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Year = BCD_INT32(&Data[2]+StPos,1)+2000;
	ts.Month=BCD_INT32(&Data[1]+StPos,1);
	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	if (AutoFlg==0) TimeAdd(&ts,4,1);

	sprintf((char *)Temp_FilePath,"/nand/save/xbday%02x%02x.dat",ts.Month,ts.Day);
	ret=ReadFile((char*)Temp_FilePath,
			(char *) &Jdatafileinfo->jc.xiebo.XieBo_QuXian,
			sizeof(Jdatafileinfo->jc.xiebo.XieBo_QuXian),Jproginfo);

//	if(access((char *)Temp_FilePath,0)==0)//SendALLNAK(0);
//	{
//	memcpy(&SendBuff[SendIndex],t,3);
//	SendIndex=SendIndex+3;
	for(j=2;j<20;j++)
	{
		INT32U_BCD(Jdatafileinfo->jc.xiebo.XieBo_QuXian.IAxb_Max[j]*100,&SendBuff[SendIndex],2);
		SendIndex=SendIndex+2;
		memcpy(&SendBuff[SendIndex],&Jdatafileinfo->jc.xiebo.XieBo_QuXian.IAxb_Max_Time,4);
		SendIndex=SendIndex+4;
	}
	INT32U_BCD(Jdatafileinfo->jc.xiebo.XieBo_QuXian.IA_ZongJiBian_Max*100,&SendBuff[SendIndex],2);
	SendIndex=SendIndex+2;
	memcpy(&SendBuff[SendIndex],&Jdatafileinfo->jc.xiebo.XieBo_QuXian.IA_ZongJiBian_Max_Time,4);
	SendIndex=SendIndex+4;
//	}
//	else
//	{
//		memset(&SendBuff[SendIndex],OxXX,6);
//		SendIndex=SendIndex+6;
//		//SendNAK(F, P, 0x0d);
//		//return 3;
//	}


//	if(!Read_Day_XieBo(t,&Jdatafileinfo->jc.xiebo.XieBo_QuXian,P))
//	{
//	if(i!=0xff)
//		SendALLNAK(0);
//		return 0;
//	}
//	memcpy(&SendBuff[SendIndex],t,3);
//	SendIndex=SendIndex+3;
//	for(j=2;j<20;j++)
//	{
//		INT32U_BCD(Jdatafileinfo->jc.xiebo.XieBo_QuXian.IAxb_Max[j]*100,&SendBuff[SendIndex],2);
//		SendIndex=SendIndex+2;
//		memcpy(&SendBuff[SendIndex],&Jdatafileinfo->jc.xiebo.XieBo_QuXian.IAxb_Max_Time,4);
//		SendIndex=SendIndex+4;
//	}
//	INT32U_BCD(Jdatafileinfo->jc.xiebo.XieBo_QuXian.IA_ZongJiBian_Max*100,&SendBuff[SendIndex],2);
//	SendIndex=SendIndex+2;
//	memcpy(&SendBuff[SendIndex],&Jdatafileinfo->jc.xiebo.XieBo_QuXian.IA_ZongJiBian_Max_Time,4);
//	SendIndex=SendIndex+4;

//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 1;
}
INT16U Get_Level2Data_F114(INT8U Set,INT16U F,INT16U P,INT8U *Data)//b��2~19��г�����������ֵ������ʱ��
{
	TS ts,ts2;	INT8U ret;
	INT8U j;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
//	TongJi tj;
	INT8U Temp_FilePath[60];
	StPos=0;
	if (AutoFlg==1)
		StPos=2;
	//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Year = BCD_INT32(&Data[2]+StPos,1)+2000;
	ts.Month=BCD_INT32(&Data[1]+StPos,1);
	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	if (AutoFlg==0) TimeAdd(&ts,4,1);

	sprintf((char *)Temp_FilePath,"/nand/save/xbday%02x%02x.dat",ts.Month,ts.Day);
	ret=ReadFile((char*)Temp_FilePath,
			(char *) &Jdatafileinfo->jc.xiebo.XieBo_QuXian,
			sizeof(Jdatafileinfo->jc.xiebo.XieBo_QuXian),Jproginfo);

//	memcpy(&SendBuff[SendIndex],t,3);
//	SendIndex=SendIndex+3;
	for(j=2;j<20;j++)
	{
		INT32U_BCD(Jdatafileinfo->jc.xiebo.XieBo_QuXian.IBxb_Max[j]*100,&SendBuff[SendIndex],2);
		SendIndex=SendIndex+2;
		memcpy(&SendBuff[SendIndex],&Jdatafileinfo->jc.xiebo.XieBo_QuXian.IBxb_Max_Time,4);
		SendIndex=SendIndex+4;
	}
	INT32U_BCD(Jdatafileinfo->jc.xiebo.XieBo_QuXian.IB_ZongJiBian_Max*100,&SendBuff[SendIndex],2);
	SendIndex=SendIndex+2;
	memcpy(&SendBuff[SendIndex],&Jdatafileinfo->jc.xiebo.XieBo_QuXian.IB_ZongJiBian_Max_Time,4);
	SendIndex=SendIndex+4;

//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 1;
}
INT16U Get_Level2Data_F115(INT8U Set,INT16U F,INT16U P,INT8U *Data)//�ն��������B��2-19��г����ѹ�����ʼ��ܻ����������ֵ������ʱ��
{
	return 1;
}
INT16U Get_Level2Data_F116(INT8U Set,INT16U F,INT16U P,INT8U *Data)//�ն��������B��2-19��г����ѹ�����ʼ��ܻ����������ֵ������ʱ��
{
	return 1;
}

INT16U Get_Level2Data_F117(INT8U Set,INT16U F,INT16U P,INT8U *Data)//�ն��������B��2-19��г����ѹ�����ʼ��ܻ����������ֵ������ʱ��
{
	TS ts,ts2;	INT8U ret;
	INT8U j;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
//	TongJi tj;
	INT8U Temp_FilePath[60];
	StPos=0;
	if (AutoFlg==1)
		StPos=2;
	//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);
	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	ts.Year = BCD_INT32(&Data[2]+StPos,1)+2000;
	ts.Month=BCD_INT32(&Data[1]+StPos,1);
	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	if (AutoFlg==0) TimeAdd(&ts,4,1);

	sprintf((char *)Temp_FilePath,"/nand/save/xbday%02x%02x.dat",ts.Month,ts.Day);
	ret=ReadFile((char*)Temp_FilePath,
			(char *) &Jdatafileinfo->jc.xiebo.XieBo_QuXian,
			sizeof(Jdatafileinfo->jc.xiebo.XieBo_QuXian),Jproginfo);

//	memcpy(&SendBuff[SendIndex],t,3);
//	SendIndex=SendIndex+3;
	for(j=2;j<20;j++)
	{
		INT32U_BCD(Jdatafileinfo->jc.xiebo.XieBo_QuXian.UB_Hanyoulv_Max[j]*10,&SendBuff[SendIndex],2);
		SendIndex=SendIndex+2;
		memcpy(&SendBuff[SendIndex],&Jdatafileinfo->jc.xiebo.XieBo_QuXian.UB_Hanyoulv_Max_Time,4);
		SendIndex=SendIndex+4;
	}
	INT32U_BCD(Jdatafileinfo->jc.xiebo.XieBo_QuXian.UB_ZongJiBianLv_Max*10,&SendBuff[SendIndex],2);
	SendIndex=SendIndex+2;
	memcpy(&SendBuff[SendIndex],&Jdatafileinfo->jc.xiebo.XieBo_QuXian.UB_ZongJiBianLv_Max_Time,4);
	SendIndex=SendIndex+4;

//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 1;
}
INT16U Get_Level2Data_F118(INT8U Set,INT16U F,INT16U P,INT8U *Data)//�ն��������B��2-19��г����ѹ�����ʼ��ܻ����������ֵ������ʱ��
{
	return 1;
}
INT16U Get_Level2Data_F215(INT8U Set,INT16U F,INT16U P,INT8U *Data)//���ܱ����õ���Ϣ
{
//	int i=0;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=3;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Month=BCD_INT32(&Data[0]+StPos,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
	if (AutoFlg==1) TimeDecrease(&ts2,5,1);

	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1); //�¶�������ʱ��
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);

	ts.Month=BCD_INT32(&Data[0]+StPos,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+1,1);
	if (AutoFlg==0) TimeAdd(&ts,5,1);

	SendBuff[SendIndex++]=0;						//�ն˳���ʱ��
	SendBuff[SendIndex++]=0;
	SendBuff[SendIndex++]=0x01;
	INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);


	//��ȡ������
	IsDataFlag=0;
	memset(Temp_FilePath,0x00,60);
	sprintf((char *)Temp_FilePath,"/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
	SdPrintf(YNPrint,PreFix,"f215 ���ļ���%s \n",Temp_FilePath);
	if ((MeterType == 9) || (MeterType == 6))
	{
		dftype=1;//comm
	}
	else
	{
		dftype=1;
	}
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,3);
//  CommonDayFlags.cfg
//	0x00, 0x91 			 //�������--		��һ�ι�����ܹ������        03 32 02 01  ����  03 33 02 01
//	0x00, 0x92			 //ʣ����--		��ǰʣ��������� 		00 90 02 00
//	0x00, 0x93			 //�ۼƹ�����--  	��һ�ι�����ۼƹ�����   03 33 06 01
//	0x00, 0x94			 //ʣ�����--		��ǰʣ�������kWh��		00 90 01 00
//	0x00, 0x95			 //͸֧����--		��ǰ͸֧������kWh��		00 90 01 01
//	0x00, 0x96			 //�ۼƹ�����--		��һ�ι�����ۼƹ�����         03 32 06 01
//	0x00, 0x97			 //��Ƿ���޵���--	͸֧������ֵ				04 00 0F 04
//	0x00, 0x98			 //��������--		��������1��ֵ			04 00 0F 01
//	0x00, 0x99			 //���ϵ���--		������
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x00,0x91,0,2,1,0,0,0,0,dftype);
		SdPrintf(YNPrint,PreFix," Get_Level2Data_F215 SendBuff[%d] %02x %02x\n",SendIndex,SendBuff[SendIndex],SendBuff[SendIndex+1]);
		if (IsDataFlag == 0){
			memset(&SendBuff[SendIndex],OxXX,2);
			SendIndex=SendIndex+2;
		}
		else
			SendIndex = SendIndex + 2;

		SendBuff[SendIndex++] = 0;
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x00,0x92,0,4,1,0,0,0,0,dftype);
		if (IsDataFlag == 0){
			memset(&SendBuff[SendIndex-1],OxXX,5);
			SendIndex=SendIndex+4;
		}
		else
			SendIndex = SendIndex + 4;

		SendBuff[SendIndex++] = 0;
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x00,0x93,0,4,1,0,0,0,0,dftype);
		if (IsDataFlag == 0){
			memset(&SendBuff[SendIndex-1],OxXX,5);
			SendIndex=SendIndex+4;
		}
		else
			SendIndex = SendIndex + 4;
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x00,0x94,0,4,6,0,0,0,0,dftype);
//		SdPrintf(YNPrint,PreFix,"");
//		for(i=0;i<32;i++)
//		{
//			SdPrintf(YNPrint," ","%02x", SendBuff[SendIndex+i]);
//			if(i%4 == 0)
//				SdPrintf(YNPrint,PreFix,"");
//		}
//		SdPrintf(YNPrint,PreFix,"");
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,24);
			SendIndex=SendIndex+24;
		}
		else SendIndex = SendIndex + 24;
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,36);
		SendIndex=SendIndex+36;
	}
	return 2;
}

INT16U Get_Level2Data_F216(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	INT16U i,IsDataFlag,dftype,dflg;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts2=ts;
	INT32S tmp[5];
	for(i=0;i<5;i++)
		tmp[i]=0;
	StPos=0;
	if (AutoFlg==1)
		StPos=3;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Month=BCD_INT32(&Data[0]+StPos,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+1,1);
	SdPrintf(YNPrint,PreFix,"=============F21   AutoFlg=%d",AutoFlg);
	if (AutoFlg==1) TimeDecrease(&ts2,5,1);
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);
	//SendBuff[SendIndex++] = FeiLvNum;////////////////lcy
	ts.Year = BCD_INT32(&Data[1]+StPos,1)+2000;
	ts.Month=BCD_INT32(&Data[0]+StPos,1);
	if (AutoFlg==0) TimeAdd(&ts,5,1);
	SendBuff[SendIndex++]=0;						//�ն˳���ʱ��
	SendBuff[SendIndex++]=0;
	SendBuff[SendIndex++]=0x01;
	INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);

	SendBuff[SendIndex++] = FeiLvNum;///////////////lcy
	//��������
	IsDataFlag=0;
	LDType=2;
	dflg=0;
	memset(Temp_FilePath,0x00,60);
	sprintf((char *)Temp_FilePath,"/nand/DataMonth/%04d/%02d.dat",P,ts.Month);
	SdPrintf(YNPrint,PreFix,"Get_Level2Data_F216 P==%d ts.Month=%d  %s", P, ts.Month,Temp_FilePath);
	dftype=1;
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,3);
	SdPrintf(YNPrint,PreFix,"IsDataFlag == %d\n",IsDataFlag);
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x90,0x10,0,4,5,1,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,25);
			SendIndex=SendIndex+25;
		}
		else SendIndex = SendIndex + 25;
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x91,0x10,0,4,5,1,0,0,0,dftype);
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,25);
			SendIndex=SendIndex+25;
		}
		else SendIndex = SendIndex + 25;
		memset(&SendBuff[SendIndex],OxXX,5);////////lcy
		SendIndex=SendIndex+5;////////lcy
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,55);////////lcy
		SendIndex=SendIndex+55;////////lcy
	}
	return 2;
}

INT16U Get_Level2Data_F225(INT8U Set,INT16U F,INT16U P,INT8U *Data)//���ܱ����õ���Ϣ
{
	//int i=0;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60],CJQno,MeterNo,MeterType;
	TS ts,ts2;
	ts.Year=2000;ts.Month=1;ts.Day=1;ts.Hour=0;ts.Minute=0;ts.Sec=0;
	ts.Week = 0;
	ts2=ts;
	StPos=0;
	if(AutoFlg==1)
		StPos=2;
	CJQno=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	//	MkLevel2Head(P,F,0x88|(PrmFlg<<6));//��������ͷ��
	ts2.Day=BCD_INT32(&Data[0]+StPos,1);
	ts2.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts2.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==1) TimeDecrease(&ts2,4,1);

	INT32U_BCD(ts2.Day,&SendBuff[SendIndex++],1); //�ն�������ʱ��
	INT32U_BCD(ts2.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts2.Year,&SendBuff[SendIndex++],1);

	ts.Day=BCD_INT32(&Data[0]+StPos,1);
	ts.Month=BCD_INT32(&Data[0]+StPos+1,1);
	ts.Year=BCD_INT32(&Data[0]+StPos+2,1);
	if (AutoFlg==0) TimeAdd(&ts,4,1);

	SendBuff[SendIndex++]=0;						//�ն˳���ʱ��
	SendBuff[SendIndex++]=0;
	INT32U_BCD(ts.Day,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts.Month,&SendBuff[SendIndex++],1);
	INT32U_BCD(ts.Year,&SendBuff[SendIndex++],1);

	//��ȡ������
	IsDataFlag=0;
	memset(Temp_FilePath,0x00,60);
	sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/%02d.dat",P,ts.Day);
	SdPrintf(YNPrint,PreFix,"f225 ���ļ���%s \n",Temp_FilePath);
	dftype=1;//comm
	IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,3);
//  CommonDayFlags.cfg
//	0x00, 0x91 			 //�������--		��һ�ι�����ܹ������        	03 32 02 01  ����  03 33 02 01
//	0x00, 0x92			 //ʣ����--		��ǰʣ��������� 		00 90 02 00
//	0x00, 0x93			 //�ۼƹ�����--  	��һ�ι�����ۼƹ�����   	03 33 06 01
//	0x00, 0x94			 //ʣ�����--		��ǰʣ�������kWh��		00 90 01 00
//	0x00, 0x95			 //͸֧����--		��ǰ͸֧������kWh��		00 90 01 01
//	0x00, 0x96			 //�ۼƹ�����--		��һ�ι�����ۼƹ�����         03 32 06 01
//	0x00, 0x97			 //��Ƿ���޵���--	͸֧������ֵ				04 00 0F 04
//	0x00, 0x98			 //��������--		��������1��ֵ			04 00 0F 01
//	0x00, 0x99			 //���ϵ���--		������
	if(IsDataFlag==1)
	{
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x00,0x91,0,2,1,0,0,0,0,dftype);
		SdPrintf(YNPrint,PreFix," Get_Level2Data_F225 SendBuff[%d] %02x %02x  IsDataFlag=%d\n",
				SendIndex,SendBuff[SendIndex],SendBuff[SendIndex+1],IsDataFlag);
		if (IsDataFlag == 0){
			memset(&SendBuff[SendIndex],OxXX,2);
			SendIndex=SendIndex+2;
		}
		else
			SendIndex = SendIndex + 2;

		SendBuff[SendIndex++] = 0;
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x00,0x92,0,4,1,0,0,0,0,dftype);
		SdPrintf(YNPrint,PreFix," Get_Level2Data_F225 0x00,0x92 IsDataFlag=%d,SendIndex=%d\n",IsDataFlag,SendIndex);
		if (IsDataFlag == 0){
			memset(&SendBuff[SendIndex-1],OxXX,5);
			SendIndex=SendIndex+4;
		}
		else
			SendIndex = SendIndex + 4;

		SendBuff[SendIndex++] = 0;
		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x00,0x93,0,4,1,0,0,0,0,dftype);
		SdPrintf(YNPrint,PreFix," Get_Level2Data_F225 0x00,0x93 IsDataFlag=%d SendIndex=%d\n",IsDataFlag,SendIndex);
		if (IsDataFlag == 0){
			memset(&SendBuff[SendIndex-1],OxXX,5);
			SendIndex=SendIndex+4;
		}
		else
			SendIndex = SendIndex + 4;

		IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x00,0x94,0,4,6,0,0,0,0,dftype);
		SdPrintf(YNPrint,PreFix," Get_Level2Data_F225 0x00,0x94 IsDataFlag=%d\n",IsDataFlag);
//		SdPrintf(YNPrint,PreFix,"");
//		for(i=0;i<32;i++)
//		{
//			printf("%02x ", SendBuff[SendIndex+i]);
//			if(i%4 == 0)
//				SdPrintf(YNPrint,PreFix,"");
//		}
//		SdPrintf(YNPrint,PreFix,"");
		if (IsDataFlag == 0)
		{
			memset(&SendBuff[SendIndex],OxXX,24);
			SendIndex=SendIndex+24;
		}
		else SendIndex = SendIndex + 24;
	}
	else
	{
		memset(&SendBuff[SendIndex],OxXX,36);
		SendIndex=SendIndex+36;
	}
	return 3;

}
#ifdef SHANGHAI
//�ն����½��վ����
INT16U Get_Level2Data_F241(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	TongJi tj;
	INT32U lognum= 0;
	INT8U Temp_FilePath[60];
	StPos=0;
	TS ts;
	SdPrintf(YNPrint,PreFix,"��ȡ�ն����½��վ����(Get_Level2Data_F241)");
	ts.Day=BCD_INT32(&Data[0]+StPos,1);    //��
	ts.Month=BCD_INT32(&Data[0]+StPos+1,1);  //��
	ts.Year=BCD_INT32(&Data[0]+StPos+2,1);  //��
	SendBuff[SendIndex++] = Data[StPos];
	SendBuff[SendIndex++] = Data[StPos+1];
	SendBuff[SendIndex++] = Data[StPos+2];
//����ʱ�䲻��ʱ��
	sprintf((char *)Temp_FilePath,"/nand/DataAlarm/d%2d.dat",ts.Day);
	if(access((char*)Temp_FilePath,0)==0){
		ReadFile((char*)Temp_FilePath,(void*)&tj,sizeof(TongJi),Jproginfo);
		lognum = tj.LoginNum;
//		INT32U_BCD(lognum_day,lognum_day_bcd,4);
		SdPrintf(YNPrint,PreFix,"%d-%d-%d��½����:%d",ts.Year,ts.Month,ts.Day,lognum);
//		memcpy((void*)&SendBuff[SendIndex],(void*)&lognum,4);
		SendBuff[SendIndex++] = lognum & 0xff;
		SendBuff[SendIndex++] = (lognum >> 8) & 0xff;
		SendBuff[SendIndex++] = (lognum >> 2*8) & 0xff;
		SendBuff[SendIndex++] = (lognum >> 3*8) &0xff;
	}
	else{
		SdPrintf(YNPrint,PreFix,"�ļ�%s�Ҳ���",Temp_FilePath);
		memset((void*)&SendBuff[SendIndex],0xee,4);
	}
	SendIndex +=4;
	return 3;
}
//�¶����½��վ����
INT16U Get_Level2Data_F242(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	TongJi tj;
	INT32U lognum = 0;
	INT8U Temp_FilePath[60];
	StPos=0;
	TS ts;
	SdPrintf(YNPrint,PreFix,"��ȡ�¶����½��վ����(Get_Level2Data_F242)");
	ts.Month=BCD_INT32(&Data[0]+StPos,1);  //��
	ts.Year=BCD_INT32(&Data[0]+StPos+1,1);    //��
	SendBuff[SendIndex++] = Data[StPos];
	SendBuff[SendIndex++] = Data[StPos+1];
	sprintf((char *)Temp_FilePath,"/nand/DataAlarm/m%2d.dat",ts.Month);
	if(access((char*)Temp_FilePath,0)==0){
		ReadFile((void*)Temp_FilePath,(void*)&tj,sizeof(TongJi),Jproginfo);
		lognum = tj.LoginNum;
		SdPrintf(YNPrint,PreFix,"%d-%d��½����:%d",ts.Year,ts.Month,lognum);
//		memcpy((void*)&SendBuff[SendIndex],(void*)&lognum,4);
		SendBuff[SendIndex++] = lognum & 0xff;
		SendBuff[SendIndex++] = (lognum >> 8) & 0xff;
		SendBuff[SendIndex++] = (lognum >> 2*8) & 0xff;
		SendBuff[SendIndex++] = (lognum >> 3*8) &0xff;
	}
	else {
		SdPrintf(YNPrint,PreFix,"�ļ�%s�Ҳ���",Temp_FilePath);
		memset(&SendBuff[SendIndex],0xee,4);
	}
	SendIndex +=4;
	return 2;
}
/*
 * +CSQ:N,99�Ļ��㹫ʽ��
��1��0-99��Χ���ù�ʽ��N*2-113 ����ʾGSM��ʵ���ź�ǿ��
��2��100-199��Χ���ù�ʽ�� N-216����ʾTD��ʵ���ź�ǿ��
������ģ���ϱ�+CSQ:149,99
 149����100-199����ʾTD��ʵ���ź�ǿ��=149-216=-67dBm��
GSM�µ�ģ��Ĺ�����Χ��  -20dBm~-102dBm
TD�µ�ģ��Ĺ�����Χ��   -25dBm~-108dBm
����ȷ��N�Ĺ�����Χ:
GSM��N�Ĺ�����ΧΪ 6~66
TD��N�Ĺ�����ΧΪ 108~191
*/
//���ź�ǿ��
INT16U Get_Level2Data_F243(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	TongJi tj;
	INT8U csq = 0xee;
	INT8U Temp_FilePath[60];
	StPos=0;
	TS ts;
	ts.Day=BCD_INT32(&Data[0]+StPos,1);    //��
	ts.Month=BCD_INT32(&Data[0]+StPos+1,1);  //��
	ts.Year=BCD_INT32(&Data[0]+StPos+2,1);   //��
	SendBuff[SendIndex++] = Data[StPos];
	SendBuff[SendIndex++] = Data[StPos+1];
	SendBuff[SendIndex++] = Data[StPos+2];
	sprintf((char *)Temp_FilePath,"/nand/DataAlarm/d%2d.dat",ts.Day);
	if(access((char*)Temp_FilePath,0)==0){
		NormalReadFile((void*)Temp_FilePath,(void*)&tj.GprsCSQ,sizeof(TongJi),Jproginfo);
//		INT32U_BCD(csq,&csq_BCD,1);
		csq = tj.GprsCSQ & 0x000000ff;
		SdPrintf(YNPrint,PreFix,"%d-%d-%d�ź�ǿ��:%d",ts.Year,ts.Month,ts.Day,csq);
		SendBuff[SendIndex++] = csq;
	}
	else
	{
		SdPrintf(YNPrint,PreFix,"�ļ�%s�Ҳ���",Temp_FilePath);
		SendBuff[SendIndex++] = 0xee;
	}
	return 3;
}
#endif
