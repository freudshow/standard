
#ifndef UPDATE_H_
#define UPDATE_H_
//#include "../jAPub/jPub.h"
#include "jGWProtocol.h"
#include <sys/types.h>
#include <sys/ipc.h>

#ifdef __linux__
#include <sys/msg.h>
#include <signal.h>
#else
#include <sys/sched.h>
#include <pthread.h>
#include <sys/neutrino.h>
#endif

void SendOKtoStation(unsigned char* buf);
void    TrnPackACK(INT16U num);
void    TrnFlagWord();
//-----------------------------------------------------------------------
INT8U Packflag(FILE *f,INT8U *buf);
//--------------------------------------------------------------------
void buildUpdatefile(FILE *m_UpDataFile);
//---------------------------------------------------------------------
void copyfile();
//--------------------------------------------------------------------
void SendmyMsg();
//====================================================================
extern void    FileTrans();
#endif
