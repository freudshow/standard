/*
 * update.c
 *
 *  Created on: Nov 30, 2009
 *      Author: ln
 */

#include <unistd.h>
#include "../jBase/inc/pubfunction.h"
#include "update.h"
#include "innerPubVar.h"
#define DebugComm stderr
#define     ALLBYTE 1200

INT8U  		UpdateProgFlag;
INT16U  	RecPacketCount;
INT16U  	FileOffsetCount;
INT32U 		FileOffSet[1024];
INT8U  		PackFlagList[ALLBYTE];
INT32U 		AllByteCount;
INT16U 		oneSize;     //�����ֽ���
INT16U 		AllPackNum;	//�ܰ���
int 		chid, rcvid, status,seq;
pid_t 		spid;
FILE			*m_UpDataFile;				//�����ļ�ָ��

unsigned char 	Asdu130Addr[5];
unsigned char 	Tmp130Buff[FrameSize];

unsigned char   g_fileName[15];				//�����ļ�����

void SendOKtoStation(unsigned char* buf)
{
	SendIndex = 0;
	CreateGWHead(0x8e,0);
	SendBuff[SendIndex++] = 0x0f;//afn   0-12//AFN=0fH���ļ�����
	SendBuff[SendIndex++] = 0x60|(seq&0x0f);//seq
	SendBuff[SendIndex++] = 0;//Tmp130Buff[14];//da1e
	SendBuff[SendIndex++] = 0;//Tmp130Buff[15];//da2
	SendBuff[SendIndex++] = 0;//Tmp130Buff[16];//dt1
	SendBuff[SendIndex++] = 1;//Tmp130Buff[17];//dt2
	SendBuff[SendIndex++] = 4;//�������� 3
	SendBuff[SendIndex++] = 1;
	SendBuff[SendIndex++] = 0;
	SendBuff[SendIndex++] = 1;
	SendBuff[SendIndex++] = 2;
	SendBuff[SendIndex++] = 4;
	SendBuff[SendIndex++] = (unsigned char)(AllByteCount&0xff000000)>>24;//���ֽ���
	SendBuff[SendIndex++] = (unsigned char)(AllByteCount&0x00ff0000)>>16;
	SendBuff[SendIndex++] = (unsigned char)(AllByteCount&0x0000ff00)>>8;
	SendBuff[SendIndex++] = (unsigned char)(AllByteCount&0x000000ff);
	SendBuff[SendIndex++] = AllPackNum & 0x00ff;
	SendBuff[SendIndex++] = (AllPackNum & 0xff00)>>8;
	SendBuff[SendIndex++] = 0;
	SendBuff[SendIndex++] = 0;
	SendBuff[SendIndex++] = 0xff;
	SendBuff[SendIndex++] = 0xff;
	FrameTailCreate_Send(2);
	seq++;
}

void TrnPackACK(INT16U num)
{
	CreateGWHead(0x9e,0);
	SendBuff[SendIndex++]=0x9e;//afn						//13
	SendBuff[SendIndex++]=0x60|(seq&0x0f);//seq			//14
	SendBuff[SendIndex++]=0;//Tmp130Buff[14];//da1e  		//15
	SendBuff[SendIndex++]=0;//Tmp130Buff[15];//da2		//16
	SendBuff[SendIndex++]=0;//Tmp130Buff[16];//dt1		//17
	SendBuff[SendIndex++]=1;//Tmp130Buff[17];//dt2		//18
	SendBuff[SendIndex++]= num & 0x00FF;		//����� �� //19
	SendBuff[SendIndex++]= (num & 0xFF00)>>8; //����� �� //20
	FrameTailCreate_Send(2);
	seq++;
}

void    TrnFlagWord()
{
	INT16U i;
	CreateGWHead(0x8a,0);								//1~12
	SendBuff[SendIndex++]=0x0e;//afn							//13
	SendBuff[SendIndex++]=0x60|(seq&0x0f);//seq			//14
	SendBuff[SendIndex++]=0;//Tmp130Buff[14];//da1e  		//15
	SendBuff[SendIndex++]=0;//Tmp130Buff[15];//da2		//16
	SendBuff[SendIndex++]=0;//Tmp130Buff[16];//dt1		//17
	SendBuff[SendIndex++]=1;//Tmp130Buff[17];//dt2		//18
	for(i=0;i<ALLBYTE;i++)
	{
		if (PackFlagList[i]!=0xff)
		{
			SendBuff[SendIndex++] = i&0xff;
			SendBuff[SendIndex++] = (i>>8)&0xff;
			SendBuff[SendIndex++] = PackFlagList[i];
			break;
		}
	}
	FrameTailCreate_Send(2);
	seq++;
	//FrameTailCreate_Send();
}
//-----------------------------------------------------------------------
INT8U Packflag(FILE *f,INT8U *buf)
{
  int j;
  INT8U m=0;
  int num;
	 if (f!=NULL)
	 {
		 for(j=0;j<AllPackNum;j++)
		 {
			num = 0;m = 0;
			fseek(f,j*(oneSize+1),0);
			num = fread(&m,1,1,f);
			if (num<=0)
				break;
			buf[j/8]=buf[j/8]|((m&0x01)<<(j%8));
		 }
		  for(j=0;j<ALLBYTE;j++)
			 SdPrintf(YNPrint,PreFix,"%x ",buf[j]);
		 return 1;
	 }
	 else
		 return 0;

}
//--------------------------------------------------------------------
void buildUpdatefile(FILE *m_UpDataFile)
{
	char updatefilename[128];
    char command[80];
	FILE *fp;
	INT8U buf[500];
	int num;
	int space,lastpack;
	int j;

	memset(command,0,80);
    sprintf(command,"%s /nand/gprsgw/%s",_CMDRM_,g_fileName);
	syscmd(command,Jproginfo);
	sprintf(updatefilename,"/nand/gprsgw/%s",g_fileName);
	fp=fopen(updatefilename,"wb+");

	lastpack = (AllByteCount)%oneSize;
	space = oneSize +1;
	SdPrintf(YNPrint,PreFix,"space = %d  AllByteCount= %d  laskpack = %d,updatefilename=%s\n\r",space,AllByteCount,lastpack,updatefilename);
	if (fp!= NULL)
	{
		SdPrintf(YNPrint,PreFix,"fp!=null");
		fseek(m_UpDataFile,0,0);
		for(j=0;j<AllPackNum-1;j++)
		{
			memset(buf,0,500);
			num = 0;
			num = fread(buf,space,1,m_UpDataFile);
			if (num<=0)
				break;
			fwrite(&buf[1],oneSize,1,fp);
		}
		memset(buf,0,500);
		space = lastpack + 1;
		fread(buf,space,1,m_UpDataFile);
		fwrite(&buf[1],lastpack,1,fp);
	}
	fclose(fp);
	fp=NULL;
}

//---------------------------------------------------------------------
void copyfile()
{
	char c;
	unsigned char num;
	char infilename[128],outfilename[128];
    FILE *fpin,*fpout;
	sprintf(infilename,"/nand/gprsgw/%s",g_fileName);
	sprintf(outfilename,"%s/%s",_USERDIR_,g_fileName);
	fpin=fopen(infilename,"rb");
	fpout=fopen(outfilename,"wb+");

	fseek(fpin,0,0);
	num = fread(&c,1,1,fpin);
	while(num>0)
	{
		fwrite(&c,1,1,fpout);
		num = fread(&c,1,1,fpin);
	}
	fclose(fpin);
	fclose(fpout);
	fpin=NULL;
	fpout=NULL;
}
//--------------------------------------------------------------------
void SendmyMsg()
{
	Jproginfo->Update_Time|=0x80;
/*#ifdef __linux__
	int senmsgkey;
	int rcvmsgkey;
	char buf[128];
    if((senmsgkey=msgget((key_t)12,IPC_CREAT|0660))<0)//�������͵���Ϣ����
    {
         printf("senmsgkey error %s\n",strerror(errno));
         exit(1);
    }
    printf("senmsgkey key %d\n",senmsgkey);

    if((rcvmsgkey=msgget((key_t)34,IPC_CREAT|0660))<0)//�򿪽��յ���Ϣ����
    {
         printf("rcvmsgkey error %s\n",strerror(errno));
         exit(1);
    }
    printf("rcvmsgkey key %d\n",rcvmsgkey);
    sprintf(buf, "begin");
    if (msgsnd(senmsgkey, buf, sizeof(buf),0) == -1)
    {
    	printf("\n\r in jDataDeal send msg   1");
    	perror("MsgSend");
    	printf("\n\r");
    	return ;
    }
#else
	int  coid;
	char buf[128];
	FILE *fp;
	int numstr;
	char ReadString[50];
	//--------------------------------------------------------
	//���ļ���ȡ fkupdate����pid
	fp = fopen("/user/serverpid","r");
	memset(ReadString,0,50);
	numstr  = fscanf(fp, "%s", ReadString);
	if (numstr<=0)
		return;
	sscanf(ReadString,"%d",&spid);

	memset(ReadString,0,50);
	numstr  = fscanf(fp, "%s", ReadString);
	if (numstr<=0)
		return;
	sscanf(ReadString,"%d",&chid);
	//-------------------------------------------------------
	//������Ϣ"begin"�� fkupdate
    if ((coid = ConnectAttach(0, spid, chid, 0, 0)) == -1) {
            perror("ConnectAttach");
            fclose(fp);
            fp=NULL;
            return;
    }
    sprintf(buf, "begin");
    if (MsgSend(coid, buf, strlen(buf) + 1, buf, sizeof(buf)) != 0) {
            perror("MsgSend");
            fclose(fp);
            fp=NULL;
            return;
    }
    ConnectDetach(coid);
    fclose(fp);
    fp=NULL;
#endif*/
	Jproginfo->Para.UpdateFlags =0;
    //ConnectDetach(coid);
}
//====================================================================

#define CHECK_OK   1
#define CHECK_FAIL 2

struct filetrans_t
{
	INT8U file_ID;
	INT8U file_Attribute;
	INT8U file_Instruction;
	INT16U total; //�ܶ���
	INT32U curr_segment_id;
	INT16U curr_segment_size;     //��ǰ�γ���
	INT8U trans_State;  //0 ��ʼֵδ������  1 ����������   9 �������
	INT8U check_flag;  //0��ʼ  1��ȷ  2����
};
struct filetrans_t file_format;
INT8U SEQ;
INT8U FRAME_TP[6];
INT8U CtrlCode;

void  FileTranACK_Lw(INT8U check_flag)
{
	INT8U cc;
	cc = CtrlCode | (1<<7);
	cc = cc &(~(1<<6));
	CreateGWHead(cc,0); //������ ??????? ������
	SendBuff[SendIndex++]=0x0f;//afn						//13
	SendBuff[SendIndex++]=0x60|(SEQ&0x0f);//seq			//14
	SendBuff[SendIndex++]=0;//Tmp130Buff[14];//da1e  		//15
	SendBuff[SendIndex++]=0;//Tmp130Buff[15];//da2		//16
	SendBuff[SendIndex++]=1;//Tmp130Buff[16];//dt1		//17
	SendBuff[SendIndex++]=0;//Tmp130Buff[17];//dt2		//18
	if(file_format.curr_segment_id>=1 || file_format.curr_segment_id<file_format.total)
	{
		//data
		SendBuff[SendIndex++] = file_format.total &0xff;  //�ܶ���
		SendBuff[SendIndex++] = file_format.total>>8 &0xff; //�ܶ���
		//��һ�α�ʶ

		if(file_format.curr_segment_id==file_format.total && check_flag == CHECK_OK) //ȫ���ļ�����ɹ�
		{
			SendBuff[SendIndex++] = 0xff;
			SendBuff[SendIndex++] = 0xff;
			SendBuff[SendIndex++] = 0xff;
			SendBuff[SendIndex++] = 0xff;
		}else
		{
			if(check_flag == CHECK_OK) //���У��ɹ���������֡id+1 ����Ļ�����ԭ��֡id
			{
				file_format.curr_segment_id++;
			}
			SendBuff[SendIndex++] = file_format.curr_segment_id &0xff;
			SendBuff[SendIndex++] = file_format.curr_segment_id>>8 &0xff;
			SendBuff[SendIndex++] = file_format.curr_segment_id>>16 &0xff;
			SendBuff[SendIndex++] = file_format.curr_segment_id>>24 &0xff;
		}
	}
	//EC
	SendBuff[SendIndex++] = Jdatafileinfo->ErcEvt.EC1;//��Ҫ�¼�������	EC1ֵ
	SendBuff[SendIndex++] = Jdatafileinfo->ErcEvt.EC2;//һ���¼������� 	EC2ֵ
	//TP
	memcpy(&SendBuff[SendIndex], FRAME_TP, 6);  //TP
	SendIndex = SendIndex + 6;
	FrameTailCreate_Send(2);
}

void FileTrans()
{
	INT8U begin, check=0;
	INT8U data[1024];
	int i=0, len;
	FILE *fp=NULL;
	memset(&file_format, 0 ,sizeof(struct filetrans_t));
	CtrlCode = TempBuf[6];
	SEQ = TempBuf[13];
	GetDa(TempBuf[14], TempBuf[15]);
	GetDt(TempBuf[16], TempBuf[17]);
	if (DT[1] == 1) {   //F1
		begin = 18;
		//���ṹ�� file_format
		file_format.file_ID = TempBuf[begin];
		file_format.file_Attribute = TempBuf[begin+1];
		file_format.file_Instruction = TempBuf[begin+2];
		file_format.total = (TempBuf[begin+3])|(TempBuf[begin+4]<<8);
		file_format.curr_segment_id = (TempBuf[begin+5])|
									(TempBuf[begin+6]<<8)|
									(TempBuf[begin+7]<<16)|
									(TempBuf[begin+8]<<24);
		file_format.curr_segment_size = (TempBuf[begin+9])|(TempBuf[begin+10]<<8);

		len = (TempBuf[1]|(TempBuf[2]<<8))>>2;
		for(i=6; i<len+6; i++)
		{
			check += TempBuf[i];
		}
		check = check & 0xff;
		if(check == TempBuf[len+6])
		{
			file_format.check_flag = CHECK_OK;
		}else
		{
			file_format.check_flag = CHECK_FAIL;
		}
		if(access("/nand/gprsgw",0)!=0)
			system("mkdir /nand/gprsgw");
		if(file_format.curr_segment_id==0 || file_format.curr_segment_id>file_format.total)
		{
			printf("\nfile_format.curr_segment_id==0 || \n");
			return;
		}
		memset(data, 0, 1024);
		if(file_format.curr_segment_id==1)
		{
			//��һ������
			system("rm -r /nand/gprsgw/*"); //����������ʱ��ɾ��gprsgw�µ�������ǰ�������ļ�
			printf("\nBegin file trans!!!  %d\n", file_format.curr_segment_id);
			fp=fopen("/nand/gprsgw/updatefile.tar", "wb+");

		}else if(file_format.curr_segment_id<=file_format.total && file_format.curr_segment_id!=0)
		{
			printf("\n file transing!!!  %d\n", file_format.curr_segment_id);
			fp=fopen("/nand/gprsgw/updatefile.tar", "ab+");
		}
		if(fp==NULL)
			printf("\nCan not open /nand/gprsgw/updatefile.tar ERROR ERROR!!!\n");

		memcpy(data, &TempBuf[begin+12], file_format.curr_segment_size);
		fwrite(data, file_format.curr_segment_size, 1, fp);

		fclose(fp);
		memset(FRAME_TP, 0, 6);
		memcpy(FRAME_TP, &TempBuf[begin+file_format.curr_segment_size+26],6);
		//--------------------------------------------------------------------//
	//	ClearWaitTimes(ProjectNo);
		FileTranACK_Lw(file_format.check_flag);//��Ӧ����

		if(file_format.curr_segment_id==file_format.total && file_format.check_flag == CHECK_OK) //ȫ���ļ�����ɹ�
		{
			file_format.trans_State = 9;
			Jproginfo->Para.UpdateFlags = 4;
			//�����ű�
			system("tar -xvf /nand/gprsgw/updatefile.tar -C /nand/gprsgw");
			system("chmod 777 /nand/gprsgw/update.sh");
			system("/nand/gprsgw/update.sh &");
			return;
		}else //����������
		{
			file_format.trans_State = 1;
			Jproginfo->Para.UpdateFlags  = 1;
		}
		return;
	}
	else if(DT[97] == 1) //F97
	{

	}
	else if(DT[98] == 1)//F98
	{

	}
	//--------------------------------------------------------//
}



