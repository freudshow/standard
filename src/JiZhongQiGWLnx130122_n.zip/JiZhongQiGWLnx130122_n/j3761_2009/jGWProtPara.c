/*
 *
 *   ������Լ�ӿں�������
 *       ������Լ���Ĵ���ģ����ýӿں����������Ӧ��������
 *       ������Լ���Ĵ���ģ����ýӿں�����������վ�·�����
 *
 *///-------------------------------------------------------------

#include "time.h"
#include <sys/mman.h>
#include "jGWProtocol.h"
//#include "inc/init.h"
#include "../jBase/inc/pubfunction.h"
#include "innerPubVar.h"
#include <ctype.h>
#include <time.h>

INT16U SetPara_F1_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//�ն�����ͨ�ſ�ͨ�Ų�������
{
	if (Set == 1)//��վ��������
	{
		memcpy(&JSetPara_AFN04_3761_2009->group1.f1.RTS, Data, 1);
		memcpy(&JSetPara_AFN04_3761_2009->group1.f1.Allow_Delay, Data + 1, 1);
		memcpy(&JSetPara_AFN04_3761_2009->group1.f1.DelayTime_AgainNum, Data + 2, 2);
		memcpy(&JSetPara_AFN04_3761_2009->group1.f1.NeedAllow, Data + 4, 1);
		memcpy(&JSetPara_AFN04_3761_2009->group1.f1.HeartInterval, Data + 5, 1);
		if (JSetPara_AFN04_3761_2009->group1.f1.HeartInterval==0)
		{
			if(zone_so==TIANJIN)
				JSetPara_AFN04_3761_2009->group1.f1.HeartInterval=30;
			else
				JSetPara_AFN04_3761_2009->group1.f1.HeartInterval=5;                   //ԭ����5�ó�2
		}
		SetDaDt(P, F);//AFN=00H,Fn=F3ʱ�����ݵ�Ԫ�е����ݵ�Ԫ��ʶ
		SendBuff[SendIndex++] = 0;//ERR=0,ȷ��
//		 Jproginfo->Para.ChangedJiZhongQiInfo = 2;//���漯��������
		Jproginfo->FileSaveFlag.g1flag = 1;
		return 6;
	}
	if (Set == 0)//��ȡ�����ϱ���վ
	{
		SetDaDt(P, F);
		memcpy(&SendBuff[SendIndex++], &JSetPara_AFN04_3761_2009->group1.f1.RTS, 1);
		memcpy(&SendBuff[SendIndex++], &JSetPara_AFN04_3761_2009->group1.f1.Allow_Delay, 1);
		JSetPara_AFN04_3761_2009->group1.f1.DelayTime_AgainNum=0x301E;
		SdPrintf(YNPrint,PreFix,"JSetPara_AFN04_3761_2009->group1.f1.DelayTime_AgainNum = %x\n",
				JSetPara_AFN04_3761_2009->group1.f1.DelayTime_AgainNum);
		SendBuff[SendIndex++] = JSetPara_AFN04_3761_2009->group1.f1.DelayTime_AgainNum & 0x00ff;
		SendBuff[SendIndex++] = 0x30;//(JSetPara_AFN04_3761_2009->group1.f1.DelayTime_AgainNum>>8) & 0x00ff;
//		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group1.f1.DelayTime_AgainNum, 2);
//		SendIndex = SendIndex + 2;
		memcpy(&SendBuff[SendIndex++], &JSetPara_AFN04_3761_2009->group1.f1.NeedAllow, 1);
		memcpy(&SendBuff[SendIndex++], &JSetPara_AFN04_3761_2009->group1.f1.HeartInterval, 1);
		return 4;
	}
	return 1;
}

INT16U SetPara_F2_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//�ն�����ͨ�ſ������м�ת������
{
	INT8U i, Num;
	if (Set == 1)//��վ��������
	{
		memset(&JSetPara_AFN04_3761_2009->group1.f2.Flag_AddrNum, 0, sizeof(JSetPara_AFN04_3761_2009->group1.f2));//��ʼ��
		memcpy(&JSetPara_AFN04_3761_2009->group1.f2.Flag_AddrNum, Data, 1);
		Num = Data[0] & 0x7f;
		for (i = 0; i < Num; i++) {
			memcpy(&JSetPara_AFN04_3761_2009->group1.f2.Addr[i][0], Data + 1 + i * 2, 2);
		}
		SetDaDt(P, F);
		SendBuff[SendIndex++] = 0;
//		Jproginfo->Para.ChangedJiZhongQiInfo = 2;//���漯��������
		Jproginfo->FileSaveFlag.g1flag = 1;
		return 1 + 2* Num ;
	}
	if (Set == 0)//��ȡ�����ϱ���վ
	{
		SetDaDt(P, F);
		memcpy(&SendBuff[SendIndex++], &JSetPara_AFN04_3761_2009->group1.f2.Flag_AddrNum, 1);
		Num = JSetPara_AFN04_3761_2009->group1.f2.Flag_AddrNum & 0x7f;
		for (i = 0; i < Num; i++) {
			memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group1.f2.Addr[i][0], 2);
			SendIndex = SendIndex + 2;
		}
		return 4;
	}
	return 1;
}
INT16U SetPara_F47_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
//	INT8U i, Num;
	if (Set == 1)//��վ��������
	{
		return 17 ;
	}
	if (Set == 0)//��ȡ�����ϱ���վ
	{
		return 4;
	}
	return 1;
}
INT16U SetPara_F3_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��վIP��ַ�Ͷ˿�
{
	int i = 0,flag=0;
//	INT8U TempBufn[60];
	SdPrintf(YNPrint,PreFix,"���ò���F3����վIP��ַ�Ͷ˿ڡ�");
	if (Set == 1)//��վ��������
	{
		for (i = 0; i < 4; i++)
		{
			if (*(Data + 3 - i)!=JSetPara_AFN04_3761_2009->group1.f3.IP[i])
			{
				flag=1;
				SdPrintf(YNPrint,PreFix,"ip diff\n\r");
			}
			if (*(Data + 3 - i)!=0xff)
				JSetPara_AFN04_3761_2009->group1.f3.IP[i] = *(Data + 3 - i);
			else JSetPara_AFN04_3761_2009->group1.f3.IP[i]=0;
		}
		//memcpy(&JSetPara_AFN04_3761_2009->group1.f3.IP[0],Data,4);
		if (JSetPara_AFN04_3761_2009->group1.f3.PortAddress[0]!=*(Data + 4))
		{
			flag=1;
			SdPrintf(YNPrint,PreFix,"PortAddress 0 diff\n\r");
		}
		if (JSetPara_AFN04_3761_2009->group1.f3.PortAddress[1]!=*(Data + 5))
		{
			flag=1;
			SdPrintf(YNPrint,PreFix,"PortAddress 1 diff\n\r");
		}
		memcpy(&JSetPara_AFN04_3761_2009->group1.f3.PortAddress[0], Data + 4, 2);
		for (i = 0; i < 4; i++)
			JSetPara_AFN04_3761_2009->group1.f3.IP1[i] = *(Data + 6 + 3 - i);
		memcpy(&JSetPara_AFN04_3761_2009->group1.f3.PortAddress1[0], Data + 10, 2);

		for (i = 0; i < 16; i++)
		{
			if (toupper(*(Data + 12 + 15 - i))!=toupper(JSetPara_AFN04_3761_2009->group1.f3.APN[i]))
			{
				flag=2;
				SdPrintf(YNPrint,PreFix,"APN diff  %02x--%02x\n\r",JSetPara_AFN04_3761_2009->group1.f3.APN[i],*(Data + 12 + 15 - i));
			}
		}
		memset(JSetPara_AFN04_3761_2009->group1.f3.APN, 0x00, 16);
		for (i = 0; i < 16; i++)
		{
			JSetPara_AFN04_3761_2009->group1.f3.APN[i] = *(Data + 12 + 15 - i);
		}
		//memcpy(&JSetPara_AFN04_3761_2009->group1.f3.APN,Data+12,16);
		SetDaDt(P, F);
		SendBuff[SendIndex++] = 0;

//		memset(TempBufn,0,60);
//		sprintf((char*)TempBufn,"%s/JzhqParaN.par",_PARADIR_);
//		NormalSaveFile((char*)TempBufn, &Jcfginfo->jzqpara, sizeof(Jcfginfo->jzqpara),Jproginfo);
//		delay(100);
//		Jproginfo->Para.ChangedJiZhongQiInfo = 2;//���漯��������
		Jproginfo->FileSaveFlag.g1flag = 1;
		if (flag>=1)
			ReLink=1;
		if (flag==2)
		{
			write_apn();
			Jproginfo->Gprs_ok = 0;
			//syscmd("slay pppd > /dev/null");
		}
		return 28;
	}
	if (Set == 0)//��ȡ�����ϱ���վ
	{
		SetDaDt(P, F);
		for (i = 0; i < 4; i++)
			SendBuff[SendIndex++] = JSetPara_AFN04_3761_2009->group1.f3.IP[3 - i];
		//SendIndex=SendIndex+4;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group1.f3.PortAddress[0], 2);
		SendIndex = SendIndex + 2;
		for (i = 0; i < 4; i++)
			SendBuff[SendIndex++] = JSetPara_AFN04_3761_2009->group1.f3.IP1[3 - i];

		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group1.f3.PortAddress1[0], 2);
		SendIndex = SendIndex + 2;

		for (i = 0; i < 16; i++)
			SendBuff[SendIndex++] = JSetPara_AFN04_3761_2009->group1.f3.APN[15 - i];
		return 4;
	}
	return 1;
}

INT16U SetPara_F4_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��վ�绰����Ͷ������ĺ���
{
	if (Set == 1)//��վ��������
	{
		memcpy(&JSetPara_AFN04_3761_2009->group1.f4.ZZ[0], Data, 8);
		memcpy(&JSetPara_AFN04_3761_2009->group1.f4.SM[0], Data + 8, 8);
		SetDaDt(P, F);
		SendBuff[SendIndex++] = 0;
//		Jproginfo->Para.ChangedJiZhongQiInfo = 2;//���漯��������
		Jproginfo->FileSaveFlag.g1flag = 1;
		return 16;
	}

	if (Set == 0)//��ȡ�����ϱ���վ
	{
		SetDaDt(P, F);
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group1.f4.ZZ[0], 8);
		SendIndex = SendIndex + 8;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group1.f4.SM[0], 8);
		SendIndex = SendIndex + 8;
		return 4;
	}
	return 1;
}

INT16U SetPara_F5_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//�ն�����ͨ����Ϣ��֤����
{
	if (Set == 1)//��վ��������
	{
		memcpy(&JSetPara_AFN04_3761_2009->group1.f5.XiaoXi_Renzheng_FangAN, Data, 1);
		memcpy(&JSetPara_AFN04_3761_2009->group1.f5.CanShu[0], Data + 1, 2);
		//printf("\n\rset f5 %02x-%02x---%02x-%02x\n\r",*(Data+1),*(Data+2),JSetPara_AFN04_3761_2009->group1.f5.CanShu[0],JSetPara_AFN04_3761_2009->group1.f5.CanShu[1]);
		SetDaDt(P, F);
		SendBuff[SendIndex++] = 0;
//		Jproginfo->Para.ChangedJiZhongQiInfo = 2;//���漯��������
		Jproginfo->FileSaveFlag.g1flag = 1;
		return 3;
	}
	if (Set == 0)//��ȡ�����ϱ���վ
	{
		SetDaDt(P, F);
		memcpy(&SendBuff[SendIndex++], &JSetPara_AFN04_3761_2009->group1.f5.XiaoXi_Renzheng_FangAN,	1);
		//printf("\n\rread f5 ---%02x-%02x\n\r",JSetPara_AFN04_3761_2009->group1.f5.CanShu[0],JSetPara_AFN04_3761_2009->group1.f5.CanShu[1]);
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group1.f5.CanShu[0], 2);
		SendIndex = SendIndex + 2;
		return 4;
	}
	return 1;
}

INT16U SetPara_F6_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//�ն����ַ����
{
	if (Set == 1)//��վ��������
	{
		memcpy(&JSetPara_AFN04_3761_2009->group1.f6.GroupAdress0[0], Data, 2);
		memcpy(&JSetPara_AFN04_3761_2009->group1.f6.GroupAdress1[0], Data + 2, 2);
		memcpy(&JSetPara_AFN04_3761_2009->group1.f6.GroupAdress2[0], Data + 4, 2);
		memcpy(&JSetPara_AFN04_3761_2009->group1.f6.GroupAdress3[0], Data + 6, 2);
		memcpy(&JSetPara_AFN04_3761_2009->group1.f6.GroupAdress4[0], Data + 8, 2);
		memcpy(&JSetPara_AFN04_3761_2009->group1.f6.GroupAdress5[0], Data + 10, 2);
		memcpy(&JSetPara_AFN04_3761_2009->group1.f6.GroupAdress6[0], Data + 12, 2);
		memcpy(&JSetPara_AFN04_3761_2009->group1.f6.GroupAdress7[0], Data + 14, 2);
		SetDaDt(P, F);
		SendBuff[SendIndex++] = 0;
//		Jproginfo->Para.ChangedJiZhongQiInfo = 2;//���漯��������
		Jproginfo->FileSaveFlag.g1flag = 1;
		return 16;
	}
	if (Set == 0)//��ȡ�����ϱ���վ
	{
		SetDaDt(P, F);
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group1.f6.GroupAdress0[0], 2);
		SendIndex = SendIndex + 2;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group1.f6.GroupAdress1[0], 2);
		SendIndex = SendIndex + 2;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group1.f6.GroupAdress2[0], 2);
		SendIndex = SendIndex + 2;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group1.f6.GroupAdress3[0], 2);
		SendIndex = SendIndex + 2;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group1.f6.GroupAdress4[0], 2);
		SendIndex = SendIndex + 2;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group1.f6.GroupAdress5[0], 2);
		SendIndex = SendIndex + 2;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group1.f6.GroupAdress6[0], 2);
		SendIndex = SendIndex + 2;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group1.f6.GroupAdress7[0], 2);
		SendIndex = SendIndex + 2;
		return 4;
	}
	return 1;
}

INT16U SetPara_F7_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//�ն�IP��ַ�Ͷ˿�
{
	INT8U passwd[20];
	INT16U len;
	INT8U IP[4],strIP[100],cmd[100];
	len = 0;
	if (Set == 1)//��վ��������
	{
		memcpy(&JSetPara_AFN04_3761_2009->group1.f7.IP[0], Data, 4);
		memcpy(&JSetPara_AFN04_3761_2009->group1.f7.SubnetAddresses[0], Data + 4, 4);
		memcpy(&JSetPara_AFN04_3761_2009->group1.f7.GateWay[0], Data + 8, 4);
		memcpy(&JSetPara_AFN04_3761_2009->group1.f7.SubstituteType, Data + 12, 1);
		memcpy(&JSetPara_AFN04_3761_2009->group1.f7.SubstituteIP[0], Data + 13, 4);
		memcpy(&JSetPara_AFN04_3761_2009->group1.f7.SubstitutePort[0], Data + 17, 2);
		memcpy(&JSetPara_AFN04_3761_2009->group1.f7.SubstituteConnetType, Data + 19, 1);
		memcpy(&JSetPara_AFN04_3761_2009->group1.f7.UserLen, Data + 20, 1);
		memcpy(&JSetPara_AFN04_3761_2009->group1.f7.UserName[0], Data + 21, JSetPara_AFN04_3761_2009->group1.f7.UserLen);
		len = 21 + JSetPara_AFN04_3761_2009->group1.f7.UserLen;
		memcpy(&JSetPara_AFN04_3761_2009->group1.f7.PassLen, Data + len, 1);
		len = len + 1;
		memset(passwd, 0, 20);
		memcpy(passwd, Data + len, JSetPara_AFN04_3761_2009->group1.f7.PassLen);
		len = len + JSetPara_AFN04_3761_2009->group1.f7.PassLen;
		memcpy(&JSetPara_AFN04_3761_2009->group1.f7.WatchPort[0], Data + len, 2);
		if (JSetPara_AFN04_3761_2009->group1.f7.PassLen % 2 != 0) {
			passwd[JSetPara_AFN04_3761_2009->group1.f7.PassLen] = '0';
			len = JSetPara_AFN04_3761_2009->group1.f7.PassLen + 1;
		} else {
			len = JSetPara_AFN04_3761_2009->group1.f7.PassLen;
		}

		ASCToBCD(passwd, len, JSetPara_AFN04_3761_2009->group1.f7.PassWords);
		if(zone_so==TIANJIN)
		{
			JSetPara_AFN04_3761_2009->group1.f7.PassWords[0]=0x11;
			JSetPara_AFN04_3761_2009->group1.f7.PassWords[1]=0x11;
			JSetPara_AFN04_3761_2009->group1.f7.PassWords[2]=0x11;
		}

		memset(IP,0,4);
		memset(cmd, 0, 100);
		memset(strIP, 0, 100);
		sprintf((char*)strIP, "ifconfig eth0 %d.%d.%d.%d up",
								JSetPara_AFN04_3761_2009->group1.f7.IP[0],
								JSetPara_AFN04_3761_2009->group1.f7.IP[1],
								JSetPara_AFN04_3761_2009->group1.f7.IP[2],
								JSetPara_AFN04_3761_2009->group1.f7.IP[3]);
		sprintf((char*)cmd, "echo %s > /nor/rc.d/ip.sh", strIP);
		system((char*)cmd);
		SetDaDt(P, F);
		SendBuff[SendIndex++] = 0;
//		Jproginfo->Para.ChangedJiZhongQiInfo = 2;//���漯��������
		Jproginfo->FileSaveFlag.g1flag = 1;
		return 64;
	}
	if (Set == 0)//��ȡ�����ϱ���վ
	{
		SetDaDt(P, F);
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group1.f7.IP[0], 4);
		SendIndex = SendIndex + 4;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group1.f7.SubnetAddresses[0], 4);
		SendIndex = SendIndex + 4;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group1.f7.GateWay[0], 4);
		SendIndex = SendIndex + 4;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group1.f7.SubstituteType, 1);
		SendIndex = SendIndex + 1;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group1.f7.SubstituteIP[0], 4);
		SendIndex = SendIndex + 4;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group1.f7.SubstitutePort[0], 2);
		SendIndex = SendIndex + 2;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group1.f7.SubstituteConnetType, 1);
		SendIndex = SendIndex + 1;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group1.f7.UserLen, 1);
		SendIndex = SendIndex + 1;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group1.f7.UserName[0],
				JSetPara_AFN04_3761_2009->group1.f7.UserLen);
		SendIndex = SendIndex + JSetPara_AFN04_3761_2009->group1.f7.UserLen;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group1.f7.PassLen, 1);
		SendIndex = SendIndex + 1;
		if (JSetPara_AFN04_3761_2009->group1.f7.PassLen % 2 != 0) {
			len = JSetPara_AFN04_3761_2009->group1.f7.PassLen + 1;
		} else {
			len = JSetPara_AFN04_3761_2009->group1.f7.PassLen;
		}
		len = len / 2;
		if(zone_so==TIANJIN)
			SendBuff[SendIndex] = '1';
		else
			BCDToASC(JSetPara_AFN04_3761_2009->group1.f7.PassWords, len, &SendBuff[SendIndex]);
		//memcpy(&SendBuff[SendIndex],&JSetPara_AFN04_3761_2009->group1.f7.PassWords[0],20);
		SendIndex = SendIndex + JSetPara_AFN04_3761_2009->group1.f7.PassLen;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group1.f7.WatchPort[0], 2);
		SendIndex = SendIndex + 2;
		return 4;
	}
	return 1;
}

INT16U SetPara_F8_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//�ն�����ͨ�Ź�����ʽ����̫ר��������ר����
{
	if (Set == 1)//��վ��������
	{
		memcpy(&JSetPara_AFN04_3761_2009->group1.f8.Type, Data, 1);
		memcpy(&JSetPara_AFN04_3761_2009->group1.f8.Interval[0], Data + 1, 2);
		memcpy(&JSetPara_AFN04_3761_2009->group1.f8.Num, Data + 3, 1);
		memcpy(&JSetPara_AFN04_3761_2009->group1.f8.ShutDown, Data + 4, 1);
		memcpy(&JSetPara_AFN04_3761_2009->group1.f8.Flag[0], Data + 5, 3);
		SetDaDt(P, F);
		SendBuff[SendIndex++] = 0;
//		Jproginfo->Para.ChangedJiZhongQiInfo = 2;//���漯��������
		Jproginfo->FileSaveFlag.g1flag = 1;
		return 8;
	}
	if (Set == 0)//��ȡ�����ϱ���վ
	{
		SetDaDt(P, F);
		memcpy(&SendBuff[SendIndex++], &JSetPara_AFN04_3761_2009->group1.f8.Type, 1);
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group1.f8.Interval[0], 2);
		SendIndex = SendIndex + 2;
		memcpy(&SendBuff[SendIndex++], &JSetPara_AFN04_3761_2009->group1.f8.Num, 1);
		memcpy(&SendBuff[SendIndex++], &JSetPara_AFN04_3761_2009->group1.f8.ShutDown, 1);
		memset(JSetPara_AFN04_3761_2009->group1.f8.Flag,0xFF,3);
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group1.f8.Flag[0], 3);
		SendIndex = SendIndex + 3;
		return 4;
	}
	return 1;
}

INT16U SetPara_F9_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//�ն� �¼���¼��������
{
	if (Set == 1)//��վ��������
	{
		memcpy(&JSetPara_AFN04_3761_2009->group2.f9.Flag[0], Data, 8);
		memcpy(&JSetPara_AFN04_3761_2009->group2.f9.FlagStep[0], Data + 8, 8);
		SetDaDt(P, F);
		SendBuff[SendIndex++] = 0;
//		Jproginfo->Para.ChangedJiZhongQiInfo = 2;//���漯��������
		Jproginfo->FileSaveFlag.g2flag = 1;
		return 16;
	}
	if (Set == 0)//��ȡ�����ϱ���վ
	{
		SetDaDt(P, F);
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group2.f9.Flag[0], 8);
		SendIndex = SendIndex + 8;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group2.f9.FlagStep[0], 8);
		SendIndex = SendIndex + 8;
		return 4;
	}
	return 1;
}

INT16U SetPara_F10_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//�ն�����ͨ�Ź�����ʽ����̫ר��������ר���� //9.27
{
	INT8U 	DaNo,XiaoNo;
	INT8U i, baud;//TempBufn[60];
	INT16U Num, dIndex, meter, Index[PointMax],metold,nn,fqn;//dIndex-���ܱ�/��������װ�����;Index[PointMax]-��Ų�ѯ�Ķ������
	int meternum=0;
	meter=0;
	metold=0;
	nn=0;
	fqn=0;
	if (Set == 1)//��վ��������
	{
		Num = Data[0] + (Data[1] << 8);
		SdPrintf(YNPrint,PreFix,"set =%d--%02x--%02x\n\r",Num,Data[0],Data[1]);
		for (i = 0; i < Num; i++) {
			dIndex = Data[2 + i * 27] + (Data[3 + i * 27] << 8);
			if (dIndex >= PointMax)
			{
				return 0;
			}
			metold=JSetPara_AFN04_3761_2009->group2.f10[dIndex-1].PointIndex[0]
			               +(JSetPara_AFN04_3761_2009->group2.f10[dIndex-1].PointIndex[1]<<8);
			if (metold>0)
				JSetPara_AFN04_3761_2009->group2.f10[metold - 1].Status=0;
			meter = *(Data + 4 + i * 27) + (*(Data + 5 + i * 27) << 8);

			memcpy(&JSetPara_AFN04_3761_2009->group2.f10[dIndex-1].PointIndex[0], Data + 4+ i * 27, 2);
			SdPrintf(YNPrint,PreFix,"set f10 meterold=%d,meter=%d,index=%d\n\r",metold,meter,dIndex);
			if (meter>0)
			{
				//memcpy(&Jmemory->Points.f10.f10[dIndex-1].CommVP,Data+6+i*27,1);//ͨ�����ʼ��˿�
				memcpy(&JSetPara_AFN04_3761_2009->group2.f10[meter - 1].ConnectType, Data +7+ i * 27, 1);//ͨ��Э������ 1 97 30 2007
				memcpy(&JSetPara_AFN04_3761_2009->group2.f10[meter - 1].Address[0], Data + 8
						+ i * 27, 6);//ͨ�ŵ�ַ

				memcpy(&JSetPara_AFN04_3761_2009->group2.f10[meter - 1].PassWord[0], Data + 14
						+ i * 27, 6);//ͨ������
				memcpy(&JSetPara_AFN04_3761_2009->group2.f10[meter - 1].FeiLvCnt, Data + 20 + i
						* 27, 1);//���ܷ��ʸ���
				memcpy(&JSetPara_AFN04_3761_2009->group2.f10[meter - 1].DecimalDigits, Data
						+ 21 + i * 27, 1);//�й�����ʾֵ����λ��С��λ����
				if ((JSetPara_AFN04_3761_2009->group2.f10[meter - 1].port == 2)
						||(JSetPara_AFN04_3761_2009->group2.f10[meter - 1].port==3))
					memset(&JSetPara_AFN04_3761_2009->group2.f10[meter - 1].CaijiqiAddress[0],0,6);
				else
					memcpy(&JSetPara_AFN04_3761_2009->group2.f10[meter - 1].CaijiqiAddress[0], Data + 22 + i * 27, 6);//�����ɼ���ͨ�ŵ�ַ
				memcpy(&JSetPara_AFN04_3761_2009->group2.f10[meter - 1].UserType, Data + 28 + i
						* 27, 1);//�û�����ż��û�С���

				baud = (Data[6 + i * 27] & 0xe0) >> 5;//SD������
				switch (baud) {
				case 1:
					JSetPara_AFN04_3761_2009->group2.f10[meter - 1].baudrate = 600 / 300;
					break;
				case 2:
					JSetPara_AFN04_3761_2009->group2.f10[meter - 1].baudrate = 1200 / 300;
					break;
				case 3:
					JSetPara_AFN04_3761_2009->group2.f10[meter - 1].baudrate = 2400 / 300;
					break;
				case 4:
					JSetPara_AFN04_3761_2009->group2.f10[meter - 1].baudrate = 4800 / 300;
					break;
				case 5:
					JSetPara_AFN04_3761_2009->group2.f10[meter - 1].baudrate = 7200 / 300;
					break;
				case 6:
					JSetPara_AFN04_3761_2009->group2.f10[meter - 1].baudrate = 9600 / 300;
					break;
				case 7:
					JSetPara_AFN04_3761_2009->group2.f10[meter - 1].baudrate = 19200 / 300;
					break;
				}
				JSetPara_AFN04_3761_2009->group2.f10[meter - 1].port = Data[6 + i * 27] & 0x1f;//SD�˿ں�
				SdPrintf(YNPrint,PreFix,"Э�����ͣ�%d",JSetPara_AFN04_3761_2009->group2.f10[meter - 1].ConnectType);
				SdPrintf(YNPrint,PreFix,"����ַ:%02x %02x %02x %02x %02x %02x",
						  JSetPara_AFN04_3761_2009->group2.f10[meter - 1].Address[0],
						  JSetPara_AFN04_3761_2009->group2.f10[meter - 1].Address[1],
						  JSetPara_AFN04_3761_2009->group2.f10[meter - 1].Address[2],
						  JSetPara_AFN04_3761_2009->group2.f10[meter - 1].Address[3],
						  JSetPara_AFN04_3761_2009->group2.f10[meter - 1].Address[4],
						  JSetPara_AFN04_3761_2009->group2.f10[meter - 1].Address[5]);
				if(JSetPara_AFN04_3761_2009->group2.f10[meter - 1].ConnectType == 21){
					//�Ϻ�������  ����ǰ2λ + ���ŵ���λASCII��ת����2ΪBCD�루10���Ʊ�ʾ��+���ź�6λ
					if((JSetPara_AFN04_3761_2009->group2.f10[meter - 1].Address[3]>=0x65 &&
							JSetPara_AFN04_3761_2009->group2.f10[meter - 1].Address[3]<=0x90)){
						JSetPara_AFN04_3761_2009->group2.f10[meter - 1].Address[3] -= 0x30;
					}
					if(JSetPara_AFN04_3761_2009->group2.f10[meter - 1].Address[5] == 0x00)
						JSetPara_AFN04_3761_2009->group2.f10[meter - 1].Address[5] = 0xff;
				}
				JSetPara_AFN04_3761_2009->group2.f10[meter - 1].jiao_yan_wei = 1;//SDУ��λ
				JSetPara_AFN04_3761_2009->group2.f10[meter - 1].shu_ju_wei = 8;//SD����λ
				JSetPara_AFN04_3761_2009->group2.f10[meter - 1].ting_zhi_wei = 1;//SDֹͣλ
				JSetPara_AFN04_3761_2009->group2.f10[meter - 1].Status = 1;
				JSetPara_AFN04_3761_2009->group2.f10[meter - 1].CjqNo = (meter - 1) / 64 + 1;//SD�ɼ���
				JSetPara_AFN04_3761_2009->group2.f10[meter - 1].MeterNo = (meter - 1) % 64;//SD�������
				JSetPara_AFN04_3761_2009->group2.f10[meter - 1].FirRead=2;
				JSetPara_AFN04_3761_2009->group2.f10[meter - 1].Type = 3;

				DaNo = (JSetPara_AFN04_3761_2009->group2.f10[meter - 1].UserType & 0xf0) >>4;		//�����
				XiaoNo = JSetPara_AFN04_3761_2009->group2.f10[meter - 1].UserType & 0x0f;			//С���
//10.30
//				if(DaNo == 0) {
//					if(JSetPara_AFN04_3761_2009->group2.f10[meter - 1].f10.port == 31){		//�ز�Ĭ�ϵ����
//						JSetPara_AFN04_3761_2009->group2.f10[meter - 1].f25.Type = 9;
//					}
//				}

				if(zone_so != SHANGHAI){
					if(DaNo == 5 || DaNo == 4) {		//E������û�Ϊ�����
						JSetPara_AFN04_3761_2009->group2.f10[meter - 1].Type = 9;
					}
				}else if(zone_so == SHANGHAI){
					if((DaNo == 5 && XiaoNo==1)|| (DaNo == 7 && XiaoNo ==1)){   //���������
						JSetPara_AFN04_3761_2009->group2.f10[meter - 1].Type = 9;
					}
					else {//���������
						JSetPara_AFN04_3761_2009->group2.f10[meter - 1].Type = 3;
					}
				}
				memset(&JSetPara_AFN04_3761_2009->group2.f10[meter - 1].AlarmFlg[0],0,64);
				if(JSetPara_AFN04_3761_2009->group2.f10[meter - 1].Address[0]==0 &&
					JSetPara_AFN04_3761_2009->group2.f10[meter - 1].Address[1]==0 &&
					JSetPara_AFN04_3761_2009->group2.f10[meter - 1].Address[2]==0 &&
					JSetPara_AFN04_3761_2009->group2.f10[meter - 1].Address[3]==0 &&
					JSetPara_AFN04_3761_2009->group2.f10[meter - 1].Address[4]==0 &&
					JSetPara_AFN04_3761_2009->group2.f10[meter - 1].Address[5]==0 )
					JSetPara_AFN04_3761_2009->group2.f10[meter - 1].Status = 0;

			}//�Ϻ�������ַascII 80->50
		}
		SetDaDt(P, F);
		SendBuff[SendIndex++] = 0;
//		system("rm -r /nand/para/Ammeter*");
//		system("rm -r /nand/para/bak*");
//		memset(TempBufn,0,60);
//		sprintf((char*)TempBufn,"%s/AmmeterN.par",_PARADIR_);
//		NormalSaveFile((char*)TempBufn,
//				(INT8U *)&JSetPara_AFN04_3761_2009->group2.f10,
//				sizeof(JSetPara_AFN04_3761_2009->group2.f10),Jproginfo);
//		delay(100);
		Jproginfo->Para.ChangedPointInfo = meter;//������������
//		SaveMeterPara1(PointMax+1);
		Jproginfo->stateflags.F10_Changed = 1;
//		Jmemory->F10_ChangedSave = 1;
		Jproginfo->FileSaveFlag.F10_ChangedSave[meter-1] = 1;
		SdPrintf(YNPrint,PreFix,"F10_ChangedSave=%d",Jproginfo->FileSaveFlag.F10_ChangedSave[meter-1]);
		return 2 + Num * 27;

	}
	if (Set == 0)//��ȡ�����ϱ���վ
	{
		SetDaDt(P, F);
		dIndex=SendIndex;
//		memcpy(&SendBuff[SendIndex], Data, 2);//���ε��ܱ�/��������װ����������n
//		SendIndex = SendIndex + 2;
		Num = (*(Data + 1) << 8) + *Data;
		SdPrintf(YNPrint,PreFix,"get f10=%d\n\r",Num);
		meternum = 0;
		for (i = 0; i < Num; i++) {
			Index[i] = *(Data + 2 + 2* i ) + (*(Data + 3 + 2* i ) << 8);//��Ų�ѯ�Ķ������
			SdPrintf(YNPrint,PreFix,"get f10--ind=%d\n\r",Index[i]);
			if(Index[i]>=1 && Index[i]<=PointMax)
			{
				if(JSetPara_AFN04_3761_2009->group2.f10[Index[i] - 1].Status == 1)
					meternum++;
			}
		}
		SdPrintf(YNPrint,PreFix, "\n get f10 meternum=%d,\n\r",meternum);
		SendBuff[SendIndex++] = meternum & 0xff;
		SendBuff[SendIndex++] = (meternum>>8) & 0xff;
		metold=0;
		for (i = 0; i < Num; i++)
		{
			if (Index[i] >= PointMax) {
				Index[i] = PointMax;
			}

			meter=JSetPara_AFN04_3761_2009->group2.f10[Index[i]-1].PointIndex[0]+
					(JSetPara_AFN04_3761_2009->group2.f10[Index[i]-1].PointIndex[1]<<8);
			if (meter==0)
				continue;
			if(JSetPara_AFN04_3761_2009->group2.f10[meter - 1].Status != 1)
			{
				SdPrintf(YNPrint,PreFix, "get f10 meter=%d,index=%d �޴˲�����\n\r",meter,Index[i]);
				continue;
			}
			metold++;
			SdPrintf(YNPrint,PreFix,"Get f10 meter=%d,index=%d",meter,Index[i]);
			SendBuff[SendIndex++]=Index[i]&0xff;
			SendBuff[SendIndex++]=(Index[i]>>8)&0xff;
			SendBuff[SendIndex++]=meter&0xff;
			SendBuff[SendIndex++]=(meter>>8)&0xff;
			SendBuff[SendIndex] = 0x00;
			switch (JSetPara_AFN04_3761_2009->group2.f10[meter - 1].baudrate) {
			case 2:
				SendBuff[SendIndex] = (1 << 5) & 0xe0;
				break;
			case 4:
				SendBuff[SendIndex] = (2 << 5) & 0xe0;
				break;
			case 8:
				SendBuff[SendIndex] = (3 << 5) & 0xe0;
				break;
			case 16:
				SendBuff[SendIndex] = (4 << 5) & 0xe0;
				break;
			case 24:
				SendBuff[SendIndex] = (5 << 5) & 0xe0;
				break;
			case 32:
				SendBuff[SendIndex] = (6 << 5) & 0xe0;
				break;
			case 64:
				SendBuff[SendIndex] = (7 << 5) & 0xe0;
				break;
			}

			SendBuff[SendIndex] = SendBuff[SendIndex] | (JSetPara_AFN04_3761_2009->group2.f10[meter - 1].port & 0X1F);
			//memcpy(&SendBuff[SendIndex],&Jmemory->Points.f10.f10[Index[i]-1].CommVP,1);//ͨ�����ʼ��˿�
			SendIndex = SendIndex + 1;
			memcpy(&SendBuff[SendIndex],
					&JSetPara_AFN04_3761_2009->group2.f10[meter - 1].ConnectType, 1);//ͨ��Э������ 1 97 30 2007
			SendIndex = SendIndex + 1;

			memcpy(&SendBuff[SendIndex],
					&JSetPara_AFN04_3761_2009->group2.f10[meter - 1].Address[0], 6);//ͨ�ŵ�ַ
			if(JSetPara_AFN04_3761_2009->group2.f10[meter - 1].ConnectType == 21){
				//�Ϻ�������  ����ǰ2λ + ���ŵ���λASCII��ת����2ΪBCD�루10���Ʊ�ʾ��+���ź�6λ
				SendBuff[SendIndex+3] = JSetPara_AFN04_3761_2009->group2.f10[meter - 1].Address[3] + 0x30;
				if(JSetPara_AFN04_3761_2009->group2.f10[meter - 1].Address[5] == 0xff)
					SendBuff[SendIndex+5] = 0x00;
			}
			SendIndex = SendIndex + 6;
			memcpy(&SendBuff[SendIndex],
					&JSetPara_AFN04_3761_2009->group2.f10[meter - 1].PassWord[0], 6);//ͨ������
			SendIndex = SendIndex + 6;
			memcpy(&SendBuff[SendIndex],
					&JSetPara_AFN04_3761_2009->group2.f10[meter - 1].FeiLvCnt, 1);//���ܷ��ʸ���
			SendIndex = SendIndex + 1;
			memcpy(&SendBuff[SendIndex],
					&JSetPara_AFN04_3761_2009->group2.f10[meter - 1].DecimalDigits, 1);//�й�����ʾֵ����λ��С��λ����
			SendIndex = SendIndex + 1;
			memcpy(&SendBuff[SendIndex],
					&JSetPara_AFN04_3761_2009->group2.f10[meter - 1].CaijiqiAddress[0], 6);//�����ɼ���ͨ�ŵ�ַ
			SendIndex = SendIndex + 6;
			memcpy(&SendBuff[SendIndex],
					&JSetPara_AFN04_3761_2009->group2.f10[meter - 1].UserType, 1);//�û�����ż��û�С���
			SendIndex = SendIndex + 1;

			nn++;
			if (((nn%100)==0)&&(Num>100)&&(nn!=Num))
			{
				fqn++;
				if (fqn==1)
				{
					SendBuff[dIndex++]=metold&0xff;
					SendBuff[dIndex++]=(metold>>8)&0xff;
					SendBuff[13] = 0x40 | (Fseq & 0x0f);
					FrameTailCreate_Send(0);
					metold=0;
				}
				else
				{
					SendBuff[dIndex++]=metold&0xff;
					SendBuff[dIndex++]=(metold>>8)&0xff;
					SendBuff[13] = 0x00 | (Fseq & 0x0f);
					FrameTailCreate_Send(0);
					metold=0;
				}
				CreateGWHead(0x88, 0);
				// SdPrint("\n\rComplete create head!");
				SendBuff[SendIndex++] = 0x0a;//afn
				SdPrintf(YNPrint,PreFix,"\n\rFlag0-1");
				SendBuff[SendIndex] = 0x00 | (Fseq & 0x0f);
				SendIndex++;
				SetDaDt(P, F);
				dIndex=SendIndex;
				SendIndex = SendIndex + 2;

			}
		}
		SendBuff[dIndex++]=metold&0xff;
		SendBuff[dIndex++]=(metold>>8)&0xff;
		return 4 + 2* ( Num+1);
	}
	return 1;
}

INT16U SetPara_F11_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	int num=0,i,port,iNum, Index[MaichongInputMax];
	if (Set == 1)//��վ��������
	{
		num=Data[0];
		for(i=0;i<num;i++)
		{
			port=Data[1+i*5];
			memcpy(&JSetPara_AFN04_3761_2009->group2.f11.MaiChong[port-1].CeLiangNo, &Data[2+i*5], 4);
			SdPrintf(YNPrint,PreFix,"port=%d,%d,%02x,%02x %02x\n\r",port,JSetPara_AFN04_3761_2009->group2.f11.MaiChong[port-1].CeLiangNo,
					JSetPara_AFN04_3761_2009->group2.f11.MaiChong[port-1].Stat,JSetPara_AFN04_3761_2009->group2.f11.MaiChong[port-1].ChangShu[0],
					JSetPara_AFN04_3761_2009->group2.f11.MaiChong[port-1].ChangShu[1]);
		}
		SetDaDt(P, F);
		SendBuff[SendIndex++] = 1;//ERR=0,ȷ��
		Jproginfo->FileSaveFlag.g2flag = 1;
		return 1+5*num;
	}
	else
	{
		SetDaDt(P, F);
		memcpy(&SendBuff[SendIndex++], Data, 1);
		iNum = Data[0];//���β�ѯ����n
		for (i = 0; i < iNum; i++) {
			Index[i] = Data[1 + i];//��Ų�ѯ�Ķ������
		}
		for (i = 0; i < iNum; i++) {
			SendBuff[SendIndex++]=Index[i];

			memcpy(&SendBuff[SendIndex++],
					&JSetPara_AFN04_3761_2009->group2.f11.MaiChong[Index[i] - 1].CeLiangNo, 1);
			memcpy(&SendBuff[SendIndex++],
					&JSetPara_AFN04_3761_2009->group2.f11.MaiChong[Index[i] - 1].Stat, 1);
			memcpy(&SendBuff[SendIndex],
					&JSetPara_AFN04_3761_2009->group2.f11.MaiChong[Index[i] - 1].ChangShu, 2);
			SendIndex=SendIndex+2;
		}
		return 4 + iNum + 1;
	}
	return num;
}

INT16U SetPara_F12_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//�ն�����ͨ�Ź�����ʽ����̫ר��������ר����
{
	if (Set == 1)//��վ��������
	{
		JSetPara_AFN04_3761_2009->group2.f12.Flag=Data[0];
		JSetPara_AFN04_3761_2009->group2.f12.Attr=Data[1];
		SetDaDt(P, F);
		SendBuff[SendIndex++] = 0;
//		Jproginfo->Para.ChangedJiZhongQiInfo = 2;//���漯��������
		Jproginfo->FileSaveFlag.g2flag = 1;
		return 2;
	}
	if (Set == 0)//��ȡ�����ϱ���վ
	{
		SetDaDt(P, F);
		SendBuff[SendIndex]=JSetPara_AFN04_3761_2009->group2.f12.Flag;
		SendIndex = SendIndex + 1;
		SendBuff[SendIndex]=JSetPara_AFN04_3761_2009->group2.f12.Attr;
		SendIndex = SendIndex + 1;
		return 4;
	}
	return 1;
}
//�ն˵�ѹ����ģ�������ò���
INT16U SetPara_F13_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	int num=0,i,port,iNum, Index[ZhiliuInputMax];
	if (Set == 1)//��վ��������
	{
		num=Data[0];
		for(i=0;i<num;i++)
		{
			port=Data[1+i*3];
			memcpy(&JSetPara_AFN04_3761_2009->group2.f13.VI[port-1].CeLiangNo, &Data[2+i*3], 2);
		}
		SetDaDt(P, F);
		SendBuff[SendIndex++] = 1;//ERR=0,ȷ��
		Jproginfo->FileSaveFlag.g2flag = 1;
		return 1+5*num;
	}
	else
	{
		SetDaDt(P, F);
		memcpy(&SendBuff[SendIndex++], Data, 1);
		iNum = Data[0];//���β�ѯ����n
		for (i = 0; i < iNum; i++) {
			Index[i] = Data[1 + i];//��Ų�ѯ�Ķ������
		}
		for (i = 0; i < iNum; i++) {
			SendBuff[SendIndex++]=Index[i];

			memcpy(&SendBuff[SendIndex++],
					&JSetPara_AFN04_3761_2009->group2.f13.VI[Index[i] - 1].CeLiangNo, 1);
			memcpy(&SendBuff[SendIndex++],
					&JSetPara_AFN04_3761_2009->group2.f13.VI[Index[i] - 1].Stat, 1);
		}
		return 4 + iNum + 1;
	}
	return num;
}

INT16U SetPara_F14_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//�ն�����ͨ�Ź�����ʽ����̫ר��������ר����
{
	INT8U i, j, iNum, jNum, gIndex, Index[GroupMax]; //iNum-�����ܼ�����������;jNum-�ܼ���Ĳ���������
	//gIndex-�ܼ������;Index[GroupMax]-��Ų�ѯ�Ķ������
	INT16U rNum;//�ѽ����ı��ĳ���
	if (Set == 1)//��վ��������
	{
		iNum = Data[0];
		rNum = 1;
		for (i = 0; i < iNum; i++) {
			gIndex = Data[rNum];
			memcpy(&JSetPara_AFN04_3761_2009->group2.f14.Group[gIndex - 1].GroupIndex, Data + rNum,
					1);//�ܼ������
			rNum++;
			jNum = Data[rNum];
			memcpy(&JSetPara_AFN04_3761_2009->group2.f14.Group[gIndex - 1].PointNum, Data + rNum, 1);//�ܼ���Ĳ���������
			rNum++;
			for (j = 0; j < jNum; j++) {
				memcpy(&JSetPara_AFN04_3761_2009->group2.f14.Group[gIndex - 1].Index_Flag[j], Data
						+ rNum, 1);//������ż��ܼӱ�־
				rNum++;
			}
		}
		SetDaDt(P, F);
		SendBuff[SendIndex++] = 0;
//		Jproginfo->Para.ChangedJiZhongQiInfo = 2;//���漯��������
		Jproginfo->FileSaveFlag.g2flag = 1;
		return rNum;
	}
	if (Set == 0)//��ȡ�����ϱ���վ
	{
		SetDaDt(P, F);
		memcpy(&SendBuff[SendIndex++], Data, 1);//�����ܼ�����������n
		iNum = Data[0];//���β�ѯ����n
		for (i = 0; i < iNum; i++) {
			Index[i] = Data[1 + i];//��Ų�ѯ�Ķ������
		}
		for (i = 0; i < iNum; i++) {
			memcpy(&SendBuff[SendIndex++],
					&JSetPara_AFN04_3761_2009->group2.f14.Group[Index[i] - 1].GroupIndex, 1);//�ܼ������
			memcpy(&SendBuff[SendIndex++],
					&JSetPara_AFN04_3761_2009->group2.f14.Group[Index[i] - 1].PointNum, 1);//�ܼ���Ĳ���������
			jNum = JSetPara_AFN04_3761_2009->group2.f14.Group[i].PointNum;
			for (j = 0; j < jNum; j++) {
				memcpy(&SendBuff[SendIndex++], &JSetPara_AFN04_3761_2009->group2.f14.Group[Index[i]
						- 1].Index_Flag[j], 1);//������ż��ܼӱ�־
			}
		}
		return 4 + iNum + 1;
	}
	return 1;
}

INT16U SetPara_F15_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//�й��ܵ������Խ��
{
	INT8U i, iNum,  gIndex, Index[GroupMax]; //iNum-������������
	//gIndex-�ܼ������;Index[GroupMax]-��Ų�ѯ�Ķ������
	INT16U rNum;//�ѽ����ı��ĳ���
	if (Set == 1)//��վ��������
	{
		iNum = Data[0];
		rNum = 1;
		for (i = 0; i < iNum; i++) {
			gIndex = Data[rNum];
			memcpy(&JSetPara_AFN04_3761_2009->group2.f15.Group[gIndex - 1].GroupIndex, Data + rNum,1);//����
			rNum++;
			memcpy(&JSetPara_AFN04_3761_2009->group2.f15.Group[gIndex - 1].CmpGrpNo, Data + rNum, 1);//�Ա��ܼ������
			rNum++;
			memcpy(&JSetPara_AFN04_3761_2009->group2.f15.Group[gIndex - 1].CanGrpNo, Data + rNum, 1);//�����ܼ������
			rNum++;
			memcpy(&JSetPara_AFN04_3761_2009->group2.f15.Group[gIndex - 1].Flag, Data + rNum, 1);//�Աȷ�����־
			rNum++;
			memcpy(&JSetPara_AFN04_3761_2009->group2.f15.Group[gIndex - 1].XdVal, Data + rNum, 1);//���ƫ��ֵ
			rNum++;
			memcpy(&JSetPara_AFN04_3761_2009->group2.f15.Group[gIndex - 1].JdVal[0], Data + rNum, 4);//����Խ��ƫ��ֵ
			rNum+=4;
		}
		SetDaDt(P, F);
		SendBuff[SendIndex++] = 0;
//		Jproginfo->Para.ChangedJiZhongQiInfo = 2;//���漯��������
		Jproginfo->FileSaveFlag.g2flag = 1;
		return rNum;
	}
	if (Set == 0)//��ȡ�����ϱ���վ
	{
		SetDaDt(P, F);
		memcpy(&SendBuff[SendIndex++], Data, 1);//������������n
		iNum = Data[0];//���β�ѯ����n
		for (i = 0; i < iNum; i++) {
			Index[i] = Data[1 + i];//��Ų�ѯ�Ķ������
		}
		for (i = 0; i < iNum; i++) {
			memcpy(&SendBuff[SendIndex++],&JSetPara_AFN04_3761_2009->group2.f15.Group[Index[i] - 1].GroupIndex, 1);//����
			memcpy(&SendBuff[SendIndex++],&JSetPara_AFN04_3761_2009->group2.f15.Group[Index[i] - 1].CmpGrpNo, 1);//�Ա��ܼ������
			memcpy(&SendBuff[SendIndex++],&JSetPara_AFN04_3761_2009->group2.f15.Group[Index[i] - 1].CanGrpNo, 1);//�����ܼ������
			memcpy(&SendBuff[SendIndex++],&JSetPara_AFN04_3761_2009->group2.f15.Group[Index[i] - 1].Flag, 1);//�Աȷ�����־
			memcpy(&SendBuff[SendIndex++],&JSetPara_AFN04_3761_2009->group2.f15.Group[Index[i] - 1].XdVal, 1);//���ƫ��ֵ
			memcpy(&SendBuff[SendIndex],&JSetPara_AFN04_3761_2009->group2.f15.Group[Index[i] - 1].JdVal[0], 4);//���ƫ��ֵ
			SendIndex+=4;
		}
		return 4 + iNum + 1;
	}
	return 1;
}

INT16U SetPara_F16_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//����ר���û���������
{
	if (Set == 1)//��վ��������
	{
		memcpy(&JSetPara_AFN04_3761_2009->group2.f16.UserName[0], Data, 32);
		memcpy(&JSetPara_AFN04_3761_2009->group2.f16.PassWord[0], Data + 32, 32);
		SetDaDt(P, F);
		SendBuff[SendIndex++] = 0;
//		Jproginfo->Para.ChangedJiZhongQiInfo = 2;//���漯��������
		Jproginfo->FileSaveFlag.g2flag = 1;
		return 64;
	}
	if (Set == 0)//��ȡ�����ϱ���վ
	{
		SetDaDt(P, F);
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group2.f16.UserName[0], 32);
		SendIndex = SendIndex + 32;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group2.f16.PassWord[0], 32);
		SendIndex = SendIndex + 32;
		return 4;
	}
	return 1;
}

INT16U SetPara_F17_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	int num=4;
	if (Set == 1)//��վ��������
	{
		num=64;

		SetDaDt(P, F);//AFN=00H,Fn=F3ʱ�����ݵ�Ԫ�е����ݵ�Ԫ��ʶ
		SendBuff[SendIndex++] = 1;//ERR=0,ȷ��
		Jproginfo->FileSaveFlag.g3flag = 1;
		return num;
	}
	return num;
}

INT16U SetPara_F18_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	int num=4;
	if (Set == 1)//��վ��������
	{
		num=12;

		SetDaDt(P, F);//AFN=00H,Fn=F3ʱ�����ݵ�Ԫ�е����ݵ�Ԫ��ʶ
		SendBuff[SendIndex++] = 1;//ERR=0,ȷ��
		Jproginfo->FileSaveFlag.g3flag = 1;
		return num;
	}
	return num;
}

INT16U SetPara_F19_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	int num=4;
	if (Set == 1)//��վ��������
	{
		num=1;

		SetDaDt(P, F);//AFN=00H,Fn=F3ʱ�����ݵ�Ԫ�е����ݵ�Ԫ��ʶ
		SendBuff[SendIndex++] = 1;//ERR=0,ȷ��
		Jproginfo->FileSaveFlag.g3flag = 1;
		return num;
	}
	return num;
}

INT16U SetPara_F20_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	int num=4;
	if (Set == 1)//��վ��������
	{
		num=1;

		SetDaDt(P, F);//AFN=00H,Fn=F3ʱ�����ݵ�Ԫ�е����ݵ�Ԫ��ʶ
		SendBuff[SendIndex++] = 1;//ERR=0,ȷ��
		Jproginfo->FileSaveFlag.g3flag = 1;
		return num;
	}
	return num;
}

INT16U SetPara_F21_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	int num=4;
	if (Set == 1)//��վ��������
	{
		num=49;
		memcpy(&JSetPara_AFN04_3761_2009->group3.f21.FLTime[0], Data, 49);
		SetDaDt(P, F);//AFN=00H,Fn=F3ʱ�����ݵ�Ԫ�е����ݵ�Ԫ��ʶ
		SendBuff[SendIndex++] = 1;//ERR=0,ȷ��
		Jproginfo->FileSaveFlag.g3flag = 1;
		return num;
	}
	if (Set == 0)//��ȡ�����ϱ���վ
	{
		SetDaDt(P, F);
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group3.f21.FLTime[0], 49);
		SendIndex = SendIndex + 49;
		return 4;
	}
	return num;
}

INT16U SetPara_F22_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	int num=4;
	if (Set == 1)//��վ��������
	{
		num=Data[0];
		JSetPara_AFN04_3761_2009->group3.f22.FLNum=num;
		memcpy(&JSetPara_AFN04_3761_2009->group3.f22.Feilv[0][0], &Data[1], num*4);
		SetDaDt(P, F);//AFN=00H,Fn=F3ʱ�����ݵ�Ԫ�е����ݵ�Ԫ��ʶ
		SendBuff[SendIndex++] = 1;//ERR=0,ȷ��
		Jproginfo->FileSaveFlag.g3flag = 1;
		return 1+4*num;
	}
	if (Set == 0)//��ȡ�����ϱ���վ
	{
		SetDaDt(P, F);
		memcpy(&SendBuff[SendIndex++], &JSetPara_AFN04_3761_2009->group3.f22.FLNum, 1);
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group3.f22.Feilv[0][0], JSetPara_AFN04_3761_2009->group3.f22.FLNum*4);
		SendIndex = SendIndex + JSetPara_AFN04_3761_2009->group3.f22.FLNum*4;
		return 4;
	}
	return num;
}

INT16U SetPara_F23_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//�ն˴߷Ѹ澯����
{
	if (Set == 1)//��վ��������
	{
		memcpy(&JSetPara_AFN04_3761_2009->group3.f23.Allow[0], Data, 3);
		SetDaDt(P, F);
		SendBuff[SendIndex++] = 0;
//		Jproginfo->Para.ChangedJiZhongQiInfo = 2;//���漯��������
		Jproginfo->FileSaveFlag.g3flag = 1;
		return 3;
	}
	if (Set == 0)//��ȡ�����ϱ���վ
	{
		SetDaDt(P, F);
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group3.f23.Allow[0], 3);
		SendIndex = SendIndex + 3;
		return 4;
	}
	return 1;
}

INT16U SetPara_F25_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//�ն˴߷Ѹ澯����
{
	INT8U type;
	INT16U Pn;
	Pn = P;
	if (P >= PointMax) {
		SdPrintf(YNPrint,PreFix,"\n\r----PointMax > %d-------\n\r",PointMax);
		Pn = PointMax;
	}
	if (Set == 1)//��վ��������
	{
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f25.V_BeiLv[0], Data, 2);//��ѹ����������
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f25.I_BeiLv[0], Data + 2, 2);//��������������
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f25.E_Ding_V[0], Data + 4, 2);//���ѹ
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f25.Max_I, Data + 6, 1);//������
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f25.Max_Burthen[0], Data + 7, 3);//�����
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f25.DYType, Data + 10, 1);//��Դ���߷�ʽ
		type = Data[10] & 0x03;//SD������
//
		SetDaDt(P, F);
		SendBuff[SendIndex++] = 0;
//		Jproginfo->Para.ChangedPointInfo = Pn;//���漯��������
		Jproginfo->FileSaveFlag.g4flag = 1;
		return 11;
	}
	if (Set == 0)//��ȡ�����ϱ���վ
	{
		SetDaDt(P, F);
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->Point[Pn - 1].f25.V_BeiLv[0], 2);//��ѹ����������
		SendIndex += 2;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->Point[Pn - 1].f25.I_BeiLv[0], 2);//��������������
		SendIndex += 2;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->Point[Pn - 1].f25.E_Ding_V[0],
				2);//���ѹ
		SendIndex += 2;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->Point[Pn - 1].f25.Max_I, 1);//������
		SendIndex += 1;
		memcpy(&SendBuff[SendIndex],
				&JSetPara_AFN04_3761_2009->Point[Pn - 1].f25.Max_Burthen[0], 3);//�����
		SendIndex += 3;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->Point[Pn - 1].f25.DYType, 1);//��Դ���߷�ʽ
		SendIndex += 1;
		return 4;
	}
	return 1;
}

INT16U SetPara_F26_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//�ն˴߷Ѹ澯����
{
	INT16U Pn;
	Pn = P;
	if (P >= PointMax) {
		SdPrintf(YNPrint,PreFix,"\n\r----PointMax > %d-------\n\r",PointMax);
		Pn = PointMax;
	}
	if (Set == 1)//��վ��������
	{

		//��ѹ�ϸ����б����
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.V_He_ge_S[0], Data, 2);//��ѹ�ϸ�����
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.V_He_ge_X[0], Data + 2, 2);//��ѹ�ϸ�����
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.V_Duan_Men[0], Data + 4, 2);//��ѹ�ϸ�����
		//��ѹ�б����
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.V_He_ge_SS[0], Data + 6, 2);//��ѹ�����ޣ���ѹ���ޣ�
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.V_He_ge_SS_Time, Data + 8, 1);//Խ�޳���ʱ��
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.V_He_ge_SS_Renew[0], Data + 9, 2);//Խ�޻ָ�ϵ��
		//Ƿѹ�б����
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.V_He_ge_XX[0], Data + 11, 2);//��ѹ�����ޣ�Ƿѹ���ޣ�
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.V_He_ge_XX_Time, Data + 13, 1);//Խ�޳���ʱ��
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.V_He_ge_XX_Renew[0], Data + 14, 2);//Խ�޻ָ�ϵ��
		//�����б����
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.I_SS[0], Data + 16, 3);//����������ޣ��������ޣ�
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.I_SS_Time, Data + 19, 1);//Խ�޳���ʱ��
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.I_SS_Renew[0], Data + 20, 2);//Խ�޻ָ�ϵ��
		//��������б����
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.I_S[0], Data + 22, 3);//��������ޣ���������ޣ�
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.I_S_Time, Data + 25, 1);//Խ�޳���ʱ��
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.I_S_Renew[0], Data + 26, 2);//Խ�޻ָ�ϵ��
		//������������б����
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.U0I_S[0], Data + 28, 3);//�����������
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.U0I_S_Time, Data + 31, 1);//Խ�޳���ʱ��
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.U0I_S_Renew[0], Data + 32, 2);//Խ�޻ָ�ϵ��
		//���ڹ��ʳ��������б����
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.S_SS[0], Data + 34, 3);//���ڹ���������
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.S_SS_Time, Data + 37, 1);//Խ�޳���ʱ��
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.S_SS_Renew[0], Data + 38, 2);//Խ�޻ָ�ϵ��
		//���ڹ��ʳ������б����
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.S_S[0], Data + 40, 3);//���ڹ�������
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.S_S_Time, Data + 43, 1);//Խ�޳���ʱ��
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.S_S_Renew[0], Data + 44, 2);//Խ�޻ָ�ϵ��
		//�����ѹ��ƽ�ⳬ���б����
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.U3_Unbalance_Value[0], Data + 46, 2);//�����ѹ��ƽ����ֵ
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.U3_Unbalance_Time, Data + 48, 1);//Խ�޳���ʱ��
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.U3_Unbalance_Renew[0], Data + 49, 2);//Խ�޻ָ�ϵ��
		//���������ƽ�ⳬ���б����
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.I3_Unbalance_Value[0], Data + 51, 2);//���������ƽ����ֵ
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.I3_Unbalance_Time, Data + 53, 1);//Խ�޳���ʱ��
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.I3_Unbalance_Renew[0], Data + 54, 2);//Խ�޻ָ�ϵ��
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.LianXu_ShiYa, Data + 56, 1);//����ʧѹʱ����ֵ

		SetDaDt(P, F);
		SendBuff[SendIndex++] = 0;
		Jproginfo->Para.ChangedPointInfo = Pn;//���漯��������
		Jproginfo->FileSaveFlag.g4flag = 1;
		return 57;
	}
	if (Set == 0)//��ȡ�����ϱ���վ
	{
		SetDaDt(P, F);
		//��ѹ�ϸ����б����
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.V_He_ge_S[0],
				2);//��ѹ�ϸ�����
		SendIndex += 2;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.V_He_ge_X[0],
				2);//��ѹ�ϸ�����
		SendIndex += 2;
		memcpy(&SendBuff[SendIndex],
				&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.V_Duan_Men[0], 2);//��ѹ�ϸ�����
		SendIndex += 2;
		//��ѹ�б����
		memcpy(&SendBuff[SendIndex],
				&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.V_He_ge_SS[0], 2);//��ѹ�����ޣ���ѹ���ޣ�
		SendIndex += 2;
		memcpy(&SendBuff[SendIndex],
				&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.V_He_ge_SS_Time, 1);//Խ�޳���ʱ��
		SendIndex += 1;
		memcpy(&SendBuff[SendIndex],
				&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.V_He_ge_SS_Renew[0], 2);//Խ�޻ָ�ϵ��
		SendIndex += 2;
		//Ƿѹ�б����
		memcpy(&SendBuff[SendIndex],
				&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.V_He_ge_XX[0], 2);//��ѹ�����ޣ�Ƿѹ���ޣ�
		SendIndex += 2;
		memcpy(&SendBuff[SendIndex],
				&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.V_He_ge_XX_Time, 1);//Խ�޳���ʱ��
		SendIndex += 1;
		memcpy(&SendBuff[SendIndex],
				&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.V_He_ge_XX_Renew[0], 2);//Խ�޻ָ�ϵ��
		SendIndex += 2;
		//�����б����
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.I_SS[0], 3);//����������ޣ��������ޣ�
		SendIndex += 3;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.I_SS_Time, 1);//Խ�޳���ʱ��
		SendIndex += 1;
		memcpy(&SendBuff[SendIndex],
				&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.I_SS_Renew[0], 2);//Խ�޻ָ�ϵ��
		SendIndex += 2;
		//��������б����
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.I_S[0], 3);//��������ޣ���������ޣ�
		SendIndex += 3;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.I_S_Time, 1);//Խ�޳���ʱ��
		SendIndex += 1;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.I_S_Renew[0],
				2);//Խ�޻ָ�ϵ��
		SendIndex += 2;
		//������������б����
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.U0I_S[0], 3);//�����������
		SendIndex += 3;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.U0I_S_Time, 1);//Խ�޳���ʱ��
		SendIndex += 1;
		memcpy(&SendBuff[SendIndex],
				&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.U0I_S_Renew[0], 2);//Խ�޻ָ�ϵ��
		SendIndex += 2;
		//���ڹ��ʳ��������б����
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.S_SS[0], 3);//���ڹ���������
		SendIndex += 3;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.S_SS_Time, 1);//Խ�޳���ʱ��
		SendIndex += 1;
		memcpy(&SendBuff[SendIndex],
				&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.S_SS_Renew[0], 2);//Խ�޻ָ�ϵ��
		SendIndex += 2;
		//���ڹ��ʳ������б����
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.S_S[0], 3);//���ڹ�������
		SendIndex += 3;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.S_S_Time, 1);//Խ�޳���ʱ��
		SendIndex += 1;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.S_S_Renew[0],
				2);//Խ�޻ָ�ϵ��
		SendIndex += 2;
		//�����ѹ��ƽ�ⳬ���б����
		memcpy(&SendBuff[SendIndex],
				&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.U3_Unbalance_Value[0], 2);//�����ѹ��ƽ����ֵ
		SendIndex += 2;
		memcpy(&SendBuff[SendIndex],
				&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.U3_Unbalance_Time, 1);//Խ�޳���ʱ��
		SendIndex += 1;
		memcpy(&SendBuff[SendIndex],
				&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.U3_Unbalance_Renew[0], 2);//Խ�޻ָ�ϵ��
		SendIndex += 2;
		//���������ƽ�ⳬ���б����
		memcpy(&SendBuff[SendIndex],
				&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.I3_Unbalance_Value[0], 2);//���������ƽ����ֵ
		SendIndex += 2;
		memcpy(&SendBuff[SendIndex],
				&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.I3_Unbalance_Time, 1);//Խ�޳���ʱ��
		SendIndex += 1;
		memcpy(&SendBuff[SendIndex],
				&JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.I3_Unbalance_Renew[0], 2);//Խ�޻ָ�ϵ��
		SendIndex += 2;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->Point[Pn - 1].f26.LianXu_ShiYa,
				1);//����ʧѹʱ����ֵ
		SendIndex += 1;
		return 4;
	}
	return 1;
}

INT16U SetPara_F27_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//�ն˴߷Ѹ澯����
{
	INT16U Pn;
	Pn = P;
	if (P >= PointMax) {
		SdPrintf(YNPrint,PreFix,"\n\r----PointMax > %d-------\n\r",PointMax);
		Pn = PointMax;
	}
	if (Set == 1)//��վ��������
	{
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f27.RA[0], Data, 2);
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f27.XA[0], Data + 2, 2);
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f27.GA[0], Data + 4, 2);
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f27.BA[0], Data + 6, 2);
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f27.RB[0], Data + 8, 2);
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f27.XB[0], Data + 10, 2);
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f27.GB[0], Data + 12, 2);
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f27.BB[0], Data + 14, 2);
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f27.RC[0], Data + 16, 2);
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f27.XC[0], Data + 18, 2);
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f27.GC[0], Data + 20, 2);
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f27.BC[0], Data + 22, 2);
		SetDaDt(P, F);
		SendBuff[SendIndex++] = 0;
		Jproginfo->Para.ChangedPointInfo = Pn;//���漯��������
		Jproginfo->FileSaveFlag.g4flag = 1;
		return 24;
	}
	if (Set == 0)//��ȡ�����ϱ���վ
	{
		SetDaDt(P, F);
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->Point[Pn - 1].f27.RA[0], 2);
		SendIndex += 2;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->Point[Pn - 1].f27.XA[0], 2);
		SendIndex += 2;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->Point[Pn - 1].f27.GA[0], 2);
		SendIndex += 2;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->Point[Pn - 1].f27.BA[0], 2);
		SendIndex += 2;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->Point[Pn - 1].f27.RB[0], 2);
		SendIndex += 2;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->Point[Pn - 1].f27.XB[0], 2);
		SendIndex += 2;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->Point[Pn - 1].f27.GB[0], 2);
		SendIndex += 2;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->Point[Pn - 1].f27.BB[0], 2);
		SendIndex += 2;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->Point[Pn - 1].f27.RC[0], 2);
		SendIndex += 2;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->Point[Pn - 1].f27.XC[0], 2);
		SendIndex += 2;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->Point[Pn - 1].f27.GC[0], 2);
		SendIndex += 2;
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->Point[Pn - 1].f27.BC[0], 2);
		SendIndex += 2;
		return 4;
	}
	return 1;
}

INT16U SetPara_F28_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//�ն˴߷Ѹ澯����
{
	INT16U Pn;
	Pn = P;
	if (P >= PointMax) {
		SdPrintf(YNPrint,PreFix,"\n\r----PointMax > %d-------\n\r",PointMax);
		Pn = PointMax - 1;
	}
	if (Set == 1)//��վ��������
	{
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f28.CosFenDuan_Xian1[0], Data, 2);
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f28.CosFenDuan_Xian2[0], Data + 2, 2);
		SetDaDt(P, F);
		SendBuff[SendIndex++] = 0;
		Jproginfo->Para.ChangedPointInfo = Pn;//���漯��������
		Jproginfo->FileSaveFlag.g4flag = 1;
		return 4;
	}
	if (Set == 0)//��ȡ�����ϱ���վ
	{
		SetDaDt(P, F);
		memcpy(&SendBuff[SendIndex],
				&JSetPara_AFN04_3761_2009->Point[Pn - 1].f28.CosFenDuan_Xian1[0], 2);
		SendIndex += 2;
		memcpy(&SendBuff[SendIndex],
				&JSetPara_AFN04_3761_2009->Point[Pn - 1].f28.CosFenDuan_Xian2[0], 2);
		SendIndex += 2;
		return 4;
	}
	return 1;
}

INT16U SetPara_F29_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//�ն˴߷Ѹ澯����
{
	INT16U Pn;
	Pn = P;
	if (P >= PointMax) {
		SdPrintf(YNPrint,PreFix,"\n\r----PointMax > %d-------\n\r",PointMax);
		Pn = PointMax;
	}
	if (Set == 1)//��վ��������
	{
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f29.Address_Show[0], Data, 12);
		SetDaDt(P, F);
		SendBuff[SendIndex++] = 0;
		Jproginfo->Para.ChangedPointInfo = Pn;//���漯��������
		Jproginfo->FileSaveFlag.g4flag = 1;
		return 12;
	}
	if (Set == 0)//��ȡ�����ϱ���վ
	{
		SetDaDt(P, F);
		memcpy(&SendBuff[SendIndex],
				&JSetPara_AFN04_3761_2009->Point[Pn - 1].f29.Address_Show[0], 12);
		SendIndex += 12;
		return 4;
	}
	return 1;
}

INT16U SetPara_F30_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)
{
	INT16U Pn;
	Pn = P;
	if (P >= PointMax) {
		SdPrintf(YNPrint,PreFix,"\n\r----PointMax > %d-------\n\r",PointMax);
		Pn = PointMax;
	}
	if (Set == 1)//��վ��������
	{
		memcpy(&JSetPara_AFN04_3761_2009->Point[Pn - 1].f30.IsRun, Data, 1);
		SetDaDt(P, F);
		SendBuff[SendIndex++] = 0;
		Jproginfo->Para.ChangedPointInfo = Pn;//���漯��������
		Jproginfo->FileSaveFlag.g4flag = 1;
		return 1;
	}
	if (Set == 0)//��ȡ�����ϱ���վ
	{
		SetDaDt(P, F);
		memcpy(&SendBuff[SendIndex++], &JSetPara_AFN04_3761_2009->Point[Pn - 1].f30.IsRun, 1);
		return 4;
	}
	return 1;
}

INT16U SetPara_F31_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//�ն�����ͨ�ſ������м�ת������
{
	INT8U i, Num;
	if (Set == 1)//��վ��������
	{
		memset(&JSetPara_AFN04_3761_2009->Point[0].f31.AddrNum, 0, sizeof(JSetPara_AFN04_3761_2009->Point[0].f31));//��ʼ��
		memcpy(&JSetPara_AFN04_3761_2009->Point[0].f31.AddrNum, Data, 1);
		Num = Data[0];
		for (i = 0; i < Num; i++) {
			memcpy(&JSetPara_AFN04_3761_2009->Point[0].f31.Addr[i][0], Data + 1 + i * 6, 6);
		}
		SetDaDt(P, F);
		SendBuff[SendIndex++] = 0;
		Jproginfo->Para.ChangedJiZhongQiInfo = 2;//���漯��������
		Jproginfo->FileSaveFlag.g4flag = 1;
		return 1 + 6* Num ;
	}
	if (Set == 0)//��ȡ�����ϱ���վ
	{
		SetDaDt(P, F);
		memcpy(&SendBuff[SendIndex++], &JSetPara_AFN04_3761_2009->Point[0].f31.AddrNum, 1);
		Num = JSetPara_AFN04_3761_2009->Point[0].f31.AddrNum;
		for (i = 0; i < Num; i++) {
			memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->Point[0].f31.Addr[i][0], 6);
			SendIndex = SendIndex + 6;
		}
		return 4;
	}
	return 1;
}

INT16U SetPara_F33_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//�ն˳������в���//10.13
{
	INT8U iNum, jNum, i, j, port;//iNum-�������õĲ��������;jNum-����������ʱ����;port-���ն�ͨ�Ŷ˿ں�
	INT16U rNum, Index[CommPortMax];//rNum-�ѽ����ı��ĳ���;Index[CommPortMax]-��Ų�ѯ�Ķ������
	if (Set == 1)//��վ��������
	{
		JSetPara_AFN04_3761_2009->group5.f33.Count = Data[0];
		iNum = Data[0];
		rNum = 1;
		for (i = 0; i < iNum; i++) {
			port = Data[rNum];//�õ����ն�ͨ�Ŷ˿ںţ�������Ӧ�Ĳ�����
			memcpy(&JSetPara_AFN04_3761_2009->group5.f33.f33[port - 1].port, Data + rNum, 1);//ͨ�Ŷ˿ں�
			memcpy(&JSetPara_AFN04_3761_2009->group5.f33.f33[i].port, Data + rNum, 1);//ͨ�Ŷ˿ں�
			rNum++;
			memcpy(&JSetPara_AFN04_3761_2009->group5.f33.f33[port - 1].CtrlZ[0], Data + rNum, 2);//̨�����г������п�����
			memcpy(&JSetPara_AFN04_3761_2009->group5.f33.f33[i].CtrlZ[0], Data + rNum, 2);//̨�����г������п�����
			rNum += 2;
			memcpy(&JSetPara_AFN04_3761_2009->group5.f33.f33[port - 1].CbDate[0], Data + rNum, 4);//����������
			memcpy(&JSetPara_AFN04_3761_2009->group5.f33.f33[i].CbDate[0], Data + rNum, 4);//����������
			rNum += 4;
			memcpy(&JSetPara_AFN04_3761_2009->group5.f33.f33[port - 1].CbTime[0], Data + rNum, 2);//������ʱ��
			memcpy(&JSetPara_AFN04_3761_2009->group5.f33.f33[i].CbTime[0], Data + rNum, 2);//������ʱ��
			rNum += 2;
			memcpy(&JSetPara_AFN04_3761_2009->group5.f33.f33[port - 1].CbInter, Data + rNum, 1);//�������ʱ��
			memcpy(&JSetPara_AFN04_3761_2009->group5.f33.f33[i].CbInter, Data + rNum, 1);//�������ʱ��
			rNum += 1;
			memcpy(&JSetPara_AFN04_3761_2009->group5.f33.f33[port - 1].XbTime[0], Data + rNum, 3);//�Ե���㲥Уʱ��ʱʱ��
			memcpy(&JSetPara_AFN04_3761_2009->group5.f33.f33[i].XbTime[0], Data + rNum, 3);//�Ե���㲥Уʱ��ʱʱ��
			rNum += 3;
			memcpy(&JSetPara_AFN04_3761_2009->group5.f33.f33[port - 1].TimeCnt, Data + rNum, 1);//��������ʱ����
			memcpy(&JSetPara_AFN04_3761_2009->group5.f33.f33[i].TimeCnt, Data + rNum, 1);//��������ʱ����
			rNum += 1;
			jNum = JSetPara_AFN04_3761_2009->group5.f33.f33[port - 1].TimeCnt;
			jNum = JSetPara_AFN04_3761_2009->group5.f33.f33[i].TimeCnt;
			for (j = 0; j < jNum; j++) {
				memcpy(&JSetPara_AFN04_3761_2009->group5.f33.f33[port - 1].StTime[j][0], Data + rNum, 2);//����ʱ�ο�ʼʱ��
				memcpy(&JSetPara_AFN04_3761_2009->group5.f33.f33[i].StTime[j][0], Data + rNum, 2);//����ʱ�ο�ʼʱ��
				rNum += 2;
				memcpy(&JSetPara_AFN04_3761_2009->group5.f33.f33[port - 1].EdTime[j][0], Data + rNum, 2);//����ʱ�ν���ʱ��
				memcpy(&JSetPara_AFN04_3761_2009->group5.f33.f33[i].EdTime[j][0], Data + rNum, 2);//����ʱ�ν���ʱ��
				rNum += 2;
			}
		}
		SetDaDt(P, F);
		SendBuff[SendIndex++] = 0;
		Jproginfo->Para.ChangedJiZhongQiInfo = 2;//���漯��������
		Jproginfo->FileSaveFlag.g5flag = 1;
		return rNum;
	}
	if (Set == 0)//��ȡ�����ϱ���վ
	{
		SetDaDt(P, F);
		memcpy(&SendBuff[SendIndex++], Data, 1);//���β�ѯ�Ĳ��������n
		iNum = Data[0];//���β�ѯ����n
		for (i = 0; i < iNum; i++) {
			Index[i] = Data[1 + i];//��Ų�ѯ�Ķ������
		}
		for (i = 0; i < iNum; i++) {
			memcpy(&SendBuff[SendIndex],
					&JSetPara_AFN04_3761_2009->group5.f33.f33[Index[i] - 1].port, 1);//ͨ�Ŷ˿ں�
			SendIndex = SendIndex + 1;
			memcpy(&SendBuff[SendIndex],
					&JSetPara_AFN04_3761_2009->group5.f33.f33[Index[i] - 1].CtrlZ[0], 2);//̨�����г������п�����
			SendIndex = SendIndex + 2;
			memcpy(&SendBuff[SendIndex],
					&JSetPara_AFN04_3761_2009->group5.f33.f33[Index[i] - 1].CbDate[0], 4);//����������
			SendIndex = SendIndex + 4;
			memcpy(&SendBuff[SendIndex],
					&JSetPara_AFN04_3761_2009->group5.f33.f33[Index[i] - 1].CbTime[0], 2);//������ʱ��
			SendIndex = SendIndex + 2;
			memcpy(&SendBuff[SendIndex],
					&JSetPara_AFN04_3761_2009->group5.f33.f33[Index[i] - 1].CbInter, 1);//�������ʱ��
			SendIndex = SendIndex + 1;
			memcpy(&SendBuff[SendIndex],
					&JSetPara_AFN04_3761_2009->group5.f33.f33[Index[i] - 1].XbTime[0], 3);//�Ե���㲥Уʱ��ʱʱ��
			SendIndex = SendIndex + 3;
			memcpy(&SendBuff[SendIndex],
					&JSetPara_AFN04_3761_2009->group5.f33.f33[Index[i] - 1].TimeCnt, 1);//��������ʱ����
			SendIndex = SendIndex + 1;
			jNum = JSetPara_AFN04_3761_2009->group5.f33.f33[Index[i] - 1].TimeCnt;
			for (j = 0; j < jNum; j++) {
				memcpy(&SendBuff[SendIndex],
						&JSetPara_AFN04_3761_2009->group5.f33.f33[Index[i] - 1].StTime[j][0], 2);//����ʱ�ο�ʼʱ��
				SendIndex = SendIndex + 2;
				memcpy(&SendBuff[SendIndex],
						&JSetPara_AFN04_3761_2009->group5.f33.f33[Index[i] - 1].EdTime[j][0], 2);//����ʱ�ν���ʱ��
				SendIndex = SendIndex + 2;
			}
		}
		return 4 + iNum + 1;
	}
	return 1;
}
INT16U SetPara_F34_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//����������ͨ��ģ��Ĳ�������
{
	INT8U i, Num, pIndex, Index[CommPortMax];//pIndex-�ն�ͨ�Ŷ˿ں�;Index[CommPortMax]-��Ų�ѯ�Ķ������
	if (Set == 1)//��վ��������
	{
		memset(&JSetPara_AFN04_3761_2009->group5.f34, 0, sizeof(JSetPara_AFN04_3761_2009->group5.f34));//��ʼ��
		Num = Data[0];
		for (i = 0; i < Num; i++) {
			pIndex = Data[1 + i * 6];
			memcpy(&JSetPara_AFN04_3761_2009->group5.f34.Module[pIndex - 1].Port1, Data + 1 + i
					* 6, 1);//�ն�ͨ�Ŷ˿ں�
			memcpy(&JSetPara_AFN04_3761_2009->group5.f34.Module[pIndex - 1].Control_Num, Data
					+ 2 + i * 6, 1);//���ն˽ӿڶ˵�ͨ�ſ�����
			memcpy(&JSetPara_AFN04_3761_2009->group5.f34.Module[pIndex - 1].BPS[0], Data + 3 + i
					* 6, 4);//���ն˽ӿڶ�Ӧ�˵�ͨ������
		}
		SetDaDt(P, F);
		SendBuff[SendIndex++] = 0;
		Jproginfo->Para.ChangedPointInfo = 1;//������������
		Jproginfo->FileSaveFlag.g5flag = 1;
		return 1 + Num * 6;
	}
	if (Set == 0)//��ȡ�����ϱ���վ
	{
		SetDaDt(P, F);
		memcpy(&SendBuff[SendIndex++], Data, 1);//�������õĲ��������n
		Num = Data[0];
		for (i = 0; i < Num; i++) {
			Index[i] = Data[1 + i];//��Ų�ѯ�Ķ������
		}
		for (i = 0; i < Num; i++) {
			memcpy(&SendBuff[SendIndex++], &JSetPara_AFN04_3761_2009->group5.f34.Module[Index[i]
					- 1].Port1, 1);//�ն�ͨ�Ŷ˿ں�
			memcpy(&SendBuff[SendIndex++], &JSetPara_AFN04_3761_2009->group5.f34.Module[Index[i]
					- 1].Control_Num, 1);//���ն˽ӿڶ˵�ͨ�ſ�����
			memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group5.f34.Module[Index[i]
					- 1].BPS[0], 4);//���ն˽ӿڶ�Ӧ�˵�ͨ������
			SendIndex = SendIndex + 4;
		}
		return 4 + Num + 1;
	}
	return 1;
}

INT16U SetPara_F35_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//�ն˴߷Ѹ澯����
{
	INT8U i, Num;
	if (Set == 1)//��վ��������
	{
		memset(&JSetPara_AFN04_3761_2009->group5.f35.Count, 0, sizeof(JSetPara_AFN04_3761_2009->group5.f35));//��ʼ��
		memcpy(&JSetPara_AFN04_3761_2009->group5.f35.Count, Data, 1);
		Num = Data[0];
		for (i = 0; i < Num; i++) {
//			memcpy(&JSetPara_AFN04_3761_2009->group5.f35.Module[i].Index[0], Data + 1 + i * 2, 2);
			JSetPara_AFN04_3761_2009->group5.f35.Index[i] = ((*(Data + 1 + i * 2)) |  ((*(Data + 2 + i * 2))<<8)); //!!!!!
		}

		SetDaDt(P, F);
		SendBuff[SendIndex++] = 0;
		Jproginfo->Para.ChangedPointInfo = 1;//���漯��������
		Jproginfo->FileSaveFlag.g5flag = 1;
		return 1 + Num * 2;
	}
	if (Set == 0)//��ȡ�����ϱ���վ
	{
		SetDaDt(P, F);
		memcpy(&SendBuff[SendIndex++], &JSetPara_AFN04_3761_2009->group5.f35.Count, 1);
		Num = JSetPara_AFN04_3761_2009->group5.f35.Count;
		for (i = 0; i < Num; i++) {
			memcpy(&SendBuff[SendIndex],&JSetPara_AFN04_3761_2009->group5.f35.Index[i], 2);
//			JSetPara_AFN04_3761_2009->group5.f35.Index[i] = ((*(Data + 1 + i * 2)) |  ((*(Data + 2 + i * 2))<<8)); //!!!!!
//			SendIndex += 2;
		}
		return 4;
	}
	return 1;
}
INT16U SetPara_F36_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//�ն�����ͨ��������������
{
	if (Set == 1)//��վ��������
	{
		memcpy(&JSetPara_AFN04_3761_2009->group5.f36.Flow[0], Data, 4);
		SetDaDt(P, F);
		SendBuff[SendIndex++] = 0;
		Jproginfo->Para.ChangedJiZhongQiInfo = 2;//���漯��������
		Jproginfo->FileSaveFlag.g5flag = 1;
		return 4;
	}
	if (Set == 0)//��ȡ�����ϱ���վ
	{
		SetDaDt(P, F);
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group5.f36.Flow[0], 4);
		SendIndex = SendIndex + 4;
		return 4;
	}
	return 1;
}

INT16U SetPara_F37_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//�ն�����ͨ��������������
{
	INT8U Num, i;//Num-���������ն�����
	if (Set == 1)//��վ��������
	{
		memset(&JSetPara_AFN04_3761_2009->group5.f37.Port, 0, sizeof(JSetPara_AFN04_3761_2009->group5.f37));//��ʼ��
		memcpy(&JSetPara_AFN04_3761_2009->group5.f37.Port, Data, 1);
		memcpy(&JSetPara_AFN04_3761_2009->group5.f37.CtrlZ, Data + 1, 1);

		memcpy(&JSetPara_AFN04_3761_2009->group5.f37.RPackTime, Data + 2, 1);
		memcpy(&JSetPara_AFN04_3761_2009->group5.f37.RByteTime, Data + 3, 1);
		memcpy(&JSetPara_AFN04_3761_2009->group5.f37.RetryCnt, Data + 4, 1);
		memcpy(&JSetPara_AFN04_3761_2009->group5.f37.Period, Data + 5, 1);
		memcpy(&JSetPara_AFN04_3761_2009->group5.f37.FlagCnt, Data + 6, 1);
		Num = Data[6] & 0x0f;
		for (i = 0; i < Num; i++) {
			memcpy(&JSetPara_AFN04_3761_2009->group5.f37.AreaCode[i][0], Data + 7 + i * 4, 2);
			memcpy(&JSetPara_AFN04_3761_2009->group5.f37.TermAddr[i][0], Data + 9 + i * 4, 2);
		}
		SetDaDt(P, F);
		SendBuff[SendIndex++] = 0;
		Jproginfo->Para.ChangedJiZhongQiInfo = 2;//���漯��������
		Jproginfo->FileSaveFlag.g5flag = 1;
		return 7 + Num * 4;
	}
	if (Set == 0)//��ȡ�����ϱ���վ
	{
		SetDaDt(P, F);
		memcpy(&SendBuff[SendIndex++], &JSetPara_AFN04_3761_2009->group5.f37.Port, 1);
		memcpy(&SendBuff[SendIndex++], &JSetPara_AFN04_3761_2009->group5.f37.CtrlZ, 1);
		memcpy(&SendBuff[SendIndex++], &JSetPara_AFN04_3761_2009->group5.f37.RPackTime, 1);
		memcpy(&SendBuff[SendIndex++], &JSetPara_AFN04_3761_2009->group5.f37.RByteTime, 1);
		memcpy(&SendBuff[SendIndex++], &JSetPara_AFN04_3761_2009->group5.f37.RetryCnt, 1);
		memcpy(&SendBuff[SendIndex++], &JSetPara_AFN04_3761_2009->group5.f37.Period, 1);
		memcpy(&SendBuff[SendIndex++], &JSetPara_AFN04_3761_2009->group5.f37.FlagCnt, 1);
		Num = JSetPara_AFN04_3761_2009->group5.f37.FlagCnt & 0x0f;
		for (i = 0; i < Num; i++) {
			memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group5.f37.AreaCode[i][0], 2);
			SendIndex = SendIndex + 2;
			memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group5.f37.TermAddr[i][0], 2);
			SendIndex = SendIndex + 2;
		}
		return 4;
	}
	return 1;
}

INT16U SetPara_F38_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)
{
	INT8U BigType,SmallType,GroupNum,InfoNum,i,j;
	INT16U ind;
	if (Set == 1)//��վ��������
	{
		BigType=Data[0];
		GroupNum=Data[1];
		ind=2;
		for(i=0;i<GroupNum;i++)
		{
			SmallType=Data[ind];
			ind++;
			InfoNum=Data[ind];
			ind++;
			JSetPara_AFN04_3761_2009->group5.f38[BigType].Group[SmallType].GrpNum=InfoNum;
			for(j=0;j<InfoNum;j++)
			{
				JSetPara_AFN04_3761_2009->group5.f38[BigType].Group[SmallType].InfoGrpFlg[j]=Data[ind];
				ind++;
			}
		}
		SetDaDt(P, F);
		SendBuff[SendIndex++] = 0;
		Jproginfo->Para.ChangedJiZhongQiInfo = 2;//���漯��������
		Jproginfo->FileSaveFlag.g5flag = 1;
		return ind;
	}
	if (Set == 0)
	{
		SetDaDt(P, F);
		BigType=Data[0];
		GroupNum=Data[1];
		SendBuff[SendIndex++] = BigType;
		SendBuff[SendIndex++] = GroupNum;
		ind=2;
		for(i=0;i<GroupNum;i++)
		{
			SmallType=Data[ind];
			ind++;
			SendBuff[SendIndex++] = SmallType;
			InfoNum = JSetPara_AFN04_3761_2009->group5.f38[BigType].Group[SmallType].GrpNum;
			printf("\n BigType=%d SmallType=%d InfoNum =%d\n",BigType,SmallType,InfoNum);
			SendBuff[SendIndex++] = InfoNum;
			for(j=0;j<InfoNum;j++)
			{
				SendBuff[SendIndex++]=JSetPara_AFN04_3761_2009->group5.f38[BigType].Group[SmallType].InfoGrpFlg[j];
			}
		}
		return 6+GroupNum;
	}
	return 1;
}

INT16U SetPara_F39_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//�ն�����ͨ��������������
{
	INT8U BigType,SmallType,GroupNum,InfoNum,i,j;
	INT16U ind;
	if (Set == 1)//��վ��������
	{
		BigType=Data[0];
		GroupNum=Data[1];
		ind=2;
		for(i=0;i<GroupNum;i++)
		{
			SmallType=Data[ind];
			ind++;
			InfoNum=Data[ind];
			ind++;
			JSetPara_AFN04_3761_2009->group5.f39[BigType].Group[SmallType].GrpNum=InfoNum;
			for(j=0;j<InfoNum;j++)
			{
				JSetPara_AFN04_3761_2009->group5.f39[BigType].Group[SmallType].InfoGrpFlg[j]=Data[ind];
				ind++;
			}
		}
		SetDaDt(P, F);
		SendBuff[SendIndex++] = 0;
		Jproginfo->Para.ChangedJiZhongQiInfo = 2;//���漯��������
		Jproginfo->FileSaveFlag.g5flag = 1;
		return ind;
	}
	if (Set == 0)
	{
		SetDaDt(P, F);
		BigType=Data[0];
		GroupNum=Data[1];
		SendBuff[SendIndex++] = BigType;
		SendBuff[SendIndex++] = GroupNum;
		ind=2;
		for(i=0;i<GroupNum;i++)
		{
			SmallType=Data[ind];
			ind++;
			SendBuff[SendIndex++] = SmallType;
			InfoNum = JSetPara_AFN04_3761_2009->group5.f39[BigType].Group[SmallType].GrpNum;
			SendBuff[SendIndex++] = InfoNum;
			for(j=0;j<InfoNum;j++)
			{
				SendBuff[SendIndex++]=JSetPara_AFN04_3761_2009->group5.f39[BigType].Group[SmallType].InfoGrpFlg[j];
			}
		}
		return 6+GroupNum;
	}
	return 1;
}
INT16U SetPara_F57_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)
{
	if (Set == 1)//��վ��������
	{
		memcpy(&JSetPara_AFN04_3761_2009->group8.f57.Flag[0], Data, 3);
		SetDaDt(P, F);
		SendBuff[SendIndex++] = 0;
		Jproginfo->Para.ChangedJiZhongQiInfo = 2;//���漯��������
		Jproginfo->FileSaveFlag.g8flag = 1;
		return 3;
	}
	if (Set == 0)//��ȡ�����ϱ���վ
	{
		SetDaDt(P, F);
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group8.f57.Flag[0], 3);
		SendIndex = SendIndex + 3;
		return 4;
	}
	return 1;
}

INT16U SetPara_F59_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���ܱ��쳣�б���ֵ�趨
{
	if (Set == 1)//��վ��������
	{
		memcpy(&JSetPara_AFN04_3761_2009->group8.f59.ChaoCha, Data, 1);
		memcpy(&JSetPara_AFN04_3761_2009->group8.f59.FeiZou, Data + 1, 1);
		memcpy(&JSetPara_AFN04_3761_2009->group8.f59.TingZou, Data + 2, 1);
		memcpy(&JSetPara_AFN04_3761_2009->group8.f59.JiaoShi, Data + 3, 1);
		SetDaDt(P, F);
		SendBuff[SendIndex++] = 0;
		Jproginfo->Para.ChangedJiZhongQiInfo = 2;//���漯��������
		Jproginfo->FileSaveFlag.g8flag = 1;
		return 4;
	}
	if (Set == 0)//��ȡ�����ϱ���վ
	{
		SetDaDt(P, F);
		memcpy(&SendBuff[SendIndex++], &JSetPara_AFN04_3761_2009->group8.f59.ChaoCha, 1);
		memcpy(&SendBuff[SendIndex++], &JSetPara_AFN04_3761_2009->group8.f59.FeiZou, 1);
		memcpy(&SendBuff[SendIndex++], &JSetPara_AFN04_3761_2009->group8.f59.TingZou, 1);
		memcpy(&SendBuff[SendIndex++], &JSetPara_AFN04_3761_2009->group8.f59.JiaoShi, 1);
		return 4;
	}
	return 1;
}

//LQQ xiebo
//INT16U SetPara_F60_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data)
//{
//	int num=4;
//	if (Set == 1)//��վ��������
//	{
//		num=80;
//
//		SetDaDt(P, F);//AFN=00H,Fn=F3ʱ�����ݵ�Ԫ�е����ݵ�Ԫ��ʶ
//		SendBuff[SendIndex++] = 1;//ERR=0,ȷ��
//		return num;
//	}
//	return num;
//}
INT16U SetPara_F60_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	INT8U i;
	if(Set==1)//��վ��������
	{
		 JSetPara_AFN04_3761_2009->group8.f60.Valid=1;
		memcpy(&JSetPara_AFN04_3761_2009->group8.f60.All_QiBian_DYaHy_S,&Data[0],6);
		for(i=2;i<20;i+=2)
		{
			memcpy(&JSetPara_AFN04_3761_2009->group8.f60.XIeBo_DYXieBoLv_S[i],&Data[6+i-2],2);
		}
		for(i=3;i<20;i+=2)
		{
			memcpy(&JSetPara_AFN04_3761_2009->group8.f60.XIeBo_DYXieBoLv_S[i],&Data[24+i-3],2);
		}
		memcpy(&JSetPara_AFN04_3761_2009->group8.f60.All_QiBian_DLiu_YX_S,&Data[42],2);
		for(i=2;i<20;i+=2)
		{
			memcpy(&JSetPara_AFN04_3761_2009->group8.f60.XIeBo_DL_YX_S[i],&Data[44+i-2],2);
		}
		for(i=3;i<20;i+=2)
		{
			memcpy(&JSetPara_AFN04_3761_2009->group8.f60.XIeBo_DL_YX_S[i],&Data[62+i-3],2);
		}
//		SaveFKSet();



//		INT8U  TempBufn[60];
//		memset(TempBufn,0,60);
//		sprintf((char*)TempBufn,"%s/xiebo.par",_PARADIR_);
//		NormalSaveFile((char*)TempBuf,(INT8U *)&JSetPara_AFN04_3761_2009->group8.f60,sizeof(JSetPara_AFN04_3761_2009->group8.f60));//xiebo
		SetDaDt(P, F);
//		CreateErr03(0,0,8,7);//xiebo   ---
//		CreateErr03(ts);
//		RtuDataAddr->SetChanged[60]=1;
		SendBuff[SendIndex++]=1;
		Jproginfo->FileSaveFlag.g8flag = 1;
		return 80;
	}
	if(Set==0)//��ȡ���ñ���
	{
		//if(RtuDataAddr->FkInput_Value.F60_Set_Para.Valid==1)
		{
			SetDaDt(P,F);
			memcpy(&SendBuff[SendIndex],&JSetPara_AFN04_3761_2009->group8.f60.All_QiBian_DYaHy_S,6);
			SendIndex=SendIndex+6;
			for(i=2;i<20;i+=2)
			{
				memcpy(&SendBuff[SendIndex],&JSetPara_AFN04_3761_2009->group8.f60.XIeBo_DYXieBoLv_S[i],2);
				SendIndex=SendIndex+2;
			}
			for(i=3;i<20;i+=2)
			{
				memcpy(&SendBuff[SendIndex],&JSetPara_AFN04_3761_2009->group8.f60.XIeBo_DYXieBoLv_S[i],2);
				SendIndex=SendIndex+2;
			}
			memcpy(&SendBuff[SendIndex],&JSetPara_AFN04_3761_2009->group8.f60.All_QiBian_DLiu_YX_S,2);
			SendIndex=SendIndex+2;
			for(i=2;i<20;i+=2)
			{
				memcpy(&SendBuff[SendIndex],&JSetPara_AFN04_3761_2009->group8.f60.XIeBo_DL_YX_S[i],2);
				SendIndex=SendIndex+2;
			}
			for(i=3;i<20;i+=2)
			{
				memcpy(&SendBuff[SendIndex],&JSetPara_AFN04_3761_2009->group8.f60.XIeBo_DL_YX_S[i],2);
				SendIndex=SendIndex+2;
			}
		}
		return 4;
	}
	return 1;
}

INT16U SetPara_F61_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	int num=4;
	if (Set == 1)//��վ��������
	{
		num=1;

		SetDaDt(P, F);//AFN=00H,Fn=F3ʱ�����ݵ�Ԫ�е����ݵ�Ԫ��ʶ
		SendBuff[SendIndex++] = 1;//ERR=0,ȷ��
		return num;
	}
	return num;
}


INT16U SetPara_F73_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	int num=4;
	if (Set == 1)//��վ��������
	{
		num=16*3;

		SetDaDt(P, F);//AFN=00H,Fn=F3ʱ�����ݵ�Ԫ�е����ݵ�Ԫ��ʶ
		SendBuff[SendIndex++] = 1;//ERR=0,ȷ��
		return num;
	}
	return num;
}


INT16U SetPara_F74_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	int num=4;
	if (Set == 1)//��վ��������
	{
		num=10;

		SetDaDt(P, F);//AFN=00H,Fn=F3ʱ�����ݵ�Ԫ�е����ݵ�Ԫ��ʶ
		SendBuff[SendIndex++] = 1;//ERR=0,ȷ��
		return num;
	}
	return num;
}


INT16U SetPara_F75_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	int num=4;
	if (Set == 1)//��վ��������
	{
		num=16;

		SetDaDt(P, F);//AFN=00H,Fn=F3ʱ�����ݵ�Ԫ�е����ݵ�Ԫ��ʶ
		SendBuff[SendIndex++] = 1;//ERR=0,ȷ��
		return num;
	}
	return num;
}

INT16U SetPara_F76_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	int num=4;
	if (Set == 1)//��վ��������
	{
		num=1;

		SetDaDt(P, F);//AFN=00H,Fn=F3ʱ�����ݵ�Ԫ�е����ݵ�Ԫ��ʶ
		SendBuff[SendIndex++] = 1;//ERR=0,ȷ��
		return num;
	}
	return num;
}

INT16U SetPara_F81_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	int num=4;
	if (Set == 1)//��վ��������
	{
		num=4;

		SetDaDt(P, F);//AFN=00H,Fn=F3ʱ�����ݵ�Ԫ�е����ݵ�Ԫ��ʶ
		SendBuff[SendIndex++] = 1;//ERR=0,ȷ��
		return num;
	}
	return num;
}

INT16U SetPara_F82_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	int num=4;
	if (Set == 1)//��վ��������
	{
		num=4;

		SetDaDt(P, F);//AFN=00H,Fn=F3ʱ�����ݵ�Ԫ�е����ݵ�Ԫ��ʶ
		SendBuff[SendIndex++] = 1;//ERR=0,ȷ��
		return num;
	}
	return num;
}

INT16U SetPara_F83_Set(INT8U Set,INT16U F,INT16U P,INT8U *Data)
{
	int num=4;
	if (Set == 1)//��վ��������
	{
		num=1;

		SetDaDt(P, F);//AFN=00H,Fn=F3ʱ�����ݵ�Ԫ�е����ݵ�Ԫ��ʶ
		SendBuff[SendIndex++] = 1;//ERR=0,ȷ��
		return num;
	}
	return num;
}
INT16U SetPara_F65_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ʱ�ϱ�1��������������
{
	INT16U i, k = 0, Num;
	INT16U Pn;
//	INT8U TempBufn[60];
	Pn = P;
	if (Set == 1)//��վ��������
	{
		if (P > Task1_Max) {
			goto e;
		}
		Jproginfo->stateflags.F65_Changed= 1;
		memset(&JSetPara_AFN04_3761_2009->group9.f65[Pn - 1].Interval, 0,
				sizeof(JSetPara_AFN04_3761_2009->group9.f65[Pn - 1]));//��ʼ��
		memcpy(&JSetPara_AFN04_3761_2009->group9.f65[Pn - 1].Interval, Data, 1);
		memcpy(&JSetPara_AFN04_3761_2009->group9.f65[Pn - 1].Post_Time[0], Data + 1, 6);
		memcpy(&JSetPara_AFN04_3761_2009->group9.f65[Pn - 1].R, Data + 7, 1);
		memcpy(&JSetPara_AFN04_3761_2009->group9.f65[Pn - 1].Count, Data + 8, 1);
		Jproginfo->task1_Delay_Count[Pn - 1]=0;
		Num = Data[8];
		if (Num>ItemCount)
			Num = ItemCount;
		for (i = 0; i < Num; i++) {
			memcpy(&JSetPara_AFN04_3761_2009->group9.f65[Pn - 1].Flag[i][0], Data + 9 + i * 4,	4);
		}
		SetDaDt(P, F);
		SendBuff[SendIndex++] = 0;

//		memset(TempBufn,0,60);
//		sprintf((char*)TempBufn,"%s/TaskPara.par",_PARADIR_);
//		NormalSaveFile((char*)TempBufn, &JSetPara_AFN04_3761_2009->group9, sizeof(JSetPara_AFN04_3761_2009->group9),Jproginfo);
		Jproginfo->FileSaveFlag.g9flag = 1;
		Jproginfo->Para.ChangedJiZhongQiInfo = 2;
		for (i = 0; i < Num; i++) {
			k = k + 4;
		}
		k=k+9;
		return k;
		e: k = 0;
		k++;
		k = k + sizeof(JSetPara_AFN04_3761_2009->group9.f65[Pn - 1].Post_Time);
		k++;
		Num = Data[k++];//���ݵ�Ԫ��ʶ����
		for (i = 0; i < Num; i++) {
			k = k + 4;
		}
		SetDaDt(P, F);
		SendBuff[SendIndex++] = 1;
		return k;
	}
	if (Set == 0)//��ȡ�����ϱ���վ
	{
		SetDaDt(P, F);
		memcpy(&SendBuff[SendIndex++], &JSetPara_AFN04_3761_2009->group9.f65[Pn - 1].Interval,
				1);
		memcpy(&SendBuff[SendIndex],
				&JSetPara_AFN04_3761_2009->group9.f65[Pn - 1].Post_Time[0], 6);
		SendIndex += 6;
		memcpy(&SendBuff[SendIndex++], &JSetPara_AFN04_3761_2009->group9.f65[Pn - 1].R, 1);
		memcpy(&SendBuff[SendIndex++], &JSetPara_AFN04_3761_2009->group9.f65[Pn - 1].Count, 1);
		Num = JSetPara_AFN04_3761_2009->group9.f65[Pn - 1].Count;
		for (i = 0; i < Num; i++) {
			memcpy(&SendBuff[SendIndex],
					&JSetPara_AFN04_3761_2009->group9.f65[Pn - 1].Flag[i][0], 4);
			SendIndex += 4;
		}
		return 4;
	}
	return 1;
}

INT16U SetPara_F66_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ʱ�ϱ�2��������������
{
	INT16U i, k = 0, Num;
	INT16U Pn;
//	INT8U TempBufn[60];
	Pn = P;
	if (Set == 1)//��վ��������
	{
		if (P > Task2_Max) {
			goto e;
		}
		Jproginfo->stateflags.F66_Changed= 1;
		memset(&JSetPara_AFN04_3761_2009->group9.f66[Pn - 1].Interval, 0,
				sizeof(JSetPara_AFN04_3761_2009->group9.f66[Pn - 1]));//��ʼ��
		memcpy(&JSetPara_AFN04_3761_2009->group9.f66[Pn - 1].Interval, Data, 1);
		memcpy(&JSetPara_AFN04_3761_2009->group9.f66[Pn - 1].Post_Time[0], Data + 1, 6);
		memcpy(&JSetPara_AFN04_3761_2009->group9.f66[Pn - 1].R, Data + 7, 1);
		memcpy(&JSetPara_AFN04_3761_2009->group9.f66[Pn - 1].Count, Data + 8, 1);
		Jproginfo->task2_Delay_Count[Pn - 1]=0;
		Num = Data[8];
		if (Num>ItemCount)
			Num = ItemCount;
		for (i = 0; i < Num; i++) {
			memcpy(&JSetPara_AFN04_3761_2009->group9.f66[Pn - 1].Flag[i][0], Data + 9 + i * 4,
					4);
		}
		SetDaDt(P, F);
		SendBuff[SendIndex++] = 0;
//		memset(TempBufn,0,60);
//		sprintf((char*)TempBufn,"%s/TaskPara.par",_PARADIR_);
//		NormalSaveFile((char*)TempBufn, &JSetPara_AFN04_3761_2009->group9, sizeof(JSetPara_AFN04_3761_2009->group9),Jproginfo);
		Jproginfo->FileSaveFlag.g9flag = 1;
		Jproginfo->Para.ChangedJiZhongQiInfo = 2;
		for (i = 0; i < Num; i++) {
			k = k + 4;
		}
		k=k+9;
		//printf("k=%d\n\r",k);
		return k;
		e: k = 0;
		k++;
		k = k + sizeof(JSetPara_AFN04_3761_2009->group9.f66[Pn - 1].Post_Time);
		k++;
		Num = Data[k++];//���ݵ�Ԫ��ʶ����
		for (i = 0; i < Num; i++) {
			k = k + 4;
		}
		SetDaDt(P, F);
		SendBuff[SendIndex++] = 1;
		return k;
	}
	if (Set == 0)//��ȡ�����ϱ���վ
	{
		SetDaDt(P, F);
		memcpy(&SendBuff[SendIndex++], &JSetPara_AFN04_3761_2009->group9.f66[Pn - 1].Interval,
				1);
		memcpy(&SendBuff[SendIndex],
				&JSetPara_AFN04_3761_2009->group9.f66[Pn - 1].Post_Time[0], 6);
		SendIndex += 6;
		memcpy(&SendBuff[SendIndex++], &JSetPara_AFN04_3761_2009->group9.f66[Pn - 1].R, 1);
		memcpy(&SendBuff[SendIndex++], &JSetPara_AFN04_3761_2009->group9.f66[Pn - 1].Count, 1);
		Num = JSetPara_AFN04_3761_2009->group9.f66[Pn - 1].Count;
		for (i = 0; i < Num; i++) {
			memcpy(&SendBuff[SendIndex],
					&JSetPara_AFN04_3761_2009->group9.f66[Pn - 1].Flag[i][0], 4);
			SendIndex += 4;
		}
		return 4;
	}
	return 1;
}

INT16U SetPara_F67_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ʱ�ϱ�1����������������
{
	INT16U Pn;
//	INT8U TempBufn[60];
	Pn = P;
	if (Set == 1)//��վ��������
	{
		if (P > Task1_Max) {
			goto e;
		}
		JSetPara_AFN04_3761_2009->group9.f67[Pn - 1].IsRun = Data[0];
//		memset(TempBufn,0,60);
//		sprintf((char*)TempBufn,"%s/TaskPara.par",_PARADIR_);
//		NormalSaveFile((char*)TempBufn, &JSetPara_AFN04_3761_2009->group9, sizeof(JSetPara_AFN04_3761_2009->group9),Jproginfo);
		Jproginfo->FileSaveFlag.g9flag = 1;
		Jproginfo->Para.ChangedJiZhongQiInfo = 2;
		SetDaDt(P, F);
		SendBuff[SendIndex++] = 0;
		return 1;
		e: SetDaDt(P, F);
		SendBuff[SendIndex++] = 1;
		return 1;
	}
	if (Set == 0)//��ȡ���ñ���
	{

		SetDaDt(P, F);
		SendBuff[SendIndex++] = JSetPara_AFN04_3761_2009->group9.f67[Pn - 1].IsRun;
		return 4;
	}
	return 1;
}

INT16U SetPara_F68_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ʱ�ϱ�2����������������
{
	INT16U Pn;
//	INT8U TempBufn[60];
	Pn = P;
	if (Set == 1)//��վ��������
	{
		if (P > Task2_Max) {
			goto e;
		}
		JSetPara_AFN04_3761_2009->group9.f68[Pn - 1].IsRun = Data[0];
//		memset(TempBufn,0,60);
//		sprintf((char*)TempBufn,"%s/TaskPara.par",_PARADIR_);
//		NormalSaveFile((char*)TempBufn, &JSetPara_AFN04_3761_2009->group9, sizeof(JSetPara_AFN04_3761_2009->group9),Jproginfo);
		Jproginfo->FileSaveFlag.g9flag = 1;
		Jproginfo->Para.ChangedJiZhongQiInfo = 2;
		SetDaDt(P, F);
		SendBuff[SendIndex++] = 0;
		return 1;
		e: SetDaDt(P, F);
		SendBuff[SendIndex++] = 1;
		return 1;
	}
	if (Set == 0)//��ȡ���ñ���
	{

		SetDaDt(P, F);
		SendBuff[SendIndex++] = JSetPara_AFN04_3761_2009->group9.f68[Pn - 1].IsRun;
		return 4;
	}
	return 1;
}
INT16U SetPara_F111_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��������ά����ʱ�������
{
	if (Set == 1)//��վ��������
	{
		memcpy(&JSetPara_AFN04_3761_2009->group11.f111.Com, Data, 1);
		memcpy(&JSetPara_AFN04_3761_2009->group11.f111.Enable, Data + 1, 1);
		memcpy(&JSetPara_AFN04_3761_2009->group11.f111.StartTime, Data + 2, 3);
		memcpy(&JSetPara_AFN04_3761_2009->group11.f111.AllowTime, Data + 5, 1);

		SetDaDt(P, F);//AFN=00H,Fn=F3ʱ�����ݵ�Ԫ�е����ݵ�Ԫ��ʶ
		SendBuff[SendIndex++] = 0;//ERR=0,ȷ��
		Jproginfo->Para.ChangedJiZhongQiInfo = 2;//���漯��������
		Jproginfo->FileSaveFlag.g11flag = 1;
		return 6;
	}
	if (Set == 0)//��ȡ�����ϱ���վ
	{
		SetDaDt(P, F);
		memcpy(&SendBuff[SendIndex++], &JSetPara_AFN04_3761_2009->group11.f111.Com, 1);
		memcpy(&SendBuff[SendIndex++], &JSetPara_AFN04_3761_2009->group11.f111.Enable, 1);
		memcpy(&SendBuff[SendIndex], &JSetPara_AFN04_3761_2009->group11.f111.StartTime, 3);
		SendIndex = SendIndex + 3;
		memcpy(&SendBuff[SendIndex++], &JSetPara_AFN04_3761_2009->group11.f111.AllowTime , 1);
		return 4;
	}
	return 1;
}
//int getPointCount()
//{
//	int re=0,i;
//	for(i=0; i<PointMax; i++)        //���������ж�
//	{
//		if (JSetPara_AFN04_3761_2009->Point[i].f10.Status == 1)
//		{
//			re++;
//		}
//	}
//	return re;
//}
INT16U SetPara_F112_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ѯ�ɼ�������ܱ���ϵ��(����ѯ)
{/////!!!!!!!!!!!!!!!�˺�����Ҫ����
	int count=0,pointindex,i;
	Point Pt_AutoRep[PointMax];
	memset(Pt_AutoRep, 0, sizeof(Point)*PointMax);
	NormalReadFile("/nand/para/SouBiaoPt.par",(INT8U *)Pt_AutoRep,sizeof(Point)*PointMax,Jproginfo);
	if (Set == 0)//��ȡ�����ϱ���վ
	{
		SetDaDt(P, F);
		//count = getPointCount();
		for(i=0; i<PointMax; i++)        //���������ж�
		{
			if (Pt_AutoRep[i].f10.Status == 1)
				count++;
		}
		SendBuff[SendIndex++] = count & 0x00ff;
		SendBuff[SendIndex++] = (count & 0xff00)>>8;
		for(i=0;i<PointMax;i++)
		{
			if (Pt_AutoRep[i].f10.Status == 1)
			{
				if ((Pt_AutoRep[i].f10.ConnectType!=1) && (Pt_AutoRep[i].f10.ConnectType!=30))
					continue;
				if (Pt_AutoRep[i].f10.port!=31)
					continue;
				pointindex = getPoint(Pt_AutoRep[i].f10.CjqNo-1,Pt_AutoRep[i].f10.MeterNo)+1;
				SendBuff[SendIndex++] = pointindex & 0x00ff;
				SendBuff[SendIndex++] = (pointindex & 0xff00)>>8;
				memcpy(&SendBuff[SendIndex],Pt_AutoRep[i].f10.Address,6);
				SendIndex = SendIndex + 6;
				memcpy(&SendBuff[SendIndex],Pt_AutoRep[i].f10.CaijiqiAddress,6);
				SendIndex = SendIndex + 6;
				SendBuff[SendIndex++] = 0;
			}
		}
		return 4;
	}
	return 1;
}
INT16U CallSetting_F01_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//�ն˰汾��Ϣ
{
	INT8U area[5];
	INT8U devno[5];
	memset(devno,0,5);
	memset(area,0,5);
	BCDToASC(&Jcfginfo->jzqpara.Address_8017.JZ_di_zhi[0],2,devno);
	BCDToASC(&Jcfginfo->jzqpara.Area_8016.JZ_XingZhuangQuHaoMa[0],2,area);
	SdPrintf(YNPrint,PreFix,"area=%s\n\r",area);
	SdPrintf(YNPrint,PreFix,"id=%s\n\r",devno);
	memcpy(&Jcfginfo->jzqpara.ver.DevNo,area,4);
	memcpy(&Jcfginfo->jzqpara.ver.DevNo[4],devno,4);
	SetDaDt(P, F);
	memcpy(&SendBuff[SendIndex], &Jcfginfo->jzqpara.ver.FactNo, 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &Jcfginfo->jzqpara.ver.DevNo, 8);
	SendIndex = SendIndex + 8;
	memcpy(&SendBuff[SendIndex], &Jcfginfo->jzqpara.ver.SoftVer, 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &Jcfginfo->jzqpara.ver.SoftDate, 3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex], &Jcfginfo->jzqpara.ver.SetInf, 11);
	SendIndex = SendIndex + 11;
	memcpy(&SendBuff[SendIndex], &Jcfginfo->jzqpara.ver.ProtVer, 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &Jcfginfo->jzqpara.ver.HardVer, 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &Jcfginfo->jzqpara.ver.HardDate, 3);
	SendIndex = SendIndex + 3;
	//return 41;
	return 4;
}

INT16U CallSetting_F02_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//�ն�֧�ֵ����롢�����ͨ�Ŷ˿�����
{
	INT32U i, tmp;
	/************** �Զ���**************/
	INT16U PM = PointMax, RM = RecByteMax, SM = SendByteMax;
	/***********************************/
	SetDaDt(P, F);
	SendBuff[SendIndex++] = 0;//����������·��
	SendBuff[SendIndex++] = 2;//����������·��
	SendBuff[SendIndex++] = 0;//ֱ��ģ��������·��
	SendBuff[SendIndex++] = 0;//���������·��
	memcpy(&SendBuff[SendIndex], &PM, 2);//֧�ֵĳ����ܱ�/��������װ��������
	SendIndex += 2;
	memcpy(&SendBuff[SendIndex], &RM, 2);//֧�ֵ��ն�����ͨ�������ջ������ֽ���
	SendIndex += 2;
	memcpy(&SendBuff[SendIndex], &SM, 2);//֧�ֵ��ն�����ͨ������ͻ������ֽ���
	SendIndex += 2;
	SendBuff[SendIndex++] = 1;//MAC��ַ1��
	SendBuff[SendIndex++]=2;//MAC��ַ2��
	SendBuff[SendIndex++]=3;//MAC��ַ3��
	SendBuff[SendIndex++]=4;//MAC��ַ4��
	SendBuff[SendIndex++]=5;//MAC��ַ5��
	SendBuff[SendIndex++]=6;//MAC��ַ6��

	SendBuff[SendIndex++] = 3;//ͨ�Ŷ˿�����
	tmp = 0;
	for (i = 0; i < 3; i++) {
		SendBuff[SendIndex] = i+1;
		SendBuff[SendIndex + 1] = 0x60;
		SendIndex += 2;
		tmp = 9600;
		memcpy(&SendBuff[SendIndex],&tmp,4);
		/*SendBuff[SendIndex + 0] = 0x00;
		SendBuff[SendIndex + 1] = 0x00;
		SendBuff[SendIndex + 2] = (tmp >> 8) & 0xff;
		SendBuff[SendIndex + 3] = tmp & 0xff;*/
		SendIndex += 4;
		tmp = 32;
		memcpy(&SendBuff[SendIndex],&tmp,2);
		//SendBuff[SendIndex] = (tmp >> 8) & 0xff;
		//SendBuff[SendIndex + 1] = tmp & 0xff;
		SendIndex += 2;
		RM=256;
		memcpy(&SendBuff[SendIndex], &RM, 2);
		SendIndex += 2;
		SM=256;
		memcpy(&SendBuff[SendIndex], &SM, 2);
		SendIndex += 2;
	}
	return 4;
}

INT16U CallSetting_F03_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//�ն�֧�ֵ���������
{
	INT8U i;
	/************** �Զ���**************/
	INT16U PM = PointMax;
	/***********************************/
	SetDaDt(P, F);
	memcpy(&SendBuff[SendIndex], &PM, 2);//֧�ֵĲ�����������
	SendIndex += 2;
	SendBuff[SendIndex++] = GroupMax;//֧�ֵ��ܼ����������
	SendBuff[SendIndex++] = 20;//֧�ֵ�����������
	SendBuff[SendIndex++] = SubGroupMax;//֧�ֵ��й��ܵ���������������
	SendBuff[SendIndex++] = FeilvMax;//֧�ֵ���������

	SendBuff[SendIndex++] = 3;//֧�ֵĲ�����������󶳽��ܶ�
	SendBuff[SendIndex++] = 3;//֧�ֵ��ܼ����й�����������󶳽��ܶ�
	SendBuff[SendIndex++] = 3;//֧�ֵ��ܼ����޹�����������󶳽��ܶ�
	SendBuff[SendIndex++] = 3;//֧�ֵ��ܼ����й�������������󶳽��ܶ�
	SendBuff[SendIndex++] = 3;//֧�ֵ��ܼ����޹�������������󶳽��ܶ�
	SendBuff[SendIndex++] = 31;//֧�ֵ����������������
	SendBuff[SendIndex++] = 12;//֧�ֵ����������������
	SendBuff[SendIndex++] = 0;//֧�ֵ�ʱ�ι��ض�ֵ����������
	SendBuff[SendIndex++] = 0;//֧�ֵ�г��������г������
	SendBuff[SendIndex++] = 0;//֧�ֵ��޹��������������������
	SendBuff[SendIndex++] = PointKeyMax;//֧�ֵ�̨�����г����ص㻧��໧��
	//memcpy(&SendBuff[SendIndex],Data1+11,2);//֧�ֵ��û�����ű�־
	SendBuff[SendIndex++] = 0b00011100;
	SendBuff[SendIndex++] = 0b00000000;
	for (i = 0; i < 16; i++) {
		SendBuff[SendIndex + i] = 0x02;//֧��i���û������µ��û�С��Ÿ���
	}
	SendIndex += 16;

	//return 32;
	return 4;
}

INT16U CallSetting_F04_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//�ն�֧�ֵĲ�������
{
	SetDaDt(P, F);
	SendBuff[SendIndex++] = 9;//֧�ֵ������Ϣ����ֵ
	SendBuff[SendIndex++] = 0b00010101;   //F1 3 5
	SendBuff[SendIndex++] = 0b01101011;   //F9 10 12 14 15
	SendBuff[SendIndex++] = 0b00000000;
	SendBuff[SendIndex++] = 0b00000011;   //F25 26
	SendBuff[SendIndex++] = 0b00001101;   //F33 35 36
	SendBuff[SendIndex++] = 0b00000000;   //
	SendBuff[SendIndex++] = 0b00000000;
	SendBuff[SendIndex++] = 0b00000100;   //F59
	SendBuff[SendIndex++] = 0b00001111;   //F65 66 67 68

	return 4;
}

INT16U CallSetting_F05_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//�ն�֧�ֵĿ�������
{
	SetDaDt(P, F);
	SendBuff[SendIndex++] = 5;//֧�ֵ������Ϣ����ֵ
	SendBuff[SendIndex++] = 0b00000000;
	SendBuff[SendIndex++] = 0b00000000;
	SendBuff[SendIndex++] = 0b00000000;
	SendBuff[SendIndex++] = 0b01010000;   //F29 31
	SendBuff[SendIndex++] = 0b00010000;   //F37
	return 4;
}

INT16U CallSetting_F06_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//�ն�֧�ֵ�1����������
{
	SetDaDt(P, F);
	SendBuff[SendIndex++] = 0b00011100;
	SendBuff[SendIndex++] = 0b00000000;
	SendBuff[SendIndex++] = 21;
	SendBuff[SendIndex++] = 0b11001111;//1-8
	SendBuff[SendIndex++] = 0b00000011;//9-16
	SendBuff[SendIndex++] = 0b00000011;//17-24
	SendBuff[SendIndex++] = 0b00001111;//25-32
	SendBuff[SendIndex++] = 0b00001111;//33-40
	SendBuff[SendIndex++] = 0b00000000;//41-48
	SendBuff[SendIndex++] = 0b00000000;//49-56
	SendBuff[SendIndex++] = 0b00000000;//57-64
	SendBuff[SendIndex++] = 0b00000000;//65-72
	SendBuff[SendIndex++] = 0b00000000;//73-80
	SendBuff[SendIndex++] = 0b00000000;//81-88
	SendBuff[SendIndex++] = 0b00000000;//89-96
	SendBuff[SendIndex++] = 0b00000000;//97-104
	SendBuff[SendIndex++] = 0b00000000;//105-112
	SendBuff[SendIndex++] = 0b00000000;//113-120
	SendBuff[SendIndex++] = 0b00000000;//121-128
	SendBuff[SendIndex++] = 0b11111111;//129-136
	SendBuff[SendIndex++] = 0b00000000;//137-144
	SendBuff[SendIndex++] = 0b00001111;//145-152
	SendBuff[SendIndex++] = 0b00000000;//153-160
	SendBuff[SendIndex++] = 0b11110001;//161-168
	SendBuff[SendIndex++] = 21;
	SendBuff[SendIndex++] = 0b11001111;//1-8
	SendBuff[SendIndex++] = 0b00000011;//9-16
	SendBuff[SendIndex++] = 0b00000011;//17-24
	SendBuff[SendIndex++] = 0b00001111;//25-32
	SendBuff[SendIndex++] = 0b00001111;//33-40
	SendBuff[SendIndex++] = 0b00000000;//41-48
	SendBuff[SendIndex++] = 0b00000000;//49-56
	SendBuff[SendIndex++] = 0b00000000;//57-64
	SendBuff[SendIndex++] = 0b00000000;//65-72
	SendBuff[SendIndex++] = 0b00000000;//73-80
	SendBuff[SendIndex++] = 0b00000000;//81-88
	SendBuff[SendIndex++] = 0b00000000;//89-96
	SendBuff[SendIndex++] = 0b00000000;//97-104
	SendBuff[SendIndex++] = 0b00000000;//105-112
	SendBuff[SendIndex++] = 0b00000000;//113-120
	SendBuff[SendIndex++] = 0b00000000;//121-128
	SendBuff[SendIndex++] = 0b11111111;//129-136
	SendBuff[SendIndex++] = 0b00000000;//137-144
	SendBuff[SendIndex++] = 0b00001111;//145-152
	SendBuff[SendIndex++] = 0b00000000;//153-160
	SendBuff[SendIndex++] = 0b11110001;//161-168
	SendBuff[SendIndex++] = 21;
	SendBuff[SendIndex++] = 0b11001111;//1-8
	SendBuff[SendIndex++] = 0b00000011;//9-16
	SendBuff[SendIndex++] = 0b00000011;//17-24
	SendBuff[SendIndex++] = 0b00001111;//25-32
	SendBuff[SendIndex++] = 0b00001111;//33-40
	SendBuff[SendIndex++] = 0b00000000;//41-48
	SendBuff[SendIndex++] = 0b00000000;//49-56
	SendBuff[SendIndex++] = 0b00000000;//57-64
	SendBuff[SendIndex++] = 0b00000000;//65-72
	SendBuff[SendIndex++] = 0b00000000;//73-80
	SendBuff[SendIndex++] = 0b00000000;//81-88
	SendBuff[SendIndex++] = 0b00000000;//89-96
	SendBuff[SendIndex++] = 0b00000000;//97-104
	SendBuff[SendIndex++] = 0b00000000;//105-112
	SendBuff[SendIndex++] = 0b00000000;//113-120
	SendBuff[SendIndex++] = 0b00000000;//121-128
	SendBuff[SendIndex++] = 0b11111111;//129-136
	SendBuff[SendIndex++] = 0b00000000;//137-144
	SendBuff[SendIndex++] = 0b00001111;//145-152
	SendBuff[SendIndex++] = 0b00000000;//153-160
	SendBuff[SendIndex++] = 0b11110001;//161-168

	return 4;
}

INT16U CallSetting_F07_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//�ն�֧�ֵ�2����������
{
	SetDaDt(P, F);
	SendBuff[SendIndex++] = 0b00011100;
	SendBuff[SendIndex++] = 0b00000000;
	SendBuff[SendIndex++] = 24;
	SendBuff[SendIndex++] = 0b11111111;//1-8
	SendBuff[SendIndex++] = 0b00000000;//9-16
	SendBuff[SendIndex++] = 0b11111111;//17-24
	SendBuff[SendIndex++] = 0b00000000;//25-32
	SendBuff[SendIndex++] = 0b00001100;//33-40
	SendBuff[SendIndex++] = 0b00000000;//41-48
	SendBuff[SendIndex++] = 0b00110101;//49-56
	SendBuff[SendIndex++] = 0b00000000;//57-64
	SendBuff[SendIndex++] = 0b00000000;//65-72
	SendBuff[SendIndex++] = 0b00001111;//73-80
	SendBuff[SendIndex++] = 0b11111111;//81-88
	SendBuff[SendIndex++] = 0b00111111;//89-96
	SendBuff[SendIndex++] = 0b11111111;//97-104
	SendBuff[SendIndex++] = 0b00001111;//105-112
	SendBuff[SendIndex++] = 0b00000000;//113-120
	SendBuff[SendIndex++] = 0b00000000;//121-128
	SendBuff[SendIndex++] = 0b00000000;//129-136
	SendBuff[SendIndex++] = 0b00000000;//137-144
	SendBuff[SendIndex++] = 0b00000000;//145-152
	SendBuff[SendIndex++] = 0b00000000;//153-160
	SendBuff[SendIndex++] = 0b11111111;//161-168
	SendBuff[SendIndex++] = 0b00000011;//169-176
	SendBuff[SendIndex++] = 0b11111111;//177-184
	SendBuff[SendIndex++] = 0b11111111;//185-192
	SendBuff[SendIndex++] = 24;
	SendBuff[SendIndex++] = 0b11111111;//1-8
	SendBuff[SendIndex++] = 0b00000000;//9-16
	SendBuff[SendIndex++] = 0b11111111;//17-24
	SendBuff[SendIndex++] = 0b00000000;//25-32
	SendBuff[SendIndex++] = 0b00001100;//33-40
	SendBuff[SendIndex++] = 0b00000000;//41-48
	SendBuff[SendIndex++] = 0b00110101;//49-56
	SendBuff[SendIndex++] = 0b00000000;//57-64
	SendBuff[SendIndex++] = 0b00000000;//65-72
	SendBuff[SendIndex++] = 0b00001111;//73-80
	SendBuff[SendIndex++] = 0b11111111;//81-88
	SendBuff[SendIndex++] = 0b00111111;//89-96
	SendBuff[SendIndex++] = 0b11111111;//97-104
	SendBuff[SendIndex++] = 0b00001111;//105-112
	SendBuff[SendIndex++] = 0b00000000;//113-120
	SendBuff[SendIndex++] = 0b00000000;//121-128
	SendBuff[SendIndex++] = 0b00000000;//129-136
	SendBuff[SendIndex++] = 0b00000000;//137-144
	SendBuff[SendIndex++] = 0b00000000;//145-152
	SendBuff[SendIndex++] = 0b00000000;//153-160
	SendBuff[SendIndex++] = 0b11111111;//161-168
	SendBuff[SendIndex++] = 0b00000011;//169-176
	SendBuff[SendIndex++] = 0b11111111;//177-184
	SendBuff[SendIndex++] = 0b11111111;//185-192
	SendBuff[SendIndex++] = 23;
	SendBuff[SendIndex++] = 0b00010001;//1-8
	SendBuff[SendIndex++] = 0b00000000;//9-16
	SendBuff[SendIndex++] = 0b00010101;//17-24
	SendBuff[SendIndex++] = 0b00000000;//25-32
	SendBuff[SendIndex++] = 0b00000000;//33-40
	SendBuff[SendIndex++] = 0b00000000;//41-48
	SendBuff[SendIndex++] = 0b00000001;//49-56
	SendBuff[SendIndex++] = 0b00000000;//57-64
	SendBuff[SendIndex++] = 0b00000000;//65-72
	SendBuff[SendIndex++] = 0b00000101;//73-80
	SendBuff[SendIndex++] = 0b00000001;//81-88
	SendBuff[SendIndex++] = 0b00000000;//89-96
	SendBuff[SendIndex++] = 0b00000001;//97-104
	SendBuff[SendIndex++] = 0b00000000;//105-112
	SendBuff[SendIndex++] = 0b00000000;//113-120
	SendBuff[SendIndex++] = 0b00000000;//121-128
	SendBuff[SendIndex++] = 0b00000000;//129-136
	SendBuff[SendIndex++] = 0b00000000;//137-144
	SendBuff[SendIndex++] = 0b00000000;//145-152
	SendBuff[SendIndex++] = 0b00000000;//153-160
	SendBuff[SendIndex++] = 0b00000001;//161-168
	SendBuff[SendIndex++] = 0b00000001;//169-176
	SendBuff[SendIndex++] = 0b00000001;//177-184
	return 4;
}

INT16U CallSetting_F08_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//�ն�֧�ֵ��¼���¼����
{
	SetDaDt(P, F);
	memset(&SendBuff[SendIndex], 0x00, 8);//֧�ֵ��¼���¼��־λ
	SendBuff[SendIndex] = 0b10001111; //ERC1 2 3 4 8
	SendBuff[SendIndex + 1] = 0b00111011;//ERC 9 10 12 13 14
	SendBuff[SendIndex + 2] = 0b10011001;//ERC 17 20 21 24
	SendBuff[SendIndex + 3] = 0b11111111;//ERC 25-32
	SendBuff[SendIndex + 4] = 0b00000001;//ERC33
	SendIndex += 8;
	//return 8;
	return 4;
}
//zbupdate
INT16U CallSetting_F248_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)//Ϊ���������ز�ģ���¼ӵ�F248
{
	FILE *fp;
	INT8U strVersion[50];
	memset(strVersion, 0, 50);
	SetDaDt(P, F);
	fp=fopen("/nand/bin/zbversion","r");
	if(fp==NULL)
	{
		SdPrintf(YNPrint,PreFix,"CallSetting_F248_Set open file 'zbversion' failed!!!!\n");
		fclose(fp);
		return 4;
	}
	fscanf(fp, "%s",strVersion);
	SdPrintf(YNPrint,PreFix,"zb strVersion:  %s",strVersion);
	SendBuff[SendIndex++] = strVersion[0];
	SendBuff[SendIndex++] = strVersion[1];
	SendBuff[SendIndex++] = strVersion[2];
	SendBuff[SendIndex++] = strVersion[3];
	ASCToBCD(&strVersion[4], 2, &SendBuff[SendIndex++]);
	ASCToBCD(&strVersion[6], 2, &SendBuff[SendIndex++]);
	ASCToBCD(&strVersion[8], 2, &SendBuff[SendIndex++]);
	ASCToBCD(&strVersion[10], 2, &SendBuff[SendIndex++]);
	ASCToBCD(&strVersion[12], 2, &SendBuff[SendIndex++]);
	fclose(fp);
	return 4;
}
#ifdef SHANGHAI   //�Ϻ���չЭ��
//�ն˶Ե��ܱ�ʱ�Ӻ˶ԵĲ���
INT16U SetPara_F241_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)
{
//	int i = 0,flag=0;
//	INT8U TempBufn[60];
	if (Set == 1)//��վ��������
	{
		SdPrintf(YNPrint,PreFix,"���ò���F241���ն˶Ե��ܱ�ʱ�Ӻ˶ԵĲ�����");
		JSetPara_AFN04_3761_2009->group31.RdMeterParaChkTmr.chkfreq = *(Data);
		JSetPara_AFN04_3761_2009->group31.RdMeterParaChkTmr.chkdate = *(Data+1);
		JSetPara_AFN04_3761_2009->group31.RdMeterParaChkTmr.chkhour = *(Data+2);
		JSetPara_AFN04_3761_2009->group31.RdMeterParaChkTmr.chkmin = *(Data+3);
		JSetPara_AFN04_3761_2009->group31.RdMeterParaChkTmr.alarmerrmin = *(Data+4);
		SetDaDt(P, F);
		SendBuff[SendIndex++] = 0;
		Jproginfo->FileSaveFlag.g31flag = 1;
		SdPrintf(YNPrint,PreFix,"F241:%02x,%02x,%02x��%02x,%02x",JSetPara_AFN04_3761_2009->group31.RdMeterParaChkTmr.chkfreq,
				JSetPara_AFN04_3761_2009->group31.RdMeterParaChkTmr.chkdate,
				JSetPara_AFN04_3761_2009->group31.RdMeterParaChkTmr.chkhour,
				JSetPara_AFN04_3761_2009->group31.RdMeterParaChkTmr.chkmin,
				JSetPara_AFN04_3761_2009->group31.RdMeterParaChkTmr.alarmerrmin);
		return 5;
	}
	else if (Set == 0)//��ȡ�����ϱ���վ
	{
		SdPrintf(YNPrint,PreFix,"��ȡ����F241���ն˶Ե��ܱ�ʱ�Ӻ˶ԵĲ�����");
		SetDaDt(P, F);
		SendBuff[SendIndex++] = JSetPara_AFN04_3761_2009->group31.RdMeterParaChkTmr.chkfreq;
		SendBuff[SendIndex++] = JSetPara_AFN04_3761_2009->group31.RdMeterParaChkTmr.chkdate;
		SendBuff[SendIndex++] = JSetPara_AFN04_3761_2009->group31.RdMeterParaChkTmr.chkhour;
		SendBuff[SendIndex++] = JSetPara_AFN04_3761_2009->group31.RdMeterParaChkTmr.chkmin;
		SendBuff[SendIndex++] = JSetPara_AFN04_3761_2009->group31.RdMeterParaChkTmr.alarmerrmin;
		SdPrintf(YNPrint,PreFix,"F241:%02x,%02x,%02x��%02x,%02x",JSetPara_AFN04_3761_2009->group31.RdMeterParaChkTmr.chkfreq,
				JSetPara_AFN04_3761_2009->group31.RdMeterParaChkTmr.chkdate,
				JSetPara_AFN04_3761_2009->group31.RdMeterParaChkTmr.chkhour,
				JSetPara_AFN04_3761_2009->group31.RdMeterParaChkTmr.chkmin,
				JSetPara_AFN04_3761_2009->group31.RdMeterParaChkTmr.alarmerrmin);
		return 4;
	}
	return 1;
}
//�ն˶Ե��ܱ��������ƵĲ���
INT16U SetPara_F242_Set(INT8U Set, INT16U F, INT16U P, INT8U *Data)
{
	if(Set == 1){
		SdPrintf(YNPrint,PreFix,"���ò���F242���ն˶Ե��ܱ��������ƵĲ�����");
		JSetPara_AFN04_3761_2009->group31.RdMeterParaDelay.rdelaymin = *Data;
		SetDaDt(P, F);
		SendBuff[SendIndex++] = 0;
		Jproginfo->FileSaveFlag.g31flag = 1;
		return 1;
	}
	else if(Set == 0){
		SdPrintf(YNPrint,PreFix,"��ȡ����F242���ն˶Ե��ܱ��������ƵĲ�����");
		SetDaDt(P, F);
		SendBuff[SendIndex++] = JSetPara_AFN04_3761_2009->group31.RdMeterParaDelay.rdelaymin;
		return  4;
	}
	return 1;
}
//�ն�SIM������
INT16U SetPara_F243_Set(INT8U Set,INT16U F, INT16U P, INT8U *Data){
	if(Set == 1){
		INT8U simb[8];
		INT8U simc[16];
		INT8U i=0;
		SdPrintf(YNPrint,PreFix,"���ò���F243���ն�sim���ֻ����롿");
		SetDaDt(P, F);
		for(i=0; i < 8; i++)
		{
			simb[i] = *(Data+7-i);
		}
		memset(simc,0,16);
		BCDToASC(simb,8,simc);
		memset(Jcfginfo->jzqpara.SIMCard,0,20);
		memcpy(Jcfginfo->jzqpara.SIMCard,simc,16);
		Jproginfo->FileSaveFlag.jzqflag = 1;
		return 8;
	}
	else if(Set == 0){
		INT8U i=0;
		SdPrintf(YNPrint,PreFix,"��ȡ����F243���ն�sim���ֻ����롿");
		SetDaDt(P, F);
		INT8U  simc[16];
		INT8U simb[8];
		memset(simc,'0',16);
//		fprintf(stderr,"simno=%s,simlen=%d",Jcfginfo->jzqpara.SIMCard,strlen(Jcfginfo->jzqpara.SIMCard));
		memcpy(&simc[16-strlen(Jcfginfo->jzqpara.SIMCard)],Jcfginfo->jzqpara.SIMCard,strlen(Jcfginfo->jzqpara.SIMCard));
		ASCToBCD(simc,16,simb);
		for(i=0; i < 8; i++)
		{
			SendBuff[SendIndex++] = simb[7-i];
		}
		return 4;
	}
	return 1;
}
#endif
