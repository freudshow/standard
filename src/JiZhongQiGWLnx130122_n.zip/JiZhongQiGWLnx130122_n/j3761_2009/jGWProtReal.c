/*
 *
 *   ������Լ�ӿں�������
 *       ������Լ���Ĵ���ģ����ýӿں����������Ӧ��������
 *       ������Լ���Ĵ���ģ����ýӿں�����������վ�·�����
 *
 *///-------------------------------------------------------------

#include "time.h"
#include <sys/mman.h>
#include <unistd.h>
#include "jGWProtocol.h"
//#include "inc/init.h"
#include "../jBase/inc/pubfunction.h"
#include "innerPubVar.h"

//extern INT32S BCD_INT32(INT8U *buf, INT8U len);
//extern void INT32U_BCD(INT32S data, INT8U *buf, INT8U len);

//1�����ݴ�������

INT16U Level1Data_F1_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//����ն�����ʱ��
{
	INT8U area[5];
	INT8U devno[5];
//	if (AutoFlg==0)
//		//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));//����1�����ݵı���ͷ

	memset(devno,0,5);
	memset(area,0,5);
	BCDToASC(&Jcfginfo->jzqpara.Address_8017.JZ_di_zhi[0],2,devno);
	BCDToASC(&Jcfginfo->jzqpara.Area_8016.JZ_XingZhuangQuHaoMa[0],2,area);
	SdPrintf(YNPrint,PreFix,"area=%s\n\r",area);
	SdPrintf(YNPrint,PreFix,"id=%s\n\r",devno);
	memcpy(&Jcfginfo->jzqpara.ver.DevNo,area,4);
	memcpy(&Jcfginfo->jzqpara.ver.DevNo[4],devno,4);
	memcpy(&SendBuff[SendIndex], &Jcfginfo->jzqpara.ver.FactNo, 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &Jcfginfo->jzqpara.ver.DevNo, 8);
	SendIndex = SendIndex + 8;
	memcpy(&SendBuff[SendIndex], &Jcfginfo->jzqpara.ver.SoftVer, 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &Jcfginfo->jzqpara.ver.SoftDate, 3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex], &Jcfginfo->jzqpara.ver.SetInf, 11);
	SendIndex = SendIndex + 11;

//	if (AutoFlg==0)
//	{
//		EC();
//		//TP();
//		FrameTailCreate_Send(0);//���ͱ���β��������
//	}
	return 1;
}

INT16U Level1Data_F2_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//����ն�����ʱ��
{
	TS ts;
	TSGet(&ts);//��ȡʱ��
	SdPrintf(YNPrint,PreFix,"Level1Data_F2_Get--%d\n\r",AutoFlg);
//	if (AutoFlg==0)
//		//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));//����1�����ݵı���ͷ
	SendBuff[SendIndex++] = ((ts.Sec / 10) << 4) + (ts.Sec % 10);
	SendBuff[SendIndex++] = ((ts.Minute / 10) << 4) + (ts.Minute % 10);
	SendBuff[SendIndex++] = ((ts.Hour / 10) << 4) + (ts.Hour % 10);
	SendBuff[SendIndex++] = ((ts.Day / 10) << 4) + (ts.Day % 10);
	if (ts.Week == 0) {
		SendBuff[SendIndex++] = ((ts.Month / 10) << 4) + (ts.Month % 10) + 0xe0;
	} else {
		SendBuff[SendIndex++] = ((ts.Month / 10) << 4) + (ts.Month % 10)
				+ (ts.Week << 5);
	}
	SendBuff[SendIndex++] = (((ts.Year % 100) / 10) << 4) + (ts.Year % 10);
//	if (AutoFlg==0)
//	{
//		EC();
//		TP();
//		FrameTailCreate_Send(0);//���ͱ���β��������
//	}
	return 1;
}

//�ж��ն���afn=04h�Ĳ�����
INT16U Level1Data_F3_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//����ն˲���״̬
{
	SdPrintf(YNPrint,PreFix,">>��ȡ�ն˲�������(Fn=%d)",F);
//	if (AutoFlg==0)
//		//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));//����1�����ݵı���ͷ
	//31���ֽ�
	SendBuff[SendIndex++] = 0b00010101;   //F1 3 5
	SendBuff[SendIndex++] = 0b01101011;   //F9 10 12 14 15
	SendBuff[SendIndex++] = 0b00000000;
	SendBuff[SendIndex++] = 0b00000011;   //F25 26
	SendBuff[SendIndex++] = 0b00001101;   //F33 35 36
	SendBuff[SendIndex++] = 0b00000000;   //
	SendBuff[SendIndex++] = 0b00000000;
	SendBuff[SendIndex++] = 0b00000100;   //F59
	SendBuff[SendIndex++] = 0b00001111;   //F65 66 67 68
	SendBuff[SendIndex++] = 0b00000000;//10
	SendBuff[SendIndex++] = 0b00000000;
	SendBuff[SendIndex++] = 0b00000000;
	SendBuff[SendIndex++] = 0b00000000;
	SendBuff[SendIndex++] = 0b00000000;
	SendBuff[SendIndex++] = 0b00000000;
	SendBuff[SendIndex++] = 0b00000000;
	SendBuff[SendIndex++] = 0b00000000;
	SendBuff[SendIndex++] = 0b00000000;
	SendBuff[SendIndex++] = 0b00000000;//F97
	SendBuff[SendIndex++] = 0b00000000;//20,F96,F95,F94,F93,F92,F91,F90,F89
	SendBuff[SendIndex++] = 0b00000000;
	SendBuff[SendIndex++] = 0b00000000;
	SendBuff[SendIndex++] = 0b00000000;//F68,F67,F66,F65
	SendBuff[SendIndex++] = 0b00000000;
	SendBuff[SendIndex++] = 0b00000000;
	SendBuff[SendIndex++] = 0b00000000;
	SendBuff[SendIndex++] = 0b00000000;
	SendBuff[SendIndex++] = 0b00000000;//F25
	SendBuff[SendIndex++] = 0b00000000;
	SendBuff[SendIndex++] = 0b00000000;//30,F10
	SendBuff[SendIndex++] = 0b00000000;//F8,F7,F6,F4,F3,F1

//	if (AutoFlg==0)
//	{
//		EC();
//		TP();
//		FrameTailCreate_Send(0);//���ͱ���β��������
//	}

	return 1;
}

INT16U Level1Data_F4_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//����ն�����ͨ��״̬
{
	//if (AutoFlg==0)
		//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));//����1�����ݵı���ͷ

	SendBuff[SendIndex++] = Jcfginfo->jzqpara.CommStat;//ͨ��״̬ 00000001,����ͨ�������������ϱ�

//	if (AutoFlg==0)
//	{
//		EC();
//		TP();
//		FrameTailCreate_Send(0);//���ͱ���β��������
//	}
	return 1;
}

INT16U Level1Data_F5_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//����ն�����ͨ��״̬
{
	//if (AutoFlg==0)
		//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));//����1�����ݵı���ͷ

	SendBuff[SendIndex++] = 0x01;
	SendBuff[SendIndex++] = 0x00;

//	if (AutoFlg==0)
//	{
//		EC();
//		TP();
//		FrameTailCreate_Send(0);//���ͱ���β��������
//	}
	return 1;
}

INT16U Level1Data_F6_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//F6���ն˵�ǰ����״̬ //10.24
{
	//if (AutoFlg==0)
		//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));//����1�����ݵı���ͷ
	int i;
	SendBuff[SendIndex++]=0;
	SendBuff[SendIndex++]=0;
	SendBuff[SendIndex++]=0;
	for(i=0;i<8;i++)
	{
		SendBuff[SendIndex++]=0;
		SendBuff[SendIndex++]=0;
		SendBuff[SendIndex++]=0;
		SendBuff[SendIndex++]=0;
		SendBuff[SendIndex++]=0;
		SendBuff[SendIndex++]=0;
		SendBuff[SendIndex++]=0;
		SendBuff[SendIndex++]=0;
	}

//	if (AutoFlg==0)
//	{
//		EC();
//		TP();
//		FrameTailCreate_Send(0);//���ͱ���β��������
//	}
	return 1;
}

INT16U Level1Data_F7_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//����ն��¼���������ǰֵ
{

	//if (AutoFlg==0)
		//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));//����1�����ݵı���ͷ

	SendBuff[SendIndex++] = Jdatafileinfo->ErcEvt.EC1;//��Ҫ�¼�������	EC1ֵ
	SendBuff[SendIndex++] = Jdatafileinfo->ErcEvt.EC2;//һ���¼������� 	EC2ֵ


//	if (AutoFlg==0)
//	{
//		EC();
//		TP();
//		FrameTailCreate_Send(0);//���ͱ���β��������
//	}
	return 1;
}

INT16U Level1Data_F8_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//����ն��¼�״̬��־
{
	//if (AutoFlg==0)
		//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));//����1�����ݵı���ͷ

	memcpy(&SendBuff[SendIndex], Jdatafileinfo->ErcEvt.ERCBiaoZhi, 8);
	SendIndex = SendIndex + 8;

//	if (AutoFlg==0)
//	{
//		EC();
//		TP();
//		FrameTailCreate_Send(0);//���ͱ���β��������
//	}
	return 1;
}

INT16U Level1Data_F9_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//����ն�״̬������λ��־
{
	//int i;
	//if (AutoFlg==0)
		//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));//����1�����ݵı���ͷ

	SendBuff[SendIndex++] =  Jproginfo->YxStat;  // Jmemory->jzq.YxStat;//1~8·״̬����״̬ST
	SendBuff[SendIndex++] =  Jproginfo->YxChange;//1~8·״̬���ı�λ ����״̬�仯

//	if (AutoFlg==0)
//	{
//		EC();
//		TP();
//		FrameTailCreate_Send(0);//���ͱ���β��������
//	}
	return 1;
}

INT16U Level1Data_F10_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//����ն�����վ���ա���ͨ������
{
	//if (AutoFlg==0)
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));//����1�����ݵı���ͷ

	INT32U_BCD(Jdatafileinfo->DayRunTj.LiuLiang, &SendBuff[SendIndex], 4);
	SendIndex = SendIndex + 4;
	INT32U_BCD(Jdatafileinfo->YueRunTj.LiuLiang, &SendBuff[SendIndex], 4);
	SendIndex = SendIndex + 4;

//	if (AutoFlg==0)
//	{
//		EC();
//		TP();
//		FrameTailCreate_Send(0);//���ͱ���β��������
//	}
	return 1;
}

//9��15�ո�
INT16U Level1Data_F11_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//����ն˼���������״̬��Ϣ
{
	int num,num1,num2,num3,num4,pt1,pt2,pt3,pt4,i,met;
	TS ts;
	//if (AutoFlg==0)
		//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));//����1�����ݵı���ͷ

	SendBuff[SendIndex++] = 3;			//�������ݿ����n///��ȷ������Ҫ�޸�,����Ϊ2������+1���ز�
	num1=0;num2=0;num3=0;num4=0;
	pt1=0;pt2=0;pt3=0;pt4=0;
	for(num=0;num<PointMax;num++)
	{
		if (JSetPara_AFN04_3761_2009->group2.f10[num].Status==1)
		{
			if (JSetPara_AFN04_3761_2009->group2.f10[num].port==(1+PortBegNum))
				num1++;
			if (JSetPara_AFN04_3761_2009->group2.f10[num].port==(2+PortBegNum))
				num2++;
//			if (Jmemory->Points.pt[num].f10.port==(5+PortBegNum))
//				num3++;
			if (JSetPara_AFN04_3761_2009->group2.f10[num].port==(30+PortBegNum))
				num4++;
		}
	}
	for(num=0;num<JSetPara_AFN04_3761_2009->group5.f35.Count;num++)
	{
		i=JSetPara_AFN04_3761_2009->group5.f35.Index[num];
		//i=Jmemory->Points.f35.Module[num].Index[0]+(Jmemory->Points.f35.Module[num].Index[1]<<8);
		if (i>PointMax)
			continue;
		met=JSetPara_AFN04_3761_2009->group2.f10[i].PointIndex[0]+(JSetPara_AFN04_3761_2009->group2.f10[i].PointIndex[1]<<8);
		//met=JSetPara_AFN04_3761_2009->group2.f10[i].PointIndex[0]+(Jmemory->Points.pt[i].ind.PointIndex[1]<<8);
		//met=Jmemory->Points.pt[i].ind.PointIndex[0]+(Jmemory->Points.pt[i].ind.PointIndex[1]<<8);
//		met = JSetPara_AFN04_3761_2009->group5.f35.Index[num];
		if (JSetPara_AFN04_3761_2009->group2.f10[met].port==(1+PortBegNum))
			pt1++;
		if (JSetPara_AFN04_3761_2009->group2.f10[met].port==(2+PortBegNum))
			pt2++;
//		if (Jmemory->Points.pt[met].f10.port==(5+PortBegNum))
//			pt3++;
		if (JSetPara_AFN04_3761_2009->group2.f10[met].port==(30+PortBegNum))
			pt4++;
	}

	SendBuff[SendIndex++] = 1+PortBegNum;	//�ն�ͨ�Ŷ˿ں�
	SendBuff[SendIndex++] = num1&0xff;		//Ҫ����������λ
	SendBuff[SendIndex++] = (num1>>8)&0xff;//Ҫ����������λ
	if(num1==0)
		SendBuff[SendIndex++] = 0x02;
	else
	{
		if(Jdatafileinfo->data485[0+PortBegNum].Flag == 2)
			SendBuff[SendIndex++] = 0x03;//��ǰ��������״̬��־ ���ڳ���
		if(Jdatafileinfo->data485[0+PortBegNum].Flag == 1 || Jdatafileinfo->data485[0+PortBegNum].Flag == 0)
			SendBuff[SendIndex++] = 0x02;//��ǰ��������״̬��־ δ����
	}
	SendBuff[SendIndex++] = Jdatafileinfo->data485[0+PortBegNum].MeterNum_CBSucc & 0xff;//�����ɹ�����
	SendBuff[SendIndex++] = (Jdatafileinfo->data485[0+PortBegNum].MeterNum_CBSucc>>8)&0xff;
	SendBuff[SendIndex++] = pt1&0xff;//���ص���ɹ�����
	//TSGet(&ts);//��ȡʱ��
//	ts.Hour=0;
//	ts.Minute=0;
//	ts.Sec=0;
	ts = Jdatafileinfo->data485[0+PortBegNum].ts_begin;
	SendBuff[SendIndex++] = ((ts.Sec / 10) << 4) + (ts.Sec % 10);
	SendBuff[SendIndex++] = ((ts.Minute / 10) << 4) + (ts.Minute % 10);
	SendBuff[SendIndex++] = ((ts.Hour / 10) << 4) + (ts.Hour % 10);
	SendBuff[SendIndex++] = ((ts.Day / 10) << 4) + (ts.Day % 10);
	if (ts.Week == 0) {
		SendBuff[SendIndex++] = ((ts.Month / 10) << 4) + (ts.Month % 10) + 0xe0;
	} else {
		SendBuff[SendIndex++] = ((ts.Month / 10) << 4) + (ts.Month % 10)
				+ (ts.Week << 5);
	}
	SendBuff[SendIndex++] = (((ts.Year % 100) / 10) << 4) + (ts.Year % 10);
	//TSGet(&ts);//��ȡʱ��
	ts = Jdatafileinfo->data485[0+PortBegNum].ts;
	SendBuff[SendIndex++] = ((ts.Sec / 10) << 4) + (ts.Sec % 10);
	SendBuff[SendIndex++] = ((ts.Minute / 10) << 4) + (ts.Minute % 10);
	SendBuff[SendIndex++] = ((ts.Hour / 10) << 4) + (ts.Hour % 10);
	SendBuff[SendIndex++] = ((ts.Day / 10) << 4) + (ts.Day % 10);
	if (ts.Week == 0) {
		SendBuff[SendIndex++] = ((ts.Month / 10) << 4) + (ts.Month % 10) + 0xe0;
	} else {
		SendBuff[SendIndex++] = ((ts.Month / 10) << 4) + (ts.Month % 10)
				+ (ts.Week << 5);
	}
	SendBuff[SendIndex++] = (((ts.Year % 100) / 10) << 4) + (ts.Year % 10);


	SendBuff[SendIndex++] = 2+PortBegNum;//�ն�ͨ�Ŷ˿ں�
	SendBuff[SendIndex++] = num2&0xff;//Ҫ����������λ
	SendBuff[SendIndex++] = (num2>>8)&0xff;//Ҫ����������λ
	if(num2==0)
		SendBuff[SendIndex++] = 0x02;
	else
	{
		if(Jdatafileinfo->data485[1+PortBegNum].Flag == 2)
			SendBuff[SendIndex++] = 0x03;//��ǰ��������״̬��־ ���ڳ���
		if(Jdatafileinfo->data485[1+PortBegNum].Flag == 1 || Jdatafileinfo->data485[1+PortBegNum].Flag == 0)
			SendBuff[SendIndex++] = 0x02;//��ǰ��������״̬��־ δ����
	}
	SendBuff[SendIndex++] = Jdatafileinfo->data485[1+PortBegNum].MeterNum_CBSucc&0xff;//�����ɹ�����
	SendBuff[SendIndex++] = (Jdatafileinfo->data485[1+PortBegNum].MeterNum_CBSucc>>8)&0xff;
	SendBuff[SendIndex++] = pt2&0xff;//���ص���ɹ�����

	//TSGet(&ts);//��ȡʱ��
//	ts.Hour=0;
//	ts.Minute=0;
//	ts.Sec=0;
	ts = Jdatafileinfo->data485[1+PortBegNum].ts_begin;
	SendBuff[SendIndex++] = ((ts.Sec / 10) << 4) + (ts.Sec % 10);
	SendBuff[SendIndex++] = ((ts.Minute / 10) << 4) + (ts.Minute % 10);
	SendBuff[SendIndex++] = ((ts.Hour / 10) << 4) + (ts.Hour % 10);
	SendBuff[SendIndex++] = ((ts.Day / 10) << 4) + (ts.Day % 10);
	if (ts.Week == 0) {
		SendBuff[SendIndex++] = ((ts.Month / 10) << 4) + (ts.Month % 10) + 0xe0;
	} else {
		SendBuff[SendIndex++] = ((ts.Month / 10) << 4) + (ts.Month % 10)
				+ (ts.Week << 5);
	}
	SendBuff[SendIndex++] = (((ts.Year % 100) / 10) << 4) + (ts.Year % 10);
	//TSGet(&ts);//��ȡʱ��
	ts = Jdatafileinfo->data485[1+PortBegNum].ts;
	SendBuff[SendIndex++] = ((ts.Sec / 10) << 4) + (ts.Sec % 10);
	SendBuff[SendIndex++] = ((ts.Minute / 10) << 4) + (ts.Minute % 10);
	SendBuff[SendIndex++] = ((ts.Hour / 10) << 4) + (ts.Hour % 10);
	SendBuff[SendIndex++] = ((ts.Day / 10) << 4) + (ts.Day % 10);
	if (ts.Week == 0) {
		SendBuff[SendIndex++] = ((ts.Month / 10) << 4) + (ts.Month % 10) + 0xe0;
	} else {
		SendBuff[SendIndex++] = ((ts.Month / 10) << 4) + (ts.Month % 10)
				+ (ts.Week << 5);
	}
	SendBuff[SendIndex++] = (((ts.Year % 100) / 10) << 4) + (ts.Year % 10);

	//68 7A 01 7A 01 68 88 02 35 01 00 02 0C E5
	//00 00 04 01 //04
	//02 00 00 02 00 00 00 00 00 00 00 E0 00 00 00 00 00 E0 00
	//03 00 00 02 00 00 00 00 00 00 00 E0 00 00 00 00 00 E0 00
	//06 01 00 00 00 00 02 00 17 01 30 12 18 00 17 01 30 12 1F
	//00 00 02 00 00 00 00 00 00 00 E0 00 00 00 00 00 E0 00 05 54 33 18 13 00 B2 16

	SendBuff[SendIndex++] = 30+PortBegNum;//�ն�ͨ�Ŷ˿ں�
	SendBuff[SendIndex++] = num4&0xff;//Ҫ����������λ
	SendBuff[SendIndex++] = (num4>>8)&0xff;//Ҫ����������λ
	if(num4==0)
		SendBuff[SendIndex++] = 0x02;
	else
	{
		if(Jdatafileinfo->data485[29+PortBegNum].Flag == 2)
			SendBuff[SendIndex++] = 0x03;//��ǰ��������״̬��־ ���ڳ���
		if(Jdatafileinfo->data485[29+PortBegNum].Flag == 1|| Jdatafileinfo->data485[29+PortBegNum].Flag == 0)
			SendBuff[SendIndex++] = 0x02;//��ǰ��������״̬��־ δ����
	}
	SendBuff[SendIndex++] = Jdatafileinfo->data485[29+PortBegNum].MeterNum_CBSucc&0xff;//�����ɹ�����
	SendBuff[SendIndex++] = (Jdatafileinfo->data485[29+PortBegNum].MeterNum_CBSucc>>8)&0xff;
	SendBuff[SendIndex++] = pt4&0xff;//���ص���ɹ�����

	//TSGet(&ts);//��ȡʱ��
//	ts.Hour=0;
//	ts.Minute=0;
//	ts.Sec=0;
	ts = Jdatafileinfo->data485[29+PortBegNum].ts_begin;
	SendBuff[SendIndex++] = ((ts.Sec / 10) << 4) + (ts.Sec % 10);
	SendBuff[SendIndex++] = ((ts.Minute / 10) << 4) + (ts.Minute % 10);
	SendBuff[SendIndex++] = ((ts.Hour / 10) << 4) + (ts.Hour % 10);
	SendBuff[SendIndex++] = ((ts.Day / 10) << 4) + (ts.Day % 10);
	if (ts.Week == 0) {
		SendBuff[SendIndex++] = ((ts.Month / 10) << 4) + (ts.Month % 10) + 0xe0;
	} else {
		SendBuff[SendIndex++] = ((ts.Month / 10) << 4) + (ts.Month % 10)
				+ (ts.Week << 5);
	}
	SendBuff[SendIndex++] = (((ts.Year % 100) / 10) << 4) + (ts.Year % 10);
	//TSGet(&ts);//��ȡʱ��
	ts = Jdatafileinfo->data485[29+PortBegNum].ts;
	SendBuff[SendIndex++] = ((ts.Sec / 10) << 4) + (ts.Sec % 10);
	SendBuff[SendIndex++] = ((ts.Minute / 10) << 4) + (ts.Minute % 10);
	SendBuff[SendIndex++] = ((ts.Hour / 10) << 4) + (ts.Hour % 10);
	SendBuff[SendIndex++] = ((ts.Day / 10) << 4) + (ts.Day % 10);
	if (ts.Week == 0) {
		SendBuff[SendIndex++] = ((ts.Month / 10) << 4) + (ts.Month % 10) + 0xe0;
	} else {
		SendBuff[SendIndex++] = ((ts.Month / 10) << 4) + (ts.Month % 10)
				+ (ts.Week << 5);
	}
	SendBuff[SendIndex++] = (((ts.Year % 100) / 10) << 4) + (ts.Year % 10);

//	if (AutoFlg==0)
//	{
//		EC();
//		TP();
//		FrameTailCreate_Send(0);//���ͱ���β��������
//	}
	return 1;
}


void Create_Data_Type05(float value,INT8U *Data)
{
	int temp,fflag=0;
	INT8U BCD_shifen,BCD_ge,BCD_shi,BCD_bai;
	if (value<0)
	{
		value = value * -1;
		fflag = 1;
	}
	temp = value * 10;
	BCD_shifen = temp%10;      	//ʮ��λ
	temp = value;
	BCD_ge = temp%10;         	//��λ
	BCD_shi = (temp/10)%10;		//ʮλ
	BCD_bai = (temp/100)%10;  	//�ٷ�λ
	Data[0] = (BCD_ge << 4 ) | BCD_shifen;
	Data[1] = (BCD_bai << 4) | BCD_shi;
	if (fflag==1)
		Data[1] = Data[1] | 0x80;
	return;
}
INT16U Level1Data_F12_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//�ز�ģ�����汾��
{
	//if (AutoFlg==0)
		//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));//����1�����ݵı���ͷ
	Create_Data_Type05(-116.2, &SendBuff[SendIndex]);//������
	SendIndex = SendIndex + 2;
	if (AutoFlg!=0)
		return 1;
	//	EC();
	//TP();
	//FrameTailCreate_Send(0);//���ͱ���β��������
	return 1;
}
//��ȡ��������й������޹������ݣ����������Detect_pointNum������ţ�Postive_flag�������־��is_youGong�й��޹����ʱ�־
INT32S Calculate_total_GongLv(INT8U Detect_pointNum, INT16U Postive_flag,
		INT8U is_youGong) {
	INT32S _result = 0;//�������ݵ�ֵ
	INT8U temp_result[4],i;//��ǰһ����������й����ʣ�2���ֽ�
	//��ʼ��ȡ��ǰ�й���������
	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
	Jproginfo->RealData.CaijiqiNo
			= JSetPara_AFN04_3761_2009->group2.f10[Detect_pointNum].CjqNo-1;//�ɼ�����
	Jproginfo->RealData.MeterNo
			= JSetPara_AFN04_3761_2009->group2.f10[Detect_pointNum].MeterNo;//SD����
	LDType=2;
	memset(temp_result,0x00,4);
	if (is_youGong)//��ȡ��������й��������ݣ���ӦF17��ȡ����
	{
		if (!Postive_flag) {
			SetDataFlag97(0xb6, 0x30, Jproginfo->RealData.flg97[0].flg.Dataflag); //˲ʱ�����й�����
		} else {
			SetDataFlag97(0xb6, 0x30, Jproginfo->RealData.flg97[0].flg.Dataflag); //˲ʱ�����й�����
		}
	} else//��ȡ��������޹��������ݣ���ӦF18��ȡ����
	{
		if (!Postive_flag) {
			SetDataFlag97(0xb6, 0x40, Jproginfo->RealData.flg97[0].flg.Dataflag); //˲ʱ�����޹�����
		} else {
			SetDataFlag97(0xb6, 0x40, Jproginfo->RealData.flg97[0].flg.Dataflag); //˲ʱ�����޹�����
		}
	}
	Jproginfo->RealData.CurFlgCount = 1;
	//Jproginfo->RealData.ReadFlg = 0;
	/*while(Jproginfo->RealData.ReadFlg!=9){
	 delay(50);
	 }*/
	int delay = 4;
	if (Jproginfo->RealData.CurFlgCount < 20)
		delay = Jproginfo->RealData.CurFlgCount * 3;
	else
		delay = 40;
	if (delay < 10)
		delay = 10;
	if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,
				sizeof(Jproginfo->RealData));
		memcpy(&temp_result[0], &tempRealTimeData.flg97[0].datas[0], 4);//ȡ�����ݽ��xxxxxx.xx
	} else {
		//memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
		//memcpy(&temp_result[0], &tempRealTimeData.flg97[0].datas[0], 4);//ȡ�����ݽ��xxxxxx.xx
	}
    Jproginfo->RealData.ReadFlg=0;

    if (is_youGong)
	{
		for(i=0;i<3;i++)
			if (temp_result[i]==OxXX)
				temp_result[i]=0x00;
		_result=BCD_INT32(&temp_result[0],3);
		SdPrintf(YNPrint,PreFix,"\n\r_result=%d\n\r",_result);
	}
	else
	{
		for(i=0;i<2;i++)
			if (temp_result[i]==OxXX)
				temp_result[i]=0x00;
		_result=BCD_INT32(&temp_result[0],3);
		SdPrintf(YNPrint,PreFix,"\n\r_result=%d\n\r",_result);
	}

	return _result;//���ط������ĺ�����ݽ��
}

INT16U Level1Data_F17_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ�ܼ��й�����
{
	INT8U tmp_i = P - 1;//��ʱ��ѭ������
	INT8U tmp_j;
	FP64 youGong_result = 0.0;//��ǰ���й�����
	INT8U Detect_pointNum;//�������
	INT8U Postive_flag; //����/�����й����� 0:����1:����
	INT8U Sub_flag; //��/���������־ 0:�ӣ�1:��
	INT8U type2Msg[2];
	memset(type2Msg,0x00,2);
	for (tmp_j = 0; tmp_j < JSetPara_AFN04_3761_2009->group2.f14.Group[tmp_i].PointNum; tmp_j++)//�Թ����ڴ���������ò�����������з���
	{
		Detect_pointNum = (JSetPara_AFN04_3761_2009->group2.f14.Group[tmp_i].Index_Flag[tmp_j])
				& 0x3f; //D0~D5
		Postive_flag = (JSetPara_AFN04_3761_2009->group2.f14.Group[tmp_i].Index_Flag[tmp_j]) >> 6
				& 0x01; //D6
		Sub_flag = (JSetPara_AFN04_3761_2009->group2.f14.Group[tmp_i].Index_Flag[tmp_j]) >> 7
				& 0x01; //D7

		if (!Sub_flag) {
			youGong_result += Calculate_total_GongLv(Detect_pointNum,
					Postive_flag, 1);
		} else {
			youGong_result -= Calculate_total_GongLv(Detect_pointNum,
					Postive_flag, 1);
		}
	}
	SdPrintf(YNPrint,PreFix,"youGong_result=%f\n\r",youGong_result);
	Double2TypeA2(youGong_result, type2Msg);

	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));//����1�����ݵı���ͷ

	memcpy(&SendBuff[SendIndex], &type2Msg[0], 2);
	SendIndex = SendIndex + 2;

//	EC();
//	TP();
//	FrameTailCreate_Send(0);//���ͱ���β��������
	return 1;
}

INT16U Level1Data_F18_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ�ܼ��޹�����
{
	INT8U tmp_i = P - 1;//��ʱ��ѭ������
	INT8U tmp_j;
	FP64 youGong_result = 0.0; //��ǰ���޹�����
	INT8U Detect_pointNum; //�������
	INT8U Postive_flag; //����/�����й����� 0:����1:����
	INT8U Sub_flag; //��/���������־ 0:�ӣ�1:��
	INT8U type2Msg[2];
	memset(type2Msg,0x00,2);
	for (tmp_j = 0; tmp_j < JSetPara_AFN04_3761_2009->group2.f14.Group[tmp_i].PointNum; tmp_j++)//�Թ����ڴ���������ò�����������з���
	{
		Detect_pointNum = (JSetPara_AFN04_3761_2009->group2.f14.Group[tmp_i].Index_Flag[tmp_j])
				& 0x3f; //D0~D5
		Postive_flag = (JSetPara_AFN04_3761_2009->group2.f14.Group[tmp_i].Index_Flag[tmp_j]) >> 6
				& 0x01; //D6
		Sub_flag = (JSetPara_AFN04_3761_2009->group2.f14.Group[tmp_i].Index_Flag[tmp_j]) >> 7
				& 0x01; //D7

		if (!Sub_flag) {
			youGong_result += Calculate_total_GongLv(Detect_pointNum,
					Postive_flag, 0);
		} else {
			youGong_result -= Calculate_total_GongLv(Detect_pointNum,
					Postive_flag, 0);
		}
	}
	SdPrintf(YNPrint,PreFix,"youGong_result=%f\n\r",youGong_result);
	Double2TypeA2(youGong_result, type2Msg);//ת�����ݸ�ʽ2����

	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));//����1�����ݵı���ͷ

	memcpy(&SendBuff[SendIndex], &type2Msg[0], 2);
	SendIndex = SendIndex + 2;

//	EC();
//	TP();
//	FrameTailCreate_Send(0);//���ͱ���β��������
	return 1;
}

//added by mqingkui
INT16U Level1Data_F25_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ���༰����/�޹����ʡ����������������ѹ��������������������ڹ���
{
	TS ts;
	int i;
	SdPrintf(YNPrint,PreFix,"Level1Data_F25_Get set:%02x F:%02x P:%02x \n", Set, F, P);
	SdPrintf(YNPrint,PreFix,"JSetPara_AFN04_3761_2009->group2.f10[P-1].ConnectType=%d  JSetPara_AFN04_3761_2009->group2.f10[P-1].port=%d\n",JSetPara_AFN04_3761_2009->group2.f10[P-1].ConnectType,JSetPara_AFN04_3761_2009->group2.f10[P-1].port);
	if(JSetPara_AFN04_3761_2009->group2.f10[P-1].ConnectType==2 && JSetPara_AFN04_3761_2009->group2.f10[P-1].port==1)
	{
		//���ڴ����
		SdPrintf(YNPrint,PreFix,"-----------Level1Data_Curr_F25_Get  JC from memory----------------------------------------\n");
		SetDataFlag97(0xb6, 0x30, Jproginfo->RealData.flg97[0].flg.Dataflag);
		SetDataFlag97(0xb6, 0x31, Jproginfo->RealData.flg97[1].flg.Dataflag);
		SetDataFlag97(0xb6, 0x32, Jproginfo->RealData.flg97[2].flg.Dataflag);
		SetDataFlag97(0xb6, 0x33, Jproginfo->RealData.flg97[3].flg.Dataflag);

		SetDataFlag97(0xb6, 0x40, Jproginfo->RealData.flg97[4].flg.Dataflag);
		SetDataFlag97(0xb6, 0x41, Jproginfo->RealData.flg97[5].flg.Dataflag);
		SetDataFlag97(0xb6, 0x42, Jproginfo->RealData.flg97[6].flg.Dataflag);
		SetDataFlag97(0xb6, 0x43, Jproginfo->RealData.flg97[7].flg.Dataflag);

		SetDataFlag97(0xb6, 0x50, Jproginfo->RealData.flg97[8].flg.Dataflag);
		SetDataFlag97(0xb6, 0x51, Jproginfo->RealData.flg97[9].flg.Dataflag);
		SetDataFlag97(0xb6, 0x52, Jproginfo->RealData.flg97[10].flg.Dataflag);
		SetDataFlag97(0xb6, 0x53, Jproginfo->RealData.flg97[11].flg.Dataflag);

		SetDataFlag97(0xb6, 0x11, Jproginfo->RealData.flg97[12].flg.Dataflag);
		SetDataFlag97(0xb6, 0x12, Jproginfo->RealData.flg97[13].flg.Dataflag);
		SetDataFlag97(0xb6, 0x13, Jproginfo->RealData.flg97[14].flg.Dataflag);
		SetDataFlag97(0xb6, 0x21, Jproginfo->RealData.flg97[15].flg.Dataflag);
		SetDataFlag97(0xb6, 0x22, Jproginfo->RealData.flg97[16].flg.Dataflag);
		SetDataFlag97(0xb6, 0x23, Jproginfo->RealData.flg97[17].flg.Dataflag);

		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.P, &Jproginfo->RealData.flg97[0].datas[0],3);
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.PA, &Jproginfo->RealData.flg97[1].datas[0],3);
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.PB, &Jproginfo->RealData.flg97[2].datas[0],3);
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.PC, &Jproginfo->RealData.flg97[3].datas[0],3);

		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.Q, &Jproginfo->RealData.flg97[4].datas[0],3);
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.QA, &Jproginfo->RealData.flg97[5].datas[0],3);
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.QB, &Jproginfo->RealData.flg97[6].datas[0],3);
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.QC, &Jproginfo->RealData.flg97[7].datas[0],3);

		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.Cos, &Jproginfo->RealData.flg97[8].datas[0],2);
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.CosA, &Jproginfo->RealData.flg97[9].datas[0],2);
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.CosB, &Jproginfo->RealData.flg97[10].datas[0],2);
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.CosC, &Jproginfo->RealData.flg97[11].datas[0],2);

		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.VA, &Jproginfo->RealData.flg97[12].datas[0],2);
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.VB, &Jproginfo->RealData.flg97[13].datas[0],2);
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.VC, &Jproginfo->RealData.flg97[14].datas[0],2);
//		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.IA*10, &Jproginfo->RealData.flg97[15].datas[0],3);
//		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.IB*10, &Jproginfo->RealData.flg97[16].datas[0],3);
//		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.IC*10, &Jproginfo->RealData.flg97[17].datas[0],3);
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.IA, &Jproginfo->RealData.flg97[15].datas[0],3);//LQQ
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.IB, &Jproginfo->RealData.flg97[16].datas[0],3);//LQQ
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.IC, &Jproginfo->RealData.flg97[17].datas[0],3);//LQQ
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.IL, &Jproginfo->RealData.flg97[18].datas[0],3);//LQQ

		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.S, &Jproginfo->RealData.flg97[19].datas[0],3);
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.SA, &Jproginfo->RealData.flg97[20].datas[0],3);
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.SB, &Jproginfo->RealData.flg97[21].datas[0],3);
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.SC, &Jproginfo->RealData.flg97[22].datas[0],3);
		Jproginfo->RealData.CurFlgCount = 23;
		for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		{
				SdPrintf(YNPrint,PreFix,"i: %d   datas[0] %02x %02x %02x %02x \n",
						i,
						Jproginfo->RealData.flg97[i].datas[0],
						Jproginfo->RealData.flg97[i].datas[1],
						Jproginfo->RealData.flg97[i].datas[2],
						Jproginfo->RealData.flg97[i].datas[3]);
		}
		TSGet(&ts);
//		//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
		INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[0].datas[0], 3);
		SendIndex = SendIndex + 3;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[1].datas[0], 3);
		SendIndex = SendIndex + 3;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[2].datas[0], 3);
		SendIndex = SendIndex + 3;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[3].datas[0], 3);
		SendIndex = SendIndex + 3;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[4].datas[0], 3);
		SendIndex = SendIndex + 3;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[5].datas[0], 3);
		SendIndex = SendIndex + 3;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[6].datas[0], 3);
		SendIndex = SendIndex + 3;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[7].datas[0], 3);
		SendIndex = SendIndex + 3;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[8].datas[0], 2);
		SendIndex = SendIndex + 2;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[9].datas[0], 2);
		SendIndex = SendIndex + 2;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[10].datas[0], 2);
		SendIndex = SendIndex + 2;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[11].datas[0], 2);
		SendIndex = SendIndex + 2;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[12].datas[0], 2);
		SendIndex = SendIndex + 2;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[13].datas[0], 2);
		SendIndex = SendIndex + 2;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[14].datas[0], 2);
		SendIndex = SendIndex + 2;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[15].datas[0], 3);
		SendIndex = SendIndex + 3;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[16].datas[0], 3);
		SendIndex = SendIndex + 3;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[17].datas[0], 3);
		SendIndex = SendIndex + 3;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[18].datas[0], 3);//�������
		SendIndex = SendIndex + 3;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[19].datas[0], 3);
		SendIndex = SendIndex + 3;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[20].datas[0], 3);
		SendIndex = SendIndex + 3;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[21].datas[0], 3);
		SendIndex = SendIndex + 3;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[22].datas[0], 3);
		SendIndex = SendIndex + 3;
	}else
	{
	INT8U CJQno, Meterno,i,MeterType;
	TS ts;
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	Meterno = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
	Jproginfo->RealData.CaijiqiNo = CJQno;//�ɼ�����
	Jproginfo->RealData.MeterNo = Meterno;//SD����
	SetDataFlag97(0xb6, 0x3f, Jproginfo->RealData.flg97[0].flg.Dataflag); //���й�����
	if ((MeterType == 9) || (MeterType == 6))
		SetDataFlag97(0xb6, 0x30, Jproginfo->RealData.flg97[0].flg.Dataflag); //���й�����
	else
		SetDataFlag97(0xb6, 0x3f, Jproginfo->RealData.flg97[0].flg.Dataflag); //���й�����
	if ((MeterType == 9) || (MeterType == 6))
		SetDataFlag97(0x00, 0x00, Jproginfo->RealData.flg97[1].flg.Dataflag); //���޹�����
	else
		SetDataFlag97(0xb6, 0x4f, Jproginfo->RealData.flg97[1].flg.Dataflag); //���޹�����
	if ((MeterType == 9) || (MeterType == 6))
		SetDataFlag97(0x00, 0x00, Jproginfo->RealData.flg97[2].flg.Dataflag); //�ܹ�������
	else SetDataFlag97(0xb6, 0x5f, Jproginfo->RealData.flg97[2].flg.Dataflag); //�ܹ�������
	SetDataFlag97(0xb6, 0x11, Jproginfo->RealData.flg97[3].flg.Dataflag);//A���ѹ
	if ((MeterType == 9) || (MeterType == 6))
		SetDataFlag97(0x00, 0x00, Jproginfo->RealData.flg97[4].flg.Dataflag);
	else
		SetDataFlag97(0xb6, 0x12, Jproginfo->RealData.flg97[4].flg.Dataflag);//B���ѹ
	if ((MeterType == 9) || (MeterType == 6))
		SetDataFlag97(0x00, 0x00, Jproginfo->RealData.flg97[5].flg.Dataflag);
	else
		SetDataFlag97(0xb6, 0x13, Jproginfo->RealData.flg97[5].flg.Dataflag);//C���ѹ
	SetDataFlag97(0xb6, 0x21, Jproginfo->RealData.flg97[6].flg.Dataflag);//A�����
	if ((MeterType == 9) || (MeterType == 6))
		SetDataFlag97(0x00, 0x00, Jproginfo->RealData.flg97[7].flg.Dataflag);
	else SetDataFlag97(0xb6, 0x22, Jproginfo->RealData.flg97[7].flg.Dataflag);//B�����

	if ((MeterType == 9) || (MeterType == 6))
		SetDataFlag97(0x00, 0x00, Jproginfo->RealData.flg97[8].flg.Dataflag);
	else SetDataFlag97(0xb6, 0x23, Jproginfo->RealData.flg97[8].flg.Dataflag);//C�����

	if ((MeterType == 9) || (MeterType == 6))
		SetDataFlag97(0x00, 0x00, Jproginfo->RealData.flg97[9].flg.Dataflag);
	else SetDataFlag97(0x00, 0x31, Jproginfo->RealData.flg97[9].flg.Dataflag);//�������--

	if ((MeterType == 9) || (MeterType == 6))
		SetDataFlag97(0x00, 0x00, Jproginfo->RealData.flg97[10].flg.Dataflag);
	else SetDataFlag97(0x00, 0x5f, Jproginfo->RealData.flg97[10].flg.Dataflag);//�����ڹ���--
	Jproginfo->RealData.CurFlgCount = 11;
	for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);

	int delay = 4;
	if (Jproginfo->RealData.CurFlgCount < 20)
		delay = Jproginfo->RealData.CurFlgCount * 3;
	else
		delay = 40;
	if (delay < 10)
		delay = 10;
	if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
	} else {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
	}
    Jproginfo->RealData.ReadFlg=0;
	TSGet(&ts);
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[0].datas[0], 12);
	SendIndex = SendIndex + 12;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[1].datas[0], 12);
	SendIndex = SendIndex + 12;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[2].datas[0], 8);
	SendIndex = SendIndex + 8;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[3].datas[0], 2);
	SendIndex = SendIndex + 2;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[4].datas[0], 2);
	SendIndex = SendIndex + 2;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[5].datas[0], 2);
	SendIndex = SendIndex + 2;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[6].datas[0], 3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[7].datas[0], 3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[8].datas[0], 3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[9].datas[0], 3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[10].datas[0], 12);
	SendIndex = SendIndex + 12;
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 1;
}

INT16U Level1Data_F26_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//A��B��C�������ͳ�����ݼ����һ�ζ����¼
{
	INT8U CJQno, Meterno,i,dsj=0;
	TS ts;
	INT32U tmp;

	SdPrintf(YNPrint,PreFix, " Go Leverl1Data_F26_Get!!!!!!!!!!\n");
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	Meterno = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
	Jproginfo->RealData.CaijiqiNo = CJQno;//�ɼ�����
	Jproginfo->RealData.MeterNo = Meterno;//SD����
	SetDataFlag97(0xb3, 0x10, Jproginfo->RealData.flg97[0].flg.Dataflag); //�ܶ������
	SetDataFlag97(0xb3, 0x11, Jproginfo->RealData.flg97[1].flg.Dataflag); //A��������
	SetDataFlag97(0xb3, 0x12, Jproginfo->RealData.flg97[2].flg.Dataflag); //B��������
	SetDataFlag97(0xb3, 0x13, Jproginfo->RealData.flg97[3].flg.Dataflag); //C��������
	SetDataFlag97(0xb3, 0x20, Jproginfo->RealData.flg97[4].flg.Dataflag); //�ܶ����ۼ�ʱ��
	SetDataFlag97(0xb3, 0x21, Jproginfo->RealData.flg97[5].flg.Dataflag); //A������ۼ�ʱ��
	SetDataFlag97(0xb3, 0x22, Jproginfo->RealData.flg97[6].flg.Dataflag); //B������ۼ�ʱ��
	SetDataFlag97(0xb3, 0x23, Jproginfo->RealData.flg97[7].flg.Dataflag); //C������ۼ�ʱ��
	SetDataFlag97(0xb3, 0x30, Jproginfo->RealData.flg97[8].flg.Dataflag);
	SetDataFlag97(0xb3, 0x31, Jproginfo->RealData.flg97[9].flg.Dataflag); //A�����������ʼʱ��
	SetDataFlag97(0xb3, 0x32, Jproginfo->RealData.flg97[10].flg.Dataflag); //B�����������ʼʱ��
	SetDataFlag97(0xb3, 0x33, Jproginfo->RealData.flg97[11].flg.Dataflag);//C�����������ʼʱ��
	SetDataFlag97(0xb3, 0x40, Jproginfo->RealData.flg97[12].flg.Dataflag);
	SetDataFlag97(0xb3, 0x41, Jproginfo->RealData.flg97[13].flg.Dataflag);//A������������ʱ��
	SetDataFlag97(0xb3, 0x42, Jproginfo->RealData.flg97[14].flg.Dataflag);//B������������ʱ��
	SetDataFlag97(0xb3, 0x43, Jproginfo->RealData.flg97[15].flg.Dataflag);//C������������ʱ��
	Jproginfo->RealData.CurFlgCount = 16;
	//Jproginfo->RealData.ReadFlg = 0;
	for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);

	int delay = 4;
	if (Jproginfo->RealData.CurFlgCount < 20)
		delay = Jproginfo->RealData.CurFlgCount * 3;
	else
		delay = 40;
	if (delay < 10)
		delay = 10;
	if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,
				sizeof(Jproginfo->RealData));
	} else {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
	}
    Jproginfo->RealData.ReadFlg=0;
	TSGet(&ts);
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	if (JSetPara_AFN04_3761_2009->group2.f10[P-1].ConnectType==30)
	{
		tmp=BCD_INT32(&tempRealTimeData.flg97[1].datas[0],2)+BCD_INT32(&tempRealTimeData.flg97[2].datas[0],2)+BCD_INT32(&tempRealTimeData.flg97[3].datas[0],2);

		INT32U_BCD(tmp,&SendBuff[SendIndex],2);
	}
	else
		memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[0].datas[0], 2);
	SendIndex = SendIndex + 2;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[1].datas[0], 2);
	SendIndex = SendIndex + 2;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[2].datas[0], 2);
	SendIndex = SendIndex + 2;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[3].datas[0], 2);
	SendIndex = SendIndex + 2;

	if (JSetPara_AFN04_3761_2009->group2.f10[P-1].ConnectType==30)
	{
		tmp=BCD_INT32(&tempRealTimeData.flg97[5].datas[0],3)+BCD_INT32(&tempRealTimeData.flg97[6].datas[0],3)+BCD_INT32(&tempRealTimeData.flg97[7].datas[0],3);

		INT32U_BCD(tmp,&SendBuff[SendIndex],3);
	}
	else
		memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[4].datas[0], 3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[5].datas[0], 3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[6].datas[0], 3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[7].datas[0], 3);
	SendIndex = SendIndex + 3;

	dsj=0;
	if (JSetPara_AFN04_3761_2009->group2.f10[P-1].ConnectType==30)
	{
		dsj=1;
		tmp=BCD_INT32(&tempRealTimeData.flg97[9].datas[1],4);
		if (BCD_INT32(&tempRealTimeData.flg97[10].datas[1],4)>tmp)
		{
			tmp=BCD_INT32(&tempRealTimeData.flg97[10].datas[1],4);
			dsj=2;
		}
		if (BCD_INT32(&tempRealTimeData.flg97[11].datas[1],4)>tmp)
		{
			tmp=BCD_INT32(&tempRealTimeData.flg97[11].datas[1],4);
			dsj=3;
		}
		if (dsj==1)
		{
			memcpy(&SendBuff[SendIndex],&tempRealTimeData.flg97[9].datas[1],4);
		}
		if (dsj==2)
		{
			memcpy(&SendBuff[SendIndex],&tempRealTimeData.flg97[10].datas[1],4);
		}
		if (dsj==3)
		{
			memcpy(&SendBuff[SendIndex],&tempRealTimeData.flg97[11].datas[1],4);
		}
	}
	else memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[8].datas[1], 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[9].datas[1], 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[10].datas[1], 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[11].datas[1], 4);
	SendIndex = SendIndex + 4;

	dsj=0;
	if (JSetPara_AFN04_3761_2009->group2.f10[P-1].ConnectType==30)
	{
		dsj=1;
		tmp=BCD_INT32(&tempRealTimeData.flg97[13].datas[1],4);
		if (BCD_INT32(&tempRealTimeData.flg97[14].datas[1],4)>tmp)
		{
			tmp=BCD_INT32(&tempRealTimeData.flg97[14].datas[1],4);
			dsj=2;
		}
		if (BCD_INT32(&tempRealTimeData.flg97[15].datas[1],4)>tmp)
		{
			tmp=BCD_INT32(&tempRealTimeData.flg97[15].datas[1],4);
			dsj=3;
		}
		if (dsj==1)
		{
			memcpy(&SendBuff[SendIndex],&tempRealTimeData.flg97[13].datas[1],4);
		}
		if (dsj==2)
		{
			memcpy(&SendBuff[SendIndex],&tempRealTimeData.flg97[14].datas[1],4);
		}
		if (dsj==3)
		{
			memcpy(&SendBuff[SendIndex],&tempRealTimeData.flg97[15].datas[1],4);
		}
	}
	else memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[12].datas[1], 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[13].datas[1], 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[14].datas[1], 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[15].datas[1], 4);
	SendIndex = SendIndex + 4;

//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 1;
}

//added by mqingkui
INT16U Level1Data_F27_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���ܱ�����ʱ�ӡ���̴����������һ�β���ʱ��
{
	SdPrintf(YNPrint,PreFix,"Level1Data_F27_Get Set %d F %d P %d", Set, F, P);
	INT8U CJQno, Meterno,i;
	TS ts;
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	Meterno = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
	Jproginfo->RealData.CaijiqiNo = CJQno;
	Jproginfo->RealData.MeterNo = Meterno;
	SetDataFlag97(0xc0, 0x10, Jproginfo->RealData.flg97[0].flg.Dataflag);//���ܱ�����ʱ��
	SetDataFlag97(0xc0, 0x11, Jproginfo->RealData.flg97[1].flg.Dataflag);
	SetDataFlag97(0xB2, 0x14, Jproginfo->RealData.flg97[2].flg.Dataflag);//��ع���ʱ��
	SetDataFlag97(0xB2, 0x12, Jproginfo->RealData.flg97[3].flg.Dataflag);//����ܴ���
	SetDataFlag97(0xB2, 0x10, Jproginfo->RealData.flg97[4].flg.Dataflag);//���һ�α�̷���ʱ��
	SetDataFlag97(0x00, 0x44, Jproginfo->RealData.flg97[5].flg.Dataflag);//��������ܴ���--
	SetDataFlag97(0x00, 0x45, Jproginfo->RealData.flg97[6].flg.Dataflag);//���һ�����㷢��ʱ��--
	SetDataFlag97(0xB2, 0x13, Jproginfo->RealData.flg97[7].flg.Dataflag);//���������ܴ���
	SetDataFlag97(0xB2, 0x11, Jproginfo->RealData.flg97[8].flg.Dataflag);//���һ�����㷢��ʱ��
	SetDataFlag97(0x00, 0x40, Jproginfo->RealData.flg97[9].flg.Dataflag);//�¼������ܴ���--
	SetDataFlag97(0x00, 0x41, Jproginfo->RealData.flg97[10].flg.Dataflag);//���һ�����㷢��ʱ��--
	SetDataFlag97(0x00, 0x42, Jproginfo->RealData.flg97[11].flg.Dataflag);//Уʱ�ܴ���--
	SetDataFlag97(0x00, 0x43, Jproginfo->RealData.flg97[12].flg.Dataflag);//���һ��Уʱ����ʱ��--
	Jproginfo->RealData.CurFlgCount = 13;
	//Jproginfo->RealData.ReadFlg = 0;//���ڶ�ȡ״̬
	for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);

	int delay = 4;
	if (Jproginfo->RealData.CurFlgCount < 20)
		delay = Jproginfo->RealData.CurFlgCount * 3;
	else
		delay = 40;
	if (delay < 10)
		delay = 10;
	if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
	} else {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
	}
    Jproginfo->RealData.ReadFlg=0;
	TSGet(&ts);
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[1].datas[0], 3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[0].datas[0]+1, 3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[2].datas[0], 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[3].datas[0], 3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[4].datas[0], 6);
	SendIndex = SendIndex + 6;
	//INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	//SendIndex++;
	//memcpy(&SendBuff[SendIndex],&tempRealTimeData.flg97[4].datas[0],3);
	//SendIndex=SendIndex+3;
	//memcpy(&SendBuff[SendIndex],&tempRealTimeData.flg97[5].datas[0],6);
	//SendIndex=SendIndex+6;

	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[5].datas[0], 3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[6].datas[0], 6);
	SendIndex = SendIndex + 6;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[7].datas[0], 3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[8].datas[0], 6);
	SendIndex = SendIndex + 6;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[9].datas[0], 3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[10].datas[0], 6);
	SendIndex = SendIndex + 6;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[11].datas[0], 3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[12].datas[0], 6);
	SendIndex = SendIndex + 6;

//	EC();
//	TP();
//	FrameTailCreate_Send(0);

	return 1;
}

//added by mqingkui
INT16U Level1Data_F28_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//�������״̬�ּ����λ��־
{
	int CjqNo,MeterNo,MeterType,i;
		INT8U Temp_FilePath[60], tempManyData[DataLenMax],chgflg;
		INT16U StatB[7],Stat[7],StatChg[7],tmp;
		memset(StatChg,0,7*sizeof(INT16U));
		TS ts;
		chgflg=0;
		tmp=0;
		TSGet(&ts);
		CjqNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
		MeterNo=JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
		MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
		memset(&StatB,0,sizeof(StatB));
		memset(&Stat,0,sizeof(Stat));
		//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
		INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
		LDType=2;
		memset(Temp_FilePath,0,60);
		sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",P);
		ReadFile((char *) Temp_FilePath, &smfile,sizeof(SMFiles),Jproginfo);

		if(smfile.sm.CaijiQiNo==CjqNo&&smfile.sm.MeterNo==MeterNo)
		{
			memset(tempManyData,0,sizeof(tempManyData));
			GetManyData(0,smfile.sm.datas,&tempManyData[0],0xc0,0x20);
			memcpy(&StatB[0],&tempManyData[0],2);
			memset(tempManyData,0,sizeof(tempManyData));
			GetManyData(0,smfile.sm.datas,&tempManyData[0],0xc0,0x21);
			memcpy(&StatB[1],&tempManyData[0],2);
			memset(tempManyData,0,sizeof(tempManyData));
			GetManyData(0,smfile.sm.datas,&tempManyData[0],0x00,0x63);
			memcpy(&StatB[2],&tempManyData[0],2);
			memset(tempManyData,0,sizeof(tempManyData));
			GetManyData(0,smfile.sm.datas,&tempManyData[0],0x00,0x64);
			memcpy(&StatB[3],&tempManyData[0],2);
			memset(tempManyData,0,sizeof(tempManyData));
			GetManyData(0,smfile.sm.datas,&tempManyData[0],0x00,0x65);
			memcpy(&StatB[4],&tempManyData[0],2);
			memset(tempManyData,0,sizeof(tempManyData));
			GetManyData(0,smfile.sm.datas,&tempManyData[0],0x00,0x66);
			memcpy(&StatB[5],&tempManyData[0],2);
			memset(tempManyData,0,sizeof(tempManyData));
			GetManyData(0,smfile.sm.datas,&tempManyData[0],0x00,0x67);
			memcpy(&StatB[6],&tempManyData[0],2);
		}

		memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
		Jproginfo->RealData.CaijiqiNo = CjqNo;
		Jproginfo->RealData.MeterNo = MeterNo;
		SetDataFlag97(0xc0, 0x20, Jproginfo->RealData.flg97[0].flg.Dataflag);//�������״̬��1 o
		SetDataFlag97(0xc0, 0x21, Jproginfo->RealData.flg97[1].flg.Dataflag);//�������״̬��2--
		SetDataFlag97(0x00, 0x63, Jproginfo->RealData.flg97[2].flg.Dataflag);//�������״̬��3--
		SetDataFlag97(0x00, 0x64, Jproginfo->RealData.flg97[3].flg.Dataflag);//�������״̬��4--
		SetDataFlag97(0x00, 0x65, Jproginfo->RealData.flg97[4].flg.Dataflag);//�������״̬��5--
		SetDataFlag97(0x00, 0x66, Jproginfo->RealData.flg97[5].flg.Dataflag);//�������״̬��6--
		SetDataFlag97(0x00, 0x67, Jproginfo->RealData.flg97[6].flg.Dataflag);//�������״̬��7--
		Jproginfo->RealData.CurFlgCount = 7;
		//Jproginfo->RealData.ReadFlg = 0;//���ڶ�ȡ״̬
		for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
			memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);

		int delay = 4;
		if (Jproginfo->RealData.CurFlgCount < 20)
			delay = Jproginfo->RealData.CurFlgCount * 3;
		else
			delay = 40;
		if (delay < 10)
			delay = 10;
		if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
			memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,
					sizeof(Jproginfo->RealData));
		} else {
			memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
		}
	    Jproginfo->RealData.ReadFlg=0;
	    for(i=0;i<7;i++)
	    {
	    	if ((tempRealTimeData.flg97[i].datas[0]==OxXX) && (tempRealTimeData.flg97[i].datas[1]==OxXX))
	    	{
	    		tempRealTimeData.flg97[i].datas[0]=0x00;
	    		tempRealTimeData.flg97[i].datas[1]=0x00;
	    	}
			memcpy(&Stat[i],&tempRealTimeData.flg97[i].datas[0],2);
		}
		for (i=0;i<7;i++)
		{
			tmp=CmpOneByte(StatB[i]&0xff,Stat[i]&0xff);
			StatChg[i]=tmp&0xff;
			tmp=CmpOneByte((StatB[i]>>8)&0xff,(Stat[i]>>8)&0xff);
			StatChg[i]=StatChg[i]|(tmp<<8);
			for(i=0;i<7;i++)
			{
				memcpy(&SendBuff[SendIndex],&StatChg[i],2);
				SendIndex=SendIndex+2;
			}
			for(i=0;i<7;i++)
			{
				memcpy(&SendBuff[SendIndex],&Stat[i],2);
				SendIndex=SendIndex+2;
			}
		}

//	EC();
//	TP();
//	FrameTailCreate_Send(0);

	return 1;
}
//376.1lqq+++++++++++<<<<<<<<<<<
INT16U Level1Data_F31_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰA��B��C������/�����й�����ʾֵ������޹�1/2����ʾֵ
{
	INT8U CJQno, Meterno,i,MeterType;
	TS ts;
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	Meterno = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
	Jproginfo->RealData.CaijiqiNo = CJQno;
	Jproginfo->RealData.MeterNo = Meterno;

	SetDataFlag97(0xff, 0xc0, Jproginfo->RealData.flg97[0].flg.Dataflag);//
	SetDataFlag97(0xff, 0xc1, Jproginfo->RealData.flg97[1].flg.Dataflag);//
	SetDataFlag97(0xff, 0xc2, Jproginfo->RealData.flg97[2].flg.Dataflag);//
	SetDataFlag97(0xff, 0xc3, Jproginfo->RealData.flg97[3].flg.Dataflag);//
	SetDataFlag97(0xff, 0xc4, Jproginfo->RealData.flg97[4].flg.Dataflag);//
	SetDataFlag97(0xff, 0xc5, Jproginfo->RealData.flg97[5].flg.Dataflag);//
	SetDataFlag97(0xff, 0xc6, Jproginfo->RealData.flg97[6].flg.Dataflag);//
	SetDataFlag97(0xff, 0xc7, Jproginfo->RealData.flg97[7].flg.Dataflag);//
	SetDataFlag97(0xff, 0xc8, Jproginfo->RealData.flg97[8].flg.Dataflag);//
	SetDataFlag97(0xff, 0xc9, Jproginfo->RealData.flg97[9].flg.Dataflag);//
	SetDataFlag97(0xff, 0xca, Jproginfo->RealData.flg97[10].flg.Dataflag);//
	SetDataFlag97(0xff, 0xcb, Jproginfo->RealData.flg97[11].flg.Dataflag);//
	Jproginfo->RealData.CurFlgCount = 12;
	//Jproginfo->RealData.ReadFlg = 0;//���ڶ�ȡ״̬
	for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);

	int delay = 4;
	if(Jproginfo->RealData.CurFlgCount < 20)
		delay = Jproginfo->RealData.CurFlgCount * 3;
	else
		delay = 40;
	if(delay < 10)
		delay = 10;

	if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg, sizeof(Jproginfo->RealData));
	} else {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg, sizeof(Jproginfo->RealData));
	}

    Jproginfo->RealData.ReadFlg=0;
	TSGet(&ts);
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;

	for(i=0;i<2;i++)
	{
		if ((tempRealTimeData.flg97[i].datas[0]==OxXX) && (tempRealTimeData.flg97[i].datas[1]==OxXX)&&
				(tempRealTimeData.flg97[i].datas[2]==OxXX)&&(tempRealTimeData.flg97[i].datas[3]==OxXX))
			SendBuff[SendIndex++] = OxXX;
		else SendBuff[SendIndex++]=0x00;
		memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[i].datas[0], 4);
		SendIndex = SendIndex + 4;
	}
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[2].datas[0], 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[3].datas[0], 4);
	SendIndex = SendIndex + 4;

	if ((tempRealTimeData.flg97[4].datas[0]==OxXX) && (tempRealTimeData.flg97[4].datas[1]==OxXX)&&
			(tempRealTimeData.flg97[4].datas[2]==OxXX)&&(tempRealTimeData.flg97[4].datas[3]==OxXX))
		SendBuff[SendIndex++] = OxXX;
	else SendBuff[SendIndex++]=0x00;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[4].datas[0], 4);
	SendIndex = SendIndex + 4;
	if ((tempRealTimeData.flg97[5].datas[0]==OxXX) && (tempRealTimeData.flg97[5].datas[1]==OxXX)&&
			(tempRealTimeData.flg97[5].datas[2]==OxXX)&&(tempRealTimeData.flg97[5].datas[3]==OxXX))
		SendBuff[SendIndex++] = OxXX;
	else SendBuff[SendIndex++]=0x00;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[5].datas[0], 4);
	SendIndex = SendIndex + 4;

	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[6].datas[0], 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[7].datas[0], 4);
	SendIndex = SendIndex + 4;

	if ((tempRealTimeData.flg97[8].datas[0]==OxXX) && (tempRealTimeData.flg97[8].datas[1]==OxXX)&&
			(tempRealTimeData.flg97[8].datas[2]==OxXX)&&(tempRealTimeData.flg97[8].datas[3]==OxXX))
		SendBuff[SendIndex++] = OxXX;
	else SendBuff[SendIndex++]=0x00;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[8].datas[0], 4);
	SendIndex = SendIndex + 4;
	if ((tempRealTimeData.flg97[9].datas[0]==OxXX) && (tempRealTimeData.flg97[9].datas[1]==OxXX)&&
			(tempRealTimeData.flg97[9].datas[2]==OxXX)&&(tempRealTimeData.flg97[9].datas[3]==OxXX))
		SendBuff[SendIndex++] = OxXX;
	else SendBuff[SendIndex++]=0x00;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[9].datas[0], 4);
	SendIndex = SendIndex + 4;

	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[10].datas[0], 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[11].datas[0], 4);
	SendIndex = SendIndex + 4;

//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 1;
}
INT16U Level1Data_F32_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��һ������A��B��C������/�����й�����ʾֵ������޹�1/2����ʾֵ
{
	INT8U CJQno, Meterno,i,MeterType;
	TS ts;
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	Meterno = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
	Jproginfo->RealData.CaijiqiNo = CJQno;
	Jproginfo->RealData.MeterNo = Meterno;

	SetDataFlag97(0xff, 0xd0, Jproginfo->RealData.flg97[0].flg.Dataflag);//
	SetDataFlag97(0xff, 0xd1, Jproginfo->RealData.flg97[1].flg.Dataflag);//
	SetDataFlag97(0xff, 0xd2, Jproginfo->RealData.flg97[2].flg.Dataflag);//
	SetDataFlag97(0xff, 0xd3, Jproginfo->RealData.flg97[3].flg.Dataflag);//
	SetDataFlag97(0xff, 0xd4, Jproginfo->RealData.flg97[4].flg.Dataflag);//
	SetDataFlag97(0xff, 0xd5, Jproginfo->RealData.flg97[5].flg.Dataflag);//
	SetDataFlag97(0xff, 0xd6, Jproginfo->RealData.flg97[6].flg.Dataflag);//
	SetDataFlag97(0xff, 0xd7, Jproginfo->RealData.flg97[7].flg.Dataflag);//
	SetDataFlag97(0xff, 0xd8, Jproginfo->RealData.flg97[8].flg.Dataflag);//
	SetDataFlag97(0xff, 0xd9, Jproginfo->RealData.flg97[9].flg.Dataflag);//
	SetDataFlag97(0xff, 0xda, Jproginfo->RealData.flg97[10].flg.Dataflag);//
	SetDataFlag97(0xff, 0xdb, Jproginfo->RealData.flg97[11].flg.Dataflag);//
	Jproginfo->RealData.CurFlgCount = 12;
	//Jproginfo->RealData.ReadFlg = 0;//���ڶ�ȡ״̬
	for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);

	int delay = 4;
	if(Jproginfo->RealData.CurFlgCount < 20)
		delay = Jproginfo->RealData.CurFlgCount * 3;
	else
		delay = 40;
	if(delay < 10)
		delay = 10;

	if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg, sizeof(Jproginfo->RealData));
	} else {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg, sizeof(Jproginfo->RealData));
	}

    Jproginfo->RealData.ReadFlg=0;
	TSGet(&ts);
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;

	for(i=0;i<2;i++)
	{
		if ((tempRealTimeData.flg97[i].datas[0]==OxXX) && (tempRealTimeData.flg97[i].datas[1]==OxXX)&&
				(tempRealTimeData.flg97[i].datas[2]==OxXX)&&(tempRealTimeData.flg97[i].datas[3]==OxXX))
			SendBuff[SendIndex++] = OxXX;
		else SendBuff[SendIndex++]=0x00;
		memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[i].datas[0], 4);
		SendIndex = SendIndex + 4;
	}
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[2].datas[0], 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[3].datas[0], 4);
	SendIndex = SendIndex + 4;

	if ((tempRealTimeData.flg97[4].datas[0]==OxXX) && (tempRealTimeData.flg97[4].datas[1]==OxXX)&&
			(tempRealTimeData.flg97[4].datas[2]==OxXX)&&(tempRealTimeData.flg97[4].datas[3]==OxXX))
		SendBuff[SendIndex++] = OxXX;
	else SendBuff[SendIndex++]=0x00;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[4].datas[0], 4);
	SendIndex = SendIndex + 4;
	if ((tempRealTimeData.flg97[5].datas[0]==OxXX) && (tempRealTimeData.flg97[5].datas[1]==OxXX)&&
			(tempRealTimeData.flg97[5].datas[2]==OxXX)&&(tempRealTimeData.flg97[5].datas[3]==OxXX))
		SendBuff[SendIndex++] = OxXX;
	else SendBuff[SendIndex++]=0x00;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[5].datas[0], 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[6].datas[0], 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[7].datas[0], 4);
	SendIndex = SendIndex + 4;

	if ((tempRealTimeData.flg97[8].datas[0]==OxXX) && (tempRealTimeData.flg97[8].datas[1]==OxXX)&&
			(tempRealTimeData.flg97[8].datas[2]==OxXX)&&(tempRealTimeData.flg97[8].datas[3]==OxXX))
		SendBuff[SendIndex++] = OxXX;
	else SendBuff[SendIndex++]=0x00;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[8].datas[0], 4);
	SendIndex = SendIndex + 4;
	if ((tempRealTimeData.flg97[9].datas[0]==OxXX) && (tempRealTimeData.flg97[9].datas[1]==OxXX)&&
			(tempRealTimeData.flg97[9].datas[2]==OxXX)&&(tempRealTimeData.flg97[9].datas[3]==OxXX))
		SendBuff[SendIndex++] = OxXX;
	else SendBuff[SendIndex++]=0x00;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[9].datas[0], 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[10].datas[0], 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[11].datas[0], 4);
	SendIndex = SendIndex + 4;

//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 1;
}
//376.1lqq+++++++++++>>>>>

INT16U Level1Data_F33_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ������/�޹�����ʾֵ��һ/�������޹�����ʾֵ
{
	SdPrintf(YNPrint,PreFix,"----------Level1Data_F33_Get---------------");
	INT8U CJQno, Meterno,i,MeterType;
	TS ts;
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	Meterno = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;

	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
	Jproginfo->RealData.CaijiqiNo = CJQno;
	Jproginfo->RealData.MeterNo = Meterno;
	SetDataFlag97(0x90, 0x1f, Jproginfo->RealData.flg97[0].flg.Dataflag);//��ǰ�����й��ܵ���
//	if ((MeterType == 9) || (MeterType == 6))
//		SetDataFlag97(0x00, 0x00, Jproginfo->RealData.flg97[1].flg.Dataflag);
//	else
	SetDataFlag97(0x91, 0x1f, Jproginfo->RealData.flg97[1].flg.Dataflag);//��ǰ�����޹��ܵ���
	SetDataFlag97(0x91, 0x3f, Jproginfo->RealData.flg97[2].flg.Dataflag);//��ǰһ�����޹��ܵ���ʾֵ
	SetDataFlag97(0x91, 0x4f, Jproginfo->RealData.flg97[3].flg.Dataflag);//��ǰ�������޹��ܵ���ʾֵ
	Jproginfo->RealData.CurFlgCount = 4;
	//Jproginfo->RealData.ReadFlg = 0;//���ڶ�ȡ״̬
	for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);

	int delay = 4;
	if(Jproginfo->RealData.CurFlgCount < 20)
		delay = Jproginfo->RealData.CurFlgCount * 3;
	else
		delay = 40;
	if(delay < 10)
		delay = 10;

	if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg, sizeof(Jproginfo->RealData));
	} else {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg, sizeof(Jproginfo->RealData));
	}

    Jproginfo->RealData.ReadFlg=0;
	TSGet(&ts);
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = FeiLvNum;
	for(i=0;i<5;i++)
	{
		if ((tempRealTimeData.flg97[0].datas[i*4]==OxXX) && (tempRealTimeData.flg97[0].datas[i*4+1]==OxXX)&&
				(tempRealTimeData.flg97[0].datas[i*4+2]==OxXX)&&(tempRealTimeData.flg97[0].datas[i*4+3]==OxXX))
			SendBuff[SendIndex++] = OxXX;
		else SendBuff[SendIndex++]=0x00;
		memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[0].datas[i*4], 4);
		SendIndex = SendIndex + 4;
	}
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[1].datas[0], 20);
	SendIndex = SendIndex + 20;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[2].datas[0], 20);
	SendIndex = SendIndex + 20;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[3].datas[0], 20);
	SendIndex = SendIndex + 20;
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 1;
}

INT16U Level1Data_F34_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ������/�޹�����ʾֵ����/�������޹�����ʾֵ
{
	INT8U CJQno, Meterno,i,MeterType;
	TS ts;
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	Meterno = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
	Jproginfo->RealData.CaijiqiNo = CJQno;
	Jproginfo->RealData.MeterNo = Meterno;
	SetDataFlag97(0x90, 0x20, Jproginfo->RealData.flg97[0].flg.Dataflag);//��ǰ�����й��ܵ���
	SetDataFlag97(0x91, 0x20, Jproginfo->RealData.flg97[1].flg.Dataflag);//��ǰ�����޹��ܵ���
	SetDataFlag97(0x91, 0x5f, Jproginfo->RealData.flg97[2].flg.Dataflag);//��ǰ�������޹��ܵ���ʾֵ
	SetDataFlag97(0x91, 0x6f, Jproginfo->RealData.flg97[3].flg.Dataflag);//��ǰ�������޹��ܵ���ʾֵ
	Jproginfo->RealData.CurFlgCount = 4;
	//Jproginfo->RealData.ReadFlg = 0;
	SdPrintf(YNPrint,PreFix,"Level1Data_F34_Get\n");
	for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);

	int delay = 4;
	if (Jproginfo->RealData.CurFlgCount < 20)
		delay = Jproginfo->RealData.CurFlgCount * 3;
	else
		delay = 40;
	if (delay < 10)
		delay = 10;
	if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,
				sizeof(Jproginfo->RealData));
	} else {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
	}
    Jproginfo->RealData.ReadFlg=0;
	TSGet(&ts);
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = FeiLvNum;
	for(i=0;i<5;i++)
	{
		if ((tempRealTimeData.flg97[0].datas[i*4]==OxXX) && (tempRealTimeData.flg97[0].datas[i*4+1]==OxXX)&&
				(tempRealTimeData.flg97[0].datas[i*4+2]==OxXX)&&(tempRealTimeData.flg97[0].datas[i*4+3]==OxXX))
			SendBuff[SendIndex++] = OxXX;
		else SendBuff[SendIndex++]=0x00;
		memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[0].datas[i*4], 4);
		SendIndex = SendIndex + 4;
	}
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[1].datas[0], 20);
	SendIndex = SendIndex + 20;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[2].datas[0], 20);
	SendIndex = SendIndex + 20;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[3].datas[0], 20);
	SendIndex = SendIndex + 20;
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 1;
}

INT16U Level1Data_F35_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//����������/�޹��������������ʱ��
{
	INT8U CJQno, Meterno,i;
	TS ts;
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	Meterno = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;

	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
	Jproginfo->RealData.CaijiqiNo = CJQno;
	Jproginfo->RealData.MeterNo = Meterno;
	SetDataFlag97(0xA0, 0x1f, Jproginfo->RealData.flg97[0].flg.Dataflag);//��ǰ�����й����������
	SetDataFlag97(0xB0, 0x1f, Jproginfo->RealData.flg97[1].flg.Dataflag);//��ǰ�����й��������������ʱ��
	SetDataFlag97(0xA1, 0x1f, Jproginfo->RealData.flg97[2].flg.Dataflag);//��ǰ�����޹����������
	SetDataFlag97(0xB1, 0x1f, Jproginfo->RealData.flg97[3].flg.Dataflag);//��ǰ�����޹��������������ʱ��
	Jproginfo->RealData.CurFlgCount = 4;
	//Jproginfo->RealData.ReadFlg = 0;
	for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);

	int delay = 4;
	if (Jproginfo->RealData.CurFlgCount < 20)
		delay = Jproginfo->RealData.CurFlgCount * 3;
	else
		delay = 40;
	if (delay < 10)
		delay = 10;
	if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,
				sizeof(Jproginfo->RealData));
	} else {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
	}
    Jproginfo->RealData.ReadFlg=0;
	TSGet(&ts);
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = FeiLvNum;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[0].datas[0], 15);
	SendIndex = SendIndex + 15;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[1].datas[0], 20);
	SendIndex = SendIndex + 20;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[2].datas[0], 15);
	SendIndex = SendIndex + 15;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[3].datas[0], 20);
	SendIndex = SendIndex + 20;

//	EC();
//	TP();
//	FrameTailCreate_Send(0);

	return 1;
}

INT16U Level1Data_F36_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���·�����/�޹��������������ʱ��
{
	INT8U CJQno, Meterno,i;
	TS ts;
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	Meterno = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
	Jproginfo->RealData.CaijiqiNo = CJQno;
	Jproginfo->RealData.MeterNo = Meterno;
	SetDataFlag97(0xA0, 0x2f, Jproginfo->RealData.flg97[0].flg.Dataflag);//��ǰ�����й����������
	SetDataFlag97(0xB0, 0x2f, Jproginfo->RealData.flg97[1].flg.Dataflag);//��ǰ�����й��������������ʱ��
	SetDataFlag97(0xA1, 0x2f, Jproginfo->RealData.flg97[2].flg.Dataflag);
	SetDataFlag97(0xb1, 0x2f, Jproginfo->RealData.flg97[3].flg.Dataflag);
	Jproginfo->RealData.CurFlgCount = 4;
	//Jproginfo->RealData.ReadFlg = 0;
	for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);

	int delay = 4;
	if (Jproginfo->RealData.CurFlgCount < 20)
		delay = Jproginfo->RealData.CurFlgCount * 3;
	else
		delay = 40;
	if (delay < 10)
		delay = 10;
	if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,
				sizeof(Jproginfo->RealData));
	} else {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
	}
    Jproginfo->RealData.ReadFlg=0;
	TSGet(&ts);
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = FeiLvNum;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[0].datas[0], 15);
	SendIndex = SendIndex + 15;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[1].datas[0], 20);
	SendIndex = SendIndex + 20;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[2].datas[0], 15);
	SendIndex = SendIndex + 15;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[3].datas[0], 20);
	SendIndex = SendIndex + 20;
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 1;
}
//376.1lqq+++<<<<<<<<<<<<<<<<<<<
INT16U Level1Data_F37_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���£���һ�����գ�������/�޹�����ʾֵ��һ/�������޹�����ʾֵ��
{
	INT8U CJQno, Meterno,i,MeterType;
	TS ts;
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	Meterno = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;

	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
	Jproginfo->RealData.CaijiqiNo = CJQno;
	Jproginfo->RealData.MeterNo = Meterno;
	SetDataFlag97(0x94, 0x1f, Jproginfo->RealData.flg97[0].flg.Dataflag);//��һ�����������й��ܵ���
	SetDataFlag97(0x95, 0x1f, Jproginfo->RealData.flg97[1].flg.Dataflag);//��һ�����������޹��ܵ���
	SetDataFlag97(0x95, 0x3f, Jproginfo->RealData.flg97[2].flg.Dataflag);//��һ������һ�����޹��ܵ���ʾֵ
	SetDataFlag97(0x95, 0x4f, Jproginfo->RealData.flg97[3].flg.Dataflag);//��һ�������������޹��ܵ���ʾֵ
	Jproginfo->RealData.CurFlgCount = 4;
	//Jproginfo->RealData.ReadFlg = 0;//���ڶ�ȡ״̬
	for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);

	int delay = 4;
	if(Jproginfo->RealData.CurFlgCount < 20)
		delay = Jproginfo->RealData.CurFlgCount * 3;
	else
		delay = 40;
	if(delay < 10)
		delay = 10;

	if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg, sizeof(Jproginfo->RealData));
	} else {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg, sizeof(Jproginfo->RealData));
	}

    Jproginfo->RealData.ReadFlg=0;
	TSGet(&ts);
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = FeiLvNum;
	for(i=0;i<5;i++)
	{
		if ((tempRealTimeData.flg97[0].datas[i*4]==OxXX) && (tempRealTimeData.flg97[0].datas[i*4+1]==OxXX)&&
				(tempRealTimeData.flg97[0].datas[i*4+2]==OxXX)&&(tempRealTimeData.flg97[0].datas[i*4+3]==OxXX))
			SendBuff[SendIndex++] = OxXX;
		else SendBuff[SendIndex++]=0x00;
		memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[0].datas[i*4], 4);
		SendIndex = SendIndex + 4;
	}
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[1].datas[0], 20);
	SendIndex = SendIndex + 20;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[2].datas[0], 20);
	SendIndex = SendIndex + 20;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[3].datas[0], 20);
	SendIndex = SendIndex + 20;
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 1;
}

INT16U Level1Data_F38_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���£���һ�����գ�������/�޹�����ʾֵ����/�������޹�����ʾֵ
{
	INT8U CJQno, Meterno,i,MeterType;
	TS ts;
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	Meterno = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType=JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
	Jproginfo->RealData.CaijiqiNo = CJQno;
	Jproginfo->RealData.MeterNo = Meterno;
	SetDataFlag97(0x94, 0x2f, Jproginfo->RealData.flg97[0].flg.Dataflag);//�����й��ܵ���
	SetDataFlag97(0x95, 0x2f, Jproginfo->RealData.flg97[1].flg.Dataflag);//�����޹��ܵ���
	SetDataFlag97(0x95, 0x5f, Jproginfo->RealData.flg97[2].flg.Dataflag);//�������޹��ܵ���ʾֵ
	SetDataFlag97(0x95, 0x6f, Jproginfo->RealData.flg97[3].flg.Dataflag);//�������޹��ܵ���ʾֵ
	Jproginfo->RealData.CurFlgCount = 4;
	//Jproginfo->RealData.ReadFlg = 0;
	for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);

	int delay = 4;
	if (Jproginfo->RealData.CurFlgCount < 20)
		delay = Jproginfo->RealData.CurFlgCount * 3;
	else
		delay = 40;
	if (delay < 10)
		delay = 10;
	if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,
				sizeof(Jproginfo->RealData));
	} else {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
	}
    Jproginfo->RealData.ReadFlg=0;
	TSGet(&ts);
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = FeiLvNum;
	for(i=0;i<5;i++)
	{
		if ((tempRealTimeData.flg97[0].datas[i*4]==OxXX) && (tempRealTimeData.flg97[0].datas[i*4+1]==OxXX)&&
				(tempRealTimeData.flg97[0].datas[i*4+2]==OxXX)&&(tempRealTimeData.flg97[0].datas[i*4+3]==OxXX))
			SendBuff[SendIndex++] = OxXX;
		else SendBuff[SendIndex++]=0x00;
		memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[0].datas[i*4], 4);
		SendIndex = SendIndex + 4;
	}
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[1].datas[0], 20);
	SendIndex = SendIndex + 20;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[2].datas[0], 20);
	SendIndex = SendIndex + 20;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[3].datas[0], 20);
	SendIndex = SendIndex + 20;
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 1;
}
INT16U Level1Data_F39_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���£���һ�����գ�������/�޹�����ʾֵ����/�������޹�����ʾֵ
{
	INT8U CJQno, Meterno,i;
	TS ts;
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	Meterno = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;

	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
	Jproginfo->RealData.CaijiqiNo = CJQno;
	Jproginfo->RealData.MeterNo = Meterno;
	SetDataFlag97(0xA4, 0x1f, Jproginfo->RealData.flg97[0].flg.Dataflag);//���������й����������
	SetDataFlag97(0xB4, 0x1f, Jproginfo->RealData.flg97[1].flg.Dataflag);//���������й��������������ʱ��
	SetDataFlag97(0xA5, 0x1f, Jproginfo->RealData.flg97[2].flg.Dataflag);//���������޹����������
	SetDataFlag97(0xB5, 0x1f, Jproginfo->RealData.flg97[3].flg.Dataflag);//���������޹��������������ʱ��
	Jproginfo->RealData.CurFlgCount = 4;
	//Jproginfo->RealData.ReadFlg = 0;
	for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);

	int delay = 4;
	if (Jproginfo->RealData.CurFlgCount < 20)
		delay = Jproginfo->RealData.CurFlgCount * 3;
	else
		delay = 40;
	if (delay < 10)
		delay = 10;
	if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,
				sizeof(Jproginfo->RealData));
	} else {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
	}
    Jproginfo->RealData.ReadFlg=0;
	TSGet(&ts);
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = FeiLvNum;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[0].datas[0], 15);
	SendIndex = SendIndex + 15;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[1].datas[0], 20);
	SendIndex = SendIndex + 20;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[2].datas[0], 15);
	SendIndex = SendIndex + 15;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[3].datas[0], 20);
	SendIndex = SendIndex + 20;

//	EC();
//	TP();
//	FrameTailCreate_Send(0);

	return 1;
}

INT16U Level1Data_F40_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���£���һ�����գ�������/�޹��������������ʱ��    9��15�ո�
{
	INT8U CJQno, Meterno,i;
	TS ts;
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	Meterno = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;

	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
	Jproginfo->RealData.CaijiqiNo = CJQno;
	Jproginfo->RealData.MeterNo = Meterno;
	SetDataFlag97(0xA4, 0x2f, Jproginfo->RealData.flg97[0].flg.Dataflag);//���·����й����������
	SetDataFlag97(0xB4, 0x2f, Jproginfo->RealData.flg97[1].flg.Dataflag);//���·����й��������������ʱ��
	SetDataFlag97(0xA5, 0x2f, Jproginfo->RealData.flg97[2].flg.Dataflag);//���·����޹����������
	SetDataFlag97(0xB5, 0x2f, Jproginfo->RealData.flg97[3].flg.Dataflag);//���·����޹��������������ʱ��
	Jproginfo->RealData.CurFlgCount = 4;
	//Jproginfo->RealData.ReadFlg = 0;
	for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);

	int delay = 4;
	if (Jproginfo->RealData.CurFlgCount < 20)
		delay = Jproginfo->RealData.CurFlgCount * 3;
	else
		delay = 40;
	if (delay < 10)
		delay = 10;
	if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,
				sizeof(Jproginfo->RealData));
	} else {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
	}
    Jproginfo->RealData.ReadFlg=0;
	TSGet(&ts);
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = FeiLvNum;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[0].datas[0], 15);
	SendIndex = SendIndex + 15;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[1].datas[0], 20);
	SendIndex = SendIndex + 20;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[2].datas[0], 15);
	SendIndex = SendIndex + 15;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[3].datas[0], 20);
	SendIndex = SendIndex + 20;

//	EC();
//	TP();
//	FrameTailCreate_Send(0);

	return 1;
}
//376.1lqq++>>>>>>>>>>>>>>>>>>>>>>>>>.
//added by mqingkui
INT16U Level1Data_F49_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ��ѹ��������λ��
{
	INT8U CJQno, Meterno,i;
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	Meterno = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
	Jproginfo->RealData.CaijiqiNo = CJQno;
	Jproginfo->RealData.MeterNo = Meterno;
	SetDataFlag97(0x00, 0x21, Jproginfo->RealData.flg97[0].flg.Dataflag);//Uab/Ua��λ�� --
	SetDataFlag97(0x00, 0x22, Jproginfo->RealData.flg97[1].flg.Dataflag);//Ub��λ��--
	SetDataFlag97(0x00, 0x23, Jproginfo->RealData.flg97[2].flg.Dataflag);//Ucb/Uc��λ��--
	SetDataFlag97(0x00, 0x01, Jproginfo->RealData.flg97[3].flg.Dataflag);//Ia��λ��--
	SetDataFlag97(0x00, 0x02, Jproginfo->RealData.flg97[4].flg.Dataflag);//Ib��λ��--
	SetDataFlag97(0x00, 0x03, Jproginfo->RealData.flg97[5].flg.Dataflag);//Ic��λ��--
	Jproginfo->RealData.CurFlgCount = 6;
	//Jproginfo->RealData.ReadFlg = 0;
	for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);

	int delay = 4;
	if (Jproginfo->RealData.CurFlgCount < 20)
		delay = Jproginfo->RealData.CurFlgCount * 3;
	else
		delay = 40;
	if (delay < 10)
		delay = 10;
	if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,
				sizeof(Jproginfo->RealData));
	} else {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
	}
    Jproginfo->RealData.ReadFlg=0;
	//MkLevel1Head(P,F,0x88|(PrmFlg<<6));
	memcpy(&SendBuff[SendIndex],&tempRealTimeData.flg97[0].datas[0],2);
	SendIndex=SendIndex+2;
	memcpy(&SendBuff[SendIndex],&tempRealTimeData.flg97[1].datas[0],2);
	SendIndex=SendIndex+2;
	memcpy(&SendBuff[SendIndex],&tempRealTimeData.flg97[2].datas[0],2);
	SendIndex=SendIndex+2;
	memcpy(&SendBuff[SendIndex],&tempRealTimeData.flg97[3].datas[0],2);
	SendIndex=SendIndex+2;
	memcpy(&SendBuff[SendIndex],&tempRealTimeData.flg97[4].datas[0],2);
	SendIndex=SendIndex+2;
	memcpy(&SendBuff[SendIndex],&tempRealTimeData.flg97[5].datas[0],2);
	SendIndex=SendIndex+2;

//	EC();
//	TP();
//	FrameTailCreate_Send(0);//���ͱ���β��������

	return 1;
}

INT16U Level1Data_F73_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)
{
	//songjian
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));//����1�����ݵı���ͷ
	SendBuff[SendIndex++] = Jproginfo->BeiYong[0];
	SendBuff[SendIndex++] = Jproginfo->BeiYong[1];
	SdPrintf(YNPrint,PreFix,"Level1Data_F73_Get   Jproginfo->BeiYong[1][0] = %02x%02x\n",Jproginfo->BeiYong[1],Jproginfo->BeiYong[0]);
//	EC();
//	TP();
//	FrameTailCreate_Send(0);//���ͱ���β��������
	return 1;
}

INT16U Level1Data_F129_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ�����й�����ʾֵ
{
	SdPrintf(YNPrint,PreFix,"Level1Data_F129_Get");
	INT8U CJQno, Meterno,i;
	TS ts;
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	Meterno = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
	Jproginfo->RealData.CaijiqiNo = CJQno;
	Jproginfo->RealData.MeterNo = Meterno;
	SetDataFlag97(0x90, 0x1f, Jproginfo->RealData.flg97[0].flg.Dataflag);//��ǰ�����й��ܵ���
	Jproginfo->RealData.CurFlgCount = 1;
	//Jproginfo->RealData.ReadFlg = 0;
	for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);

	int delay = 4;
	if (Jproginfo->RealData.CurFlgCount < 20)
		delay = Jproginfo->RealData.CurFlgCount * 3;
	else
		delay = 40;
	if (delay < 10)
		delay = 10;
	if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,
				sizeof(Jproginfo->RealData));
	} else {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
	}
    Jproginfo->RealData.ReadFlg=0;
	TSGet(&ts);
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = FeiLvNum;
	for(i=0;i<5;i++)
	{
		if ((tempRealTimeData.flg97[0].datas[i*4]==OxXX) && (tempRealTimeData.flg97[0].datas[i*4+1]==OxXX)&&
				(tempRealTimeData.flg97[0].datas[i*4+2]==OxXX)&&(tempRealTimeData.flg97[0].datas[i*4+3]==OxXX))
			SendBuff[SendIndex++] = OxXX;
		else
			SendBuff[SendIndex++] = 0x00;
		memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[0].datas[i*4], 4);
		SendIndex = SendIndex + 4;
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 1;
}

INT16U Level1Data_F130_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ�����޹�������޹�1������ʾֵ
{
	INT8U CJQno, Meterno,i;
	TS ts;
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	Meterno = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
	Jproginfo->RealData.CaijiqiNo = CJQno;
	Jproginfo->RealData.MeterNo = Meterno;
	SetDataFlag97(0x91, 0x1f, Jproginfo->RealData.flg97[0].flg.Dataflag);//��ǰ�����޹�������޹�1���ܵ���
	Jproginfo->RealData.CurFlgCount = 1;
	//Jproginfo->RealData.ReadFlg = 0;
	for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);

	int delay = 4;
	if (Jproginfo->RealData.CurFlgCount < 20)
		delay = Jproginfo->RealData.CurFlgCount * 3;
	else
		delay = 40;
	if (delay < 10)
		delay = 10;
	if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,
				sizeof(Jproginfo->RealData));
	} else {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
	}
    Jproginfo->RealData.ReadFlg=0;
	TSGet(&ts);
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = FeiLvNum;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[0].datas[0], 20);
	SendIndex = SendIndex + 20;
//	EC();
//	TP();
//	FrameTailCreate_Send(0);

	return 1;
}

INT16U Level1Data_F131_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ�����й�����ʾֵ
{
	INT8U CJQno, Meterno,i;
	TS ts;
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	Meterno = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
	Jproginfo->RealData.CaijiqiNo = CJQno;
	Jproginfo->RealData.MeterNo = Meterno;
	SetDataFlag97(0x90, 0x2f, Jproginfo->RealData.flg97[0].flg.Dataflag);//��ǰ�����й��ܵ���
	Jproginfo->RealData.CurFlgCount = 1;
	//Jproginfo->RealData.ReadFlg = 0;
	for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);

	int delay = 4;
	if (Jproginfo->RealData.CurFlgCount < 20)
		delay = Jproginfo->RealData.CurFlgCount * 3;
	else
		delay = 40;
	if (delay < 10)
		delay = 10;
	if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,
				sizeof(Jproginfo->RealData));
	} else {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
	}
    Jproginfo->RealData.ReadFlg=0;
	TSGet(&ts);
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = FeiLvNum;
	for(i=0;i<5;i++)
	{
		if ((tempRealTimeData.flg97[0].datas[i*4]==OxXX) && (tempRealTimeData.flg97[0].datas[i*4+1]==OxXX)&&
				(tempRealTimeData.flg97[0].datas[i*4+2]==OxXX)&&(tempRealTimeData.flg97[0].datas[i*4+3]==OxXX))
			SendBuff[SendIndex++] = OxXX;
		else
			SendBuff[SendIndex++] = 0x00;
		memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[0].datas[i*4], 4);
		SendIndex = SendIndex + 4;
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);

	return 1;
}

INT16U Level1Data_F132_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ�����޹�������޹�1������ʾֵ
{
	TS ts;
	int i;
	SdPrintf(YNPrint,PreFix,"Level1Data_F132_Get set:%02x F:%02x P:%02x \n", Set, F, P);
	SdPrintf(YNPrint,PreFix,"JSetPara_AFN04_3761_2009->group2.f10[P-1].ConnectType=%d  JSetPara_AFN04_3761_2009->group2.f10[P-1].port=%d\n",JSetPara_AFN04_3761_2009->group2.f10[P-1].ConnectType,JSetPara_AFN04_3761_2009->group2.f10[P-1].port);
	if(JSetPara_AFN04_3761_2009->group2.f10[P-1].ConnectType==2 && JSetPara_AFN04_3761_2009->group2.f10[P-1].port==1)
	{
		TSGet(&ts);
		INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
		SendBuff[SendIndex++] = FeiLvNum;
		//���ڴ����
		SdPrintf(YNPrint,PreFix,"-----------Level1Data_Curr_F25_Get  JC from memory----------------------------------------\n");
		SetDataFlag97(0x91, 0x20, Jproginfo->RealData.flg97[0].flg.Dataflag);
		SetDataFlag97(0x91, 0x21, Jproginfo->RealData.flg97[1].flg.Dataflag);
		SetDataFlag97(0x91, 0x22, Jproginfo->RealData.flg97[2].flg.Dataflag);
		SetDataFlag97(0x91, 0x23, Jproginfo->RealData.flg97[3].flg.Dataflag);
		SetDataFlag97(0x91, 0x24, Jproginfo->RealData.flg97[4].flg.Dataflag);

		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.F_Q_All/64, &Jproginfo->RealData.flg97[0].datas[0],4);
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.F_Q_F[0]/64, &Jproginfo->RealData.flg97[1].datas[0],4);
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.F_Q_F[1]/64, &Jproginfo->RealData.flg97[2].datas[0],4);
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.F_Q_F[2]/64, &Jproginfo->RealData.flg97[3].datas[0],4);
		INT32U_BCD(Jdatafileinfo->jc.JcDdRealData.F_Q_F[3]/64, &Jproginfo->RealData.flg97[4].datas[0],4);

		Jproginfo->RealData.CurFlgCount = 5;
		for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		{
				SdPrintf(YNPrint,PreFix,"i: %d   datas[0] %02x %02x %02x %02x \n",
						i,
						Jproginfo->RealData.flg97[i].datas[0],
						Jproginfo->RealData.flg97[i].datas[1],
						Jproginfo->RealData.flg97[i].datas[2],
						Jproginfo->RealData.flg97[i].datas[3]);
		}
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[0].datas[0], 4);
		SendIndex = SendIndex + 4;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[1].datas[0], 4);
		SendIndex = SendIndex + 4;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[2].datas[0], 4);
		SendIndex = SendIndex + 4;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[3].datas[0], 4);
		SendIndex = SendIndex + 4;
		memcpy(&SendBuff[SendIndex], &Jproginfo->RealData.flg97[4].datas[0], 4);
		SendIndex = SendIndex + 4;
	}else
	{
	INT8U CJQno, Meterno,i;
	TS ts;
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	Meterno = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
	Jproginfo->RealData.CaijiqiNo = CJQno;
	Jproginfo->RealData.MeterNo = Meterno;
	SetDataFlag97(0x91, 0x2f, Jproginfo->RealData.flg97[0].flg.Dataflag);//(��ǰ)�����޹��ܵ���ʾֵ
	Jproginfo->RealData.CurFlgCount = 1;
	//Jproginfo->RealData.ReadFlg = 0;
	for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);

	int delay = 4;
	if (Jproginfo->RealData.CurFlgCount < 20)
		delay = Jproginfo->RealData.CurFlgCount * 3;
	else
		delay = 40;
	if (delay < 10)
		delay = 10;
	if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,
				sizeof(Jproginfo->RealData));
	} else {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
	}
    Jproginfo->RealData.ReadFlg=0;
	TSGet(&ts);
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = FeiLvNum;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[0].datas[0], 20);
	SendIndex = SendIndex + 20;
	}
//	EC();
//	TP();
//	FrameTailCreate_Send(0);
	return 1;
}

INT16U Level1Data_F133_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰһ�����޹�����ʾֵ
{
	INT8U CJQno, Meterno,i;
	TS ts;
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	Meterno = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
	Jproginfo->RealData.CaijiqiNo = CJQno;
	SetDataFlag97(0x91, 0x3f, Jproginfo->RealData.flg97[0].flg.Dataflag);//��ǰһ�����޹��ܵ���ʾֵ
	Jproginfo->RealData.CurFlgCount = 1;
	//Jproginfo->RealData.ReadFlg = 0;
	for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);

	int delay = 4;
	if (Jproginfo->RealData.CurFlgCount < 20)
		delay = Jproginfo->RealData.CurFlgCount * 3;
	else
		delay = 40;
	if (delay < 10)
		delay = 10;
	if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,
				sizeof(Jproginfo->RealData));
	} else {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
	}
    Jproginfo->RealData.ReadFlg=0;
	TSGet(&ts);
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = FeiLvNum;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[0].datas[0], 20);
	SendIndex = SendIndex + 20;
//	EC();
	//TP();
	//FrameTailCreate_Send(0);
	return 1;
}

INT16U Level1Data_F134_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ�������޹�����ʾֵ
{
	INT8U CJQno, Meterno,i;
	TS ts;
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	Meterno = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
	Jproginfo->RealData.CaijiqiNo = CJQno;
	Jproginfo->RealData.MeterNo = Meterno;
	SetDataFlag97(0x91, 0x5f, Jproginfo->RealData.flg97[0].flg.Dataflag);//��ǰ�������޹��ܵ���ʾֵ
	Jproginfo->RealData.CurFlgCount = 1;
	//Jproginfo->RealData.ReadFlg = 0;
	for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);

	int delay = 4;
	if (Jproginfo->RealData.CurFlgCount < 20)
		delay = Jproginfo->RealData.CurFlgCount * 3;
	else
		delay = 40;
	if (delay < 10)
		delay = 10;
	if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,
				sizeof(Jproginfo->RealData));
	} else {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
	}
    Jproginfo->RealData.ReadFlg=0;
	TSGet(&ts);
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = FeiLvNum;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[0].datas[0], 20);
	SendIndex = SendIndex + 20;
	//	EC();
	//TP();
	//FrameTailCreate_Send(0);
	return 1;
}

INT16U Level1Data_F135_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ�������޹�����ʾֵ
{
	INT8U CJQno, Meterno,i;
	TS ts;
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	Meterno = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
	Jproginfo->RealData.CaijiqiNo = CJQno;
	Jproginfo->RealData.MeterNo = Meterno;
	SetDataFlag97(0x91, 0x6f, Jproginfo->RealData.flg97[0].flg.Dataflag);//��ǰ�������޹��ܵ���ʾֵ
	Jproginfo->RealData.CurFlgCount = 1;
	//Jproginfo->RealData.ReadFlg = 0;
	for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);

	int delay = 4;
	if (Jproginfo->RealData.CurFlgCount < 20)
		delay = Jproginfo->RealData.CurFlgCount * 3;
	else
		delay = 40;
	if (delay < 10)
		delay = 10;
	if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,
				sizeof(Jproginfo->RealData));
	} else {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
	}
    Jproginfo->RealData.ReadFlg=0;
	TSGet(&ts);
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = FeiLvNum;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[0].datas[0], 20);
	SendIndex = SendIndex + 20;

	//	EC();
	//TP();
	//FrameTailCreate_Send(0);
	return 1;
}

INT16U Level1Data_F136_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//��ǰ�������޹�����ʾֵ
{
	INT8U CJQno, Meterno,i;
	TS ts;
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	Meterno = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
	Jproginfo->RealData.CaijiqiNo = CJQno;
	Jproginfo->RealData.MeterNo = Meterno;
	SetDataFlag97(0x91, 0x4f, Jproginfo->RealData.flg97[0].flg.Dataflag);//��ǰ�������޹��ܵ���ʾֵ
	Jproginfo->RealData.CurFlgCount = 1;
	//Jproginfo->RealData.ReadFlg = 0;
	for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);

	int delay = 4;
	if (Jproginfo->RealData.CurFlgCount < 20)
		delay = Jproginfo->RealData.CurFlgCount * 3;
	else
		delay = 40;
	if (delay < 10)
		delay = 10;
	if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,
				sizeof(Jproginfo->RealData));
	} else {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
	}
    Jproginfo->RealData.ReadFlg=0;
	TSGet(&ts);
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = FeiLvNum;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[0].datas[0], 20);
	SendIndex = SendIndex + 20;
	//	EC();
	//TP();
	//FrameTailCreate_Send(0);
	return 1;
}
//376.1lqq++++<<<<<<<<<<<<<<<<<<<
INT16U Level1Data_F137_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���£���һ�����գ������й�����ʾֵ���ܡ�����1��M
{
	INT8U CJQno, Meterno,i;
	TS ts;
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	Meterno = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
	Jproginfo->RealData.CaijiqiNo = CJQno;
	Jproginfo->RealData.MeterNo = Meterno;
	SetDataFlag97(0x94, 0x1f, Jproginfo->RealData.flg97[0].flg.Dataflag);//���������й��ܵ���
	Jproginfo->RealData.CurFlgCount = 1;
	//Jproginfo->RealData.ReadFlg = 0;
	for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);

	int delay = 4;
	if (Jproginfo->RealData.CurFlgCount < 20)
		delay = Jproginfo->RealData.CurFlgCount * 3;
	else
		delay = 40;
	if (delay < 10)
		delay = 10;
	if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,
				sizeof(Jproginfo->RealData));
	} else {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
	}
    Jproginfo->RealData.ReadFlg=0;
	TSGet(&ts);
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = FeiLvNum;
	for(i=0;i<5;i++)
	{
		if ((tempRealTimeData.flg97[0].datas[i*4]==OxXX) && (tempRealTimeData.flg97[0].datas[i*4+1]==OxXX)&&
				(tempRealTimeData.flg97[0].datas[i*4+2]==OxXX)&&(tempRealTimeData.flg97[0].datas[i*4+3]==OxXX))
			SendBuff[SendIndex++] = OxXX;
		else
			SendBuff[SendIndex++] = 0x00;
		memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[0].datas[i*4], 4);
		SendIndex = SendIndex + 4;
	}
	//	EC();
	//TP();
	//FrameTailCreate_Send(0);
	return 1;
}
INT16U Level1Data_F138_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���£���һ�����գ������޹�������޹�1������ʾֵ
{
	INT8U CJQno, Meterno,i;
	TS ts;
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	Meterno = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
	Jproginfo->RealData.CaijiqiNo = CJQno;
	Jproginfo->RealData.MeterNo = Meterno;
	SetDataFlag97(0x95, 0x1f, Jproginfo->RealData.flg97[0].flg.Dataflag);//���������޹�������޹�1���ܵ���
	Jproginfo->RealData.CurFlgCount = 1;
	//Jproginfo->RealData.ReadFlg = 0;
	for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);

	int delay = 4;
	if (Jproginfo->RealData.CurFlgCount < 20)
		delay = Jproginfo->RealData.CurFlgCount * 3;
	else
		delay = 40;
	if (delay < 10)
		delay = 10;
	if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,
				sizeof(Jproginfo->RealData));
	} else {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
	}
    Jproginfo->RealData.ReadFlg=0;
	TSGet(&ts);
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = FeiLvNum;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[0].datas[0], 20);
	SendIndex = SendIndex + 20;
	//	EC();
	//TP();
	//FrameTailCreate_Send(0);

	return 1;
}

INT16U Level1Data_F139_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���£���һ�����գ������й�����ʾֵ���ܡ�����1��M
{
	INT8U CJQno, Meterno,i;
	TS ts;
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	Meterno = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
	Jproginfo->RealData.CaijiqiNo = CJQno;
	Jproginfo->RealData.MeterNo = Meterno;
	SetDataFlag97(0x94, 0x2f, Jproginfo->RealData.flg97[0].flg.Dataflag);//���·����й��ܵ���
	Jproginfo->RealData.CurFlgCount = 1;
	//Jproginfo->RealData.ReadFlg = 0;
	for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);

	int delay = 4;
	if (Jproginfo->RealData.CurFlgCount < 20)
		delay = Jproginfo->RealData.CurFlgCount * 3;
	else
		delay = 40;
	if (delay < 10)
		delay = 10;
	if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,
				sizeof(Jproginfo->RealData));
	} else {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
	}
    Jproginfo->RealData.ReadFlg=0;
	TSGet(&ts);
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = FeiLvNum;
	for(i=0;i<5;i++)
	{
		if ((tempRealTimeData.flg97[0].datas[i*4]==OxXX) && (tempRealTimeData.flg97[0].datas[i*4+1]==OxXX)&&
				(tempRealTimeData.flg97[0].datas[i*4+2]==OxXX)&&(tempRealTimeData.flg97[0].datas[i*4+3]==OxXX))
			SendBuff[SendIndex++] = OxXX;
		else
			SendBuff[SendIndex++] = 0x00;
		memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[0].datas[i*4], 4);
		SendIndex = SendIndex + 4;
	}
	//	EC();
	//TP();
	//FrameTailCreate_Send(0);

	return 1;
}

INT16U Level1Data_F140_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���£���һ�����գ������޹�������޹�1������ʾֵ
{
	INT8U CJQno, Meterno,i;
	TS ts;
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	Meterno = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
	Jproginfo->RealData.CaijiqiNo = CJQno;
	SetDataFlag97(0x95, 0x2f, Jproginfo->RealData.flg97[0].flg.Dataflag);//(��ǰ)�����޹��ܵ���ʾֵ
	Jproginfo->RealData.CurFlgCount = 1;
	//Jproginfo->RealData.ReadFlg = 0;
	for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);

	int delay = 4;
	if (Jproginfo->RealData.CurFlgCount < 20)
		delay = Jproginfo->RealData.CurFlgCount * 3;
	else
		delay = 40;
	if (delay < 10)
		delay = 10;
	if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,
				sizeof(Jproginfo->RealData));
	} else {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
	}
    Jproginfo->RealData.ReadFlg=0;
	TSGet(&ts);
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = FeiLvNum;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[0].datas[0], 20);
	SendIndex = SendIndex + 20;

	//	EC();
	//TP();
	//FrameTailCreate_Send(0);
	return 1;
}

INT16U Level1Data_F141_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//����һ�����޹�����ʾֵ
{
	INT8U CJQno, Meterno,i;
	TS ts;
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	Meterno = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
	Jproginfo->RealData.CaijiqiNo = CJQno;
	SetDataFlag97(0x95, 0x3f, Jproginfo->RealData.flg97[0].flg.Dataflag);//����һ�����޹��ܵ���ʾֵ
	Jproginfo->RealData.CurFlgCount = 1;
	//Jproginfo->RealData.ReadFlg = 0;
	for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);

	int delay = 4;
	if (Jproginfo->RealData.CurFlgCount < 20)
		delay = Jproginfo->RealData.CurFlgCount * 3;
	else
		delay = 40;
	if (delay < 10)
		delay = 10;
	if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,
				sizeof(Jproginfo->RealData));
	} else {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
	}
    Jproginfo->RealData.ReadFlg=0;
	TSGet(&ts);
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = FeiLvNum;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[0].datas[0], 20);
	SendIndex = SendIndex + 20;
	//	EC();
	//TP();
	//FrameTailCreate_Send(0);
	return 1;
}

INT16U Level1Data_F142_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���¶������޹�����ʾֵ
{
	INT8U CJQno, Meterno,i;
	TS ts;
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	Meterno = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
	Jproginfo->RealData.CaijiqiNo = CJQno;
	Jproginfo->RealData.MeterNo = Meterno;
	SetDataFlag97(0x95, 0x5f, Jproginfo->RealData.flg97[0].flg.Dataflag);//���¶������޹��ܵ���ʾֵ
	Jproginfo->RealData.CurFlgCount = 1;
	//Jproginfo->RealData.ReadFlg = 0;
	for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);

	int delay = 4;
	if (Jproginfo->RealData.CurFlgCount < 20)
		delay = Jproginfo->RealData.CurFlgCount * 3;
	else
		delay = 40;
	if (delay < 10)
		delay = 10;
	if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,
				sizeof(Jproginfo->RealData));
	} else {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
	}
    Jproginfo->RealData.ReadFlg=0;
	TSGet(&ts);
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = FeiLvNum;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[0].datas[0], 20);
	SendIndex = SendIndex + 20;
	//	EC();
	//TP();
	//FrameTailCreate_Send(0);
	return 1;
}

INT16U Level1Data_F143_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//�����������޹�����ʾֵ
{
	INT8U CJQno, Meterno,i;
	TS ts;
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	Meterno = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
	Jproginfo->RealData.CaijiqiNo = CJQno;
	Jproginfo->RealData.MeterNo = Meterno;
	SetDataFlag97(0x95, 0x6f, Jproginfo->RealData.flg97[0].flg.Dataflag);//�����������޹��ܵ���ʾֵ
	Jproginfo->RealData.CurFlgCount = 1;
	//Jproginfo->RealData.ReadFlg = 0;
	for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);

	int delay = 4;
	if (Jproginfo->RealData.CurFlgCount < 20)
		delay = Jproginfo->RealData.CurFlgCount * 3;
	else
		delay = 40;
	if (delay < 10)
		delay = 10;
	if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,
				sizeof(Jproginfo->RealData));
	} else {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
	}
    Jproginfo->RealData.ReadFlg=0;
	TSGet(&ts);
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = FeiLvNum;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[0].datas[0], 20);
	SendIndex = SendIndex + 20;

	//	EC();
	//TP();
	//FrameTailCreate_Send(0);
	return 1;
}

INT16U Level1Data_F144_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//�����������޹�����ʾֵ
{
	INT8U CJQno, Meterno,i;
	TS ts;
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	Meterno = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
	Jproginfo->RealData.CaijiqiNo = CJQno;
	Jproginfo->RealData.MeterNo = Meterno;
	SetDataFlag97(0x95, 0x4f, Jproginfo->RealData.flg97[0].flg.Dataflag);//�����������޹��ܵ���ʾֵ
	Jproginfo->RealData.CurFlgCount = 1;
	//Jproginfo->RealData.ReadFlg = 0;
	for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);

	int delay = 4;
	if (Jproginfo->RealData.CurFlgCount < 20)
		delay = Jproginfo->RealData.CurFlgCount * 3;
	else
		delay = 40;
	if (delay < 10)
		delay = 10;
	if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,
				sizeof(Jproginfo->RealData));
	} else {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
	}
    Jproginfo->RealData.ReadFlg=0;
	TSGet(&ts);
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = FeiLvNum;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[0].datas[0], 20);
	SendIndex = SendIndex + 20;
	//	EC();
	//TP();
	//FrameTailCreate_Send(0);
	return 1;
}
INT16U Level1Data_F149_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���������й��������������ʱ��
{
	INT8U CJQno, Meterno,i;
	TS ts;
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	Meterno = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
	Jproginfo->RealData.CaijiqiNo = CJQno;
	Jproginfo->RealData.MeterNo = Meterno;
	SetDataFlag97(0xa4, 0x10, Jproginfo->RealData.flg97[0].flg.Dataflag);//���������й����������
	SetDataFlag97(0xb4, 0x10, Jproginfo->RealData.flg97[1].flg.Dataflag);//���������й��������������ʱ��
	SetDataFlag97(0xa4, 0x11, Jproginfo->RealData.flg97[2].flg.Dataflag);//���·���1�����й��������
	SetDataFlag97(0xb4, 0x11, Jproginfo->RealData.flg97[3].flg.Dataflag);//���·���1�����й������������ʱ��
	SetDataFlag97(0xa4, 0x12, Jproginfo->RealData.flg97[4].flg.Dataflag);//���·���2�����й��������
	SetDataFlag97(0xb4, 0x12, Jproginfo->RealData.flg97[5].flg.Dataflag);//���·���2�����й������������ʱ��
	SetDataFlag97(0xa4, 0x13, Jproginfo->RealData.flg97[6].flg.Dataflag);//���·���3�����й��������
	SetDataFlag97(0xb4, 0x13, Jproginfo->RealData.flg97[7].flg.Dataflag);//���·���3�����й������������ʱ��
	SetDataFlag97(0xa4, 0x14, Jproginfo->RealData.flg97[8].flg.Dataflag);//���·���4�����й��������
	SetDataFlag97(0xb4, 0x14, Jproginfo->RealData.flg97[9].flg.Dataflag);//���·���4�����й������������ʱ��
	Jproginfo->RealData.CurFlgCount = 10;
	//Jproginfo->RealData.ReadFlg = 0;
	for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);

	int delay = 4;
	if (Jproginfo->RealData.CurFlgCount < 20)
		delay = Jproginfo->RealData.CurFlgCount * 3;
	else
		delay = 40;
	if (delay < 10)
		delay = 10;
	if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,
				sizeof(Jproginfo->RealData));
	} else {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
	}
    Jproginfo->RealData.ReadFlg=0;
	TSGet(&ts);
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = FeiLvNum;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[0].datas[0], 3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[1].datas[0], 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[2].datas[0], 3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[3].datas[0], 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[4].datas[0], 3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[5].datas[0], 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[6].datas[0], 3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[7].datas[0], 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[8].datas[0], 3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[9].datas[0], 4);
	SendIndex = SendIndex + 4;
	//	EC();
	//TP();
	//FrameTailCreate_Send(0);
	return 1;
}
//376.1lqq++++>>>>>>>>>>>

INT16U Level1Data_F145_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���������й��������������ʱ��
{
	INT8U CJQno, Meterno,i;
	TS ts;
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	Meterno = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
	Jproginfo->RealData.CaijiqiNo = CJQno;
	Jproginfo->RealData.MeterNo = Meterno;
	SetDataFlag97(0xa0, 0x1f, Jproginfo->RealData.flg97[0].flg.Dataflag);//���������й����������
	SetDataFlag97(0xb0, 0x1f, Jproginfo->RealData.flg97[1].flg.Dataflag);//���������й��������������ʱ��
	Jproginfo->RealData.CurFlgCount = 2;
	//Jproginfo->RealData.ReadFlg = 0;
	for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);

	int delay = 4;
	if (Jproginfo->RealData.CurFlgCount < 20)
		delay = Jproginfo->RealData.CurFlgCount * 3;
	else
		delay = 40;
	if (delay < 10)
		delay = 10;
	if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,
				sizeof(Jproginfo->RealData));
	} else {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
	}
	SdPrintf(YNPrint,PreFix, "\n 1111 a01f: \n ");
	for(i=0;i<60;i++)
		SdPrintf(YNPrint," ", "%02x", tempRealTimeData.flg97[0].datas[i]);
	SdPrintf(YNPrint,PreFix,  "\n 2222 b01f: \n ");
	for(i=0;i<60;i++)
		SdPrintf(YNPrint," ",  "%02x", tempRealTimeData.flg97[1].datas[i]);
    Jproginfo->RealData.ReadFlg=0;
	TSGet(&ts);
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = FeiLvNum;

	for(i=0;i<5;i++)
	{
		if ((tempRealTimeData.flg97[0].datas[i*3]==OxXX) && (tempRealTimeData.flg97[0].datas[i*3+1]==OxXX)&&
				(tempRealTimeData.flg97[0].datas[i*3+2]==OxXX))
			memset(&SendBuff[SendIndex], OxXX, 3);
		else
			memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[0].datas[i*3], 3);
		SendIndex = SendIndex + 3;

		if ((tempRealTimeData.flg97[1].datas[i*4]==OxXX) && (tempRealTimeData.flg97[1].datas[i*4+1]==OxXX)&&
				(tempRealTimeData.flg97[1].datas[i*4+2]==OxXX)&&(tempRealTimeData.flg97[1].datas[i*4+3]==OxXX))
			memset(&SendBuff[SendIndex], OxXX, 4);
		else
			memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[1].datas[i*4], 4);
		SendIndex = SendIndex + 4;
	}
	//	EC();
	//TP();
	//FrameTailCreate_Send(0);
	return 1;
}

//added by mqingkui
INT16U Level1Data_F146_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���������޹��������������ʱ��
{
	INT8U CJQno, Meterno,i;
	TS ts;
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	Meterno = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
	Jproginfo->RealData.CaijiqiNo = CJQno;
	Jproginfo->RealData.MeterNo = Meterno;
	SetDataFlag97(0xa1, 0x10, Jproginfo->RealData.flg97[0].flg.Dataflag);//���������޹����������
	SetDataFlag97(0xb1, 0x10, Jproginfo->RealData.flg97[1].flg.Dataflag);//���������޹��������������ʱ��
	SetDataFlag97(0xa1, 0x11, Jproginfo->RealData.flg97[2].flg.Dataflag);//���·���1�����޹��������
	SetDataFlag97(0xb1, 0x11, Jproginfo->RealData.flg97[3].flg.Dataflag);//���·���1�����޹������������ʱ��
	SetDataFlag97(0xa1, 0x12, Jproginfo->RealData.flg97[4].flg.Dataflag);//���·���2�����޹��������
	SetDataFlag97(0xb1, 0x12, Jproginfo->RealData.flg97[5].flg.Dataflag);//���·���2�����޹������������ʱ��
	SetDataFlag97(0xa1, 0x13, Jproginfo->RealData.flg97[6].flg.Dataflag);//���·���3�����޹��������
	SetDataFlag97(0xb1, 0x13, Jproginfo->RealData.flg97[7].flg.Dataflag);//���·���3�����޹������������ʱ��
	SetDataFlag97(0xa1, 0x14, Jproginfo->RealData.flg97[8].flg.Dataflag);//���·���4�����޹��������
	SetDataFlag97(0xb1, 0x14, Jproginfo->RealData.flg97[9].flg.Dataflag);//���·���4�����޹������������ʱ��
	Jproginfo->RealData.CurFlgCount = 10;
	//Jproginfo->RealData.ReadFlg = 0;
	for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);

	int delay = 4;
	if (Jproginfo->RealData.CurFlgCount < 20)
		delay = Jproginfo->RealData.CurFlgCount * 3;
	else
		delay = 40;
	if (delay < 10)
		delay = 10;
	if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,
				sizeof(Jproginfo->RealData));
	} else {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
	}
    Jproginfo->RealData.ReadFlg=0;
	TSGet(&ts);
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));//����ͷ��ʼ��
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = FeiLvNum;//������M
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[0].datas[0], 3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[1].datas[0], 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[2].datas[0], 3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[3].datas[0], 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[4].datas[0], 3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[5].datas[0], 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[6].datas[0], 3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[7].datas[0], 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[8].datas[0], 3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[9].datas[0], 4);
	SendIndex = SendIndex + 4;

	//	EC();
	//TP();
	//FrameTailCreate_Send(0);//���ͱ���β��������

	return 1;
}

INT16U Level1Data_F147_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���·����й��������������ʱ��
{
	INT8U CJQno, Meterno,i;
	TS ts;
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	Meterno = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
	Jproginfo->RealData.CaijiqiNo = CJQno;
	Jproginfo->RealData.MeterNo = Meterno;
	SetDataFlag97(0xa0, 0x20, Jproginfo->RealData.flg97[0].flg.Dataflag);//���·����й����������
	SetDataFlag97(0xb0, 0x20, Jproginfo->RealData.flg97[1].flg.Dataflag);//���·����й��������������ʱ��
	SetDataFlag97(0xa0, 0x21, Jproginfo->RealData.flg97[2].flg.Dataflag);//���·���1�����й��������
	SetDataFlag97(0xb0, 0x21, Jproginfo->RealData.flg97[3].flg.Dataflag);//���·���1�����й������������ʱ��
	SetDataFlag97(0xa0, 0x22, Jproginfo->RealData.flg97[4].flg.Dataflag);//���·���2�����й��������
	SetDataFlag97(0xb0, 0x22, Jproginfo->RealData.flg97[5].flg.Dataflag);//���·���2�����й������������ʱ��
	SetDataFlag97(0xa0, 0x23, Jproginfo->RealData.flg97[6].flg.Dataflag);//���·���3�����й��������
	SetDataFlag97(0xb0, 0x23, Jproginfo->RealData.flg97[7].flg.Dataflag);//���·���3�����й������������ʱ��
	SetDataFlag97(0xa0, 0x24, Jproginfo->RealData.flg97[8].flg.Dataflag);//���·���4�����й��������
	SetDataFlag97(0xb0, 0x24, Jproginfo->RealData.flg97[9].flg.Dataflag);//���·���4�����й������������ʱ��
	Jproginfo->RealData.CurFlgCount = 10;
	//Jproginfo->RealData.ReadFlg = 0;
	for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);

	int delay = 4;
	if (Jproginfo->RealData.CurFlgCount < 20)
		delay = Jproginfo->RealData.CurFlgCount * 3;
	else
		delay = 40;
	if (delay < 10)
		delay = 10;
	if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,
				sizeof(Jproginfo->RealData));
	} else {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
	}
    Jproginfo->RealData.ReadFlg=0;
	TSGet(&ts);
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = FeiLvNum;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[0].datas[0], 3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[1].datas[0], 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[2].datas[0], 3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[3].datas[0], 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[4].datas[0], 3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[5].datas[0], 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[6].datas[0], 3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[7].datas[0], 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[8].datas[0], 3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[9].datas[0], 4);
	SendIndex = SendIndex + 4;

	//	EC();
	//TP();
	//FrameTailCreate_Send(0);
	return 1;
}

INT16U Level1Data_F148_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���·����޹��������������ʱ��
{
	INT8U CJQno, Meterno,i;
	TS ts;
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	Meterno = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
	Jproginfo->RealData.CaijiqiNo = CJQno;
	Jproginfo->RealData.MeterNo = Meterno;
	SetDataFlag97(0xa1, 0x20, Jproginfo->RealData.flg97[0].flg.Dataflag);//���·����޹����������
	SetDataFlag97(0xb1, 0x20, Jproginfo->RealData.flg97[1].flg.Dataflag);//���·����޹��������������ʱ��
	SetDataFlag97(0xa1, 0x21, Jproginfo->RealData.flg97[2].flg.Dataflag);//���·���1�����޹��������
	SetDataFlag97(0xb1, 0x21, Jproginfo->RealData.flg97[3].flg.Dataflag);//���·���1�����޹������������ʱ��
	SetDataFlag97(0xa1, 0x22, Jproginfo->RealData.flg97[4].flg.Dataflag);//���·���2�����޹��������
	SetDataFlag97(0xb1, 0x22, Jproginfo->RealData.flg97[5].flg.Dataflag);//���·���2�����޹������������ʱ��
	SetDataFlag97(0xa1, 0x23, Jproginfo->RealData.flg97[6].flg.Dataflag);//���·���3�����޹��������
	SetDataFlag97(0xb1, 0x23, Jproginfo->RealData.flg97[7].flg.Dataflag);//���·���3�����޹������������ʱ��
	SetDataFlag97(0xa1, 0x24, Jproginfo->RealData.flg97[8].flg.Dataflag);//���·���4�����޹��������
	SetDataFlag97(0xb1, 0x24, Jproginfo->RealData.flg97[9].flg.Dataflag);//���·���4�����޹������������ʱ��
	Jproginfo->RealData.CurFlgCount = 10;
	//Jproginfo->RealData.ReadFlg = 0;
	for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);

	int delay = 4;
	if (Jproginfo->RealData.CurFlgCount < 20)
		delay = Jproginfo->RealData.CurFlgCount * 3;
	else
		delay = 40;
	if (delay < 10)
		delay = 10;
	if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,
				sizeof(Jproginfo->RealData));
	} else {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
	}
    Jproginfo->RealData.ReadFlg=0;
	TSGet(&ts);
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));//����1�����ݵı���ͷ
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = FeiLvNum;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[0].datas[0], 3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[1].datas[0], 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[2].datas[0], 3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[3].datas[0], 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[4].datas[0], 3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[5].datas[0], 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[6].datas[0], 3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[7].datas[0], 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[8].datas[0], 3);
	SendIndex = SendIndex + 3;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[9].datas[0], 4);
	SendIndex = SendIndex + 4;

	//	EC();
	//TP();
	//FrameTailCreate_Send(0);//���ͱ���β��������

	return 1;
}

INT16U Level1Data_F151_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���£���һ�����գ��������������������ʱ��    9��15�ո�
{
	INT8U CJQno, Meterno,i;
	TS ts;
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	Meterno = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;

	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
	Jproginfo->RealData.CaijiqiNo = CJQno;
	Jproginfo->RealData.MeterNo = Meterno;
	SetDataFlag97(0xA4, 0x2f, Jproginfo->RealData.flg97[0].flg.Dataflag);//���·����й����������
	SetDataFlag97(0xB4, 0x2f, Jproginfo->RealData.flg97[1].flg.Dataflag);//���·����й��������������ʱ��
	Jproginfo->RealData.CurFlgCount = 4;
	//Jproginfo->RealData.ReadFlg = 0;
	for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);

	int delay = 4;
	if (Jproginfo->RealData.CurFlgCount < 20)
		delay = Jproginfo->RealData.CurFlgCount * 3;
	else
		delay = 40;
	if (delay < 10)
		delay = 10;
	if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,
				sizeof(Jproginfo->RealData));
	} else {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
	}
    Jproginfo->RealData.ReadFlg=0;
	TSGet(&ts);
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	SendBuff[SendIndex++] = FeiLvNum;
	for(i=0;i<5;i++) {
		memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[0].datas[i*3], 3);
		SendIndex = SendIndex + 3;
		memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[1].datas[i*4], 4);
		SendIndex = SendIndex + 4;
	}
	//	EC();
	//TP();
	//FrameTailCreate_Send(0);

	return 1;
}

//added by mqingkui
INT16U Level1Data_F161_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���ܱ�Զ�̿���ͨ�ϵ�״̬����¼
{
	INT8U CJQno, Meterno,i;
	TS ts;
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	Meterno = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
	Jproginfo->RealData.CaijiqiNo = CJQno;
	Jproginfo->RealData.MeterNo = Meterno;
	SetDataFlag97(0x00, 0x63, Jproginfo->RealData.flg97[0].flg.Dataflag);//���ܱ�ͨ��״̬ --
	SetDataFlag97(0x00, 0x07, Jproginfo->RealData.flg97[1].flg.Dataflag);//���һ�ε��ܱ�Զ�̿���ͨ��ʱ��--
	SetDataFlag97(0x00, 0x08, Jproginfo->RealData.flg97[2].flg.Dataflag);//���һ�ε��ܱ�Զ�̿��ƶϵ�ʱ��--
	Jproginfo->RealData.CurFlgCount = 3;
	//Jproginfo->RealData.ReadFlg = 0;
	for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);

	int delay = 4;
	if (Jproginfo->RealData.CurFlgCount < 20)
		delay = Jproginfo->RealData.CurFlgCount * 3;
	else
		delay = 40;
	if (delay < 10)
		delay = 10;
	if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,
				sizeof(Jproginfo->RealData));
	} else {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
	}
    Jproginfo->RealData.ReadFlg=0;
	TSGet(&ts);
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));//����1�����ݵı���ͷ
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;

	SendBuff[SendIndex]=(tempRealTimeData.flg97[0].datas[1]>>6)&0x01;
	SendIndex = SendIndex + 1;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[1].datas[1], 5);
	SendIndex = SendIndex + 5;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[2].datas[1], 5);
	SendIndex = SendIndex + 5;

	//	EC();
	//TP();
	//FrameTailCreate_Send(0);//���ͱ���β��������

	return 1;
}
//added by mqingkui
INT16U Level1Data_F165_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���ܱ����ز���������ʱ��
{
	INT8U CJQno, MeterNo, MeterType;
	TS ts;
	F165_t f165;
	INT16U count = 0;
	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
//	if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;

	if(access("/nand/para/f165.par",0)==0)
	{
		NormalReadFile("/nand/para/f165.par", &f165, sizeof(F165_t),Jproginfo);
		count = f165.program_count & 0xffff;
		INT32U_BCD(count&0xff, &SendBuff[SendIndex++], 1);
		INT32U_BCD(count>>8, &SendBuff[SendIndex++], 1);
		INT32U_BCD(f165.program_ts.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(f165.program_ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
		INT32U_BCD(f165.program_ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
		INT32U_BCD(f165.program_ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
		INT32U_BCD(f165.program_ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;

		count = f165.weigai_count & 0xffff;
		INT32U_BCD(count&0xff, &SendBuff[SendIndex++], 1);
		INT32U_BCD(count>>8, &SendBuff[SendIndex++], 1);
		INT32U_BCD(f165.weigai_ts.Minute, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(f165.weigai_ts.Hour, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(f165.weigai_ts.Day, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(f165.weigai_ts.Month, &SendBuff[SendIndex], 1);
		SendIndex++;
		INT32U_BCD(f165.weigai_ts.Year%100, &SendBuff[SendIndex], 1);
		SendIndex++;
	}
	else
	{
		memset(&SendBuff[SendIndex],0,14);
		SendIndex=SendIndex+14;
	}
	return 1;
}
//added by mqingkui
INT16U Level1Data_F166_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���ܱ������޸Ĵ�����ʱ��
{
	INT8U CJQno, Meterno,i;
	TS ts;
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	Meterno = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
	Jproginfo->RealData.CaijiqiNo = CJQno;
	Jproginfo->RealData.MeterNo = Meterno;
	SetDataFlag97(0x00, 0x42, Jproginfo->RealData.flg97[0].flg.Dataflag);//���ܱ�ʱ���޸Ĵ���--
	SetDataFlag97(0x00, 0x43, Jproginfo->RealData.flg97[1].flg.Dataflag);//���ܱ����һ��ʱ���޸�ʱ��--
	SetDataFlag97(0x00, 0x56, Jproginfo->RealData.flg97[2].flg.Dataflag);//���ܱ�ʱ�β����޸Ĵ���--
	SetDataFlag97(0x00, 0x57, Jproginfo->RealData.flg97[3].flg.Dataflag);//���һ�ε��ܱ�ʱ�β����޸�ʱ��--
	Jproginfo->RealData.CurFlgCount = 4;
	//Jproginfo->RealData.ReadFlg = 0;
	for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);

	int delay = 4;
	if (Jproginfo->RealData.CurFlgCount < 20)
		delay = Jproginfo->RealData.CurFlgCount * 3;
	else
		delay = 40;
	if (delay < 10)
		delay = 10;
	if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,
				sizeof(Jproginfo->RealData));
	} else {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
	}
    Jproginfo->RealData.ReadFlg=0;
	TSGet(&ts);
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));//����1�����ݵı���ͷ
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[0].datas[0], 2);
	SendIndex = SendIndex + 2;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[1].datas[1], 5);
	SendIndex = SendIndex + 5;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[2].datas[0], 2);
	SendIndex = SendIndex + 2;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[3].datas[1], 5);
	SendIndex = SendIndex + 5;
	//	EC();
	//TP();
	//FrameTailCreate_Send(0);//���ͱ���β��������

	return 1;
}
//added by mqingkui
INT16U Level1Data_F167_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���ܱ������õ���Ϣ
{
	INT8U CJQno, Meterno,i;
	TS ts;
	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	Meterno = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
	Jproginfo->RealData.CaijiqiNo = CJQno;
	Jproginfo->RealData.MeterNo = Meterno;
	SetDataFlag97(0x00, 0x91, Jproginfo->RealData.flg97[0].flg.Dataflag);//�������--
	SetDataFlag97(0x00, 0x92, Jproginfo->RealData.flg97[1].flg.Dataflag);//ʣ����--
	SetDataFlag97(0x00, 0x93, Jproginfo->RealData.flg97[2].flg.Dataflag);//�ۼƹ�����--
	SetDataFlag97(0x00, 0x94, Jproginfo->RealData.flg97[3].flg.Dataflag);//ʣ�����--
	SetDataFlag97(0x00, 0x95, Jproginfo->RealData.flg97[4].flg.Dataflag);//͸֧����--
	SetDataFlag97(0x00, 0x96, Jproginfo->RealData.flg97[5].flg.Dataflag);//�ۼƹ�����--
	SetDataFlag97(0x00, 0x97, Jproginfo->RealData.flg97[6].flg.Dataflag);//��Ƿ���޵���--
	SetDataFlag97(0x00, 0x98, Jproginfo->RealData.flg97[7].flg.Dataflag);//��������--
	SetDataFlag97(0x00, 0x99, Jproginfo->RealData.flg97[8].flg.Dataflag);//���ϵ���--
	Jproginfo->RealData.CurFlgCount = 9;
	//Jproginfo->RealData.ReadFlg = 0;
	for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
		memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);

	int delay = 4;
	if (Jproginfo->RealData.CurFlgCount < 20)
		delay = Jproginfo->RealData.CurFlgCount * 3;
	else
		delay = 40;
	if (delay < 10)
		delay = 10;
	if (GetRealTimeDatas(1000, delay,Jproginfo) == 9) {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,
				sizeof(Jproginfo->RealData));
	} else {
		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
	}
    Jproginfo->RealData.ReadFlg=0;
	TSGet(&ts);
	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));//����1�����ݵı���ͷ
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[0].datas[0], 2);
	SendIndex = SendIndex + 2;
	SendBuff[SendIndex++]=0x00;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[1].datas[0], 4);
	SendIndex = SendIndex + 4;
	SendBuff[SendIndex++]=0x00;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[2].datas[0], 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[3].datas[0], 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[4].datas[0], 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[5].datas[0], 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[6].datas[0], 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[7].datas[0], 4);
	SendIndex = SendIndex + 4;
	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[8].datas[0], 4);
	SendIndex = SendIndex + 4;

	//	EC();
	//TP();
	//FrameTailCreate_Send(0);//���ͱ���β��������

	return 1;
}
//added by mqingkui
INT16U Level1Data_F168_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���ܱ�������Ϣ
{
//	INT8U CJQno, Meterno,i;
//	TS ts;
//	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
//	Meterno = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
//	memset(Jproginfo->RealData.flg97, 0, sizeof(Jproginfo->RealData.flg97));
//	Jproginfo->RealData.CaijiqiNo = CJQno;
//	Jproginfo->RealData.MeterNo = Meterno;
//	SetDataFlag97(0xff, 0x00, Jproginfo->RealData.flg97[0].flg.Dataflag);//�ѽ��й��ܵ���--
//	SetDataFlag97(0xff, 0x01, Jproginfo->RealData.flg97[1].flg.Dataflag);//�ѽ����1�����й��ܵ���--
//	SetDataFlag97(0xff, 0x02, Jproginfo->RealData.flg97[2].flg.Dataflag);//�ѽ����2�����й��ܵ���--
//	SetDataFlag97(0xff, 0x03, Jproginfo->RealData.flg97[3].flg.Dataflag);//�ѽ����3�����й��ܵ���--
//	SetDataFlag97(0xff, 0x04, Jproginfo->RealData.flg97[4].flg.Dataflag);//�ѽ����4�����й��ܵ���--
//	SetDataFlag97(0xff, 0x10, Jproginfo->RealData.flg97[5].flg.Dataflag);//δ���й��ܵ���--
//	SetDataFlag97(0xff, 0x11, Jproginfo->RealData.flg97[6].flg.Dataflag);//δ�����1�����й��ܵ���--
//	SetDataFlag97(0xff, 0x12, Jproginfo->RealData.flg97[7].flg.Dataflag);//δ�����2�����й��ܵ���--
//	SetDataFlag97(0xff, 0x13, Jproginfo->RealData.flg97[8].flg.Dataflag);//δ�����3�����й��ܵ���--
//	SetDataFlag97(0xff, 0x14, Jproginfo->RealData.flg97[9].flg.Dataflag);//δ�����4�����й��ܵ���--
//	Jproginfo->RealData.CurFlgCount = 10;
//	//Jproginfo->RealData.ReadFlg = 0;
//	for(i=0;i<Jproginfo->RealData.CurFlgCount;i++)
//		memset(Jproginfo->RealData.flg97[i].datas,OxXX,DataLenMax);
//
//	int delay = 4;
//	if (Jproginfo->RealData.CurFlgCount < 20)
//		delay = Jproginfo->RealData.CurFlgCount * 3;
//	else
//		delay = 40;
//	if (delay < 10)
//		delay = 10;
//	if (GetRealTimeDatas(1000, delay) == 9) {
//		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,
//				sizeof(Jproginfo->RealData));
//	} else {
//		memcpy(&tempRealTimeData.ReadFlg, &Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
//	}
//    Jproginfo->RealData.ReadFlg=0;
//	TSGet(&ts);
//	//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));//����1�����ݵı���ͷ
//	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
//	SendIndex++;
//	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
//	SendIndex++;
//	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
//	SendIndex++;
//	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
//	SendIndex++;
//	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
//	SendIndex++;
//	SendBuff[SendIndex++] = FeiLvNum;//������M
//	SendBuff[SendIndex++] = 0x00; //������ռ�����ֽڣ����ֽ���ǰ
//
//	SendBuff[SendIndex++] = 0x00;
//	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[0].datas[0], 4);
//	SendIndex = SendIndex + 4;
//	SendBuff[SendIndex++] = 0x00;
//	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[1].datas[0], 4);
//	SendIndex = SendIndex + 4;
//	SendBuff[SendIndex++] = 0x00;
//	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[2].datas[0], 4);
//	SendIndex = SendIndex + 4;
//	SendBuff[SendIndex++] = 0x00;
//	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[3].datas[0], 4);
//	SendIndex = SendIndex + 4;
//	SendBuff[SendIndex++] = 0x00;
//	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[4].datas[0], 4);
//	SendIndex = SendIndex + 4;
//	SendBuff[SendIndex++] = 0x00;
//	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[5].datas[0], 4);
//	SendIndex = SendIndex + 4;
//	SendBuff[SendIndex++] = 0x00;
//	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[6].datas[0], 4);
//	SendIndex = SendIndex + 4;
//	SendBuff[SendIndex++] = 0x00;
//	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[7].datas[0], 4);
//	SendIndex = SendIndex + 4;
//	SendBuff[SendIndex++] = 0x00;
//	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[8].datas[0], 4);
//	SendIndex = SendIndex + 4;
//	SendBuff[SendIndex++] = 0x00;
//	memcpy(&SendBuff[SendIndex], &tempRealTimeData.flg97[9].datas[0], 4);
//	SendIndex = SendIndex + 4;
//
//	//	EC();
//	//TP();
//	//FrameTailCreate_Send(0);//���ͱ���β��������
	INT8U CJQno, MeterNo, MeterType;
	TS ts;
	int portn=JSetPara_AFN04_3761_2009->group2.f10[P-1].port;
	if (portn == LocalCommPort)
		portn=CarrWavePort;

	CJQno = JSetPara_AFN04_3761_2009->group2.f10[P-1].CjqNo-1;
	MeterNo = JSetPara_AFN04_3761_2009->group2.f10[P-1].MeterNo;
	MeterType = JSetPara_AFN04_3761_2009->group2.f10[P-1].Type;
	TSGet(&ts);
//	if (AutoFlg==0)	MkLevel1Head(P, F, 0x88|(PrmFlg<<6));
	INT32U_BCD(ts.Minute, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Hour, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Day, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Month, &SendBuff[SendIndex], 1);
	SendIndex++;
	INT32U_BCD(ts.Year%100, &SendBuff[SendIndex], 1);
	SendIndex++;

	SendBuff[SendIndex++] = FeiLvNum;
	SendBuff[SendIndex++] = 0;
	memset(&SendBuff[SendIndex],0,50);
	SendIndex=SendIndex+50;
	return 1;
}

INT16U Level1Data_F169_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���г������ܱ�������Ϣ
{
	SdPrintf(YNPrint,PreFix,  "\nLevel1Data_F169_Get\n");
	SendBuff[SendIndex++] = 31;
	SendBuff[SendIndex++] = 0;
	SendBuff[SendIndex++] = 0;
	return 1;
}
INT16U Level1Data_F170_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//���г������ܱ�������Ϣ
{
	SdPrintf(YNPrint,PreFix,  "\nLevel1Data_F170_Get\n");
	TS ts;
	SendBuff[SendIndex++] = 31;
	SendBuff[SendIndex++] = 0;
	SendBuff[SendIndex++] = 0;
	SendBuff[SendIndex++] = 0xFF;
	SendBuff[SendIndex++] = 1;
	ts = Jdatafileinfo->data485[29+PortBegNum].ts_begin;
	SendBuff[SendIndex++] = ((ts.Sec / 10) << 4) + (ts.Sec % 10);
	SendBuff[SendIndex++] = ((ts.Minute / 10) << 4) + (ts.Minute % 10);
	SendBuff[SendIndex++] = ((ts.Hour / 10) << 4) + (ts.Hour % 10);
	SendBuff[SendIndex++] = ((ts.Day / 10) << 4) + (ts.Day % 10);
	if (ts.Week == 0) {
		SendBuff[SendIndex++] = ((ts.Month / 10) << 4) + (ts.Month % 10) + 0xe0;
	} else {
		SendBuff[SendIndex++] = ((ts.Month / 10) << 4) + (ts.Month % 10)
				+ (ts.Week << 5);
	}
	SendBuff[SendIndex++] = (((ts.Year % 100) / 10) << 4) + (ts.Year % 10);
	//TSGet(&ts);//��ȡʱ��
	ts = Jdatafileinfo->data485[29+PortBegNum].ts;
	SendBuff[SendIndex++] = ((ts.Sec / 10) << 4) + (ts.Sec % 10);
	SendBuff[SendIndex++] = ((ts.Minute / 10) << 4) + (ts.Minute % 10);
	SendBuff[SendIndex++] = ((ts.Hour / 10) << 4) + (ts.Hour % 10);
	SendBuff[SendIndex++] = ((ts.Day / 10) << 4) + (ts.Day % 10);
	if (ts.Week == 0) {
		SendBuff[SendIndex++] = ((ts.Month / 10) << 4) + (ts.Month % 10) + 0xe0;
	} else {
		SendBuff[SendIndex++] = ((ts.Month / 10) << 4) + (ts.Month % 10)
				+ (ts.Week << 5);
	}
	SendBuff[SendIndex++] = (((ts.Year % 100) / 10) << 4) + (ts.Year % 10);


	SendBuff[SendIndex++] = 0;
	return 1;
}
INT16U Level1Data_F186_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)//�ز�ģ�����汾��
{
	FILE *fp;
	INT8U strVersion[50];
	memset(strVersion, 0, 50);
	fp=fopen("/nand/bin/zbversion","r");
	if(fp==NULL)
	{
		SdPrintf(YNPrint,PreFix,"CallSetting_F248_Set open file 'zbversion' failed!!!!\n");
		fclose(fp);
		return 4;
	}
	fscanf(fp, "%s",strVersion);
	SdPrintf(YNPrint,PreFix,"zb strVersion:  %s",strVersion);
	//if (AutoFlg==0)
		//MkLevel1Head(P, F, 0x88|(PrmFlg<<6));//����1�����ݵı���ͷ

	SendBuff[SendIndex++] = strVersion[0];
	SendBuff[SendIndex++] = strVersion[1];
	SendBuff[SendIndex++] = strVersion[2];
	SendBuff[SendIndex++] = strVersion[3];
	ASCToBCD(&strVersion[4], 2, &SendBuff[SendIndex++]);
	ASCToBCD(&strVersion[6], 2, &SendBuff[SendIndex++]);
	ASCToBCD(&strVersion[8], 2, &SendBuff[SendIndex++]);
	ASCToBCD(&strVersion[10], 2, &SendBuff[SendIndex++]);
	ASCToBCD(&strVersion[12], 2, &SendBuff[SendIndex++]);
	fclose(fp);

	if (AutoFlg!=0)
		return 1;
	//	EC();
	//TP();
	//FrameTailCreate_Send(0);//���ͱ���β��������
	return 1;
}
INT16U Level1Data_F248_Get(INT8U Set, INT16U F, INT16U P, INT8U *Data)
{
	//68 32 00 32 00 68 4B 02 35 02 00 02 0C 60 10 01 80 1E 14 16


	int i=0,num=0,port;
	INT8U FirFin=0,indtmp=0,tmp1=0,tmp2=0,tmp3=0;
	INT8U CJQno, MeterNo, MeterType;
	INT16U IsDataFlag,dftype;
	INT8U Temp_FilePath[60];
	TS ts;

	for(i=0;i<PointMax;i++)
	{
		if (JSetPara_AFN04_3761_2009->group2.f10[i].Status!=1)
			continue;
		FirFin=0;
		if ((num%7)==0)
		{
			if(num>6)
			{
				//	EC();
				////TP();
				//FrameTailCreate_Send(0);
			}

			CreateGWHead(0x88|(PrmFlg<<6), 0);
			SendBuff[SendIndex++] = 0x0c;//afn
			if (num == 0)
				FirFin = 0x40;
			indtmp=SendIndex;
			SendBuff[SendIndex++] = FirFin | (Fseq & 0x0f);//seq��һ�壬��������
			tmp1=SendIndex;
			SendBuff[SendIndex++] |= SetDa1(i+1);
			tmp2=SendIndex;
			SendBuff[SendIndex++] |= SetDa2(i+1);
			SendBuff[SendIndex++] = SetDt1(F);
			SendBuff[SendIndex++] = SetDt2(F);
			if (JSetPara_AFN04_3761_2009->group2.f10[i].port==LocalCommPort)
				port=CarrWavePort;
			else port=JSetPara_AFN04_3761_2009->group2.f10[i].port;
			
			INT32U_BCD(Jdatafileinfo->data485[port-1].ts.Minute, &SendBuff[SendIndex++], 1);
			INT32U_BCD(Jdatafileinfo->data485[port-1].ts.Hour, &SendBuff[SendIndex++], 1);
			INT32U_BCD(Jdatafileinfo->data485[port-1].ts.Day, &SendBuff[SendIndex++], 1);
			INT32U_BCD(Jdatafileinfo->data485[port-1].ts.Month, &SendBuff[SendIndex++], 1);
			INT32U_BCD(Jdatafileinfo->data485[port-1].ts.Year%100, &SendBuff[SendIndex++], 1);
			tmp3=SendIndex;
			SendBuff[SendIndex++] = 7;

		}
		SendBuff[tmp1] = 0xff;
		SendBuff[tmp2] = 0xff;
		SendBuff[SendIndex++] = SetDa1(i+1);
		SendBuff[SendIndex++] = SetDa2(i+1);
		SendBuff[SendIndex++] = FeiLvNum;
		CJQno = JSetPara_AFN04_3761_2009->group2.f10[i].CjqNo-1;
		MeterNo = JSetPara_AFN04_3761_2009->group2.f10[i].MeterNo;
		MeterType = JSetPara_AFN04_3761_2009->group2.f10[i].Type;
		memset(Temp_FilePath,0,60);
		sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",i+1);
		if ((MeterType == 9) || (MeterType == 6))
		{
			dftype=1;//comm
		}
		else
		{
			dftype=1;
		}
		IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath,ts,1);
		if(IsDataFlag==1)
		{
			IsDataFlag=getMetersData(MeterType,&SendBuff[SendIndex],CJQno,MeterNo,0x90,0x10,0,4,5,1,0,0,0,dftype);
			if (IsDataFlag == 0)
			{
				memset(&SendBuff[SendIndex],OxXX,25);
			}
			SendIndex = SendIndex + 25;
		}
		else
		{
			memset(&SendBuff[SendIndex],OxXX,25);
			SendIndex = SendIndex + 25;
		}

		num++;

	}
	if ((num%7)!=0)
	{
		SendBuff[tmp3]=(num%7);
		FirFin = FirFin | 0x20;
		SendBuff[indtmp]=FirFin | (Fseq & 0x0f);
		//	EC();
		//TP();
		//FrameTailCreate_Send(0);//���ͱ���β��������
	}
	return 1;
}
