#include <stdlib.h>
#include <stdio.h>
//#include "update.h"
#include "../jBase/inc/pubfunction.h"
#include "esam.h"
#include <time.h>
#include "innerPubVar.h"
#include "jGWProtocol.h"
#include "datadeal.h"
#include "j3761_2009.h"
#include "update.h"
#define  FRAME_MAX     700

//////////////////////  lwadd///////////////////////////////
#define CHECK_OK   1
#define CHECK_FAIL 2
struct filetrans_t
{
	INT8U file_ID;
	INT8U file_Attribute;
	INT8U file_Instruction;
	INT16U total; //�ܶ���
	INT32U curr_segment_id;
	INT16U curr_segment_size;     //��ǰ�γ���
	INT8U trans_State;  //0 ��ʼֵδ������  1 ����������   9 �������
	INT8U check_flag;  //0��ʼ  1��ȷ  2����
};
struct filetrans_t file_format;
INT8U SEQ_FILE;
INT8U FRAME_TP[6];
INT8U CtrlCode;
int indexup=1;
////////////////////////  lwadd/////////////////////////////////////

//name_attach_t *attach;
const DATAGW_TYPE DataGWList[]={
		{0,0,0,SetPara_F0_Set},
		{J_SETPARA,	1,	1,	SetPara_F1_Set},
		{J_SETPARA,	2,	1,	SetPara_F2_Set},
		{J_SETPARA,	3,	1,	SetPara_F3_Set},
		{J_SETPARA,	4,	1,	SetPara_F4_Set},
		{J_SETPARA,	5,	1,	SetPara_F5_Set},
		{J_SETPARA,	6,	1,	SetPara_F6_Set},
		{J_SETPARA,	7,	1,	SetPara_F7_Set},
		{J_SETPARA,	8,	1,	SetPara_F8_Set},
		{J_SETPARA,	9,	1,	SetPara_F9_Set},
		{J_SETPARA,	10,	1,	SetPara_F10_Set},
		{J_SETPARA,	11,	1,	SetPara_F11_Set},
		{J_SETPARA,	12,	1,	SetPara_F12_Set},
		{J_SETPARA,	13,	1,	SetPara_F13_Set},
		{J_SETPARA,	14,	1,	SetPara_F14_Set},
		{J_SETPARA,	15,	1,	SetPara_F15_Set},
		{J_SETPARA,	16,	1,	SetPara_F16_Set},
//		{J_SETPARA,	17,	1,	SetPara_F17_Set},
		{J_SETPARA,	18,	1,	SetPara_F18_Set},
		{J_SETPARA,	19,	1,	SetPara_F19_Set},
		{J_SETPARA,	20,	1,	SetPara_F20_Set},
		{J_SETPARA,	21,	1,	SetPara_F21_Set},
		{J_SETPARA,	22,	1,	SetPara_F22_Set},
		{J_SETPARA,	23,	1,	SetPara_F23_Set},
//		{J_SETPARA,	24,	1,	SetPara_F24_Set},
		{J_SETPARA,	25,	1,	SetPara_F25_Set},
		{J_SETPARA,	26,	1,	SetPara_F26_Set},
		{J_SETPARA,	27,	1,	SetPara_F27_Set},
		{J_SETPARA,	28,	1,	SetPara_F28_Set},
		{J_SETPARA,	29,	1,	SetPara_F29_Set},
		{J_SETPARA,	30,	1,	SetPara_F30_Set},
		{J_SETPARA,	31,	1,	SetPara_F31_Set},
//		{J_SETPARA,	32,	1,	SetPara_F32_Set},
		{J_SETPARA,	33,	1,	SetPara_F33_Set},
		{J_SETPARA,	34,	1,	SetPara_F34_Set},
		{J_SETPARA,	35,	1,	SetPara_F35_Set},
		{J_SETPARA,	36,	1,	SetPara_F36_Set},
		{J_SETPARA,	37,	1,	SetPara_F37_Set},
		{J_SETPARA,	38,	1,	SetPara_F38_Set},
		{J_SETPARA,	39,	1,	SetPara_F39_Set},
//		{J_SETPARA,	40,	1,	SetPara_F40_Set},
//		{J_SETPARA,	41,	1,	SetPara_F41_Set},
//		{J_SETPARA,	42,	1,	SetPara_F42_Set},
//		{J_SETPARA,	43,	1,	SetPara_F43_Set},
//		{J_SETPARA,	44,	1,	SetPara_F44_Set},
//		{J_SETPARA,	45,	1,	SetPara_F45_Set},
//		{J_SETPARA,	46,	1,	SetPara_F46_Set},
		{J_SETPARA,	47,	1,	SetPara_F47_Set},
//		{J_SETPARA,	48,	1,	SetPara_F48_Set},
//		{J_SETPARA,	49,	1,	SetPara_F49_Set},
//		{J_SETPARA,	50,	1,	SetPara_F50_Set},
//		{J_SETPARA,	51,	1,	SetPara_F51_Set},
//		{J_SETPARA,	52,	1,	SetPara_F52_Set},
//		{J_SETPARA,	53,	1,	SetPara_F53_Set},
//		{J_SETPARA,	54,	1,	SetPara_F54_Set},
//		{J_SETPARA,	55,	1,	SetPara_F55_Set},
//		{J_SETPARA,	56,	1,	SetPara_F56_Set},
		{J_SETPARA,	57,	1,	SetPara_F57_Set},
//		{J_SETPARA,	58,	1,	SetPara_F58_Set},
		{J_SETPARA,	59,	1,	SetPara_F59_Set},
		{J_SETPARA,	60,	1,	SetPara_F60_Set},
//		{J_SETPARA,	61,	1,	SetPara_F61_Set},
//		{J_SETPARA,	62,	1,	SetPara_F62_Set},
//		{J_SETPARA,	63,	1,	SetPara_F63_Set},
//		{J_SETPARA,	64,	1,	SetPara_F64_Set},
		{J_SETPARA,	65,	1,	SetPara_F65_Set},
		{J_SETPARA,	66,	1,	SetPara_F66_Set},
		{J_SETPARA,	67,	1,	SetPara_F67_Set},
		{J_SETPARA,	68,	1,	SetPara_F68_Set},
//		{J_SETPARA,	69,	1,	SetPara_F69_Set},
//		{J_SETPARA,	70,	1,	SetPara_F70_Set},
//		{J_SETPARA,	71,	1,	SetPara_F71_Set},
//		{J_SETPARA,	72,	1,	SetPara_F72_Set},
//		{J_SETPARA,	73,	1,	SetPara_F73_Set},
//		{J_SETPARA,	74,	1,	SetPara_F74_Set},
//		{J_SETPARA,	75,	1,	SetPara_F75_Set},
//		{J_SETPARA,	76,	1,	SetPara_F76_Set},
//		{J_SETPARA,	77,	1,	SetPara_F77_Set},
//		{J_SETPARA,	78,	1,	SetPara_F78_Set},
//		{J_SETPARA,	79,	1,	SetPara_F79_Set},
//		{J_SETPARA,	80,	1,	SetPara_F80_Set},
//		{J_SETPARA,	81,	1,	SetPara_F81_Set},
//		{J_SETPARA,	82,	1,	SetPara_F82_Set},
//		{J_SETPARA,	83,	1,	SetPara_F83_Set},
//		{J_SETPARA,	84,	1,	SetPara_F84_Set},
//		{J_SETPARA,	85,	1,	SetPara_F85_Set},
//		{J_SETPARA,	86,	1,	SetPara_F86_Set},
//		{J_SETPARA,	87,	1,	SetPara_F87_Set},
//		{J_SETPARA,	88,	1,	SetPara_F88_Set},
//		{J_SETPARA,	89,	1,	SetPara_F89_Set},
//		{J_SETPARA,	90,	1,	SetPara_F90_Set},
//		{J_SETPARA,	91,	1,	SetPara_F91_Set},
//		{J_SETPARA,	92,	1,	SetPara_F92_Set},
//		{J_SETPARA,	93,	1,	SetPara_F93_Set},
//		{J_SETPARA,	94,	1,	SetPara_F94_Set},
//		{J_SETPARA,	95,	1,	SetPara_F95_Set},
//		{J_SETPARA,	96,	1,	SetPara_F96_Set},
//		{J_SETPARA,	97,	1,	SetPara_F97_Set},
//		{J_SETPARA,	98,	1,	SetPara_F98_Set},
//		{J_SETPARA,	99,	1,	SetPara_F99_Set},
//		{J_SETPARA,	100, 1,	SetPara_F100_Set},
//		{J_SETPARA,	101, 1,	SetPara_F101_Set},
//		{J_SETPARA,	102, 1,	SetPara_F102_Set},
//		{J_SETPARA,	103, 1,	SetPara_F103_Set},
//		{J_SETPARA,	104, 1,	SetPara_F104_Set},
//		{J_SETPARA,	105, 1,	SetPara_F105_Set},
//		{J_SETPARA,	106, 1,	SetPara_F106_Set},
//		{J_SETPARA,	107, 1,	SetPara_F107_Set},
//		{J_SETPARA,	108, 1,	SetPara_F108_Set},
//		{J_SETPARA,	109, 1,	SetPara_F109_Set},
//		{J_SETPARA,	110, 1,	SetPara_F110_Set},
		{J_SETPARA,	111, 1,	SetPara_F111_Set},
		{J_SETPARA,	112, 1,	SetPara_F112_Set},
#ifdef SHANGHAI
		{J_SETPARA, 241, 1, SetPara_F241_Set},
		{J_SETPARA, 242, 1, SetPara_F242_Set},
		{J_SETPARA, 243, 1, SetPara_F243_Set},
#endif
		{J_QUERYPARA,	1,	2,	CallSetting_F01_Set},
        {J_QUERYPARA,	2,	2,	CallSetting_F02_Set},
		{J_QUERYPARA,	3,	2,	CallSetting_F03_Set},
		{J_QUERYPARA,	4,	2,	CallSetting_F04_Set},
		{J_QUERYPARA,	5,	2,	CallSetting_F05_Set},
		{J_QUERYPARA,	6,	2,	CallSetting_F06_Set},
		{J_QUERYPARA,	7,	2,	CallSetting_F07_Set},
		{J_QUERYPARA,	8,	2,	CallSetting_F08_Set},
//*********************************************************
		{J_1LEIDATE,	1,	3,	Level1Data_F1_Get},
		{J_1LEIDATE,	2,	3,	Level1Data_F2_Get},
		{J_1LEIDATE,	3,	3,	Level1Data_F3_Get},
		{J_1LEIDATE,	4,	3,	Level1Data_F4_Get},
		{J_1LEIDATE,	5,	3,	Level1Data_F5_Get},
		{J_1LEIDATE,	6,	3,	Level1Data_F6_Get},
		{J_1LEIDATE,	7,	3,	Level1Data_F7_Get},
		{J_1LEIDATE,	8,	3,	Level1Data_F8_Get},
		{J_1LEIDATE,	9,	3,	Level1Data_F9_Get},
		{J_1LEIDATE,	10,	3,	Level1Data_F10_Get},
		{J_1LEIDATE,	11,	3,	Level1Data_F11_Get},
		{J_1LEIDATE,	12,	3,	Level1Data_F12_Get},
		{J_1LEIDATE,	13,	3,	Level1Data_F13_Get},
		{J_1LEIDATE,	14,	3,	Level1Data_F14_Get},
//		{J_1LEIDATE,	15,	3,	Level1Data_F15_Get},
//		{J_1LEIDATE,	16,	3,	Level1Data_F16_Get},
		{J_1LEIDATE,	17,	3,	Level1Data_F17_Get},
		{J_1LEIDATE,	18,	3,	Level1Data_F18_Get},
//		{J_1LEIDATE,	19,	3,	Level1Data_F19_Get},
//		{J_1LEIDATE,	20,	3,	Level1Data_F20_Get},
//		{J_1LEIDATE,	21,	3,	Level1Data_F21_Get},
//		{J_1LEIDATE,	22,	3,	Level1Data_F22_Get},
//		{J_1LEIDATE,	23,	3,	Level1Data_F23_Get},
//		{J_1LEIDATE,	24,	3,	Level1Data_F24_Get},
		{J_1LEIDATE,	25,	3,	Level1Data_F25_Get},
		{J_1LEIDATE,	26,	3,	Level1Data_F26_Get},
		{J_1LEIDATE,	27,	3,	Level1Data_F27_Get},
		{J_1LEIDATE,	28,	3,	Level1Data_F28_Get},
//		{J_1LEIDATE,	29,	3,	Level1Data_F29_Get},
//		{J_1LEIDATE,	30,	3,	Level1Data_F30_Get},
		{J_1LEIDATE,	31,	3,	Level1Data_F31_Get},
		{J_1LEIDATE,	32,	3,	Level1Data_F32_Get},
		{J_1LEIDATE,	33,	3,	Level1Data_F33_Get},
		{J_1LEIDATE,	34,	3,	Level1Data_F34_Get},
		{J_1LEIDATE,	35,	3,	Level1Data_F35_Get},
		{J_1LEIDATE,	36,	3,	Level1Data_F36_Get},
		{J_1LEIDATE,	37,	3,	Level1Data_F37_Get},
		{J_1LEIDATE,	38,	3,	Level1Data_F38_Get},
		{J_1LEIDATE,	39,	3,	Level1Data_F39_Get},
		{J_1LEIDATE,	40,	3,	Level1Data_F40_Get},
//		{J_1LEIDATE,	41,	3,	Level1Data_F41_Get},
//		{J_1LEIDATE,	42,	3,	Level1Data_F42_Get},
//		{J_1LEIDATE,	43,	3,	Level1Data_F43_Get},
//		{J_1LEIDATE,	44,	3,	Level1Data_F44_Get},
//		{J_1LEIDATE,	45,	3,	Level1Data_F45_Get},
//		{J_1LEIDATE,	46,	3,	Level1Data_F46_Get},
//		{J_1LEIDATE,	47,	3,	Level1Data_F47_Get},
//		{J_1LEIDATE,	48,	3,	Level1Data_F48_Get},
		{J_1LEIDATE,	49,	3,	Level1Data_F49_Get},
//		{J_1LEIDATE,	50,	3,	Level1Data_F50_Get},
//		{J_1LEIDATE,	51,	3,	Level1Data_F51_Get},
//		{J_1LEIDATE,	52,	3,	Level1Data_F52_Get},
//		{J_1LEIDATE,	53,	3,	Level1Data_F53_Get},
//		{J_1LEIDATE,	54,	3,	Level1Data_F54_Get},
//		{J_1LEIDATE,	55,	3,	Level1Data_F55_Get},
//		{J_1LEIDATE,	56,	3,	Level1Data_F56_Get},
//		{J_1LEIDATE,	57,	3,	Level1Data_F57_Get},
//		{J_1LEIDATE,	58,	3,	Level1Data_F58_Get},
//		{J_1LEIDATE,	59,	3,	Level1Data_F59_Get},
//		{J_1LEIDATE,	60,	3,	Level1Data_F60_Get},
//		{J_1LEIDATE,	61,	3,	Level1Data_F61_Get},
//		{J_1LEIDATE,	62,	3,	Level1Data_F62_Get},
//		{J_1LEIDATE,	63,	3,	Level1Data_F63_Get},
//		{J_1LEIDATE,	64,	3,	Level1Data_F64_Get},
//		{J_1LEIDATE,	65,	3,	Level1Data_F65_Get},
//		{J_1LEIDATE,	66,	3,	Level1Data_F66_Get},
//		{J_1LEIDATE,	67,	3,	Level1Data_F67_Get},
//		{J_1LEIDATE,	68,	3,	Level1Data_F68_Get},
//		{J_1LEIDATE,	69,	3,	Level1Data_F69_Get},
//		{J_1LEIDATE,	70,	3,	Level1Data_F70_Get},
//		{J_1LEIDATE,	71,	3,	Level1Data_F71_Get},
//		{J_1LEIDATE,	72,	3,	Level1Data_F72_Get},
		{J_1LEIDATE,	73,	3,	Level1Data_F73_Get},
//		{J_1LEIDATE,	74,	3,	Level1Data_F74_Get},
//		{J_1LEIDATE,	75,	3,	Level1Data_F75_Get},
//		{J_1LEIDATE,	76,	3,	Level1Data_F76_Get},
//		{J_1LEIDATE,	77,	3,	Level1Data_F77_Get},
//		{J_1LEIDATE,	78,	3,	Level1Data_F78_Get},
//		{J_1LEIDATE,	79,	3,	Level1Data_F79_Get},
//		{J_1LEIDATE,	80,	3,	Level1Data_F80_Get},
//		{J_1LEIDATE,	81,	3,	Level1Data_F81_Get},
//		{J_1LEIDATE,	82,	3,	Level1Data_F82_Get},
//		{J_1LEIDATE,	83,	3,	Level1Data_F83_Get},
//		{J_1LEIDATE,	84,	3,	Level1Data_F84_Get},
//		{J_1LEIDATE,	85,	3,	Level1Data_F85_Get},
//		{J_1LEIDATE,	86,	3,	Level1Data_F86_Get},
//		{J_1LEIDATE,	87,	3,	Level1Data_F87_Get},
//		{J_1LEIDATE,	88,	3,	Level1Data_F88_Get},
//		{J_1LEIDATE,	89,	3,	Level1Data_F89_Get},
//		{J_1LEIDATE,	90,	3,	Level1Data_F90_Get},
//		{J_1LEIDATE,	91,	3,	Level1Data_F91_Get},
//		{J_1LEIDATE,	92,	3,	Level1Data_F92_Get},
//		{J_1LEIDATE,	93,	3,	Level1Data_F93_Get},
//		{J_1LEIDATE,	94,	3,	Level1Data_F94_Get},
//		{J_1LEIDATE,	95,	3,	Level1Data_F95_Get},
//		{J_1LEIDATE,	96,	3,	Level1Data_F96_Get},
//		{J_1LEIDATE,	97,	3,	Level1Data_F97_Get},
//		{J_1LEIDATE,	98,	3,	Level1Data_F98_Get},
//		{J_1LEIDATE,	99,	3,	Level1Data_F99_Get},
//		{J_1LEIDATE,	100,3,	Level1Data_F100_Get},
//		{J_1LEIDATE,	101,3,	Level1Data_F101_Get},
//		{J_1LEIDATE,	102,3,	Level1Data_F102_Get},
//		{J_1LEIDATE,	103,3,	Level1Data_F103_Get},
//		{J_1LEIDATE,	104,3,	Level1Data_F104_Get},
//		{J_1LEIDATE,	105,3,	Level1Data_F105_Get},
//		{J_1LEIDATE,	106,3,	Level1Data_F106_Get},
//		{J_1LEIDATE,	107,3,	Level1Data_F107_Get},
//		{J_1LEIDATE,	108,3,	Level1Data_F108_Get},
//		{J_1LEIDATE,	109,3,	Level1Data_F109_Get},
//		{J_1LEIDATE,	110,3,	Level1Data_F110_Get},
//		{J_1LEIDATE,	111,3,	Level1Data_F111_Get},
//		{J_1LEIDATE,	112,3,	Level1Data_F112_Get},
//		{J_1LEIDATE,	113,3,	Level1Data_F113_Get},
//		{J_1LEIDATE,	114,3,	Level1Data_F114_Get},
//		{J_1LEIDATE,	115,3,	Level1Data_F115_Get},
//		{J_1LEIDATE,	116,3,	Level1Data_F116_Get},
//		{J_1LEIDATE,	117,3,	Level1Data_F117_Get},
//		{J_1LEIDATE,	118,3,	Level1Data_F118_Get},
//		{J_1LEIDATE,	119,3,	Level1Data_F119_Get},
//		{J_1LEIDATE,	120,3,	Level1Data_F120_Get},
//		{J_1LEIDATE,	121,3,	Level1Data_F121_Get},
//		{J_1LEIDATE,	122,3,	Level1Data_F122_Get},
//		{J_1LEIDATE,	123,3,	Level1Data_F123_Get},
//		{J_1LEIDATE,	124,3,	Level1Data_F124_Get},
//		{J_1LEIDATE,	125,3,	Level1Data_F125_Get},
//		{J_1LEIDATE,	126,3,	Level1Data_F126_Get},
//		{J_1LEIDATE,	127,3,	Level1Data_F127_Get},
//		{J_1LEIDATE,	128,3,	Level1Data_F128_Get},
		{J_1LEIDATE,	129,3,	Level1Data_F129_Get},
		{J_1LEIDATE,	130,3,	Level1Data_F130_Get},
		{J_1LEIDATE,	131,3,	Level1Data_F131_Get},
		{J_1LEIDATE,	132,3,	Level1Data_F132_Get},
		{J_1LEIDATE,	133,3,	Level1Data_F133_Get},
		{J_1LEIDATE,	134,3,	Level1Data_F134_Get},
		{J_1LEIDATE,	135,3,	Level1Data_F135_Get},
		{J_1LEIDATE,	136,3,	Level1Data_F136_Get},
		{J_1LEIDATE,	137,3,	Level1Data_F137_Get},
		{J_1LEIDATE,	138,3,	Level1Data_F138_Get},
		{J_1LEIDATE,	139,3,	Level1Data_F139_Get},
		{J_1LEIDATE,	140,3,	Level1Data_F140_Get},
		{J_1LEIDATE,	141,3,	Level1Data_F141_Get},
		{J_1LEIDATE,	142,3,	Level1Data_F142_Get},
		{J_1LEIDATE,	143,3,	Level1Data_F143_Get},
		{J_1LEIDATE,	144,3,	Level1Data_F144_Get},
		{J_1LEIDATE,	145,3,	Level1Data_F145_Get},
		{J_1LEIDATE,	146,3,	Level1Data_F146_Get},
		{J_1LEIDATE,	147,3,	Level1Data_F147_Get},
		{J_1LEIDATE,	148,3,	Level1Data_F148_Get},
		{J_1LEIDATE,	149,3,	Level1Data_F149_Get},
//		{J_1LEIDATE,	150,3,	Level1Data_F150_Get},
		{J_1LEIDATE,	151,3,	Level1Data_F151_Get},
//		{J_1LEIDATE,	152,3,	Level1Data_F152_Get},
//		{J_1LEIDATE,	153,3,	Level1Data_F153_Get},
//		{J_1LEIDATE,	154,3,	Level1Data_F154_Get},
//		{J_1LEIDATE,	155,3,	Level1Data_F155_Get},
//		{J_1LEIDATE,	156,3,	Level1Data_F156_Get},
//		{J_1LEIDATE,	157,3,	Level1Data_F157_Get},
//		{J_1LEIDATE,	158,3,	Level1Data_F158_Get},
//		{J_1LEIDATE,	159,3,	Level1Data_F159_Get},
//		{J_1LEIDATE,	160,3,	Level1Data_F160_Get},
		{J_1LEIDATE,	161,3,	Level1Data_F161_Get},
//		{J_1LEIDATE,	162,3,	Level1Data_F162_Get},
//		{J_1LEIDATE,	163,3,	Level1Data_F163_Get},
//		{J_1LEIDATE,	164,3,	Level1Data_F164_Get},
		{J_1LEIDATE,	165,3,	Level1Data_F165_Get},
		{J_1LEIDATE,	166,3,	Level1Data_F166_Get},
		{J_1LEIDATE,	167,3,	Level1Data_F167_Get},
		{J_1LEIDATE,	168,3,	Level1Data_F168_Get},
		{J_1LEIDATE,	169,3,	Level1Data_F169_Get},
		{J_1LEIDATE,	170,3,	Level1Data_F170_Get},
//		{J_1LEIDATE,	171,3,	Level1Data_F171_Get},
//		{J_1LEIDATE,	172,3,	Level1Data_F172_Get},
//		{J_1LEIDATE,	173,3,	Level1Data_F173_Get},
//		{J_1LEIDATE,	174,3,	Level1Data_F174_Get},
//		{J_1LEIDATE,	175,3,	Level1Data_F175_Get},
//		{J_1LEIDATE,	176,3,	Level1Data_F176_Get},
//		{J_1LEIDATE,	177,3,	Level1Data_F177_Get},
//		{J_1LEIDATE,	178,3,	Level1Data_F178_Get},
//		{J_1LEIDATE,	179,3,	Level1Data_F179_Get},
//		{J_1LEIDATE,	180,3,	Level1Data_F180_Get},
//		{J_1LEIDATE,	181,3,	Level1Data_F181_Get},
//		{J_1LEIDATE,	182,3,	Level1Data_F182_Get},
//		{J_1LEIDATE,	183,3,	Level1Data_F183_Get},
//		{J_1LEIDATE,	184,3,	Level1Data_F184_Get},
//		{J_1LEIDATE,	185,3,	Level1Data_F185_Get},
		{J_1LEIDATE,	186,3,	Level1Data_F186_Get},
		{J_1LEIDATE,	201,3,	Level1Data_F201_Get},
		{J_1LEIDATE,	202,3,	Level1Data_F202_Get},
		{J_1LEIDATE,	241,3,	Level1Data_F241_Get},
		{J_1LEIDATE,	242,3,	Level1Data_F242_Get},
		{J_1LEIDATE,	243,3,	Level1Data_F243_Get},
		{J_1LEIDATE,	248,3,	Level1Data_F248_Get},
//*********************************************************
		{J_1LEICURR,	1,	3,	Level1Data_F1_Get},
		{J_1LEICURR,	2,	3,	Level1Data_F2_Get},
		{J_1LEICURR,	3,	3,	Level1Data_F3_Get},
		{J_1LEICURR,	4,	3,	Level1Data_F4_Get},
		{J_1LEICURR,	5,	3,	Level1Data_F5_Get},
//		{J_1LEICURR,	6,	3,	Level1Data_F6_Get},
		{J_1LEICURR,	7,	3,	Level1Data_F7_Get},
		{J_1LEICURR,	8,	3,	Level1Data_F8_Get},
		{J_1LEICURR,	9,	3,	Level1Data_F9_Get},
		{J_1LEICURR,	10,	3,	Level1Data_F10_Get},
		{J_1LEICURR,	11,	3,	Level1Data_F11_Get},

//		{J_1LEICURR,	12,	3,	Level1Data_Curr_F12_Get},
//		{J_1LEIDATE,	13,	3,	Level1Data_Curr_F13_Get},
//		{J_1LEIDATE,	14,	3,	Level1Data_Curr_F14_Get},
//		{J_1LEICURR,	15,	3,	Level1Data_Curr_F15_Get},
//		{J_1LEICURR,	16,	3,	Level1Data_Curr_F16_Get},

		{J_1LEICURR,	17,	3,	Level1Data_Curr_F17_Get},
		{J_1LEICURR,	18,	3,	Level1Data_Curr_F18_Get},
//		{J_1LEICURR,	19,	3,	Level1Data_Curr_F19_Get},
//		{J_1LEICURR,	20,	3,	Level1Data_Curr_F20_Get},
//		{J_1LEICURR,	21,	3,	Level1Data_Curr_F21_Get},
//		{J_1LEICURR,	22,	3,	Level1Data_Curr_F22_Get},
//		{J_1LEICURR,	23,	3,	Level1Data_Curr_F23_Get},
//		{J_1LEICURR,	24,	3,	Level1Data_Curr_F24_Get},
		{J_1LEICURR,	25,	3,	Level1Data_Curr_F25_Get},
		{J_1LEICURR,	26,	3,	Level1Data_Curr_F26_Get},
		{J_1LEICURR,	27,	3,	Level1Data_Curr_F27_Get},
		{J_1LEICURR,	28,	3,	Level1Data_Curr_F28_Get},
		{J_1LEICURR,	29,	3,	Level1Data_Curr_F29_Get},
//		{J_1LEICURR,	30,	3,	Level1Data_Curr_F30_Get},
		{J_1LEICURR,	31,	3,	Level1Data_Curr_F31_Get},
		{J_1LEICURR,	32,	3,	Level1Data_Curr_F32_Get},
		{J_1LEICURR,	33,	3,	Level1Data_Curr_F33_Get},
		{J_1LEICURR,	34,	3,	Level1Data_Curr_F34_Get},
		{J_1LEICURR,	35,	3,	Level1Data_Curr_F35_Get},
		{J_1LEICURR,	36,	3,	Level1Data_Curr_F36_Get},
		{J_1LEICURR,	37,	3,	Level1Data_Curr_F37_Get},
		{J_1LEICURR,	38,	3,	Level1Data_Curr_F38_Get},
		{J_1LEICURR,	39,	3,	Level1Data_Curr_F39_Get},
		{J_1LEICURR,	40,	3,	Level1Data_Curr_F40_Get},
		{J_1LEICURR,	41,	3,	Level1Data_Curr_F41_Get},
		{J_1LEICURR,	42,	3,	Level1Data_Curr_F42_Get},
		{J_1LEICURR,	43,	3,	Level1Data_Curr_F43_Get},
		{J_1LEICURR,	44,	3,	Level1Data_Curr_F44_Get},
		{J_1LEICURR,	45,	3,	Level1Data_Curr_F45_Get},
		{J_1LEICURR,	46,	3,	Level1Data_Curr_F46_Get},
		{J_1LEICURR,	47,	3,	Level1Data_Curr_F47_Get},
		{J_1LEICURR,	48,	3,	Level1Data_Curr_F48_Get},
		{J_1LEICURR,	49,	3,	Level1Data_Curr_F49_Get},
//		{J_1LEICURR,	50,	3,	Level1Data_Curr_F50_Get},
//		{J_1LEICURR,	51,	3,	Level1Data_Curr_F51_Get},
//		{J_1LEICURR,	52,	3,	Level1Data_Curr_F52_Get},
//		{J_1LEICURR,	53,	3,	Level1Data_Curr_F53_Get},
//		{J_1LEICURR,	54,	3,	Level1Data_Curr_F54_Get},
//		{J_1LEICURR,	55,	3,	Level1Data_Curr_F55_Get},
//		{J_1LEICURR,	56,	3,	Level1Data_Curr_F56_Get},
		{J_1LEICURR,	57,	3,	Level1Data_Curr_F57_Get},
		{J_1LEICURR,	58,	3,	Level1Data_Curr_F58_Get},
//		{J_1LEICURR,	59,	3,	Level1Data_Curr_F59_Get},
//		{J_1LEICURR,	60,	3,	Level1Data_Curr_F60_Get},
//		{J_1LEICURR,	61,	3,	Level1Data_Curr_F61_Get},
//		{J_1LEICURR,	62,	3,	Level1Data_Curr_F62_Get},
//		{J_1LEICURR,	63,	3,	Level1Data_Curr_F63_Get},
//		{J_1LEICURR,	64,	3,	Level1Data_Curr_F64_Get},
//		{J_1LEICURR,	65,	3,	Level1Data_Curr_F65_Get},
//		{J_1LEICURR,	66,	3,	Level1Data_Curr_F66_Get},
//		{J_1LEICURR,	67,	3,	Level1Data_Curr_F67_Get},
//		{J_1LEICURR,	68,	3,	Level1Data_Curr_F68_Get},
//		{J_1LEICURR,	69,	3,	Level1Data_Curr_F69_Get},
//		{J_1LEICURR,	70,	3,	Level1Data_Curr_F70_Get},
//		{J_1LEICURR,	71,	3,	Level1Data_Curr_F71_Get},
//		{J_1LEICURR,	72,	3,	Level1Data_Curr_F72_Get},
		{J_1LEICURR,	73,	3,	Level1Data_Curr_F73_Get},
//		{J_1LEICURR,	74,	3,	Level1Data_Curr_F74_Get},
//		{J_1LEICURR,	75,	3,	Level1Data_Curr_F75_Get},
//		{J_1LEICURR,	76,	3,	Level1Data_Curr_F76_Get},
//		{J_1LEICURR,	77,	3,	Level1Data_Curr_F77_Get},
//		{J_1LEICURR,	78,	3,	Level1Data_Curr_F78_Get},
//		{J_1LEICURR,	79,	3,	Level1Data_Curr_F79_Get},
//		{J_1LEICURR,	80,	3,	Level1Data_Curr_F80_Get},
//		{J_1LEICURR,	81,	3,	Level1Data_Curr_F81_Get},
//		{J_1LEICURR,	82,	3,	Level1Data_Curr_F82_Get},
//		{J_1LEICURR,	83,	3,	Level1Data_Curr_F83_Get},
//		{J_1LEICURR,	84,	3,	Level1Data_Curr_F84_Get},
//		{J_1LEICURR,	85,	3,	Level1Data_Curr_F85_Get},
//		{J_1LEICURR,	86,	3,	Level1Data_Curr_F86_Get},
//		{J_1LEICURR,	87,	3,	Level1Data_Curr_F87_Get},
//		{J_1LEICURR,	88,	3,	Level1Data_Curr_F88_Get},
		{J_1LEICURR,	89,	3,	Level1Data_Curr_F89_Get},
		{J_1LEICURR,	90,	3,	Level1Data_Curr_F90_Get},
		{J_1LEICURR,	91,	3,	Level1Data_Curr_F91_Get},
		{J_1LEICURR,	92,	3,	Level1Data_Curr_F92_Get},
		{J_1LEICURR,	93,	3,	Level1Data_Curr_F93_Get},
		{J_1LEICURR,	94,	3,	Level1Data_Curr_F94_Get},
		{J_1LEICURR,	95,	3,	Level1Data_Curr_F95_Get},
		{J_1LEICURR,	96,	3,	Level1Data_Curr_F96_Get},
		{J_1LEICURR,	97,	3,	Level1Data_Curr_F97_Get},
		{J_1LEICURR,	98,	3,	Level1Data_Curr_F98_Get},
		{J_1LEICURR,	99,	3,	Level1Data_Curr_F99_Get},
		{J_1LEICURR,	100,	3,	Level1Data_Curr_F100_Get},
		{J_1LEICURR,	101,	3,	Level1Data_Curr_F101_Get},
		{J_1LEICURR,	102,	3,	Level1Data_Curr_F102_Get},
		{J_1LEICURR,	103,	3,	Level1Data_Curr_F103_Get},
//		{J_1LEICURR,	104,	3,	Level1Data_Curr_F104_Get},
		{J_1LEICURR,	105,	3,	Level1Data_Curr_F105_Get},
		{J_1LEICURR,	106,	3,	Level1Data_Curr_F106_Get},
		{J_1LEICURR,	107,	3,	Level1Data_Curr_F107_Get},
		{J_1LEICURR,	108,	3,	Level1Data_Curr_F108_Get},
		{J_1LEICURR,	109,	3,	Level1Data_Curr_F109_Get},
		{J_1LEICURR,	110,	3,	Level1Data_Curr_F110_Get},
		{J_1LEICURR,	111,	3,	Level1Data_Curr_F111_Get},
		{J_1LEICURR,	112,	3,	Level1Data_Curr_F112_Get},
		{J_1LEICURR,	113,	3,	Level1Data_Curr_F113_Get},
		{J_1LEICURR,	114,	3,	Level1Data_Curr_F114_Get},
		{J_1LEICURR,	115,	3,	Level1Data_Curr_F115_Get},
		{J_1LEICURR,	116,	3,	Level1Data_Curr_F116_Get},
//		{J_1LEICURR,	117,	3,	Level1Data_Curr_F117_Get},
//		{J_1LEICURR,	118,	3,	Level1Data_Curr_F118_Get},
//		{J_1LEICURR,	119,	3,	Level1Data_Curr_F119_Get},
//		{J_1LEICURR,	120,	3,	Level1Data_Curr_F120_Get},
//		{J_1LEICURR,	121,	3,	Level1Data_Curr_F121_Get},
//		{J_1LEICURR,	122,	3,	Level1Data_Curr_F122_Get},
//		{J_1LEICURR,	123,	3,	Level1Data_Curr_F123_Get},
//		{J_1LEICURR,	124,	3,	Level1Data_Curr_F124_Get},
//		{J_1LEICURR,	125,	3,	Level1Data_Curr_F125_Get},
//		{J_1LEICURR,	126,	3,	Level1Data_Curr_F126_Get},
//		{J_1LEICURR,	127,	3,	Level1Data_Curr_F127_Get},
//		{J_1LEICURR,	128,	3,	Level1Data_Curr_F128_Get},
		{J_1LEICURR,	129,	3,	Level1Data_Curr_F129_Get},
		{J_1LEICURR,	130,	3,	Level1Data_Curr_F130_Get},
		{J_1LEICURR,	131,	3,	Level1Data_Curr_F131_Get},
		{J_1LEICURR,	132,	3,	Level1Data_Curr_F132_Get},
		{J_1LEICURR,	133,	3,	Level1Data_Curr_F133_Get},
		{J_1LEICURR,	134,	3,	Level1Data_Curr_F134_Get},
		{J_1LEICURR,	135,	3,	Level1Data_Curr_F135_Get},
		{J_1LEICURR,	136,	3,	Level1Data_Curr_F136_Get},
		{J_1LEICURR,	137,	3,	Level1Data_Curr_F137_Get},
		{J_1LEICURR,	138,	3,	Level1Data_Curr_F138_Get},
		{J_1LEICURR,	139,	3,	Level1Data_Curr_F139_Get},
		{J_1LEICURR,	140,	3,	Level1Data_Curr_F140_Get},
		{J_1LEICURR,	141,	3,	Level1Data_Curr_F141_Get},
		{J_1LEICURR,	142,	3,	Level1Data_Curr_F142_Get},
		{J_1LEICURR,	143,	3,	Level1Data_Curr_F143_Get},
		{J_1LEICURR,	144,	3,	Level1Data_Curr_F144_Get},
		{J_1LEICURR,	145,	3,	Level1Data_Curr_F145_Get},
		{J_1LEICURR,	146,	3,	Level1Data_Curr_F146_Get},
		{J_1LEICURR,	147,	3,	Level1Data_Curr_F147_Get},
		{J_1LEICURR,	148,	3,	Level1Data_Curr_F148_Get},
		{J_1LEICURR,	149,	3,	Level1Data_Curr_F149_Get},
		{J_1LEICURR,	150,	3,	Level1Data_Curr_F150_Get},
		{J_1LEICURR,	151,	3,	Level1Data_Curr_F151_Get},
		{J_1LEICURR,	152,	3,	Level1Data_Curr_F152_Get},
		{J_1LEICURR,	153,	3,	Level1Data_Curr_F153_Get},
		{J_1LEICURR,	154,	3,	Level1Data_Curr_F154_Get},
		{J_1LEICURR,	155,	3,	Level1Data_Curr_F155_Get},
		{J_1LEICURR,	156,	3,	Level1Data_Curr_F156_Get},
		{J_1LEICURR,	157,	3,	Level1Data_Curr_F157_Get},
		{J_1LEICURR,	158,	3,	Level1Data_Curr_F158_Get},
		{J_1LEICURR,	159,	3,	Level1Data_Curr_F159_Get},
		{J_1LEICURR,	160,	3,	Level1Data_Curr_F160_Get},
		{J_1LEICURR,	161,	3,	Level1Data_Curr_F161_Get},
//		{J_1LEICURR,	162,	3,	Level1Data_Curr_F162_Get},
//		{J_1LEICURR,	163,	3,	Level1Data_Curr_F163_Get},
//		{J_1LEICURR,	164,	3,	Level1Data_Curr_F164_Get},
		{J_1LEICURR,	165,	3,	Level1Data_Curr_F165_Get},
		{J_1LEICURR,	166,	3,	Level1Data_Curr_F166_Get},
		{J_1LEICURR,	167,	3,	Level1Data_Curr_F167_Get},
		{J_1LEICURR,	168,	3,	Level1Data_Curr_F168_Get},
//		{J_1LEICURR,	169,	3,	Level1Data_Curr_F169_Get},
//		{J_1LEICURR,	170,	3,	Level1Data_Curr_F170_Get},
//		{J_1LEICURR,	171,	3,	Level1Data_Curr_F171_Get},
//		{J_1LEICURR,	172,	3,	Level1Data_Curr_F172_Get},
//		{J_1LEICURR,	173,	3,	Level1Data_Curr_F173_Get},
//		{J_1LEICURR,	174,	3,	Level1Data_Curr_F174_Get},
//		{J_1LEICURR,	175,	3,	Level1Data_Curr_F175_Get},
//		{J_1LEICURR,	176,	3,	Level1Data_Curr_F176_Get},
//		{J_1LEICURR,	177,	3,	Level1Data_Curr_F177_Get},
//		{J_1LEICURR,	178,	3,	Level1Data_Curr_F178_Get},
//		{J_1LEICURR,	179,	3,	Level1Data_Curr_F179_Get},
//		{J_1LEICURR,	180,	3,	Level1Data_Curr_F180_Get},
//		{J_1LEICURR,	181,	3,	Level1Data_Curr_F181_Get},
//		{J_1LEICURR,	182,	3,	Level1Data_Curr_F182_Get},
//		{J_1LEICURR,	183,	3,	Level1Data_Curr_F183_Get},
//		{J_1LEICURR,	184,	3,	Level1Data_Curr_F184_Get},
//		{J_1LEICURR,	185,	3,	Level1Data_Curr_F185_Get},
//		{J_1LEICURR,	186,	3,	Level1Data_Curr_F186_Get},
//		{J_1LEICURR,	187,	3,	Level1Data_Curr_F187_Get},
//		{J_1LEICURR,	188,	3,	Level1Data_Curr_F188_Get},
//		{J_1LEICURR,	189,	3,	Level1Data_Curr_F189_Get},
//		{J_1LEICURR,	190,	3,	Level1Data_Curr_F190_Get},
//		{J_1LEICURR,	191,	3,	Level1Data_Curr_F191_Get},
//		{J_1LEICURR,	192,	3,	Level1Data_Curr_F192_Get},
//		{J_1LEICURR,	193,	3,	Level1Data_Curr_F193_Get},
//		{J_1LEICURR,	194,	3,	Level1Data_Curr_F194_Get},
//		{J_1LEICURR,	195,	3,	Level1Data_Curr_F195_Get},
//		{J_1LEICURR,	196,	3,	Level1Data_Curr_F196_Get},
//		{J_1LEICURR,	197,	3,	Level1Data_Curr_F197_Get},
//		{J_1LEICURR,	198,	3,	Level1Data_Curr_F198_Get},
//		{J_1LEICURR,	199,	3,	Level1Data_Curr_F199_Get},
//		{J_1LEICURR,	200,	3,	Level1Data_Curr_F200_Get},
//		{J_1LEICURR,	201,	3,	Level1Data_Curr_F201_Get},
//		{J_1LEICURR,	202,	3,	Level1Data_Curr_F202_Get},
//		{J_1LEICURR,	203,	3,	Level1Data_Curr_F203_Get},
//		{J_1LEICURR,	204,	3,	Level1Data_Curr_F204_Get},
//		{J_1LEICURR,	205,	3,	Level1Data_Curr_F205_Get},
//		{J_1LEICURR,	206,	3,	Level1Data_Curr_F206_Get},
//		{J_1LEICURR,	207,	3,	Level1Data_Curr_F207_Get},
//		{J_1LEICURR,	208,	3,	Level1Data_Curr_F208_Get},
//		{J_1LEICURR,	209,	3,	Level1Data_Curr_F209_Get},
//		{J_1LEICURR,	210,	3,	Level1Data_Curr_F210_Get},
//		{J_1LEICURR,	211,	3,	Level1Data_Curr_F211_Get},
//		{J_1LEICURR,	212,	3,	Level1Data_Curr_F212_Get},
//		{J_1LEICURR,	213,	3,	Level1Data_Curr_F213_Get},
//		{J_1LEICURR,	214,	3,	Level1Data_Curr_F214_Get},
//		{J_1LEICURR,	215,	3,	Level1Data_Curr_F215_Get},
//		{J_1LEICURR,	216,	3,	Level1Data_Curr_F216_Get},
//		{J_1LEICURR,	217,	3,	Level1Data_Curr_F217_Get},
//		{J_1LEICURR,	218,	3,	Level1Data_Curr_F218_Get},
//		{J_1LEICURR,	219,	3,	Level1Data_Curr_F219_Get},
//		{J_1LEICURR,	220,	3,	Level1Data_Curr_F220_Get},
//		{J_1LEICURR,	221,	3,	Level1Data_Curr_F221_Get},
//		{J_1LEICURR,	222,	3,	Level1Data_Curr_F222_Get},
//		{J_1LEICURR,	223,	3,	Level1Data_Curr_F223_Get},
//		{J_1LEICURR,	224,	3,	Level1Data_Curr_F224_Get},
//		{J_1LEICURR,	225,	3,	Level1Data_Curr_F225_Get},
//		{J_1LEICURR,	226,	3,	Level1Data_Curr_F226_Get},
//		{J_1LEICURR,	227,	3,	Level1Data_Curr_F227_Get},
//		{J_1LEICURR,	228,	3,	Level1Data_Curr_F228_Get},
//		{J_1LEICURR,	229,	3,	Level1Data_Curr_F229_Get},
//		{J_1LEICURR,	230,	3,	Level1Data_Curr_F230_Get},
//		{J_1LEICURR,	231,	3,	Level1Data_Curr_F231_Get},
//		{J_1LEICURR,	232,	3,	Level1Data_Curr_F232_Get},
//		{J_1LEICURR,	233,	3,	Level1Data_Curr_F233_Get},
//		{J_1LEICURR,	234,	3,	Level1Data_Curr_F234_Get},
//		{J_1LEICURR,	235,	3,	Level1Data_Curr_F235_Get},
//		{J_1LEICURR,	236,	3,	Level1Data_Curr_F236_Get},
//		{J_1LEICURR,	237,	3,	Level1Data_Curr_F237_Get},
//		{J_1LEICURR,	238,	3,	Level1Data_Curr_F238_Get},
//		{J_1LEICURR,	239,	3,	Level1Data_Curr_F239_Get},
//		{J_1LEICURR,	240,	3,	Level1Data_Curr_F240_Get},
//		{J_1LEICURR,	241,	3,	Level1Data_Curr_F241_Get},
//		{J_1LEICURR,	242,	3,	Level1Data_Curr_F242_Get},
//		{J_1LEICURR,	243,	3,	Level1Data_Curr_F243_Get},
//		{J_1LEICURR,	244,	3,	Level1Data_Curr_F244_Get},
//		{J_1LEICURR,	245,	3,	Level1Data_Curr_F245_Get},
//		{J_1LEICURR,	246,	3,	Level1Data_Curr_F246_Get},
//		{J_1LEICURR,	247,	3,	Level1Data_Curr_F247_Get},
		{J_1LEICURR,	248,	3,	Level1Data_F248_Get},
//**************************************************************
		{J_2LEIDATE,	1,	4,	Get_Level2Data_F1},
		{J_2LEIDATE,	2,	4,	Get_Level2Data_F2},
		{J_2LEIDATE,	3,	4,	Get_Level2Data_F3},
		{J_2LEIDATE,	4,	4,	Get_Level2Data_F4},
		{J_2LEIDATE,	5,	4,	Get_Level2Data_F5},
		{J_2LEIDATE,	6,	4,	Get_Level2Data_F6},
		{J_2LEIDATE,	7,	4,	Get_Level2Data_F7},
		{J_2LEIDATE,	8,	4,	Get_Level2Data_F8},
		{J_2LEIDATE,	9,	4,	Get_Level2Data_F9},
		{J_2LEIDATE,	10,	4,	Get_Level2Data_F10},
		{J_2LEIDATE,	11,	4,	Get_Level2Data_F11},
		{J_2LEIDATE,	12,	4,	Get_Level2Data_F12},
//		{J_2LEIDATE,	13,	4,	Get_Level2Data_F13},
//		{J_2LEIDATE,	14,	4,	Get_Level2Data_F14},
//		{J_2LEIDATE,	15,	4,	Get_Level2Data_F15},
//		{J_2LEIDATE,	16,	4,	Get_Level2Data_F16},
		{J_2LEIDATE,	17,	4,	Get_Level2Data_F17},
		{J_2LEIDATE,	18,	4,	Get_Level2Data_F18},
		{J_2LEIDATE,	19,	4,	Get_Level2Data_F19},
		{J_2LEIDATE,	20,	4,	Get_Level2Data_F20},
		{J_2LEIDATE,	21,	4,	Get_Level2Data_F21},
		{J_2LEIDATE,	22,	4,	Get_Level2Data_F22},
		{J_2LEIDATE,	23,	4,	Get_Level2Data_F23},
		{J_2LEIDATE,	24,	4,	Get_Level2Data_F24},
		{J_2LEIDATE,	25,	4,	Get_Level2Data_F25},
		{J_2LEIDATE,	26,	4,	Get_Level2Data_F26},
		{J_2LEIDATE,	27,	4,	Get_Level2Data_F27},
		{J_2LEIDATE,	28,	4,	Get_Level2Data_F28},
		{J_2LEIDATE,	29,	4,	Get_Level2Data_F29},
		{J_2LEIDATE,	30,	4,	Get_Level2Data_F30},
		{J_2LEIDATE,	31,	4,	Get_Level2Data_F31},
		{J_2LEIDATE,	32,	4,	Get_Level2Data_F32},
		{J_2LEIDATE,	33,	4,	Get_Level2Data_F33},
		{J_2LEIDATE,	34,	4,	Get_Level2Data_F34},
		{J_2LEIDATE,	35,	4,	Get_Level2Data_F35},
		{J_2LEIDATE,	36,	4,	Get_Level2Data_F36},
		{J_2LEIDATE,	37,	4,	Get_Level2Data_F37},
		{J_2LEIDATE,	38,	4,	Get_Level2Data_F38},
		{J_2LEIDATE,	39,	4,	Get_Level2Data_F39},
//		{J_2LEIDATE,	40,	4,	Get_Level2Data_F40},
		{J_2LEIDATE,	41,	4,	Get_Level2Data_F41},
		{J_2LEIDATE,	42,	4,	Get_Level2Data_F42},
		{J_2LEIDATE,	43,	4,	Get_Level2Data_F43},
		{J_2LEIDATE,	44,	4,	Get_Level2Data_F44},
		{J_2LEIDATE,	45,	4,	Get_Level2Data_F45},
		{J_2LEIDATE,	46,	4,	Get_Level2Data_F46},
//		{J_2LEIDATE,	47,	4,	Get_Level2Data_F47},
//		{J_2LEIDATE,	48,	4,	Get_Level2Data_F48},
		{J_2LEIDATE,	49,	4,	Get_Level2Data_F49},
		{J_2LEIDATE,	50,	4,	Get_Level2Data_F50},
		{J_2LEIDATE,	51,	4,	Get_Level2Data_F51},
		{J_2LEIDATE,	52,	4,	Get_Level2Data_F52},
		{J_2LEIDATE,	53,	4,	Get_Level2Data_F53},
		{J_2LEIDATE,	54,	4,	Get_Level2Data_F54},
//		{J_2LEIDATE,	55,	4,	Get_Level2Data_F55},
//		{J_2LEIDATE,	56,	4,	Get_Level2Data_F56},
		{J_2LEIDATE,	57,	4,	Get_Level2Data_F57},
//		{J_2LEIDATE,	58,	4,	Get_Level2Data_F58},
//		{J_2LEIDATE,	59,	4,	Get_Level2Data_F59},
		{J_2LEIDATE,	60,	4,	Get_Level2Data_F60},
//		{J_2LEIDATE,	61,	4,	Get_Level2Data_F61},
//		{J_2LEIDATE,	62,	4,	Get_Level2Data_F62},
//		{J_2LEIDATE,	63,	4,	Get_Level2Data_F63},
//		{J_2LEIDATE,	64,	4,	Get_Level2Data_F64},
//		{J_2LEIDATE,	65,	4,	Get_Level2Data_F65},
//		{J_2LEIDATE,	66,	4,	Get_Level2Data_F66},
//		{J_2LEIDATE,	67,	4,	Get_Level2Data_F67},
//		{J_2LEIDATE,	68,	4,	Get_Level2Data_F68},
//		{J_2LEIDATE,	69,	4,	Get_Level2Data_F69},
//		{J_2LEIDATE,	70,	4,	Get_Level2Data_F70},
//		{J_2LEIDATE,	71,	4,	Get_Level2Data_F71},
//		{J_2LEIDATE,	72,	4,	Get_Level2Data_F72},
//		{J_2LEIDATE,	73,	4,	Get_Level2Data_F73},
//		{J_2LEIDATE,	74,	4,	Get_Level2Data_F74},
//		{J_2LEIDATE,	75,	4,	Get_Level2Data_F75},
//		{J_2LEIDATE,	76,	4,	Get_Level2Data_F76},
//		{J_2LEIDATE,	77,	4,	Get_Level2Data_F77},
//		{J_2LEIDATE,	78,	4,	Get_Level2Data_F78},
//		{J_2LEIDATE,	79,	4,	Get_Level2Data_F79},
//		{J_2LEIDATE,	80,	4,	Get_Level2Data_F80},
		{J_2LEIDATE,	81,	4,	Get_Level2Data_F81},
		{J_2LEIDATE,	82,	4,	Get_Level2Data_F82},
		{J_2LEIDATE,	83,	4,	Get_Level2Data_F83},
		{J_2LEIDATE,	84,	4,	Get_Level2Data_F84},
		{J_2LEIDATE,	85,	4,	Get_Level2Data_F85},
		{J_2LEIDATE,	86,	4,	Get_Level2Data_F86},
		{J_2LEIDATE,	87,	4,	Get_Level2Data_F87},
		{J_2LEIDATE,	88,	4,	Get_Level2Data_F88},
		{J_2LEIDATE,	89,	4,	Get_Level2Data_F89},
		{J_2LEIDATE,	90,	4,	Get_Level2Data_F90},
		{J_2LEIDATE,	91,	4,	Get_Level2Data_F91},
		{J_2LEIDATE,	92,	4,	Get_Level2Data_F92},
		{J_2LEIDATE,	93,	4,	Get_Level2Data_F93},
		{J_2LEIDATE,	94,	4,	Get_Level2Data_F94},
		{J_2LEIDATE,	95,	4,	Get_Level2Data_F95},
//		{J_2LEIDATE,	96,	4,	Get_Level2Data_F96},
		{J_2LEIDATE,	97,	4,	Get_Level2Data_F97},
		{J_2LEIDATE,	98,	4,	Get_Level2Data_F98},
		{J_2LEIDATE,	99,	4,	Get_Level2Data_F99},
		{J_2LEIDATE,	100,	4,	Get_Level2Data_F100},
		{J_2LEIDATE,	101,	4,	Get_Level2Data_F101},
		{J_2LEIDATE,	102,	4,	Get_Level2Data_F102},
		{J_2LEIDATE,	103,	4,	Get_Level2Data_F103},
		{J_2LEIDATE,	104,	4,	Get_Level2Data_F104},
		{J_2LEIDATE,	105,	4,	Get_Level2Data_F105},
		{J_2LEIDATE,	106,	4,	Get_Level2Data_F106},
		{J_2LEIDATE,	107,	4,	Get_Level2Data_F107},
		{J_2LEIDATE,	108,	4,	Get_Level2Data_F108},
		{J_2LEIDATE,	109,	4,	Get_Level2Data_F109},
		{J_2LEIDATE,	110,	4,	Get_Level2Data_F110},
//		{J_2LEIDATE,	111,	4,	Get_Level2Data_F111},
//		{J_2LEIDATE,	112,	4,	Get_Level2Data_F112},
		{J_2LEIDATE,	113,	4,	Get_Level2Data_F113},
		{J_2LEIDATE,	114,	4,	Get_Level2Data_F114},
		{J_2LEIDATE,	115,	4,	Get_Level2Data_F115},
		{J_2LEIDATE,	116,	4,	Get_Level2Data_F116},
		{J_2LEIDATE,	117,	4,	Get_Level2Data_F117},
		{J_2LEIDATE,	118,	4,	Get_Level2Data_F118},
//		{J_2LEIDATE,	119,	4,	Get_Level2Data_F119},
//		{J_2LEIDATE,	120,	4,	Get_Level2Data_F120},
		{J_2LEIDATE,	121,	4,	Get_Level2Data_F121},
		{J_2LEIDATE,	122,	4,	Get_Level2Data_F122},
		{J_2LEIDATE,	123,	4,	Get_Level2Data_F123},
//		{J_2LEIDATE,	124,	4,	Get_Level2Data_F124},
//		{J_2LEIDATE,	125,	4,	Get_Level2Data_F125},
//		{J_2LEIDATE,	126,	4,	Get_Level2Data_F126},
//		{J_2LEIDATE,	127,	4,	Get_Level2Data_F127},
//		{J_2LEIDATE,	128,	4,	Get_Level2Data_F128},
//		{J_2LEIDATE,	129,	4,	Get_Level2Data_F129},
//		{J_2LEIDATE,	130,	4,	Get_Level2Data_F130},
//		{J_2LEIDATE,	131,	4,	Get_Level2Data_F131},
//		{J_2LEIDATE,	132,	4,	Get_Level2Data_F132},
//		{J_2LEIDATE,	133,	4,	Get_Level2Data_F133},
//		{J_2LEIDATE,	134,	4,	Get_Level2Data_F134},
//		{J_2LEIDATE,	135,	4,	Get_Level2Data_F135},
//		{J_2LEIDATE,	136,	4,	Get_Level2Data_F136},
//		{J_2LEIDATE,	137,	4,	Get_Level2Data_F137},
//		{J_2LEIDATE,	138,	4,	Get_Level2Data_F138},
//		{J_2LEIDATE,	139,	4,	Get_Level2Data_F139},
//		{J_2LEIDATE,	140,	4,	Get_Level2Data_F140},
//		{J_2LEIDATE,	141,	4,	Get_Level2Data_F141},
//		{J_2LEIDATE,	142,	4,	Get_Level2Data_F142},
//		{J_2LEIDATE,	143,	4,	Get_Level2Data_F143},
//		{J_2LEIDATE,	144,	4,	Get_Level2Data_F144},
		{J_2LEIDATE,	145,	4,	Get_Level2Data_F145},
		{J_2LEIDATE,	146,	4,	Get_Level2Data_F146},
		{J_2LEIDATE,	147,	4,	Get_Level2Data_F147},
		{J_2LEIDATE,	148,	4,	Get_Level2Data_F148},
//		{J_2LEIDATE,	149,	4,	Get_Level2Data_F149},
//		{J_2LEIDATE,	150,	4,	Get_Level2Data_F150},
//		{J_2LEIDATE,	151,	4,	Get_Level2Data_F151},
//		{J_2LEIDATE,	152,	4,	Get_Level2Data_F152},
		{J_2LEIDATE,	153,	4,	Get_Level2Data_F153},
		{J_2LEIDATE,	154,	4,	Get_Level2Data_F154},
		{J_2LEIDATE,	155,	4,	Get_Level2Data_F155},
		{J_2LEIDATE,	156,	4,	Get_Level2Data_F156},
		{J_2LEIDATE,	157,	4,	Get_Level2Data_F157},
		{J_2LEIDATE,	158,	4,	Get_Level2Data_F158},
		{J_2LEIDATE,	159,	4,	Get_Level2Data_F159},
		{J_2LEIDATE,	160,	4,	Get_Level2Data_F160},
		{J_2LEIDATE,	161,	4,	Get_Level2Data_F161},
		{J_2LEIDATE,	162,	4,	Get_Level2Data_F162},
		{J_2LEIDATE,	163,	4,	Get_Level2Data_F163},
		{J_2LEIDATE,	164,	4,	Get_Level2Data_F164},
		{J_2LEIDATE,	165,	4,	Get_Level2Data_F165},
		{J_2LEIDATE,	166,	4,	Get_Level2Data_F166},
		{J_2LEIDATE,	167,	4,	Get_Level2Data_F167},
		{J_2LEIDATE,	168,	4,	Get_Level2Data_F168},
		{J_2LEIDATE,	169,	4,	Get_Level2Data_F169},
		{J_2LEIDATE,	170,	4,	Get_Level2Data_F170},
		{J_2LEIDATE,	171,	4,	Get_Level2Data_F171},
		{J_2LEIDATE,	172,	4,	Get_Level2Data_F172},
		{J_2LEIDATE,	173,	4,	Get_Level2Data_F173},
		{J_2LEIDATE,	174,	4,	Get_Level2Data_F174},
		{J_2LEIDATE,	175,	4,	Get_Level2Data_F175},
		{J_2LEIDATE,	176,	4,	Get_Level2Data_F176},
		{J_2LEIDATE,	177,	4,	Get_Level2Data_F177},
		{J_2LEIDATE,	178,	4,	Get_Level2Data_F178},
		{J_2LEIDATE,	179,	4,	Get_Level2Data_F179},
		{J_2LEIDATE,	180,	4,	Get_Level2Data_F180},
		{J_2LEIDATE,	181,	4,	Get_Level2Data_F181},
		{J_2LEIDATE,	182,	4,	Get_Level2Data_F182},
		{J_2LEIDATE,	183,	4,	Get_Level2Data_F183},
		{J_2LEIDATE,	184,	4,	Get_Level2Data_F184},
		{J_2LEIDATE,	185,	4,	Get_Level2Data_F185},
		{J_2LEIDATE,	186,	4,	Get_Level2Data_F186},
		{J_2LEIDATE,	187,	4,	Get_Level2Data_F187},
		{J_2LEIDATE,	188,	4,	Get_Level2Data_F188},
		{J_2LEIDATE,	189,	4,	Get_Level2Data_F189},
		{J_2LEIDATE,	190,	4,	Get_Level2Data_F190},
		{J_2LEIDATE,	191,	4,	Get_Level2Data_F191},
		{J_2LEIDATE,	192,	4,	Get_Level2Data_F192},
		{J_2LEIDATE,	193,	4,	Get_Level2Data_F193},
		{J_2LEIDATE,	194,	4,	Get_Level2Data_F194},
		{J_2LEIDATE,	195,	4,	Get_Level2Data_F195},
		{J_2LEIDATE,	196,	4,	Get_Level2Data_F196},
//		{J_2LEIDATE,	197,	4,	Get_Level2Data_F197},
//		{J_2LEIDATE,	198,	4,	Get_Level2Data_F198},
//		{J_2LEIDATE,	199,	4,	Get_Level2Data_F199},
//		{J_2LEIDATE,	200,	4,	Get_Level2Data_F200},
//		{J_2LEIDATE,	201,	4,	Get_Level2Data_F201},
//		{J_2LEIDATE,	202,	4,	Get_Level2Data_F202},
//		{J_2LEIDATE,	203,	4,	Get_Level2Data_F203},
//		{J_2LEIDATE,	204,	4,	Get_Level2Data_F204},
//		{J_2LEIDATE,	205,	4,	Get_Level2Data_F205},
//		{J_2LEIDATE,	206,	4,	Get_Level2Data_F206},
//		{J_2LEIDATE,	207,	4,	Get_Level2Data_F207},
//		{J_2LEIDATE,	208,	4,	Get_Level2Data_F208},
		{J_2LEIDATE,	209,	4,	Get_Level2Data_F209},
//		{J_2LEIDATE,	210,	4,	Get_Level2Data_F210},
//		{J_2LEIDATE,	211,	4,	Get_Level2Data_F211},
//		{J_2LEIDATE,	212,	4,	Get_Level2Data_F212},
//		{J_2LEIDATE,	213,	4,	Get_Level2Data_F213},
//		{J_2LEIDATE,	214,	4,	Get_Level2Data_F214},
		{J_2LEIDATE,	215,	4,	Get_Level2Data_F215},
		{J_2LEIDATE,	216,	4,	Get_Level2Data_F216},
//		{J_2LEIDATE,	217,	4,	Get_Level2Data_F217},
//		{J_2LEIDATE,	218,	4,	Get_Level2Data_F218},
//		{J_2LEIDATE,	219,	4,	Get_Level2Data_F219},
//		{J_2LEIDATE,	220,	4,	Get_Level2Data_F220},
//		{J_2LEIDATE,	221,	4,	Get_Level2Data_F221},
//		{J_2LEIDATE,	222,	4,	Get_Level2Data_F222},
//		{J_2LEIDATE,	223,	4,	Get_Level2Data_F223},
//		{J_2LEIDATE,	224,	4,	Get_Level2Data_F224},
		{J_2LEIDATE,	225,	4,	Get_Level2Data_F225},
//		{J_2LEIDATE,	226,	4,	Get_Level2Data_F226},
//		{J_2LEIDATE,	227,	4,	Get_Level2Data_F227},
//		{J_2LEIDATE,	228,	4,	Get_Level2Data_F228},
//		{J_2LEIDATE,	229,	4,	Get_Level2Data_F229},
//		{J_2LEIDATE,	230,	4,	Get_Level2Data_F230},
//		{J_2LEIDATE,	231,	4,	Get_Level2Data_F231},
//		{J_2LEIDATE,	232,	4,	Get_Level2Data_F232},
//		{J_2LEIDATE,	233,	4,	Get_Level2Data_F233},
//		{J_2LEIDATE,	234,	4,	Get_Level2Data_F234},
//		{J_2LEIDATE,	235,	4,	Get_Level2Data_F235},
//		{J_2LEIDATE,	236,	4,	Get_Level2Data_F236},
//		{J_2LEIDATE,	237,	4,	Get_Level2Data_F237},
//		{J_2LEIDATE,	238,	4,	Get_Level2Data_F238},
//		{J_2LEIDATE,	239,	4,	Get_Level2Data_F239},
//		{J_2LEIDATE,	240,	4,	Get_Level2Data_F240},
		{J_2LEIDATE,	241,	4,	Get_Level2Data_F241},
		{J_2LEIDATE,	242,	4,	Get_Level2Data_F242},
		{J_2LEIDATE,	243,	4,	Get_Level2Data_F243},
//		{J_2LEIDATE,	244,	4,	Get_Level2Data_F244},
//		{J_2LEIDATE,	245,	4,	Get_Level2Data_F245},
//		{J_2LEIDATE,	246,	4,	Get_Level2Data_F246},
//		{J_2LEIDATE,	247,	4,	Get_Level2Data_F247},
		{J_2LEIDATE,	248,	4,	Get_Level2Data_F248},
};

struct tm nowtm;
TS ts;
INT8U myMin;
int tskalmflg; //��ȡ����澯��־
//extern int PackFlg; //������Դ 0 GPRS 1 485У��
unsigned char ReadEveHead, ReadEveTail;
int timeflg; //Уʱ��־
int thrdnum; //�̼߳�����
//AlarmFile dfalm[AlarmFileNum];
//void InitDataTable();
INT16U TmpF, TmpP; //��ʱFn����ʱPn,jAutoSend.c ���涨��ı���

unsigned int rtc_addr = 0x32;
ERC Tmp_Erc;
extern FILE *m_UpDataFile;
//name_attach_t  *attach;
INT8U groupNo;

INT8U CallTwolevelDataCalc_flg;

INT8U SendTwoLevelData(INT16U P, INT16U F, INT8U *t);
//#define DINGXINGLIANTIAO 1
//void ClearThreadTimes(unsigned char ProjectID) {
//	ClearWaitTimes(ProjectNo);
//}

//����
void HeartBeat()
{
	INT32S tmpheart; //����ʱ��(����)
	time_t mytime;

 	int TXmodeType ;
// 	if(Jmemory->JiangSu == 1)
 	if((zone_so&0x7f) == JIANGSU)
 	{
		TXmodeType = (JSetPara_AFN04_3761_2009->group1.f8.Type & 0b00110000)>>4;// 0 Ϊ���ģʽ     1Ϊ�ͻ���ģʽ         2 Ϊ�����ģʽ
		if (TXmodeType == 0)  //���ģʽ����Ҫ��������
			return;
 	}

	nowtm.tm_year = ts.Year + 100;
	nowtm.tm_mon = ts.Month - 1;
	nowtm.tm_mday = ts.Day;
	nowtm.tm_hour = ts.Hour;
	nowtm.tm_min = ts.Minute;
	nowtm.tm_sec = ts.Sec;
	nowtm.tm_isdst = 0;
	mytime = mktime(&nowtm);
    if(HeartBeatErr>0)
    {//����һ���������ᣬÿ2���ӷ�һ������
    	if ((((ts.Minute + 60 - myMin) % 60) >= 2) && (IfLoginOK == 1))//����
    	{
    		SdPrintf(YNPrint,PreFix,"HeartBeat! ����һ���������ᣬÿ2���ӷ�һ������");
    		LinkControl(3);
    		HeartBeatErr++;
    		myMin = ts.Minute;
    	}
    }

	tmpheart = JSetPara_AFN04_3761_2009->group1.f1.HeartInterval;
	if ((tmpheart < 1) || (tmpheart > 60))
		tmpheart = 2;
	//�������������ڣ���������
	if ((((ts.Minute + 60 - myMin) % 60) >= tmpheart) && (IfLoginOK == 1))//����
	{
		LinkControl(3);
		HeartBeatErr++;
		myMin = ts.Minute;
		SdPrintf(YNPrint,PreFix,"HeartBeat!  HeartBeatErr=%d", HeartBeatErr);
	}
}
void InitGwAddr() {
	memset(GwAddr, 0, 5);
	GwAddr[0] = Jcfginfo->jzqpara.Area_8016.JZ_XingZhuangQuHaoMa[1];//����������
	GwAddr[1] = Jcfginfo->jzqpara.Area_8016.JZ_XingZhuangQuHaoMa[0];
	GwAddr[2] = Jcfginfo->jzqpara.Address_8017.JZ_di_zhi[1];//�ն˵�ַ
	GwAddr[3] = Jcfginfo->jzqpara.Address_8017.JZ_di_zhi[0];
}

INT16U CalcCRC(INT8U *pBuff, INT16U len, INT16U wPsw) {
	INT16U i, j;
	INT16U W_RslCRC, W_Reg;
	INT8U B_Tmp;
	union {
		INT16U W_Reg;
		INT8U B_Reg[2];
	} U_Reg;
	W_RslCRC = 0;
	for (i = 0; i < len; i++) {
		W_RslCRC = W_RslCRC ^ (INT16U) pBuff[i];
		for (j = 0; j < 8; j++) {
			W_Reg = W_RslCRC & 0x0001;
			W_RslCRC >>= 1;
			if (W_Reg)
				W_RslCRC = W_RslCRC ^ wPsw;
		}
	}
	U_Reg.W_Reg = W_RslCRC;
	B_Tmp = U_Reg.B_Reg[0];
	U_Reg.B_Reg[0] = U_Reg.B_Reg[1];
	U_Reg.B_Reg[1] = B_Tmp;
	W_RslCRC = U_Reg.W_Reg;
	return W_RslCRC;
}
INT16U RemoteAnswer() {
//	ClearThreadTimes(ProjectNo);
	switch (TempBuf[12]) {
	case 0x00:
		SdPrintf(YNPrint,PreFix,"RemoteAnswer ��վ���� �ն���·���\n\r");
		HeartBeatErr = 0;
		IfLoginOK = 1;
		break;
	}
  return (J_ACK_NAK <<8 | TempBuf[12]);
}
INT16S LinkTest()
{
  	//ClearThreadTimes(ProjectNo);
	CreateGWHead(0x8b, 0);
	SendBuff[SendIndex++] = 0x00;
	SendBuff[SendIndex++] = 0x60 | (Fseq & 0x0f);
	SendBuff[SendIndex++] = 0;
	SendBuff[SendIndex++] = 0;
	SendBuff[SendIndex++] = 0x04;
	SendBuff[SendIndex++] = 0;

	SendBuff[SendIndex++] = 0x02;
	SendBuff[SendIndex++] = 0x00;
	SendBuff[SendIndex++] = 0x00;
	SendBuff[SendIndex++] = 0x04;
	SendBuff[SendIndex++] = 0x00;
	SendBuff[SendIndex++] = 0;
	EC();
	TP();
	FrameTailCreate_Send(0);
	HeartBeatErr = 0;
	SdPrintf(YNPrint,PreFix,"��վ���� ��·���� ȷ��\n\r");
	return J_LINKTEST;
}

void Zdrenzheng(INT8U login)
{
	int Resolve_Pos=14;
	//while(Resolve_Pos<(RecDataLen+6))//�򿪵Ļ��ַ���һ��ȡ�����
	int i;
	SdPrintf(YNPrint,PreFix, "\n Zdrenzheng\n");
	for(i=0; i<100; i++)
	{
		SdPrintf(YNPrint," ",  " %02x", TempBuf[i]);
	}
	SdPrintf(YNPrint,PreFix, "\n Zdrenzheng---------------1\n");
	CallEsam(&TempBuf[Resolve_Pos]);
	memset(TempBuf, 0, TEMPBUF_SIZE);
	return;
}

INT16U SendSet(INT8U *s)//���Ͳ������ñ��ĵ�����ȷ�ϱ��ģ�һ�����б��Ķ�Ӧ������б���
{
	INT16U i, j, k;
	INT16U Result = 0, res = 0, num;
	Result = 4;
	/*CreateGWHead(0x80, 0);
	SendBuff[SendIndex++] = 0;//AFN=00H
	SendBuff[SendIndex++] = 0x60 | (Fseq & 0x0f);//seq
	SendBuff[SendIndex++] = 0;//TmpGWBuff[14];//da1	p0
	SendBuff[SendIndex++] = 0;//TmpGWBuff[15];//da2
	SendBuff[SendIndex++] = 4;//TmpGWBuff[16];//dt1	F3:�����ݵ�Ԫ��ʶȷ�Ϻͷ���
	SendBuff[SendIndex++] = 0;//TmpGWBuff[17];//dt2
	SendBuff[SendIndex++] = 0x04;//Ҫ��ȷ�ϵı��ĵ�AFN*/
	memset(DA, 0, PointMax);
	memset(DT, 0, 255);
	GetDa(s[0], s[1]);//������ݵ�Ԫ��ʶ�е���Ϣ�㣬��Ӧ��DA[i]��1
	GetDt(s[2], s[3]);//������ݵ�Ԫ��ʶ�е���Ϣ�࣬��Ӧ��DT[i]��1
	for (i = 0; i < PointMax; i++) {
		if (DA[i] == 1) {
			for (j = 0; j < 249; j++) {
				if (DT[j] == 1) {
					TmpF = j;
					TmpP = i;//TmpPΪ��Ϣ�㣬TmpFΪ��Ϣ��Ԫ
					res = 0;
					for (k = 0; k < ITEMGWCOUNT; k++) {
//						SdPrintf(YNPrint,PreFix,"Pn=%d,Fn=%d,k=%d",i,j,k);
						if (DataGWList[k].Fn == TmpF && DataGWList[k].iDataType	== J_SETPARA)
						{
							//ClearThreadTimes(ProjectNo);
							SdPrintf(YNPrint,PreFix,"����Fn=%d��Pn=%d,Fn=%d,%d������������ַ��%d",
									           TmpF,i,j,k,(int)DataGWList[k].setdata);
							//ClearThreadTimes(ProjectNo);
							res = DataGWList[k].setdata(1, j, i, s + 4);
//							res = SetPara_F3_Set(1,j,i,s+4);
							if (res == 0) {
								break;
							}
							Result = Result + res;
							SdPrintf(YNPrint,PreFix,"Set Fe=%d--%d,%d,%d ",TmpF,i,j,k);
							//��������¼���Ч
							if (JSetPara_AFN04_3761_2009->group2.f9.Flag[0] & 0x04) {
								num = 0;
								while (num < 100) {//�ȴ��¼��������
									if (Jproginfo->stateflags.ErcFlg == 0)
										break;
									delay(50);
									num++;
								}
								memset(&Jproginfo->CurrErc , 0, sizeof(ERC));
								Jproginfo->CurrErc.Err3.ERCNo = 3;
								Jproginfo->CurrErc.Err3.len = 10;
								Jproginfo->CurrErc.Err3.QiDong_Addr = StationAddr;
								Jproginfo->CurrErc.Err3.DanYuan[0] = SetDa1(TmpP);
								Jproginfo->CurrErc.Err3.DanYuan[1] = SetDa2(TmpP);
								Jproginfo->CurrErc.Err3.DanYuan[2] = SetDt1(TmpF);
								Jproginfo->CurrErc.Err3.DanYuan[3] = SetDt2(TmpF);
								Jproginfo->stateflags.ErcFlg  = 3;
							}

						}
					}
					if (res == 0) {
						SdPrintf(YNPrint,PreFix,"����Fn=%d��δ�ҵ������ӿڣ����ͷ���",j);
						SendNAK(TmpF, TmpP, 0x0a);
						return 0;
					}
					SdPrintf(YNPrint,PreFix,"����Fn=%d����� ",j);
				}
			}
		}
	}
	/*EC();
	TP();
	//SendALLACK(0);
	FrameTailCreate_Send(0);*/
	return Result;//��ЧFn��Ӧ�ı��ĳ���֮�� + 4���ֽڣ������б�����һ�����ݵ�Ԫ�����ʶ���ܳ���
}

void SetPara()//���ò���----��
{
	int res = 0;
	Resolve_Pos = 14;
	CreateGWHead(0x80, 0);
	SendBuff[SendIndex++] = 0;//AFN=00H
	SendBuff[SendIndex++] = 0x60 | (Fseq & 0x0f);//seq
	SendBuff[SendIndex++] = 0;//TmpGWBuff[14];//da1	p0
	SendBuff[SendIndex++] = 0;//TmpGWBuff[15];//da2
	SendBuff[SendIndex++] = 4;//TmpGWBuff[16];//dt1	F3:�����ݵ�Ԫ��ʶȷ�Ϻͷ���
	SendBuff[SendIndex++] = 0;//TmpGWBuff[17];//dt2
	SendBuff[SendIndex++] = 0x04;//Ҫ��ȷ�ϵı��ĵ�AFN
	SdPrintf(YNPrint,PreFix,"�Ѵ����ֽ���=%d,�����ֽ���=%d",Resolve_Pos,DataLength);
	while (Resolve_Pos < (DataLength - 10))//���볤��Ϊ16ʱʹ��   ///while(Resolve_Pos<(DataLength+12-16-6))
	{
		SdPrintf(YNPrint,PreFix,"�Ѵ����ֽ���=%d,�����ֽ���=%d",Resolve_Pos,DataLength);
		res = SendSet(&TempBuf[Resolve_Pos]);
		if (res == 0)
			break;
		Resolve_Pos = Resolve_Pos + res;//�ۼӸ����ݵ�Ԫ�����ʶ���ܳ���,Resolve_Posָ������ݵ�Ԫ��ʶ�ĵ�һ���ֽ�
	}

	EC();
	TP();
	//10.16
	SendALLACK(0);

//	if ((Jmemory->jzq.DevFlg&0x01)==1)//��������������ȫ��ȷ��
//		SendALLACK(0);
//	else FrameTailCreate_Send(0);
}

//�����ٲ⴦��
INT16U CallSet(INT8U *s) {
	INT16U i, j, k;
	INT16U Result;
	Result = 0;
	memset(DA, 0, PointMax);
	memset(DT, 0, 255);
	GetDa(s[0], s[1]);
	GetDt(s[2], s[3]);
	for (i = 0; i < PointMax; i++) {
		if (DA[i] == 1) {
			for (j = 0; j < 249; j++) {
				if (DT[j] == 1) {
					//ClearThreadTimes(ProjectNo);
					TmpF = j;
					TmpP = i;
					for (k = 0; k < ITEMGWCOUNT; k++) {
						if (DataGWList[k].Fn == TmpF && DataGWList[k].iDataType
								== J_SETPARA) {
						//	ClearThreadTimes(ProjectNo);
							SdPrintf(YNPrint,PreFix,"��ȡ����Fn=%d��Pn=%d,Fn=%d,k=%d������������ַ��%d",TmpF,i,j,k,(int)DataGWList[k].setdata);
							Result = Result + DataGWList[k].setdata(0, j, i, s+4);
							break;
						}
					}
				}
			}
		}
	}
	SdPrintf(YNPrint,PreFix,"�ٲ��������,Result=%d",(int)Result);
	return Result;//��������ݵ�Ԫ������ֵΪ���ݵ�Ԫ��ʶ�ĳ���4����������ݵ�Ԫ������ֵΪ���ݵ�Ԫ�����ʶ���ܳ���
}

void CallSetPara()//�����ٲ������������б��ģ�һ�����б��Ķ�Ӧһ�����б���
{
	INT16U TmpSendlen, res;
	INT8U fqn;
	CreateGWHead(0x88, 0);
	SendBuff[SendIndex++] = 0x0a;//afn
	if(NeedTp==1)
		SendBuff[SendIndex++] = 0xE0 | (Fseq & 0x0f);
	else
		SendBuff[SendIndex++] = 0x60 | (Fseq & 0x0f);//seq
	fqn=Fseq;
	Resolve_Pos = 14;
	TmpSendlen = SendIndex;
	while (Resolve_Pos < (DataLength + 6))//while(Resolve_Pos<(DataLength+12-6))
	{
		res = CallSet(&TempBuf[Resolve_Pos]);
		SdPrintf(YNPrint,PreFix,"Resolve_Pos=%d res==%d  DataLength=%d\n",Resolve_Pos,res,DataLength);
		if (res == 0)
			break;
		Resolve_Pos = Resolve_Pos + res;
		if (SendIndex>TEMPBUF_SIZE-100)
			break;
	}
	if (TmpSendlen == SendIndex) {
		SdPrintf(YNPrint,PreFix,"go nodata");
		goto nodata;
	}
	EC();
	TP();
	if (fqn==Fseq)
	{
		if(NeedTp==1)
			SendBuff[13] = 0xE0 | (Fseq & 0x0f);
		else
			SendBuff[13] = 0x60 | (Fseq & 0x0f);
	}
	else {
		if(NeedTp==1)
			SendBuff[13] = 0xA0 | (Fseq & 0x0f);
		else
			SendBuff[13] = 0x20 | (Fseq & 0x0f);
		}
	FrameTailCreate_Send(0);
	return;
	nodata: SendNAK(TmpF, TmpP, 0x0a);
	return;
}

/*void CallSetPara()//�����ٲ������������б��ģ�һ�����б��Ķ�Ӧһ�����б���
{
	INT16U TmpSendlen, res,num,nn,fqn;
	SdPrint("\n\rTTTT begin\n\r");
	CreateGWHead(0x88, 0);
	// SdPrint("\n\rComplete create head!");
	SendBuff[SendIndex++] = 0x0a;//afn
	SdPrint("\n\rFlag0-1");
	SendBuff[SendIndex] = 0x60 | (Fseq & 0x0f);//seq
	SdPrint("\n\rFlag0-2");
	Resolve_Pos = 14;
	num=(DataLength-Resolve_Pos+6-2)/4;
	SendIndex++;
	TmpSendlen = SendIndex;
	SdPrint("\n\rFlag0-3");
	nn=0;
	fqn=0;
	while (Resolve_Pos < (DataLength + 6))//while(Resolve_Pos<(DataLength+12-6))
	{
		res = CallSet(&TempBuf[Resolve_Pos]);
		if (res == 0)
			break;
		Resolve_Pos = Resolve_Pos + res;
		nn++;
		if (((nn%100)==0)&&(num>100)&&(nn!=num))
		{
			if (TmpSendlen != SendIndex)
			{
				fqn++;
				if (fqn==1)
				{
					SendBuff[13] = 0x40 | (Fseq & 0x0f);
					FrameTailCreate_Send(0);
				}
				else
				{
					SendBuff[13] = 0x00 | (Fseq & 0x0f);
					FrameTailCreate_Send(0);
				}
			}
			CreateGWHead(0x88, 0);
			// SdPrint("\n\rComplete create head!");
			SendBuff[SendIndex++] = 0x0a;//afn
			SdPrint("\n\rFlag0-1");
			SendBuff[SendIndex] = 0x00 | (Fseq & 0x0f);
			SendIndex++;
			TmpSendlen = SendIndex;
		}
		if (SendIndex>TEMPBUF_SIZE-100)
			break;
	}
	SdPrint("\n\rFlag1\n\r");
	if (TmpSendlen == SendIndex) {
		goto nodata;
	}
	SdPrint("\n\rFlag2");
	EC();
	SdPrint("\n\rFlag3");
	TP();
	SdPrint("\n\rFlag4");
	if (fqn==0)
		SendBuff[13] = 0x60 | (Fseq & 0x0f);
	else SendBuff[13] = 0x20 | (Fseq & 0x0f);
	FrameTailCreate_Send(0);
	return;
	nodata: SendNAK(TmpF, TmpP, 0x0a);
	return;
}*/

INT8U CallOnelevelDataCalc()//����һ������
{
	INT16U i, j;//Pro130SetMax
	INT16U Tmp_Resolve_Pos;
	Tmp_Resolve_Pos = 14;
	AllReportHead = 0;
	AllReportTail = 0;
	while (Tmp_Resolve_Pos < (DataLength + 6)) {
		GetDa(TempBuf[Tmp_Resolve_Pos], TempBuf[Tmp_Resolve_Pos + 1]);
		GetDt(TempBuf[Tmp_Resolve_Pos + 2], TempBuf[Tmp_Resolve_Pos + 3]);
		//		DebugOut(DebugComm,"W=%d S=%d ",Resolve_Pos,(RecDataLen+6));
		for (i = 0; i < PointMax; i++) {
			if (DA[i] == 1) {
				for (j = 0; j < 255; j++) {
					if (DT[j] == 1) {
						AllReportHead++;
					}
				}
			}
		}
		Tmp_Resolve_Pos += 4;
	}
	return 0;
}

/***********************************************************************
 *����1�����ݣ�AFN=0CH��
 *���ú���:AskTwoLevelData();
 *�ص�����:��     ��д��Ա��
 ***********************************************************************/
void CallOnelevelData()//
{
	INT16U i, j, k, res;//ProGWSetMax
	INT8U datatype,TempBuf2[60];
	//CallOnelevelDataCalc();
	Resolve_Pos = 14;
	res = 0;
	LDType = 1;
	AllReportTail = 0;
	AllReportHead = 1;

	MY_MKLevel1Head(0x88);
	while (Resolve_Pos < (DataLength + 6))
	{
		GetDa(TempBuf[Resolve_Pos], TempBuf[Resolve_Pos + 1]);
		GetDt(TempBuf[Resolve_Pos + 2], TempBuf[Resolve_Pos + 3]);
		Resolve_Pos = Resolve_Pos + 4;
		for (i = 0; i < PointMax; i++) {
			if (DA[i] == 1) {
				for (j = 0; j < 255; j++) {
					if (DT[j] == 1) {
						TmpF = j;
						TmpP = i;
						SdPrintf(YNPrint,PreFix,"Pn=%d  Fn=%d \n\r",TmpP,TmpF);
						for (k = 0; k < ITEMGWCOUNT; k++)//ͨ��ITEMGWCOUNT��ѭ������������Ӧ�Ĵ���������������������
						{
							//ClearThreadTimes(ProjectNo);
							memset(TempBuf2,0,60);
							datatype = J_1LEIDATE;
							if (JSetPara_AFN04_3761_2009->group2.f10[TmpP-1].Type!=9)
								datatype = J_1LEICURR;
//							if (Jmemory->mainData.Time_Flag != 100)
							if(Jproginfo->mainData.Time_Flag != 100)
								datatype = J_1LEICURR;
							datatype = J_1LEICURR;
							sprintf((char*)TempBuf2,"/nand/DataCurr/%04d/curr.dat",TmpP);
							if (access((char*)TempBuf2,0)!=0)
								datatype = J_1LEIDATE;
							else
								datatype = J_1LEICURR;

							//�½�
							//if((Jmemory->JiangXi || Jmemory->XinJiang ||Jmemory->TianJing || Jmemory->JiangSu) && TmpP!=1)		//DataGWList[k].Fn == 35 ||  9.22
							if((((zone_so&0x7f) == JIANGXI) || ((zone_so&0x7f) == XINJIANG) || ((zone_so&0x7f) == TIANJIN)
									||((zone_so&0x7f) == JIANGSU))
																 && (TmpP != 1))
							{
								if(
									DataGWList[k].Fn ==161 || DataGWList[k].Fn ==49 || DataGWList[k].Fn ==162 ||
									DataGWList[k].Fn == 165 || DataGWList[k].Fn == 166 || DataGWList[k].Fn == 167 ||
									DataGWList[k].Fn == 31|| DataGWList[k].Fn == 32||
									DataGWList[k].Fn == 37|| DataGWList[k].Fn == 38|| DataGWList[k].Fn == 39 ||
									DataGWList[k].Fn == 137|| DataGWList[k].Fn == 138|| DataGWList[k].Fn == 139 ||
									DataGWList[k].Fn == 140|| DataGWList[k].Fn == 141|| DataGWList[k].Fn == 142||
									DataGWList[k].Fn == 143|| DataGWList[k].Fn == 144||
									DataGWList[k].Fn == 149)
								{
									datatype = J_1LEIDATE;
								}
							}
							//if(Jmemory->HeBei && ((TmpF>=17 && TmpF<=160) || TmpF == 167))
							if(((zone_so&0x7f) == HEBEI) && ((TmpF>=17 && TmpF<=160) || TmpF == 167))
							{
								datatype = J_1LEICURR;
							}
						//	if(Jmemory->JiangSu)
							if((zone_so&0x7f) ==  JIANGSU)
							{
								if(DataGWList[k].Fn == 129)
									datatype = J_1LEICURR;
							}
						//	if(Jmemory->TianJing && (TmpF>=17 && TmpF<=160))
							if((zone_so&0x7f) == TIANJIN && (TmpF>=17 && TmpF<=160))
							{
								datatype = J_1LEICURR;
							}
							//if((Jmemory->TianJing) && (TmpF == 167))
							if((zone_so&0x7f) == TIANJIN && (TmpF == 167))
							{
								datatype = J_1LEICURR;
							}

							if(TmpF==168||TmpF==169 || TmpF ==170)
								datatype = J_1LEIDATE;
							if((zone_so&0x7f) == SHANGHAI){
								datatype = J_1LEICURR;
							}
							LDType = 0;
//							SdPrintf("P=%d  F=%d  AFN=%02x======",i,j,datatype);
							if (DataGWList[k].Fn == TmpF && DataGWList[k].iDataType == datatype)
							{
		                        SdPrintf(YNPrint,PreFix,"Fn=%d  Pn=%d  AFN=%02x",j,i,datatype);
//								MY_MKDataUnitFlag(i,j);				//���ݵ�Ԫ��ʶ
		                        MY_MKDataUnitFlag(TmpP,TmpF);
								//ClearThreadTimes(ProjectNo);
								AutoFlg = 0;
								PrmFlg = 0;
//								res = res + DataGWList[k].setdata(0, j, i, &TempBuf[Resolve_Pos]);
								res = res + DataGWList[k].setdata(0, TmpF, TmpP, &TempBuf[Resolve_Pos]);
								SdPrintf(YNPrint,PreFix,"��������ִ�����");
								break;
							}
						}
						if (j==248)//������Լ��չ
							return;
					}
				}
			}
		}
		//Resolve_Pos += 4;
	}
	EC();
	TP();
	FrameTailCreate_Send(0);  //jiangsu 10��18��
	if (res == 0) {
		SendNAK(TmpF, TmpP, 0x0a);
		return;
	}
	return;
}
extern INT8U CallTwolevelDataCalc_flg;
INT8U CallTwolevelDataCalc()
{
	INT16U i, j;
	int TailSendOk=0;
	Resolve_Pos = 14;
	LDType = 1;
	AllReportHead = 0;
	AllReportTail = 0;
	SendIndex = 0;
	SendIndex = SendIndex + 14;
	while (Resolve_Pos < (DataLength + 6))
	{
		GetDa(TempBuf[Resolve_Pos], TempBuf[Resolve_Pos + 1]);
		GetDt(TempBuf[Resolve_Pos + 2], TempBuf[Resolve_Pos + 3]);
//		fprintf(stderr,"\n")
		Resolve_Pos = Resolve_Pos + 4;
		for (i = 0; i < PointMax; i++)
		{
			if (DA[i] == 1)
			{
				for (j = 0; j < 255; j++)
				{
					if (DT[j] == 1)
					{
						CallTwolevelDataCalc_flg = 1;
						MY_MKDataUnitFlag(i,j);				//���ݵ�Ԫ��ʶ
						TailSendOk = 0;
						Resolve_Pos = Resolve_Pos + SendTwoLevelData(i, j,&TempBuf[Resolve_Pos]);
						CallTwolevelDataCalc_flg = 0;
					}
				}
				if (SendIndex > FRAME_MAX)
				{
					AllReportHead++;
					SdPrintf(YNPrint,PreFix, "\n------00����� %d ֡   �ֽ��� %d",AllReportHead, SendIndex);
					TailSendOk = 1;
					SendIndex = 0;
					SendIndex = SendIndex + 14;
				}
			}
		}
	}
	if(TailSendOk == 0)
	{
		AllReportHead++;
		SdPrintf(YNPrint,PreFix, "\n------����� %d ֡   �ֽ��� %d",AllReportHead, SendIndex);
	}
		return 0;
//	INT16U i, j;//Pro130SetMax
//	INT16U Tmp_Resolve_Pos;
//	Tmp_Resolve_Pos = 14;
//	AllReportHead = 0;
//	AllReportTail = 0;
//	while (Tmp_Resolve_Pos < (DataLength + 6))
//       {
//		GetDa(TempBuf[Tmp_Resolve_Pos], TempBuf[Tmp_Resolve_Pos + 1]);
//		GetDt(TempBuf[Tmp_Resolve_Pos + 2], TempBuf[Tmp_Resolve_Pos + 3]);
//		//		DebugOut(DebugComm,"W=%d S=%d ",Resolve_Pos,(RecDataLen+6));
//		for (i = 0; i < PointMax; i++)
//                {
//			if (DA[i] == 1)
//                        {
//				for (j = 0; j < 255; j++)
//                                {
//					if (DT[j] == 1)
//                    {
//						AllReportHead++;
//					}
//				}
//			}
//		}
//		Tmp_Resolve_Pos += 4;
//	}
//	return 0;
}

/***********************************************************************
 *����2�����ݣ�AFN=0DH��
 *���ú���:AskTwoLevelData();
 *�ص�����:��
 ***********************************************************************/
INT8U CallTwoDataProc(INT16U F, INT16U P, INT8U QxBl, INT8U *S, INT8U FRM) {
	INT16U k = 0;
	//AllReportHead = 0;
	//AllReportTail = 0;
	SdPrintf(YNPrint,PreFix,"%s p=%d f=%d ","���Ͷ�������",P,F);
	//AllReportHead++;
	for (k = 0; k < ITEMGWCOUNT; k++)//ͨ��ITEMGWCOUNT��ѭ������������Ӧ�Ĵ���������������������
	{
		if (DataGWList[k].Fn == F && DataGWList[k].iDataType == J_2LEIDATE) {
			//ClearThreadTimes(ProjectNo);
			LDType = 0;
			return DataGWList[k].setdata(0, F, P, S);
		}
	}
	if (AutoFlg==0 && CallTwolevelDataCalc_flg ==0)//376.1   3250ping----
		SendNAK(F, P, 0x0d);//376.1   3250ping----
	return 7;
}
INT8U SendTwoLevelData(INT16U P, INT16U F, INT8U *t) {
	INT16U i;
	PrmFlg = 0;
	AutoFlg = 0;
	i = CallTwoDataProc(F, P, 1, t, 0x88);
	return i;
}
/***********************************************************************
 *����2�����ݣ�AFN=0DH��
 *���ú���:AskTwoLevelData();
 *�ص�����:��
 ***********************************************************************/
void CallTwolevelData() {
	INT16U i, j;
	int TailSendOk=0;
	CallTwolevelDataCalc();//�¼��ֽ���������
	SdPrintf(YNPrint,PreFix, "\n  ������֡����%d",AllReportHead);
	Resolve_Pos = 14;
	LDType = 1;
	MY_MKLevel2Head(0x88);	//����֡ͷ
	TailSendOk = 0;
	while (Resolve_Pos < (DataLength + 6))
	{
		GetDa(TempBuf[Resolve_Pos], TempBuf[Resolve_Pos + 1]);
		GetDt(TempBuf[Resolve_Pos + 2], TempBuf[Resolve_Pos + 3]);
		Resolve_Pos = Resolve_Pos + 4;
		for (i = 0; i < PointMax; i++)
		{
			if (DA[i] == 1)
			{
				for (j = 0; j < 255; j++)
				{
					if (DT[j] == 1)
					{
						MY_MKDataUnitFlag(i,j);				//���ݵ�Ԫ��ʶ
						TailSendOk = 0;
						Resolve_Pos = Resolve_Pos + SendTwoLevelData(i, j,&TempBuf[Resolve_Pos]);
					}
				}
				if (SendIndex > FRAME_MAX)
				{
					EC(); TP(); FrameTailCreate_Send(0);
					SdPrintf(YNPrint,PreFix, "\n--------------------------------00����  %d ֡    �ֽ� %d",AllReportTail,SendIndex);
					TailSendOk = 1;
//					ClearWaitTimes(ProjectNo);
					delay(1000);
					MY_MKLevel2Head(0x88|(PrmFlg<<6));
				}
			}
		}
	}
	if(TailSendOk == 0)
	{
		EC(); TP(); FrameTailCreate_Send(0);
		SdPrintf(YNPrint,PreFix, "\n--------------------------------����  %d ֡    �ֽ� %d",AllReportTail,SendIndex);
//		ClearWaitTimes(ProjectNo);
		delay(1000);
	}
	return;
}
int Set_Importnet_eve(INT8U B) {
	INT8U FirFin, j, i;
	SdPrintf(YNPrint,PreFix,"������Ҫ�¼�");
	FirFin = 0;
	CreateGWHead(0x84, 0);
	SendBuff[SendIndex++] = 0x0e;//afn
	if (B == 0)
		FirFin = 0x40;
	if (((ReadEveHead + 256 - ReadEveTail) % 256) <= 5) {
		FirFin = FirFin | 0x20;
	}
	SendBuff[SendIndex++] = FirFin | (Fseq & 0x0f);//seq��һ�壬��������
	SendBuff[SendIndex++] = 0;
	SendBuff[SendIndex++] = 0;
	SendBuff[SendIndex++] = 1;
	SendBuff[SendIndex++] = 0;
	SendBuff[SendIndex++] = Jdatafileinfo->ErcEvt.EC1;
	SendBuff[SendIndex++] = Jdatafileinfo->ErcEvt.EC2;
	if ((((ReadEveHead + 256 - ReadEveTail) % 256) <= 5)) {
		SendBuff[SendIndex++] = ReadEveTail;
		SendBuff[SendIndex++] = ReadEveHead;
	} else {
		SendBuff[SendIndex++] = ReadEveTail;
		SendBuff[SendIndex++] = ReadEveTail + 5;
	}
	for (j = 0; j < 5; j++) {
//		printf("ReadEveTail---%d--%d\n\r", ReadEveHead, ReadEveTail);
//		printf("ReadEveBuff---%d--%d\n\r",
//				Jdatafileinfo->ErcEvt.ImpEvent[ReadEveTail].Buff[0],
//				Jdatafileinfo->ErcEvt.ImpEvent[ReadEveTail].Buff[1]);
		memcpy(&Tmp_Erc, &Jdatafileinfo->ErcEvt.ImpEvent[ReadEveTail], sizeof(ERC));
		SendBuff[SendIndex++] = Tmp_Erc.Buff[0];
		SendBuff[SendIndex++] = Tmp_Erc.Buff[1];
		if ((Tmp_Erc.Buff[0] == 0) || (Tmp_Erc.Buff[1] == 0)) {
			//SendNAK(TmpF,TmpP,0x0e);
			ReadEveTail++;
			return 0;
		}
		for (i = 0; i < Tmp_Erc.Buff[1]; i++) {
			SendBuff[SendIndex++] = Tmp_Erc.Buff[2 + i];
		}
		ReadEveTail++;
		if (ReadEveTail == ReadEveHead)
			break;
	}
	EC();
	TP();
	FrameTailCreate_Send(0);
	return 1;
}

int Set_normal_eve(INT8U B) {
	INT8U FirFin, j, i;
	SdPrintf(YNPrint,PreFix,"����һ���¼�");
	FirFin = 0;
	CreateGWHead(0x84, 0);
	SdPrintf(YNPrint,PreFix,"Set_normal_eve SendIndex : %d", SendIndex);
	SendBuff[SendIndex++] = 0x0e;//afn
	if (B == 0)
		FirFin = 0x40;
	if (((ReadEveHead + 256 - ReadEveTail) % 256) <= 5) {
		FirFin = FirFin | 0x20;
	}
	SendBuff[SendIndex++] = FirFin | (Fseq & 0x0f);//seq��һ�壬��������
	SendBuff[SendIndex++] = 0;//TempBuf[14];//da1e
	SendBuff[SendIndex++] = 0;//TempBuf[15];//da2
	SendBuff[SendIndex++] = 2;//TempBuf[16];//dt1
	SendBuff[SendIndex++] = 0;//TempBuf[17];//dt2
	SendBuff[SendIndex++] = Jdatafileinfo->ErcEvt.EC1;
	SendBuff[SendIndex++] = Jdatafileinfo->ErcEvt.EC2;
//	printf("\n --ReadEveHead =%d  ReadEveTail=%d\n", ReadEveHead, ReadEveTail);
	if ((((ReadEveHead + 256 - ReadEveTail) % 256) <= 5)) {
		SendBuff[SendIndex++] = ReadEveTail;
		SendBuff[SendIndex++] = ReadEveHead;
	} else {
		SendBuff[SendIndex++] = ReadEveTail;
		SendBuff[SendIndex++] = ReadEveTail + 5;
	}
//	printf("\n ++++ReadEveHead =%d  ReadEveTail=%d\n", ReadEveHead, ReadEveTail);
//	for(i=0;i<256;i++)
//	{
//		printf("\n Jdatafileinfo->ErcEvt.NorEvent[0][1]=%02x %02x",Jdatafileinfo->ErcEvt.NorEvent[i].Buff[0],Jdatafileinfo->ErcEvt.NorEvent[i].Buff[1]);
//	}
	for (j = 0; j < 5; j++)
	{
		memcpy(&Tmp_Erc, &Jdatafileinfo->ErcEvt.NorEvent[ReadEveTail], sizeof(ERC));
		SendBuff[SendIndex++] = Tmp_Erc.Buff[0];
		SendBuff[SendIndex++] = Tmp_Erc.Buff[1];
//		printf("\n Tmp_Erc.Buff[0] = %02x %02x \n", Tmp_Erc.Buff[0],Tmp_Erc.Buff[1]);
		if ((Tmp_Erc.Buff[0] == 0) || (Tmp_Erc.Buff[1] == 0))
		{
			//SendNAK(TmpF,TmpP,0x0e);
			ReadEveTail++;
			return 0;
		}
		for (i = 0; i < Tmp_Erc.Buff[1]; i++)
		{
			SendBuff[SendIndex++] = Tmp_Erc.Buff[2 + i];
		}
		ReadEveTail++;
		if (ReadEveTail == ReadEveHead)
			break;
	}
	EC();
	TP();
	FrameTailCreate_Send(0);
	return 1;
}

void CallThreelevelData()//----��
{
	INT8U k, flag = 0;
	NeedTp = 0;
	if (TempBuf[13] & 0x80) {
		NeedTp = 1;
	}
	GetDa(TempBuf[14], TempBuf[15]);
	GetDt(TempBuf[16], TempBuf[17]);
//	printf("\n TempBuf[16]:%02x TempBuf[17]:%02x  DT[1]=%02x DT[2]=%02x \n",
//			TempBuf[16],TempBuf[17], DT[1], DT[2]);
	if (DT[1] == 1) {
		TmpF = 1;
		ReadEveHead = TempBuf[19];
		ReadEveTail = TempBuf[18];
//		printf("import event: ReadEveHead---%d--%d\n\r", ReadEveHead, ReadEveTail);
		k = 0;
		while (ReadEveHead != ReadEveTail)
		{
			//ClearThreadTimes(ProjectNo);
			if (Set_Importnet_eve(k++) == 1)
				flag = 1;
		}
		delay(100);
	}
	if (DT[2] == 1) {
		TmpF = 2;
		ReadEveHead = TempBuf[19];
		ReadEveTail = TempBuf[18];
//		printf("normal event : ReadEveHead---%d--%d\n\r", ReadEveHead, ReadEveTail);
		k = 0;
		while (ReadEveHead != ReadEveTail)
		{
			//ClearThreadTimes(ProjectNo);
			if (Set_normal_eve(k++) == 1)
				flag = 1;
		}
		delay(100);
	}

	TmpP = 0;
	if (flag == 0)
		SendNAK(TmpF, TmpP, 0x0e);
}
void SendNakTrans(INT16U F,INT16U P,INT8U AFN,int tport) //weifang
{
	if (AutoFlg==1)
		return;
	CreateGWHead(0x88,0);
	SendBuff[SendIndex++]=0x10;	//afn����ѯ�����Ļظ����ģ�afn=0x10��
	SendBuff[SendIndex++]=0x60|(Fseq&0x0f);	//Fseq: ��jPub.h���涨��
	SendBuff[SendIndex++]=0x00;	//da1
	SendBuff[SendIndex++]=0x00;	//da2
	SendBuff[SendIndex++]=0x01;	//dt1
	SendBuff[SendIndex++]=0x00;	//dt2
	SendBuff[SendIndex++]= tport;	//port
	SendBuff[SendIndex++]=0;
	SendBuff[SendIndex++]=0;

	EC();
	TP();
	FrameTailCreate_Send(0);
	return;

}
/***********************************************************************
 *����2�����ݣ�AFN=10H��
 *���ú���:AskTwoLevelData();
 *�ص�����:�ޣ�*��д��Ա�������
 ***********************************************************************/
int GetFlag97By07(INT8U *Flag07,INT8U *Flag97)
{
	int re=0;
	int i;
	for(i=0;i<FlagsCount;i++)
	{
//		printf("\n 07[0]=%02x %02x %02x %02x  ",
//				Jmemory->Para.meterFlags.dataFlags[0][i].flagOth.Dataflag[0],
//				Jmemory->Para.meterFlags.dataFlags[0][i].flagOth.Dataflag[1],
//				Jmemory->Para.meterFlags.dataFlags[0][i].flagOth.Dataflag[2],
//				Jmemory->Para.meterFlags.dataFlags[0][i].flagOth.Dataflag[3]);
		//printf("\n ��ս�·���07[0]=%02x %02x %02x %02x  ",Flag07[0],Flag07[1],Flag07[2],Flag07[3]);
	//	printf("\n-----------------------------");
		if ((Flag07[0] == Jproginfo->Para.meterFlags.dataFlags[0][i].flagOth.Dataflag[0] ) &&
			(Flag07[1] == Jproginfo->Para.meterFlags.dataFlags[0][i].flagOth.Dataflag[1] ) &&
			(Flag07[2] == Jproginfo->Para.meterFlags.dataFlags[0][i].flagOth.Dataflag[2] ) &&
			(Flag07[3] == Jproginfo->Para.meterFlags.dataFlags[0][i].flagOth.Dataflag[3] ))
		{
			Flag97[0] = Jproginfo->Para.meterFlags.dataFlags[0][i].flag97.Dataflag[0];
			Flag97[1] = Jproginfo->Para.meterFlags.dataFlags[0][i].flag97.Dataflag[1];
			re = 1;
			break;
		}
	}
	return re;
}

void DataTrans()//����ת��
{
	int seconds=0;
	int k, num, dely;//weifang
	NeedTp = 0;

	INT16U i, _ByteCount;//ѭ���ͷ������ݵľֲ�����

	if (TempBuf[13] & 0x80)//֡������TpV��TempBuf[TEMPBUF_SIZE];    //��ʱ������
	{
		NeedTp = 1;
	}
	GetDa(TempBuf[14], TempBuf[15]);
	GetDt(TempBuf[16], TempBuf[17]);

	num = 0;
	if (DT[1] == 1)//��ӦF1��DT[255]
	{
		Jproginfo->dataTransgw.f1.ASK_Port = TempBuf[18];//Jmemory �ڴ湲��������ָ��
		Jproginfo->dataTransgw.f1.ASK_Control = TempBuf[19];
		Jproginfo->dataTransgw.f1.WaitTime = TempBuf[20];
		Jproginfo->dataTransgw.f1.DelayTime = TempBuf[21];
		Jproginfo->dataTransgw.f1.len[0] = TempBuf[22];
		Jproginfo->dataTransgw.f1.len[1] = TempBuf[23];

		_ByteCount = TempBuf[22] + (TempBuf[23] << 8);//͸��ת�������ֽ���K
		if (_ByteCount >= 256)
			SendNAK(0, 1, 0x10);
		memset(&Jproginfo->dataTransgw.f1.ANSWER_Buf[0], 0, 256);
		//----ת��----
//		for (i = 0; i < _ByteCount; i++)//�ٶ�����������ֽ���_ByteCount������256���ֽڣ��������
//		{
//			Jproginfo->dataTransgw.f1.ANSWER_Buf[i+4] = TempBuf[24 + i];
//		}	//zhuanfa ---
//		Jproginfo->dataTransgw.f1.ANSWER_Buf[0]= 0xfe;//zhuanfa ---
//		Jproginfo->dataTransgw.f1.ANSWER_Buf[1]= 0xfe;
//		Jproginfo->dataTransgw.f1.ANSWER_Buf[2]= 0xfe;
//		Jproginfo->dataTransgw.f1.ANSWER_Buf[3]= 0xfe;

		for (i = 0; i < _ByteCount; i++)//�ٶ�����������ֽ���_ByteCount������256���ֽڣ��������
		{
			Jproginfo->dataTransgw.f1.ANSWER_Buf[i] = TempBuf[24+i];
		}

		SdPrintf(YNPrint,PreFix,"Trans ANSWER_Buf: _ByteCount=%d\n",_ByteCount);
		for(i=0;i<_ByteCount;i++)//zhuanfa  i<_ByteCount+4
			SdPrintf(YNPrint," ","%02x",Jproginfo->dataTransgw.f1.ANSWER_Buf[i]);
		//-------------ת��--------------end
		num++;
		while (num < 100) {
			if (Jproginfo->dataTransgw.f1.ASK_Stat == 0) {
				break;
			}
			delay(50);
			num++;
		}
		Jproginfo->dataTransgw.f1.ASK_Stat = 1;

		//Jproginfo->dataTransgw.delay = 1000;
		k = 0; //ת��
		if (Jproginfo->dataTransgw.f1.WaitTime & 0x80)
		{
			//�밴��2���ȴ�
			dely = (Jproginfo->dataTransgw.f1.WaitTime & 0x7F) * 1000* 2;
		}
		else
		{
			//���밴��10���ȴ�
			dely=(Jproginfo->dataTransgw.f1.WaitTime&0x7F)*10*10;
		}
		num=0;
//		printf("\n----dely----------------------%d\n",dely);
		if(Jproginfo->dataTransgw.f1.ANSWER_Buf[10]==0xF0 &&
			Jproginfo->dataTransgw.f1.ANSWER_Buf[11]==0x08 &&
			Jproginfo->dataTransgw.f1.ANSWER_Buf[12]==0x00)
			Jproginfo->stateflags.UpdateZB_flag = 1;
		for(k=0;k<(dely/100);k++)//���ѭ��20��
		{
			//ClearThreadTimes(ProjectNo);
			if (Jproginfo->dataTransgw.f1.ASK_Stat==2)
			{
				num=1;
				CreateGWHead(0x88,0);
				SendBuff[SendIndex++]=0x10; //afn����ѯ�����Ļظ����ģ�afn=0x10��
				SendBuff[SendIndex++]=0x60|(Fseq&0x0f); //Fseq: ��jPub.h���涨��
				SendBuff[SendIndex++]=0x00; //da1
				SendBuff[SendIndex++]=0x00; //da2
				SendBuff[SendIndex++]=0x01; //dt1
				SendBuff[SendIndex++]=0x00; //dt2
				SendBuff[SendIndex++]=Jproginfo->dataTransgw.f1.ASK_Port;/////----ת�������޸�
				SendBuff[SendIndex++]=Jproginfo->dataTransgw.f1.len[0];
				SendBuff[SendIndex++]=Jproginfo->dataTransgw.f1.len[1];

				_ByteCount=Jproginfo->dataTransgw.f1.len[0]+(Jproginfo->dataTransgw.f1.len[1]<<8);

				SdPrintf(YNPrint,PreFix,"_ByteCount=%d\n\r",_ByteCount);
				for(i=0;i<_ByteCount;i++)
				{
					SdPrintf(YNPrint," ","%02x",Jproginfo->dataTransgw.f1.ANSWER_Buf[i]);
					SendBuff[SendIndex++]=Jproginfo->dataTransgw.f1.ANSWER_Buf[i];//׷��ת����������
				}
				SdPrintf(YNPrint,PreFix,"\n\r");
				EC();
				TP();
				FrameTailCreate_Send(0);//��֪��������������������壬1 ��¼
				Jproginfo->dataTransgw.f1.ASK_Stat=0;
				return;
			}
			delay(100);//zhuanfa  delay(100)
		}
		if (num==0)
		{
//			printf("\n SendNAK datatrans \n");
			seconds = time((time_t*)NULL);
//			printf("\n sendnak seconds =%d\n",seconds);
			//ClearThreadTimes(ProjectNo);
			Jproginfo->BeiYong[10]=1;//weifang
			//68 3e 00 3e 00 68 88 30 05 62 04 96 10 61 00 00 01 00 1f 00 00 4a 16   //0530-0462
			//68 3e 00 3e 00 68 88 30 05 62 04 96 10 66 00 00 01 00 1f 00 00 4f 16
			//68 3e 00 3e 00 68 88 30 05 62 04 96 10 60 00 00 01 00 1f 00 00 49 16
			//SendNAK(0,1,0x10);
			SendNakTrans(0,0,0x10,Jproginfo->dataTransgw.f1.ASK_Port);
			Jproginfo->dataTransgw.f1.ASK_Stat = 0;//����ת��ʧ�ܣ�ת��״̬��0 //weifang
		}
		return;
	}


	if(DT[9]==1)//F9   //9.27
	{
		Jproginfo->dataTransgw.f9.ASK_Port=TempBuf[18];//Jmemory �ڴ湲��������ָ��
		Jproginfo->dataTransgw.f9.ASK_Leval=TempBuf[19];
		if(Jproginfo->dataTransgw.f9.ASK_Leval==0xff) //9.27
			Jproginfo->dataTransgw.f9.ASK_Leval = 0;
		for(i=0;i<Jproginfo->dataTransgw.f9.ASK_Leval;i++)
		{
			for(k=0;k<6;k++)//ת���м̵�ַ
			{
				Jproginfo->dataTransgw.f9.ASK_Buf[i][k]=TempBuf[20+i*6+k];
			}
		}
		SdPrintf(YNPrint,PreFix,"��ַ:");
		for(k=0;k<6;k++)//ת��Ŀ���ַ
		{
			Jproginfo->dataTransgw.f9.ANSWER_adress[k]=TempBuf[20+Jproginfo->dataTransgw.f9.ASK_Leval*6+k];//
			SdPrintf(YNPrint," ","%02x",Jproginfo->dataTransgw.f9.ANSWER_adress[k]);
		}
		Jproginfo->dataTransgw.f9.ASK_DataType=TempBuf[20+Jproginfo->dataTransgw.f9.ASK_Leval*6 + 6];
		SdPrintf(YNPrint,PreFix,"�����Լ��%d  ������:",Jproginfo->dataTransgw.f9.ASK_DataType);
		if (Jproginfo->dataTransgw.f9.ASK_DataType == 0)
		{
			for(k=0;k<2;k++)//ת��ֱ�ӳ��������ݱ�ʶ
			{
				Jproginfo->dataTransgw.f9.DataFlag[k]=TempBuf[20+Jproginfo->dataTransgw.f9.ASK_Leval*6+ 7 +k];
				SdPrintf(YNPrint," ","%02x",Jproginfo->dataTransgw.f9.DataFlag[k]);
			}
		}
		if (Jproginfo->dataTransgw.f9.ASK_DataType == 1)
		{
			for(k=0;k<4;k++)//ת��ֱ�ӳ��������ݱ�ʶ
			{
				Jproginfo->dataTransgw.f9.DataFlag[k]=TempBuf[20+Jproginfo->dataTransgw.f9.ASK_Leval*6+ 7 +k];
				SdPrintf(YNPrint," ","%02x",Jproginfo->dataTransgw.f9.DataFlag[k]);
			}
		}
		int tmp_cno;
		INT8U meterfind=0;
		for(tmp_cno=0;tmp_cno<PointMax;tmp_cno++)//����Ŀ���ַ�����Ҳɼ�����
		{
			if ((Jproginfo->dataTransgw.f9.ANSWER_adress[0] == JSetPara_AFN04_3761_2009->group2.f10[tmp_cno].Address[0])&&
				(Jproginfo->dataTransgw.f9.ANSWER_adress[1] == JSetPara_AFN04_3761_2009->group2.f10[tmp_cno].Address[1])&&
				(Jproginfo->dataTransgw.f9.ANSWER_adress[2] == JSetPara_AFN04_3761_2009->group2.f10[tmp_cno].Address[2])&&
				(Jproginfo->dataTransgw.f9.ANSWER_adress[3] == JSetPara_AFN04_3761_2009->group2.f10[tmp_cno].Address[3])&&
				(Jproginfo->dataTransgw.f9.ANSWER_adress[4] == JSetPara_AFN04_3761_2009->group2.f10[tmp_cno].Address[4])&&
				(Jproginfo->dataTransgw.f9.ANSWER_adress[5] == JSetPara_AFN04_3761_2009->group2.f10[tmp_cno].Address[5]))
			{
				Jproginfo->RealData.CaijiqiNo=JSetPara_AFN04_3761_2009->group2.f10[tmp_cno].CjqNo-1;//CJQno;//�ɼ�����
				Jproginfo->RealData.MeterNo=JSetPara_AFN04_3761_2009->group2.f10[tmp_cno].MeterNo;//Meterno;//SD����
				meterfind = 1;
				break;
			}
			else
			{
				continue;
			}
		}
		//��ѯ��Ӧ���ݱ�ʶ����������
		INT8U flag97[2];
		if (Jproginfo->dataTransgw.f9.ASK_DataType==0)
		{
			flag97[0] =  Jproginfo->dataTransgw.f9.DataFlag[0];
			flag97[1] =  Jproginfo->dataTransgw.f9.DataFlag[1];
		}
		if (Jproginfo->dataTransgw.f9.ASK_DataType==1)
		{
			GetFlag97By07(Jproginfo->dataTransgw.f9.DataFlag,flag97);
		}
		SdPrintf(YNPrint,PreFix,"find !97[0]=%02x %02x",flag97[0],flag97[1]);
		Jproginfo->RealData.flg97[0].flg.Dataflag[1]=flag97[1];
		Jproginfo->RealData.flg97[0].flg.Dataflag[0]=flag97[0];
		Jproginfo->RealData.CurFlgCount=1;
		int dely=4;
		if (Jproginfo->RealData.CurFlgCount<20)
			dely = Jproginfo->RealData.CurFlgCount*3;
		else
			dely=40;
		if (dely<5)
			dely=20;
		SdPrintf(YNPrint,PreFix,"delay=%d\n",dely);

		memset(tempRealTimeData.flg97[0].datas,0xee,DataLenMax);
		if(meterfind==1)
		{
			Jproginfo->dataTransgw.f9.len= 0;
			if (GetRealTimeDatas(1000,dely,Jproginfo)==9)
			{
				//memcpy(&tempRealTimeData.ReadFlg,&Jmemory->RealData.ReadFlg,sizeof(Jmemory->RealData));
				memcpy(&tempRealTimeData.ReadFlg,&Jproginfo->RealData.ReadFlg,sizeof(Jproginfo->RealData));
				printf("\n�����ɹ���");
			}
		}
//			else
//			{
//				memset(&tempRealTimeData.ReadFlg,0x00,sizeof(Jmemory->RealData));
//				printf("\n����ʧ�ܣ�");
//			}
		SdPrintf(YNPrint,PreFix,"end============================================");

		if (Jproginfo->RealData.ReadFlg == 9)
			Jproginfo->dataTransgw.f9.ANSWER_endflag = 5;//ת����������
		else
			Jproginfo->dataTransgw.f9.ANSWER_endflag = 1;//ת�����ճ�ʱ
		CreateGWHead(0x88,0);//ȷ��/���ϣ�����
		SendBuff[SendIndex++]=0x10; //afn����ѯ�����Ļظ����ģ�afn=0x10��
		SendBuff[SendIndex++]=0x60|(Fseq&0x0f); //Fseq: ��jPub.h���涨��
		SendBuff[SendIndex++]=0x00; //da1
		SendBuff[SendIndex++]=0x00; //da2
		SendBuff[SendIndex++]=0x01; //dt1
		SendBuff[SendIndex++]=0x01; //dt2
		SendBuff[SendIndex++]=Jproginfo->dataTransgw.f9.ASK_Port;//�˿ڵ�ַ
		for(i=0;i<6;i++)//ת��Ŀ���ַ
			SendBuff[SendIndex++]=Jproginfo->dataTransgw.f9.ANSWER_adress[i];
		if(meterfind==0)
			Jproginfo->dataTransgw.f9.ANSWER_endflag = 0;
		SendBuff[SendIndex++]=Jproginfo->dataTransgw.f9.ANSWER_endflag;//ת�������־
		if(meterfind==1)
			SendBuff[SendIndex++] = 4+Jproginfo->dataTransgw.f9.len;//ת��ֱ�ӳ��������������ֽ���k+2
		else
			SendBuff[SendIndex++] = 4;
		if (Jproginfo->dataTransgw.f9.ASK_DataType==0)
		{
			SendBuff[SendIndex++] = Jproginfo->dataTransgw.f9.DataFlag[0];
			SendBuff[SendIndex++] = Jproginfo->dataTransgw.f9.DataFlag[1];
			SendBuff[SendIndex++] = 0;
			SendBuff[SendIndex++] = 0;
		}
		if (Jproginfo->dataTransgw.f9.ASK_DataType==1)
		{
			SendBuff[SendIndex++] = Jproginfo->dataTransgw.f9.DataFlag[0];
			SendBuff[SendIndex++] = Jproginfo->dataTransgw.f9.DataFlag[1];
			SendBuff[SendIndex++] = Jproginfo->dataTransgw.f9.DataFlag[2];
			SendBuff[SendIndex++] = Jproginfo->dataTransgw.f9.DataFlag[3];
		}
		//memcpy(&tempRealTimeData.ReadFlg,&Jproginfo->RealData.ReadFlg,sizeof(Jmemory->RealData));//���ڴ��е����ݿ�������
		if(meterfind==1)
		{
			for(i=0; i<Jproginfo->dataTransgw.f9.len;i++)
			{
				SdPrintf(YNPrint," ", "[%02x]",tempRealTimeData.flg97[0].datas[i]);
				if(tempRealTimeData.flg97[0].datas[i]==OxXX &&tempRealTimeData.flg97[0].datas[i+1]==OxXX)
					break;
				SendBuff[SendIndex++]=tempRealTimeData.flg97[0].datas[i];
			}
		}
		if (i>100)
		{
			SendNakTrans(0,0,0x10,Jproginfo->dataTransgw.f1.ASK_Port);
			Jproginfo->RealData.ReadFlg = 0;
			return;
		}
		EC();
		TP();
		FrameTailCreate_Send(0);//��֪��������������������壬1 ��¼
		Jproginfo->RealData.ReadFlg = 0;
		return;
	}
//----------------------------------------------------------------------------------------------------------------------

		if(DT[10]==1)//F10
		{
			Jproginfo->dataTransgw.f10.ASK_Port=TempBuf[18];//Jmemory �ڴ湲��������ָ��
			Jproginfo->dataTransgw.f10.ASK_Leval=TempBuf[19];

			for(i=0;i<Jproginfo->dataTransgw.f10.ASK_Leval;i++)
			{
				for(k=0;k<6;k++)//ת���м̵�ַ
				{
					Jproginfo->dataTransgw.f10.ASK_Buf[i][k]=TempBuf[20+i*6+k];
				}
			}
			for(k=0;k<6;k++)//ת��Ŀ���ַ
			{
				Jproginfo->dataTransgw.f10.ANSWER_adress[k]=TempBuf[21+Jproginfo->dataTransgw.f10.ASK_Leval*6+k];//
			}
			Jproginfo->dataTransgw.f10.ANSWER_zhabiaozhi=TempBuf[22+Jproginfo->dataTransgw.f10.ASK_Leval*7];//ң����բ/������բ��־
			Jproginfo->dataTransgw.f10.len=TempBuf[23+Jproginfo->dataTransgw.f10.ASK_Leval*7];//ת��ֱ��ң�����������ֽ���

			for(k=0;k<Jproginfo->dataTransgw.f10.len;k++)//ת��ֱ��ң����������
			{
				Jproginfo->dataTransgw.f10.ANSWER_Buf[k]=TempBuf[24+Jproginfo->dataTransgw.f10.ASK_Leval*7+k];
			}
			Jproginfo->dataTransgw.f10.ASK_Stat=1;

			k=0; //ת��
			delay(Jproginfo->dataTransgw.f1.WaitTime*10);
			for(k=0;k<20;k++)//���ѭ��20��
			{
				CreateGWHead(0x88,0);//ȷ��/���ϣ�����
				SendBuff[SendIndex++]=0x10; //afn����ѯ�����Ļظ����ģ�afn=0x10��
				SendBuff[SendIndex++]=0x60|(Fseq&0x0f); //Fseq: ��jPub.h���涨��
				SendBuff[SendIndex++]=0x00; //da1
				SendBuff[SendIndex++]=0x00; //da2
				SendBuff[SendIndex++]=0x02; //dt1
				SendBuff[SendIndex++]=0x01; //dt2
				SendBuff[SendIndex++]=Jproginfo->dataTransgw.f10.ASK_Port;//�˿ڵ�ַ
				for(i=0;i<6;i++)//ת��Ŀ���ַ
				{
					SendBuff[SendIndex++]=Jproginfo->dataTransgw.f10.ANSWER_adress[i];
				}
				SendBuff[SendIndex++]=Jproginfo->dataTransgw.f10.ANSWER_endflag;//ת�������־
				SendBuff[SendIndex++]=Jproginfo->dataTransgw.f10.ANSWER_zhabiaozhi;//ң����բ/������բ��־

				EC();
				TP();
				FrameTailCreate_Send(0);//��֪��������������������壬1 ��¼
				return;
				delay(Jproginfo->dataTransgw.f1.DelayTime*10);			//?????��Ҫ�ŵ�returnǰ��ô��
			}
		}//end

		if(DT[11]==1)//F11
		{
			Jproginfo->dataTransgw.f11.ASK_Port=TempBuf[18];//Jmemory �ڴ湲��������ָ��
			Jproginfo->dataTransgw.f11.ASK_Leval=TempBuf[19];

			for(i=0;i<Jproginfo->dataTransgw.f11.ASK_Leval;i++)
			{
				for(k=0;k<6;k++)//ת���м̵�ַ
				{
					Jproginfo->dataTransgw.f11.ASK_Buf[i][k]=TempBuf[20+i*6+k];
				}
			}
			for(k=0;k<6;k++)//ת��Ŀ���ַ
			{
				Jproginfo->dataTransgw.f11.ANSWER_adress[k]=TempBuf[21+Jproginfo->dataTransgw.f11.ASK_Leval*6+k];//
			}
			Jproginfo->dataTransgw.f11.ANSWER_songdian=TempBuf[22+Jproginfo->dataTransgw.f11.ASK_Leval*7];//ң���͵��־
			Jproginfo->dataTransgw.f11.len=TempBuf[23+Jproginfo->dataTransgw.f11.ASK_Leval*7];//ת��ֱ��ң�����������ֽ���
			for(k=0;k<Jproginfo->dataTransgw.f11.len;k++)//ת��ֱ��ң����������
			{
				Jproginfo->dataTransgw.f11.ANSWER_Buf[k]=TempBuf[24+Jproginfo->dataTransgw.f11.ASK_Leval*7+k];
			}
			Jproginfo->dataTransgw.f11.ASK_Stat=1;

			k=0; //ת��
			delay(Jproginfo->dataTransgw.f1.WaitTime*10);

			for(k=0;k<20;k++)//���ѭ��20��
			{
				CreateGWHead(0x88,0);//ȷ��/���ϣ�����
				SendBuff[SendIndex++]=0x10; //afn����ѯ�����Ļظ����ģ�afn=0x10��
				SendBuff[SendIndex++]=0x60|(Fseq&0x0f); //Fseq: ��jPub.h���涨��
				SendBuff[SendIndex++]=0x00; //da1
				SendBuff[SendIndex++]=0x00; //da2
				SendBuff[SendIndex++]=0x02; //dt1
				SendBuff[SendIndex++]=0x01; //dt2
				SendBuff[SendIndex++]=Jproginfo->dataTransgw.f11.ASK_Port;//�˿ڵ�ַ
				for(i=0;i<6;i++)//ת��Ŀ���ַ
				{
					SendBuff[SendIndex++]=Jproginfo->dataTransgw.f11.ANSWER_adress[i];
				}
				SendBuff[SendIndex++]=Jproginfo->dataTransgw.f11.ANSWER_endflag;//ת�������־
				SendBuff[SendIndex++]=Jproginfo->dataTransgw.f11.ANSWER_songdian;//ң���͵��־

				EC();
				TP();
				FrameTailCreate_Send(0);//��֪��������������������壬1 ��¼

				delay(Jproginfo->dataTransgw.f1.DelayTime*10);return;
			}
		}

		SendNAK(TmpF,TmpP,4);//afn=4,��Ӧ���ܣ�������վ��IP��ַ�Ͷ˿ں�
		return;
	}

INT16U CallSetting(INT8U *s) {
	INT16U i, j, k;
	INT16U Result;
	Result = 0;
	memset(DA, 0, PointMax);
	memset(DT, 0, 255);
	GetDa(s[0], s[1]);
	GetDt(s[2], s[3]);
	for (i = 0; i < PointMax; i++) {
		if (DA[i] == 1) {
			for (j = 0; j < 249; j++) {
				if (DT[j] == 1) {
					//ClearThreadTimes(ProjectNo);
					TmpF = j;
					TmpP = i;
					SdPrintf(YNPrint,PreFix,"F=%d  P=%d ",TmpF,TmpP);
					for (k = 0; k < ITEMGWCOUNT; k++) {
						if (DataGWList[k].Fn == TmpF && DataGWList[k].iDataType
								== J_QUERYPARA) {
							//ClearThreadTimes(ProjectNo);
							Result = Result + DataGWList[k].setdata(0, j, i, s
									+ 4);
							break;
						}
					}
				}
			}
		}
	}
	return Result;//��������ݵ�Ԫ������ֵΪ���ݵ�Ԫ��ʶ�ĳ���4����������ݵ�Ԫ������ֵΪ���ݵ�Ԫ�����ʶ���ܳ���
}

void CallTermimalSetting()//���������ն����ü���Ϣ�����б��ģ�һ�����б��Ķ�Ӧһ�����б���
{
	INT16U TmpSendlen;
	CreateGWHead(0x88, 0);
	SendBuff[SendIndex++] = 0x09;//afn
	SendBuff[SendIndex++] = 0x60 | (Fseq & 0x0f);//seq
	Resolve_Pos = 14;
	TmpSendlen = SendIndex;
	while (Resolve_Pos < (DataLength + 6))//while(Resolve_Pos<(DataLength+12-6))
	{
		Resolve_Pos = Resolve_Pos + CallSetting(&TempBuf[Resolve_Pos]);
	}
	if (TmpSendlen == SendIndex) {
		goto nodata;
	}
	TP();
	FrameTailCreate_Send(0);
	return;
	nodata: SendNAK(TmpF, TmpP, 0x09);
	return;
}

void CallTaskParaCalc() {
	INT16U i, j, f;//Pro130SetMax
	INT16U Tmp_Resolve_Pos;
	Tmp_Resolve_Pos = 14;
	AllReportHead = 0;
	AllReportTail = 0;
	while (Tmp_Resolve_Pos < (DataLength + 6)) {
		GetDa(TempBuf[Tmp_Resolve_Pos], TempBuf[Tmp_Resolve_Pos + 1]);
		GetDt(TempBuf[Tmp_Resolve_Pos + 2], TempBuf[Tmp_Resolve_Pos + 3]);
		//		DebugOut(DebugComm,"W=%d S=%d ",Resolve_Pos,(RecDataLen+6));
		f = 0;
		for (i = 0; i < PointMax; i++) {
			if (DA[i] == 1) {
				for (j = 0; j < 255; j++) {
					if (DT[j] == 1) {
						f = j;
						AllReportHead++;
					}
				}
			}
		}
		Tmp_Resolve_Pos += 4;
		if (f == 2)//2������
			Tmp_Resolve_Pos += 5;
	}
}

void CallTaskPara() {
	INT16U i, j, k, l, f, res, m;//ProGWSetMax
	INT8U t[20];
	CallTaskParaCalc();
	Resolve_Pos = 14;
	res = 0;
	memset(t, 0, 20);
	AutoFlg = 0;
	while (Resolve_Pos < (DataLength + 6)) {
		GetDa(TempBuf[Resolve_Pos], TempBuf[Resolve_Pos + 1]);
		GetDt(TempBuf[Resolve_Pos + 2], TempBuf[Resolve_Pos + 3]);
		f = 0;
		for (i = 0; i < PointMax; i++) {
			if (DA[i] == 1) {
				for (j = 0; j < 255; j++) {
					if (DT[j] == 1) {
						TmpF = j;
						TmpP = i;
						f = j;
					}
				}
			}
		}
		Resolve_Pos += 4;
		if (f == 1) {
			if ((TmpP == 0) || (TmpP > Task1_Max))
				continue;
			if (JSetPara_AFN04_3761_2009->group9.f67[TmpP-1].IsRun != 0x55)
				continue;
			for (j = 0; j < JSetPara_AFN04_3761_2009->group9.f65[TmpP - 1].Count; j++) {
				GetDa(JSetPara_AFN04_3761_2009->group9.f65[TmpP - 1].Flag[j][0],
						JSetPara_AFN04_3761_2009->group9.f65[TmpP - 1].Flag[j][1]);
				GetDt(JSetPara_AFN04_3761_2009->group9.f65[TmpP - 1].Flag[j][2],
						JSetPara_AFN04_3761_2009->group9.f65[TmpP - 1].Flag[j][3]);
				for (k = 0; k < PointMax; k++) {
					if (DA[k] == 1) {
						for (l = 0; l < 255; l++) {
							if (DT[l] == 1) {
								for (m = 0; m < ITEMGWCOUNT; m++) {
									if (DataGWList[m].Fn == l
											&& DataGWList[m].iDataType
													== J_1LEICURR) {
										//ClearThreadTimes(ProjectNo);
										LDType = 0;
										SdPrintf(YNPrint,PreFix,"tmpf=%d,tmp=%d\n\r",l,k);
										//ClearThreadTimes(ProjectNo);
										res = 1;
										AutoFlg = 0;
										PrmFlg = 0;
										DataGWList[m].setdata(0, l, k, &t[0]);
									}
								}
							}
						}
					}
				}
			}
		}
		if (f == 2)//2������
		{
			memset(t, 0, 20);
			memcpy(&t[0], &TempBuf[Resolve_Pos], 5);
			t[5] = 3;
			t[6] = 1;
			Resolve_Pos += 5;
			if ((TmpP == 0) || (TmpP > Task2_Max))
				continue;
			if (JSetPara_AFN04_3761_2009->group9.f68[TmpP - 1].IsRun != 0x55)
				continue;
			for (j = 0; j < JSetPara_AFN04_3761_2009->group9.f66[TmpP - 1].Count; j++) {
				GetDa(JSetPara_AFN04_3761_2009->group9.f66[TmpP - 1].Flag[j][0],
						JSetPara_AFN04_3761_2009->group9.f66[TmpP - 1].Flag[j][1]);
				GetDt(JSetPara_AFN04_3761_2009->group9.f66[TmpP - 1].Flag[j][2],
						JSetPara_AFN04_3761_2009->group9.f66[TmpP - 1].Flag[j][3]);
				for (k = 0; k < PointMax; k++) {
					if (DA[k] == 1) {
						for (l = 0; l < 255; l++) {
							if (DT[l] == 1) {
								for (m = 0; m < ITEMGWCOUNT; m++) {
									if (DataGWList[m].Fn == l
											&& DataGWList[m].iDataType
													== J_2LEIDATE) {
										LDType = 0;
										SdPrintf(YNPrint,PreFix,"tmpf=%d,tmp=%d\n\r",l,k);
										res = 1;
//										ClearThreadTimes(ProjectNo);
										AutoFlg = 0;
										PrmFlg = 0;
										DataGWList[m].setdata(0, l, k, &t[0]);
									}
								}
							}
						}
					}
				}
			}
		}
	}
	if (res == 0) {
		SendNAK(TmpF, TmpP, 0x0a);
		return;
	}
	return;
}

void ControlHead() {
	CreateGWHead(0x88, 0);
	SendBuff[SendIndex++] = 0;//afn
	SendBuff[SendIndex++] = 0x60 | (Fseq & 0x0f);//seq
	SendBuff[SendIndex++] = 0;//TempBuf[14];//da1e
	SendBuff[SendIndex++] = 0;//TempBuf[15];//da2
	SendBuff[SendIndex++] = 4;//TempBuf[16];//dt1
	SendBuff[SendIndex++] = 0;//TempBuf[17];//dt2
	SendBuff[SendIndex++] = 0x05;//
}

void ControlTail() {
	EC();
	TP();
	//FrameTailCreate_Send(0);
	SendALLACK(0);
}

void DoControl(INT8U F, INT8U P) {
	int j = 0,i=0,tmp=0;
	int port=0;
//	char TempFile[60];
	GetDa(TempBuf[14], TempBuf[15]);
//	ClearThreadTimes(ProjectNo);
	switch (F) {
	case 27:
		ControlHead();
		Jcfginfo->jzqpara.CommStat = (Jcfginfo->jzqpara.CommStat | 0x04) & 0x07;
		SdPrintf(YNPrint,PreFix,"CtrolSet---27--%x",Jcfginfo->jzqpara.CommStat);
		memcpy(&SendBuff[SendIndex], &TempBuf[14], 4);
		SendIndex = SendIndex + 4;
		SendBuff[SendIndex++] = 0;
//		Jproginfo->Para.ChangedJiZhongQiInfo = 2;
		Jproginfo->FileSaveFlag.jzqflag = 1;
		ControlTail();
		break;
	case 29:
		ControlHead();
		Jcfginfo->jzqpara.CommStat = (Jcfginfo->jzqpara.CommStat | 0x01) & 0x0D;
		SdPrintf(YNPrint,PreFix,"CtrolSet---29--%x",Jcfginfo->jzqpara.CommStat);
		memcpy(&SendBuff[SendIndex], &TempBuf[14], 4);
		SendIndex = SendIndex + 4;
		SendBuff[SendIndex++] = 0;
//		Jproginfo->Para.ChangedJiZhongQiInfo = 2;
		Jproginfo->FileSaveFlag.jzqflag = 1;
		ControlTail();
		break;
	case 31:
		SdPrintf(YNPrint,PreFix,"CtrolSet---31");
		TS ts1, nowTs;
		char command[50];
		INT8U mon = TempBuf[22] & 0x1F;
		ts1.Year = BCD_INT32(&TempBuf[23], 1) + 2000;
		ts1.Month = BCD_INT32(&mon, 1);
		ts1.Day = BCD_INT32(&TempBuf[21], 1);
		ts1.Hour = BCD_INT32(&TempBuf[20], 1);
		ts1.Minute = BCD_INT32(&TempBuf[19], 1);
		ts1.Sec = BCD_INT32(&TempBuf[18], 1);
		ts1.Week = 0;
		if (!Judgetstime(ts1)) {
			SendALLNAK(0);
			break;
		}
		ControlHead();
			SdPrintf(YNPrint,PreFix,"set time=%04d:%02d:%02d:%02d:%02d:%02d",ts1.Year,ts1.Month,
				ts1.Day,ts1.Hour,ts1.Minute,ts1.Sec);
		#ifdef __linux__
			sprintf(command, "date %04d.%02d.%02d-%02d:%02d:%02d", ts1.Year, ts1.Month,
				ts1.Day, ts1.Hour, ts1.Minute, ts1.Sec);
		#else
			sprintf(command, "date %d %d %d %d %d %d", ts1.Day, ts1.Month,
				ts1.Year, ts1.Hour, ts1.Minute, ts1.Sec);
		#endif

		SdPrintf(YNPrint,PreFix,"command=%s",command);
//		syscmd(command);
		system(command);
		delay(100);
//		syscmd(_SETCLK_);
		system(_SETCLK_);
		TSGet(&nowTs);
		SdPrintf(YNPrint,PreFix,"sd_Set_803F aft=%d:%d:%d:%d:%d:%d",nowTs.Year,nowTs.Month,
				nowTs.Day,nowTs.Hour,nowTs.Minute,nowTs.Sec);

		memcpy(&SendBuff[SendIndex], &TempBuf[14], 4);
		SendIndex = SendIndex + 4;
		SendBuff[SendIndex++] = 0;
//		Jproginfo->Para.ChangedJiZhongQiInfo = 2;
		Jproginfo->FileSaveFlag.jzqflag = 1;
		ControlTail();
		break;
	case 35:
		ControlHead();
		Jcfginfo->jzqpara.CommStat = (Jcfginfo->jzqpara.CommStat | 0x08) & 0x0B;
		SdPrintf(YNPrint,PreFix,"CtrolSet---35--%x",Jcfginfo->jzqpara.CommStat);
		memcpy(&SendBuff[SendIndex], &TempBuf[14], 4);
		SendIndex = SendIndex + 4;
		SendBuff[SendIndex++] = 0;
//		Jproginfo->Para.ChangedJiZhongQiInfo = 2;
		Jproginfo->FileSaveFlag.jzqflag = 1;
		ControlTail();
		break;
	case 37:
		//ControlHead();
		CreateGWHead(0x88, 0);
		SendBuff[SendIndex++] = 0;//afn
		SendBuff[SendIndex++] = 0x60 | (Fseq & 0x0f);//seq
		SendBuff[SendIndex++] = 0;//TempBuf[14];//da1e
		SendBuff[SendIndex++] = 0;//TempBuf[15];//da2
		SendBuff[SendIndex++] = 1;//TempBuf[16];//dt1
		SendBuff[SendIndex++] = 0;//TempBuf[17];//dt2
		//SendBuff[SendIndex++] = 0x05;//
		Jcfginfo->jzqpara.CommStat = (Jcfginfo->jzqpara.CommStat | 0x02) & 0x0E;
		SdPrintf(YNPrint,PreFix,"CtrolSet---37--%x",Jcfginfo->jzqpara.CommStat);
//		memcpy(&SendBuff[SendIndex], &TempBuf[14], 4);
//		SendIndex = SendIndex + 4;
//		SendBuff[SendIndex++] = 0;
//		Jproginfo->Para.ChangedJiZhongQiInfo = 2;
		Jproginfo->FileSaveFlag.jzqflag = 1;
		ControlTail();
		break;
	case 49:	//����ָ��ͨ�Ŷ˿���ͣ����
		CreateGWHead(0x88, 0);
		SendBuff[SendIndex++] = 0;//afn
		SendBuff[SendIndex++] = 0x60 | (Fseq & 0x0f);//seq
		SendBuff[SendIndex++] = 0;//TempBuf[14];//da1e
		SendBuff[SendIndex++] = 0;//TempBuf[15];//da2
		SendBuff[SendIndex++] = 1;//TempBuf[16];//dt1
		SendBuff[SendIndex++] = 0;//TempBuf[17];//dt2
		port = TempBuf[18];				//��ȡ�·��˿ں�
//		Jproginfo->data485[port-1].ChaobiaoSta = 1;			//��ͣ
		Jdatafileinfo->data485[port-1].ChaobiaoSta = 1;
		if(port == 31)
			Jdatafileinfo->data485[CarrWavePort-1].ChaobiaoSta = 1;			//��ͣ
		ControlTail();
		break;
	case 50:	//����ָ��ͨ�Ŷ˿ڻָ�����
	case 51:	//����ָ��ͨ�Ŷ˿����³���
		CreateGWHead(0x88, 0);
		SendBuff[SendIndex++] = 0;//afn
		SendBuff[SendIndex++] = 0x60 | (Fseq & 0x0f);//seq
		SendBuff[SendIndex++] = 0;//TempBuf[14];//da1e
		SendBuff[SendIndex++] = 0;//TempBuf[15];//da2
		SendBuff[SendIndex++] = 1;//TempBuf[16];//dt1
		SendBuff[SendIndex++] = 0;//TempBuf[17];//dt2
		port = TempBuf[18];				//��ȡ�·��˿ں�
//		Jproginfo->data485[port-1].ChaobiaoSta = 2;			//�س�
		Jdatafileinfo->data485[port-1].ChaobiaoSta = 1;
		if(port == 31)
			Jdatafileinfo->data485[port-1].ChaobiaoSta = 1;
//			Jproginfo->data485[CarrWavePort-1].ChaobiaoSta = 2;			//��ͣ
		ControlTail();
		break;
	case 53:	//ɾ���ƶ�ͨ�Ŷ˿��µ�ȫ�����
		CreateGWHead(0x88, 0);
		SendBuff[SendIndex++] = 0;//afn
		SendBuff[SendIndex++] = 0x60 | (Fseq & 0x0f);//seq
		SendBuff[SendIndex++] = 0;//TempBuf[14];//da1e
		SendBuff[SendIndex++] = 0;//TempBuf[15];//da2
		SendBuff[SendIndex++] = 1;//TempBuf[16];//dt1
		SendBuff[SendIndex++] = 0;//TempBuf[17];//dt2

		port = TempBuf[18];			//��ȡ�·��˿ں�
		for (j = 0; j < PointMax; j++)//��������Ϣ
		{
			if(port==JSetPara_AFN04_3761_2009->group2.f10[j].port  && JSetPara_AFN04_3761_2009->group2.f10[j].Status==1)	//��ʼ��ָ���Ķ˿ں��²�����
			{
				//memset(Jmemory->Points.pt[j].f10.Index,j,2);
				//memset(Jmemory->Points.pt[j].f10.PointIndex,0x00,2);
				JSetPara_AFN04_3761_2009->group2.f10[j].ConnectType=30;					//ͨ��Э������ 1 97 30 2007
				memset(JSetPara_AFN04_3761_2009->group2.f10[j].Address,0x00,6);			//ͨ�ŵ�ַ
				memset(JSetPara_AFN04_3761_2009->group2.f10[j].PassWord,0x00,6);			//ͨ������
				JSetPara_AFN04_3761_2009->group2.f10[j].FeiLvCnt=4;						//���ܷ��ʸ���
				JSetPara_AFN04_3761_2009->group2.f10[j].DecimalDigits=1;					//�й�����ʾֵ����λ��С��λ����
				memset(JSetPara_AFN04_3761_2009->group2.f10[j].CaijiqiAddress,0x00,6);	//�����ɼ���ͨ�ŵ�ַ
				JSetPara_AFN04_3761_2009->group2.f10[j].UserType=0;						//�û�����ż��û�С���
				JSetPara_AFN04_3761_2009->group2.f10[j].baudrate=0x08;					//SD������
				if(j == 0)
					JSetPara_AFN04_3761_2009->group2.f10[j].port=1;						//����  yangdong
				else
					JSetPara_AFN04_3761_2009->group2.f10[j].port=1+PortBegNum;					//SD�˿ں�
				JSetPara_AFN04_3761_2009->group2.f10[j].jiao_yan_wei=0x01;			//SDУ��λ
				JSetPara_AFN04_3761_2009->group2.f10[j].shu_ju_wei=0x08;			//SD����λ
				JSetPara_AFN04_3761_2009->group2.f10[j].ting_zhi_wei=0x01;			//SDֹͣλ
				for(i=0;i<64;i++)
					JSetPara_AFN04_3761_2009->group2.f10[j].AlarmFlg[i]=0x00;
				JSetPara_AFN04_3761_2009->group2.f10[j].Status=0;				//SD״̬

				JSetPara_AFN04_3761_2009->group2.f10[j].CjqNo=j/64+1;				//SD�ɼ���
				JSetPara_AFN04_3761_2009->group2.f10[j].MeterNo=j%64;			//SD�������
				JSetPara_AFN04_3761_2009->group2.f10[j].FirRead=0;
				JSetPara_AFN04_3761_2009->group2.f10[j].Type=9;
				tmp=1;
				JSetPara_AFN04_3761_2009->Point[j].f25.V_BeiLv[0]=1;
				JSetPara_AFN04_3761_2009->Point[j].f25.I_BeiLv[0]=1;
//				memset(Jmemory->Points.pt[j].ind.PointIndex,0x00,2);
//				Jmemory->Points.pt[j].ind.PointIndex[0]=(j+1)&0xff;
//				Jmemory->Points.pt[j].ind.PointIndex[1]=((j+1)>>8)&0xff;
				memset(JSetPara_AFN04_3761_2009->group2.f10[j].PointIndex,0x00,2);
				JSetPara_AFN04_3761_2009->group2.f10[j].PointIndex[0]=(j+1)&0xff;
				JSetPara_AFN04_3761_2009->group2.f10[j].PointIndex[1]=((j+1)>>8)&0xff;
				Jproginfo->FileSaveFlag.F10_ChangedSave[j-(j%SaveNum)] = 2;
				Jproginfo->FileSaveFlag.g4flag = 1;
//				memset(TempFile,0,60);
//				sprintf((char*)TempFile,"%s/Ammeter%04d.par",_PARADIR_,j/SaveNum+1);
//				fprintf(stderr,"TempFile=%s,j=%d\n\r",TempFile,j);
//				NormalSaveFile((char*)TempFile,(INT8U *)&Jmemory->Points.pt[j-(j%SaveNum)],
//						sizeof(Jmemory->Points.pt[j-(j%SaveNum)])*SaveNum);
//				NormalSaveFile((char*)TempFile,(INT8U *)&JSetPara_AFN04_3761_2009->Point[j-(j%SaveNum)],
//						sizeof(JSetPara_AFN04_3761_2009->Point[j-(j%SaveNum)])*SaveNum,Jproginfo);
			}
		}
//		if (ACSMPFLG==1)
//		{
//			Jmemory->Points.pt[0].f10.Status=1;
//			Jmemory->Points.pt[0].f10.ConnectType=2;
//			Jmemory->Points.pt[0].f25.Type=3;
//	//		memset(Jmemory->Points.pt[j].f10.Address,0x00,6);
//	//		Jmemory->Points.pt[j].f10.Address[0] = 0x01;//?????????????
//			memset(Jmemory->Points.pt[0].f10.Address,0x00,6);
//			Jmemory->Points.pt[0].f10.Address[0] = 0x01;
//		}

//		memset(TempFile,0,60);
//		sprintf((char*)TempFile,"%s/AmmeterN.par",_PARADIR_);
////		NormalSaveFile((char*)TempFile,(INT8U *)&Jmemory->Points,sizeof(Jmemory->Points));
//		NormalSaveFile((char*)TempFile,(INT8U *)&JSetPara_AFN04_3761_2009->Point,sizeof(JSetPara_AFN04_3761_2009->Point),Jproginfo);
////		Jmemory->Reset_Changed = 1;//9.28
		Jproginfo->stateflags.Reset_Changed = 1;
		ControlTail();
		break;
	case 63://����������ֹͣ��������ά��
		CreateGWHead(0x88, 0);
		SendBuff[SendIndex++] = 0;//afn
		SendBuff[SendIndex++] = 0x60 | (Fseq & 0x0f);//seq
		SendBuff[SendIndex++] = 0;//TempBuf[14];//da1e
		SendBuff[SendIndex++] = 0;//TempBuf[15];//da2
		SendBuff[SendIndex++] = 1;//TempBuf[16];//dt1
		SendBuff[SendIndex++] = 0;//TempBuf[17];//dt2
		JSetPara_AFN04_3761_2009->group11.f111.immdoit = TempBuf[18];//����������ֹͣ��־   0xAAֹͣ    0x55����
		if(JSetPara_AFN04_3761_2009->group11.f111.immdoit==0x55)
			Jproginfo->BeginSouBiao = 1;
//			Jmemory->BeginSouBiao = 1;
		else
			Jproginfo->BeginSouBiao = 0;
//			Jmemory->BeginSouBiao = 0;
		JSetPara_AFN04_3761_2009->group11.f111.Com = TempBuf[19];    //�˿ں�
//		Jproginfo->Para.ChangedJiZhongQiInfo = 2;
		Jproginfo->FileSaveFlag.jzqflag = 1;
		ControlTail();
		break;
	default:
		SendALLNAK(0);
		break;
	}
	return;
}

void ControlSet() {
	INT8U j;
	GetDa(TempBuf[14], TempBuf[15]);
	GetDt(TempBuf[16], TempBuf[17]);
	for (j = 0; j < 248; j++) {
		if (DT[j] == 1) {
			DoControl(j, 0);
		}
	}
}

void AskTwoLevelDataDingXin() {
	SdPrintf(YNPrint,PreFix,"%s","��վ���������������\n\r");
	AutoFlg = 0;
	switch (TempBuf[12])//Ӧ�ò㹦����AFN
	{
	case 0x00:
		SdPrintf(YNPrint,PreFix,"%s","��վ���� �ն���·���\n\r");
		IfLoginOK = 1;
		HeartBeatErr = 0;
		break;
	case J_SETPARA:
		SdPrintf(YNPrint,PreFix,"��վ���� �ն˲�������\n\r");
		SetPara();//�ն˲�������
		break;
	case J_CTRLCOM:
		SdPrintf(YNPrint,PreFix,"��վ���� �ն˿�������\n\r");
		ControlSet();//�ն˿�������
		break;
	case 06:
		SdPrintf(YNPrint,PreFix,"��վ���� �ն�������֤\n\r");
		Zdrenzheng(0);//�ն�������֤
		break;
	case 0x09:
		SdPrintf(YNPrint,PreFix,"��վ���� �����ն����ü���Ϣ\n\r");
		CallTermimalSetting();//�����ն����ü���Ϣ
		break;
	case 0x0a:
		SdPrintf(YNPrint,PreFix,"��վ���� �ٻ��ն˲�������\n\r");
		CallSetPara();
		break;
	case 0x0b:
		SdPrintf(YNPrint,PreFix,"��վ���� �ٻ��ն���������\n\r");
		CallTaskPara();
		break;
	case 0x0c:
		SdPrintf(YNPrint,PreFix,"��վ���� �ٻ��ն�1�����ݣ�ʵʱ���ݣ�\n\r");
		CallOnelevelData();
		break;
	case 0x0d:
		SdPrintf(YNPrint,PreFix,"��վ���� �ٻ��ն�2�����ݣ���ʷ���ݣ�\n\r");
		CallTwolevelData();
		break;
	case 0x0e:
		SdPrintf(YNPrint,PreFix,"��վ���� �ٻ��ն�3�����ݣ��¼����ݣ�\n\r");
		CallThreelevelData();
		break;
	case 0x10:
		SdPrintf(YNPrint,PreFix,"��վ���� �ն�����ת������ȱ����ݣ�\n\r");
		DataTrans();
		break;
	default:
		SdPrintf(YNPrint,PreFix,"%s��afn=%d","��վ���� δ����ȫ������\n\r",TempBuf[12]);
		SendALLNAK(0);
		break;
	}

}

INT16S AskOneLevelData()
{
	INT16S ret = 0;
	INT8U MacOk = 0;
	int macindex=0;
	INT8U buf[512];
	INT16U TmpCrc,tmpp;//tempp�����е�У�����룬tempCrc�������б����У������
//	ClearThreadTimes(ProjectNo);
	SdPrintf(YNPrint,PreFix,"��Ϣ��֤����:%d",JSetPara_AFN04_3761_2009->group1.f5.XiaoXi_Renzheng_FangAN);
	if(JSetPara_AFN04_3761_2009->group1.f5.XiaoXi_Renzheng_FangAN==1)//��Ϣ��֤��ʽ
	 {
		 TmpCrc=JSetPara_AFN04_3761_2009->group1.f5.CanShu[1];
		 TmpCrc=(TmpCrc<<8)+JSetPara_AFN04_3761_2009->group1.f5.CanShu[0];
		 SdPrintf(YNPrint,PreFix,"%s %x","��Ҫ��������У�飬������ 1 ��Կ",TmpCrc);
		 TmpCrc=CalcCRC(&TempBuf[6],12,TmpCrc);
		 SdPrintf(YNPrint,PreFix,"%s %x len=%d ","�������ֵ",TmpCrc,DataLength);
		 SdPrintf(YNPrint,PreFix,"%s %x %x ","���뷢��ֵ",TempBuf[DataLength+4],TempBuf[DataLength+5]);
		 tmpp=TempBuf[DataLength+4];
		 tmpp=(tmpp<<8)+TempBuf[DataLength+5];
		 if(tmpp!=TmpCrc)
		 {
			 SdPrintf(YNPrint,PreFix,"����У��ʧ�ܣ���������ʧ���¼�");
			 //CreateErr20(TmpCrc);
			 SendALLNAK(0);//���ͷ���֡
			 ret = J_ALLNAK;
		 }
	 }
	memset(buf, 0, 512);
	SdPrintf(YNPrint,PreFix,"AFN=%02x",TempBuf[12]);
	switch (TempBuf[12])//AFN
	{
	case J_SETPARA:
		SdPrintf(YNPrint,PreFix,"��վ���� �ն˲�������\n\r");
		SdPrintf(YNPrint,PreFix,"��֤���� %d NeedTP=%d DataLength=%d  groupNo=%d\n",JSetPara_AFN04_3761_2009->group1.f5.XiaoXi_Renzheng_FangAN,NeedTp,DataLength,groupNo);
		if(JSetPara_AFN04_3761_2009->group1.f5.XiaoXi_Renzheng_FangAN==0xFF)//ר��Ӳ����֤����
		{
//			if (NeedTp == 0)//Tp��Ч //cuo
//			{
//				macindex = DataLength + 6 - 16;
//				MacOk = CheckMac(&TempBuf[12],DataLength-22,0x04,groupNo,&TempBuf[macindex]);
//			}
//			else
//			{
//				macindex = DataLength + 12 - 6 - 16;
//				memcpy(&buf[0], &TempBuf[12], DataLength-22);
//				memcpy(&buf[DataLength-22], &TempBuf[DataLength+12-6], 6);
//				MacOk = CheckMac(&buf[0],DataLength-22+6,0x04,groupNo,&TempBuf[macindex]);
//			}
			macindex = DataLength + 6 - 16;
			MacOk = CheckMac(&TempBuf[12],DataLength-22,0x04,groupNo,&TempBuf[macindex],GuangBoflag);
			if (MacOk ==1)
				SetPara();
		}else
			SetPara();//�ն˲�������
		ret = J_SETPARA;
		break;
	case J_CTRLCOM:
		SdPrintf(YNPrint,PreFix,"%s","��վ���� �ն˿�������\n\r");
		SdPrintf(YNPrint,PreFix," ��֤���� %d NeedTP=%d DataLength=%d groupNo=%d\n",JSetPara_AFN04_3761_2009->group1.f5.XiaoXi_Renzheng_FangAN,NeedTp,DataLength,groupNo);
		if(JSetPara_AFN04_3761_2009->group1.f5.XiaoXi_Renzheng_FangAN==0xFF)//ר��Ӳ����֤����
		{
			//if (NeedTp == 0)//Tp��Ч //cuo
				macindex = DataLength + 6 - 16;
			//else
			//	macindex = DataLength + 6 - 22;
			MacOk = CheckMac(&TempBuf[12],DataLength-22,0x05,groupNo,&TempBuf[macindex],GuangBoflag);//RecDataLen + 6 -16
			if (MacOk ==1)
				ControlSet();
		}else
			ControlSet();//�ն˿�������
		ret = J_CTRLCOM;
		break;
	case J_VERIFY:
		SdPrintf(YNPrint,PreFix,"��վ���� �ն�������֤\n\r");
		Zdrenzheng(0);//�ն�������֤
		ret = J_VERIFY;
		break;
	default:
//		SdPrintf("%safn=%d","��վ���� δ����ȫ������\n\r",TempBuf[12]);
//		SendALLNAK(0);
		ret = J_ALLNAK;
		break;
	}
	return ret;
}
INT16S AskTwoLevelData() {
	INT16S ret = TempBuf[12];
	SdPrintf(YNPrint,PreFix,"��վ����2����������");
	AutoFlg = 0;
	switch (TempBuf[12])//Ӧ�ò㹦����AFN
	{
	case 0x00:
		SdPrintf(YNPrint,PreFix,"��վ���� �ն���·���");
		IfLoginOK = 1;
		HeartBeatErr = 0;
		break;
	case 06:
		SdPrintf(YNPrint,PreFix,"��վ���� �ն�������֤");
		Zdrenzheng(0);//�ն�������֤
		break;
	case 0x09:
		SdPrintf(YNPrint,PreFix,"��վ���� �����ն����ü���Ϣ");
		CallTermimalSetting();//�����ն����ü���Ϣ
		break;
	case 0x0a:
		SdPrintf(YNPrint,PreFix,"��վ���� �ٻ��ն˲�������");
		CallSetPara();
		break;
	case 0x0b:
		SdPrintf(YNPrint,PreFix,"��վ���� �ٻ��ն���������");
		CallTaskPara();
		break;
	case 0x0c:
		SdPrintf(YNPrint,PreFix,"��վ���� �ٻ��ն�1�����ݣ�ʵʱ���ݣ�");
		CallOnelevelData();
		break;
	case 0x0d:
		SdPrintf(YNPrint,PreFix,"��վ���� �ٻ��ն�2�����ݣ���ʷ���ݣ�");
		CallTwolevelData();
		break;
	case 0x0e:
		SdPrintf(YNPrint,PreFix,"��վ���� �ٻ��ն�3�����ݣ��¼����ݣ�");
		CallThreelevelData();
		break;
	case 0x10:
		SdPrintf(YNPrint,PreFix,"��վ���� �ն�����ת������ȱ����ݣ�");
		DataTrans();
		break;
	case 0x1D:
//		if(zone_so == SHANGHAI)
		{
			SdPrintf(YNPrint,PreFix,"��վ�����ٻ��ն�2�����ݣ��Ϻ���չ��Լ��");
			CallTwolevelData();
		}
		break;
	default:
		SdPrintf(YNPrint,PreFix,"%s��afn=%d","��վ���� δ����ȫ������\n\r",TempBuf[12]);
		SendALLNAK(0);
		break;
	}
	return ret;
}
//void SaveJzqPara()
//{
//	INT8U TempBuf[60];
//	memset(TempBuf,0,60);
//	sprintf((char*)TempBuf,"%s/JzhqPara.par",_PARADIR_);
//	NormalSaveFile((char*)TempBuf,(INT8U *)&Jmemory->jzq,sizeof(Jmemory->jzq));
//	delay(50);
//}
////�������Ĳ���
//void SaveMeterPara(int flg){//9.24wan
//	int i;
//	memset(TempBuf,0,60);
//	sprintf((char*)TempBuf,"%s/AmmeterOth.par",_PARADIR_);
//	NormalSaveFile((char*)TempBuf,(INT8U *)&Jmemory->Points.f34,sizeof(Jmemory->Points.f34)+sizeof(Jmemory->Points.f35));
//	memset(TempBuf,0,60);
//	sprintf((char*)TempBuf,"%s/AmmeterN.par",_PARADIR_);
//	NormalSaveFile((char*)TempBuf,(INT8U *)&Jmemory->Points,sizeof(Jmemory->Points));
//	if (flg>PointMax)
//	{
//		for(i=0;i<PointMax;i++)
//		{
////			if (Jmemory->Points.pt[i].f10.Status!=1)
////				continue;
//			if ((i%SaveNum)==0)
//			{
//				memset(TempBuf,0,60);
//				sprintf((char*)TempBuf,"%s/Ammeter%04d.par",_PARADIR_,(i/SaveNum)+1);
//				NormalSaveFile((char*)TempBuf,(INT8U *)&Jmemory->Points.pt[i-(i%SaveNum)],sizeof(Jmemory->Points.pt[i-(i%SaveNum)])*SaveNum);
//				delay(10);
//			}
//		}
//	}
//	else
//	{
//			memset(TempBuf,0,60);
//			sprintf((char*)TempBuf,"%s/Ammeter%04d.par",_PARADIR_,((flg-1)/SaveNum)+1);
//
//			NormalSaveFile((char*)TempBuf,(INT8U *)&Jmemory->Points.pt[flg-1-((flg-1)%SaveNum)],sizeof(Jmemory->Points.pt[flg-1-((flg-1)%SaveNum)])*SaveNum);
//			delay(10);
//	}
//	delay(50);
//}

INT16S ResetControl() {
	TS ts;
//376.1 3250++>>>
	GetDa(TempBuf[14], TempBuf[15]);
	GetDt(TempBuf[16], TempBuf[17]);
	CreateGWHead(0x80, 0);
	TSGet(&ts);
	SdPrintf(YNPrint,PreFix,"��λ ��DT[0]=%02x  DT[1]=%02x  DT[2]=%02x  DT[3]=%02x",DT[0],DT[1],DT[2],DT[3]);
	Jproginfo->Para.ChangedJiZhongQiInfo = 2;
	SendBuff[SendIndex++] = 0;
	SendBuff[SendIndex++] = 0x60 | (Fseq & 0x0f);
	SendBuff[SendIndex++] = 0;
	SendBuff[SendIndex++] = 0;
	SendBuff[SendIndex++] = 1;
	SendBuff[SendIndex++] = 0;
	EC();
	TP();
	FrameTailCreate_Send(0);
	if (DT[2] == 1)
			{
				SdPrintf(YNPrint,PreFix,"��վ�����������λ��λ");
				Jproginfo->stateflags.RebootFlag = F2_DATA_INIT;
			};
	if (DT[3] == 1)
	{
		SdPrintf(YNPrint,PreFix,"��վ�����������������λ��λ");
		Jproginfo->stateflags.RebootFlag = F3_PARA_INIT;
	};
	if (DT[4] == 1)
	{
		SdPrintf(YNPrint,PreFix,"��վ�����������������λ(ͨ�ų���)��λ");
		Jproginfo->stateflags.RebootFlag = F4_PARA_DATA_INIT;
	};
	if(DT[1] == 1){
		SdPrintf(YNPrint,PreFix,"��վ���Ӳ����λ��λ");
		Jproginfo->stateflags.RebootFlag = F1_NO_INIT;
	}
	return J_RESET;
}



/*
void InitDataTable() {
	INT32S i = 0;
	for (i = 0; i < ITEMGWCOUNT; i++) {
		DataGWList[i].setdata = SetPara_F0_Set;
		DataGWList[i].iDataType = 0;
		DataGWList[i].Fn = 0;
		DataGWList[i].Type = 0;
	}
	i = 0;
	//AFNΪ���ò���
	//Fn=F1ʱ�����ݻ�ȡ�����ú���
	DataGWList[i].setdata = SetPara_F1_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 1;
	DataGWList[i].Type = 1;
	i = i + 1;

	DataGWList[i].setdata = SetPara_F2_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 2;
	DataGWList[i].Type = 1;
	i = i + 1;

	DataGWList[i].setdata = SetPara_F3_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 3;
	DataGWList[i].Type = 1;
	i = i + 1;

	DataGWList[i].setdata = SetPara_F4_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 4;
	DataGWList[i].Type = 1;
	i = i + 1;

	DataGWList[i].setdata = SetPara_F5_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 5;
	DataGWList[i].Type = 1;
	i = i + 1;

	DataGWList[i].setdata = SetPara_F6_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 6;
	DataGWList[i].Type = 1;
	i = i + 1;

	DataGWList[i].setdata = SetPara_F7_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 7;
	DataGWList[i].Type = 1;
	i = i + 1;

	DataGWList[i].setdata = SetPara_F8_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 8;
	DataGWList[i].Type = 1;
	i = i + 1;

	DataGWList[i].setdata = SetPara_F9_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 9;
	DataGWList[i].Type = 1;
	i = i + 1;

	DataGWList[i].setdata = SetPara_F10_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 10;
	DataGWList[i].Type = 1;
	i = i + 1;

	DataGWList[i].setdata = SetPara_F11_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 11;
	DataGWList[i].Type = 1;
	i = i + 1;

	DataGWList[i].setdata = SetPara_F12_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 12;
	DataGWList[i].Type = 1;
	i = i + 1;

	DataGWList[i].setdata = SetPara_F13_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 13;
	DataGWList[i].Type = 1;
	i = i + 1;

	DataGWList[i].setdata = SetPara_F14_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 14;
	DataGWList[i].Type = 1;
	i = i + 1;

	DataGWList[i].setdata = SetPara_F15_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 15;
	DataGWList[i].Type = 1;
	i = i + 1;

	DataGWList[i].setdata = SetPara_F16_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 16;
	DataGWList[i].Type = 1;
	i = i + 1;

	DataGWList[i].setdata = SetPara_F21_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 21;
	DataGWList[i].Type = 1;
	i = i + 1;

	DataGWList[i].setdata = SetPara_F22_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 22;
	DataGWList[i].Type = 1;
	i = i + 1;

	DataGWList[i].setdata = SetPara_F23_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 23;
	DataGWList[i].Type = 1;
	i = i + 1;

	DataGWList[i].setdata = SetPara_F25_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 25;
	DataGWList[i].Type = 1;
	i = i + 1;

	DataGWList[i].setdata = SetPara_F26_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 26;
	DataGWList[i].Type = 1;
	i = i + 1;

	DataGWList[i].setdata = SetPara_F27_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 27;
	DataGWList[i].Type = 1;
	i = i + 1;

	DataGWList[i].setdata = SetPara_F28_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 28;
	DataGWList[i].Type = 1;
	i = i + 1;

	DataGWList[i].setdata = SetPara_F29_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 29;
	DataGWList[i].Type = 1;
	i = i + 1;

	DataGWList[i].setdata = SetPara_F30_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 30;
	DataGWList[i].Type = 1;
	i = i + 1;

	DataGWList[i].setdata = SetPara_F31_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 31;
	DataGWList[i].Type = 1;
	i = i + 1;

	DataGWList[i].setdata = SetPara_F33_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 33;
	DataGWList[i].Type = 1;
	i = i + 1;

	DataGWList[i].setdata = SetPara_F34_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 34;
	DataGWList[i].Type = 1;
	i = i + 1;

	DataGWList[i].setdata = SetPara_F35_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 35;
	DataGWList[i].Type = 1;
	i = i + 1;

	DataGWList[i].setdata = SetPara_F36_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 36;
	DataGWList[i].Type = 1;
	i = i + 1;

	DataGWList[i].setdata = SetPara_F37_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 37;
	DataGWList[i].Type = 1;
	i = i + 1;

	DataGWList[i].setdata = SetPara_F38_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 38;
	DataGWList[i].Type = 1;
	i = i + 1;

	DataGWList[i].setdata = SetPara_F39_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 39;
	DataGWList[i].Type = 1;
	i = i + 1;

	DataGWList[i].setdata = SetPara_F57_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 57;
	DataGWList[i].Type = 1;
	i = i + 1;

	DataGWList[i].setdata = SetPara_F59_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 59;
	DataGWList[i].Type = 1;
	i = i + 1;
//+++++++++++++++++++++++++++++++++++++++++++++++  //LQQ xiebo (((((((
	DataGWList[i].setdata = SetPara_F60_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 60;
	DataGWList[i].Type = 1;
	i = i + 1;
	//+++++++++++++++++++++++++++++++++++++++++++++++  //xiebo )))))))
	DataGWList[i].setdata = SetPara_F65_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 65;
	DataGWList[i].Type = 1;
	i = i + 1;

	DataGWList[i].setdata = SetPara_F66_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 66;
	DataGWList[i].Type = 1;
	i = i + 1;

	DataGWList[i].setdata = SetPara_F67_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 67;
	DataGWList[i].Type = 1;
	i = i + 1;

	DataGWList[i].setdata = SetPara_F68_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 68;
	DataGWList[i].Type = 1;
	i = i + 1;
	DataGWList[i].setdata = SetPara_F111_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 111;
	DataGWList[i].Type = 1;
	i = i + 1;

	DataGWList[i].setdata = SetPara_F112_Set;
	DataGWList[i].iDataType = J_SETPARA;
	DataGWList[i].Fn = 112;
	DataGWList[i].Type = 1;
	i = i + 1;

	DataGWList[i].setdata = CallSetting_F01_Set;
	DataGWList[i].iDataType = J_QUERYPARA;
	DataGWList[i].Fn = 1;
	DataGWList[i].Type = 2;
	i = i + 1;

	DataGWList[i].setdata = CallSetting_F02_Set;
	DataGWList[i].iDataType = J_QUERYPARA;
	DataGWList[i].Fn = 2;
	DataGWList[i].Type = 2;
	i = i + 1;

	DataGWList[i].setdata = CallSetting_F03_Set;
	DataGWList[i].iDataType = J_QUERYPARA;
	DataGWList[i].Fn = 3;
	DataGWList[i].Type = 2;
	i = i + 1;

	DataGWList[i].setdata = CallSetting_F04_Set;
	DataGWList[i].iDataType = J_QUERYPARA;
	DataGWList[i].Fn = 4;
	DataGWList[i].Type = 2;
	i = i + 1;

	DataGWList[i].setdata = CallSetting_F05_Set;
	DataGWList[i].iDataType = J_QUERYPARA;
	DataGWList[i].Fn = 5;
	DataGWList[i].Type = 2;
	i = i + 1;

	DataGWList[i].setdata = CallSetting_F06_Set;
	DataGWList[i].iDataType = J_QUERYPARA;
	DataGWList[i].Fn = 6;
	DataGWList[i].Type = 2;
	i = i + 1;

	DataGWList[i].setdata = CallSetting_F07_Set;
	DataGWList[i].iDataType = J_QUERYPARA;
	DataGWList[i].Fn = 7;
	DataGWList[i].Type = 2;
	i = i + 1;

	DataGWList[i].setdata = CallSetting_F08_Set;
	DataGWList[i].iDataType = J_QUERYPARA;
	DataGWList[i].Fn = 8;
	DataGWList[i].Type = 2;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F1_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 1;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F2_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 2;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F3_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 3;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F4_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 4;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F5_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 5;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F6_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 6;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F7_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 7;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F8_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 8;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F9_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 9;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F10_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 10;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F11_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 11;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F17_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 17;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F18_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 18;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F25_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 25;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F26_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 26;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F27_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 27;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F28_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 28;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F31_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 31;
	DataGWList[i].Type = 3;
	i = i + 1;
	DataGWList[i].setdata = Level1Data_F32_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 32;
	DataGWList[i].Type = 3;
	i = i + 1;
	DataGWList[i].setdata = Level1Data_F33_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 33;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F34_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 34;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F35_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 35;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F36_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 36;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F37_Get;//376.1lqq++
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 37;
	DataGWList[i].Type = 3;
	i = i + 1;
	DataGWList[i].setdata = Level1Data_F38_Get;//376.1lqq++
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 38;
	DataGWList[i].Type = 3;
	i = i + 1;
	DataGWList[i].setdata = Level1Data_F39_Get;//376.1lqq++
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 39;
	DataGWList[i].Type = 3;
	i = i + 1;
	DataGWList[i].setdata = Level1Data_F40_Get;	//376.1lqq++	//9��15�ո�
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 40;
	DataGWList[i].Type = 3;
	i = i + 1;
	DataGWList[i].setdata = Level1Data_F49_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 49;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F73_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 73;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F129_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 129;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F130_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 130;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F131_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 131;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F132_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 132;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F133_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 133;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F134_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 134;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F135_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 135;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F136_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 136;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F137_Get;//376.1lqq++
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 137;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F138_Get;//376.1lqq++
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 138;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F139_Get;//376.1lqq++
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 139;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F140_Get;//376.1lqq++
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 140;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F141_Get;//376.1lqq++
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 141;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F142_Get;//376.1lqq++
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 142;
	DataGWList[i].Type = 3;
	i = i + 1;
	DataGWList[i].setdata = Level1Data_F143_Get;//376.1lqq++
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 143;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F144_Get;//376.1lqq++
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 144;
	DataGWList[i].Type = 3;
	i = i + 1;
	DataGWList[i].setdata = Level1Data_F145_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 145;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F146_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 146;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F147_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 147;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F148_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 148;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F149_Get;//376.1lqq++
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 149;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F151_Get;	//376.1lqq++	//9��15�ո�
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 151;
	DataGWList[i].Type = 3;
	i = i + 1;
	DataGWList[i].setdata = Level1Data_F161_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 161;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F165_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 165;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F166_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 166;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F167_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 167;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F168_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 168;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F169_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 169;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F170_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 170;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F248_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 248;
	DataGWList[i].Type = 3;
	i = i + 1;
	DataGWList[i].setdata = Level1Data_F12_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 12;
	DataGWList[i].Type = 3;
	i = i + 1;
	DataGWList[i].setdata = Level1Data_F186_Get;
	DataGWList[i].iDataType = J_1LEIDATE;
	DataGWList[i].Fn = 186;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F1_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 1;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F2_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 2;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F3_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 3;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F4_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 4;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F5_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 5;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F7_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 7;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F8_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 8;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F9_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 9;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F10_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 10;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F11_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 11;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F17_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 17;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F18_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 18;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F25_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 25;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F26_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 26;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F27_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 27;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F28_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 28;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F29_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 29;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F31_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 31;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F32_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 32;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F33_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 33;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F34_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 34;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F35_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 35;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F36_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 36;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F37_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 37;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F38_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 38;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F39_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 39;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F40_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 40;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F41_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 41;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F42_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 42;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F43_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 43;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F44_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 44;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F45_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 45;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F46_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 46;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F47_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 47;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F48_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 48;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F49_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 49;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F57_Get;//LQQ xiebo++
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 57;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F58_Get;//LQQ xiebo++
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 58;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F73_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 73;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F89_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 89;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F90_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 90;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F91_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 91;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F92_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 92;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F93_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 93;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F94_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 94;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F95_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 95;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F96_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 96;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F97_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 97;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F98_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 98;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F99_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 99;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F100_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 100;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F101_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 101;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F102_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 102;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F103_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 103;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F105_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 105;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F106_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 106;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F107_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 107;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F108_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 108;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F109_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 109;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F110_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 110;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F111_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 111;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F112_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 112;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F113_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 113;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F114_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 114;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F115_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 115;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F116_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 116;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F129_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 129;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F130_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 130;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F131_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 131;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F132_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 132;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F133_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 133;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F134_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 134;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F135_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 135;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F136_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 136;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F137_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 137;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F138_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 138;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F139_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 139;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F140_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 140;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F141_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 141;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F142_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 142;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F143_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 143;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F144_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 144;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F145_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 145;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F146_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 146;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F147_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 147;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F148_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 148;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F149_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 149;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F150_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 150;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F151_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 151;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F152_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 152;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F153_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 153;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F154_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 154;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F155_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 155;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F156_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 156;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F157_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 157;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F158_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 158;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F159_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 159;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F159_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 159;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F160_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 160;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F161_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 161;
	DataGWList[i].Type = 3;
	i = i + 1;

//	DataGWList[i].setdata = Level1Data_Curr_F162_Get;
//	DataGWList[i].iDataType = J_1LEICURR;
//	DataGWList[i].Fn = 162;
//	DataGWList[i].Type = 3;
//	i = i + 1;
//
//	DataGWList[i].setdata = Level1Data_Curr_F163_Get;
//	DataGWList[i].iDataType = J_1LEICURR;
//	DataGWList[i].Fn = 163;
//	DataGWList[i].Type = 3;
//	i = i + 1;
//
//	DataGWList[i].setdata = Level1Data_Curr_F164_Get;
//	DataGWList[i].iDataType = J_1LEICURR;
//	DataGWList[i].Fn = 164;
//	DataGWList[i].Type = 3;
//	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F165_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 165;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F166_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 166;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F167_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 167;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_Curr_F168_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 168;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Level1Data_F248_Get;
	DataGWList[i].iDataType = J_1LEICURR;
	DataGWList[i].Fn = 248;
	DataGWList[i].Type = 3;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F1;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 1;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F2;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 2;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F3;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 3;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F4;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 4;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F5;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 5;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F6;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 6;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F7;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 7;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F8;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 8;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F9;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 9;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F10;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 10;
	DataGWList[i].Type = 4;
	i = i + 1;
	DataGWList[i].setdata = Get_Level2Data_F11;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 11;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F12;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 12;
	DataGWList[i].Type = 4;
	i = i + 1;
	DataGWList[i].setdata = Get_Level2Data_F17;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 17;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F18;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 18;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F19;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 19;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F20;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 20;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F21;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 21;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F22;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 22;
	DataGWList[i].Type = 4;
	i = i + 1;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F23;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 23;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F24;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 24;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F25;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 25;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F26;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 26;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F27;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 27;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F28;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 28;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F29;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 29;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F30;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 30;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F32;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 32;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F33;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 33;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F34;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 34;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F35;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 35;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F36;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 36;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F37;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 37;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F38;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 38;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F41;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 41;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F42;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 42;
	DataGWList[i].Type = 4;
	i = i + 1;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F43;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 43;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F44;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 44;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F45;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 45;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F46;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 46;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F49;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 49;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F50;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 50;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F51;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 51;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F52; //10.24
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 52;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F53;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 53;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F54;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 54;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F57;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 57;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F60;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 60;
	DataGWList[i].Type = 4;
	i = i + 1;

//	DataGWList[i].setdata = Get_Level2Data_F73;
//	 DataGWList[i].iDataType = J_2LEIDATE;
//	 DataGWList[i].Fn = 73;
//	 DataGWList[i].Type = 4;
//	 i = i + 1;
//
//	 DataGWList[i].setdata = Get_Level2Data_F74;
//	 DataGWList[i].iDataType = J_2LEIDATE;
//	 DataGWList[i].Fn = 74;
//	 DataGWList[i].Type = 4;
//	 i = i + 1;
//
//	 DataGWList[i].setdata = Get_Level2Data_F75;
//	 DataGWList[i].iDataType = J_2LEIDATE;
//	 DataGWList[i].Fn = 75;
//	 DataGWList[i].Type = 4;
//	 i = i + 1;
//
//	 DataGWList[i].setdata = Get_Level2Data_F76;
//	 DataGWList[i].iDataType = J_2LEIDATE;
//	 DataGWList[i].Fn = 76;
//	 DataGWList[i].Type = 4;
//	 i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F81;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 81;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F82;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 82;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F83;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 83;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F84;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 84;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F85;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 85;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F86;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 86;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F87;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 87;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F88;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 88;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F89;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 89;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F90;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 90;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F91;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 91;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F92;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 92;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F93;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 93;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F94;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 94;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F95;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 95;
	DataGWList[i].Type = 4;
	i = i + 1;
	DataGWList[i].setdata = Get_Level2Data_F97;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 97;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F98;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 98;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F99;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 99;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F100;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 100;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F101;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 101;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F102;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 102;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F103;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 103;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F104;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 104;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F105;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 105;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F106;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 106;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F107;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 107;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F108;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 108;
	DataGWList[i].Type = 4;
	i = i + 1;

	//��������ӵĶ��������в�
	DataGWList[i].setdata = Get_Level2Data_F121;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 121;
	DataGWList[i].Type = 4;
	i = i + 1;
	DataGWList[i].setdata = Get_Level2Data_F122;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 122;
	DataGWList[i].Type = 4;
	i = i + 1;
	DataGWList[i].setdata = Get_Level2Data_F123;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 123;
	DataGWList[i].Type = 4;
	i = i + 1;
	DataGWList[i].setdata = Get_Level2Data_F109;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 109;
	DataGWList[i].Type = 4;
	i = i + 1;
	DataGWList[i].setdata = Get_Level2Data_F110;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 110;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F194;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 194;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F196;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 196;
	DataGWList[i].Type = 4;
	i = i + 1;
	DataGWList[i].setdata = Get_Level2Data_F209;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 209;
	DataGWList[i].Type = 4;
	i = i + 1;
	//------------------------------------------jiangsugaidong

	DataGWList[i].setdata = Get_Level2Data_F31;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 31;
	DataGWList[i].Type = 4;
	i = i + 1;
	DataGWList[i].setdata = Get_Level2Data_F39;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 39;
	DataGWList[i].Type = 4;
	i = i + 1;
	DataGWList[i].setdata = Get_Level2Data_F160;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 160;
	DataGWList[i].Type = 4;
	i = i + 1;
	DataGWList[i].setdata = Get_Level2Data_F159;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 159;
	DataGWList[i].Type = 4;
	i = i + 1;
	DataGWList[i].setdata = Get_Level2Data_F158;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 158;
	DataGWList[i].Type = 4;
	i = i + 1;
	DataGWList[i].setdata = Get_Level2Data_F157;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 157;
	DataGWList[i].Type = 4;
	i = i + 1;
	//----------------  //xiebo   <<<<<<<<------------------------------
	DataGWList[i].setdata = Get_Level2Data_F113;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 113;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F114;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 114;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F115;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 115;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F116;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 116;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F117;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 117;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F118;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 118;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F145;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 145;
	DataGWList[i].Type = 4;
	i = i + 1;
	DataGWList[i].setdata = Get_Level2Data_F146;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 146;
	DataGWList[i].Type = 4;
	i = i + 1;
	DataGWList[i].setdata = Get_Level2Data_F147;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 147;
	DataGWList[i].Type = 4;
	i = i + 1;
	DataGWList[i].setdata = Get_Level2Data_F148;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 148;
	DataGWList[i].Type = 4;
	i = i + 1;

	//----------------  //xiebo   <<<<<<<<------------------------------

	DataGWList[i].setdata = Get_Level2Data_F153;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 153;
	DataGWList[i].Type = 4;
	i = i + 1;
	DataGWList[i].setdata = Get_Level2Data_F154;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 154;
	DataGWList[i].Type = 4;
	i = i + 1;
	DataGWList[i].setdata = Get_Level2Data_F155;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 155;
	DataGWList[i].Type = 4;
	i = i + 1;
	DataGWList[i].setdata = Get_Level2Data_F156;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 156;
	DataGWList[i].Type = 4;
	i = i + 1;


	DataGWList[i].setdata = Get_Level2Data_F161;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 161;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F162;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 162;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F163;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 163;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F164;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 164;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F165;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 165;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F166;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 166;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F167;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 167;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F168;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 168;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F169;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 169;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F170;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 170;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F171;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 171;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F172;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 172;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F173;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 173;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F174;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 174;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F175;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 175;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F176;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 176;
	DataGWList[i].Type = 4;
	i = i + 1;
	DataGWList[i].setdata = Get_Level2Data_F177;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 177;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F178;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 178;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F179;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 179;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F180;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 180;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F181;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 181;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F182;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 182;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F183;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 183;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F184;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 184;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F185;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 185;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F186;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 186;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F187;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 187;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F188;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 188;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F189;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 189;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F190;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 190;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F191;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 191;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F192;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 192;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F193;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 193;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F195;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 195;
	DataGWList[i].Type = 4;
	i = i + 1;
	DataGWList[i].setdata = Get_Level2Data_F215;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 215;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F216;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 216;
	DataGWList[i].Type = 4;
	i = i + 1;

	DataGWList[i].setdata = Get_Level2Data_F225;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 225;
	DataGWList[i].Type = 4;
	i = i + 1;


	DataGWList[i].setdata = Get_Level2Data_F248;
	DataGWList[i].iDataType = J_2LEIDATE;
	DataGWList[i].Fn = 248;
	DataGWList[i].Type = 4;
	i = i + 1;
	SdPrint("initdatatable i=%d\n\r",i);
}
*/


INT8U testTime(INT8U *s,TS ts,INT8U zqdw )
{
	INT8U Sec, Min, Hour, Day, Month, Year;
	Sec = (s[0] >> 4) * 10;
	Sec = Sec + (s[0] & 0x0f);
	Min = (s[1] >> 4) * 10;
	Min = Min + (s[1] & 0x0f);
	Hour = (s[2] >> 4) * 10;
	Hour = Hour + (s[2] & 0x0f);
	Day = (s[3] >> 4) * 10;
	Day = Day + (s[3] & 0x0f);
	Month = ((s[4] >> 4) & 1) * 10;
	Month = Month + (s[4] & 0x0f);
	Year = ((s[5] >> 4) & 1) * 10;
	Year = Year + (s[5] & 0x0f);
	if ((zqdw==1)&&(ts.Minute<Min))
		return 0;
	if ((zqdw==2)&&(ts.Hour<Hour))
		return 0;
	if ((zqdw==3)&&(ts.Day<Day))
		return 0;

	if ((ts.Year % 100) > Year) {
		return 1;
	} else {
		if ((ts.Year % 100) < Year) {
			return 0;
		} else {
			if (ts.Month > Month) {
				return 1;
			} else {
				if (ts.Month < Month) {
					return 0;
				} else {
					if (ts.Day > Day) {
						return 1;
					} else {
						if (ts.Day < Day) {
							return 0;
						} else {
							if (ts.Hour > Hour) {
								return 1;
							} else {
								if (ts.Hour < Hour) {
									return 0;
								} else {
									if (ts.Minute > Min) {
										return 1;
									} else {
										return 0;
									}
								}
							}
						}
					}
				}
			}
		}
	}
}

void SetFrameCountL1(int taskno, INT8U *t,INT8U zqdw,TS ts)//10.10
{
	int TailSendOk = 0;
	int k,L,m;
	int j;

	/////////////////////////////////////////////////////////
	AllReportTail=0;
	AllReportHead=0;
	SendIndex = 0;
	SendIndex = SendIndex + 14;
	TailSendOk = 0;
	for (j = 0; j < JSetPara_AFN04_3761_2009->group9.f65[taskno].Count; j++)
	{
		GetDa(JSetPara_AFN04_3761_2009->group9.f65[taskno].Flag[j][0],	JSetPara_AFN04_3761_2009->group9.f65[taskno].Flag[j][1]);
		GetDt(JSetPara_AFN04_3761_2009->group9.f65[taskno].Flag[j][2],	JSetPara_AFN04_3761_2009->group9.f65[taskno].Flag[j][3]);
		for (k = 0; k < PointMax; k++)
		{
			if (DA[k] == 1)
			{
				for (L = 0; L < 255; L++)
				{
					if (DT[L] == 1)
					{
						TmpF = L;
						TmpP = k;
						if (TmpF==248)
							continue;
						for (m = 0; m < ITEMGWCOUNT; m++)
						{
							if (DataGWList[m].Fn == TmpF && DataGWList[m].iDataType	== J_1LEICURR)
							{
								SdPrintf(YNPrint,PreFix,"tmpf=%d,tmp=%d\n\r",TmpF,TmpP);
//								ClearThreadTimes(ProjectNo);
								if ((TmpF > 11) && (TmpP == 0))
									continue;
								AutoFlg = 1;
								PrmFlg = 1;
								SendBuff[SendIndex++] = SetDa1(TmpP);
								SendBuff[SendIndex++] = SetDa2(TmpP);
								SendBuff[SendIndex++] = SetDt1(TmpF);
								SendBuff[SendIndex++] = SetDt2(TmpF);
								DataGWList[m].setdata(0, TmpF, TmpP, &t[0]);
							}
						}
						if (SendIndex > FRAME_MAX)
						{//����ĳ��������ȫ����������֯��ϣ��ж��Ƿ��ֽڳ�����ֵ��������ޱ��뷢�͸�֡
							AllReportHead++;
							TailSendOk = 1;
							SendIndex = 0;
							SendIndex = SendIndex + 14;
						}
					}
				}
			}
		}//end for pointMax
		if (SendIndex > FRAME_MAX)
		{//����ĳ��������ȫ����������֯��ϣ��ж��Ƿ��ֽڳ�����ֵ��������ޱ��뷢�͸�֡
			EC(); TP(); FrameTailCreate_Send(0);
			TailSendOk = 1;
			delay(50);

			SendIndex = 0;
			SendIndex = SendIndex + 14;
		}
	}//end for
	if(TailSendOk == 0)
	{
		AllReportHead++;
	}
	return ;
}
INT16S autoReportOneLevelData(INT8U taskno) //10.10
{
	INT16U j, k, l, m;
	int TailSendOk=0;
	INT8U zqdw;// zqvalue;
	INT8U t[20];
	Fseq = Jproginfo->PFC;
	Jproginfo->PFC++;
	NeedTp = 0;
	if (NeedTp) {
		TS ts2;
		TSGet(&ts2);
		TpBuff[0] = Jproginfo->PFC;
		INT32U_BCD(ts2.Sec, &TpBuff[1], 1);
		INT32U_BCD(ts2.Minute, &TpBuff[2], 1);
		INT32U_BCD(ts2.Hour, &TpBuff[3], 1);
		INT32U_BCD(ts2.Day, &TpBuff[4], 1);
		TpBuff[5] = 0;
	}
//	if (JSetPara_AFN04_3761_2009->group9.f67[taskno].IsRun == 0x55)
//	{
		TSGet(&ts);
		zqdw = JSetPara_AFN04_3761_2009->group9.f65[taskno].Interval >> 6;
//		zqvalue = JSetPara_AFN04_3761_2009->group9.f65[taskno].Interval & 0x3f;
//		if (testTime(JSetPara_AFN04_3761_2009->group9.f65[taskno].Post_Time,ts,zqdw))
//		{
//			if (zqvalue == 0)
//				return ERR_AUTO_WRONG_AFN;
//
//			if (zqdw == 0) {
//				m = (ts.Minute + 60 - Jproginfo->task1_Delay_Count[taskno]) % 60;
//				if (((m % zqvalue) != 0) || (m == 0)) {
//					return ERR_AUTO_WRONG_AFN;
//				} else {
//					SdPrintf(">>Jproginfo->task1_Delay_Count=%d-%d\n\r",Jproginfo->task1_Delay_Count[taskno],ts.Minute);
//					Jproginfo->task1_Delay_Count[taskno] = ts.Minute;
//				}
//			}
//			if (zqdw == 1) {
//				m = (ts.Hour + 24 - Jproginfo->task1_Delay_Count[taskno]) % 24;
//				if (((m % zqvalue) != 0) || (m == 0)) {
//					return ERR_AUTO_WRONG_AFN;
//				} else {
//					Jproginfo->task1_Delay_Count[taskno] = ts.Hour;
//				}
//			}
//			if (zqdw == 2) {
//				m = (ts.Day + 31 - Jproginfo->task1_Delay_Count[taskno]) % 31;
//				if (((m % zqvalue) != 0) || (m == 0)) {
//					return ERR_AUTO_WRONG_AFN;
//				} else {
//					Jproginfo->task1_Delay_Count[taskno] = ts.Day;
//				}
//			}
//			if (zqdw == 3) {
//				m = (ts.Month + 12 - Jproginfo->task1_Delay_Count[taskno]) % 12;
//				if (((m % zqvalue) != 0) || (m == 0)) {
//					return ERR_AUTO_WRONG_AFN;
//				} else {
//					Jproginfo->task1_Delay_Count[taskno] = ts.Month;
//				}
//			}
			memset(t,0,20);
			INT32U_BCD(ts.Minute, &t[0], 1);
			INT32U_BCD(ts.Hour, &t[1], 1);
			INT32U_BCD(ts.Day, &t[2], 1);
			INT32U_BCD(ts.Month, &t[3], 1);
			INT32U_BCD(ts.Year, &t[4], 1);
			t[5] = 3;
			t[6] = 1;
			NeedTp = 0;
			SdPrintf(YNPrint,PreFix,"�����ϱ�һ���������������:%d\n\r",taskno+1);

			//����֡����
			AutoFlg = 1; PrmFlg = 1;
			SetFrameCountL1(taskno,&t[0],zqdw,ts);//���㽫Ҫ����֡������
			//����֡ͷ
			MY_MKLevel1Head(0x88|(PrmFlg<<6));

			for (j = 0; j < JSetPara_AFN04_3761_2009->group9.f65[taskno].Count; j++)
			{
				GetDa(JSetPara_AFN04_3761_2009->group9.f65[taskno].Flag[j][0],	JSetPara_AFN04_3761_2009->group9.f65[taskno].Flag[j][1]);
				GetDt(JSetPara_AFN04_3761_2009->group9.f65[taskno].Flag[j][2],	JSetPara_AFN04_3761_2009->group9.f65[taskno].Flag[j][3]);
				for (k = 0; k < PointMax; k++)
				{
					if (DA[k] == 1)
					{
						for (l = 0; l < 255; l++)
						{
							if (DT[l] == 1)
							{
								TmpF = l;
								TmpP = k;
								if (TmpF==248)
									continue;
								for (m = 0; m < ITEMGWCOUNT; m++)
								{
									if (DataGWList[m].Fn == TmpF && DataGWList[m].iDataType	== J_1LEICURR)
									{
										SdPrintf(YNPrint,PreFix,"Fn=%d,Pn=%d\n\r",TmpF,TmpP);
//										ClearThreadTimes(ProjectNo);
										if ((TmpF > 11) && (TmpP == 0))
											continue;
										AutoFlg = 1;
										PrmFlg = 1;
										SendBuff[SendIndex++] = SetDa1(TmpP);//Tmp130Buff[14];//da1e
										SendBuff[SendIndex++] = SetDa2(TmpP);//Tmp130Buff[15];//da2
										SendBuff[SendIndex++] = SetDt1(TmpF);//Tmp130Buff[16];//dt1
										SendBuff[SendIndex++] = SetDt2(TmpF);//Tmp130Buff[17];//dt2
										DataGWList[m].setdata(0, TmpF, TmpP, &t[0]);
										TailSendOk = 0;
									}
								}
								if (SendIndex > FRAME_MAX)
								{//����ĳ��������ȫ����������֯��ϣ��ж��Ƿ��ֽڳ�����ֵ��������ޱ��뷢�͸�֡
									SdPrintf(YNPrint,PreFix,"���Ĵ���900��byte\n");
									EC(); TP(); FrameTailCreate_Send(0);
									TailSendOk = 1;
									delay(50);

									MY_MKLevel1Head(0x88|(PrmFlg<<6));
								}
							}
						}
					}
				}//end for pointMax
				if (SendIndex > FRAME_MAX)
				{//����ĳ��������ȫ����������֯��ϣ��ж��Ƿ��ֽڳ�����ֵ��������ޱ��뷢�͸�֡
					SdPrintf(YNPrint,PreFix,"���Ĵ���900��byte\n");
					EC(); TP(); FrameTailCreate_Send(0);
					TailSendOk = 1;
					delay(50);

					MY_MKLevel1Head(0x88|(PrmFlg<<6));
				}
			}//end for
			if(TailSendOk == 0)
			{
				SdPrintf(YNPrint,PreFix,"���һ֡����\n");
				delay(50);
				EC(); TP(); FrameTailCreate_Send(0);
			}
//		}//end if test time
//	}//end if IsRun == 0x55
	return J_1LEIDATE;
}

void dealTime(INT16U TmpF,INT8U zqdw,TS ts,INT8U *t)
{
	TS ts2;
	if ((TmpF>72)&&(TmpF<96)&&(zqdw>1))//����
	{//ÿ���ϴ����ߣ����ϴ�������������
		ts2=ts;
		TimeDecrease(&ts2,4,1);
		memset(t,0,20);
		INT32U_BCD(ts2.Minute, &t[0], 1);
		INT32U_BCD(ts2.Hour, &t[1], 1);
		INT32U_BCD(ts2.Day, &t[2], 1);
		INT32U_BCD(ts2.Month, &t[3], 1);
		INT32U_BCD(ts2.Year, &t[4], 1);
		t[5] = 1;
		t[6] = 24;
	}
	else
	{
		memset(t,0,20);
		INT32U_BCD(ts.Minute, &t[0], 1);
		INT32U_BCD(ts.Hour, &t[1], 1);
		INT32U_BCD(ts.Day, &t[2], 1);
		INT32U_BCD(ts.Month, &t[3], 1);
		INT32U_BCD(ts.Year, &t[4], 1);

		t[5] = 3;
		t[6] = 1;
	}
	return ;
}
void SetFrameCount(int taskno, INT8U *t,INT8U zqdw,TS ts)
{
	int TailSendOk = 0;
	int k,L,m;
	int j;
	AllReportTail=0;
	AllReportHead=0;
	SendIndex = 0;
	SendIndex = SendIndex + 14;
	TailSendOk = 0;
	for (j = 0; j < JSetPara_AFN04_3761_2009->group9.f66[taskno].Count; j++)
	{
		GetDa(JSetPara_AFN04_3761_2009->group9.f66[taskno].Flag[j][0],JSetPara_AFN04_3761_2009->group9.f66[taskno].Flag[j][1]);
		GetDt(JSetPara_AFN04_3761_2009->group9.f66[taskno].Flag[j][2],JSetPara_AFN04_3761_2009->group9.f66[taskno].Flag[j][3]);

		for (k = 0; k < PointMax; k++)
		{
			if (DA[k] == 1)
			{//������
				for (L = 0; L < 255; L++)
				{
					if (DT[L] == 1)
					{//Fn
						TmpF = L;  TmpP = k;
						if (TmpF==248)
							continue;
						for (m = 0; m < ITEMGWCOUNT; m++)
						{
							if (DataGWList[m].Fn == TmpF && DataGWList[m].iDataType== J_2LEIDATE)
							{
								if (((TmpF < 49) || (TmpF > 54))&& (TmpP == 0))
									continue;
								dealTime(TmpF,zqdw,ts,t);

								MY_MKDataUnitFlag(TmpP,TmpF);
//								ClearThreadTimes(ProjectNo);
								CallTwoDataProc(TmpF, TmpP, 1, &t[0],0x88);
								TailSendOk = 0;
								break;
							}
						}
						//����ĳ��������ȫ����������֯��ϣ��ж��Ƿ��ֽڳ�����ֵ��������ޱ��뷢�͸�֡
						if (SendIndex > FRAME_MAX)
						{
							AllReportHead++;
							TailSendOk = 1;
							SendIndex = 0;
							SendIndex = SendIndex + 14;
						}
					}
				}//end for dt
			}
		}
	}
	if(TailSendOk == 0)
	{
		AllReportHead++;
	}
	return ;
//	int TailSendOk = 0;
//	int k,L,m;
//
//	AllReportTail=0;
//	AllReportHead=0;
//	SendIndex = 0;
//	SendIndex = SendIndex + 14;
//
//	GetDa(JSetPara_AFN04_3761_2009->group9.f66[taskno].Flag[j][0],JSetPara_AFN04_3761_2009->group9.f66[taskno].Flag[j][1]);
//	GetDt(JSetPara_AFN04_3761_2009->group9.f66[taskno].Flag[j][2],JSetPara_AFN04_3761_2009->group9.f66[taskno].Flag[j][3]);
//
//	for (k = 0; k < PointMax; k++)
//	{
//		if (DA[k] == 1)
//		{//������
//			for (L = 0; L < 255; L++)
//			{
//				if (DT[L] == 1)
//				{//Fn
//					TmpF = L;  TmpP = k;
//					printf("tmpf=%d,tmp=%d\n\r",TmpF,TmpP);
//					if (TmpF==248)
//						continue;
//					for (m = 0; m < ITEMGWCOUNT; m++)
//					{
//						if (DataGWList[m].Fn == TmpF && DataGWList[m].iDataType== J_2LEIDATE)
//						{
//							if (((TmpF < 49) || (TmpF > 54))&& (TmpP == 0))
//								continue;
//							dealTime(TmpF,zqdw,ts,t);
//
//							MY_MKDataUnitFlag(TmpP,TmpF);
//							ClearThreadTimes(ProjectNo);
//							CallTwoDataProc(TmpF, TmpP, 1, &t[0],0x88);
//							TailSendOk = 0;
//							break;
//						}
//					}
//				}
//			}//end for dt
//			//����ĳ��������ȫ����������֯��ϣ��ж��Ƿ��ֽڳ�����ֵ��������ޱ��뷢�͸�֡
//			if (SendIndex > FRAME_MAX)
//			{
//				AllReportHead++;
//				TailSendOk = 1;
//				SendIndex = 0;
//				SendIndex = SendIndex + 14;
//			}
//		}
//	}
//	if(TailSendOk == 0)
//	{
//		AllReportHead++;
//	}
//	return ;
}
INT16S autoReportTwoLevelData(INT8U taskno)
{//376.1
	INT16U j, k,  m,L;
	TS ts;
	int TailSendOk;
	INT8U zqdw,  t[20];  //zqvalue
//	Fseq = Jmemory->jzq.PFC;
//	Jmemory->jzq.PFC++;
	Fseq = Jproginfo->PFC;
	Jproginfo->PFC++;
	NeedTp = 0;
	if (NeedTp) {
		TpBuff[0] = Jproginfo->PFC;
		INT32U_BCD(ts.Sec, &TpBuff[1], 1);
		INT32U_BCD(ts.Minute, &TpBuff[2], 1);
		INT32U_BCD(ts.Hour, &TpBuff[3], 1);
		INT32U_BCD(ts.Day, &TpBuff[4], 1);
		TpBuff[5] = 0;
	}
//	if (JSetPara_AFN04_3761_2009->group9.f68[taskno].IsRun == 0x55) {
		TSGet(&ts);

		zqdw = JSetPara_AFN04_3761_2009->group9.f66[taskno].Interval >> 6;
//		zqvalue = JSetPara_AFN04_3761_2009->group9.f66[taskno].Interval & 0x3f;
//		if (testTime(JSetPara_AFN04_3761_2009->group9.f66[taskno].Post_Time,ts,zqdw))
//		{
//			if(zqvalue==0) //9.25wan
//				return ERR_AUTO_WRONG_AFN;
//			if (zqdw == 0) {
//				m = (ts.Minute + 60 - Jproginfo->task2_Delay_Count[taskno]) % 60;
//				if (((m % zqvalue) != 0) || (m == 0)) {
//					return ERR_AUTO_WRONG_AFN;
//				} else {
//					SdPrintf("Jproginfo->task2_Delay_Count=%d-%d\n\r",Jproginfo->task2_Delay_Count[taskno],ts.Minute);
//					Jproginfo->task2_Delay_Count[taskno] = ts.Minute;
//				}
//			}
//			if (zqdw == 1) {
//				m = (ts.Hour + 24 - Jproginfo->task2_Delay_Count[taskno]) % 24;
//				if (((m % zqvalue) != 0) || (m == 0)) {
//					return ERR_AUTO_WRONG_AFN;
//				} else {
//					Jproginfo->task2_Delay_Count[taskno] = ts.Hour;
//				}
//			}
//			if (zqdw == 2) {
//				m = (ts.Day + 31 - Jproginfo->task2_Delay_Count[taskno]) % 31;
//				if (((m % zqvalue) != 0) || (m == 0)) {
//					return ERR_AUTO_WRONG_AFN;
//				} else {
//					//if (Jmemory->jzq.ReadMeter==0)
//					//	return;
//					SdPrintf("Jproginfo->task2_Delay_Count=%d-%d\n\r",Jproginfo->task2_Delay_Count[taskno],ts.Hour);
//					Jproginfo->task2_Delay_Count[taskno] = ts.Day;
//				}
//			}
//			if (zqdw == 3) {
//				m = (ts.Month + 12 - Jproginfo->task2_Delay_Count[taskno]) % 12;
//				if (((m % zqvalue) != 0) || (m == 0)) {
//					return ERR_AUTO_WRONG_AFN;
//				} else {
//					Jproginfo->task2_Delay_Count[taskno] = ts.Month;
//				}
//			}
			NeedTp = 0;
			memset(t,0,20);
			INT32U_BCD(ts.Minute, &t[0], 1);
			INT32U_BCD(ts.Hour, &t[1], 1);
			INT32U_BCD(ts.Day, &t[2], 1);
			INT32U_BCD(ts.Month, &t[3], 1);
			INT32U_BCD(ts.Year, &t[4], 1);
		//	if(Jmemory->TianJing == 1)
			t[5] = 1;
			t[6] = 1;
			AutoSucc=0;

			AutoFlg = 1; PrmFlg = 1;
			SetFrameCount(taskno,&t[0],zqdw,ts);//���㽫Ҫ����֡������

			SdPrintf(YNPrint,PreFix, "\n	taskno=%d AllReportTail= %d  AllReportHead= %d",taskno,AllReportTail,AllReportHead);
			SdPrintf(YNPrint,PreFix, "\n  Count= %d",JSetPara_AFN04_3761_2009->group9.f66[taskno].Count);
			SdPrintf(YNPrint,PreFix, "\n");
			MY_MKLevel2Head(0x88|(PrmFlg<<6));
			TailSendOk = 0;
//			Jmemory->jzq.BeiYong[13] = taskno;
			Jproginfo->BeiYong[13] = taskno;
			for (j = 0; j < JSetPara_AFN04_3761_2009->group9.f66[taskno].Count; j++)
			{
				GetDa(JSetPara_AFN04_3761_2009->group9.f66[taskno].Flag[j][0],JSetPara_AFN04_3761_2009->group9.f66[taskno].Flag[j][1]);
				GetDt(JSetPara_AFN04_3761_2009->group9.f66[taskno].Flag[j][2],JSetPara_AFN04_3761_2009->group9.f66[taskno].Flag[j][3]);

				for (k = 0; k < PointMax; k++)
				{
					if (DA[k] == 1)
					{//������
						for (L = 0; L < 255; L++)
						{
							if (DT[L] == 1)
							{//Fn
								TmpF = L;  TmpP = k;
								SdPrintf(YNPrint,PreFix, " tmpf=%d,tmp=%d\n",TmpF,TmpP);
								if (TmpF==248)
									continue;
								for (m = 0; m < ITEMGWCOUNT; m++)
								{
									if (DataGWList[m].Fn == TmpF && DataGWList[m].iDataType== J_2LEIDATE)
									{
										if (((TmpF < 49) || (TmpF > 54))&& (TmpP == 0))
											continue;
										dealTime(TmpF,zqdw,ts,t);
										MY_MKDataUnitFlag(TmpP,TmpF);
//										ClearThreadTimes(ProjectNo);
										SdPrintf(YNPrint," ","t[5] =%d",t[5]);
										CallTwoDataProc(TmpF, TmpP, 1, &t[0],0x88);
										TailSendOk = 0;
										break;
									}
								}
								if (SendIndex > FRAME_MAX)
								{//����ĳ��������ȫ����������֯��ϣ��ж��Ƿ��ֽڳ�����ֵ��������ޱ��뷢�͸�֡
									EC(); TP(); FrameTailCreate_Send(0);
									TailSendOk = 1;
									delay(50);

									MY_MKLevel2Head(0x88|(PrmFlg<<6));
								}
							}
						}//end for dt
					}
				}//end for PointMax
			}
			if(TailSendOk == 0)
			{
				delay(50);
				EC(); TP(); FrameTailCreate_Send(0);
			}
			Jproginfo->Para.ChangedJiZhongQiInfo = 2;
//		}//end if test time
//	}
	return J_2LEIDATE;
}

INT16S AutoSendThreeLevelData(INT8U F) {
	INT8U i;
	SendIndex = 0;
	NeedTp = 0;
	if (NeedTp) {
		TS ts;
		TSGet(&ts);
//		TpBuff[0] = Jmemory->jzq.PFC;
		TpBuff[0] =Jproginfo->PFC;
		INT32U_BCD(ts.Sec, &TpBuff[1], 1);
		INT32U_BCD(ts.Minute, &TpBuff[2], 1);
		INT32U_BCD(ts.Hour, &TpBuff[3], 1);
		INT32U_BCD(ts.Day, &TpBuff[4], 1);
		TpBuff[5] = 0;
	}
	Fseq = Jproginfo->PFC;
	Jproginfo->PFC++;
	memset(SendBuff, 0, FrameSize);
	SendBuff[SendIndex++] = 0x68;
	SendBuff[SendIndex++] = 0;
	SendBuff[SendIndex++] = 0;
	SendBuff[SendIndex++] = 0;
	SendBuff[SendIndex++] = 0;
	SendBuff[SendIndex++] = 0x68;
	SendBuff[SendIndex++] = 0xc4;
	SendBuff[SendIndex++] = Jcfginfo->jzqpara.Area_8016.JZ_XingZhuangQuHaoMa[1];//����������
	SendBuff[SendIndex++] = Jcfginfo->jzqpara.Area_8016.JZ_XingZhuangQuHaoMa[0];
	SendBuff[SendIndex++] = Jcfginfo->jzqpara.Address_8017.JZ_di_zhi[1];//�ն˵�ַ
	SendBuff[SendIndex++] = Jcfginfo->jzqpara.Address_8017.JZ_di_zhi[0];
	///////////////////////////////////////////////////////////
	SendBuff[SendIndex++] = 0;
	SendBuff[SendIndex++] = 0x0e;
	SendBuff[SendIndex++] = 0x60 | (Fseq & 0x0f);
	SendBuff[SendIndex++] = 0;
	SendBuff[SendIndex++] = 0;
	if (F == 1) {  //��Ҫ�¼�
		SendBuff[SendIndex++] = 1;
		SendBuff[SendIndex++] = 0;
		SendBuff[SendIndex++] = Jdatafileinfo->ErcEvt.EC1;
		SendBuff[SendIndex++] = Jdatafileinfo->ErcEvt.EC2;
		SendBuff[SendIndex++] = Jdatafileinfo->ErcEvt.EC1old;
		SendBuff[SendIndex++] = Jdatafileinfo->ErcEvt.EC1old + 1;
		memcpy(&Tmp_Erc, &Jdatafileinfo->ErcEvt.ImpEvent[Jdatafileinfo->ErcEvt.EC1old],
				sizeof(ERC));
		SendBuff[SendIndex++] = Tmp_Erc.Buff[0];
		SendBuff[SendIndex++] = Tmp_Erc.Buff[1];
		for (i = 0; i < Tmp_Erc.Buff[1]; i++) {
			SendBuff[SendIndex++] = Tmp_Erc.Buff[2 + i];
		}
		Jdatafileinfo->ErcEvt.EC1old++;
	}
	if (F == 2) {  //һ���¼�
		SendBuff[SendIndex++] = 2;
		SendBuff[SendIndex++] = 0;
		SendBuff[SendIndex++] = Jdatafileinfo->ErcEvt.EC1;
		SendBuff[SendIndex++] = Jdatafileinfo->ErcEvt.EC2;
		SendBuff[SendIndex++] = Jdatafileinfo->ErcEvt.EC2old;
		SendBuff[SendIndex++] = Jdatafileinfo->ErcEvt.EC2old + 1;
		memcpy(&Tmp_Erc, &Jdatafileinfo->ErcEvt.NorEvent[Jdatafileinfo->ErcEvt.EC2old],
				sizeof(ERC));
		SendBuff[SendIndex++] = Tmp_Erc.Buff[0];
		SendBuff[SendIndex++] = Tmp_Erc.Buff[1];
		for (i = 0; i < Tmp_Erc.Buff[1]; i++) {
			SendBuff[SendIndex++] = Tmp_Erc.Buff[2 + i];
		}
		Jdatafileinfo->ErcEvt.EC2old++;
	}
	EC();
	TP();
	FrameTailCreate_Send(0);
//	Jproginfo->FileSaveFlag.ercflag = 1;
	SdPrintf(YNPrint,PreFix,"EC1=%d,EC1old=%d,EC2=%d,EC2old=%d",
			Jdatafileinfo->ErcEvt.EC1,		Jdatafileinfo->ErcEvt.EC1old,
			Jdatafileinfo->ErcEvt.EC2,Jdatafileinfo->ErcEvt.EC2old);
	//Jmemory->jzq.PFC = Fseq;
	return J_3LEIDATE;
}
/////////////////////lwadd//////////////////////

void  FileTranACK(INT8U check_flag)
{
	INT8U cc;
	cc = CtrlCode | (1<<7);
	cc = cc &(~(1<<6));
	CreateGWHead(cc,0); //������ ������
	SendBuff[SendIndex++]=0x0f;//afn						//13
	SendBuff[SendIndex++]=0x60|(SEQ_FILE&0x0f);//seq			//14
	SendBuff[SendIndex++]=0;//Tmp130Buff[14];//da1e  		//15
	SendBuff[SendIndex++]=0;//Tmp130Buff[15];//da2		//16
	SendBuff[SendIndex++]=1;//Tmp130Buff[16];//dt1		//17
	SendBuff[SendIndex++]=0;//Tmp130Buff[17];//dt2		//18
	if(file_format.curr_segment_id>=1 || file_format.curr_segment_id<file_format.total)
	{
		//data
		SendBuff[SendIndex++] = file_format.total &0xff;  //�ܶ���
		SendBuff[SendIndex++] = file_format.total>>8 &0xff; //�ܶ���
		//��һ�α�ʶ

		if(file_format.curr_segment_id==file_format.total && check_flag == CHECK_OK) //ȫ���ļ�����ɹ�
		{
			SendBuff[SendIndex++] = 0xff;
			SendBuff[SendIndex++] = 0xff;
			SendBuff[SendIndex++] = 0xff;
			SendBuff[SendIndex++] = 0xff;
		}else
		{
			if(check_flag == CHECK_OK) //&& file_format.curr_segment_id==indexup) //���У��ɹ���������֡id+1 ����Ļ�����ԭ��֡id
			{
				file_format.curr_segment_id++;
				SendBuff[SendIndex++] = file_format.curr_segment_id &0xff;
				SendBuff[SendIndex++] = file_format.curr_segment_id>>8 &0xff;
				SendBuff[SendIndex++] = file_format.curr_segment_id>>16 &0xff;
				SendBuff[SendIndex++] = file_format.curr_segment_id>>24 &0xff;
			}
			if(check_flag == CHECK_FAIL)//���У��ʧ�� ������ԭ��֡id
			{
				SendBuff[SendIndex++] = file_format.curr_segment_id &0xff;
				SendBuff[SendIndex++] = file_format.curr_segment_id>>8 &0xff;
				SendBuff[SendIndex++] = file_format.curr_segment_id>>16 &0xff;
				SendBuff[SendIndex++] = file_format.curr_segment_id>>24 &0xff;
			}
//			if(file_format.curr_segment_id!=indexup&&check_flag == CHECK_OK)
//			{
//				file_format.curr_segment_id = indexup;
//				SendBuff[SendIndex++] = file_format.curr_segment_id &0xff;
//				SendBuff[SendIndex++] = file_format.curr_segment_id>>8 &0xff;
//				SendBuff[SendIndex++] = file_format.curr_segment_id>>16 &0xff;
//				SendBuff[SendIndex++] = file_format.curr_segment_id>>24 &0xff;
//			}
		}
	}
	EC();
	//SendBuff[SendIndex++] = Jmemory->jzq.EC1;//��Ҫ�¼�������	EC1ֵ
	//SendBuff[SendIndex++] = Jmemory->jzq.EC2;//һ���¼������� 	EC2ֵ
	//TP
	memcpy(&SendBuff[SendIndex], FRAME_TP, 6);  //TP
	SendIndex = SendIndex + 6;
	FrameTailCreate_Send(2);
	//FrameTailCreate_Send(2);
}
void FileTrans()//lwadd
{
		INT8U begin,check=0;
		INT8U data[1024];
		int i=0, len;
	//	int fp=0;
		int wrnum=0;
		FILE *fp=NULL;
		memset(&file_format, 0 ,sizeof(struct filetrans_t));
		CtrlCode = TempBuf[6];
		SEQ_FILE = TempBuf[13];
		begin = 18;
		//���ṹ�� file_format
		file_format.file_ID = TempBuf[begin];
		file_format.file_Attribute = TempBuf[begin+1];
		file_format.file_Instruction = TempBuf[begin+2];
		file_format.total = (TempBuf[begin+3])|(TempBuf[begin+4]<<8);
		file_format.curr_segment_id = (TempBuf[begin+5])|
									(TempBuf[begin+6]<<8)|
									(TempBuf[begin+7]<<16)|
									(TempBuf[begin+8]<<24);
		printf(" seg: %d\n",file_format.curr_segment_id);
		file_format.curr_segment_size = (TempBuf[begin+9])|(TempBuf[begin+10]<<8);

		len = (TempBuf[1]|(TempBuf[2]<<8))>>2;
		for(i=6; i<len+6; i++)
		{
			check += TempBuf[i];
		}
		check = check & 0xff;
		if(check == TempBuf[len+6])
		{
			file_format.check_flag = CHECK_OK;
		}else
		{
			file_format.check_flag = CHECK_FAIL;

		}
		if(access("/nand/gprsgw",0)!=0)
			system("mkdir /nand/gprsgw");
		if(file_format.curr_segment_id==0 || file_format.curr_segment_id>file_format.total)
		{
			printf("\nfile_format.curr_segment_id==0 || \n");
			return;
		}
		memset(data, 0, 1024);
		if(file_format.curr_segment_id==1)
		{
			//��һ������
			printf("111111111111\n\n");
			system("rm -r /nand/gprsgw/*"); //����������ʱ��ɾ��gprsgw�µ�������ǰ�������ļ�
			fp = fopen("/nand/gprsgw/updatefile.tar","wb");
			printf("\nBegin file trans!!!  %d\n", file_format.curr_segment_id);
			indexup=1;
		//	fp=open("/nand/gprsgw/updatefile.tar", O_WRONLY|O_CREAT,666);
			if(fp==NULL){
					printf("\nCan not open /nand/gprsgw/updatefile.tar ERROR ERROR!!!\n");
					return;
				}


		}else if(file_format.curr_segment_id<=file_format.total && file_format.curr_segment_id!=0)
		{
			fp = fopen("/nand/gprsgw/updatefile.tar","ab+");
			printf("\n file transing!!!  %d\n", file_format.curr_segment_id);
			//fp=open("/nand/gprsgw/updatefile.tar",O_WRONLY|O_APPEND,666 );
		}
		if(fp==NULL){
			printf("\nCan not open /nand/gprsgw/updatefile.tar ERROR ERROR!!!\n");
			return;
		}

		if(file_format.curr_segment_id==indexup )//&& file_format.check_flag == CHECK_OK)
		{
		memcpy(data, &TempBuf[begin+11], file_format.curr_segment_size);
		wrnum=fwrite(data, file_format.curr_segment_size, 1, fp);
	//	wrnum=write(fp,data,file_format.curr_segment_size);
		printf("д�룺%d�ֽ�\n",wrnum);
//		FileTranACK(file_format.check_flag);//��Ӧ����
		if(indexup==file_format.total)
					indexup=1;
		indexup++;

		}
	//	else if(file_format.curr_segment_id!=indexup){
	//		FileTranACK(file_format.check_flag);//��Ӧ����

		//}
        else if(file_format.check_flag == CHECK_FAIL){
//			FileTranACK(file_format.check_flag);//��Ӧ����
		}

		fclose(fp);

		memset(FRAME_TP, 0, 6);
		memcpy(FRAME_TP, &TempBuf[begin+file_format.curr_segment_size+26],6);
		//--------------------------------------------------------------------//
	//	ClearWaitTimes(ProjectNo);

		if(file_format.curr_segment_id==file_format.total && file_format.check_flag == CHECK_OK) //ȫ���ļ�����ɹ�
		{
			file_format.trans_State = 9;
		//	Jmemory->Para.UpdateFlags = 4;
			//�����ű�
			system("tar -xvf /nand/gprsgw/updatefile.tar -C /nand/gprsgw");
			system("chmod 777 /nand/gprsgw/update.sh");
			system("/nand/gprsgw/update.sh &");
			return;
		}else //����������
		{
			file_format.trans_State = 1;
		//	Jmemory->Para.UpdateFlags = 1;
		}
		return;
}
//////////////////////////////lwadd//////////////////////////
INT16S DealGWProtocol() {
	INT16S ret = -1;
	INT16U i = 0;
	INT16U macindex=0;
	INT8U MacOk=0;
	NeedTp = 0;
	HeartBeatErr = 0;
//	ClearThreadTimes(ProjectNo);
	InitGwAddr();
	if (TempBuf[13] & 0x80)//֡ʱ�����ǩ��ЧλTpVΪ1
	{
		NeedTp = 1;
		memcpy(TpBuff, &TempBuf[DataLength], 6);//RecDataLenΪ�����򡢵�ַ���û��������ܳ��ȣ�
		//Ӧ����DataLength+6������ͷ��-6��ʱ��У����������
		DataLength = DataLength - 6;//�û���������ܳ���cb
	}
	StationAddr = (TempBuf[11] >> 1) & 0xff;//�ӱ����л����վ��ַ
	//*******************************************************
	GwAddr[4] = StationAddr << 1;//��վ��ַ���浽��������

	if ((TempBuf[6] & 0x0f) != 0){
		for (i = 0; i < 4; i++)
		{
			SdPrintf(YNPrint," ","[%02x]",GwAddr[i]);
			SdPrintf(YNPrint," " ,"%02x",TempBuf[7+i]);
			if (GwAddr[i] != TempBuf[7 + i])
			{
				SdPrintf(YNPrint,PreFix,"�����ն˵�ַ:%02x%02x(A1) %02x%02x(A2) %02x(A3)",GwAddr[0],GwAddr[1],GwAddr[2],GwAddr[3],GwAddr[4]);
				SdPrintf(YNPrint,PreFix,"���ݰ��е�ַ:%02x%02x(A1) %02x%02x(A2) %02x(A3)",TempBuf[7],TempBuf[8],TempBuf[9],TempBuf[10],TempBuf[11]);
				SdPrintf(YNPrint,PreFix,"�ն˵�ַ�뱾��������");
				return ERR_DIFF_ADDR;
			}
		}
	}
//	ClearThreadTimes(ProjectNo);
	Fseq = TempBuf[13] & 0x0f;//֡������SEQ�еĺ���λ����Ӧ����֡���PSEQ����Ӧ֡���RSEQ
//	SdPrint("\n\rseq=%d ",Fseq);
	AutoFlg = 0;
	PrmFlg = 0;
//	INT8U GuangBoflag;//mac
//	INT8U ZuAdressflag;
	if(((TempBuf[11]&0x01)==1)&&(TempBuf[9]==0xff)&&(TempBuf[10]==0xff))
		GuangBoflag=1;
	else
		GuangBoflag=0;

//	if(((TempBuf[11]&0x01)==1)&&((TempBuf[9]!=0xff)||(TempBuf[10]!=0xff)))
//		Jmemory->jzq.ZuAdressflag = 1;
//	else
//		Jmemory->jzq.ZuAdressflag = 0;
	groupNo = 0;
//	if (Jmemory->jzq.ZuAdressflag == 1)
	if(((TempBuf[11]&0x01)==1)&&((TempBuf[9]!=0xff)||(TempBuf[10]!=0xff)))
	{//�ն����ַ���ǹ㲥��ַ�����жϸ����ַ�Ƿ�Ϊ���ն����ַ�����8�����ַ��
		if ((JSetPara_AFN04_3761_2009->group1.f6.GroupAdress0[1] == TempBuf[10])&&(JSetPara_AFN04_3761_2009->group1.f6.GroupAdress0[0] == TempBuf[9]))
					groupNo = 1;
		if ((JSetPara_AFN04_3761_2009->group1.f6.GroupAdress1[1] == TempBuf[10])&&(JSetPara_AFN04_3761_2009->group1.f6.GroupAdress1[0] == TempBuf[9]))
			groupNo = 2;
		if ((JSetPara_AFN04_3761_2009->group1.f6.GroupAdress2[1] == TempBuf[10])&&(JSetPara_AFN04_3761_2009->group1.f6.GroupAdress2[0] == TempBuf[9]))
			groupNo = 3;
		if ((JSetPara_AFN04_3761_2009->group1.f6.GroupAdress3[1] == TempBuf[10])&&(JSetPara_AFN04_3761_2009->group1.f6.GroupAdress3[0] == TempBuf[9]))
			groupNo = 4;
		if ((JSetPara_AFN04_3761_2009->group1.f6.GroupAdress4[1] == TempBuf[10])&&(JSetPara_AFN04_3761_2009->group1.f6.GroupAdress4[0] == TempBuf[9]))
			groupNo = 5;
		if ((JSetPara_AFN04_3761_2009->group1.f6.GroupAdress5[1] == TempBuf[10])&&(JSetPara_AFN04_3761_2009->group1.f6.GroupAdress5[0] == TempBuf[9]))
			groupNo = 6;
		if ((JSetPara_AFN04_3761_2009->group1.f6.GroupAdress6[1] == TempBuf[10])&&(JSetPara_AFN04_3761_2009->group1.f6.GroupAdress6[0] == TempBuf[9]))
			groupNo = 7;
		if ((JSetPara_AFN04_3761_2009->group1.f6.GroupAdress7[1] == TempBuf[10])&&(JSetPara_AFN04_3761_2009->group1.f6.GroupAdress7[0] == TempBuf[9]))
			groupNo = 8;
	}
//	printf("\n Jmemory->jzq.GuangBoflag=%d Jmemory->jzq.ZuAdressflag=%d groupNo=%d\n",Jmemory->jzq.GuangBoflag,Jmemory->jzq.ZuAdressflag,groupNo);
	/*
	 *
			��2 �����붨�壨PRM=1��
			������  ֡����  ������
			0  ����  ����
			1  ����ȷ��  ��λ����
			2��3  ����  ����
			4  �����޻ش�  �û�����
			5��8  ����  ����
			9  ������Ӧ֡  ��·����
			10  ������Ӧ֡  ����1 ������
			11  ������Ӧ֡  ����2 ������
			12��15  ����  ����
	 * */
	//	if ((TempBuf[6] & 0x0f) == 0) {


	if((TempBuf[6]&0x0f) == 0){ //ȷ��
		SdPrintf(YNPrint,PreFix,"֡���ͣ�ȷ��(0)");
		return RemoteAnswer();
	}
	if((TempBuf[6]&0x0f) == 1)//	if ((TempBuf[6] & 0x0f) == 1)
	{
		SdPrintf(YNPrint,PreFix,"֡���ͣ���λ����(1)");
		//mac
//		SdPrint("\n\r%s","��վ��λ����\n\r");
//		printf(" ��֤���� %d NeedTP=%d DataLength=%d groupNo=%d\n",Jmemory->jzq.f5.XiaoXi_Renzheng_FangAN,NeedTp,DataLength,groupNo);
		//if(Jmemory->jzq.f5.XiaoXi_Renzheng_FangAN==0xFF)//ר��Ӳ����֤����
		if(JSetPara_AFN04_3761_2009->group1.f5.XiaoXi_Renzheng_FangAN == 0xFF)
		{
			//if (NeedTp == 0)//Tp��Ч //cuo
				macindex = DataLength + 6 - 16;
			//else
			//	macindex = DataLength + 6 - 22;
      //�Ժ��ٲ�
     		MacOk = CheckMac(&TempBuf[12],DataLength-22,0x01,groupNo,&TempBuf[macindex],GuangBoflag);//RecDataLen + 6 -16
				if (MacOk ==1)
					ResetControl();
		}else  {
//			ResetControl();//�ն˿�������
			ResetControl();
		}
		return J_RESET;
	} //��λ
//	if ((TempBuf[6] & 0x0f) == 9) {
	if((TempBuf[6] &0x0f) == 9){
		SdPrintf(YNPrint,PreFix,"֡���ͣ����Ӳ���(9)");
		return LinkTest();
	} //��·����
#ifndef DINGXINGLIANTIAO
//	if((TempBuf[6] & 0x0f)== 10)
	{
		SdPrintf(YNPrint,PreFix,"֡���ͣ�����1������(10)");
		ret = AskOneLevelData();

	} //�ٻ�1������
//	if((TempBuf[6]&0x0f)==11)
	if(ret == J_ALLNAK)
	{
		SdPrintf(YNPrint,PreFix,"֡���ͣ�����2������(11)");
		ret = AskTwoLevelData();
	} //�ٻ�2������
#else
	if ((TempBuf[6] & 0x0f) == 10 || (TempBuf[6] & 0x0f) == 11) {//��϶�������
			AskTwoLevelDataDingXin();
			return;
		} //�ٻ�1������
#endif
	   //[12]:AFN-0FH���ļ�����
	if(((TempBuf[6]&0x0f)==14) || (TempBuf[12]==0x0f)){
			GetDa(TempBuf[14], TempBuf[15]);
			GetDt(TempBuf[16], TempBuf[17]);
			if (DT[1] == 1) {   //F1
				Jproginfo->Para.UpdateFlags = 1; //zbupdate
				delay(100);
				FileTrans();
			}
			else if(DT[97] == 1) //F97
			{

			}
			else if(DT[98] == 1)//F98
			{

			}
		return 0;
	} //�ļ�����
//	SdPrint("\n\r NOT PROCESS!!! %d ",TempBuf[6]&0x0f);
	if(ret == -1){
		SendALLNAK(0);
		ret = J_ALLNAK;
	}
	return ret;
}

void PrintZone()
{
	switch(zone_so&0x7f)
		{
			case XINJIANG:
				SdPrintf(YNPrint,PreFix,"��������:%d,�������½�",XINJIANG);
				break;
			case JIANGSU:
				SdPrintf(YNPrint,PreFix,"��������:%d,����������",JIANGSU);
				break;
			case JIANGXI:
				SdPrintf(YNPrint,PreFix,"��������:%d,����������",JIANGXI);
				break;
			case TIANJIN:
				SdPrintf(YNPrint,PreFix,"��������:%d,���������",TIANJIN);
				break;
			case HEBEI:
				SdPrintf(YNPrint,PreFix,"��������:%d,�������ӱ�",HEBEI);
				break;
//			case GUOWANGSOFTTEST:
//				SdPrintf(YNPrint,PreFix,"��������:%d,��������������",GUOWANGSOFTTEST);
//				break;
			case SHANGHAI:
				SdPrintf(YNPrint,PreFix,"��������:%d,�������Ϻ�",SHANGHAI);
				break;
		}
		if ( (zone_so >> 7) == 1){
			SdPrintf(YNPrint,PreFix,"��������־��Ч");
		}
		else{
			SdPrintf(YNPrint,PreFix,"��������־��Ч");
		}
}
void LogSwitch(){
//	INT8U fpath[125];
//	INT8U pswitch[8];
//	memset(pswitch,0,8);
//	memset(fpath,0,125);
//	getcwd(fpath,sizeof(fpath));
//	strcat(fpath,"/j3761_2009.cfg");
//	SdPrintf(YNPrint,PreFix,"j3761_2009�����ļ�·��:%s",fpath);
//	INT32S fd = fopen(fpath,"r");
//	fgets(fpath,1,fd);
//	fclose(fd);
}
