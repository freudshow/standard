#include <inc/pubfunction.h>
#include <inc/Options.h>
#include <inc/init.h>
#include <linux/types.h>
#include <linux/spi/spidev.h>
#include <linux/i2c.h>
#include <linux/i2c-dev.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <signal.h>
#include "rtc_.h"

#define I2C_DEVNAME  "/dev/rtc0"
int fd = -1;

int open_rtc() {
	if ((fd = open(I2C_DEVNAME, O_RDWR)) < 0) {
		return 1;
	} else {
		printf("openi2c rtc ok  fd==%d\n\r",fd);
		//clear_whole_eeprom(i2cfd);
		return 0;
	}
}

int close_rtc(void)
{
   close(fd);
   return 0;
}

//**************************************************
// �������ܣ�����RTC��INT���ж���������
// ���������SEC_INT(0x03)��INT������ж�
//		   MIN_INT(0x23), INT������ж�
//**************************************************

void SetRtcInt(unsigned char type)
{
	int i;
	struct rtc_reg_rw reg0d, reg0e, reg0f;
	reg0d.reg_index = 0x0d;
	reg0d.data = 0x03;
	reg0e.reg_index = 0x0e;
	reg0e.data = 0x00;
	reg0f.reg_index = 0x0f;
	reg0f.data = 0x20;

	if(open_rtc())
		return ;

	ioctl(fd, RTC_REG_SET, &reg0f);
	ioctl(fd, RTC_REG_SET, &reg0e);

	ioctl(fd, RTC_REG_GET, &reg0d);
	//printf("\nwrite before :  read 0x0d ==%x\n",reg0d.data);
	ioctl(fd, RTC_REG_SET, &reg0d);
	for(i=0;i<100;i++);
	ioctl(fd,RTC_REG_GET,&reg0d);
	//printf("\n write after :  read 0x0d ==%x\n",reg0d.data);
//	get_rtc(&temptm);
//	data[0]=0x20;
//	data[1]=0x00;
//	data[2]=type;//0x03
//	i2c_write(fd, 0x0F, data[0], 1);
//	i2c_write(fd, 0x0E, data[1], 1);
//	i2c_write(fd, 0x0D, data[2], 1);

	close_rtc();
}
