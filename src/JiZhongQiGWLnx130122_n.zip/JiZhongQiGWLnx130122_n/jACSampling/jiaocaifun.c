#include "jiaocai.h"
extern int i2cfd;
unsigned char pagelist[7][8];
//�¶Ȳ���ϵ��
#define WDXISHU  992
#define WDXISHU_UI  9960
#define SPI1   0
int device = 0;
unsigned char cmd[1024];
#ifdef __linux__
#else
	name_attach_t *attach;
	spi_devinfo_t cfg;
	spi_cfg_t cfg_t;
#endif
INT8U Day,Month;
int i2ctype=0;
int fp=-1;
/*
 *******************************************
 *�ӿں�������
 *******************************************
 */
INT8U SpiByteSend(INT8U spi, INT8U da, INT16U to);
INT8U ATTWriteEnable(INT8U spi, INT16U to);
INT8U ATTWriteDisable(INT8U spi, INT16U to);
INT8U ATTStatusGet(INT8U spi, INT16U to);
INT8U ATTStatusSet(INT8U spi, INT8U st, INT16U to);
INT8U ATTDataRead(INT8U spi, INT32U addr, INT32U len, INT8U *buf, INT16U to);
INT8U ATTDataWrite(INT8U spi, INT32U addr, INT32U len, INT8U *buf, INT16U to);
void ATTInit();
INT32S ATTRead(INT8U spi, INT32U addr, INT32U len, INT8U *buf, INT16U to);
INT32S ATTWrite(INT8U spi, INT32U addr, INT32U len, INT8U *buf, INT16U to);
unsigned char Att24Tmp[1024];
#ifdef __linux__
	static const char *devname = "/dev/spi0.0";
	//static const char *i2cdev = "/dev/i2c-0";
	static uint8_t mode;
	static uint8_t bits = 8;
	static uint32_t speed = 400000;
	#define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))
	static void pabort(const char *s)
	{
		perror(s);
	}
#endif
//��ڲ���˵����reg ��ʼ��ַ��val ���ص���ֵ��num ����
#ifdef __linux__
static inline __s32 i2c_smbus_access(int file, char read_write, __u8 command,int size, union i2c_smbus_data *data)
{
		int re;
//		struct i2c_smbus_ioctl_data args;
//
//		args.read_write = read_write;
//		args.command = command;
//		args.size = size;
//		args.data = data;
//		re = ioctl(file,I2C_SMBUS,&args);
//		if (re<0)
//	    {
//	        printf("Can not set i2c address (%d)\n", errno);
//	    }
//		printf("\n\r i2c ioctl re = %d",re);
		return re;
}

static inline __s32 i2c_smbus_write_byte_data(int file, __u8 command,__u8 value)
{
		union i2c_smbus_data data;
		data.byte = value;
		return i2c_smbus_access(file,I2C_SMBUS_WRITE,command,I2C_SMBUS_BYTE_DATA, &data);
}
static inline __s32 i2c_smbus_read_byte_data(int file, __u8 command)
{
		union i2c_smbus_data data;
		if (i2c_smbus_access(file,I2C_SMBUS_READ,command,
							 I2C_SMBUS_BYTE_DATA,&data))
				return -1;
		else
				return 0x0FF & data.byte;
}
int i2c_read(int fd, unsigned char reg, unsigned char *val, unsigned char num)
{
	int retries;
	for(retries=5; retries; retries--)
		if(write(fd, &reg, 1)==1)
			if(read(fd, val, 1)==1)
				return 0;
	return -1;
}
int i2c_write(int fd, unsigned char reg, unsigned char val, unsigned char num)
{
	int retries;
	unsigned char data[2];

	data[0] = reg;
	data[1] = val;
	for(retries=5; retries; retries--)
	{
		if(write(fd, data, 2)==2)
				return 0;
		usleep(1000*10);
	}
	return -1;
}
int spi_cmdread(int fd, uint32_t device, INT8U *cbuf, int16_t clen, INT8U *rbuf, int rlen)
{
	unsigned char tx[32],rx[32],i;
	memset(tx,0,32);
	memset(rx,0,32);
	struct spi_ioc_transfer	xfer[2];
	memset(xfer, 0, sizeof xfer);
	for(i=0;i<clen;i++)
		tx[i]=cbuf[i];
	xfer[0].tx_buf = (int)tx;
	xfer[0].len = clen;
	//xfer[0].delay_usecs=10;

	xfer[1].rx_buf = (int) rx;
	xfer[1].len = rlen;
	//xfer[1].delay_usecs=10;
	gpio_write("gpoATT_CS",0);//yangdong
	ioctl(fd, SPI_IOC_MESSAGE(2), xfer);
	gpio_write("gpoATT_CS",1);//yangdong
	 for(i=0; i<rlen; i++)
		 rbuf[i]=rx[i];
	 return 1;
}
int spi_close(int fd)
{
	close(fd);
	return 1;
}
int spi_write(int fd, uint32_t device, INT8U *buf, int len)
{
	unsigned char tx[32],rx[32],i;
	memset(tx,0,32);
	memset(rx,0,32);
	struct spi_ioc_transfer	xfer[2];
	memset(xfer, 0, sizeof xfer);
	for(i=0;i<len;i++)
		tx[i]=buf[i];
	xfer[0].tx_buf = (int)tx;
	xfer[0].len = len;
	//xfer[0].delay_usecs=10;

	xfer[1].rx_buf = (int) rx;
	xfer[1].len = 0;
	//xfer[1].delay_usecs=10;
	gpio_write("gpoATT_CS",0);//yangdong
	ioctl(fd, SPI_IOC_MESSAGE(2), xfer);
	gpio_write("gpoATT_CS",1);//yangdong
	return len;
}
#else
	static int i2c_read(unsigned char reg, unsigned char val[], unsigned char num) {
		iov_t siov[2], riov[2];
		i2c_sendrecv_t hdr;

		hdr.slave.addr = AT24ADDR;
		hdr.slave.fmt = I2C_ADDRFMT_7BIT;
		hdr.send_len = 1;
		hdr.recv_len = num;
		hdr.stop = 1;

		SETIOV(&siov[0], &hdr, sizeof(hdr));
		SETIOV(&siov[1], &reg, sizeof(reg));

		SETIOV(&riov[0], &hdr, sizeof(hdr));
		SETIOV(&riov[1], val, num);

		return devctlv(i2cfd, DCMD_I2C_SENDRECV, 2, 2, siov, riov, NULL);

	}
	//��ڲ���˵����reg ��ʼ��ַ��val Ҫд����ֵ��num ����
	//ע�⣺                    д�����ǰ���ҳ�����ġ�ÿҳ8���ֽڡ�
	//             ����    num �������Ϊ8
	static int i2c_write(unsigned char reg, unsigned char val[], unsigned char num) {
		iov_t siov[3];
		i2c_send_t hdr;

		hdr.slave.addr = AT24ADDR;
		hdr.slave.fmt = I2C_ADDRFMT_7BIT;
		hdr.len = num + 1;
		hdr.stop = 1;

		SETIOV(&siov[0], &hdr, sizeof(hdr));
		SETIOV(&siov[1], &reg, sizeof(reg));
		SETIOV(&siov[2], val, num);

		return devctlv(i2cfd, DCMD_I2C_SEND, 3, 0, siov, NULL, NULL);
	}
#endif

int openi2c() {

		i2cfd = open("/dev/i2c-1", O_RDWR);   //������д
		if(i2cfd < 0)
		{
			perror("Can't open /dev/nrf24l01 \n"); //��iic�豸�ļ�ʧ��
			fprintf(stderr,"\n\n??????????????Can't open /dev/nrf24l01 \n");
			return -1;
		}
		if(ioctl(i2cfd, I2C_SLAVE, 0x50)<0)
		{    //����iic��������ַ
			fprintf(stderr,"fail to set i2c device slave address!\n");
			close(i2cfd);
			return -1;
		}
		return(1);
}
void testi(int i, unsigned char* buf) {
#if 0
	printf("\n\r -------------------------------");
	printf("\n\r page = %d",i);
	printf("\n\r Display[0]=========%d",buf[0]);
	printf("\n\r Display[1]=========%d",buf[1]);
	printf("\n\r Display[2]=========%d",buf[2]);
#endif

}
void test2(int i, unsigned char* buf, int len, char* name) {
//#define 0
//#if 0
	int k = 0;
	printf("\n\r -------------------------------");
	printf("\n\r page = %d %s",i,name);
	for(k=0;k<len;k++)
	{
		printf("\n\r After Xiuzheng  %d",buf[k]);
	}
//#endif
}
//  ͨ�� I2C ��ȡ����ϵ��
void Read_Fk_xiu_I2C(int flag) {
	INT8U TempBuf[80];
	INT8U rbuf[128],pagetmp[8];//,rflg;
	int index = 0,i,ret;
	Day=0;Month=0;
	memset(pagetmp,0,8);
	memset(rbuf,0,128);
	index=0;
	i=0;
	ret=0;
	i2ctype=0;
	memset(TempBuf, 0, 80);

	//��ȡ�ϴα���Ľ�������
/*	rflg=1;
	if (access("/nand/DataCurr/JcData.dat", 0) == 0)
	{//printf("\n-------------------------------------------1\n");
		if (NormalReadFile("/nand/DataCurr/JcData.dat",(char *) &JDataFileInfo->jc,sizeof(JDataFileInfo->jc),JProgramInfo)==1)
		{
			delay(100);
			if (NormalReadFile("/nand/DataCurr/JcData.dat",(char *) &JDataFileInfo->jc, sizeof(JDataFileInfo->jc),JProgramInfo)==1)
			{
				delay(100);
				if (NormalReadFile("/nand/DataCurr/JcData.dat",(char *) &JDataFileInfo->jc, sizeof(JDataFileInfo->jc),JProgramInfo)==1)
				{
					memset(TempBuf,0,80);
					sprintf((char*)TempBuf,"%s /nand/DataCurr/JcData.dat.bak /nand/DataCurr/JcData.dat",_CMDCP_);
					syscmd((char*)TempBuf,JProgramInfo);
					delay(100);
					if (access("/nand/DataCurr/JcData.dat.bak", 0) == 0)	//lqq feilv ++
					{
						memset(TempBuf,0,80);
						sprintf((char*)TempBuf,"%s /nand/DataCurr/JcData.dat.bak /nand/DataCurr/JcData.dat",_CMDCP_);
						syscmd((char*)TempBuf,JProgramInfo);
						delay(100);
					}
					else
					{
						if (access("/nand/DataCurr",0)!=0)//��Ŀ¼�����ڣ��ȴ���
						{
							memset(TempBuf,0,80);
							sprintf((char*)TempBuf,"%s /nand/DataCurr",_CMDMKDIR_);
							syscmd((char*)TempBuf,JProgramInfo);
							delay(100);
						 }
//						memset(&JDataFileInfo->jc,0,sizeof(JcData));
//						fprintf(stderr,"\nsave .......1111      JDataFileInfo->jc.JcDdRealData.Z_P_F[0]=%d",JDataFileInfo->jc.JcDdRealData.Z_P_F[0]);
//						NormalSaveFile("/nand/DataCurr/JcData.dat",(INT8U *)&JDataFileInfo->jc,sizeof(JDataFileInfo->jc),JProgramInfo);
					}//lqq feilv ++

					if (access("/nand/DataCurr/JcData.dat.bak", 0) == 0)	//lqq feilv ++
					{
						memset(TempBuf,0,80);
						sprintf((char*)TempBuf,"%s /nand/DataCurr/JcData.dat.bak /nand/DataCurr/JcData.dat",_CMDCP_);
						syscmd((char*)TempBuf,JProgramInfo);
						delay(100);
					}
					else
					{
						if (access("/nand/DataCurr",0)!=0)//��Ŀ¼�����ڣ��ȴ���
						{
							memset(TempBuf,0,80);
							sprintf((char*)TempBuf,"%s /nand/DataCurr",_CMDMKDIR_);
							syscmd((char*)TempBuf,JProgramInfo);
							delay(100);
						 }
//						memset(&JDataFileInfo->jc,0,sizeof(JcData));
//						fprintf(stderr,"\nsave .......1111      JDataFileInfo->jc.JcDdRealData.Z_P_F[0]=%d",JDataFileInfo->jc.JcDdRealData.Z_P_F[0]);
//						NormalSaveFile("/nand/DataCurr/JcData.dat",(INT8U *)&JDataFileInfo->jc,sizeof(JDataFileInfo->jc),JProgramInfo);
					}//lqq feilv ++



					if (NormalReadFile("/nand/DataCurr/JcData.dat",(char *) &JDataFileInfo->jc,sizeof(JDataFileInfo->jc),JProgramInfo)==1)
					{
						delay(100);
						if (NormalReadFile("/nand/DataCurr/JcData.dat",(char *) &JDataFileInfo->jc, sizeof(JDataFileInfo->jc),JProgramInfo)==1)
						{
							delay(100);
							if (NormalReadFile("/nand/DataCurr/JcData.dat",(char *) &JDataFileInfo->jc, sizeof(JDataFileInfo->jc),JProgramInfo)==1)
							{
								rflg=0;
							}
						}
					}
				}
			}
		}
	}else
		rflg=0;
	if (rflg==1)
	{
		memset(TempBuf,0,80);
		sprintf((char*)TempBuf,"%s /nand/DataCurr/JcData.dat /nand/DataCurr/JcData.dat.bak",_CMDCP_);
		syscmd((char*)TempBuf,JProgramInfo);
	}
	delay(100);
*/
	if(JDataFileInfo->jc.JcDdRealData.Z_P_All==-1)
		JDataFileInfo->jc.JcDdRealData.Z_P_All=0;
	if(JDataFileInfo->jc.JcDdRealData.F_P_All==-1)
		JDataFileInfo->jc.JcDdRealData.F_P_All=0;
	if(JDataFileInfo->jc.JcDdRealData.Z_Q_All==-1)
		JDataFileInfo->jc.JcDdRealData.Z_Q_All=0;
	if(JDataFileInfo->jc.JcDdRealData.F_Q_All==-1)
		JDataFileInfo->jc.JcDdRealData.F_Q_All=0;
	if(JDataFileInfo->jc.JcDdRealData.X1_Q_All==-1)
		JDataFileInfo->jc.JcDdRealData.X1_Q_All=0;
	if(JDataFileInfo->jc.JcDdRealData.X2_Q_All==-1)
		JDataFileInfo->jc.JcDdRealData.X2_Q_All=0;
	if(JDataFileInfo->jc.JcDdRealData.X3_Q_All==-1)
		JDataFileInfo->jc.JcDdRealData.X3_Q_All=0;
	if(JDataFileInfo->jc.JcDdRealData.X4_Q_All==-1)
		JDataFileInfo->jc.JcDdRealData.X4_Q_All=0;
	for(i=0;i<FeiLvNum;i++)
	{
		if(JDataFileInfo->jc.JcDdRealData.Z_P_F[i]==-1)
			JDataFileInfo->jc.JcDdRealData.Z_P_F[i]=0;
		if(JDataFileInfo->jc.JcDdRealData.F_P_F[i]==-1)
			JDataFileInfo->jc.JcDdRealData.F_P_F[i]=0;
		if(JDataFileInfo->jc.JcDdRealData.Z_Q_F[i]==-1)
			JDataFileInfo->jc.JcDdRealData.Z_Q_F[i]=0;
		if(JDataFileInfo->jc.JcDdRealData.F_Q_F[i]==-1)
			JDataFileInfo->jc.JcDdRealData.F_Q_F[i]=0;
		if(JDataFileInfo->jc.JcDdRealData.X1_F_Q[i]==-1)
			JDataFileInfo->jc.JcDdRealData.X1_F_Q[i]=0;
		if(JDataFileInfo->jc.JcDdRealData.X4_F_Q[i]==-1)
			JDataFileInfo->jc.JcDdRealData.X4_F_Q[i]=0;
		if(JDataFileInfo->jc.JcDdRealData.X2_F_Q[i]==-1)
			JDataFileInfo->jc.JcDdRealData.X2_F_Q[i]=0;
		if(JDataFileInfo->jc.JcDdRealData.X3_F_Q[i]==-1)
			JDataFileInfo->jc.JcDdRealData.X3_F_Q[i]=0;
	}

	//��ȡ������������ϵ��
	memset(TempBuf,0,80);
	sprintf((char*)TempBuf,"%s/JcXiu.par",_PARADIR_); //yangdongac
	if (access((char*)TempBuf, 0) == 0)
	{
//		fprintf(stderr,"read JcXiu.par\n\r");
		if (NormalReadFile((char*)TempBuf,(char *) &JConfigInfo->jcxs,sizeof(JConfigInfo->jcxs),JProgramInfo)==1)
		{
			delay(100);
			if (NormalReadFile((char*)TempBuf,(char *) &JConfigInfo->jcxs, sizeof(JConfigInfo->jcxs),JProgramInfo)==1)
			{
				delay(100);
				if (NormalReadFile((char*)TempBuf,(char *) &JConfigInfo->jcxs, sizeof(JConfigInfo->jcxs),JProgramInfo)==1)
				{
					memset(TempBuf,0,80);
					sprintf((char*)TempBuf,"%s %s/JcXiu.par.bak %s/JcXiu.par",_CMDCP_,_PARADIR_,_PARADIR_);
					syscmd((char*)TempBuf,JProgramInfo);
					delay(100);
					memset(TempBuf,0,80);
					sprintf((char*)TempBuf,"%s/JcXiu.par",_PARADIR_);
					if (NormalReadFile((char*)TempBuf,(char *) &JConfigInfo->jcxs,sizeof(JConfigInfo->jcxs),JProgramInfo)==1)
					{
						delay(100);
						if (NormalReadFile((char*)TempBuf,(char *) &JConfigInfo->jcxs, sizeof(JConfigInfo->jcxs),JProgramInfo)==1)
						{
							delay(100);
							NormalReadFile((char*)TempBuf,(char *) &JConfigInfo->jcxs, sizeof(JConfigInfo->jcxs),JProgramInfo);
						}
					}
				}
			}
		}
	}else
	{
		if(access("/nor/para/", 0)!=0)
			system("mkdir /nor/para");
		system("cp /nor/para/JcXiu.par /nand/para/JcXiu.par");
	}
	//-----------------------------
	char tttt[100];
	memset(tttt,0,100);
	sprintf(tttt,"echo 'UA_xishu = %02x  %02x  %02x' >/nand/bin/tttt.txt",JConfigInfo->jcxs.displayUA_xishu[0],JConfigInfo->jcxs.displayUA_xishu[1],JConfigInfo->jcxs.displayUA_xishu[2]);
	system(tttt);
	JDataFileInfo->jc.JcXuLiangCalc.Offset=0;//-----lcy ��֤ÿ��ϵͳ����ʱǰ15���Ӳ���������
//#endif
#ifdef SAVEI2C
#ifdef __linux__

	if (openi2c()==1)
	{
		SdPrint("\n read i2c-------read i2c \n ");
		delay(10);
		for (i = 0; i < 128; i++) {
			ret = i2c_read(i2cfd, i, &rbuf[i], 1);
			delay(10);
		}
		if (i2cfd > 0)
			close(i2cfd);
		memcpy(pagetmp, rbuf + index, 8);
		JDataFileInfo->jc.jcxs.displayUA_xishu[0] = pagetmp[0];
		JDataFileInfo->jc.jcxs.displayUA_xishu[1] = pagetmp[1];
		JDataFileInfo->jc.jcxs.displayUA_xishu[2] = pagetmp[2];
		testi(index, JDataFileInfo->jc.jcxs.displayUA_xishu);
		JDataFileInfo->jc.jcxs.displayUB_xishu[0] = pagetmp[4];
		JDataFileInfo->jc.jcxs.displayUB_xishu[1] = pagetmp[5];
		JDataFileInfo->jc.jcxs.displayUB_xishu[2] = pagetmp[6];
		testi(index, JDataFileInfo->jc.jcxs.displayUB_xishu);
		index = index + 8;
		delay(10);

		memcpy(pagetmp, rbuf + index, 8);
		JDataFileInfo->jc.jcxs.displayUC_xishu[0] = pagetmp[0];
		JDataFileInfo->jc.jcxs.displayUC_xishu[1] = pagetmp[1];
		JDataFileInfo->jc.jcxs.displayUC_xishu[2] = pagetmp[2];
		testi(index, JDataFileInfo->jc.jcxs.displayUC_xishu);
		JDataFileInfo->jc.jcxs.displayIA_xishu[0] = pagetmp[4];
		JDataFileInfo->jc.jcxs.displayIA_xishu[1] = pagetmp[5];
		JDataFileInfo->jc.jcxs.displayIA_xishu[2] = pagetmp[6];
		testi(index, JDataFileInfo->jc.jcxs.displayIA_xishu);
		index = index + 8;
		delay(10);

		memcpy(pagetmp, rbuf + index, 8);
		JDataFileInfo->jc.jcxs.displayIB_xishu[0] = pagetmp[0];
		JDataFileInfo->jc.jcxs.displayIB_xishu[1] = pagetmp[1];
		JDataFileInfo->jc.jcxs.displayIB_xishu[2] = pagetmp[2];
		testi(index, JDataFileInfo->jc.jcxs.displayIB_xishu);
		JDataFileInfo->jc.jcxs.displayIC_xishu[0] = pagetmp[4];
		JDataFileInfo->jc.jcxs.displayIC_xishu[1] = pagetmp[5];
		JDataFileInfo->jc.jcxs.displayIC_xishu[2] = pagetmp[6];
		testi(index, JDataFileInfo->jc.jcxs.displayIC_xishu);
		index = index + 8;
		delay(10);

		memcpy(pagetmp, rbuf + index, 8);
		JDataFileInfo->jc.jcxs.displayI0_xishu[0] = pagetmp[0];
		JDataFileInfo->jc.jcxs.displayI0_xishu[1] = pagetmp[1];
		JDataFileInfo->jc.jcxs.displayI0_xishu[2] = pagetmp[2];
		testi(index, JDataFileInfo->jc.jcxs.displayI0_xishu);
		JDataFileInfo->jc.jcxs.displayPA_xishu[0] = pagetmp[4];
		JDataFileInfo->jc.jcxs.displayPA_xishu[1] = pagetmp[5];
		JDataFileInfo->jc.jcxs.displayPA_xishu[2] = pagetmp[6];
		testi(index, JDataFileInfo->jc.jcxs.displayPA_xishu);
		index = index + 8;
		delay(10);

		memcpy(pagetmp, rbuf + index, 8);
		JDataFileInfo->jc.jcxs.displayPB_xishu[0] = pagetmp[0];
		JDataFileInfo->jc.jcxs.displayPB_xishu[1] = pagetmp[1];
		JDataFileInfo->jc.jcxs.displayPB_xishu[2] = pagetmp[2];
		testi(index, JDataFileInfo->jc.jcxs.displayPB_xishu);
		JDataFileInfo->jc.jcxs.displayPC_xishu[0] = pagetmp[4];
		JDataFileInfo->jc.jcxs.displayPC_xishu[1] = pagetmp[5];
		JDataFileInfo->jc.jcxs.displayPC_xishu[2] = pagetmp[6];
		testi(index, JDataFileInfo->jc.jcxs.displayPC_xishu);
		index = index + 8;
		delay(10);

		memcpy(pagetmp, rbuf + index, 8);
		JDataFileInfo->jc.jcxs.displayA_jiaoxiu[0] = pagetmp[0];
		JDataFileInfo->jc.jcxs.displayA_jiaoxiu[1] = pagetmp[1];
		JDataFileInfo->jc.jcxs.displayA_jiaoxiu[2] = pagetmp[2];
		testi(index, JDataFileInfo->jc.jcxs.displayA_jiaoxiu);
		JDataFileInfo->jc.jcxs.displayB_jiaoxiu[0] = pagetmp[4];
		JDataFileInfo->jc.jcxs.displayB_jiaoxiu[1] = pagetmp[5];
		JDataFileInfo->jc.jcxs.displayB_jiaoxiu[2] = pagetmp[6];
		testi(index, JDataFileInfo->jc.jcxs.displayB_jiaoxiu);
		index = index + 8;
		delay(10);

		memcpy(pagetmp, rbuf + index, 8);
		JDataFileInfo->jc.jcxs.displayC_jiaoxiu[0] = pagetmp[0];
		JDataFileInfo->jc.jcxs.displayC_jiaoxiu[1] = pagetmp[1];
		JDataFileInfo->jc.jcxs.displayC_jiaoxiu[2] = pagetmp[2];
		testi(index, JDataFileInfo->jc.jcxs.displayC_jiaoxiu);
		JDataFileInfo->jc.jcxs.displayMC_out_xishu[0] = pagetmp[4];
		JDataFileInfo->jc.jcxs.displayMC_out_xishu[1] = pagetmp[5];
		JDataFileInfo->jc.jcxs.displayMC_out_xishu[2] = pagetmp[6];
		testi(index, JDataFileInfo->jc.jcxs.displayMC_out_xishu);
	}
#endif
#endif
	return;
}
void readrec() {

	INT8U temp[3];
	temp[0] = 0x00;
	temp[1] = 0x00;
	temp[2] = 0x5A;
	ATTWrite(SPI1, 0xC6, 3, temp, 0);//ѡ���ȡУ���Ĵ�������
	sleep(1);
	ATTRead(SPI1, 0x00, 3, temp, 0);

	if ((temp[0] == 0xAA) && (temp[1] == 0xAA) && (temp[2] == 0xAA)) {
		ATTRead(SPI1, 0x02, 3, temp, 0);
		ATTRead(SPI1, 0x06, 3, temp, 0);
		ATTRead(SPI1, 0x09, 3, temp, 0);
		ATTRead(SPI1, 0x07, 3, temp, 0);
		ATTRead(SPI1, 0x0A, 3, temp, 0);
		ATTRead(SPI1, 0x08, 3, temp, 0);
		ATTRead(SPI1, 0x0B, 3, temp, 0);
	}
	temp[0] = 0x00;
	temp[1] = 0x00;
	temp[1] = 0x00;
	ATTWrite(SPI1, 0xc6, 3, temp, 0);//ѡ���ȡУ���Ĵ�������
}
//�ϱ��������й����޹�����10����
//��ѹ����10������������1000����
//�ϱ�����
void SinglePQUIA()
{
	float tempJiaoChaA=0,tempAPgain=0,tempUAgain=0,tempIAgain=0;
	short JiaoChaA,APgain,UAgain,IAgain;
	INT8U temp[3],i,mod_a;
	INT32S ATT_PA,ATT_QA,SUM_PA,SUM_QA;
	INT32S ATT_UA,ATT_IA,SUM_UA,SUM_IA;
	float temp1,temp2;
	SUM_PA=SUM_QA=SUM_UA=SUM_IA=0;
	for(i=0;i<ReadCount;i++)
	{
		//���й����޹��Ĵ���ֵ
		SUM_PA=SUM_PA+ATTRead(SPI1, 0x01, 3, temp, 0);
		SUM_QA=SUM_QA+ATTRead(SPI1, 0x05, 3, temp, 0);
		//����ѹ�������Ĵ���ֵ
		SUM_UA=SUM_UA+ATTRead(SPI1, 0x0D, 3, temp, 0);
		SUM_IA=SUM_IA+ATTRead(SPI1, 0x10, 3, temp, 0);
		delay(400);
//		fprintf(stderr,"\n\r SUM_PA==%x [%d]",SUM_PA,SUM_PA);
//		fprintf(stderr,"\n\r SUM_QA==%x [%d]",SUM_QA,SUM_QA);
		fprintf(stderr,"\n\r SUM_UA==%x [%d]",SUM_UA,SUM_UA);
		printf("\n\r SUM_UA==%x [%d]",SUM_UA,SUM_UA);
//		fprintf(stderr,"\n\r SUM_IA==%x [%d]",SUM_IA,SUM_IA);
	}

	ATT_PA = SUM_PA/ReadCount;
	ATT_QA = SUM_QA/ReadCount;

	ATT_UA = SUM_UA/ReadCount;
	ATT_IA = SUM_IA/ReadCount;

//	ATT_PA = ATTRead(SPI1, 0x01, 3, temp, 0);
//	ATT_QA = ATTRead(SPI1, 0x05, 3, temp, 0);
//
//	//����ѹ�������Ĵ���ֵ
//	ATT_UA = ATTRead(SPI1, 0x0D, 3, temp, 0);
//	ATT_IA = ATTRead(SPI1, 0x10, 3, temp, 0);
	fprintf(stderr,"\n\r PA==%x [%d]",ATT_PA,ATT_PA);
	fprintf(stderr,"\n\r QA==%x [%d]",ATT_QA,ATT_QA);
	fprintf(stderr,"\n\r UA==%x [%d]",ATT_UA,ATT_UA);
	fprintf(stderr,"\n\r IA==%x [%d]",ATT_IA,ATT_IA);

    //�����������ֵ
	if (ATT_PA > 8388608)//2^23
		ATT_PA = ATT_PA -16777216;//2^24
	ATT_PA = ATT_PA*1.0/756*100;
	fprintf(stderr,"\n\r PA/256==%x [%d]",ATT_PA,ATT_PA);

	if (ATT_QA > 8388608)//2^23
		ATT_QA = ATT_QA -16777216;//2^24
	ATT_QA = (ATT_QA*1.0/756)*1.0005*100;//1.0005Ϊ�޹��㷨���ڵ�����
	fprintf(stderr,"\n\r QA/256==%x [%d]",ATT_QA,ATT_QA);

	//����ǲ�У��ֵ(Preal*Q-P*Qreal)/(P*Preal+Q*Qreal);
	temp1=JConfigInfo->jcxs.PrealA*ATT_QA - ATT_PA*JConfigInfo->jcxs.QrealA;//8yue9hao
	temp2=ATT_PA*JConfigInfo->jcxs.PrealA + ATT_QA*JConfigInfo->jcxs.QrealA;
	if(temp2!=0)
		tempJiaoChaA=temp1*1.0/temp2;
	fprintf(stderr,"\n\r tempJiaoChaA==%f",tempJiaoChaA);

	if (tempJiaoChaA>=0)
	{
		mod_a=(int)(tempJiaoChaA*32768*10)%10;//2^15=32768
		fprintf(stderr,"\n\r mod_a 1==%d",mod_a);
		if(mod_a>=5)
			JiaoChaA = floor(tempJiaoChaA * 32768)+1;
		else
			JiaoChaA = floor(tempJiaoChaA * 32768);
	}else
	{
		mod_a=(int)((65536 + tempJiaoChaA * 32768)*10)%10;
		if(mod_a>=5)
			JiaoChaA = floor(65536 + tempJiaoChaA * 32768)+1;
		else
			JiaoChaA = floor(65536 + tempJiaoChaA * 32768);
	}

	//У���ǲ��Ĺ���ֵ
	ATT_PA=ATT_PA+ATT_QA*tempJiaoChaA;

	//��������У��ֵ
	if(ATT_PA!=0)
		tempAPgain=JConfigInfo->jcxs.PrealA*100*1.0/ATT_PA-1;
	fprintf(stderr,"\n\r tempAPgain==%f",tempAPgain);
	if (tempAPgain>=0)
	{
		mod_a=(int)(tempAPgain*32768*10)%10;
		if(mod_a>=5)
			APgain = floor(tempAPgain * 32768)+1;
		else
			APgain = floor(tempAPgain * 32768);
	}else
	{
		mod_a=(int)((65536 + tempAPgain * 32768)*10)%10;
		fprintf(stderr,"\n\r mod_a 2==%d",mod_a);
		if(mod_a>=5)
			APgain = floor(65536 + tempAPgain * 32768)+1;
		else
			APgain = floor(65536 + tempAPgain * 32768);
	}

//	temp[0] = 0;
//	temp[1] = 0;
//	temp[2] = 0x5a;
//	ATTWrite(SPI1, 0xc9, 3, temp, 0); //����д����
	temp[0] = 0;
	temp[1] = (JiaoChaA & 0xff00) >> 8;
	temp[2] = JiaoChaA & 0xff;
//	ATTWrite(SPI1, 0x0D, 3, temp, 0);//��λУ��0  �й���λ
//	ATTWrite(SPI1, 0x10, 3, temp, 0);//��λУ��1 �޹���λ
	JConfigInfo->jcxs.displayA_jiaoxiu[0] = temp[0];
	JConfigInfo->jcxs.displayA_jiaoxiu[1] = temp[1];
	JConfigInfo->jcxs.displayA_jiaoxiu[2] = temp[2];

	temp[0] = 0;
	temp[1] = (APgain & 0xff00) >> 8;
	temp[2] = APgain & 0xff;
//	ATTWrite(SPI1, 0x04, 3, temp, 0);//pa
//	ATTWrite(SPI1, 0x07, 3, temp, 0);//qa
//	ATTWrite(SPI1, 0x0A, 3, temp, 0);//sa
	JConfigInfo->jcxs.displayPA_xishu[0] = temp[0];
	JConfigInfo->jcxs.displayPA_xishu[1] = temp[1];
	JConfigInfo->jcxs.displayPA_xishu[2] = temp[2];
	fprintf(stderr,"\n\rAPgain==%d  JiaoChaA==%d",APgain,JiaoChaA);//�ǲ�У��ֵ�͹�������У��ֵд��i2c

	//��ѹ������У��
	//���������ѹ������Чֵ
	ATT_UA=ATT_UA*1.0/8192*100; //*100��Ϊ�˱�ס��ѹС�����2λ����֤���ȡ�
	ATT_IA=ATT_IA*1.0/8192*10000;//*10000��Ϊ�˱�ס����С�����3λ����֤���ȡ�
	fprintf(stderr,"\n\r celiang UA==%x [%d]",ATT_UA,ATT_UA);
	fprintf(stderr,"\n\r celiang IA==%x [%d]",ATT_IA,ATT_IA);

	//�����ѹ��������ЧֵУ��ϵ��
	if(ATT_UA!=0)
		tempUAgain=JConfigInfo->jcxs.UrealA*100*1.0/ATT_UA-1;
	fprintf(stderr,"\n\r tempUAgain==%f",tempUAgain);
	if (tempUAgain>=0)
	{
		mod_a=(int)(tempUAgain*32768*10)%10;
		fprintf(stderr,"\n\r mod_a 3==%d",mod_a);
		if(mod_a>=5)
			UAgain = floor(tempUAgain * 32768)+1;
		else
			UAgain = floor(tempUAgain * 32768);
	}else
	{
		mod_a=(int)(65536 + tempUAgain*32768*10)%10;
		if(mod_a>=5)
			UAgain = floor(65536 + tempUAgain * 32768)+1;
		else
			UAgain = floor(65536 + tempUAgain * 32768);
	}
	if(ATT_IA!=0)
		tempIAgain=JConfigInfo->jcxs.IrealA*10000*1.0/ATT_IA-1;
	fprintf(stderr,"\n\r tempIAgain==%f",tempIAgain);
	if (tempIAgain>=0)
	{
		mod_a=(int)(tempIAgain*32768*10)%10;
		if(mod_a>=5)
			IAgain = floor(tempIAgain * 32768)+1;
		else
			IAgain = floor(tempIAgain * 32768);
	}else
	{
		mod_a=(int)((65536 + tempIAgain * 32768)*10)%10;
		fprintf(stderr,"\n\r mod_a 4==%d",mod_a);
		if(mod_a>=5)
			IAgain = floor(65536 + tempIAgain * 32768)+1;
		else
			IAgain = floor(65536 + tempIAgain * 32768);
	}
	temp[0] = 0;
	temp[1] = (UAgain & 0xff00) >> 8;
	temp[2] = UAgain & 0xff;
	//ATTWrite(SPI1, 0x17, 3, temp, 0);
	JConfigInfo->jcxs.displayUA_xishu[0] = temp[0];
	JConfigInfo->jcxs.displayUA_xishu[1] = temp[1];
	JConfigInfo->jcxs.displayUA_xishu[2] = temp[2];
	fprintf(stderr,"\n\rtemp[0] = %x,temp[1] = %x,temp[2] = %x",temp[0],temp[1],temp[2]);
	temp[0] = 0;
	temp[1] = (IAgain & 0xff00) >> 8;
	temp[2] = IAgain & 0xff;
	//ATTWrite(SPI1, 0x1A, 3, temp, 0);
	JConfigInfo->jcxs.displayIA_xishu[0] = temp[0];
	JConfigInfo->jcxs.displayIA_xishu[1] = temp[1];
	JConfigInfo->jcxs.displayIA_xishu[2] = temp[2];
	fprintf(stderr,"\n\rUAgain==%d  IAgain==%d",UAgain,IAgain);
	fprintf(stderr,"\n\r[ pquia end ]\n");
//	temp[0] = 0;
//	temp[1] = 0;
//	temp[2] = 1;
//	ATTWrite(SPI1, 0xc9, 3, temp, 0); //������д����
	return;
}
void SinglePQUIB()
{
	float tempJiaoChaB=0,tempBPgain=0,tempUBgain=0,tempIBgain=0;
	short JiaoChaB,BPgain,UBgain,IBgain;//jiaocai
	INT8U temp[3],i,mod_b;
	INT32S ATT_PB,ATT_QB,SUM_PB,SUM_QB;
	INT32S ATT_UB,ATT_IB,SUM_UB,SUM_IB;
	float temp1,temp2;
	SUM_PB=SUM_QB=SUM_UB=SUM_IB=0;

	for(i=0;i<ReadCount;i++)
	{
		//���й����޹��Ĵ���ֵ
		SUM_PB=SUM_PB+ATTRead(SPI1, 0x02, 3, temp, 0);
		SUM_QB=SUM_QB+ATTRead(SPI1, 0x06, 3, temp, 0);
		//����ѹ�������Ĵ���ֵ
		SUM_UB=SUM_UB+ATTRead(SPI1, 0x0E, 3, temp, 0);
		SUM_IB=SUM_IB+ATTRead(SPI1, 0x11, 3, temp, 0);
		delay(400);
//		fprintf(stderr,"\n\r SUM_PB==%x [%d]",SUM_PB,SUM_PB);
//		fprintf(stderr,"\n\r SUM_QB==%x [%d]",SUM_QB,SUM_QB);
//		fprintf(stderr,"\n\r SUM_UB==%x [%d]",SUM_UB,SUM_UB);
//		fprintf(stderr,"\n\r SUM_IB==%x [%d]",SUM_IB,SUM_IB);
	}
	ATT_PB = SUM_PB/ReadCount;
	ATT_QB = SUM_QB/ReadCount;
	ATT_UB = SUM_UB/ReadCount;
	ATT_IB = SUM_IB/ReadCount;
//	//���й����޹��Ĵ���ֵ
//	ATT_PB = ATTRead(SPI1, 0x02, 3, temp, 0);
//	ATT_QB = ATTRead(SPI1, 0x06, 3, temp, 0);
//
//	//����ѹ�������Ĵ���ֵ
//	ATT_UB = ATTRead(SPI1, 0x0E, 3, temp, 0);
//	ATT_IB = ATTRead(SPI1, 0x11, 3, temp, 0);
	fprintf(stderr,"\n\r sizeof short ==%d",sizeof(short));
	fprintf(stderr,"\n\r PB==%x [%d]",ATT_PB,ATT_PB);
	fprintf(stderr,"\n\r QB==%x [%d]",ATT_QB,ATT_QB);
	fprintf(stderr,"\n\r UB==%x [%d]",ATT_UB,ATT_UB);
	fprintf(stderr,"\n\r IB==%x [%d]",ATT_IB,ATT_IB);

    //�����������ֵ
	if (ATT_PB > 8388608)
		ATT_PB = ATT_PB -16777216;
	ATT_PB = ATT_PB*1.0/756*100;
	fprintf(stderr,"\n\r PB/256==%x [%d]",ATT_PB,ATT_PB);

	if (ATT_QB > 8388608)
		ATT_QB = ATT_QB -16777216;
	ATT_QB = (ATT_QB*1.0/756)*1.0005*100;//1.0005Ϊ�޹��㷨���ڵ�����
	fprintf(stderr,"\n\r QB/256==%x [%d]",ATT_QB,ATT_QB);

	//����ǲ�У��ֵ(Preal*Q-P*Qreal)/(P*Preal+Q*Qreal);
	temp1=JConfigInfo->jcxs.PrealB*ATT_QB-ATT_PB*JConfigInfo->jcxs.QrealB;
	temp2=ATT_PB*JConfigInfo->jcxs.PrealB+ATT_QB*JConfigInfo->jcxs.QrealB;
	fprintf(stderr,"\n\r ");
	if(temp2!=0)
		tempJiaoChaB=temp1*1.0/temp2;

	fprintf(stderr,"\n\r temp1==%f,temp2==%f,tempJiaoChaB=%f",temp1,temp2,tempJiaoChaB);
	if (tempJiaoChaB>=0)
	{
		mod_b=(int)((tempJiaoChaB * 32768)*10)%10;
		fprintf(stderr,"\n\r mod_b 1==%d",mod_b);
		if(mod_b>=5)
			JiaoChaB = floor(tempJiaoChaB * 32768)+1;
		else
			JiaoChaB = floor(tempJiaoChaB * 32768);
	}else
	{
		mod_b=(int)((65536 + tempJiaoChaB * 32768)*10)%10;
		if(mod_b>=5)
			JiaoChaB = floor(65536 + tempJiaoChaB * 32768)+1;
		else
			JiaoChaB = floor(65536 + tempJiaoChaB * 32768);
	}
	//У���ǲ��Ĺ���ֵ
	ATT_PB=ATT_PB+ATT_QB*tempJiaoChaB;
	fprintf(stderr,"\n\r JiaoChaB== %d",JiaoChaB);
	fprintf(stderr,"\n\r У���ǲ��Ĺ���ֵ==%x [%d]",ATT_PB,ATT_PB);
	//��������У��ֵ
	if(ATT_PB!=0)
		tempBPgain=JConfigInfo->jcxs.PrealB*100*1.0/ATT_PB-1;
	fprintf(stderr,"\n\r tempBPgain==%f",tempBPgain);
	if (tempBPgain>=0)
	{
		mod_b=(int)((tempBPgain * 32768)*10)%10;
		fprintf(stderr,"\n\r mod_b 2==%d",mod_b);
		if(mod_b>=5)
			BPgain = floor(tempBPgain * 32768)+1;
		else
			BPgain = floor(tempBPgain * 32768);
	}else
	{
		mod_b=(int)((65536 + tempBPgain * 32768)*10)%10;
		fprintf(stderr,"\n\r mod_b .....==%d",mod_b);
		if(mod_b>=5)
			BPgain = floor(65536 + tempBPgain * 32768)+1;
		else
			BPgain = floor(65536 + tempBPgain * 32768);
	}
	fprintf(stderr,"\n\r1111BPgain==%d ",BPgain);
//	temp[0] = 0;
//	temp[1] = 0;
//	temp[2] = 0x5a;
//	ATTWrite(SPI1, 0xc9, 3, temp, 0); //����д����
	temp[0] = 0;
	temp[1] = (JiaoChaB & 0xff00) >> 8;
	temp[2] = JiaoChaB & 0xff;
//	ATTWrite(SPI1, 0x0E, 3, temp, 0);//��λУ��0  �й���λ
//	ATTWrite(SPI1, 0x11, 3, temp, 0);//��λУ��1 �޹���λ
	JConfigInfo->jcxs.displayB_jiaoxiu[0] = temp[0];
	JConfigInfo->jcxs.displayB_jiaoxiu[1] = temp[1];
	JConfigInfo->jcxs.displayB_jiaoxiu[2] = temp[2];

	temp[0] = 0;
	temp[1] = (BPgain & 0xff00) >> 8;
	temp[2] = BPgain & 0xff;
//	ATTWrite(SPI1, 0x05, 3, temp, 0);//pB
//	ATTWrite(SPI1, 0x08, 3, temp, 0);//qB
//	ATTWrite(SPI1, 0x0B, 3, temp, 0);//sB
	JConfigInfo->jcxs.displayPB_xishu[0] = temp[0];
	JConfigInfo->jcxs.displayPB_xishu[1] = temp[1];
	JConfigInfo->jcxs.displayPB_xishu[2] = temp[2];
	fprintf(stderr,"\n\rBPgain==%d  JiaoChaB==%d",BPgain,JiaoChaB);//�ǲ�У��ֵ�͹�������У��ֵд��i2c

	//��ѹ������У��
	//���������ѹ������Чֵ
	ATT_UB=ATT_UB*1.0/8192*100;//*10��Ϊ�˱�ס��ѹС�����2λ����֤���ȡ�
	ATT_IB=ATT_IB*1.0/8192*10000;//*1000��Ϊ�˱�ס����С�����3λ����֤���ȡ�
	fprintf(stderr,"\n\r celiang UB==%x [%d]",ATT_UB,ATT_UB);
	fprintf(stderr,"\n\r celiang IB==%x [%d]",ATT_IB,ATT_IB);
	//�����ѹ��������ЧֵУ��ϵ��
	if(ATT_UB!=0)
		tempUBgain=JConfigInfo->jcxs.UrealB*100*1.0/ATT_UB-1;
	if (tempUBgain>=0)
	{
		mod_b=(int)((tempUBgain * 32768)*10)%10;
		fprintf(stderr,"\n\r mod_b 3==%d",mod_b);
		if(mod_b>=5)
			UBgain = floor(tempUBgain * 32768)+1;
		else
			UBgain = floor(tempUBgain * 32768);
	}else
	{
		mod_b=(int)((65536 + tempUBgain * 32768)*10)%10;
		if(mod_b>=5)
			UBgain = floor(65536 + tempUBgain * 32768)+1;
		else
			UBgain = floor(65536 + tempUBgain * 32768);
	}
	if(ATT_IB!=0)
		tempIBgain=JConfigInfo->jcxs.IrealB*10000*1.0/ATT_IB-1;
	if (tempIBgain>=0)
	{
		mod_b=(int)((tempIBgain * 32768)*10)%10;
		fprintf(stderr,"\n\r mod_b 4==%d",mod_b);
		if(mod_b>=5)
			IBgain = floor(tempIBgain * 32768)+1;
		else
			IBgain = floor(tempIBgain * 32768);
	}else
	{
		mod_b=(int)((65536 + tempIBgain * 32768)*10)%10;
		fprintf(stderr,"\n\r mod_b 5==%d",mod_b);
		if(mod_b>=5)
			IBgain = floor(65536 + tempIBgain * 32768)+1;
		else
			IBgain = floor(65536 + tempIBgain * 32768);
	}
	fprintf(stderr,"\n\r tempUBgain==%f",tempUBgain);
	fprintf(stderr,"\n\r tempIBgain==%f",tempIBgain);
	temp[0] = 0;
	temp[1] = (UBgain & 0xff00) >> 8;
	temp[2] = UBgain & 0xff;
	//ATTWrite(SPI1, 0x18, 3, temp, 0);
	JConfigInfo->jcxs.displayUB_xishu[0] = temp[0];
	JConfigInfo->jcxs.displayUB_xishu[1] = temp[1];
	JConfigInfo->jcxs.displayUB_xishu[2] = temp[2];
	temp[0] = 0;
	temp[1] = (IBgain & 0xff00) >> 8;
	temp[2] = IBgain & 0xff;
	//ATTWrite(SPI1, 0x1B, 3, temp, 0);
	JConfigInfo->jcxs.displayIB_xishu[0] = temp[0];
	JConfigInfo->jcxs.displayIB_xishu[1] = temp[1];
	JConfigInfo->jcxs.displayIB_xishu[2] = temp[2];
	fprintf(stderr,"\n\rUBgain==%x [%d]  IBgain==%x [%d]",UBgain,UBgain,IBgain,IBgain);
	fprintf(stderr,"\n\r[ pquib end ]\n");
//	temp[0] = 0;
//	temp[1] = 0;
//	temp[2] = 1;
//	ATTWrite(SPI1, 0xc9, 3, temp, 0); //������д����
	return;
}
void SinglePQUIC()
{
	float tempJiaoChaC=0,tempCPgain=0,tempUCgain=0,tempICgain=0;
	short JiaoChaC,CPgain,UCgain,ICgain;
	INT8U temp[3],i,mod_c;
	INT32S ATT_PC,ATT_QC,SUM_PC,SUM_QC;
	INT32S ATT_UC,ATT_IC,SUM_UC,SUM_IC;
	float temp1,temp2;
	SUM_PC=SUM_QC=SUM_UC=SUM_IC=0;
	for(i=0;i<ReadCount;i++)
	{
		//���й����޹��Ĵ���ֵ
		SUM_PC=SUM_PC+ATTRead(SPI1, 0x03, 3, temp, 0);
		SUM_QC=SUM_QC+ATTRead(SPI1, 0x07, 3, temp, 0);
		//����ѹ�������Ĵ���ֵ
		SUM_UC=SUM_UC+ATTRead(SPI1, 0x0F, 3, temp, 0);
		SUM_IC=SUM_IC+ATTRead(SPI1, 0x12, 3, temp, 0);
		delay(400);
//		fprintf(stderr,"\n\r SUM_PC==%x [%d]",SUM_PC,SUM_PC);
//		fprintf(stderr,"\n\r SUM_QC==%x [%d]",SUM_QC,SUM_QC);
//		fprintf(stderr,"\n\r SUM_UC==%x [%d]",SUM_UC,SUM_UC);
//		fprintf(stderr,"\n\r SUM_IC==%x [%d]",SUM_IC,SUM_IC);
	}
	ATT_PC = SUM_PC/ReadCount;
	ATT_QC = SUM_QC/ReadCount;
	ATT_UC = SUM_UC/ReadCount;
	ATT_IC = SUM_IC/ReadCount;
//	//���й����޹��Ĵ���ֵ
//	ATT_PC = ATTRead(SPI1, 0x03, 3, temp, 0);
//	ATT_QC = ATTRead(SPI1, 0x07, 3, temp, 0);
//
//	//����ѹ�������Ĵ���ֵ
//	ATT_UC = ATTRead(SPI1, 0x0F, 3, temp, 0);
//	ATT_IC = ATTRead(SPI1, 0x12, 3, temp, 0);
	fprintf(stderr,"\n\r PC==%x [%d]",ATT_PC,ATT_PC);
	fprintf(stderr,"\n\r QC==%x [%d]",ATT_QC,ATT_QC);
	fprintf(stderr,"\n\r UC==%x [%d]",ATT_UC,ATT_UC);
	fprintf(stderr,"\n\r IC==%x [%d]",ATT_IC,ATT_IC);

    //�����������ֵ
	if (ATT_PC > 8388608)
		ATT_PC = ATT_PC -16777216;
	ATT_PC = ATT_PC*1.0/756*100;
	fprintf(stderr,"\n\r PC/256==%x [%d]",ATT_PC,ATT_PC);

	if (ATT_QC > 8388608)
		ATT_QC = ATT_QC -16777216;
	ATT_QC = (ATT_QC*1.0/756)*1.0005*100;//1.0005Ϊ�޹��㷨���ڵ�����
	fprintf(stderr,"\n\r QC/256==%x [%d]",ATT_QC,ATT_QC);

	//����ǲ�У��ֵ(Preal*Q-P*Qreal)/(P*Preal+Q*Qreal);
	temp1=JConfigInfo->jcxs.PrealC*ATT_QC-ATT_PC*JConfigInfo->jcxs.QrealC;
	temp2=ATT_PC*JConfigInfo->jcxs.PrealC+ATT_QC*JConfigInfo->jcxs.QrealC;
	if(temp2!=0)
		tempJiaoChaC=temp1*1.0/temp2;
	if (tempJiaoChaC>=0)
	{
		mod_c=(int)((tempJiaoChaC * 32768)*10)%10;
		if(mod_c>=5)
			JiaoChaC = floor(tempJiaoChaC * 32768)+1;
		else
			JiaoChaC = floor(tempJiaoChaC * 32768);
	}else
	{
		mod_c=(int)((65536 + tempJiaoChaC * 32768)*10)%10;
		if(mod_c>=5)
			JiaoChaC = floor(65536 + tempJiaoChaC * 32768)+1;
		else
			JiaoChaC = floor(65536 + tempJiaoChaC * 32768);
	}
	//У���ǲ��Ĺ���ֵ
	ATT_PC=ATT_PC+ATT_QC*tempJiaoChaC;

	//��������У��ֵ
	if(ATT_PC!=0)
		tempCPgain=JConfigInfo->jcxs.PrealC*100*1.0/ATT_PC-1;
	if (tempCPgain>=0)
	{
		mod_c=(int)((tempCPgain * 32768)*10)%10;
		if(mod_c>=5)
			CPgain = floor(tempCPgain * 32768)+1;
		else
			CPgain = floor(tempCPgain * 32768);
	}else
	{
		mod_c=(int)((65536 + tempCPgain * 32768)*10)%10;
		if(mod_c>=5)
			CPgain = floor(65536 + tempCPgain * 32768)+1;
		else
			CPgain = floor(65536 + tempCPgain * 32768);
	}
	temp[0] = 0;
	temp[1] = (JiaoChaC & 0xff00) >> 8;
	temp[2] = JiaoChaC & 0xff;
//	ATTWrite(SPI1, 0x0F, 3, temp, 0);//��λУ��0  �й���λ
//	ATTWrite(SPI1, 0x12, 3, temp, 0);//��λУ��1 �޹���λ
	JConfigInfo->jcxs.displayC_jiaoxiu[0] = temp[0];
	JConfigInfo->jcxs.displayC_jiaoxiu[1] = temp[1];
	JConfigInfo->jcxs.displayC_jiaoxiu[2] = temp[2];

	temp[0] = 0;
	temp[1] = (CPgain & 0xff00) >> 8;
	temp[2] = CPgain & 0xff;
//	ATTWrite(SPI1, 0x06, 3, temp, 0);//pC
//	ATTWrite(SPI1, 0x09, 3, temp, 0);//qC
//	ATTWrite(SPI1, 0x0c, 3, temp, 0);//sC
	JConfigInfo->jcxs.displayPC_xishu[0] = temp[0];
	JConfigInfo->jcxs.displayPC_xishu[1] = temp[1];
	JConfigInfo->jcxs.displayPC_xishu[2] = temp[2];
	fprintf(stderr,"\n\rCPgain==%d  JiaoChaC==%d",CPgain,JiaoChaC);//�ǲ�У��ֵ�͹�������У��ֵд��i2c

	//��ѹ������У��
	//���������ѹ������Чֵ
	ATT_UC=ATT_UC*1.0/8192*100; //*10��Ϊ�˱�ס��ѹС�����2λ����֤���ȡ�
	ATT_IC=ATT_IC*1.0/8192*10000;//*1000��Ϊ�˱�ס����С�����3λ����֤���ȡ�
	fprintf(stderr,"\n\r celiang UC==%x [%d]",ATT_UC,ATT_UC);
	fprintf(stderr,"\n\r celiang IC==%x [%d]",ATT_IC,ATT_IC);
	//�����ѹ��������ЧֵУ��ϵ��
	if(ATT_UC!=0)
		tempUCgain=JConfigInfo->jcxs.UrealC*100*1.0/ATT_UC-1;
	if (tempUCgain>=0)
	{
		mod_c=(int)((tempUCgain * 32768)*10)%10;
		if(mod_c>=5)
			UCgain = floor(tempUCgain * 32768)+1;
		else
			UCgain = floor(tempUCgain * 32768);
	}else
	{
		mod_c=(int)((65536 + tempUCgain * 32768)*10)%10;
		if(mod_c>=5)
			UCgain = floor(65536 + tempUCgain * 32768)+1;
		else
			UCgain = floor(65536 + tempUCgain * 32768);
	}
	if(ATT_IC!=0)
		tempICgain=JConfigInfo->jcxs.IrealC*10000*1.0/ATT_IC-1;
	fprintf(stderr,"\n\r tempUCgain==%f",tempUCgain);
	fprintf(stderr,"\n\r tempICgain==%f",tempICgain);
	if (tempICgain>=0)
	{
		mod_c=(int)((tempICgain * 32768)*10)%10;
		if(mod_c>=5)
			ICgain = floor(tempICgain * 32768)+1;
		else
			ICgain = floor(tempICgain * 32768);
	}else
	{
		mod_c=(int)((65536 + tempICgain * 32768)*10)%10;
		if(mod_c>=5)
			ICgain = floor(65536 + tempICgain * 32768)+1;
		else
			ICgain = floor(65536 + tempICgain * 32768);
	}
	temp[0] = 0;
	temp[1] = (UCgain & 0xff00) >> 8;
	temp[2] = UCgain & 0xff;
	//ATTWrite(SPI1, 0x19, 3, temp, 0);
	JConfigInfo->jcxs.displayUC_xishu[0] = temp[0];
	JConfigInfo->jcxs.displayUC_xishu[1] = temp[1];
	JConfigInfo->jcxs.displayUC_xishu[2] = temp[2];
	temp[0] = 0;
	temp[1] = (ICgain & 0xff00) >> 8;
	temp[2] = ICgain & 0xff;
	//ATTWrite(SPI1, 0x1C, 3, temp, 0);
	JConfigInfo->jcxs.displayIC_xishu[0] = temp[0];
	JConfigInfo->jcxs.displayIC_xishu[1] = temp[1];
	JConfigInfo->jcxs.displayIC_xishu[2] = temp[2];
	fprintf(stderr,"\n\rUCgain==%d  ICgain==%d",UCgain,ICgain);
	fprintf(stderr,"\n\r[ pquic end ]\n");
	return;
}
void PQCbt()//У������
{
	float errA,errB,errC;
	float APgain,BPgain,CPgain;
	short GP1A,GP1B,GP1C;
	INT8U temp[3];
	INT32S ATT_PA, ATT_PB, ATT_PC;

	//----------------------------------------------�������Ĵ���-��λ�Ĵ�������
	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0x5a;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //����д����

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0;
	ATTWrite(SPI1, 0x0D, 3, temp, 0); //����д����
	ATTWrite(SPI1, 0x0E, 3, temp, 0); //����д����
	ATTWrite(SPI1, 0x0F, 3, temp, 0); //����д����
	ATTWrite(SPI1, 0x10, 3, temp, 0); //����д����
	ATTWrite(SPI1, 0x11, 3, temp, 0); //����д����
	ATTWrite(SPI1, 0x12, 3, temp, 0); //����д����
	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0;
	ATTWrite(SPI1, 0xc9, 3, temp, 0);//������д

	//----------------------------------------------
	ATT_PA = ATTRead(SPI1, 0x01, 3, temp, 0);
	ATT_PB = ATTRead(SPI1, 0x02, 3, temp, 0);
	ATT_PC = ATTRead(SPI1, 0x03, 3, temp, 0);
	fprintf(stderr,"\n\r PA==%x [%d]",ATT_PA,ATT_PA);
	fprintf(stderr,"\n\r PB==%x [%d]",ATT_PB,ATT_PB);
	fprintf(stderr,"\n\r PC==%x [%d]",ATT_PC,ATT_PC);

	if (ATT_PA > 8388608)//2^23
		ATT_PA = ATT_PA -16777216;//2^24
	ATT_PA = ATT_PA /75.7;
	fprintf(stderr,"\n\r PA/256==%x [%d]",ATT_PA,ATT_PA);

	if (ATT_PB > 8388608)
		ATT_PB = ATT_PB -16777216;
	ATT_PB = ATT_PB /75.7;
	fprintf(stderr,"\n\r PB/256==%x [%d]",ATT_PB,ATT_PB);

	if (ATT_PC > 8388608)
		ATT_PC = ATT_PC -16777216;
	ATT_PC = ATT_PC /75.7;
	fprintf(stderr,"\n\r PC/256==%x [%d]",ATT_PC,ATT_PC);

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0x5a;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //����д����

	//_______________________________________________//PA reg
	errA = (ATT_PA -1100 )*1.0/1100;
	APgain = -errA/(1+errA)*1.0;
	if (APgain>=0)
	{
		GP1A = APgain * 32768;
	}else
	{
		GP1A = 65536 + APgain * 32768 ;
	}
	temp[0] = 0;
	temp[1] = (GP1A & 0xff00) >> 8;
	temp[2] = GP1A & 0xff;
	ATTWrite(SPI1, 0x04, 3, temp, 0);
	ATTWrite(SPI1, 0x07, 3, temp, 0);
	ATTWrite(SPI1, 0x0A, 3, temp, 0);
	JConfigInfo->jcxs.displayPA_xishu[0] = temp[0];
	JConfigInfo->jcxs.displayPA_xishu[1] = temp[1];
	JConfigInfo->jcxs.displayPA_xishu[2] = temp[2];
	fprintf(stderr,"\n\r errA==%f  APgain==%f  GP1A==%x",errA,APgain,GP1A);
	//_______________________________________________//PB

	errB = (ATT_PB -1100 )*1.0/1100;
	BPgain = -errB/(1+errB)*1.0;
	if (BPgain>=0)
	{
		GP1B = BPgain * 32768;
	}else
	{
		GP1B = 65536 + BPgain * 32768 ;
	}
	temp[0] = 0;
	temp[1] = (GP1A & 0xff00) >> 8;
	temp[2] = GP1A & 0xff;
	ATTWrite(SPI1, 0x05, 3, temp, 0);
	ATTWrite(SPI1, 0x08, 3, temp, 0);
	ATTWrite(SPI1, 0x0B, 3, temp, 0);
	JConfigInfo->jcxs.displayPB_xishu[0] = temp[0];
	JConfigInfo->jcxs.displayPB_xishu[1] = temp[1];
	JConfigInfo->jcxs.displayPB_xishu[2] = temp[2];
	fprintf(stderr,"\n\r errB==%f  BPgain==%f  GP1B==%x",errB,BPgain,GP1B);

	//_______________________________________________//PC reg
	errC = (ATT_PC -1100 )*1.0/1100;
	CPgain = -errC/(1+errC);
	if (CPgain>=0)
	{
		GP1C = CPgain * 32768;
	}else
	{
		GP1C = 65536 + CPgain * 32768;
	}
	temp[0] = 0;
	temp[1] = (GP1C & 0xff00) >> 8;
	temp[2] = GP1C & 0xff;
	ATTWrite(SPI1, 0x06, 3, temp, 0);
	ATTWrite(SPI1, 0x09, 3, temp, 0);
	ATTWrite(SPI1, 0x0C, 3, temp, 0);
	JConfigInfo->jcxs.displayPC_xishu[0] = temp[0];
	JConfigInfo->jcxs.displayPC_xishu[1] = temp[1];
	JConfigInfo->jcxs.displayPC_xishu[2] = temp[2];
	fprintf(stderr,"\n\r errC=%f  CPgain=%f  GP1C=%x\n\r",errC,CPgain,GP1C);
	//_______________________________________________
	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //������д����
	savefun();
	return;
}
/*****************************************^^^^^^^^^^^^^^^^---*/
void savetest()
{

	INT8U temp[3], i;
	INT32S ATT_PA, ATT_PB, ATT_PC;
	INT32S XISHU_PA, XISHU_PB, XISHU_PC;

	for (i = 0; i < 0x1D; i++) {
		JConfigInfo->jcxs.REC[i] = ATTRead(SPI1, i, 3, temp, 0);
	}
	JConfigInfo->jcxs.REC[0x29] = ATTRead(SPI1, 0x29, 3, temp, 0);

	if (JConfigInfo->jcxs.REC[0x01] > 8388608)
		ATT_PA = (JConfigInfo->jcxs.REC[0x01] - 16777216) / 256; //pa
	else
		ATT_PA = JConfigInfo->jcxs.REC[0x01] / 256;

	if (JConfigInfo->jcxs.REC[0x02] > 8388608)
		ATT_PB = (JConfigInfo->jcxs.REC[0x02] - 16777216) / 256; //pb
	else
		ATT_PB = JConfigInfo->jcxs.REC[0x02] / 256;

	if (JConfigInfo->jcxs.REC[0x03] > 8388608)
		ATT_PC = (JConfigInfo->jcxs.REC[0x03] - 16777216) / 256; //pc
	else
		ATT_PC = JConfigInfo->jcxs.REC[0x03] / 256;

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //����д����

	if (ATT_PA != 0) {
		ATT_PA = ATT_PA / 2;
		if (1100 >= ATT_PA)
			XISHU_PA = ((1100 - ATT_PA) * 32768 / ATT_PA) * 256; //PA
		else
			XISHU_PA = ((1100 + ATT_PA) * 32768 / ATT_PA) * 256;

		//XISHU_PA = ((ATT_PA - 1100)*100/1100);
		//XISHU_PA=XISHU_PA/256;

		temp[0] = (XISHU_PA & 0xff0000) >> 16;
		temp[1] = (XISHU_PA & 0xff00) >> 8;
		temp[2] = XISHU_PA & 0xff;
		//temp[0] = 0x00;
		//temp[1] = 0xF4;
		//temp[2] = 0x4A;
		JConfigInfo->jcxs.displayPA_xishu[0] = temp[0];
		JConfigInfo->jcxs.displayPA_xishu[1] = temp[1];
		JConfigInfo->jcxs.displayPA_xishu[2] = temp[2];

		ATTWrite(SPI1, 0x06, 3, temp, 0);
		ATTWrite(SPI1, 0x09, 3, temp, 0);
	}

	if (ATT_PB != 0) {
		ATT_PB = ATT_PB / 2;
		if (1100 >= ATT_PB)
			XISHU_PB = ((1100 - ATT_PB) * 32768 / ATT_PB) * 256; //PB
		else
			XISHU_PB = ((1100 + ATT_PB) * 32768 / ATT_PB) * 256;
		//XISHU_PB = ((ATT_PB - 1100)*100/1100);
		//XISHU_PB = XISHU_PB/256;
		temp[0] = (XISHU_PB & 0xff0000) >> 16;
		temp[1] = (XISHU_PB & 0xff00) >> 8;
		temp[2] = XISHU_PB & 0xff;
		//temp[0] = 0x07;
		//temp[1] = 0xB5;
		//temp[2] = 0x4E;

		JConfigInfo->jcxs.displayPB_xishu[0] = temp[0];
		JConfigInfo->jcxs.displayPB_xishu[1] = temp[1];
		JConfigInfo->jcxs.displayPB_xishu[2] = temp[2];

		ATTWrite(SPI1, 0x07, 3, temp, 0);
		ATTWrite(SPI1, 0x0A, 3, temp, 0);
	}

	if (ATT_PC != 0) {
		ATT_PC = ATT_PC / 2;
		if (1100 >= ATT_PC)
			XISHU_PC = ((1100 - ATT_PC) * 32768 / ATT_PC) * 256; //PC
		else
			XISHU_PC = ((1100 + ATT_PC) * 32768 / ATT_PC) * 256;

		temp[0] = (XISHU_PC & 0xff0000) >> 16;
		temp[1] = (XISHU_PC & 0xff00) >> 8;
		temp[2] = XISHU_PC & 0xff;

		JConfigInfo->jcxs.displayPC_xishu[0] = temp[0];
		JConfigInfo->jcxs.displayPC_xishu[1] = temp[1];
		JConfigInfo->jcxs.displayPC_xishu[2] = temp[2];

		ATTWrite(SPI1, 0x08, 3, temp, 0);
		ATTWrite(SPI1, 0x0B, 3, temp, 0);
	}

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 1;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //bu����д����
	savefun();

}
void save7022flag(void)//����7022���͵�оƬ
{
	if (openi2c())
	{
		printf("\n Save DeviceFlag = %02x\n",DeviceFlag);
		i2c_write(i2cfd,7 * 8 + 0, DeviceFlag, 1);
		if (i2cfd > 0)
			close(i2cfd);
	}
}
//  ��������ϵ�����浽оƬ  �൱��Save_Fk_xiu_I2C();
void savefun(void) {
/*	int i, j;

	if (openi2c()){fprintf(stderr,"\n\rBegin write to I2C .....");
		memset(pagelist, 0, 56);
		pagelist[0][0] = JConfigInfo->jcxs.displayUA_xishu[0];
		pagelist[0][1] = JConfigInfo->jcxs.displayUA_xishu[1];
		pagelist[0][2] = JConfigInfo->jcxs.displayUA_xishu[2];
		test2(0, &pagelist[0][0], 3, "Ua");
		pagelist[0][4] = JConfigInfo->jcxs.displayUB_xishu[0];
		pagelist[0][5] = JConfigInfo->jcxs.displayUB_xishu[1];
		pagelist[0][6] = JConfigInfo->jcxs.displayUB_xishu[2];
		test2(0, &pagelist[0][4], 3, "Ub");
		//-----------------------------
		pagelist[1][0] = JConfigInfo->jcxs.displayUC_xishu[0];
		pagelist[1][1] = JConfigInfo->jcxs.displayUC_xishu[1];
		pagelist[1][2] = JConfigInfo->jcxs.displayUC_xishu[2];
		test2(1, &pagelist[1][0], 3, "Uc");
		pagelist[1][4] = JConfigInfo->jcxs.displayIA_xishu[0];
		pagelist[1][5] = JConfigInfo->jcxs.displayIA_xishu[1];
		pagelist[1][6] = JConfigInfo->jcxs.displayIA_xishu[2];
		test2(1, &pagelist[1][4], 3, "Ia");
		//-----------------------------
		pagelist[2][0] = JConfigInfo->jcxs.displayIB_xishu[0];
		pagelist[2][1] = JConfigInfo->jcxs.displayIB_xishu[1];
		pagelist[2][2] = JConfigInfo->jcxs.displayIB_xishu[2];
		test2(2, &pagelist[2][0], 3, "Ib");
		pagelist[2][4] = JConfigInfo->jcxs.displayIC_xishu[0];
		pagelist[2][5] = JConfigInfo->jcxs.displayIC_xishu[1];
		pagelist[2][6] = JConfigInfo->jcxs.displayIC_xishu[2];
		test2(2, &pagelist[2][4], 3, "Ic");
		//-----------------------------
		pagelist[3][0] = JConfigInfo->jcxs.displayI0_xishu[0];
		pagelist[3][1] = JConfigInfo->jcxs.displayI0_xishu[1];
		pagelist[3][2] = JConfigInfo->jcxs.displayI0_xishu[2];
		test2(3, &pagelist[3][0], 3, "I0");
		pagelist[3][4] = JConfigInfo->jcxs.displayPA_xishu[0];
		pagelist[3][5] = JConfigInfo->jcxs.displayPA_xishu[1];
		pagelist[3][6] = JConfigInfo->jcxs.displayPA_xishu[2];
		test2(3, &pagelist[3][4], 3, "PA");
		//-----------------------------
		pagelist[4][0] = JConfigInfo->jcxs.displayPB_xishu[0];
		pagelist[4][1] = JConfigInfo->jcxs.displayPB_xishu[1];
		pagelist[4][2] = JConfigInfo->jcxs.displayPB_xishu[2];
		test2(4, &pagelist[4][0], 3, "PB");
		pagelist[4][4] = JConfigInfo->jcxs.displayPC_xishu[0];
		pagelist[4][5] = JConfigInfo->jcxs.displayPC_xishu[1];
		pagelist[4][6] = JConfigInfo->jcxs.displayPC_xishu[2];
		test2(4, &pagelist[4][4], 3, "PC");
		//-----------------------------
		pagelist[5][0] = JConfigInfo->jcxs.displayA_jiaoxiu[0];
		pagelist[5][1] = JConfigInfo->jcxs.displayA_jiaoxiu[1];
		pagelist[5][2] = JConfigInfo->jcxs.displayA_jiaoxiu[2];
		test2(5, &pagelist[5][0], 3, "ja");
		pagelist[5][4] = JConfigInfo->jcxs.displayB_jiaoxiu[0];
		pagelist[5][5] = JConfigInfo->jcxs.displayB_jiaoxiu[1];
		pagelist[5][6] = JConfigInfo->jcxs.displayB_jiaoxiu[2];
		test2(5, &pagelist[5][4], 3, "jb");
		//-----------------------------
		pagelist[6][0] = JConfigInfo->jcxs.displayC_jiaoxiu[0];
		pagelist[6][1] = JConfigInfo->jcxs.displayC_jiaoxiu[1];
		pagelist[6][2] = JConfigInfo->jcxs.displayC_jiaoxiu[2];
		test2(6, &pagelist[6][0], 3, "jc");
		pagelist[6][4] = JConfigInfo->jcxs.displayMC_out_xishu[0];
		pagelist[6][5] = JConfigInfo->jcxs.displayMC_out_xishu[1];
		pagelist[6][6] = JConfigInfo->jcxs.displayMC_out_xishu[2];
		test2(6, &pagelist[6][4], 3, "mc");
		delay(1000);

		for (i = 0; i < 7; i++) {
			for (j = 0; j < 8; j++) {
				delay(100);
				i2c_write(i2cfd,i * 8 + j, pagelist[i][j], 1);
			}
		}
		if (i2cfd > 0)
			close(i2cfd);


	}*/

//#ifdef SAVEFILE
	printf("\n ���� UA_xishu = %02x  %02x  %02x",JConfigInfo->jcxs.displayUA_xishu[0],JConfigInfo->jcxs.displayUA_xishu[1],JConfigInfo->jcxs.displayUA_xishu[2]);
	printf("\n ���� UA_xishu = %02x  %02x  %02x",JConfigInfo->jcxs.displayUA_xishu[0],JConfigInfo->jcxs.displayUA_xishu[1],JConfigInfo->jcxs.displayUA_xishu[2]);
//	INT8U TempBuf[60];//jiaocai	yangodng  60
//	memset(TempBuf,0,60);
//	sprintf((char*)TempBuf,"%s/JcXiu.par",_PARADIR_);
//	NormalSaveFile((char*)TempBuf,(INT8U *)&JConfigInfo->jcxs,sizeof(JConfigInfo->jcxs),JProgramInfo);

//	memset(TempBuf,0,60);
//	sprintf((char*)TempBuf,"%s/JcXiu.par.bak",_PARADIR_);
//	NormalSaveFile((char*)TempBuf,(INT8U *)&JConfigInfo->jcxs,sizeof(JConfigInfo->jcxs),JProgramInfo);
//#endif
	if(JProgramInfo->FileSaveFlag.jcxsflag==0)
		JProgramInfo->FileSaveFlag.jcxsflag=1;
	printf("\n\rsave file 7022  ");
	return;
}

INT8U Save_Fk_xiu_Set() {
	FILE *fp;
	sem_wait(&JProgramInfo->mainData.UseFileFlg);
	fp = fopen("/nor/config/pfkxiu.set", "w");
	if (fp != NULL) {
		fseek(fp, 0, SEEK_SET);
		fwrite(Att24Tmp, sizeof(Att24Tmp), 1, fp);
		fclose(fp);
		sem_post(&JProgramInfo->mainData.UseFileFlg);
		return TRUE;
	}
	sem_post(&JProgramInfo->mainData.UseFileFlg);
	return FALSE;
}
INT8U Read_Fk_xiu_Set() {
	FILE *fp;
	sem_wait(&JProgramInfo->mainData.UseFileFlg);
	fp = fopen("/nor/config/pfkxiu.set", "r");
	if (fp != NULL) {
		fseek(fp, 0, SEEK_SET);
		fread(Att24Tmp, sizeof(Att24Tmp), 1, fp);
		fclose(fp);
		sem_post(&JProgramInfo->mainData.UseFileFlg);
		return TRUE;
	}
	sem_post(&JProgramInfo->mainData.UseFileFlg);
	return FALSE;
}

void AT24Read(int addr, unsigned char *dest, int len) {
	//memcpy(dest,&Att24Tmp[addr],len);
}
void AT24Write(int addr, unsigned char data) {
	Att24Tmp[addr] = data;
}


static void dumpstat(const char *name, int fd)
{
	int ret;
	mode |= SPI_CPHA;

	ret = ioctl(fd, SPI_IOC_WR_MODE, &mode);//�趨���ݴ����spiģʽ
	if (ret == -1)
		pabort("can't set spi mode");

	ret = ioctl(fd, SPI_IOC_RD_MODE, &mode);//://��ȡspi����ģʽ
	if (ret == -1)
		pabort("can't get spi mode");

	ret = ioctl(fd, SPI_IOC_WR_BITS_PER_WORD, &bits);//://�趨����λ��
	if (ret == -1)
		pabort("can't set bits per word");

	ret = ioctl(fd, SPI_IOC_RD_BITS_PER_WORD, &bits);//://��ȡÿ�δ������ݵ�λ��
	if (ret == -1)
		pabort("can't get bits per word");


	ret = ioctl(fd, SPI_IOC_WR_MAX_SPEED_HZ, &speed);//://�趨������ٶ�
	if (ret == -1)
		pabort("can't set max speed hz");

	ret = ioctl(fd, SPI_IOC_RD_MAX_SPEED_HZ, &speed);//://��ȡ���ݴ����ٶ�
	if (ret == -1)
		pabort("can't get max speed hz");
}
void RESet7022b()
{
	int ret,i;
	if (fp != -1)
	{
		spi_close(fp);
	}

	i=0;
	ret=0;
	fp = open(devname, O_RDWR);
	if (fp < 0)
		pabort("can't open device");
	dumpstat(devname,fp);
}
unsigned short ftoformat02(float val)
{
	int i,j,dota_pos=0;
	unsigned short ret=0;
	char str_value[20];
	char flag=0;
	float value;
	memset(str_value,0,20);
	value = fabs(val);
	sprintf(str_value,"%f",value);

	for(i=0,j=0; i<strlen(str_value); i++)
	{
		if(value<1)
		{
			if((str_value[i] >'0' && str_value[i] != '.') && flag==0)
			{
				dota_pos = 2 - i;
				flag = 1;
			}
			else if(flag==0)
				continue;
		}
		if(str_value[i]=='.' && flag==0)
		{
			dota_pos = i;
			continue;
		}
		if(j<3)
		{
			ret |= (str_value[i]-'0') << ((2-j)*4);
			j++;
		}
	}
	//���� dota_pos-3 ֵ�ҵ� ret�ĸ�3λ   ��ֵ ret
	if(val<0)
		ret |= 1<<12;
	else
		ret &= (~(1<<12));

	if(value==0)
		ret |= 0x4<<13;
	else
		ret |= (4-(dota_pos-3))<<13;
	return ret;
}

void CalWendufun()
{
	int fd,data;
	unsigned short AD_Ima_short;
	if (WenduXishu >0)
	{
		if((fd = open("/dev/freq", O_RDWR | O_NDELAY)) == -1)
			return;
		read(fd,&data,sizeof(int));
		close(fd);
		AD_Ima = (float)(data/ WenduXishu);
	}
	AD_Ima_short = ftoformat02(AD_Ima);
	JProgramInfo->BeiYong[0] = AD_Ima_short & 0xff;
	JProgramInfo->BeiYong[1] = (AD_Ima_short>>8) & 0xff;
	//SdPrint("\n Freq AD_Ima=%f JDataFileInfo->jzq->BeiYong[1][0]=%02x%02x\n", AD_Ima, JDataFileInfo->jzq.BeiYong[1], JDataFileInfo->jzq.BeiYong[0]);
}
void jiao4mA()
{
	int fd,data;
	if((fd = open("/dev/freq", O_RDWR | O_NDELAY)) == -1)
		return;
	read(fd,&data,sizeof(int));
	WenduK1 = (float) data/4;
	printf("\n WenduK1==%d",(int)WenduK1);
	fflush(stdout);
	close(fd);
}
void jiao20mA()
{
	int fd,data;
	if((fd = open("/dev/freq", O_RDWR | O_NDELAY)) == -1)
		return;
	read(fd,&data,sizeof(int));
	WenduK2 = (float) data/20;

	close(fd);

	if ((WenduK2!=0)&&(WenduK1!=0))
	{
		WenduXishu = (WenduK2 + WenduK1)/2;
		SaveXishuData();
	}
	printf("\nWenduK2==%d  WenduXishu =%d",(int)WenduK2,(int)WenduXishu);
	fflush(stdout);
}
void Setup7022E() //����7022E
{
	INT8U temp[3];
	temp[0] = 0;
	temp[1] = 0xB9;
//  temp[2] = 0xFE;
	temp[2] = 0xFF;	//�������ߵ���ͨ��
	ATTWrite(SPI1, 0x01, 3, temp, 0); //ģʽ����

	temp[0] = 0;
	temp[1] = 0xF8;
	temp[2] = 0x84;
	ATTWrite(SPI1, 0x03, 3, temp, 0); //EMU��Ԫʹ��
	temp[0] = 0;
	temp[1] = 0x34;
//	temp[2] = 0xB7;
	temp[2] = 0x37;//jiaocai
	ATTWrite(SPI1, 0x31, 3, temp, 0);//ģ��ģ��ʹ��
	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0;
	ATTWrite(SPI1, 0x16, 3, temp, 0);//�޹���λУ��
	temp[0] = 0;
	temp[1] = 0x01;
	//temp[2] = 0x6E;
	temp[2] = 0x6D;
	ATTWrite(SPI1, 0x1E, 3, temp, 0); //HFconst
}
int read7022flag(void)//��оƬ��ȡ7022����
{
	if (openi2c())
	{
		i2c_read(i2cfd,7 * 8 + 0, &DeviceFlag, 1);
		if (i2cfd > 0)
			close(i2cfd);
		if((DeviceFlag== ATT7022EE)||(DeviceFlag== ATT7022CC))
			return 1;
	}
	DeviceFlag = ATTUNKNOWN;
	return 0;
}
void JugeAtt7022(void )
{
	int fd=-1;
	int data;
	INT32U DeviceId;
	INT8U temp[3];
	//--------��λATT7022---------------------------------------------------------
	RESet7022b();
	fd = open("/dev/gpoATT_RST",O_RDWR | O_NDELAY);
	if ( fd <0)
		return ;
	data = 0;
	write(fd,&data,sizeof(int));
	OSTimeDly(10);
	data = 1;
	write(fd,&data,sizeof(int));
	OSTimeDly(1000);
	close(fd);
	//delay(2000);

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0x5a;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //����д����
	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0;
	ATTWrite(SPI1, 0xc3, 3, temp, 0); //��У���Ĵ���

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 1;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //������д����

	//---------��ȡ����оƬ����---------------------------------------------------
	DeviceId = 0;
	DeviceId = ATTRead(SPI1, 0x00, 3, temp, 0);
	printf("\n ����оƬ : %x",DeviceId);
	if (DeviceId == 0x7122a0)
	{
		DeviceFlag = ATT7022EE;
		printf(" ATT7022E ��ʶ %x   ",DeviceFlag);
	}else
	{
		DeviceFlag = ATT7022CC;
		printf(" ATT7022C ��ʶ %x   ",DeviceFlag);
	}
}
void SaveXishuData()
{
//	char filename[50];
//	memset(filename,0,50);
//	sprintf(filename,"/nand/para/WenduXishu.par");
//	SaveFile(filename,(INT8U *)&WenduXishu,sizeof(float),JProgramInfo);
}
void ReadWenduXishu()
{
//	int re;
//	char filename[50];
//	memset(filename,0,50);
//	if(access("/nand/para/WenduXishu.par",0)==0)
//	{
//		sprintf(filename,"/nand/para/WenduXishu.par");
//		re = ReadFile(filename,(INT8U *)&WenduXishu,sizeof(float),JProgramInfo);
//		if(WenduXishu==0)
//			WenduXishu=1;
//	}
}
void ATTInit_CC()
{
	INT8U temp[3];
	INT32U jiexianfangshi;
	JConfigInfo->jcxs.mod_uip_flag = 0;
	JConfigInfo->jcxs.mod_q_flag = 0;

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0;//7022b
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //����д����
	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0;
	ATTWrite(SPI1, 0xc3, 3, temp, 0); //��У���Ĵ���
	temp[0] = 0;
	temp[1] = 0x35;
	temp[2] = 0x84; //dian ya jian ce shi neng
	ATTWrite(SPI1, 0x2e, 3, temp, 0);
	temp[0] = 0;
	temp[1] = 0x56;
	temp[2] = 0x78; //dian liu jian ce shi neng
	ATTWrite(SPI1, 0x30, 3, temp, 0);
	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 1;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //bu����д����

	jiexianfangshi = ATTRead(SPI1, 0x3e, 3, temp, 0);
	if ((jiexianfangshi&0xff0000) == 0x040000)
	{
		JDataFileInfo->jc.RES.RES_JXFS = 4;
		printf("\n ���߷�ʽ  : %s\n","������");
	}
	else if  ((jiexianfangshi&0xff0000) == 0x160000)
	{
		JDataFileInfo->jc.RES.RES_JXFS = 3;
		printf("���߷�ʽ  : %s\n","������");
	}
	else
	{
		JDataFileInfo->jc.RES.RES_JXFS = 0;
		fprintf(stderr,"\n\r ����оƬ����!!");
	}
}
void ATTInit_EE() {
//	int fd=-1;
//	int data;
	INT8U temp[3];
	INT32U jiexianfangshi;
	JConfigInfo->jcxs.mod_uip_flag = 0;
	JConfigInfo->jcxs.mod_q_flag = 0;

	//-----------------------------------------------------
	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0x5a;
	ATTWrite(SPI1, 0xc6, 3, temp, 0); //�л���У���Ĵ���
	jiexianfangshi = ATTRead(SPI1, 0x1f, 3, temp, 0);
	if ((jiexianfangshi) == 0x0600)
	{
		JDataFileInfo->jc.RES.RES_JXFS = 4;
		jiexianfangshi = 1;
		printf("\n ���߷�ʽ : %s   ","������");
	}else if (jiexianfangshi == 0x1200)
	{
		jiexianfangshi = 2;
		JDataFileInfo->jc.RES.RES_JXFS = 3;
		printf("\n ���߷�ʽ  : %s   ","������");
	}
	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0;
	ATTWrite(SPI1, 0xc6, 3, temp, 0); //�л����������Ĵ���
	//----------------------------------------------------
	jiexianfangshi = 0;
	jiexianfangshi = ATTRead(SPI1, 0x3e, 3, temp, 0);

	if ((jiexianfangshi) == 0x01E4CD)
	{
		JDataFileInfo->jc.RES.RES_JXFS = 4; // ��������JDataFileInfo->jc.RES.RES_JXFS = 4;
		printf("     ���߷�ʽ  : %s\n","������");
	}else if ((jiexianfangshi) == 0x01F0CD)
	{
		JDataFileInfo->jc.RES.RES_JXFS = 3;
		printf("    ���߷�ʽ  : %s\n","������");
	}
  	//-----------------------------------------------------

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0x5a;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //����д����

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0;
	ATTWrite(SPI1, 0xc3, 3, temp, 0); //��У���Ĵ���

	temp[0] = 0;
	temp[1] = 0xb9;
	temp[2] = 0xfe;
	ATTWrite(SPI1, 0x01, 3, temp, 0); //ģʽ����

	temp[0] = 0;
//	temp[1] = 0xF8;
	temp[1] = 0x3d;		//XIEBO
	temp[2] = 0x84;//���������Ĵ����������㣬bit7��1����������Ϊ0x84
	               //����ADC����������Դ�ھ�����ͨ���õ������ݣ�bit9bit8=01����������Ϊ0x85
				   //ϵͳ�Ƽ�д��F8 04
	ATTWrite(SPI1, 0x03, 3, temp, 0); //EMU��Ԫ����

	temp[0] = 0;
	temp[1] = 0x34;
	temp[2] = 0x37;//�Ƽ�д��0x3427 Ϊ�˲��¶ȴ���������8λ дΪ1
	ATTWrite(SPI1, 0x31, 3, temp, 0); //ģ��ģ��ʹ�ܼĴ���

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0;
	ATTWrite(SPI1, 0x16, 3, temp, 0); //�޹���λУ���Ĵ���

	temp[0] = 0x00;
	temp[1] = 0x01;
	temp[2] = 0x6D;
	ATTWrite(SPI1, 0x1e, 3, temp, 0); //��Ƶ���峣��
	//HFConst=INT[25920000000*G*G*Vu*Vi/(EC*Un*Ib)]  G=1.163   EC=6400  Vu=0.22  Vi=0.334  Un=220   Ib=5

//	temp[0] = 0x00;//46
//	temp[1] = 0x01;//55
//	temp[2] = 0x00;                   //��ѹ��������
//	ATTWrite(SPI1, 0x02, 3, temp, 0); //��ѹͨ��AD����

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0;
	ATTWrite(SPI1, 0x0D, 3, temp, 0);//��λУ��
	ATTWrite(SPI1, 0x0E, 3, temp, 0);
	ATTWrite(SPI1, 0x0F, 3, temp, 0);
	ATTWrite(SPI1, 0x10, 3, temp, 0);
	ATTWrite(SPI1, 0x11, 3, temp, 0);
	ATTWrite(SPI1, 0x12, 3, temp, 0);

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 1;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //������д����
	fprintf(stderr,"INIT 7022E OK\n");
}

INT32S ATTRead(INT8U spi, INT32U addr, INT32U len, INT8U *buf, INT16U to) {
	INT32U i;
	INT32S rec;
	int cnt = 0;
	struct timespec tsspec;
	if (clock_gettime(CLOCK_REALTIME, &tsspec)==-1)
		printf("clock_gettime error\n\r");
	tsspec.tv_sec += 2;
	sem_timedwait(&JProgramInfo->mainData.ATT_STM8_sem, &tsspec);
	cmd[cnt++] = addr & 0x7f;
	spi_cmdread(fp, device, cmd, cnt, buf, len);
	rec = 0;
	for (i = 0; i < len; i++) {
		rec = (rec << 8) | buf[i];
	}
	sem_post(&JProgramInfo->mainData.ATT_STM8_sem);
	return rec;
}

INT32S ATTWrite(INT8U spi, INT32U addr, INT32U len, INT8U *buf, INT16U to) {
	INT32U i;
	int cnt = 0;
	int num;
	struct timespec tsspec;
	if (clock_gettime(CLOCK_REALTIME, &tsspec)==-1)
		printf("clock_gettime error\n\r");
	tsspec.tv_sec += 2;
	sem_timedwait(&JProgramInfo->mainData.ATT_STM8_sem, &tsspec);
	if ((addr == 0xC3) || (addr == 0xC6) || (addr == 0xC9) || (addr == 0xD3)) {
		cmd[cnt++] = addr | 0xC0; //д��������
	} else
		cmd[cnt++] = addr | 0x80; //д����У������
	for (i = 0; i < len; i++) {
		cmd[cnt++] = buf[i];
	}
	num = spi_write(fp, device, cmd, cnt);
	sem_post(&JProgramInfo->mainData.ATT_STM8_sem);
	return 0;
}
extern INT32S CkSum, CkSunOld;

void att_spi_init_CC(void)
{
	INT8U tempp[3];

	delay(50);
	tempp[0] = 0;
	tempp[1] = 0;
	tempp[2] = 0;
	ATTWrite(SPI1, 0xc9, 3, tempp, 0); //����д����

	tempp[0] = 0x46;
    tempp[1] = 0x55;
	tempp[2] = 0x01;
	ATTWrite(SPI1, 0x3f, 3, tempp, 0); //��ѹͨ��AD����

	/*tempp[0] = 0x0;
	tempp[1] = 0x0;
	tempp[2] = 0x4;
	ATTWrite(SPI1, 0x2c, 3, tempp, 0); //�¶�ʹ��*/

	//ATTWrite(SPI1,0x20,3,JConfigInfo->jcxs.displayMC_out_xishu,0);

	ATTWrite(SPI1, 0x1B, 3, JConfigInfo->jcxs.displayUA_xishu, 0);
	ATTWrite(SPI1, 0x1C, 3, JConfigInfo->jcxs.displayUB_xishu, 0);
	ATTWrite(SPI1, 0x1D, 3, JConfigInfo->jcxs.displayUC_xishu, 0);

	ATTWrite(SPI1, 0x26, 3, JConfigInfo->jcxs.displayIA_xishu, 0);
	ATTWrite(SPI1, 0x27, 3, JConfigInfo->jcxs.displayIB_xishu, 0);
	ATTWrite(SPI1, 0x28, 3, JConfigInfo->jcxs.displayIC_xishu, 0);
	ATTWrite(SPI1, 0x2B, 3, JConfigInfo->jcxs.displayI0_xishu, 0);
	//.......................
	tempp[0] = 0;
	tempp[1] = 0;
	tempp[2] = 18;//JConfigInfo->McAttr;//0xb;//0x39;//53;72//  8000 ->2d  6400->39
	//ATTWrite(SPI1,0x20,3,JConfigInfo->jcxs.displayMC_out_xishu,0);///�������
	//ATTWrite(SPI1,0x20,3,tempp,0);///�������
	//.......................

	ATTWrite(SPI1, 0x06, 3, JConfigInfo->jcxs.displayPA_xishu, 0);
	ATTWrite(SPI1, 0x09, 3, JConfigInfo->jcxs.displayPA_xishu, 0);

	ATTWrite(SPI1, 0x07, 3, JConfigInfo->jcxs.displayPB_xishu, 0);
	ATTWrite(SPI1, 0x0A, 3, JConfigInfo->jcxs.displayPB_xishu, 0);

	ATTWrite(SPI1, 0x08, 3, JConfigInfo->jcxs.displayPC_xishu, 0);
	ATTWrite(SPI1, 0x0B, 3, JConfigInfo->jcxs.displayPC_xishu, 0);

	ATTWrite(SPI1, 0xc, 3, JConfigInfo->jcxs.displayA_jiaoxiu, 0);
	ATTWrite(SPI1, 0xd, 3, JConfigInfo->jcxs.displayA_jiaoxiu, 0);
	ATTWrite(SPI1, 0xe, 3, JConfigInfo->jcxs.displayA_jiaoxiu, 0);
	ATTWrite(SPI1, 0xf, 3, JConfigInfo->jcxs.displayA_jiaoxiu, 0);
	ATTWrite(SPI1, 0x10, 3, JConfigInfo->jcxs.displayA_jiaoxiu, 0);

	ATTWrite(SPI1, 0x11, 3, JConfigInfo->jcxs.displayB_jiaoxiu, 0);
	ATTWrite(SPI1, 0x12, 3, JConfigInfo->jcxs.displayB_jiaoxiu, 0);
	ATTWrite(SPI1, 0x13, 3, JConfigInfo->jcxs.displayB_jiaoxiu, 0);
	ATTWrite(SPI1, 0x14, 3, JConfigInfo->jcxs.displayB_jiaoxiu, 0);
	ATTWrite(SPI1, 0x15, 3, JConfigInfo->jcxs.displayB_jiaoxiu, 0);

	ATTWrite(SPI1, 0x16, 3, JConfigInfo->jcxs.displayC_jiaoxiu, 0);
	ATTWrite(SPI1, 0x17, 3, JConfigInfo->jcxs.displayC_jiaoxiu, 0);
	ATTWrite(SPI1, 0x18, 3, JConfigInfo->jcxs.displayC_jiaoxiu, 0);
	ATTWrite(SPI1, 0x19, 3, JConfigInfo->jcxs.displayC_jiaoxiu, 0);
	ATTWrite(SPI1, 0x1A, 3, JConfigInfo->jcxs.displayC_jiaoxiu, 0);

	tempp[0] = 0;
	tempp[1] = 0;
	tempp[2] = 1;
	ATTWrite(SPI1, 0xc9, 3, tempp, 0); //bu����д����
	delay(1000);
	CkSum = ATTRead(SPI1, 0x3e, 3, tempp, 0);
	CkSunOld = ATTRead(SPI1, 0x3e, 3, tempp, 0);
}

void att_spi_init_EE(void)
{
	INT8U temp[3];
	delay(50);
	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0x5a;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //����д����

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0;
	ATTWrite(SPI1, 0xc3, 3, temp, 0); //��У���Ĵ���

	temp[0] = 0;
	temp[1] = 0xb9;
	temp[2] = 0xfe; ////////////////////////////////////
	ATTWrite(SPI1, 0x01, 3, temp, 0); //ģʽ����

//	temp[0] = 0;
////	temp[1] = 0xF8;
//	temp[1] = 0xFC;//XIEBO			��������/г������
//	temp[2] = 0x84;//���������Ĵ����������㣬bit7��1//ϵͳ�Ƽ�д��F8 04
//	ATTWrite(SPI1, 0x03, 3, temp, 0); //EMU��Ԫ����

	temp[0] = 0;
//	temp[1] = 0xF8;
	temp[1] = 0x3d;//XIEBO			��������/г������
	temp[2] = 0x84;//���������Ĵ����������㣬bit7��1//ϵͳ�Ƽ�д��F8 04
	ATTWrite(SPI1, 0x03, 3, temp, 0); //EMU��Ԫ����

	temp[0] = 0;
	temp[1] = 0x34;
	temp[2] = 0x37;
//	temp[2] = 0x27;	//jiaocai
	ATTWrite(SPI1, 0x31, 3, temp, 0); //ģ��ģ��ʹ�ܼĴ���

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0;
	ATTWrite(SPI1, 0x16, 3, temp, 0); //�޹���λУ���Ĵ���

	temp[0] = 0x00;
	temp[1] = 0x01;
	temp[2] = 0x6D;
	ATTWrite(SPI1, 0x1e, 3, temp, 0); //��Ƶ���峣��
	//HFConst=INT[25920000000*G*G*Vu*Vi/(EC*Un*Ib)]  G=1.163   EC=6400  Vu=0.22  Vi=0.334  Un=220   Ib=5

//	257.61050815104
//	7040000
//	temp[0] = 0x00;
//	temp[1] = 0x01;
//	temp[2] = 0x00;
//	ATTWrite(SPI1, 0x02, 3, temp, 0); //��ѹͨ��AD����

	ATTWrite(SPI1, 0x17, 3, JConfigInfo->jcxs.displayUA_xishu, 0);
	ATTWrite(SPI1, 0x18, 3, JConfigInfo->jcxs.displayUB_xishu, 0);
	ATTWrite(SPI1, 0x19, 3, JConfigInfo->jcxs.displayUC_xishu, 0);

	ATTWrite(SPI1, 0x1a, 3, JConfigInfo->jcxs.displayIA_xishu, 0);
	ATTWrite(SPI1, 0x1b, 3, JConfigInfo->jcxs.displayIB_xishu, 0);
	ATTWrite(SPI1, 0x1c, 3, JConfigInfo->jcxs.displayIC_xishu, 0);
	//ATTWrite(SPI1, 0x2B, 3, JConfigInfo->jcxs.displayI0_xishu, 0);

	ATTWrite(SPI1, 0x04, 3, JConfigInfo->jcxs.displayPA_xishu, 0);
	ATTWrite(SPI1, 0x07, 3, JConfigInfo->jcxs.displayPA_xishu, 0);
	ATTWrite(SPI1, 0x0a, 3, JConfigInfo->jcxs.displayPA_xishu, 0);

	ATTWrite(SPI1, 0x05, 3, JConfigInfo->jcxs.displayPB_xishu, 0);
	ATTWrite(SPI1, 0x08, 3, JConfigInfo->jcxs.displayPB_xishu, 0);
	ATTWrite(SPI1, 0x0b, 3, JConfigInfo->jcxs.displayPB_xishu, 0);

	ATTWrite(SPI1, 0x06, 3, JConfigInfo->jcxs.displayPC_xishu, 0);
	ATTWrite(SPI1, 0x09, 3, JConfigInfo->jcxs.displayPC_xishu, 0);
	ATTWrite(SPI1, 0x0c, 3, JConfigInfo->jcxs.displayPC_xishu, 0);
	if (JDataFileInfo->jc.RES.RES_JXFS == 04) //jiaoxiu
	{
		//�й�����λУ��
		ATTWrite(SPI1, 0x0d, 3, JConfigInfo->jcxs.displayA_jiaoxiu, 0);
		ATTWrite(SPI1, 0x0e, 3, JConfigInfo->jcxs.displayB_jiaoxiu, 0);
		ATTWrite(SPI1, 0x0f, 3, JConfigInfo->jcxs.displayC_jiaoxiu, 0);
		//�޹�����λУ��
		ATTWrite(SPI1, 0x10, 3, JConfigInfo->jcxs.displayA_jiaoxiu, 0);
		ATTWrite(SPI1, 0x11, 3, JConfigInfo->jcxs.displayB_jiaoxiu, 0);
		ATTWrite(SPI1, 0x12, 3, JConfigInfo->jcxs.displayC_jiaoxiu, 0);
	}

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 1;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //������д����

	delay(1000);
	CkSum = ATTRead(SPI1, 0x3e, 3, temp, 0);
	CkSunOld = ATTRead(SPI1, 0x3e, 3, temp, 0);
}
INT32U XBhz(INT32U *hz,INT32U temphz)
{
	INT8U  i,j;
	INT32U SumHz;
	SumHz =0;
	j = sizeof(hz);
	for(i=0;i<j;i++)
	SumHz = SumHz + hz[i];
	SumHz = SumHz/j;
	if((abs(SumHz - temphz)) > 1000)      //�������1HZ
		return temphz;                    //����˲ʱ��Ƶ��
	else
		return SumHz;                     //���򷵻�ƽ��Ƶ��
}
//Ϊ�˽��esam�ͽ�����ͬһ��spi��ͻ
void EnSpi(int count)
{
	int i=0;
	if(count < 60)
		count = 60;
	while(i<count)
	{
		ClearWaitTimes(ProjectNo,JProgramInfo);
		if(JProgramInfo->EsamJiaocaiflag==0)
			break;
		delay(1000);
		i++;
	}
	JProgramInfo->EsamJiaocaiflag = 1;
}

void DisEnSpi()
{
	JProgramInfo->EsamJiaocaiflag = 0;
}
void spi_test_ATT7022CC(void)
{
	//	DBG("\n+++++++spi_test++");
		INT8U temp[3];
		INT32U test;
		FP64 j;
		int i;
		INT32U temper;
		INT32S tread;
		EnSpi(60);
		CkSum = ATTRead(SPI1, 0x3e, 3, temp, 0);
		CkSum = CkSum & 0xffffff;

		temper = ATTRead(SPI1, 0x2A, 3, temp, 0);
	//	JDataFileInfo->temper = temper;
		for (i = 0; i < 0x1D; i++) {
			JConfigInfo->jcxs.REC[i] = ATTRead(SPI1, i, 3, temp, 0);
			ClearWaitTimes(ProjectNo,JProgramInfo);
		}
	//	printf("\n\rJDataFileInfor->REC[0x0D]=%d",JConfigInfo->jcxs.REC[0x0D]);
		JConfigInfo->jcxs.REC[0x26] = ATTRead(SPI1, 0x26, 3, temp, 0);
		JConfigInfo->jcxs.REC[0x27] = ATTRead(SPI1, 0x27, 3, temp, 0);
		JConfigInfo->jcxs.REC[0x28] = ATTRead(SPI1, 0x28, 3, temp, 0);
		JConfigInfo->jcxs.REC[0x29] = ATTRead(SPI1, 0x29, 3, temp, 0);
		JConfigInfo->jcxs.REC[0x2c] = ATTRead(SPI1, 0x2c, 3, temp, 0);

	//�й�����  ����10��
		tread = JConfigInfo->jcxs.REC[0x01] ;
		if (tread > 8388608)//2^23
			tread = tread -16777216;//2^24
		//tread = tread /757;
		JDataFileInfo->jc.RES.RES_PA= tread*10.0/756;

		tread = JConfigInfo->jcxs.REC[0x02] ;
		if (tread > 8388608)//2^23
			tread = tread -16777216;//2^24
		//tread = tread /757;
		JDataFileInfo->jc.RES.RES_PB= tread*10.0/756;

		tread = JConfigInfo->jcxs.REC[0x03] ;
		if (tread > 8388608)//2^23
			tread = tread -16777216;//2^24
		//tread = tread /757;
		JDataFileInfo->jc.RES.RES_PC= tread*10.0/756;

		tread = JConfigInfo->jcxs.REC[0x04] ;
		if (tread > 8388608)//2^23
			tread = tread -16777216;//2^24
		//tread = tread*2/757;
		JDataFileInfo->jc.RES.RES_PZ= tread*10.0*2/756;
	//�޹�����  ����10��
		tread = JConfigInfo->jcxs.REC[0x05];
		if (tread > 8388608)
			tread = tread - 16777216;
		//tread = tread /757;
		JDataFileInfo->jc.RES.RES_QA= tread*10.0/756;

		tread = JConfigInfo->jcxs.REC[0x06];
		if (tread > 8388608)
			tread = tread - 16777216;
		//tread = tread /757;
		JDataFileInfo->jc.RES.RES_QB= tread*10.0/756;

		tread = JConfigInfo->jcxs.REC[0x07];
		if (tread > 8388608)
			tread = tread - 16777216;
		//tread = tread /757;
		JDataFileInfo->jc.RES.RES_QC= tread*10.0/756;

		tread = JConfigInfo->jcxs.REC[0x08];
		if (tread > 8388608)
			tread = tread - 16777216;
		//tread = tread*2/757;
		JDataFileInfo->jc.RES.RES_QZ= tread*10.0*2/756;
		//JDataFileInfo->jc.RES.RES_QZ=JDataFileInfo->jc.RES.RES_QA+JDataFileInfo->jc.RES.RES_QB+JDataFileInfo->jc.RES.RES_QC;

	//���ڹ���  ����10�������ڹ������ڴ��ڵ���0������������з���λ���жϣ�
		tread = JConfigInfo->jcxs.REC[0x09] ;
		//tread = tread /757;
		JDataFileInfo->jc.RES.RES_SA= tread*10.0/756;

		tread = JConfigInfo->jcxs.REC[0x0a] ;
		//tread = tread /757;
		JDataFileInfo->jc.RES.RES_SB= tread*10.0/756;

		tread = JConfigInfo->jcxs.REC[0x0b] ;
		//tread = tread /757;
		JDataFileInfo->jc.RES.RES_SC= tread*10.0/756;

	//	tread = JDataFileInfo->REC[0x0c] ;
	//	//tread = tread*2/757;
	//	JDataFileInfo->jc.RES.RES_SZ= tread*10.0*2/756;
		//DBG("\n........temper = %d",temper);

		//�����¶Ȳ���
		if( (temper >165)&&(temper <205))
	//	if( (temper<WDCANSHU)||(temper >128))		//++++++++++��
		{

			JDataFileInfo->jc.RES.RES_PA= JDataFileInfo->jc.RES.RES_PA * WDXISHU /1000;
			JDataFileInfo->jc.RES.RES_PB= JDataFileInfo->jc.RES.RES_PB * WDXISHU /1000;
			JDataFileInfo->jc.RES.RES_PC= JDataFileInfo->jc.RES.RES_PC * WDXISHU /1000;
			JDataFileInfo->jc.RES.RES_PZ= JDataFileInfo->jc.RES.RES_PZ * WDXISHU /1000;

			JDataFileInfo->jc.RES.RES_QA= JDataFileInfo->jc.RES.RES_QA * WDXISHU /1000;
			JDataFileInfo->jc.RES.RES_QB= JDataFileInfo->jc.RES.RES_QB * WDXISHU /1000;
			JDataFileInfo->jc.RES.RES_QC= JDataFileInfo->jc.RES.RES_QC * WDXISHU /1000;
			JDataFileInfo->jc.RES.RES_QZ= JDataFileInfo->jc.RES.RES_QZ * WDXISHU /1000;

			JDataFileInfo->jc.RES.RES_SA= JDataFileInfo->jc.RES.RES_SA * WDXISHU /1000;
			JDataFileInfo->jc.RES.RES_SB= JDataFileInfo->jc.RES.RES_SB * WDXISHU /1000;
			JDataFileInfo->jc.RES.RES_SC= JDataFileInfo->jc.RES.RES_SC * WDXISHU /1000;
		}

		JDataFileInfo->jc.RES.RES_SZ =JDataFileInfo->jc.RES.RES_SA+JDataFileInfo->jc.RES.RES_SB+JDataFileInfo->jc.RES.RES_SC;

	//UA//UB//UC  ����10��
		tread = JConfigInfo->jcxs.REC[0x0D] * 10 / 8192;
		JDataFileInfo->jc.RES.RES_UA= tread ;
		tread = JConfigInfo->jcxs.REC[0x0E] * 10 / 8192;
		JDataFileInfo->jc.RES.RES_UB= tread;
		tread = JConfigInfo->jcxs.REC[0x0F] * 10 / 8192;
		JDataFileInfo->jc.RES.RES_UC= tread;

	//	printf("\n\rjc.RES.RES_UA =%d",JDataFileInfo->jc.RES.RES_UA);
	//	printf("\n\rRtuDataAddr->REC[0x0D]=%d",JDataFileInfo->REC[0x0D]);
	//	printf("\n\rRtuDataAddr->REC[0x0E]=%d",JDataFileInfo->REC[0x0E]);
	//	printf("\n\rRtuDataAddr->REC[0x0F]=%d",JDataFileInfo->REC[0x0F]);
	//
	//	printf("\n\rRtuDataAddr->REC[0x10]=%d",JDataFileInfo->REC[0x10]);
	//	printf("\n\rRtuDataAddr->REC[0x11]=%d",JDataFileInfo->REC[0x11]);
	//	printf("\n\rRtuDataAddr->REC[0x12]=%d",JDataFileInfo->REC[0x12]);
	//IA//IB//IC  ����1000
		tread = (JConfigInfo->jcxs.REC[0x10] * 1000) / 8192;
		JDataFileInfo->jc.RES.RES_IA= tread;
		tread = (JConfigInfo->jcxs.REC[0x11] * 1000) / 8192;
		JDataFileInfo->jc.RES.RES_IB= tread;
		tread = (JConfigInfo->jcxs.REC[0x12] * 1000) / 8192;
		JDataFileInfo->jc.RES.RES_IC= tread;
		JDataFileInfo->jc.RES.RES_I0 = (JConfigInfo->jcxs.REC[0x29] * 1000) / 8192; //���ߵ���
		//��ѹ  �����¶Ȳ���
		if( (temper >165)&&(temper <205))
	//	if( (temper<WDCANSHU)||(temper >128))		//++++++++++��
		{
			JDataFileInfo->jc.RES.RES_UA= JDataFileInfo->jc.RES.RES_UA * WDXISHU_UI /1000;
			JDataFileInfo->jc.RES.RES_UB= JDataFileInfo->jc.RES.RES_UB * WDXISHU_UI /1000;
			JDataFileInfo->jc.RES.RES_UC= JDataFileInfo->jc.RES.RES_UC * WDXISHU_UI /1000;

			JDataFileInfo->jc.RES.RES_IA= JDataFileInfo->jc.RES.RES_IA * WDXISHU_UI /1000;
			JDataFileInfo->jc.RES.RES_IB= JDataFileInfo->jc.RES.RES_IB * WDXISHU_UI /1000;
			JDataFileInfo->jc.RES.RES_IC= JDataFileInfo->jc.RES.RES_IC * WDXISHU_UI /1000;
		}


	//��������     ����1000
		if (JConfigInfo->jcxs.REC[0x14] > 8388608)
			JDataFileInfo->jc.RES.RES_PFA = (JConfigInfo->jcxs.REC[0x14] - 16777216) * 10.0 / 8388608 *100;
		else
			JDataFileInfo->jc.RES.RES_PFA = JConfigInfo->jcxs.REC[0x14] * 10.0 / 8388608 *100;

		if (JConfigInfo->jcxs.REC[0x15] > 8388608)
			JDataFileInfo->jc.RES.RES_PFB = (JConfigInfo->jcxs.REC[0x15] - 16777216) * 10.0 / 8388608 *100;
		else
			JDataFileInfo->jc.RES.RES_PFB = JConfigInfo->jcxs.REC[0x15]* 10.0 / 8388608 *100;

		if (JConfigInfo->jcxs.REC[0x16] > 8388608)
			JDataFileInfo->jc.RES.RES_PFC = (JConfigInfo->jcxs.REC[0x16] - 16777216) * 10.0 / 8388608 *100;
		else
			JDataFileInfo->jc.RES.RES_PFC = JConfigInfo->jcxs.REC[0x16] * 10.0 / 8388608 *100;

		if (JConfigInfo->jcxs.REC[0x17] > 8388608)
			JDataFileInfo->jc.RES.RES_PFZ = (JConfigInfo->jcxs.REC[0x17] - 16777216) * 10.0 / 8388608 *100;
		else
			JDataFileInfo->jc.RES.RES_PFZ = JConfigInfo->jcxs.REC[0x17] * 10.0 / 8388608 *100;

		//������ѹ��������Чֵ
			JDataFileInfo->jc.xiebo.AllXBo.UAbase=ATTRead(SPI1,0x48,3,temp,0)*1.0/8192;
			JDataFileInfo->jc.xiebo.AllXBo.UBbase=ATTRead(SPI1,0x49,3,temp,0)*1.0/8192;
			JDataFileInfo->jc.xiebo.AllXBo.UCbase=ATTRead(SPI1,0x4A,3,temp,0)*1.0/8192;
			JDataFileInfo->jc.xiebo.AllXBo.IAbase=ATTRead(SPI1,0x4B,3,temp,0)*1.0/8192;
			JDataFileInfo->jc.xiebo.AllXBo.IBbase=ATTRead(SPI1,0x4C,3,temp,0)*1.0/8192;
			JDataFileInfo->jc.xiebo.AllXBo.ICbase=ATTRead(SPI1,0x4D,3,temp,0)*1.0/8192;

			test = ATTRead(SPI1,0x1C,3,temp,0)*100/8192;
			if( (test>5600)||(test<4400) )   //45hz --- 55hz֮��
				HZall.HZBuff[HZall.HZpoint]  = 5000;
			else
				HZall.HZBuff[HZall.HZpoint]  = test;
		    HZall.HZpoint = (HZall.HZpoint + 1) & 0xf;
		    delay(100);

			test = ATTRead(SPI1,0x1C,3,temp,0)*100/8192;
			if( (test>5600)||(test<4400) )   //45hz --- 55hz֮��
				HZall.HZBuff[HZall.HZpoint]  = 5000;
			else
				HZall.HZBuff[HZall.HZpoint]  = test;

			JDataFileInfo->jc.RES.RES_F = XBhz(HZall.HZBuff,HZall.HZBuff[HZall.HZpoint]); //Ƶ��
		    HZall.HZpoint = (HZall.HZpoint + 1) & 0xf;

	//		JDataFileInfo->jc.RES.RES_F = JConfigInfo->jcxs.REC[0x1C] * 100 / Kf;//��Ƶ��
			JDataFileInfo->jc.RES.RES_FLAG = JConfigInfo->jcxs.REC[0x2C];        //��־״̬
			JConfigInfo->jcxs.REC[0x26] = ATTRead(SPI1,0x26,3,temp,0)/1048576.0*180*10;////Ua��Ub��ѹ�н�
			JConfigInfo->jcxs.REC[0x27] = ATTRead(SPI1,0x27,3,temp,0)/1048576.0*180*10;////Ua��Uc��ѹ�н�
			JConfigInfo->jcxs.REC[0x28] = ATTRead(SPI1,0x28,3,temp,0)/1048576.0*180*10;////Ub��Uc��ѹ�н�

		j = JDataFileInfo->jc.RES.RES_PFA / 1000.0;
		if (JDataFileInfo->jc.RES.RES_QA >= 0)
			JConfigInfo->jcxs.REC[0x18] = 3600 - acos(j) * 1800 / 3.14;
		else
			JConfigInfo->jcxs.REC[0x18] = (acos(j) * 1800 / 3.14);//A��������ѹ�н�
		j = JDataFileInfo->jc.RES.RES_PFB / 1000.0;
		if (JDataFileInfo->jc.RES.RES_QB >= 0)
			JConfigInfo->jcxs.REC[0x19] = 3600 - acos(j) * 1800 / 3.14;
		else
			JConfigInfo->jcxs.REC[0x19] = (acos(j) * 1800 / 3.14);//B��������ѹ�н�
		j = JDataFileInfo->jc.RES.RES_PFC / 1000.0;
		if (JDataFileInfo->jc.RES.RES_QC >= 0)
			JConfigInfo->jcxs.REC[0x1A] = 3600 - acos(j) * 1800 / 3.14;
		else
			JConfigInfo->jcxs.REC[0x1A] = (acos(j) * 1800 / 3.14);//C��������ѹ�н�
		if (((0 <= JConfigInfo->jcxs.REC[0x26]) && (JConfigInfo->jcxs.REC[0x26] <= 3600))
			&& ((0 <= JConfigInfo->jcxs.REC[0x27])&& (JConfigInfo->jcxs.REC[0x27] <= 3600))) {
			JDataFileInfo->jc.RES.RES_UAJ = 0;
			JDataFileInfo->jc.RES.RES_UBJ = JConfigInfo->jcxs.REC[0x26];
			JDataFileInfo->jc.RES.RES_UCJ = JConfigInfo->jcxs.REC[0x27];
			JDataFileInfo->jc.RES.RES_IAJ = JDataFileInfo->jc.RES.RES_UAJ - JConfigInfo->jcxs.REC[0x18];
			if (JDataFileInfo->jc.RES.RES_UBJ < 0)
				JDataFileInfo->jc.RES.RES_UBJ = JDataFileInfo->jc.RES.RES_UBJ + 3600;
			if (JDataFileInfo->jc.RES.RES_UCJ < 0)
				JDataFileInfo->jc.RES.RES_UCJ = JDataFileInfo->jc.RES.RES_UCJ + 3600;
			JDataFileInfo->jc.RES.RES_IBJ = JDataFileInfo->jc.RES.RES_UBJ - JConfigInfo->jcxs.REC[0x19];
			JDataFileInfo->jc.RES.RES_ICJ = JDataFileInfo->jc.RES.RES_UCJ - JConfigInfo->jcxs.REC[0x1A];
			if (JDataFileInfo->jc.RES.RES_IAJ < 0)
				JDataFileInfo->jc.RES.RES_IAJ = JDataFileInfo->jc.RES.RES_IAJ + 3600;
			if (JDataFileInfo->jc.RES.RES_IBJ < 0)
				JDataFileInfo->jc.RES.RES_IBJ = JDataFileInfo->jc.RES.RES_IBJ + 3600;
			if (JDataFileInfo->jc.RES.RES_ICJ < 0)
				JDataFileInfo->jc.RES.RES_ICJ = JDataFileInfo->jc.RES.RES_ICJ + 3600;

			if (JDataFileInfo->jc.RES.RES_IA < 2)
				JDataFileInfo->jc.RES.RES_IAJ = 0;

			if (JDataFileInfo->jc.RES.RES_IB < 2)
				JDataFileInfo->jc.RES.RES_IBJ = 0;

			if (JDataFileInfo->jc.RES.RES_IC < 2)
				JDataFileInfo->jc.RES.RES_ICJ = 0;

			if (JDataFileInfo->jc.RES.RES_UB < 10)
				JDataFileInfo->jc.RES.RES_UBJ = 0;

			if (JDataFileInfo->jc.RES.RES_UC < 10)
				JDataFileInfo->jc.RES.RES_UCJ = 0;
		}
		DisEnSpi();
}


void spi_test_ATT7022EE(void) {
	INT8U temp[3];
	INT32U test;
	FP64 j;
	int i;
	INT32U temper;
	INT32S tread,tmm;

	EnSpi(60);
	CkSum = ATTRead(SPI1, 0x3e, 3, temp, 0);
	CkSum = CkSum & 0xffffff;

	temper = ATTRead(SPI1, 0x2A, 3, temp, 0);
	temper = temper & 0x00ff;

	if(temper>128)
		tmm=temper-256;
	else
		tmm=temper;
//	fprintf(stderr,"\ntemper==%d tmm=%d",temper,tmm);
	for (i = 0; i < 0x1D; i++) {
		JConfigInfo->jcxs.REC[i] = ATTRead(SPI1, i, 3, temp, 0);
		ClearWaitTimes(ProjectNo,JProgramInfo);
	}

	JConfigInfo->jcxs.REC[0x26] = ATTRead(SPI1, 0x26, 3, temp, 0);
	JConfigInfo->jcxs.REC[0x27] = ATTRead(SPI1, 0x27, 3, temp, 0);
	JConfigInfo->jcxs.REC[0x28] = ATTRead(SPI1, 0x28, 3, temp, 0);
	JConfigInfo->jcxs.REC[0x29] = ATTRead(SPI1, 0x29, 3, temp, 0);
	JConfigInfo->jcxs.REC[0x2c] = ATTRead(SPI1, 0x2c, 3, temp, 0);

	JConfigInfo->jcxs.REC[0x48] = ATTRead(SPI1, 0x48, 3, temp, 0);//A���ѹ������Чֵ
	JConfigInfo->jcxs.REC[0x49] = ATTRead(SPI1, 0x49, 3, temp, 0);//B���ѹ������Чֵ
	JConfigInfo->jcxs.REC[0x4a] = ATTRead(SPI1, 0x4a, 3, temp, 0);//C���ѹ������Чֵ

//�й�����  ����10��
	tread = JConfigInfo->jcxs.REC[0x01] ;
	if (tread > 8388608)//2^23
		tread = tread -16777216;//2^24
	//tread = tread /757;
	JDataFileInfo->jc.RES.RES_PA= (tread*10.0/756)*(1.0*(1+(tmm-15)*0.0001));

	tread = JConfigInfo->jcxs.REC[0x02] ;
	if (tread > 8388608)//2^23
		tread = tread -16777216;//2^24
	//tread = tread /757;
	JDataFileInfo->jc.RES.RES_PB= (tread*10.0/756)*(1.0*(1+(tmm-15)*0.0001));

	tread = JConfigInfo->jcxs.REC[0x03] ;
	if (tread > 8388608)//2^23
		tread = tread -16777216;//2^24
	//tread = tread /757;
	JDataFileInfo->jc.RES.RES_PC= (tread*10.0/756)*(1.0*(1+(tmm-15)*0.0001));

	tread = JConfigInfo->jcxs.REC[0x04] ;
	if (tread > 8388608)//2^23
		tread = tread -16777216;//2^24
	//tread = tread*2/757;
	JDataFileInfo->jc.RES.RES_PZ= (tread*10.0*2/756)*(1.0*(1+(tmm-15)*0.0001));
//�޹�����  ����10��
	tread = JConfigInfo->jcxs.REC[0x05];
	if (tread > 8388608)
		tread = tread - 16777216;
	//tread = tread /757;
	JDataFileInfo->jc.RES.RES_QA= (tread*10.0/756)*(1.0*(1+(tmm-15)*1.2247*0.0001));

	tread = JConfigInfo->jcxs.REC[0x06];
	if (tread > 8388608)
		tread = tread - 16777216;
	//tread = tread /757;
	JDataFileInfo->jc.RES.RES_QB= (tread*10.0/756)*(1.0*(1+(tmm-15)*1.2247*0.0001));

	tread = JConfigInfo->jcxs.REC[0x07];
	if (tread > 8388608)
		tread = tread - 16777216;
	//tread = tread /757;
	JDataFileInfo->jc.RES.RES_QC= (tread*10.0/756)*(1.0*(1+(tmm-15)*1.2247*0.0001));

	tread = JConfigInfo->jcxs.REC[0x08];
	if (tread > 8388608)
		tread = tread - 16777216;
	//tread = tread*2/757;
	JDataFileInfo->jc.RES.RES_QZ= (tread*10.0*2/756)*(1.0*(1+(tmm-15)*1.2247*0.0001));
	//JDataFileInfo->jc.RES.RES_QZ=JDataFileInfo->jc.RES.RES_QA+JDataFileInfo->jc.RES.RES_QB+JDataFileInfo->jc.RES.RES_QC;

//���ڹ���  ����10�������ڹ������ڴ��ڵ���0������������з���λ���жϣ�
	tread = JConfigInfo->jcxs.REC[0x09] ;
	//tread = tread /757;
	JDataFileInfo->jc.RES.RES_SA= tread*10.0/756;

	tread = JConfigInfo->jcxs.REC[0x0a] ;
	//tread = tread /757;
	JDataFileInfo->jc.RES.RES_SB= tread*10.0/756;

	tread = JConfigInfo->jcxs.REC[0x0b] ;
	//tread = tread /757;
	JDataFileInfo->jc.RES.RES_SC= tread*10.0/756;

//	tread = JDataFileInfo->REC[0x0c] ;
//	//tread = tread*2/757;
//	JDataFileInfo->jc.RES.RES_SZ= tread*10.0*2/756;

//UA//UB//UC  ����10��
	tread = JConfigInfo->jcxs.REC[0x0D] * 10 / 8192;
	JDataFileInfo->jc.RES.RES_UA= tread * (1.0*(1+(tmm-15)*0.00008));
	tread = JConfigInfo->jcxs.REC[0x0E] * 10 / 8192;
	JDataFileInfo->jc.RES.RES_UB= tread * (1.0*(1+(tmm-15)*0.00008));
	tread = JConfigInfo->jcxs.REC[0x0F] * 10 / 8192;
	JDataFileInfo->jc.RES.RES_UC= tread * (1.0*(1+(tmm-15)*0.00008));

//IA//IB//IC  ����1000
	tread = (JConfigInfo->jcxs.REC[0x10] * 1000) / 8192;
	JDataFileInfo->jc.RES.RES_IA= tread * (1.0*(1+(tmm-15)*0.00005));
	tread = (JConfigInfo->jcxs.REC[0x11] * 1000) / 8192;
	JDataFileInfo->jc.RES.RES_IB= tread * (1.0*(1+(tmm-15)*0.00005));
	tread = (JConfigInfo->jcxs.REC[0x12] * 1000) / 8192;
	JDataFileInfo->jc.RES.RES_IC= tread * (1.0*(1+(tmm-15)*0.00005));
	JDataFileInfo->jc.RES.RES_I0 = (JConfigInfo->jcxs.REC[0x29] * 1000) / 8192; //I0

	//�й����޹�����ѹ���¶ȴ������Ĵ����仯�����в���
//	JDataFileInfo->jc.RES.RES_PA = JDataFileInfo->jc.RES.RES_PA*1.0*(1+(tmm-15)*0.0001);
//	JDataFileInfo->jc.RES.RES_PB = JDataFileInfo->jc.RES.RES_PB*1.0*(1+(tmm-15)*0.0001);
//	JDataFileInfo->jc.RES.RES_PC = JDataFileInfo->jc.RES.RES_PC*1.0*(1+(tmm-15)*0.0001);
//	JDataFileInfo->jc.RES.RES_PZ = JDataFileInfo->jc.RES.RES_PZ*1.0*(1+(tmm-15)*0.0001);
//
//	JDataFileInfo->jc.RES.RES_QA= JDataFileInfo->jc.RES.RES_QA*1.0*(1+(tmm-15)*1.2247*0.0001);
//	JDataFileInfo->jc.RES.RES_QB= JDataFileInfo->jc.RES.RES_QB*1.0*(1+(tmm-15)*1.2247*0.0001);
//	JDataFileInfo->jc.RES.RES_QC= JDataFileInfo->jc.RES.RES_QC*1.0*(1+(tmm-15)*1.2247*0.0001);
//	JDataFileInfo->jc.RES.RES_QZ= JDataFileInfo->jc.RES.RES_QZ*1.0*(1+(tmm-15)*1.2247*0.0001);
//
//	JDataFileInfo->jc.RES.RES_UA= JDataFileInfo->jc.RES.RES_UA*1.0*(1+(tmm-15)*0.0001);
//	JDataFileInfo->jc.RES.RES_UB= JDataFileInfo->jc.RES.RES_UB*1.0*(1+(tmm-15)*0.0001);
//	JDataFileInfo->jc.RES.RES_UC= JDataFileInfo->jc.RES.RES_UC*1.0*(1+(tmm-15)*0.0001);
//
//	JDataFileInfo->jc.RES.RES_IA= JDataFileInfo->jc.RES.RES_IA*1.0*(1+(tmm-15)*0.0001);
//	JDataFileInfo->jc.RES.RES_IB= JDataFileInfo->jc.RES.RES_IB*1.0*(1+(tmm-15)*0.0001);
//	JDataFileInfo->jc.RES.RES_IC= JDataFileInfo->jc.RES.RES_IC*1.0*(1+(tmm-15)*0.0001);

//	if(JDataFileInfo->jc.RES.RES_UA<2200){
//		JDataFileInfo->jc.RES.RES_PA = JDataFileInfo->jc.RES.RES_PA*1.0+(2200-JDataFileInfo->jc.RES.RES_UA)*0.006;
//		JDataFileInfo->jc.RES.RES_PB = JDataFileInfo->jc.RES.RES_PB*1.0+(2200-JDataFileInfo->jc.RES.RES_UB)*0.006;
//		JDataFileInfo->jc.RES.RES_PC = JDataFileInfo->jc.RES.RES_PC*1.0+(2200-JDataFileInfo->jc.RES.RES_UC)*0.006;
//	}else{
//		JDataFileInfo->jc.RES.RES_PA = JDataFileInfo->jc.RES.RES_PA*1.0-(JDataFileInfo->jc.RES.RES_UA-2200)*0.006;
//		JDataFileInfo->jc.RES.RES_PB = JDataFileInfo->jc.RES.RES_PB*1.0-(JDataFileInfo->jc.RES.RES_UB-2200)*0.006;
//		JDataFileInfo->jc.RES.RES_PC = JDataFileInfo->jc.RES.RES_PC*1.0-(JDataFileInfo->jc.RES.RES_UC-2200)*0.006;
//	}
//	if( (temper >185)&&(temper <205)){
//		JDataFileInfo->jc.RES.RES_SA= JDataFileInfo->jc.RES.RES_SA * WDXISHU /1000;
//		JDataFileInfo->jc.RES.RES_SB= JDataFileInfo->jc.RES.RES_SB * WDXISHU /1000;
//		JDataFileInfo->jc.RES.RES_SC= JDataFileInfo->jc.RES.RES_SC * WDXISHU /1000;
//	}
	JDataFileInfo->jc.RES.RES_SZ =JDataFileInfo->jc.RES.RES_SA+JDataFileInfo->jc.RES.RES_SB+JDataFileInfo->jc.RES.RES_SC;

//	//����  ��ѹ  �����¶Ȳ���--ԭ��
//	if( (temper >165)&&(temper <205))
//	{
//		Jmemory->jc.RES.RES_PA= Jmemory->jc.RES.RES_PA * WDXISHU /1000;
//		Jmemory->jc.RES.RES_PB= Jmemory->jc.RES.RES_PB * WDXISHU /1000;
//		Jmemory->jc.RES.RES_PC= Jmemory->jc.RES.RES_PC * WDXISHU /1000;
//		Jmemory->jc.RES.RES_PZ= Jmemory->jc.RES.RES_PZ * WDXISHU /1000;
//
//		Jmemory->jc.RES.RES_QA= Jmemory->jc.RES.RES_QA * WDXISHU /1000;
//		Jmemory->jc.RES.RES_QB= Jmemory->jc.RES.RES_QB * WDXISHU /1000;
//		Jmemory->jc.RES.RES_QC= Jmemory->jc.RES.RES_QC * WDXISHU /1000;
//		Jmemory->jc.RES.RES_QZ= Jmemory->jc.RES.RES_QZ * WDXISHU /1000;
//
//		Jmemory->jc.RES.RES_SA= Jmemory->jc.RES.RES_SA * WDXISHU /1000;
//		Jmemory->jc.RES.RES_SB= Jmemory->jc.RES.RES_SB * WDXISHU /1000;
//		Jmemory->jc.RES.RES_SC= Jmemory->jc.RES.RES_SC * WDXISHU /1000;
//
//		Jmemory->jc.RES.RES_UA= Jmemory->jc.RES.RES_UA * WDXISHU_UI /1000;
//		Jmemory->jc.RES.RES_UB= Jmemory->jc.RES.RES_UB * WDXISHU_UI /1000;
//		Jmemory->jc.RES.RES_UC= Jmemory->jc.RES.RES_UC * WDXISHU_UI /1000;
//
//		Jmemory->jc.RES.RES_IA= Jmemory->jc.RES.RES_IA * WDXISHU_UI /1000;
//		Jmemory->jc.RES.RES_IB= Jmemory->jc.RES.RES_IB * WDXISHU_UI /1000;
//		Jmemory->jc.RES.RES_IC= Jmemory->jc.RES.RES_IC * WDXISHU_UI /1000;
//	}
//	Jmemory->jc.RES.RES_SZ =Jmemory->jc.RES.RES_SA+Jmemory->jc.RES.RES_SB+Jmemory->jc.RES.RES_SC;

	tread = JConfigInfo->jcxs.REC[0x48] * 10 / 8192;
	JDataFileInfo->jc.RES.RES_JB_UA= tread ;
	tread = JConfigInfo->jcxs.REC[0x49] * 10 / 8192;
	JDataFileInfo->jc.RES.RES_JB_UB= tread;
	tread = JConfigInfo->jcxs.REC[0x4a] * 10 / 8192;
	JDataFileInfo->jc.RES.RES_JB_UC= tread;

//��������     ����1000
	if (JConfigInfo->jcxs.REC[0x14] > 8388608)
		JDataFileInfo->jc.RES.RES_PFA = (JConfigInfo->jcxs.REC[0x14] - 16777216) * 10.0 / 8388608 *100;
	else
		JDataFileInfo->jc.RES.RES_PFA = JConfigInfo->jcxs.REC[0x14] * 10.0 / 8388608 *100;
	if(abs(JDataFileInfo->jc.RES.RES_PA)<=1)JDataFileInfo->jc.RES.RES_PFA=0;//nengliang

	if (JConfigInfo->jcxs.REC[0x15] > 8388608)
		JDataFileInfo->jc.RES.RES_PFB = (JConfigInfo->jcxs.REC[0x15] - 16777216) * 10.0 / 8388608 *100;
	else
		JDataFileInfo->jc.RES.RES_PFB = JConfigInfo->jcxs.REC[0x15]* 10.0 / 8388608 *100;
	if(abs(JDataFileInfo->jc.RES.RES_PB)<=1)JDataFileInfo->jc.RES.RES_PFB=0;//nengliang

	if (JConfigInfo->jcxs.REC[0x16] > 8388608)
		JDataFileInfo->jc.RES.RES_PFC = (JConfigInfo->jcxs.REC[0x16] - 16777216) * 10.0 / 8388608 *100;
	else
		JDataFileInfo->jc.RES.RES_PFC = JConfigInfo->jcxs.REC[0x16] * 10.0 / 8388608 *100;
	if(abs(JDataFileInfo->jc.RES.RES_PC)<=1)JDataFileInfo->jc.RES.RES_PFC=0;//nengliang

	if (JConfigInfo->jcxs.REC[0x17] > 8388608)
		JDataFileInfo->jc.RES.RES_PFZ = (JConfigInfo->jcxs.REC[0x17] - 16777216) * 10.0 / 8388608 *100;
	else
		JDataFileInfo->jc.RES.RES_PFZ = JConfigInfo->jcxs.REC[0x17] * 10.0 / 8388608 *100;
	if(abs(JDataFileInfo->jc.RES.RES_PZ)<=1)JDataFileInfo->jc.RES.RES_PFZ=0;//nengliang

	//������ѹ��������Чֵ
		JDataFileInfo->jc.xiebo.AllXBo.UAbase=ATTRead(SPI1,0x48,3,temp,0)*1.0/8192;
		JDataFileInfo->jc.xiebo.AllXBo.UBbase=ATTRead(SPI1,0x49,3,temp,0)*1.0/8192;
		JDataFileInfo->jc.xiebo.AllXBo.UCbase=ATTRead(SPI1,0x4A,3,temp,0)*1.0/8192;
		JDataFileInfo->jc.xiebo.AllXBo.IAbase=ATTRead(SPI1,0x4B,3,temp,0)*1.0/8192;
		JDataFileInfo->jc.xiebo.AllXBo.IBbase=ATTRead(SPI1,0x4C,3,temp,0)*1.0/8192;
		JDataFileInfo->jc.xiebo.AllXBo.ICbase=ATTRead(SPI1,0x4D,3,temp,0)*1.0/8192;

		test = ATTRead(SPI1,0x1C,3,temp,0)*100/8192;
		if( (test>5600)||(test<4400) )   //45hz --- 55hz֮��
			HZall.HZBuff[HZall.HZpoint]  = 5000;
		else
			HZall.HZBuff[HZall.HZpoint]  = test;
		HZall.HZpoint = (HZall.HZpoint + 1) & 0xf;
		delay(100);

		test = ATTRead(SPI1,0x1C,3,temp,0)*100/8192;
		if( (test>5600)||(test<4400) )   //45hz --- 55hz֮��
			HZall.HZBuff[HZall.HZpoint]  = 5000;
		else
			HZall.HZBuff[HZall.HZpoint]  = test;

		JDataFileInfo->jc.RES.RES_F = XBhz(HZall.HZBuff,HZall.HZBuff[HZall.HZpoint]); //Ƶ��
		HZall.HZpoint = (HZall.HZpoint + 1) & 0xf;

//		JDataFileInfo->jc.RES.RES_F = JConfigInfo->jcxs.REC[0x1C] * 100 / Kf;//��Ƶ��
		JDataFileInfo->jc.RES.RES_FLAG = JConfigInfo->jcxs.REC[0x2C];        //��־״̬
		JConfigInfo->jcxs.REC[0x26] = ATTRead(SPI1,0x26,3,temp,0)/1048576.0*180*10;////Ua��Ub��ѹ�н�
		JConfigInfo->jcxs.REC[0x27] = ATTRead(SPI1,0x27,3,temp,0)/1048576.0*180*10;////Ua��Uc��ѹ�н�
		JConfigInfo->jcxs.REC[0x28] = ATTRead(SPI1,0x28,3,temp,0)/1048576.0*180*10;////Ub��Uc��ѹ�н�

	j = JDataFileInfo->jc.RES.RES_PFA / 1000.0;
	if (JDataFileInfo->jc.RES.RES_QA >= 0)
		JConfigInfo->jcxs.REC[0x18] = 3600 - acos(j) * 1800 / 3.14;
	else
		JConfigInfo->jcxs.REC[0x18] = (acos(j) * 1800 / 3.14);//A��������ѹ�н�
	j = JDataFileInfo->jc.RES.RES_PFB / 1000.0;
	if (JDataFileInfo->jc.RES.RES_QB >= 0)
		JConfigInfo->jcxs.REC[0x19] = 3600 - acos(j) * 1800 / 3.14;
	else
		JConfigInfo->jcxs.REC[0x19] = (acos(j) * 1800 / 3.14);//B��������ѹ�н�
	j = JDataFileInfo->jc.RES.RES_PFC / 1000.0;
	if (JDataFileInfo->jc.RES.RES_QC >= 0)
		JConfigInfo->jcxs.REC[0x1A] = 3600 - acos(j) * 1800 / 3.14;
	else
		JConfigInfo->jcxs.REC[0x1A] = (acos(j) * 1800 / 3.14);//C��������ѹ�н�
	if (((0 <= JConfigInfo->jcxs.REC[0x26]) && (JConfigInfo->jcxs.REC[0x26] <= 3600))
		&& ((0 <= JConfigInfo->jcxs.REC[0x27])&& (JConfigInfo->jcxs.REC[0x27] <= 3600))) {
		JDataFileInfo->jc.RES.RES_UAJ = 0;
		JDataFileInfo->jc.RES.RES_UBJ = JConfigInfo->jcxs.REC[0x26];
		JDataFileInfo->jc.RES.RES_UCJ = JConfigInfo->jcxs.REC[0x27];
		JDataFileInfo->jc.RES.RES_IAJ = JDataFileInfo->jc.RES.RES_UAJ - JConfigInfo->jcxs.REC[0x18];
		if (JDataFileInfo->jc.RES.RES_UBJ < 0)
			JDataFileInfo->jc.RES.RES_UBJ = JDataFileInfo->jc.RES.RES_UBJ + 3600;
		if (JDataFileInfo->jc.RES.RES_UCJ < 0)
			JDataFileInfo->jc.RES.RES_UCJ = JDataFileInfo->jc.RES.RES_UCJ + 3600;
		JDataFileInfo->jc.RES.RES_IBJ = JDataFileInfo->jc.RES.RES_UBJ - JConfigInfo->jcxs.REC[0x19];
		JDataFileInfo->jc.RES.RES_ICJ = JDataFileInfo->jc.RES.RES_UCJ - JConfigInfo->jcxs.REC[0x1A];
		if (JDataFileInfo->jc.RES.RES_IAJ < 0)
			JDataFileInfo->jc.RES.RES_IAJ = JDataFileInfo->jc.RES.RES_IAJ + 3600;
		if (JDataFileInfo->jc.RES.RES_IBJ < 0)
			JDataFileInfo->jc.RES.RES_IBJ = JDataFileInfo->jc.RES.RES_IBJ + 3600;
		if (JDataFileInfo->jc.RES.RES_ICJ < 0)
			JDataFileInfo->jc.RES.RES_ICJ = JDataFileInfo->jc.RES.RES_ICJ + 3600;

		if (JDataFileInfo->jc.RES.RES_IA < 2)
			JDataFileInfo->jc.RES.RES_IAJ = 0;

		if (JDataFileInfo->jc.RES.RES_IB < 2)
			JDataFileInfo->jc.RES.RES_IBJ = 0;

		if (JDataFileInfo->jc.RES.RES_IC < 2)
			JDataFileInfo->jc.RES.RES_ICJ = 0;

		if (JDataFileInfo->jc.RES.RES_UB < 10)
			JDataFileInfo->jc.RES.RES_UBJ = 0;

		if (JDataFileInfo->jc.RES.RES_UC < 10)
			JDataFileInfo->jc.RES.RES_UCJ = 0;
	}
	DisEnSpi();
}

/*************************************************************************************/
/*************  ��ѹ��������I0������ У������  ***************************************/
/*************************************************************************************/
//////////////////////2009.3.12/////////////////////
void modify_uipp(void) {

  	INT8U temp[3], i,j;
	INT32S ATT_PA, ATT_PB, ATT_PC;
	INT32S XISHU_UA, XISHU_UB, XISHU_UC, XISHU_IA, XISHU_IB, XISHU_IC;
	INT32S Temp_REC1[128];
	INT32S Temp_REC2[128];
	FP32 f_temp;
	memset(Temp_REC1,0,128);
	memset(Temp_REC2,0,128);
	JConfigInfo->jcxs.REC[0x0D]=0;
	JConfigInfo->jcxs.REC[0x0E]=0;
	JConfigInfo->jcxs.REC[0x0F]=0;
	JConfigInfo->jcxs.REC[0x10]=0;
	JConfigInfo->jcxs.REC[0x11]=0;
	JConfigInfo->jcxs.REC[0x12]=0;

	for (j= 0; j < 2; j++)
	{
		for (i = 0; i < 0x1D; i++)
		{
			Temp_REC1[i] = Temp_REC1[i] + ATTRead(SPI1, i, 3, temp, 0);
			Temp_REC1[i] = Temp_REC1[i]/(j+1);
		}
		delay(500);
	}
	for (j= 0; j < 2; j++)
	{
		for (i = 0; i < 0x1D; i++)
		{
			Temp_REC2[i] = Temp_REC2[i] + ATTRead(SPI1, i, 3, temp, 0);
			Temp_REC2[i] = Temp_REC2[i]/(j+1);
		}
		delay(500);
	}
	for (i=0;i<0x1D;i++)
	{
		JConfigInfo->jcxs.REC[i] = (Temp_REC1[i] + Temp_REC2[i])/2;
	}

	JConfigInfo->jcxs.REC[0x29] = ATTRead(SPI1, 0x29, 3, temp, 0);

	if (JConfigInfo->jcxs.REC[0x01] > 8388608)
		ATT_PA = (JConfigInfo->jcxs.REC[0x01] - 16777216) / 256; //pa
	else
		ATT_PA = JConfigInfo->jcxs.REC[0x01] / 256;

	if (JConfigInfo->jcxs.REC[0x02] > 8388608)
		ATT_PB = (JConfigInfo->jcxs.REC[0x02] - 16777216) / 256; //pb
	else
		ATT_PB = JConfigInfo->jcxs.REC[0x02] / 256;

	if (JConfigInfo->jcxs.REC[0x03] > 8388608)
		ATT_PC = (JConfigInfo->jcxs.REC[0x03] - 16777216) / 256; //pc
	else
		ATT_PC = JConfigInfo->jcxs.REC[0x03] / 256;

	//-------------------------------------------
	SdPrint("\n\r UA REC = % d",JConfigInfo->jcxs.REC[0x0D]);
	SdPrint("\n\r UB REC = % d",JConfigInfo->jcxs.REC[0x0E]);
	SdPrint("\n\r UC REC = % d",JConfigInfo->jcxs.REC[0x0F]);

	SdPrint("\n\r IA REC = % d",JConfigInfo->jcxs.REC[0x10]);
	SdPrint("\n\r IB REC = % d",JConfigInfo->jcxs.REC[0x11]);
	SdPrint("\n\r IC REC = % d",JConfigInfo->jcxs.REC[0x12]);
	//-------------------------------------------

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //����д����

    if(JConfigInfo->jcxs.REC[0x0D]!=0)
    {
	    f_temp =1.0*220*8192/JConfigInfo->jcxs.REC[0x0D];
	    SdPrint("\n\r f_temp = %f",f_temp);

		if (f_temp >= 1)
			XISHU_UA   =  (INT32U )((f_temp-1)*8388608);
		else
			XISHU_UA   =  (INT32U )((f_temp+1)*8388608);

		SdPrint("\n\r XISHU_UA = %x",XISHU_UA);

		temp[0] = (XISHU_UA & 0xff0000) >> 16;
		temp[1] = (XISHU_UA & 0xff00) >> 8;
		temp[2] = XISHU_UA & 0xff;
		JConfigInfo->jcxs.displayUA_xishu[0] = temp[0];
		JConfigInfo->jcxs.displayUA_xishu[1] = temp[1];
		JConfigInfo->jcxs.displayUA_xishu[2] = temp[2];
		SdPrint("\n\r xishu_ua= %x",XISHU_UA);
		SdPrint("\n\r ");
		ATTWrite(SPI1, 0x1B, 3, temp, 0);
	}

	if (JConfigInfo->jcxs.REC[0x0E] != 0) {
		f_temp = 1.0*220*8192/JConfigInfo->jcxs.REC[0x0E];
	    SdPrint("\n\r f_temp = %f",f_temp);
		if (f_temp >= 1)
			XISHU_UB   =  (INT32U )((f_temp-1)*8388608);
		else
			XISHU_UB   =  (INT32U )((f_temp+1)*8388608);
		SdPrint("\n\r XISHU_UB %x",XISHU_UB);

		temp[0] = (XISHU_UB & 0xff0000) >> 16;
		temp[1] = (XISHU_UB & 0xff00) >> 8;
		temp[2] = XISHU_UB & 0xff;
		JConfigInfo->jcxs.displayUB_xishu[0] = temp[0];
		JConfigInfo->jcxs.displayUB_xishu[1] = temp[1];
		JConfigInfo->jcxs.displayUB_xishu[2] = temp[2];

		ATTWrite(SPI1, 0x1C, 3, temp, 0);
	}

	if (JConfigInfo->jcxs.REC[0x0F] != 0) {
		f_temp = 1.0*220*8192/JConfigInfo->jcxs.REC[0x0F];
		if (f_temp >= 1)
			XISHU_UC   =  (INT32U )((f_temp-1)*8388608);
		else
			XISHU_UC   =  (INT32U )((f_temp+1)*8388608);
		temp[0] = (XISHU_UC & 0xff0000) >> 16;
		temp[1] = (XISHU_UC & 0xff00) >> 8;
		temp[2] = XISHU_UC & 0xff;
		JConfigInfo->jcxs.displayUC_xishu[0] = temp[0];
		JConfigInfo->jcxs.displayUC_xishu[1] = temp[1];
		JConfigInfo->jcxs.displayUC_xishu[2] = temp[2];

		ATTWrite(SPI1, 0x1D, 3, temp, 0);
	}

	if (JConfigInfo->jcxs.REC[0x10] != 0) {        //IA
		f_temp =1.0* 5*8192/JConfigInfo->jcxs.REC[0x10];
		if (f_temp >= 1)
			XISHU_IA   =  (INT32U )((f_temp-1)*8388608);
		else
			XISHU_IA   =  (INT32U )((f_temp+1)*8388608);
		temp[0] = (XISHU_IA & 0xff0000) >> 16;
		temp[1] = (XISHU_IA & 0xff00) >> 8;
		temp[2] = XISHU_IA & 0xff;
		JConfigInfo->jcxs.displayIA_xishu[0] = temp[0];
		JConfigInfo->jcxs.displayIA_xishu[1] = temp[1];
		JConfigInfo->jcxs.displayIA_xishu[2] = temp[2];

		ATTWrite(SPI1, 0x26, 3, temp, 0);
	}


	if (JConfigInfo->jcxs.REC[0x11] != 0) {        //IB
		f_temp = 1.0*5*8192/JConfigInfo->jcxs.REC[0x11];
		if (f_temp >= 1)
			XISHU_IB   =  (INT32U )((f_temp-1)*8388608);
		else
			XISHU_IB   =  (INT32U )((f_temp+1)*8388608);
		temp[0] = (XISHU_IB & 0xff0000) >> 16;
		temp[1] = (XISHU_IB & 0xff00) >> 8;
		temp[2] = XISHU_IB & 0xff;
		JConfigInfo->jcxs.displayIB_xishu[0] = temp[0];
		JConfigInfo->jcxs.displayIB_xishu[1] = temp[1];
		JConfigInfo->jcxs.displayIB_xishu[2] = temp[2];

		ATTWrite(SPI1, 0x27, 3, temp, 0);
	}


	if (JConfigInfo->jcxs.REC[0x12] != 0) {        //IC
		f_temp = 1.0*5*8192/JConfigInfo->jcxs.REC[0x12];
		if (f_temp >= 1)
			XISHU_IC   =  (INT32U )((f_temp-1)*8388608);
		else
			XISHU_IC   =  (INT32U )((f_temp+1)*8388608);
		temp[0] = (XISHU_IC & 0xff0000) >> 16;
		temp[1] = (XISHU_IC & 0xff00) >> 8;
		temp[2] = XISHU_IC & 0xff;
		JConfigInfo->jcxs.displayIC_xishu[0] = temp[0];
		JConfigInfo->jcxs.displayIC_xishu[1] = temp[1];
		JConfigInfo->jcxs.displayIC_xishu[2] = temp[2];

		ATTWrite(SPI1, 0x28, 3, temp, 0);
	}


	savefun();

	delay(2000);
	printf("modify_uipp end\n\r");

}

/*************************************************************************************/
/*************  �ǲ�У������  ********************************************************/
/*************************************************************************************/
//////////////////////2009.03.12//////////////////////

void jiaoxiu_pa(void)
{
	INT8U temp[3];
	float err;
	INT32U tem, jiaoxiu;

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //����д����

	if (MODE == 04)
		err = (JDataFileInfo->jc.RES.RES_PA - 5500) / 5500.0;
	else
		err = 0;

	tem = 300* acos ((1 + err) / 2);

	if (tem >= 314)
		jiaoxiu = (tem - 314) * 8388608 / 300;
	else
		jiaoxiu = (286 + tem) * (8388608 / 300);

	temp[0] = (jiaoxiu & 0xff0000) >> 16;
	temp[1] = (jiaoxiu & 0xff00) >> 8;
	temp[2] = jiaoxiu & 0xff;

	JConfigInfo->jcxs.displayA_jiaoxiu[0] = temp[0];
	JConfigInfo->jcxs.displayA_jiaoxiu[1] = temp[1];
	JConfigInfo->jcxs.displayA_jiaoxiu[2] = temp[2];

	ATTWrite(SPI1, 0xc, 3, temp, 0);
	ATTWrite(SPI1, 0xd, 3, temp, 0);
	ATTWrite(SPI1, 0xe, 3, temp, 0);
	ATTWrite(SPI1, 0xf, 3, temp, 0);
	ATTWrite(SPI1, 0x10, 3, temp, 0);

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 1;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //bu����д����
	SdPrint("\n\r mpa over!!!!!");
	SdPrint("\n\r over!!!!!");
	savefun();
	delay(2000);
	printf("jiaoxiu_pa end\n\r");
}
void mcjiaozheng() {
	INT8U temp[3];
	float Vu, Vi;
	//int EC = 6400;//3200
	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0x5a;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //����д����

	Vu = 0.1;//220*0.9/450;        //                      450/0.9  = 220/Vu
	//Vi=5*5*30/(1.5*1000);  //                      1.5/(5(mA)/1000)= 5(A)  /y     Vi=y*30(ŷ)
	Vi = 0.5;//((5*5*30)/1.5)/1000;
	//HFConst = (INT32U) (5760000000* 0.648 * 0.648 * Vu * Vi / (EC * 220* 1.5 ));

	//temp[0] = (HFConst & 0xff0000) >> 16;
	//temp[1] = (HFConst & 0xff00) >> 8;
	//temp[2] = HFConst & 0xff;

	//JConfigInfo->jcxs.displayMC_out_xishu[0] = temp[0];
	//JConfigInfo->jcxs.displayMC_out_xishu[1] = temp[1];
	//JConfigInfo->jcxs.displayMC_out_xishu[2] = temp[2];

	//printf("\n\r mcjiaozheng w HFConst=%d   temp0=%d   temp1=%d  temp2=%d ",HFConst,temp[0],temp[1],temp[2]);
	temp[0] = 0;
	temp[1] = 0;
	temp[2] =18; //JDataFileInfo->McAttr; //0xb;//0x39;
	ATTWrite(SPI1, 0x20, 3, temp, 0);

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 1;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //bu����д����
	savefun();
	printf("\n\r mc over!!!!!");
	printf("\n\r over!!!!!");
	printf("\n\r ");
}
void jiaoxiu_pb(void) {
	INT8U temp[3];
	float err;
	INT32U tem, jiaoxiu;

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //����д����


	if (MODE == 04)
		err = (JDataFileInfo->jc.RES.RES_PB - 5500) / 5500.0;
	else
		err = 0;

	tem = 300* acos ((1 + err) / 2);

	if (tem >= 314)
		jiaoxiu = (tem - 314) * 8388608 / 300;
	else
		jiaoxiu = (286 + tem) * (8388608 / 300);

	temp[0] = (jiaoxiu & 0xff0000) >> 16;
	temp[1] = (jiaoxiu & 0xff00) >> 8;
	temp[2] = jiaoxiu & 0xff;

	JConfigInfo->jcxs.displayB_jiaoxiu[0] = temp[0];
	JConfigInfo->jcxs.displayB_jiaoxiu[1] = temp[1];
	JConfigInfo->jcxs.displayB_jiaoxiu[2] = temp[2];

	ATTWrite(SPI1, 0x11, 3, temp, 0);
	ATTWrite(SPI1, 0x12, 3, temp, 0);
	ATTWrite(SPI1, 0x13, 3, temp, 0);
	ATTWrite(SPI1, 0x14, 3, temp, 0);
	ATTWrite(SPI1, 0x15, 3, temp, 0);

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 1;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //bu����д����
	SdPrint("\n\r mpb over!!!!!");
	SdPrint("\n\r over!!!!!");
	savefun();
	delay(2000);
	printf("jiaoxiu_pb end\n\r");
}

void jiaoxiu_pc(void) {
	INT8U temp[3];
	float err;
	INT32U tem, jiaoxiu;

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //����д����

	if (MODE == 04)
		err = (JDataFileInfo->jc.RES.RES_PC - 5500) / 5500.0;
	else
		err = 0;

	tem = 300* acos ((1 + err) / 2);

	if (tem >= 314)
		jiaoxiu = (tem - 314) * 8388608 / 300;
	else
		jiaoxiu = (286 + tem) * (8388608 / 300);

	temp[0] = (jiaoxiu & 0xff0000) >> 16;
	temp[1] = (jiaoxiu & 0xff00) >> 8;
	temp[2] = jiaoxiu & 0xff;

	JConfigInfo->jcxs.displayC_jiaoxiu[0] = temp[0];
	JConfigInfo->jcxs.displayC_jiaoxiu[1] = temp[1];
	JConfigInfo->jcxs.displayC_jiaoxiu[2] = temp[2];

	ATTWrite(SPI1, 0x16, 3, temp, 0);
	ATTWrite(SPI1, 0x17, 3, temp, 0);
	ATTWrite(SPI1, 0x18, 3, temp, 0);
	ATTWrite(SPI1, 0x19, 3, temp, 0);
	ATTWrite(SPI1, 0x1A, 3, temp, 0);

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 1;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //bu����д����
	SdPrint("\n\r mpc over!!!!!");
	SdPrint("\n\r over!!!!!");
	savefun();
	delay(2000);
	printf("jiaoxiu_pc end\n\r");
}
void qingabc_cc(void)
{
	INT8U temp[3];
	INT32U m;
	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0;
	SdPrint("qingabc begin\n\r");
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //����д����

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0;
	ATTWrite(SPI1, 0xc3, 3, temp, 0); //��У���Ĵ���


	temp[0] = 0x46;
    temp[1] = 0x55;
	temp[2] = 0x01;

	ATTWrite(SPI1, 0x3f, 3, temp, 0); //��ѹͨ��AD����

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 1;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //bu����д����

	m = ATTRead(SPI1, 0x20, 3, temp, 0);
	delay(2000);
	printf("qingabc end m=%d\n\r",m);

}
void qingabc(void) {
	INT8U temp[3];
	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0x5a;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //����д����

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0;
	ATTWrite(SPI1, 0xc3, 3, temp, 0); //��У������

	temp[0] = 0;
	temp[1] = 0xb9;
	temp[2] = 0xfe;
	ATTWrite(SPI1, 0x01, 3, temp, 0); //ģʽ����

	temp[0] = 0;
//	temp[1] = 0xF8;
	temp[1] = 0xFC;	//jiaocai   xiebos
	temp[2] = 0x84;//���������Ĵ����������㣬bit7��1//ϵͳ�Ƽ�д��F8 04
	ATTWrite(SPI1, 0x03, 3, temp, 0); //EMU��Ԫ����

	temp[0] = 0;
	temp[1] = 0x34;
	temp[2] = 0x37;
	ATTWrite(SPI1, 0x31, 3, temp, 0); //ģ��ģ��ʹ�ܼĴ���

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0;
	ATTWrite(SPI1, 0x16, 3, temp, 0); //�޹���λУ���Ĵ���

	temp[0] = 0x00;
	temp[1] = 0x01;
//	temp[2] = 0x6D;			jiaocai  zhou6
	temp[2] = 0x6D;
	ATTWrite(SPI1, 0x1e, 3, temp, 0); //��Ƶ���峣��
	//HFConst=INT[25920000000*G*G*Vu*Vi/(EC*Un*Ib)]  G=1.163   EC=6400  Vu=0.22  Vi=0.334  Un=220   Ib=5
/*****************+++++++++++<<<<<<<<<<<<<<*/
//	temp[0] = 0x00;
//	temp[1] = 0x00;
//	temp[2] = 0x00;
//	ATTWrite(SPI1, 0x02, 3, temp, 0); //��ѹͨ��AD����
/****************++++++++++++++>>>>>>>>>>>>>>>.*/
	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0;
	ATTWrite(SPI1, 0x0D, 3, temp, 0);//��λУ��
	ATTWrite(SPI1, 0x0E, 3, temp, 0);
	ATTWrite(SPI1, 0x0F, 3, temp, 0);
	ATTWrite(SPI1, 0x10, 3, temp, 0);
	ATTWrite(SPI1, 0x11, 3, temp, 0);
	ATTWrite(SPI1, 0x12, 3, temp, 0);

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 1;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //������д����

	fprintf(stderr,"\n\r  [qing end]\n\r");


}

/************************************************************************************
 *         ��λУ�������ȼ����Գ���
 *************************************************************************************/

void YCP_Jingdu(void) {

	SdPrint("\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r");

	SdPrint("\n\r                            ��GPRS�װ���λ���Ȳ�����\n\r");
	SdPrint("\n\r�밴������Ҫ����в�����\n\r");
	SdPrint("\n\r1�����µ�ѹ�����������ֵʱ����(�������߼�220v��5A��60�ȣ�������Ч��) \r");
	SdPrint("\n\r2���й����ʺ��޹����ʵ����ȼ�����ֵ������0.5���ȼ����ڣ�\r");

	SdPrint("\n\r*************************************************************************");
	SdPrint("\n\r                           ����������ʾ���£�");
	SdPrint("\n\r*************************************************************************\n\r");

	if (MODE == 4) {
		INT16U k;

		if (JDataFileInfo->jc.RES.RES_PZ != 0) {
			k = abs(JDataFileInfo->jc.RES.RES_PZ - 16500);
			if (k <= 165) {
				SdPrint("\n\rPz�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�0.%d��\n\r", k * 1000 / 16500);
			} else {
				SdPrint("\n\r�����������������ˣ���������Pz�������ϸ�NONONO!!!!     �����ȼ�����%d.%d��\n\r", k * 1000 / 16500 / 10, k * 1000 / 16500
							% 10);
			}
		}

		if (JDataFileInfo->jc.RES.RES_QZ != 0) {
			k = abs(JDataFileInfo->jc.RES.RES_QZ - 28578);
			if (k <= 285) {
				SdPrint("\n\rQz�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�0.%d��\n\r", k * 1000 / 28578);
			} else {
				SdPrint("\n\r�����������������ˣ���������Pz�������ϸ�NONONO!!!!     �����ȼ�����%d.%d��\n\r", k * 1000 / 28578 / 10, k * 1000 / 28578
							% 10);
			}
		}

		SdPrint("\n\r*************************************************************************");
		SdPrint("\n\r          �ǲ�У�����ȼ���ʾ���,�޴�ͨ�����д�����������");
		SdPrint("\n\r*************************************************************************\n\r");
	}

	else SdPrint("\n\r�������ն˽��߷�ʽ��������������������������n\r");

}
////////////////////////////////////////////////////////////////////////////////////////////////////////


void initdl() {
//	fprintf(stderr,"\n\r###########  initdl");
	INT8U i;
	Z_P_ALL_Temp = 0;
	F_P_ALL_Temp = 0;
	Q_1_ALL_Temp = 0;
	Q_2_ALL_Temp = 0;
	Q_3_ALL_Temp = 0;
	Q_4_ALL_Temp = 0;
	JDataFileInfo->jc.JcOldXuLiang.Z_P_Value = JDataFileInfo->jc.JcMaxXuliang.Z_P_X_All;
	JDataFileInfo->jc.JcOldXuLiang.Z_Q_Value = JDataFileInfo->jc.JcMaxXuliang.Z_Q_X_All;
	JDataFileInfo->jc.JcOldXuLiang.F_P_Value = JDataFileInfo->jc.JcMaxXuliang.F_P_X_All;
	JDataFileInfo->jc.JcOldXuLiang.F_Q_Value = JDataFileInfo->jc.JcMaxXuliang.F_Q_X_All;
	for (i = 0; i < FeiLvNum; i++) {
		JDataFileInfo->jc.JcOldXuLiang.Z_P_FL_Value[i] = JDataFileInfo->jc.JcMaxXuliang.Z_P_X_F[i];
		JDataFileInfo->jc.JcOldXuLiang.F_P_FL_Value[i] = JDataFileInfo->jc.JcMaxXuliang.F_P_X_F[i];
		JDataFileInfo->jc.JcOldXuLiang.Z_Q_FL_Value[i] = JDataFileInfo->jc.JcMaxXuliang.Z_Q_X_F[i];
		JDataFileInfo->jc.JcOldXuLiang.F_Q_FL_Value[i] = JDataFileInfo->jc.JcMaxXuliang.F_Q_X_F[i];

		JDataFileInfo->jc.JcOldXuLiang.X1_Q_FL_Value[i] = JDataFileInfo->jc.JcMaxXuliang.X1_Q_F[i];
		JDataFileInfo->jc.JcOldXuLiang.X2_Q_FL_Value[i] = JDataFileInfo->jc.JcMaxXuliang.X2_Q_F[i];
		JDataFileInfo->jc.JcOldXuLiang.X3_Q_FL_Value[i] = JDataFileInfo->jc.JcMaxXuliang.X3_Q_F[i];
		JDataFileInfo->jc.JcOldXuLiang.X4_Q_FL_Value[i] = JDataFileInfo->jc.JcMaxXuliang.X4_Q_F[i];
	}

//	fprintf(stderr,"\n\r###########  initdl   end");
}

unsigned int Z_P_All;//�����й��ܵ���(+A)6 7 8 9
unsigned int Z_P_F[FeiLvNum];//����1<-->4�����й����� 9 10 11

unsigned int F_P_All;//�����й��ܵ���(-A)
unsigned int F_P_F[FeiLvNum];//����1�����й�����

unsigned int Z_Q_All;//�����޹��ܵ���(+RL,+RC)
unsigned int Z_Q_F[FeiLvNum];//����1�����޹�����

unsigned int F_Q_All;//�����޹��ܵ���(-RL,-RC)
unsigned int F_Q_F[FeiLvNum];//����1�����޹�����

unsigned int X1_Q_All;//һ�����޹��ܵ���(+RL)
unsigned int X1_F_Q[FeiLvNum];//����1һ�����޹�����

unsigned int X4_Q_All;//�������޹��ܵ���(-Rc)
unsigned int X4_F_Q[FeiLvNum];//����1�������޹�����

unsigned int X2_Q_All;//�������޹��ܵ���(+RC)
unsigned int X2_F_Q[FeiLvNum];//����1�������޹�����

unsigned int X3_Q_All;//�������޹��ܵ���(�DRL)
unsigned int X3_F_Q[FeiLvNum];//����1�������޹�����

void dddealpro(void) {			//jiaocai
	INT8U tmp;

	tmp = JDataFileInfo->jc.NowFeiLvNo;

	if (JDataFileInfo->jc.RES.RES_PZ >= 0) //�����������
	{
		Z_P_ALL_Temp = Z_P_ALL_Temp + abs(JDataFileInfo->jc.RES.RES_PZ);
		JDataFileInfo->jc.JcDdRealData.Z_P_All = JDataFileInfo->jc.JcDdRealData.Z_P_All + Z_P_ALL_Temp / 360000;
		JDataFileInfo->jc.JcDdRealData.Z_P_F[tmp] += Z_P_ALL_Temp / 360000; //by liuxw
		Z_P_ALL_Temp = Z_P_ALL_Temp % 360000;

		Z_P_All = Z_P_All + Z_P_ALL_Temp / 360000;
		Z_P_F[tmp] += Z_P_ALL_Temp / 360000;
	}

	if (JDataFileInfo->jc.RES.RES_PZ < 0) //�����������
	{
		F_P_ALL_Temp = F_P_ALL_Temp + abs(JDataFileInfo->jc.RES.RES_PZ);
		JDataFileInfo->jc.JcDdRealData.F_P_All = JDataFileInfo->jc.JcDdRealData.F_P_All + F_P_ALL_Temp / 360000;
		JDataFileInfo->jc.JcDdRealData.F_P_F[tmp] += F_P_ALL_Temp / 360000; //by liuxw
		F_P_ALL_Temp = F_P_ALL_Temp % 360000;
	}

	JDataFileInfo->jc.JcMaxXuliang.Q_X_1 = 0;
	JDataFileInfo->jc.JcMaxXuliang.Q_X_2 = 0;
	JDataFileInfo->jc.JcMaxXuliang.Q_X_3 = 0;
	JDataFileInfo->jc.JcMaxXuliang.Q_X_4 = 0;

	if (JDataFileInfo->jc.RES.RES_PZ >= 0) {
		if (JDataFileInfo->jc.RES.RES_QZ >= 0) {
			Q_1_ALL_Temp = Q_1_ALL_Temp + (JDataFileInfo->jc.RES.RES_QZ);
			JDataFileInfo->jc.JcDdRealData.X1_Q_All = JDataFileInfo->jc.JcDdRealData.X1_Q_All + Q_1_ALL_Temp / 360000;
			JDataFileInfo->jc.JcDdRealData.X1_F_Q[tmp] += Q_1_ALL_Temp / 360000; //by liuxw
			Q_1_ALL_Temp = Q_1_ALL_Temp % 360000;
			JDataFileInfo->jc.JcMaxXuliang.Q_X_1 = JDataFileInfo->jc.RES.RES_QZ;
		}
		else {
			Q_4_ALL_Temp = Q_4_ALL_Temp + abs(JDataFileInfo->jc.RES.RES_QZ);
			JDataFileInfo->jc.JcDdRealData.X4_Q_All = JDataFileInfo->jc.JcDdRealData.X4_Q_All + Q_4_ALL_Temp / 360000;
			JDataFileInfo->jc.JcDdRealData.X4_F_Q[tmp] += Q_4_ALL_Temp / 360000; //by liuxw
			Q_4_ALL_Temp = Q_4_ALL_Temp % 360000;
			JDataFileInfo->jc.JcMaxXuliang.Q_X_4 = JDataFileInfo->jc.RES.RES_QZ;
		}

	} else {
		if (JDataFileInfo->jc.RES.RES_QZ < 0) {
			Q_3_ALL_Temp = Q_3_ALL_Temp + abs(JDataFileInfo->jc.RES.RES_QZ);
			JDataFileInfo->jc.JcDdRealData.X3_Q_All = JDataFileInfo->jc.JcDdRealData.X3_Q_All + Q_3_ALL_Temp / 360000;
			JDataFileInfo->jc.JcDdRealData.X3_F_Q[tmp] += Q_3_ALL_Temp / 360000; //by liuxw
			Q_3_ALL_Temp = Q_3_ALL_Temp % 360000;
			JDataFileInfo->jc.JcMaxXuliang.Q_X_3 = JDataFileInfo->jc.RES.RES_QZ;
		} else {
			Q_2_ALL_Temp = Q_2_ALL_Temp + (JDataFileInfo->jc.RES.RES_QZ);
			JDataFileInfo->jc.JcDdRealData.X2_Q_All = JDataFileInfo->jc.JcDdRealData.X2_Q_All + Q_2_ALL_Temp / 360000;
			JDataFileInfo->jc.JcDdRealData.X2_F_Q[tmp] += Q_2_ALL_Temp / 360000; //by liuxw
			Q_2_ALL_Temp = Q_2_ALL_Temp % 360000;
			JDataFileInfo->jc.JcMaxXuliang.Q_X_2 = JDataFileInfo->jc.RES.RES_QZ;
		}

	}
	JDataFileInfo->jc.JcDdRealData.Z_Q_All = JDataFileInfo->jc.JcDdRealData.X1_Q_All + JDataFileInfo->jc.JcDdRealData.X2_Q_All;
	JDataFileInfo->jc.JcDdRealData.Z_Q_F[tmp] = JDataFileInfo->jc.JcDdRealData.X1_F_Q[tmp] + JDataFileInfo->jc.JcDdRealData.X2_F_Q[tmp];//by liuxw
	JDataFileInfo->jc.JcDdRealData.F_Q_All = JDataFileInfo->jc.JcDdRealData.X4_Q_All + JDataFileInfo->jc.JcDdRealData.X3_Q_All;
	JDataFileInfo->jc.JcDdRealData.F_Q_F[tmp] = JDataFileInfo->jc.JcDdRealData.X4_F_Q[tmp] + JDataFileInfo->jc.JcDdRealData.X3_F_Q[tmp];//by liuxw

}
void calcdianliang_CC()
{
	return;
}
void calcdianliang_EE() {

	INT8U tmp;
	INT8U temp[3];
	float tread;
	tmp = JDataFileInfo->jc.NowFeiLvNo;
	ClearWaitTimes(ProjectNo,JProgramInfo);

//�й����޹������Ĵ���
	JConfigInfo->jcxs.REC[0x21] = ATTRead(SPI1, 0x21, 3, temp, 0);//�����й�������
	JConfigInfo->jcxs.REC[0x25] = ATTRead(SPI1, 0x25, 3, temp, 0);//�����޹�������
	JConfigInfo->jcxs.REC[0x3D] = ATTRead(SPI1, 0x3D, 3, temp, 0);//�й����޹����ʷ���Ĵ���

//	SdPrint("\n\rJDataFileInfo->REC[0x21]=%d",JConfigInfo->jcxs.REC[0x21]);
//	SdPrint("\n\rJDataFileInfo->REC[0x25]=%d",JConfigInfo->jcxs.REC[0x25]);
//�����й��ܵ���    ����100*10��
//	tread = JConfigInfo->jcxs.REC[0x21] * 1000.0 / 6400;
	tread = JConfigInfo->jcxs.REC[0x21];			//���ղ��Լ�С���

	//JConfigInfo->RES.RES_PALLZ= tread;

//�����й��ܵ��� ����100��
	if(JConfigInfo->jcxs.REC[0x3D]&0x08)
	{
		JDataFileInfo->jc.RES.RES_PALLF= tread; //abs(JDataFileInfo->jc.RES.RES_PZ)*10.0/60;
		JDataFileInfo->jc.RES.RES_PALLZ= 0;
		//fprintf(stderr,"\n-----�����й�!! %f",tread);
	}
	else
	{
		JDataFileInfo->jc.RES.RES_PALLF=0;
		JDataFileInfo->jc.RES.RES_PALLZ= tread;
		//fprintf(stderr,"\n-----�����й�!! %f",tread);
	}

//�����޹��ܵ���    ����100*10��
	tread = JConfigInfo->jcxs.REC[0x25] ;//* 1000.0 / 6400;
	//JDataFileInfo->jc.RES.RES_QALLZ= tread;
//�����޹��ܵ���  ����100��
	if(JConfigInfo->jcxs.REC[0x3D]&0x80)
	{
		JDataFileInfo->jc.RES.RES_QALLF= tread;//abs(JDataFileInfo->jc.RES.RES_QZ)*10.0/60;
		JDataFileInfo->jc.RES.RES_QALLZ=0;
	}
	else
	{
		JDataFileInfo->jc.RES.RES_QALLZ=tread;
		JDataFileInfo->jc.RES.RES_QALLF=0;
	}

	//---lcy
	JConfigInfo->jcxs.REC[0x1E] = ATTRead(SPI1, 0x1E, 3, temp, 0);//A���й�������
	tread = JConfigInfo->jcxs.REC[0x1E];
	if(JConfigInfo->jcxs.REC[0x3D]&0x01)
	{
		JDataFileInfo->jc.RES.RES_PALLAF= tread; //abs(JDataFileInfo->jc.RES.RES_PZ)*10.0/60;
		JDataFileInfo->jc.RES.RES_PALLAZ= 0;
	}else
	{
		JDataFileInfo->jc.RES.RES_PALLAF=0;
		JDataFileInfo->jc.RES.RES_PALLAZ= tread;
	}
	JConfigInfo->jcxs.REC[0x1F] = ATTRead(SPI1, 0x1F, 3, temp, 0);//B���й�������
	tread = JConfigInfo->jcxs.REC[0x1F];
	if(JConfigInfo->jcxs.REC[0x3D]&0x02)
	{
		JDataFileInfo->jc.RES.RES_PALLBF= tread; //abs(JDataFileInfo->jc.RES.RES_PZ)*10.0/60;
		JDataFileInfo->jc.RES.RES_PALLBZ= 0;
	}else
	{
		JDataFileInfo->jc.RES.RES_PALLBF=0;
		JDataFileInfo->jc.RES.RES_PALLBZ= tread;
	}
	JConfigInfo->jcxs.REC[0x20] = ATTRead(SPI1, 0x20, 3, temp, 0);//C���й�������
	tread = JConfigInfo->jcxs.REC[0x20];
	if(JConfigInfo->jcxs.REC[0x3D]&0x04)
	{
		JDataFileInfo->jc.RES.RES_PALLCF= tread; //abs(JDataFileInfo->jc.RES.RES_PZ)*10.0/60;
		JDataFileInfo->jc.RES.RES_PALLCZ= 0;
	}else
	{
		JDataFileInfo->jc.RES.RES_PALLCF=0;
		JDataFileInfo->jc.RES.RES_PALLCZ= tread;
	}
	//�޹��������й������Ĵ���
	JConfigInfo->jcxs.REC[0x22] = ATTRead(SPI1, 0x22, 3, temp, 0);//A���й�������
	tread = JConfigInfo->jcxs.REC[0x22];
	if(JConfigInfo->jcxs.REC[0x3D]&0x10)
	{
		JDataFileInfo->jc.RES.RES_QALLAF= tread; //abs(JDataFileInfo->jc.RES.RES_PZ)*10.0/60;
		JDataFileInfo->jc.RES.RES_QALLAZ= 0;
	}else
	{
		JDataFileInfo->jc.RES.RES_QALLAF=0;
		JDataFileInfo->jc.RES.RES_QALLAZ= tread;
	}
	JConfigInfo->jcxs.REC[0x23] = ATTRead(SPI1, 0x23, 3, temp, 0);//B���й�������
	tread = JConfigInfo->jcxs.REC[0x23];
	if(JConfigInfo->jcxs.REC[0x3D]&0x20)
	{
		JDataFileInfo->jc.RES.RES_QALLBF= tread; //abs(JDataFileInfo->jc.RES.RES_PZ)*10.0/60;
		JDataFileInfo->jc.RES.RES_QALLBZ= 0;
	}else
	{
		JDataFileInfo->jc.RES.RES_QALLBF=0;
		JDataFileInfo->jc.RES.RES_QALLBZ= tread;
	}
	JConfigInfo->jcxs.REC[0x24] = ATTRead(SPI1, 0x24, 3, temp, 0);//C���й�������
	tread = JConfigInfo->jcxs.REC[0x24];
	if(JConfigInfo->jcxs.REC[0x3D]&0x40)
	{
		JDataFileInfo->jc.RES.RES_QALLCF= tread; //abs(JDataFileInfo->jc.RES.RES_PZ)*10.0/60;
		JDataFileInfo->jc.RES.RES_QALLCZ= 0;
	}else
	{
		JDataFileInfo->jc.RES.RES_QALLCF=0;
		JDataFileInfo->jc.RES.RES_QALLCZ= tread;
	}

//	fprintf(stderr,"\n\rJDataFileInfo->jc.ES.RES_QZ=%d",JDataFileInfo->jc.RES.RES_QZ);
//	fprintf(stderr,"\n\rJDataFileInfo->jc.RES.RES_QALLF=%f",JDataFileInfo->jc.RES.RES_QALLF);

//    JDataFileInfo->jc.JcDdRealData.Z_P_All=(JDataFileInfo->jc.JcDdRealData.Z_P_All + JDataFileInfo->jc.RES.RES_PALLZ)/10;    //���ղ�����ֵ̫С����Ⱥ����
   //---lcy
	JDataFileInfo->jc.JcDdRealData.Z_P_All=(JDataFileInfo->jc.JcDdRealData.Z_P_All + JDataFileInfo->jc.RES.RES_PALLZ);
	JDataFileInfo->jc.JcDdRealData.Z_P_F[tmp]=JDataFileInfo->jc.JcDdRealData.Z_P_F[tmp]+JDataFileInfo->jc.RES.RES_PALLZ;//old

	JDataFileInfo->jc.JcDdRealData.F_P_All= JDataFileInfo->jc.JcDdRealData.F_P_All+JDataFileInfo->jc.RES.RES_PALLF;//old
	JDataFileInfo->jc.JcDdRealData.F_P_F[tmp]=JDataFileInfo->jc.JcDdRealData.F_P_F[tmp]+JDataFileInfo->jc.RES.RES_PALLF;//old

	JDataFileInfo->jc.JcDdRealData.A_Z_P_All=JDataFileInfo->jc.JcDdRealData.A_Z_P_All+JDataFileInfo->jc.RES.RES_PALLAZ;
	JDataFileInfo->jc.JcDdRealData.B_Z_P_All=JDataFileInfo->jc.JcDdRealData.B_Z_P_All+JDataFileInfo->jc.RES.RES_PALLBZ;
	JDataFileInfo->jc.JcDdRealData.C_Z_P_All=JDataFileInfo->jc.JcDdRealData.C_Z_P_All+JDataFileInfo->jc.RES.RES_PALLCZ;

	JDataFileInfo->jc.JcDdRealData.A_F_P_All=JDataFileInfo->jc.JcDdRealData.A_F_P_All+JDataFileInfo->jc.RES.RES_PALLAF;
	JDataFileInfo->jc.JcDdRealData.B_F_P_All=JDataFileInfo->jc.JcDdRealData.B_F_P_All+JDataFileInfo->jc.RES.RES_PALLBF;
	JDataFileInfo->jc.JcDdRealData.C_F_P_All=JDataFileInfo->jc.JcDdRealData.C_F_P_All+JDataFileInfo->jc.RES.RES_PALLCF;

	JDataFileInfo->jc.JcDdRealData.A_Z_Q_All=JDataFileInfo->jc.JcDdRealData.A_Z_Q_All+JDataFileInfo->jc.RES.RES_QALLAZ;
	JDataFileInfo->jc.JcDdRealData.B_Z_Q_All=JDataFileInfo->jc.JcDdRealData.B_Z_Q_All+JDataFileInfo->jc.RES.RES_QALLBZ;
	JDataFileInfo->jc.JcDdRealData.C_Z_Q_All=JDataFileInfo->jc.JcDdRealData.C_Z_Q_All+JDataFileInfo->jc.RES.RES_QALLCZ;

	JDataFileInfo->jc.JcDdRealData.A_F_Q_All=JDataFileInfo->jc.JcDdRealData.A_F_Q_All+JDataFileInfo->jc.RES.RES_QALLAF;
	JDataFileInfo->jc.JcDdRealData.B_F_Q_All=JDataFileInfo->jc.JcDdRealData.B_F_Q_All+JDataFileInfo->jc.RES.RES_QALLBF;
	JDataFileInfo->jc.JcDdRealData.C_F_Q_All=JDataFileInfo->jc.JcDdRealData.C_F_Q_All+JDataFileInfo->jc.RES.RES_QALLCF;

	JDataFileInfo->jc.JcMaxXuliang.Q_X_1 = 0;
	JDataFileInfo->jc.JcMaxXuliang.Q_X_2 = 0;
	JDataFileInfo->jc.JcMaxXuliang.Q_X_3 = 0;
	JDataFileInfo->jc.JcMaxXuliang.Q_X_4 = 0;

	if (JDataFileInfo->jc.RES.RES_PZ >= 0) {
		if (JDataFileInfo->jc.RES.RES_QZ >= 0) {
			JDataFileInfo->jc.JcDdRealData.X1_Q_All=  JDataFileInfo->jc.JcDdRealData.X1_Q_All+JDataFileInfo->jc.RES.RES_QALLZ;//old
			JDataFileInfo->jc.JcDdRealData.X1_F_Q[tmp]= JDataFileInfo->jc.JcDdRealData.X1_F_Q[tmp]+JDataFileInfo->jc.RES.RES_QALLZ;//old
			JDataFileInfo->jc.JcMaxXuliang.Q_X_1 = JDataFileInfo->jc.RES.RES_QZ;
		}

		else {
			JDataFileInfo->jc.JcDdRealData.X4_Q_All= JDataFileInfo->jc.JcDdRealData.X4_Q_All+JDataFileInfo->jc.RES.RES_QALLZ;//old
			JDataFileInfo->jc.JcDdRealData.X4_F_Q[tmp]= JDataFileInfo->jc.JcDdRealData.X4_F_Q[tmp]+JDataFileInfo->jc.RES.RES_QALLZ;//old
			JDataFileInfo->jc.JcMaxXuliang.Q_X_4 = JDataFileInfo->jc.RES.RES_QZ;
		}

	} else {
		if (JDataFileInfo->jc.RES.RES_QZ < 0) {
			JDataFileInfo->jc.JcDdRealData.X3_Q_All= JDataFileInfo->jc.JcDdRealData.X3_Q_All+JDataFileInfo->jc.RES.RES_QALLF;//old
			JDataFileInfo->jc.JcDdRealData.X3_F_Q[tmp]= JDataFileInfo->jc.JcDdRealData.X3_F_Q[tmp]+JDataFileInfo->jc.RES.RES_QALLF;//old
			JDataFileInfo->jc.JcMaxXuliang.Q_X_3 = JDataFileInfo->jc.RES.RES_QZ;
		} else {
			JDataFileInfo->jc.JcDdRealData.X2_Q_All= JDataFileInfo->jc.JcDdRealData.X2_Q_All+JDataFileInfo->jc.RES.RES_QALLF;//old
			JDataFileInfo->jc.JcDdRealData.X2_F_Q[tmp]= JDataFileInfo->jc.JcDdRealData.X2_F_Q[tmp]+JDataFileInfo->jc.RES.RES_QALLF;//old
			JDataFileInfo->jc.JcMaxXuliang.Q_X_2 = JDataFileInfo->jc.RES.RES_QZ;
		}

	}
	//----lcy����޹�1��2����
	//����޹�����1��2����1--4�����޹��ܵ����Լ������ֽ���ʸ����
	//����޹�������1��ʼ��Ϊ0x05��һ��������ӣ�������޹�������2��ʼ��Ϊ0x50������������ӣ�
	switch(JDataFileInfo->JcPara_645.WuGongZuHeByte1&0x03){
		case 0x01:
			JDataFileInfo->jc.JcDdRealData.Z_Q_All = JDataFileInfo->jc.JcDdRealData.X1_Q_All;
			JDataFileInfo->jc.JcDdRealData.Z_Q_F[tmp]=JDataFileInfo->jc.JcDdRealData.X1_F_Q[tmp];
			break;
		case 0x02:
			JDataFileInfo->jc.JcDdRealData.Z_Q_All = -JDataFileInfo->jc.JcDdRealData.X1_Q_All;
			JDataFileInfo->jc.JcDdRealData.Z_Q_F[tmp]=-JDataFileInfo->jc.JcDdRealData.X1_F_Q[tmp];
			break;
	}
	switch((JDataFileInfo->JcPara_645.WuGongZuHeByte1>>2)&0x03){
		case 0x01:
			JDataFileInfo->jc.JcDdRealData.Z_Q_All=JDataFileInfo->jc.JcDdRealData.Z_Q_All+ JDataFileInfo->jc.JcDdRealData.X2_Q_All;
			JDataFileInfo->jc.JcDdRealData.Z_Q_F[tmp]=JDataFileInfo->jc.JcDdRealData.Z_Q_F[tmp]+JDataFileInfo->jc.JcDdRealData.X2_F_Q[tmp];
			break;
		case 0x02:
			JDataFileInfo->jc.JcDdRealData.Z_Q_All=JDataFileInfo->jc.JcDdRealData.Z_Q_All- JDataFileInfo->jc.JcDdRealData.X2_Q_All;
			JDataFileInfo->jc.JcDdRealData.Z_Q_F[tmp]=JDataFileInfo->jc.JcDdRealData.Z_Q_F[tmp]-JDataFileInfo->jc.JcDdRealData.X2_F_Q[tmp];
			break;
	}
	switch((JDataFileInfo->JcPara_645.WuGongZuHeByte1>>4)&0x03){
		case 0x01:
			JDataFileInfo->jc.JcDdRealData.Z_Q_All =JDataFileInfo->jc.JcDdRealData.Z_Q_All+ JDataFileInfo->jc.JcDdRealData.X3_Q_All;
			JDataFileInfo->jc.JcDdRealData.Z_Q_F[tmp]=JDataFileInfo->jc.JcDdRealData.Z_Q_F[tmp]+JDataFileInfo->jc.JcDdRealData.X3_F_Q[tmp];
			break;
		case 0x02:
			JDataFileInfo->jc.JcDdRealData.Z_Q_All =JDataFileInfo->jc.JcDdRealData.Z_Q_All -JDataFileInfo->jc.JcDdRealData.X3_Q_All;
			JDataFileInfo->jc.JcDdRealData.Z_Q_F[tmp]=JDataFileInfo->jc.JcDdRealData.Z_Q_F[tmp]-JDataFileInfo->jc.JcDdRealData.X3_F_Q[tmp];
			break;
	}
	switch((JDataFileInfo->JcPara_645.WuGongZuHeByte1>>6)&0x03){
		case 0x01:
			JDataFileInfo->jc.JcDdRealData.Z_Q_All = JDataFileInfo->jc.JcDdRealData.Z_Q_All+JDataFileInfo->jc.JcDdRealData.X4_Q_All;
			JDataFileInfo->jc.JcDdRealData.Z_Q_F[tmp]=JDataFileInfo->jc.JcDdRealData.Z_Q_F[tmp]+JDataFileInfo->jc.JcDdRealData.X4_F_Q[tmp];
			break;
		case 0x02:
			JDataFileInfo->jc.JcDdRealData.Z_Q_All = JDataFileInfo->jc.JcDdRealData.Z_Q_All-JDataFileInfo->jc.JcDdRealData.X4_Q_All;
			JDataFileInfo->jc.JcDdRealData.Z_Q_F[tmp]=JDataFileInfo->jc.JcDdRealData.Z_Q_F[tmp]-JDataFileInfo->jc.JcDdRealData.X4_F_Q[tmp];
			break;
	}
	switch(JDataFileInfo->JcPara_645.WuGongZuHeByte2&0x03){
		case 0x01:
			JDataFileInfo->jc.JcDdRealData.F_Q_All = JDataFileInfo->jc.JcDdRealData.X1_Q_All;
			JDataFileInfo->jc.JcDdRealData.F_Q_F[tmp]=JDataFileInfo->jc.JcDdRealData.X1_F_Q[tmp];
			break;
		case 0x02:
			JDataFileInfo->jc.JcDdRealData.F_Q_All = -JDataFileInfo->jc.JcDdRealData.X1_Q_All;
			JDataFileInfo->jc.JcDdRealData.F_Q_F[tmp]=-JDataFileInfo->jc.JcDdRealData.X1_F_Q[tmp];
			break;
	}
	switch((JDataFileInfo->JcPara_645.WuGongZuHeByte2>>2)&0x03){
		case 0x01:
			JDataFileInfo->jc.JcDdRealData.F_Q_All=JDataFileInfo->jc.JcDdRealData.F_Q_All+ JDataFileInfo->jc.JcDdRealData.X2_Q_All;
			JDataFileInfo->jc.JcDdRealData.F_Q_F[tmp]=JDataFileInfo->jc.JcDdRealData.F_Q_F[tmp]+JDataFileInfo->jc.JcDdRealData.X2_F_Q[tmp];
			break;
		case 0x02:
			JDataFileInfo->jc.JcDdRealData.F_Q_All=JDataFileInfo->jc.JcDdRealData.F_Q_All- JDataFileInfo->jc.JcDdRealData.X2_Q_All;
			JDataFileInfo->jc.JcDdRealData.F_Q_F[tmp]=JDataFileInfo->jc.JcDdRealData.F_Q_F[tmp]-JDataFileInfo->jc.JcDdRealData.X2_F_Q[tmp];
			break;
	}
	switch((JDataFileInfo->JcPara_645.WuGongZuHeByte2>>4)&0x03){
		case 0x01:
			JDataFileInfo->jc.JcDdRealData.F_Q_All =JDataFileInfo->jc.JcDdRealData.F_Q_All+ JDataFileInfo->jc.JcDdRealData.X3_Q_All;
			JDataFileInfo->jc.JcDdRealData.F_Q_F[tmp]=JDataFileInfo->jc.JcDdRealData.F_Q_F[tmp]+JDataFileInfo->jc.JcDdRealData.X3_F_Q[tmp];
			break;
		case 0x02:
			JDataFileInfo->jc.JcDdRealData.F_Q_All =JDataFileInfo->jc.JcDdRealData.F_Q_All -JDataFileInfo->jc.JcDdRealData.X3_Q_All;
			JDataFileInfo->jc.JcDdRealData.F_Q_F[tmp]=JDataFileInfo->jc.JcDdRealData.F_Q_F[tmp]-JDataFileInfo->jc.JcDdRealData.X3_F_Q[tmp];
			break;
	}
	switch((JDataFileInfo->JcPara_645.WuGongZuHeByte2>>6)&0x03){
		case 0x01:
			JDataFileInfo->jc.JcDdRealData.F_Q_All = JDataFileInfo->jc.JcDdRealData.F_Q_All+JDataFileInfo->jc.JcDdRealData.X4_Q_All;
			JDataFileInfo->jc.JcDdRealData.F_Q_F[tmp]=JDataFileInfo->jc.JcDdRealData.F_Q_F[tmp]+JDataFileInfo->jc.JcDdRealData.X4_F_Q[tmp];
			break;
		case 0x02:
			JDataFileInfo->jc.JcDdRealData.F_Q_All = JDataFileInfo->jc.JcDdRealData.F_Q_All-JDataFileInfo->jc.JcDdRealData.X4_Q_All;
			JDataFileInfo->jc.JcDdRealData.F_Q_F[tmp]=JDataFileInfo->jc.JcDdRealData.F_Q_F[tmp]-JDataFileInfo->jc.JcDdRealData.X4_F_Q[tmp];
			break;
	}
//	JDataFileInfo->jc.JcDdRealData.Z_Q_All = JDataFileInfo->jc.JcDdRealData.X1_Q_All + JDataFileInfo->jc.JcDdRealData.X2_Q_All;
//	JDataFileInfo->jc.JcDdRealData.Z_Q_F[tmp] = JDataFileInfo->jc.JcDdRealData.X1_F_Q[tmp] + JDataFileInfo->jc.JcDdRealData.X2_F_Q[tmp];
//	JDataFileInfo->jc.JcDdRealData.F_Q_All = JDataFileInfo->jc.JcDdRealData.X4_Q_All + JDataFileInfo->jc.JcDdRealData.X3_Q_All;
//	JDataFileInfo->jc.JcDdRealData.F_Q_F[tmp] = JDataFileInfo->jc.JcDdRealData.X4_F_Q[tmp] + JDataFileInfo->jc.JcDdRealData.X3_F_Q[tmp];
//	fprintf(stderr,"\n\rWuGongZuHeByte1 WuGongZuHeByte1 %02x %02x  ",JDataFileInfo->JcPara_645.WuGongZuHeByte1,JDataFileInfo->JcPara_645.WuGongZuHeByte2);
//	fprintf(stderr,"\n\rX1_Q_All=%d X2_Q_All  %d  X3_Q_All  %d  X4_Q_All  %d",JDataFileInfo->jc.JcDdRealData.X1_Q_All,JDataFileInfo->jc.JcDdRealData.X2_Q_All,JDataFileInfo->jc.JcDdRealData.X3_Q_All,JDataFileInfo->jc.JcDdRealData.X4_Q_All);
//	fprintf(stderr,"\n\rJDataFileInfo->jc.JcDdRealData.Z_Q_All=========%d",JDataFileInfo->jc.JcDdRealData.Z_Q_All);
}
DataFiles df;
/*����97�����Լ�洢*/
void DoDataChange(TS ts) {
	int i,num,j,pt=0;
	INT32U   P_All_Temp,P_Temp[4];
	num=0;
	//NormalSaveFile("/nand/DataCurr/JcData.dat",(INT8U *)&JDataFileInfo->jc,sizeof(JDataFileInfo->jc),JProgramInfo);
	if(JProgramInfo->FileSaveFlag.jcflag==0)
		JProgramInfo->FileSaveFlag.jcflag=1;
	for(i=0;i<PointMax;i++)
	{
		if (JParamInfo3761->group2.f10[i].Status!=1)
			continue;
		if (JParamInfo3761->group2.f10[i].ConnectType!=2)
			continue;
		//if (PortBegNum>0) //yangdong
		JDataFileInfo->data485[0].ts=ts;
		pt=getPoint(JParamInfo3761->group2.f10[i].CjqNo-1,JParamInfo3761->group2.f10[i].MeterNo)+1;
		df.manyFiles.ts=ts;
		df.manyFiles.sm.CaijiQiNo=JParamInfo3761->group2.f10[i].CjqNo-1;
		df.manyFiles.sm.MeterNo=JParamInfo3761->group2.f10[i].MeterNo;
		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x10;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0x90;

//		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.Z_P_All/10,&df.manyFiles.sm.datas[num].datas[0],4);//nengliang
												//datas[0]�����λ
		P_All_Temp  = (INT32U)JDataFileInfo->jc.JcDdRealData.Z_P_All/64;
		INT32U_BCD(P_All_Temp,&df.manyFiles.sm.datas[num].datas[0],4);//nengliang		//���ղ���
													//datas[0]�����λ
		num++;
		for(j=0;j<FeiLvNum;j++)
		{
			df.manyFiles.sm.datas[num].flg.ReadFlg=2;
			df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x11+j;
			df.manyFiles.sm.datas[num].flg.Dataflag[1]=0x90;
			P_Temp[j]  = (INT32U)JDataFileInfo->jc.JcDdRealData.Z_P_F[j]/64;
			INT32U_BCD(P_Temp[j],&df.manyFiles.sm.datas[num].datas[0],4);//nengliang
			num++;
		}
		df.manyFiles.sm.datas[num].flg.ReadFlg=1;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x1f;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0x90;
//		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.Z_P_All/10,&df.manyFiles.sm.datas[num].datas[0],4);//nengliang    /10
		INT32U_BCD(P_All_Temp,&df.manyFiles.sm.datas[num].datas[0],4);//nengliang    /10			//�����޸�

		for(j=0;j<FeiLvNum;j++)
		{
			INT32U_BCD(P_Temp[j],&df.manyFiles.sm.datas[num].datas[4+j*4],4);//nengliang
		}
		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x20;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0x90;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.F_P_All/64,&df.manyFiles.sm.datas[num].datas[0],4);
		num++;
		for(j=0;j<FeiLvNum;j++)
		{
			df.manyFiles.sm.datas[num].flg.ReadFlg=2;
			df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x21+j;
			df.manyFiles.sm.datas[num].flg.Dataflag[1]=0x90;
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.F_P_F[j]/64,&df.manyFiles.sm.datas[num].datas[0],4);
			num++;
		}
		df.manyFiles.sm.datas[num].flg.ReadFlg=1;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x2f;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0x90;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.F_P_All/64,&df.manyFiles.sm.datas[num].datas[0],4);
		for(j=0;j<FeiLvNum;j++)
		{
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.F_P_F[j]/64,&df.manyFiles.sm.datas[num].datas[4+j*4],4);
		}
		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x10;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0x91;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.Z_Q_All/64,&df.manyFiles.sm.datas[num].datas[0],4);//nengliang
		num++;
		for(j=0;j<FeiLvNum;j++)
		{
			df.manyFiles.sm.datas[num].flg.ReadFlg=2;
			df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x11+j;
			df.manyFiles.sm.datas[num].flg.Dataflag[1]=0x91;
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.Z_Q_F[j]/64,&df.manyFiles.sm.datas[num].datas[0],4);//nengliang
			num++;
		}
		df.manyFiles.sm.datas[num].flg.ReadFlg=1;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x1f;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0x91;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.Z_Q_All/64,&df.manyFiles.sm.datas[num].datas[0],4);//nengliang
		for(j=0;j<FeiLvNum;j++)
		{
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.Z_Q_F[j]/64,&df.manyFiles.sm.datas[num].datas[4+j*4],4);//nengliang
		}
		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x20;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0x91;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.F_Q_All/64,&df.manyFiles.sm.datas[num].datas[0],4);
		num++;
		for(j=0;j<FeiLvNum;j++)
		{
			df.manyFiles.sm.datas[num].flg.ReadFlg=2;
			df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x21+j;
			df.manyFiles.sm.datas[num].flg.Dataflag[1]=0x91;
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.F_Q_F[j]/64,&df.manyFiles.sm.datas[num].datas[0],4);
			num++;
		}
		df.manyFiles.sm.datas[num].flg.ReadFlg=1;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x2f;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0x91;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.F_Q_All/64,&df.manyFiles.sm.datas[num].datas[0],4);
		for(j=0;j<FeiLvNum;j++)
		{
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.F_Q_F[j]/64,&df.manyFiles.sm.datas[num].datas[4+j*4],4);
		}
		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x30;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0x91;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.X1_Q_All/64,&df.manyFiles.sm.datas[num].datas[0],4);//nengliang
		num++;
		for(j=0;j<FeiLvNum;j++)
		{
			df.manyFiles.sm.datas[num].flg.ReadFlg=2;
			df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x31+j;
			df.manyFiles.sm.datas[num].flg.Dataflag[1]=0x91;
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.X1_F_Q[j]/64,&df.manyFiles.sm.datas[num].datas[0],4);//nengliang
			num++;
		}
		df.manyFiles.sm.datas[num].flg.ReadFlg=1;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x3f;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0x91;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.X1_Q_All/64,&df.manyFiles.sm.datas[num].datas[0],4);//nengliang
		for(j=0;j<FeiLvNum;j++)
		{
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.X1_F_Q[j]/64,&df.manyFiles.sm.datas[num].datas[4+j*4],4);//nengliang
		}
		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x40;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0x91;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.X4_Q_All/64,&df.manyFiles.sm.datas[num].datas[0],4);//nengliang
		num++;
		for(j=0;j<FeiLvNum;j++)
		{
			df.manyFiles.sm.datas[num].flg.ReadFlg=2;
			df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x41+j;
			df.manyFiles.sm.datas[num].flg.Dataflag[1]=0x91;
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.X4_F_Q[j]/64,&df.manyFiles.sm.datas[num].datas[0],4);//nengliang
			num++;
		}
		df.manyFiles.sm.datas[num].flg.ReadFlg=1;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x4f;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0x91;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.X4_Q_All/64,&df.manyFiles.sm.datas[num].datas[0],4);//nengliang
		for(j=0;j<FeiLvNum;j++)
		{
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.X4_F_Q[j]/64,&df.manyFiles.sm.datas[num].datas[4+j*4],4);//nengliang
		}
		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x50;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0x91;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.X2_Q_All/64,&df.manyFiles.sm.datas[num].datas[0],4);
		num++;
		for(j=0;j<FeiLvNum;j++)
		{
			df.manyFiles.sm.datas[num].flg.ReadFlg=2;
			df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x51+j;
			df.manyFiles.sm.datas[num].flg.Dataflag[1]=0x91;
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.X2_F_Q[j]/64,&df.manyFiles.sm.datas[num].datas[0],4);
			num++;
		}
		df.manyFiles.sm.datas[num].flg.ReadFlg=1;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x5f;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0x91;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.X2_Q_All/64,&df.manyFiles.sm.datas[num].datas[0],4);
		for(j=0;j<FeiLvNum;j++)
		{
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.X2_F_Q[j]/64,&df.manyFiles.sm.datas[num].datas[4+j*4],4);
		}
		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x60;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0x91;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.X3_Q_All/64,&df.manyFiles.sm.datas[num].datas[0],4);
		num++;
		for(j=0;j<FeiLvNum;j++)
		{
			df.manyFiles.sm.datas[num].flg.ReadFlg=2;
			df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x61+j;
			df.manyFiles.sm.datas[num].flg.Dataflag[1]=0x91;
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.X3_F_Q[j]/64,&df.manyFiles.sm.datas[num].datas[0],4);
			num++;
		}
		df.manyFiles.sm.datas[num].flg.ReadFlg=1;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x6f;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0x91;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.X3_Q_All/64,&df.manyFiles.sm.datas[num].datas[0],4);
		for(j=0;j<FeiLvNum;j++)
		{
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.X3_F_Q[j]/64,&df.manyFiles.sm.datas[num].datas[4+j*4],4);
		}
		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x11;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xb6;
		//INT32U_BCD(JDataFileInfo->jc.JcDdRealData.VA,&df.manyFiles.sm.datas[num].datas[0],2);
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.VA_AVG,&df.manyFiles.sm.datas[num].datas[0],2);//lcy2013
		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x12;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xb6;
		//INT32U_BCD(JDataFileInfo->jc.JcDdRealData.VB,&df.manyFiles.sm.datas[num].datas[0],2);
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.VB_AVG,&df.manyFiles.sm.datas[num].datas[0],2);//lcy2013

		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x13;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xb6;
		//INT32U_BCD(JDataFileInfo->jc.JcDdRealData.VC,&df.manyFiles.sm.datas[num].datas[0],2);
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.VC_AVG,&df.manyFiles.sm.datas[num].datas[0],2);//lcy2013

		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=1;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x1f;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xb6;
//		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.VA,&df.manyFiles.sm.datas[num].datas[0],2);
//		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.VB,&df.manyFiles.sm.datas[num].datas[2],2);
//		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.VC,&df.manyFiles.sm.datas[num].datas[4],2);
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.VA_AVG,&df.manyFiles.sm.datas[num].datas[0],2);//lcy2013
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.VB_AVG,&df.manyFiles.sm.datas[num].datas[2],2);//lcy2013
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.VC_AVG,&df.manyFiles.sm.datas[num].datas[4],2);//lcy2013
		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x21;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xb6;

//		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.IA*10,&df.manyFiles.sm.datas[num].datas[0],3);
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.IA,&df.manyFiles.sm.datas[num].datas[0],3);//jiaocai
		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x22;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xb6;
//		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.IB*10,&df.manyFiles.sm.datas[num].datas[0],3);
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.IB,&df.manyFiles.sm.datas[num].datas[0],3);//jiaocai
		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x23;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xb6;
//		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.IC*10,&df.manyFiles.sm.datas[num].datas[0],3);
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.IC,&df.manyFiles.sm.datas[num].datas[0],3);//jiaocai
		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=1;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x2f;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xb6;
//		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.IA*10,&df.manyFiles.sm.datas[num].datas[0],3);
//		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.IB*10,&df.manyFiles.sm.datas[num].datas[3],3);
//		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.IC*10,&df.manyFiles.sm.datas[num].datas[6],3);
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.IA,&df.manyFiles.sm.datas[num].datas[0],3);//jiaocai
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.IB,&df.manyFiles.sm.datas[num].datas[3],3);//jiaocai
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.IC,&df.manyFiles.sm.datas[num].datas[6],3);//jiaocai
		//jiaocai
		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x30;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xb6;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.P,&df.manyFiles.sm.datas[num].datas[0],3);
		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x31;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xb6;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.PA,&df.manyFiles.sm.datas[num].datas[0],3);
		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x32;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xb6;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.PB,&df.manyFiles.sm.datas[num].datas[0],3);
		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x33;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xb6;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.PC,&df.manyFiles.sm.datas[num].datas[0],3);
		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=1;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x3f;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xb6;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.P,&df.manyFiles.sm.datas[num].datas[0],3);
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.PA,&df.manyFiles.sm.datas[num].datas[3],3);
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.PB,&df.manyFiles.sm.datas[num].datas[6],3);
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.PC,&df.manyFiles.sm.datas[num].datas[9],3);
		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x40;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xb6;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.Q,&df.manyFiles.sm.datas[num].datas[0],2);
		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x41;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xb6;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.QA,&df.manyFiles.sm.datas[num].datas[0],2);
		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x42;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xb6;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.QB,&df.manyFiles.sm.datas[num].datas[0],2);
		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x43;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xb6;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.QC,&df.manyFiles.sm.datas[num].datas[0],2);
		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=1;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x4f;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xb6;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.Q,&df.manyFiles.sm.datas[num].datas[0],2);
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.QA,&df.manyFiles.sm.datas[num].datas[2],2);
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.QB,&df.manyFiles.sm.datas[num].datas[4],2);
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.QC,&df.manyFiles.sm.datas[num].datas[6],2);
		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x50;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xb6;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.Cos,&df.manyFiles.sm.datas[num].datas[0],2);
		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x51;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xb6;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.CosA,&df.manyFiles.sm.datas[num].datas[0],2);
		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x52;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xb6;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.CosB,&df.manyFiles.sm.datas[num].datas[0],2);
		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x53;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xb6;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.CosC,&df.manyFiles.sm.datas[num].datas[0],2);
		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=1;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x5f;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xb6;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.Cos,&df.manyFiles.sm.datas[num].datas[0],2);
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.CosA,&df.manyFiles.sm.datas[num].datas[2],2);
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.CosB,&df.manyFiles.sm.datas[num].datas[4],2);
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.CosC,&df.manyFiles.sm.datas[num].datas[6],2);
		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x10;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xA0;
		INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.Z_P_X_All,&df.manyFiles.sm.datas[num].datas[0],3);
		num++;
		for(j=0;j<FeiLvNum;j++)
		{
			df.manyFiles.sm.datas[num].flg.ReadFlg=2;
			df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x11+j;
			df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xA0;
			INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.Z_P_X_F[j],&df.manyFiles.sm.datas[num].datas[0],3);
			num++;
		}
		df.manyFiles.sm.datas[num].flg.ReadFlg=1;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x1f;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xA0;
		INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.Z_P_X_All,&df.manyFiles.sm.datas[num].datas[0],3);
		for(j=0;j<FeiLvNum;j++)
		{
			INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.Z_P_X_F[j],&df.manyFiles.sm.datas[num].datas[3+j*3],3);
		}
		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x20;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xA0;
		INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.F_P_X_All,&df.manyFiles.sm.datas[num].datas[0],3);
		num++;
		for(j=0;j<FeiLvNum;j++)
		{
			df.manyFiles.sm.datas[num].flg.ReadFlg=2;
			df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x21+j;
			df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xA0;
			INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.F_P_X_F[j],&df.manyFiles.sm.datas[num].datas[0],3);
			num++;
		}
		df.manyFiles.sm.datas[num].flg.ReadFlg=1;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x2f;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xA0;
		INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.F_P_X_All,&df.manyFiles.sm.datas[num].datas[0],3);
		for(j=0;j<FeiLvNum;j++)
		{
			INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.F_P_X_F[j],&df.manyFiles.sm.datas[num].datas[3+j*3],3);
		}
		num++;
		//���� �����޹��������---tianjin----
		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x10;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xA1;
		INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.Z_Q_X_All,&df.manyFiles.sm.datas[num].datas[0],3);
		num++;
		for(j=0;j<FeiLvNum;j++)
		{
			df.manyFiles.sm.datas[num].flg.ReadFlg=2;
			df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x11+j;
			df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xA1;
			INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.Z_Q_X_F[j],&df.manyFiles.sm.datas[num].datas[0],3);
			num++;
		}
		df.manyFiles.sm.datas[num].flg.ReadFlg=1;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x1f;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xA1;
		INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.Z_Q_X_All,&df.manyFiles.sm.datas[num].datas[0],3);
		for(j=0;j<FeiLvNum;j++)
		{
			INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.Z_Q_X_F[j],&df.manyFiles.sm.datas[num].datas[3+j*3],3);
		}
		num++;

		df.manyFiles.sm.datas[num].flg.ReadFlg=1;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x2f;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xA1;
		INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.F_Q_X_All,&df.manyFiles.sm.datas[num].datas[0],3);
		for(j=0;j<FeiLvNum;j++)
		{
			INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.F_Q_X_F[j],&df.manyFiles.sm.datas[num].datas[3+j*3],3);
		}
		num++;

		df.manyFiles.sm.datas[num].flg.ReadFlg=1;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x20;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xA1;
		INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.F_Q_X_All,&df.manyFiles.sm.datas[num].datas[0],3);
		num++;

		df.manyFiles.sm.datas[num].flg.ReadFlg=1;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x21;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xA1;
		INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.F_Q_X_F[0],&df.manyFiles.sm.datas[num].datas[0],3);
		num++;

		df.manyFiles.sm.datas[num].flg.ReadFlg=1;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x22;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xA1;
		INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.F_Q_X_F[1],&df.manyFiles.sm.datas[num].datas[0],3);
		num++;

		df.manyFiles.sm.datas[num].flg.ReadFlg=1;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x23;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xA1;
		INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.F_Q_X_F[2],&df.manyFiles.sm.datas[num].datas[0],3);
		num++;

		df.manyFiles.sm.datas[num].flg.ReadFlg=1;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x24;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xA1;
		INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.F_Q_X_F[3],&df.manyFiles.sm.datas[num].datas[0],3);
		num++;

		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x20;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xA0;
		INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.F_Q_X_All,&df.manyFiles.sm.datas[num].datas[0],3);
		num++;
		for(j=0;j<FeiLvNum;j++)
		{
			df.manyFiles.sm.datas[num].flg.ReadFlg=2;
			df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x21+j;
			df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xA0;
			INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.F_Q_X_F[j],&df.manyFiles.sm.datas[num].datas[0],3);
			num++;
		}
		df.manyFiles.sm.datas[num].flg.ReadFlg=1;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x2f;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xA0;
		INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.F_Q_X_All,&df.manyFiles.sm.datas[num].datas[0],3);
		for(j=0;j<FeiLvNum;j++)
		{
			INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.F_Q_X_F[j],&df.manyFiles.sm.datas[num].datas[3+j*3],3);
		}
		num++;

		df.manyFiles.sm.datas[num].flg.ReadFlg=1;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x1f;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xB0;
		memcpy(&df.manyFiles.sm.datas[num].datas[0],JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_All,4);
		for(j=0;j<FeiLvNum;j++)
		{
			memcpy(&df.manyFiles.sm.datas[num].datas[4+j*4],JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_F[j],4);
		}
		num++;

		df.manyFiles.sm.datas[num].flg.ReadFlg=1;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x1f;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xB1;
		memcpy(&df.manyFiles.sm.datas[num].datas[0],JDataFileInfo->jc.JcMaxXuliang.Time_Z_Q_X_All,4);
		for(j=0;j<FeiLvNum;j++)
		{
			memcpy(&df.manyFiles.sm.datas[num].datas[4+j*4],JDataFileInfo->jc.JcMaxXuliang.Time_Z_Q_X_F[j],4);
		}
		num++;

		df.manyFiles.sm.datas[num].flg.ReadFlg=1;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x2f;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xB0;
		memcpy(&df.manyFiles.sm.datas[num].datas[0],JDataFileInfo->jc.JcMaxXuliang.Time_F_P_X_All,4);
		for(j=0;j<FeiLvNum;j++)
		{
			memcpy(&df.manyFiles.sm.datas[num].datas[4+j*4],JDataFileInfo->jc.JcMaxXuliang.Time_F_P_X_F[j],4);
		}
		num++;

		df.manyFiles.sm.datas[num].flg.ReadFlg=1;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x2f;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xB1;
		memcpy(&df.manyFiles.sm.datas[num].datas[0],JDataFileInfo->jc.JcMaxXuliang.Time_F_Q_X_All,4);
		for(j=0;j<FeiLvNum;j++)
		{
			memcpy(&df.manyFiles.sm.datas[num].datas[4+j*4],JDataFileInfo->jc.JcMaxXuliang.Time_F_Q_X_F[j],4);
		}
		num++;

		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x10;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xB0;
		memcpy(&df.manyFiles.sm.datas[num].datas[0],JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_All,4);
		num++;

		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x11;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xB0;
		memcpy(&df.manyFiles.sm.datas[num].datas[0],JDataFileInfo->jc.JcMaxXuliang.Time_Z_Q_X_F[0],4);
		num++;

		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x12;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xB0;
		memcpy(&df.manyFiles.sm.datas[num].datas[0],JDataFileInfo->jc.JcMaxXuliang.Time_Z_Q_X_F[1],4);
		num++;

		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x13;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xB0;
		memcpy(&df.manyFiles.sm.datas[num].datas[0],JDataFileInfo->jc.JcMaxXuliang.Time_Z_Q_X_F[2],4);
		num++;

		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x14;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xB0;
		memcpy(&df.manyFiles.sm.datas[num].datas[0],JDataFileInfo->jc.JcMaxXuliang.Time_Z_Q_X_F[3],4);
		num++;

		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x20;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xB0;
		memcpy(&df.manyFiles.sm.datas[num].datas[0],JDataFileInfo->jc.JcMaxXuliang.Time_F_P_X_All,4);
		num++;

		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x10;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xB1;
		memcpy(&df.manyFiles.sm.datas[num].datas[0],JDataFileInfo->jc.JcMaxXuliang.Time_Z_Q_X_All,4);
		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x20;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xB1;
		memcpy(&df.manyFiles.sm.datas[num].datas[0],JDataFileInfo->jc.JcMaxXuliang.Time_F_Q_X_All,4);
		num++;

		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x21;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xB1;
		memcpy(&df.manyFiles.sm.datas[num].datas[0],JDataFileInfo->jc.JcMaxXuliang.Time_F_Q_X_F[0],4);
		num++;

		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x22;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xB1;
		memcpy(&df.manyFiles.sm.datas[num].datas[0],JDataFileInfo->jc.JcMaxXuliang.Time_F_Q_X_F[1],4);
		num++;

		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x23;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xB1;
		memcpy(&df.manyFiles.sm.datas[num].datas[0],JDataFileInfo->jc.JcMaxXuliang.Time_F_Q_X_F[2],4);
		num++;

		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x24;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xB1;
		memcpy(&df.manyFiles.sm.datas[num].datas[0],JDataFileInfo->jc.JcMaxXuliang.Time_F_Q_X_F[3],4);
		num++;

		//lcy
		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0xC0;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xFF;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.A_Z_P_All/64,&df.manyFiles.sm.datas[num].datas[0],4);
		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0xC1;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xFF;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.A_F_P_All/64,&df.manyFiles.sm.datas[num].datas[0],4);
		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0xC2;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xFF;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.A_Z_Q_All/64,&df.manyFiles.sm.datas[num].datas[0],4);
		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0xC3;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xFF;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.A_F_Q_All/64,&df.manyFiles.sm.datas[num].datas[0],4);
		num++;

		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0xC4;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xFF;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.B_Z_P_All/64,&df.manyFiles.sm.datas[num].datas[0],4);
		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0xC5;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xFF;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.B_F_P_All/64,&df.manyFiles.sm.datas[num].datas[0],4);
		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0xC6;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xFF;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.B_Z_Q_All/64,&df.manyFiles.sm.datas[num].datas[0],4);
		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0xC7;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xFF;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.B_F_Q_All/64,&df.manyFiles.sm.datas[num].datas[0],4);
		num++;

		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0xC8;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xFF;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.C_Z_P_All/64,&df.manyFiles.sm.datas[num].datas[0],4);
		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0xC9;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xFF;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.C_F_P_All/64,&df.manyFiles.sm.datas[num].datas[0],4);
		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0xCA;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xFF;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.C_Z_Q_All/64,&df.manyFiles.sm.datas[num].datas[0],4);
		num++;
		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0xCB;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0xFF;
		INT32U_BCD(JDataFileInfo->jc.JcDdRealData.C_F_Q_All/64,&df.manyFiles.sm.datas[num].datas[0],4);
		num++;
		//lcy

		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x0F;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0x00;
		INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.IAJ,&df.manyFiles.sm.datas[num].datas[0],2);
		INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.IBJ,&df.manyFiles.sm.datas[num].datas[2],2);
		INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.ICJ,&df.manyFiles.sm.datas[num].datas[4],2);
		num++;

		df.manyFiles.sm.datas[num].flg.ReadFlg=2;
		df.manyFiles.sm.datas[num].flg.Dataflag[0]=0x2F;
		df.manyFiles.sm.datas[num].flg.Dataflag[1]=0x00;
		INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.UAJ,&df.manyFiles.sm.datas[num].datas[0],2);
		INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.UBJ,&df.manyFiles.sm.datas[num].datas[2],2);
		INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.UCJ,&df.manyFiles.sm.datas[num].datas[4],2);
		num++;

		//�ñ�־λ��ʼ�����ļ�
		df.fileinfo.cldno=pt;				//lhl�ģ���datachangedֵ����Ϊ�������
		df.fileinfo.filetype=FILECURR;
		memset(&df.fileinfo.ts,0,sizeof(TS));
		df.dataChanged=1;
		df.filelen=sizeof(DataFiles);
		sprintf(df.filename,"/nand/DataCurr/%04d/curr.dat",pt);

		sem_wait(&JProgramInfo->mainData.UseCycleFlg);
		if((JProgramInfo->sm_tail-JProgramInfo->sm_head-1+SMBUFLEN)%SMBUFLEN>0) {   //�������пռ�
//			if(JProgramInfo->sm[JProgramInfo->sm_head].dataChanged==0){
			memcpy(&JProgramInfo->sm[JProgramInfo->sm_head],&df,sizeof(DataFiles));
			JProgramInfo->sm_head = (JProgramInfo->sm_head+1)%SMBUFLEN;
//			delay(10);
//			}
		}
		sem_post(&JProgramInfo->mainData.UseCycleFlg);
		break;
//		memset(TempBuf,0,60);
//		sprintf((char*)TempBuf,"/nand/DataCurr");
//		if (access((char*)TempBuf,0)!=0)//��Ŀ¼�����ڣ��ȴ���
//		{
//			memset(Command,0,60);
//			sprintf((char*)Command,"%s /nand/DataCurr",_CMDMKDIR_);
//			syscmd((char*)TempBuf,JProgramInfo);
//			delay(100);
//		 }
//		memset(TempBuf,0,60);
//		sprintf((char*)TempBuf,"/nand/DataCurr/%04d/",pt);
//		if (access((char*)TempBuf,0)!=0)//��Ŀ¼�����ڣ��ȴ���
//		{
//			memset(Command,0,60);
//			sprintf((char*)Command,"%s /nand/DataCurr/%04d/",_CMDMKDIR_,pt);
//			syscmd((char*)TempBuf,JProgramInfo);
//			delay(100);
//		 }
//		memset(TempBuf,0,60);
//		sprintf((char*)TempBuf,"/nand/DataDay/%04d/",pt);//��Ŀ¼�����ڣ��ȴ���
//		if (access((char*)TempBuf,0)!=0)
//		{
//			memset(Command,0,60);
//			sprintf((char*)Command,"%s /nand/DataDay/%04d/",_CMDMKDIR_,pt);
//			syscmd((char*)TempBuf,JProgramInfo);
//			delay(100);
//		 }
//		memset(TempBuf,0,60);
//		sprintf((char*)TempBuf,"/nand/DataMonth/%04d/",pt);//��Ŀ¼�����ڣ��ȴ���
//		if (access((char*)TempBuf,0)!=0)
//		{
//			memset(Command,0,60);
//			sprintf((char*)Command,"%s /nand/DataMonth/%04d/",_CMDMKDIR_,pt);
//			syscmd((char*)TempBuf,JProgramInfo);
//			delay(100);
//		 }
//		memset(TempBuf,0,60);
//		sprintf((char*)TempBuf,"/nand/DataCurr/%04d/curr.dat",pt);
//		if (access((char*)TempBuf,0)==0)//��curr.dat����last.dat
//		{
//			memset(Command,0,120);
//			sprintf((char*)Command,"%s /nand/DataCurr/%04d/curr.dat /nand/DataCurr/%04d/last.dat",
//					_CMDCP_,pt,pt);
//			syscmd((char*)TempBuf,JProgramInfo);
//			delay(50);
//		}else
//			JProgramInfo->LunFlg=1;
//		SaveFile((char*)TempBuf,(INT8U *)&df.manyFiles,sizeof(SMFiles),JProgramInfo);
//		if (JProgramInfo->stateflags.JCFlag>0)
//		{
//			JProgramInfo->stateflags.JCFlag=0;
//		}
//
//    	memset(TempBuf,0,60);
//    	sprintf((char*)TempBuf,"/nand/DataHour/%04d%02d%02d/",ts.Year,ts.Month,ts.Day);
//    	if (access((char*)TempBuf,0)!=0)
//    	{
//    		memset(TempBuf,0,60);
//    		sprintf((char*)TempBuf,"%s /nand/DataHour/%04d%02d%02d/",_CMDMKDIR_,ts.Year,ts.Month,ts.Day);
//    		syscmd((char*)TempBuf,JProgramInfo);
//    		delay(50);
//    	}
//    	memset(TempBuf,0,60);
//    	sprintf((char*)TempBuf,"/nand/DataHour/%04d%02d%02d/%04d/",ts.Year,ts.Month,ts.Day,pt);
//    	if (access((char*)TempBuf,0)!=0)
//    	{
//    		memset(TempBuf,0,60);
//    		sprintf((char*)TempBuf,"%s /nand/DataHour/%04d%02d%02d/%04d/",_CMDMKDIR_,ts.Year,ts.Month,ts.Day,pt);
//    		syscmd((char*)TempBuf,JProgramInfo);
//    		delay(50);
//    	}
//		if (JParamInfo3761->group2.f10[i].port<=0)
//			JParamInfo3761->group2.f10[i].port=1;
//		if (ts.Minute>=45)
//		{
//			if (JParamInfo3761->group5.f33.f33[JParamInfo3761->group2.f10[i].port-1].CbInter<=15)
//			{
//				memset(TempBuf,0,60);
//				sprintf((char*)TempBuf,"/nand/DataCurr/%04d/curr.dat",pt);
//				if (access((char*)TempBuf,0)==0)
//				{
//					memset(TempBuf,0,60);
//					sprintf((char*)TempBuf,"/nand/DataHour/%04d%02d%02d/%04d/%04d%02d%02d%02d45.dat",ts.Year,ts.Month,ts.Day,pt,ts.Year,ts.Month,ts.Day,ts.Hour);
//					if (access((char*)TempBuf,0)!=0)
//					{
//						memset(Command,0,120);
//						sprintf((char*)Command,"%s /nand/DataCurr/%04d/curr.dat /nand/DataHour/%04d%02d%02d/%04d/%04d%02d%02d%02d45.dat",
//								_CMDCP_,pt,ts.Year,ts.Month,ts.Day,pt,ts.Year,ts.Month,ts.Day,ts.Hour);
//						syscmd((char*)TempBuf,JProgramInfo);
//						delay(50);
//					}
//				}
//			}
//		}
//		else if (ts.Minute>=30)
//		{
//			if (JParamInfo3761->group5.f33.f33[JParamInfo3761->group2.f10[i].port-1].CbInter<=30)
//			{
//				memset(TempBuf,0,60);
//				sprintf((char*)TempBuf,"/nand/DataCurr/%04d/curr.dat",pt);
//				if (access((char*)TempBuf,0)==0)
//				{
//					memset(TempBuf,0,60);
//					sprintf((char*)TempBuf,"/nand/DataHour/%04d%02d%02d/%04d/%04d%02d%02d%02d30.dat",ts.Year,ts.Month,ts.Day,pt,ts.Year,ts.Month,ts.Day,ts.Hour);
//					if (access((char*)TempBuf,0)!=0)
//					{
//						memset(Command,0,120);
//						sprintf((char*)Command,"%s /nand/DataCurr/%04d/curr.dat /nand/DataHour/%04d%02d%02d/%04d/%04d%02d%02d%02d30.dat",
//								_CMDCP_,pt,ts.Year,ts.Month,ts.Day,pt,ts.Year,ts.Month,ts.Day,ts.Hour);
//						syscmd((char*)TempBuf,JProgramInfo);
//						delay(50);
//					}
//				}
//			}
//		}
//		else if (ts.Minute>=15)
//		{
//			if (JParamInfo3761->group5.f33.f33[JParamInfo3761->group2.f10[i].port-1].CbInter<=15)
//			{
//				memset(TempBuf,0,60);
//				sprintf((char*)TempBuf,"/nand/DataCurr/%04d/curr.dat",pt);
//				if (access((char*)TempBuf,0)==0)
//				{
//					memset(TempBuf,0,60);
//					sprintf((char*)TempBuf,"/nand/DataHour/%04d%02d%02d/%04d/%04d%02d%02d%02d15.dat",ts.Year,ts.Month,ts.Day,pt,ts.Year,ts.Month,ts.Day,ts.Hour);
//					if (access((char*)TempBuf,0)!=0)
//					{
//						memset(Command,0,120);
//						sprintf((char*)Command,"%s /nand/DataCurr/%04d/curr.dat /nand/DataHour/%04d%02d%02d/%04d/%04d%02d%02d%02d15.dat",
//								_CMDCP_,pt,ts.Year,ts.Month,ts.Day,pt,ts.Year,ts.Month,ts.Day,ts.Hour);
//						syscmd((char*)TempBuf,JProgramInfo);
//						delay(50);
//					}
//				}
//			}
//		}
//
//		memset(TempBuf,0,60);//�洢Сʱ����
//		sprintf((char*)TempBuf,"/nand/DataHour/%04d%02d%02d/%04d/%04d%02d%02d%02d00.dat",
//				ts.Year,ts.Month,ts.Day,pt,ts.Year,ts.Month,ts.Day,ts.Hour);
//		SdPrint("TempBuf%d=%s\n\r",i,TempBuf);
//		if (access((char*)TempBuf,0)!=0)
//		{
//			memset(Command,0,120);
//			sprintf((char*)Command,"%s /nand/DataCurr/%04d/curr.dat /nand/DataHour/%04d%02d%02d/%04d/%04d%02d%02d%02d00.dat",
//					_CMDCP_,pt,ts.Year,ts.Month,ts.Day,pt,ts.Year,ts.Month,ts.Day,ts.Hour);
//			SdPrint("Command=%s\n\r",Command);
//			syscmd((char*)TempBuf,JProgramInfo);
//			delay(50);
//		}
//		//�洢������
//		if (ts.Day!=Day)
//		{
//			memset(Command,0,120);
//			sprintf((char*)Command,"%s /nand/DataCurr/%04d/curr.dat /nand/DataDay/%04d/%02d.dat",
//					_CMDCP_,pt,pt,ts.Day);
//			syscmd((char*)TempBuf,JProgramInfo);
//			delay(50);
//			Day=ts.Day;
//		}
//		//�洢������
//		if (ts.Month!=Month)
//		{
//			memset(Command,0,120);
//			sprintf((char*)Command,"%s /nand/DataCurr/%04d/curr.dat /nand/DataMonth/%04d/%02d.dat",
//					_CMDCP_,pt,pt,ts.Month);
//			syscmd((char*)TempBuf,JProgramInfo);
//			delay(50);
//			Month=ts.Month;
//		}
	//	fprintf(stderr,"\n\r.......i1 = %d.",i);
//		break;
	}
}
//lcy
void XuLiangCalc(INT32S *Dest, INT32S S, INT8U *DestTime, INT32S *CMP, TS ts) {

	INT32S Temp;
	Temp = 0;
//	for (i = 0; i < 15; i++) {
//		Temp = Temp + S[i];
//	}
	Temp = S;
	if (Temp >= *CMP)
	{//�洢�й��������
		*Dest = Temp;
		*CMP = Temp;
		DestTime[4] = (((ts.Year-2000) / 10) << 4) + ((ts.Year-2000) % 10);
		DestTime[3] = ((ts.Month / 10) << 4) + (ts.Month % 10);
		DestTime[2] = ((ts.Day / 10) << 4) + (ts.Day % 10);
		DestTime[1] = ((ts.Hour / 10) << 4) + (ts.Hour % 10);
		DestTime[0] = ((ts.Minute / 10) << 4) + (ts.Minute % 10);
	}
}
//lcy
void XuLiangRst() {
	INT8U i, j;
	FeiLvMin=0;
	HuaChaTime=0;
	JDataFileInfo->jc.JcMaxXuliang.F_P_X_All = 0;
	JDataFileInfo->jc.JcMaxXuliang.F_Q_X_All = 0;
	JDataFileInfo->jc.JcMaxXuliang.Z_P_X_All = 0;
	JDataFileInfo->jc.JcMaxXuliang.Z_Q_X_All = 0;

	for (i = 0; i < FeiLvNum; i++) {
		JDataFileInfo->jc.JcMaxXuliang.F_P_X_F[i] = 0;
		JDataFileInfo->jc.JcMaxXuliang.F_Q_X_F[i] = 0;
		JDataFileInfo->jc.JcMaxXuliang.Z_P_X_F[i] = 0;
		JDataFileInfo->jc.JcMaxXuliang.Z_Q_X_F[i] = 0;

		JDataFileInfo->jc.JcMaxXuliang.X1_Q_F[i] = 0;
		JDataFileInfo->jc.JcMaxXuliang.X2_Q_F[i] = 0;
		JDataFileInfo->jc.JcMaxXuliang.X3_Q_F[i] = 0;
		JDataFileInfo->jc.JcMaxXuliang.X4_Q_F[i] = 0;
		for (j = 0; j < 4; j++){
			memset(&JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_F[i][j],0,4);
			memset(&JDataFileInfo->jc.JcMaxXuliang.Time_F_P_X_F[i][j],0,4);
			memset(&JDataFileInfo->jc.JcMaxXuliang.Time_Z_Q_X_F[i][j],0,4);
			memset(&JDataFileInfo->jc.JcMaxXuliang.Time_F_Q_X_F[i][j],0,4);

			memset(&JDataFileInfo->jc.JcMaxXuliang.Time_X1_Q_F[i][j],0,4);
			memset(&JDataFileInfo->jc.JcMaxXuliang.Time_X2_Q_F[i][j],0,4);
			memset(&JDataFileInfo->jc.JcMaxXuliang.Time_X3_Q_F[i][j],0,4);
			memset(&JDataFileInfo->jc.JcMaxXuliang.Time_X4_Q_F[i][j],0,4);
		}
	}
	memset(JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_All,0,4);
	memset(JDataFileInfo->jc.JcMaxXuliang.Time_F_P_X_All,0,4);
	memset(JDataFileInfo->jc.JcMaxXuliang.Time_Z_Q_X_All,0,4);
	memset(JDataFileInfo->jc.JcMaxXuliang.Time_F_Q_X_All,0,4);
	memset(&JDataFileInfo->jc.JcOldXuLiang,0,sizeof(OldXuLiangSet));
	for (i = 0; i < 16; i++) {
		JDataFileInfo->jc.JcXuLiangCalc.F_P_Value[i] = 0;
		JDataFileInfo->jc.JcXuLiangCalc.F_Q_Value[i] = 0;
		JDataFileInfo->jc.JcXuLiangCalc.Z_P_Value[i] = 0;
		JDataFileInfo->jc.JcXuLiangCalc.Z_Q_Value[i] = 0;
		for (j = 0; j < FeiLvNum; j++) {
			JDataFileInfo->jc.JcXuLiangCalc.F_P_FL_Value[j][i] = 0;
			JDataFileInfo->jc.JcXuLiangCalc.F_Q_FL_Value[j][i] = 0;
			JDataFileInfo->jc.JcXuLiangCalc.Z_P_FL_Value[j][i] = 0;
			JDataFileInfo->jc.JcXuLiangCalc.Z_Q_FL_Value[j][i] = 0;

			JDataFileInfo->jc.JcXuLiangCalc.X1_Q_FL_Value[j][i] = 0;
			JDataFileInfo->jc.JcXuLiangCalc.X2_Q_FL_Value[j][i] = 0;
			JDataFileInfo->jc.JcXuLiangCalc.X3_Q_FL_Value[j][i] = 0;
			JDataFileInfo->jc.JcXuLiangCalc.X4_Q_FL_Value[j][i] = 0;
		}
	}
	JDataFileInfo->jc.JcXuLiangCalc.Offset = 0;
}
//lcy
void SetYCData()
{
	//double m,n;
	JDataFileInfo->jc.JcDdRealData.Valid = 1;
	JDataFileInfo->jc.JcDdRealData.Cos = JDataFileInfo->jc.RES.RES_PFZ;/////////////////
	JDataFileInfo->jc.JcDdRealData.CosA = JDataFileInfo->jc.RES.RES_PFA;
	JDataFileInfo->jc.JcDdRealData.CosB = JDataFileInfo->jc.RES.RES_PFB;
	JDataFileInfo->jc.JcDdRealData.CosC = JDataFileInfo->jc.RES.RES_PFC;

/*	//Ϊ��֤�������ȶ��������´���
	if((abs(JDataFileInfo->jc.RES.RES_IA)%10)>=5)
		if(JDataFileInfo->jc.RES.RES_IA>0)
			JDataFileInfo->jc.JcDdRealData.IA = JDataFileInfo->jc.RES.RES_IA / 10 + 1;
		else
			JDataFileInfo->jc.JcDdRealData.IA = JDataFileInfo->jc.RES.RES_IA / 10 - 1;
	else
		JDataFileInfo->jc.JcDdRealData.IA = JDataFileInfo->jc.RES.RES_IA / 10;
	if((abs(JDataFileInfo->jc.RES.RES_IB)%10)>=5)
		if(JDataFileInfo->jc.RES.RES_IB>0)
			JDataFileInfo->jc.JcDdRealData.IB = JDataFileInfo->jc.RES.RES_IB / 10 + 1;
		else
			JDataFileInfo->jc.JcDdRealData.IB = JDataFileInfo->jc.RES.RES_IB / 10 - 1;
	else
		JDataFileInfo->jc.JcDdRealData.IB = JDataFileInfo->jc.RES.RES_IB / 10;
	if((abs(JDataFileInfo->jc.RES.RES_IC)%10)>=5)
		if(JDataFileInfo->jc.RES.RES_IC>0)
			JDataFileInfo->jc.JcDdRealData.IC = JDataFileInfo->jc.RES.RES_IC / 10 + 1;
		else
			JDataFileInfo->jc.JcDdRealData.IC = JDataFileInfo->jc.RES.RES_IC / 10 - 1;
	else
		JDataFileInfo->jc.JcDdRealData.IC = JDataFileInfo->jc.RES.RES_IC / 10;
	if((abs(JDataFileInfo->jc.RES.RES_I0)%10)>=5)
		if(JDataFileInfo->jc.RES.RES_I0>0)
			JDataFileInfo->jc.JcDdRealData.IL = JDataFileInfo->jc.RES.RES_I0 / 10 + 1;
		else
			JDataFileInfo->jc.JcDdRealData.IL = JDataFileInfo->jc.RES.RES_I0 / 10 - 1;
	else
		JDataFileInfo->jc.JcDdRealData.IL = JDataFileInfo->jc.RES.RES_I0 / 10;
*/
/*	//�Ե������Ȳ���������������С�������λ*/
	JDataFileInfo->jc.JcDdRealData.IA = JDataFileInfo->jc.RES.RES_IA;// / 10;
	JDataFileInfo->jc.JcDdRealData.IB = JDataFileInfo->jc.RES.RES_IB;// / 10;
	JDataFileInfo->jc.JcDdRealData.IC = JDataFileInfo->jc.RES.RES_IC;// / 10;
	JDataFileInfo->jc.JcDdRealData.IL = JDataFileInfo->jc.RES.RES_I0;// / 10;


	JDataFileInfo->jc.JcDdRealData.VA = JDataFileInfo->jc.RES.RES_UA;
//	printf("\n\r### SetYCData ## jc.JcDdRealData.VA = %d ",JDataFileInfo->jc.RES.RES_UA);
	JDataFileInfo->jc.JcDdRealData.VB = JDataFileInfo->jc.RES.RES_UB;
	JDataFileInfo->jc.JcDdRealData.VC = JDataFileInfo->jc.RES.RES_UC;

	JDataFileInfo->jc.JcDdRealData.VA_JB = JDataFileInfo->jc.RES.RES_JB_UA;
	JDataFileInfo->jc.JcDdRealData.VB_JB = JDataFileInfo->jc.RES.RES_JB_UB;
	JDataFileInfo->jc.JcDdRealData.VC_JB = JDataFileInfo->jc.RES.RES_JB_UC;


	JDataFileInfo->jc.JcDdRealData.P = JDataFileInfo->jc.RES.RES_PZ;
	JDataFileInfo->jc.JcDdRealData.PA = JDataFileInfo->jc.RES.RES_PA;
	JDataFileInfo->jc.JcDdRealData.PB = JDataFileInfo->jc.RES.RES_PB;
	JDataFileInfo->jc.JcDdRealData.PC = JDataFileInfo->jc.RES.RES_PC;
	//JDataFileInfo->jc.JcDdRealData.P=JDataFileInfo->jc.JcDdRealData.PA+JDataFileInfo->jc.JcDdRealData.PB+JDataFileInfo->jc.JcDdRealData.PC;//////////

	JDataFileInfo->jc.JcDdRealData.Q = JDataFileInfo->jc.RES.RES_QZ;
	JDataFileInfo->jc.JcDdRealData.QA = JDataFileInfo->jc.RES.RES_QA;
	JDataFileInfo->jc.JcDdRealData.QB = JDataFileInfo->jc.RES.RES_QB;
	JDataFileInfo->jc.JcDdRealData.QC = JDataFileInfo->jc.RES.RES_QC;
	//JDataFileInfo->jc.JcDdRealData.Q=JDataFileInfo->jc.JcDdRealData.QA+JDataFileInfo->jc.JcDdRealData.QB+JDataFileInfo->jc.JcDdRealData.QC;////////////////
	JDataFileInfo->jc.JcDdRealData.S = JDataFileInfo->jc.RES.RES_SZ;
	JDataFileInfo->jc.JcDdRealData.SA = JDataFileInfo->jc.RES.RES_SA;
	JDataFileInfo->jc.JcDdRealData.SB = JDataFileInfo->jc.RES.RES_SB;
	JDataFileInfo->jc.JcDdRealData.SC = JDataFileInfo->jc.RES.RES_SC;
	JDataFileInfo->jc.JcMaxXuliang.UAJ = JDataFileInfo->jc.RES.RES_UAJ;
	JDataFileInfo->jc.JcMaxXuliang.UBJ = JDataFileInfo->jc.RES.RES_UBJ;
	JDataFileInfo->jc.JcMaxXuliang.UCJ = JDataFileInfo->jc.RES.RES_UCJ;
	JDataFileInfo->jc.JcMaxXuliang.IAJ = JDataFileInfo->jc.RES.RES_IAJ;
	JDataFileInfo->jc.JcMaxXuliang.IBJ = JDataFileInfo->jc.RES.RES_IBJ;
	JDataFileInfo->jc.JcMaxXuliang.ICJ = JDataFileInfo->jc.RES.RES_ICJ;
	JDataFileInfo->jc.JcMaxXuliang.JcStat = JDataFileInfo->jc.RES.RES_FLAG;
//	m=(double)JDataFileInfo->jc.JcDdRealData.P;
//	n=(double)((JDataFileInfo->jc.JcDdRealData.P)*(JDataFileInfo->jc.JcDdRealData.P)+(JDataFileInfo->jc.JcDdRealData.Q)*(JDataFileInfo->jc.JcDdRealData.Q));
//	if(n!=0)
//		 JDataFileInfo->jc.JcDdRealData.Cos=1000*m/sqrt(n);
//	else
//		 JDataFileInfo->jc.JcDdRealData.Cos=0;

}
INT8U FeiLvNo(const TS ts_t)
{
	INT8U Byte,sdn;
	if(ts_t.Minute<30)
		sdn=ts_t.Hour*2;
	else
		sdn=ts_t.Hour*2+1;
	Byte = JParamInfo3761->group3.f21.FLTime[sdn];
		return ((Byte > FeiLvNum) ? 0x01 : Byte);
}

//---lcy
void FeiLvCalc() {
	TS ts;
	if(JDataFileInfo->JcPara_645.XuLiangZhouQi==0)
		JDataFileInfo->JcPara_645.XuLiangZhouQi =15;
	if(JDataFileInfo->JcPara_645.HuaChaTime==0)
		JDataFileInfo->JcPara_645.HuaChaTime = 1;
	//if (FeiLvMin != ts.Minute)
	//fprintf(stderr,"\n\rJDataFileInfo->JcPara_645.XuLiangZhouQi=%d",JDataFileInfo->JcPara_645.XuLiangZhouQi);
	if (FeiLvMin>=JDataFileInfo->JcPara_645.XuLiangZhouQi)
	{
		HuaChaTime++;
		//����15������ÿ����������й�������ֵ����ƽ�����ʣ���������
		Z_P_RealXL=(JDataFileInfo->jc.JcXuLiangCalc.Z_P_Value[JDataFileInfo->jc.JcXuLiangCalc.Offset]
		                                    -JDataFileInfo->jc.JcXuLiangCalc.Z_P_Value[(JDataFileInfo->jc.JcXuLiangCalc.Offset+1)%(JDataFileInfo->JcPara_645.XuLiangZhouQi+1)])*100/64;
		Z_P_FL_RealXL[JDataFileInfo->jc.NowFeiLvNo]=(JDataFileInfo->jc.JcXuLiangCalc.Z_P_FL_Value[JDataFileInfo->jc.NowFeiLvNo][JDataFileInfo->jc.JcXuLiangCalc.Offset]
		                                    -JDataFileInfo->jc.JcXuLiangCalc.Z_P_FL_Value[JDataFileInfo->jc.NowFeiLvNo][(JDataFileInfo->jc.JcXuLiangCalc.Offset+1)%(JDataFileInfo->JcPara_645.XuLiangZhouQi+1)])*100/64;
		F_P_RealXL=(JDataFileInfo->jc.JcXuLiangCalc.F_P_Value[JDataFileInfo->jc.JcXuLiangCalc.Offset]
		                                    -JDataFileInfo->jc.JcXuLiangCalc.F_P_Value[(JDataFileInfo->jc.JcXuLiangCalc.Offset+1)%(JDataFileInfo->JcPara_645.XuLiangZhouQi+1)])*100/64;
		F_P_FL_RealXL[JDataFileInfo->jc.NowFeiLvNo]=(JDataFileInfo->jc.JcXuLiangCalc.F_P_FL_Value[JDataFileInfo->jc.NowFeiLvNo][JDataFileInfo->jc.JcXuLiangCalc.Offset]
		                                    -JDataFileInfo->jc.JcXuLiangCalc.F_P_FL_Value[JDataFileInfo->jc.NowFeiLvNo][(JDataFileInfo->jc.JcXuLiangCalc.Offset+1)%(JDataFileInfo->JcPara_645.XuLiangZhouQi+1)])*100/64;
		Z_Q_RealXL=(JDataFileInfo->jc.JcXuLiangCalc.Z_Q_Value[JDataFileInfo->jc.JcXuLiangCalc.Offset]
		                                    -JDataFileInfo->jc.JcXuLiangCalc.Z_Q_Value[(JDataFileInfo->jc.JcXuLiangCalc.Offset+1)%(JDataFileInfo->JcPara_645.XuLiangZhouQi+1)])*100/64;
		Z_Q_FL_RealXL[JDataFileInfo->jc.NowFeiLvNo]=(JDataFileInfo->jc.JcXuLiangCalc.Z_Q_FL_Value[JDataFileInfo->jc.NowFeiLvNo][JDataFileInfo->jc.JcXuLiangCalc.Offset]
		                                    -JDataFileInfo->jc.JcXuLiangCalc.Z_Q_FL_Value[JDataFileInfo->jc.NowFeiLvNo][(JDataFileInfo->jc.JcXuLiangCalc.Offset+1)%(JDataFileInfo->JcPara_645.XuLiangZhouQi+1)])*100/64;
		F_Q_RealXL=(JDataFileInfo->jc.JcXuLiangCalc.F_Q_Value[JDataFileInfo->jc.JcXuLiangCalc.Offset]
		                                    -JDataFileInfo->jc.JcXuLiangCalc.F_Q_Value[(JDataFileInfo->jc.JcXuLiangCalc.Offset+1)%(JDataFileInfo->JcPara_645.XuLiangZhouQi+1)])*100/64;
		F_Q_FL_RealXL[JDataFileInfo->jc.NowFeiLvNo]=(JDataFileInfo->jc.JcXuLiangCalc.F_Q_FL_Value[JDataFileInfo->jc.NowFeiLvNo][JDataFileInfo->jc.JcXuLiangCalc.Offset]
		                                    -JDataFileInfo->jc.JcXuLiangCalc.F_Q_FL_Value[JDataFileInfo->jc.NowFeiLvNo][(JDataFileInfo->jc.JcXuLiangCalc.Offset+1)%(JDataFileInfo->JcPara_645.XuLiangZhouQi+1)])*100/64;
		Q_X_1[JDataFileInfo->jc.NowFeiLvNo]=(JDataFileInfo->jc.JcXuLiangCalc.X1_Q_FL_Value[JDataFileInfo->jc.NowFeiLvNo][JDataFileInfo->jc.JcXuLiangCalc.Offset]
		                                     -JDataFileInfo->jc.JcXuLiangCalc.X1_Q_FL_Value[JDataFileInfo->jc.NowFeiLvNo][(JDataFileInfo->jc.JcXuLiangCalc.Offset+1)%(JDataFileInfo->JcPara_645.XuLiangZhouQi+1)])*100/64;
		Q_X_2[JDataFileInfo->jc.NowFeiLvNo]=(JDataFileInfo->jc.JcXuLiangCalc.X2_Q_FL_Value[JDataFileInfo->jc.NowFeiLvNo][JDataFileInfo->jc.JcXuLiangCalc.Offset]
		                                     -JDataFileInfo->jc.JcXuLiangCalc.X2_Q_FL_Value[JDataFileInfo->jc.NowFeiLvNo][(JDataFileInfo->jc.JcXuLiangCalc.Offset+1)%(JDataFileInfo->JcPara_645.XuLiangZhouQi+1)])*100/64;
		Q_X_3[JDataFileInfo->jc.NowFeiLvNo]=(JDataFileInfo->jc.JcXuLiangCalc.X3_Q_FL_Value[JDataFileInfo->jc.NowFeiLvNo][JDataFileInfo->jc.JcXuLiangCalc.Offset]
		                                     -JDataFileInfo->jc.JcXuLiangCalc.X3_Q_FL_Value[JDataFileInfo->jc.NowFeiLvNo][(JDataFileInfo->jc.JcXuLiangCalc.Offset+1)%(JDataFileInfo->JcPara_645.XuLiangZhouQi+1)])*100/64;
		Q_X_4[JDataFileInfo->jc.NowFeiLvNo]=(JDataFileInfo->jc.JcXuLiangCalc.X4_Q_FL_Value[JDataFileInfo->jc.NowFeiLvNo][JDataFileInfo->jc.JcXuLiangCalc.Offset]
		                                     -JDataFileInfo->jc.JcXuLiangCalc.X4_Q_FL_Value[JDataFileInfo->jc.NowFeiLvNo][(JDataFileInfo->jc.JcXuLiangCalc.Offset+1)%(JDataFileInfo->JcPara_645.XuLiangZhouQi+1)])*100/64;

		//����ʱ����������������е�ƽ�����ʵ����ֵ�����������ֵ��
		if(HuaChaTime>=JDataFileInfo->JcPara_645.HuaChaTime)
		{
			TSGet(&ts);
			HuaChaTime=0;
			JDataFileInfo->jc.JcDdRealData.Chao_Time.BCD01 = ((ts.Minute / 10) << 4) + (ts.Minute % 10);
			JDataFileInfo->jc.JcDdRealData.Chao_Time.BCD02 = ((ts.Hour / 10) << 4) + (ts.Hour % 10);
			JDataFileInfo->jc.JcDdRealData.Chao_Time.BCD03 = ((ts.Day / 10) << 4) + (ts.Day % 10);
			JDataFileInfo->jc.JcDdRealData.Chao_Time.BCD04 = ((ts.Month / 10) << 4) + (ts.Month % 10);
			JDataFileInfo->jc.JcDdRealData.Chao_Time.BCD05 = (((ts.Year % 100) / 10) << 4) + (ts.Year % 10);
			//������/64*4
			XuLiangCalc(&JDataFileInfo->jc.JcMaxXuliang.Z_P_X_All, Z_P_RealXL*60/JDataFileInfo->JcPara_645.XuLiangZhouQi, JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_All_645, &JDataFileInfo->jc.JcOldXuLiang.Z_P_Value, ts);
			XuLiangCalc(&JDataFileInfo->jc.JcMaxXuliang.F_P_X_All, F_P_RealXL*60/JDataFileInfo->JcPara_645.XuLiangZhouQi, JDataFileInfo->jc.JcMaxXuliang.Time_F_P_X_All_645, &JDataFileInfo->jc.JcOldXuLiang.F_P_Value, ts);
			XuLiangCalc(&JDataFileInfo->jc.JcMaxXuliang.Z_Q_X_All, Z_Q_RealXL*60/JDataFileInfo->JcPara_645.XuLiangZhouQi, JDataFileInfo->jc.JcMaxXuliang.Time_Z_Q_X_All_645, &JDataFileInfo->jc.JcOldXuLiang.Z_Q_Value, ts);
			XuLiangCalc(&JDataFileInfo->jc.JcMaxXuliang.F_Q_X_All, F_Q_RealXL*60/JDataFileInfo->JcPara_645.XuLiangZhouQi, JDataFileInfo->jc.JcMaxXuliang.Time_F_Q_X_All_645, &JDataFileInfo->jc.JcOldXuLiang.F_Q_Value, ts);

			memcpy(&JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_All[JDataFileInfo->jc.NowFeiLvNo],&JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_All_645[JDataFileInfo->jc.NowFeiLvNo],4);
			memcpy(&JDataFileInfo->jc.JcMaxXuliang.Time_F_P_X_All[JDataFileInfo->jc.NowFeiLvNo],&JDataFileInfo->jc.JcMaxXuliang.Time_F_P_X_All_645[JDataFileInfo->jc.NowFeiLvNo],4);
			memcpy(&JDataFileInfo->jc.JcMaxXuliang.Time_Z_Q_X_All[JDataFileInfo->jc.NowFeiLvNo],&JDataFileInfo->jc.JcMaxXuliang.Time_Z_Q_X_All_645[JDataFileInfo->jc.NowFeiLvNo],4);
			memcpy(&JDataFileInfo->jc.JcMaxXuliang.Time_F_Q_X_All[JDataFileInfo->jc.NowFeiLvNo],&JDataFileInfo->jc.JcMaxXuliang.Time_F_Q_X_All_645[JDataFileInfo->jc.NowFeiLvNo],4);

			XuLiangCalc(&JDataFileInfo->jc.JcMaxXuliang.Z_P_X_F[JDataFileInfo->jc.NowFeiLvNo], Z_P_FL_RealXL[JDataFileInfo->jc.NowFeiLvNo]*60/JDataFileInfo->JcPara_645.XuLiangZhouQi, JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_F_645[JDataFileInfo->jc.NowFeiLvNo], &JDataFileInfo->jc.JcOldXuLiang.Z_P_FL_Value[JDataFileInfo->jc.NowFeiLvNo], ts);
			XuLiangCalc(&JDataFileInfo->jc.JcMaxXuliang.F_P_X_F[JDataFileInfo->jc.NowFeiLvNo], F_P_FL_RealXL[JDataFileInfo->jc.NowFeiLvNo]*60/JDataFileInfo->JcPara_645.XuLiangZhouQi, JDataFileInfo->jc.JcMaxXuliang.Time_F_P_X_F_645[JDataFileInfo->jc.NowFeiLvNo], &JDataFileInfo->jc.JcOldXuLiang.F_P_FL_Value[JDataFileInfo->jc.NowFeiLvNo], ts);
			XuLiangCalc(&JDataFileInfo->jc.JcMaxXuliang.Z_Q_X_F[JDataFileInfo->jc.NowFeiLvNo], Z_Q_FL_RealXL[JDataFileInfo->jc.NowFeiLvNo]*60/JDataFileInfo->JcPara_645.XuLiangZhouQi, JDataFileInfo->jc.JcMaxXuliang.Time_Z_Q_X_F_645[JDataFileInfo->jc.NowFeiLvNo], &JDataFileInfo->jc.JcOldXuLiang.Z_Q_FL_Value[JDataFileInfo->jc.NowFeiLvNo], ts);
			XuLiangCalc(&JDataFileInfo->jc.JcMaxXuliang.F_Q_X_F[JDataFileInfo->jc.NowFeiLvNo], F_Q_FL_RealXL[JDataFileInfo->jc.NowFeiLvNo]*60/JDataFileInfo->JcPara_645.XuLiangZhouQi, JDataFileInfo->jc.JcMaxXuliang.Time_F_Q_X_F_645[JDataFileInfo->jc.NowFeiLvNo], &JDataFileInfo->jc.JcOldXuLiang.F_Q_FL_Value[JDataFileInfo->jc.NowFeiLvNo], ts);

			memcpy(&JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_F[JDataFileInfo->jc.NowFeiLvNo],&JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_F_645[JDataFileInfo->jc.NowFeiLvNo],4);
			memcpy(&JDataFileInfo->jc.JcMaxXuliang.Time_F_P_X_F[JDataFileInfo->jc.NowFeiLvNo],&JDataFileInfo->jc.JcMaxXuliang.Time_F_P_X_F_645[JDataFileInfo->jc.NowFeiLvNo],4);
			memcpy(&JDataFileInfo->jc.JcMaxXuliang.Time_Z_Q_X_F[JDataFileInfo->jc.NowFeiLvNo],&JDataFileInfo->jc.JcMaxXuliang.Time_Z_Q_X_F_645[JDataFileInfo->jc.NowFeiLvNo],4);
			memcpy(&JDataFileInfo->jc.JcMaxXuliang.Time_F_Q_X_F[JDataFileInfo->jc.NowFeiLvNo],&JDataFileInfo->jc.JcMaxXuliang.Time_F_Q_X_F_645[JDataFileInfo->jc.NowFeiLvNo],4);


			XuLiangCalc(&JDataFileInfo->jc.JcMaxXuliang.X1_Q_F[JDataFileInfo->jc.NowFeiLvNo], Q_X_1[JDataFileInfo->jc.NowFeiLvNo]*60/JDataFileInfo->JcPara_645.XuLiangZhouQi, JDataFileInfo->jc.JcMaxXuliang.Time_X1_Q_F_645[JDataFileInfo->jc.NowFeiLvNo], &JDataFileInfo->jc.JcOldXuLiang.X1_Q_FL_Value[JDataFileInfo->jc.NowFeiLvNo], ts);
			XuLiangCalc(&JDataFileInfo->jc.JcMaxXuliang.X2_Q_F[JDataFileInfo->jc.NowFeiLvNo], Q_X_2[JDataFileInfo->jc.NowFeiLvNo]*60/JDataFileInfo->JcPara_645.XuLiangZhouQi, JDataFileInfo->jc.JcMaxXuliang.Time_X2_Q_F_645[JDataFileInfo->jc.NowFeiLvNo], &JDataFileInfo->jc.JcOldXuLiang.X2_Q_FL_Value[JDataFileInfo->jc.NowFeiLvNo], ts);
			XuLiangCalc(&JDataFileInfo->jc.JcMaxXuliang.X3_Q_F[JDataFileInfo->jc.NowFeiLvNo], Q_X_3[JDataFileInfo->jc.NowFeiLvNo]*60/JDataFileInfo->JcPara_645.XuLiangZhouQi, JDataFileInfo->jc.JcMaxXuliang.Time_X3_Q_F_645[JDataFileInfo->jc.NowFeiLvNo], &JDataFileInfo->jc.JcOldXuLiang.X3_Q_FL_Value[JDataFileInfo->jc.NowFeiLvNo], ts);
			XuLiangCalc(&JDataFileInfo->jc.JcMaxXuliang.X4_Q_F[JDataFileInfo->jc.NowFeiLvNo], Q_X_4[JDataFileInfo->jc.NowFeiLvNo]*60/JDataFileInfo->JcPara_645.XuLiangZhouQi, JDataFileInfo->jc.JcMaxXuliang.Time_X4_Q_F_645[JDataFileInfo->jc.NowFeiLvNo], &JDataFileInfo->jc.JcOldXuLiang.X4_Q_FL_Value[JDataFileInfo->jc.NowFeiLvNo], ts);

			memcpy(&JDataFileInfo->jc.JcMaxXuliang.Time_X1_Q_F[JDataFileInfo->jc.NowFeiLvNo],&JDataFileInfo->jc.JcMaxXuliang.Time_X1_Q_F_645[JDataFileInfo->jc.NowFeiLvNo],4);
			memcpy(&JDataFileInfo->jc.JcMaxXuliang.Time_X2_Q_F[JDataFileInfo->jc.NowFeiLvNo],&JDataFileInfo->jc.JcMaxXuliang.Time_X2_Q_F_645[JDataFileInfo->jc.NowFeiLvNo],4);
			memcpy(&JDataFileInfo->jc.JcMaxXuliang.Time_X3_Q_F[JDataFileInfo->jc.NowFeiLvNo],&JDataFileInfo->jc.JcMaxXuliang.Time_X3_Q_F_645[JDataFileInfo->jc.NowFeiLvNo],4);
			memcpy(&JDataFileInfo->jc.JcMaxXuliang.Time_X4_Q_F[JDataFileInfo->jc.NowFeiLvNo],&JDataFileInfo->jc.JcMaxXuliang.Time_X4_Q_F_645[JDataFileInfo->jc.NowFeiLvNo],4);

			JDataFileInfo->jc.JcMaxXuliang.Valid = 1;
			memcpy(&JDataFileInfo->jc.JcMaxXuliang.Chao_Time.BCD01, &JDataFileInfo->jc.JcDdRealData.Chao_Time.BCD01, 5);
//			fprintf(stderr,"\n\rJDataFileInfo->jc.JcXuLiangCalc.Z_P_Value[%d]=%d",JDataFileInfo->jc.JcXuLiangCalc.Offset,JDataFileInfo->jc.JcXuLiangCalc.Z_P_Value[JDataFileInfo->jc.JcXuLiangCalc.Offset]);
//			fprintf(stderr,"\n\rJDataFileInfo->jc.JcXuLiangCalc.Z_P_Value[%d]=%d",(JDataFileInfo->jc.JcXuLiangCalc.Offset+1)%(JDataFileInfo->JcPara_645.XuLiangZhouQi+1),JDataFileInfo->jc.JcXuLiangCalc.Z_P_Value[(JDataFileInfo->jc.JcXuLiangCalc.Offset+1)%(JDataFileInfo->JcPara_645.XuLiangZhouQi+1)]);
//			fprintf(stderr,"\n\rZ_P_RealXL=%d ",Z_P_RealXL);
//			fprintf(stderr,"\n\rJDataFileInfo->jc.JcMaxXuliang.Z_P_X_All=%d",JDataFileInfo->jc.JcMaxXuliang.Z_P_X_All);
//
//			fprintf(stderr,"\n\rJDataFileInfo->jc.JcXuLiangCalc.Z_Q_Value[%d]=%d",JDataFileInfo->jc.JcXuLiangCalc.Offset,JDataFileInfo->jc.JcXuLiangCalc.Z_Q_Value[JDataFileInfo->jc.JcXuLiangCalc.Offset]);
//			fprintf(stderr,"\n\rJDataFileInfo->jc.JcXuLiangCalc.Z_Q_Value[%d]=%d",(JDataFileInfo->jc.JcXuLiangCalc.Offset+1)%(JDataFileInfo->JcPara_645.XuLiangZhouQi+1),JDataFileInfo->jc.JcXuLiangCalc.Z_Q_Value[(JDataFileInfo->jc.JcXuLiangCalc.Offset+1)%(JDataFileInfo->JcPara_645.XuLiangZhouQi+1)]);
//			fprintf(stderr,"\n\rZ_Q_RealXL=%d",Z_Q_RealXL);
//			fprintf(stderr,"\n\rJDataFileInfo->jc.JcMaxXuliang.Z_Q_X_All=%d",JDataFileInfo->jc.JcMaxXuliang.Z_Q_X_All);

		}
	}
}
//---lcy
void UHeGePrt()
{
	INT32U USS=0,US=0,UX=0,UXX=0;
	USS=BCD_INT32(&JParamInfo3761->Point[0].f26.V_He_ge_SS[0],2);
	US=BCD_INT32(&JParamInfo3761->Point[0].f26.V_He_ge_S[0],2);
	UXX=BCD_INT32(&JParamInfo3761->Point[0].f26.V_He_ge_XX[0],2);
	UX=BCD_INT32(&JParamInfo3761->Point[0].f26.V_He_ge_X[0],2);
	fprintf(stderr,"\n\r*****************************************");
	fprintf(stderr,"\n\rUSS %d   US %d   UX %d   UXX %d ",USS,US,UX,UXX);
	fprintf(stderr,"\n\rUA =%d   UB =%d   UC =%d ",JDataFileInfo->jc.JcDdRealData.VA,JDataFileInfo->jc.JcDdRealData.VB,JDataFileInfo->jc.JcDdRealData.VC);

	fprintf(stderr,"\n\rA TIME");
	fprintf(stderr,"\n\r  USSU_Count = %d",exdtjd.USSU_Count);
	fprintf(stderr,"\n\r  USU_Count  = %d",exdtjd.USU_Count);
	fprintf(stderr,"\n\r  UXXU_Count = %d",exdtjd.UXXU_Count);
	fprintf(stderr,"\n\r  UXU_Count  = %d",exdtjd.UXU_Count);
	fprintf(stderr,"\n\r  UHGU_Count = %d",exdtjd.UHGU_Count);
	fprintf(stderr,"\n\rB TIME");
	fprintf(stderr,"\n\r  USSV_Count = %d",exdtjd.USSV_Count);
	fprintf(stderr,"\n\r  USV_Count  = %d",exdtjd.USV_Count);
	fprintf(stderr,"\n\r  UXXV_Count = %d",exdtjd.UXXV_Count);
	fprintf(stderr,"\n\r  UXV_Count  = %d",exdtjd.UXV_Count);
	fprintf(stderr,"\n\r  UHGV_Count = %d",exdtjd.UHGV_Count);
	fprintf(stderr,"\n\rC TIME");
	fprintf(stderr,"\n\r  USSW_Count = %d",exdtjd.USSW_Count);
	fprintf(stderr,"\n\r  USW_Count  = %d",exdtjd.USW_Count);
	fprintf(stderr,"\n\r  UXXW_Count = %d",exdtjd.UXXW_Count);
	fprintf(stderr,"\n\r  UXW_Count  = %d",exdtjd.UXW_Count);
	fprintf(stderr,"\n\r  UHGW_Count = %d",exdtjd.UHGW_Count);
	fprintf(stderr,"\n\rA MAX MIN");
	fprintf(stderr,"\n\r  DUUMAX = %d",exdtjd.DUUMAX);
	fprintf(stderr,"\n\r  DUUMIN = %d",exdtjd.DUUMIN);
	fprintf(stderr,"\n\rB MAX MIN");
	fprintf(stderr,"\n\r  DUVMAX = %d",exdtjd.DUVMAX);
	fprintf(stderr,"\n\r  DUVMIN = %d",exdtjd.DUVMIN);
	fprintf(stderr,"\n\rC MAX MIN");
	fprintf(stderr,"\n\r  DUWMAX = %d",exdtjd.DUWMAX);
	fprintf(stderr,"\n\r  DUWMIN = %d",exdtjd.DUWMIN);
	fprintf(stderr,"\n\rUA Average=%d ,UB Average=%d ,UC Average=%d",exdtjd.DUUAVE,exdtjd.DUVAVE,exdtjd.DUWAVE);
	fprintf(stderr,"\n\r*****************************************\n");
}

/*��������ͳ��*/
void DoTongJi(TS ts)
{
	int i=0;
	INT32U USS=0,US=0,UX=0,UXX=0;
	for(i=0;i<PointMax;i++)
	{
		ClearWaitTimes(ProjectNo,JProgramInfo);
		if (JParamInfo3761->group2.f10[i].Status!=1)
			continue;
		if (JParamInfo3761->group2.f10[i].ConnectType!=2)
			continue;
		USS=BCD_INT32(&JParamInfo3761->Point[i].f26.V_He_ge_SS[0],2);
		US=BCD_INT32(&JParamInfo3761->Point[i].f26.V_He_ge_S[0],2);
		UXX=BCD_INT32(&JParamInfo3761->Point[i].f26.V_He_ge_XX[0],2);
		UX=BCD_INT32(&JParamInfo3761->Point[i].f26.V_He_ge_X[0],2);

		if ((USS!=0)||(US!=0)||(UXX!=0)||(UX!=0))
		{
			if ((JDataFileInfo->jc.JcDdRealData.VA>US) && (US>0))//��ѹAԽ����
			{
				exdtjd.U_A_Sum +=JDataFileInfo->jc.JcDdRealData.VA;
				exdtjm.U_A_Sum +=JDataFileInfo->jc.JcDdRealData.VA;
				exdtjd.USU_Count++;
				exdtjm.USU_Count++;
				if ((JDataFileInfo->jc.JcDdRealData.VA>USS) && (USS>0))//��ѹAԽ������
				{
					exdtjd.USSU_Count++;
					exdtjm.USSU_Count++;
				}
			}else
			{
				if ((JDataFileInfo->jc.JcDdRealData.VA<UX)&&(UX>0))//��ѹAԽ����
				{
					exdtjd.U_A_Sum +=JDataFileInfo->jc.JcDdRealData.VA;
					exdtjm.U_A_Sum +=JDataFileInfo->jc.JcDdRealData.VA;
					exdtjd.UXU_Count++;
					exdtjm.UXU_Count++;
					if ((JDataFileInfo->jc.JcDdRealData.VA<UXX)&&(UXX>0))//��ѹAԽ������
					{
						exdtjd.UXXU_Count++;
						exdtjm.UXXU_Count++;
					}
				}else
				{
					exdtjd.U_A_Sum +=JDataFileInfo->jc.JcDdRealData.VA;
					exdtjm.U_A_Sum +=JDataFileInfo->jc.JcDdRealData.VA;
					exdtjd.UHGU_Count++;
					exdtjm.UHGU_Count++;
				}
			}

			if ((JDataFileInfo->jc.JcDdRealData.VB>US) && (US>0))//��ѹBԽ����
			{
				exdtjd.U_B_Sum +=JDataFileInfo->jc.JcDdRealData.VB;
				exdtjm.U_B_Sum +=JDataFileInfo->jc.JcDdRealData.VB;
				exdtjd.USV_Count++;
				exdtjm.USV_Count++;
				if ((JDataFileInfo->jc.JcDdRealData.VB>USS) && (USS>0))//��ѹBԽ������
				{
					exdtjd.USSV_Count++;
					exdtjm.USSV_Count++;
				}
			}else
			{
				if ((JDataFileInfo->jc.JcDdRealData.VB<UX)&&(UX>0))//��ѹBԽ����
				{
					exdtjd.U_B_Sum +=JDataFileInfo->jc.JcDdRealData.VB;
					exdtjm.U_B_Sum +=JDataFileInfo->jc.JcDdRealData.VB;
					exdtjd.UXV_Count++;
					exdtjm.UXV_Count++;
					if ((JDataFileInfo->jc.JcDdRealData.VB<UXX)&&(UXX>0))//��ѹBԽ������
					{
						exdtjd.UXXV_Count++;
						exdtjm.UXXV_Count++;
					}
				}else
				{
					exdtjd.U_B_Sum +=JDataFileInfo->jc.JcDdRealData.VB;
					exdtjm.U_B_Sum +=JDataFileInfo->jc.JcDdRealData.VB;
					exdtjd.UHGV_Count++;
					exdtjm.UHGV_Count++;
				}
			}

			if ((JDataFileInfo->jc.JcDdRealData.VC>US) && (US>0))//��ѹCԽ����
			{
				exdtjd.U_C_Sum +=JDataFileInfo->jc.JcDdRealData.VC;
				exdtjm.U_C_Sum +=JDataFileInfo->jc.JcDdRealData.VC;
				exdtjd.USW_Count++;
				exdtjm.USW_Count++;
				if ((JDataFileInfo->jc.JcDdRealData.VC>USS) && (USS>0))//��ѹCԽ������
				{
					exdtjd.USSW_Count++;
					exdtjm.USSW_Count++;
				}
			}else
			{
				if ((JDataFileInfo->jc.JcDdRealData.VC<UX)&&(UX>0))//��ѹCԽ����
				{
					exdtjd.U_C_Sum +=JDataFileInfo->jc.JcDdRealData.VC;
					exdtjm.U_C_Sum +=JDataFileInfo->jc.JcDdRealData.VC;
					exdtjd.UXW_Count++;
					exdtjm.UXW_Count++;
					if ((JDataFileInfo->jc.JcDdRealData.VC<UXX)&&(UXX>0))//��ѹCԽ������
					{
						exdtjd.UXXW_Count++;
						exdtjm.UXXW_Count++;
					}
				}else
				{
					exdtjd.U_C_Sum +=JDataFileInfo->jc.JcDdRealData.VC;
					exdtjm.U_C_Sum +=JDataFileInfo->jc.JcDdRealData.VC;
					exdtjd.UHGW_Count++;
					exdtjm.UHGW_Count++;
				}
			}
		}
		//�¹���Ϊ��ͳ��ʱ��
		if(JDataFileInfo->jc.JcDdRealData.P == 0)		exdtjm.P_Zero_Time++;
		if(JDataFileInfo->jc.JcDdRealData.PA == 0)	exdtjm.PA_Zero_Time++;
		if(JDataFileInfo->jc.JcDdRealData.PB == 0)	exdtjm.PB_Zero_Time++;
		if(JDataFileInfo->jc.JcDdRealData.PC== 0)		exdtjm.PC_Zero_Time++;

		//A  B  C  ��   ��   ��ѹ���ֵ����Сֵ
		if (JDataFileInfo->jc.JcDdRealData.VA>exdtjd.DUUMAX)//A��  ��  ��ѹ���ֵ
		{
			exdtjd.DUUMAX=JDataFileInfo->jc.JcDdRealData.VA;
			INT32U_BCD(ts.Minute,&exdtjd.DUUMAX_TIME[0],1);
			INT32U_BCD(ts.Hour,&exdtjd.DUUMAX_TIME[1],1);
			INT32U_BCD(ts.Day,&exdtjd.DUUMAX_TIME[2],1);
		}
		if (JDataFileInfo->jc.JcDdRealData.VA<exdtjd.DUUMIN || exdtjd.DUUMIN==0)//A��  ��  ��ѹ��Сֵ
		{
			exdtjd.DUUMIN=JDataFileInfo->jc.JcDdRealData.VA;
			INT32U_BCD(ts.Minute,&exdtjd.DUUMIN_TIME[0],1);
			INT32U_BCD(ts.Hour,&exdtjd.DUUMIN_TIME[1],1);
			INT32U_BCD(ts.Day,&exdtjd.DUUMIN_TIME[2],1);
		}
		if (JDataFileInfo->jc.JcDdRealData.P>exdtjd.P_MAX)//���й��� ���ֵ //yangdongjc
		{
			exdtjd.P_MAX=JDataFileInfo->jc.JcDdRealData.P;
			INT32U_BCD(ts.Minute,&exdtjd.P_MAX_TIME[0],1);
			INT32U_BCD(ts.Hour,&exdtjd.P_MAX_TIME[1],1);
			INT32U_BCD(ts.Day,&exdtjd.P_MAX_TIME[2],1);
		}


		if (JDataFileInfo->jc.JcDdRealData.VA>exdtjm.DUUMAX)//A��  ��  ��ѹ���ֵ
		{
			exdtjm.DUUMAX=JDataFileInfo->jc.JcDdRealData.VA;
			INT32U_BCD(ts.Minute,&exdtjm.DUUMAX_TIME[0],1);
			INT32U_BCD(ts.Hour,&exdtjm.DUUMAX_TIME[1],1);
			INT32U_BCD(ts.Day,&exdtjm.DUUMAX_TIME[2],1);
		}
		if (JDataFileInfo->jc.JcDdRealData.VA<exdtjm.DUUMIN || exdtjm.DUUMIN==0)//A��  ��  ��ѹ��Сֵ
		{
			exdtjm.DUUMIN=JDataFileInfo->jc.JcDdRealData.VA;
			INT32U_BCD(ts.Minute,&exdtjm.DUUMIN_TIME[0],1);
			INT32U_BCD(ts.Hour,&exdtjm.DUUMIN_TIME[1],1);
			INT32U_BCD(ts.Day,&exdtjm.DUUMIN_TIME[2],1);
		}
		if (JDataFileInfo->jc.JcDdRealData.P>exdtjm.P_MAX)//���й������� ���ֵ //yangdongjc
		{
			exdtjm.P_MAX=JDataFileInfo->jc.JcDdRealData.P;
			INT32U_BCD(ts.Minute,&exdtjm.P_MAX_TIME[0],1);
			INT32U_BCD(ts.Hour,&exdtjm.P_MAX_TIME[1],1);
			INT32U_BCD(ts.Day,&exdtjm.P_MAX_TIME[2],1);
		}
		if (JDataFileInfo->jc.JcDdRealData.PA>exdtjm.PA_MAX)//A�й������� ���ֵ //yangdongjc
		{
			exdtjm.PA_MAX=JDataFileInfo->jc.JcDdRealData.PA;
			INT32U_BCD(ts.Minute,&exdtjm.PA_MAX_TIME[0],1);
			INT32U_BCD(ts.Hour,&exdtjm.PA_MAX_TIME[1],1);
			INT32U_BCD(ts.Day,&exdtjm.PA_MAX_TIME[2],1);
		}
		if (JDataFileInfo->jc.JcDdRealData.PB>exdtjm.PB_MAX)//B�й������� ���ֵ //yangdongjc
		{
			exdtjm.PB_MAX=JDataFileInfo->jc.JcDdRealData.PB;
			INT32U_BCD(ts.Minute,&exdtjm.PB_MAX_TIME[0],1);
			INT32U_BCD(ts.Hour,&exdtjm.PB_MAX_TIME[1],1);
			INT32U_BCD(ts.Day,&exdtjm.PB_MAX_TIME[2],1);
		}
		if (JDataFileInfo->jc.JcDdRealData.PC>exdtjm.PC_MAX)//C�й������� ���ֵ //yangdongjc
		{
			exdtjm.PC_MAX=JDataFileInfo->jc.JcDdRealData.PC;
			INT32U_BCD(ts.Minute,&exdtjm.PC_MAX_TIME[0],1);
			INT32U_BCD(ts.Hour,&exdtjm.PC_MAX_TIME[1],1);
			INT32U_BCD(ts.Day,&exdtjm.PC_MAX_TIME[2],1);
		}
		if (JDataFileInfo->jc.JcDdRealData.VB>exdtjd.DUVMAX)//B���յ�ѹ���ֵ
		{
			exdtjd.DUVMAX=JDataFileInfo->jc.JcDdRealData.VB;
			INT32U_BCD(ts.Minute,&exdtjd.DUVMAX_TIME[0],1);
			INT32U_BCD(ts.Hour,&exdtjd.DUVMAX_TIME[1],1);
			INT32U_BCD(ts.Day,&exdtjd.DUVMAX_TIME[2],1);
		}
		if (JDataFileInfo->jc.JcDdRealData.VB<exdtjd.DUVMIN || exdtjd.DUVMIN==0)//B���յ�ѹ��Сֵ
		{
			exdtjd.DUVMIN=JDataFileInfo->jc.JcDdRealData.VB;
			INT32U_BCD(ts.Minute,&exdtjd.DUVMIN_TIME[0],1);
			INT32U_BCD(ts.Hour,&exdtjd.DUVMIN_TIME[1],1);
			INT32U_BCD(ts.Day,&exdtjd.DUVMIN_TIME[2],1);
		}
		if (JDataFileInfo->jc.JcDdRealData.VB>exdtjm.DUVMAX)//B���µ�ѹ���ֵ
		{
			exdtjm.DUVMAX=JDataFileInfo->jc.JcDdRealData.VB;
			INT32U_BCD(ts.Minute,&exdtjm.DUVMAX_TIME[0],1);
			INT32U_BCD(ts.Hour,&exdtjm.DUVMAX_TIME[1],1);
			INT32U_BCD(ts.Day,&exdtjm.DUVMAX_TIME[2],1);
		}
		if (JDataFileInfo->jc.JcDdRealData.VB<exdtjm.DUVMIN  || exdtjm.DUVMIN==0)//B���µ�ѹ��Сֵ
		{
			exdtjm.DUVMIN=JDataFileInfo->jc.JcDdRealData.VB;
			INT32U_BCD(ts.Minute,&exdtjm.DUVMIN_TIME[0],1);
			INT32U_BCD(ts.Hour,&exdtjm.DUVMIN_TIME[1],1);
			INT32U_BCD(ts.Day,&exdtjm.DUVMIN_TIME[2],1);
		}
		if (JDataFileInfo->jc.JcDdRealData.VC>exdtjd.DUWMAX)//C��ri ��ѹ���ֵ
		{
			exdtjd.DUWMAX=JDataFileInfo->jc.JcDdRealData.VC;
			INT32U_BCD(ts.Minute,&exdtjd.DUWMAX_TIME[0],1);
			INT32U_BCD(ts.Hour,&exdtjd.DUWMAX_TIME[1],1);
			INT32U_BCD(ts.Day,&exdtjd.DUWMAX_TIME[2],1);
		}
		if (JDataFileInfo->jc.JcDdRealData.VC<exdtjd.DUWMIN || exdtjd.DUWMIN==0)//C��ri ��ѹ��Сֵ
		{
			exdtjd.DUWMIN=JDataFileInfo->jc.JcDdRealData.VC;
			INT32U_BCD(ts.Minute,&exdtjd.DUWMIN_TIME[0],1);
			INT32U_BCD(ts.Hour,&exdtjd.DUWMIN_TIME[1],1);
			INT32U_BCD(ts.Day,&exdtjd.DUWMIN_TIME[2],1);
		}
		if (JDataFileInfo->jc.JcDdRealData.VC>exdtjm.DUWMAX)//C��yue ��ѹ���ֵ
		{
			exdtjm.DUWMAX=JDataFileInfo->jc.JcDdRealData.VC;
			INT32U_BCD(ts.Minute,&exdtjm.DUWMAX_TIME[0],1);
			INT32U_BCD(ts.Hour,&exdtjm.DUWMAX_TIME[1],1);
			INT32U_BCD(ts.Day,&exdtjm.DUWMAX_TIME[2],1);
		}
		if (JDataFileInfo->jc.JcDdRealData.VC<exdtjm.DUWMIN || exdtjm.DUWMIN==0)//C��yue ��ѹ��Сֵ
		{
			exdtjm.DUWMIN=JDataFileInfo->jc.JcDdRealData.VC;
			INT32U_BCD(ts.Minute,&exdtjm.DUWMIN_TIME[0],1);
			INT32U_BCD(ts.Hour,&exdtjm.DUWMIN_TIME[1],1);
			INT32U_BCD(ts.Day,&exdtjm.DUWMIN_TIME[2],1);
		}
		//A\B\C�����յ�ѹƽ��ֵ
		if((exdtjd.USU_Count+exdtjd.UXU_Count+exdtjd.UHGU_Count)!=0)
			exdtjd.DUUAVE=exdtjd.U_A_Sum/(exdtjd.USU_Count+exdtjd.UXU_Count+exdtjd.UHGU_Count);
		if((exdtjd.USV_Count+exdtjd.UXV_Count+exdtjd.UHGV_Count)!=0)
			exdtjd.DUVAVE=exdtjd.U_B_Sum/(exdtjd.USV_Count+exdtjd.UXV_Count+exdtjd.UHGV_Count);
		if((exdtjd.USW_Count+exdtjd.UXW_Count+exdtjd.UHGW_Count)!=0)
			exdtjd.DUWAVE=exdtjd.U_C_Sum/(exdtjd.USW_Count+exdtjd.UXW_Count+exdtjd.UHGW_Count);
		//A\B\C�����µ�ѹƽ��ֵ
		if((exdtjm.USU_Count+exdtjm.UXU_Count+exdtjm.UHGU_Count)!=0)
			exdtjm.DUUAVE=exdtjm.U_A_Sum/(exdtjm.USU_Count+exdtjm.UXU_Count+exdtjm.UHGU_Count);
		if((exdtjm.USV_Count+exdtjm.UXV_Count+exdtjm.UHGV_Count)!=0)
			exdtjm.DUVAVE=exdtjm.U_B_Sum/(exdtjm.USV_Count+exdtjm.UXV_Count+exdtjm.UHGV_Count);
		if((exdtjm.USW_Count+exdtjm.UXW_Count+exdtjm.UHGW_Count)!=0)
			exdtjm.DUWAVE=exdtjm.U_C_Sum/(exdtjm.USW_Count+exdtjm.UXW_Count+exdtjm.UHGW_Count);

		exdtjd.T_time=ts;
		exdtjm.T_time=ts;
	}
}
