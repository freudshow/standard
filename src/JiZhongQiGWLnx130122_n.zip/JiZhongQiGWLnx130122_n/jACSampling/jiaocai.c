#include "jiaocai.h"
extern void SetRtcInt(INT8U type);
INT32S CkSum, CkSunOld;
const char verstr[] = { "VER-jiaocai-FLG=007.002.217.004"__DATE__" "__TIME__ };
#if (NUM_FFT == 64)
const INT32S sin_tab[64]  = {     0,   3212,   6393,   9512,  12539,  15446,  18204,  20787,  23170,   25329,  27245,  28898,  30273,  31356,  32137,  32609,
                              32767,  32609,  32137,  31356,  30273,  28898,  27245,  25329,  23170,   20787,  18204,  15446,  12539,   9512,   6393,   3212,
                                  0,  -3212,  -6393,  -9512, -12539, -15446, -18204, -20787, -23170,  -25329, -27245, -28898, -30273, -31356, -32137, -32609,
                             -32767, -32609, -32137, -31356, -30273, -28898, -27245, -25329, -23170,  -20787, -18204, -15446, -12539,  -9512,  -6393,  -3212};

const INT32S cos_tab[64]  = {  32767,  32609,  32137,  31356,  30273,  28898,  27245,  25329,  23170,   20787,  18204,  15446,  12539,   9512,   6393,   3212,
                                  0,  -3212,  -6393,  -9512, -12539, -15446, -18204, -20787, -23170,  -25329, -27245, -28898, -30273, -31356, -32137, -32609,
                             -32767, -32609, -32137, -31356, -30273, -28898, -27245, -25329, -23170,  -20787, -18204, -15446, -12539,  -9512,  -6393,  -3212,
                                  0,   3212,   6393,   9512,  12539,  15446,  18204,  20787,  23170,   25329,  27245,  28898,  30273,  31356,  32137,  32609};





const INT8U DXTable[64] =  {
							0 ,	32,	16,	48,
							8 ,	40,	24,	56,
							4 ,	36,	20,	52,
							12,	44,	28,	60,
							2 ,	34,	18,	50,
							10,	42,	26,	58,
							6 ,	38,	22,	54,
							14,	46,	30,	62,

							1 ,	33,	17,	49,
							9 ,	41,	25,	57,
							5 ,	37,	21,	53,
							13,	45,	29,	61,
							3 ,	35,	19,	51,
							11,	43,	27,	59,
							7 ,	39,	23,	55,
							15,	47,	31,	63
						  };


#endif
/*********************************/
//���������㲢�Ҵ�����
//********************************/
INT32S ReadXBpoint(void)
{
   INT32S readc=0;
   INT8U temp[3];

   readc=ATTRead(SPI1,0x7f,3,temp,0);
   if(readc>32768)
	   readc = readc - 65536;
   return readc;
}
//**************************************************/
// ʹ�ܵ�ѹ\����ͨ����г����������
// 0xa ��ѹͨ�� ���� ua ub uc��˳��Ų�����
// 0xb ��ѹͨ�� ���� ia ib ic��˳��Ų�����
//**************************************************/
void ATT7022E_XIEBO()
{
	INT8U i,temp[3];
	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0x5a;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //����д����

	//ֹͣͬ�����ݹ���
	temp[0] = 0x00;
	temp[1] = 0x00;
	temp[2] = 0x00;
	ATTWrite(SPI1,0xc5,3,temp,0);
	//�����Զ�ͬ�����ݹ���
	temp[0] = 0x00;
	temp[1] = 0x00;
	temp[2] = 0x02;
	ATTWrite(SPI1,0xc5,3,temp,0);
	delay(100);
	for(i=0;i<80;i++)
	{
		ClearWaitTimes(ProjectNo,JProgramInfo);
		XBpoint.ua[i]=ReadXBpoint();
		XBpoint.ub[i]=ReadXBpoint();
		XBpoint.uc[i]=ReadXBpoint();
		XBpoint.ia[i]=ReadXBpoint();
		XBpoint.ib[i]=ReadXBpoint();
		XBpoint.ic[i]=ReadXBpoint();
		ReadXBpoint();
//		printf("\n\r%d",XBpoint.ua[i]);
//		printf("\n\r7022 XBpoint.ub[%d]=%d",i,XBpoint.ub[i]);
//		printf("\n\r7022 XBpoint.uc[%d]=%d",i,XBpoint.uc[i]);
//		printf("\n\r7022 XBpoint.ia[%d]=%d",i,XBpoint.ia[i]);
//		printf("\n\r7022 XBpoint.ib[%d]=%d",i,XBpoint.ib[i]);
//		printf("\n\r7022 XBpoint.ic[%d]=%d",i,XBpoint.ic[i]);
	}
	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 1;
	ATTWrite(SPI1, 0xc9, 3, temp, 0); //������д����
	memcpy(&JDataFileInfo->jc.xiebo.XBpoint,&XBpoint,sizeof(xdata));
	JDataFileInfo->jc.xiebo.AllXBo.Valid=1;
}
/***********************************************************/
//fft�㷨��
//*��ڲ�������������Ժ�Ĳ����㣬���ڲ�����ʵ���鲿
/***********************************************************/
void FFT_Test(INT32S *dataR,Lisan *some)
{
    int k,L,j,b,p,i,temp;
    INT32S TR,TI;
    INT32S XRC,XRS,XIC,XIS,AXRI,SXRI;
    INT32S dataI[NUM_FFT];
    memset(dataI,0,sizeof(dataI));

    for(L=1;L<=EXP_FFT;++L) {   /* for(1) */
        b=1;
        i=L-1;
        if (i>0)
        	b=b<<(i);
        for(j=0;j<=b-1;j++) {   /* for(2) */
            p=1;
            i=EXP_FFT-L;
            if (i>0)
                p=p<<(i);
            p=p*j;
            for(k=j;k<NUM_FFT;k+=(b << 1)) {  /* for(3) */

                TR=dataR[k];
                TI=dataI[k];
                temp=k+b;

				XRC=((INT64S)dataR[temp]*cos_tab[p])>>15;
				XRS=((INT64S)dataR[temp]*sin_tab[p])>>15;
				XIC=((INT64S)dataI[temp]*cos_tab[p])>>15;
                XIS=((INT64S)dataI[temp]*sin_tab[p])>>15;

                AXRI=XRC+XIS;
                SXRI=XRS-XIC;
                dataR[k]=TR+AXRI;//(XRC+XIS);
                dataI[k]=TI-SXRI;//(XRS-XIC);
                dataR[temp]=TR-AXRI;//(XRC+XIS);
                dataI[temp]=TI+SXRI;//(XRS-XIC);


            }
        }
    }
    for(i=0;i<20;i++)
	{ /* ֻ��Ҫ20�����µ�г�����з��� */
      some[i].Real = dataR[i];
      some[i].Imag = dataI[i];
	}
}
void fft_daoxu(INT32S *dataR)
{
   INT8U a,b,i;
   INT32S Temp;
   for(i=1;i<NUM_FFT;i++)
   {
		a = i;
		b = DXTable[i];
		if(b > a)
		{
		  Temp = dataR[a];
		  dataR[a]=dataR[b];
		  dataR[b]=Temp;
		}
   }
}
//ffttest  �ܺ���
//��ڲ�������ɢ������
//���ڲ�����г��
void ffttest(INT32S *pointbuf,INT16U *xb)
{
	INT8U i;
	INT64U tempasd;
    INT32S temp1,temp2;
	INT32S chazhibuf[64];   //64��fft
	Lisan allsome[20];
	TS ts;
	TSGet(&ts);
//	chazhilage(chazhibuf,pointbuf);
	memcpy(chazhibuf,pointbuf,sizeof(chazhibuf));
//	for(i=0;i<64;i++)
//	{
//		printf("\n\r%d",chazhibuf[i]);
//	}
//	printf("\n\r\n\r\n\r");
	fft_daoxu(chazhibuf);
	FFT_Test(chazhibuf,allsome);

	for(i=0;i<20;i++)
	{
		temp1 = (allsome[i].Real)/10;
		temp2 = (allsome[i].Imag)/10;
		tempasd =(INT64U) (temp1*temp1+temp2*temp2) ;
		xb[i]=sqrt(tempasd);
	}
}
void FFT(){
    ffttest(JDataFileInfo->jc.xiebo.XBpoint.ua,JDataFileInfo->jc.xiebo.AllXBo.TempUAxb);//����A��2-19��г����ѹ
    ffttest(JDataFileInfo->jc.xiebo.XBpoint.ub,JDataFileInfo->jc.xiebo.AllXBo.TempUBxb);//����B��2-19��г����ѹ
    ffttest(JDataFileInfo->jc.xiebo.XBpoint.uc,JDataFileInfo->jc.xiebo.AllXBo.TempUCxb);//����C��2-19��г����ѹ
    ffttest(JDataFileInfo->jc.xiebo.XBpoint.ia,JDataFileInfo->jc.xiebo.AllXBo.TempIAxb);//����A��2-19��г������
    ffttest(JDataFileInfo->jc.xiebo.XBpoint.ib,JDataFileInfo->jc.xiebo.AllXBo.TempIBxb);//����B��2-19��г������
    ffttest(JDataFileInfo->jc.xiebo.XBpoint.ic,JDataFileInfo->jc.xiebo.AllXBo.TempICxb);//����C��2-19��г������
}
void calxbval()
{
	int i=0;
    for(i=0;i<20;i++)
    {//����г���ܺ����ʼ�����г�������ʺ�г��ֵ
    	ClearWaitTimes(ProjectNo,JProgramInfo);
    	if(abs(JDataFileInfo->jc.xiebo.AllXBo.TempUAxb[1])>60)
    	{
    		JDataFileInfo->jc.xiebo.AllXBo.UA_Hanyoulv[i]=JDataFileInfo->jc.xiebo.AllXBo.TempUAxb[i]*100.0/JDataFileInfo->jc.xiebo.AllXBo.TempUAxb[1];
    		JDataFileInfo->jc.xiebo.AllXBo.UAxb[i]=JDataFileInfo->jc.xiebo.AllXBo.TempUAxb[i]*1.0/JDataFileInfo->jc.xiebo.AllXBo.TempUAxb[1]*JDataFileInfo->jc.xiebo.AllXBo.UAbase;
    	}
    	else
    	{
    		JDataFileInfo->jc.xiebo.AllXBo.UA_Hanyoulv[i]=0;
    		JDataFileInfo->jc.xiebo.AllXBo.UAxb[i]=0;
    	}
    	if(abs(JDataFileInfo->jc.xiebo.AllXBo.TempUBxb[1])>60)
    	{
	    	JDataFileInfo->jc.xiebo.AllXBo.UB_Hanyoulv[i]=JDataFileInfo->jc.xiebo.AllXBo.TempUBxb[i]*100.0/JDataFileInfo->jc.xiebo.AllXBo.TempUBxb[1];
    		JDataFileInfo->jc.xiebo.AllXBo.UBxb[i]=JDataFileInfo->jc.xiebo.AllXBo.TempUBxb[i]*1.0/JDataFileInfo->jc.xiebo.AllXBo.TempUBxb[1]*JDataFileInfo->jc.xiebo.AllXBo.UBbase;
    	}
    	else
    	{
    		JDataFileInfo->jc.xiebo.AllXBo.UB_Hanyoulv[i]=0;
    		JDataFileInfo->jc.xiebo.AllXBo.UBxb[i]=0;
    	}
    	if(abs(JDataFileInfo->jc.xiebo.AllXBo.TempUCxb[1])>60)
    	{
    		JDataFileInfo->jc.xiebo.AllXBo.UC_Hanyoulv[i]=JDataFileInfo->jc.xiebo.AllXBo.TempUCxb[i]*100.0/JDataFileInfo->jc.xiebo.AllXBo.TempUCxb[1];
    		JDataFileInfo->jc.xiebo.AllXBo.UCxb[i]=JDataFileInfo->jc.xiebo.AllXBo.TempUCxb[i]*1.0/JDataFileInfo->jc.xiebo.AllXBo.TempUCxb[1]*JDataFileInfo->jc.xiebo.AllXBo.UCbase;
    	}
    	else
    	{
    		JDataFileInfo->jc.xiebo.AllXBo.UC_Hanyoulv[i]=0;
    		JDataFileInfo->jc.xiebo.AllXBo.UCxb[i]=0;
    	}

    	if(abs(JDataFileInfo->jc.xiebo.AllXBo.TempIAxb[1]>10))
    	{
    		JDataFileInfo->jc.xiebo.AllXBo.IA_Hanyoulv[i]=JDataFileInfo->jc.xiebo.AllXBo.TempIAxb[i]*100.0/JDataFileInfo->jc.xiebo.AllXBo.TempIAxb[1];
    		JDataFileInfo->jc.xiebo.AllXBo.IAxb[i]=JDataFileInfo->jc.xiebo.AllXBo.TempIAxb[i]*1.0/JDataFileInfo->jc.xiebo.AllXBo.TempIAxb[1]*JDataFileInfo->jc.xiebo.AllXBo.IAbase;
    	}
    	else
    	{
    		JDataFileInfo->jc.xiebo.AllXBo.IA_Hanyoulv[i]=0;
    		JDataFileInfo->jc.xiebo.AllXBo.IAxb[i]=0;
    	}
    	if(abs(JDataFileInfo->jc.xiebo.AllXBo.TempIBxb[1]>10))
    	{
    		JDataFileInfo->jc.xiebo.AllXBo.IB_Hanyoulv[i]=JDataFileInfo->jc.xiebo.AllXBo.TempIBxb[i]*100.0/JDataFileInfo->jc.xiebo.AllXBo.TempIBxb[1];
    		JDataFileInfo->jc.xiebo.AllXBo.IBxb[i]=JDataFileInfo->jc.xiebo.AllXBo.TempIBxb[i]*1.0/JDataFileInfo->jc.xiebo.AllXBo.TempIBxb[1]*JDataFileInfo->jc.xiebo.AllXBo.IBbase;
    	}
    	else
    	{
    		JDataFileInfo->jc.xiebo.AllXBo.IB_Hanyoulv[i]=0;
    		JDataFileInfo->jc.xiebo.AllXBo.IBxb[i]=0;
    	}
    	if(abs(JDataFileInfo->jc.xiebo.AllXBo.TempICxb[1]>10))
    	{
    		JDataFileInfo->jc.xiebo.AllXBo.IC_Hanyoulv[i]=JDataFileInfo->jc.xiebo.AllXBo.TempICxb[i]*100.0/JDataFileInfo->jc.xiebo.AllXBo.TempICxb[1];
    		JDataFileInfo->jc.xiebo.AllXBo.ICxb[i]=JDataFileInfo->jc.xiebo.AllXBo.TempICxb[i]*1.0/JDataFileInfo->jc.xiebo.AllXBo.TempICxb[1]*JDataFileInfo->jc.xiebo.AllXBo.ICbase;
    	}
    	else
    	{
    		JDataFileInfo->jc.xiebo.AllXBo.IC_Hanyoulv[i]=0;
    		JDataFileInfo->jc.xiebo.AllXBo.ICxb[i]=0;
    	}
    }
}

void XIEBO_MAX_Calc()
{
	INT8U i;
	float IA_Zongjibian,IB_Zongjibian,IC_Zongjibian,UA_Zongjibian,UB_Zongjibian,UC_Zongjibian;
	UA_Zongjibian=UB_Zongjibian=UC_Zongjibian=0;
	IA_Zongjibian=IB_Zongjibian=IC_Zongjibian=0;
	for(i=2;i<20;i++)
	{	//�ܻ�����=����г�������ʵ�ƽ���͵Ŀ���
		ClearWaitTimes(ProjectNo,JProgramInfo);
		UA_Zongjibian=UA_Zongjibian+(JDataFileInfo->jc.xiebo.AllXBo.UA_Hanyoulv[i])*(JDataFileInfo->jc.xiebo.AllXBo.UA_Hanyoulv[i]);
		UB_Zongjibian=UB_Zongjibian+(JDataFileInfo->jc.xiebo.AllXBo.UB_Hanyoulv[i])*(JDataFileInfo->jc.xiebo.AllXBo.UB_Hanyoulv[i]);
		UC_Zongjibian=UC_Zongjibian+(JDataFileInfo->jc.xiebo.AllXBo.UC_Hanyoulv[i])*(JDataFileInfo->jc.xiebo.AllXBo.UC_Hanyoulv[i]);
		IA_Zongjibian=IA_Zongjibian+(JDataFileInfo->jc.xiebo.AllXBo.IA_Hanyoulv[i])*(JDataFileInfo->jc.xiebo.AllXBo.IA_Hanyoulv[i]);
		IB_Zongjibian=IB_Zongjibian+(JDataFileInfo->jc.xiebo.AllXBo.IB_Hanyoulv[i])*(JDataFileInfo->jc.xiebo.AllXBo.IB_Hanyoulv[i]);
		IC_Zongjibian=IC_Zongjibian+(JDataFileInfo->jc.xiebo.AllXBo.IC_Hanyoulv[i])*(JDataFileInfo->jc.xiebo.AllXBo.IC_Hanyoulv[i]);
	}
	JDataFileInfo->jc.xiebo.AllXBo.UA_Zongjibian=sqrt(UA_Zongjibian);//����A���ѹ�ܻ�����
	JDataFileInfo->jc.xiebo.AllXBo.UB_Zongjibian=sqrt(UB_Zongjibian);//����B���ѹ�ܻ�����
	JDataFileInfo->jc.xiebo.AllXBo.UC_Zongjibian=sqrt(UC_Zongjibian);//����C���ѹ�ܻ�����
	JDataFileInfo->jc.xiebo.AllXBo.IA_Zongjibian=sqrt(IA_Zongjibian);//����A������ܻ�����
	JDataFileInfo->jc.xiebo.AllXBo.IB_Zongjibian=sqrt(IB_Zongjibian);//����B������ܻ�����
	JDataFileInfo->jc.xiebo.AllXBo.IC_Zongjibian=sqrt(IC_Zongjibian);//����C������ܻ�����

	JDataFileInfo->jc.xiebo.AllXBo.UA_HanyoulvZong=JDataFileInfo->jc.xiebo.AllXBo.UA_Zongjibian;
	JDataFileInfo->jc.xiebo.AllXBo.UB_HanyoulvZong=JDataFileInfo->jc.xiebo.AllXBo.UB_Zongjibian;
	JDataFileInfo->jc.xiebo.AllXBo.UC_HanyoulvZong=JDataFileInfo->jc.xiebo.AllXBo.UC_Zongjibian;

	JDataFileInfo->jc.xiebo.AllXBo.IA_Zongjb=JDataFileInfo->jc.xiebo.AllXBo.IA_Zongjibian*JDataFileInfo->jc.xiebo.AllXBo.IAbase;
	JDataFileInfo->jc.xiebo.AllXBo.IB_Zongjb=JDataFileInfo->jc.xiebo.AllXBo.IB_Zongjibian*JDataFileInfo->jc.xiebo.AllXBo.IBbase;
	JDataFileInfo->jc.xiebo.AllXBo.IC_Zongjb=JDataFileInfo->jc.xiebo.AllXBo.IC_Zongjibian*JDataFileInfo->jc.xiebo.AllXBo.ICbase;
	for(i=2;i<20;i++)
	{
		ClearWaitTimes(ProjectNo,JProgramInfo);
		if(JDataFileInfo->jc.xiebo.AllXBo.IAxb[i]>JDataFileInfo->jc.xiebo.IAxb_Max[i])
		{//U��2--19�ε���г�����ֵ������ʱ��
			JDataFileInfo->jc.xiebo.IAxb_Max[i]=JDataFileInfo->jc.xiebo.AllXBo.IAxb[i];
			memcpy(&JDataFileInfo->jc.xiebo.IAxb_Max_Time[i],&xb_Time,sizeof(xb_Time));
		}
		if(JDataFileInfo->jc.xiebo.AllXBo.IBxb[i]>JDataFileInfo->jc.xiebo.IBxb_Max[i])
		{//V��2--19�ε���г�����ֵ������ʱ��
			JDataFileInfo->jc.xiebo.IBxb_Max[i]=JDataFileInfo->jc.xiebo.AllXBo.IBxb[i];
			memcpy(&JDataFileInfo->jc.xiebo.IBxb_Max_Time[i],&xb_Time,sizeof(xb_Time));
		}
		if(JDataFileInfo->jc.xiebo.AllXBo.ICxb[i]>JDataFileInfo->jc.xiebo.ICxb_Max[i])
		{//W��2--19�ε���г�����ֵ������ʱ��
			JDataFileInfo->jc.xiebo.ICxb_Max[i]=JDataFileInfo->jc.xiebo.AllXBo.ICxb[i];
			memcpy(&JDataFileInfo->jc.xiebo.ICxb_Max_Time[i],&xb_Time,sizeof(xb_Time));
		}
		//A\B\C��2--19��г����ѹ���������ֵ
		if(JDataFileInfo->jc.xiebo.AllXBo.UA_Hanyoulv[i]>JDataFileInfo->jc.xiebo.UA_Hanyoulv_Max[i])
		{
			JDataFileInfo->jc.xiebo.UA_Hanyoulv_Max[i]=JDataFileInfo->jc.xiebo.AllXBo.UA_Hanyoulv[i];
			memcpy(&JDataFileInfo->jc.xiebo.UA_Hanyoulv_Max_Time[i],&xb_Time,sizeof(xb_Time));
		}
		if(JDataFileInfo->jc.xiebo.AllXBo.UB_Hanyoulv[i]>JDataFileInfo->jc.xiebo.UB_Hanyoulv_Max[i])
		{
			JDataFileInfo->jc.xiebo.UB_Hanyoulv_Max[i]=JDataFileInfo->jc.xiebo.AllXBo.UB_Hanyoulv[i];
			memcpy(&JDataFileInfo->jc.xiebo.UB_Hanyoulv_Max_Time[i],&xb_Time,sizeof(xb_Time));
		}
		if(JDataFileInfo->jc.xiebo.AllXBo.UC_Hanyoulv[i]>JDataFileInfo->jc.xiebo.UC_Hanyoulv_Max[i])
		{
			JDataFileInfo->jc.xiebo.UC_Hanyoulv_Max[i]=JDataFileInfo->jc.xiebo.AllXBo.UC_Hanyoulv[i];
			memcpy(&JDataFileInfo->jc.xiebo.UC_Hanyoulv_Max_Time[i],&xb_Time,sizeof(xb_Time));
		}
	}
	//A\B\C��г����ѹ�ܻ��������ֵ
	if(JDataFileInfo->jc.xiebo.AllXBo.UA_Zongjibian>JDataFileInfo->jc.xiebo.UA_ZongJiBianLv_Max)
	{
		JDataFileInfo->jc.xiebo.UA_ZongJiBianLv_Max=JDataFileInfo->jc.xiebo.AllXBo.UA_Zongjibian;
		memcpy(&JDataFileInfo->jc.xiebo.UA_ZongJiBianLv_Max_Time,&xb_Time,sizeof(xb_Time));
	}
	if(JDataFileInfo->jc.xiebo.AllXBo.UB_Zongjibian>JDataFileInfo->jc.xiebo.UB_ZongJiBianLv_Max)
	{
		JDataFileInfo->jc.xiebo.UB_ZongJiBianLv_Max=JDataFileInfo->jc.xiebo.AllXBo.UB_Zongjibian;
		memcpy(&JDataFileInfo->jc.xiebo.UB_ZongJiBianLv_Max_Time,&xb_Time,sizeof(xb_Time));
	}
	if(JDataFileInfo->jc.xiebo.AllXBo.UC_Zongjibian>JDataFileInfo->jc.xiebo.UC_ZongJiBianLv_Max)
	{
		JDataFileInfo->jc.xiebo.UC_ZongJiBianLv_Max=JDataFileInfo->jc.xiebo.AllXBo.UC_Zongjibian;
		memcpy(&JDataFileInfo->jc.xiebo.UC_ZongJiBianLv_Max_Time,&xb_Time,sizeof(xb_Time));
	}

	//A\B\C��г���ܻ���������ֵ
	if(JDataFileInfo->jc.xiebo.AllXBo.IA_Zongjb>JDataFileInfo->jc.xiebo.IA_ZongJiBian_Max)
	{
		JDataFileInfo->jc.xiebo.IA_ZongJiBian_Max=JDataFileInfo->jc.xiebo.AllXBo.IA_Zongjb;
		memcpy(&JDataFileInfo->jc.xiebo.IA_ZongJiBian_Max_Time,&xb_Time,sizeof(xb_Time));
	}
	if(JDataFileInfo->jc.xiebo.AllXBo.IB_Zongjb>JDataFileInfo->jc.xiebo.IB_ZongJiBian_Max)
	{
		JDataFileInfo->jc.xiebo.IB_ZongJiBian_Max=JDataFileInfo->jc.xiebo.AllXBo.IB_Zongjb;
		memcpy(&JDataFileInfo->jc.xiebo.IB_ZongJiBian_Max_Time,&xb_Time,sizeof(xb_Time));
	}
	if(JDataFileInfo->jc.xiebo.AllXBo.IC_Zongjb>JDataFileInfo->jc.xiebo.IC_ZongJiBian_Max)
	{
		JDataFileInfo->jc.xiebo.IC_ZongJiBian_Max=JDataFileInfo->jc.xiebo.AllXBo.IC_Zongjb;
		memcpy(&JDataFileInfo->jc.xiebo.IC_ZongJiBian_Max_Time,&xb_Time,sizeof(xb_Time));
	}
}
//void XIEBO_YUEXIAN_Calc()
//{
//	INT16U ZongJiBian_UHanyoulvSX,JiCi_UHanyoulvSX,OuCi_UHanyoulvSX,ZongJiBian_ISX,NCixiebo_ISX[20],NCi_UHanyoulvSX[20];
//	INT8U i;
//	memset(NCi_UHanyoulvSX,0,20);
//	memset(NCixiebo_ISX,0,20);
//	if(Jmemory->jzq.F60_Set_Para.Valid==1)
//	{
//		ClearWaitTimes(ProjectNo,JProgramInfo);
//		//�����ܻ����ѹ����������,������10��
//		ZongJiBian_UHanyoulvSX=((Jmemory->jzq.F60_Set_Para.All_QiBian_DYaHy_S[1]>>4)*10)+
//			(Jmemory->jzq.F60_Set_Para.All_QiBian_DYaHy_S[1]&0x0f);
//		ZongJiBian_UHanyoulvSX=(ZongJiBian_UHanyoulvSX*100)+((Jmemory->jzq.F60_Set_Para.All_QiBian_DYaHy_S[0]>>4)*10)+
//			(Jmemory->jzq.F60_Set_Para.All_QiBian_DYaHy_S[0]&0x0f);
//		//�������г����ѹ���������ޣ�������10��
//		JiCi_UHanyoulvSX=((Jmemory->jzq.F60_Set_Para.O_XieBo_DYaHy_S[1]>>4)*10)+
//			(Jmemory->jzq.F60_Set_Para.O_XieBo_DYaHy_S[1]&0x0f);
//		JiCi_UHanyoulvSX=(JiCi_UHanyoulvSX*100)+((Jmemory->jzq.F60_Set_Para.O_XieBo_DYaHy_S[0]>>4)*10)+
//			(Jmemory->jzq.F60_Set_Para.O_XieBo_DYaHy_S[0]&0x0f);
//		//����ż��г����ѹ���������ޣ�������10��
//		OuCi_UHanyoulvSX=((Jmemory->jzq.F60_Set_Para.E_XieBo_DYaHanyou_S[1]>>4)*10)+
//			(Jmemory->jzq.F60_Set_Para.E_XieBo_DYaHanyou_S[1]&0x0f);
//		OuCi_UHanyoulvSX=(OuCi_UHanyoulvSX*100)+((Jmemory->jzq.F60_Set_Para.E_XieBo_DYaHanyou_S[0]>>4)*10)+
//			(Jmemory->jzq.F60_Set_Para.E_XieBo_DYaHanyou_S[0]&0x0f);
//		for(i=2;i<20;i++)
//		{//����2--19��г����ѹ���������ޣ�������10��
//			NCi_UHanyoulvSX[i]=(((Jmemory->jzq.F60_Set_Para.XIeBo_DYXieBoLv_S[i][1]>>4)&0x07)*10)+
//				(Jmemory->jzq.F60_Set_Para.XIeBo_DYXieBoLv_S[i][1]&0x0f);
//			NCi_UHanyoulvSX[i]=(NCi_UHanyoulvSX[i]*100)+((Jmemory->jzq.F60_Set_Para.XIeBo_DYXieBoLv_S[i][0]>>4)*10)+
//				(Jmemory->jzq.F60_Set_Para.XIeBo_DYXieBoLv_S[i][0]&0x0f);
//		}
//		//�����ܻ��������Чֵ���ޣ�������100��
//		ZongJiBian_ISX=(((Jmemory->jzq.F60_Set_Para.All_QiBian_DLiu_YX_S[1]>>4)&0x07)*10)+
//			(Jmemory->jzq.F60_Set_Para.All_QiBian_DLiu_YX_S[1]&0x0f);
//		ZongJiBian_ISX=(ZongJiBian_ISX*100)+((Jmemory->jzq.F60_Set_Para.All_QiBian_DLiu_YX_S[0]>>4)*10)+
//			(Jmemory->jzq.F60_Set_Para.All_QiBian_DLiu_YX_S[0]&0x0f);
//		for(i=2;i<20;i++)
//		{//����2--19��г��������Чֵ���ޣ�������100��
//			NCixiebo_ISX[i]=(((Jmemory->jzq.F60_Set_Para.XIeBo_DL_YX_S[i][1]>>4)&0x07)*10)+
//				(Jmemory->jzq.F60_Set_Para.XIeBo_DL_YX_S[i][1]&0x0f);
//			NCixiebo_ISX[i]=(NCixiebo_ISX[i]*100)+((Jmemory->jzq.F60_Set_Para.XIeBo_DL_YX_S[i][0]>>4)*10)+
//				(Jmemory->jzq.F60_Set_Para.XIeBo_DL_YX_S[i][0]&0x0f);
//		}
//
//		//��ʼͳ�Ƹ���Խ���ۼ�ʱ��
//		//�ܻ����ѹ�����ʼ�2-19г����ѹ������Խ��ͳ��
//		if(JDataFileInfo->jc.xiebo.AllXBo.UA_HanyoulvZong*10>ZongJiBian_UHanyoulvSX)
//		{
//			Jmemory->F121_real_Value.ZongJiBian_UCount++;
//		}
//		if(JDataFileInfo->jc.xiebo.AllXBo.UB_HanyoulvZong*10>ZongJiBian_UHanyoulvSX)
//		{
//			Jmemory->F122_real_Value.ZongJiBian_UCount++;
//		}
//		if(JDataFileInfo->jc.xiebo.AllXBo.UC_HanyoulvZong*10>ZongJiBian_UHanyoulvSX)
//		{
//			Jmemory->F123_real_Value.ZongJiBian_UCount++;
//		}
//		//���ݸ���г����ѹ����������ֵ����ͳ��
//		for(i=2;i<20;i++)
//		{
//			if(JDataFileInfo->jc.xiebo.AllXBo.UA_Hanyoulv[i]*10>NCi_UHanyoulvSX[i])
//			{
//				Jmemory->F121_real_Value.GeCi_UCount[i]++;
//			}
//			if(JDataFileInfo->jc.xiebo.AllXBo.UB_Hanyoulv[i]*10>NCi_UHanyoulvSX[i])
//			{
//				Jmemory->F122_real_Value.GeCi_UCount[i]++;
//			}
//			if(JDataFileInfo->jc.xiebo.AllXBo.UC_Hanyoulv[i]*10>NCi_UHanyoulvSX[i])
//			{
//				Jmemory->F123_real_Value.GeCi_UCount[i]++;
//			}
//		}
//		//������ż��г����ѹ����������ֵ����ͳ��
////		for(i=3;i<20;i+=2)
////		{
////			if(JDataFileInfo->jc.xiebo.AllXBo.UA_Hanyoulv[i]*10>JiCi_UHanyoulvSX)
////			{
////				Jmemory->F121_real_Value.GeCi_UCount[i]++;
////			}
////			if(JDataFileInfo->jc.xiebo.AllXBo.UB_Hanyoulv[i]*10>JiCi_UHanyoulvSX)
////			{
////				Jmemory->F122_real_Value.GeCi_UCount[i]++;
////			}
////			if(JDataFileInfo->jc.xiebo.AllXBo.UC_Hanyoulv[i]*10>JiCi_UHanyoulvSX)
////			{
////				Jmemory->F123_real_Value.GeCi_UCount[i]++;
////			}
////		}
////		for(i=2;i<20;i+=2)
////		{
////			if(JDataFileInfo->jc.xiebo.AllXBo.UA_Hanyoulv[i]*10>OuCi_UHanyoulvSX)
////			{
////				Jmemory->F121_real_Value.GeCi_UCount[i]++;
////			}
////			if(JDataFileInfo->jc.xiebo.AllXBo.UB_Hanyoulv[i]*10>OuCi_UHanyoulvSX)
////			{
////				Jmemory->F122_real_Value.GeCi_UCount[i]++;
////			}
////			if(JDataFileInfo->jc.xiebo.AllXBo.UC_Hanyoulv[i]*10>OuCi_UHanyoulvSX)
////			{
////				Jmemory->F123_real_Value.GeCi_UCount[i]++;
////			}
////		}
//
//		//�ܻ��������2-19��г������Խ��ͳ��
//		if(JDataFileInfo->jc.xiebo.AllXBo.IA_Zongjb>ZongJiBian_ISX)
//		{
//			Jmemory->F121_real_Value.ZongJiBian_ICount++;
//		}
//		if(JDataFileInfo->jc.xiebo.AllXBo.IB_Zongjb>ZongJiBian_ISX)
//		{
//			Jmemory->F122_real_Value.ZongJiBian_ICount++;
//		}
//		if(JDataFileInfo->jc.xiebo.AllXBo.IC_Zongjb>ZongJiBian_ISX)
//		{
//			Jmemory->F123_real_Value.ZongJiBian_ICount++;
//		}
//		for(i=2;i<20;i++)
//		{
//			if(JDataFileInfo->jc.xiebo.AllXBo.IAxb[i]*100>NCixiebo_ISX[i])
//			{
//				Jmemory->F121_real_Value.GeCi_ICount[i]++;
//			}
//			if(JDataFileInfo->jc.xiebo.AllXBo.IBxb[i]*100>NCixiebo_ISX[i])
//			{
//				Jmemory->F122_real_Value.GeCi_ICount[i]++;
//			}
//			if(JDataFileInfo->jc.xiebo.AllXBo.ICxb[i]*100>NCixiebo_ISX[i])
//			{
//				Jmemory->F123_real_Value.GeCi_ICount[i]++;
//			}
//		}
//		fprintf(stderr,"\n\r%s %f","A���ѹ�ܺ�����*10",JDataFileInfo->jc.xiebo.AllXBo.UA_HanyoulvZong*10);
//		fprintf(stderr,"\n\r%s %f","B���ѹ�ܺ�����*10",JDataFileInfo->jc.xiebo.AllXBo.UB_HanyoulvZong*10);
//		fprintf(stderr,"\n\r%s %f","C���ѹ�ܺ�����*10",JDataFileInfo->jc.xiebo.AllXBo.UC_HanyoulvZong*10);
//		fprintf(stderr,"\n\r%s %d","A���ܻ������*100",JDataFileInfo->jc.xiebo.AllXBo.IA_Zongjb);
//		fprintf(stderr,"\n\r%s %d","B���ܻ������*100",JDataFileInfo->jc.xiebo.AllXBo.IB_Zongjb);
//		fprintf(stderr,"\n\r%s %d","C���ܻ������*100",JDataFileInfo->jc.xiebo.AllXBo.IC_Zongjb);
//		fprintf(stderr,"\n\r%s","--------------г��ͳ�ƴ�ӡ-------------");
//		fprintf(stderr,"\n\r%s %d","�ܻ����ѹ����������:  ",ZongJiBian_UHanyoulvSX);
//		fprintf(stderr,"\n\r%s %d","���г����ѹ����������:",JiCi_UHanyoulvSX);
//		fprintf(stderr,"\n\r%s %d","ż��г����ѹ����������:",OuCi_UHanyoulvSX);
//		for(i=2;i<20;i++)
//			fprintf(stderr,"\n\r%d %s %d",i,"��г����ѹ����������:",NCi_UHanyoulvSX[i]);
//		fprintf(stderr,"\n\r%s %d","�ܻ��������Чֵ����:  ",ZongJiBian_ISX);
//		for(i=2;i<20;i++)
//			fprintf(stderr,"\n\r%d %s %d",i,"��г����������:",NCixiebo_ISX[i]);
//
//		fprintf(stderr,"\n\r%s %d  %d  %d","�ܻ����ѹ������Խ��ʱ��: A  B  C",Jmemory->F121_real_Value.ZongJiBian_UCount,Jmemory->F122_real_Value.ZongJiBian_UCount,Jmemory->F123_real_Value.ZongJiBian_UCount);
//		for(i=2;i<20;i++)
//			fprintf(stderr,"\n\r%d%s %d  %d  %d",i,"��г����ѹ������Խ��ʱ��:A  B  C",Jmemory->F121_real_Value.GeCi_UCount[i],Jmemory->F122_real_Value.GeCi_UCount[i],Jmemory->F123_real_Value.GeCi_UCount[i]);
//		fprintf(stderr,"\n\r%s %d  %d  %d","�ܻ������Խ��ʱ��: A  B  C",Jmemory->F121_real_Value.ZongJiBian_ICount,Jmemory->F122_real_Value.ZongJiBian_ICount,Jmemory->F123_real_Value.ZongJiBian_ICount);
//		for(i=2;i<20;i++)
//			fprintf(stderr,"\n\r%d%s %d  %d  %d",i,"��г������Խ��ʱ��:A  B  C",Jmemory->F121_real_Value.GeCi_ICount[i],Jmemory->F122_real_Value.GeCi_ICount[i],Jmemory->F123_real_Value.GeCi_ICount[i]);
//		fprintf(stderr,"\n\r%s","--------------г��ͳ�ƴ�ӡ����-------------");
//	}
//}
//void XIEBO_MAX_Calc()
//{
//	INT8U i;
//	float IA_Zongjibian,IB_Zongjibian,IC_Zongjibian,UA_Zongjibian,UB_Zongjibian,UC_Zongjibian;
//	UA_Zongjibian=UB_Zongjibian=UC_Zongjibian=0;
//	IA_Zongjibian=IB_Zongjibian=IC_Zongjibian=0;
//	for(i=2;i<20;i++)
//	{	//�ܻ�����=����г�������ʵ�ƽ���͵Ŀ���
//		ClearWaitTimes(ProjectNo,JProgramInfo);
//		UA_Zongjibian=UA_Zongjibian+(JDataFileInfo->jc.xiebo.AllXBo.UA_Hanyoulv[i])*(JDataFileInfo->jc.xiebo.AllXBo.UA_Hanyoulv[i]);
//		UB_Zongjibian=UB_Zongjibian+(JDataFileInfo->jc.xiebo.AllXBo.UB_Hanyoulv[i])*(JDataFileInfo->jc.xiebo.AllXBo.UB_Hanyoulv[i]);
//		UC_Zongjibian=UC_Zongjibian+(JDataFileInfo->jc.xiebo.AllXBo.UC_Hanyoulv[i])*(JDataFileInfo->jc.xiebo.AllXBo.UC_Hanyoulv[i]);
//		IA_Zongjibian=IA_Zongjibian+(JDataFileInfo->jc.xiebo.AllXBo.IA_Hanyoulv[i])*(JDataFileInfo->jc.xiebo.AllXBo.IA_Hanyoulv[i]);
//		IB_Zongjibian=IB_Zongjibian+(JDataFileInfo->jc.xiebo.AllXBo.IB_Hanyoulv[i])*(JDataFileInfo->jc.xiebo.AllXBo.IB_Hanyoulv[i]);
//		IC_Zongjibian=IC_Zongjibian+(JDataFileInfo->jc.xiebo.AllXBo.IC_Hanyoulv[i])*(JDataFileInfo->jc.xiebo.AllXBo.IC_Hanyoulv[i]);
//	}
//	JDataFileInfo->jc.xiebo.AllXBo.UA_Zongjibian=sqrt(UA_Zongjibian);//����A���ѹ�ܻ�����
//	JDataFileInfo->jc.xiebo.AllXBo.UB_Zongjibian=sqrt(UB_Zongjibian);//����B���ѹ�ܻ�����
//	JDataFileInfo->jc.xiebo.AllXBo.UC_Zongjibian=sqrt(UC_Zongjibian);//����C���ѹ�ܻ�����
//	JDataFileInfo->jc.xiebo.AllXBo.IA_Zongjibian=sqrt(IA_Zongjibian);//����A������ܻ�����
//	JDataFileInfo->jc.xiebo.AllXBo.IB_Zongjibian=sqrt(IB_Zongjibian);//����B������ܻ�����
//	JDataFileInfo->jc.xiebo.AllXBo.IC_Zongjibian=sqrt(IC_Zongjibian);//����C������ܻ�����
//
//	JDataFileInfo->jc.xiebo.AllXBo.UA_HanyoulvZong=JDataFileInfo->jc.xiebo.AllXBo.UA_Zongjibian;
//	JDataFileInfo->jc.xiebo.AllXBo.UB_HanyoulvZong=JDataFileInfo->jc.xiebo.AllXBo.UB_Zongjibian;
//	JDataFileInfo->jc.xiebo.AllXBo.UC_HanyoulvZong=JDataFileInfo->jc.xiebo.AllXBo.UC_Zongjibian;
//
//	JDataFileInfo->jc.xiebo.AllXBo.IA_Zongjb=JDataFileInfo->jc.xiebo.AllXBo.IA_Zongjibian*JDataFileInfo->jc.xiebo.AllXBo.IAbase;
//	JDataFileInfo->jc.xiebo.AllXBo.IB_Zongjb=JDataFileInfo->jc.xiebo.AllXBo.IB_Zongjibian*JDataFileInfo->jc.xiebo.AllXBo.IBbase;
//	JDataFileInfo->jc.xiebo.AllXBo.IC_Zongjb=JDataFileInfo->jc.xiebo.AllXBo.IC_Zongjibian*JDataFileInfo->jc.xiebo.AllXBo.ICbase;
//	for(i=2;i<20;i++)
//	{
//		ClearWaitTimes(ProjectNo,JProgramInfo);
//		if(JDataFileInfo->jc.xiebo.AllXBo.IAxb[i]>Jmemory->IAxb_Max[i])
//		{//U��2--19�ε���г�����ֵ������ʱ��
//			Jmemory->IAxb_Max[i]=JDataFileInfo->jc.xiebo.AllXBo.IAxb[i];
//			memcpy(&Jmemory->IAxb_Max_Time[i],&xb_Time,sizeof(xb_Time));
//		}
//		if(JDataFileInfo->jc.xiebo.AllXBo.IBxb[i]>Jmemory->IBxb_Max[i])
//		{//V��2--19�ε���г�����ֵ������ʱ��
//			Jmemory->IBxb_Max[i]=JDataFileInfo->jc.xiebo.AllXBo.IBxb[i];
//			memcpy(&Jmemory->IBxb_Max_Time[i],&xb_Time,sizeof(xb_Time));
//		}
//		if(JDataFileInfo->jc.xiebo.AllXBo.ICxb[i]>Jmemory->ICxb_Max[i])
//		{//W��2--19�ε���г�����ֵ������ʱ��
//			Jmemory->ICxb_Max[i]=JDataFileInfo->jc.xiebo.AllXBo.ICxb[i];
//			memcpy(&Jmemory->ICxb_Max_Time[i],&xb_Time,sizeof(xb_Time));
//		}
//		//A\B\C��2--19��г����ѹ���������ֵ
//		if(JDataFileInfo->jc.xiebo.AllXBo.UA_Hanyoulv[i]>Jmemory->UA_Hanyoulv_Max[i])
//		{
//			Jmemory->UA_Hanyoulv_Max[i]=JDataFileInfo->jc.xiebo.AllXBo.UA_Hanyoulv[i];
//			memcpy(&Jmemory->UA_Hanyoulv_Max_Time[i],&xb_Time,sizeof(xb_Time));
//		}
//		if(JDataFileInfo->jc.xiebo.AllXBo.UB_Hanyoulv[i]>Jmemory->UB_Hanyoulv_Max[i])
//		{
//			Jmemory->UB_Hanyoulv_Max[i]=JDataFileInfo->jc.xiebo.AllXBo.UB_Hanyoulv[i];
//			memcpy(&Jmemory->UB_Hanyoulv_Max_Time[i],&xb_Time,sizeof(xb_Time));
//		}
//		if(JDataFileInfo->jc.xiebo.AllXBo.UC_Hanyoulv[i]>Jmemory->UC_Hanyoulv_Max[i])
//		{
//			Jmemory->UC_Hanyoulv_Max[i]=JDataFileInfo->jc.xiebo.AllXBo.UC_Hanyoulv[i];
//			memcpy(&Jmemory->UC_Hanyoulv_Max_Time[i],&xb_Time,sizeof(xb_Time));
//		}
//	}
//	//A\B\C��г����ѹ�ܻ��������ֵ
//	if(JDataFileInfo->jc.xiebo.AllXBo.UA_Zongjibian>Jmemory->UA_ZongJiBianLv_Max)
//	{
//		Jmemory->UA_ZongJiBianLv_Max=JDataFileInfo->jc.xiebo.AllXBo.UA_Zongjibian;
//		memcpy(&Jmemory->UA_ZongJiBianLv_Max_Time,&xb_Time,sizeof(xb_Time));
//	}
//	if(JDataFileInfo->jc.xiebo.AllXBo.UB_Zongjibian>Jmemory->UB_ZongJiBianLv_Max)
//	{
//		Jmemory->UB_ZongJiBianLv_Max=JDataFileInfo->jc.xiebo.AllXBo.UB_Zongjibian;
//		memcpy(&Jmemory->UB_ZongJiBianLv_Max_Time,&xb_Time,sizeof(xb_Time));
//	}
//	if(JDataFileInfo->jc.xiebo.AllXBo.UC_Zongjibian>Jmemory->UC_ZongJiBianLv_Max)
//	{
//		Jmemory->UC_ZongJiBianLv_Max=JDataFileInfo->jc.xiebo.AllXBo.UC_Zongjibian;
//		memcpy(&Jmemory->UC_ZongJiBianLv_Max_Time,&xb_Time,sizeof(xb_Time));
//	}
//
//	//A\B\C��г���ܻ���������ֵ
//	if(JDataFileInfo->jc.xiebo.AllXBo.IA_Zongjb>Jmemory->IA_ZongJiBian_Max)
//	{
//		Jmemory->IA_ZongJiBian_Max=JDataFileInfo->jc.xiebo.AllXBo.IA_Zongjb;
//		memcpy(&Jmemory->IA_ZongJiBian_Max_Time,&xb_Time,sizeof(xb_Time));
//	}
//	if(JDataFileInfo->jc.xiebo.AllXBo.IB_Zongjb>Jmemory->IB_ZongJiBian_Max)
//	{
//		Jmemory->IB_ZongJiBian_Max=JDataFileInfo->jc.xiebo.AllXBo.IB_Zongjb;
//		memcpy(&Jmemory->IB_ZongJiBian_Max_Time,&xb_Time,sizeof(xb_Time));
//	}
//	if(JDataFileInfo->jc.xiebo.AllXBo.IC_Zongjb>Jmemory->IC_ZongJiBian_Max)
//	{
//		Jmemory->IC_ZongJiBian_Max=JDataFileInfo->jc.xiebo.AllXBo.IC_Zongjb;
//		memcpy(&Jmemory->IC_ZongJiBian_Max_Time,&xb_Time,sizeof(xb_Time));
//	}
//}
//void Save_Min15_XieBo()
//{
//	TS ts;
//	TSGet(&ts);
//	char name[128];
////	int i;
////	for(i=2;i<20;i++)
////		fprintf(stderr,"\n\ri%d Jmemory->IAxb_Max=%f",i,Jmemory->IAxb_Max[i]);
////	for(i=2;i<20;i++)
////		fprintf(stderr,"\n\ri%d Jmemory->UA_Hanyoulv_Max=%f",i,Jmemory->UA_Hanyoulv_Max[i]);
//	memcpy(Jmemory->Min_15_XieBo_Value.IAxb_Max,Jmemory->IAxb_Max,sizeof(Jmemory->IAxb_Max));
//	memcpy(Jmemory->Min_15_XieBo_Value.IBxb_Max,Jmemory->IBxb_Max,sizeof(Jmemory->IAxb_Max));
//	memcpy(Jmemory->Min_15_XieBo_Value.ICxb_Max,Jmemory->ICxb_Max,sizeof(Jmemory->IAxb_Max));
//	memcpy(Jmemory->Min_15_XieBo_Value.IAxb_Max_Time,Jmemory->IAxb_Max_Time,sizeof(Jmemory->IAxb_Max_Time));
//	memcpy(Jmemory->Min_15_XieBo_Value.IBxb_Max_Time,Jmemory->IBxb_Max_Time,sizeof(Jmemory->IBxb_Max_Time));
//	memcpy(Jmemory->Min_15_XieBo_Value.ICxb_Max_Time,Jmemory->ICxb_Max_Time,sizeof(Jmemory->ICxb_Max_Time));
//
//	Jmemory->Min_15_XieBo_Value.IA_ZongJiBian_Max=Jmemory->IA_ZongJiBian_Max;
//	Jmemory->Min_15_XieBo_Value.IB_ZongJiBian_Max=Jmemory->IB_ZongJiBian_Max;
//	Jmemory->Min_15_XieBo_Value.IC_ZongJiBian_Max=Jmemory->IC_ZongJiBian_Max;
//	memcpy(&Jmemory->Min_15_XieBo_Value.IA_ZongJiBian_Max_Time.BCD01,&Jmemory->IA_ZongJiBian_Max_Time.BCD01,sizeof(Jmemory->IA_ZongJiBian_Max_Time));
//	memcpy(&Jmemory->Min_15_XieBo_Value.IB_ZongJiBian_Max_Time.BCD01,&Jmemory->IB_ZongJiBian_Max_Time.BCD01,sizeof(Jmemory->IB_ZongJiBian_Max_Time));
//	memcpy(&Jmemory->Min_15_XieBo_Value.IC_ZongJiBian_Max_Time.BCD01,&Jmemory->IC_ZongJiBian_Max_Time.BCD01,sizeof(Jmemory->IC_ZongJiBian_Max_Time));
//
//	memcpy(Jmemory->Min_15_XieBo_Value.UA_Hanyoulv_Max,Jmemory->UA_Hanyoulv_Max,sizeof(Jmemory->UA_Hanyoulv_Max));
//	memcpy(Jmemory->Min_15_XieBo_Value.UB_Hanyoulv_Max,Jmemory->UB_Hanyoulv_Max,sizeof(Jmemory->UB_Hanyoulv_Max));
//	memcpy(Jmemory->Min_15_XieBo_Value.UC_Hanyoulv_Max,Jmemory->UC_Hanyoulv_Max,sizeof(Jmemory->UC_Hanyoulv_Max));
//	memcpy(Jmemory->Min_15_XieBo_Value.UA_Hanyoulv_Max_Time,Jmemory->UA_Hanyoulv_Max_Time,sizeof(Jmemory->UA_Hanyoulv_Max_Time));
//	memcpy(Jmemory->Min_15_XieBo_Value.UB_Hanyoulv_Max_Time,Jmemory->UB_Hanyoulv_Max_Time,sizeof(Jmemory->UB_Hanyoulv_Max_Time));
//	memcpy(Jmemory->Min_15_XieBo_Value.UC_Hanyoulv_Max_Time,Jmemory->UC_Hanyoulv_Max_Time,sizeof(Jmemory->UC_Hanyoulv_Max_Time));
//
//	Jmemory->Min_15_XieBo_Value.UA_ZongJiBianLv_Max=Jmemory->UA_ZongJiBianLv_Max;
//	Jmemory->Min_15_XieBo_Value.UB_ZongJiBianLv_Max=Jmemory->UB_ZongJiBianLv_Max;
//	Jmemory->Min_15_XieBo_Value.UC_ZongJiBianLv_Max=Jmemory->UC_ZongJiBianLv_Max;
//	memcpy(&Jmemory->Min_15_XieBo_Value.UA_ZongJiBianLv_Max_Time.BCD01,&Jmemory->UA_ZongJiBianLv_Max_Time.BCD01,sizeof(Jmemory->UA_ZongJiBianLv_Max_Time));
//	memcpy(&Jmemory->Min_15_XieBo_Value.UB_ZongJiBianLv_Max_Time.BCD01,&Jmemory->UB_ZongJiBianLv_Max_Time.BCD01,sizeof(Jmemory->UB_ZongJiBianLv_Max_Time));
//	memcpy(&Jmemory->Min_15_XieBo_Value.UC_ZongJiBianLv_Max_Time.BCD01,&Jmemory->UC_ZongJiBianLv_Max_Time.BCD01,sizeof(Jmemory->UC_ZongJiBianLv_Max_Time));
//
//	Jmemory->Min_15_XieBo_Value.U_ZongJiBian_UCount=Jmemory->F121_real_Value.ZongJiBian_UCount;
//	Jmemory->Min_15_XieBo_Value.U_ZongJiBian_ICount=Jmemory->F121_real_Value.ZongJiBian_ICount;
//	Jmemory->Min_15_XieBo_Value.V_ZongJiBian_UCount=Jmemory->F122_real_Value.ZongJiBian_UCount;
//	Jmemory->Min_15_XieBo_Value.V_ZongJiBian_ICount=Jmemory->F122_real_Value.ZongJiBian_ICount;
//	Jmemory->Min_15_XieBo_Value.W_ZongJiBian_UCount=Jmemory->F123_real_Value.ZongJiBian_UCount;
//	Jmemory->Min_15_XieBo_Value.W_ZongJiBian_ICount=Jmemory->F123_real_Value.ZongJiBian_ICount;
//	memcpy(Jmemory->Min_15_XieBo_Value.U_GeCi_UCount,Jmemory->F121_real_Value.GeCi_UCount,sizeof(Jmemory->F121_real_Value.GeCi_UCount));
//	memcpy(Jmemory->Min_15_XieBo_Value.U_GeCi_ICount,Jmemory->F121_real_Value.GeCi_ICount,sizeof(Jmemory->F121_real_Value.GeCi_ICount));
//	memcpy(Jmemory->Min_15_XieBo_Value.V_GeCi_UCount,Jmemory->F122_real_Value.GeCi_UCount,sizeof(Jmemory->F122_real_Value.GeCi_UCount));
//	memcpy(Jmemory->Min_15_XieBo_Value.V_GeCi_ICount,Jmemory->F122_real_Value.GeCi_ICount,sizeof(Jmemory->F122_real_Value.GeCi_ICount));
//	memcpy(Jmemory->Min_15_XieBo_Value.W_GeCi_UCount,Jmemory->F123_real_Value.GeCi_UCount,sizeof(Jmemory->F123_real_Value.GeCi_UCount));
//	memcpy(Jmemory->Min_15_XieBo_Value.W_GeCi_ICount,Jmemory->F123_real_Value.GeCi_ICount,sizeof(Jmemory->F123_real_Value.GeCi_ICount));
//
//	sprintf(name,"/nand/save/xb%02d%02d.dat",ts.Month,ts.Day);
//	SaveFile(name,&Jmemory->Min_15_XieBo_Value.Valid,sizeof(Jmemory->Min_15_XieBo_Value));
//	delay(100);
//}
//void cpyMinDataToRtu()
//{
//	memcpy(Jmemory->IAxb_Max,Jmemory->Min_15_XieBo_Value.IAxb_Max,sizeof(Jmemory->IAxb_Max));
//	memcpy(Jmemory->IBxb_Max,Jmemory->Min_15_XieBo_Value.IBxb_Max,sizeof(Jmemory->IAxb_Max));
//	memcpy(Jmemory->ICxb_Max,Jmemory->Min_15_XieBo_Value.ICxb_Max,sizeof(Jmemory->IAxb_Max));
//	memcpy(Jmemory->IAxb_Max_Time,Jmemory->Min_15_XieBo_Value.IAxb_Max_Time,sizeof(Jmemory->IAxb_Max_Time));
//	memcpy(Jmemory->IBxb_Max_Time,Jmemory->Min_15_XieBo_Value.IBxb_Max_Time,sizeof(Jmemory->IBxb_Max_Time));
//	memcpy(Jmemory->ICxb_Max_Time,Jmemory->Min_15_XieBo_Value.ICxb_Max_Time,sizeof(Jmemory->ICxb_Max_Time));
//
//	Jmemory->IA_ZongJiBian_Max=Jmemory->Min_15_XieBo_Value.IA_ZongJiBian_Max;
//	Jmemory->IB_ZongJiBian_Max=Jmemory->Min_15_XieBo_Value.IB_ZongJiBian_Max;
//	Jmemory->IC_ZongJiBian_Max=Jmemory->Min_15_XieBo_Value.IC_ZongJiBian_Max;
//	memcpy(&Jmemory->IA_ZongJiBian_Max_Time.BCD01,&Jmemory->Min_15_XieBo_Value.IA_ZongJiBian_Max_Time.BCD01,sizeof(Jmemory->IA_ZongJiBian_Max_Time));
//	memcpy(&Jmemory->IB_ZongJiBian_Max_Time.BCD01,&Jmemory->Min_15_XieBo_Value.IB_ZongJiBian_Max_Time.BCD01,sizeof(Jmemory->IB_ZongJiBian_Max_Time));
//	memcpy(&Jmemory->IC_ZongJiBian_Max_Time.BCD01,&Jmemory->Min_15_XieBo_Value.IC_ZongJiBian_Max_Time.BCD01,sizeof(Jmemory->IC_ZongJiBian_Max_Time));
//
//	memcpy(Jmemory->UA_Hanyoulv_Max,Jmemory->Min_15_XieBo_Value.UA_Hanyoulv_Max,sizeof(Jmemory->UA_Hanyoulv_Max));
//	memcpy(Jmemory->UB_Hanyoulv_Max,Jmemory->Min_15_XieBo_Value.UB_Hanyoulv_Max,sizeof(Jmemory->UB_Hanyoulv_Max));
//	memcpy(Jmemory->UC_Hanyoulv_Max,Jmemory->Min_15_XieBo_Value.UC_Hanyoulv_Max,sizeof(Jmemory->UC_Hanyoulv_Max));
//	memcpy(Jmemory->UA_Hanyoulv_Max_Time,Jmemory->Min_15_XieBo_Value.UA_Hanyoulv_Max_Time,sizeof(Jmemory->UA_Hanyoulv_Max_Time));
//	memcpy(Jmemory->UB_Hanyoulv_Max_Time,Jmemory->Min_15_XieBo_Value.UB_Hanyoulv_Max_Time,sizeof(Jmemory->UB_Hanyoulv_Max_Time));
//	memcpy(Jmemory->UC_Hanyoulv_Max_Time,Jmemory->Min_15_XieBo_Value.UC_Hanyoulv_Max_Time,sizeof(Jmemory->UC_Hanyoulv_Max_Time));
//
//	Jmemory->UA_ZongJiBianLv_Max=Jmemory->Min_15_XieBo_Value.UA_ZongJiBianLv_Max;
//	Jmemory->UB_ZongJiBianLv_Max=Jmemory->Min_15_XieBo_Value.UB_ZongJiBianLv_Max;
//	Jmemory->UC_ZongJiBianLv_Max=Jmemory->Min_15_XieBo_Value.UC_ZongJiBianLv_Max;
//	memcpy(&Jmemory->UA_ZongJiBianLv_Max_Time.BCD01,&Jmemory->Min_15_XieBo_Value.UA_ZongJiBianLv_Max_Time.BCD01,sizeof(Jmemory->UA_ZongJiBianLv_Max_Time));
//	memcpy(&Jmemory->UB_ZongJiBianLv_Max_Time.BCD01,&Jmemory->Min_15_XieBo_Value.UB_ZongJiBianLv_Max_Time.BCD01,sizeof(Jmemory->UB_ZongJiBianLv_Max_Time));
//	memcpy(&Jmemory->UC_ZongJiBianLv_Max_Time.BCD01,&Jmemory->Min_15_XieBo_Value.UC_ZongJiBianLv_Max_Time.BCD01,sizeof(Jmemory->UC_ZongJiBianLv_Max_Time));
//
//	Jmemory->F121_real_Value.ZongJiBian_UCount=Jmemory->Min_15_XieBo_Value.U_ZongJiBian_UCount;
//	Jmemory->F121_real_Value.ZongJiBian_ICount=Jmemory->Min_15_XieBo_Value.U_ZongJiBian_ICount;
//	Jmemory->F122_real_Value.ZongJiBian_UCount=Jmemory->Min_15_XieBo_Value.V_ZongJiBian_UCount;
//	Jmemory->F122_real_Value.ZongJiBian_ICount=Jmemory->Min_15_XieBo_Value.V_ZongJiBian_ICount;
//	Jmemory->F123_real_Value.ZongJiBian_UCount=Jmemory->Min_15_XieBo_Value.W_ZongJiBian_UCount;
//	Jmemory->F123_real_Value.ZongJiBian_ICount=Jmemory->Min_15_XieBo_Value.W_ZongJiBian_ICount;
//	memcpy(Jmemory->F121_real_Value.GeCi_UCount,Jmemory->Min_15_XieBo_Value.U_GeCi_UCount,sizeof(Jmemory->F121_real_Value.GeCi_UCount));
//	memcpy(Jmemory->F121_real_Value.GeCi_ICount,Jmemory->Min_15_XieBo_Value.U_GeCi_ICount,sizeof(Jmemory->F121_real_Value.GeCi_ICount));
//	memcpy(Jmemory->F122_real_Value.GeCi_UCount,Jmemory->Min_15_XieBo_Value.V_GeCi_UCount,sizeof(Jmemory->F122_real_Value.GeCi_UCount));
//	memcpy(Jmemory->F122_real_Value.GeCi_ICount,Jmemory->Min_15_XieBo_Value.V_GeCi_ICount,sizeof(Jmemory->F122_real_Value.GeCi_ICount));
//	memcpy(Jmemory->F123_real_Value.GeCi_UCount,Jmemory->Min_15_XieBo_Value.W_GeCi_UCount,sizeof(Jmemory->F123_real_Value.GeCi_UCount));
//	memcpy(Jmemory->F123_real_Value.GeCi_ICount,Jmemory->Min_15_XieBo_Value.W_GeCi_ICount,sizeof(Jmemory->F123_real_Value.GeCi_ICount));
//
//}
//void Read_Min15_Xiebo()
//{
//	char name[128];
//	TS ts;
//	TSGet(&ts);
//	sprintf(name,"/nand/save/xb%02d%02d.dat",ts.Month,ts.Day);
//	if(ReadFile(name,&Jmemory->Min_15_XieBo_Value.Valid,sizeof(Jmemory->Min_15_XieBo_Value)))
//	{
//		memset(&Jmemory->Min_15_XieBo_Value,0,sizeof(Jmemory->Min_15_XieBo_Value));
//	}
//	cpyMinDataToRtu();
//}
//void Init_XieBo()
//{
//	Jmemory->IA_ZongJiBian_Max=0;
//	Jmemory->IB_ZongJiBian_Max=0;
//	Jmemory->IC_ZongJiBian_Max=0;
//
//	Jmemory->UA_ZongJiBianLv_Max=0;
//	Jmemory->UB_ZongJiBianLv_Max=0;
//	Jmemory->UC_ZongJiBianLv_Max=0;
//
//	memset(Jmemory->IAxb_Max,0,sizeof(Jmemory->IAxb_Max));
//	memset(Jmemory->IBxb_Max,0,sizeof(Jmemory->IBxb_Max));
//	memset(Jmemory->ICxb_Max,0,sizeof(Jmemory->ICxb_Max));
//	memset(Jmemory->IAxb_Max_Time,0,sizeof(Jmemory->IAxb_Max_Time));
//	memset(Jmemory->IBxb_Max_Time,0,sizeof(Jmemory->IBxb_Max_Time));
//	memset(Jmemory->ICxb_Max_Time,0,sizeof(Jmemory->ICxb_Max_Time));
//
//	memset(Jmemory->UA_Hanyoulv_Max,0,sizeof(Jmemory->UA_Hanyoulv_Max));
//	memset(Jmemory->UB_Hanyoulv_Max,0,sizeof(Jmemory->UB_Hanyoulv_Max));
//	memset(Jmemory->UC_Hanyoulv_Max,0,sizeof(Jmemory->UC_Hanyoulv_Max));
//	memset(Jmemory->UA_Hanyoulv_Max_Time,0,sizeof(Jmemory->UA_Hanyoulv_Max_Time));
//	memset(Jmemory->UB_Hanyoulv_Max_Time,0,sizeof(Jmemory->UB_Hanyoulv_Max_Time));
//	memset(Jmemory->UC_Hanyoulv_Max_Time,0,sizeof(Jmemory->UC_Hanyoulv_Max_Time));
//
//	memset(&Jmemory->IA_ZongJiBian_Max_Time,0,sizeof(Jmemory->IA_ZongJiBian_Max_Time));
//	memset(&Jmemory->IB_ZongJiBian_Max_Time,0,sizeof(Jmemory->IB_ZongJiBian_Max_Time));
//	memset(&Jmemory->IC_ZongJiBian_Max_Time,0,sizeof(Jmemory->IC_ZongJiBian_Max_Time));
//
//	memset(&Jmemory->UA_ZongJiBianLv_Max_Time,0,sizeof(Jmemory->UA_ZongJiBianLv_Max_Time));
//	memset(&Jmemory->UB_ZongJiBianLv_Max_Time,0,sizeof(Jmemory->UB_ZongJiBianLv_Max_Time));
//	memset(&Jmemory->UC_ZongJiBianLv_Max_Time,0,sizeof(Jmemory->UC_ZongJiBianLv_Max_Time));
//}
void XieBoPrt(){
	int i=0;
    fprintf(stderr,"\n\rUAbase=%5.1f",JDataFileInfo->jc.xiebo.AllXBo.UAbase);
    fprintf(stderr,"\n\rUbbase=%5.1f",JDataFileInfo->jc.xiebo.AllXBo.UBbase);
    fprintf(stderr,"\n\rUcbase=%5.1f",JDataFileInfo->jc.xiebo.AllXBo.UCbase);
    fprintf(stderr,"\n\rIAbase=%5.3f",JDataFileInfo->jc.xiebo.AllXBo.IAbase);
    fprintf(stderr,"\n\rIBbase=%5.3f",JDataFileInfo->jc.xiebo.AllXBo.IBbase);
    fprintf(stderr,"\n\rICbase=%5.3f",JDataFileInfo->jc.xiebo.AllXBo.ICbase);
    fprintf(stderr,"\n\rRES_F =%d",JDataFileInfo->jc.RES.RES_F);
    for(i=0;i<20;i++){
    	ClearWaitTimes(ProjectNo,JProgramInfo);
	    fprintf(stderr,"\n\rTempUAxb[%d]=%d",i,JDataFileInfo->jc.xiebo.AllXBo.TempUAxb[i]);
	    fprintf(stderr,"\n\rTempUBxb[%d]=%d",i,JDataFileInfo->jc.xiebo.AllXBo.TempUBxb[i]);
	    fprintf(stderr,"\n\rTempUCxb[%d]=%d",i,JDataFileInfo->jc.xiebo.AllXBo.TempUCxb[i]);
	    fprintf(stderr,"\n\rTempIAxb[%d]=%d",i,JDataFileInfo->jc.xiebo.AllXBo.TempIAxb[i]);
	    fprintf(stderr,"\n\rTempIBxb[%d]=%d",i,JDataFileInfo->jc.xiebo.AllXBo.TempIBxb[i]);
	    fprintf(stderr,"\n\rTempICxb[%d]=%d",i,JDataFileInfo->jc.xiebo.AllXBo.TempICxb[i]);
	    fprintf(stderr,"\n\r");
    }
    fprintf(stderr,"\n\r-----------------U xiebo start");
    for(i=0;i<20;i++){
    	ClearWaitTimes(ProjectNo,JProgramInfo);
	    fprintf(stderr,"\n\rRtuDataAddr->AllXBo.UAxb[%d]=%5.2f",i,JDataFileInfo->jc.xiebo.AllXBo.UAxb[i]);
	    fprintf(stderr,"\n\rRtuDataAddr->AllXBo.UBxb[%d]=%5.2f",i,JDataFileInfo->jc.xiebo.AllXBo.UBxb[i]);
	    fprintf(stderr,"\n\rRtuDataAddr->AllXBo.UCxb[%d]=%5.2f",i,JDataFileInfo->jc.xiebo.AllXBo.UCxb[i]);
	    fprintf(stderr,"\n\r");
    }
    fprintf(stderr,"\n\r-----------------U xiebo end");
    fprintf(stderr,"\n\r~~~~~~~~I xiebo start");
    for(i=0;i<20;i++){
    	ClearWaitTimes(ProjectNo,JProgramInfo);
	    fprintf(stderr,"\n\rRtuDataAddr->AllXBo.IAxb[%d]=%5.2f",i,JDataFileInfo->jc.xiebo.AllXBo.IAxb[i]);
	    fprintf(stderr,"\n\rRtuDataAddr->AllXBo.IBxb[%d]=%5.2f",i,JDataFileInfo->jc.xiebo.AllXBo.IBxb[i]);
	    fprintf(stderr,"\n\rRtuDataAddr->AllXBo.ICxb[%d]=%5.2f",i,JDataFileInfo->jc.xiebo.AllXBo.ICxb[i]);
	    fprintf(stderr,"\n\r");
    }
    fprintf(stderr,"\n\r~~~~~~~~I xiebo end");
}
void IniXiShu_Mem()
{
	memset(JConfigInfo->jcxs.displayA_jiaoxiu,0,3);
	memset(JConfigInfo->jcxs.displayB_jiaoxiu,0,3);
	memset(JConfigInfo->jcxs.displayC_jiaoxiu,0,3);
	memset(JConfigInfo->jcxs.displayUA_xishu,0,3);
	memset(JConfigInfo->jcxs.displayUB_xishu,0,3);
	memset(JConfigInfo->jcxs.displayUC_xishu,0,3);
	memset(JConfigInfo->jcxs.displayIA_xishu,0,3);
	memset(JConfigInfo->jcxs.displayIB_xishu,0,3);
	memset(JConfigInfo->jcxs.displayIC_xishu,0,3);
	memset(JConfigInfo->jcxs.displayI0_xishu,0,3);
	memset(JConfigInfo->jcxs.displayPA_xishu,0,3);
	memset(JConfigInfo->jcxs.displayPB_xishu,0,3);
	memset(JConfigInfo->jcxs.displayPC_xishu,0,3);
	memset(JConfigInfo->jcxs.displayMC_out_xishu,0,3);
	savefun();
}
void PrtReg()
{
	int i;
	INT8U temp[3];
	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0;
	ATTWrite(SPI1, 0xc6, 3, temp, 0);
	fprintf(stderr,"\n\r���ݼĴ���");
	for (i = 0; i < 0x3f; i++) {
		JConfigInfo->jcxs.REC[i] = ATTRead(SPI1, i, 3, temp, 0);
		fprintf(stderr,"\n\r-REC[%x] = %x",i,JConfigInfo->jcxs.REC[i]);
	}
	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0;
	ATTWrite(SPI1, 0xc6, 3, temp, 0);

	FP32 ATT_PA,ATT_PB,ATT_PC,IAUAJ,IBUBJ,ICUCJ,UAUB,UAUC,UBUC;
	IAUAJ = ATTRead(SPI1, 0x18, 3, temp, 0);
	IBUBJ = ATTRead(SPI1, 0x19, 3, temp, 0);
	ICUCJ = ATTRead(SPI1, 0x1A, 3, temp, 0);
	UAUB  = ATTRead(SPI1, 0x26, 3, temp, 0);
	UAUC  = ATTRead(SPI1, 0x27, 3, temp, 0);
	UBUC  = ATTRead(SPI1, 0x28, 3, temp, 0);

	if (IAUAJ >= 1048576)
		IAUAJ = IAUAJ - 16777216;
	if (IBUBJ >= 1048576)
		IBUBJ = IBUBJ - 16777216;
	if (ICUCJ >= 1048576)
		ICUCJ = ICUCJ - 16777216;

	IAUAJ = (IAUAJ*1.0/1048576)*180;
	IBUBJ = (IBUBJ*1.0/1048576)*180;
	ICUCJ = (ICUCJ*1.0/1048576)*180;

	UAUB = (UAUB*1.0/1048576)*180;
	UAUC = (UAUC*1.0/1048576)*180;
	UBUC = (UBUC*1.0/1048576)*180;

	ATT_PA = ATTRead(SPI1, 0x01, 3, temp, 0);
	ATT_PB = ATTRead(SPI1, 0x02, 3, temp, 0);
	ATT_PC = ATTRead(SPI1, 0x03, 3, temp, 0);
	fprintf(stderr,"\n\r\n\r\n\r");
	fprintf(stderr,"\n\r IAUAJ=%f IBUBJ=%f ICUCJ=%f ",IAUAJ,IBUBJ,ICUCJ);
	fprintf(stderr,"\n\r UAUB=%f UAUC=%f UBUC=%f ",UAUB,UAUC,UBUC);
	fprintf(stderr,"\n\r\n\r");
	fprintf(stderr,"\n\r PAreg=%f PBreg=%f PCreg=%f ",ATT_PA,ATT_PB,ATT_PC);
	fprintf(stderr,"\n\r UA=%d UB=%d UC=%d",JDataFileInfo->jc.RES.RES_UA,JDataFileInfo->jc.RES.RES_UB,JDataFileInfo->jc.RES.RES_UC);
	fprintf(stderr,"\n\r IA=%d IB=%d IC=%d",JDataFileInfo->jc.RES.RES_IA,JDataFileInfo->jc.RES.RES_IB,JDataFileInfo->jc.RES.RES_IC);
	fprintf(stderr,"\n\r PA=%d PB=%d PC=%d",JDataFileInfo->jc.RES.RES_PA,JDataFileInfo->jc.RES.RES_PB,JDataFileInfo->jc.RES.RES_PC);
	fprintf(stderr,"\n\r QA=%d QB=%d QC=%d",JDataFileInfo->jc.RES.RES_QA,JDataFileInfo->jc.RES.RES_QB,JDataFileInfo->jc.RES.RES_QC);

	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0x5a;
	ATTWrite(SPI1, 0xc6, 3, temp, 0);
	fprintf(stderr,"\n\rУ���Ĵ���");
	for (i = 0; i < 0x3f; i++) {
		JConfigInfo->jcxs.REC[i] = ATTRead(SPI1, i, 3, temp, 0);
		fprintf(stderr,"\n\r-REC[%x] = %x",i,JConfigInfo->jcxs.REC[i]);
	}
	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0;
	ATTWrite(SPI1, 0xc6, 3, temp, 0);
}
void  JiaobiaoPro_CC()
{
	unsigned char TempBuf[100];
	int i;
	unsigned char temp[10];
	if (JDataFileInfo->jc.JcXiu == 8) {//SPI ����У���Ĵ�������
		JDataFileInfo->jc.JcXiu = 0;
		readrec();
	}
	if (JDataFileInfo->jc.JcXiu == 6) {//I2C����
		JDataFileInfo->jc.JcXiu = 0;
		savetest();
	}
	if (JDataFileInfo->jc.JcXiu == 7) {//У���������
		JDataFileInfo->jc.JcXiu = 0;
		mcjiaozheng();
	}
	if (JDataFileInfo->jc.JcXiu == 1) {//mpp
		printf("\nTT7022CC MPP");
		if (access("/nand/DataCurr/0001/curr.dat",0)==0)
		{
			memset(TempBuf,0,60);
			sprintf((char*)TempBuf,"%s /nand/DataCurr/0001/*.dat",_CMDRM_);
			syscmd((char*)TempBuf,JProgramInfo);
		}
		JDataFileInfo->jc.JcXiu = 0;
		savetest();
		modify_uipp();
	}
	if (JDataFileInfo->jc.JcXiu == 2) {//mpa
		printf("\nTT7022CC MPA");
		JDataFileInfo->jc.JcXiu = 0;
		jiaoxiu_pa();
	}
	if (JDataFileInfo->jc.JcXiu == 3) {//mpb
		printf("\nTT7022CC MPb");
		JDataFileInfo->jc.JcXiu = 0;
		jiaoxiu_pb();
	}
	if (JDataFileInfo->jc.JcXiu == 4) {//mpc
		printf("\nTT7022CC MPc");
		JDataFileInfo->jc.JcXiu = 0;
		jiaoxiu_pc();
	}

	if (JDataFileInfo->jc.JcXiu == 9) {//qing
		printf("\nTT7022CC QING");
		if (access("/nand/DataCurr/0001/curr.dat",0)==0)
		{
			memset(TempBuf,0,60);
			sprintf((char*)TempBuf,"%s /nand/DataCurr/0001/*.dat",_CMDRM_);
			syscmd((char*)TempBuf,JProgramInfo);
		}
		memset(&JDataFileInfo->jc.JcDdRealData,0,sizeof(JDataFileInfo->jc.JcDdRealData));
		JDataFileInfo->jc.JcXiu = 0;
		qingabc_cc();
	}
	if (JDataFileInfo->jc.JcXiu == 11)
	{
		printf("\n Read У���Ĵ�����");
		temp[0] = 0x00;
		temp[1] = 0x00;
		temp[2] = 0x5A;
		ATTWrite(SPI1, 0xC6, 3, temp, 0);//ѡ���ȡУ���Ĵ�������
		for (i = 0; i < 0x35; i++)
		{
			JConfigInfo->jcxs.REC[i] = ATTRead(SPI1, i, 3, temp, 0);
			printf("\n  REC[%x] = %x",i,JConfigInfo->jcxs.REC[i]);
		}
		printf("\n\r");

		temp[0] = 0x00;
		temp[1] = 0x00;
		temp[2] = 0x00;
		ATTWrite(SPI1, 0xC6, 3, temp, 0);
		printf("\n Read ���ݼĴ���״̬\n");

		printf("\n Read ���ݼĴ�����");
		for (i = 0; i < 0x35; i++)
		{
			JConfigInfo->jcxs.REC[i] = ATTRead(SPI1, i, 3, temp, 0);
			printf("\n  REC[%x] = %x",i,JConfigInfo->jcxs.REC[i]);
		}
		printf("\n\r");

		printf("RES UA=%u,UB=%u,UC=%u\n\r",JDataFileInfo->jc.RES.RES_UA,JDataFileInfo->jc.RES.RES_UB,JDataFileInfo->jc.RES.RES_UC);
		printf("RES IA=%u,IB=%u,IC=%u,I0=%u\n\r",JDataFileInfo->jc.RES.RES_IA,JDataFileInfo->jc.RES.RES_IB,JDataFileInfo->jc.RES.RES_IC,JDataFileInfo->jc.RES.RES_I0);
		printf("RES PA=%d,PB=%d,PC=%d,PZ=%d\n\r",JDataFileInfo->jc.RES.RES_PA,JDataFileInfo->jc.RES.RES_PB,JDataFileInfo->jc.RES.RES_PC,JDataFileInfo->jc.RES.RES_PZ);
		printf("RES QA=%d,QB=%d,QC=%d,QZ=%d\n\r",JDataFileInfo->jc.RES.RES_QA,JDataFileInfo->jc.RES.RES_QB,JDataFileInfo->jc.RES.RES_QC,JDataFileInfo->jc.RES.RES_QZ);
		printf("RES SA=%d,SB=%d,SC=%d,SZ=%d\n\r",JDataFileInfo->jc.RES.RES_SA,JDataFileInfo->jc.RES.RES_SB,JDataFileInfo->jc.RES.RES_SC,JDataFileInfo->jc.RES.RES_SZ);
		printf("RES PFA=%d,PFB=%d,PFC=%d,PFZ=%d\n\r",JDataFileInfo->jc.RES.RES_PFA,JDataFileInfo->jc.RES.RES_PFB,JDataFileInfo->jc.RES.RES_PFC,JDataFileInfo->jc.RES.RES_PFZ);
		printf("\nYUaIa=%f,YUbIb=%f,YUcIc=%f",YUaIa,YUbIb,YUcIc);
		printf("\nYUaUb=%f,YUaUc=%f,YUbUc=%f",YUaUb,YUaUc,YUbUc);
		printf("\nRES RES_JXFS=%d,RES_F=%d,RES_FLAG=%d",JDataFileInfo->jc.RES.RES_JXFS,JDataFileInfo->jc.RES.RES_F,JDataFileInfo->jc.RES.RES_FLAG);
		printf("\n\r");
		JDataFileInfo->jc.JcXiu = 0;
	}
	if (JDataFileInfo->jc.JcXiu == 20) //jiao4ma   //songjian
	{
		jiao4mA();
		JDataFileInfo->jc.JcXiu = 0;
	}
	if (JDataFileInfo->jc.JcXiu == 21) //jiao20ma   //songjian
	{
		jiao20mA();
		JDataFileInfo->jc.JcXiu = 0;
	}
	return;
}
void  JiaobiaoPro_EE()
{
	INT8U temp[3];
	int i;
	memset(temp, 0, 3);
	if (JDataFileInfo->jc.JcXiu == 9) {//��ϱ��Ĵ���
		qingabc();
		JDataFileInfo->jc.JcXiu = 0;
	}
	if (JDataFileInfo->jc.JcXiu == 2) {//����У��A���й����޹�����ѹ������

		SinglePQUIA();
		JDataFileInfo->jc.JcXiu = 0;
	}
	if (JDataFileInfo->jc.JcXiu == 3) {//����У��B���й����޹�����ѹ������

		SinglePQUIB();
		JDataFileInfo->jc.JcXiu = 0;
	}
	if (JDataFileInfo->jc.JcXiu == 4) {//����У��C���й����޹�����ѹ������

		SinglePQUIC();
		JDataFileInfo->jc.JcXiu = 0;
	}
	if (JDataFileInfo->jc.JcXiu == 7) {//У���������

		JDataFileInfo->jc.JcXiu = 0;
	}
	if (JDataFileInfo->jc.JcXiu == 11)
	{
		fprintf(stderr,"\n Read У���Ĵ�����");
		temp[0] = 0x00;
		temp[1] = 0x00;
		temp[2] = 0x5A;
		ATTWrite(SPI1, 0xC6, 3, temp, 0);//ѡ���ȡУ���Ĵ�������
		for (i = 0; i < 0x35; i++)
		{
			JConfigInfo->jcxs.REC[i] = ATTRead(SPI1, i, 3, temp, 0);
			fprintf(stderr,"\n  REC[%x] = %x",i,JConfigInfo->jcxs.REC[i]);
		}
		fprintf(stderr,"\n\r");

		temp[0] = 0x00;
		temp[1] = 0x00;
		temp[2] = 0x00;
		ATTWrite(SPI1, 0xC6, 3, temp, 0);
		fprintf(stderr,"\n Read ���ݼĴ���״̬\n");

		fprintf(stderr,"\n Read ���ݼĴ�����");
		for (i = 0; i < 0x35; i++)
		{
			JConfigInfo->jcxs.REC[i] = ATTRead(SPI1, i, 3, temp, 0);
			fprintf(stderr,"\n  REC[%x] = %x 	[%d]",i,JConfigInfo->jcxs.REC[i],JConfigInfo->jcxs.REC[i]);
		}
		fprintf(stderr,"\n\r");

		fprintf(stderr,"RES UA=%u,UB=%u,UC=%u\n\r",JDataFileInfo->jc.RES.RES_UA,JDataFileInfo->jc.RES.RES_UB,JDataFileInfo->jc.RES.RES_UC);
		fprintf(stderr,"RES IA=%u,IB=%u,IC=%u,I0=%u\n\r",JDataFileInfo->jc.RES.RES_IA,JDataFileInfo->jc.RES.RES_IB,JDataFileInfo->jc.RES.RES_IC,JDataFileInfo->jc.RES.RES_I0);
		fprintf(stderr,"RES PA=%d,PB=%d,PC=%d,PZ=%d\n\r",JDataFileInfo->jc.RES.RES_PA,JDataFileInfo->jc.RES.RES_PB,JDataFileInfo->jc.RES.RES_PC,JDataFileInfo->jc.RES.RES_PZ);
		fprintf(stderr,"RES QA=%d,QB=%d,QC=%d,QZ=%d\n\r",JDataFileInfo->jc.RES.RES_QA,JDataFileInfo->jc.RES.RES_QB,JDataFileInfo->jc.RES.RES_QC,JDataFileInfo->jc.RES.RES_QZ);
		fprintf(stderr,"RES SA=%d,SB=%d,SC=%d,SZ=%d\n\r",JDataFileInfo->jc.RES.RES_SA,JDataFileInfo->jc.RES.RES_SB,JDataFileInfo->jc.RES.RES_SC,JDataFileInfo->jc.RES.RES_SZ);
		fprintf(stderr,"RES PFA=%d,PFB=%d,PFC=%d,PFZ=%d\n\r",JDataFileInfo->jc.RES.RES_PFA,JDataFileInfo->jc.RES.RES_PFB,JDataFileInfo->jc.RES.RES_PFC,JDataFileInfo->jc.RES.RES_PFZ);
		fprintf(stderr,"\nRES RES_JXFS=%d,RES_F=%d,RES_FLAG=%d",JDataFileInfo->jc.RES.RES_JXFS,JDataFileInfo->jc.RES.RES_F,JDataFileInfo->jc.RES.RES_FLAG);
		fprintf(stderr,"\n\r");
		JDataFileInfo->jc.JcXiu = 0;
	}
}

name_attach_t  *attach;
//����ע��,��ȡ����źͳ�������
INT8U GetProjects(INT32S argc, char * argv[]) {
	char proc_name[32] = "";

	if (argc < 2)
		return (FALSE);
	ProjectNo = atoi(argv[1]);
	sprintf(proc_name, "%s", argv[0]);
	return (TRUE);
}
void QuitProcess(int signo)
{
	delay(200);
	fprintf(stderr,"\n\r jACSampling quit xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n\r");
	JProgramInfo->Projects[ProjectNo].ProjectID=0;
	exit(0);
}
//lcy
void CpToXuLiangValue(){
//	int tmp;
	JDataFileInfo->jc.JcXuLiangCalc.Z_P_Value[JDataFileInfo->jc.JcXuLiangCalc.Offset]=JDataFileInfo->jc.JcDdRealData.Z_P_All;
	JDataFileInfo->jc.JcXuLiangCalc.F_P_Value[JDataFileInfo->jc.JcXuLiangCalc.Offset]=JDataFileInfo->jc.JcDdRealData.F_P_All;
	JDataFileInfo->jc.JcXuLiangCalc.Z_Q_Value[JDataFileInfo->jc.JcXuLiangCalc.Offset]=JDataFileInfo->jc.JcDdRealData.Z_Q_All;
	JDataFileInfo->jc.JcXuLiangCalc.F_Q_Value[JDataFileInfo->jc.JcXuLiangCalc.Offset]=JDataFileInfo->jc.JcDdRealData.F_Q_All;
	//for (tmp = 0; tmp < FeiLvNum; tmp++){
	JDataFileInfo->jc.JcXuLiangCalc.Z_P_FL_Value[JDataFileInfo->jc.NowFeiLvNo][JDataFileInfo->jc.JcXuLiangCalc.Offset]=JDataFileInfo->jc.JcDdRealData.Z_P_F[JDataFileInfo->jc.NowFeiLvNo];
	JDataFileInfo->jc.JcXuLiangCalc.F_P_FL_Value[JDataFileInfo->jc.NowFeiLvNo][JDataFileInfo->jc.JcXuLiangCalc.Offset]=JDataFileInfo->jc.JcDdRealData.F_P_F[JDataFileInfo->jc.NowFeiLvNo];
	JDataFileInfo->jc.JcXuLiangCalc.Z_Q_FL_Value[JDataFileInfo->jc.NowFeiLvNo][JDataFileInfo->jc.JcXuLiangCalc.Offset]=JDataFileInfo->jc.JcDdRealData.Z_Q_F[JDataFileInfo->jc.NowFeiLvNo];
	JDataFileInfo->jc.JcXuLiangCalc.F_Q_FL_Value[JDataFileInfo->jc.NowFeiLvNo][JDataFileInfo->jc.JcXuLiangCalc.Offset]=JDataFileInfo->jc.JcDdRealData.F_Q_F[JDataFileInfo->jc.NowFeiLvNo];

	JDataFileInfo->jc.JcXuLiangCalc.X1_Q_FL_Value[JDataFileInfo->jc.NowFeiLvNo][JDataFileInfo->jc.JcXuLiangCalc.Offset]=JDataFileInfo->jc.JcDdRealData.X1_F_Q[JDataFileInfo->jc.NowFeiLvNo];
	JDataFileInfo->jc.JcXuLiangCalc.X2_Q_FL_Value[JDataFileInfo->jc.NowFeiLvNo][JDataFileInfo->jc.JcXuLiangCalc.Offset]=JDataFileInfo->jc.JcDdRealData.X2_F_Q[JDataFileInfo->jc.NowFeiLvNo];
	JDataFileInfo->jc.JcXuLiangCalc.X3_Q_FL_Value[JDataFileInfo->jc.NowFeiLvNo][JDataFileInfo->jc.JcXuLiangCalc.Offset]=JDataFileInfo->jc.JcDdRealData.X3_F_Q[JDataFileInfo->jc.NowFeiLvNo];
	JDataFileInfo->jc.JcXuLiangCalc.X4_Q_FL_Value[JDataFileInfo->jc.NowFeiLvNo][JDataFileInfo->jc.JcXuLiangCalc.Offset]=JDataFileInfo->jc.JcDdRealData.X4_F_Q[JDataFileInfo->jc.NowFeiLvNo];
	//}
	FeiLvCalc();//��������ֵ��ͳ���������ֵ������ʱ��
	JDataFileInfo->jc.JcXuLiangCalc.Offset=(JDataFileInfo->jc.JcXuLiangCalc.Offset+1)%(JDataFileInfo->JcPara_645.XuLiangZhouQi+1);
	FeiLvMin++;
}
void CalcUshizhendu()
{
	INT32U UA,UB,UC;
	INT32U UAJ,UBJ,UCJ;

	UA = JDataFileInfo->jc.JcDdRealData.VA;
	UB = JDataFileInfo->jc.JcDdRealData.VB;
	UC = JDataFileInfo->jc.JcDdRealData.VC;
	UAJ = JDataFileInfo->jc.JcDdRealData.VA_JB;
	UBJ = JDataFileInfo->jc.JcDdRealData.VB_JB;
	UCJ = JDataFileInfo->jc.JcDdRealData.VC_JB;

	if (UAJ>0)
	{
		JDataFileInfo->jc.JcDdRealData.VASZD = (abs(sqrt(UA*UA*100 - UAJ*UAJ*100))*1000 / UAJ);
	}
	if (UBJ>0)
	{
		JDataFileInfo->jc.JcDdRealData.VBSZD = (abs(sqrt(UB*UB*100 - UBJ*UBJ*100))*1000 / UBJ);
	}
	if (UCJ>0)
	{
		JDataFileInfo->jc.JcDdRealData.VCSZD = (abs(sqrt(UC*UC*100 - UCJ*UCJ*100))*1000 / UCJ);
	}
//	fprintf(stderr,"\n UA= %d UB=%d  UC=%d  UAJ=%d  UBJ=%d  UCJ=%d ",UA,UB,UC,UAJ,UBJ,UCJ);
//	fprintf(stderr,"\n UA_SZD= %d UB_SZD=%d  UC_SZD=%d\n\n",UA_SZD,UB_SZD,UC_SZD);
}
int main(int argc, char *argv[]) {

	struct sigaction sa1;
	INT8U Sec,Now_Min,Now_day,Now_mon,Now_hour,DongJi_Min,xieboMinute;//lcy
	INT8U lunf=0;
	TS ts;
	//lcy2013
	unsigned int VA_SUM=0;
	unsigned int VB_SUM=0;
	unsigned int VC_SUM=0;
	unsigned char Count=0;
	//lcy2013
	markver();
   if (getenv("jACSpPrt")==NULL)
   {
    	jACSpPrint = 0;
 		if (getenv("jAllProgPrt")!=NULL)
 			jACSpPrint = atoi(getenv("jAllProgPrt"));
   }
   else jACSpPrint = atoi(getenv("jACSpPrt"));
   if (jACSpPrint==2)
   {
		INT8U TempBuf[60];
		memset(TempBuf, 0, 60);
		sprintf((char *) TempBuf, "%s/jACSamping_log.txt", _USERDIR_);
	    filep=fopen((char *) TempBuf,"a+");
   }

	JParamInfo3761 = Open1ShMem("ParamInfo3761",sizeof(ParamInfo3761),NULL);
	JDataFileInfo = Open1ShMem("DataFileInfo",sizeof(DataFileInfo),NULL);
	JConfigInfo = Open1ShMem("ConfigInfo",sizeof(ConfigInfo),NULL);
	JProgramInfo = Open1ShMem("ProgramInfo",sizeof(ProgramInfo),NULL);

	if(JProgramInfo->mainData.MemoryLength!=sizeof(ProgramInfo))
	{
		fprintf(stderr,"\nShare mem uncompared!\n");
		return EXIT_FAILURE;
	}
   if(!GetProjects(argc, argv))
	{
		fprintf(stderr,"\n jiaocai  Bad command format. Type 'use exe_name' for help!\n\r");
		return EXIT_FAILURE;
	}
	sa1.sa_handler = QuitProcess;
	sigemptyset(&sa1.sa_mask);
	sa1.sa_flags = 0;
	sigaction(SIGTERM, &sa1, NULL);
	sigaction(SIGSYS, &sa1, NULL);
	sigaction(SIGPWR, &sa1, NULL);
	sigaction(SIGKILL, &sa1, NULL);
	sigaction(SIGQUIT, &sa1, NULL);
	sigaction(SIGILL, &sa1, NULL);
	sigaction(SIGINT, &sa1, NULL);
	sigaction(SIGHUP, &sa1, NULL);
	sigaction(SIGABRT, &sa1, NULL);
	sigaction(SIGBUS, &sa1, NULL);

	JProgramInfo->Projects[ProjectNo].ProjectID=getpid();//����������Ϣ
	fprintf(stderr,"Starting jACSampling ..........%d\n",ProjectNo);
	ClearWaitTimes(ProjectNo,JProgramInfo);

	DeviceFlag = ATTUNKNOWN;
	Read_Fk_xiu_I2C(1);		// �� I2C ��ȡϵ��
	JugeAtt7022();      	// �жϼ���оƬ����

	if (DeviceFlag == ATTUNKNOWN)
	{
		fprintf(stderr,"\n����оƬ����");
		return 0;
	}
	if (DeviceFlag == ATT7022EE)
	{
		ATTInit_EE(); 		// ATT7022��ʼ��  ��SPI
		att_spi_init_EE(); 	// ����ȡ��ϵ��д��SPI0���� (�������� оƬ ATT7022)
		DbgPrintToFile("����ģ�飺7022E");
	}
	if (DeviceFlag == ATT7022CC)
	{
		ATTInit_CC(); 		// ATT7022��ʼ��  ��SPI
		ReadWenduXishu();	//songjian
		att_spi_init_CC(); 	// ����ȡ��ϵ��д��SPI0���� (�������� оƬ ATT7022)
		DbgPrintToFile("����ģ�飺7022C");
	}
	initdl();
	FeiLvMin=0;
	HuaChaTime=0;
	Z_P_RealXL=0;
	F_P_RealXL=0;
	Z_Q_RealXL=0;
	F_Q_RealXL=0;
	memset(JieSuanRiData,0,12);
	memset(Z_P_FL_RealXL,0,4);
	memset(F_P_FL_RealXL,0,4);
	memset(Z_Q_FL_RealXL,0,4);
	memset(F_Q_FL_RealXL,0,4);
	memset(Q_X_1,0,4);
	memset(Q_X_2,0,4);
	memset(Q_X_3,0,4);
	memset(Q_X_4,0,4);
	TSGet(&ts);
	DongJi_Min=ts.Minute;//lcy
	Sec = ts.Sec;
	Now_Min=ts.Minute;
	xieboMinute=ts.Minute;
	Now_day=ts.Day;
	Now_mon=ts.Month;
	Now_hour=ts.Hour;
	JDataFileInfo->jc.Setting = 0;
	SetRtcInt(0x03); //����������
	for (;;)
	{
		if(JProgramInfo->stateflags.XuLiangQingFlag==1){
			XuLiangRst();
			JProgramInfo->stateflags.XuLiangQingFlag = 0;
		}
		if (jACSpPrint == 0)
		{
		   if ((JProgramInfo->mainData.Prt_Flag==15) || (JProgramInfo->mainData.Prt_Flag==50))
			   jACSpPrint = 3;
		}
		else
		{
		   if ((JProgramInfo->mainData.Prt_Flag==115) || (JProgramInfo->mainData.Prt_Flag==150))
			   jACSpPrint = 0;
		}
		delay(800);//�Ϻ����������뱣֤ÿ��ɼ�һ����//lcy2013
		ClearWaitTimes(ProjectNo,JProgramInfo);

		if (DeviceFlag == ATT7022EE)
			spi_test_ATT7022EE();			//��ȡATT7022EE�Ĵ�����������
		if (DeviceFlag == ATT7022CC)
			spi_test_ATT7022CC();			//��ȡATT7022CC�Ĵ�����������

		SetYCData();						//��ATT7022�������ݷ��õ������ڴ�
		if (JDataFileInfo->jc.Setting ==0)		//�������У��״̬����Ҫ���ATT7022����У��Ĵ�������
		{
			if (CkSum != CkSunOld)
			{
				fprintf(stderr, "\nCkSum %x CkSunOld %x\n", CkSum, CkSunOld);
				if (DeviceFlag == ATT7022EE)
					att_spi_init_EE();
				if (DeviceFlag == ATT7022CC)
					att_spi_init_CC();
				savefun();
				CkSunOld = CkSum;
				delay(50);
				fprintf(stderr,"\n\r[ setoff  end ]\n");
				system("cp /nand/para/JcXiu.par /nor/para/JcXiu.par");
			}
		}
		TSGet(&ts);
		if (ts.Sec != Sec)
		{
			Sec = ts.Sec;
			if (DeviceFlag == ATT7022EE)//ÿ�����ж��Ƿ�У��
				JiaobiaoPro_EE();		//У���ж�
			if (DeviceFlag == ATT7022CC)
				JiaobiaoPro_CC();		//У���ж�
			delay(50);

			if (ts.Minute!=Now_Min)
			{
				ClearWaitTimes(ProjectNo,JProgramInfo);
				Now_Min=ts.Minute;
				DongJi_Min=ts.Minute;
				xieboMinute=ts.Minute;
				//lcy2013
				if(ts.Minute==1){//Ϊ�˱�֤��Сʱ1���ӵ���Сʱ0��������60�����ڼ�ƽ����ѹֵ��ŵ�curr
								 //curr��ts.minute==0ʱ���Сʱ���ݣ������ӿ��Ա�֤ƽ����ѹֵ��ŵ�Сʱ�����ļ���
					Count=0;
					VA_SUM=0;
					VB_SUM=0;
					VC_SUM=0;
					JDataFileInfo->jc.JcDdRealData.VA_AVG = JDataFileInfo->jc.RES.RES_UA;
					JDataFileInfo->jc.JcDdRealData.VB_AVG = JDataFileInfo->jc.RES.RES_UB;
					JDataFileInfo->jc.JcDdRealData.VC_AVG = JDataFileInfo->jc.RES.RES_UC;

//					fprintf(stderr,"\nqing ts.Minute=%d",ts.Minute);
//					fprintf(stderr,"\nhour changed Now_hour=%d Hour=%d Count=%d",Now_hour,ts.Hour,Count);
//					fprintf(stderr,"\nhour changed VA_SUM=%u",VA_SUM);
//					fprintf(stderr,"\nhour changed VB_SUM=%u",VB_SUM);
//					fprintf(stderr,"\nhour changed VC_SUM=%u",VC_SUM);
//					fprintf(stderr,"\nhour changed VA_AVG=%u",JDataFileInfo->jc.JcDdRealData.VA_AVG);
//					fprintf(stderr,"\nhour changed VB_AVG=%u",JDataFileInfo->jc.JcDdRealData.VB_AVG);
//					fprintf(stderr,"\nhour changed VC_AVG=%u",JDataFileInfo->jc.JcDdRealData.VC_AVG);
				}
				Count++;
				VA_SUM = VA_SUM + JDataFileInfo->jc.RES.RES_UA;
				VB_SUM = VB_SUM + JDataFileInfo->jc.RES.RES_UB;
				VC_SUM = VC_SUM + JDataFileInfo->jc.RES.RES_UC;
				JDataFileInfo->jc.JcDdRealData.VA_AVG = VA_SUM / Count;
				JDataFileInfo->jc.JcDdRealData.VB_AVG = VB_SUM / Count;
				JDataFileInfo->jc.JcDdRealData.VC_AVG = VC_SUM / Count;

//				fprintf(stderr,"\nHour=%d minute=%d Count=%d",ts.Hour,ts.Minute,Count);
//				fprintf(stderr,"\nVA_SUM=%u",VA_SUM);
//				fprintf(stderr,"\nVB_SUM=%u",VB_SUM);
//				fprintf(stderr,"\nVC_SUM=%u",VC_SUM);
//				fprintf(stderr,"\n");
//				fprintf(stderr,"\nVA_AVG=%u",JDataFileInfo->jc.JcDdRealData.VA_AVG);
//				fprintf(stderr,"\nVB_AVG=%u",JDataFileInfo->jc.JcDdRealData.VB_AVG);
//				fprintf(stderr,"\nVC_AVG=%u",JDataFileInfo->jc.JcDdRealData.VC_AVG);

				if (DeviceFlag == ATT7022CC)
					calcdianliang_CC();//7022C�ɼ�������
				else{
					EnSpi(60);
					calcdianliang_EE();//7022E�ɼ�������
					ATT7022E_XIEBO();  //�ɼ�г��lcy2013
					DisEnSpi();
				}
				JDataFileInfo->jc.NowFeiLvNo = FeiLvNo(ts);
				CalcUshizhendu();	   //�����ѹ����ʧ���
				CpToXuLiangValue();	   //lcy ��ÿ���ӵ���ʵʱֵ���뵽���������Ļ�����ȥ
				DoDataChange(ts);      //�洢curr.dat����
				delay(50);

				//г������lcy2013
				xb_Time.BCD01 = ((ts.Minute / 10) << 4) + (ts.Minute % 10);
				xb_Time.BCD02 = ((ts.Hour / 10) << 4) + (ts.Hour % 10);
				xb_Time.BCD03 = ((ts.Day / 10) << 4) + (ts.Day % 10);
				xb_Time.BCD04 = ((ts.Month / 10) << 4) + (ts.Month % 10);
				FFT();                 //����FFT�任
				calxbval();            //����г���ܺ����ʼ�����г�������ʺ�г��ֵ
				XIEBO_MAX_Calc();		//����г����ѹ���������������ֵ������ʱ��
				//XieBoPrt();            //г����ӡ
			}
		}
		if (lunf==0)
		{
			lunf=1;
			JProgramInfo->LunFlg=1;
		}
	}
	return EXIT_SUCCESS;
}
