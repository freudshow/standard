#ifndef JIAOCAI_H_
#define JIAOCAI_H_
#include <math.h>
#include <inc/pubfunction.h>
#include <inc/Options.h>
#include <inc/init.h>
#include <inc/DataGroups.h>
#include <linux/types.h>
#include <linux/spi/spidev.h>
#include <linux/i2c.h>
#include <linux/i2c-dev.h>
#include <sys/ioctl.h>
#include <signal.h>
#include "rtc_.h"
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <errno.h>
#include <net/if.h>
#include <signal.h>
#include <pthread.h>
#include <netinet/tcp.h>
#include <mcheck.h>
#include <inc/pubfunction.h>
#include <inc/init.h>
#include <termios.h>
#include "j3761_2009.h"

#define SdPrint(...) if (jACSpPrint==1) fprintf(stderr,__VA_ARGS__);

//	else if (jACSpPrint==2) fprintf(fp, __VA_ARGS__);
//	else if (jACSpPrint==3) fprintf(stderr,__VA_ARGS__);

#define ATTUNKNOWN        0x00
#define ATT7022EE         0xaa
#define ATT7022CC         0x55
#define AT24ADDR (0x50)
unsigned char DeviceFlag;
float WenduK1,WenduK2,WenduXishu,AD_Ima;
float YUaUb,YUaUc,YUbUc;
float YUaIa,YUbIb,YUcIc;
extern unsigned char pagelist[7][8];
/*******************************************
*ATT�����붨��
*******************************************
*/
#define ATTCMD_WRDI					0x04
#define ATTCMD_WREN					0x06
#define SPI1   0
#define ReadCount 4
typedef unsigned long long     	INT64U;                   /* Unsigned 64 bit quantity    */
typedef signed long long  		INT64S;                   /* Unsigned 64 bit quantity    */
typedef struct
{
   INT32S Real;
   INT32S Imag;
}Lisan;
INT32S ATT_UC,ATT_IC,SUM_UC,SUM_IC;
ParamInfo3761* JParamInfo3761;
DataFileInfo*  JDataFileInfo;
ConfigInfo*    JConfigInfo;
ProgramInfo* JProgramInfo;
extern int device;
extern unsigned char cmd[1024];
Data_Type_17		xb_Time;
#define NUM_FFT  64
#define EXP_FFT  6    //(2)6=64
extern int setupTimer();
extern void QuitProcess(int signo);
#ifdef __linux__
#else
	extern name_attach_t *attach;
#endif
 INT32U 	Z_P_ALL_Temp;
 INT32U 	F_P_ALL_Temp;
 INT32U 	Q_1_ALL_Temp;
 INT32U 	Q_2_ALL_Temp;
 INT32U 	Q_3_ALL_Temp;
 INT32U 	Q_4_ALL_Temp;
 //----lcy
#define XuLCircle 5
 INT16U 	FeiLvMin;
 INT16U     HuaChaTime;
 signed int Z_P_RealXL;
 signed int F_P_RealXL;
 signed int Z_Q_RealXL;
 signed int F_Q_RealXL;
 signed int Z_P_FL_RealXL[FeiLvNum];
 signed int F_P_FL_RealXL[FeiLvNum];
 signed int Z_Q_FL_RealXL[FeiLvNum];
 signed int F_Q_FL_RealXL[FeiLvNum];
 signed int Q_X_1[FeiLvNum];
 signed int Q_X_2[FeiLvNum];
 signed int Q_X_3[FeiLvNum];
 signed int Q_X_4[FeiLvNum];
 typedef struct
 {
	 INT8U Day;
	 INT8U Hour;
 }JieSuanRi;
 JieSuanRi JieSuanRiData[12];
//��������
 //xiebo
 typedef struct
 {
 	INT32S ua[80];
 	INT32S ub[80];
 	INT32S uc[80];

 	INT32S ia[80];
 	INT32S ib[80];
 	INT32S ic[80];

 }xdata;
xdata XBpoint;

int i2cfd;
float WenduK1,WenduK2;
/*******************************************
*�ӿں�������
********************************************/
//------------------------------------------------------
void JugeAtt7022(void );
void save7022flag(void);
//------------------------------------------------------
void ReadWenduXishu();
void SaveXishuData();
void jiao4mA();
void jiao20mA();

extern INT8U 	SpiByteSend(INT8U spi,INT8U da,INT16U to);

extern INT8U 	ATTStatusGet(INT8U spi,INT16U to);
extern INT8U 	ATTStatusSet(INT8U spi,INT8U st,INT16U to);
extern INT8U 	ATTDataRead(INT8U spi,INT32U addr,INT32U len,INT8U *buf,INT16U to);
extern INT8U 	ATTDataWrite(INT8U spi,INT32U addr,INT32U len,INT8U *buf,INT16U to);
extern void  	ATTInit_EE();
extern void  	ATTInit_CC();
extern INT32S 	ATTRead(INT8U spi,INT32U addr,INT32U len,INT8U *buf,INT16U to);
extern INT32S 	ATTWrite(INT8U spi,INT32U addr,INT32U len,INT8U *buf,INT16U to);
extern unsigned char Att24Tmp[1024];

//��ڲ���˵����reg ��ʼ��ַ��val ���ص���ֵ��num ����
extern void calcdianliang_EE();
extern void calcdianliang_CC();
extern int openi2c();
extern void testi(int i,unsigned char* buf);
extern void test2(int i,unsigned char* buf,int len,char* name);
//  ͨ�� I2C ��ȡ����ϵ��
extern void Read_Fk_xiu_I2C(int flag);
extern void readrec();
extern void savetest();
//  ��������ϵ�����浽оƬ  �൱��Save_Fk_xiu_I2C();
extern void savefun(void);
extern INT8U Save_Fk_xiu_Set();
extern INT8U Read_Fk_xiu_Set();
extern void AT24Read(int addr,unsigned char *dest,int len);
extern void AT24Write(int addr,unsigned char data);
extern INT8U ATTWriteDisable(INT8U spi,INT16U to);
extern void RESet7022b();
extern INT32S CkSum,CkSunOld;
extern void att_spi_init_EE(void);
extern void att_spi_init_CC(void);
extern void spi_test_ATT7022EE(void);
extern void spi_test_ATT7022CC(void);
/*************************************************************************************/
/*************  ��ѹ��������I0������ У������  ***************************************/
/*************************************************************************************/
//////////////////////2009.3.12/////////////////////
extern void modify_uipp(void);
extern void PQCbt();
extern void SinglePQUIA();
extern void SinglePQUIB();
extern void SinglePQUIC();
/*************************************************************************************/
/*************  �ǲ�У������  ********************************************************/
/*************************************************************************************/
extern void jiaoxiu_pa(void);
extern void mcjiaozheng();
extern void jiaoxiu_pb(void);
extern void jiaoxiu_pc(void);
void qingabc_cc(void);
extern void qingabc(void);
extern void YCP_Jingdu(void);
extern void initdl();
extern void dddealpro(void);
extern void XuLiangCalc(INT32S *Dest,INT32S S,INT8U *DestTime,INT32S *CMP,TS ts);
extern void XuLiangRst();
extern void SetYCData();
extern void FeiLvCalc();
extern void CreateErr14(INT8U Flag);
extern void CreateErr04(INT8U Flag);
extern void DoFkDataChange(TS ts);
extern void DoYouGongShuChu();
extern void DoWuGongShuChu();
extern void EnSpi(int count);
extern void DisEnSpi();
void IniXiShu_Mem();
int jACSpPrint;
#define SAVEFILE 1
/*******************************/
ExdTongJi exdtjd,exdtjm;//����ͳ��
INT8U FeiLvNo(const TS ts_t);
void DoDataChange(TS ts);
extern void DoTongJi(TS ts);
extern void UHeGePrt();
unsigned char ProjectNo;
FILE *filep;
typedef struct
{
    INT8U  HZpoint;
    INT32U HZBuff[16];

}hzxg;
hzxg HZall;

#endif /*FKJIAOCAI_H_*/
