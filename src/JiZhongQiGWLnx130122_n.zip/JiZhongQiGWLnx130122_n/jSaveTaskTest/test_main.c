/*
 * main.c
 *
 *  Created on: Jan 10, 2013
 *      Author: ln
 */
#include "unity_fixture.h"

#include "jSaveTask.h"

ParamInfo3761 _JParamInfo3761;
DataFileInfo  _JDataFileInfo;
ProgramInfo   _JProgramInfo;
ConfigInfo    _JConfigInfo;
extern char output[1024];
extern struct tm sim_rtc;
extern INT8U Day[PointMax],Month[PointMax];		//��¼�����������ն��ᣬ�¶�����
extern void TSGet(TS *ts);
extern INT8U access_flag[256];
extern int StateProcess(int* step,int* rev_delay,int delay_num, int* rev_tail,int* rev_tail2,int* rev_tail3,int* rev_head,INT8U *NetRevBuf,INT8U* dealbuf,int* deallen);


TEST_GROUP(Class1DataProc);

TEST_SETUP(Class1DataProc)
{
	memset(output,0,sizeof(output));
	memset(&_JProgramInfo,0xff,sizeof(JProgramInfo));//set  0xff
	memset(&_JDataFileInfo,0xff,sizeof(JDataFileInfo));
	memset(&_JParamInfo3761,0xff,sizeof(JParamInfo3761));
	memset(&_JConfigInfo,0xff,sizeof(JConfigInfo));
	JProgramInfo = &_JProgramInfo;
	JDataFileInfo= &_JDataFileInfo;
	JParamInfo3761=&_JParamInfo3761;
	JConfigInfo =&_JConfigInfo;
	sem_init(&JProgramInfo->mainData.UseCycleFlg,1,1);//����д������Ϣ��������ͻ
	sem_init(&JProgramInfo->mainData.UseFileFlg,1,1);
	sem_init(&JProgramInfo->mainData.UseFMFileFlg,1,1);//����д������Ϣ��������ͻ
	sem_init(&JProgramInfo->mainData.Gprs_Data_Flag,1,1);//��������ģ�黺������ͻ
}

TEST_TEAR_DOWN(Class1DataProc)
{

}
TEST(Class1DataProc,1)
{
	JProgramInfo->FileSaveFlag.g1flag = 1;
	Class1DataProc(JProgramInfo,JParamInfo3761,JDataFileInfo,&JConfigInfo->jzqpara);		//������Ҫ��־���д洢��I���ļ�
	STRCMP_EQUAL("FileName=/nand/para/group1.par",output);

//	JProgramInfo->FileSaveFlag.g1flag = 2;
//	Class1DataProc(JProgramInfo,JParamInfo3761,JDataFileInfo,&JConfigInfo->jzqpara);		//������Ҫ��־���д洢��I���ļ�
//	STRCMP_EQUAL("rm -f /nand/para/group1.par",output);

//	JProgramInfo->FileSaveFlag.g1flag = 5;
//	Class1DataProc(JProgramInfo,JParamInfo3761,JDataFileInfo,&JConfigInfo->jzqpara);		//������Ҫ��־���д洢��I���ļ�
//	STRCMP_EQUAL("",output);

}

TEST_GROUP(savePointData);

TEST_SETUP(savePointData)
{
	fprintf(stderr,"init start\n");
	memset(output,0,sizeof(output));
	memset(&_JProgramInfo,0xff,sizeof(JProgramInfo));//set  0xff
	memset(&_JDataFileInfo,0xff,sizeof(JDataFileInfo));
	memset(&_JParamInfo3761,0xff,sizeof(JParamInfo3761));
	memset(&_JConfigInfo,0xff,sizeof(JConfigInfo));
	JProgramInfo = &_JProgramInfo;
	JDataFileInfo= &_JDataFileInfo;
	JParamInfo3761=&_JParamInfo3761;
	JConfigInfo =&_JConfigInfo;
	fprintf(stderr,"init end\n");
	sem_init(&JProgramInfo->mainData.UseCycleFlg,1,1);//����д������Ϣ��������ͻ
	sem_init(&JProgramInfo->mainData.UseFileFlg,1,1);
	sem_init(&JProgramInfo->mainData.UseFMFileFlg,1,1);//����д������Ϣ��������ͻ
	sem_init(&JProgramInfo->mainData.Gprs_Data_Flag,1,1);//��������ģ�黺������ͻ

}

TEST_TEAR_DOWN(savePointData)
{

}
TEST(savePointData,1)
{
	fprintf(stderr,"start\n");
	JProgramInfo->sm.dataChanged = 1;
	strcpy(JProgramInfo->sm.filename,"/nand/DataCurr/0001/curr.dat");
	JProgramInfo->sm.filelen = 1000;
	fprintf(stderr,"JProgramInfo->sm.dataChanged=%d\n",JProgramInfo->sm.dataChanged);
	savePointData(JProgramInfo,JParamInfo3761,JDataFileInfo);	//������Ҫ��־���д洢��I���ļ�


}

TEST_GROUP(StateProcess);

TEST_SETUP(StateProcess)
{
	memset(output,0,sizeof(output));
	memset(&_JProgramInfo,0xff,sizeof(JProgramInfo));//set  0xff
	memset(&_JDataFileInfo,0xff,sizeof(JDataFileInfo));
	memset(&_JParamInfo3761,0xff,sizeof(JParamInfo3761));
	memset(&_JConfigInfo,0xff,sizeof(JConfigInfo));
	JProgramInfo = &_JProgramInfo;
	JDataFileInfo= &_JDataFileInfo;
	JParamInfo3761=&_JParamInfo3761;
	JConfigInfo =&_JConfigInfo;
	sem_init(&JProgramInfo->mainData.UseCycleFlg,1,1);//����д������Ϣ��������ͻ
	sem_init(&JProgramInfo->mainData.UseFileFlg,1,1);
	sem_init(&JProgramInfo->mainData.UseFMFileFlg,1,1);//����д������Ϣ��������ͻ
	sem_init(&JProgramInfo->mainData.Gprs_Data_Flag,1,1);//��������ģ�黺������ͻ
}

TEST_TEAR_DOWN(StateProcess)
{

}
TEST(StateProcess,1)
{
	int  step=0;
	int  rev_delay;
	int  delay_num=10;
	int	 rev_tail;
	int	 rev_tail2;
	int	 rev_tail3;
	int	 rev_head;
	INT8U NetRevBuf[]={
			0x68, 0xD6, 0x01, 0xD6, 0x01, 0x68, 0x4A, 0x02, 0x35, 0x01, 0x00, 0x02, 0x04, 0xF0, 0x00, 0x00,
			0x02, 0x01, 0x03, 0x00, 0x01, 0x00, 0x01, 0x00, 0x61, 0x1E, 0x11, 0x00, 0x11, 0x00, 0x00, 0x00,
			0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04, 0x09, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02,
			0x00, 0x02, 0x00, 0x62, 0x1E, 0x22, 0x00, 0x22, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
			0x00, 0x04, 0x09, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x03, 0x00, 0x03, 0x00, 0x7F, 0x1E,
			0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04, 0x09, 0x01, 0x00,
			0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
			0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x20, 0x34, 0x17, 0x09, 0x00, 0x2A, 0x16
	};
	INT8U dealbuf[8192];
	int	 deallen;

	StateProcess(&step,&rev_delay,delay_num,&rev_tail,&rev_tail2,&rev_tail3,&rev_head,&NetRevBuf,&dealbuf,&deallen);
}

TEST_GROUP_RUNNER(Class1DataProc)
{
	RUN_TEST_CASE(Class1DataProc,1);
}
TEST_GROUP_RUNNER(savePointData)
{

	RUN_TEST_CASE(savePointData,1);
}
TEST_GROUP_RUNNER(StateProcess)
{

	RUN_TEST_CASE(StateProcess,1);
}

/////////////////////////////////////////////////
static void run_all_test()
{
//	RUN_TEST_GROUP(Class1DataProc);
//	RUN_TEST_GROUP(savePointData);
	RUN_TEST_GROUP(StateProcess);
}

int main(int argc ,char *argv)
{
	return UnityMain(argc,argv,run_all_test);
}
