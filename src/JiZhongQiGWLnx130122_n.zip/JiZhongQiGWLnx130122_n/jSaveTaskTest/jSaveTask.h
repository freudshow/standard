#ifndef FKDSFUN_H_
#define FKDSFUN_H_
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <dirent.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <arpa/inet.h>
#include <ctype.h>
#include <time.h>
#include <signal.h>
#include <semaphore.h>
#include <errno.h>
#include <netdb.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <math.h>
#include <inc/jMemory.h>
#include <inc/pubfunction.h>
#include <pthread.h>
#include <math.h>
#ifndef __linux__
#include <hw/inout.h>
#endif

#define DataSaveDbg if(RtuDataAddr->DATASAVEDBON)fprintf
#define DebugComm stderr

#define Dlt645Dbg fprintf
#define DebugComm stderr

#define SaveTaskPrint(...) if (jDataSavePrint==1) printf(__VA_ARGS__); \
	else if (jDataSavePrint==2) fprintf(fp, __VA_ARGS__); \
	else if (jDataSavePrint==3) fprintf(stderr,__VA_ARGS__);
//	else print(__VA_ARGS__);

ParamInfo3761* JParamInfo3761;
DataFileInfo*  JDataFileInfo;
ConfigInfo*    JConfigInfo;
ProgramInfo* 	JProgramInfo;

INT8U GetProjects(INT32S argc, char * argv[]);
void MakeFolden();
INT8U readParaFile(TS ts,ProgramInfo *proginfo,ParamInfo3761 *paraminfo,DataFileInfo *datainfo,ConfigInfo *cfginfo);
void Class1DataProc(ProgramInfo *proginfo,ParamInfo3761 *paraminfo,DataFileInfo *datainfo,ConfigInfo *cfginfo);
void saveMonthData(INT8U *monflag,TS nowts,ParamInfo3761 *parainfo,ProgramInfo *proginfo);
void saveDayData(INT8U *dayflag,TS nowts,ParamInfo3761 *parainfo,ProgramInfo *proginfo);
void saveHourData(TS nowts,ParamInfo3761 *parainfo,ProgramInfo *proginfo);
void saveTjData(TS nowts,DataFileInfo *datainfo,ParamInfo3761 *parainfo,ProgramInfo *proginfo);
void savePointData(ProgramInfo *proginfo,ParamInfo3761 *paraminfo,DataFileInfo *datainfo);
void savePointConfig(TS nowts,ProgramInfo *proginfo,ParamInfo3761 *paraminfo,DataFileInfo *datainfo);
void powerOffDataSave(TS nowts,ProgramInfo *proginfo,ParamInfo3761 *paraminfo,DataFileInfo *datainfo);
void rebootSaveProc(TS nowts,ProgramInfo *proginfo,ParamInfo3761 *paraminfo,DataFileInfo *datainfo,ConfigInfo *cfginfo);
void delallcurrdat(TS ts,ProgramInfo *proginfo,ParamInfo3761 *paraminfo);

#endif /*FKDSFUN_H_*/
