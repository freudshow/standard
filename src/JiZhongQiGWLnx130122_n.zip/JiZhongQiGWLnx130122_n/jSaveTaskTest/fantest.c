/*
 * fantest.c

 *
 *  Created on: 2013-1-11
 *      Author: Administrator
 */
#include "stdio.h"
#include "stdlib.h"
#define INT8U	unsigned char
#define FrameSize  8192


int StateProcess(int* step,int* rev_delay,int delay_num, int* rev_tail,int* rev_tail2,int* rev_tail3,int* rev_head,INT8U *NetRevBuf,INT8U* dealbuf,int* deallen)
{
	int length = 0,i;
	switch(*step)
	{
		case 0:    //��һ�� 0x68
			if (*rev_tail != *rev_head)
			{
				if (NetRevBuf[*rev_tail]== 0x68)
				{
					//fprintf(stderr,"\nrev_tail[68-1] = %d",rev_tail);
					*step = 1;
					*rev_tail2 = (*rev_tail + 5)% FrameSize;
				}else
					*rev_tail = (*rev_tail + 1)% FrameSize;
			}
			break;
		case 1:    //�ڶ��� 0x68   �����㳤��
			if (NetRevBuf[*rev_tail2]== 0x68)
			{
				length = (NetRevBuf[*rev_tail+ 2] << 8) + NetRevBuf[*rev_tail+ 1];
				length = length >>2;
				//fprintf(stderr,"\nrev_tail[68-2] = %d length=%d",rev_tail2 ,length);
				*step = 2;//������һ��
			}else
			{
				*rev_tail = (*rev_tail2 + 1)% FrameSize;
				*step = 0;//���ص�һ��
			}
			break;
		case 2:	   //��rev_tail2��ʼ �糤���ֽ��� 0x16
			*rev_tail3= (*rev_tail2 + length + 2 + FrameSize)% FrameSize;
			//fprintf(stderr,"\nrev_tail3 = %d  [%02x]",rev_tail3,NetRevBuf[ rev_tail3 ]);
			if(NetRevBuf[ *rev_tail3 ]== 0x16)
			{
				*rev_delay = 0;
				*step = 3;//������һ��
			}
			else
			{
				fprintf(stderr,"\n  ?? !!");
				if (*rev_delay < delay_num)
				{
					(*rev_delay)++;
					//delay(10);
					break;
				}else
				{
					*rev_delay = 0;
					*rev_tail = (*rev_tail2 + 1)% FrameSize;
					*step = 0;//���ص�һ��
				}
			}
			break;
		case 3:
			*deallen = (*rev_tail3 - *rev_tail + FrameSize)% FrameSize + 1;
			fprintf(stderr,"\nprocess %d bytes\n",*deallen);
			for(i=0;i<*deallen;i++)
			{
				dealbuf[i] = NetRevBuf[*rev_tail];
				fprintf(stderr,"%02x ",dealbuf[i]);
				*rev_tail = (*rev_tail + 1) % FrameSize;
			}
			*step = 0;
			return 1;
			break;
		default :
			break;
	}
	return 0;
}
