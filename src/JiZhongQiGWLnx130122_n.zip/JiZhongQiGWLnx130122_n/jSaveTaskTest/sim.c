#include "inc/jMemory.h"
#include <time.h>
#define INT16U unsigned short int
#define INT8U  unsigned char


ParamInfo3761 JParamInfo3761;
DataFileInfo  JDataFileInfo;
ProgramInfo JProgramInfo;
ConfigInfo    JConfigInfo;
char output[1024];
struct tm sim_rtc;
INT8U access_flag[256];
#if 0
//int clock_gettime (clockid_t __clock_id, struct timespec *__tp)
//{
//	__tp->tv_sec = 0;
//	__tp->tv_nsec = 0;
//	return 1;
//}
#define clock_gettime() {}
int gpio_write(char *devname, int data)
{
	return 1;
}

//int sem_timedwait (sem_t *__restrict __sem, __const struct timespec *__restrict __abstime)
//{
//	return 1;
//}
#define sem_timedwait() {}
#define sem_post() {}
//int sem_post (sem_t *__sem)
//{
//	return 1;
//}


void TSGet(TS *ts)
{
	ts->Year = sim_rtc.tm_year;
	ts->Month = sim_rtc.tm_mon;
	ts->Day = sim_rtc.tm_mday;
	ts->Hour = sim_rtc.tm_hour;
	ts->Minute = sim_rtc.tm_min;
	ts->Sec = sim_rtc.tm_sec;
	ts->Week = sim_rtc.tm_wday;
}
INT8U NormalSaveFile(char *FileName, void *source, int size,ParamInfo3761 *parainfo)
{
	sprintf(output,"%s",FileName);
	return 0;
}

INT8U NormalReadFile(char *FileName, void *source, int size,ParamInfo3761 *parainfo)
{
	sprintf(output,"%s",FileName);
	return 0;
}

int unlink (__const char *__name)
{
	sprintf(output,"%s",__name);
	return 1;
}

int system (__const char *__command)
{
	sprintf(output,"%s",__command);
	fprintf(stderr,"output=%s\n",output);
	return 0;
}

void TimeDecrease(TS *ts, INT16U unit, int step)//ʱ���
{
	struct tm nowtm;
	if (ts->Year<1900)
		nowtm.tm_year = ts->Year + 2000;
	else nowtm.tm_year = ts->Year;
	nowtm.tm_mon = ts->Month;
	nowtm.tm_mday = ts->Day;
	nowtm.tm_hour = ts->Hour;
	nowtm.tm_min = ts->Minute;
	nowtm.tm_sec = 0;
	nowtm.tm_isdst = 0;
	nowtm.tm_year -= 1900;
	nowtm.tm_mon -= 1;
	switch (unit) {
	case 2:
		nowtm.tm_min -= step;
		break;
	case 3:
		nowtm.tm_hour -= step;
		break;
	case 4:
		nowtm.tm_mday -= step;
		break;
	case 5:
		nowtm.tm_mon -= step;
		break;
	case 6:
		nowtm.tm_year -= step;
		break;
	default:
		break;
	}
	mktime(&nowtm);
	nowtm.tm_year += 1900;
	nowtm.tm_mon += 1;
	ts->Year = nowtm.tm_year;
	ts->Month = nowtm.tm_mon;
	ts->Day = nowtm.tm_mday;
	ts->Hour = nowtm.tm_hour;
	ts->Minute = nowtm.tm_min;
}

void ClearWaitTimes(unsigned char ProjectID) {
//	JProgramInfo->Projects[ProjectID].WaitTimes = 0;
}

//��ȡ���ݵ�ָ��������
INT8U ReadFile(char *FileName, void *source, int size,ParamInfo3761 *parainfo) {
//	FILE *fp;
//	INT8U res;
//	int num;
	sprintf(output,"ReadFile=%s",FileName);
//	fprintf(stderr,"output=%s\n",output);
	return 0;
}

INT8U SaveFile(char *FileName, void *source, int size,ParamInfo3761 *parainfo)
{
	sprintf(output,"SaveFile=%s",FileName);
	fprintf(stderr,"output=%s\n",output);
	//printf("%s",FileName);
	return size;
}

int access (__const char *__name, int __type)
{
	static INT8U	step;
	int		ret;

		ret = access_flag[step];
		step = (step+1)%4;

	return ret;
}
#endif

