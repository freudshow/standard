//Copyright ��Ȩ����  2009�ൺ�߿�ͨ�Źɷ����޹�˾
// �ļ�����jmain.c
// �ļ�����������������������  ��ʼ���ڴ� �������������̵��������
//
//�޸İ汾�ţ�	1��const INT8U _VERSION[] = {"VER-STRING-FLG=02.03"__DATE__" "__TIME__ };  // PublicFunction.c
//				2��printf("\n\rHardware ver: LPC3250   Application ver: WX 0203 starting........................\n\r");//jmain.c
//				3��jSet ver
//
// ������ʶ��20090901 Ray
//�汾��SC 0200
//�޸�����:
//1����date�޸�ʱ�䣬����޸�ǰ��2��ʱ���Сʱֵ���3��������
//2��������ͨ��������485С�ƿ��Ƿ񳭱���ɣ���Ҫ���ڲ��Գ����Ƿ�ɹ���
//3��������USB�����������ļ���U�̵�gprsgwĿ¼��
//4�������˺��Ⳮ����С���������Ƴ����������ڴ�������
//	�����˲�����Ⱥ����Ⱥ���ã�ɾ����������Ϣ��ɾ����������
//5����Һ������������Ⱥ����ť
//6����IO��Ϊ����
//7���޸Ľ��ɴ��ļ���Ϊ��I2C��eeprom��,  spi���ڶ�7022b�н���ϵ��
//8�����Ҫ����jUpdate������ִ��killall,��˼������pkill jUpdate ,Ȼ������ι��ʱ��Ϊ1Сʱ�����pkill jmain
//9���������ã��������ַΪ000000000001��ͨ�Ź�ԼΪ2��ͨ�Ŷ˿�Ϊ1������������Ϊ3���ɼ�����ַΪ00000000  żУ�飻     ����ʼ�����ɱ���ַΪ000000000001 ������0��
//10�����������ã� ͨѶ��Լ 97Ϊ1 07Ϊ30�� ��29 30��ͨѶ�˿�485I<->������2  ��27 28��ͨѶ�˿�485II<->������3 ��25 26��ͨѶ�˿�485III<->������4  ���ն��ϴ��������� 485I 485II 485III
//ż����
//11��system.cfg�ļ�����
//# cat system.cfg
//[��̬�ļ���ʼ]
//{
//SER1=jGPRS_37i
//SER2=jRead485
//SER3=jRead4852
//SER4=jIfr
//SER5=
//SER6=jRead4853 // jReadCarr
//SER7=jLcdTask
//TCP1=
//TCP2=
//TCP3=
//TCP4=
//PROG1=jDataDeal
//PROG2=jLedTask
//PROG3=jACSampling
//PROG4=
//PROG5=jDataSaveTask
//PROG6=
//PROG7=
//PROG8=
//}
//[��̬�ļ�����]
//
//12���汾�� SC 0200
//  �����汾�ţ�0200
//13������Һ����ʾ CPU������ʾ
//14��m37ir3�����м��GPRSС��  ��checkmodem ���ӡ ��EnableGPRSLED
//	ok��
//15���޸�#define WDXISHU  1000 ��Ϊ�˽��У����׼��219������220��

//0320 01 �ĳɹ�����
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/mman.h>
#include <inc/pubfunction.h>
#include <inc/Options.h>
#include <signal.h>
#include <pthread.h>
#include "inc/init.h"
#ifdef __linux__
#include <wait.h>
#endif
//#define AT91C_PIO_PB17        (1 <<  17)
//uintptr_t Memories_RSTC,PBIO;
#define MyPulseCode   _PULSE_CODE_MINAVAIL
#ifdef __linux__
#define Attach_Point argv[0] //�ռ�·��
#else
#define Attach_Point "cbkernel" //�ռ�·��
#endif
name_attach_t *attach;

ParamInfo3761* JParamInfo3761;
DataFileInfo*  JDataFileInfo;
ConfigInfo*    JConfigInfo;
ProgramInfo* JProgramInfo;

//FILE *fp;
INT8U TempBuf[256],Command[256];

void ReadSystemInfo();//��ȡ�����ļ���Ϣ
void ProjectMainExit(int signo);//�˳�����
void ProjectKill(int i);//����ⲿ�����Ƿ���������,�Ƿ�ʱ
void ProjectCheck(int i);//����ⲿ�����Ƿ���������,�Ƿ�ʱ
int ProjectExecute(int i);//�����ⲿ����
void ProjectAllKill();
void InitProjects();
//JMemory  *Jmemory;//�ڴ湲��������ָ��

//extern void CloseComCarr();
//extern void initSerPort6();
//extern unsigned int CheckZBversion();
INT8U ProjectNo;
//extern void ReadStateInfo();
//extern void InitShiDuan();
//extern void initjcpara_jzq();
//extern void setVersion1();


#define  initxuliangtime6451(xuliangts)    \
		if(xuliangts[0]==0 && \
				xuliangts[1]==0 &&\
				xuliangts[2]==0 &&\
				xuliangts[3]==0 &&\
				xuliangts[4]==0)\
		{\
			INT32U_BCD(ts.Minute, &xuliangts[0],1);\
			INT32U_BCD(ts.Hour, &xuliangts[1],1);\
			INT32U_BCD(ts.Day, &xuliangts[2],1);\
			INT32U_BCD(ts.Month, &xuliangts[3],1);\
			INT32U_BCD(ts.Year, &xuliangts[4],1);\
		}
#define  initxuliangtime6452(xuliangts)    \
	for(i=0;i<4;i++)\
	{\
		if(xuliangts[i][0]==0 && \
				xuliangts[i][1]==0 &&\
				xuliangts[i][2]==0 &&\
				xuliangts[i][3]==0 &&\
				xuliangts[i][4]==0)\
		{\
			INT32U_BCD(ts.Minute, &xuliangts[i][0],1);\
			INT32U_BCD(ts.Hour, &xuliangts[i][1],1);\
			INT32U_BCD(ts.Day, &xuliangts[i][2],1);\
			INT32U_BCD(ts.Month, &xuliangts[i][3],1);\
			INT32U_BCD(ts.Year, &xuliangts[i][4],1);\
		}\
	}
#define  initxuliangtime3(xuliangts)    \
		if(xuliangts[0]==0 && \
				xuliangts[1]==0 &&\
				xuliangts[2]==0 &&\
				xuliangts[3]==0)\
		{\
			INT32U_BCD(ts.Minute, &xuliangts[0],1);\
			INT32U_BCD(ts.Hour, &xuliangts[1],1);\
			INT32U_BCD(ts.Day, &xuliangts[2],1);\
			INT32U_BCD(ts.Month, &xuliangts[3],1);\
		}

#define  initxuliangtime4(xuliangts)    \
	for(i=0;i<4;i++)\
	{\
		if(xuliangts[i][0]==0 && \
				xuliangts[i][1]==0 &&\
				xuliangts[i][2]==0 &&\
				xuliangts[i][3]==0)\
		{\
			INT32U_BCD(ts.Minute, &xuliangts[i][0],1);\
			INT32U_BCD(ts.Hour, &xuliangts[i][1],1);\
			INT32U_BCD(ts.Day, &xuliangts[i][2],1);\
			INT32U_BCD(ts.Month, &xuliangts[i][3],1);\
		}\
	}

//-----ver
//jSet ver �鿴�汾��
/*
const INT8U _VERSION1[] = {"VER-STRING-FLG=03.20"__DATE__" "__TIME__ };//1.01 ��ʽXXXX.XX����Ҫ�ı�

void setVersion1(INT8U flag)
{
	unsigned char softver[4];
	unsigned char hardver[4];
	unsigned char i,j,num;
	memset(softver,0x00,4);
	memset(hardver,0x00,4);
	j=0;
	for(i=0;i<5;i++)
	{
		if (_VERSION1[i+15]!='.')
		{
			softver[j]=_VERSION1[i+15];
			j++;
		}
	}

	hardver[0]='0'; //1.00
	hardver[1]='1';
	hardver[2]='0';
	hardver[3]='0';

	if (Jmemory->jzq.f9.Flag[0] & 0x01)
	{
		num=0;
		while(num<100)
		{
			if(Jmemory->ErcFlg==0)
				break;
			delay(50);
			num++;
		}

//		fprintf(stderr,"\nJmemory->jzq.ver.SoftVer: %02x %02x %02x %02x  111111",
//				Jmemory->jzq.ver.SoftVer[0],
//				Jmemory->jzq.ver.SoftVer[1],
//				Jmemory->jzq.ver.SoftVer[2],
//				Jmemory->jzq.ver.SoftVer[3]);
//		fprintf(stderr,"\nsoftver: %02x %02x %02x %02x 111111\n",softver[0],
//				softver[1],
//				softver[2],
//				softver[3]);
		if ((Jmemory->jzq.f9.Flag[0] & 0x01)&&(flag==0))
		{
//			fprintf(stderr,"\nJmemory->jzq.ver.SoftVer: %02x %02x %02x %02x",Jmemory->jzq.ver.SoftVer[0],
//					Jmemory->jzq.ver.SoftVer[1],
//					Jmemory->jzq.ver.SoftVer[2],
//					Jmemory->jzq.ver.SoftVer[3]);
//			fprintf(stderr,"\nsoftver: %02x %02x %02x %02x",softver[0],
//					softver[1],
//					softver[2],
//					softver[3]);
			if(softver[0]!=Jmemory->jzq.ver.SoftVer[0] ||
				softver[1]!=Jmemory->jzq.ver.SoftVer[1] ||
				softver[2]!=Jmemory->jzq.ver.SoftVer[2] ||
				softver[3]!=Jmemory->jzq.ver.SoftVer[3])
			{
				printf("version change\n\r");
				memset(&Jmemory->CurrErc,0,sizeof(ERC));
				Jmemory->CurrErc.Err1.ERCNo=1;
				Jmemory->CurrErc.Err1.len=14;
				Jmemory->CurrErc.Err1.BiaoZhi=0x02;
				memcpy(&Jmemory->CurrErc.Err1.Old_Ver,&Jmemory->jzq.ver.SoftVer[0],4);
				memcpy(&Jmemory->CurrErc.Err1.New_Ver,&softver[0],4);
				Jmemory->ErcFlg=1;
			}
		}
	}
	for(i=0;i<4;i++)
	{
		Jmemory->jzq.ver.SoftDate[0]=0x12; //11��1��12��
		Jmemory->jzq.ver.SoftDate[1]=0x01;
		Jmemory->jzq.ver.SoftDate[2]=0x11;
		Jmemory->jzq.ver.SoftVer[i]=softver[i];
	}
	j=0;
	for(i=0;i<4;i++)
	{
		if (hardver[i]>Jmemory->jzq.ver.HardVer[i])
		{
			j=1;
			break;
		}
		if (hardver[i]<Jmemory->jzq.ver.HardVer[i])
		{
			j=2;
			break;
		}
	}

	if (j==1)
		for(i=0;i<4;i++)
		{
			Jmemory->jzq.ver.HardDate[2]=0x20; //10��3��20��
			Jmemory->jzq.ver.HardDate[1]=0x03;
			Jmemory->jzq.ver.HardDate[0]=0x10;
			Jmemory->jzq.ver.HardVer[i]=hardver[i];
		}
//	printf("~!~!~!version:ZB[%c][%c][%c][%c]\n\r",Jmemory->jzq.ver.SoftVer[0],Jmemory->jzq.ver.SoftVer[1],
//			Jmemory->jzq.ver.SoftVer[2],Jmemory->jzq.ver.SoftVer[3]);
}*/


//--------

int ComPort;

void initSerPort6(sem_t sem)
{
	int zbbaud;
	INT8U TempBuf[60];
	FILE *fpzb = NULL;
	char ReadString[50];
	int numstr;
	unsigned char Parity[20];
	sprintf((char*)Parity,"even");
	zbbaud=9600;
	memset(TempBuf, 0, 60);
	sprintf((char *) TempBuf, "%s/localbaud.txt", _USERDIR_);
	 if (access((char *)TempBuf,0)==0)
	 {
        struct timespec tsspec;
        if (clock_gettime(CLOCK_REALTIME, &tsspec)==-1)
        	printf("clock_gettime error\n\r");
        tsspec.tv_sec += 3;
//    	sem_timedwait(&Jmemory->mainData.UseFileFlg,&tsspec);
        sem_timedwait(&sem,&tsspec);
		fpzb = fopen((char *)TempBuf,"r");
		memset(ReadString,0,50);
		numstr  = fscanf(fpzb, "%s", ReadString);
		if (numstr<=0)
		{
			zbbaud=0;
		}
		else{
			sscanf(ReadString,"%d",&zbbaud);
		}
		printf("zbbaud=%d\n\r",zbbaud);
		fclose(fpzb);
		fpzb=NULL;
//	    sem_post(&Jmemory->mainData.UseFileFlg);
		sem_post(&sem);
	 }
	 fprintf(stderr,"\n--baud=%d par=%s port=%d",zbbaud,Parity,CarrWavePort);
	ComPort = OpenComCarr(CarrWavePort,zbbaud,Parity,1,8);
	while (ComPort <1)
	{
		ComPort = OpenComCarr(CarrWavePort,zbbaud,Parity,1,8);
		delay(1000);
		printf("OpenComZB ERRO ........................\n");
	}
}
//���Ӵ򿪺����ַ���
void SendStrToCarr(unsigned char *str,unsigned short Len)
{
	write(ComPort,str,Len);
	DbPrt("ZB����:", (char *)str, Len, NULL);
}
//�����ַ���
unsigned char ReceiveFromCarr(unsigned char *str)
{
	int i,j;
	unsigned char pos = 0;
	int len;
	unsigned char TmpBuf[512];
	pos=0;
	i=0;
	j=0;
	memset(TmpBuf,0,512);

	while(1)
	{
		delay(100);
		j++;
		len = read(ComPort,TmpBuf,200);//********************//
		if(len<=0)	break;

		for(i=0;i<len;i++)
		{
			str[pos]=TmpBuf[i];
			pos=(pos+1)%512;
		}
		if(j>(1000/50)) return pos;
	}
	DbPrt("ZB����:", (char *)str, pos, NULL);
	return pos;
}
//ZBtiaohsi
//68 0F 00 41 00 00 5F 00 00 00 03 01 00 A4 16
//68 18 00 81 00 00 00 00 00 00 (03 01 00) (53 45 54 52)(03 06 11 13 00) F0 16
unsigned int CheckZBversion()
{
	unsigned char  Rec645Buff[256];
	unsigned char  Trn645Buff[256];
	unsigned int i,k=0,len=0;
	unsigned char Check=0,tmpversion[100];
	char zb_version[100],cmd[100];

	//��ZBCarrVer[20]-[25]���õ��ǡ�MANSET����������ͨ��Һ���ֶ��������ز�ģ�����ͣ���ô�������Զ���ȡ�ز�ģ�����á�
	if((JProgramInfo->ZBCarrVer[20]=='M')&&(JProgramInfo->ZBCarrVer[21]=='A')&&(JProgramInfo->ZBCarrVer[22]=='N')
			&&(JProgramInfo->ZBCarrVer[23]=='S')&&(JProgramInfo->ZBCarrVer[24]=='E')&&(JProgramInfo->ZBCarrVer[25]=='T')) {
		fprintf(stderr,"Һ���ֶ������ز����ͣ�ͨ��Һ����ѯ��ǰ�ز�����\n");
		return 1;
	}
	memset(zb_version,0,100);
	memset(cmd,0,100);
	memset(tmpversion,0,100);
	memset(JProgramInfo->ZBCarrVer,0,sizeof(JProgramInfo->ZBCarrVer));
	Trn645Buff[len++]=0x68;	//����ͷ
	Trn645Buff[len++]=0x0F;
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x41;
	//-----------------------
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x5F;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//
	//-----------------------
	Trn645Buff[len++]=0x03;//AFN
	Trn645Buff[len++]=0x01;//
	Trn645Buff[len++]=0x00;//
	for (i = 3; i < len; i++)
			Check += Trn645Buff[i];
	Trn645Buff[len++]=Check;//
	Trn645Buff[len++]=0x16;//
	delay(50);
	printf("\n ��ȡģ��汾�� ����  %d��",len);
	for(i=0;i<len;i++)
		printf("%02x ",Trn645Buff[i]);
	printf("\n\r");
	SendStrToCarr(Trn645Buff,len);//���ͱ���
	while(k<3)
	{
		delay(500);
		len=ReceiveFromCarr(Rec645Buff);
		k++;
		if(len>0)
			break;
	}
	printf("\n ����  %d��",len);
	for(i=0;i<len;i++)
		printf("%02x ",Rec645Buff[i]);	//����
	printf("\n\r");
	for(i=0;i<len;i++)
	{
		if(Rec645Buff[i]==0x68 && Rec645Buff[i+10]==0x03 && Rec645Buff[i+11]==0x01 &&
				Rec645Buff[i+12]==0x00)
		{
			BCDToASC(&Rec645Buff[i+17],5,tmpversion);
			sprintf(zb_version,"%c%c%c%c%s",Rec645Buff[i+14],Rec645Buff[i+13],Rec645Buff[i+16],Rec645Buff[i+15],
					tmpversion);

			memcpy(JProgramInfo->ZBCarrVer,zb_version,4);

			if(JProgramInfo->ZBCarrVer[0]=='E' && JProgramInfo->ZBCarrVer[1]=='S' &&
					JProgramInfo->ZBCarrVer[2]=='R' && JProgramInfo->ZBCarrVer[3]=='T')
			{
				system("cp /nor/config/system_DR.cfg /nor/config/system.cfg");
				printf("\n������·��ģ��\n");
				DbgPrintToFile("������·��ģ��");
			}
			else if(JProgramInfo->ZBCarrVer[0]=='T' && JProgramInfo->ZBCarrVer[1]=='C' &&
					JProgramInfo->ZBCarrVer[2]=='R' )
			{
				system("cp /nor/config/system_DX.cfg /nor/config/system.cfg");
				printf("\n���ŵ�·��ģ��\n");
				DbgPrintToFile("���ŵ�·��ģ��");
			}
			else if(JProgramInfo->ZBCarrVer[0]=='C' && JProgramInfo->ZBCarrVer[1]=='X')
			{
				system("cp /nor/config/system_FX.cfg /nor/config/system.cfg");
				printf("\n�������ǵ�·��ģ��\n");
				DbgPrintToFile("�������ǵ�·��ģ��");
			}
			else if((JProgramInfo->ZBCarrVer[0]=='T' && JProgramInfo->ZBCarrVer[1]=='N' &&
					JProgramInfo->ZBCarrVer[2]=='R' && JProgramInfo->ZBCarrVer[3]=='S')||
						((JProgramInfo->ZBCarrVer[0]==0x33 && JProgramInfo->ZBCarrVer[1]==0x37 &&
							JProgramInfo->ZBCarrVer[2]==0x33 && JProgramInfo->ZBCarrVer[3]==0x37)))
			{
				system("cp /nor/config/system_ZR.cfg /nor/config/system.cfg");
				printf("\n��������·��ģ��\n");
				DbgPrintToFile("��������·��ģ��");
			}else
			{
				system("cp /nor/config/system_SR.cfg /nor/config/system.cfg");
				printf("\nɣ�������ģ��\n");
//				if(Jmemory->JiangSu)
//				{
//					system("cp /nor/config/system_DX.cfg /nor/config/system.cfg");
//					printf("\n���ŵ�·��ģ��\n");
//					DbgPrintToFile("���ŵ�·��ģ��");
//				}else if(Jmemory->XinJiang)
//				{
//					system("cp /nor/config/system_DR.cfg /nor/config/system.cfg");
//					printf("\n������·��ģ��\n");
//					DbgPrintToFile("������·��ģ��");
//				}else
//				{
//					system("cp /nor/config/system_DR.cfg /nor/config/system.cfg");
//					printf("\n������·��ģ��\n");
//					DbgPrintToFile("������·��ģ��");
//				}
			}
			sprintf(cmd,"echo %s > /nand/zbversion", zb_version);
			printf("\n�ز��汾�ţ� %s\n",zb_version);
			DbgPrintToFile("�ز��汾�ţ� %s",zb_version);
			system(cmd);
		}
	}
	return 1;
}

//system(	"echo [��̬�ļ���ʼ] > /nor/system.cfg");
//system(	"echo { >> /nor/system.cfg");
//system(	"echo SER1=jGPRS_37i > /nor/system.cfg");
//system(	"echo SER2=jRead485 > /nor/system.cfg");
//system(	"echo SER3=jRead4852 > /nor/system.cfg");
//system(	"echo SER4=jIfr > /nor/system.cfg");
//system(	"echo SER5= > /nor/system.cfg");
//system(	"echo SER6=jReadZB > /nor/system.cfg");
//system(	"echo SER7=jLcdTask > /nor/system.cfg");
//system(	"echo TCP1= > /nor/system.cfg");
//system(	"echo TCP2= > /nor/system.cfg");
//system(	"echo TCP3= > /nor/system.cfg");
//system(	"echo TCP4= > /nor/system.cfg");
//system(	"echo PROG1=jDataDeal > /nor/system.cfg");
//system(	"echo PROG2=jLedTask > /nor/system.cfg");
//system(	"echo PROG3=jACSampling > /nor/system.cfg");
//system(	"echo PROG4= > /nor/system.cfg");
//system(	"echo PROG5=jDataSaveTask > /nor/system.cfg");
//system(	"echo PROG6= > /nor/system.cfg");
//system(	"echo PROG7= > /nor/system.cfg");
//system(	"echo PROG8= > /nor/system.cfg");


void ReadStateInfo()
{
	FILE *fp;
	char str[100], state[50], filename[100];
	int flag;
	memset(str, 0, 100);
	memset(state, 0, 50);
	memset(filename, 0, 100);
	sprintf(filename, "/nor/config/diqu.cfg");
	fp = fopen(filename,"r");
	if(fp!=NULL)
	{
		while(!feof(fp))
		{
			memset(str, 0, 100);
			memset(state, 0, 50);
			flag = 0;
			if(fgets(str, 100, fp) != NULL)
			{
				sscanf(str, "%s %d", state, &flag);
				if(memcmp(state, "XinJiang", strlen("XinJiang"))==0)
				{
					if(flag==1)
					{
						JProgramInfo->zone = (GUOWANGSOFTTEST | (XINJIANG&0x7f));
						system("echo xinjiang >> /dev/shm/diqu.ini");
					}
				}
				if(memcmp(state, "JiangSu", strlen("JiangSu"))==0)
				{
					if(flag==1)
					{
						JProgramInfo->zone =JIANGSU;
						system("echo JiangSu >> /dev/shm/diqu.ini");
						printf("\njiang su\n");
					}
				}
				if(memcmp(state, "TianJing", strlen("TianJing"))==0)
				{
					if(flag==1)
					{
						JProgramInfo->zone = TIANJIN;
						system("echo TianJing >> /dev/shm/diqu.ini");
					}
				}
				if(memcmp(state, "JiangXi", strlen("JiangXi"))==0)
				{
					if(flag==1)
					{
						JProgramInfo->zone = (GUOWANGSOFTTEST | (JIANGXI&0x7f));
						system("echo JiangXi >> /dev/shm/diqu.ini");
					}
				}
				if(memcmp(state, "HeBei", strlen("HeBei"))==0)
				{
					if(flag==1)
					{
						JProgramInfo->zone = (GUOWANGSOFTTEST | (HEBEI&0x7f))  ;
						system("echo HeBei >> /dev/shm/diqu.ini");
					}
				}
				if(memcmp(state, "ShangHai", strlen("ShangHai"))==0)
				{
					if(flag==1)
					{
						JProgramInfo->zone = (GUOWANGSOFTTEST | (SHANGHAI&0x7f));
						system("echo ShangHai >> /dev/shm/diqu.ini");
					}
				}
				if(memcmp(state, "GuoWangSoftTest", strlen("GuoWangSoftTest"))==0)		//9.23
				{
					if(flag==1)
					{
						JProgramInfo->zone = ((GUOWANGSOFTTEST<<7) | (JProgramInfo->zone &0x7f) );
						system("echo GuoWangSoftTest >> /dev/shm/diqu.ini");
					}
				}
			}
		}
		fclose(fp);
	}
}

void initjcpara_jzq()
{
	int i=0;
	for(i=0;i<DAY_NUM;i++) {
		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][0].Hour=7;
		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][0].Minute=0x0;
		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][0].FeilvNo=PING_SHIDUAN+1;

		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][1].Hour=8;
		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][1].Minute=0x0;
		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][1].FeilvNo=FENG_SHIDUAN+1;

		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][2].Hour=10;
		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][2].Minute=0x0;
		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][2].FeilvNo=JIAN_SHIDUAN+1;

		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][3].Hour=11;
		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][3].Minute=0x0;
		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][3].FeilvNo=PING_SHIDUAN+1;

		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][4].Hour=18;
		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][4].Minute=0x0;
		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][4].FeilvNo=FENG_SHIDUAN+1;

		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][5].Hour=19;
		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][5].Minute=0x0;
		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][5].FeilvNo=JIAN_SHIDUAN+1;

		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][6].Hour=21;
		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][6].Minute=0x0;
		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][6].FeilvNo=FENG_SHIDUAN+1;

		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][7].Hour=23;
		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][7].Minute=0x0;
		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][7].FeilvNo=GU_SHIDUAN+1;

		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][8].Hour=23;
		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][8].Minute=0x0;
		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][8].FeilvNo=GU_SHIDUAN+1;

		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][9].Hour=23;
		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][9].Minute=0x0;
		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][9].FeilvNo=GU_SHIDUAN+1;

		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][10].Hour=23;
		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][10].Minute=0x0;
		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][10].FeilvNo=GU_SHIDUAN+1;

		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][11].Hour=23;
		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][11].Minute=0x0;
		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][11].FeilvNo=GU_SHIDUAN+1;

		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][12].Hour=23;
		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][12].Minute=0x0;
		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][12].FeilvNo=GU_SHIDUAN+1;

		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][13].Hour=23;
		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][13].Minute=0x0;
		JDataFileInfo->JcPara_645.SDuanRecord.SDuan[0][i][13].FeilvNo=GU_SHIDUAN+1;
	}
	for(i=0;i<ZONE_NUM;i++) {
		JDataFileInfo->JcPara_645.SQuRecord.SQu[0][i].Month=01;
		JDataFileInfo->JcPara_645.SQuRecord.SQu[0][i].Day=01;
		JDataFileInfo->JcPara_645.SQuRecord.SQu[0][i].TableNo=01;
	}
	JDataFileInfo->JcPara_645.DongJieStartTime[0] = 0x00;
	JDataFileInfo->JcPara_645.DongJieStartTime[1] = 0x00;
	JDataFileInfo->JcPara_645.DongJieStartTime[2] = 0x10;
	JDataFileInfo->JcPara_645.DongJieStartTime[3] = 0x01;
	JDataFileInfo->JcPara_645.DongJieStartTime[4] = 0x10;
	JDataFileInfo->JcPara_645.DongJieInteral = 0x60;
	JDataFileInfo->JcPara_645.DongJieTime[0] = 0x0;
	JDataFileInfo->JcPara_645.DongJieTime[1] = 0x0;

	JDataFileInfo->JcPara_645.jiesuanDay[0].Hour=0x0;
	JDataFileInfo->JcPara_645.jiesuanDay[0].Day =0x1;
	JDataFileInfo->JcPara_645.jiesuanDay[1].Hour=0x0;
	JDataFileInfo->JcPara_645.jiesuanDay[1].Day =0x1;
	JDataFileInfo->JcPara_645.jiesuanDay[2].Hour=0x0;
	JDataFileInfo->JcPara_645.jiesuanDay[2].Day =0x1;

	JDataFileInfo->JcPara_645.XuLiangZhouQi = 15;
	JDataFileInfo->JcPara_645.HuaChaTime = 0x01;
	JDataFileInfo->JcPara_645.NianShiQuNum =0x01;
	JDataFileInfo->JcPara_645.RiShiDuanBiaoNum = 0x01;
	JDataFileInfo->JcPara_645.RiShiDuanNum = DAY_NUM;//ʱ����
	JDataFileInfo->JcPara_645.FlvNum = 0x04;//������
	JDataFileInfo->JcPara_645.GongGongJiaRi[0] = 0;
	JDataFileInfo->JcPara_645.GongGongJiaRi[1] = 0;

	JDataFileInfo->JcPara_645.YouGongZuHeByte = 5;
	JDataFileInfo->JcPara_645.WuGongZuHeByte1 = 5;
	JDataFileInfo->JcPara_645.WuGongZuHeByte2 = 0x50;
	JDataFileInfo->JcPara_645.ZhouXiuRiByte = 0x7f;
	JDataFileInfo->JcPara_645.ZhouXiuRiShiDuanBiao = 0x01;
	JDataFileInfo->JcPara_645.DingShiDongJieByte = 0xff;
	JDataFileInfo->JcPara_645.ShunShiDongJieByte = 0xff;
	JDataFileInfo->JcPara_645.YueDingDongJieByte = 0xff;
	JDataFileInfo->JcPara_645.RiDongJieByte = 0xff;
	JDataFileInfo->JcPara_645.ZhengDianDongJieByte = 0x03;

	TS ts;
	TSGet(&ts);
	initxuliangtime3(JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_All);
	initxuliangtime4(JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_F);
	initxuliangtime6451(JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_All_645);
	initxuliangtime6452(JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_F_645);

	initxuliangtime3(JDataFileInfo->jc.JcMaxXuliang.Time_F_P_X_All);
	initxuliangtime4(JDataFileInfo->jc.JcMaxXuliang.Time_F_P_X_F);
	initxuliangtime6451(JDataFileInfo->jc.JcMaxXuliang.Time_F_P_X_All_645);
	initxuliangtime6452(JDataFileInfo->jc.JcMaxXuliang.Time_F_P_X_F_645);

	initxuliangtime3(JDataFileInfo->jc.JcMaxXuliang.Time_Z_Q_X_All);
	initxuliangtime4(JDataFileInfo->jc.JcMaxXuliang.Time_Z_Q_X_F);
	initxuliangtime6451(JDataFileInfo->jc.JcMaxXuliang.Time_Z_Q_X_All_645);
	initxuliangtime6452(JDataFileInfo->jc.JcMaxXuliang.Time_Z_Q_X_F_645);

	initxuliangtime3(JDataFileInfo->jc.JcMaxXuliang.Time_F_Q_X_All);
	initxuliangtime4(JDataFileInfo->jc.JcMaxXuliang.Time_F_Q_X_F);
	initxuliangtime6451(JDataFileInfo->jc.JcMaxXuliang.Time_F_Q_X_All_645);
	initxuliangtime6452(JDataFileInfo->jc.JcMaxXuliang.Time_F_Q_X_F_645);

	initxuliangtime4(JDataFileInfo->jc.JcMaxXuliang.Time_X1_Q_F);
	initxuliangtime4(JDataFileInfo->jc.JcMaxXuliang.Time_X2_Q_F);
	initxuliangtime4(JDataFileInfo->jc.JcMaxXuliang.Time_X3_Q_F);
	initxuliangtime4(JDataFileInfo->jc.JcMaxXuliang.Time_X4_Q_F);

	initxuliangtime6452(JDataFileInfo->jc.JcMaxXuliang.Time_X1_Q_F_645);
	initxuliangtime6452(JDataFileInfo->jc.JcMaxXuliang.Time_X2_Q_F_645);
	initxuliangtime6452(JDataFileInfo->jc.JcMaxXuliang.Time_X3_Q_F_645);
	initxuliangtime6452(JDataFileInfo->jc.JcMaxXuliang.Time_X4_Q_F_645);

//	printf("\n JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_All: %02x-%02x %02x:%02x\n",
//			JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_All[3],
//			JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_All[2],
//			JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_All[1],
//			JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_All[0]);
//	for(i=0;i<4;i++)
//	{
//		printf("\n JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_F: %02x-%02x %02x:%02x\n",
//				JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_F[i][3],
//				JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_F[i][2],
//				JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_F[i][1],
//				JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_F[i][0]);
//	}
}

void InitShiDuan()
{	//�Ϻ�������ʱ��Ҫ��   6:00-22:00ƽ��T1��		22:00~6:00�ȣ�T2��
	JParamInfo3761->group3.f21.FLTime[0]=GU_SHIDUAN;//0��
	JParamInfo3761->group3.f21.FLTime[1]=GU_SHIDUAN;//0��
	JParamInfo3761->group3.f21.FLTime[2]=GU_SHIDUAN;//1��
	JParamInfo3761->group3.f21.FLTime[3]=GU_SHIDUAN;//1
	JParamInfo3761->group3.f21.FLTime[4]=GU_SHIDUAN;//2
	JParamInfo3761->group3.f21.FLTime[5]=GU_SHIDUAN;//2
	JParamInfo3761->group3.f21.FLTime[6]=GU_SHIDUAN;//3
	JParamInfo3761->group3.f21.FLTime[7]=GU_SHIDUAN;//3
	JParamInfo3761->group3.f21.FLTime[8]=GU_SHIDUAN;//4
	JParamInfo3761->group3.f21.FLTime[9]=GU_SHIDUAN;//4
	JParamInfo3761->group3.f21.FLTime[10]=GU_SHIDUAN;//5
	JParamInfo3761->group3.f21.FLTime[11]=GU_SHIDUAN;//5

	JParamInfo3761->group3.f21.FLTime[12]=PING_SHIDUAN;//6
	JParamInfo3761->group3.f21.FLTime[13]=PING_SHIDUAN;//6
	JParamInfo3761->group3.f21.FLTime[14]=PING_SHIDUAN;//7
	JParamInfo3761->group3.f21.FLTime[15]=PING_SHIDUAN;//7
	JParamInfo3761->group3.f21.FLTime[16]=PING_SHIDUAN;//8
	JParamInfo3761->group3.f21.FLTime[17]=PING_SHIDUAN;//8
	JParamInfo3761->group3.f21.FLTime[18]=PING_SHIDUAN;//9
	JParamInfo3761->group3.f21.FLTime[19]=PING_SHIDUAN;//9
	JParamInfo3761->group3.f21.FLTime[20]=PING_SHIDUAN;//10
	JParamInfo3761->group3.f21.FLTime[21]=PING_SHIDUAN;//10
	JParamInfo3761->group3.f21.FLTime[22]=PING_SHIDUAN;//11
	JParamInfo3761->group3.f21.FLTime[23]=PING_SHIDUAN;//11
	JParamInfo3761->group3.f21.FLTime[24]=PING_SHIDUAN;//12
	JParamInfo3761->group3.f21.FLTime[25]=PING_SHIDUAN;//12
	JParamInfo3761->group3.f21.FLTime[26]=PING_SHIDUAN;//13
	JParamInfo3761->group3.f21.FLTime[27]=PING_SHIDUAN;//13
	JParamInfo3761->group3.f21.FLTime[28]=PING_SHIDUAN;//14
	JParamInfo3761->group3.f21.FLTime[29]=PING_SHIDUAN;//14
	JParamInfo3761->group3.f21.FLTime[30]=PING_SHIDUAN;//15
	JParamInfo3761->group3.f21.FLTime[31]=PING_SHIDUAN;//15
	JParamInfo3761->group3.f21.FLTime[32]=PING_SHIDUAN;//16
	JParamInfo3761->group3.f21.FLTime[33]=PING_SHIDUAN;//16
	JParamInfo3761->group3.f21.FLTime[34]=PING_SHIDUAN;//17
	JParamInfo3761->group3.f21.FLTime[35]=PING_SHIDUAN;//17
	JParamInfo3761->group3.f21.FLTime[36]=PING_SHIDUAN;//18
	JParamInfo3761->group3.f21.FLTime[37]=PING_SHIDUAN;//18
	JParamInfo3761->group3.f21.FLTime[38]=PING_SHIDUAN;//19
	JParamInfo3761->group3.f21.FLTime[39]=PING_SHIDUAN;//19
	JParamInfo3761->group3.f21.FLTime[40]=PING_SHIDUAN;//20
	JParamInfo3761->group3.f21.FLTime[41]=PING_SHIDUAN;//20
	JParamInfo3761->group3.f21.FLTime[42]=PING_SHIDUAN;//21
	JParamInfo3761->group3.f21.FLTime[43]=PING_SHIDUAN;//21

	JParamInfo3761->group3.f21.FLTime[44]=GU_SHIDUAN;//22
	JParamInfo3761->group3.f21.FLTime[45]=GU_SHIDUAN;//22
	JParamInfo3761->group3.f21.FLTime[46]=GU_SHIDUAN;//23
	JParamInfo3761->group3.f21.FLTime[47]=GU_SHIDUAN;//23
}

//�����˳�ǰ������ɱ���������н��� ��������ڴ�
void ProjectMainExit(int signo)
{
	//<summary>
	//�����˳�ǰ������ɱ���������н���
	//ϵͳ���õ���
	//</summary>
	//<param name="signo"> ���̺�</param>
	//<returns></returns>
	unsigned int i;
	char command[50];
	//Memories_RSTC = mmap_device_io(16, 0xFFFFFD00);
	//out32(Memories_RSTC + 0x08, 0xA5000000);
	for(i=0;i<ProjectCount;i++)
	{
		memset(command,0,50);
		sprintf(command,"slay %s",JProgramInfo->Projects[i].ProjectName);
		//printf("\n\r %s --------------",command);
		ProjectKill(i);
		delay(100);
		//system(command);
	}
	/*if (fp!=NULL)
	{
		fclose(fp);
		fp=NULL;
	}*/
	//Memories_RSTC = mmap_device_io(16, 0xFFFFFD00);
	//out32(Memories_RSTC + 0x08, 0xA5000000);
	printf("\n\r jmain quit xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n\r");
	delay(100);
	//timer_delete(chid);
	sem_destroy(&JProgramInfo->mainData.UseCycleFlg);//����д�����������Ϣ��������ͻ
	sem_destroy(&JProgramInfo->mainData.UseFileFlg);//����д�����������Ϣ��������ͻ
	sem_destroy(&JProgramInfo->mainData.UseFMFileFlg);//����д�����������Ϣ��������ͻ
	sem_destroy(&JProgramInfo->mainData.Gprs_Data_Flag);//����д�����������Ϣ��������ͻ
	shm_unlink("ParamInfo3761");
	shm_unlink("DataFileInfo");
	shm_unlink("ConfigInfo");
	shm_unlink("ProgramInfo");

//	name_detach(attach, 0);
	exit(0);
}


int LAPI_Fork2(void)
{
    pid_t pid;
    int status;

    if (!(pid = fork())) {
        // fork first time, in child process

        switch (fork()) {
            case 0:
                return 0;
            case -1:
                _exit( errno ); /* assumes all errnos are <256 */
                break;
            default:
                _exit(0);//���ӵĸ����뿪���Ա��ö��ӵĸ��׻���!!
                break;
        }
    }

    // parent

    //printf("LAPI_Fork2() function in Parent ");
    if (pid < 0 || waitpid(pid, &status, 0) < 0)//���ӵĸ��׻���
        return -1;

    if (WIFEXITED(status)) {
        if (WEXITSTATUS(status) == 0)
            return 1;
        else
            errno = WEXITSTATUS(status);
    } else
        errno = EINTR; /* well, interrupted */

    return -1;
}

//�����ⲿ����
int ProjectExecute(int i)
{
	//<summary>
	//�����ⲿ����
	//</summary>
	//<param i="">����� </param>
	//<returns></returns>
	pid_t pid;
	char t1[20];
	if(strlen((char*)JProgramInfo->Projects[i].ProjectName)<2) return 0;
	ProjectKill(i);
	delay(500);
	//printf("\n execute project %s ............................." ,JProgramInfo->Projects[i].ProjectName);
	pid = LAPI_Fork2();//LAPI_Fork2();
	//����һ���½���
	if(pid==-1)
	{
		perror( "\n\rfork failure" );
		return 1;
	}
	memset(t1,0,sizeof(t1));

	if(pid==0)//�ӽ��̴������в���
	{
		//printf("\n execute project11111111 %d ............................." ,getpid());
		/*if (fp!=NULL)
		{
		    fprintf(fp,"\n execute project11111111 %s %d ............................." ,JProgramInfo->Projects[i].ProjectName,getpid());
    		fflush(fp);
    	}*/
		memset(TempBuf,0,256);
		sprintf((char *)TempBuf,"execute-project11111111---%s-%d",JProgramInfo->Projects[i].ProjectName,getpid());
		memset(Command,0,256);
		sprintf((char *)Command,"%s %s >> %s/main.log",_CMDECHO_,(char *)TempBuf,_USERDIR_);
		//printf("Command=%s\n\r",(char *)Command);
		//syscmd((char *)Command);
		itoa(i,t1,10);
		execlp((char*)JProgramInfo->Projects[i].ProjectName,
				(char*)JProgramInfo->Projects[i].ProjectName,
				t1,NULL);
		exit(1);
		return 0;
	}
	else//�����̴������в���
	{
		//��ȡ���������ǵ�����
		//printf("\n Main project %d ............................." ,getpid());
		itoa(i,t1,10);
	    sprintf((char*)JProgramInfo->Projects[i].ProjectRunName,"%s %s",JProgramInfo->Projects[i].ProjectName,t1);
		JProgramInfo->Projects[i].ProjectState=NowRun;
		delay(100);
		return 1;
	}
	return 1;
}


//����ⲿ�����Ƿ���������,�Ƿ�ʱ
void ProjectKill(int i)
{
	//<summary>
	//�����ⲿ����
	//</summary>
	//<param i="">����� </param>
	//<returns></returns>
	//pid_t pid;
	char command[50];
	TS ts;
	if(JProgramInfo->Projects[i].ProjectID==0 ) return;
	if(strlen((char*)JProgramInfo->Projects[i].ProjectName)<2) return;
//	if(i==7) //weifang
//		return;
	if(JProgramInfo->Projects[i].ProjectID!=0)
	{
		if (kill(JProgramInfo->Projects[i].ProjectID,SIGTERM)<0)
		{
			delay(500);
			delay(500);
			memset(command,0,50);
			sprintf(command,"slay %s",JProgramInfo->Projects[i].ProjectName);
			syscmd(command,JProgramInfo);
		}
		JProgramInfo->Projects[i].ProjectID=0;
		printf("\n kill project %s .............................\n\r" ,JProgramInfo->Projects[i].ProjectName);

		TSGet(&ts);
		/*if (fp!=NULL)
		{
    		fprintf(fp,"\n kill project %d-%d-%d %d:%d %s .............................\n\r" ,
    				ts.Year,ts.Month,ts.Day,ts.Hour,ts.Minute,JProgramInfo->Projects[i].ProjectName);
    		fflush(fp);
    	}*/

		memset(TempBuf,0,256);
		sprintf((char *)TempBuf,"kill-project-%d-%d-%d-%d:%d---%s...",
				ts.Year,ts.Month,ts.Day,ts.Hour,ts.Minute,JProgramInfo->Projects[i].ProjectName);
		memset(Command,0,256);
		sprintf((char *)Command,"%s %s >> %s/main.log",_CMDECHO_,(char *)TempBuf,_USERDIR_);
		//printf("Command=%s\n\r",(char *)Command);
		//syscmd((char *)Command);
	}
}
//ɱ�������ӳ�����˳�
void ProjectAllKill()
{
	unsigned char ProjectNo;
	for(ProjectNo=0;ProjectNo<ProjectCount;ProjectNo++)//ѭ����������
	{
		if(strlen((char*)JProgramInfo->Projects[ProjectNo].ProjectName)<2)continue;
		ProjectKill(ProjectNo);
	}
}





//����ⲿ�����Ƿ���������,�Ƿ�ʱ
void ProjectCheck(int i)
{
	//<summary>
	//�����ⲿ����
	//</summary>
	//<param i="">����� </param>
	//<returns></returns>
	if(strlen((char*)JProgramInfo->Projects[i].ProjectName)<2) return;
	if(JProgramInfo->Projects[i].ProjectState==NowRun)
	{
		JProgramInfo->Projects[i].WaitTimes++;
		if(JProgramInfo->Projects[i].WaitTimes>ProjectWaitMaxCount)
		{
			JProgramInfo->Projects[i].ProjectState=NeedKill;
			JProgramInfo->Projects[i].WaitTimes=0;
		}
	}

}
//��ʼ���ӳ�����Ϣ
void InitProjects()
{

	int ProjectNo=0;
	for(ProjectNo=ProjectCount-1;ProjectNo>=0;ProjectNo--)
	{
		if(strlen((char*)JProgramInfo->Projects[ProjectNo].ProjectName)>2)
		{
		//	ProjectKill(ProjectNo);
			JProgramInfo->Projects[ProjectNo].ProjectID=0;
			JProgramInfo->Projects[ProjectNo].WaitTimes=1;
			JProgramInfo->Projects[ProjectNo].ProjectState=NeedStart;
			//printf("\n\r project %d %s",ProjectNo,JProgramInfo->Projects[ProjectNo].ProjectName);
		}
		else
		{
			JProgramInfo->Projects[ProjectNo].ProjectID=0;
			JProgramInfo->Projects[ProjectNo].WaitTimes=0;
			JProgramInfo->Projects[ProjectNo].ProjectState=0;
		}
	}
}
/*
//ͨ����ȡsystem.cfg, �����С���߻���4853  ?????????
void CheckWXor4853()
{
	int i=0;
	char syssetfile[100]={0};
	int uiPortTmp=0;

	char ReadString[256];
    FILE    *fd;
	sprintf((char*)syssetfile,"%s/system.cfg",_CFGDIR_);
	fd = fopen(syssetfile,"r");
	if(fd!=NULL)
	{
		for(;;)
		{
			memset(ReadString,0,sizeof(ReadString));//����ReadString��ʼֵΪ0
			fscanf(fd,"%s",ReadString);//��һ����fd��ִ�и�ʽ������
			//printf("\n aaaaaa %s",ReadString);
			if(strncmp(ReadString,"[��̬�ļ�����]",sizeof(ReadString))==0)//�Ƚ��ַ���str1��str2�Ĵ�С,���str1С��str2,����ֵ��<0,��֮���str1����str2,����ֵ��>0,���str1����str2,����ֵ��=0
			{
				break;
		    }
			//�˿ڳ���
			if(strncmp(ReadString,"SER",3)==0)
			{
				if(strlen((char*)ReadString)<8)
					continue;
				sscanf(ReadString,"%s=%s",&uiPortTmp);
				continue;
			}
			//���ڳ���
			if(strncmp(ReadString,"TCP",3)==0)
			{
				if(strlen((char*)ReadString)<8)continue;
				for(i=0;i<strlen((char*)ReadString);i++)
				{

				}
				sscanf(&ReadString[3],"%d",&uiPortTmp);

				continue;
			}
			//���ܳ���
			if(strncmp(ReadString,"PROG",4)==0)
			{

				if(strlen((char*)ReadString)<8)continue;
				for(i=0;i<strlen((char*)ReadString);i++)
				{

				}
				sscanf(&ReadString[4],"%d",&uiPortTmp);//��ȡ�������

				continue;
			}
		}
		fclose(fd);
		fd=NULL;
	}
	sem_post(&JProgramInfo->mainData.UseFileFlg);
}
*/


//��ȡϵͳ�����ļ�
void ReadSystemInfo()
{
	//<summary>
	//��ȡϵͳ�����ļ�
	//main����ʱ ����
	//�˳����쳣�жϣ����³�������ʧ�ܡ�
	//</summary>
	//<param name=""></param>
	//<returns></returns>
	int i=0;
	char    syssetfile[100]={0};
	int uiPortTmp=0;
	char ReadString[256];
    FILE *fd;
    for(i=0;i<ProjectCount;i++)
	{
    	memset(JProgramInfo->Projects[i].ProjectName,0,30);
    	JProgramInfo->Projects[i].ProjectID=0;
	    JProgramInfo->Projects[i].WaitTimes=0;
	    JProgramInfo->Projects[i].ProjectState=0;
	}
	sprintf((char*)syssetfile,"%s/system.cfg",_CFGDIR_);
    struct timespec tsspec;
    if (clock_gettime(CLOCK_REALTIME, &tsspec)==-1)
    	printf("clock_gettime error\n\r");
    tsspec.tv_sec += 3;
	sem_timedwait(&JProgramInfo->mainData.UseFileFlg,&tsspec);
	fd = fopen(syssetfile,"r");
	if(fd!=NULL)
	{
		for(;;)
		{
			memset(ReadString,0,sizeof(ReadString));//����ReadString��ʼֵΪ0
			fscanf(fd,"%s",ReadString);//��һ����fd��ִ�и�ʽ������
			//printf("\n aaaaaa %s",ReadString);
			if(strncmp(ReadString,"[��̬�ļ�����]",sizeof(ReadString))==0)//�Ƚ��ַ���str1��str2�Ĵ�С,���str1С��str2,����ֵ��<0,��֮���str1����str2,����ֵ��>0,���str1����str2,����ֵ��=0
			{
				break;
		    }
			//�˿ڳ���
			if(strncmp(ReadString,"SER",3)==0)
			{
				if(strlen((char*)ReadString)<8)continue;
				for(i=0;i<strlen((char*)ReadString);i++)
				{
					if((ReadString[i]==',')||(ReadString[i]=='='))ReadString[i]=' ';
				}
				sscanf(&ReadString[3],"%d",&uiPortTmp);
				uiPortTmp=TCP_IP_Start-(uiPortTmp+SER_Start);
				JProgramInfo->Projects[uiPortTmp].projectType=SerProject;
				strcpy((char*)JProgramInfo->Projects[uiPortTmp].ProjectName,&ReadString[5]);
				if(uiPortTmp==2||uiPortTmp==3)
				JProgramInfo->Para.Com485PhysicalAddr=uiPortTmp;
				//printf("\n read  config project name: %d %s",uiPortTmp,JProgramInfo->Projects[uiPortTmp].ProjectName);
				continue;
			}
			//���ڳ���
			if(strncmp(ReadString,"TCP",3)==0)
			{
				if(strlen((char*)ReadString)<8)continue;
				for(i=0;i<strlen((char*)ReadString);i++)
				{
					if((ReadString[i]==',')||(ReadString[i]=='='))ReadString[i]=' ';
				}
				sscanf(&ReadString[3],"%d",&uiPortTmp);
				uiPortTmp=uiPortTmp+TCP_IP_Start;
				JProgramInfo->Projects[uiPortTmp].projectType=TCPProject;
				strcpy((char*)JProgramInfo->Projects[uiPortTmp].ProjectName,&ReadString[5]);
				//printf("\n read  config project name: %d %s",uiPortTmp,JProgramInfo->Projects[uiPortTmp].ProjectName);
				continue;
			}
			//���ܳ���
			if(strncmp(ReadString,"PROG",4)==0)
			{

				if(strlen((char*)ReadString)<8)continue;
				for(i=0;i<strlen((char*)ReadString);i++)
				{
					if((ReadString[i]==',')||(ReadString[i]=='='))ReadString[i]=' ';//ȥ���Ⱥ�
				}
				sscanf(&ReadString[4],"%d",&uiPortTmp);//��ȡ�������
				uiPortTmp=uiPortTmp+Function_Start;//��ȡ������к�
				JProgramInfo->Projects[uiPortTmp].projectType=FunctionProject;
				strcpy((char*)JProgramInfo->Projects[uiPortTmp].ProjectName,&ReadString[6]);
				//printf("\n read  config project name: %d %s",uiPortTmp,JProgramInfo->Projects[uiPortTmp].ProjectName);
				continue;
			}
		}
		fclose(fd);
		fd=NULL;
	}
	sem_post(&JProgramInfo->mainData.UseFileFlg);
}


void TianJingInit()
{
	int i=0;
	if(JProgramInfo->zone == TIANJIN)
	{
		//����
		JParamInfo3761->group1.f1.HeartInterval=30;
		//IP
		int port = 6801;
		JParamInfo3761->group1.f3.IP[3] = 10;
		JParamInfo3761->group1.f3.IP[2] = 121;
		JParamInfo3761->group1.f3.IP[1] = 23;
		JParamInfo3761->group1.f3.IP[0] = 2;
		JParamInfo3761->group1.f3.PortAddress[1] = port >> 8;
		JParamInfo3761->group1.f3.PortAddress[0] = port & 0xff;

		JParamInfo3761->group1.f3.IP1[3] = 10;
		JParamInfo3761->group1.f3.IP1[2] = 121;
		JParamInfo3761->group1.f3.IP1[1] = 23;
		JParamInfo3761->group1.f3.IP1[0] = 2;
		JParamInfo3761->group1.f3.PortAddress1[1] = port >> 8;
		JParamInfo3761->group1.f3.PortAddress1[0] = port & 0xff;
		//apn
		INT8U TmpAPN[16];
		memset(TmpAPN, 0x00, sizeof(TmpAPN));
		memset(JParamInfo3761->group1.f3.APN, 0, sizeof(JParamInfo3761->group1.f3.APN));
		memcpy(TmpAPN, "dlmy.tj", strlen("dlmy.tj"));
		for (i = 0; i < 16; i++)
			JParamInfo3761->group1.f3.APN[15 - i] = TmpAPN[i];
		write_apn();
		//�绰����
		memset(JParamInfo3761->group1.f4.ZZ, 0xff, 8);
		memset(JParamInfo3761->group1.f4.SM, 0xff, 8);
		JParamInfo3761->group1.f4.ZZ[0] = 0x13;
		JParamInfo3761->group1.f4.ZZ[1] = 0x80;
		JParamInfo3761->group1.f4.ZZ[2] = 0x02;
		JParamInfo3761->group1.f4.ZZ[3] = 0x20;
		JParamInfo3761->group1.f4.ZZ[4] = 0x50;
		JParamInfo3761->group1.f4.ZZ[5] = 0x0F;
		JParamInfo3761->group1.f4.SM[0] = 0x13;
		JParamInfo3761->group1.f4.SM[1] = 0x80;
		JParamInfo3761->group1.f4.SM[2] = 0x02;
		JParamInfo3761->group1.f4.SM[3] = 0x20;
		JParamInfo3761->group1.f4.SM[4] = 0x50;
		JParamInfo3761->group1.f4.SM[5] = 0x0F;
		JParamInfo3761->group1.f7.SubstituteIP[0] = 10;
		JParamInfo3761->group1.f7.SubstituteIP[1] = 121;
		JParamInfo3761->group1.f7.SubstituteIP[2] = 23;
		JParamInfo3761->group1.f7.SubstituteIP[3] = 254;
		JParamInfo3761->group1.f7.SubstitutePort[0]=0x91;//6801
		JParamInfo3761->group1.f7.SubstitutePort[1]=0x1A;

		JParamInfo3761->group1.f7.UserLen = 1;
		JParamInfo3761->group1.f7.UserName[0] = 'a';
		JParamInfo3761->group1.f7.PassLen = 1;
		JParamInfo3761->group1.f7.PassWords[0] = '1';
		JParamInfo3761->group1.f7.WatchPort[0] = 0x90;
		JParamInfo3761->group1.f7.WatchPort[1] = 0x1A;

		JParamInfo3761->group1.f8.Type=0x11;
		JParamInfo3761->group1.f8.Interval[0] = 0x08;
		JParamInfo3761->group1.f8.Interval[1] = 0x07;
		JParamInfo3761->group1.f8.Num= 5;
		JParamInfo3761->group1.f8.ShutDown = 9;
		JParamInfo3761->group2.f9.Flag[0] = 0x03;
		JParamInfo3761->group2.f9.Flag[1] = 0x10;
		JParamInfo3761->group2.f9.Flag[2] = 0x00;
		JParamInfo3761->group2.f9.Flag[3] = 0x00;
		JParamInfo3761->group2.f9.Flag[4] = 0x00;
		JParamInfo3761->group2.f9.Flag[5] = 0x00;
		JParamInfo3761->group2.f9.Flag[6] = 0x00;
		JParamInfo3761->group2.f9.Flag[7] = 0x10;
		JParamInfo3761->group2.f9.FlagStep[0] = 0x03;
		JParamInfo3761->group2.f9.FlagStep[1] = 0x10;
		JParamInfo3761->group2.f9.FlagStep[2] = 0x00;
		JParamInfo3761->group2.f9.FlagStep[3] = 0x00;
		JParamInfo3761->group2.f9.FlagStep[4] = 0x00;
		JParamInfo3761->group2.f9.FlagStep[5] = 0x00;
		JParamInfo3761->group2.f9.FlagStep[6] = 0x00;
		JParamInfo3761->group2.f9.FlagStep[7] = 0x10;

		int terminalIP[4];
		INT8U str1[20],str2[20],str3[20],str4[20];
		FILE *pfile;
		pfile = fopen("/nor/rc.d/ip.sh", "r");
		if(pfile!=NULL)
		{
			memset(str3, 0, 20);
			memset(terminalIP, 0, 4);
			fscanf(pfile, "%s %s %s %s", str1,str2, str3, str4);
			sscanf((char*)str3,"%d.%d.%d.%d", &terminalIP[0],
									&terminalIP[1],
									&terminalIP[2],
									&terminalIP[3]);
			for(i=0;i<4;i++)
				JParamInfo3761->group1.f7.IP[i] = (INT8U)terminalIP[i];
			printf("\nstr3=%s",str3);
		}
	}
}

/**************************************/
//�������ܣ���ʼ�������������ļ�
/**************************************/
INT8U readParaFile(TS ts,ProgramInfo *proginfo,ParamInfo3761 *paraminfo,DataFileInfo *datainfo,ConfigInfo *cfginfo)
{
	char 	TempBuf[128];
	int		savelen;

	//�����㣨F10���ò�������ȡ
	//wyq
	int i, groupNum;
	groupNum = ((int)PointMax)/SaveNum;
	for(i=0;i<groupNum;i++)
	{
		memset(TempBuf,0,128);
		sprintf((char*)TempBuf,"%s/Ammeter%04d_%04d.par",_PARADIR_,i*SaveNum+1,(i+1)*SaveNum);
		if (access((char*)TempBuf, 0) == 0)
			NormalReadFile((char*)TempBuf,(INT8U *)&paraminfo->group2.f10[i*SaveNum],sizeof(F10)*SaveNum,proginfo);
		else if(i==0) {
			proginfo->FileSaveFlag.F10_ChangedSave[0]=1;
		}
	}

	//����ϵ����ȡ
	memset(TempBuf,0,128);
	sprintf((char*)TempBuf,"%s/JcXiu.par",_PARADIR_);
	if (access((char*)TempBuf, 0) == 0)
		NormalReadFile(TempBuf,&cfginfo->jcxs,sizeof(cfginfo->jcxs),proginfo);

	memset(TempBuf,0,128);
	sprintf((char*)TempBuf,"%s/group1.par",_PARADIR_);
	if (access((char*)TempBuf, 0) == 0)
		NormalReadFile((char*)TempBuf,(INT8U *)&paraminfo->group1,sizeof(paraminfo->group1),proginfo);

	memset(TempBuf,0,128);
	sprintf((char*)TempBuf,"%s/group2.par",_PARADIR_);
	savelen = sizeof(paraminfo->group2.f9)+sizeof(paraminfo->group2.f11)+sizeof(paraminfo->group2.f12)
			+sizeof(paraminfo->group2.f13)+sizeof(paraminfo->group2.f14)+sizeof(paraminfo->group2.f15)
			+sizeof(paraminfo->group2.f16);
	if (access((char*)TempBuf, 0) == 0)
		NormalReadFile((char*)TempBuf,(INT8U *)&paraminfo->group2.f9,savelen,proginfo);

	memset(TempBuf,0,128);
	sprintf((char*)TempBuf,"%s/group3.par",_PARADIR_);
	if (access((char*)TempBuf, 0) == 0)
		NormalReadFile((char*)TempBuf,(INT8U *)&paraminfo->group3,sizeof(paraminfo->group3),proginfo);

	memset(TempBuf,0,128);
	sprintf((char*)TempBuf,"%s/group4_point.par",_PARADIR_);
	if (access((char*)TempBuf, 0) == 0)
		NormalReadFile((char*)TempBuf,(INT8U *)&paraminfo->Point,sizeof(paraminfo->Point),proginfo);

	memset(TempBuf,0,128);
	sprintf((char*)TempBuf,"%s/group5.par",_PARADIR_);
	if (access((char*)TempBuf, 0) == 0)
		NormalReadFile((char*)TempBuf,(INT8U *)&paraminfo->group5,sizeof(paraminfo->group5),proginfo);

	memset(TempBuf,0,128);
	sprintf((char*)TempBuf,"%s/group8.par",_PARADIR_);
	if (access((char*)TempBuf, 0) == 0)
		NormalReadFile((char*)TempBuf,(INT8U *)&paraminfo->group8,sizeof(paraminfo->group8),proginfo);

	memset(TempBuf,0,128);
	sprintf((char*)TempBuf,"%s/group9_task.par",_PARADIR_);
	if (access((char*)TempBuf, 0) == 0)
		NormalReadFile((char*)TempBuf,(INT8U *)&paraminfo->group9,sizeof(paraminfo->group9),proginfo);

	memset(TempBuf,0,128);
	sprintf((char*)TempBuf,"%s/group11.par",_PARADIR_);
	if (access((char*)TempBuf, 0) == 0)
		NormalReadFile((char*)TempBuf,(INT8U *)&paraminfo->group11,sizeof(paraminfo->group11),proginfo);

	memset(TempBuf,0,128);
	sprintf((char*)TempBuf,"%s/group31.par",_PARADIR_);
	if (access((char*)TempBuf, 0) == 0)
		NormalReadFile((char*)TempBuf,(INT8U *)&paraminfo->group31,sizeof(paraminfo->group31),proginfo);

	memset(TempBuf,0,128);
	sprintf((char*)TempBuf,"%s/f165.par",_PARADIR_);
	if (access((char*)TempBuf, 0) == 0)
		NormalReadFile((char*)TempBuf,(INT8U *)&paraminfo->level1,sizeof(paraminfo->level1),proginfo);

	memset(TempBuf,0,128);
	sprintf((char*)TempBuf,"%s/ercevent.par",_PARADIR_);
	if (access((char*)TempBuf, 0) == 0)
		NormalReadFile((char*)TempBuf,(INT8U *)&datainfo->ErcEvt,sizeof(datainfo->ErcEvt),proginfo);

	memset(TempBuf,0,128);
	sprintf((char*)TempBuf,"%s/jzqpara.par",_PARADIR_);
	if (access((char*)TempBuf, 0) == 0)
		NormalReadFile((char*)TempBuf,(INT8U *)&cfginfo->jzqpara,sizeof(cfginfo->jzqpara),proginfo);

	memset(TempBuf,0,128);
	sprintf((char*)TempBuf,"%s/jc645.par",_PARADIR_);
	if (access((char*)TempBuf, 0) == 0)
		NormalReadFile((char*)TempBuf,(INT8U *)&datainfo->JcPara_645,sizeof(datainfo->JcPara_645),proginfo);

	memset(TempBuf,0,128);
	sprintf((char*)TempBuf,"%s/csq.dat",_ALARMDIR_);
	if (access((char*)TempBuf, 0) == 0){
		ReadFile((char*)TempBuf,(INT8U *)&datainfo->logininfo.GprsCSQ,sizeof(datainfo->logininfo.GprsCSQ),proginfo);
	}else 	{
		for(i=0;i<24;i++){
			JDataFileInfo->logininfo.GprsCSQ[i]=0xEE;
		}
	}

	memset(TempBuf,0,128);
	sprintf((char*)TempBuf,"%s/d%02d.dat",_ALARMDIR_,ts.Day);
	if (access((char*)TempBuf, 0) == 0)
		ReadFile((char*)TempBuf,(INT8U *)&datainfo->DayRunTj,sizeof(datainfo->DayRunTj),proginfo);

	memset(TempBuf,0,128);
	sprintf((char*)TempBuf,"%s/m%02d.dat",_ALARMDIR_,ts.Month);
	if (access((char*)TempBuf, 0) == 0)
		ReadFile((char*)TempBuf,(INT8U *)&datainfo->YueRunTj,sizeof(datainfo->YueRunTj),proginfo);

	memset(TempBuf,0,128);
	sprintf((char*)TempBuf,"%s/ptinfo.dat",_ALARMDIR_);
	if (access((char*)TempBuf, 0) == 0)
		ReadFile((char*)TempBuf,(INT8U *)&datainfo->ptinfo,sizeof(datainfo->ptinfo),proginfo);

	memset(TempBuf,0,128);
	sprintf((char*)TempBuf,"%s/data485.dat",_ALARMDIR_);
	if (access((char*)TempBuf, 0) == 0)
		ReadFile((char*)TempBuf,(INT8U *)&datainfo->data485,sizeof(datainfo->data485),proginfo);

	for(i=0;i<PointMax;i++)
	{
		memset(TempBuf,0,128);
		sprintf((char*)TempBuf,"%s/%04d/d%02d.dat",_DAYTJDIR_,i+1,ts.Day);
		if (access((char*)TempBuf, 0) == 0)
			ReadFile((char*)TempBuf,(INT8U *)&datainfo->DayTjValue[i],sizeof(ExdTongJi),proginfo);

		memset(TempBuf,0,128);
		sprintf((char*)TempBuf,"%s/%04d/m%02d.dat",_MONTJDIR_,i+1,ts.Month);
		if (access((char*)TempBuf, 0) == 0)
			ReadFile((char*)TempBuf,(INT8U *)&datainfo->YueTjValue[i],sizeof(ExdTongJi),proginfo);
	}
	//�������ݶ�ȡ
	memset(TempBuf,0,128);
	sprintf((char*)TempBuf,"%s/JcData.dat",_CURRDIR_);
	if (access((char*)TempBuf, 0) == 0) {
		if(NormalReadFile(TempBuf,&datainfo->jc,sizeof(datainfo->jc),proginfo)==1){		//�ļ���ȡʧ��
			memset(&datainfo->jc,0,sizeof(datainfo->jc));
			fprintf(stderr,"***************jmain    read  jc error!!!!\n");
		}
	}
	if(proginfo->zone == JIANGSU)
		datainfo->data485[1].MeterNum_CBSucc = 0;				//���ղ��Եĳ����ɹ�����=0��ÿ���ϵ����¼���
	return (1);
}


//�ڴ��ʼ��
void InitMemory()
{
	INT8U i;
	JProgramInfo->ExcuteNo = 0;
	JProgramInfo->ShutNum &= 0x0F;
	InitjzqInfo(0, JParamInfo3761, JProgramInfo,JConfigInfo,JDataFileInfo);
	InitMeterInfo(JParamInfo3761);
	InitTaskInfo(JParamInfo3761,JProgramInfo);
	JProgramInfo->ExcuteNo++;
	JProgramInfo->ExcuteNo=JProgramInfo->ExcuteNo&0x77FF;

	INT8U ver[4];
	ver[0]='0';
	ver[1]='1';
	ver[2]='0';
	ver[3]='5';
//	printf("\n JConfigInfo->jzqpara.ver.SoftVer[0]~[3]=%c%c%c%c \n",
//			JConfigInfo->jzqpara.ver.SoftVer[0],
//			JConfigInfo->jzqpara.ver.SoftVer[1],
//			JConfigInfo->jzqpara.ver.SoftVer[2],
//			JConfigInfo->jzqpara.ver.SoftVer[3]);
	if (memcmp(&JConfigInfo->jzqpara.ver.SoftVer[0],&ver[0],4)<0)
	{
		printf("ver---\n\r");
		JConfigInfo->jzqpara.CommType = 0;
		JParamInfo3761->group11.f111.Enable = 0;
		JProgramInfo->InitMeterType = 0;
		JConfigInfo->jzqpara.ChaoBiaoDongJieType = 0;
		JConfigInfo->jzqpara.HeBei_ReadLevelOne = 0;
		JProgramInfo->Update_Time=80;
		TS ts;
		TSGet(&ts);
		InitTaskInfo(JParamInfo3761,JProgramInfo);
		for(i=0;i<R485Max;i++)
		{
			JDataFileInfo->data485[i].ts.Year=ts.Year;
			JDataFileInfo->data485[i].ts.Month=ts.Month;
			JDataFileInfo->data485[i].ts.Day=ts.Day;
			JDataFileInfo->data485[i].ts.Hour=ts.Hour;
			JDataFileInfo->data485[i].ts.Minute=ts.Minute;
			JDataFileInfo->data485[i].ts.Sec=0;
			JDataFileInfo->data485[i].Flag=0;
		}
		JProgramInfo->ExcuteNo = 1;
		JConfigInfo->jzqpara.DevFlg = 1;
		memset(&JDataFileInfo->DayRunTj,0,sizeof(TongJi));
		memset(&JDataFileInfo->YueRunTj,0,sizeof(TongJi));
		//Jmemory->jzq.YueTj=0;
		JProgramInfo->LunFlg=0;
		JProgramInfo->PFC=0;
		JConfigInfo->jzqpara.CommStat=0x5;
		JProgramInfo->PowerOnMessage=0;
		JProgramInfo->PowerOFFMessage=0;
		JProgramInfo->mainData.Time_Flag=100;
		JProgramInfo->Update_Time=80;
		JProgramInfo->YxChange=0;
		JProgramInfo->YxStat=0;
		JProgramInfo->BoardElecState=1;
		memset(JDataFileInfo->ErcEvt.ImpEvent,0x00,sizeof(ERC));
		memset(JDataFileInfo->ErcEvt.NorEvent,0x00,sizeof(ERC));
		JDataFileInfo->ErcEvt.EC1=0;
		JDataFileInfo->ErcEvt.EC2=0;
		JDataFileInfo->ErcEvt.EC1old=0;
		JDataFileInfo->ErcEvt.EC2old=0;
		for(i=0;i<8;i++)
			JDataFileInfo->ErcEvt.ERCBiaoZhi[i]=0x00;
		if(JProgramInfo->zone == TIANJIN)
			JParamInfo3761->group1.f1.HeartInterval=30;
		else
			JParamInfo3761->group1.f1.HeartInterval=5;

		memset(JParamInfo3761->group2.f9.Flag,0x00,8);
		if(JProgramInfo->zone == JIANGSU)
		{
			JParamInfo3761->group2.f9.Flag[1] = JParamInfo3761->group2.f9.Flag[1] | 0x20;		//����ͣ�ϵ��¼�Ĭ����Ч
			JParamInfo3761->group2.f9.FlagStep[1]=JParamInfo3761->group2.f9.FlagStep[1] |0x20;  //����ͣ�ϵ�ʱ��Ĭ��Ϊ��Ҫ�¼�
		}
		TianJingInit();
	}

	//songjian
//	memset(JConfigInfo->jzqpara.ver.FactNo,0x00,4);
//	JConfigInfo->jzqpara.ver.FactNo[0]='G';
//	JConfigInfo->jzqpara.ver.FactNo[1]='K';
	memset(JConfigInfo->jzqpara.ver.DevNo,0x00,8);
	JConfigInfo->jzqpara.ver.DevNo[0]='G';
	JConfigInfo->jzqpara.ver.DevNo[1]='0';
	JConfigInfo->jzqpara.ver.DevNo[2]='0';
	JConfigInfo->jzqpara.ver.DevNo[3]='0';
	JConfigInfo->jzqpara.ver.DevNo[4]='0';
	JConfigInfo->jzqpara.ver.DevNo[5]='0';
	JConfigInfo->jzqpara.ver.DevNo[6]='1';

//	memset(JConfigInfo->jzqpara.ver.SoftDate,0x00,3);
//	JConfigInfo->jzqpara.ver.SoftDate[0]=0x01;
//	JConfigInfo->jzqpara.ver.SoftDate[1]=0x04;
//	JConfigInfo->jzqpara.ver.SoftDate[2]=0x12;

//	memset(JConfigInfo->jzqpara.ver.ProtVer,0x00,4);
//	JConfigInfo->jzqpara.ver.ProtVer[0]='3';
//	JConfigInfo->jzqpara.ver.ProtVer[1]='7';
//	JConfigInfo->jzqpara.ver.ProtVer[2]='6';
//	JConfigInfo->jzqpara.ver.ProtVer[3]='1';

//	memset(JConfigInfo->jzqpara.ver.HardVer,0x00,4);
//	JConfigInfo->jzqpara.ver.HardVer[0]='0';
//	JConfigInfo->jzqpara.ver.HardVer[1]='1';
//	JConfigInfo->jzqpara.ver.HardVer[2]='0';
//	JConfigInfo->jzqpara.ver.HardVer[3]='0';

//	memset(JConfigInfo->jzqpara.ver.HardDate,0x00,3);
//	JConfigInfo->jzqpara.ver.HardDate[0]=0x12;
//	JConfigInfo->jzqpara.ver.HardDate[1]=0x03;
//	JConfigInfo->jzqpara.ver.HardDate[2]=0x10;
	memset(JConfigInfo->jzqpara.ver.SetInf,0x00,11);
	JConfigInfo->jzqpara.ver.SetInf[0]='3';
	JConfigInfo->jzqpara.ver.SetInf[1]='2';
	JConfigInfo->jzqpara.ver.SetInf[2]='M';
	JProgramInfo->ShutNum=0;
	memset(JProgramInfo->BeiYong,0,20);
	delay(100);
}

//������ں���-----------------------------------------------------------------------------------------------------------
int main(int argc, char *argv[])
{
	INT8U read4852_flg=0;
	int i;
	struct sigaction sa1;//����ָ��
	int ProjectNo=0;
	TS ts,tsn;
    char command[50];
    INT8U TempBuf[60];
    int j;

    printf("\n\rHardware ver: LPC3250  starting........................\n\r");
    JParamInfo3761 = NULL;
    JDataFileInfo = NULL;
    JConfigInfo = NULL;
    JProgramInfo = NULL;

    JParamInfo3761 = Create1ShMem("ParamInfo3761",sizeof(ParamInfo3761),NULL);
    JDataFileInfo = Create1ShMem("DataFileInfo",sizeof(DataFileInfo),NULL);
    JConfigInfo = Create1ShMem("ConfigInfo",sizeof(ConfigInfo),NULL);
    JProgramInfo = Create1ShMem("ProgramInfo",sizeof(ProgramInfo),NULL);

    if (JParamInfo3761 ==NULL || JDataFileInfo == NULL ||JConfigInfo == NULL ||JProgramInfo == NULL)
    {
 		printf("\n\r  jmain chuan jian gong xiang mei buchenggong");
   		return EXIT_FAILURE;//���������ڴ�
    }
//	if(CreateMem(JParamInfo3761,JDataFileInfo,JConfigInfo,JProgramInfo))
//	{
//		printf("\n\r  jmain chuan jian gong xiang mei buchenggong");
//		return EXIT_FAILURE;//���������ڴ�
//	}

	memset(JProgramInfo,0,sizeof(ProgramInfo));
	JProgramInfo->mainData.MemoryLength=sizeof(ProgramInfo);
	sem_init(&JProgramInfo->mainData.UseFMFileFlg,1,1);//����д������Ϣ��������ͻ
	sem_init(&JProgramInfo->mainData.UseCycleFlg,1,1);//����д������Ϣ��������ͻ
	sem_init(&JProgramInfo->mainData.UseFileFlg,1,1);//�����ļ�������ͻ
	sem_init(&JProgramInfo->mainData.Gprs_Data_Flag,1,1);//��������ģ�黺������ͻ
	if(sem_init(&JProgramInfo->mainData.ATT_STM8_sem, 1, 1)==-1)
		printf("\nesam sem_init error!!!!\n");

#if 0
#ifdef __linux__
	memset(TempBuf,0,256);
	sprintf((char*)TempBuf,"%s",_PARADIR_);
	if ((access((char*)TempBuf,0)!=0)&&(strcmp("/nand/para",(char*)TempBuf)!=0))
	{
		memset(TempBuf,0,256);
		sprintf((char*)TempBuf,"%s %s",_CMDMKDIR_,_PARADIR_);
		 syscmd((char*)TempBuf,JProgramInfo);
		 delay(100);
		memset(TempBuf,0,256);
		sprintf((char*)TempBuf,"/nand/para");
		fprintf(stderr,"\n--------------------1.2");
		if (access((char*)TempBuf,0)==0)
		{
			memset(TempBuf,0,256);
			sprintf((char*)TempBuf,"%s /nand/para/*.par /nor/para/",_CMDCP_);
			syscmd((char*)TempBuf,JProgramInfo);
			delay(100);
			memset(TempBuf,0,256);
			sprintf((char*)TempBuf,"%s /nand/para",_CMDRMDIR_);
			syscmd((char*)TempBuf,JProgramInfo);
			delay(100);
		}
	}
#endif
#endif
	memset(TempBuf,0,256);
	sprintf((char*)TempBuf,"%s/main.log",_USERDIR_);
	if (access((char*)TempBuf,0)==0)
	{
		memset(TempBuf,0,256);
		sprintf((char*)TempBuf,"%s %s/main.log %s/main2.log",_CMDCP_,_USERDIR_,_USERDIR_);
		syscmd((char*)TempBuf,JProgramInfo);
	}

	memset(TempBuf,0,256);
	sprintf((char*)TempBuf,"%s > %s/main.log",_CMDECHO_,_USERDIR_);
	delay(100);
	markver();

    if ((attach=name_attach(NULL, Attach_Point, 0,JProgramInfo)) == NULL)//����һ���ռ䲢�Ҵ���һ���ŵ�
	{
    	printf( "ERR:'%s' runed,cann't regist\n\r", argv[0]);
		return EXIT_FAILURE;
   	}
	sa1.sa_handler = ProjectMainExit;//�������˳�ʱɱ�������ӽ��̣���չ����ڴ�
	sigemptyset(&sa1.sa_mask);//���������� �źż���ʼ������ա�

	sa1.sa_flags = 0;
	sigaction(SIGTERM, &sa1,NULL);
	sigaction(SIGSYS, &sa1,NULL);
	sigaction(SIGPWR, &sa1,NULL);
	sigaction(SIGKILL,&sa1,NULL);
	sigaction(SIGQUIT, &sa1,NULL);
	sigaction(SIGILL, &sa1,NULL);
	sigaction(SIGINT, &sa1,NULL);
	sigaction(SIGHUP, &sa1,NULL);
	sigaction(SIGABRT, &sa1,NULL);
	sigaction(SIGBUS, &sa1,NULL);
	TSGet(&ts);
	tsn=ts;
	if (ts.Year<2000)
	{
	   //С��2000��ʱ,��ʼ����2000-01-01 00��00��00
	   ts.Year = 2000;
	   ts.Month = 1;
	   ts.Day = 1;
	   ts.Hour = 0;
	   ts.Minute = 0;
	   ts.Sec = 0;
	   ts.Week=0;
	   memset(command,0,50);
	   sprintf(command,"date %04d.%02d.%02d-%02d:%02d:%02d",ts.Year,ts.Month,ts.Day,ts.Hour,ts.Minute,ts.Sec);
	   syscmd(command,JProgramInfo);
	}

	ReadStateInfo();//�ж��ն˹����ĸ�����
	fprintf(stderr,"\n----------------------1");
	InitMemory();
	fprintf(stderr,"\n----------------------2");
	initSerPort6(JProgramInfo->mainData.UseFileFlg);//Jmemory->mainData.UseFileFlg
	CheckZBversion();
	CloseComCarr(ComPort);
	//---------------------------------------------------------------
	ReadSystemInfo(); //��ȡ�����ļ�
	InitProjects();//��ʼ���ڴ�,���ñ�������ֵ
#if 0
	memset(TempBuf,0,256);
	sprintf((char*)TempBuf,"%s",_PARADIR_);
	if (access((char*)TempBuf,0)!=0)
	{
		memset(TempBuf,0,256);
		sprintf((char*)TempBuf,"%s %s",_CMDMKDIR_,_PARADIR_);
		syscmd((char*)TempBuf,JProgramInfo);
		delay(100);
		memset(TempBuf,0,256);
		sprintf((char*)TempBuf,"%s %s/bak",_CMDMKDIR_,_PARADIR_);
		syscmd((char*)TempBuf,JProgramInfo);
		delay(100);
		memset(TempBuf,0,256);
		sprintf((char*)TempBuf,"%s %s/bak2",_CMDMKDIR_,_PARADIR_);
		syscmd((char*)TempBuf,JProgramInfo);
		delay(100);
	 }
	else
	{
		memset(TempBuf,0,256);
		sprintf((char*)TempBuf,"%s/bak",_PARADIR_);
		if (access((char*)TempBuf,0)!=0)
		{
			memset(TempBuf,0,256);
			sprintf((char*)TempBuf,"%s %s/bak",_CMDMKDIR_,_PARADIR_);
			syscmd((char*)TempBuf,JProgramInfo);
			delay(100);
		 }
		memset(TempBuf,0,256);
		sprintf((char*)TempBuf,"%s %s/*.par %s/bak/",_CMDCP_,_PARADIR_,_PARADIR_);
		syscmd((char*)TempBuf,JProgramInfo);
		delay(100);
		memset(TempBuf,0,256);
		sprintf((char*)TempBuf,"%s/bak2",_PARADIR_);
		if (access((char*)TempBuf,0)!=0)
		{
			memset(TempBuf,0,256);
			sprintf((char*)TempBuf,"%s %s/bak2",_CMDMKDIR_,_PARADIR_);
			syscmd((char*)TempBuf,JProgramInfo);
			delay(100);
		 }
		memset(TempBuf,0,256);
		sprintf((char*)TempBuf,"%s %s/*.par %s/bak2/",_CMDCP_,_PARADIR_,_PARADIR_);
		syscmd((char*)TempBuf,JProgramInfo);
		delay(100);
	}

	if (access("/nand/gprsgw",0)!=0)
	{
			memset(TempBuf,0,256);
			sprintf((char*)TempBuf,"%s /nand/gprsgw",_CMDMKDIR_);
			 syscmd((char*)TempBuf,JProgramInfo);
		 delay(100);
	 }
#endif
	JProgramInfo->PowerOnMessage = 1;
	JProgramInfo->PowerOFFMessage = 0;
	JProgramInfo->EsamJiaocaiflag = 0;
	//ѭ���������̲���� �Ƿ��������̣�������������

	JProgramInfo->inChaoBiao = 0;
	JProgramInfo->BeginSouBiao = 0;
//	JProgramInfo->F26Valid = 0;
	JProgramInfo->stateflags.F10_Changed = 0;
	JProgramInfo->stateflags.F65_Changed = 0;
	JProgramInfo->stateflags.F66_Changed = 0;
	JProgramInfo->stateflags.UpdateZB_flag = 0;
	JProgramInfo->stateflags.Reset_Changed = 0;
	JProgramInfo->BeiYong[11]=0;
	if(JProgramInfo->zone == JIANGSU)//gaidongjiangsu
		JParamInfo3761->group2.f12.Attr = 0x00;//����ң��Ĭ��Ϊ���մ���//ң������
	else
		JParamInfo3761->group2.f12.Attr = 0x03;
	if(JProgramInfo->zone == TIANJIN)
	{
		JParamInfo3761->group1.f7.PassWords[0]=0x11;
		JParamInfo3761->group1.f7.PassWords[1]=0x11;
		JParamInfo3761->group1.f7.PassWords[2]=0x11;
	}
	initjcpara_jzq();
	InitShiDuan();

	///////�����������ļ��������ڴ��У����������ж�ParaReadFlag=1���ɶ������ڴ�����////////
	TSGet(&ts);
	JProgramInfo->stateflags.ParaReadFlag=readParaFile(ts,JProgramInfo,JParamInfo3761,JDataFileInfo,JConfigInfo);
	JProgramInfo->sm_head = 0;
	JProgramInfo->sm_tail = 0;
	setVersion(0,JParamInfo3761,JProgramInfo,JConfigInfo);
	//////////////////////////////////////////////////////

	while(1)
   	{
	    TSGet(&ts);
	    if (JProgramInfo->Gprs_ok == 1)
	    {
	    	tsn=ts;
	    }
	    else
	    {
	    	if(JProgramInfo->zone == JIANGXI)
			{
				if((ts.Hour==23)&&(ts.Minute==0)&&(ts.Sec>0)&&(ts.Sec<5))
				{	printf("\nJIANGXI  reboot jDataSaveTask ------\n\r");
					DbgPrintToFile("\njmain Jiangxi ����  23������ reboot\n");//9.27
//					memset(TempBuf, 0, 60);
//					sprintf((char *) TempBuf, "%s/rebtsys &", _USERDIR_);
//					syscmd((char *) TempBuf,JProgramInfo);
//					syscmd("reboot",JProgramInfo);
					JProgramInfo->stateflags.RebootFlag = F1_NO_INIT;
				}
			}
			else
			{
				if((((ts.Hour+24-tsn.Hour)%24)*60 + (ts.Minute-tsn.Minute))>=3*60)//����3Сʱû��������վ
				{
					if(ts.Hour==23 && ts.Minute==30)
					{
						DbgPrintToFile("\njmain ���ߴ���3Сʱ reboot\n");//9.27
						tsn=ts;
						printf("reboot jmain ------\n\r");
//						memset(TempBuf, 0, 60);
//						sprintf((char *) TempBuf, "%s/rebtsys &", _USERDIR_);
						JProgramInfo->stateflags.RebootFlag = F1_NO_INIT;
						for (j=0;j<20;j++)
						{
							delay(1000);
							JProgramInfo->Projects[ProjectCount-1].WaitTimes = 0;
						}
//						syscmd((char *) TempBuf,JProgramInfo);
//						syscmd("reboot",JProgramInfo);
					}

				}
			}
	    }
		//for(ProjectNo=ProjectCount-1;ProjectNo>=0;ProjectNo--)//ѭ����������
		for(ProjectNo=0;ProjectNo<ProjectCount;ProjectNo++)//ѭ����������
		{
			JProgramInfo->Projects[ProjectCount-1].WaitTimes = 0;
			if(strlen((char*)JProgramInfo->Projects[ProjectNo].ProjectName)<2)continue;
			//------------------------------------------------------------------------------
			for(i=0;i<PointMax;i++)
			{
				if((JParamInfo3761->group2.f10[i].Status==1)&&
					((JParamInfo3761->group2.f10[i].ConnectType==1)||(JParamInfo3761->group2.f10[i].ConnectType==30)||
							(JParamInfo3761->group2.f10[i].ConnectType==30)))
				{
					if(JParamInfo3761->group2.f10[i].port==3)
						read4852_flg = 1;
					else
						read4852_flg = 0;
				}
			}
//			printf("\nJProgramInfo->Projects[ProjectNo].ProjectName=%s,ProjectState=%d\n",JProgramInfo->Projects[ProjectNo].ProjectName,JProgramInfo->Projects[10].ProjectState);
			if(read4852_flg==1){
				if(JProgramInfo->Projects[9].ProjectState==0)
				{
					printf("\n-----------------------------------485 ����");
					JProgramInfo->Projects[9].ProjectState = NeedStart;
				}
			}
			if(read4852_flg==0){
					//printf("\n-----------------------------------485�ر�");
					JProgramInfo->Projects[9].ProjectState = None;
			}
			//------------------------------------------------------------------------------
			ProjectCheck(ProjectNo);
			if(JProgramInfo->Projects[ProjectNo].ProjectState==NeedKill)//��Ҫ��ɱ���ӳ���
			{
				if(	ProjectExecute(ProjectNo)==0)
				{
					printf("\n project %s Execute end.............................\n\r" ,JProgramInfo->Projects[ProjectNo].ProjectName);
					return  EXIT_SUCCESS;
				}
			}
			else if(JProgramInfo->Projects[ProjectNo].ProjectState==NeedStart)//��Ҫ��������
			{
				 if(ProjectExecute(ProjectNo)==0)
				{
					printf("\n project %s Execute end.............................\n\r" ,JProgramInfo->Projects[ProjectNo].ProjectName);
					return  EXIT_SUCCESS;
				}
			}
		}
//		if(JProgramInfo->Para.UpdateFlags==4)//zbupdate
//		{
//			ProjectAllKill();
//			break;
//		}
		delay(1000);
		//InitTestRealTimeData();

   	}
//ɱ���������еĽ���
//	ProjectCount=32 ���˿���
    ProjectMainExit(0);
	return EXIT_SUCCESS;//�˳�
}
