#ifndef LedSpiopC
#define LedSpiopC
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <ctype.h>
#include <time.h>
#include <signal.h>
#include <semaphore.h>
#include <errno.h>
#include <netdb.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <math.h>
#ifndef __linux__
#include <hw/inout.h>
#endif
#include "jLedTask.h"

#define AT91C_PIO_PC8         (1 <<   8) // ��Ļ�Ҳ�  u33 ��
#define AT91C_PIO_PB28        (1 <<  28) // gprs���յ�
#define AT91C_PIO_PB29        (1 <<  29) // gprs���� ��

#define AT91C_PIO_PC10         (1 <<   10)
#define AT91C_PIO_PC11         (1 <<   11) // D1 �� LED_1 com485 2 ��������
#define AT91C_PIO_PC15         (1 <<   15) // D1 �� LED_2 com485 2 ��������
#define AT91C_PIO_PA28         (1 <<   28) //jl
#define AT91C_PIO_PA7         (1 <<   7) // D3 �� LED_4 com485 3 ��������

unsigned int comGPRSState;//1�Ƿ��͵����� 2�ǽ��յ�����0�ǿ��� ��ָʾ��ȫ��
unsigned int com4852State;//1�Ƿ��͵����� 2�ǽ��յ�����0�ǿ��� ��ָʾ��ȫ��
unsigned int com4853State;//1�Ƿ��͵����� 2�ǽ��յ�����0�ǿ��� ��ָʾ��ȫ��

void LedInit();
uintptr_t port1,port2,port3 ;
extern int counter;
void LedInit() //yangdong
{
/*
	port1 = mmap_device_io( 0x200,0xFFFFF400 );// PA*���
	//port2 = mmap_device_io( 0x200,0xFFFFF600 );//D3D4 ��gprs��ʼ��
	port3 = mmap_device_io( 0x200,0xFFFFF800 );//PC

	out32(port3,AT91C_PIO_PC8);//u33��ʼ��
	out32(port3+0x10,AT91C_PIO_PC8);//u33��ʼ��

	//out32(port2,AT91C_PIO_PB28);//D3D4 ��gprs��ʼ��
	//out32(port2+0x10,AT91C_PIO_PB28);//D3D4 ��gprs��ʼ��
	//out32(port2,AT91C_PIO_PB29);//D3D4 ��gprs��ʼ��
	//out32(port2+0x10,AT91C_PIO_PB29);//D3D4 ��gprs��ʼ��
*/

	gpio_write("gpoJILIAN_LED", 1);
	gpio_write("gpoJILIAN_LED", 0);
	gpio_write("gpo485T_LED", 1);
	gpio_write("gpo485T_LED", 0);
	gpio_write("gpo485R_LED", 1);
	gpio_write("gpo485R_LED", 0);
	gpio_write("gpoALARM", 1);
	gpio_write("gpoALARM", 0);
//	if((fd = open("/dev/gpoJILIAN_LED", O_RDWR | O_NDELAY)) > 0)
//	{
//		write(fd,&on,sizeof(int));
//		close(fd);
//	}
//	if((fd = open("/dev/gpoJILIAN_LED", O_RDWR | O_NDELAY)) > 0)
//	{
//		write(fd,&off,sizeof(int));
//		close(fd);
//	}
//
//
//	if((fd = open("/dev/gpo485T_LED", O_RDWR | O_NDELAY)) > 0)
//	{
//		write(fd,&on,sizeof(int));
//		close(fd);
//	}
//
//	if((fd = open("/dev/gpo485R_LED", O_RDWR | O_NDELAY)) > 0)
//	{
//		write(fd,&on,sizeof(int));
//		close(fd);
//	}
//
//	if((fd = open("/dev/gpo485T_LED", O_RDWR | O_NDELAY)) > 0)//yangdongwenti
//	{
//		write(fd,&on,sizeof(int));
//		close(fd);
//	}
	/*
	out32(port1,AT91C_PIO_PA28);//����
	out32(port1+0x10,AT91C_PIO_PA28);

	out32(port3,AT91C_PIO_PC11);//D1 �� LED_1:��  com485 2 �������ݽ���
	out32(port3+0x10,AT91C_PIO_PC11);
	out32(port3,AT91C_PIO_PC15);// D1 �� LED_2:��  com485 2 ��������
	out32(port3+0x10,AT91C_PIO_PC15);


	out32(port3,AT91C_PIO_PC10);//gaojing
	out32(port3+0x10,AT91C_PIO_PC10);
	//out32(port1,AT91C_PIO_PA6);//D3 �� LED_3:��  com485 3 ��������
	//out32(port1+0x10,AT91C_PIO_PA6);// D3 �� LED_3:��  com485 3 ��������
	//out32(port1,AT91C_PIO_PA7);
	//out32(port1+0x10,AT91C_PIO_PA7);

	 */
}


void LedGPRS(unsigned char State)  //yangdong
{
	if(State==0)
	{
		gpio_write("gpoGPRS_LED1", 0);
		gpio_write("gpoGPRS_LED2", 0);
//		if((fd = open("/dev/gpoGPRS_LED1", O_RDWR | O_NDELAY)) > 0)
//		{
//			write(fd,&off,sizeof(int));
//			close(fd);
//		}
//		if((fd = open("/dev/gpoGPRS_LED2", O_RDWR | O_NDELAY)) > 0)
//		{
//			write(fd,&off,sizeof(int));
//			close(fd);
//		}
	}
	else if(State==1)
	{
		gpio_write("gpoGPRS_LED1", 1);
//		if((fd = open("/dev/gpoGPRS_LED1", O_RDWR | O_NDELAY)) > 0)
//		{
//			write(fd,&on,sizeof(int));
//			close(fd);
//		}
	}else if(State==2)
	{
		gpio_write("gpoGPRS_LED2", 1);
//		if((fd = open("/dev/gpoGPRS_LED2", O_RDWR | O_NDELAY)) > 0)
//		{
//			write(fd,&on,sizeof(int));
//			close(fd);
//		}
	}

	/*
	if(State==0)
	{
		out32(port2+0x34,AT91C_PIO_PB29);//�ر�
		out32(port2+0x34,AT91C_PIO_PB28);//�ر�
		comGPRSState=0;
	}
	else if(State==1)out32(port2+0x30,AT91C_PIO_PB28);// ���͵�gprs��
	else if(State==2)	out32(port2+0x30,AT91C_PIO_PB29);// ���յ�gprs��
*/
}
void Ledcom4852(unsigned char State) //yangdong
{
	if(State==0)
	{
		gpio_write("gpo485R_LED", 0);
		gpio_write("gpo485T_LED", 0);
//		if((fd = open("/dev/gpo485R_LED", O_RDWR | O_NDELAY)) > 0)
//		{
//			write(fd,&off,sizeof(int));
//			close(fd);
//		}
//		if((fd = open("/dev/gpo485T_LED", O_RDWR | O_NDELAY)) > 0)
//		{
//			write(fd,&off,sizeof(int));
//			close(fd);
//		}
	}
	else if(State==1)
	{
		gpio_write("gpo485T_LED", 1);
//		if((fd = open("/dev/gpo485T_LED", O_RDWR | O_NDELAY)) > 0)
//		{
//			write(fd,&on,sizeof(int));
//			close(fd);
//		}
	}else if(State==2)
	{
		gpio_write("gpo485R_LED", 1);
//		if((fd = open("/dev/gpo485R_LED", O_RDWR | O_NDELAY)) > 0)
//		{
//			write(fd,&on,sizeof(int));
//			close(fd);
//		}
	}
	/*
	if(State==0)
	{
	    out32(port3+0x30,AT91C_PIO_PC11);//�ر�
	    out32(port3+0x30,AT91C_PIO_PC15);//�ر�
	    com4852State=0;
	}
	else if(State==1)out32(port3+0x34,AT91C_PIO_PC15);  // �����̵���
	else if(State==2)out32(port3+0x34,AT91C_PIO_PC11);  // ���ͺ����
	*/
}
void Ledcom4853(unsigned char State)
{
	/*if(State==0)
	{
	    out32(port1+0x30,AT91C_PIO_PA6);
	    out32(port1+0x30,AT91C_PIO_PA7);
	    com4852State=0;
	}
	else if(State==1)out32(port1+0x34,AT91C_PIO_PA7);  // �����̵���
	else if(State==2)out32(port1+0x34,AT91C_PIO_PA6);  // ���ͺ����*/
}

void LedGPRSu33(unsigned char State)
{
//	if(State==0)//u33��
//	{
//		gpio_write("gpoALARM", 0);
//
//	}
//	if(State==1)//u33�� �澯��
//	{
//		gpio_write("gpoALARM", 1);
//
//	}

	if (State != 0)
	{
		counter = (counter+1)%4;
		if (counter==0)
		{
			gpio_write("gpoALARM", 1);
		}else
		{
			gpio_write("gpoALARM", 0);
		}
	}
	/*
	if(State==0)out32(port3+0x30,AT91C_PIO_PC10);//u33��
	if(State==1)out32(port3+0x34,AT91C_PIO_PC10);//u33�� �澯��
	*/
}

#endif /*LedSpiopC*/
