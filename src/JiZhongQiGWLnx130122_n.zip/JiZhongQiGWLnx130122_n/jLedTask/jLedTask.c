//Copyright ��Ȩ����  2009�ൺ�߿�ͨ�Źɷ����޹�˾
// �ļ�����jLedTask.c
// �ļ������������Զ���������
// ������ʶ��20090901 Ray
//
// �޸ı�ʶ��
// �޸�������
//
// �޸ı�ʶ��
// �޸�������
#include <stdio.h>
#include <stdlib.h>
#include <inc/pubfunction.h>
#include "jLedTask.h"

unsigned char   GetProjects(int argc, char * argv[]);//����ע��,��ȡ����źͳ�������
void QuitProcess(int signo);//�˳�����


INT8U   ADC_Alarm;
int ADC_AlarmCounter;
uintptr_t BatIO,OutIO;
void InitADC()
{
	uintptr_t IO_tmp;
	IO_tmp = mmap_device_io(0x10,0x40048008);//system("po -4 0x40048008 4");
	out8(IO_tmp,4);
	IO_tmp = mmap_device_io(0x10,0x400040B4);//system("po -4 0x400040B4 1");
	out8(IO_tmp,1);
	IO_tmp = mmap_device_io(0x10,0x40004060);//system("po -4 0x40004060 0x1ff");
	out32(IO_tmp,0x1ff);
	IO_tmp = mmap_device_io(0x10,0x40048004);//system("po -4 0x40048004 0x284");
	out32(IO_tmp,0x284);
}
void DoADC()
{
	float U;
	INT32U dianya;
	out8(BatIO,6);
	delay(2000);
	dianya = in32(OutIO);
	dianya = dianya ^ 0x400;
	U = (dianya * 6.6)/1024;
	//printf("\n��ص�ѹ=%f V",U);
	if (U <= 3.4)
	{
		ADC_Alarm = 1;
		printf("\n!!!! ADC_Alarm = %d",ADC_Alarm);
	}else
	{
		ADC_Alarm = 0;
		gpio_write("gpoALARM", 0);
	}
}
int counter;
void ADC_AlarmPro()
{

	if (ADC_Alarm == 1)
	{
		counter = (counter+1)%4;
		printf("��ص�ѹ��!");
		if (counter==0)
		{
			gpio_write("gpoALARM", 1);
		}else
		{
			gpio_write("gpoALARM", 0);
		}
	}
}

//������
int main(int argc, char *argv[])
{
	unsigned char State485_1,State485_2,State485_3,AlarmCode;
	struct sigaction sa1;//�ź�
	int count=0;
	TS ts,ts2;
	if (getenv("jLedPrt")==NULL)
	{
		jLedPrint = 0;
		if (getenv("jAllProgPrt")!=NULL)
			jLedPrint = atoi(getenv("jAllProgPrt"));
	}
	else jLedPrint = atoi(getenv("jLedPrt"));
	if (jLedPrint==2)
	{
		INT8U TempBuf[60];
		memset(TempBuf, 0, 60);
		sprintf((char *) TempBuf, "%s/jLed_log.txt", _USERDIR_);
	   fp=fopen((char *) TempBuf,"a+");
	}
	markver();
	JParamInfo3761 = Open1ShMem("ParamInfo3761",sizeof(ParamInfo3761),NULL);
	JDataFileInfo = Open1ShMem("DataFileInfo",sizeof(DataFileInfo),NULL);
	JConfigInfo = Open1ShMem("ConfigInfo",sizeof(ConfigInfo),NULL);
	JProgramInfo = Open1ShMem("ProgramInfo",sizeof(ProgramInfo),NULL);

	if(JProgramInfo->mainData.MemoryLength!=sizeof(ProgramInfo))
	{
		printf( "\n jLedTask base mem uncompared prog will exit %d  %d :\n",sizeof(ProgramInfo),JProgramInfo->mainData.MemoryLength);
		return EXIT_FAILURE;
	}
	if(!GetProjects(argc, argv))
	{
		printf("\n jLedTask Bad command format. Type 'use exe_name' for help!\n\r");
		return EXIT_FAILURE;
	}
	delay(200);
	JProgramInfo->Projects[ProjectNo].ProjectID=getpid();//����������Ϣ
	printf("Starting jLedTask ..........%d\n\r",ProjectNo);
	DbgPrintToFile("Starting jLedTask ..........%d",ProjectNo);
	ClearWaitTimes(ProjectNo,JProgramInfo);
	//��ʼ������
	sa1.sa_handler = QuitProcess;
	sigemptyset(&sa1.sa_mask);
	sa1.sa_flags = 0;
	sigaction(SIGTERM, &sa1,NULL);
	sigaction(SIGSYS, &sa1,NULL);
	sigaction(SIGPWR, &sa1,NULL);
	sigaction(SIGKILL, &sa1,NULL);
	sigaction(SIGQUIT, &sa1,NULL);
	sigaction(SIGILL, &sa1,NULL);
	sigaction(SIGINT, &sa1,NULL);
	sigaction(SIGHUP, &sa1,NULL);
	sigaction(SIGABRT, &sa1,NULL);
	sigaction(SIGBUS, &sa1,NULL);
	LedInit();

	Ledcom4852(1);
	LedGPRSu33(1);
	delay(1000);
	//LedGPRS(0);
	Ledcom4852(0);
	//Ledcom4853(0);
	LedGPRSu33(0);

	//485�����˸ʱ����ʾģ��������ݣ��̵���˸ʱ����ʾģ�鷢�����ݡ�
	//LINK�� ��̫��״ָ̬ʾ�ƣ���ɫ����ʾ��̫���ڳɹ��������Ӻ�LINK�Ƴ�����
	//DATA�� ��̫������ָʾ�ƣ���ɫ����̫�����������ݽ���ʱ��DATA����˸��
	AlarmCode=0;
	TSGet(&ts);
	TSGet(&ts2);
	//JProgramInfo->stateflags.ErcFlg=1;
	InitADC();
	counter = 0;
	BatIO = mmap_device_io(0x10,0x40048008);//����
	OutIO = mmap_device_io(0x10,0x40048048);//��ȡ
	while(1)
	{
		count++;
		if(count%90==0)
		{
			count=0;
			DoADC();
		}
		State485_1=JProgramInfo->Para.State485_1;
		State485_2=JProgramInfo->Para.State485_2;
		State485_3=JProgramInfo->Para.State485_3;
		if (JProgramInfo->stateflags.ErcFlg>=1)
		{
			//printf("\nJProgramInfo->stateflags.ErcFlg  %d\n",JProgramInfo->stateflags.ErcFlg);
			TSGet(&ts);
			if (AlarmCode==0)
				ts2=ts;
			AlarmCode=1;
		}
		else AlarmCode=0;

		ClearWaitTimes(ProjectNo,JProgramInfo);
	   if (jLedPrint == 0)
	   {
		   if ((JProgramInfo->mainData.Prt_Flag==7) || (JProgramInfo->mainData.Prt_Flag==50))
			  jLedPrint = 3;
	   }
	   else
	   {
		   if ((JProgramInfo->mainData.Prt_Flag==107) || (JProgramInfo->mainData.Prt_Flag==150))
			  jLedPrint = 0;
	   }
		//LedGPRS(StateGPRS);
	    if (State485_1>0)
	    {
			SdPrint("State485=%d\n\r",State485_1);
	    	Ledcom4852(State485_1);
			delay(100);
	    }
	    if (State485_2>0)
	    {
			SdPrint("State485=%d\n\r",State485_2);
	    	Ledcom4852(State485_2);
			delay(100);
	    }
	    if (State485_3>0)
	    {
			SdPrint("State485=%d\n\r",State485_3);
	    	Ledcom4852(State485_3);
			delay(100);
	    }

		LedGPRSu33(AlarmCode|ADC_Alarm);
		JProgramInfo->Para.StateGPRS=0;
		JProgramInfo->Para.State485_1=0;
		JProgramInfo->Para.State485_2=0;
		JProgramInfo->Para.State485_3=0;

		if (JProgramInfo->stateflags.ErcFlg>=1)
		{
			//�и澯���ҳ���10�룬����澯
			if (((ts.Sec + 60 - ts2.Sec)%60) > 10)
			{
				//printf("\n---����10��------��JProgramInfo->stateflags.ErcFlg %d-------\n",JProgramInfo->stateflags.ErcFlg);
				JProgramInfo->stateflags.ErcFlg=0;
			}
		}
		//JProgramInfo->AlmFile.AlarmCode=0;
		delay(300);
		//LedGPRS(0);
		Ledcom4852(0);
		//LedGPRSu33(0);
		delay(100);
	}
	QuitProcess(0);
 	return EXIT_SUCCESS;
}
name_attach_t  *attach;
//����ע��,��ȡ����źͳ�������
INT8U GetProjects(INT32S argc, char * argv[]) {
	char proc_name[32] = "";

	if (argc < 2)
		return (FALSE);
	ProjectNo = atoi(argv[1]);
#ifdef __linux__
	sprintf(proc_name, "%s", argv[0]);
#else
	sprintf(proc_name, "%s %d", argv[0], ProjectNo);
#endif
//   if((attach=name_attach(NULL, proc_name,0))  == NULL)
//   {
//	   printf( "ERR:'%s' runed,cann't regist\n\r", proc_name);
//	   return (FALSE);
//   }
	return (TRUE);
}

//�˳�����
void QuitProcess(int signo)
{
	delay(100);
	JProgramInfo->Projects[ProjectNo].ProjectID=0;
   	printf("\n\r jLedTask quit xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n\r");
   	if (jLedPrint==2)
	{
	   fclose(fp);
	   fp=NULL;
	}
   	exit(0);
}



