#ifndef InitH
#define InitH
//#include <stdlib.h>
//#include <stdio.h>
//#include <unistd.h>
//#include <stdint.h>
#ifdef __linux__
#include <sys/io.h>
#endif
//#include <sys/dispatch.h>
//#include <sys/neutrino.h>
//#include <sys/netmgr.h>
//#include <sys/iofunc.h>
//extern JMemory *Jmemory;


#ifdef __linux__
extern unsigned int mmap_device_io(unsigned int len, unsigned int paddr);
extern int munmap_device_io(unsigned int vaddr, unsigned int len);


static __inline__ unsigned long int __attribute__ ((__unused__)) in32 (unsigned long int __port)
{
	return inl(__port);
}

static __inline__ void __attribute__((__unused__))
out32(unsigned int __addr, unsigned int __data) {
	*(unsigned int *) __addr = __data;
}
static __inline__ void __attribute__((__unused__))
out8(unsigned int __addr, unsigned char __data) {
	*(unsigned char *) __addr = __data;
}
//extern void out32 ( unsigned long int __port,unsigned long __value);
//extern void in32 (unsigned long int __port);
extern char* itoa(int value, char*  str, int radix);
#endif
#endif /*InitH*/

