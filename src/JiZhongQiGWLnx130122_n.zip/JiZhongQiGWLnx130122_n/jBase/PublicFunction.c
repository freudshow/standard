#ifndef JPublicFunctionH
#define JPublicFunctionH
#include "stdio.h"
#include "zlib.h"
#include "errno.h"
#include "time.h"
//#include <hw/inout.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <string.h>
#include <strings.h>
#include "inc/CVariable.h"
#include "inc/DataGroups.h"
#include "inc/jMemory.h"
#include "inc/pubfunction.h"
#include <stdlib.h>
#include <termios.h>
#include <ctype.h>
#include <unistd.h>
#include <sys/mman.h>
#include <semaphore.h>
#include <stdarg.h>
#include "../j3761_2009/j3761_2009.h"

//JMemory *Jmemory;//�ڴ湲��������ָ��
//ParamInfo3761* JParamInfo3761;
//DataFileInfo*  JDataFileInfo;
//ConfigInfo*    JConfigInfo;
//ProgramInfo* JProgramInfo;

//TaskInfo sd_NowTask;
extern INT8U ProjectNo;
const INT8U _VERSION[] = {"VER-STRING-FLG=13.01"__DATE__" "__TIME__ };//1.01 ��ʽXXXX.XX����Ҫ�ı�
INT8U CreateMem();//�����������������ڴ�
INT8U OpenMem();//�򿪹����ڴ�
//void ClearWaitTimes(INT8U ProjectID,ProgramInfo* JProgramInfo);//���������ȴ��ӳ���ʱ��
void printString(unsigned char *str, unsigned char Count, unsigned char flg);
int IsEqual(TS *ts0, TS *ts1);//����������
void TimeAdd(TS *ts, INT16U unit, int step);//ʱ���

void setVersion(INT8U flag,ParamInfo3761* JParamInfo3761,ProgramInfo* JProgramInfo,ConfigInfo*  JConfigInfo)
{
	JConfigInfo->jzqpara.ver.SoftVer[0] = '1';
	JConfigInfo->jzqpara.ver.SoftVer[1] = '3';
	JConfigInfo->jzqpara.ver.SoftVer[2] = '0';
	JConfigInfo->jzqpara.ver.SoftVer[3] = '1';

	JConfigInfo->jzqpara.ver.HardVer[0] = '1';
	JConfigInfo->jzqpara.ver.HardVer[1] = '3';
	JConfigInfo->jzqpara.ver.HardVer[2] = '0';
	JConfigInfo->jzqpara.ver.HardVer[3] = '0';

	JConfigInfo->jzqpara.ver.FactNo[0]='G';
	JConfigInfo->jzqpara.ver.FactNo[1]='K';

	JConfigInfo->jzqpara.ver.SoftDate[0]=0x20;
	JConfigInfo->jzqpara.ver.SoftDate[1]=0x01;
	JConfigInfo->jzqpara.ver.SoftDate[2]=0x13;

	JConfigInfo->jzqpara.ver.HardDate[0]=0x01;
	JConfigInfo->jzqpara.ver.HardDate[1]=0x01;
	JConfigInfo->jzqpara.ver.HardDate[2]=0x13;

	JConfigInfo->jzqpara.ver.ProtVer[0]='3';
	JConfigInfo->jzqpara.ver.ProtVer[1]='7';
	JConfigInfo->jzqpara.ver.ProtVer[2]='6';
	JConfigInfo->jzqpara.ver.ProtVer[3]='1';

}

//��ʼ����������Ϣ CommFlg 1 ͨ�Ų�������
void InitjzqInfo(int CommFlg,ParamInfo3761* JParamInfo3761,ProgramInfo* JProgramInfo,ConfigInfo*  JConfigInfo,DataFileInfo*  JDataFileInfo)
{
	int i=0,j=0;
	JParamInfo3761->group1.f1.RTS=5;
	JParamInfo3761->group1.f1.Allow_Delay=0;
	JParamInfo3761->group1.f1.DelayTime_AgainNum=0x301E;
//	fprintf(stderr,"\n\n\n\n");
//	fprintf(stderr,"\nJParamInfo3761->group1.f1.DelayTime_AgainNum = %x\n",JParamInfo3761->group1.f1.DelayTime_AgainNum);
	JParamInfo3761->group1.f1.NeedAllow=0x07;
	if(((JProgramInfo->zone)&0x7f) == TIANJIN)
		JParamInfo3761->group1.f1.HeartInterval=30;
	else
		JParamInfo3761->group1.f1.HeartInterval=5;
	JProgramInfo->BoardElecState=1;
//	jzqinfo_so->InitFlg=0;
	memset(&JParamInfo3761->group1.f2,0x00,sizeof(F2));
	if (CommFlg != 1)
	{
		memset(JParamInfo3761->group1.f3.IP, 0x00, 4); //*ͨ�ŵ�ַ�Ͷ˿� ip and port and ͨ������ * ���ŵ�ͨѶ����/
		memset(JParamInfo3761->group1.f3.PortAddress, 0x00, 2);
		memset(JParamInfo3761->group1.f3.IP1, 0x00, 4); //*ͨ�ŵ�ַ�Ͷ˿� ip and port and ͨ������ * ���ŵ�ͨѶ����/
		memset(JParamInfo3761->group1.f3.PortAddress1, 0x00, 2);
		memset(JParamInfo3761->group1.f3.APN, 0x00, 16); //*ע�����! 0xff,0xff,...0xff,apn*/
		JParamInfo3761->group1.f3.APN[15] = 'C';
		JParamInfo3761->group1.f3.APN[14] = 'M';
		JParamInfo3761->group1.f3.APN[13] = 'N';
		JParamInfo3761->group1.f3.APN[12] = 'E';
		JParamInfo3761->group1.f3.APN[11] = 'T';

		//memset(jzqinfo_so->Area_8016.JZ_XingZhuangQuHaoMa, 0xff, 2);//����������������//����������������
		//memset(jzqinfo_so->Address_8017.JZ_di_zhi, 0xff, 2);/*��������ַ */
		memset(JParamInfo3761->group5.f36.Flow,0x00,4);

		memset(JParamInfo3761->group1.f7.IP,0x00,4);
		memset(JParamInfo3761->group1.f7.SubnetAddresses,0x00,4);
		memset(JParamInfo3761->group1.f7.GateWay,0x00,4);
		JParamInfo3761->group1.f7.SubstituteType=0;			        //��������������
	    memset(JParamInfo3761->group1.f7.SubstituteIP,0x00,4);		//������������ַ
		memset(JParamInfo3761->group1.f7.SubstitutePort,0x00,2);		//�����������˿�
		JParamInfo3761->group1.f7.SubstituteConnetType=0;		        //�������������ӷ�ʽ
		JParamInfo3761->group1.f7.UserLen=0;					        //�û�������
		memset(JParamInfo3761->group1.f7.UserName,0x00,20);;			//�û���
		JParamInfo3761->group1.f7.PassLen=6;					        //���볤��
		//printf("\nJmemory->TianJing ======= %d\n",Jmemory->TianJing);
//		if(Jmemory->TianJing == 1)
		if(((JProgramInfo->zone)&0x7f) == TIANJIN)
		{
			//printf("\nJmemory->TianJing == 1\n");
			JParamInfo3761->group1.f7.PassWords[0]=0x11;
			JParamInfo3761->group1.f7.PassWords[1]=0x11;
			JParamInfo3761->group1.f7.PassWords[2]=0x11;
		}else
		{
			//printf("\nJmemory->TianJing != 1\n");
 			memset(JParamInfo3761->group1.f7.PassWords,0x00,20);			//����
			//JParamInfo3761->group1.f7.PassWords[2]=0x10;                  //�Ϻ���������ʼ��������Ϊ000000  lcy2013
		}
		memset(JParamInfo3761->group1.f7.WatchPort,0x00,2);			//�ն������˿�

		JParamInfo3761->group1.f8.Type=0x11;					//����ģʽ	//lhl1.12
		memset(JParamInfo3761->group1.f8.Interval,0x00,2);	//�������ߡ�ʱ������ģʽ�ز���� ��
		JParamInfo3761->group1.f8.Num=0;						//��������ģʽ�ز�����
		JParamInfo3761->group1.f8.ShutDown=0;					//��������ģʽ������ͨ���Զ�����ʱ��
		memset(JParamInfo3761->group1.f8.Flag,0xFF,3);		//ʱ������ģʽ��������ʱ�α�־
	}
	memset(JParamInfo3761->group1.f4.ZZ,0x00,8);
	memset(JParamInfo3761->group1.f4.SM,0x00,8);
	JParamInfo3761->group1.f5.XiaoXi_Renzheng_FangAN=0;
	memset(JParamInfo3761->group1.f5.CanShu,0x00,2);
	memset(JParamInfo3761->group1.f6.GroupAdress0,0x00,2);
	memset(JParamInfo3761->group1.f6.GroupAdress1,0x00,2);
	memset(JParamInfo3761->group1.f6.GroupAdress2,0x00,2);
	memset(JParamInfo3761->group1.f6.GroupAdress3,0x00,2);
	memset(JParamInfo3761->group1.f6.GroupAdress4,0x00,2);
	memset(JParamInfo3761->group1.f6.GroupAdress5,0x00,2);
	memset(JParamInfo3761->group1.f6.GroupAdress6,0x00,2);
	memset(JParamInfo3761->group1.f6.GroupAdress7,0x00,2);

	memset(JParamInfo3761->group2.f9.Flag,0x00,8);
	JParamInfo3761->group2.f9.Flag[0]=0x00;  //ERC
	JParamInfo3761->group2.f9.Flag[1]=0x20;  //ERC14
	JParamInfo3761->group2.f9.Flag[2]=0x00;  //ERC
	JParamInfo3761->group2.f9.Flag[3]=0x80;  //ERC32
	JParamInfo3761->group2.f9.Flag[4]=0x00;  //ERC
	memset(&JParamInfo3761->group2.f9.FlagStep,0x00,8);
	memset(&JParamInfo3761->group2.f12,0x00,sizeof(F12));
	memset(&JParamInfo3761->group2.f14,0x00,sizeof(F14));
	memset(&JParamInfo3761->group2.f15,0x00,sizeof(F15));
	memset(JParamInfo3761->group2.f16.UserName,0x00,16);
	memset(JParamInfo3761->group2.f16.PassWord,0x00,16);
	memcpy(JParamInfo3761->group2.f16.UserName,"CMNET",5);
	memcpy(JParamInfo3761->group2.f16.PassWord,"CMNET",5);
	memset(&JParamInfo3761->group3.f23.Allow,0x00,3);
	memset(&JParamInfo3761->Point[0].f31,0x00,sizeof(F31));
	//JParamInfo3761->group5.f33.Count=0;
	for (i=0;i<CommPortMax;i++)
	{
		JParamInfo3761->group5.f33.f33[i].port=0;
		//memset(JParamInfo3761->group5.f33.f33[i].CtrlZ,0x00,2);
		JParamInfo3761->group5.f33.f33[i].CtrlZ[1]=0;
		JParamInfo3761->group5.f33.f33[i].CtrlZ[0]=0x01;
		memset(JParamInfo3761->group5.f33.f33[i].CbDate,0x00,4);
		memset(JParamInfo3761->group5.f33.f33[i].CbTime,0x00,2);
		JParamInfo3761->group5.f33.f33[i].CbInter=60;
		memset(JParamInfo3761->group5.f33.f33[i].XbTime,0x00,3);
		JParamInfo3761->group5.f33.f33[i].TimeCnt=1;
		for(j=0;j<24;j++)
		{
			memset(JParamInfo3761->group5.f33.f33[i].StTime[j],0x00,2);
			memset(JParamInfo3761->group5.f33.f33[i].EdTime[j],0x00,2);
		}

	}

	JParamInfo3761->group5.f37.Port=0;
	JParamInfo3761->group5.f37.CtrlZ=0;
	JParamInfo3761->group5.f37.RPackTime=0;
	JParamInfo3761->group5.f37.RByteTime=0;
	JParamInfo3761->group5.f37.RetryCnt=0;
	JParamInfo3761->group5.f37.Period=0;
	JParamInfo3761->group5.f37.FlagCnt=0;
	for (i=0;i<CascadeMax;i++)
	{
		memset(JParamInfo3761->group5.f37.AreaCode[i],0x00,2);
		memset(JParamInfo3761->group5.f37.TermAddr[i],0x00,2);
	}
	memset(&JParamInfo3761->group5.f38,0x00,sizeof(F38_39));
	memset(&JParamInfo3761->group5.f39,0x00,sizeof(F38_39));
	memset(&JParamInfo3761->group8.f57,0x00,sizeof(F57));
	memset(&JParamInfo3761->group8.f59,0x00,sizeof(F59));


	memset(JConfigInfo->jzqpara.ver.FactNo,0x00,4);
	JConfigInfo->jzqpara.ver.FactNo[0]='Z';
	JConfigInfo->jzqpara.ver.FactNo[1]='K';
	memset(JConfigInfo->jzqpara.ver.DevNo,0x00,8);
	JConfigInfo->jzqpara.ver.DevNo[0]='Z';
	JConfigInfo->jzqpara.ver.DevNo[1]='0';
	JConfigInfo->jzqpara.ver.DevNo[2]='0';
	JConfigInfo->jzqpara.ver.DevNo[3]='0';
	JConfigInfo->jzqpara.ver.DevNo[4]='0';
	JConfigInfo->jzqpara.ver.DevNo[5]='0';
	JConfigInfo->jzqpara.ver.DevNo[6]='1';
//	fprintf(stderr,"\n JConfigInfo->jzqpara.ver.SoftVer: %02x %02x %02x %02x  initjzq(0)",
//			JConfigInfo->jzqpara.ver.SoftVer[0],
//			JConfigInfo->jzqpara.ver.SoftVer[1],
//			JConfigInfo->jzqpara.ver.SoftVer[2],
//			JConfigInfo->jzqpara.ver.SoftVer[3]);
	memset(JConfigInfo->jzqpara.ver.SoftVer,0x00,5);
	JConfigInfo->jzqpara.ver.SoftVer[0]='0';
	JConfigInfo->jzqpara.ver.SoftVer[1]='1';
	JConfigInfo->jzqpara.ver.SoftVer[2]='0';
	JConfigInfo->jzqpara.ver.SoftVer[3]='1';
	memset(JConfigInfo->jzqpara.ver.SoftDate,0x00,3);
	JConfigInfo->jzqpara.ver.SoftDate[0]=0x12;
	JConfigInfo->jzqpara.ver.SoftDate[1]=0x03;
	JConfigInfo->jzqpara.ver.SoftDate[2]=0x10;
	memset(JConfigInfo->jzqpara.ver.ProtVer,0x00,4);
	JConfigInfo->jzqpara.ver.ProtVer[0]='3';
	JConfigInfo->jzqpara.ver.ProtVer[1]='7';
	JConfigInfo->jzqpara.ver.ProtVer[2]='6';
	JConfigInfo->jzqpara.ver.ProtVer[3]='1';
	memset(JConfigInfo->jzqpara.ver.HardVer,0x00,4);
	JConfigInfo->jzqpara.ver.HardVer[0]='0';
	JConfigInfo->jzqpara.ver.HardVer[1]='1';
	JConfigInfo->jzqpara.ver.HardVer[2]='0';
	JConfigInfo->jzqpara.ver.HardVer[3]='0';
	memset(JConfigInfo->jzqpara.ver.HardDate,0x00,3);
	JConfigInfo->jzqpara.ver.HardDate[0]=0x12;
	JConfigInfo->jzqpara.ver.HardDate[1]=0x03;
	JConfigInfo->jzqpara.ver.HardDate[2]=0x10;
	memset(JConfigInfo->jzqpara.ver.SetInf,0x00,11);
	JConfigInfo->jzqpara.ver.SetInf[0]='3';
	JConfigInfo->jzqpara.ver.SetInf[1]='2';
	JConfigInfo->jzqpara.ver.SetInf[2]='M';
	if (CommFlg != 1)
	{
		for(i=0;i<R485Max;i++)
		{
			JDataFileInfo->data485[i].ts.Year=1999;
			JDataFileInfo->data485[i].ts.Month=01;
			JDataFileInfo->data485[i].ts.Day=01;
			JDataFileInfo->data485[i].ts.Hour=0;
			JDataFileInfo->data485[i].ts.Minute=0;
			JDataFileInfo->data485[i].ts.Sec=0;
			JDataFileInfo->data485[i].Flag=0;
		}
		//jzqinfo_so->CurHourFile = 0x25;
		//jzqinfo_so->CurDayFile = 0x00; //��ǰ�������Ƿ��Ѿ���ȡ��
		//jzqinfo_so->CurMonthFile = 0x00; //��ǰ�������Ƿ��Ѿ���ȡ��
		JProgramInfo->ExcuteNo = 1;
		JConfigInfo->jzqpara.DevFlg = 1;
	}
	//�ɼ�����Ϣ
//	for(i=0;i<McollectionMaxCount;i++)
//	{
////		Jmemory->caiJiQiInfo.cjqInfo[i].Status=0;
//		cjqinfo_so->cjqInfo[i].Status=0;
//	}
//	memset(Jmemory->ErcEvt.ImpEvent,0x00,sizeof(ERC));
//	memset(Jmemory->ErcEvt.NorEvent,0x00,sizeof(ERC));
	memset(JDataFileInfo->ErcEvt.ImpEvent,0x00,sizeof(ERC));
	memset(JDataFileInfo->ErcEvt.NorEvent,0x00,sizeof(ERC));
	JDataFileInfo->ErcEvt.EC1=0;
	JDataFileInfo->ErcEvt.EC2=0;
	JDataFileInfo->ErcEvt.EC1old=0;
	JDataFileInfo->ErcEvt.EC2old=0;
	for(i=0;i<8;i++)
		JDataFileInfo->ErcEvt.ERCBiaoZhi[i]=0x00;
	JConfigInfo->jzqpara.CommStat=0x5;
	JProgramInfo->PowerOnMessage=0;
	JProgramInfo->PowerOFFMessage=0;
//	Jmemory->mainData.Time_Flag=100;
	JProgramInfo->Update_Time=80;
	JProgramInfo->YxChange=0;
	JParamInfo3761->group3.f21.FLNum=4;
	//for(i=0;i<48;i++)
		//jzqinfo_so->f21.FLTime[i]=1;

	if(((JProgramInfo->zone)&0x7f) == JIANGSU)
	{
		JParamInfo3761->group2.f9.Flag[1] = JParamInfo3761->group2.f9.Flag[1] | 0x20;		//����ͣ�ϵ��¼�Ĭ����Ч
		JParamInfo3761->group2.f9.FlagStep[1]=JParamInfo3761->group2.f9.FlagStep[1] |0x20;  //����ͣ�ϵ�ʱ��Ĭ��Ϊ��Ҫ�¼�
	}

}
//�������Ĳ���
void SaveMeterPara2(int flg,ParamInfo3761* JParamInfo3761,ProgramInfo* JProgramInfo)
{
	int i;
	INT8U TempBuf[60];
	memset(TempBuf,0,60);
	sprintf((char*)TempBuf,"%s/AmmeterOth.par",_PARADIR_);
	NormalSaveFile((char*)TempBuf,(INT8U *)&JParamInfo3761->group5.f34,sizeof(F34)+sizeof(F35),JProgramInfo);
	memset(TempBuf,0,60);
	sprintf((char*)TempBuf,"%s/AmmeterN.par",_PARADIR_);
	NormalSaveFile((char*)TempBuf,(INT8U *)JParamInfo3761,sizeof(ParamInfo3761),JProgramInfo);
	if (flg>PointMax)
	{
		for(i=0;i<PointMax;i++)
		{
//			if (JParamInfo3761->Point[i].f10.Status!=1)
//				continue;
			if ((i%SaveNum)==0)
			{
				memset(TempBuf,0,60);
				sprintf((char*)TempBuf,"%s/Ammeter%04d.par",_PARADIR_,(i/SaveNum)+1);
				NormalSaveFile((char*)TempBuf,(INT8U *)&JParamInfo3761->Point[i-(i%SaveNum)],sizeof(JParamInfo3761->Point[i-(i%SaveNum)])*SaveNum,JProgramInfo);
				delay(10);
			}
		}
	}
	else
	{
			memset(TempBuf,0,60);
			sprintf((char*)TempBuf,"%s/Ammeter%04d.par",_PARADIR_,((flg-1)/SaveNum)+1);

			NormalSaveFile((char*)TempBuf,(INT8U *)&JParamInfo3761->Point[flg-1-((flg-1)%SaveNum)],sizeof(JParamInfo3761->Point[flg-1-((flg-1)%SaveNum)])*SaveNum,JProgramInfo);
			delay(10);
	}
	delay(50);
}
//��ʼ�������Ϣ
void readjzqmeter(ParamInfo3761* JParamInfo3761)//��ȡ���������ɱ���ַ ��jzqmeter.cfg��
{
		int addr[6];
		FILE *fpcomm = NULL;
		INT8U TempBuf[60];
		memset(TempBuf, 0, 60);
		sprintf((char *) TempBuf, "%s/jzqmeter.cfg", _CFGDIR_);
		fpcomm = fopen((char *) TempBuf, "r");

		if (fpcomm!=NULL)
		{
			JParamInfo3761->group2.f10[0].Status=1;
			JParamInfo3761->group2.f10[0].ConnectType=2;
			JParamInfo3761->group2.f10[0].Type=3;

			fscanf(fpcomm,"%02x-%02x-%02x-%02x-%02x-%02x",
					 &addr[5],&addr[4],&addr[3],&addr[2],&addr[1],&addr[0]);

			JParamInfo3761->group2.f10[0].Address[5] = (INT8U)addr[5];
			JParamInfo3761->group2.f10[0].Address[4] = (INT8U)addr[4];
			JParamInfo3761->group2.f10[0].Address[3] = (INT8U)addr[3];
			JParamInfo3761->group2.f10[0].Address[2] = (INT8U)addr[2];
			JParamInfo3761->group2.f10[0].Address[1] = (INT8U)addr[1];
			JParamInfo3761->group2.f10[0].Address[0] = (INT8U)addr[0];
			fclose(fpcomm);
			fpcomm = NULL;
//			fprintf(stderr,"\n !!!addr:%02x%02x%02x%02x%02x%02x"
//					,JParamInfo3761->group2.f10[0].Address[5]
//					,JParamInfo3761->group2.f10[0].Address[4]
//       			,JParamInfo3761->group2.f10[0].Address[3]
//					,JParamInfo3761->group2.f10[0].Address[2]
//					,JParamInfo3761->group2.f10[0].Address[1]
//					,JParamInfo3761->group2.f10[0].Address[0]);
		}else
		{
			JParamInfo3761->group2.f10[0].Status=1;
			JParamInfo3761->group2.f10[0].ConnectType=2;
			JParamInfo3761->group2.f10[0].Type=3;
			memset(JParamInfo3761->group2.f10[0].Address,0x00,6);
			JParamInfo3761->group2.f10[0].Address[0] = 0x01;
		}
		//SaveMeterPara2(PointMax+1);
}

//��ʼ�������Ϣ
void InitMeterInfo(ParamInfo3761* JParamInfo3761)
{
	int j = 0,i=0,tmp=0;
	//memset(pointinfo_so->f10.Count,0x00,2);
//	memset(&Jmemory->Points,0x00,sizeof(Jmemory->Points));
	memset(&JParamInfo3761->Point,0x00,sizeof(Group4));
	for (j = 0; j < PointMax; j++)//��������Ϣ
	{
		//memset(JParamInfo3761->group2.f10[j].Index,j,2);
		//memset(JParamInfo3761->group2.f10[j].PointIndex,0x00,2);
		JParamInfo3761->group2.f10[j].ConnectType=30;			//ͨ��Э������ 1 97 30 2007
		memset(JParamInfo3761->group2.f10[j].Address,0x00,6);			//ͨ�ŵ�ַ
		memset(JParamInfo3761->group2.f10[j].PassWord,0x00,6);			//ͨ������
		JParamInfo3761->group2.f10[j].FeiLvCnt=4;				//���ܷ��ʸ���
		JParamInfo3761->group2.f10[j].DecimalDigits=1;		//�й�����ʾֵ����λ��С��λ����
		memset(JParamInfo3761->group2.f10[j].CaijiqiAddress,0x00,6);	//�����ɼ���ͨ�ŵ�ַ
		JParamInfo3761->group2.f10[j].UserType=0;				//�û�����ż��û�С���
		JParamInfo3761->group2.f10[j].baudrate=0x08;				//SD������
		if(j == 0)
			JParamInfo3761->group2.f10[j].port=1;	//����  yangdong
		else
			JParamInfo3761->group2.f10[j].port=1+PortBegNum;					//SD�˿ں�
		JParamInfo3761->group2.f10[j].jiao_yan_wei=0x01;			//SDУ��λ
		JParamInfo3761->group2.f10[j].shu_ju_wei=0x08;			//SD����λ
		JParamInfo3761->group2.f10[j].ting_zhi_wei=0x01;			//SDֹͣλ
		for(i=0;i<64;i++)
			JParamInfo3761->group2.f10[j].AlarmFlg[i]=0x00;
		JParamInfo3761->group2.f10[j].Status=0;				//SD״̬

		JParamInfo3761->group2.f10[j].CjqNo=j/64+1;				//SD�ɼ���
		JParamInfo3761->group2.f10[j].MeterNo=j%64;			//SD�������
		JParamInfo3761->group2.f10[j].FirRead=0;
		JParamInfo3761->group2.f10[j].Type=9;
		tmp=1;
		JParamInfo3761->Point[j].f25.V_BeiLv[0]=1;
		JParamInfo3761->Point[j].f25.I_BeiLv[0]=1;
		memset(JParamInfo3761->group2.f10[j].PointIndex,0x00,2);
		JParamInfo3761->group2.f10[j].PointIndex[0]=(j+1)&0xff;
		JParamInfo3761->group2.f10[j].PointIndex[1]=((j+1)>>8)&0xff;
	}
	readjzqmeter(JParamInfo3761);
//	if (ACSMPFLG==1)
//	{
//		JParamInfo3761->group2.f10[0].Status=1;
//		JParamInfo3761->group2.f10[0].ConnectType=2;
//		JParamInfo3761->Point[0].f25.Type=3;
////		memset(JParamInfo3761->group2.f10[j].Address,0x00,6);
////		JParamInfo3761->group2.f10[j].Address[0] = 0x01;//?????????????
//		memset(JParamInfo3761->group2.f10[0].Address,0x00,6);
//		JParamInfo3761->group2.f10[0].Address[0] = 0x01;
//	}

	memset(&JParamInfo3761->group5.f34,0x00,sizeof(F34));
	JParamInfo3761->group5.f35.Count=0;
	memset(JParamInfo3761->group5.f34.Module,0x00,sizeof(F34)-1);

}

//��ʼ��������Ϣ
void InitTaskInfo(ParamInfo3761* JParamInfo3761,ProgramInfo* JProgramInfo)
{
	int i = 0, j = 0;
	//printf("InitTaskInfo 0000000000000000000000000000\n");
	for (i = 0; i < Task1_Max; i++)
	{
		JParamInfo3761->group9.f67[i].IsRun=0xAA;
		JParamInfo3761->group9.f65[i].Interval=0;
		memset(JParamInfo3761->group9.f65[i].Post_Time,0,6);
		JParamInfo3761->group9.f65[i].Post_Time[0]=0x00;
		JParamInfo3761->group9.f65[i].Post_Time[1]=0x00;
		JParamInfo3761->group9.f65[i].Post_Time[2]=0x00;
		JParamInfo3761->group9.f65[i].Post_Time[3]=0x01;
		JParamInfo3761->group9.f65[i].Post_Time[4]=0x01;
		JParamInfo3761->group9.f65[i].Post_Time[5]=0x00;
		JParamInfo3761->group9.f65[i].R=1;
		JParamInfo3761->group9.f65[i].Count=0;
		for(j=0;j<ItemCount;j++)
			memset(JParamInfo3761->group9.f65[i].Flag[j],0,4);
		JProgramInfo->task1_Delay_Count[i]=0;
	}
	for (i = 0; i < Task2_Max; i++)
	{
		JParamInfo3761->group9.f68[i].IsRun=0xAA;
		JParamInfo3761->group9.f66[i].Interval=0;
		memset(JParamInfo3761->group9.f66[i].Post_Time,0,6);
		JParamInfo3761->group9.f66[i].Post_Time[0]=0x00;
		JParamInfo3761->group9.f66[i].Post_Time[1]=0x00;
		JParamInfo3761->group9.f66[i].Post_Time[2]=0x00;
		JParamInfo3761->group9.f66[i].Post_Time[3]=0x01;
		JParamInfo3761->group9.f66[i].Post_Time[4]=0x01;
		JParamInfo3761->group9.f66[i].Post_Time[5]=0x00;
		JParamInfo3761->group9.f66[i].R=1;
		JParamInfo3761->group9.f66[i].Count=0;
		for(j=0;j<ItemCount;j++)
			memset(JParamInfo3761->group9.f66[i].Flag[j],0,4);
		JProgramInfo->task2_Delay_Count[i]=0;
	}
}

INT16U getPoint(INT8U group,INT8U meterno)
{
	return group*64+meterno;
}


int uart_setup(int ComPort, INT16U baud, INT8U *par, INT8U stopb, INT8U bits)
{
	struct termios old_termi, new_termi;

	if (tcgetattr(ComPort, &old_termi) != 0) /*�洢ԭ��������*/
	{
		/*��ȡ�ն���ز���ʱ����*/
		exit(EXIT_FAILURE);
	}
	bzero(&new_termi,sizeof(new_termi)); /*���ṹ������*/
	new_termi.c_cflag |= (CLOCAL | CREAD); /*���Ե��ƽ����״̬�У�����ʹ��*/
	new_termi.c_lflag &= ~(ICANON | ECHO | ECHOE); /*ѡ��Ϊԭʼ����ģʽ*/
	new_termi.c_oflag &= ~OPOST; /*ѡ��Ϊԭʼ���ģʽ*/
	new_termi.c_cc[VTIME] = 5; /*���ó�ʱʱ��Ϊ0.5 s*/
	new_termi.c_cc[VMIN] = 0; /*���ٷ��ص��ֽ����� 7*/
	cfsetispeed(&new_termi, baud); /* �������벦���� */
	cfsetospeed(&new_termi, baud); /* ������������� */
	new_termi.c_cflag &= (~CSIZE); /* ��������λ��,8λ���� */
	switch (bits) {
		case 5:
			new_termi.c_cflag |= CS5;
			break;
		case 6:
			new_termi.c_cflag |= CS6;
			break;
		case 7:
			new_termi.c_cflag |= CS7;
			break;
		case 8:
			new_termi.c_cflag |= CS8;
			break;
	}

	if (strcmp((char *)par, "none") == 0)
		new_termi.c_cflag &= ~PARENB; /*������żУ��Ϊ��У��*/
	if (strcmp((char *)par, "odd") == 0) {
		new_termi.c_cflag |= PARENB;
		new_termi.c_cflag |= PARODD;
	}
	if (strcmp((char *)par, "even") == 0) {
		new_termi.c_cflag |= PARENB;
		new_termi.c_cflag &= ~PARODD;
	}
	new_termi.c_iflag &= ~ISTRIP;
	new_termi.c_cflag &= ~CSTOPB; /*����ֹͣλΪ:һλֹͣλ*/
	tcflush(ComPort, TCIOFLUSH); /* ˢ����������� */

	if (tcsetattr(ComPort, TCSANOW, &new_termi) != 0) /* ��������� */
	{
		exit(EXIT_FAILURE);
	}
	return EXIT_SUCCESS;
}

//���������ȴ��ӳ���ʱ��
void ClearWaitTimes(INT8U ProjectID,ProgramInfo* JProgramInfo)//,ProgramInfo* JProgramInfo
{
	JProgramInfo->Projects[ProjectID].WaitTimes = 0;
}

void markver()//��Ŀ������б�ʶ�����汾��Ϣ
{
	char str[100];
	memset(str,0,100);
	sprintf(str,"\n%s\n", _VERSION);
}

void write_apn(ParamInfo3761* JParamInfo3761,ProgramInfo* JProgramInfo)
{
	FILE *fp = NULL;
	int i,j;
	unsigned char APN[16];
	memset(APN,0,16);
	j=0;
	for(i=0;i<16;i++)
	{
		if ((JParamInfo3761->group1.f3.APN[15-i]!=0xff)&&(JParamInfo3761->group1.f3.APN[15-i]!=0x00))
		{
//			fprintf(stderr,"apn=\n");
//			fprintf(stderr,"%c",JParamInfo3761->group1.f3.APN[15-i]);
			APN[j]=toupper(JParamInfo3761->group1.f3.APN[15-i]);
			j++;
		}
	}
//	fprintf(stderr,"JProgramInfo->gpiGPRS_ID=%d\n",JProgramInfo->gpiGPRS_ID);
	if(JProgramInfo->gpiGPRS_ID == 0x00)
	{//M37i
		struct timespec tsspec;
		if (clock_gettime(CLOCK_REALTIME, &tsspec)==-1)
			printf("clock_gettime error\n\r");
		tsspec.tv_sec += 3;
		sem_timedwait(&JProgramInfo->mainData.UseFileFlg,&tsspec);
		fp=fopen("/etc/ppp/gprs-connect-chat","w");
		if (fp==NULL)
		{
			sem_post(&JProgramInfo->mainData.UseFileFlg);
			return;
		}
		fprintf(fp,"TIMEOUT        5\n");
		fprintf(fp,"ABORT        \'\\nBUSY\\r\'\n");
		fprintf(fp,"ABORT        \'\\nNO ANSWER\\r\'\n");
		fprintf(fp,"ABORT        \'\\nRINGING\\r\\n\\r\\nRINGING\\r\'\n");
		fprintf(fp,"\'\' \\rAT\n");
		fprintf(fp,"TIMEOUT        5\n");
		fprintf(fp,"\'OK-+++\\c-OK\'    ATZ\n");
		fprintf(fp,"TIMEOUT        20\n");
		fprintf(fp,"OK        AT+CFUN=1\n");
		fprintf(fp,"TIMEOUT        5\n");
		fprintf(fp,"OK        AT+CPIN?\n");
		fprintf(fp,"TIMEOUT        5\n");
		fprintf(fp,"OK        AT+CSQ\n");
		fprintf(fp,"TIMEOUT        5\n");
		fprintf(fp,"OK        AT+CGDCONT=1,\"IP\",\"%s\"\n",APN);
		fprintf(fp,"OK        ATDT*99***1#\n");
		fprintf(fp,"CONNECT \'\'\n");
		fclose(fp);
		fp=NULL;
		sem_post(&JProgramInfo->mainData.UseFileFlg);
	}
	else
	{//m590
		fp=fopen("/etc/ppp/gprs-connect-chat","w");
		if (fp==NULL)
			return;
		fprintf(fp,"ABORT        \"BUSY\"\n");
		fprintf(fp,"ABORT        \"NO CARRIER\"\n");
		fprintf(fp,"ABORT        \"NO ANSWER\"\n");
		fprintf(fp,"ABORT        \"NO DIALTONE\"\n");
		fprintf(fp,"ABORT        \"ERROR\"\n");
		//fprintf(fp,"ABORT        \'\\nRINGING\\r\\n\\r\\nRINGING\\r\'\n");
		fprintf(fp,"TIMEOUT        20\n");
		fprintf(fp,"\"\" AT\n");
		fprintf(fp,"OK        AT+CGDCONT=1,\"IP\",\"%s\"\n",APN);
		fprintf(fp,"OK        ATDT*99#\n");
		fprintf(fp,"CONNECT\n");
		fclose(fp);
	}
}
void* Create1ShMem(char* shname,int memsize,void* pmem)
{
	int fd;
	void *memptr;
	#ifdef __linux__
	fd = shm_open(shname, O_RDWR | O_CREAT, 0777);
	#else
	fd = shm_open("/dev/shm/"+shname, O_RDWR | O_CREAT, 0777);
	#endif
	if (fd == -1) {
		fprintf(stderr, "\nERROR: Create share %s memory failed:%s!\n", shname,strerror(errno));
		return NULL;
	}
	if (ftruncate(fd, memsize) == -1) {
		fprintf(stderr, "ltrunc %s: %s\n", shname,strerror(errno));
		return NULL;
	}
	memptr = mmap(0, memsize, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
	if (memptr == MAP_FAILED) {

		fprintf(stderr, "mmap %s failed: %s\n", shname,strerror(errno));
		return NULL;
	}
	close(fd);
	return memptr;
}

//�����������������ڴ�
INT8U CreateMem(ParamInfo3761* j3761mem,DataFileInfo* jDfinfo,ConfigInfo* jConfinfo,ProgramInfo* jPmem)
{
	j3761mem = Create1ShMem("ParamInfo3761",sizeof(ParamInfo3761),NULL);
	if(j3761mem == NULL)
		return -1;

	jDfinfo = Create1ShMem("DataFileInfo",sizeof(DataFileInfo),NULL);
	if(jDfinfo == NULL)
		return -2;

	jConfinfo = Create1ShMem("ConfigInfo",sizeof(ConfigInfo),NULL);
	if(jConfinfo == NULL)
		return -3;

	jPmem = Create1ShMem("ProgramInfo",sizeof(ProgramInfo),NULL);
	if(jPmem == NULL)
		return -3;
	return 0;
}
void* Open1ShMem(char* shname,int memsize,void* pmem)
{
	int fd;

	fd = shm_open(shname, O_RDWR, 0777);
	if (fd == -1) {
		fprintf(stderr, "\nERROR: Open share memory %s failed:%s!\n", shname,strerror(errno));
		return NULL;
	}
	pmem = mmap(0, memsize, PROT_READ | PROT_WRITE, MAP_SHARED, fd,0);
	if (pmem == MAP_FAILED) {
		fprintf(stderr, "mmap %s failed: %s\n",shname, strerror(errno));
		return NULL;
	}
	close(fd);
	return pmem;
}
void *OpenMem1()
{
	ParamInfo3761* j3761mem = NULL;
	j3761mem = Open1ShMem("ParamInfo3761",sizeof(ParamInfo3761),NULL);
	return j3761mem;
}
void *OpenMem2()
{
	DataFileInfo* jDfinfo = NULL;
	jDfinfo = Open1ShMem("DataFileInfo",sizeof(DataFileInfo),NULL);
	return jDfinfo;
}
void *OpenMem3()
{
	ConfigInfo* jConfinfo = NULL;
	jConfinfo = Open1ShMem("ConfigInfo",sizeof(ConfigInfo),NULL);
	return jConfinfo;
}
void *OpenMem4()
{
	ProgramInfo* jPmem = NULL;
	jPmem = Open1ShMem("ProgramInfo",sizeof(ProgramInfo),NULL);
	return jPmem;
}
//���ݱ��浽ָ���ļ�
INT8U NormalSaveFile(char *FileName, void *source, int size,ProgramInfo* JProgramInfo)
{
#ifndef __linux__
	return SaveFile(FileName, source, size);
#endif

	FILE *fp;
	INT8U res;
	int num=0,i;
	//fprintf(stderr,"\n\r%s saved",FileName);
	sem_wait(&JProgramInfo->mainData.UseFileFlg);
	fp = fopen((char*) FileName, "w");
	if (fp != NULL) {
		for(i=0;((i<3)&&(num!=1));i++)
		{
			if (i>0)
				delay(100);
			res = 0;
			fseek(fp, 0, SEEK_SET);
			if((num=fwrite( source, size,1,fp))!=size)
			{
				//printf("WRITE num=%d size=%d\n\r",num,size);
				if (num!=1)
					res = 1;
			}
		}
		if (i>1)
		{
			printf("%s  save failed %d\n\r",FileName,i);
		}
		fclose(fp);
		fp=NULL;
		res = 0;
	} else {
		fprintf(stderr, "%s saved error\n\r", FileName);
		res = 1;
	}
	sem_post(&JProgramInfo->mainData.UseFileFlg);
	return res;
}
//��ȡ���ݵ�ָ��������
INT8U NormalReadFile(char *FileName, void *source, int size,ProgramInfo* JProgramInfo) {
#ifndef __linux__
	return ReadFile(FileName, source, size);
#endif
	FILE *fp;
	INT8U res;
	int num;
	//printf("%s read\n\r",FileName);
	sem_wait(&JProgramInfo->mainData.UseFileFlg);
	//printf("fopen\n\r");
	memset(source, 0xff, size);
	fp = fopen(FileName, "r");
	if (fp != NULL) {
		if (fseek(fp, 0, SEEK_SET)<0)
		{
		}
		res = 0;
		if ((num=fread(source, size,1,fp))!=size)
		{
			//printf("num=%d size=%d\n\r",num,size);
			if (num!=1) res = 1;
		}

		fclose(fp);
		fp=NULL;
	} else {
		fprintf(stderr, "%s read error\n\r", FileName);
		//memset(source, 0, size);
		res = 1;
	}
	sem_post(&JProgramInfo->mainData.UseFileFlg);
	return res;
}

void syscmd(char *cmd,ProgramInfo* JProgramInfo)
{
    struct timespec tsspec;
    if (clock_gettime(CLOCK_REALTIME, &tsspec)==-1)
    	printf("clock_gettime error\n\r");
    tsspec.tv_sec += 3;

	sem_timedwait(&JProgramInfo->mainData.UseFileFlg,&tsspec);
	system(cmd);
	sem_post(&JProgramInfo->mainData.UseFileFlg);
}

//���ݱ��浽ָ���ļ�
INT8U SaveFile(char *FileName, void *source, int size,ProgramInfo* JProgramInfo) {
	FILE *fp;
	INT8U res;
	int num;
	//fprintf(stderr,"\n\r%s saved",FileName);
	sem_wait(&JProgramInfo->mainData.UseFileFlg);
	fp = gzopen((char*) FileName, "w");
	if (fp != NULL) {
		gzseek(fp, 0, SEEK_SET);
		if((num=gzwrite(fp, source, size))!=size)
		{
			printf("WRITE num=%d size=%d\n\r",num,size);
			//res = 1;
		}
		gzclose(fp);
		res = 0;
	} else {
		fprintf(stderr, "%s saved error\n\r", FileName);
		res = 1;
	}
	sem_post(&JProgramInfo->mainData.UseFileFlg);
	return res;
}
//��ȡ���ݵ�ָ��������
INT8U ReadFile(char *FileName, void *source, int size,ProgramInfo* JProgramInfo) {
	FILE *fp;
	INT8U res;
	int num;
	//printf("%s read\n\r",FileName);
	sem_wait(&JProgramInfo->mainData.UseFileFlg);
	//printf("gzopen\n\r");
	memset(source, 0xff, size);
	fp = gzopen(FileName, "r");
	if (fp != NULL) {
		if (gzseek(fp, 0, SEEK_SET)<0)
		{
		}
		res = 0;
		if ((num=gzread(fp, source, size))!=size)
		{
			//printf("num=%d size=%d\n\r",num,size);
			//res = 1;
		}

		gzclose(fp);
	} else {
		fprintf(stderr, "%s read error\n\r", FileName);
		//memset(source, 0, size);
		res = 1;
	}
	sem_post(&JProgramInfo->mainData.UseFileFlg);
	return res;
}

//��ȡʱ��
void TSGet(TS *ts) {
	struct tm tmp_tm;
	time_t time_of_day;
	time_of_day = time(NULL);
	localtime_r(&time_of_day, &tmp_tm);
	ts->Year = tmp_tm.tm_year + 1900;
	ts->Month = tmp_tm.tm_mon + 1;
	ts->Day = tmp_tm.tm_mday;
	ts->Hour = tmp_tm.tm_hour;
	ts->Minute = tmp_tm.tm_min;
	ts->Sec = tmp_tm.tm_sec;
	ts->Week = tmp_tm.tm_wday;
}

void TSSet(TS ts) {
	struct tm tmpsec;
	struct timespec rtime;
	struct timespec cur_time;
	tmpsec.tm_sec = ts.Sec;
	tmpsec.tm_min = ts.Minute;
	tmpsec.tm_hour = ts.Hour;
	tmpsec.tm_mday = ts.Day;
	tmpsec.tm_mon = ts.Month - 1;
	tmpsec.tm_year = ts.Year - 1900;
	rtime.tv_sec = mktime(&tmpsec);
	clock_gettime(CLOCK_REALTIME, &cur_time);
	rtime.tv_nsec = cur_time.tv_nsec;
	clock_settime(CLOCK_REALTIME, &rtime);

}
void printString(unsigned char *str, unsigned char Count, unsigned char flg) {
	int i;
	printf("\n\r");
	for (i = 0; i < Count; i++) {

		if (flg == 1)
			printf(" %d", str[i]);
		else if (flg == 2)
			printf(" %x", str[i]);
		else
			printf(" %s", str);
	}
	printf("\n\r");
}
//��ȡʵʱ����
// GetRealTimeDatas(100,20)��ȴ����룬���0.1��
int GetRealTimeDatas(int interval, int cts,ProgramInfo* JProgramInfo)
{
	//<summary>
	//��ȡʵʱ����
	//</summary>
	//<param name="signo"> ���̺�</param>
	//<returns>0���ɹ���1����ʱ</returns>
	int i,nn;
	nn=0;
	while (JProgramInfo->RealData.ReadFlg != 0)
	{
		ClearWaitTimes(ProjectNo,JProgramInfo);
		delay(100);
		nn++;
		if (nn>50)
		{
			break;
		}
	}
	JProgramInfo->RealData.ReadFlg = 1;
	cts = cts * 4;
	for (i = 0; i < cts; i++) {
		ClearWaitTimes(ProjectNo,JProgramInfo);
		delay(interval);
		if (JProgramInfo->RealData.ReadFlg == 9)
			return 9;//�ɹ�����9
		if (JProgramInfo->RealData.ReadFlg == 4)
			return 0;
	}
	return JProgramInfo->RealData.ReadFlg;//��ʱ
}


		//ʱ��Ƚ� ���ڷ���1 ��������0 ��С���� -1��
int IsEqual(TS *ts0, TS *ts1) {
	if (ts0->Year > ts1->Year)
		return 1;
	else if (ts0->Year < ts1->Year)
		return -1;
	else if (ts0->Year == ts1->Year) {
		if (ts0->Month > ts1->Month)
			return 1;
		else if (ts0->Month < ts1->Month)
			return -1;
		else if (ts0->Month == ts1->Month) {
			if (ts0->Day > ts1->Day)
				return 1;
			else if (ts0->Day < ts1->Day)
				return -1;
			else if (ts0->Day == ts1->Day) {
				if (ts0->Hour > ts1->Hour)
					return 1;
				else if (ts0->Hour < ts1->Hour)
					return -1;
				else if (ts0->Hour == ts1->Hour) {
					if (ts0->Minute > ts1->Minute)
						return 1;
					else if (ts0->Minute < ts1->Minute)
						return -1;
					else if (ts0->Minute == ts1->Minute)
						return 0;

				}
			}
		}
	}
	return 1;
}

INT32U ifLeaps(INT16U year) {
	if (year % 4 == 0) {
		if (year % 100 == 0) {
			if (year % 400 == 0)
				return 1;
			else
				return 0;
		} else
			return 1;
	} else
		return 0;
}

/*#ifdef __linux__
void TimeAdd(TS *ts, INT16U unit, int step)
{
	INT32U isleaps;
	isleaps = ifLeaps(ts->Year);
	if (unit==5)
	{
		if (ts->Month==12)
		{
			ts->Month=1;
			ts->Year++;
		}else
		{
			if ((ts->Month==2) || (ts->Month==4) || (ts->Month==6) || (ts->Month==9) || (ts->Month==11))
				ts->Month++;
			if ((ts->Month==3) || (ts->Month==5) || (ts->Month==7) || (ts->Month==8) || (ts->Month==10))
			{
				ts->Month++;
				if (ts->Day==31)
					ts->Day=30;
			}
			if (ts->Month==1)
			{
				ts->Month++;
				if ((isleaps==1)&&(ts->Day>29))
					ts->Day=29;
				if ((isleaps==0)&&(ts->Day>28))
					ts->Day=28;
			}
		}
		return;
	}
	if (unit==6)
	{
		if (isleaps==1)
		{
			if ((ts->Month==2)&&(ts->Day==29))
				ts->Day=28;
		}
		ts->Year=ts->Year+1;
		return;
	}
	struct tm nowtm;
	time_t tt;
	memset(&nowtm,0,sizeof(struct tm));
	nowtm.tm_year = ts->Year-1900;
	nowtm.tm_mon = ts->Month-1;
	nowtm.tm_mday = ts->Day;
	nowtm.tm_hour = ts->Hour;
	nowtm.tm_min = ts->Minute;
	nowtm.tm_sec = 0;
	nowtm.tm_isdst = 0;
	nowtm.tm_zone="UTC";
	nowtm.tm_gmtoff=0;
	//nowtm.tm_year -= 1900;
	//nowtm.tm_mon -= 1;
	printf("nowtm.===%04d-%02d-%02d %02d:%02d:%02d %ld-%d-%d-%d-%s\n\r",nowtm.tm_year,nowtm.tm_mon,nowtm.tm_mday,
			nowtm.tm_hour,nowtm.tm_min,nowtm.tm_sec,nowtm.tm_gmtoff,nowtm.tm_isdst,nowtm.tm_wday,nowtm.tm_yday,nowtm.tm_zone);
	switch (unit) {
	case 2:
		tt = mktime(&nowtm) + step*60;
		printf("00000\n\r");
		break;
	case 3:
		tt = mktime(&nowtm) + step*60*24;
		printf("11111\n\r");
		break;
	case 4:
		tt = mktime(&nowtm);// + step*60*24*60;
		printf("2222-----%s==\n\r",strerror(errno));
		break;
	default:
		break;
	}
	 tt = time(NULL) + 24 * 3600;

	printf("---dddd-%s\n\r",ctime(&tt));
	struct tm *ntm=localtime(&tt);
	printf("ntm===%04d-%02d-%02d %02d:%02d:%02d %ld-%d-%d-%d-%s\n\r",ntm->tm_year,ntm->tm_mon,ntm->tm_mday,
			ntm->tm_hour,ntm->tm_min,ntm->tm_sec,ntm->tm_gmtoff,ntm->tm_isdst,ntm->tm_wday,ntm->tm_yday,ntm->tm_zone);
	tt = mktime(ntm);// + step*60*24*60;
	printf("2222-----%s==\n\r",strerror(errno));
	//nowtm.tm_year += 1900;
	//nowtm.tm_mon += 1;
	ts->Year = ntm->tm_year+=1900;
	ts->Month = ntm->tm_mon+=1;
	ts->Day = ntm->tm_mday;
	ts->Hour = ntm->tm_hour;
	ts->Minute = ntm->tm_min;

}

void TimeDecrease(TS *ts, INT16U unit, int step)
{
	INT32U isleaps;
	isleaps = ifLeaps(ts->Year);
	if (unit==5)
	{
		if (ts->Month==1)
		{
			ts->Month=12;
			ts->Year--;
		}else
		{
			if ((ts->Month==2) || (ts->Month==4) || (ts->Month==6) || (ts->Month==9) || (ts->Month==11))
				ts->Month--;
			if ((ts->Month==12) || (ts->Month==5) || (ts->Month==7) || (ts->Month==8) || (ts->Month==10))
			{
				ts->Month--;
				if (ts->Day==31)
					ts->Day=30;
			}
			if (ts->Month==3)
			{
				if ((isleaps==1)&&(ts->Day>29))
					ts->Day=29;
				if ((isleaps==0)&&(ts->Day>28))
					ts->Day=28;
				ts->Month--;
			}
		}
		return;
	}
	if (unit==6)
	{
		if (isleaps==1)
		{
			if ((ts->Month==2)&&(ts->Day==29))
				ts->Day=28;
		}
		ts->Year=ts->Year+1;
		return;
	}
	struct tm nowtm;
	time_t tt;
	nowtm.tm_year = ts->Year;
	nowtm.tm_mon = ts->Month;
	nowtm.tm_mday = ts->Day;
	nowtm.tm_hour = ts->Hour;
	nowtm.tm_min = ts->Minute;
	nowtm.tm_sec = 0;
	nowtm.tm_isdst = 0;
	nowtm.tm_year -= 1900;
	nowtm.tm_mon -= 1;
	switch (unit) {
	case 2:
		tt = mktime(&nowtm) - step*60;
		break;
	case 3:
		tt = mktime(&nowtm) - step*60*24;
		break;
	case 4:
		tt = mktime(&nowtm) - step*60*24*60;
		break;
	default:
		break;
	}
	struct tm *ntm=localtime(&tt);
	printf("ntm===%04d-%02d-%02d %02d:%02d:%02d\n\r",ntm->tm_year,ntm->tm_mon,ntm->tm_mday,ntm->tm_hour,ntm->tm_min,ntm->tm_sec);
	//nowtm.tm_year += 1900;
	//nowtm.tm_mon += 1;
	ts->Year = ntm->tm_year+=1900;
	ts->Month = ntm->tm_mon+=1;
	ts->Day = ntm->tm_mday;
	ts->Hour = ntm->tm_hour;
	ts->Minute = ntm->tm_min;
}
#else*/
void TimeAdd(TS *ts, INT16U unit, int step)//ʱ���
{
	struct tm nowtm;
	if (ts->Year<1900)
		nowtm.tm_year = ts->Year + 2000;
	else nowtm.tm_year = ts->Year;
	//nowtm.tm_year = ts->Year;
	nowtm.tm_mon = ts->Month;
	nowtm.tm_mday = ts->Day;
	nowtm.tm_hour = ts->Hour;
	nowtm.tm_min = ts->Minute;
	nowtm.tm_sec = 0;
	nowtm.tm_isdst = 0;
	nowtm.tm_year -= 1900;
	nowtm.tm_mon -= 1;
	switch (unit) {
	case 2:
		nowtm.tm_min += step;
		break;
	case 3:
		nowtm.tm_hour += step;
		break;
	case 4:
		nowtm.tm_mday += step;
		break;
	case 5:
		nowtm.tm_mon += step;
		break;
	case 6:
		nowtm.tm_year += step;
		break;
	default:
		break;
	}
	mktime(&nowtm);
	nowtm.tm_year += 1900;
	nowtm.tm_mon += 1;
	ts->Year = nowtm.tm_year;
	ts->Month = nowtm.tm_mon;
	ts->Day = nowtm.tm_mday;
	ts->Hour = nowtm.tm_hour;
	ts->Minute = nowtm.tm_min;
}

void TimeDecrease(TS *ts, INT16U unit, int step)//ʱ���
{
	struct tm nowtm;
	if (ts->Year<1900)
		nowtm.tm_year = ts->Year + 2000;
	else nowtm.tm_year = ts->Year;
	nowtm.tm_mon = ts->Month;
	nowtm.tm_mday = ts->Day;
	nowtm.tm_hour = ts->Hour;
	nowtm.tm_min = ts->Minute;
	nowtm.tm_sec = 0;
	nowtm.tm_isdst = 0;
	nowtm.tm_year -= 1900;
	nowtm.tm_mon -= 1;
	switch (unit) {
	case 2:
		nowtm.tm_min -= step;
		break;
	case 3:
		nowtm.tm_hour -= step;
		break;
	case 4:
		nowtm.tm_mday -= step;
		break;
	case 5:
		nowtm.tm_mon -= step;
		break;
	case 6:
		nowtm.tm_year -= step;
		break;
	default:
		break;
	}
	mktime(&nowtm);
	nowtm.tm_year += 1900;
	nowtm.tm_mon += 1;
	ts->Year = nowtm.tm_year;
	ts->Month = nowtm.tm_mon;
	ts->Day = nowtm.tm_mday;
	ts->Hour = nowtm.tm_hour;
	ts->Minute = nowtm.tm_min;
}
//#endif
//BCDת��Ϊ32λ����
INT32S BCD_INT32(INT8U *buf, INT8U len) {
	INT32S i;
	INT32S Result = 0;
	for (i = len; i > 0; i--) {
		Result = (Result * 10) + ((buf[i - 1] >> 4) & 0xf);
		Result = (Result * 10) + (buf[i - 1] & 0xf);
	}
	return Result;
}

//32λ����ת��ΪBCD
void INT32U_BCD(INT32S data, INT8U *buf, INT8U len) {
	INT8U i;
	INT32S Temp;
	INT16U j = 1;
	Temp = abs(data);
	for (i = 0; i < len; i++) {
		j = Temp % 100;
		buf[i] = (j / 10);
		buf[i] = (buf[i] << 4) + (j % 10);
		Temp = Temp / 100;
	}
	if (data < 0) {
		buf[len - 1] = buf[len - 1] | 0x80;
	}
}
void BCDToASC(unsigned char * BCD, int Len, unsigned char *Ret) {
	unsigned char *BCDtmp = (unsigned char *) malloc(Len * sizeof(unsigned char)+1);
	memcpy(BCDtmp, BCD, Len);
	int i, j, k;
	if (BCDtmp != NULL) {
		i = 0;
		while (BCDtmp[i] != '\0') {
			i++;
		};
		//i--;
		i = Len;
		memset(Ret, 0, Len);
		for (j = 0, k = 0; j < i; j++) {
			if (BCDtmp != NULL) {
				unsigned char A = BCDtmp[j] >> 4;
				unsigned char B = BCDtmp[j] & 0x0F;
				if (A < 10)
					*(Ret + k) = A + '0';
				else
					*(Ret + k) = A + '7';
				if (B < 10)
					*(Ret + k + 1) = B + '0';
				else
					*(Ret + k + 1) = B + '7';
				k++;
				k++;
			}
		}
		*(Ret + i * 2) = '\0';
	}
	free(BCDtmp);
}
int ASCToBCD(unsigned char * ASC, int Len, unsigned char *Ret) {
	int i, j, k;
	if (ASC != NULL) {
		for (i = 0; i < Len; i++) {
			if (ASC[i] <= '9' && ASC[i] >= '0')
				ASC[i] = ASC[i] - '0';
			else if(ASC[i] <= 'f' && ASC[i] >= 'a')
			{
				ASC[i] = ASC[i] - 'W';
			}
			else if(ASC[i] <= 'F' && ASC[i] >= 'A')
			{
				ASC[i] = ASC[i] - '7';
			}
		}
		if (Len % 2 == 0) {
			//unsigned char *Ret=new char[Len/2+1];
			memset(Ret, 0, Len / 2 + 1);
			for (j = 0, k = 0; j < Len / 2; j++) {
				*(Ret + j) = (ASC[k] << 4) | ASC[k + 1];
				k++;
				k++;
			}
			//return Ret;
		}
	}
	return 0;
}

INT8U CmpOneByte(INT8U FByte,INT8U SByte)
{
	INT8U res=0;
	if (FByte!=SByte)
	{
		if ((FByte&0b00000001)!=(SByte&0b00000001))
		{
			res|=0b00000001;
		}
		if ((FByte&0b00000010)!=(SByte&0b00000010))
		{
			res|=0b00000010;
		}
		if ((FByte&0b00000100)!=(SByte&0b00000100))
		{
			res|=0b00000100;
		}
		if ((FByte&0b00001000)!=(SByte&0b00001000))
		{
			res|=0b00001000;
		}
		if ((FByte&0b00010000)!=(SByte&0b00010000))
		{
			res|=0b00010000;
		}
		if ((FByte&0b00100000)!=(SByte&0b00100000))
		{
			res|=0b00100000;
		}
		if ((FByte&0b01000000)!=(SByte&0b01000000))
		{
			res|=0b01000000;
		}
		if ((FByte&0b10000000)!=(SByte&0b10000000))
		{
			res|=0b10000000;
		}
	}
	return res;
}

#ifdef __linux__
pid_t find_pid_by_name(char* pidName,ProgramInfo* JProgramInfo) {
	DIR *dir;
	struct dirent *next;
	pid_t* pidList = NULL;
	int i = 0;
    struct timespec tsspec;
    if (clock_gettime(CLOCK_REALTIME, &tsspec)==-1)
    	printf("clock_gettime error\n\r");
    tsspec.tv_sec += 3;
	sem_timedwait(&JProgramInfo->mainData.UseFileFlg,&tsspec);
	dir = opendir("/proc");
	if (!dir)
	{
	    sem_post(&JProgramInfo->mainData.UseFileFlg);
	     return -1;
	}

	while ((next = readdir(dir)) != NULL) {
		FILE *status;
		char filename[50];
		char buffer[50];
		char name[50];

		/* Must skip ".." since that is outside /proc */
		if (strcmp(next->d_name, "..") == 0)
			continue;

		/* If it isn't a number, we don't want it */
		if (!isdigit(*next->d_name))
			continue;

		sprintf(filename, "/proc/%s/status", next->d_name);
		if (!(status = fopen(filename, "r"))) {
			continue;
		}
		if (fgets(buffer, 50 - 1, status) == NULL) {
			fclose(status);
			status=NULL;
			continue;
		}
		fclose(status);
		status=NULL;

		/* Buffer should contain a string like "Name:   binary_name" */
		sscanf(buffer, "%*s %s", name);
		if (strcmp(name, pidName) == 0) {
			if (strtol(next->d_name, NULL, 0)==getpid())
				continue;
			pidList = realloc(pidList, sizeof(pid_t) * (i + 2));
			pidList[i++] = strtol(next->d_name, NULL, 0);
		}
	}

	if (pidList)
		pidList[i] = 0;
	else if (strcmp(pidName, "init") == 0) {
		/* If we found nothing and they were trying to kill "init",
		 * guess PID 1 and call it good...  Perhaps we should simply
		 * exit if /proc isn't mounted, but this will do for now. */
		pidList = realloc(pidList, sizeof(pid_t));
		pidList[0] = 1;
	} else {
		pidList = realloc(pidList, sizeof(pid_t));
		pidList[0] = -1;
	}
	sem_post(&JProgramInfo->mainData.UseFileFlg);
	closedir(dir);
	free(pidList);
	return *pidList;
}

name_attach_t *name_attach(void *dpp, char *path, unsigned flags,ProgramInfo* JProgramInfo)
{
	name_attach_t att;
	name_attach_t *ret;
	ret =  &att;
	if (find_pid_by_name(path,JProgramInfo)>0)
	{
		return NULL;
	}
	return ret;
}

void name_detach(name_attach_t *attach, unsigned flags)
{

}

int gpio_read(char *devname)
{
	int data=0, fd=0;
	char devpath[100];
	sprintf(devpath, "/dev/%s", devname);
	if((fd = open(devpath, O_RDWR | O_NDELAY)) > 0)
	{
		read(fd,&data,sizeof(int));
		close(fd);
	}
	return data;
}

int gpio_write(char *devname, int data)
{
	int fd=0;
	char devpath[100];
	sprintf(devpath, "/dev/%s", devname);
	if((fd = open(devpath, O_RDWR | O_NDELAY)) > 0)
	{
		write(fd,&data,sizeof(int));
		close(fd);
		return 1;
	}
	return 0;
}
void DbgPrintToFile(const char *format,...)
{
	char str[50];
	time_t cur_time;
	struct tm cur_tm;
	FILE *fp = NULL;
	memset(str,0,50);
	cur_time=time(NULL);
	localtime_r(&cur_time,&cur_tm);
	sprintf(str, "\n[%04d-%02d-%02d %02d:%02d:%02d]",
			cur_tm.tm_year+1900, cur_tm.tm_mon+1, cur_tm.tm_mday,
			cur_tm.tm_hour, cur_tm.tm_min, cur_tm.tm_sec);
    va_list ap;
	//���ļ�
	if(!fp)
		fp = fopen("/nand/dbglog.log", "a+");
	//��ʼ��ӡ
    va_start(ap,format);
    //vprintf(format,ap);
	vfprintf(fp,str,ap);
    if(fp)
		vfprintf(fp,format,ap); // д�ļ�
    va_end(ap);
    fflush(fp);
	//�ر��ļ�
	if(fp)
    {
        fclose(fp);
        fp = NULL;
    }
}

void myBCDtoASC(char val, char dest[2])
{
	int i=0;
	char c[2];
	c[0]=0; c[1]=0;
	c[0] = (val>>4) & 0x0f;
	c[1] = val & 0x0f;
	for(i=0; i<2; i++)
	{
		if(c[i]>=0 && c[i]<=9)
			dest[i] = c[i] + '0';
		if(c[i]==10)
			dest[i] = 'a';
		if(c[i]==11)
			dest[i] = 'b';
		if(c[i]==12)
			dest[i] = 'c';
		if(c[i]==13)
			dest[i] = 'd';
		if(c[i]==14)
			dest[i] = 'e';
		if(c[i]==15)
			dest[i] = 'f';
	}
}
//prefix ǰ׺   buf ��ӡ������ buf ���� len  suffix ��׺
// DbPrt("GPRS����", buf, 12, "ȷ��")   //[April 7-2 2012] GPRS����(12): 68 00 00 00 12 34 56 68 11 04 32 16 ȷ��
void DbPrt(char *prefix, char *buf, int len, char *suffix)
{
	char str[50], tmpbuf[2048], c[2], c1[2], c2[2];
	int i=0;
	memset(c, 0, 2);
	memset(str, 0, 50);
	memset(tmpbuf, 0, 2048);
//	if(len>512)
//		len=512;
	int count= 0;
	int prtlen=0;
	int k=0;
	while(1)
	{
		memset(c, 0, 2);
		memset(str, 0, 50);
		memset(tmpbuf, 0, 2048);
		if(len<=512)
		{
			prtlen = len;
		}else
		{
			if(k<len/512)
			{
				k++;
				prtlen = 512;
			}else
			{
				prtlen = len%512;
			}
		}
		if(prefix!=NULL)
		{
			sprintf(str, "%s[%d] ", prefix,prtlen);
			strcat(tmpbuf, str);
		}
		for(i=0; i<prtlen; i++)
		{
			memset(c, 0, 2);
			memset(c1, 0, 2);
			memset(c2, 0, 2);
			myBCDtoASC(buf[i+count], c);

			c1[0] = c[0];
			c2[0] = c[1];
			strcat(tmpbuf, c1);
			strcat(tmpbuf, c2);
			strcat(tmpbuf, " ");
		}
		if(suffix!=NULL)
			strcat(tmpbuf, suffix);
		DbgPrintToFile(tmpbuf);
//		JProgramInfo->Print_rowCount++;
		count += prtlen;
		if(count>=len)
			break;
	}
//	if(JParameterInfo->jzq.Print_rowCount>3000)
//	{
//		syscmd("rm /nand/dbglog.log");
//		printf("\nrm /nand/dbglog.log\n");
//		JParameterInfo->jzq.Print_rowCount=0;
//	}
}
void mydelay(int seccount,INT8U ProjectNo,ProgramInfo* JProgramInfo)
{
	int i=0;
	for(i=0;i<seccount;i++)
	{
		ClearWaitTimes(ProjectNo,JProgramInfo);
		delay(1000);
	}
}
int OpenComCarr(INT8U port,int baud, unsigned char *par, unsigned char stopb, INT8U bits)
{
	int ComPort=0;
	struct termios old_termi,new_termi;
	int baud_lnx=0;
	unsigned char tmp[128];
	memset(tmp,0,128);
    sprintf((char *)tmp,"/dev/ttyS%d",port);
    ComPort = open((char *)tmp, O_RDWR|O_NOCTTY);/* �򿪴����ļ� */
    if( ComPort<0 )
    {
    	printf("open the serial port fail! errno is: %d\n", errno);
    	return 0; /*�򿪴���ʧ��*/
    }
    if ( tcgetattr( ComPort, &old_termi) != 0) /*�洢ԭ��������*/
    {
    	printf("get the terminal parameter error when set baudrate! errno is: %d\n", errno);
    	/*��ȡ�ն���ز���ʱ����*/
    	return 0;
    }
    //printf("\n\r c_ispeed == %d old_termi  c_ospeed == %d",old_termi.c_ispeed, old_termi.c_ospeed);
    bzero(&new_termi,sizeof(new_termi));    				/*���ṹ������*/
    new_termi.c_cflag|= (CLOCAL|CREAD); 					/*���Ե��ƽ����״̬�У�����ʹ��*/
    new_termi.c_lflag&=~(ICANON|ECHO|ECHOE);				/*ѡ��Ϊԭʼ����ģʽ*/
    new_termi.c_oflag&=~OPOST; 								/*ѡ��Ϊԭʼ���ģʽ*/
    new_termi.c_cc[VTIME] = 5; 								/*���ó�ʱʱ��Ϊ0.5 s*/
    new_termi.c_cc[VMIN] = 0;								/*���ٷ��ص��ֽ����� 7*/
    new_termi.c_cflag &= ~CSIZE;
    //new_termi.c_iflag &= ~INPCK;     /* Enable parity checking */
    new_termi.c_iflag &=~ ISTRIP;
    switch(baud)
    {
    	case 1200:
    		baud_lnx = B1200;
    		break;
    	case 2400:
    		baud_lnx = B2400;
    		break;
    	case 4800:
    		baud_lnx = B4800;
    		break;
    	case 9600:
    		baud_lnx = B9600;
    		break;
    	case 19200:
    		baud_lnx = B19200;
    		break;
    	case 38400:
    		baud_lnx = B38400;
    		break;
    	case 57600:
    		baud_lnx = B57600;
    		break;
    	case 115200:
    		baud_lnx = B115200;
    		break;
    	default:
    		baud_lnx = B9600;
    		printf("\nSerial COM%d do not setup baud, default baud is 9600!!!", port);
    		break;
    }

    switch( bits )
	{
		case 5:
			new_termi.c_cflag |= CS5;
			break;
		case 6:
			new_termi.c_cflag |= CS6;
			break;
		case 7:
			new_termi.c_cflag |= CS7;
			break;
		case 8:
			new_termi.c_cflag |= CS8;
			break;
		default:
			new_termi.c_cflag |= CS8;
			break;
	}

    if(strncmp((char *)par,"even",4)==0)//������żУ��ΪżУ��
    {
		//new_termi.c_iflag |= (INPCK | ISTRIP);
    	new_termi.c_cflag |= PARENB;
    	new_termi.c_cflag &= ~PARODD;

    }
    else if(strncmp((char *)par,"odd",3)==0)  //������żУ��Ϊ��У��
	{
		new_termi.c_cflag |= PARENB;
		new_termi.c_cflag |= PARODD;
		//new_termi.c_iflag |= (INPCK | ISTRIP);
	}else
	{
    	new_termi.c_cflag &= ~PARENB; 	//������żУ��Ϊ��У��
    	//new_termi.c_iflag &=~ ISTRIP;
    }


	if(stopb==1)//ֹͣλ
	{
		new_termi.c_cflag&= ~CSTOPB; //����ֹͣλΪ:һλֹͣλ
	}
	else if(stopb==2)
	{
		new_termi.c_cflag |= CSTOPB; //����ֹͣλΪ:��λֹͣλ
	}
	else
	{
		new_termi.c_cflag&= ~CSTOPB; //����ֹͣλΪ:һλֹͣλ
	}

	cfsetispeed(&new_termi, baud_lnx); 							/* �������벦���� */
    cfsetospeed(&new_termi, baud_lnx); 							/* ������������� */

    tcflush(ComPort, TCIOFLUSH); 								/* ˢ����������� */
    if(tcsetattr(ComPort,TCSANOW,&new_termi)!= 0)				/* ��������� */
    {
    	printf("Set serial port parameter error!\n");
    	return 0;
    }
    return ComPort;
}


//�رմ���
void CloseComCarr(int ComPort)
{
	close(ComPort);
}

unsigned char GetValuefromFile1(INT8U DI1,INT8U DI0, unsigned char *Dest, unsigned char *buf)//����
{
	//int datalen=0;
	int ret=0;
	if(((DI0|0x0f) == 0x1f) && (DI1 == 0xB6)) //��ѹ
	{
		memcpy(Dest, buf+(DI0-0x10-1)*2, 2);
		//printf("DI0=%02x[%02x] [%02x]", DI0,Dest[0],Dest[1]);
	}
	else if(((DI0|0x0f) == 0x2f) && (DI1 == 0xB6))//����
	{
		memcpy(Dest, buf+(DI0-0x20-1)*3, 3);
		if(Dest[0]==0 && Dest[1]==0 && Dest[2]==0)
		{
			ret = 2;
//			Dest[0]=0xee;
//			Dest[1]=0xee;
//			Dest[2]=0xee;
		}
	}
	else if(((DI0|0x0f) == 0x3f) && (DI1 == 0xB6))//����
		memcpy(Dest, buf+(DI0-0x30)*3, 3);
	else
	{

	}
	return ret;
}
int FindFlginFile(SMFiles *smfile, INT8U DI1,INT8U DI0,ProgramInfo* JProgramInfo)	//10.24
{
	if(((JProgramInfo->zone)>>7&0x01) ==1)
		return 1;
	INT8U i,isFlag=0;
	INT8U reslutBuf[100];
	for(i=0;i<ManyFlagsCount;i++)
	{
		if (smfile->sm.datas[i].flg.Dataflag[1]==0x00 && smfile->sm.datas[i].flg.Dataflag[0]==0x00)
			continue;
		if (smfile->sm.datas[i].flg.Dataflag[1]==0xff && smfile->sm.datas[i].flg.Dataflag[0]==0xff)
			continue;
		if (smfile->sm.datas[i].flg.Dataflag[1]==OxXX && smfile->sm.datas[i].flg.Dataflag[0]==OxXX)
			continue;
		if(smfile->sm.datas[i].flg.Dataflag[0]==DI0 && smfile->sm.datas[i].flg.Dataflag[1]==DI1){
            isFlag=1;
            break;
		}
	}
	if(isFlag==0) {
		for(i=0;i<ManyFlagsCount;i++) {
			if (smfile->sm.datas[i].flg.Dataflag[1]==0x00 && smfile->sm.datas[i].flg.Dataflag[0]==0x00)
				continue;
			if (smfile->sm.datas[i].flg.Dataflag[1]==0xff && smfile->sm.datas[i].flg.Dataflag[0]==0xff)
				continue;
			if (smfile->sm.datas[i].flg.Dataflag[1]==OxXX && smfile->sm.datas[i].flg.Dataflag[0]==OxXX)
				continue;
			if(smfile->sm.datas[i].flg.Dataflag[0]==(DI0|0x0f) && smfile->sm.datas[i].flg.Dataflag[1]==DI1)
			{
				memset(reslutBuf, 0, 100);
				GetValuefromFile1(DI1, DI0, reslutBuf, &smfile->sm.datas[i].datas[0]);
				if(reslutBuf[0]==0xee && reslutBuf[1]==0xee)
					isFlag=0;
				else
					isFlag=1;
				break;
			}
		}
	}
	return isFlag;
}

#define FATAL do { fprintf(stderr, "Error at line %d, file %s (%d) [%s]\n", \
  __LINE__, __FILE__, errno, strerror(errno)); exit(1); } while(0)

unsigned int mmap_device_io(unsigned int len, unsigned int paddr) {
	int fd;
	unsigned int vaddr;
	unsigned int *p;
	unsigned int page, mask;
	page = ((len / 4096) + 1) * 4096;
	mask = page - 1;
	if ((fd = open("/dev/mem", O_RDWR | O_SYNC)) == -1)
		FATAL;
	p = mmap(0, page, PROT_READ | PROT_WRITE, MAP_SHARED, fd, paddr & ~mask);
	if (p == (void *) -1)
		FATAL;
	vaddr = (unsigned int) p + (paddr & mask);
	close(fd);

	return vaddr;
}
int munmap_device_io(unsigned int vaddr, unsigned int len) {
	unsigned int page, mask;
	unsigned int p;
	page = ((len / 4096) + 1) * 4096;
	mask = page - 1;
	p = vaddr & mask;
	if (munmap((void *) p, page) == -1)
		return -1;
	return 0;
}

char* strrev(char* szT)
{
    if ( !szT )                 // ��������Ŀմ�.
        return "";
    int i ,j,t,k;
    i= strlen(szT);
    t = !(i%2)? 1 : 0;      // ��鴮����.
    for(j = i-1 , k = 0 ; j > (i/2 -t) ; j-- )
    {
        char ch  = szT[j];
        szT[j]   = szT[k];
        szT[k++] = ch;
    }
    return szT;
}

char* itoa(int value, char*  str, int radix)
{
    int  rem = 0;
    int  pos = 0;
    char ch  = '!' ;
    do
    {
        rem    = value % radix ;
        value /= radix;
        if ( 16 == radix )
        {
            if( rem >= 10 && rem <= 15 )
            {
                switch( rem )
                {
                    case 10:
                        ch = 'a' ;
                        break;
                    case 11:
                        ch ='b' ;
                        break;
                    case 12:
                        ch = 'c' ;
                        break;
                    case 13:
                        ch ='d' ;
                        break;
                    case 14:
                        ch = 'e' ;
                        break;
                    case 15:
                        ch ='f' ;
                        break;
                }
            }
        }
        if( '!' == ch )
        {
            str[pos++] = (char) ( rem + 0x30 );
        }
        else
        {
            str[pos++] = ch ;
        }
    }while( value != 0 );
    str[pos] = '\0' ;
    return strrev(str);
}
//-----------------------------------------------------fzh
//void GetDa(INT8U Da1, INT8U Da2,INT8U* da)
//{
//	INT8U i;
//	memset(DA, 0, PointMax);//DAֻʹ�ú�64λ
//	if ((Da1 == 0) && (Da2 == 0)) {
//		da[0] = 1;
//		return;
//	}
//	if (Da2 == 0) {
//		memset(da, 0, PointMax);
//		return;
//	}
//	if ((Da1 == 0xff) && (Da2 == 0xff)) {
//		memset(da, 1, PointMax);
//	}
//	for (i = 0; i < 8; i++) {
//		if (Da1 & CMP8U[i]) {
//			da[(Da2-1) * 8 + i + 1] = 1;
//		}
//	}
//}
//void GetDt(INT8U Dt1, INT8U Dt2,INT8U* dt)//�õ���Ϣ��DT��
//{
//	INT8U i;
//	memset(dt, 0, 255);
//	for (i = 0; i < 8; i++) {
//		if (Dt1 & CMP8U[i]) {
//			dt[Dt2 * 8 + i + 1] = 1;
//		}
//	}
//}
//void Afn04_fn(INT16U DA,INT16U DT)//da ��������Ϣ   dt ������Ϣ
//{
//	INT8U da_point[PointMax];
//	INT8U dt_fn[255];
//	INT8U da1,da2,dt1,dt2;
//	da1 = DA
//	da2 = DA
//	dt1 = DT
//	dt2 = DT
//	GetDa()
//	return;
//}
//void interface(PkgPropertyInfo* pkg_property ,
//			   ParamInfo3761* JParamInfo3761,
//			   ProgramInfo* JProgramInfo,ConfigInfo*
//			   JConfigInfo,
//			   DataFileInfo*  JDataFileInfo)
//{
//	int i =0 ;
//	pkg_property->AFN = 0x04;
//	fprintf(stderr,"\ninterface: Afn=%02x",pkg_property->AFN);
//	switch(pkg_property->AFN )
//	{
//		case 0x00 : //5.1 ȷ�ϨM ���ϣ�AFN=00H��
//			break;
//		case 0x01 : //5.2 ��λ���AFN=01H��
//			break;
//		case 0x02 : //5.3 ��·�ӿڼ�⣨AFN=02H��
//			break;
//		case 0x03 : //5.4 �м�վ���AFN=03H��
//			break;
//		case 0x04 : //5.5 ���ò�����AFN=04H��
//			for(i=0;i< pkg_property.DataUnitNum ; i++)
//			{
//				Afn04_fn(pkg_property.dadt[i].DA,pkg_property.dadt[i].DT);
//			}
//			break;
//		case 0x05 : //5.6 �������AFN=05H��
//			break;
//		case 0x06 : //5.7 ������֤����ԿЭ�̣�AFN=06H��
//			break;
//		case 0x08 : //5.8 ���󱻼����ն������ϱ���AFN=08H��
//			break;
//		case 0x09 : //5.9 �����ն����ü���Ϣ��AFN=09H��
//			break;
//		case 0x0a : //5.10 ��ѯ������AFN=0AH��
//			break;
//		case 0x0b : //5.11 �����������ݣ�AFN=0BH��
//			break;
//		case 0x0c : //5.12 ����1�����ݣ�AFN=0CH��
//			break;
//		case 0x0d : //5.13 ����2�����ݣ�AFN=0DH��
//			break;
//		case 0x0e : //5.14 ����3�����ݣ�AFN=0EH��
//			break;
//		case 0x0f : //5.15 �ļ����䣨AFN=0FH��
//			break;
//		case 0x10 : //5.16 ����ת����AFN=10H��
//			break;
//		default :
//			break;
//	}
//}
int TwoLevelDataTask(INT8U taskno,ParamInfo3761* JParamInfo3761,ProgramInfo* JProgramInfo)
{
	INT8U zqdw, zqvalue;
	TS ts;
	//initnextime();//lcy 2012.12.19

	if (JParamInfo3761->group9.f68[taskno].IsRun == 0x55)
	{
		TSGet(&ts);
		zqdw = JParamInfo3761->group9.f66[taskno].Interval >> 6;//���ڵ�λ 0��   1ʱ   2��	  3��
		zqvalue = JParamInfo3761->group9.f66[taskno].Interval & 0x3f;//����ֵ

		if (newtestTime(2,taskno,JParamInfo3761->group9.f65[taskno].Post_Time,ts,zqdw,zqvalue,JParamInfo3761,JProgramInfo))
		{
			fprintf(stderr,"\n=====��ʱ���Ͷ������� ��%d =====\n",taskno);
			return 1;
		}//end if test time
	}
	return 0;
}
int OneLevelDataTask(INT8U taskno,ParamInfo3761* JParamInfo3761,ProgramInfo* JProgramInfo)
{
	INT8U zqdw, zqvalue;
	TS ts;
	//initnextime();//lcy 2012.12.19

	if (JParamInfo3761->group9.f67[taskno].IsRun == 0x55)
	{
		TSGet(&ts);
		zqdw = JParamInfo3761->group9.f65[taskno].Interval >> 6;//���ڵ�λ 0��   1ʱ   2��	  3��
		zqvalue = JParamInfo3761->group9.f65[taskno].Interval & 0x3f;//����ֵ
		if (newtestTime(1,taskno,JParamInfo3761->group9.f65[taskno].Post_Time,ts,zqdw,zqvalue,JParamInfo3761,JProgramInfo))
		{
			fprintf(stderr,"\n=====��ʱ���Ͷ������� ��%d =====\n",taskno);
			return 1;
		}//end if test time
	}
	return 0;
}


INT8U newtestTime(int type,INT8U taskno,INT8U *s,TS ts,INT8U zqdw ,INT8U zqvalue,ParamInfo3761* JParamInfo3761,ProgramInfo* JProgramInfo)
{//taian3250
	struct tm tblock;
	INT8U year,mon,day,hour,min,sec;
	int ifok=0;
	time_t cur_time;
	cur_time=time(NULL);
	//�жϵ�ǰʱ���Ƿ���ڵ��ڷ���ʱ��    ���� 1  ��  0
	switch (type)
	{
	case 1://1����������
		if (JProgramInfo->TaskNextime1[taskno] > 0)
		{
			year=((JParamInfo3761->group9.f65[taskno].Post_Time[5]&0xf0)>>4)*10 + (JParamInfo3761->group9.f65[taskno].Post_Time[5]&0x0f);
			mon=((JParamInfo3761->group9.f65[taskno].Post_Time[4]&0x10)>>4)*10 + (JParamInfo3761->group9.f65[taskno].Post_Time[4]&0x0f);
			day=((JParamInfo3761->group9.f65[taskno].Post_Time[3]&0xf0)>>4)*10 + (JParamInfo3761->group9.f65[taskno].Post_Time[3]&0x0f);
			hour=((JParamInfo3761->group9.f65[taskno].Post_Time[2]&0xf0)>>4)*10 + (JParamInfo3761->group9.f65[taskno].Post_Time[2]&0x0f);
			min=((JParamInfo3761->group9.f65[taskno].Post_Time[1]&0xf0)>>4)*10 + (JParamInfo3761->group9.f65[taskno].Post_Time[1]&0x0f);
			sec=((JParamInfo3761->group9.f65[taskno].Post_Time[0]&0xf0)>>4)*10 + (JParamInfo3761->group9.f65[taskno].Post_Time[0]&0x0f);
			fprintf(stderr,"\n��׼ʱ��  %d-%d-%d %d:%d:%d\n", year+2000,mon,day,hour,min,sec);
			fprintf(stderr,"\n1������ %d  ����Ԥ��ʱ��=%ld  ��ǰʱ��=%ld\n",taskno+1,JProgramInfo->TaskNextime1[taskno],cur_time);
			localtime_r(&JProgramInfo->TaskNextime1[taskno],&tblock);
			fprintf(stderr,"\n�´��ϱ�ʱ��  %d-%d-%d %d:%d:%d\n", tblock.tm_year+1900,tblock.tm_mon+1,tblock.tm_mday,tblock.tm_hour,tblock.tm_min,tblock.tm_sec);

			if (cur_time >= JProgramInfo->TaskNextime1[taskno])
			{
				JProgramInfo->TaskNextime1[taskno] = CalcTaskNextTime(s,zqdw,zqvalue,ts);//�����´η���ʱ��
				fprintf(stderr,"\n1������ %d  ʱ�䵽! ����Ԥ��ʱ��=%ld  ��ǰʱ��=%ld",taskno+1,JProgramInfo->TaskNextime1[taskno],cur_time);
				ifok = 1;
			}
		}
		break;
	case 2://2����������
		if (JProgramInfo->TaskNextime2[taskno] > 0)
		{
			year=((JParamInfo3761->group9.f66[taskno].Post_Time[5]&0xf0)>>4)*10 + (JParamInfo3761->group9.f66[taskno].Post_Time[5]&0x0f);
			mon=((JParamInfo3761->group9.f66[taskno].Post_Time[4]&0x10)>>4)*10 + (JParamInfo3761->group9.f66[taskno].Post_Time[4]&0x0f);
			day=((JParamInfo3761->group9.f66[taskno].Post_Time[3]&0xf0)>>4)*10 + (JParamInfo3761->group9.f66[taskno].Post_Time[3]&0x0f);
			hour=((JParamInfo3761->group9.f66[taskno].Post_Time[2]&0xf0)>>4)*10 + (JParamInfo3761->group9.f66[taskno].Post_Time[2]&0x0f);
			min=((JParamInfo3761->group9.f66[taskno].Post_Time[1]&0xf0)>>4)*10 + (JParamInfo3761->group9.f66[taskno].Post_Time[1]&0x0f);
			sec=((JParamInfo3761->group9.f66[taskno].Post_Time[0]&0xf0)>>4)*10 + (JParamInfo3761->group9.f66[taskno].Post_Time[0]&0x0f);
			fprintf(stderr,"\n��׼ʱ��  %d-%d-%d %d:%d:%d\n", year,mon,day,hour,min,sec);
			fprintf(stderr,"\n2������ %d  ����Ԥ��ʱ��=%ld  ��ǰʱ��=%ld\n",taskno+1,JProgramInfo->TaskNextime2[taskno],cur_time);
			localtime_r(&JProgramInfo->TaskNextime2[taskno],&tblock);
			fprintf(stderr,"\n�´��ϱ�ʱ��   %d-%d-%d %d:%d:%d\n", tblock.tm_year+1900,tblock.tm_mon+1,tblock.tm_mday,tblock.tm_hour,tblock.tm_min,tblock.tm_sec);

			if (cur_time >= JProgramInfo->TaskNextime2[taskno])
			{
				fprintf(stderr,"\n2������ %d  ʱ�䵽! ! ! !����Ԥ��ʱ��=%ld  ��ǰʱ��=%ld",taskno+1,JProgramInfo->TaskNextime2[taskno],cur_time);
				JProgramInfo->TaskNextime2[taskno] = CalcTaskNextTime(s,zqdw,zqvalue,ts);//�����´η���ʱ��
				ifok = 1;
			}
		}

		break;
	}
	return (ifok);
}

time_t GetSectime(int year,int month,int day,int hour,int minute)
{//taian3250
	time_t cur_time;
	struct tm cur_tm;
	cur_time=time(NULL);
	localtime_r(&cur_time,&cur_tm);
	fprintf(stderr,"\n tm_year=%d  tm_mon=%d  tm_day=%d  tm_hour=%d",cur_tm.tm_year+1900,cur_tm.tm_mon+1,cur_tm.tm_mday,cur_tm.tm_hour);
	cur_tm.tm_year = year-1900;
	cur_tm.tm_mon = month-1;
	cur_tm.tm_mday = day;
	cur_tm.tm_hour = hour;
	cur_tm.tm_min = minute;
	cur_tm.tm_sec = 0;
	cur_time = mktime(&cur_tm);
	fprintf(stderr,"\ntime=%ld",cur_time);
	return (cur_time);
}

time_t CalcTaskNextTime(INT8U *s,INT8U zqdw ,INT8U zqvalue,TS nowts)
{//taian3250
	int nextime =0;
	INT8U Hour,	Min;
	switch (zqdw)
	{
		case 0://����
			break;
		case 1://Сʱ///////////////////lcy 2012.12.31
			Min = (s[1] >> 4) * 10;
			Min = Min + (s[1] & 0x0f);
			fprintf(stderr,"\nСʱ����  ����=%d   ��ǰ����=%d",Min,nowts.Minute);

			if (nowts.Minute < Min) //��û����
			{
				fprintf(stderr,"\nû���㣨Сʱ��");
				fprintf(stderr,"\n���� %d-%d-%d  %d:%d",nowts.Year,nowts.Month,nowts.Day,nowts.Hour,Min);
				nextime = GetSectime(nowts.Year,nowts.Month,nowts.Day,nowts.Hour,Min);
			}else//�Ѿ������ˣ�Ҫ�ȵ���һ����
			{
				fprintf(stderr,"\n����,Ҫ�ȵ���һ���ڣ�Сʱ��");
				TimeAdd(&nowts,3,1);
				fprintf(stderr,"\n���� %d-%d-%d  %d:%d",nowts.Year,nowts.Month,nowts.Day,nowts.Hour,Min);
				nextime = GetSectime(nowts.Year,nowts.Month,nowts.Day,nowts.Hour,Min);
			}
			break;
		case 2://��
			Hour = (s[2] >> 4) * 10;
			Hour = Hour + (s[2] & 0x0f);
			fprintf(stderr,"\n�ն�������  Сʱ=%d   ��ǰСʱ=%d",Hour,nowts.Hour);

			if (nowts.Hour < Hour) //��û����
			{
				fprintf(stderr,"\nû����");
				fprintf(stderr,"\n���� %d-%d-%d  %d",nowts.Year,nowts.Month,nowts.Day,Hour);
				nextime = GetSectime(nowts.Year,nowts.Month,nowts.Day,Hour,0);
			}else//�Ѿ������ˣ�Ҫ�ȵ�����
			{
				fprintf(stderr,"\n����,Ҫ�ȵ�����");
				TimeAdd(&nowts,4,1);
				fprintf(stderr,"\n���� %d-%d-%d  %d",nowts.Year,nowts.Month,nowts.Day,Hour);
				nextime = GetSectime(nowts.Year,nowts.Month,nowts.Day,Hour,0);
			}
			break;
		case 3://��
			break;
	}
	return nextime;
}

void initnextime(ParamInfo3761* JParamInfo3761,ProgramInfo* JProgramInfo)
{//taian3250
	INT8U zqdw,zqvalue;
	int i;
	TS ts;
	TSGet(&ts);

	for(i=0;i<Task2_Max;i++)
	{
		if ((JParamInfo3761->group9.f68[i].IsRun == 0x55)&&(JProgramInfo->TaskNextime2[i]<=0))
		{
			zqdw = JParamInfo3761->group9.f66[i].Interval >> 6;//���ڵ�λ 0��   1ʱ   2��	  3��
			zqvalue = JParamInfo3761->group9.f66[i].Interval & 0x3f;//����ֵ
			JProgramInfo->TaskNextime2[i] = CalcTaskNextTime(JParamInfo3761->group9.f66[i].Post_Time,zqdw,zqvalue,ts);
		}
	}
	for(i=0;i<Task1_Max;i++)
	{
		if ((JParamInfo3761->group9.f67[i].IsRun == 0x55)&&(JProgramInfo->TaskNextime1[i]<=0))
		{
			zqdw = JParamInfo3761->group9.f65[i].Interval >> 6;//���ڵ�λ 0��   1ʱ   2��	  3��
			zqvalue = JParamInfo3761->group9.f65[i].Interval & 0x3f;//����ֵ
			JProgramInfo->TaskNextime1[i] = CalcTaskNextTime(JParamInfo3761->group9.f65[i].Post_Time,zqdw,zqvalue,ts);
		}
	}
}
int StateProcess(int* step,int* rev_delay,int delay_num, int* rev_tail,int* rev_head,INT8U *NetRevBuf,INT8U* dealbuf)
{
	int i;
	int length;
//	fprintf(stderr,"\nStateProcess %d",*step);
	switch(*step)
	{
		case 0:		 // �ҵ���һ�� 0x68
			while(*rev_head!=*rev_tail) {
				if (NetRevBuf[*rev_tail]== 0x68) {
					*step = 1;
					break;
				}else {
					*rev_tail = (*rev_tail + 1)% FrameSize;
				}
			}
			break;
		case 1:    //��һ�� 0x68
			if (((*rev_head - *rev_tail +FrameSize)%FrameSize)>5)
			{
				if ((NetRevBuf[*rev_tail]== 0x68) && NetRevBuf[(*rev_tail+5)%FrameSize]== 0x68)
				{
	//				fprintf(stderr,"\nrev_tail[68-1] = %d",*rev_tail);
					*step = 2;
					*rev_delay = 0;
				}else{
					*step = 0;
					*rev_tail = (*rev_tail + 1)% FrameSize;
				}
			}
			break;
		case 2:	   //��rev_tail2��ʼ �糤���ֽ��� 0x16
			length = (NetRevBuf[(*rev_tail+ 2)%FrameSize] << 8) + NetRevBuf[(*rev_tail+ 1)%FrameSize];
			length = (length) >>2;
			if (length == 0)
			{
				*rev_tail = (*rev_tail + 1)% FrameSize;
				*step = 0;
			}
			if((*rev_head-*rev_tail+FrameSize)%FrameSize >= (length+8)){

//				fprintf(stderr,"\nlen=%d rev_tail3 = %d  [%02x]",length,(*rev_tail + 6 + length + 2 + FrameSize)% FrameSize ,NetRevBuf[ (*rev_tail + 6 + length + 1 + FrameSize)% FrameSize ]);
//				for (i=0;i<length+8;i++) {
//					if ((i%16) == 0) fprintf(stderr,"\n");
//					fprintf(stderr,"%02x ",NetRevBuf[ (*rev_tail + i + FrameSize)% FrameSize ]);
//				}
				if(NetRevBuf[ (*rev_tail + 6 + length + 1 + FrameSize)% FrameSize ]== 0x16)
				{
//					fprintf(stderr,"Conf[%d]=%x",(*rev_tail + 6 + FrameSize)% FrameSize,NetRevBuf[ (*rev_tail + 6 + FrameSize)% FrameSize ]);
					if((NetRevBuf[ (*rev_tail + 6 + FrameSize)% FrameSize ]& 0x80) == 0){
						*rev_delay = 0;
						for(i=0;i<length+8;i++)
						{
							dealbuf[i] = NetRevBuf[*rev_tail];
//							fprintf(stderr,"%02x ",dealbuf[i]);
							*rev_tail = (*rev_tail + 1) % FrameSize;
						}
						*step = 0;//������һ��
						return (length+8);
					}else {
						*rev_tail = (*rev_tail + 6 + length + 2 + FrameSize)% FrameSize;
						*step = 0;//������һ��
						break;
					}
				}
				else
				{
//					fprintf(stderr,"\n  ?? !! tail=%d head=%d",*rev_tail,*rev_head);
					if (*rev_delay < delay_num)
					{
						(*rev_delay)++;
						delay(10);
						break;
					}else
					{
						*rev_delay = 0;
						*rev_tail = (*rev_tail +1 )% FrameSize;
						*step = 0;//���ص�һ��
					}
				}
			}else
			{
//				fprintf(stderr,"\n  ## !! tail=%d head=%d",*rev_tail,*rev_head);
				if (*rev_delay < delay_num)
				{
					(*rev_delay)++;
					delay(10);
					break;
				}else
				{
					*rev_delay = 0;
					*rev_tail = (*rev_tail +1 )% FrameSize;
					*step = 0;//���ص�һ��
				}
			}
			break;
		default :
			break;
	}
	return 0;
}
//--------------------------------------------------------
#endif
#endif /*JPublicFunctionH*/
