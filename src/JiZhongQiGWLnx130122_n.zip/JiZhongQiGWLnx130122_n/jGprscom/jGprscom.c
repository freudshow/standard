
#include "jGprscom.h"
int NoDataTime(time_t old_t)//���ؼ�����������ͨѶ������
{
	time_t now_time;
	if (old_t>0)
	{
		now_time = time(NULL);
		return (now_time - old_t);
	}
	return 0;
}

int SendATCommand(char *buf,int len,int com)
{
	int re;
	re = write(com, buf, len);
	if (re < 0)
		re = 0;
	return (re);
}
int RecieveFromComm(unsigned char *buf,int mlen,int com)
{
	int len ;
	int j;
	if (mlen <= 0)
		return 0;
	j = 0;

	len = read(com, buf, mlen);//RES_LENGTH
	if (len<0)
		len = 0;
	return len;
}

int CheckAT()
{
	int timeout = 0,i,err;

	do{
		err=0;
		delay(100);
		timeout++;
		SendATCommand("at\r",3,ComPort);
		delay(100);
		memset(Mrecvbuf,0,RES_LENGTH);
		RecieveFromComm(Mrecvbuf,RES_LENGTH,ComPort);
		for(i=0;i<RES_LENGTH-10;i++)
		{
			fprintf(stderr, "%c",Mrecvbuf[i]);
			if((Mrecvbuf[i]=='O')&&(Mrecvbuf[i+1]=='K'))
			{
				err=1;
				break;
			}
		}
		if (err==1)
			break;
	}while(timeout <50);
	if (timeout>=50)
		return 0;
	return 1;
}
int CheckCCID()
{
	int timeout = 0,i,scid;
	char scidstr[50];
	memset(scidstr,0,50);
	do{
		scid=0;
		timeout++;
		SendATCommand("AT^SCID\r",8,ComPort);
		delay(100);
		memset(Mrecvbuf,0,RES_LENGTH);
		RecieveFromComm(Mrecvbuf,RES_LENGTH,ComPort);

		for(i=0;i<RES_LENGTH-10;i++)
		{
			if((Mrecvbuf[i]=='^')&&(Mrecvbuf[i+1]=='S')&&(Mrecvbuf[i+2]=='C')&&(Mrecvbuf[i+3]=='I')&&(Mrecvbuf[i+4]=='D'))
			{
				scid=1;
				break;
			}
		}
		if (scid==1)
		{
			if(sscanf((char *)&Mrecvbuf[i],"^SCID:%s",scidstr)==1)
			{
				memcpy(JDataFileInfo->logininfo.ICCIDstr,scidstr,20);
				break;
			}
		}
	}while(timeout<50);
	if (timeout>=50)
		return 0;

	return 1;
}
int CheckIMSI()
{
	int timeout = 0,i,imsi;
	char imsistr[50];
	memset(imsistr,0,50);
	fprintf(stderr,"\nCHECKIMSI");
	do{
		imsi=0;
		timeout++;
		SendATCommand("AT+CIMI\r",8,ComPort);
		delay(100);
		memset(Mrecvbuf,0,RES_LENGTH);
		RecieveFromComm(Mrecvbuf,RES_LENGTH,ComPort);

		for(i=0;i<RES_LENGTH-10;i++)
		{
			if((Mrecvbuf[i]=='O')&&(Mrecvbuf[i+1]=='K'))
			{
				imsi=1;
				break;
			}
		}
		if (imsi==1)
		{
			if(sscanf((char *)&Mrecvbuf[0],"AT+CIMI%s",imsistr)==1)
			{
				memcpy(JDataFileInfo->logininfo.IMSIstr,imsistr,15);
				break;
			}
		}
	}while(timeout<50);
	if (timeout>=50)
		return 0;

	return 1;
}

int CheckCSQ(int com)
{
	int timeout = 0,i,k,l,csq;
	fprintf(stderr,"\n-incheck csq");
	do{
		csq=0;
		timeout++;
		SendATCommand("at+csq\r",7,com);
		delay(500);
		memset(Mrecvbuf,0,RES_LENGTH);
		RecieveFromComm(Mrecvbuf,RES_LENGTH,com);
		for(i=0;i<RES_LENGTH-10;i++)
		{
			if((Mrecvbuf[i]=='+')&&(Mrecvbuf[i+1]=='C')&&(Mrecvbuf[i+2]=='S')&&(Mrecvbuf[i+3]=='Q')&&(Mrecvbuf[i+4]==':'))
			{
				csq=1;
				break;
			}
		}
		if (csq==1)
		{
			if(sscanf((char *)&Mrecvbuf[i],"+CSQ:%d,%d",&k,&l)==2)
			{
				if (k!=99)
				{
					JDataFileInfo->DayRunTj.GprsCSQ = k;
					break;
				}
			}
		}
	}while(timeout<30);
	if (timeout>=30)
		return 0;
	return 1;
}
int CheckCreg()
{
	int timeout=0,i,chk,k,l;
	do{
		timeout++;
		chk=0;
		SendATCommand("at+creg?\r",9,ComPort);
		delay(1000);
		memset(Mrecvbuf,0,RES_LENGTH);
		RecieveFromComm(Mrecvbuf,RES_LENGTH,ComPort);

		for(i=0;i<RES_LENGTH-10;i++)
		{
			if((Mrecvbuf[i]=='+')&&(Mrecvbuf[i+1]=='C')&&(Mrecvbuf[i+2]=='R')&&(Mrecvbuf[i+3]=='E')&&(Mrecvbuf[i+4]=='G')&&(Mrecvbuf[i+5]==':'))
			{
				chk=1;
				break;
			}
		}
		if (chk==1)
		{
			if(sscanf((char *)&Mrecvbuf[i],"+CREG:%d,%d",&k,&l)==2)
			{
				if ((k==0)&&(l==1))
					break;
				if ((k==0)&&(l==5))
					break;
			}
		}
	}while(timeout <70);
	if (timeout>=70)
		return 0;
	return 1;
}

int CheckCNUM()
{
	int timeout = 0,i,imsi;
	char Cnumstr1[50];
	char Cnumstr2[50];
	char Cnumstr3[50];
	memset(Cnumstr1,0,50);memset(Cnumstr2,0,50);memset(Cnumstr3,0,50);
	fprintf(stderr,"\nCHECKCNUM");
	do{
		imsi=0;
		timeout++;
		SendATCommand("AT+CNUM\r",8,ComPort);
		delay(200);
		memset(Mrecvbuf,0,RES_LENGTH);
		RecieveFromComm(Mrecvbuf,RES_LENGTH,ComPort);

		for(i=0;i<RES_LENGTH-10;i++)
		{
			fprintf(stderr,"%c",Mrecvbuf[i]);
			if((Mrecvbuf[i]=='O')&&(Mrecvbuf[i+1]=='K'))
			{
				imsi=1;
				break;
			}
		}
		if (imsi==1)
		{
			if(sscanf((char *)&Mrecvbuf[0],"+CNUM:%s,%s,%s",Cnumstr1,Cnumstr2,Cnumstr3)==1)
			{
				fprintf(stderr,"\nCNUM= %s  ,  %s  , %s",Cnumstr1,Cnumstr2,Cnumstr3);
				break;
			}
		}
	}while(timeout<10);
	if (timeout>=10)
		return 0;

	return 1;
}

int ATSMSO()
{
	int len,j;
	int timeout = 0;
	do{
		delay(100);
		timeout++;
		SendATCommand("AT^SMSO\r",8,ComPort);
		delay(100);
		memset(Mrecvbuf,0,RES_LENGTH);
		len = RecieveFromComm(Mrecvbuf,RES_LENGTH,ComPort);
		if(strstr((char *)Mrecvbuf,"OK")>0)
			break;//��⵽  ��OK��
	}while(timeout <50);
	fprintf(stderr,"\n\r SMSO !!! recieve ComPort==%d  len==%d",ComPort,len);
	fprintf(stderr,"\n\r");

	if (len > 0)
	{
		for(j=0; j<len; j++)
			printf("%c",Mrecvbuf[j]);
	}
	if (timeout>=50)
		return 0;
	return 1;
}
int CheckModem()
{
	printf("\n\rCheckModem          begin\n\r" );
	if (!ATSMSO())
	{
		return 0;
	}
	printf("AT SMSO                     ok\n\r" );

	if (!CheckAT())
	{
		return 0;
	}
	printf("AT CHECK                    ok\n\r" );
	if (!CheckCCID())
	{
		return 0;
	}
//	SendATCommand("AT+CPBW=123456\r",15,ComPort);
	printf("AT CCID                     [%s]\n\r", JDataFileInfo->logininfo.ICCIDstr);
	if (!CheckIMSI())
	{
		return 0;
	}
	printf("AT IMSI                     [%s]\n\r", JDataFileInfo->logininfo.IMSIstr);

//	if (!CheckCNUM())
//	{
//		return 0;
//	}
//	printf("AT CNUM                     ok\n\r");
	if(!CheckCSQ(ComPort))
	{
		return 0;
	}
	printf("step 2   CheckCSQ           [%d]\n\r ",JDataFileInfo->DayRunTj.GprsCSQ);


	if(!CheckCreg())
	{
		return 0;
	}
	printf("\n\r step 3   CheckCreg          ok\n\r");

	close(ComPort);   //���ر�

	return 1;
}
int tryifconfig()
{
	  int sock;
	  struct sockaddr_in  sin;
	  struct ifreq  ifr;
	  sock = socket(AF_INET, SOCK_DGRAM, 0);
	  if   (sock   ==   -1)
	  {
		  return   -1;
	  }
	  strncpy(ifr.ifr_name, ETH_NAME, IFNAMSIZ);
	  ifr.ifr_name[IFNAMSIZ   -   1]   =   0;
	  if (ioctl(sock, SIOCGIFADDR,  &ifr)   <   0)
	  {
		  if(close(sock) == -1)
		  {
			  printf(" tryifconfig: fail to close !!!\n\r");
		  }
		  sock=-1;
		  return   -1;
	  }
	  memcpy(&sin,   &ifr.ifr_addr,   sizeof(sin));
	  if (sin.sin_addr.s_addr >0)
	  {
		  close(sock);
		  sock=-1;
		  memset(pppip,0,16);
		  sprintf(pppip,"%s",inet_ntoa(sin.sin_addr));
		  return 1;
	  }
	  close(sock);
	  sock=-1;
	  return 0;
}

void initm37i()
{
	printf("\n  reset M37i\n");
	gpio_write("gpoGPRS_POWER", 1);
	gpio_write("gpoGPRS_RST", 1);
	gpio_write("gpoGPRS_SWITCH", 1);
	mydelay(2,ProjectNo,JProgramInfo);
	gpio_write("gpoGPRS_RST", 0);
	delay(100);
	gpio_write("gpoGPRS_RST", 1);
	mydelay(5,ProjectNo,JProgramInfo);
	gpio_write("gpoGPRS_SWITCH", 0);
	mydelay(1,ProjectNo,JProgramInfo);
	gpio_write("gpoGPRS_SWITCH", 1);
	return ;
}

int ppppro()
{
	unsigned char Parity[20];
	sprintf((char*)Parity,"none");
	int i = 0;
	system("pkill pppd");
	initm37i();
	mydelay(2,ProjectNo,JProgramInfo);
	if (ComPort > 0) close(ComPort);
	ComPort = OpenComCarr(1,9600,Parity,1,8);
	if(ComPort <= 0)
	{
		fprintf(stderr,"GPRS37i SerialCOM init failed!!!");
		return NO;
	}
	if (CheckModem()==1)//����modem
	{
		system("pppd call gprs &");//��ʼ����
		while(1)
		{
	    	if (tryifconfig()==1)
	    	{
	    		printf("\n get ip !! : %s\n",pppip); printf("\n ");
	    		return OK;
	    	}
	    	 i++;
	    	if (i>40) break;
	    	mydelay(1,ProjectNo,JProgramInfo);
		}
	}
	return NO;
}


/**************************************************
 *�ر�����
 * **********************************************/
int close_socket(int *skfd)
{
	if (*skfd > 0)
	{
		close(*skfd);
		*skfd = -1;
	}
    return 0;
}
/**************************************************
 *��������
 * **********************************************/
int connect_socket(char * server,int serverPort){
	int    result;
    struct sockaddr_in    addr;
    struct timeval timeo;
    unsigned long ul1 = 0;//������
    char *optval2;

    close_socket(&sockfd);
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) <0)
	{
    	fprintf(stderr, "\ncreate socket error! [%s]\n\r ",strerror(errno)  );
		return -1;
	}
	fprintf(stderr,"\nconnect socket =%d\n\r",sockfd);

	optval2 = "ppp0"; // 4 bytes long, so 4, below:
	setsockopt(sockfd, SOL_SOCKET, SO_BINDTODEVICE, optval2, 4);

	result = ioctl(sockfd, FIONBIO, (unsigned long*)&ul1);
	if(result< 0)
	{
		fprintf(stderr,"\r\nioctl_socket err [%s]\r\n",strerror(errno));
    	close_socket(&sockfd);
		return -1;
	}
    bzero(&addr,sizeof(addr));
    addr.sin_family=AF_INET;
    addr.sin_port=htons(serverPort);
    addr.sin_addr.s_addr=inet_addr(server);
    fprintf(stderr,"\nGprscom��Begin Connect ip=%s  port=%d",server,serverPort);
    if(connect(sockfd,(struct sockaddr*)&addr,sizeof(addr))<0)
    {
    	fprintf(stderr,"\n\r socket connect errs [%s]",strerror(errno) );
    	close_socket(&sockfd);
    	return -1;
	}

	timeo.tv_sec  = 0;
	timeo.tv_usec = 500;
	result = setsockopt(sockfd,SOL_SOCKET,SO_RCVTIMEO,(char *)&timeo.tv_sec,sizeof(struct timeval));
	if (result < 0)
	{
		fprintf(stderr,"\r\n setsockopt err[%s]\n\r",strerror(errno));
    	close_socket(&sockfd);
		return -1;
	}
	if (sockfd>0)
		printf("\nClient Connection Ok! socket %d\n",sockfd);
    return sockfd;
}
void  net_send(INT8U * buffer,INT16U len)
{
	INT16U i;
	size_t  nleft;
	ssize_t nwritten;

	nwritten = 0;
	nleft = len;
	if (len > 0)
		fprintf(stderr,"\nGprs send [%d bytes]:\n",len);
	while( nleft > 0)
	{
		nwritten = send(sockfd, buffer, nleft,0);
		if (nwritten > 0)
		{
			for(i=0; i<nwritten; i++)
				fprintf(stderr,"%02x ",buffer[i]);
		}
		if (nwritten<= 0)
		{
			if (errno == EINTR)
				nwritten = 0;
			else
			{
				return ;
			}
		}
		nleft -= nwritten;
		buffer += nwritten;
	}
	return ;
}
int  net_rev(int *skfd,INT8U* revbuf)
{
    int revcount=0,i,recLenth=0;
    unsigned char c;

    if (*skfd<0) return -1;

    ioctl(*skfd,FIONREAD,&revcount);
    if (revcount > 0)
    	fprintf(stderr,"\nGprs rev [%d bytes]:\n",revcount);
    else
    	return 0;
    for(i=0; i<revcount; i++)
    {
    	recLenth=recv(*skfd,&c,1,0);
    	revbuf[rev_head] = c;
    	rev_head = (rev_head + 1) % FrameSize;
    	fprintf(stderr,"%02x ",c);
    }
    return revcount;
}
void *SevPro(void* param)
{
	thread_param *client_para;
	client_para = (thread_param*)param;

	while(client_para->run)
	{
		mydelay(1,ProjectNo,JProgramInfo);
		net_rev(&sockfd,NetRevBuf);
	}
	close_socket(&sockfd);
	exit(EXIT_SUCCESS);
}
void GetCSQfun(TS ts,int* oldhour)
{
	if (*oldhour!=ts.Hour)
	{
		unsigned char Parity[20];
		sprintf((char*)Parity,"none");
		*oldhour = ts.Hour;
		if (csqComPort > 0)
		{
			close(csqComPort);
			csqComPort = 0;
		}
		csqComPort = OpenComCarr(7,57600,Parity,1,8);
		fprintf(stderr,"\n-ttyS7 csqCom=%d",csqComPort);
		if(csqComPort > 0)
		{
			CheckCSQ(csqComPort);
		}
		if (csqComPort > 0)
		{
			close(csqComPort);
			csqComPort = 0;
		}

//		if (*oldhour == 0)
//			memset(JDataFileInfo->logininfo.GprsCSQ,0xee,24);
//		JDataFileInfo->logininfo.GprsCSQ[*oldhour] = JDataFileInfo->DayRunTj.GprsCSQ ;
	}
	return;
}
void *DealPro(void* param)
{
	int notautoreport = 1;
	int taskno,oldhour;
	thread_param *para;
	para = (thread_param*)param;
	int firstflag=1;
	TS ts;
	TSGet(&ts);
	oldhour = ts.Hour;
	while(para->run)
	{
		mydelay(1,ProjectNo,JProgramInfo);
		TSGet(&ts);
		GetCSQfun(ts,&oldhour);//һСʱȡһ���ź�ǿ��
		if (para->online_flag == FALSE)
		{
			//stateflags.LoginOk =0;
//			if(JProgramInfo->jzq_login == GPRS_COM) {
//				JProgramInfo->jzq_login = 0;
//			}
			firstflag = TRUE;
			continue;
		}
		if ((para->online_flag == TRUE) && (para->login_flag == NO))//���ߣ�����û�е�½
		{
			if ((NoDataTime(para->old_time ) > com_para.Heartbeat) ||(firstflag ==TRUE))
			{
				fprintf(stderr,"\n��ʼ��½");
				firstflag = FALSE;
				LinkCtrl(JConfigInfo,&JProgramInfo->PFC,1,para->sendbuf,&para->sendlen,sendfunp);//���͵�½
				sprintf(JDataFileInfo->logininfo.timestr,"%04d-%02d-%02d %02d:%02d:%02d",ts.Year,ts.Month,ts.Day,ts.Hour,ts.Minute,ts.Sec);
				JDataFileInfo->DayRunTj.LoginNum++;
				JDataFileInfo->YueRunTj.LoginNum++;
				JProgramInfo->FileSaveFlag.loginflag= 1;
				para->old_time = time(NULL);
				para->linktst_num++;
			}
		}
		if (para->login_flag == OK)//�Ѿ���½�ɹ�
		{
			JProgramInfo->jzq_login = GPRS_COM;
			JProgramInfo->stateflags.LoginOk =GPRS_COM;
			if (NoDataTime(para->old_time ) > com_para.Heartbeat)
			{
				fprintf(stderr,"\n����");
				LinkCtrl(JConfigInfo,&JProgramInfo->PFC,3,para->sendbuf,&para->sendlen,sendfunp);//��������
				para->old_time = time(NULL);
				para->linktst_num++;
			}
			notautoreport = (JConfigInfo->jzqpara.CommStat & 0x02) >> 1 ;
			if (notautoreport == 1)
				continue;
			if (JDataFileInfo->ErcEvt.EC1old != JDataFileInfo->ErcEvt.EC1)
			{
				AutoReportLvl3data(0,JParamInfo3761,JProgramInfo,JConfigInfo,JDataFileInfo,1,sendfunp);
				JProgramInfo->FileSaveFlag.ercflag = 1;
			}
			//-------------����---------------
			initnextime(JParamInfo3761,JProgramInfo);
			for(taskno=0; taskno<Task2_Max;taskno++)
			{
				if (TwoLevelDataTask(taskno,JParamInfo3761,JProgramInfo)==1)
					AutoReportLvl1Lv2data(JProgramInfo->zone,JParamInfo3761,JProgramInfo,JConfigInfo,JDataFileInfo,J_2LEIDATE,taskno,sendfunp);

				if (OneLevelDataTask(taskno,JParamInfo3761,JProgramInfo)==1)
					AutoReportLvl1Lv2data(JProgramInfo->zone,JParamInfo3761,JProgramInfo,JConfigInfo,JDataFileInfo,J_1LEIDATE,taskno,sendfunp);
			}
			//--------------------------------
		}
		if (para->linktst_num > 5)
		{
			para->linktst_num = 0;
			para->online_flag = FALSE;
			if(JProgramInfo->jzq_login == GPRS_COM) {
				JProgramInfo->jzq_login = 0;
			}
			JProgramInfo->stateflags.LoginOk =0;
		}
	}
	exit(EXIT_SUCCESS);
}
//����ע��,��ȡ����źͳ�������
INT8U GetProjects(INT32S argc, char * argv[]) {
	char proc_name[32] = "";
	if (argc < 2)
		return (FALSE);
	ProjectNo = atoi(argv[1]);

	sprintf(proc_name, "%s", argv[0]);
    if((attach=name_attach(NULL, proc_name,0,JProgramInfo))  == NULL)
    {
	   printf( "ERR:'%s' runed,cann't regist\n\r", proc_name);
	   return (FALSE);
    }
	return (TRUE);
}

//�˳�����
void QuitProcess(int signo)
{
	JProgramInfo->Projects[ProjectNo].ProjectID=0;
    name_detach(attach, 0);
	param.run = 0;

	if (thread_rev_id>=0)
	{
		pthread_exit(&thread_sev);
		fprintf(stderr,"\n  thread_sev quit\n");
	}
	if (thread_deal_id>=0)
	{
		pthread_exit(&thread_deal);
		fprintf(stderr,"\n  thread_deal quit\n");
	}
	fprintf(stderr,"\n  jNetcom quit \n");
	exit(0);
}
void dealinit()
{
	step = 0;
	dialNum = 0;
	dialdelay = 0;
	rev_delay = 0;
	rev_tail = rev_head = rev_tail2 = rev_tail3 = 0;
	memset(NetRevBuf,0,FrameSize);
	memset(NetSendBuf,0,FrameSize);
}
void GetNetpara()
{
	memset(&com_para,0,sizeof(NetComPara));
	com_para.mainport = (JParamInfo3761->group1.f3.PortAddress[1]<<8) + JParamInfo3761->group1.f3.PortAddress[0];
	sprintf(com_para.mainip,"%d.%d.%d.%d",JParamInfo3761->group1.f3.IP[3],JParamInfo3761->group1.f3.IP[2],JParamInfo3761->group1.f3.IP[1],JParamInfo3761->group1.f3.IP[0]);
	com_para.bakport = (JParamInfo3761->group1.f3.PortAddress1[1]<<8) + JParamInfo3761->group1.f3.PortAddress1[0];
	sprintf(com_para.bakip,"%d.%d.%d.%d",JParamInfo3761->group1.f3.IP1[3],JParamInfo3761->group1.f3.IP1[2],JParamInfo3761->group1.f3.IP1[1],JParamInfo3761->group1.f3.IP1[0]);
	memcpy(com_para.apn,JParamInfo3761->group1.f3.APN,sizeof(com_para.apn));
	com_para.Heartbeat = JParamInfo3761->group1.f1.HeartInterval * 60;
	com_para.zone = JProgramInfo->zone;  //����
	if (com_para.Heartbeat > 900)
		com_para.Heartbeat = 900;
}
//void interfacepro()
//{
//	interface(&param.pkg_property,JParamInfo3761,JProgramInfo,JConfigInfo,JDataFileInfo);
//}
int main(int argc, char *argv[])
{
	struct sigaction sa1;
	int i;
	markver();

	JParamInfo3761 = Open1ShMem("ParamInfo3761",sizeof(ParamInfo3761),NULL);
	JDataFileInfo = Open1ShMem("DataFileInfo",sizeof(DataFileInfo),NULL);
	JConfigInfo = Open1ShMem("ConfigInfo",sizeof(ConfigInfo),NULL);
	JProgramInfo = Open1ShMem("ProgramInfo",sizeof(ProgramInfo),NULL);

	if (JParamInfo3761 ==NULL || JDataFileInfo==NULL || JConfigInfo==NULL || JProgramInfo == NULL)
		return EXIT_FAILURE;

	if(JProgramInfo->mainData.MemoryLength!=sizeof(ProgramInfo))
	{
		fprintf(stderr,"\nShare mem uncompared!\n");
		return EXIT_FAILURE;
	}
	if(!GetProjects(argc, argv))
	{
		fprintf(stderr,"\nBad command format. Type 'use exe_name' for help!\n");
		return EXIT_FAILURE;
	}
	fprintf(stderr,"Starting jGprscom ..........%d\n\r",ProjectNo);

	sa1.sa_handler = QuitProcess;
	sigemptyset(&sa1.sa_mask);
	sa1.sa_flags = 0;
	sigaction(SIGTERM, &sa1,NULL);
	sigaction(SIGSYS, &sa1,NULL);
	sigaction(SIGPWR, &sa1,NULL);
	sigaction(SIGKILL, &sa1,NULL);
	sigaction(SIGQUIT, &sa1,NULL);
	sigaction(SIGILL, &sa1,NULL);
	sigaction(SIGINT, &sa1,NULL);
	sigaction(SIGHUP, &sa1,NULL);
	sigaction(SIGABRT, &sa1,NULL);
	sigaction(SIGBUS, &sa1,NULL);
	signal(SIGPIPE,SIG_IGN);
	JProgramInfo->Projects[ProjectNo].ProjectID=getpid();
	sendfunp = net_send;
	sockfd = -1;
	JProgramInfo->stateflags.LoginOk =0;
	memset(&param,0,sizeof(thread_param));
	param.run = TRUE;
	thread_rev_id = pthread_create(&thread_sev,NULL, SevPro,&param);	    /*�������ݽ����߳�*/
	thread_deal_id = pthread_create(&thread_deal,NULL, DealPro,&param);	    /*����������֧�߳�*/
	dealinit();
	GetNetpara();
	ifGprscomm = TRUE;
	while(1)
	{
		ClearWaitTimes(ProjectNo,JProgramInfo);
		delay(10);

		if (ifGprscomm == USED)//�����GPRS
		{
			GetNetpara();
			if (param.online_flag  == FALSE)
			{
				if (ppppro() == OK)
				{
					dialNum = 0;
					for(i=0;i<3;i++)//���ųɹ�����������վ 3��
					{
						if (connect_socket(com_para.mainip,com_para.mainport)>0)
						{
							fprintf(stderr,"\n-----connetct ok!");
							param.online_flag = TRUE;
							dealinit();
							break;
						}else
							param.online_flag = FALSE;
						mydelay(5,ProjectNo,JProgramInfo);
					}
				}else
				{
					dialNum++ ;
					dialdelay = dialNum * 5 * 60;
					fprintf(stderr,"\n----����ȴ�  [%d]��",dialdelay);
					mydelay(dialdelay,ProjectNo,JProgramInfo) ;// ��һ��ʧ����ʱ 5����   �ڶ���ʧ����ʱ  10����    ������ʧ����ʱ15����
				}
			}else
			{
				deallen = StateProcess(&step,&rev_delay,10,&rev_tail,&rev_head,NetRevBuf,dealbuf) ;//����Ԥ����״̬������
				if (deallen > 0)
				{
					INT16S ret;
					ret = processData(com_para.zone,			  /*����*/
								(ParamInfo3761*)JParamInfo3761,   /*������ָ��*/
								(ProgramInfo*)JProgramInfo,
								(ConfigInfo*)JConfigInfo,
								(DataFileInfo*)JDataFileInfo,
								dealbuf,							/*��Ҫ�����ı���*/
								deallen,							/*���ĳ���*/
								NetSendBuf,							/*��Լ�ⷵ����Ҫ���ͱ��Ļ�����*/
								&sendlen,							/*���͵ĳ���*/
								sendfunp);								/*�ص�����*/

					if ( ret >= 0 )
					{
						fprintf(stderr,"\n��վ��Ӧ [AFN %02x]",ret);
						param.login_flag = OK;
						param.linktst_num = 0;
					}
//					if (sendlen > 0)		//Ӧ����
//					{
//						net_send(NetSendBuf,sendlen);
//						sendlen = 0;
//					}
				}//end ״̬�������ɹ�
				if (param.sendlen > 0)  //�������ͣ����������߼���DealPro�߳��У�
				{
					fprintf(stderr,"\n�������� %d bytes",param.sendlen);
					net_send(param.sendbuf,param.sendlen);
					param.sendlen = 0;
				}
			}
		}else ////end if use gprs
		{

		}
	}
	QuitProcess(0);
	return EXIT_SUCCESS;
}
