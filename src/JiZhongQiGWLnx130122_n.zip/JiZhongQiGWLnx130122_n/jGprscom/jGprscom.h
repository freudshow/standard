/*���ù��ñ���*/
#ifndef jGprscomm_H
#define jGprscomm_H
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <net/if.h>
#include <signal.h>
#include <pthread.h>
#include <netinet/tcp.h>
#include <mcheck.h>
#include <inc/pubfunction.h>
#include <inc/init.h>
#include <termios.h>
#include "j3761_2009.h"
#define    USED   1
#define    OK     1
#define    NO	  0


#define    RES_LENGTH  128 //�����ַ�����󳤶�
#define    ETH_NAME "ppp0"  //GPRS��������  GPRS���ź�������ִ��ifconfig���Կ���
typedef struct
{
	char mainip[30];
	int mainport;
	char bakip[30];
	int bakport;
	char apn[16];
	int Heartbeat;
	INT8U zone;
}NetComPara;

typedef struct {
	int run;
	INT8U online_flag;
	INT8U login_flag;
	INT16U sendlen;
	INT8U sendbuf[128];
	INT8U linktst_num;
	time_t old_time;
	UpPkgInfo pkg_property;
}thread_param;

//---------------------------------------------------------
name_attach_t  *attach;
ParamInfo3761* JParamInfo3761;
DataFileInfo*  JDataFileInfo;
ConfigInfo*    JConfigInfo;
ProgramInfo* JProgramInfo;
//---------------------------------------------------------
thread_param param;
NetComPara com_para;
void (* sendfunp)(INT8U *Data,INT16U len); //��Լ��ص����ͺ���
int GprsCSQ;
int ComPort;
int at_ComPort;
char pppip[16];
unsigned char Mrecvbuf[RES_LENGTH];  //at������ջ�����
int ComPort;
int csqComPort;
INT8U NetRevBuf[FrameSize];     //	������ջ�����
INT8U NetSendBuf[FrameSize];    // ���緢�ͻ�����
INT8U dealbuf[FrameSize];
int rev_head;
int rev_tail,rev_tail2,rev_tail3;
int deallen;
INT16U sendlen;
int rev_delay;
int length;
int step;
int send_head;
int send_tail;
int thread_rev_id;
int thread_deal_id;
pthread_t thread_sev;
pthread_t thread_deal;
unsigned char ProjectNo;
WirelessPara CommPara;   //ͨѶ����
int sockfd;
int ifGprscomm;
int connectok;
int step;
int dialNum;
int dialdelay;

#endif   /*jNetcomm_H*/
