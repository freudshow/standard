/*
 * �ļ�����esam.c
 * �ļ�������������ȫ��֤
 * ������ʶ��2012
 * �޸ı�ʶ��
 * �޸�������
 */
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <pthread.h>
#include <linux/spi/spidev.h>
#include <math.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <linux/types.h>
#include "semaphore.h"
#include "../jBase/inc/pubfunction.h"
#include "esam.h"
//#include "../jApub/jGWProtocol.h"

#define SENDTO   0
#define GETFROM  1

ParamInfo3761* JSetPara_AFN04_3761_2009;
ProgramInfo*   Jproginfo;
ConfigInfo*    Jcfginfo;
DataFileInfo*  Jdatafileinfo;
//================================================================================
AFNGPX afnGpx[5];
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void (*pBackCallFunc)(INT8U* sndbuf, INT16U sndlen);
INT8U YNPrint = 1;
char* PreFix = "\n>>";
INT16U    SendIndex;                //����ָʾλ��
INT8U     TempBuf[TEMPBUF_SIZE];    //��ʱ������
int       PackFlg;		            //������Դ 0 GPRS 1 485У��
int ReLink;
INT32S IfLoginOK; //��¼�Ƿ�ɹ�
INT8U     GwAddr[5];           //��ַ��
INT8U NeedTp;
INT8U TpBuff[6];
INT8U EC1, EC2, EC1old;
const INT8U CMP8U[9] = { 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80 };
INT8U ProjectNo;
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

int fp_stm8_spi = -1;

//ATT��ؽ�����ṹ����
static const char *devname = "/dev/spi0.0";//att7022
static uint8_t mode;
static uint8_t bits = 8;
static uint32_t speed = 16000;
#define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))

//================================================================================

int flagtmp;
char Spi_Send_flag; //spi���ͱ�־
//extern int fp2;
int spi_cmdread(int fd, uint32_t device, INT8U *cbuf, int16_t clen, INT8U *rbuf, int rlen);
pthread_t thread;
sem_t ATT_STM8_sem; //���ɺ͵�Ƭ��Э�����ź���
INT32U Esam_Recv_len;
int SelfheartCount;

int       jDealDealPrint=3;           //�����־
//++++++++++++++++++++++++++++++++++++++++++++++++++++
void GetDa(INT8U Da1, INT8U Da2)//�õ���Ϣ��DA��
{
	INT8U i;
	memset(DA, 0, PointMax);//DAֻʹ�ú�64λ
	if ((Da1 == 0) && (Da2 == 0)) {
		DA[0] = 1;
		return;
	}
	if (Da2 == 0) {
		memset(DA, 0, PointMax);
		return;
	}
	if ((Da1 == 0xff) && (Da2 == 0xff)) {
		memset(DA, 1, PointMax);
	}
	for (i = 0; i < 8; i++) {
		if (Da1 & CMP8U[i]) {
			DA[(Da2-1) * 8 + i + 1] = 1;
		}
	}
}
void GetDt(INT8U Dt1, INT8U Dt2)//�õ���Ϣ��DT��
{
	INT8U i;
	memset(DT, 0, 255);
	for (i = 0; i < 8; i++) {
		if (Dt1 & CMP8U[i]) {
			DT[Dt2 * 8 + i + 1] = 1;
		}
	}
}

INT8U SetDt1(INT8U Value) {
	INT8U Result = 1;
	if (Value == 0)
		return 0;
	Value = Value - 1;
	Result = Result << (Value % 8);
	return Result;
}
INT8U SetDt2(INT8U Value) {
	if (Value == 0)
		return 0;
	Value = Value - 1;
	return Value / 8;
}
INT8U SetDa1(INT16U Value) {
	INT8U Result = 1;
	if (Value == 0)
		return 0;
	Value = Value - 1;
	Result = Result << (Value % 8);
	return Result;
}
INT8U SetDa2(INT16U Value) {
	if (Value == 0)
		return 0;
	Value = Value - 1;
	return (Value / 8) + 1;
}
void EC() {//�¼�
	if (EC1old != EC1) {
		SendBuff[6] = SendBuff[6] | 0x20;
		SendBuff[SendIndex++] = EC1;
		SendBuff[SendIndex++] = EC2;
	} else {
		SendBuff[6] = SendBuff[6] & 0xdf;
	}
}
void TP() {
	TS ts;
	TSGet(&ts);
	if (NeedTp) {
		SendBuff[13] = SendBuff[13] | 0x80;
		memcpy(&SendBuff[SendIndex], TpBuff, 6);
		SendIndex = SendIndex + 6;
	} else {
		SendBuff[13] = SendBuff[13] & 0x7f;
	}
}

void FrameHeadCreate(INT8U PRM)
{
	SendIndex=0;
	memset(SendBuff,0,FrameSize);
	SendBuff[SendIndex++]=0x68;
	SendBuff[SendIndex++]=0;
	SendBuff[SendIndex++]=0;
	SendBuff[SendIndex++]=0;
	SendBuff[SendIndex++]=0;
	SendBuff[SendIndex++]=0x68;
	SendBuff[SendIndex++]=PRM;
	SendBuff[SendIndex++]=Asdu130Addr[0];
	SendBuff[SendIndex++]=Asdu130Addr[1];
	SendBuff[SendIndex++]=Asdu130Addr[2];
	SendBuff[SendIndex++]=Asdu130Addr[3];
	SendBuff[SendIndex++]=Asdu130Addr[4];
}
void SetDaDt(INT16U P, INT16U F) {
	SendBuff[SendIndex++] = SetDa1(P);
	SendBuff[SendIndex++] = SetDa2(P);
	SendBuff[SendIndex++] = SetDt1(F);
	SendBuff[SendIndex++] = SetDt2(F);
}
void SendALLACK(INT8U login) {
	CreateGWHead(0x80, 0);
	SendBuff[SendIndex++] = 0;//afn
	SendBuff[SendIndex++] = 0x60 | (Fseq & 0x0f);//seq
	SendBuff[SendIndex++] = 0;//Tmp130Buff[14];//da1e
	SendBuff[SendIndex++] = 0;//Tmp130Buff[15];//da2
	SendBuff[SendIndex++] = 1;//Tmp130Buff[16];//dt1
	SendBuff[SendIndex++] = 0;//Tmp130Buff[17];//dt2
	EC();
	TP();
	FrameTailCreate_Send(login);

}
void CreateGWHead(INT8U PRM, int zdflg)//
{
	SendIndex = 0;//���ݻ�����λ���
	//SdPrint("\n\rflag1 \n\r");
	memset(SendBuff, 0, FrameSize);
	fprintf(stderr,"\n\rCreate head! %02x", PRM);
	//SdPrint("\n\r");
	SendBuff[SendIndex++] = 0x68;//������ʼ��ʶ
	SendBuff[SendIndex++] = 0;//���ݳ���L1�ĵ�8λ
	SendBuff[SendIndex++] = 0;//���ݳ���L1�ĸ�8λ
	SendBuff[SendIndex++] = 0;
	SendBuff[SendIndex++] = 0;
	SendBuff[SendIndex++] = 0x68;//������ʼ��ʶ��β
	SendBuff[SendIndex++] = PRM;//������D7���䷽��λ��D6������־λ��D5֡����λ��D4֡������Чλ��D3-D0������
	SendBuff[SendIndex++] = Jcfginfo->jzqpara.Area_8016.JZ_XingZhuangQuHaoMa[1];//����������
	SendBuff[SendIndex++] = Jcfginfo->jzqpara.Area_8016.JZ_XingZhuangQuHaoMa[0];
	SendBuff[SendIndex++] = Jcfginfo->jzqpara.Address_8017.JZ_di_zhi[1];//�ն˵�ַ
	SendBuff[SendIndex++] = Jcfginfo->jzqpara.Address_8017.JZ_di_zhi[0];
	//��վ��ַ����Ϊ��վ�����ķ���֡ʱ��MSA��Ϊ0����Ϊ�ն������ķ���֡ʱ��MSAΪ0
	if (zdflg == 1)
		SendBuff[SendIndex++] = 0;//��վ��ַ�����ַ��־A3
	else
		SendBuff[SendIndex++] = GwAddr[4];
	//SdPrint("\n\r");
}
void SendSecyNAK(INT8U type,INT8U *data)	//376.1 3250you
{
	CreateGWHead(0x80, 0);
	SendBuff[SendIndex++]=0;//afn
	SendBuff[SendIndex++]=0x60|(Fseq&0x0f);//seq
	SendBuff[SendIndex++]=0;//Tmp130Buff[14];//da1e
	SendBuff[SendIndex++]=0;//Tmp130Buff[15];//da2
	SendBuff[SendIndex++]=0x08;//Tmp130Buff[16];//dt1
	SendBuff[SendIndex++]=0;//Tmp130Buff[17];//dt2
	SendBuff[SendIndex++]=type;
	memcpy(&SendBuff[SendIndex],data,16);
	SendIndex = SendIndex + 16;
	EC();
	TP();
	FrameTailCreate_Send(0);
}


INT8U CheckSumGW(INT8U *buf, INT16U len)//����У���룬�û��������İ�λλ��������ͣ������ǽ�λλ
{
	INT16U i;
	INT8U ret = 0;
	for (i = 0; i < len; i++) {
		ret = ret + buf[i];
	}
	return ret;
}
//l

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++

void FrameTailCreate_Send(INT8U login)//���ͱ���β����������
{
	INT16U temp,i=0;
	temp = SendIndex;
	fprintf(stderr,"\nFrameTailCreate_Send SendIndex:%d",temp);
	temp = temp - 6;//����û��������ĳ��ȣ��û����������Ȱ��������򡢵�ַ����·�û���������ֽ�����
	temp = (temp << 2) | 2;//�����ȵ�D0��D1Ϊ��Ϊ01��Ϊ��Э��ʹ��
	SendBuff[1] = temp & 0xff;//L1��L2��������һ����
	SendBuff[2] = (temp >> 8) & 0xff;
	SendBuff[3] = temp & 0xff;
	SendBuff[4] = (temp >> 8) & 0xff;
	SendBuff[SendIndex] = CheckSumGW(&SendBuff[6], SendIndex - 6);//����û���������У����
	SendIndex++;
	SendBuff[SendIndex++] = 0x16;//������ֹ��ʶ
	//SdPrint("\n\r send:::::::");

	//�����������0100:04Hʱ��Ϊ����/��Ӧ���֡���ͣ������跢�ͻ�Ӧ֡
	if ((TempBuf[6] & 0x0f) != 4)
	{
//		CreateSendInf(SendIndex, login);//���ͱ��� login 1��½����
		if(pBackCallFunc != NULL)
			pBackCallFunc(SendBuff,SendIndex);
	}
	fprintf(stderr,"\nFrameTailCreate_Send ");
	for (i = 0; i < SendIndex; i++) {
		fprintf(stderr,"%02X ",SendBuff[i]);
	}
	fprintf(stderr,"\n\r");
//	delay(100);
//
//	if (PackFlg == 0) {
//		if (!Jproginfo->Gprs_ok)
//		{
//			SdPrint("FrameTailCreate_Send ");
//			for (i = 0; i < SendIndex; i++) {
//				SdPrint("%02X ",SendBuff[i]);
//			}
//			SdPrint("\n\r");
//		}
//	}
	Fseq++;
}




int gpio_read(char *devname)
{
	int data=0, fd=0;
	char devpath[100];
	sprintf(devpath, "%s", devname);
	if((fd = open(devpath, O_RDWR | O_NDELAY)) > 0)
	{
		read(fd,&data,sizeof(int));
		close(fd);
	}
	return data;
}

int gpio_write(char *devname, int data)
{
	int fd=0;
	char devpath[100];
	sprintf(devpath, "%s", devname);
	if((fd = open(devpath, O_RDWR | O_NDELAY)) > 0)
	{
		write(fd,&data,sizeof(int));
		close(fd);
		return 1;
	}
	return 0;
}

//ATT��ؽ�����ṹ����
//int device = 0;
//static const char *devname = "/dev/spi0.0";//att7022
//
//
//static uint8_t mode;
//static uint8_t bits = 8;
//static uint32_t speed = 16000;
//#define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))
//static void pabort(const char *s)
//{
//	perror(s);
//	//abort();
//}

/*spi����*/
static void dumpstat(const char *name, int fd)
{
	int ret;
	mode |= SPI_CPHA;
//----------------------------------------yangdong
//	int data=1;
//	ret = ioctl(fd, SPI_IOC_RD_LSB_FIRST, &data);
//	if (ret == -1)
//		printf("can't set spi mode");//pabort
//
//	printf("\ndata ===== %d\n", data);
//	ret = ioctl(fd, SPI_IOC_WR_LSB_FIRST, &data);
//	if (ret == -1)
//		printf("can't set spi mode");//pabort
//------------------------------------

	ret = ioctl(fd, SPI_IOC_WR_MODE, &mode);
	if (ret == -1)
		printf("can't set spi mode");//pabort

	ret = ioctl(fd, SPI_IOC_RD_MODE, &mode);
	if (ret == -1)
		printf("can't get spi mode");

	ret = ioctl(fd, SPI_IOC_WR_BITS_PER_WORD, &bits);
	if (ret == -1)
		printf("can't set bits per word");

	ret = ioctl(fd, SPI_IOC_RD_BITS_PER_WORD, &bits);
	if (ret == -1)
		printf("can't get bits per word");


	ret = ioctl(fd, SPI_IOC_WR_MAX_SPEED_HZ, &speed);
	if (ret == -1)
		printf("can't set max speed hz");

	ret = ioctl(fd, SPI_IOC_RD_MAX_SPEED_HZ, &speed);
	if (ret == -1)
		printf("can't get max speed hz");

	//printf("%s: spi mode %d, %d bits per word, %d Hz (%d KHz)\n",
	//	name, mode, bits,  speed,speed/1000);
}

int spi_close(int fd)
{
	close(fd);
	return 1;
}


int spi_cmdread(int fd, uint32_t device, INT8U *cbuf, int16_t clen, INT8U *rbuf, int rlen)
{
	unsigned char rx[BUFLEN],i;
	struct spi_ioc_transfer	xfer[2];
	unsigned char tx[BUFLEN];
	memset(tx,0x00,BUFLEN);
	memset(rx,0x00,BUFLEN);
	memset(xfer, 0,  sizeof xfer);

	for(i=0;i<clen;i++)
		tx[i]=cbuf[i];
	xfer[0].tx_buf = (int)tx;
	xfer[0].len = clen;
	//xfer[0].delay_usecs=10;
	//printf send
//	printf("\n spi read tx-buf:  clen = %d\n",clen);
//	for(i=0;i<clen;i++)
//	{
//		printf("%02x ",cbuf[i]);
//	}

	xfer[1].rx_buf = (int) rx;
	xfer[1].len = rlen;
//	//xfer[1].delay_usecs=10;
	gpio_write("/dev/gpoESAM_CS", 0);
	ioctl(fd, SPI_IOC_MESSAGE(2), xfer);
	gpio_write("/dev/gpoESAM_CS", 1);
	for(i=0; i<rlen; i++)
		rbuf[i]=rx[i];
//printf recv
//	printf("\n spi read rx-buf:  rlen = %d\n",rlen);
//	for(i=0;i<rlen;i++)
//	{
//		printf("%02x ",rbuf[i]);
//	}

	return 1;
}

int spi_cmdrecv(int fd, uint32_t device, INT8U *cbuf, int16_t clen, INT8U *rbuf, int rlen)
{
	unsigned char rx[BUFLEN],i;
	struct spi_ioc_transfer	xfer[2];
	unsigned char tx[BUFLEN];
	memset(tx,0,BUFLEN);
	memset(rx,0,BUFLEN);
	memset(xfer, 0,  sizeof xfer);


	xfer[1].rx_buf = (int) rx;
	xfer[1].len = rlen;
	//xfer[1].delay_usecs=10;
	gpio_write("gpoESAM_CS", 0);
	ioctl(fd, SPI_IOC_MESSAGE(1), xfer);
	gpio_write("gpoESAM_CS", 1);
	for(i=0; i<rlen; i++)
		rbuf[i]=rx[i];

	printf("\n spi read rx-buf:  rlen = %d\n",rlen);
	for(i=0;i<rlen;i++)
	{
		printf("%02x ",rbuf[i]);
	}
	return 1;
}



void SPIinit()
{
	int ret,i;
	if (fp_stm8_spi != -1) {
		spi_close(fp_stm8_spi);
	}
	i=0;
	ret=0;
	fp_stm8_spi = open(devname, O_RDWR);
	if (fp_stm8_spi < 0)
		printf("can't open spi0.0 device");//pabort
	dumpstat(devname,fp_stm8_spi);
}


INT8U esam_read(int fd)
{
	INT8U recv_c, tmpbuf;
	spi_cmdread(fd, 0, &tmpbuf, 0, &recv_c, 1);
	return recv_c;
}

void esam_write(int fd, INT8U *buf, INT8U len)
{
	int i;
	INT8U sbuf[512];
	INT8U tmpbuf;
	memset(sbuf, 0, 512);
	sbuf[0] = 0xfe;
	sbuf[1] = 0xfe;
	sbuf[2] = 0xfe;
	sbuf[3] = len;
	for(i=0; i<len; i++)
		sbuf[4+i] = buf[i];

	for(i=0; i<len+4; i++)
	{
		spi_cmdread(fd, 0, &sbuf[i], 1, &tmpbuf, 0);
		OSTimeDly_ESAM(1);
	}
}

//----------------------------------------------------------------------------//
void *spi_recv(void *buf)
{
	INT8U headbuf[3], head_index=0, recv_begin_ok=0,c=0;
	INT32U recvbuf_index=0, j=0;
	INT8U *recv_buf;
	recv_buf = (INT8U *)buf;
	memset(headbuf, 0, 3);
	//printf("\n------Begin spi receive process------\n");

	while(1)
	{
		SelfheartCount = 0;
	//	CleardeadCount(PORT_ID);
		OSTimeDly_ESAM(1);
		j++;

		if(j==0xfff)
		{
			printf("\nj==0xf\n");
			break;
		}
		if(Spi_Send_flag == 0)
			continue;
		//spi_cmdread(fp_stm8_spi, 0, &ctmp, 0, &c, 1);
		c = esam_read(fp_stm8_spi);
		if((headbuf[0]==0xef && headbuf[1]==0xef && headbuf[2]==0xef))
		{
			//�յ�3��fe
			recv_begin_ok = 1;
			Esam_Recv_len = c;
			memset(headbuf, 0, 3);
			continue;
		}
		if(recv_begin_ok == 1)
		{//��ʼ��������
			recv_buf[recvbuf_index] = c;
			if(recvbuf_index >= Esam_Recv_len)
			{
				recv_begin_ok = 0;
//				printf("\nrecv buf  len=%d:   \n", Esam_Recv_len);
//				for(i=0; i<Esam_Recv_len; i++)
//				{
//					printf("%02x ", recv_buf[i]);
//				}
//				printf("\n\n");
				recvbuf_index = 0;
				break;
			}
			recvbuf_index++;
		}
		if(c == 0xef)
		{
			headbuf[head_index] = 0xef;
			head_index++;
		}else
		{
			memset(headbuf, 0, 3);
			head_index = 0;
		}
	}

	 return ((void *)0);
}

int EsamProcess(INT8U *sendbuf1, int sendlen1, INT8U *sendbuf2, int sendlen2, INT8U *recvbuf)
{
	void *tret=NULL;
	int temp;
	memset(&thread, 0, sizeof(thread));
	Spi_Send_flag = 0;
//	struct timespec tsspec;
//	if (clock_gettime(CLOCK_REALTIME, &tsspec)==-1)
//		printf("clock_gettime error\n\r");
//	tsspec.tv_sec += 2;
//	sem_timedwait(&RtuDataAddr->ATT_STM8_sem, &tsspec);

	//sem_wait(&RtuDataAddr->ATT_STM8_sem);
	if((temp = pthread_create(&thread, NULL, spi_recv, (void *)&recvbuf[0])) != 0) //�������߳�
	{
		printf("thread spi_recv create fail!\n");
	}
	if(sendlen1!=0 || sendbuf1!=NULL)
		esam_write(fp_stm8_spi, sendbuf1, sendlen1);
	if(sendlen2!=0 || sendbuf2!=NULL)
		esam_write(fp_stm8_spi, sendbuf2, sendlen2);
	Spi_Send_flag = 1;
	pthread_join(thread, tret);

	//sem_post(&RtuDataAddr->ATT_STM8_sem);
	return 	Esam_Recv_len;
}

//������////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//==============================================================================================================
//initGpx() MAC�����ʼ�� p1 p2    getPx()��ȡp1 p2
//==============================================================================================================
void initGpx()
{
	int i,j;
	INT8U afnarray[5]={0x01 ,0x04 ,0x05 ,0x0f ,0x10};
	for(j=0;j<5;j++)
	{
		afnGpx[j].afn = afnarray[j];
		for(i=0;i<9;i++)
		{
			afnGpx[j].Gpxn[i].groupflag = i;	//  ����0,��ʾ���ַ��Ч
			afnGpx[j].Gpxn[i].group = i;    	//	1-7    0����Ϊ�����ַ
			if (i == 0)
			{
				afnGpx[j].Gpxn[i].p1 = 0x00;
				afnGpx[j].Gpxn[i].p2 = 0x01+j;
			}else
			{
				afnGpx[j].Gpxn[i].p1 = 0x14 + i;
				afnGpx[j].Gpxn[i].p2 = 0x0B + j;
			}
		}
	}
}
int getPx(INT8U afn,INT8U group,INT8U *p1 ,INT8U *p2)
{
	int i,j,re=0;
	for(j=0;j<5;j++)
	{
		if (afnGpx[j].afn == afn)
		{
			for(i=0;i<9;i++)
			{
				if (afnGpx[j].Gpxn[i].group == group)
				{
					*p1 = afnGpx[j].Gpxn[i].p1;
					*p2 = afnGpx[j].Gpxn[i].p2;
					re = 1;
				}
			}
		}
	}
	return re;
}

//==============================================================================================================================
//=   ESAMӦ�ò���
//=   ��ԿЭ�� ��Կע��
//==============================================================================================================================
void print_to_get_esambyte(int type,INT8U *buf,int len)
{
	int i;
	if (type==0)// send to esam
	{
		printf("\n\r\n\r\n\r\n\rSend to > Esam   lenth=%d:\n", len);
		for(i=0; i<len; i++)
			printf("%02x ", buf[i]);
	}
	if (type==1)// get from esam
	{
		printf("\n\rRev from < Esam lenth=%d:\n", len);
		for(i=0; i<len; i++)
			printf("%02x ", buf[i]);
	}
	printf("\n\r");
	return;
}
//-------------------------------------------------------------------------
//Ӧ�ó����� ESAM Ӧ�ú���
INT8U AppCmpCmd(INT8U *buf,int len)
{
	INT8U data[100];
	int reclen;
	print_to_get_esambyte(SENDTO,buf,len);
	reclen = EsamProcess(buf,len,NULL,0,data);
	print_to_get_esambyte(GETFROM,data,reclen);

	if ((data[0]== 0x90)&&(data[1]==0x00))
		return 1;
	else
		return 0;
}
INT16U AppAskRandomData(INT8U *data)		 //��ȡ�����������
{
	int len,i;
	g_SendEsamBuf[0] = 0x00;
	g_SendEsamBuf[1] = 0x84;
	g_SendEsamBuf[2] = 0x00;
	g_SendEsamBuf[3] = 0x00;
	g_SendEsamBuf[4] = 0x08;

	print_to_get_esambyte(SENDTO,g_SendEsamBuf,5);
	len = EsamProcess(g_SendEsamBuf,5,NULL,0,data);
	print_to_get_esambyte(GETFROM,data,len);
	printf("\n�ն������: ");
	for(i=0;i<len;i++)
		printf("%02x",data[i]);
	printf("\n");
	if (len<=0)
		return 0;
	return 1;
}
INT16U AppAskSerialNumber(INT8U *data)		 //��ȡESAM���к�
{
	int len,i;
	unsigned char sernum[50];
	memset(sernum,0,50);
	g_SendEsamBuf[0] = 0x00;
	g_SendEsamBuf[1] = 0x12;
	g_SendEsamBuf[2] = 0x00;
	g_SendEsamBuf[3] = 0x00;
	g_SendEsamBuf[4] = 0x00;

	print_to_get_esambyte(SENDTO,g_SendEsamBuf,5);
	len = EsamProcess(g_SendEsamBuf,5,NULL,0,sernum);
	print_to_get_esambyte(GETFROM,sernum,len);

	if (len >= 18)
	{
		printf("\n�ն�������: ");
		for(i=10; i<=18; i++)
		{
			data[i-10] = sernum[i];
			printf("%02x",data[i-10]);
		}
		printf("\n");
		return 1;
	}
	return 0;
}
INT16U AppMainKeyUpdate(INT8U *key,INT8U *sign,INT8U keytype)
{
	int len,i;
	int lenth=0;
	int lenth2=0;

	unsigned char temp[50];
	//---------------------------------send key---------------
	memset(g_SendEsamBuf,0,512);

	g_SendEsamBuf[lenth++] = 0x90;
	if (keytype == 1)//���ع�Կ����
	{
		g_SendEsamBuf[lenth++] = 0x40;
		//cmd = 0x40;
	}
	else			 //��վ��Կ���ظ���
	{
		g_SendEsamBuf[lenth++] = 0x34;
		//cmd = 0x34;
	}

	g_SendEsamBuf[lenth++] = 0x00;
	g_SendEsamBuf[lenth++] = 0x00;
	g_SendEsamBuf[lenth++] = 0x92;

	//if (AppCmpCmd(g_SendEsamBuf,5)== 1)
	//{
		//lenth  = 0;
		//memset(g_SendEsamBuf,0,512);
		g_SendEsamBuf[lenth++] = 0x62;
		g_SendEsamBuf[lenth++] = 0x90;

		for(i=143;i>=0;i--)
			g_SendEsamBuf[lenth++] = key[i];
		//	memcpy(&g_SendEsamBuf[lenth],key,144);
		//	lenth = lenth + 144;

		print_to_get_esambyte(SENDTO,g_SendEsamBuf,lenth);
		len  = EsamProcess(g_SendEsamBuf,lenth,NULL,0,temp);
		print_to_get_esambyte(GETFROM,temp,len);

	//}else
	//	return 0;
	//-------------------------------send sign-----------------

	lenth2 = 0;
	memset(temp,0,50);
	memset(g_SendEsamBuf2,0,512);

	g_SendEsamBuf2[lenth2++] = 0x80;
	if (keytype == 1)//���ع�Կ����
	{
		g_SendEsamBuf2[lenth2++] = 0x40;
		//cmd = 0x40;
	}
	else			 //��վ��Կ���ظ���
	{
		g_SendEsamBuf2[lenth2++] = 0x34;
		//cmd = 0x34;
	}
	g_SendEsamBuf2[lenth2++] = 0x00;
	g_SendEsamBuf2[lenth2++] = 0x00;
	g_SendEsamBuf2[lenth2++] = 0x82;
	//if (AppCmpCmd(g_SendEsamBuf,5)== 1)
	//{
		//lenth2  = 0;
		//memset(g_SendEsamBuf2,0,512);
		g_SendEsamBuf2[lenth2++] = 0x60;
		g_SendEsamBuf2[lenth2++] = 0x80;

		for(i=127; i>=0; i--)
			g_SendEsamBuf2[lenth2++] = sign[i];
		//	memcpy(&g_SendEsamBuf2[lenth2],sign,128);
		//	lenth2 = lenth2 + 128;

		print_to_get_esambyte(SENDTO,g_SendEsamBuf,lenth);
		len  = EsamProcess(g_SendEsamBuf2,lenth2,NULL,0,temp);
		print_to_get_esambyte(GETFROM,temp,len);
		if ((temp[0]==0x90) && (temp[1]==0x00))
			return 1;
		else
			return 0;
	//}else
	//	return 0;
	//--------------------------------------------------------------------
}
INT16U AppMainKeyRemoteUpdate(INT8U *huihuakey,INT8U *key,INT8U *signature)
{
	int lenth,i,relen;
	INT8U temp[50];
	//--------------------------------------------------------��һ֡
	memset(g_SendEsamBuf,0,512);
memset(temp,0,50);
	lenth = 0;
	g_SendEsamBuf[lenth++] = 0x90;
	g_SendEsamBuf[lenth++] = 0x3C;
	g_SendEsamBuf[lenth++] = 0x00;
	g_SendEsamBuf[lenth++] = 0x00;
	g_SendEsamBuf[lenth++] = 0xFA;
	g_SendEsamBuf[lenth++] = 0x63;
	g_SendEsamBuf[lenth++] = 0x80;
	for(i=127;i>=0;i--)// 128		�Ự��Կ128�ֽ�
		g_SendEsamBuf[lenth++] = huihuakey[i];
	g_SendEsamBuf[lenth++] = 0x62;
	g_SendEsamBuf[lenth++] = 0x90;
	for(i=143;i>=26;i--)// 143-26	��վ��Կǰ118�ֽ�
g_SendEsamBuf[lenth++] = key[i]; //cuo

	print_to_get_esambyte(SENDTO,g_SendEsamBuf,lenth);
	relen  = EsamProcess(g_SendEsamBuf,lenth,NULL,0,temp);
	print_to_get_esambyte(GETFROM,temp,relen);

	//---------------------------------------------------------�ڶ�֡
	memset(g_SendEsamBuf,0,512);
	memset(temp,0,50);
	lenth = 0;
	g_SendEsamBuf[lenth++] = 0x80;
	g_SendEsamBuf[lenth++] = 0x3C;
	g_SendEsamBuf[lenth++] = 0x00;
	g_SendEsamBuf[lenth++] = 0x00;
	g_SendEsamBuf[lenth++] = 0x9C;
	for(i=25;i>=0;i--)  // 25-0		��վ��Կ��26�ֽ�
		g_SendEsamBuf[lenth++] = key[i];

	g_SendEsamBuf[lenth++] = 0x60;
	g_SendEsamBuf[lenth++] = 0x80;
	for(i=127;i>=0;i--)	//           ����ǩ��128�ֽ�
		g_SendEsamBuf[lenth++] = signature[i];

	print_to_get_esambyte(SENDTO,g_SendEsamBuf,lenth);
	relen  = EsamProcess(g_SendEsamBuf,lenth,NULL,0,temp);
	print_to_get_esambyte(GETFROM,temp,relen);

	if ((temp[0]== 0x90) && (temp[1]== 0x00))
		return 1;
	else
		return 0;
}
//�Գƹ�Կ����
INT16U AppDuichenKeyUpdate(INT8U *huihuakey,INT8U keynum,INT8U *randomData,INT8U *signature)
{
	INT8U temp[50];
	int groupnum,N;
	int i,lenth=0,j=0,len=0, relen=0,g;
	printf("\n\r in AppDuichenKey Num =%d",keynum);
	groupnum = keynum/4;
	if (keynum%4 >0) groupnum = groupnum + 1;// ��������

	for(g=0; g< groupnum; g++)				 // �����·�
	{
		if (keynum >= 4)//����ÿ����Կ���� N
			N = 4;
		else
			N= keynum;
		memset(g_SendEsamBuf,0,512);
		g_SendEsamBuf[lenth++] = 0x90;
		g_SendEsamBuf[lenth++] = 0x3A;
		g_SendEsamBuf[lenth++] = 0x00;
		g_SendEsamBuf[lenth++] = 0x00;
		g_SendEsamBuf[lenth++] = 0xA5;
		g_SendEsamBuf[lenth++] = 0x63;
		g_SendEsamBuf[lenth++] = 0x80;
		for(i=127;i>=0;i--)
			g_SendEsamBuf[lenth++] = huihuakey[i];
		g_SendEsamBuf[lenth++] = 0x64;
		g_SendEsamBuf[lenth++] = 0x00;
		g_SendEsamBuf[lenth++] = N*0x20;
		for(i=31;i>=0;i--)
		{
			//g_SendEsamBuf[lenth++] = duichenkey[g*4][i];
			g_SendEsamBuf[lenth++] = Dckey[g*4].data[i];
		}
		keynum-- ;
		print_to_get_esambyte(SENDTO,g_SendEsamBuf,lenth);
		memset(temp,0,50);
		len  = EsamProcess(g_SendEsamBuf,lenth,NULL,0,temp);
		printf("\n---��һ֡--keynum=%d  group=%d",keynum,g);
		print_to_get_esambyte(GETFROM,temp,len);
		//---------------------------------------------------------�ڶ�֡
		memset(g_SendEsamBuf,0,512);
		memset(temp,0,50);
		lenth = 0;
		g_SendEsamBuf[lenth++] = 0x80;
		g_SendEsamBuf[lenth++] = 0x3A;
		g_SendEsamBuf[lenth++] = 0x00;
		g_SendEsamBuf[lenth++] = 0x00;
		g_SendEsamBuf[lenth++] = (N-1)*32+0x82;
		for(i=1; i<N; i++)
		{
			for(j=31; j>=0; j--)
			{
				//g_SendEsamBuf[lenth++] = duichenkey[g*4+i][i*32+j];
				g_SendEsamBuf[lenth++] = Dckey[g*4+i].data[j];
			}
			keynum--;
		}
		g_SendEsamBuf[lenth++] = 0x60;
		g_SendEsamBuf[lenth++] = 0x80;
		for(i=127;i>=0;i--)	//           ����ǩ��128�ֽ�
			g_SendEsamBuf[lenth++] = signature[i];

		print_to_get_esambyte(SENDTO,g_SendEsamBuf,lenth);
		memset(temp,0,50);
		relen  = EsamProcess(g_SendEsamBuf,lenth,NULL,0,temp);
		printf("\n---�ڶ�֡--keynum=%d  group=%d",keynum,g);
		print_to_get_esambyte(GETFROM,temp,relen);

		if ((temp[0]== 0x90) && (temp[1]== 0x00))
		{
			continue;
		}else
			return 0; // �����һ��ʧ�ܣ����θ���ʧ��
	}
	return 1;
}
INT16U AppKeyReg(INT8U type,INT8U *MasterRandom,INT8U *SignData,INT8U *TermRandom,INT8U *keydata)
{
	int len,i;
	int lenth=0;
	unsigned char temp[512];

	printf("\n\r in AppKeyReg type =%d",type);
	memset(g_SendEsamBuf,0,512);
	g_SendEsamBuf[lenth++] = 0x80;
	g_SendEsamBuf[lenth++] = 0x36;
	if (type == 3)
		g_SendEsamBuf[lenth++] = 0x01;
	else
		g_SendEsamBuf[lenth++] = 0x02;
	g_SendEsamBuf[lenth++] = 0x00;
	g_SendEsamBuf[lenth++] = 0x8c;
	g_SendEsamBuf[lenth++] = 0x81;
	g_SendEsamBuf[lenth++] = 0x08;
	for(i=7;i>=0;i--)
		g_SendEsamBuf[lenth++] = MasterRandom[i];
//	memcpy(&g_SendEsamBuf[lenth],MasterRandom,8);
//	lenth = lenth + 8;

	g_SendEsamBuf[lenth++] = 0x60;
	g_SendEsamBuf[lenth++] = 0x80;
	for(i=127;i>=0;i--)
		g_SendEsamBuf[lenth++] = SignData[i];
//	memcpy(&g_SendEsamBuf[lenth],SignData,128);
//	lenth = lenth + 128;
	print_to_get_esambyte(SENDTO,g_SendEsamBuf,lenth);

	len  = EsamProcess(g_SendEsamBuf,lenth,NULL,0,temp);

	print_to_get_esambyte(GETFROM,temp,len);

	if ((temp[0]==0x61) && (temp[1] == 0xFA))
	{//ȡ��Ӧ��A��250�ֽڣ� ��ȡ��Ӧ��B��6�ֽڣ�
		printf("\n\r------ in get A&B");
		lenth = 0;
		memset(g_SendEsamBuf,0,512);//ȡ��A
		memset(temp,0,512);//
		g_SendEsamBuf[lenth++] = 0x00;
		g_SendEsamBuf[lenth++] = 0xc0;
		g_SendEsamBuf[lenth++] = 0x00;
		g_SendEsamBuf[lenth++] = 0x00;
		g_SendEsamBuf[lenth++] = 0xFA;
		print_to_get_esambyte(SENDTO,g_SendEsamBuf,lenth);

		len  = EsamProcess(g_SendEsamBuf,lenth,NULL,0,temp);

		for(i=0;i<250;i++)
			keydata[i] = temp[i];

		INT8U nex = temp[len-1];

		print_to_get_esambyte(GETFROM,temp,len);
		lenth = 0;
		memset(g_SendEsamBuf,0,512);//ȡ��B
		memset(temp,0,512);//
		g_SendEsamBuf[lenth++] = 0x00;
		g_SendEsamBuf[lenth++] = 0xc0;
		g_SendEsamBuf[lenth++] = 0x00;
		g_SendEsamBuf[lenth++] = 0x00;
		g_SendEsamBuf[lenth++] = nex;

		print_to_get_esambyte(SENDTO,g_SendEsamBuf,lenth);

		len  = EsamProcess(g_SendEsamBuf,lenth,NULL,0,temp);
		print_to_get_esambyte(GETFROM,temp,len);

		for(i=250;i<256;i++)
			keydata[i] = temp[i-250];

	}else
		return 0;
	return 1;
}
INT16U AppSendSign(INT8U *data,INT8U *randata,INT8U keytype)//����ǩ�����������ESAM������֤
{
	int len,i;
	int lenth=0;

	unsigned char temp[50];
	memset(g_SendEsamBuf,0,512);
	g_SendEsamBuf[lenth++] = 0x80;
	g_SendEsamBuf[lenth++] = 0x42;
	g_SendEsamBuf[lenth++] = 0x00;

	if (keytype == 1)//���ع�Կ��֤
	{
		printf("\n\r ���ع�Կ��֤  %d\n",keytype);
		g_SendEsamBuf[lenth++] = 0x01;
	}
	else			 //��վ��Կ��֤
	{
		printf("\n\r ��վ��Կ��֤ %d\n",keytype);
		g_SendEsamBuf[lenth++] = 0x09;
	}
	g_SendEsamBuf[lenth++] = 0x8C;
	g_SendEsamBuf[lenth++] = 0x81;
	g_SendEsamBuf[lenth++] = 0x08;

	for(i=7;i>=0;i--)
		g_SendEsamBuf[lenth++] = randata[i];

	g_SendEsamBuf[lenth++] = 0x60;
	g_SendEsamBuf[lenth++] = 0x80;

	for(i=127;i>=0;i--)
		g_SendEsamBuf[lenth++] = data[i];

	print_to_get_esambyte(SENDTO,g_SendEsamBuf,lenth);
	len  = EsamProcess(g_SendEsamBuf,lenth,NULL,0,temp);
	print_to_get_esambyte(GETFROM,temp,len);
	if ((temp[0]==0x90) && (temp[1]== 0x00))
		return 1;

	return 0;//��֤ǩ���ɹ����� 1      ʧ�ܷ��� 0
}
//�ǶԳ���Կ����
INT16U AppUnKeyUpdate(INT8U type,INT8U *key,INT8U *MasterRandom,INT8U *TerminalRandom,INT8U *Sign,INT8U *NewKey,INT8U *NewSign)
{
	int len,i,index;
	int lenth=0;
	unsigned char tempA[512];
	unsigned char tempB[512];
	unsigned char temp[1024];

	memset(g_SendEsamBuf,0,512);
	g_SendEsamBuf[lenth++] = 0x90;
	g_SendEsamBuf[lenth++] = 0x38;
	switch(type)
	{
	case 5://�ǶԳ���Կ��1����
		g_SendEsamBuf[lenth++] = 0x01;
		break;
	case 6://�ǶԳ���Կ��2����
		g_SendEsamBuf[lenth++] = 0x02;
		break;
	default :
		return 0;
	}
	g_SendEsamBuf[lenth++] = 0x00;
	g_SendEsamBuf[lenth++] = 0x8C;
	g_SendEsamBuf[lenth++] = 0x63;
	g_SendEsamBuf[lenth++] = 0x80;
	for(i=127;i>=0;i--)
		g_SendEsamBuf[lenth++] = key[i];
	g_SendEsamBuf[lenth++] = 0x81;
	g_SendEsamBuf[lenth++] = 0x08;
	for(i=7;i>=0;i--)
		g_SendEsamBuf[lenth++] = MasterRandom[i];
	print_to_get_esambyte(SENDTO,g_SendEsamBuf,lenth);
	len  = EsamProcess(g_SendEsamBuf,lenth,NULL,0,temp);
	print_to_get_esambyte(GETFROM,temp,len);
	//--------------------------------------------------

	memset(g_SendEsamBuf,0,512);
	lenth = 0;
	g_SendEsamBuf[lenth++] = 0x80;
	g_SendEsamBuf[lenth++] = 0x38;
	switch(type)
	{
	case 5://�ǶԳ���Կ��1����
		g_SendEsamBuf[lenth++] = 0x01;
		break;
	case 6://�ǶԳ���Կ��2����
		g_SendEsamBuf[lenth++] = 0x02;
		break;
	default :
		return 0;
	}
	g_SendEsamBuf[lenth++] = 0x00;
	g_SendEsamBuf[lenth++] = 0x82;
	g_SendEsamBuf[lenth++] = 0x60;
	g_SendEsamBuf[lenth++] = 0x80;
	for(i=127;i>=0;i--)
		g_SendEsamBuf[lenth++] = Sign[i];
	print_to_get_esambyte(SENDTO,g_SendEsamBuf,lenth);
	len  = EsamProcess(g_SendEsamBuf,lenth,NULL,0,temp);
	print_to_get_esambyte(GETFROM,temp,len);

	if ((temp[0]==0x61) &&(temp[1]==0xFA))// ���η��ͺ󷵻���ȷ��Ϣ
	{
		printf("\n\r Get F10 A & B\n");
		memset(g_SendEsamBuf,0,512);
		memset(tempA,0,512);
		memset(tempB,0,512);
		memset(temp,0,1024);
		lenth = 0;
		g_SendEsamBuf[lenth++] = 0x00;
		g_SendEsamBuf[lenth++] = 0xC0;
		g_SendEsamBuf[lenth++] = 0x00;
		g_SendEsamBuf[lenth++] = 0x00;
		g_SendEsamBuf[lenth++] = 0xFA;
		print_to_get_esambyte(SENDTO,g_SendEsamBuf,lenth);
		len  = EsamProcess(g_SendEsamBuf,lenth,NULL,0,tempA);	// ȡ������ A
		print_to_get_esambyte(GETFROM,tempA,len);
		printf("\ntempA[250]=%02x tempA[251]=%02x\n", tempA[250],tempA[251]);
		if ((tempA[250]==0x61)&& (tempA[251]==0x1A))
		{
			memset(g_SendEsamBuf,0,512);
			lenth = 0;
			g_SendEsamBuf[lenth++] = 0x00;
			g_SendEsamBuf[lenth++] = 0xC0;
			g_SendEsamBuf[lenth++] = 0x00;
			g_SendEsamBuf[lenth++] = 0x00;
			g_SendEsamBuf[lenth++] = 0x1A;
			print_to_get_esambyte(SENDTO,g_SendEsamBuf,lenth);
			len  = EsamProcess(g_SendEsamBuf,lenth,NULL,0,tempB);// ȡ������B
			//------- A + B = 0x61 0x90 + 144(��Կ) + 0x60 0x80 + 128(ǩ��)
			print_to_get_esambyte(GETFROM,tempB,len);

			for(i=0;i<250;i++)
				temp[i] = tempA[i];
			for(i=250;i<276;i++)
				temp[i] = tempB[i-250];
			printf("\n\r tempA+B \n\r");
			for(i=0;i<276;i++)
				printf("%02x ",temp[i]);
			printf("\n\r");
			if ((temp[0]==0x61)&&(temp[1]==0x90) && (temp[146]==0x60) && (temp[147]==0x80))
			{
				index = 2;
				memcpy(NewKey,&temp[index],144);
				index = index + 144 + 2;
				memcpy(NewSign,&temp[index],128);
				printf("\n\r F10 OK !\n\r");
				return 1;
			}else
				return 0;
		}else
			return 0;
	}else
		return 0;
}

//-------------------------------------------------------------------------
INT16U ProEsamF1(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	return 1;
}
INT16U ProEsamF2(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	return 1;
}
INT16U ProEsamF3(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	return 1;
}
INT16U ProEsamF4(INT8U Set,INT8U F,INT8U P,INT8U *Data)
{
	return 1;
}
INT16U ProEsamF5(INT8U Set,INT8U F,INT8U P,INT8U *Data)//��ȡ�ն������
{
	int i;
	INT8U randomData[8],serialNum[8];

	FrameHeadCreate(0x88);
	SendBuff[SendIndex++]=0x06;//afn
	SendBuff[SendIndex++]=0x60|(Fseq&0x0f);//seq
	SetDaDt(P,F);

	AppAskSerialNumber(serialNum);
	AppAskRandomData(randomData);
	for (i=7;i>=0;i--)
		SendBuff[SendIndex++] = randomData[i];
	//memcpy(&SendBuff[SendLen],randomData,8);
	//SendLen = SendLen + 8;

	for (i=7;i>=0;i--)
		SendBuff[SendIndex++] = serialNum[i];
	//memcpy(&SendBuff[SendLen],serialNum,8);
	//SendLen = SendLen + 8;

	EC();
	TP();
	FrameTailCreate_Send(0);
	return 16;
}
INT16U ProEsamF6(INT8U Set,INT8U F,INT8U P,INT8U *Data)//��Կ��֤
{
	//��վ����վ�����,��ǩ�� ͨ�� F6 ���͵��ն�,�ն˽��յ����������ǩ�����͸�ESAM,ESAM������֤���,F6����ȷ�ϻ����
	INT8U keyType,randomData[8],signature[128],errData[16];
	int index;
	index = 4;
	keyType = Data[index];
	index = index + 1;
	memcpy(randomData,&Data[index],8);
	index = index + 8;
	memcpy(signature,&Data[index],128);
	if (AppSendSign(signature,randomData,keyType) == 1)//��ǩ�ɹ�
	{
		SendALLACK(0);
	}else
	{
		memset(errData,0xff,16);
		SendSecyNAK(1,errData);
	}
	return 137;
}
INT16U ProEsamF7(INT8U Set,INT8U F,INT8U P,INT8U *Data)//��Կ��������
{
	int i;
	INT8U randomData[8],serialNum[8];
	//��վ������Կ��������,�ն��յ�F7����� ȡesam�������esam���к�

	//��Կ������������
	//1 ���ع�Կ����                           5 �ն˷ǶԳƶ� 2ע��
	//2 ��վ��Կ���ظ���                 6 �ն˷ǶԳ���Կ�� 1����
	//3 ��վ��ԿԶ�̸���                 7 �ն˷ǶԳ���Կ�� 2����
	//4 �ն˷ǶԳ���Կ�� 1ע��    8 �ն˶Գ���Կ����

	update_key_type = Data[4];
	printf("\n\r key_type = %d",update_key_type);

	FrameHeadCreate(0x88);
	SendBuff[SendIndex++] = 0x06;//afn
	SendBuff[SendIndex++] = 0x60|(Fseq&0x0f);//seq
	SetDaDt(P,F);

	SendBuff[SendIndex++] = update_key_type;
	AppAskSerialNumber(serialNum);
	delay(1000);
	AppAskRandomData(randomData);
//	memcpy(&SendBuff[SendLen],randomData,8);
//	SendLen = SendLen + 8;
	for (i=7;i>=0;i--)
		SendBuff[SendIndex++] = randomData[i];

//	memcpy(&SendBuff[SendLen],serialNum,8);
//	SendLen = SendLen + 8;
	for (i=7;i>=0;i--)
		SendBuff[SendIndex++] = serialNum[i];

	EC();
	TP();
	FrameTailCreate_Send(0);
	return 1;

}
INT16U ProEsamF8(INT8U Set,INT8U F,INT8U P,INT8U *Data)//��Կ����
{
	int keynum,k,i;
	INT16U index,ifok;
	INT8U errData[16];
	INT8U huihuakey[128];	// �Ự��Կ
	INT8U key[144];      	// ��վ���أ���Կ
	INT8U randomData[8]; 	// �ն������
	INT8U signature[128];	// ����ǩ��
	//INT8U duichenkey[KEY_NUM][32]; // �ն˶Գ���Կ KEY_NUM == 12

	//	��Կ������������
	//	1 ���ع�Կ����                           5 �ն˷ǶԳƶ� 2ע��
	//	2 ��վ��Կ���ظ���                 6 �ն˷ǶԳ���Կ�� 1����
	//	3 ��վ��ԿԶ�̸���                 7 �ն˷ǶԳ���Կ�� 2����
	//	4 �ն˷ǶԳ���Կ�� 1ע��    8 �ն˶Գ���Կ����

	update_key_type = Data[4];
	F8_length = Data[6]<<8 | Data[5];
	printf("\n\r ----F8 length=%d Type=%d",F8_length,update_key_type);

	memset(g_F8tmpData,0,1024);
	memcpy(g_F8tmpData,&Data[7],F8_length );

	index = 0;  i = 0; ifok = 0;
	switch (update_key_type)
	{
		case 1:		// ���ع�Կ����
			memcpy(key,&g_F8tmpData[index],144);
			index = index + 144;
			memcpy(randomData,&g_F8tmpData[index],8);
			index = index + 8;
			memcpy(signature,&g_F8tmpData[index],128);
			index = index + 128 + 3;
			ifok = AppMainKeyUpdate(key,signature,1);
			break;
		case 2:		// ��վ��Կ���ظ���
			memcpy(key,&g_F8tmpData[index],144);
			index = index + 144;
			memcpy(randomData,&g_F8tmpData[index],8);
			index = index + 8;
			memcpy(signature,&g_F8tmpData[index],128);
			index = index + 128 +3;
			ifok = AppMainKeyUpdate(key,signature,2);
			break;
		case 3:		// ��վ��ԿԶ�̸���
			memcpy(huihuakey,&g_F8tmpData[index],128);
			index = index + 128;
			memcpy(key,&g_F8tmpData[index],144);
			index = index + 144;
			memcpy(randomData,&g_F8tmpData[index],8);
			index = index + 8;
			memcpy(signature,&g_F8tmpData[index],128);
			index = index + 128;
			ifok = AppMainKeyRemoteUpdate(huihuakey,key,signature);
			break;
		case 8:		// �ն˶Գ���Կ����
			keynum = (F8_length - 128 - 128 - 8)/32;
			printf("\n keynum ===%d   F8_length %d\n", keynum,F8_length);
			memcpy(huihuakey,&g_F8tmpData[index],128);
			index = index + 128;
			for(i=0;i<6;i++)
				memset(&Dckey[i].data[0],0,32);
			if(keynum>0)
			{
				k = keynum -1;
				for(i=k; i>=0; i--)
				{
					memcpy(&Dckey[i].data[0],&g_F8tmpData[index], 32);
					index = index + 32;
				}
			}
			memcpy(randomData,&g_F8tmpData[index],8);
			index = index + 8;
			memcpy(signature,&g_F8tmpData[index],128);
			index = index + 128;
			ifok = AppDuichenKeyUpdate(huihuakey,keynum,randomData,signature);
			break;
		default:
			index = 23;
			break;
	}
	SelfheartCount = 0;
	if (ifok == 1)
		SendALLACK(0);
	else
	{
		memset(errData,0xff,16);
		SendSecyNAK(1,errData);
	}

	return index;
}
INT16U ProEsamF9(INT8U Set,INT8U F,INT8U P,INT8U *Data)//�ն˷ǶԳ���Կע��
{
	INT8U errData[16];
	int index,re,i;
	INT8U type;
	INT8U MasterRandomData[8]; 	 // ��վ�����
	INT8U TerminalRandomData[8]; // �ն������
	INT8U signature[128];		 // ����ǩ��
	INT8U KeyData[256];
	index = 4;
	type = Data[index];
	index = index + 1;
	memcpy(MasterRandomData,&Data[index],8);
	index = index + 8;
	memcpy(TerminalRandomData,&Data[index],8);
	index = index + 8;
	memcpy(signature,&Data[index],128);
	re = AppKeyReg(type,MasterRandomData,signature,TerminalRandomData,KeyData);
	if (re == 0)
	{
		memset(errData,0xff,16);
		SendSecyNAK(1,errData);
	}else
	{
		SendIndex = 0;
		FrameHeadCreate(0x88);
		SendBuff[SendIndex++] = 0x06;				//afn
		SendBuff[SendIndex++] = 0x60|(Fseq&0x0f);	//seq
		SetDaDt(P,F);
		SendBuff[SendIndex++] = type;
		printf("\n\r ---- key data---\n\r");
		for(i=255;i>=0;i--)
		{
			SendBuff[SendIndex++] = KeyData[i];
			printf("%02x ",KeyData[i]);
		}
		printf("\n\r");
//		memcpy(&SendBuff[SendLen],MasterRandomData,8);
//		SendLen = SendLen + 8;
		EC();
		TP();
		FrameTailCreate_Send(0);
	}
	return 1;
}

INT16U ProEsamF10(INT8U Set,INT8U F,INT8U P,INT8U *Data)//�ն˷ǶԳ���Կ����
{
	int index,type,re,i;
	INT8U errData[16];
	INT8U NewKey[144];  //����Կ�ԵĹ�Կ+��վ�����
	INT8U NewSig[128];	//����ǩ����Ϣ
	INT8U huihuakey[128];			// �Ự��Կ
	INT8U MasterRandomData[8]; 		// ��վ�����
	INT8U TerminalRandomData[8]; 	// �ն������
	INT8U signature[128];			// ����ǩ��

	index = 4;
	type = Data[index];  // 5 ��ʾ�ն˷ǶԳ���Կ��1����          6��ʾ�ն˷ǶԳ���Կ��2����
	index = index + 1;
	memcpy(huihuakey,&Data[index],128);
	index = index + 128;
	memcpy(MasterRandomData,&Data[index],8);
	index = index + 8;
	memcpy(TerminalRandomData,&Data[index],8);
	index = index + 8;
	memcpy(signature,&Data[index],128);
	index = index + 128;
	//---------------------------------------------------------------------------
	memset(NewKey,0,144);
	memset(NewSig,0,128);
	re = AppUnKeyUpdate(type,huihuakey,MasterRandomData,TerminalRandomData,signature,NewKey,NewSig);
	if (re == 0)
	{
		memset(errData,0xff,16);
		SendSecyNAK(1,errData);
	}else
	{
		SendIndex = 0;
		FrameHeadCreate(0x88);
		SendBuff[SendIndex++] = 0x06;				//afn
		SendBuff[SendIndex++] = 0x60|(Fseq&0x0f);	//seq
		SetDaDt(P,F);

		SendBuff[SendIndex++] = type;
		memcpy(&SendBuff[SendIndex],MasterRandomData,8);
		SendIndex = SendIndex + 8;

		for (i=143;i>=0;i--)
			SendBuff[SendIndex++] = NewKey[i];


		for (i=127;i>=0;i--)
			SendBuff[SendIndex++] = NewSig[i];

		EC();
		TP();
		FrameTailCreate_Send(0);
	}
	return index;
}
void SendMacCheckErr()
{
	INT8U RandData[8],SerNum[8],dataErr[16];
	int i,j;
	printf("\nSend Nak\n");
	memset(dataErr,0,16);
	memset(RandData,0,8);
	memset(SerNum,0,8);
	AppAskSerialNumber(SerNum);
	delay(1000);
	AppAskRandomData(RandData);

	j = 0;
	for (i=7;i>=0;i--)
		dataErr[j++] = RandData[i];
	//memcpy(&dataErr[8],RandData,8);

	for (i=7;i>=0;i--)
		dataErr[j++] = SerNum[i];
	//memcpy(&dataErr[8],SerNum,8);

	SendSecyNAK(3,dataErr);
}
INT8U CheckMac(INT8U *data,INT16U len,INT8U afn,INT8U groupNo,INT8U *mac)
{
	INT8U p1,p2,re,ok;
	INT8U temp[512];
	int lenth =0;
	int elen,i;
	initGpx();
	ok = 0;

	printf("\nafn=%02x groupNo=%d ",afn,groupNo);
	re = getPx(afn,groupNo,&p1 ,&p2);
	printf("\n in CheckMac! p1=%02x  p2=%02x  re=%d\n",p1,p2,re);
	if (re > 0)
	{
		memset(temp,0,512);
		memset(g_SendEsamBuf,0,512);
		g_SendEsamBuf[lenth++] = 0x80;
		g_SendEsamBuf[lenth++] = 0xE8;
		g_SendEsamBuf[lenth++] = p1;
		g_SendEsamBuf[lenth++] = (p2 << 2 )|0b11;
		g_SendEsamBuf[lenth++] = len;
		for(i=0;i<len;i++)
			g_SendEsamBuf[lenth++] = data[i];
		printf("\n\r CheckMac.......\n");
		print_to_get_esambyte(SENDTO,g_SendEsamBuf,lenth);

		elen  = EsamProcess(g_SendEsamBuf,lenth,NULL,0,temp);

		print_to_get_esambyte(GETFROM,temp,elen);
		if ((temp[0]==0x61) && (temp[1]==0x04))
		{
			printf("\n\r in Get 4 byte MAC");
			memset(temp,0,512);
			memset(g_SendEsamBuf,0,512);
			lenth = 0;
			g_SendEsamBuf[lenth++] = 0x00;
			g_SendEsamBuf[lenth++] = 0xC0;
			g_SendEsamBuf[lenth++] = 0x00;
			g_SendEsamBuf[lenth++] = 0x00;
			g_SendEsamBuf[lenth++] = 0x04;
			print_to_get_esambyte(SENDTO,g_SendEsamBuf,lenth);

			elen  = EsamProcess(g_SendEsamBuf,lenth,NULL,0,temp);

			print_to_get_esambyte(GETFROM,temp,elen);
			printf("\n\r mac0 =%02x  mac1 =%02x  mac2 =%02x  mac3 =%02x\n",mac[0],mac[1],mac[2],mac[3]);

			if ((temp[3] == mac[0]) &&(temp[2] == mac[1]) &&(temp[1] == mac[2]) &&(temp[0] == mac[3]))
			{
				printf("\nMAC OK!\n");
				return 1;
			}else
			{
				SendMacCheckErr();
			}
		}else
		{
			SendMacCheckErr();
		}
	}
	return 0;
}
void WaitSpi(int counter)//��SPIʹ��Ȩ
{
	int i=0;
	if (counter<60)
		counter = 60;
	while (i < counter)
	{
		if (Jproginfo->EsamJiaocaiflag == 0)//ESAM/���ɱ�־λ��0
			break;
//		mydelay(1);
		delay(1000);
		i++;
	}
	Jproginfo->EsamJiaocaiflag = 1;
}
void EnableSpi()
{
	Jproginfo->EsamJiaocaiflag = 0;
}
INT16U CallEsam(INT8U *s)
{
	INT8U j,fnd=0;
	INT16U Result;
	Result=0;
	memset(g_SendEsamBuf, 0, 512);
	memset(g_RevEsamBuf, 0, 512);
	memset(DA,0,65);
	memset(DT,0,255);
	GetDa(s[0],s[1]);//���ݵ�Ԫ��ʶ DA
	GetDt(s[2],s[3]);//���ݵ�Ԫ��ʶ DT

	WaitSpi(60);//��SPIʹ��Ȩ

	for(j=0;j<11;j++)
	{
		SelfheartCount = 0;
		if(DT[j]==1)
		{
			fnd = 1;
			printf("\n\r CALL ESAM Fn = %02d\n\r",j);
			switch(j)
			{
				case 1:
					Result=Result+ProEsamF1(0,j,0,s);
					break;
				case 2:
					Result=Result+ProEsamF2(0,j,0,s);
					break;
				case 3:
					Result=Result+ProEsamF3(0,j,0,s);
					break;
				case 4:
					Result=Result+ProEsamF4(0,j,0,s);
					break;
				case 5://!!!
					Result=Result+ProEsamF5(0,j,0,s);//��ȡ�ն������
					break;
				case 6://!!!
					Result=Result+ProEsamF6(0,j,0,s);//��Կ��֤
					break;
				case 7://!!!@
					Result=Result+ProEsamF7(0,j,0,s);//��Կ��������
					break;
				case 8://!!!
					Result=Result+ProEsamF8(0,j,0,s);//��Կ����
					break;
				case 9://!!!
					Result=Result+ProEsamF9(0,j,0,s);//�ն˷ǶԳ���Կע��
					break;
				case 10://!!!
					Result=Result+ProEsamF10(0,j,0,s);//�ն˷ǶԳ��������
					break;
				default:
					break;
					Result=128;
			}
		}
	}
	EnableSpi(); //�ͷ�SPIʹ��Ȩ
	if (fnd == 0)
	{
		return 22;
	}
	return Result;
}

#define MYBUFLEN 2048
int main(int argc, char *argv[])
{
	int len=5, i,j,k;
	INT8U file_buf[MYBUFLEN];
	char tempbuf[MYBUFLEN];
	char file_buf_s[MYBUFLEN];
	FILE *fp;
	INT8U Esam_Send[MYBUFLEN];
	INT8U Esam_Recv[MYBUFLEN];

	char txx[6];
	unsigned int xx;
	int count=0;
	INT8U Command[60];
	memset(Command, 0, 60);

//	if(OpenMem())//OpenMem()�򿪹����ڴ�
//	{
//		if(CreateMem())//CreateMem()���������ڴ�
//		{
//			exit(0);
//			return EXIT_FAILURE;//���������ڴ�
//		}
//		else
//		{
//			Jproginfo->mainData.MemoryLength=sizeof(ProgramInfo);
//		}
//	}
	/*
	 * ParamInfo3761* JSetPara_AFN04_3761_2009;
		ProgramInfo*   Jproginfo;
	  ConfigInfo*    Jcfginfo;
	  DataFileInfo*  Jdatafileinfo;
	 * */
	JSetPara_AFN04_3761_2009 = Open1ShMem("ParamInfo3761",sizeof(ParamInfo3761),NULL);
	Jdatafileinfo = Open1ShMem("DataFileInfo",sizeof(DataFileInfo),NULL);
	Jcfginfo = Open1ShMem("ConfigInfo",sizeof(ConfigInfo),NULL);
	Jproginfo = Open1ShMem("ProgramInfo",sizeof(ProgramInfo),NULL);
	WaitSpi(60);
	if (strcmp("s", argv[1]) == 0)
	{
		fp =NULL;
		memset(Command, 0, 60);
		sprintf((char *) Command, "%s/test.txt", "/nand/bin");
		fp = fopen((char *)Command,"r");
		if (fp !=NULL)
		{
			i = 0;
			printf("\n-----------begin-----------------\n");
			while(! feof(fp))
			{
				file_buf_s[i++] = fgetc(fp);
				printf("%c",file_buf_s[i-1]);
			}
			printf("\n");
			fclose(fp);
			memset(Command, 0, 60);
			sprintf((char *) Command, "%s/test.txt", "/nand/bin");
			fp = fopen((char *)Command,"r");
			k = 0;
			for(j=0;j<i;j++)
			{
				if ((j%2==0) && (j!=0) && (j!=(i-1)))
					tempbuf[k++] = ' ';
				tempbuf[k++] = file_buf_s[j];
			}
			fwrite(tempbuf,k-1,1,fp);
			fclose(fp);
		}
		EnableSpi();
		return 1;
	}
	if (strcmp("t",argv[1])==0)
	{
		fp = NULL;
		memset(Command, 0, 60);
		sprintf((char *) Command, "%s/test.txt", "/nand/bin");
		fp = fopen((char *)Command,"r");
		if(fp != NULL)
		{
			while( ! feof( fp ) )
			{
				memset(txx,0,6);
				fscanf(fp,"%02x ",&xx);
				file_buf[count] = xx;
				//printf("%02x ",file_buf[count]);
				count++;
			}
		}
		printf("\n\r count = %d",count);

		Esam_Recv_len=0;
		memset(Esam_Send, 0, MYBUFLEN);
		memset(Esam_Recv, 0, MYBUFLEN);
		SPIinit();
		for(i=0;i<count;i++)
			Esam_Send[i] = file_buf[i];
		printf("\nEsam send buf  len=%d:\n", i);
		for(len=0; len<count; len++)
		{
			printf("%02x ", Esam_Send[len]);
		}
		printf("\n");
		Esam_Recv_len = EsamProcess(Esam_Send, len, NULL, 0, Esam_Recv);
		printf("\nEsam recv buf  len=%d:\n", Esam_Recv_len);
		for(i=0; i<Esam_Recv_len; i++)
		{
			printf("%02x ", Esam_Recv[i]);
		}
		for(i=0; i<Esam_Recv_len; i++)
		{
			if(Esam_Recv[i]==0x90 && Esam_Recv[i+1]==0x00)
				printf("        ESAM OK\n");
		}
		printf("\n\n");
		EnableSpi();
		return 1;
	}
	EnableSpi();
	return EXIT_SUCCESS;
}
