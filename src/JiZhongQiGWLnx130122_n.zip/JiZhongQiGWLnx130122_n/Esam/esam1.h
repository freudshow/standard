#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <ctype.h>
#include <time.h>
#include <stdint.h>
#include <signal.h>
#include <semaphore.h>
#include <netdb.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <math.h>
#include <termios.h>
#include "stdio.h"
#include "string.h"

#include "../jBase/inc/pubfunction.h"
//#include <inc/BaseType.h>
#include "../jBase/inc/Options.h"

#define ESAM_TIMEOUT   5
#define SPI1   0
#define LCmax              (INT8U)0xFF//(u8)20
#define SETUP_LENGTH       (INT8U)20
#define HIST_LENGTH        (INT8U)20
#define BUFLEN 512
#define  KEY_NUM               12
typedef struct
{
    INT8U group;
    INT8U groupflag;
    INT8U p1;  /* Setup array */
    INT8U p2;
} GroupPx;
typedef struct
{
    INT8U  afn;
    GroupPx Gpxn[9];
}AFNGPX;

typedef struct
{
    INT8U TS;               /* Bit Convention */
    INT8U T0;               /* High nibble = Number of setup byte; low nibble = Number of historical byte */
    INT8U T[SETUP_LENGTH];  /* Setup array */
    INT8U H[HIST_LENGTH];   /* Historical array */
    INT8U Tlength;          /* Setup array dimension */
    INT8U Hlength;          /* Historical array dimension */
} SC_ATR;

/* ADPU-Header command structure ---------------------------------------------*/
typedef struct
{
    INT8U CLA;  /* Command class */
    INT8U INS;  /* Operation code */
    INT8U P1;   /* Selection Mode */
    INT8U P2;   /* Selection Option */
} SC_Header;

/* ADPU-Body command structure -----------------------------------------------*/
typedef struct
{
    INT8U LC;           /* Data field length */
    INT8U LE;           /* Expected length of data to be returned */
    INT8U Data[LCmax];  /* Command parameters */
} SC_Body;

/* ADPU Command structure ----------------------------------------------------*/
typedef struct
{
    SC_Header Header;
    SC_Body Body;
} SC_ADPU_Commands;

/* SC response structure -----------------------------------------------------*/
typedef struct
{
    INT8U Data[LCmax];  /* Data returned from the card */
    INT8U SW1;          /* Command Processing status */
    INT8U SW2;          /* Command Processing qualification */
} SC_ADPU_Responce;
typedef struct
{
  INT8U data[32];
}DUICHENKEY;

void SPIinit();
FILE *fp;
DUICHENKEY Dckey[6];

#define OSTimeDly_ESAM(A) usleep((A)*1000)
int spi_cmdrecv(int fd, uint32_t device, INT8U *cbuf, int16_t clen, INT8U *rbuf, int rlen);
int gpio_read(char *devname);
int gpio_write(char *devname, int data);

//================================================================================

INT16U ProEsamF1(INT8U Set,INT8U F,INT8U P,INT8U *Data);
INT16U ProEsamF2(INT8U Set,INT8U F,INT8U P,INT8U *Data);
INT16U ProEsamF3(INT8U Set,INT8U F,INT8U P,INT8U *Data);
INT16U ProEsamF4(INT8U Set,INT8U F,INT8U P,INT8U *Data);
INT16U ProEsamF5(INT8U Set,INT8U F,INT8U P,INT8U *Data);
INT16U ProEsamF6(INT8U Set,INT8U F,INT8U P,INT8U *Data);
INT16U ProEsamF7(INT8U Set,INT8U F,INT8U P,INT8U *Data);
INT16U ProEsamF8(INT8U Set,INT8U F,INT8U P,INT8U *Data);
INT16U ProEsamF9(INT8U Set,INT8U F,INT8U P,INT8U *Data);
INT16U ProEsamF10(INT8U Set,INT8U F,INT8U P,INT8U *Data);
INT16U CallEsam(INT8U *s);
INT8U CheckMac(INT8U *data,INT16U len,INT8U afn,INT8U groupNo,INT8U *mac);
INT8U update_key_type;
INT16U F8_length;
INT8U g_F8tmpData[1024];
INT8U g_SendEsamBuf[512];
INT8U g_SendEsamBuf2[512];
INT8U g_RevEsamBuf[512];
int SelfheartCount;
INT16U AppAskRandomData(INT8U *data);		 //��ȡ�����������
