///*
// * smartcard.c
// *
// *  Created on: 2012-5-23
// *      Author: yd
// */
//INT8U Esam_Send1[512];
//INT8U Esam_Send2[512];
//INT8U Esam_Recv[512];
////������stm8��������
//INT8U ADPUtoStr(SC_ADPU_Commands *pADPU, INT8U *ret)
//{
//	int i;
//	if(ret == NULL || pADPU == NULL)
//		return 0;
//	ret[0] = pADPU->Header.CLA;
//	ret[1] = pADPU->Header.INS;
//	ret[2] = pADPU->Header.P1;
//	ret[3] = pADPU->Header.P2;
//	if(pADPU->Body.LC)
//		ret[4] = pADPU->Body.LC;
//	else
//		ret[4] = pADPU->Body.LE;
//	for(i=0; i<pADPU->Body.LC; i++)
//		ret[5+i] = pADPU->Body.Data[i];
//	return 1;
//}
////���ع�Կ����ָ��
//void Update_MasterPublicKey(INT8U *pulickey, INT8U *sign)
//{
//	int i;
//	SC_ADPU_Commands SC_ADPU1, SC_ADPU2;
//	memset(Esam_Send1, 0, 512);
//	memset(Esam_Send2, 0, 512);
//	memset(Esam_Recv, 0, 512);
//	//���SC_ADPU1
//	SC_ADPU1.Header.CLA = 0x90;
//	SC_ADPU1.Header.INS = 0x40;
//	SC_ADPU1.Header.P1 = 0x00;
//	SC_ADPU1.Header.P2 = 0x00;
//	SC_ADPU1.Body.LC = 0x92;
//	SC_ADPU1.Body.Data[0] = 0x62;
//	SC_ADPU1.Body.Data[1] = 0x90;
//	for(i=0; i<SC_ADPU1.Body.LC-2; i++)
//		SC_ADPU1.Body.Data[2+i] = pulickey[i];
//	//���SC_ADPU2
//	SC_ADPU2.Header.CLA = 0x90;
//	SC_ADPU2.Header.INS = 0x40;
//	SC_ADPU2.Header.P1 = 0x00;
//	SC_ADPU2.Header.P2 = 0x00;
//	SC_ADPU2.Body.LC = 0x92;
//	SC_ADPU2.Body.Data[0] = 0x62;
//	SC_ADPU2.Body.Data[1] = 0x90;
//	for(i=0; i<SC_ADPU2.Body.LC-2; i++)
//		SC_ADPU2.Body.Data[2+i] = pulickey[i];
//	//ADPUtoStr();
//	//ADPUtoStr();
//	//EsamProcess(Esam_Send11, SC_ADPU1.Body.LC+5, Esam_Send2, SC_ADPU2.Body.LC+5, Esam_Recv);
//}
