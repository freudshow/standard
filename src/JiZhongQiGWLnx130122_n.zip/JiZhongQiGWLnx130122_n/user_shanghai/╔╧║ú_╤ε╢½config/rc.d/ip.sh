ifconfig eth0 193.168.18.116 up
