ifconfig eth0 hw ether 80b710b11400
