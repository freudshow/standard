
#include "jNetcom.h"
int NoDataTime(time_t old_t)//���ؼ�����������ͨѶ������
{
	time_t now_time;
	if (old_t>0)
	{
		now_time = time(NULL);
		return (now_time - old_t);
	}
	return 0;
}

int tryifconfig()
{
	  int sock;
	  struct sockaddr_in  sin;
	  struct ifreq  ifr;
	  sock = socket(AF_INET, SOCK_DGRAM, 0);
	  if   (sock   ==   -1)
	  {
		  return   -1;
	  }
	  strncpy(ifr.ifr_name, ETH_NAME, IFNAMSIZ);
	  ifr.ifr_name[IFNAMSIZ   -   1]   =   0;
	  if (ioctl(sock, SIOCGIFADDR,  &ifr)   <   0)
	  {
		  if(close(sock) == -1)
		  {
			  printf(" tryifconfig: fail to close !!!\n\r");
		  }
		  sock=-1;
		  return   -1;
	  }
	  memcpy(&sin,   &ifr.ifr_addr,   sizeof(sin));
	  if (sin.sin_addr.s_addr >0)
	  {
		  close(sock);
		  sock=-1;
		  memset(pppip,0,16);
		  sprintf(pppip,"%s",inet_ntoa(sin.sin_addr));
		  return 1;
	  }
	  close(sock);
	  sock=-1;
	  return 0;
}


/**************************************************
 *�ر�����
 * **********************************************/
int close_socket(int *skfd)
{
	if (*skfd > 0)
	{
		close(*skfd);
		*skfd = -1;
	}
    return 0;
}
/**************************************************
 *��������
 * **********************************************/
int connect_socket(char * server,int serverPort){
	int    result;
    struct sockaddr_in    addr;
    struct timeval timeo;
    unsigned long ul1 = 0;//������
    char *optval2;

    close_socket(&sockfd);
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) <0)
	{
//    	fprintf(stderr, "\ncreate socket error! [%s]\n\r ",strerror(errno)  );
		return -1;
	}
	fprintf(stderr,"\nconnect socket =%d\n\r",sockfd);
	optval2 = "eth0"; // 4 bytes long, so 4, below:
	setsockopt(sockfd, SOL_SOCKET, SO_BINDTODEVICE, optval2, 4);
	result = ioctl(sockfd, FIONBIO, (unsigned long*)&ul1);
	if(result< 0)
	{
//		fprintf(stderr,"\r\nioctl_socket err [%s]\r\n",strerror(errno));
    	close_socket(&sockfd);
		return -1;
	}
    bzero(&addr,sizeof(addr));
    addr.sin_family=AF_INET;
    addr.sin_port=htons(serverPort);
    addr.sin_addr.s_addr=inet_addr(server);
    fprintf(stderr,"\nNetcom:Begin Connect ip=%s  port=%d",server,serverPort);
    if(connect(sockfd,(struct sockaddr*)&addr,sizeof(addr))<0)
    {
    	fprintf(stderr,"\n\r socket connect errs [%s]",strerror(errno) );
    	close_socket(&sockfd);
    	return -1;
	}

	timeo.tv_sec  = 0;
	timeo.tv_usec = 500;
	result = setsockopt(sockfd,SOL_SOCKET,SO_RCVTIMEO,(char *)&timeo.tv_sec,sizeof(struct timeval));
	if (result < 0)
	{
		fprintf(stderr,"\r\n setsockopt err[%s]\n\r",strerror(errno));
    	close_socket(&sockfd);
		return -1;
	}
	if (sockfd>0)
		printf("\nClient Connection Ok! socket %d\n",sockfd);
    return sockfd;
}
void  net_send(INT8U * buffer,INT16U len)
{
	INT16U i;
	size_t  nleft;
	ssize_t nwritten;

	nwritten = 0;
	nleft = len;
	if (len > 0)
		fprintf(stderr,"\nNetcom send [%d bytes]:\n",len);
	while( nleft > 0)
	{
		nwritten = send(sockfd, buffer, nleft,0);
		if (nwritten > 0)
		{
			for(i=0; i<nwritten; i++)
				fprintf(stderr,"%02x ",buffer[i]);
		}
		if (nwritten<= 0)
		{
			if (errno == EINTR)
				nwritten = 0;
			else
			{
				return ;
			}
		}
		nleft -= nwritten;
		buffer += nwritten;

	}
	return ;
}
int  net_rev(int *skfd,INT8U* revbuf)
{
    int revcount=0,i,recLenth=0;
    unsigned char c;

    if (*skfd<0) return -1;

    ioctl(*skfd,FIONREAD,&revcount);
    if (revcount > 0)
    	fprintf(stderr,"\nNetcom rev [%d bytes]:\n",revcount);
    else
    	return 0;
    for(i=0; i<revcount; i++)
    {
    	recLenth=recv(*skfd,&c,1,0);
    	revbuf[rev_head] = c;
    	rev_head = (rev_head + 1) % FrameSize;
    	fprintf(stderr,"%02x ",c);
    }
    return revcount;
}
void *SevPro(void* param)
{
	thread_param *client_para;
	client_para = (thread_param*)param;

	while(client_para->run)
	{
		mydelay(1,ProjectNo,JProgramInfo);
		net_rev(&sockfd,NetRevBuf);
	}
	close_socket(&sockfd);
	exit(EXIT_SUCCESS);
}
void *DealPro(void* param)
{
	int notautoreport = 1;//��ֹ�����ϱ���־
	thread_param *para;
	para = (thread_param*)param;
	int taskno,firstflag=1;
	while(para->run)
	{
		mydelay(1,ProjectNo,JProgramInfo);
		if (para->online_flag == FALSE)
		{
			firstflag = TRUE;
			if(JProgramInfo->jzq_login == NET_COM) {
				JProgramInfo->jzq_login = 0;
			}
			continue;
		}
		if ((para->online_flag == TRUE) && (para->login_flag == NO))//���ߣ�����û�е�½
		{
			if ((NoDataTime(para->old_time ) > com_para.Heartbeat) ||(firstflag ==TRUE))
			{
				fprintf(stderr,"\n��ʼ��½");
				firstflag = FALSE;
				LinkCtrl(JConfigInfo,&JProgramInfo->PFC ,1,para->sendbuf,&para->sendlen,sendfunp);//���͵�½
				para->old_time = time(NULL);
				para->linktst_num++;
			}
		}
		if (para->login_flag == OK)//�Ѿ���½�ɹ�
		{
			if(JProgramInfo->jzq_login == SER_COM)//���ڵ�½���ֹʹ�����ڵ�½
			{
				close(sockfd); sockfd = -1;
				para->online_flag = FALSE;
				para->login_flag = FALSE;
			}else
			{
				JProgramInfo->jzq_login = NET_COM;
			}

			if (NoDataTime(para->old_time ) > com_para.Heartbeat)
			{
//				fprintf(stderr,"\n����");
				LinkCtrl(JConfigInfo,&JProgramInfo->PFC ,3,para->sendbuf,&para->sendlen,sendfunp);//��������
				para->old_time = time(NULL);
				para->linktst_num++;
			}
			notautoreport = (JConfigInfo->jzqpara.CommStat & 0x02) >> 1 ;
			if (notautoreport != 1) {
				if (JDataFileInfo->ErcEvt.EC1old != JDataFileInfo->ErcEvt.EC1)
				{
					AutoReportLvl3data(0,JParamInfo3761,JProgramInfo,JConfigInfo,JDataFileInfo,1,sendfunp);
					JProgramInfo->FileSaveFlag.ercflag = 1;
				}
			}
			//-------------����---------------
			initnextime(JParamInfo3761,JProgramInfo);
			for(taskno=0; taskno<Task2_Max;taskno++)
			{
				if (TwoLevelDataTask(taskno,JParamInfo3761,JProgramInfo)==1)
					AutoReportLvl1Lv2data(JProgramInfo->zone,JParamInfo3761,JProgramInfo,JConfigInfo,JDataFileInfo,J_2LEIDATE,taskno,sendfunp);

				if (OneLevelDataTask(taskno,JParamInfo3761,JProgramInfo)==1)
					AutoReportLvl1Lv2data(JProgramInfo->zone,JParamInfo3761,JProgramInfo,JConfigInfo,JDataFileInfo,J_1LEIDATE,taskno,sendfunp);
			}
		}

		if (para->linktst_num > 1)
		{
			para->linktst_num = 0;
			para->online_flag = FALSE;
		}
	}
	exit(EXIT_SUCCESS);
}
//����ע��,��ȡ����źͳ�������
INT8U GetProjects(INT32S argc, char * argv[]) {
	char proc_name[32] = "";
	if (argc < 2)
		return (FALSE);
	ProjectNo = atoi(argv[1]);

	sprintf(proc_name, "%s", argv[0]);
    if((attach=name_attach(NULL, proc_name,0,JProgramInfo))  == NULL)
    {
	   printf( "ERR:'%s' runed,cann't regist\n\r", proc_name);
	   return (FALSE);
    }
	return (TRUE);
}

//�˳�����
void QuitProcess(int signo)
{
	JProgramInfo->Projects[ProjectNo].ProjectID=0;
    name_detach(attach, 0);
	param.run = 0;

	if (thread_rev_id>=0)
	{
		pthread_exit(&thread_sev);
		fprintf(stderr,"\n  thread_sev quit\n");
	}
	if (thread_deal_id>=0)
	{
		pthread_exit(&thread_deal);
		fprintf(stderr,"\n  thread_deal quit\n");
	}
	fprintf(stderr,"\n  jNetcom quit \n");
	exit(0);
}
void dealinit()
{
	step = 0;
	dialNum = 0;
	dialdelay = 0;
	rev_delay = 0;
	rev_tail = rev_head = rev_tail2 = rev_tail3 = 0;
	memset(NetRevBuf,0,FrameSize);
	memset(NetSendBuf,0,FrameSize);
}
void GetNetpara()
{
	memset(&com_para,0,sizeof(NetComPara));
	com_para.mainport = (JParamInfo3761->group1.f3.PortAddress[1]<<8) + JParamInfo3761->group1.f3.PortAddress[0];
	sprintf(com_para.mainip,"%d.%d.%d.%d",JParamInfo3761->group1.f3.IP[3],JParamInfo3761->group1.f3.IP[2],JParamInfo3761->group1.f3.IP[1],JParamInfo3761->group1.f3.IP[0]);
	com_para.bakport = (JParamInfo3761->group1.f3.PortAddress1[1]<<8) + JParamInfo3761->group1.f3.PortAddress1[0];
	sprintf(com_para.bakip,"%d.%d.%d.%d",JParamInfo3761->group1.f3.IP1[3],JParamInfo3761->group1.f3.IP1[2],JParamInfo3761->group1.f3.IP1[1],JParamInfo3761->group1.f3.IP1[0]);
	memcpy(com_para.apn,JParamInfo3761->group1.f3.APN,sizeof(com_para.apn));
	com_para.Heartbeat = JParamInfo3761->group1.f1.HeartInterval * 60;
	com_para.zone = JProgramInfo->zone;  //����
	if (com_para.Heartbeat > 900)
		com_para.Heartbeat = 900;
//	fprintf(stderr,"\n���� %d ��",com_para.Heartbeat);
}
//void interfacepro()
//{
//	interface(&param.pkg_property,JParamInfo3761,JProgramInfo,JConfigInfo,JDataFileInfo);
//}
int main(int argc, char *argv[])
{
	struct sigaction sa1;
	int i;
	markver();

	JParamInfo3761 = Open1ShMem("ParamInfo3761",sizeof(ParamInfo3761),NULL);
	JDataFileInfo = Open1ShMem("DataFileInfo",sizeof(DataFileInfo),NULL);
	JConfigInfo = Open1ShMem("ConfigInfo",sizeof(ConfigInfo),NULL);
	JProgramInfo = Open1ShMem("ProgramInfo",sizeof(ProgramInfo),NULL);

	if (JParamInfo3761 ==NULL || JDataFileInfo==NULL || JConfigInfo==NULL || JProgramInfo == NULL)
		return EXIT_FAILURE;

	if(JProgramInfo->mainData.MemoryLength!=sizeof(ProgramInfo))
	{
		fprintf(stderr,"\nShare mem uncompared!\n");
		return EXIT_FAILURE;
	}
	if(!GetProjects(argc, argv))
	{
		fprintf(stderr,"\nBad command format. Type 'use exe_name' for help!\n");
		return EXIT_FAILURE;
	}
	fprintf(stderr,"Starting jNetcom ..........%d\n\r",ProjectNo);

	sa1.sa_handler = QuitProcess;
	sigemptyset(&sa1.sa_mask);
	sa1.sa_flags = 0;
	sigaction(SIGTERM, &sa1,NULL);
	sigaction(SIGSYS, &sa1,NULL);
	sigaction(SIGPWR, &sa1,NULL);
	sigaction(SIGKILL, &sa1,NULL);
	sigaction(SIGQUIT, &sa1,NULL);
	sigaction(SIGILL, &sa1,NULL);
	sigaction(SIGINT, &sa1,NULL);
	sigaction(SIGHUP, &sa1,NULL);
	sigaction(SIGABRT, &sa1,NULL);
	sigaction(SIGBUS, &sa1,NULL);
	signal(SIGPIPE,SIG_IGN);
	JProgramInfo->Projects[ProjectNo].ProjectID=getpid();

	sendfunp = net_send;
	sockfd = -1;
	memset(&param,0,sizeof(thread_param));
	param.run = TRUE;
	thread_rev_id = pthread_create(&thread_sev,NULL, SevPro,&param);	    /*�������ݽ����߳�*/
	thread_deal_id = pthread_create(&thread_deal,NULL, DealPro,&param);	    /*����������֧�߳�*/
	dealinit();
	GetNetpara();
	ifNetcomm = TRUE;
	while(1)
	{
		ClearWaitTimes(ProjectNo,JProgramInfo);
		delay(10);
		if(JProgramInfo->jzq_login == SER_COM)//���ڵ�½���ֹʹ�����ڵ�½
		{
			ifNetcomm = NO;
			close(sockfd); sockfd = -1;
			param.online_flag = FALSE;
			param.login_flag = FALSE;
		}else
			ifNetcomm = TRUE;
		if (ifNetcomm == USED)//�������̫��
		{
			GetNetpara();
			if (param.online_flag  == FALSE)
			{
				for(i=0;i<3;i++)//���ųɹ�����������վ 3��
				{
					if (connect_socket(com_para.mainip,com_para.mainport)>0)
					{
						fprintf(stderr,"\n-----connetct ok!");
						param.online_flag = TRUE;
						dealinit();
						break;
					}else
						param.online_flag = FALSE;
					mydelay(5,ProjectNo,JProgramInfo);
				}
			}else
			{
				deallen = StateProcess(&step,&rev_delay,10,&rev_tail,&rev_head,NetRevBuf,dealbuf) ;//����Ԥ����״̬������
				if (deallen > 0)
				{
					INT16S ret;
					ret = processData(com_para.zone,			  /*����*/
								(ParamInfo3761*)JParamInfo3761,   /*������ָ��*/
								(ProgramInfo*)JProgramInfo,
								(ConfigInfo*)JConfigInfo,
								(DataFileInfo*)JDataFileInfo,
								dealbuf,							/*��Ҫ�����ı���*/
								deallen,							/*���ĳ���*/
								NetSendBuf,							/*��Լ�ⷵ����Ҫ���ͱ��Ļ�����*/
								&sendlen,							/*���͵ĳ���*/
								sendfunp);								/*�ص�����*/

					if ( ret >= 0 )
					{
						fprintf(stderr,"\n��վ��Ӧ [AFN %02x]",ret);
						param.login_flag = OK;
						param.linktst_num = 0;
					}else switch(ret){
						case ERR_RCVD_TOOLONG:			fprintf(stderr,"���ձ��Ĺ���\n");	break;
						case ERR_CRC_ERROR:				fprintf(stderr,"����У�����\n");	break;
						case ERR_RCVD_LOST:				fprintf(stderr,"���ձ��Ĳ�����\n");	break;
						case ERR_HEART_BEAT:			fprintf(stderr,"����δ��Ӧ������������\n");	break;
						case ERR_DIFF_ADDR:				fprintf(stderr,"�����ն˵�ַ���ն˲�һ��\n");	break;
						case ERR_AUTO_INTERVAL_ZERO:	fprintf(stderr,"��ʱ�ϱ�����Ϊ0\n");	break;
						case ERR_AUTO_WRONG_AFN:		fprintf(stderr,"�����˴����AFN\n");	break;
						case ERR_AUTO_WRONG_FN:			fprintf(stderr,"�����˴����Fn\n");	break;
					}
//					if (sendlen > 0)		//Ӧ����
//					{
//						net_send(NetSendBuf,sendlen);
//						sendlen = 0;
//					}
				}//end ״̬�������ɹ�
				if (param.sendlen > 0)  //�������ͣ����������߼���DealPro�߳��У�
				{
					fprintf(stderr,"\n�������� %d bytes",param.sendlen);
					net_send(param.sendbuf,param.sendlen);
					param.sendlen = 0;
				}
			}
		}//end if use gprs
	}
	QuitProcess(0);
	return EXIT_SUCCESS;
}
