/*
 * PrintData.c
 *
 *  Created on: Nov 30, 2009
 *      Author: ln
 */
/*
 * PrintData.h
 *
 *  Created on: 2009-10-13
 *      Author: ZhuRui
 */

#include <inc/pubfunction.h>
#include <stdio.h>
#include "PrintData.h"
#include "jLcdTask.h"
#include "jLcdFun.h"

int jLcdPrint;
FILE *fp;
extern INT8U metflag;
extern INT8U LunPage;


/******************************************************************************************************************
* �������ƣ�show_date()
* ��    �ܣ�����flag�����ݵĶ�Ӧ��ϵ��ʾ����
* ��ڲ�����dateΪ��õ����ݣ�flagΪ��Ӧ�ı�ʶ����xΪ�����꣬yΪ�����꣬GuiYueΪͨ�Ź�Լ����
* ���ڲ�������
******************************************************************************************************************/
void Print_sel_data(INT8U *date,INT8U *flag,INT8U x ,INT8U y,INT8U GuiYue)
{
	INT8U temp[32],temp2[16],i,flag1=0;
	INT8U *p;
	p = date;
	memset(temp,0,32);
	for(i=0;i<sizeof(date);i++)
	{
	   if(*p!=OxXX)
	   {
		   flag1=1;break;
	   }
	   p++;
	}
	if(flag1==0)
	{
		GUI_DispStringAt((INT8U *)"����ʧ��!",x,y);
		switch(JProgramInfo->RealData.g_flg_CB)
		{
		case 0x00:
			GUI_DispStringAt((INT8U *)"ͨ�ų�ʱ!",x,y+32);
			break;
		case 0x0d:
			GUI_DispStringAt((INT8U *)"ͨ���ܸ���!",x,y+32);
			break;
		case 0x0e:
			GUI_DispStringAt((INT8U *)"�ɼ���������!",x,y+32);
			break;
		default:
			break;
		}
	}else
	{
		flag1=0;
		for(i=0;i<sizeof(date);i++)
		{
		   if(*p != OxXX){
			   flag1=1;
			   break;
		   }
		   p++;
		}
		if(flag1==0){
			GUI_DispDecAt(0,x,y,1);
		}else{
			switch(flag[1]){
				case 0x90://90XX��Լ��
				{
					memset(temp2,0,16);
					sprintf((char*)temp2,"%.2f",(FP32)BCD_INT32(&date[0],4)/100);
					GUI_DispStringAt(temp2,x,y);
					GUI_DispStringAt((INT8U *)"kWh",112,y);
				};break;
				case 0x91://91XX��Լ��
				{
					memset(temp2,0,16);
					sprintf((char*)temp2,"%.2f",(FP32)BCD_INT32(&date[0],4)/100);
					GUI_DispStringAt(temp2,x,y);
					GUI_DispStringAt((INT8U *)"kVArh",112,y);
				};break;
				case 0x94://94XX��Լ��
				{
					memset(temp2,0,16);
					sprintf((char*)temp2,"%.2f",(FP32)BCD_INT32(&date[0],4)/100);
					GUI_DispStringAt(temp2,x,y);
					GUI_DispStringAt((INT8U *)"kWh",112,y);
				};break;
				case 0x95://95XX��Լ��
				{
					memset(temp2,0,16);
					sprintf((char*)temp2,"%.2f",(FP32)BCD_INT32(&date[0],4)/100);
					GUI_DispStringAt(temp2,x,y);
					GUI_DispStringAt((INT8U *)"kVArh",112,y);
				};break;
				case 0xa0://a0XX��Լ��
				{
					memset(temp2,0,16);
					sprintf((char*)temp2,"%.4f",(FP32)BCD_INT32(&date[0],3)/10000);
					GUI_DispStringAt(temp2,x,y);
					GUI_DispStringAt((INT8U *)"kW",112,y);
				};break;
				case 0xa1://a0XX��Լ��
				{
					memset(temp2,0,16);
					sprintf((char*)temp2,"%.4f",(FP32)BCD_INT32(&date[0],3)/10000);
					GUI_DispStringAt(temp2,x,y);
					GUI_DispStringAt((INT8U *)"kVAr",112,y);
				};break;
				case 0xa4://a4XX��Լ��
				{
					memset(temp2,0,16);
					sprintf((char*)temp2,"%.4f",(FP32)BCD_INT32(&date[0],3)/10000);
					GUI_DispStringAt(temp2,x,y);
					GUI_DispStringAt((INT8U *)"kW",112,y);
				};break;
				case 0xa5://a5XX��Լ��
				{
					memset(temp2,0,16);
					sprintf((char*)temp2,"%.4f",(FP32)BCD_INT32(&date[0],3)/10000);
					GUI_DispStringAt(temp2,x,y);
					GUI_DispStringAt((INT8U *)"kVAr",112,y);
				};break;
				case 0xb0://b0XX��Լ��
				{
					  memset(temp2,0,16);
					  sprintf((char*)temp2,"%02x-%02x %02x:%02x",date[3],date[2],date[1],date[0]);
					  GUI_DispStringAt(temp2,x,y);
				};break;
				case 0xb1://b1XX��Լ��
				{
					  memset(temp2,0,16);
					  sprintf((char*)temp2,"%02x-%02x %02x:%02x",date[3],date[2],date[1],date[0]);
					  GUI_DispStringAt(temp2,x,y);
				};break;
				case 0xb2://b2XX��Լ��
				{
					switch(flag[0]){
					  case 0x10:
						  memset(temp2,0,16);
						  sprintf((char*)temp2,"%02d-%02d %02d:%02d",date[4],date[3],date[2],date[1]);
						  GUI_DispStringAt(temp2,x,y);
					   break;
					   case 0x11:
						  memset(temp2,0,16);
						  sprintf((char*)temp2,"%02d-%02d %02d:%02d",date[4],date[3],date[2],date[1]);
						  GUI_DispStringAt(temp2,x,y);
					   break;
					   case 0x12:
							memset(temp2,0,16);
							sprintf((char*)temp2,"%04d",BCD_INT32(&date[0],2));
							GUI_DispStringAt(temp2,x,y);
					   break;
					   case 0x13:
							memset(temp2,0,16);
							sprintf((char*)temp2,"%04d",BCD_INT32(&date[0],2));
							GUI_DispStringAt(temp2,x,y);
					   break;
					   default:break;
					}

				};break;
				case 0xb3://b3XX��Լ��
				{

					switch(flag[0]){
					   case 0x10:
							memset(temp2,0,16);
							sprintf((char*)temp2,"%04d",BCD_INT32(&date[0],3));
							GUI_DispStringAt(temp2,x,y);
					   break;
					   case 0x11:
							memset(temp2,0,16);
							sprintf((char*)temp2,"%04d",BCD_INT32(&date[0],3));
							GUI_DispStringAt(temp2,x,y);
					   break;
					   case 0x12:
							memset(temp2,0,16);
							sprintf((char*)temp2,"%04d",BCD_INT32(&date[0],3));
							GUI_DispStringAt(temp2,x,y);
					   break;
					   case 0x13:
							memset(temp2,0,16);
							sprintf((char*)temp2,"%04d",BCD_INT32(&date[0],3));
							GUI_DispStringAt(temp2,x,y);
					   break;
					   case 0x31:
							  memset(temp2,0,16);
							  sprintf((char*)temp2,"%02d-%02d %02d:%02d",date[4],date[3],date[2],date[1]);
							  GUI_DispStringAt(temp2,x,y);
					   break;
					   case 0x32:
							  memset(temp2,0,16);
							  sprintf((char*)temp2,"%02d-%02d %02d:%02d",date[4],date[3],date[2],date[1]);
							  GUI_DispStringAt(temp2,x,y);
					   break;
					   case 0x33:
							  memset(temp2,0,16);
							  sprintf((char*)temp2,"%02d-%02d %02d:%02d",date[4],date[3],date[2],date[1]);
							  GUI_DispStringAt(temp2,x,y);
					   break;
					   default:break;
					}
				};break;
				case 0xb4://b4XX��Լ��
				{
					  memset(temp2,0,16);
					  sprintf((char*)temp2,"%02x-%02x %02x:%02x",date[3],date[2],date[1],date[0]);
					  GUI_DispStringAt(temp2,x,y);
				};break;
				case 0xb5://b5XX��Լ��
				{
					  memset(temp2,0,16);
					  sprintf((char*)temp2,"%02x-%02x %02x:%02x",date[3],date[2],date[1],date[0]);
					  GUI_DispStringAt(temp2,x,y);
				};break;
				case 0xb6://b6XX��Լ��
				{
					switch(flag[0]){
					   case 0x11:
						 {
								memset(temp2,0,16);
								sprintf((char*)temp2,"%.2f",(FP32)BCD_INT32(&date[0],2)/10);

								GUI_DispStringAt(temp2,x,y);
								GUI_DispStringAt((INT8U *)"V",112,y);

						 };
					   break;
					   case 0x12:
					   {

								memset(temp2,0,16);
								sprintf((char*)temp2,"%0.2f",(FP32)BCD_INT32(&date[0],2)/10);
								GUI_DispStringAt(temp2,x,y);
								GUI_DispStringAt((INT8U *)"V",112,y);
						 };
					   break;
					   case 0x13:
					   {

								memset(temp2,0,16);
								sprintf((char*)temp2,"%0.2f",(FP32)BCD_INT32(&date[0],2)/10);
								GUI_DispStringAt(temp2,x,y);
								GUI_DispStringAt((INT8U *)"V",112,y);
						 };
					   break;
					   case 0x21:
					   {

								memset(temp2,0,16);
								if (date[2]&0x80)
								{
									SdPrint("%02x--%02x--%02x\n\r",date[2],date[1],date[0]);
									date[2]&=0x7F;
									sprintf((char*)temp2,"-%.3f",(FP32)BCD_INT32(&date[0],3)/1000);
								}
								else
								{
									sprintf((char*)temp2,"%.3f",(FP32)BCD_INT32(&date[0],3)/1000);
								}
								GUI_DispStringAt(temp2,x,y);
								GUI_DispStringAt((INT8U *)"A",112,y);
						 };
					   break;
					   case 0x22:
					   {

								memset(temp2,0,16);
								if (date[2]&0x80)
								{
									date[2]&=0x7F;
									sprintf((char*)temp2,"-%.3f",(FP32)BCD_INT32(&date[0],3)/1000);
								}
								else
								{
									sprintf((char*)temp2,"%.3f",(FP32)BCD_INT32(&date[0],3)/1000);
								}
								GUI_DispStringAt(temp2,x,y);
								GUI_DispStringAt((INT8U *)"A",112,y);
						 };
					   break;
					   case 0x23:
					   {

								memset(temp2,0,16);
								if (date[2]&0x80)
								{
									date[2]&=0x7F;
									sprintf((char*)temp2,"-%.3f",(FP32)BCD_INT32(&date[0],3)/1000);
								}else
									sprintf((char*)temp2,"%.3f",(FP32)BCD_INT32(&date[0],3)/1000);
								GUI_DispStringAt(temp2,x,y);
								GUI_DispStringAt((INT8U *)"A",112,y);

						 };
					   break;
					   case 0x30:
						{
							memset(temp2,0,16);
							if (date[2]&0x80)
							{
								date[2]&=0x7F;
								sprintf((char*)temp2,"-%.4f",(FP32)BCD_INT32(&date[0],3)/10000);
							}else
								sprintf((char*)temp2,"%.4f",(FP32)BCD_INT32(&date[0],3)/10000);
							GUI_DispStringAt(temp2,x,y);
							GUI_DispStringAt((INT8U *)"kW",112,y);
						};
					   break;
					   case 0x31:
						{
							memset(temp2,0,16);
							if (date[2]&0x80)
							{
								date[2]&=0x7F;
								sprintf((char*)temp2,"-%.4f",(FP32)BCD_INT32(&date[0],3)/10000);
							}else
								sprintf((char*)temp2,"%.4f",(FP32)BCD_INT32(&date[0],3)/10000);
							GUI_DispStringAt(temp2,x,y);
							GUI_DispStringAt((INT8U *)"kW",112,y);
						};
					   break;
					   case 0x32:
						{
							memset(temp2,0,16);
							if (date[2]&0x80)
							{
								date[2]&=0x7F;
								sprintf((char*)temp2,"-%.4f",(FP32)BCD_INT32(&date[0],3)/10000);
							}else
								sprintf((char*)temp2,"%.4f",(FP32)BCD_INT32(&date[0],3)/10000);
							GUI_DispStringAt(temp2,x,y);
							GUI_DispStringAt((INT8U *)"kW",112,y);
						};
					   break;
					   case 0x33:
						{
							memset(temp2,0,16);
							if (date[2]&0x80)
							{
								date[2]&=0x7F;
								sprintf((char*)temp2,"-%.4f",(FP32)BCD_INT32(&date[0],3)/10000);
							}else
								sprintf((char*)temp2,"%.4f",(FP32)BCD_INT32(&date[0],3)/10000);
							GUI_DispStringAt(temp2,x,y);
							GUI_DispStringAt((INT8U *)"kW",112,y);
						};
					   break;
					   case 0x40:
						{
							memset(temp2,0,16);
							if (date[2]&0x80)
							{
								date[2]&=0x7F;
								sprintf((char*)temp2,"-%.4f",(FP32)BCD_INT32(&date[0],3)/10000);
							}else
								sprintf((char*)temp2,"%.4f",(FP32)BCD_INT32(&date[0],3)/10000);
							GUI_DispStringAt(temp2,x,y);
							GUI_DispStringAt((INT8U *)"kAVr",112,y);
						};
					   break;
					   case 0x41:
						{
							memset(temp2,0,16);
							if (date[2]&0x80)
							{
								date[2]&=0x7F;
								sprintf((char*)temp2,"-%.4f",(FP32)BCD_INT32(&date[0],3)/10000);
							}else
								sprintf((char*)temp2,"%.4f",(FP32)BCD_INT32(&date[0],3)/10000);
							GUI_DispStringAt(temp2,x,y);
							GUI_DispStringAt((INT8U *)"kAVr",112,y);
						};
					   break;
					   case 0x42:
						{
							memset(temp2,0,16);
							if (date[2]&0x80)
							{
								date[2]&=0x7F;
								sprintf((char*)temp2,"-%.4f",(FP32)BCD_INT32(&date[0],3)/10000);
							}else
								sprintf((char*)temp2,"%.4f",(FP32)BCD_INT32(&date[0],3)/10000);
							GUI_DispStringAt(temp2,x,y);
							GUI_DispStringAt((INT8U *)"kAVr",112,y);
						};
					   break;
					   case 0x43:
						{
							memset(temp2,0,16);
							if (date[2]&0x80)
							{
								date[2]&=0x7F;
								sprintf((char*)temp2,"-%.4f",(FP32)BCD_INT32(&date[0],3)/10000);
							}else
								sprintf((char*)temp2,"%.4f",(FP32)BCD_INT32(&date[0],3)/10000);
							GUI_DispStringAt(temp2,x,y);
							GUI_DispStringAt((INT8U *)"kAVr",112,y);
						};
					   break;
					   case 0x50:
						{
							memset(temp2,0,16);
							if (date[1]&0x80)
							{
								date[1]&=0x7F;
								sprintf((char*)temp2,"-%.3f",(FP32)BCD_INT32(&date[0],2)/1000);
							}
							else
							{
								sprintf((char*)temp2,"%.3f",(FP32)BCD_INT32(&date[0],2)/1000);
							}
							GUI_DispStringAt(temp2,x,y);
						};
					   break;
					   case 0x51:
						{
							memset(temp2,0,16);
							if (date[1]&0x80)
							{
								date[1]&=0x7F;
								sprintf((char*)temp2,"-%.3f",(FP32)BCD_INT32(&date[0],2)/1000);
							}
							else
							{
								sprintf((char*)temp2,"%.3f",(FP32)BCD_INT32(&date[0],2)/1000);
							}
							GUI_DispStringAt(temp2,x,y);
						};
					   break;
					   case 0x52:
						{
							memset(temp2,0,16);
							if (date[1]&0x80)
							{
								date[1]&=0x7F;
								sprintf((char*)temp2,"-%.3f",(FP32)BCD_INT32(&date[0],2)/1000);
							}
							else
							{
								sprintf((char*)temp2,"%.3f",(FP32)BCD_INT32(&date[0],2)/1000);
							}
							GUI_DispStringAt(temp2,x,y);
						};
					   break;
					   case 0x53:
						{
							memset(temp2,0,16);
							if (date[1]&0x80)
							{
								date[1]&=0x7F;
								sprintf((char*)temp2,"-%.3f",(FP32)BCD_INT32(&date[0],2)/1000);
							}
							else
							{
								sprintf((char*)temp2,"%.3f",(FP32)BCD_INT32(&date[0],2)/1000);
							}
							GUI_DispStringAt(temp2,x,y);
						};
					   break;
					   default:break;
					}
				};break;
				/*case 0xc0://c0XX��Լ��
				{
					memset(temp2,0,16);
					sprintf((char*)temp2,"%03d",BCD_INT32(&date[0],3));
					GUI_DispStringAt(temp2,x,y);
				};break;*/
				default:break;
			}
		}
	}
//printf("\n temp2 ==%s", temp2);
}
void GetSingleData(DataFlg *data,INT8U *reslutBuf,INT8U DI1,INT8U DI0)
{
	INT8U i,isFlag=0;
	for(i=0;i<ManyFlagsCount;i++){
		if(data[i].flg.Dataflag[0]==DI0&&data[i].flg.Dataflag[1]==DI1){
            memcpy(reslutBuf,&data[i].datas[0],sizeof(data[i].datas));
            isFlag=1;
            break;
		}
		else if(data[i].flg.Dataflag[0]==(DI0|0x0f)&&data[i].flg.Dataflag[1]==DI1)
		{
            memcpy(reslutBuf,&data[i].datas[0],sizeof(data[i].datas));
            isFlag=1;
            break;
		}
	}
	if(isFlag==0){
		memset(reslutBuf,OxXX,sizeof(data[0].datas));
	}
}

void transCommData(tmepHelData *tmephelData,DataFlg *DataFlg,INT8U count){
    INT8U i,j=0,k=0;
    tmepHelData tempData;
    memset(&tempData,0,sizeof(tempData));
    for(i=0;i<ManyFlagsCount;i++){
    	if(DataFlg[i].flg.Dataflag[1]==0x00&&DataFlg[i].flg.Dataflag[0]==0x00)continue;
    	if((DataFlg[i].flg.Dataflag[0]|0x0f)==0x1f&&DataFlg[i].flg.Dataflag[1]==0x90){
    		if (DataFlg[i].flg.Dataflag[0]==0x1f)
				for(j=0;j<5;j++){

					tempData.tempRelTimeDate[k].flg.Dataflag[0]=0x10+j;

					tempData.tempRelTimeDate[k].flg.Dataflag[1]=0x90;
					memcpy(&tempData.tempRelTimeDate[k].datas[0],&DataFlg[i].datas[j*4],4);

					//returnChNm(tempData.tempRelTimeDate[k].flg.Dataflag,tempData.ChNm[k]);

					k++;
				}
    		else
    		{
				tempData.tempRelTimeDate[k].flg.Dataflag[0]=DataFlg[i].flg.Dataflag[0];

				tempData.tempRelTimeDate[k].flg.Dataflag[1]=0x90;
				memcpy(&tempData.tempRelTimeDate[k].datas[0],&DataFlg[i].datas[0],4);
				k++;
    		}
    	}
    	else if((DataFlg[i].flg.Dataflag[0]|0x0f)==0x3f&&DataFlg[i].flg.Dataflag[1]==0xb6){
    		if (DataFlg[i].flg.Dataflag[0]==0x3f)
				for(j=0;j<4;j++){

					tempData.tempRelTimeDate[k].flg.Dataflag[0]=0x30+j;

					tempData.tempRelTimeDate[k].flg.Dataflag[1]=0xb6;
					memcpy(&tempData.tempRelTimeDate[k].datas[0],&DataFlg[i].datas[j*3],3);

					//returnChNm(tempData.tempRelTimeDate[k].flg.Dataflag,tempData.ChNm[k]);

					k++;
				}
    		else
    		{
				tempData.tempRelTimeDate[k].flg.Dataflag[0]=DataFlg[i].flg.Dataflag[0];

				tempData.tempRelTimeDate[k].flg.Dataflag[1]=0xb6;
				memcpy(&tempData.tempRelTimeDate[k].datas[0],&DataFlg[i].datas[0],3);
				k++;
    		}
    	}
    	else if((DataFlg[i].flg.Dataflag[0]|0x0f)==0x2f&&DataFlg[i].flg.Dataflag[1]==0xb6){
    		if (DataFlg[i].flg.Dataflag[0]==0x2f)
				for(j=0;j<3;j++){

					tempData.tempRelTimeDate[k].flg.Dataflag[0]=0x21+j;

					tempData.tempRelTimeDate[k].flg.Dataflag[1]=0xb6;
					memcpy(&tempData.tempRelTimeDate[k].datas[0],&DataFlg[i].datas[j*3],3);

					//returnChNm(tempData.tempRelTimeDate[k].flg.Dataflag,tempData.ChNm[k]);

					k++;
				}
    		else
    		{
				tempData.tempRelTimeDate[k].flg.Dataflag[0]=DataFlg[i].flg.Dataflag[0];

				tempData.tempRelTimeDate[k].flg.Dataflag[1]=0xb6;
				memcpy(&tempData.tempRelTimeDate[k].datas[0],&DataFlg[i].datas[0],3);
				k++;
    		}
    	}
    	else if((DataFlg[i].flg.Dataflag[0]|0x0f)==0x1f&&DataFlg[i].flg.Dataflag[1]==0xb6){
    		if (DataFlg[i].flg.Dataflag[0]==0x1f)
				for(j=0;j<3;j++){

					tempData.tempRelTimeDate[k].flg.Dataflag[0]=0x11+j;

					tempData.tempRelTimeDate[k].flg.Dataflag[1]=0xb6;
					memcpy(&tempData.tempRelTimeDate[k].datas[0],&DataFlg[i].datas[j*2],2);

					//returnChNm(tempData.tempRelTimeDate[k].flg.Dataflag,tempData.ChNm[k]);

					k++;
				}
    		else
    		{
				tempData.tempRelTimeDate[k].flg.Dataflag[0]=DataFlg[i].flg.Dataflag[0];

				tempData.tempRelTimeDate[k].flg.Dataflag[1]=0xb6;
				memcpy(&tempData.tempRelTimeDate[k].datas[0],&DataFlg[i].datas[0],2);
				k++;
    		}
    	}
    	else{
			memcpy(&tempData.tempRelTimeDate[k].datas[0],DataFlg[i].datas,DataLenMax);
			//returnChNm(tempData.tempRelTimeDate[k].flg.Dataflag,tempData.ChNm[k]);
			k++;
		}
    }
    //fprintf( stderr, "The aaaaaaaaaaaaaaaaaaaaaaaaa the COunt %d\n",k);
    for(i=0;i<count;i++){
    	for(j=0;j<k;j++){
    		if(tempData.tempRelTimeDate[j].flg.Dataflag[0]==tmephelData->tempRelTimeDate[i].flg.Dataflag[0]
    		  &&tempData.tempRelTimeDate[j].flg.Dataflag[1]==tmephelData->tempRelTimeDate[i].flg.Dataflag[1]){
    			memcpy(tmephelData->tempRelTimeDate[i].datas,tempData.tempRelTimeDate[j].datas,DataLenMax);
   			   break;
    		}
    	}
    }
    //fprintf( stderr, "The EEEEEEEEEEEEend\n");
    return;
}
INT8U initHisDate(){
   TS ts;
   //FILE *fp;
   INT8U FilePath[50],flag=0;
   INT16U i;

   TSGet(&ts);
	for(i=0;i<PointMax;i++)
	{
		if (JParamInfo3761->group2.f10[i].Status != 1)
			continue;
	   memset(FilePath,0,50);
	   sprintf((char*)FilePath,"/nand/DataCurr/%04d/curr.dat",i+1);
	   if (access((char*)FilePath,0)==0)
	   {
		   flag=1;
		   break;
	   }else{
		   flag=0;
	   }
	}
	return flag;
}
//-------------------���
void PrintLunXianData(INT8U *name, INT8U di1, INT8U di0, int value, int len, int pos_x, int pos_y, int pos_x1, int pos_y1)
{
	DataFlg data;
	memset(&data, 0, sizeof(DataFlg));
	GUI_DispStringAt(name, pos_x, pos_y);
	SetDataFlag97(di1, di0, data.flg.Dataflag);
	INT32U_BCD(value,data.datas,len);
	Print_sel_data(data.datas,data.flg.Dataflag, pos_x1, pos_y1, 0);
	return;
}

void PrintLunXianTime(TS *ts, int pos_x, int pos_y)
{
	char stime[30];
	memset(stime, 0, 30);
	sprintf(stime, "%d-%d %d:%d", ts->Month, ts->Day, ts->Hour, ts->Minute);
	GUI_DispStringAt((INT8U *)stime, pos_x, pos_y);
}
void LunXunShowPage1()
{
	PrintLunXianData((INT8U *)"�����й��ܵ���",0x90,0x10,JDataFileInfo->jc.JcDdRealData.Z_P_All/64,4,0,16,16,32);
	GUI_DispStringAt((INT8U *)"kWh", 112, 32);
	PrintLunXianData((INT8U *)"�����й��ܵ���",0x90,0x20,JDataFileInfo->jc.JcDdRealData.F_P_All/64,	4,0,48,16,64);
	GUI_DispStringAt((INT8U *)"kWh", 112, 64);
	PrintLunXianData((INT8U *)"�����޹��ܵ���",0x91,0x10,JDataFileInfo->jc.JcDdRealData.Z_Q_All/64,4,0,80,16,96);
	GUI_DispStringAt((INT8U *)"kVArh", 112, 96);
	PrintLunXianData((INT8U *)"�����޹��ܵ���",0x91,0x20,JDataFileInfo->jc.JcDdRealData.F_Q_All/64,	4,0,112,16,128);
	GUI_DispStringAt((INT8U *)"kVArh", 112, 128);
	return;
}

void LunXunShowPage2()
{
	PrintLunXianData((INT8U *)"һ���������޹�����",0x91,0x11,JDataFileInfo->jc.JcDdRealData.Z_Q_F[0]/64,4,0,16,16,32);
	GUI_DispStringAt((INT8U *)"kVArh", 112, 32);
	PrintLunXianData((INT8U *)"�����������޹�����",0x91,0x12,JDataFileInfo->jc.JcDdRealData.Z_Q_F[1]/64,4,0,48,16,64);
	GUI_DispStringAt((INT8U *)"kVArh", 112, 64);
	PrintLunXianData((INT8U *)"�����������޹�����",0x91,0x13,JDataFileInfo->jc.JcDdRealData.Z_Q_F[2]/64,4,0,80,16,96);
	GUI_DispStringAt((INT8U *)"kVArh", 112, 96);
	PrintLunXianData((INT8U *)"�����������޹�����",0x91,0x14,JDataFileInfo->jc.JcDdRealData.Z_Q_F[3]/64,4,0,112,16,128);
	GUI_DispStringAt((INT8U *)"kVArh", 112, 128);
	return;
}

void LunXunShowPage3()
{
	PrintLunXianData((INT8U *)"һ���޷����޹�����",0x91,0x21,JDataFileInfo->jc.JcDdRealData.F_Q_F[0]/64,4,0,16,16,32);
	GUI_DispStringAt((INT8U *)"kVArh", 112, 32);
	PrintLunXianData((INT8U *)"�����޷����޹�����",0x91,0x22,JDataFileInfo->jc.JcDdRealData.F_Q_F[1]/64,4,0,48,16,64);
	GUI_DispStringAt((INT8U *)"kVArh", 112, 64);
	PrintLunXianData((INT8U *)"�����޷����޹�����",0x91,0x23,JDataFileInfo->jc.JcDdRealData.F_Q_F[2]/64,4,0,80,16,96);
	GUI_DispStringAt((INT8U *)"kVArh", 112, 96);
	PrintLunXianData((INT8U *)"�����޷����޹�����",0x91,0x24,JDataFileInfo->jc.JcDdRealData.F_Q_F[3]/64,4,0,112,16,128);
	GUI_DispStringAt((INT8U *)"kVArh", 112, 128);
	return;
}
void LunXunShowPage4()
{
	TS ts;
	PrintLunXianData((INT8U *)"�����й����������",0xa0,0x10,JDataFileInfo->jc.JcMaxXuliang.Z_P_X_All,3,0,16,16,32);
	//GUI_DispStringAt((INT8U *)"kWh", 80, 32);
	GUI_DispStringAt((INT8U *)"���������������ʱ��",0,48);
	ts.Minute = BCD_INT32(&JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_All[0], 1);
	ts.Hour = BCD_INT32(&JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_All[1], 1);
	ts.Day = BCD_INT32(&JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_All[2], 1);
	ts.Month = BCD_INT32(&JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_All[3], 1);
	PrintLunXianTime(&ts, 16, 64);
	PrintLunXianData((INT8U *)"�����й����������",0xa0,0x20,JDataFileInfo->jc.JcMaxXuliang.F_P_X_All,3,0,80,16,96);
	GUI_DispStringAt((INT8U *)"���������������ʱ��",0,112);
	ts.Minute = BCD_INT32(&JDataFileInfo->jc.JcMaxXuliang.Time_F_P_X_All[0], 1);
	ts.Hour = BCD_INT32(&JDataFileInfo->jc.JcMaxXuliang.Time_F_P_X_All[1], 1);
	ts.Day = BCD_INT32(&JDataFileInfo->jc.JcMaxXuliang.Time_F_P_X_All[2], 1);
	ts.Month = BCD_INT32(&JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_All[3], 1);
	PrintLunXianTime(&ts, 16, 128);
	return;
}
void LunXunShowPage5()
{
	TS ts;
	PrintLunXianData((INT8U *)"�����޹����������",0xa1,0x10,JDataFileInfo->jc.JcMaxXuliang.Z_Q_X_All,3,0,16,16,32);
	//GUI_DispStringAt((INT8U *)"kWh", 80, 32);
	GUI_DispStringAt((INT8U *)"���������������ʱ��",0,48);
	ts.Minute = BCD_INT32(&JDataFileInfo->jc.JcMaxXuliang.Time_Z_Q_X_All[0], 1);
	ts.Hour = BCD_INT32(&JDataFileInfo->jc.JcMaxXuliang.Time_Z_Q_X_All[1], 1);
	ts.Day = BCD_INT32(&JDataFileInfo->jc.JcMaxXuliang.Time_Z_Q_X_All[2], 1);
	ts.Month = BCD_INT32(&JDataFileInfo->jc.JcMaxXuliang.Time_Z_Q_X_All[3], 1);
	PrintLunXianTime(&ts, 16, 64);
	PrintLunXianData((INT8U *)"�����޹����������",0xa1,0x20,JDataFileInfo->jc.JcMaxXuliang.F_Q_X_All,3,0,80,16,96);
	//GUI_DispStringAt((INT8U *)"kWh", 80, 32);
	GUI_DispStringAt((INT8U *)"�����޴���������ʱ��",0,112);
	ts.Minute = BCD_INT32(&JDataFileInfo->jc.JcMaxXuliang.Time_F_Q_X_All[0], 1);
	ts.Hour = BCD_INT32(&JDataFileInfo->jc.JcMaxXuliang.Time_F_Q_X_All[1], 1);
	ts.Day = BCD_INT32(&JDataFileInfo->jc.JcMaxXuliang.Time_F_Q_X_All[2], 1);
	ts.Month = BCD_INT32(&JDataFileInfo->jc.JcMaxXuliang.Time_F_Q_X_All[3], 1);
	PrintLunXianTime(&ts, 16, 128);
	return;
}
void LunXunShowPage6()
{
	PrintLunXianData((INT8U *)"A���ѹ",0xB6,0x11,JDataFileInfo->jc.JcDdRealData.VA,2,0,16,16,32);
	GUI_DispStringAt((INT8U *)"V", 112, 32);
	PrintLunXianData((INT8U *)"B���ѹ",0xB6,0x12,JDataFileInfo->jc.JcDdRealData.VB,2,0,48,16,64);
	GUI_DispStringAt((INT8U *)"V", 112, 64);
	PrintLunXianData((INT8U *)"C���ѹ",0xB6,0x13,JDataFileInfo->jc.JcDdRealData.VC,2,0,80,16,96);
	GUI_DispStringAt((INT8U *)"V", 112, 96);
	return;
}
void LunXunShowPage7()
{
	PrintLunXianData((INT8U *)"A�����",0xB6,0x21,JDataFileInfo->jc.JcDdRealData.IA,3,0,16,16,32);
	GUI_DispStringAt((INT8U *)"A", 112, 32);
	PrintLunXianData((INT8U *)"B�����",0xB6,0x22,JDataFileInfo->jc.JcDdRealData.IB,3,0,48,16,64);
	GUI_DispStringAt((INT8U *)"A", 112, 64);
	PrintLunXianData((INT8U *)"C�����",0xB6,0x23,JDataFileInfo->jc.JcDdRealData.IC,3,0,80,16,96);
	GUI_DispStringAt((INT8U *)"A", 112, 96);
	return;
}
void LunXunShowPage8()
{
	PrintLunXianData((INT8U *)"�й�����",   0xB6,0x30,JDataFileInfo->jc.JcDdRealData.P, 3,0,16,16,32);
	GUI_DispStringAt((INT8U *)"kW", 112, 32);
	PrintLunXianData((INT8U *)"A���й�����",0xB6,0x31,JDataFileInfo->jc.JcDdRealData.PA,3,0,48,16,64);
	GUI_DispStringAt((INT8U *)"kW", 112, 64);
	PrintLunXianData((INT8U *)"B���й�����",0xB6,0x32,JDataFileInfo->jc.JcDdRealData.PB,3,0,80,16,96);
	GUI_DispStringAt((INT8U *)"kW", 112, 96);
	PrintLunXianData((INT8U *)"C���й�����",0xB6,0x33,JDataFileInfo->jc.JcDdRealData.PC,3,0,112,16,128);
	GUI_DispStringAt((INT8U *)"kW", 112, 128);
	return;
}
void LunXunShowPage9()
{
	PrintLunXianData((INT8U *)"�޹�����",   0xB6,0x40,JDataFileInfo->jc.JcDdRealData.Q, 3,0,16,16,32);
	GUI_DispStringAt((INT8U *)"kVAr", 112, 32);
	PrintLunXianData((INT8U *)"A���޹�����",0xB6,0x41,JDataFileInfo->jc.JcDdRealData.QA,3,0,48,16,64);
	GUI_DispStringAt((INT8U *)"kVAr", 112, 64);
	PrintLunXianData((INT8U *)"B���޹�����",0xB6,0x42,JDataFileInfo->jc.JcDdRealData.QB,3,0,80,16,96);
	GUI_DispStringAt((INT8U *)"kVAr", 112, 96);
	PrintLunXianData((INT8U *)"C���޹�����",0xB6,0x43,JDataFileInfo->jc.JcDdRealData.QC,3,0,112,16,128);
	GUI_DispStringAt((INT8U *)"kVAr", 112, 128);
	return;
}
void LunXunShowPage10()
{
	//printf("\ncos=%x \n",JDataFileInfo->jc.JcDdRealData.Cos);
	PrintLunXianData((INT8U *)"�ܹ�������", 0xB6,0x50,JDataFileInfo->jc.JcDdRealData.Cos, 2,0,16,16,32);
	PrintLunXianData((INT8U *)"A�๦������",0xB6,0x51,JDataFileInfo->jc.JcDdRealData.CosA,2,0,48,16,64);
	PrintLunXianData((INT8U *)"B�๦������",0xB6,0x52,JDataFileInfo->jc.JcDdRealData.CosB,2,0,80,16,96);
	PrintLunXianData((INT8U *)"C�๦������",0xB6,0x53,JDataFileInfo->jc.JcDdRealData.CosC,2,0,112,16,128);
	return;
}
void LunXunDataTianJin(int PageNo)
{
	switch(PageNo)
	{
	case 0:
		LunXunShowPage1();
		break;
	case 1:
		LunXunShowPage2();
		break;
	case 2:
		LunXunShowPage3();
		break;
	case 3:
		LunXunShowPage4();
		break;
	case 4:
		LunXunShowPage5();
		break;
	case 5:
		LunXunShowPage6();
		break;
	case 6:
		LunXunShowPage7();
		break;
	case 7:
		LunXunShowPage8();
		break;
	case 8:
		LunXunShowPage9();
		break;
	case 9:
		LunXunShowPage10();
		break;
	default:
		break;
	}
}
//-------------------------end
void LunXunData(INT16U MeterNum){
	INT8U Temp_FilePath[60];
	INT8U tempAdd[13];
	INT8U type;
	GUI_DispStringAt((INT8U *) "(", 0, 144);
	GUI_DispStringAt((INT8U *) ") ", 40, 144);
	GUI_DispDecAt(getPoint(TempMeterPara[MeterNum].CJQ_hao-1, TempMeterPara[MeterNum].DNB_hao), 8, 144, 4);

	BCDToASC(&TempMeterPara[MeterNum].p_8902.address[0],6,tempAdd);
	GUI_DispStringAt(tempAdd,64,144);
	memset(&LunXunsData,0x00,sizeof(tmepHelData));
	//printf("p_flag=%d,MeterNum=%d\n\r",TempMeterPara[MeterNum].p_flag,MeterNum);
	if(TempMeterPara[MeterNum].p_flag==0)
	{
		LunPage=2;
		return;
	}
	type = JParamInfo3761->group2.f10[getPoint(TempMeterPara[MeterNum].CJQ_hao-1, TempMeterPara[MeterNum].DNB_hao)-1].ConnectType;
	//printf("\ntype == %d metflag == %d", type, metflag);
	if (metflag==0)
	{
		if (type!=2)
		{
			memset(Temp_FilePath,0,60);
			sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",
					getPoint(TempMeterPara[MeterNum].CJQ_hao-1, TempMeterPara[MeterNum].DNB_hao));
			memset(&LunXunsmfile,0xff,sizeof(SMFiles));
			//printf("\n Temp_FilePath ==%s\n", Temp_FilePath);
			if (access((char *) Temp_FilePath,0)==0)
			{
				ReadFile((char *) Temp_FilePath, &LunXunsmfile,sizeof(SMFiles),JProgramInfo);
			}
				else return;
//			fprintf(stderr,"\n%d--%d--%d--%d\n\r",LunXunsmfile.sm.CaijiQiNo,TempMeterPara[MeterNum].CJQ_hao-1,
//					LunXunsmfile.sm.MeterNo,TempMeterPara[MeterNum].DNB_hao-1);
		}
		else
		{
			LunXunsmfile.sm.CaijiQiNo=TempMeterPara[MeterNum].CJQ_hao-1;
			LunXunsmfile.sm.MeterNo=TempMeterPara[MeterNum].DNB_hao-1;
		}
	}
    if((TempMeterPara[MeterNum].p_flag==6)||(TempMeterPara[MeterNum].p_flag==9))
    {  //�����
    	LunPage=2;
    	GUI_DispStringAt((INT8U *)"�����й��ܵ���",0,16);
    	GUI_DispStringAt((INT8U *)"��ǰ����",0,48);
    	GUI_DispStringAt((INT8U *)"��ѹ",0,64);
    	GUI_DispStringAt((INT8U *)"����",0,80);

//    	printf("LunXunsmfile.sm.CaijiQiNo %d TempMeterPara[MeterNum].CJQ_hao %d  LunXunsmfile.sm.MeterNo %d TempMeterPara[MeterNum].DNB_hao %d",
//    			LunXunsmfile.sm.CaijiQiNo,
//    			TempMeterPara[MeterNum].CJQ_hao,
//    			LunXunsmfile.sm.MeterNo,
//    			TempMeterPara[MeterNum].DNB_hao
//    	);
		if(LunXunsmfile.sm.CaijiQiNo==(TempMeterPara[MeterNum].CJQ_hao-1)&&LunXunsmfile.sm.MeterNo==(TempMeterPara[MeterNum].DNB_hao-1))
		{
		//	printf("\ntype == %d metflag == %d", type, metflag);
			SetDataFlag97(0x90,0x10,LunXunsData.tempRelTimeDate[0].flg.Dataflag);
			if (type==2)
				INT32U_BCD(JDataFileInfo->jc.JcDdRealData.Z_P_All/64,&LunXunsData.tempRelTimeDate[0].datas[0],4);//nengliang
			SetDataFlag97(0xb6,0x30,LunXunsData.tempRelTimeDate[1].flg.Dataflag);
			if (type==2)
				INT32U_BCD(JDataFileInfo->jc.JcDdRealData.P/64,&LunXunsData.tempRelTimeDate[1].datas[0],3);
			SetDataFlag97(0xb6,0x11,LunXunsData.tempRelTimeDate[2].flg.Dataflag);
			if (type==2)
				INT32U_BCD(JDataFileInfo->jc.JcDdRealData.VA,&LunXunsData.tempRelTimeDate[2].datas[0],2);
			SetDataFlag97(0xb6,0x21,LunXunsData.tempRelTimeDate[3].flg.Dataflag);
			if (type==2)
				INT32U_BCD(JDataFileInfo->jc.JcDdRealData.IA,&LunXunsData.tempRelTimeDate[3].datas[0],3);//LQQ
			if (type!=2)
				transCommData(&LunXunsData,LunXunsmfile.sm.datas,4);
			//printf("----------------------begin");
    		Print_sel_data(LunXunsData.tempRelTimeDate[0].datas,LunXunsData.tempRelTimeDate[0].flg.Dataflag,16 ,32,0);
    		Print_sel_data(LunXunsData.tempRelTimeDate[1].datas,LunXunsData.tempRelTimeDate[1].flg.Dataflag,80 ,48,0);
    		Print_sel_data(LunXunsData.tempRelTimeDate[2].datas,LunXunsData.tempRelTimeDate[2].flg.Dataflag,80 ,64,0);
    		Print_sel_data(LunXunsData.tempRelTimeDate[3].datas,LunXunsData.tempRelTimeDate[3].flg.Dataflag,80 ,80,0);
    		//printf("----------------------end");
		}
    }
    else {//�๦�ܱ�
    	if (LunPage==2)
    	{
			GUI_DispStringAt((INT8U *)"�ܹ�������",0,16);
			GUI_DispStringAt((INT8U *)"A�����",0,48);
			GUI_DispStringAt((INT8U *)"B�����",0,64);
			GUI_DispStringAt((INT8U *)"C�����",0,80);
			if(LunXunsmfile.sm.CaijiQiNo==(TempMeterPara[MeterNum].CJQ_hao-1)
					&&LunXunsmfile.sm.MeterNo==(TempMeterPara[MeterNum].DNB_hao-1)){
				SetDataFlag97(0xb6,0x50,LunXunsData.tempRelTimeDate[0].flg.Dataflag);
				if (type==2)
					INT32U_BCD(JDataFileInfo->jc.JcDdRealData.Cos,&LunXunsData.tempRelTimeDate[0].datas[0],2);
				SetDataFlag97(0xb6,0x21,LunXunsData.tempRelTimeDate[1].flg.Dataflag);
				if (type==2)
					INT32U_BCD(JDataFileInfo->jc.JcDdRealData.IA,&LunXunsData.tempRelTimeDate[1].datas[0],3);//LQQ
				SetDataFlag97(0xb6,0x22,LunXunsData.tempRelTimeDate[2].flg.Dataflag);
				if (type==2)
					INT32U_BCD(JDataFileInfo->jc.JcDdRealData.IB,&LunXunsData.tempRelTimeDate[2].datas[0],3);//LQQ
				SetDataFlag97(0xb6,0x23,LunXunsData.tempRelTimeDate[3].flg.Dataflag);
				if (type==2)
					INT32U_BCD(JDataFileInfo->jc.JcDdRealData.IC,&LunXunsData.tempRelTimeDate[3].datas[0],3);//LQQ
				if (type!=2)
					transManyData(&LunXunsData,LunXunsmfile.sm.datas,4);
				Print_sel_data(LunXunsData.tempRelTimeDate[0].datas,LunXunsData.tempRelTimeDate[0].flg.Dataflag,16 ,32,0);
				Print_sel_data(LunXunsData.tempRelTimeDate[1].datas,LunXunsData.tempRelTimeDate[1].flg.Dataflag,80,48,0);
				Print_sel_data(LunXunsData.tempRelTimeDate[2].datas,LunXunsData.tempRelTimeDate[2].flg.Dataflag,80,64,0);
				Print_sel_data(LunXunsData.tempRelTimeDate[3].datas,LunXunsData.tempRelTimeDate[3].flg.Dataflag,80,80,0);
			}
    	}
    	else
    	{
			GUI_DispStringAt((INT8U *)"�����й��ܵ���",0,16);
			GUI_DispStringAt((INT8U *)"��ǰ�ܹ���",0,48);
			GUI_DispStringAt((INT8U *)"A���ѹ",0,64);
			GUI_DispStringAt((INT8U *)"B���ѹ",0,80);
			GUI_DispStringAt((INT8U *)"C���ѹ",0,96);
			if(LunXunsmfile.sm.CaijiQiNo==(TempMeterPara[MeterNum].CJQ_hao-1)
					&&LunXunsmfile.sm.MeterNo==(TempMeterPara[MeterNum].DNB_hao-1)){
				SetDataFlag97(0x90,0x10,LunXunsData.tempRelTimeDate[0].flg.Dataflag);
				if (type==2)
					INT32U_BCD(JDataFileInfo->jc.JcDdRealData.Z_P_All/64,&LunXunsData.tempRelTimeDate[0].datas[0],4);//nengliang
				SetDataFlag97(0xb6,0x30,LunXunsData.tempRelTimeDate[1].flg.Dataflag);
				if (type==2)
					INT32U_BCD(JDataFileInfo->jc.JcDdRealData.P,&LunXunsData.tempRelTimeDate[1].datas[0],3);
				SetDataFlag97(0xb6,0x11,LunXunsData.tempRelTimeDate[2].flg.Dataflag);
				if (type==2)
					INT32U_BCD(JDataFileInfo->jc.JcDdRealData.VA,&LunXunsData.tempRelTimeDate[2].datas[0],2);
				SetDataFlag97(0xb6,0x12,LunXunsData.tempRelTimeDate[3].flg.Dataflag);
				if (type==2)
					INT32U_BCD(JDataFileInfo->jc.JcDdRealData.VB,&LunXunsData.tempRelTimeDate[3].datas[0],2);
				SetDataFlag97(0xb6,0x13,LunXunsData.tempRelTimeDate[4].flg.Dataflag);
				if (type==2)
					INT32U_BCD(JDataFileInfo->jc.JcDdRealData.VC,&LunXunsData.tempRelTimeDate[4].datas[0],2);
				if (type!=2)
					transManyData(&LunXunsData,LunXunsmfile.sm.datas,5);
				Print_sel_data(LunXunsData.tempRelTimeDate[0].datas,LunXunsData.tempRelTimeDate[0].flg.Dataflag,16 ,32,0);
				Print_sel_data(LunXunsData.tempRelTimeDate[1].datas,LunXunsData.tempRelTimeDate[1].flg.Dataflag,80,48,0);
				Print_sel_data(LunXunsData.tempRelTimeDate[2].datas,LunXunsData.tempRelTimeDate[2].flg.Dataflag,80,64,0);
				Print_sel_data(LunXunsData.tempRelTimeDate[3].datas,LunXunsData.tempRelTimeDate[3].flg.Dataflag,80,80,0);
				Print_sel_data(LunXunsData.tempRelTimeDate[4].datas,LunXunsData.tempRelTimeDate[4].flg.Dataflag,80,96,0);
			}
		}
	}
}



void transManyData(tmepHelData *tmephelData,DataFlg *DataFlg,INT8U count){
    INT16U i,j=0,k=0;
    tmepHelData tempData;
    memset(&tempData,0,sizeof(tempData));
    for(i=0;i<ManyFlagsCount;i++){
    	//SdPrint("transManyData --%02x%02x\n\r",DataFlg[i].flg.Dataflag[1],DataFlg[i].flg.Dataflag[0]);
    	if(DataFlg[i].flg.Dataflag[1]==0x00&&DataFlg[i].flg.Dataflag[0]==0x00)continue;
    	if (DataFlg[i].flg.ReadFlg==2) continue;
    	if((DataFlg[i].flg.Dataflag[0]&0xF0)==0x10&&DataFlg[i].flg.Dataflag[1]==0x90){
    		for(j=0;j<5;j++){

    			tempData.tempRelTimeDate[k].flg.Dataflag[0]=0x10+j;

    			tempData.tempRelTimeDate[k].flg.Dataflag[1]=0x90;
    			memcpy(&tempData.tempRelTimeDate[k].datas[0],&DataFlg[i].datas[j*4],4);

    			//returnChNm(tempData.tempRelTimeDate[k].flg.Dataflag,tempData.ChNm[k]);

    			k++;
    		}
    	}else
    	if((DataFlg[i].flg.Dataflag[0]&0xF0)==0x20&&DataFlg[i].flg.Dataflag[1]==0x90){
			for(j=0;j<5;j++){
				tempData.tempRelTimeDate[k].flg.Dataflag[0]=0x20+j;
				tempData.tempRelTimeDate[k].flg.Dataflag[1]=0x90;
				memcpy(&tempData.tempRelTimeDate[k].datas[0],&DataFlg[i].datas[j*4],4);
				//returnChNm(tempData.tempRelTimeDate[k].flg.Dataflag,tempData.ChNm[k]);
				k++;
			}
		}else
    	if((DataFlg[i].flg.Dataflag[0]&0xF0)==0x30&&DataFlg[i].flg.Dataflag[1]==0x91){
			for(j=0;j<5;j++){
				tempData.tempRelTimeDate[k].flg.Dataflag[0]=0x30+j;
				tempData.tempRelTimeDate[k].flg.Dataflag[1]=0x91;
				memcpy(&tempData.tempRelTimeDate[k].datas[0],&DataFlg[i].datas[j*4],4);
				//returnChNm(tempData.tempRelTimeDate[k].flg.Dataflag,tempData.ChNm[k]);
				k++;
			}
		}else
    	if((DataFlg[i].flg.Dataflag[0]&0xF0)==0x40&&DataFlg[i].flg.Dataflag[1]==0x91){
			for(j=0;j<5;j++){
				tempData.tempRelTimeDate[k].flg.Dataflag[0]=0x40+j;
				tempData.tempRelTimeDate[k].flg.Dataflag[1]=0x91;
				memcpy(&tempData.tempRelTimeDate[k].datas[0],&DataFlg[i].datas[j*4],4);
				//returnChNm(tempData.tempRelTimeDate[k].flg.Dataflag,tempData.ChNm[k]);
				k++;
			}
		}else
    	if((DataFlg[i].flg.Dataflag[0]&0xF0)==0x50&&DataFlg[i].flg.Dataflag[1]==0x91){
			for(j=0;j<5;j++){
				tempData.tempRelTimeDate[k].flg.Dataflag[0]=0x50+j;
				tempData.tempRelTimeDate[k].flg.Dataflag[1]=0x91;
				memcpy(&tempData.tempRelTimeDate[k].datas[0],&DataFlg[i].datas[j*4],4);
				//returnChNm(tempData.tempRelTimeDate[k].flg.Dataflag,tempData.ChNm[k]);
				k++;
			}
		}else
    	if((DataFlg[i].flg.Dataflag[0]&0xF0)==0x60&&DataFlg[i].flg.Dataflag[1]==0x91){
			for(j=0;j<5;j++){
				tempData.tempRelTimeDate[k].flg.Dataflag[0]=0x60+j;
				tempData.tempRelTimeDate[k].flg.Dataflag[1]=0x91;
				memcpy(&tempData.tempRelTimeDate[k].datas[0],&DataFlg[i].datas[j*4],4);
				//returnChNm(tempData.tempRelTimeDate[k].flg.Dataflag,tempData.ChNm[k]);
				k++;
			}
		}else
	    	if((DataFlg[i].flg.Dataflag[0]&0xF0)==0x10&&DataFlg[i].flg.Dataflag[1]==0xa0){
				for(j=0;j<5;j++){
					tempData.tempRelTimeDate[k].flg.Dataflag[0]=0x10+j;
					tempData.tempRelTimeDate[k].flg.Dataflag[1]=0xa0;
					memcpy(&tempData.tempRelTimeDate[k].datas[0],&DataFlg[i].datas[j*3],3);
					//returnChNm(tempData.tempRelTimeDate[k].flg.Dataflag,tempData.ChNm[k]);
					k++;
				}
		}else
	    	if((DataFlg[i].flg.Dataflag[0]&0xF0)==0x10&&DataFlg[i].flg.Dataflag[1]==0xa4){
				for(j=0;j<5;j++){
					tempData.tempRelTimeDate[k].flg.Dataflag[0]=0x10+j;
					tempData.tempRelTimeDate[k].flg.Dataflag[1]=0xa4;
					memcpy(&tempData.tempRelTimeDate[k].datas[0],&DataFlg[i].datas[j*3],3);
					//returnChNm(tempData.tempRelTimeDate[k].flg.Dataflag,tempData.ChNm[k]);
					k++;
				}
		}else
	    	if((DataFlg[i].flg.Dataflag[0]&0xF0)==0x20&&DataFlg[i].flg.Dataflag[1]==0xa4){
				for(j=0;j<5;j++){
					tempData.tempRelTimeDate[k].flg.Dataflag[0]=0x20+j;
					tempData.tempRelTimeDate[k].flg.Dataflag[1]=0xa4;
					memcpy(&tempData.tempRelTimeDate[k].datas[0],&DataFlg[i].datas[j*3],3);
					//returnChNm(tempData.tempRelTimeDate[k].flg.Dataflag,tempData.ChNm[k]);
					k++;
				}
		}else
	    	if((DataFlg[i].flg.Dataflag[0]&0xF0)==0x10&&DataFlg[i].flg.Dataflag[1]==0xb3){
				for(j=0;j<5;j++){
					tempData.tempRelTimeDate[k].flg.Dataflag[0]=0x10+j;
					tempData.tempRelTimeDate[k].flg.Dataflag[1]=0xb3;
					memcpy(&tempData.tempRelTimeDate[k].datas[0],&DataFlg[i].datas[j*3],3);
					//returnChNm(tempData.tempRelTimeDate[k].flg.Dataflag,tempData.ChNm[k]);
					k++;
				}
		}else
	    	if((DataFlg[i].flg.Dataflag[0]&0xF0)==0x10&&DataFlg[i].flg.Dataflag[1]==0xb6){
				for(j=0;j<3;j++){
					tempData.tempRelTimeDate[k].flg.Dataflag[0]=0x11+j;
					tempData.tempRelTimeDate[k].flg.Dataflag[1]=0xb6;
					memcpy(&tempData.tempRelTimeDate[k].datas[0],&DataFlg[i].datas[j*2],2);
					//returnChNm(tempData.tempRelTimeDate[k].flg.Dataflag,tempData.ChNm[k]);
					k++;
				}
		}else
	    	if((DataFlg[i].flg.Dataflag[0]&0xF0)==0x20&&DataFlg[i].flg.Dataflag[1]==0xb6){
				for(j=0;j<3;j++){
					tempData.tempRelTimeDate[k].flg.Dataflag[0]=0x21+j;
					tempData.tempRelTimeDate[k].flg.Dataflag[1]=0xb6;
					memcpy(&tempData.tempRelTimeDate[k].datas[0],&DataFlg[i].datas[j*3],3);
					//returnChNm(tempData.tempRelTimeDate[k].flg.Dataflag,tempData.ChNm[k]);
					k++;
				}
		}else
	    	if((DataFlg[i].flg.Dataflag[0]&0xF0)==0x30&&DataFlg[i].flg.Dataflag[1]==0xb6){
				for(j=0;j<4;j++){
					tempData.tempRelTimeDate[k].flg.Dataflag[0]=0x30+j;
					tempData.tempRelTimeDate[k].flg.Dataflag[1]=0xb6;
					memcpy(&tempData.tempRelTimeDate[k].datas[0],&DataFlg[i].datas[j*3],3);
					//returnChNm(tempData.tempRelTimeDate[k].flg.Dataflag,tempData.ChNm[k]);
					k++;
				}
		}else
	    	if((DataFlg[i].flg.Dataflag[0]&0xF0)==0x40&&DataFlg[i].flg.Dataflag[1]==0xb6){
				for(j=0;j<4;j++){
					tempData.tempRelTimeDate[k].flg.Dataflag[0]=0x40+j;
					tempData.tempRelTimeDate[k].flg.Dataflag[1]=0xb6;
					memcpy(&tempData.tempRelTimeDate[k].datas[0],&DataFlg[i].datas[j*2],2);
					//returnChNm(tempData.tempRelTimeDate[k].flg.Dataflag,tempData.ChNm[k]);
					k++;
				}
		}else
	    	if((DataFlg[i].flg.Dataflag[0]&0xF0)==0x50&&DataFlg[i].flg.Dataflag[1]==0xb6){
				for(j=0;j<4;j++){
					tempData.tempRelTimeDate[k].flg.Dataflag[0]=0x50+j;
					tempData.tempRelTimeDate[k].flg.Dataflag[1]=0xb6;
					memcpy(&tempData.tempRelTimeDate[k].datas[0],&DataFlg[i].datas[j*2],2);
					//returnChNm(tempData.tempRelTimeDate[k].flg.Dataflag,tempData.ChNm[k]);
					k++;
				}
		}else{
			memcpy(&tempData.tempRelTimeDate[k].datas[0],DataFlg[i].datas,DataLenMax);
			//returnChNm(tempData.tempRelTimeDate[k].flg.Dataflag,tempData.ChNm[k]);
			k++;
		}
    	if (k>=ManyFlagsCount)
    		break;
    }
    //SdPrint( "The aaaaaaaaaaaaaaaaaaaaaaaaa the COunt %d\n\r",k);
    for(i=0;i<count;i++){
    	for(j=0;((j<k)&&(j<ManyFlagsCount));j++){
    		if(tempData.tempRelTimeDate[j].flg.Dataflag[0]==tmephelData->tempRelTimeDate[i].flg.Dataflag[0]
    		  &&tempData.tempRelTimeDate[j].flg.Dataflag[1]==tmephelData->tempRelTimeDate[i].flg.Dataflag[1]){
    			memcpy(tmephelData->tempRelTimeDate[i].datas,tempData.tempRelTimeDate[j].datas,DataLenMax);

   			   break;
    		}
    	}
    }
    //fprintf( stderr, "The EEEEEEEEEEEEend\n");
    return;
}


/******************************************************************************************************************
* �������ƣ�ScreenInput()
* ��    �ܣ�Һ������������õĺ���
* ��ڲ�������
* ���ڲ���������1��   ��Ҫ���õ��������ַ��������ı�
            ����0��   ��Ҫ���õ��������ַ���û�з����ı�
            ����0��   ��ʱ�ް������Զ��˳�
*******************************************************************************************************************/

