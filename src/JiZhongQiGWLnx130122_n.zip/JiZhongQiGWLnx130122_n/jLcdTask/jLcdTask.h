#ifndef JLCDTASK
#define JLCDTASK

#include "TypeDef.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "stdarg.h"
#include <stdint.h>
#include <sys/mman.h>
#include "font8x16.h"
#include "fcntl.h"
#include "unistd.h"
#include <sys/time.h>
#include <pthread.h>
#include "inc/pubfunction.h"
#include "inc/init.h"
#include <signal.h>

#define SdPrint(...) if (jLcdPrint==1) printf(__VA_ARGS__);\
	else if (jLcdPrint==2) fprintf(fp, __VA_ARGS__);\
	else if (jLcdPrint==3) fprintf(stderr,__VA_ARGS__);
#define LCD_1
#define MAX 10
char LcdBuf[160*160];
#define AT91C_SMC_READMODE    (0x1 <<  0) // (SMC) Read Mode
#define AT91C_SMC_WRITEMODE   (0x1 <<  1) // (SMC) Write Mode
#define AT91C_SMC_DBW_WIDTH_EIGTH_BITS     (0x0 << 12) // (SMC) 8 bits.

#define LCM_X    160
#define LCM_Y    160

#define AT91C_PIO_PB18        (1 <<  18) // Pin Controlled by Pb18  ;;K1=��
#define AT91C_PIO_PB19        (1 <<  19) // Pin Controlled by Pb19  ;;K2=��
#define AT91C_PIO_PB20        (1 <<  20) // Pin Controlled by Pb20  ;;K1=��
#define AT91C_PIO_PB21        (1 <<  21) // Pin Controlled by Pb21  ;;K2=��
#define AT91C_PIO_PB22        (1 <<  22) // Pin Controlled by Pb22  ;;K3=ȷ��
#define AT91C_PIO_PB25        (1 <<  25) // Pin Controlled by Pb25  ;;K6=ȡ��
#define AT91C_PIO_PA26        (1 <<  26) // Pin Controlled by PA26  Lcd rst
#define AT91C_PIO_PA27        (1 <<  27) // Pin Controlled by PA27  Lcd����


typedef struct {
	int messageType; // contains both message to and from client
} ClientMessageT;

extern void LcdSendCmd(unsigned char cmd);
extern void LcdSendData(unsigned char data);
extern void GUI_Point(unsigned int Px, unsigned char Py, unsigned char attr);
extern void GUI_DrawVLine(unsigned int x0, unsigned char y0, unsigned char y1);
extern void GUI_DrawHLine(unsigned int x0, unsigned char y0, unsigned int x1);

extern int number;
extern unsigned int ScanBuff[LCM_Y][LCM_X]; //������ʾ����,ʹ�ò��ô�Һ����������������
extern unsigned char Pixel[2];
extern uintptr_t BaseLcdIo, CmdAddr, DataAddr;
extern unsigned char LcdDrawBuff[9600];
extern uintptr_t BaseKeyIo;
extern uintptr_t BaseLcmIo;
extern unsigned char Txmode_flag;
extern char HzBuf[32];
extern unsigned char HzDat[267615];//262144
extern pthread_t thread[2];
extern pthread_mutex_t mut;

extern void ReadHzkBuff();
extern void GUI_SetTextMode(unsigned char flag);
extern void GUI_DispStringAt(unsigned char *format, unsigned int y, unsigned int x);
extern void GUI_DispDecAt(signed long int v, unsigned char x, unsigned char y, unsigned char len);
extern void GUI_DispHexAt(signed long int v, unsigned char x, unsigned char y, unsigned char len);
extern void GUI_DispDecShiftAt(unsigned char y, unsigned char x, unsigned char Num1, unsigned char Num2, signed long int Num3);
extern void GUI_DispCharAt(unsigned char c, unsigned char x, unsigned char y);
extern void LcmClear(void);
extern void Lcmfull(void);
extern void FillDataFromBuffer(void);
extern void GUI_Clear(void);
extern void LCDinit(void);
extern void IOInit(void);
extern void BOARD_ConfigureSMCLcd(void);
#ifdef __linux__
#endif
#endif

