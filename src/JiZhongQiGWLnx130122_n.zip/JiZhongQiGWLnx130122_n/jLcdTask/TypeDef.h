#ifndef TYPEDEF_H_
#define TYPEDEF_H_

typedef unsigned long  int  u32;
typedef unsigned short int  u16;
typedef unsigned char   u8;

//typedef unsigned long  int  INT32U;
//typedef signed long  int  INT32S;
//typedef unsigned short int  INT16U;
//typedef unsigned char   INT8U;
//typedef signed char   INT8S;

#endif /*TYPEDEF_H_*/
