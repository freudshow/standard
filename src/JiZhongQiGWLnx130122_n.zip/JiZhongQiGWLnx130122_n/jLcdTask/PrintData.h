/*
 * PrintData.h
 *
 *  Created on: 2009-10-13
 *      Author: ZhuRui
 */

#ifndef PRINTDATA_H_
#define PRINTDATA_H_
#include <inc/pubfunction.h>
#include <stdio.h>
#include "lcdapp.h"

extern int jLcdPrint;
extern FILE *fp;
extern INT8U initHisDate();
extern void LunXunData(INT16U MeterNum);
extern void transManyData(tmepHelData *tmephelData, DataFlg *DataFlg, INT8U count);
extern void Print_sel_date(INT8U *date, INT8U *flag, INT8U x, INT8U y, INT8U GuiYue);
extern void GetSingleData(DataFlg *data,INT8U *reslutBuf,INT8U DI1,INT8U DI0);
#endif /* PRINTDATA_H_ */
