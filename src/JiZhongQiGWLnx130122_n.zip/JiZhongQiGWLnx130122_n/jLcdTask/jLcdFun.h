/*
 * jLcdFun.h
 *  jLcdTask�漰������Ҫ����
 *  Created on: 2009-9-12
 *      Author: ZhuRui
 */

#ifndef JLCDFUN_H_
#define JLCDFUN_H_

#include <string.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include "time.h"
#include "PrintData.h"
#include <unistd.h>
#include <signal.h>
#include <fcntl.h>
#include <ctype.h>
#include <termios.h>
#include <sys/types.h>
#include <linux/ioctl.h>

/*
 * Ioctl definitions
 */

/* Use 'L' as magic number, means LCD */
#define LCD_IOC_MAGIC  'L'
/* Please use a different 8-bit number in your code */

#define LCD_IOCRESET    		_IO(LCD_IOC_MAGIC, 0)

#define LCD_IOC_UPDATE 			_IOW(LCD_IOC_MAGIC,  1,int)
#define LCD_IOC_BACKLIGHT		_IOW(LCD_IOC_MAGIC,  2,int)
#define LCD_IOC_AC_POWER		_IOW(LCD_IOC_MAGIC,  3,int)
#define LCD_IOC_CONTRAST		_IOW(LCD_IOC_MAGIC,  4,int)
#define LCD_IOC_STAT			_IOR(LCD_IOC_MAGIC,  5,int)
#define LCD_IOC_MAXNR 5


// Һ���Աȶ� ������Χ 0x0400-0x43f  0x0500-0x053f
#define YJ_BOTTOMLIMIT1 	0x041A
#define YJ_TOPLIMIT1 		0x043F
#define YJ_DEFAULTLIMIT1 	0x0436

#define YJ_BOTTOMLIMIT2 	0x0500
#define YJ_TOPLIMIT2 		0x053F
#define YJ_DEFAULTLIMIT2 	0x0514


extern unsigned char GUI_KeyState;
extern unsigned char OldLevel;
//��ʼ���๦�ܱ������ݱ�ʶ
extern void returnChNm(unsigned char *flag, unsigned char *ChNm);
extern int IsEqualed(char *Ret1, char *Ret2, int Len);
extern void InitNmFlag();
extern void TSSet1(TS *ts1);
extern INT16U PassPro();
extern INT16U GetNum(unsigned char *s, INT8U len, INT8U Flag);
extern void RunArrow(INT8U Arrow);
extern int returnNo(INT8U flag, INT8U *temp, int Len);
extern INT8U ScreenInput_Dnb(void);
extern INT8U ScreenInput(void);
extern void delayms(unsigned int ms);
// ��ʱ�ӳ���
extern void Show_Mainpage(void);
extern void LcdMainTask(void);
extern void LunXun_P1();
extern void Show_JZQ_P1();
extern void Show_JZQ_P2();
extern void Show_JZQ_P3();
extern int Show_JZQ_Param(INT8U SeleMenu);
extern void initMeterPare();
extern void initMeterPare_addr(unsigned char *addr);
extern void initMeterPare_clno(unsigned char clno);
extern int show_AlarmData(INT8U SeleMenu);
extern void show_meter_alarm(INT8U CaijiqiNo, INT8U MeterNo, unsigned char * MeterAdd);
extern void show_sel_alarm(INT8U i, INT8U CaijiqiNo, INT8U MeterNo, unsigned char * MeterAdd);
extern int show_Rel_Alarm(INT8U SeleMenu);
extern int Show_DNB_Param(INT8U SeleMenu);
extern void show_sel_Para(INT8U CJQ_hao, INT8U DNB_hao, unsigned char  *MeterAdd);
extern int Show_About(INT8U SeleMenu);
extern void Status_Bar(void);
extern int Modify_TxCanShu(INT8U SeleMenu);
extern int Set_TX_Para(INT8U SeleMenu);
extern void Modify_DBCanShu(INT8U CJQ_hao, INT8U DNB_hao);
extern int Modify_JZQ_dz(INT8U SeleMenu);
extern int Modify_TD_QieHuan(INT8U SeleMenu);
extern int Modify_AutoSouBiao(INT8U SeleMenu);
extern int Modify_InitMeterType(INT8U SeleMenu);
extern int SetDongJieType(INT8U SeleMenu);
extern int SetJZQIP(INT8U SeleMenu);

extern int Modify_Password(INT8U SeleMenu);
extern int SetZaiboType(INT8U SeleMenu);
extern int Modify_SjCanShu(INT8U SeleMenu);
extern int Modify_DB_para(INT8U SeleMenu);
extern void SetDataFlag97(unsigned char DI1, unsigned char DI0, unsigned char *flags);
extern void GetCurMeterData(unsigned char i, unsigned char j);//��������
extern int show_realData(INT8U CJQno, INT8U BDZno, INT8U p_flag, unsigned char *MeterAdd);
extern int Show_RealTimeData(INT8U SeleMenu);
extern int Show_RealTimeData1(INT8U SeleMenu);
extern int Show_RealTimeData2(INT8U SeleMenu);
extern int Show_allRealData(INT8U SeleMenu);
extern int Show_HisData_Day(INT8U SeleMenu);
extern int Show_HisData_Month(INT8U SeleMenu);
extern void ShowHisData(INT8U CJQno, INT8U BDZno, INT8U* temp_time, int flag, INT8U P_type, unsigned char *MeterAdd);
extern int SetHeartBeat(INT8U SeleMenu);
extern int Show_DataInit(INT8U SeleMenu); //zyz add
extern int Show_HwInit(INT8U SeleMenu); //zyz add
extern int Show_ParaInit(INT8U SeleMenu);  //zyz add
extern int getver(INT8U SeleMenu);
extern int getNoLineCjq(INT8U SeleMenu);
extern int getNoNetCjq(INT8U SeleMenu);
extern int getIp(INT8U SeleMenu);
extern int Show_TestSelf(INT8U SeleMenu); //yangdong
extern int Modify_YJ_Contrast(INT8U SeleMenu); //yangdong
extern int Update_Soft(unsigned char SeleMenu);
int contrast_value;

extern int ShowYxState(INT8U SeleMenu);//�ն����ݰ���   1 ң��״̬
extern int ShowSoe(INT8U SeleMenu);
extern int SetSIMNo(INT8U SeleMenu);

INT8U work_ethernet_delay;
INT8U work_485I_delay;
INT8U work_485II_delay;
INT8U work_485III_delay;
INT8U work_usb_delay;
INT8U work_zb_delay;
INT8U work_weihu_delay;
INT8U work_gprs_delay;
INT8U work_sdc_delay;
void Bottom_Bar(void);
INT8U Status_bar_style;
#define LunPageNum 10
F165_t f165;
#endif /* JLCDFUN_H_ */
