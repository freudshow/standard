/*
 * jLcdFun.h
 *  jLcdTask�漰������Ҫ����
 *  Created on: 2009-9-12
 *      Author: ZhuRui
 */

#include <string.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include "time.h"
#include "PrintData.h"
#include "jLcdFun.h"
#include "jLcdTask.h"
#include <ctype.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <net/if.h>
#include "ZdLoad.h"
uintptr_t *LcdBufBase;
unsigned char GUI_KeyState;
unsigned char OldLevel,metflag;
INT16U MeterNo;
INT8U LunPage;
extern int       thrdnum;
extern pid_t lcdpid;
extern int lcdfailnum;
extern INT8U MenuNums;
#define EVENCOUNT    33
struct stu ERCNAME[EVENCOUNT] =
{
{ "û���¼�" },
{ "���ݳ�ʼ���Ͱ汾���" },
{ "������ʧ��¼" },
{ "���������¼" },
{ "״̬����λ��¼" },
{ "ң����բ��¼" },
{ "������բ��¼" },
{ "�����բ��¼" },
{ "���ܱ��������" },
{ "������·�쳣" },
{ "��ѹ��·�쳣" },
{ "�����쳣" },
{ "���ܱ�ʱ�䳬��" },
{ "�������" },
{ "�ն�ͣ/�ϵ��¼�" },
{ "г��Խ�޸澯" },
{ "ֱ��ģ����Խ�޼�¼" },
{ "��ѹ/������ƽ��Խ��" },
{ "������Ͷ��������¼" },
{ "����������ü�¼" },
{ "��Ϣ��֤�����¼" },
{ "�ն˹��ϼ�¼" },
{ "�й��ܵ������Խ��" },
{ "����" },
{ "��ѹԽ�޼�¼" },
{ "����Խ�޼�¼" },
{ "���ڹ���Խ�޼�¼" },
{ "���ܱ�ʾ���½�" },
{ "���ܱ�����" },
{ "���ܱ�����" },
{ "���ܱ�ͣ��" },
{ "485����ʧ���¼�" },
{ "δ֪�¼�" },
};

void ClearThreadTimes(unsigned char ProjectID) {
	if (thrdnum>=200)//�̼߳�������200ʱ����
		thrdnum=0;
}

//��ʼ���๦�ܱ������ݱ�ʶ
void returnChNm(unsigned char *flag, unsigned char *ChNm) {
	INT16U i;
	for (i = 0; i < FlagsCount; i++) {
		if (NmFlag[i].NmFlags[0] == flag[0] && NmFlag[i].NmFlags[1] == flag[1]) {
			strcpy((char *) ChNm, (char *) NmFlag[i].ChNm);
			//fprintf( stderr, "%s-%s\n",NmFlag[i].ChNm,ChNm);
			return;
		}
		if (NmFlag[i].NmFlags[0] == 0x00 && NmFlag[i].NmFlags[1] == 0x00) {
			memset(ChNm, 0, sizeof(ChNm));
			return;
		}
	}

}
int IsEqualed(char *Ret1, char *Ret2, int Len) {
	int i, flag = 0;
	for (i = 0; i < Len; i++) {
		if (Ret1[i] != Ret2[i]) {
			flag = 1;
			break;
		}
	}
	return flag;
}
void InitNmFlag() {
	unsigned char TempBuf[60];
	memset(TempBuf,0,60);
	sprintf((char *)TempBuf,"%s/NameFlags.cfg",_CFGDIR_);
    struct timespec tsspec;
    if (clock_gettime(CLOCK_REALTIME, &tsspec)==-1)
    	printf("clock_gettime error\n\r");
    tsspec.tv_sec += 3;
	sem_timedwait(&JProgramInfo->mainData.UseFileFlg,&tsspec);
	FILE *fp = fopen((char *)TempBuf, "r");
	unsigned char temp[3], temp2[5];
	char ln[100];
	unsigned char i = 0, j = 0;
	char* token;
	while (!feof(fp)) {
		fgets(ln, 1024, fp);
		if (strncmp(ln, "begin", 5) == 0) {
			continue;
		}//����������������������ȡ
		if (strncmp(ln, "end", 3) == 0)
			break;
		if (strncmp(ln, "//", 2) == 0) {
			continue;
		}//����ע��������������
		token = strtok(ln, "=");
		j = 0;
		while (token != NULL) {
			if (j == 0) {
				memcpy(temp2, token, 4);
				ASCToBCD(temp2, 4, &temp[0]);
				NmFlag[i].NmFlags[1] = temp[0];
				NmFlag[i].NmFlags[0] = temp[1];
				//fprintf( stderr, "tttttttttt: %x-%x\n",NmFlag[i].NmFlags[0],NmFlag[i].NmFlags[1]);
			} else {
				strcpy((char *) NmFlag[i].ChNm, token);
				//fprintf( stderr, "wwwwwwwwww: %s\n",NmFlag[i].ChNm);
			}
			token = strtok(NULL, "\n");
			j++;
		}
		i++;
	}
	fclose(fp);
	fp=NULL;
	sem_post(&JProgramInfo->mainData.UseFileFlg);
}

/*******************************************************************************************************************/
/******************************************************************************************************************
 * �������ƣ�TSSet()
 * ��    �ܣ�ȡʱ��
 * ��ڲ�����
 * ���ڲ�����
 *******************************************************************************************************************/
void TSSet1(TS *ts1) {
	struct tm new_year;
	struct timespec rtime;
	new_year.tm_year = ts1->Year - 1900;
	new_year.tm_mon = ts1->Month - 1;
	new_year.tm_mday = ts1->Day;
	new_year.tm_hour = ts1->Hour;
	new_year.tm_min = ts1->Minute;
	new_year.tm_sec = ts1->Sec;

	new_year.tm_isdst = 0;
	rtime.tv_sec = mktime(&new_year);
	rtime.tv_nsec = 0;
	clock_settime(CLOCK_REALTIME, &rtime);

}
/******************************************************************************************************************
 * �������ƣ�PassPro()
 * ��    �ܣ�ȡʱ��
 * ��ڲ�����
 * ���ڲ�����
 *******************************************************************************************************************/
INT16U PassPro() {

	unsigned char i, Tpassword[3];
	unsigned int TmpPass = 0;

	memset(Tpassword, 0, 3);
	GUI_Clear(); //������
	GUI_DispStringAt((INT8U *) "��������:", 28, 64);
	memset(NowInput.buf, 0, 128);
	sprintf((char *) NowInput.buf, "%02d%02d", //16���Ƶ�BCD��
			Tpassword[0], Tpassword[1]); //����ת����Ϊ�ַ���
	i = 0;
	while (i < 4) {

		NowInput.col[i] = 64;//y��
		NowInput.row[i] = 100 + i * 8;//x��
		NowInput.set[i] = 1;
		i++;
	}
	NowInput.AllNum = 5;
	if (ScreenInput() == 1) {
		Tpassword[0] = (INT8U) GetNum(&NowInput.buf[0], 2, 1);
		Tpassword[1] = (INT8U) GetNum(&NowInput.buf[2], 2, 1);
		TmpPass = Tpassword[0] * 100 + Tpassword[1];

		if (TmpPass != PassWord) {
			PassPro();
			return 0;
		} else
			return 1;
	} else {
		return 2;
	}

}
/******************************************************************************************************************
 * �������ƣ�GetNum()
 * ��    �ܣ���ֵת��������(����ת��)
 * ��ڲ���������1��   ��Ҫ��ת��������
 ����2��   ת���Ժ�ĳ���
 ����3��   ת��������ͣ�Flag=1 ʮ�������ָ�ʽ��
 Flag=2 ʮ�����Ƹ�ʽ���ָ�ʽ��
 * ���ڲ�����
 *******************************************************************************************************************/
//INT16U GetNum(unsigned char *s, INT8U len, INT8U Flag) {
//	INT16U t, i;
//	t = 0;
//	for (i = 0; i < len; i++) {
//		if (Flag == 1)//���ָ�ʽ
//			t = (t * 10) + (s[i] - 0x30);
//		if (Flag == 2)//ʮ�����Ƹ�ʽ
//			t = (t * 16) + (s[i] - 0x30);
//	}
//	return t;
//}
INT16U GetNum(unsigned char *s, INT8U len, INT8U Flag) {//lcy2013 �滻ԭ����GetNum����
	INT16U t, i;
	t = 0;
	for (i = 0; i < len; i++) {
		if (Flag == 1) //���ָ�ʽ
			t = (t * 10) + (s[i] - 0x30);
		if (Flag == 2) //ʮ�����Ƹ�ʽ
			t = (t * 16) + (s[i] - 0x30);
		if (Flag == 3) //ʮ�����Ƹ�ʽ
				{
			if ((s[i] >= '0') && (s[i] <= '9'))
				t = (t << 4) + (s[i] - 0x30);
			if ((s[i] >= 'a') && (s[i] <= 'f'))
				t = (t << 4) + (s[i] - 87);
			if ((s[i] >= 'A') && (s[i] <= 'F'))
				t = (t << 4) + (s[i] - 55);
		}
	}
	return t;
}
/******************************************************************************************************************
 * �������ƣ�RunArrow()
 * ��    �ܣ�������ʾ���ϼ�ͷ�����ߡ��¼�ͷ�����ߡ����¼�ͷ��
 * ��ڲ�������
 * ���ڲ�������
 ******************************************************************************************************************/

void RunArrow(INT8U Arrow)

{
	unsigned char str[2];
	memset(str, 0, sizeof(str));
	switch (Arrow) {
	case 1:
		str[0] = 0x7e;
		break;
	case 2:
		str[0] = 0x7f;
		break;
	case 3:
		str[0] = 0x7d;
		break;
	default:
		break;
	}

	GUI_DispStringAt(&str[0], 151, 144);
}
int returnNo(INT8U flag, INT8U *temp, int Len) {
	int i, flag1 = 0;
	for (i = 0; i < Len; i++) {
		if (temp[i] == toupper(flag)) {
			flag1 = i;
			break;
		}
	}
	return flag1;
}

INT8U ScreenInput_Dnb(void) {
	INT8U ix, NowEdit, bufold[128];
	int choseNo;
	INT16U keysele, DelayTime;
	NowEdit = 0;
	choseNo = 0;
	DelayTime = 0;

	INT8U temp2[16] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A',
			'B', 'C', 'D', 'E', 'F' };
	INT8U temp4[2] = { 'N', 'Y' };
	INT8U temp3[39] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A',
			'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N',
			'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '-',
			'_', '.' };
	INT8U temp5[3] = { '0','3', '9' };
	INT8U temp6[3] = { '0', '1', '2' };
	INT8U temp7[3] = { '0', '1', '2' };
	for (ix = 0; ix < 32; ix++) {
		bufold[ix] = NowInput.buf[ix];
	}
	while (1) {
		ClearThreadTimes(ProjectNo);
		//��ʾ��Ҫ�޸ĵ����ݣ�ͬʱ������ʾĿǰ���ڸĶ������ݡ�
		switch (NowEdit) {
		case 0: {
			switch (NowInput.buf[NowEdit]) {
			/*case 0x31:
				GUI_DispStringAt((INT8U *) "�й���  ", 96, 16);
				break;
			case 0x32:
				GUI_DispStringAt((INT8U *) "�����ʱ�", 96, 16);
				break;*/
			case 0x33:
				GUI_DispStringAt((INT8U *) "�๦�ܱ�", 96, 16);
				break;
			/*case 0x34:
				GUI_DispStringAt((INT8U *) "�޹���  ", 96, 16);
				break;
			case 0x35:
				GUI_DispStringAt((INT8U *) "������  ", 96, 16);
				break;
			case 0x36:
				GUI_DispStringAt((INT8U *) "Ԥ���ѱ�", 96, 16);
				break;
			case 0x37:
				GUI_DispStringAt((INT8U *) "CPU���� ", 96, 16);
				break;
			case 0x38:
				GUI_DispStringAt((INT8U *) "IC����  ", 96, 16);
				break;*/
			case 0x39:
				GUI_DispStringAt((INT8U *) "�����  ", 96, 16);
				break;
			default:
				GUI_DispStringAt((INT8U *) "�ɼ���  ", 96, 16);
				break;
			}
		}
			;
			break;
		case 5: {
			switch (NowInput.buf[NowEdit]) {
			case 0x30:
				GUI_DispStringAt((INT8U *) "��У��", 96, 64);
				break;
			case 0x31:
				GUI_DispStringAt((INT8U *) "żУ��", 96, 64);
				break;
			case 0x32:
				GUI_DispStringAt((INT8U *) "��У��", 96, 64);
				break;
			default:
				break;
			}
		}
			;
			break;
		case 9: {
			switch (NowInput.buf[NowEdit]) {

			case 0x30:
				GUI_DispStringAt((INT8U *) "T645-97", 96, 96);
				break;
			case 0x31:
				GUI_DispStringAt((INT8U *) "T645-07", 96, 96);
				break;
			default:
			    GUI_DispStringAt((INT8U *) "����   ", 96, 96);
				break;
			}
		}
			;
			break;
		default:
			break;
		}
		for (ix = 0; ix < NowInput.AllNum; ix++) {
			GUI_DispCharAt(NowInput.buf[ix], NowInput.row[ix], NowInput.col[ix]);
		}

		GUI_SetTextMode(GUI_TM_REV);
		GUI_DispCharAt(NowInput.buf[NowEdit], NowInput.row[NowEdit],
				NowInput.col[NowEdit]);
		GUI_SetTextMode(GUI_TM_NORMAL);
		DelayTime++;
		Status_Bar();
		Lcmfull();
		delay(300);
		keysele = KeySeleflag;
		KeySeleflag = 0;
		if (keysele != 0) {
			DelayTime = 0;
		}
		if (DelayTime >= PageDelayTime) //��ʱ�˳�
		{
			OldLevel = 0;
			return 0;
		}

		switch (keysele) {
		//if(keysele==1) //��
		case 1: {
			switch (NowInput.set[NowEdit]) {
			case 1:
				//if(NowInput.set[NowEdit]==1)
			{
				NowInput.buf[NowEdit]++;
				if (NowInput.buf[NowEdit] > '9')
					NowInput.buf[NowEdit] = '0';
			}
				break;
			case 2:
				//if(NowInput.set[NowEdit]==2)
			{
				choseNo = returnNo(NowInput.buf[NowEdit], temp2, 16);
				if (choseNo < 15) {
					choseNo++;
					NowInput.buf[NowEdit] = temp2[choseNo];
				} else {
					choseNo = 0;
					NowInput.buf[NowEdit] = temp2[choseNo];
				}

			}
				break;
			case 3: {
				choseNo = returnNo(NowInput.buf[NowEdit], temp3, 39);
				if (choseNo < 38) {
					choseNo++;
					NowInput.buf[NowEdit] = temp3[choseNo];
				} else {
					choseNo = 0;
					NowInput.buf[NowEdit] = temp3[choseNo];
				}
			}
				break;
			case 4:
				//if(NowInput.set[NowEdit]==2)
			{
				choseNo = returnNo(NowInput.buf[NowEdit], temp4, 2);
				if (choseNo < 1) {
					choseNo++;
					NowInput.buf[NowEdit] = temp4[choseNo];
				} else {
					choseNo = 0;
					NowInput.buf[NowEdit] = temp4[choseNo];
				}
			}
				break;
			case 5:
				//if(NowInput.set[NowEdit]==2)
			{
				choseNo = returnNo(NowInput.buf[NowEdit], temp5, 3);
				if (choseNo < 2) {
					choseNo++;
					NowInput.buf[NowEdit] = temp5[choseNo];
				} else {
					choseNo = 0;
					NowInput.buf[NowEdit] = temp5[choseNo];
				}
			}
				break;
			case 6:
				//if(NowInput.set[NowEdit]==2)
			{
				choseNo = returnNo(NowInput.buf[NowEdit], temp6, 3);
				if (choseNo < 2) {
					choseNo++;
					NowInput.buf[NowEdit] = temp6[choseNo];
				} else {
					choseNo = 0;
					NowInput.buf[NowEdit] = temp6[choseNo];
				}
			}
				break;
			case 7:
				//if(NowInput.set[NowEdit]==2)
			{
				choseNo = returnNo(NowInput.buf[NowEdit], temp7, 3);
				if (choseNo < 2) {
					choseNo++;
					NowInput.buf[NowEdit] = temp7[choseNo];
				} else {
					choseNo = 0;
					NowInput.buf[NowEdit] = temp7[choseNo];
				}
			}
				break;
			default:
				break;
			}
		}
			break;
			//if(keysele==2) //��
		case 2: {
			switch (NowInput.set[NowEdit]) {
			case 1:
				//if(NowInput.set[NowEdit]==1)
			{
				if (NowInput.buf[NowEdit] != '0')
					NowInput.buf[NowEdit]--;
				else
					NowInput.buf[NowEdit] = '9';
			}
				break;
			case 2: {
				choseNo = returnNo(NowInput.buf[NowEdit], temp2, 16);
				if (choseNo > 0) {
					choseNo--;
					NowInput.buf[NowEdit] = temp2[choseNo];
				} else {
					choseNo = 15;
					NowInput.buf[NowEdit] = temp2[choseNo];
				}
			}
				break;
			case 3: {
				choseNo = returnNo(NowInput.buf[NowEdit], temp3, 39);
				if (NowInput.buf[NowEdit] != temp3[0]) {
					choseNo--;
					NowInput.buf[NowEdit] = temp3[choseNo];
				} else {
					choseNo = 38;
					NowInput.buf[NowEdit] = temp3[choseNo];
				}
			}
				break;
			case 4: {
				choseNo = returnNo(NowInput.buf[NowEdit], temp4, 2);
				if (NowInput.buf[NowEdit] != temp4[0]) {
					choseNo--;
					NowInput.buf[NowEdit] = temp4[choseNo];
				} else {
					choseNo = 1;
					NowInput.buf[NowEdit] = temp4[choseNo];
				}
			}
				break;
			case 5: {
				choseNo = returnNo(NowInput.buf[NowEdit], temp5, 3);
				if (NowInput.buf[NowEdit] != temp5[0]) {
					choseNo--;
					NowInput.buf[NowEdit] = temp5[choseNo];
				} else {
					choseNo = 2;
					NowInput.buf[NowEdit] = temp5[choseNo];
				}
			}
				break;
			case 6: {
				choseNo = returnNo(NowInput.buf[NowEdit], temp6, 3);
				if (NowInput.buf[NowEdit] != temp6[0]) {
					choseNo--;
					NowInput.buf[NowEdit] = temp6[choseNo];
				} else {
					choseNo = 2;
					NowInput.buf[NowEdit] = temp6[choseNo];
				}
			}
				break;
			case 7: {
				choseNo = returnNo(NowInput.buf[NowEdit], temp7, 3);
				if (NowInput.buf[NowEdit] != temp7[0]) {
					choseNo--;
					NowInput.buf[NowEdit] = temp7[choseNo];
				} else {
					choseNo = 2;
					NowInput.buf[NowEdit] = temp7[choseNo];
				}
			}
				break;

			default:
				break;
			}
		}
			break;
		case 3:
			//if(keysele==3) //��
		{
			if (NowEdit != 0) {
				NowEdit--;
				choseNo = 0;
			}
		}
			break;
		case 4:
			//if(keysele==4) //��
		{
			if (NowEdit != NowInput.AllNum - 2) {
				NowEdit++;
				choseNo = 0;
			}
		}
			break;
		case 5:
			//if(keysele==5) //ȷ��
		{
			GUI_DispCharAt(NowInput.buf[NowEdit], NowInput.row[NowEdit],
					NowInput.col[NowEdit]);
			//OSSemPost(FlushSem);
			Lcmfull();

			for (ix = 0; ix < NowInput.AllNum; ix++) {
				if (bufold[ix] != NowInput.buf[ix])
					return 1;
			}
			return 0;
		}
			break;
		case 6:
			//if(keysele==6) //ȡ��
		{
				OldLevel = 0;
			return 0;
		}
			break;
		default:
			break;
		}
	}
	return 0;
}
/******************************************************************************************************************
 * �������ƣ�ScreenInput()
 * ��    �ܣ�Һ������������õĺ���
 * ��ڲ�������
 * ���ڲ���������1��   ��Ҫ���õ��������ַ��������ı�
 ����0��   ��Ҫ���õ��������ַ���û�з����ı�
 ����0��   ��ʱ�ް������Զ��˳�
 *******************************************************************************************************************/
INT8U ScreenInput(void)
{
	INT8U ix, NowEdit, bufold[128];
	int choseNo;
	INT16U keysele, DelayTime;
	NowEdit = 0;
	choseNo = 0;
	DelayTime = 0;

	INT8U temp2[16] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A',
			'B', 'C', 'D', 'E', 'F' };
	INT8U temp4[2] = { 'N', 'Y' };
	INT8U temp5[2] = { 'H', 'D' };
	INT8U temp3[39] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A',
			'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N',
			'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '-',
			'_', '.' };
	for (ix = 0; ix < 32; ix++) {
		bufold[ix] = NowInput.buf[ix];
	}
	while (1) {
		ClearThreadTimes(ProjectNo);
		//��ʾ��Ҫ�޸ĵ����ݣ�ͬʱ������ʾĿǰ���ڸĶ������ݡ�
		for (ix = 0; ix < NowInput.AllNum; ix++) {
			GUI_DispCharAt(NowInput.buf[ix], NowInput.row[ix], NowInput.col[ix]);
		}

		GUI_SetTextMode(GUI_TM_REV);
		GUI_DispCharAt(NowInput.buf[NowEdit], NowInput.row[NowEdit],
				NowInput.col[NowEdit]);
		GUI_SetTextMode(GUI_TM_NORMAL);
		DelayTime++;
		Status_Bar();
		Lcmfull();
		delay(300);
		keysele = KeySeleflag;
		KeySeleflag = 0;
		if (keysele != 0) {
			DelayTime = 0;
		}
		if (DelayTime >= PageDelayTime) //��ʱ�˳�
		{
			return 0;
		}

		switch (keysele) {
		//if(keysele==1) //��
		case 1: {
			switch (NowInput.set[NowEdit]) {
			case 1:
				//if(NowInput.set[NowEdit]==1)
			{
				NowInput.buf[NowEdit]++;
				if (NowInput.buf[NowEdit] > '9')
					NowInput.buf[NowEdit] = '0';
			}
				break;
			case 2:
				//if(NowInput.set[NowEdit]==2)
			{
				choseNo = returnNo(NowInput.buf[NowEdit], temp2, 16);
				if (choseNo < 15) {
					choseNo++;
					NowInput.buf[NowEdit] = temp2[choseNo];
				} else {
					choseNo = 0;
					NowInput.buf[NowEdit] = temp2[choseNo];
				}

			}
				break;
			case 3: {
				choseNo = returnNo(NowInput.buf[NowEdit], temp3, 39);
				if (choseNo < 38) {
					choseNo++;
					NowInput.buf[NowEdit] = temp3[choseNo];
				} else {
					choseNo = 0;
					NowInput.buf[NowEdit] = temp3[choseNo];
				}
			}
				break;
			case 4:
				//if(NowInput.set[NowEdit]==2)
			{
				choseNo = returnNo(NowInput.buf[NowEdit], temp4, 2);
				if (choseNo < 1) {
					choseNo++;
					NowInput.buf[NowEdit] = temp4[choseNo];
				} else {
					choseNo = 0;
					NowInput.buf[NowEdit] = temp4[choseNo];
				}
			}
				break;
			case 5:
				//if(NowInput.set[NowEdit]==2)
			{
				choseNo = returnNo(NowInput.buf[NowEdit], temp5, 2);
				if (choseNo < 1) {
					choseNo++;
					NowInput.buf[NowEdit] = temp5[choseNo];
				} else {
					choseNo = 0;
					NowInput.buf[NowEdit] = temp5[choseNo];
				}
			}
				break;

			default:
				break;
			}
		}
			break;
			//if(keysele==2) //��
		case 2: {
			switch (NowInput.set[NowEdit]) {
			case 1:
				//if(NowInput.set[NowEdit]==1)
			{
				if (NowInput.buf[NowEdit] != '0')
					NowInput.buf[NowEdit]--;
				else
					NowInput.buf[NowEdit] = '9';
			}
				break;
			case 2: {
				choseNo = returnNo(NowInput.buf[NowEdit], temp2, 16);
				if (choseNo > 0) {
					choseNo--;
					NowInput.buf[NowEdit] = temp2[choseNo];
				} else {
					choseNo = 15;
					NowInput.buf[NowEdit] = temp2[choseNo];
				}
			}
				break;
			case 3: {
				choseNo = returnNo(NowInput.buf[NowEdit], temp3, 39);
				if (NowInput.buf[NowEdit] != temp3[0]) {
					choseNo--;
					NowInput.buf[NowEdit] = temp3[choseNo];
				} else {
					choseNo = 38;
					NowInput.buf[NowEdit] = temp3[choseNo];
				}
			}
				break;
			case 4: {
				choseNo = returnNo(NowInput.buf[NowEdit], temp4, 2);
				if (NowInput.buf[NowEdit] != temp4[0]) {
					choseNo--;
					NowInput.buf[NowEdit] = temp4[choseNo];
				} else {
					choseNo = 1;
					NowInput.buf[NowEdit] = temp4[choseNo];
				}
			}
				break;
			case 5: {
				choseNo = returnNo(NowInput.buf[NowEdit], temp5, 2);
				if (NowInput.buf[NowEdit] != temp5[0]) {
					choseNo--;
					NowInput.buf[NowEdit] = temp5[choseNo];
				} else {
					choseNo = 1;
					NowInput.buf[NowEdit] = temp5[choseNo];
				}
			}
				break;
			default:
				break;
			}
		}
			break;
		case 3:
			//if(keysele==3) //��
		{
			if (NowEdit != 0) {
				NowEdit--;
				choseNo = 0;
			}
		}
			break;
		case 4:
			//if(keysele==4) //��
		{
			if (NowEdit != NowInput.AllNum - 2) {
				NowEdit++;
				choseNo = 0;
			}
		}
			break;
		case 5:
			//if(keysele==5) //ȷ��
		{
			GUI_DispCharAt(NowInput.buf[NowEdit], NowInput.row[NowEdit],
					NowInput.col[NowEdit]);
			//OSSemPost(FlushSem);
			Lcmfull();

			for (ix = 0; ix < NowInput.AllNum; ix++) {
				if (bufold[ix] != NowInput.buf[ix])
					return 1;
			}
			return 0;
		}
			break;
		case 6:
			//if(keysele==6) //ȡ��
		{
			return 2;
		}
			break;
		default:
			break;
		}
	}
	return 0;
}
/******************************************************************************************************************
 * �������ƣ�
 * ��    �ܣ���ʱ����
 * ��ڲ�������
 * ���ڲ�������
 *******************************************************************************************************************/
void delayms(unsigned int ms)
// ��ʱ�ӳ���
{
	unsigned int i;
	while (ms--) {
		for (i = 0; i < 120; i++)
			;
	}
}


void InitPage()
{
	INT8U i=0;
	TS ts;
	for (i=0;i<10;i++)
	{
		TSGet(&ts);
		GUI_Clear();
		Status_Bar();//״̬��
		GUI_DispStringAt((INT8U *) "��ѹ����������", 24, 32);
		GUI_DispDecAt(ts.Year, 40, 64, 4);
		GUI_DispStringAt((INT8U *) "-", 72, 64);
		GUI_DispDecAt(ts.Month, 80, 64, 2);
		GUI_DispStringAt((INT8U *) "-", 96, 64);
		GUI_DispDecAt(ts.Day, 104, 64, 2);
		GUI_DispDecAt(ts.Hour, 48, 88, 2);
		GUI_DispStringAt((INT8U *) ":", 64, 88);
		GUI_DispDecAt(ts.Minute, 72, 88, 2);
		GUI_DispStringAt((INT8U *) ":", 88, 88);
		GUI_DispDecAt(ts.Sec, 96, 88, 2);
		if (i>7)
			GUI_DispStringAt((INT8U *) "�ն����ڳ���...", 0, 144);
		else if (i>3)
			GUI_DispStringAt((INT8U *) "�ն����ڳ���..", 0, 144);
		else
			GUI_DispStringAt((INT8U *) "�ն����ڳ���.", 0, 144);
		Lcmfull();//д��
		delay(200);
	}
}


void SetLcdFun(int ms)
{
#ifdef __linux__
	int signum;
	union sigval mysigval;
	signum=SIGUSR1;
	//pid=find_pid_by_name("lcd_drv");
	mysigval.sival_int=ms;//Ҫ���͵��ź�ֵ
	if(sigqueue(lcdpid,signum,mysigval)==-1)
	{
		lcdfailnum++;
		printf("send to pid1 %d error\n",lcdpid);
	}else lcdfailnum=0;
#else
	msg.messageType = ms;
	if (MsgSend(coid, &msg, sizeof(msg) + 1, &msg, sizeof(msg)) != 0) {
		lcdfailnum++;
		perror("LED Message Error!\n");
	}else lcdfailnum=0;
#endif
}

void InitLiangdu()
{
	contrast_value = 0;
	int fd=-1,fdyj=-1;
	fd=open("/nand/bin/yejingliang.info",O_RDWR|O_CREAT);
	if(fd>0)
	{
		read(fd,&contrast_value,sizeof(int));
		//printf("\ncontrast_value = %d\n", contrast_value);
		if( contrast_value<YJ_BOTTOMLIMIT1 || (contrast_value>YJ_TOPLIMIT1 && contrast_value<YJ_BOTTOMLIMIT2) )
			contrast_value=YJ_DEFAULTLIMIT1;
		if( contrast_value>YJ_TOPLIMIT2 )
			contrast_value=YJ_DEFAULTLIMIT2;
	}else{
		contrast_value=YJ_DEFAULTLIMIT1;
	}
	close(fd);
	if((fdyj = open("/dev/fb0", O_RDWR | O_NDELAY)) >0)
		ioctl(fdyj,LCD_IOC_CONTRAST,&contrast_value);
	close(fdyj);
}
/******************************************************************************************************************
 * �������ƣ�LcdMainTask()
 * ��    �ܣ����ݰ�����ʾ��ṹ�Ĳ˵���ִ����صĺ���
 * ��ڲ�������
 * ���ڲ�������
 *******************************************************************************************************************/
void LcdMainTask(void) {
	INT8U j, k, passtmp[4],pwon,pwoff;
	unsigned int LunXianPage;
	INT16U DelayTime,num2;
	k = 0;
	int data=1,fd=-1;
	memset(passtmp, 0, 4);
	passtmp[1] = 0;
	passtmp[0] = 0;
	DelayTime = 0;
	MenuSele = 0;
	TongDaoLeiXing = 0;//0ΪGPRS,ֵΪ1ΪPSTN,ֵΪ2ΪCDMA,
	//GprsCSQ = 25;
	GprsTXFS = 1;//1ΪGPRS,ֵΪ2ΪPSTN,ֵΪ3ΪCDMA,��TongDaoLeiXing�е��ظ�
	/////////////
	OldLevel = 10;//��ʼ��ʱ��OldLevel ������0��������MenuSele��Ⱦͻ���!
	///////////
	LcdK = 0;
	LunXianPage = 0x11;//���Ե�ҳ���0x11��ʼ
	LunPage=0;
	//��ʾ��������
	//LcdBufBase = mmap_device_memory(0, 4096, PROT_READ | PROT_WRITE | PROT_NOCACHE, 0, 0x200000);
	//LcdBuf = (INT8U *) LcdBufBase; //old
	//OpenLcdMem();
	Lcmfull();
	//delay(1000);
	initMeterPare();
	InitPage();
	InitLiangdu();//yejingliang.info
	LunXianCount = LunXianTime;
	MeterNo = 0;
	metflag=0;
	pwon=0;
	pwoff=0;
	num2=0;
#if 0
	while (1) {
		ClearThreadTimes(ProjectNo);
		//Status_Bar();
		InitPage();
		//Lcmfull();
		printf("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n\r");
		delay(1000);

	}
#endif
	GUI_Clear();
	Status_bar_style=0; //ydlcd
	while (1) {
		if(Menu[MenuSele].level == 4 ||Menu[MenuSele].level == 10)//ydlcd
			Status_bar_style=1;
		else
			Status_bar_style=0;
		ClearThreadTimes(ProjectNo);
		GUI_KeyState = KeySeleflag;
		num2++;
		if (num2>100)
		{
			//SdPrint("KeySeleflag=%d\n\r",KeySeleflag);
			num2=0;
		}
		KeySeleflag = 0;
		if ((JProgramInfo->PowerOFFMessage == 1) && (pwoff==0))
		{
			//SetLcdFun(AC_POWER_OFF);
			printf("\n JProgramInfo->PowerOFFMessage =%d  pwoff=%d \n",JProgramInfo->PowerOFFMessage,pwoff);
//			if((fd = open("/dev/fb0", O_RDWR | O_NDELAY)) >0)
//				ioctl(fd,AC_POWER_OFF,&data);
//			close(fd);
			pwoff=1;
		}
		if (JProgramInfo->PowerOFFMessage == 0)
		{
			pwoff=0;
		}
		if (JProgramInfo->PowerOnMessage == 0)
		{
			pwon=0;
		}
		if((JProgramInfo->PowerOnMessage == 1) && (pwon==0))
		{
			printf("\n JProgramInfo->PowerOnMessage =%d  pwon=%d \n",JProgramInfo->PowerOnMessage,pwon);
			//SetLcdFun(AC_POWER_ON);
			if((fd = open("/dev/fb0", O_RDWR | O_NDELAY)) >0)
			{
				//printf("\nfd ====%d\n",fd);
				ioctl(fd,LCD_IOC_AC_POWER,&data);
			}
			InitLiangdu();
			close(fd);
			delay(100);
			//SetLcdFun(UPDATE_SCREEN);
//			if((fd = open("/dev/fb0", O_RDWR | O_NDELAY)) >0)
//				ioctl(fd,UPDATE_SCREEN,&data);
//			close(fd);
			pwon=1;
		}
		else
		{
			delay(100);
		}
		/***************************��������********************************/
		switch (GUI_KeyState) {
		case 0://���û�а������¾� LunXianCount ��1
		{
			if (LunXunFlag == 1) {
				LunXianCount++;
				//printf( "LunXianCount = %d\n\r", LunXianCount );
				if (LunXianCount >= LunXianTime) {
					GUI_Clear();
					MenuSele=0;
					if (MeterNo >= meterCount)
					{
						MeterNo=0;
					}
				//	printf( "\n LunPage = %d ------1\n\r", LunPage );
					LunXunDataTianJin(LunPage);
					//LunXunData(MeterNo);
					metflag=1;
					if (TempMeterPara[MeterNo].p_flag==0)
					{
						LunXianCount = LunXianTime + LunXianPageTime;
					}
					if (LunXianCount == (LunXianTime + LunXianPageTime)) {
						LunXianCount = LunXianTime;
						metflag=0;
						LunPage++;
						if (LunPage>=LunPageNum)
						{
							LunPage=0;
							if (MeterNo == meterCount - 1) {
								MeterNo = 0;
							} else {
								MeterNo++;
							}
						}
					}
				}
			} else {
				LunXianCount++;
				//printf( "LunXianCount222= %d\n\r", LunXianCount );
				if (LunXianCount >= LunXianTime) {
					GUI_Clear();
					LunXianCount = 0;
					k = 0xff;
					OldLevel = 20;
					MenuSele = 0;
					//GUI_DispStringAt((INT8U *)"�޿�������",48,64);
				}
			}
		}
			break;
		case 1:
			//if(GUI_KeyState==1)//�ϼ�
		{
			if (LunXianCount < LunXianTime) {
				LunXianCount = 0;
				MenuSele = Menu[MenuSele].U;
				//   printf( "shang= %d\n\r", MenuSele);
			}
		}//�ϼ�����
			break;
		case 2:
			//if(GUI_KeyState==2)//�¼�
		{
			if (LunXianCount < LunXianTime) {

				LunXianCount = 0;
				MenuSele = Menu[MenuSele].D;

			}
		}//�¼�����
			break;
		case 3:
			//if(GUI_KeyState==3)//���
		{
			if (LunXianCount < LunXianTime) {
				LunXianCount = 0;
				if (Menu[MenuSele].L == 99) {
					LunXianCount = PageDelayTime*2;
					Menu[MenuSele].Command(MenuSele);
					k = 0xff;
				} else if (Menu[MenuSele].L != 77)
					MenuSele = Menu[MenuSele].L;

			}
		}//�������
			break;
		case 4:
			//if(GUI_KeyState==4)//�Ҽ�
		{
			if (LunXianCount < LunXianTime) {

				LunXianCount = 0;
				if (Menu[MenuSele].R >= 99) {
					//Menu[MenuSele].Command(MenuSele);
					k = 0xff;
				} else if (Menu[MenuSele].R != 77) {
					MenuSele = Menu[MenuSele].R;
				}
			}
		}//�Ҽ�����
			break;
		case 5:
			//if(GUI_KeyState==5)//ȷ��
		{
			if (LunXianCount < LunXianTime) {
				LunXianCount = 0;
				if (Menu[MenuSele].OK >= 99) {
					Menu[MenuSele].Command(MenuSele);
					k = 0xff;
				} else if (Menu[MenuSele].OK != 77) {
					MenuSele = Menu[MenuSele].OK; //OldLevel=20;

					if (MenuSele == 33) {
						if (PassPro() != 1)
							MenuSele = 8;
						OldLevel = 20;
						k = 0xff;
					}
					if (MenuSele == 41) {
						if (PassPro() != 1)
							MenuSele = 9;
						OldLevel = 20;
						k = 0xff;
					}
					if (MenuSele == 45) {
						if (PassPro() != 1)
							MenuSele = 10;
						OldLevel = 20;
						k = 0xff;
					}

					switch (MenuSele) {
					case 6:
						ChakanMeterNum = 0;
						break;
					case 39:
						ChakanMeterSetNum = 0;//�����޸�ʱ��Ҫ�޸ĵı����ChakanMeterSetNum����
						break;
					default:
						break;
					}
				}
			}

		}//ȷ��������
			break;
		case 6:
			//if(GUI_KeyState==6)//ȡ��
		{
			if (LunXianCount >= LunXianTime) {
				LunXianCount = 0;
				k = 0xff;
				OldLevel = 20;
				MenuSele = 0;
			}//���������ҳ���ڰ�ȷ������������
			else {

				LunXianCount = 0;
				if (Menu[MenuSele].ESC >= 99) {
					Menu[MenuSele].Command(MenuSele);
					k = 0xff;
				} else {
					if (Menu[MenuSele].ESC != 77)
						MenuSele = Menu[MenuSele].ESC;
				}

			}

		} //ȡ��������
			break;
		default:
			break;

		}
		/*************************���ϰ�����������*********************************/
		/*************************����Ϊ��ʾ���濪ʼ*********************************/
		//GUI_KeyState=0;

		if ((k != MenuSele)) {

			//printf("LCD  change!!!\n");
			//for(j=0;j<(sizeof(Menu)/52);j++)

			if (Menu[OldLevel].level != Menu[MenuSele].level) {
				GUI_Clear();
				// printf( "k= %d\n\r", k );
				//  printf( "MenuSele= %d\n\r", MenuSele );

				for (j = 0; j < MenuNums; j++) {

					if (Menu[j].level == Menu[MenuSele].level) {

						GUI_DispStringAt((INT8U *) Menu[j].Str, Menu[j].row,
								Menu[j].col);

					}
				}

			} else {

				if (/*Menu[MenuSele].level != 11 && Menu[MenuSele].level != 12//lcy2013
				&& */Menu[MenuSele].level != 13 && Menu[MenuSele].level!= 14)
					GUI_DispStringAt((INT8U *) Menu[OldLevel].Str,
							Menu[OldLevel].row, Menu[OldLevel].col);

			}

			switch (Menu[MenuSele].level) {

			default:
				GUI_SetTextMode(GUI_TM_REV);
				GUI_DispStringAt((INT8U *) Menu[MenuSele].Str,
						Menu[MenuSele].row, Menu[MenuSele].col);
				GUI_SetTextMode(GUI_TM_NORMAL);
				break;

			}
			k = MenuSele;

		}

		OldLevel = MenuSele;
		Status_Bar();//״̬��
		if ((MenuSele>=9) && (MenuSele<=13))
		{
			GUI_DispStringAt((INT8U *) "�ź�ǿ��->", 0, 144);
			GUI_DispDecAt(JDataFileInfo->DayRunTj.GprsCSQ, 80, 144, 2);
		}
		Lcmfull();//д��

	}

}
void LunXun_P1() {

	GUI_DispStringAt((INT8U *) "����״̬", 48, 16);
	initMeterPare();
	GUI_DispStringAt((INT8U *) "�ɼ�����Ŀ:", 16, 48);
	GUI_DispDecAt(CaijiqiCount, 112, 48, 3);
	GUI_DispStringAt((INT8U *) "���ܱ���Ŀ:", 16, 80);
	GUI_DispDecAt(meterCount, 112, 80, 2);
	GUI_DispStringAt((INT8U *) "�澯״̬��:", 16, 112);
	if (JProgramInfo->stateflags.ErcFlg >= 1)
		GUI_DispStringAt((INT8U *) "��", 112, 112);
	else
		GUI_DispStringAt((INT8U *) "��", 112, 112);
}
/******************************************************************************************************************
 * �������ƣ�Show_JZQ_P1()
 * ��    �ܣ���ʾͨѶIP��ַ�Ͷ˿ڣ��˿����ͣ�����IP��ַ�Ͷ˿ڣ�APN
 * ��ڲ�������
 * ���ڲ�������
 *******************************************************************************************************************/
void Show_JZQ_P1()
{
	INT8U modetype;
	unsigned char TempBuf[32];
	if (LunXianCount < LunXianTime)
		RunArrow(2);
	//////////////////////////////////////////////////////////
	GUI_DispStringAt((INT8U *) "��IP��˿�", 0, 16);
	GUI_DispDecAt(JParamInfo3761->group1.f3.IP[3], 0, 32, 3);
	GUI_DispCharAt('.', 24, 32);
	GUI_DispDecAt(JParamInfo3761->group1.f3.IP[2], 28, 32, 3);
	GUI_DispCharAt('.', 52, 32);
	GUI_DispDecAt(JParamInfo3761->group1.f3.IP[1], 56, 32, 3);
	GUI_DispCharAt('.', 80, 32);
	GUI_DispDecAt(JParamInfo3761->group1.f3.IP[0], 84, 32, 3);
	GUI_DispStringAt((INT8U *) ":", 112, 32);
	memset(TempBuf, 0, 32);
	sprintf((char *) TempBuf, "%05d", ((JParamInfo3761->group1.f3.PortAddress[1] << 8)
			+ JParamInfo3761->group1.f3.PortAddress[0])); //����ת����Ϊ�ַ���
	GUI_DispStringAt(TempBuf, 120, 32);
	////////////////////////////////////////////////////////////////
	GUI_DispStringAt((INT8U *) "��IP��˿�", 0, 48);
	GUI_DispDecAt(JParamInfo3761->group1.f3.IP1[3], 0, 64, 3);
	GUI_DispCharAt('.', 24, 64);
	GUI_DispDecAt(JParamInfo3761->group1.f3.IP1[2], 28, 64, 3);
	GUI_DispCharAt('.', 52, 64);
	GUI_DispDecAt(JParamInfo3761->group1.f3.IP1[1], 56, 64, 3);
	GUI_DispCharAt('.', 80, 64);
	GUI_DispDecAt(JParamInfo3761->group1.f3.IP1[0], 84, 64, 3);
	GUI_DispStringAt((INT8U *) ":", 112, 64);
	memset(TempBuf, 0, 32);
	sprintf((char *) TempBuf, "%05d", (JParamInfo3761->group1.f3.PortAddress1[1] << 8)
			+ JParamInfo3761->group1.f3.PortAddress1[0]); //����ת����Ϊ�ַ���
	GUI_DispStringAt(TempBuf, 120, 64);

	///////////////////////////////////////////////////////////////////////
	GUI_DispStringAt((INT8U *) "�����APN", 0, 80);
	unsigned char temp[16];
	memset(temp, 0x00, 16);
	int i = 0,j=0;
	for (i = 0; i < 16; i++) {
		if ((JParamInfo3761->group1.f3.APN[15 - i] != 0xff)&&(JParamInfo3761->group1.f3.APN[15 - i] != 0x00))
			temp[j++] = JParamInfo3761->group1.f3.APN[15 - i];
	}
	GUI_DispStringAt(temp, 0, 96);
	////////////////////////////////////////////////////////////////
	modetype = (JParamInfo3761->group1.f8.Type & 0b00110000)>>4;
	if (modetype == 0)
		GUI_DispStringAt((INT8U *) "ͨ�����ͣ����ģʽ", 0, 112);
	else if (modetype == 1)
		GUI_DispStringAt((INT8U *) "ͨ�����ͣ��ͻ�ģʽ", 0, 112);
	else
		GUI_DispStringAt((INT8U *) "ͨ�����ͣ�����ģʽ", 0, 112);}
/******************************************************************************************************************
 * �������ƣ�Show_JZQ_P2()
 * ��    �ܣ������룬��������ַ����λ��־���澯����
 * ��ڲ�������
 * ���ڲ�������
 *******************************************************************************************************************/
void Show_JZQ_P2() {
	unsigned char TempBuf[16];
	unsigned char areaid[2], JZQarea[2], tempareaId[6], temparea[6],areatmp[50];
	int areaaddr;
	areaid[0] = JConfigInfo->jzqpara.Area_8016.JZ_XingZhuangQuHaoMa[0];
	areaid[1] = JConfigInfo->jzqpara.Area_8016.JZ_XingZhuangQuHaoMa[1];
	JZQarea[0] = JConfigInfo->jzqpara.Address_8017.JZ_di_zhi[0];
	JZQarea[1] = JConfigInfo->jzqpara.Address_8017.JZ_di_zhi[1];
	areaaddr = (JZQarea[0]<<8) + JZQarea[1];
	memset(areatmp,0,50);
	BCDToASC(areaid, 2, tempareaId);
	BCDToASC(JZQarea, 2, temparea);
	if (LunXianCount < LunXianTime)
		RunArrow(3);
	sprintf((char *)areatmp,"%s(%05d)",temparea,areaaddr);
	GUI_DispStringAt((INT8U *) "������", 56, 16);
	GUI_DispStringAt(tempareaId, 64, 32);
	GUI_DispStringAt((INT8U *) "��������ַ", 40, 48);
	GUI_DispStringAt(areatmp, 36, 64);
	GUI_DispStringAt((INT8U *) "��������", 48, 80);
	memset(TempBuf, 0, 16);
	sprintf((char *) TempBuf, "%02d", JParamInfo3761->group1.f1.HeartInterval);
	GUI_DispStringAt(TempBuf, 72, 96);

}
/******************************************************************************************************************
 * �������ƣ�Show_JZQ_P3()
 * ��    �ܣ�������ʱ��(�롢�֡�ʱ���ա��¡���)����ʱ((�롢�֡�ʱ���ա��¡���))
 * ��ڲ�������
 * ���ڲ�������
 *******************************************************************************************************************/
void Show_JZQ_P3() {
	TS ts;
	if (LunXianCount < LunXianTime)
		RunArrow(1);

	GUI_DispStringAt((INT8U *) "������ʱ��", 32, 32);
	GUI_DispStringAt((INT8U *) "��", 48, 48);
	GUI_DispStringAt((INT8U *) "��", 80, 48);
	GUI_DispStringAt((INT8U *) "��", 112, 48);
	GUI_DispStringAt((INT8U *) "ʱ", 48, 64);
	GUI_DispStringAt((INT8U *) "��", 80, 64);
	GUI_DispStringAt((INT8U *) "��", 112, 64);
	TSGet(&ts);
	GUI_DispDecAt(ts.Year, 16, 48, 4);
	GUI_DispDecAt(ts.Month, 64, 48, 2);
	GUI_DispDecAt(ts.Day, 96, 48, 2);
	GUI_DispDecAt(ts.Hour, 32, 64, 2);
	GUI_DispDecAt(ts.Minute, 64, 64, 2);
	GUI_DispDecAt(ts.Sec, 96, 64, 2);

}

/******************************************************************************************************************
 * �������ƣ�Show_JZQ_Para() ���ڵ������˵�
 * ��    �ܣ�����ʾ����������������
 * ����������ͨѶIP��ַ�Ͷ˿ڣ��˿����ͣ�����IP��ַ�Ͷ˿ڣ�APN��
 *          �����룬��������ַ����λ��־�������λ��
 *          �����λ��������ʱ��(�롢�֡�ʱ���ա��¡���)����ʱ((�롢�֡�ʱ���ա��¡���))���澯���Σ�
 *          �ж�ʱ��������������
 * ��ڲ�������
 * ���ڲ�������
 ******************************************************************************************************************/
int Show_JZQ_Param(INT8U SeleMenu) {
	unsigned int DelayTime;
	INT8U keysele, i, CLpointNo;
	CLpointNo = 100;
	i = 0;
	DelayTime = 0;
	while (1) {
		ClearThreadTimes(ProjectNo);
		delay(100);
		GUI_Clear();
		Status_Bar();//Ȼ��״̬����Ȼ������ʾ�����ı��ţ����ǵ�һ���˵�����
		switch (i) {
		//ͨѶIP��ַ�Ͷ˿ڣ��˿����ͣ�����IP��ַ�Ͷ˿ڣ�APN
		case 0:
			Show_JZQ_P1();
			break;
			//�����룬��������ַ����λ��־���澯����
		case 1:
			Show_JZQ_P2();
			break;
			//������ʱ��(�롢�֡�ʱ���ա��¡���)����ʱ((�롢�֡�ʱ���ա��¡���))
		case 2:
			Show_JZQ_P3();
			break;
			//�����λ�������λ���ж�ʱ��������������
			//case 3: Show_JZQ_P4();break;
		default:
			break;
		}
		//���������������ڱ���ַ��������ʾ
		Lcmfull();
		keysele = KeySeleflag;
		KeySeleflag = 0;
		if (DelayTime >= PageDelayTime) {
			OldLevel = 0;
			return 0;
		}
		switch (keysele) {
		case 0:
			DelayTime++;
			break;
		case 1:
			if (i == 0)
				i = 0;
			else
				i = (i - 1) % 3;
			DelayTime = 0;
			break;
		case 2:
			if (i == 2)
				i = 2;
			else
				i = (i + 1) % 3;
			DelayTime = 0;
			break;
		case 3:
			DelayTime = 0;
			break;
		case 4:
			DelayTime = 0;
			break;
		case 5:
			DelayTime = 0;
			break;
		case 6:
			OldLevel = 0;
			return 0;
			break;
		default:
			break;
		}

	}
	return 0;
}
/******************************************************************************************************************
 * �������ƣ�initMeterPare() ���ڵ������˵�
 * ��    �ܣ�����ʾ�������ܱ�������
 * ����������ͨ��ѡ����ܱ���ѡ��Ҫ�鿴�ĵ��ܱ��Ĳ���
 * ��ڲ�������
 * ���ڲ�������
 ******************************************************************************************************************/
void initMeterPare() {
	INT16U i, k;
	meterCount = 0;
	CaijiqiCount = 0;
	memset(TempMeterPara, 0, sizeof(TempMeterPara));
	TempMeterPara[0].CJQ_hao=1;
	for (i = 0; i < PointMax; i++)
	{
		if (JParamInfo3761->group2.f10[i].Status != 1)
		{
			continue;
		}
		if ((JParamInfo3761->group2.f10[i].ConnectType != 1) &&
			(JParamInfo3761->group2.f10[i].ConnectType != 2) &&
			(JParamInfo3761->group2.f10[i].ConnectType != 30)&&
			(JParamInfo3761->group2.f10[i].ConnectType != 21))
			continue;
		TempMeterPara[meterCount].CJQ_hao = JParamInfo3761->group2.f10[i].CjqNo;
		TempMeterPara[meterCount].DNB_hao = JParamInfo3761->group2.f10[i].MeterNo + 1;
		for (k = 0; k < 6; k++)
			TempMeterPara[meterCount].p_8902.address[5 - k]
					= JParamInfo3761->group2.f10[i].Address[k];
		TempMeterPara[meterCount].p_flag = JParamInfo3761->group2.f10[i].Type;
		meterCount++;
	}

}
void initMeterPare_addr(unsigned char *addr) {
	INT16U i, k;
	meterCount = 0;
	CaijiqiCount = 0;
	memset(TempMeterPara, 0, sizeof(TempMeterPara));
	TempMeterPara[0].CJQ_hao=1;
	for (i = 0; i < PointMax; i++)
	{
		if (JParamInfo3761->group2.f10[i].Status != 1)
		{
			continue;
		}
		if ((JParamInfo3761->group2.f10[i].ConnectType != 1) &&
			(JParamInfo3761->group2.f10[i].ConnectType != 2) &&
			(JParamInfo3761->group2.f10[i].ConnectType != 30)&&
			(JParamInfo3761->group2.f10[i].ConnectType != 21))
			continue;

		if((addr[2]==JParamInfo3761->group2.f10[i].Address[2])&&(addr[1]==JParamInfo3761->group2.f10[i].Address[1])&&(addr[0]==JParamInfo3761->group2.f10[i].Address[0])){
			TempMeterPara[meterCount].CJQ_hao = JParamInfo3761->group2.f10[i].CjqNo;
			TempMeterPara[meterCount].DNB_hao = JParamInfo3761->group2.f10[i].MeterNo + 1;
			for (k = 0; k < 6; k++)
				TempMeterPara[meterCount].p_8902.address[5 - k]= JParamInfo3761->group2.f10[i].Address[k];
			TempMeterPara[meterCount].p_flag = JParamInfo3761->group2.f10[i].Type;
			meterCount++;
		}
	}

}
void initMeterPare_clno(unsigned char clno) {
	INT16U i, k;
	meterCount = 0;
	CaijiqiCount = 0;
	memset(TempMeterPara, 0, sizeof(TempMeterPara));
	TempMeterPara[0].CJQ_hao=1;
	for (i = 0; i < PointMax; i++)
	{
		if (JParamInfo3761->group2.f10[i].Status != 1)
		{
			continue;
		}
		if ((JParamInfo3761->group2.f10[i].ConnectType != 1) &&
			(JParamInfo3761->group2.f10[i].ConnectType != 2) &&
			(JParamInfo3761->group2.f10[i].ConnectType != 30)&&
			(JParamInfo3761->group2.f10[i].ConnectType != 21))
			continue;

		if(clno==(JParamInfo3761->group2.f10[i].MeterNo + 1)){
			TempMeterPara[meterCount].CJQ_hao = JParamInfo3761->group2.f10[i].CjqNo;
			TempMeterPara[meterCount].DNB_hao = JParamInfo3761->group2.f10[i].MeterNo + 1;
			for (k = 0; k < 6; k++)
				TempMeterPara[meterCount].p_8902.address[5 - k]= JParamInfo3761->group2.f10[i].Address[k];
			TempMeterPara[meterCount].p_flag = JParamInfo3761->group2.f10[i].Type;
			meterCount++;
		}
	}

}
/******************************************************************************************************************
 * �������ƣ�show_AlarmData() ���ڵ�һ���˵�
 * ��    �ܣ�����ʾ�����澯��Ϣ��
 * ����������ͨ��ѡ����ܱ���ѡ��Ҫ�鿴�ĵ��ܱ��ĸ澯��Ϣ
 * ��ڲ�������
 * ���ڲ�������
 ******************************************************************************************************************/

int show_AlarmData(INT8U SeleMenu) {
	unsigned int DelayTime;
	INT8U keysele;
	INT16U i,j,k;
	unsigned char tempAdd[32];
	i = 0;
	DelayTime = 0;
	initMeterPare();
	//fprintf( stderr, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa %d\n",meterCount);
	while (1) {
		ClearThreadTimes(ProjectNo);
		delay(100);
		GUI_Clear();
		Status_Bar();//Ȼ��״̬����Ȼ������ʾ�����ı��ţ����ǵ�һ���˵�����
		if (meterCount > 0) {
			GUI_DispStringAt((INT8U *) "��  ��      ����ַ", 0, 16);
			GUI_SetTextMode(GUI_TM_REV);
			GUI_DispDecAt(TempMeterPara[i].CJQ_hao - 1, 0, 32, 3);
			GUI_DispStringAt((INT8U *) " ", 24, 32);
			GUI_DispDecAt(TempMeterPara[i].DNB_hao, 32, 32, 2);
			GUI_DispStringAt((INT8U *) "  ", 48, 32);
			BCDToASC(&TempMeterPara[i].p_8902.address[0], 6, tempAdd);
			GUI_DispStringAt(tempAdd, 64, 32);
			GUI_SetTextMode(GUI_TM_NORMAL);
			if (meterCount - i >= 6)
				k = 5;
			else
				k = meterCount - i - 1;
			for (j = 0; j < k; j++) {
				GUI_DispDecAt(TempMeterPara[i + j + 1].CJQ_hao - 1, 0, 48 + j
						* 16, 3);
				GUI_DispDecAt(TempMeterPara[i + j + 1].DNB_hao, 32,
						48 + j * 16, 2);
				BCDToASC(&TempMeterPara[i + j + 1].p_8902.address[0], 6,
						tempAdd);
				GUI_DispStringAt(tempAdd, 64, 48 + j * 16);
			}
			//���������������ڱ���ַ��������ʾ
			Lcmfull();
			keysele = KeySeleflag;
			KeySeleflag = 0;
			if (DelayTime >= PageDelayTime) {
				OldLevel = 0;
				return 0;
			}
			switch (keysele) {
			case 0:
				DelayTime++;
				break;
			case 1:
				if (i == 0)
					i = meterCount - 1;
				else
					i--;
				DelayTime = 0;
				break;//���ϼ�
			case 2:
				if (i == meterCount - 1)
					i = 0;
				else
					i++;
				DelayTime = 0;
				break;//���¼�
			case 3:
				DelayTime = 0;
				break;
			case 4:
				DelayTime = 0;
				break;
			case 5:
				show_meter_alarm(TempMeterPara[i].CJQ_hao - 1,
						TempMeterPara[i].DNB_hao - 1,
						TempMeterPara[i].p_8902.address);
				break;//ȷ�ϼ�
			case 6:
				OldLevel = 0;
				return 0;
				break;
			default:
				break;
			}
		} else {
			GUI_DispStringAt((INT8U *) "�޿��ò�����!", 32, 64);
			Lcmfull();
			keysele = KeySeleflag;
			KeySeleflag = 0;
			if (DelayTime >= PageDelayTime) {
				OldLevel = 0;
				return 0;
			}
			switch (keysele) {
			case 0:
				DelayTime++;
				break;
			case 1:
				break;//���ϼ�
			case 2:
				break;//���¼�
			case 3:
				break;
			case 4:
				break;
			case 5:
				break;//ȷ�ϼ�
			case 6:
				OldLevel = 0;
				return 0;
				break;
			default:
				break;
			}
		}

	}
	return 0;
}
/******************************************************************************************************************
 * �������ƣ�show_AlarmData() ���ڵ�һ���˵�
 * ��    �ܣ�����ʾ�����澯��Ϣ��
 * ����������ͨ��ѡ����ܱ���ѡ��Ҫ�鿴�ĵ��ܱ��ĸ澯��Ϣ
 * ��ڲ�������
 * ���ڲ�������
 ******************************************************************************************************************/

void show_meter_alarm(INT8U CaijiqiNo, INT8U MeterNo, unsigned char * MeterAdd) {
	/*unsigned int DelayTime;
	 INT8U keysele,i,j,k,flag,begin2;
	 unsigned char date[12],num[3],tempAdd[13];
	 DelayTime=0;
	 initMeterPare();
	 memset(tempAdd,0,13);
	 BCDToASC(MeterAdd,6,&tempAdd[0]);
	 //memset(tempAlarmFile,0,sizeof(tempAlarmFile));
	 memset(date,0,12);
	 //flag=readAlarmData(CaijiqiNo,MeterNo,&tempAlarmFile[0]);
	 for(i=0;i<AlarmFileNum;i++){
	 if(tempAlarmFile[i].AlarmCode!=0x00)
	 break;
	 }
	 begin2=i;
	 //  fprintf( stderr, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa %d\n",begin2);
	 i=AlarmFileNum-1;
	 //fprintf( stderr, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa %d\n",meterCount);
	 while(1)
	 {
	 delay(100);
	 GUI_Clear();
	 Status_Bar();//Ȼ��״̬����Ȼ������ʾ�����ı��ţ����ǵ�һ���˵�����
	 if(flag==1)
	 {
	 GUI_DispStringAt((INT8U *)"���      ʱ��",0,16);
	 GUI_SetTextMode(GUI_TM_REV);
	 sprintf((char *)num,"%02d",AlarmFileNum-i);
	 sprintf((char *)date,"%04d-%02d-%02d %02d:%02d",tempAlarmFile[i].dt.Year,tempAlarmFile[i].dt.Month,
	 tempAlarmFile[i].dt.Day,tempAlarmFile[i].dt.Hour,tempAlarmFile[i].dt.Minute);
	 GUI_DispStringAt(num,8,32);
	 GUI_DispStringAt((INT8U *)"  ",24,32);
	 GUI_DispStringAt((INT8U *)" ",0,32);
	 GUI_DispStringAt(date,32,32);
	 GUI_SetTextMode(GUI_TM_NORMAL);
	 if(i-begin2>=4)
	 k=4;
	 else
	 k=i-begin2;
	 for(j=0;j<k;j++)
	 {
	 sprintf((char *)num,"%02d",AlarmFileNum-i+j+1);
	 sprintf((char *)date,"%04d-%02d-%02d %02d:%02d",tempAlarmFile[i-j-1].dt.Year,tempAlarmFile[i-j-1].dt.Month,
	 tempAlarmFile[i-j-1].dt.Day,tempAlarmFile[i-j-1].dt.Hour,tempAlarmFile[i-j-1].dt.Minute);
	 GUI_DispStringAt(num,8,48+j*16);
	 GUI_DispStringAt(date,32,48+j*16);
	 }
	 //���������������ڱ���ַ��������ʾ
	 keysele=KeySeleflag;
	 KeySeleflag =0;
	 if(DelayTime>=PageDelayTime)
	 {
	 OldLevel=0;
	 return;
	 }
	 switch(keysele)
	 {
	 case 0:DelayTime++;break;
	 case 1:
	 if(i==AlarmFileNum-1)
	 i=begin2;
	 else
	 i++;DelayTime=0; break;//���ϼ�
	 case 2:
	 if(i==begin2)
	 i=AlarmFileNum-1;
	 else
	 i--;DelayTime=0; break;//���¼�
	 case 3: DelayTime=0;break;
	 case 4: DelayTime=0;break;
	 case 5: show_sel_alarm(i,CaijiqiNo,MeterNo,tempAdd);DelayTime=0;break;//ȷ�Ͻ�
	 case 6: OldLevel=0;return;break;
	 default:break;
	 }
	 }else{
	 GUI_DispStringAt((INT8U *)"�޸澯��¼!",12,64);
	 keysele=KeySeleflag;
	 KeySeleflag =0;
	 if(DelayTime>=PageDelayTime)
	 {
	 OldLevel=0;
	 return;
	 }
	 switch(keysele)
	 {
	 case 0:break;
	 case 1: break;//���ϼ�
	 case 2: break;//���¼�
	 case 3: break;
	 case 4: break;
	 case 5: break;//ȷ�ϼ�
	 case 6: OldLevel=0;return;break;
	 default:break;
	 }
	 }
	 GUI_DispStringAt((INT8U *)"(",0,144);
	 GUI_DispStringAt((INT8U *)"-",32,144);
	 GUI_DispStringAt((INT8U *)")",56,144);
	 GUI_DispDecAt(CaijiqiNo,8,144,3);
	 GUI_DispDecAt(MeterNo+1,40,144,2);
	 GUI_DispStringAt(tempAdd,64,144);
	 Lcmfull();
	 }*/
}
void show_sel_alarm(INT8U i, INT8U CaijiqiNo, INT8U MeterNo,unsigned char * MeterAdd) {
	/*unsigned char keysele;
	 unsigned int DelayTime;
	 DelayTime=0;
	 unsigned char  date[12],Alarmdate[32];
	 INT8U order[2],metertype;
	 while(1)
	 {
	 delay(100);
	 GUI_Clear();
	 GUI_DispStringAt((INT8U *)"������:",16,32);
	 GUI_DispStringAt((INT8U *)"�澯ʱ��:",16,48);
	 GUI_DispStringAt((INT8U *)"�澯��Ϣ:",16,80);
	 //metertype=Jmemory->Points.f25[getPoint(tempAlarmFile[i].cNo,tempAlarmFile[i].MeterNo)].Type;
	 switch(metertype)
	 {
	 case 1:
	 GUI_DispStringAt((INT8U *)"�й���",80,32); break;
	 case 2:
	 GUI_DispStringAt((INT8U *)"�����ʱ�",80,32); break;
	 case 3:
	 GUI_DispStringAt((INT8U *)"�๦�ܱ�",80,32); break;
	 case 4:
	 GUI_DispStringAt((INT8U *)"�޹���",80,32); break;
	 case 5:
	 GUI_DispStringAt((INT8U *)"������",80,32); break;
	 case 6:
	 GUI_DispStringAt((INT8U *)"Ԥ���ѱ�",80,32); break;
	 case 7:
	 GUI_DispStringAt((INT8U *)"CPU����",80,32); break;
	 case 8:
	 GUI_DispStringAt((INT8U *)"IC����",80,32); break;
	 case 9:
	 GUI_DispStringAt((INT8U *)"�����",80,32); break;
	 default:break;
	 }
	 sprintf((char *)date,"%04d-%02d-%02d %02d:%02d",tempAlarmFile[i].dt.Year,tempAlarmFile[i].dt.Month,
	 tempAlarmFile[i].dt.Day,tempAlarmFile[i].dt.Hour,tempAlarmFile[i].dt.Minute);
	 GUI_DispStringAt(date,8,64);
	 order[1]=0x01;
	 order[0]=tempAlarmFile[i].AlarmCode;
	 // fprintf( stderr, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa %x-%x\n",order[1],order[0]);
	 returnChNm(order,Alarmdate);
	 GUI_DispStringAt(Alarmdate,32,96);
	 Status_Bar();
	 GUI_DispStringAt((INT8U *)"(",0,144);
	 GUI_DispStringAt((INT8U *)"-",32,144);
	 GUI_DispStringAt((INT8U *)")",56,144);
	 GUI_DispDecAt(CaijiqiNo,8,144,3);
	 GUI_DispDecAt(MeterNo+1,40,144,2);
	 GUI_DispStringAt(MeterAdd,64,144);
	 Lcmfull();
	 keysele=KeySeleflag;
	 KeySeleflag =0;
	 if(keysele!=0)DelayTime=0;else DelayTime++;
	 if(DelayTime>=PageDelayTime)
	 {
	 OldLevel=0;
	 return;
	 }
	 switch(keysele)
	 {
	 case 6: return;break;
	 default:break;
	 }
	 }*/
}
int show_Rel_Alarm(INT8U SeleMenu) {
	/*unsigned char keysele,i;
	 unsigned int DelayTime;
	 DelayTime=0;
	 unsigned char MeterAdd[32],tempMadd[6];
	 unsigned char date[12],Alarmdate[32];
	 INT8U order[2],metertype;
	 for(i=0;i<6;i++){
	 tempMadd[5-i]=Jmemory->Points.f10.f10[getPoint(Jmemory->AlmFile.cNo,Jmemory->AlmFile.MeterNo)].Address[i];
	 }
	 BCDToASC(&tempMadd[0],6,MeterAdd);
	 //fprintf( stderr, "The aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa add is %s\n", MeterAdd);
	 while(1)
	 {
	 delay(100);
	 GUI_Clear();
	 if(Jmemory->AlmFile.AlarmCode!=0x00){
	 GUI_DispStringAt((INT8U *)"������:",16,32);
	 GUI_DispStringAt((INT8U *)"�澯ʱ��:",16,48);
	 GUI_DispStringAt((INT8U *)"�澯��Ϣ:",16,80);
	 metertype=Jmemory->Points.f25[getPoint(Jmemory->AlmFile.cNo,Jmemory->AlmFile.MeterNo)].Type;

	 switch(metertype)
	 {
	 case 1:
	 GUI_DispStringAt((INT8U *)"�й���",80,32); break;
	 case 2:
	 GUI_DispStringAt((INT8U *)"�����ʱ�",80,32); break;
	 case 3:
	 GUI_DispStringAt((INT8U *)"�๦�ܱ�",80,32); break;
	 case 4:
	 GUI_DispStringAt((INT8U *)"�޹���",80,32); break;
	 case 5:
	 GUI_DispStringAt((INT8U *)"������",80,32); break;
	 case 6:
	 GUI_DispStringAt((INT8U *)"Ԥ���ѱ�",80,32); break;
	 case 7:
	 GUI_DispStringAt((INT8U *)"CPU����",80,32); break;
	 case 8:
	 GUI_DispStringAt((INT8U *)"IC����",80,32); break;
	 case 9:
	 GUI_DispStringAt((INT8U *)"�����",80,32); break;
	 default:break;
	 }
	 sprintf((char *)date,"%04d-%02d-%02d %02d:%02d",Jmemory->AlmFile.dt.Year,Jmemory->AlmFile.dt.Month,
	 Jmemory->AlmFile.dt.Day,Jmemory->AlmFile.dt.Hour,Jmemory->AlmFile.dt.Minute);
	 GUI_DispStringAt(date,16,64);
	 order[1]=0x01;
	 order[0]=Jmemory->AlmFile.AlarmCode;
	 returnChNm(order,Alarmdate);
	 GUI_DispStringAt(Alarmdate,16,96);
	 GUI_DispStringAt((INT8U *)"(",0,144);
	 GUI_DispStringAt((INT8U *)"-",32,144);
	 GUI_DispStringAt((INT8U *)")",56,144);
	 GUI_DispDecAt(Jmemory->AlmFile.cNo,8,144,3);
	 GUI_DispDecAt(Jmemory->AlmFile.MeterNo+1,40,144,2);
	 GUI_DispStringAt(MeterAdd,64,144);
	 }
	 else{
	 GUI_DispStringAt((INT8U *)"��ǰ�޸澯��Ϣ!",12,64);
	 }
	 Status_Bar();
	 Lcmfull();
	 keysele=KeySeleflag;
	 KeySeleflag =0;
	 if(keysele!=0)DelayTime=0;else DelayTime++;
	 if(DelayTime>=PageDelayTime)
	 {
	 OldLevel=0;return 0;
	 }
	 switch(keysele)
	 {
	 case 6: OldLevel=0;return 0;break;
	 default:break;
	 }
	 }*/
	return 1;
}

/******************************************************************************************************************
 * �������ƣ�Show_DNB_Param() ���ڵ������˵�
 * ��    �ܣ�����ʾ�������ܱ�������
 * ����������ͨ��ѡ����ܱ���ѡ��Ҫ�鿴�ĵ��ܱ��Ĳ���
 * ��ڲ�������
 * ���ڲ�������
 ******************************************************************************************************************/

int Show_DNB_Param(INT8U SeleMenu) {
	unsigned int DelayTime;
	INT8U keysele;
	INT16U i,  j, k;
	unsigned char tempAdd[32];
	i = 0;
	DelayTime = 0;
	initMeterPare();

	while (1) {
		ClearThreadTimes(ProjectNo);
		GUI_Clear();
		Status_Bar();//Ȼ��״̬����Ȼ������ʾ�����ı��ţ����ǵ�һ���˵�����
		if (meterCount > 0) {
			GUI_DispStringAt((INT8U *) "����      ����ַ", 0, 16);
			GUI_SetTextMode(GUI_TM_REV);
			GUI_DispDecAt(getPoint(TempMeterPara[i].CJQ_hao - 1,
					TempMeterPara[i].DNB_hao), 0, 32, 4);
			/*GUI_DispDecAt(TempMeterPara[i].CJQ_hao-1,0,32,3);
			 GUI_DispStringAt((INT8U *)" ",24,32);
			 GUI_DispDecAt(TempMeterPara[i].DNB_hao,32,32,2);
			 GUI_DispStringAt((INT8U *)"  ",48,32);*/
			GUI_DispStringAt((INT8U *) "   ", 32, 32);
			BCDToASC(&TempMeterPara[i].p_8902.address[0], 6, tempAdd);
			GUI_DispStringAt(tempAdd, 56, 32);
			GUI_SetTextMode(GUI_TM_NORMAL);
			if (meterCount - i >= 6)
				k = 5;
			else
				k = meterCount - i - 1;
			for (j = 0; j < k; j++) {
				GUI_DispDecAt(getPoint(TempMeterPara[i + j + 1].CJQ_hao - 1,
						TempMeterPara[i + j + 1].DNB_hao), 0, 48 + j * 16, 4);
				//GUI_DispDecAt(TempMeterPara[i+j+1].CJQ_hao-1,0,48+j*16,3);
				//GUI_DispDecAt(TempMeterPara[i+j+1].DNB_hao,32,48+j*16,2);
				BCDToASC(&TempMeterPara[i + j + 1].p_8902.address[0], 6,
						tempAdd);
				GUI_DispStringAt(tempAdd, 56, 48 + j * 16);
			}
			//���������������ڱ���ַ��������ʾ
			Lcmfull();
			keysele = KeySeleflag;
			KeySeleflag = 0;
			if (DelayTime >= PageDelayTime) {
				OldLevel = 0;
				return 0;
			}
			switch (keysele) {
			case 0:
				DelayTime++;
				break;
			case 1:
				if (i == 0)
					i = meterCount - 1;
				else
					i--;
				DelayTime = 0;
				break;//���ϼ�
			case 2:
				if (i == meterCount - 1)
					i = 0;
				else
					i++;
				DelayTime = 0;
				break;//���¼�
			case 3:
				if (i>=6)
					i=i-6;
				else i = meterCount - 1;
				DelayTime = 0;
				break;
			case 4:
				if (i<=meterCount - 6)
					i=i+6;
				else i=0;
				DelayTime = 0;
				break;
			case 5:
				show_sel_Para(TempMeterPara[i].CJQ_hao - 1,
						TempMeterPara[i].DNB_hao - 1,
						TempMeterPara[i].p_8902.address);
				break;//ȷ�ϼ�
			case 6:
				OldLevel = 0;
				return 0;
				break;
			default:
				break;
			}
		} else {
			GUI_DispStringAt((INT8U *) "�޿��ò�����!", 32, 64);
			Lcmfull();
			keysele = KeySeleflag;
			KeySeleflag = 0;
			if (DelayTime >= PageDelayTime) {
				OldLevel = 0;
				return 0;
			}
			switch (keysele) {
			case 0:
				DelayTime++;
				break;
			case 1:
				break;//���ϼ�
			case 2:
				break;//���¼�
			case 3:
				break;
			case 4:
				break;
			case 5:
				break;//ȷ�ϼ�
			case 6:
				OldLevel = 0;
				return 0;
				break;
			default:
				break;
			}
		}
		delay(100);
	}
	return 0;
}
/******************************************************************************************************************
 * �������ƣ�show_sel_Para()
 * ��    �ܣ�����������Ϣ����ʾѡ�еĵ������
 * ��ڲ�������
 * ���ڲ�������
 *******************************************************************************************************************/
void show_sel_Para(INT8U CJQ_hao, INT8U DNB_hao, unsigned char *MeterAdd) {
	unsigned char keysele;
	unsigned int DelayTime;
	unsigned char tempAdd[13];
	unsigned char cjqadd2[9];
	unsigned char cjqadd[9];
	int x_offset=0;
	INT8U metertype,i;
	DelayTime = 0;
	memset(tempAdd, 0, 13);
	BCDToASC(MeterAdd, 6, tempAdd);
	memset(cjqadd, 0, 9);
	memset(cjqadd2, 0, 9);
	for(i=0;i<4;i++)
		cjqadd2[i]=JParamInfo3761->group2.f10[getPoint(CJQ_hao, DNB_hao)].CaijiqiAddress[3-i];
	BCDToASC(&cjqadd2[0], 4, cjqadd);

	while (1) {
		ClearThreadTimes(ProjectNo);
		GUI_Clear();
		GUI_DispStringAt((INT8U *) "������:", x_offset, 16);
		GUI_DispStringAt((INT8U *) "�˿ں�:", x_offset, 32);
		GUI_DispStringAt((INT8U *) "������:", x_offset, 48);
		GUI_DispStringAt((INT8U *) "У��λ:", x_offset, 64);
		GUI_DispStringAt((INT8U *) "����λ:", x_offset, 80);
		GUI_DispStringAt((INT8U *) "ֹͣλ:", x_offset, 96);
		GUI_DispStringAt((INT8U *) "��Լ��:", x_offset, 112);
		GUI_DispStringAt((INT8U *) "����ַ:", x_offset, 128);

		metertype = JParamInfo3761->group2.f10[getPoint(CJQ_hao, DNB_hao)].Type;
		switch (metertype) {
		/*case 1:
			GUI_DispStringAt((INT8U *) "�й���", 80, 16);
			break;
		case 2:
			GUI_DispStringAt((INT8U *) "�����ʱ�", 80, 16);
			break;*/
		case 3:
			GUI_DispStringAt((INT8U *) "�๦�ܱ�", 64+x_offset, 16);
			break;
		/*case 4:
			GUI_DispStringAt((INT8U *) "�޹���", 80, 16);
			break;
		case 5:
			GUI_DispStringAt((INT8U *) "������", 80, 16);
			break;
		case 6:
			GUI_DispStringAt((INT8U *) "Ԥ���ѱ�", 80, 16);
			break;
		case 7:
			GUI_DispStringAt((INT8U *) "CPU����", 80, 16);
			break;
		case 8:
			GUI_DispStringAt((INT8U *) "IC����", 80, 16);
			break;*/
		case 9:
			GUI_DispStringAt((INT8U *) "�����", 64+x_offset, 16);
			break;
		default:
			GUI_DispStringAt((INT8U *) "�ɼ���", 64+x_offset, 16);
			break;
		}
		GUI_DispDecAt(JParamInfo3761->group2.f10[getPoint(CJQ_hao, DNB_hao)].port,
				64+x_offset, 32, 1);
		GUI_DispDecAt(
				JParamInfo3761->group2.f10[getPoint(CJQ_hao, DNB_hao)].baudrate
						* 300, 64+x_offset, 48, 4);
		switch (JParamInfo3761->group2.f10[getPoint(CJQ_hao, DNB_hao)].jiao_yan_wei) {
		case 0x00:
			GUI_DispStringAt((INT8U *) "��У��", 64+x_offset, 64);
			break;
		case 0x01:
			GUI_DispStringAt((INT8U *) "żУ��", 64+x_offset, 64);
			break;
		case 0x02:
			GUI_DispStringAt((INT8U *) "��У��", 64+x_offset, 64);
			break;
		default:
			break;
		}
		GUI_DispDecAt(
				JParamInfo3761->group2.f10[getPoint(CJQ_hao, DNB_hao)].shu_ju_wei,
				64+x_offset, 80, 1);
		GUI_DispDecAt(
				JParamInfo3761->group2.f10[getPoint(CJQ_hao, DNB_hao)].ting_zhi_wei,
				64+x_offset, 96, 1);
		switch (JParamInfo3761->group2.f10[getPoint(CJQ_hao, DNB_hao)].ConnectType) {
		case 1:
			GUI_DispStringAt((INT8U *) "T645-97", 64+x_offset, 112);
			break;
		case 30:
			GUI_DispStringAt((INT8U *) "T645-07", 64+x_offset, 112);
			break;
		case 21:
			GUI_DispStringAt((INT8U *) "T645-SH", 64+x_offset, 112);
			break;
		default:
			GUI_DispStringAt((INT8U *) "����   ", 64+x_offset, 112);
			break;
		}
		GUI_DispStringAt(tempAdd, 64+x_offset, 128);
		Status_Bar();
		Lcmfull();
		keysele = KeySeleflag;
		KeySeleflag = 0;
		if (keysele != 0)
			DelayTime = 0;
		else
			DelayTime++;
		if (DelayTime >= PageDelayTime) {
			return;
		}
		switch (keysele) {
		case 6:
			return;
			break;
		default:
			break;
		}
		delay(100);
	}
}
/******************************************************************************************************************
 * �������ƣ�Show_HwInit()�����ڵ������˵� //zyz
 * ��    �ܣ���Ӳ����ʼ����
 * ��ڲ�������
 * ���ڲ�������
 *******************************************************************************************************************/
int Show_HwInit(INT8U SeleMenu)
{
	unsigned char keysele, j = 0,msel,flag,i;
	unsigned int DelayTime;
	unsigned char TempPass[7], SavePass[4], JmPass[7];
	memset(NowInput.buf, 0, 128);
	sprintf((char*) NowInput.buf, "%06d", 0); //����ת����Ϊ�ַ���
	i = 0;
	GUI_Clear();
	GUI_DrawHLine(24, 32, 132);
	GUI_DrawVLine(24, 32, 96);
	GUI_DrawVLine(132, 32, 96);
	GUI_DrawHLine(24, 96, 132);
	GUI_DispStringAt((INT8U *) "����������", 36, 48);
	while (i < 6) {
		NowInput.col[i] = 64;
		NowInput.row[i] = 56 + i * 8;
		NowInput.set[i] = 1;
		i++;
	}
	NowInput.AllNum = 7;
	flag = ScreenInput();
	if (flag == 1 || flag == 0)
	{
		//�ж������Ƿ���ȷ����ȷ�Ļ����������޸�ҳ��
		//printf( "\n\rThe sssssssssssssssssssssssssssssssssssssssssss is %d:\n\r",GetNum(NowInput.buf,6,1));
		memcpy(TempPass, &NowInput.buf[0], 6);
		for (i = 0; i < 3; i++) {
			SavePass[i] = JParamInfo3761->group1.f7.PassWords[2 - i];
		}
		BCDToASC(SavePass, 3, &JmPass[0]);
		//printf( "\n\rThe sssssssssssssssssssssssssssssssssssssssssss is: %s\n\r",JmPass);
		if (memcmp(TempPass, JmPass, 6) == 0) {
			msel = 8;
		} else if (memcmp(TempPass, "666666", 6) == 0) {
			memset(JParamInfo3761->group1.f7.PassWords,0x00,20);//����
			//JParamInfo3761->group1.f7.PassWords[2]=0x10;	  //�Ϻ���������ʼ����Ϊ000000 //lcy2013
			//lcy2013.1.11
			//JProgramInfo->Para.ChangedJiZhongQiInfo=2;
			if(JProgramInfo->FileSaveFlag.g1flag==0)
				JProgramInfo->FileSaveFlag.g1flag=1;
			delay(3000);
			msel = 8;
		} else {
			msel = 5;
			MenuSele = 19;
		}
		GUI_Clear();
		for (j = 0; j < MenuNums; j++) {
			if (Menu[j].level == Menu[MenuSele].level) {
				GUI_DispStringAt((INT8U *) Menu[j].Str, Menu[j].row,
						Menu[j].col);
			}
		}
		if (msel == 5)
		{
			return 0;
		}
	}
	else
	{
		OldLevel = 0;
		return 0;
	}
	DelayTime = 0;
	printf("jLcdTask reboot\n\r");
	DbgPrintToFile("\nLCD Һ����λ reboot\n");//9.27
	JProgramInfo->stateflags.RebootFlag = F1_NO_INIT;
//	memset(TempBuf, 0, 60);
//	sprintf((char *) TempBuf, "%s/rebtsys &", _USERDIR_);
//	syscmd((char *) TempBuf,JProgramInfo);
	while (1) {
		ClearThreadTimes(ProjectNo);
		delay(100);
		GUI_Clear();
		Status_Bar();

		GUI_DispStringAt((INT8U *) "��ʼ��������", 8, 24);
		if (j == 0)
			GUI_DispStringAt((INT8U *) ".", 104, 24);
		else if (j == 1)
			GUI_DispStringAt((INT8U *) "..", 104, 24);
		else if (j == 2)
			GUI_DispStringAt((INT8U *) "...", 104, 24);
		else
			GUI_DispStringAt((INT8U *) "...", 104, 24);
		j++;
		if (j > 3)
			j = 0;

		keysele = KeySeleflag;
		KeySeleflag = 0;
		if (keysele != 0)
			DelayTime = 0;
		else
			DelayTime++;
		if (DelayTime >= PageDelayTime) {
			OldLevel = 0;
			return 0;
		}
		switch (keysele) {
		case 6:
			OldLevel = 0;
			return 0;
			break; //ȡ����
		default:
			break;
		}
		Lcmfull();
	}
	return 0;
}

/******************************************************************************************************************
 * �������ƣ�Show_DataInit()�����ڵ������˵� //zyz
 * ��    �ܣ������ݳ�ʼ����
 * ��ڲ�������
 * ���ڲ�������
 *******************************************************************************************************************/
int Show_DataInit(INT8U SeleMenu) {
	unsigned char keysele, msel,flag;
	INT16U i,j;
	unsigned int DelayTime;
	unsigned char TempPass[7], SavePass[4], JmPass[7];
	INT8U Command[60];
	TS ts;
	memset(NowInput.buf, 0, 128);
	sprintf((char*) NowInput.buf, "%06d", 0); //����ת����Ϊ�ַ���
	i = 0;
	GUI_Clear();
	GUI_DrawHLine(24, 32, 132);
	GUI_DrawVLine(24, 32, 96);
	GUI_DrawVLine(132, 32, 96);
	GUI_DrawHLine(24, 96, 132);
	GUI_DispStringAt((INT8U *) "����������", 36, 48);
	while (i < 6) {
		NowInput.col[i] = 64;
		NowInput.row[i] = 56 + i * 8;
		NowInput.set[i] = 1;
		i++;
	}
	NowInput.AllNum = 7;
	flag = ScreenInput();
	if (flag == 1 || flag == 0)
	{
		//�ж������Ƿ���ȷ����ȷ�Ļ����������޸�ҳ��
		//printf( "\n\rThe sssssssssssssssssssssssssssssssssssssssssss is %d:\n\r",GetNum(NowInput.buf,6,1));
		memcpy(TempPass, &NowInput.buf[0], 6);
		for (i = 0; i < 3; i++) {
			SavePass[i] = JParamInfo3761->group1.f7.PassWords[2 - i];
		}
		BCDToASC(SavePass, 3, &JmPass[0]);

		if (memcmp(TempPass, JmPass, 6) == 0) {
			msel = 8;
		} else {
			msel = 5;
			MenuSele = 20;
		}
		GUI_Clear();
		for (j = 0; j < MenuNums; j++) {
			if (Menu[j].level == Menu[MenuSele].level) {
				GUI_DispStringAt((INT8U *) Menu[j].Str, Menu[j].row,
						Menu[j].col);
			}
		}
		Status_Bar();
		Lcmfull();
		if (msel == 5) {
			return 0;
		}
	}
	else
	{
		OldLevel = 0;
		return 0;
	}
    TSGet(&ts);
	DelayTime = 0;
	memset(Command,0,60);
	sprintf((char *)Command,"%s /nand/DataAlarm/* &",_CMDRM_);
	syscmd((char *)Command,JProgramInfo);
	memset(Command, 0, 60);
	sprintf((char *) Command, "%s /nand/DataHour/%04d%02d* &", _CMDRMDIR_,ts.Year,ts.Month);
	syscmd((char *) Command,JProgramInfo);
	TimeDecrease(&ts,5,1);
	memset(Command, 0, 60);
	sprintf((char *) Command, "%s /nand/DataHour/%04d%02d* &", _CMDRMDIR_,ts.Year,ts.Month);
	syscmd((char *) Command,JProgramInfo);

	memset(Command, 0, 60);
	sprintf((char *) Command, "%s /nand/DataRiTongJi &",_CMDRMDIR_);
	syscmd((char *) Command,JProgramInfo);
	memset(Command, 0, 60);
	sprintf((char *) Command, "%s /nand/DataYueTongJi &",_CMDRMDIR_);
	syscmd((char *) Command,JProgramInfo);
	//---------------------------�����������
	memset(&JDataFileInfo->jc,0,sizeof(JDataFileInfo->jc));
	syscmd("rm -f /nand/DataCurr/JcData.*",JProgramInfo);
	//---------------------------
	for(i=0;i<PointMax;i++)
	{
		memset(Command,0,60);
		sprintf((char *)Command,"/nand/DataCurr/%04d/",i+1);
		if (access((char*)Command,0)==0)
		{
			memset(Command,0,60);
			sprintf((char *)Command,"%s /nand/DataCurr/%04d/* &",_CMDRM_,i+1);
			syscmd((char *)Command,JProgramInfo);
		}
		memset(Command,0,60);
		sprintf((char *)Command,"/nand/DataDay/%04d/",i+1);
		if (access((char*)Command,0)==0)
		{
			memset(Command,0,60);
			sprintf((char *)Command,"%s /nand/DataDay/%04d/* &",_CMDRM_,i+1);
			syscmd((char *)Command,JProgramInfo);
		}
		memset(Command,0,60);
		sprintf((char *)Command,"/nand/DataMonth/%04d/",i+1);
		if (access((char*)Command,0)==0)
		{
			memset(Command,0,60);
			sprintf((char *)Command,"%s /nand/DataMonth/%04d/* &",_CMDRM_,i+1);
			syscmd((char *)Command,JProgramInfo);
		}
	}
	JDataFileInfo->ErcEvt.EC1=0;
	JDataFileInfo->ErcEvt.EC2=0;
	JDataFileInfo->ErcEvt.EC1old=0;
	JDataFileInfo->ErcEvt.EC2old=0;
	while (1) {
		ClearThreadTimes(ProjectNo);
		delay(100);
		GUI_Clear();

		GUI_DispStringAt((INT8U *) "���ݳ�ʼ�����!", 12, 64);

		Status_Bar();

		keysele = KeySeleflag;
		KeySeleflag = 0;
		if (keysele != 0)
			DelayTime = 0;
		else
			DelayTime++;
		if (DelayTime >= PageDelayTime) {
			OldLevel = 0;
			return 0;
		}
		switch (keysele) {
		case 6:
			OldLevel = 0;
			return 0;
			break; //ȡ����
		default:
			break;
		}
		Lcmfull();
	}
	return 0;
}

/******************************************************************************************************************
 * �������ƣ�Show_ParaInit()�����ڵ������˵� //zyz
 * ��    �ܣ���������ʼ����
 * ��ڲ�������
 * ���ڲ�������
 *******************************************************************************************************************/
int Show_ParaInit(INT8U SeleMenu) {
	unsigned char keysele;
	//		 unsigned char SoftName,SoftVersion,ComName;//SoftNameΪ��������,SoftVersion����汾��,ComName��˾����
	unsigned int DelayTime;
	DelayTime = 0;
	while (1) {
		ClearThreadTimes(ProjectNo);
		GUI_Clear();

		GUI_DispStringAt((INT8U *) "������ʼ��!", 12, 64);

		Status_Bar();

		keysele = KeySeleflag;
		KeySeleflag = 0;
		if (keysele != 0)
			DelayTime = 0;
		else
			DelayTime++;
		if (DelayTime >= PageDelayTime) {
			OldLevel = 0;
			return 0;
		}
		switch (keysele) {
		case 6:
			OldLevel = 0;
			return 0;
			break; //ȡ����
		default:
			break;
		}
		Lcmfull();
	}
	return 0;
}

int getver(unsigned char SeleMenu) {
	INT8U keysele, version[6];
	unsigned int DelayTime,zbflg,i;
	INT8U yxstat1[2],yxstat2[2],yxstat3[2];
	INT8U diqu[20];
	memset(yxstat1, 0, 2);
	memset(yxstat2, 0, 2);
	memset(yxstat3, 0, 2);
	memset(version, 0, 6);
	version[0] = JConfigInfo->jzqpara.ver.SoftVer[0];
	version[1] = JConfigInfo->jzqpara.ver.SoftVer[1];
	version[2] = JConfigInfo->jzqpara.ver.SoftVer[2];
	version[3] = JConfigInfo->jzqpara.ver.SoftVer[3];
	DelayTime = 0;
	zbflg=0;
	for(i=0;i<30;i++)
	{
		if (memcmp((char*)JProgramInfo->Projects[i].ProjectName,"jReadZB",7)==0)
		{
			zbflg=1;
		}
	}
	while (1) {
		ClearThreadTimes(ProjectNo);
		delay(100);
		GUI_Clear();

#ifdef __linux
		if (zbflg==1)
			GUI_DispStringAt((INT8U *) "�汾 :����ZB", 8, 24);
		else
			GUI_DispStringAt((INT8U *) "�汾��:WX", 8, 24);
#else
		if (zbflg==1)
			GUI_DispStringAt((INT8U *) "�汾��:����ZB", 8, 24);
		else
			GUI_DispStringAt((INT8U *) "�汾��:����QX", 8, 24);
#endif
		if (zbflg==1)
			GUI_DispStringAt((INT8U *) version, 112, 24);
		else
			GUI_DispStringAt((INT8U *) version, 88, 24);

		GUI_DispStringAt((INT8U *) "0.2", 8, 40);
		memset(diqu, 0, 20);
		//if(Jmemory->XinJiang == 1)
		if((JProgramInfo->zone&0x7f) == XINJIANG)
			memcpy(diqu, "�½�", strlen("�½�"));
		//if(Jmemory->JiangSu == 1)
		if(((JProgramInfo->zone)&0x7f) == JIANGSU)
			memcpy(diqu, "����", strlen("����"));
		//if(Jmemory->TianJing == 1)
		if(((JProgramInfo->zone)&0x7f) == TIANJIN)
			memcpy(diqu, "���", strlen("���"));
		//if(Jmemory->JiangXi == 1)
		if(((JProgramInfo->zone)&0x7f)== JIANGXI)
			memcpy(diqu, "����", strlen("����"));
		//if(Jmemory->HeBei == 1)
		if(((JProgramInfo->zone)&0x7f) == HEBEI)
			memcpy(diqu, "�ӱ�", strlen("�ӱ�"));
		if(((JProgramInfo->zone)&0x7f) == SHANGHAI)
			memcpy(diqu, "�Ϻ�", strlen("�Ϻ�"));
		GUI_DispStringAt(diqu, 40, 40);
		//if(Jmemory->GuoWangSoftTest == 1)
		if(((JProgramInfo->zone)>>7&0x01) == 1)
			GUI_DispStringAt((INT8U*)"��", 72, 40);

		Status_Bar();

		keysele = KeySeleflag;
		KeySeleflag = 0;
		if (keysele != 0)
			DelayTime = 0;
		else
			DelayTime++;
		if (DelayTime >= PageDelayTime) {
			OldLevel = 0;
			return 0;
		}
		switch (keysele) {
		case 6:
			OldLevel = 0;
			return 0;
			break; //ȡ����
		default:
			break;
		}
		Lcmfull();
	}

	return 1;
}
int ShowSoe(INT8U SeleMenu)
{
	int i;
	INT8U tmpstr[30];
	INT8U keysele;
	unsigned int DelayTime;
	DelayTime = 0;
	INT8U soetype;
	INT8U curpoint1;//��Ҫ
	INT8U curpoint2;//��ͨ
	curpoint1 = JDataFileInfo->ErcEvt.EC1;
	curpoint2 = JDataFileInfo->ErcEvt.EC2;
	while(1)
	{
		ClearThreadTimes(ProjectNo);
		delay(300);
		GUI_Clear();
		memset(tmpstr,0,30);
		sprintf((char *)tmpstr,"��Ҫ�¼�     [%03d]",curpoint1);
		GUI_DispStringAt((INT8U *) tmpstr, 8, 20);
		soetype =  JDataFileInfo->ErcEvt.ImpEvent[curpoint1].Buff[0];//��Ҫ�¼�����
		if (soetype > EVENCOUNT-1)
			soetype = EVENCOUNT-1;//δ֪�¼�

		GUI_DispStringAt((INT8U *) ERCNAME[soetype].Ercname, 8, 36);
		memset(tmpstr,0,30);
		sprintf((char *)tmpstr,"%02x��%02x��%02x�� %02x:%02x",
				JDataFileInfo->ErcEvt.ImpEvent[curpoint1].Err1.Occur_Time.BCD05,
				JDataFileInfo->ErcEvt.ImpEvent[curpoint1].Err1.Occur_Time.BCD04,
				JDataFileInfo->ErcEvt.ImpEvent[curpoint1].Err1.Occur_Time.BCD03,
				JDataFileInfo->ErcEvt.ImpEvent[curpoint1].Err1.Occur_Time.BCD02,
				JDataFileInfo->ErcEvt.ImpEvent[curpoint1].Err1.Occur_Time.BCD01);
		GUI_DispStringAt((INT8U *) tmpstr, 8, 54);

		GUI_DispStringAt((INT8U *)"������������������������������������������������", 8, 71);
		memset(tmpstr,0,30);
		sprintf((char *)tmpstr,"��ͨ�¼�     [%03d]",curpoint2);
		GUI_DispStringAt((INT8U *) tmpstr, 8, 87);
		soetype =  JDataFileInfo->ErcEvt.NorEvent[curpoint2].Buff[0];//��Ҫ�¼�����
		if (soetype > EVENCOUNT-1)
			soetype = EVENCOUNT-1;//δ֪�¼�

		GUI_DispStringAt((INT8U *) ERCNAME[soetype].Ercname, 8, 103);
		memset(tmpstr,0,30);
		sprintf((char *)tmpstr,"%02x��%02x��%02x�� %02x:%02x",JDataFileInfo->ErcEvt.NorEvent[curpoint2].Err1.Occur_Time.BCD05,JDataFileInfo->ErcEvt.NorEvent[curpoint2].Err1.Occur_Time.BCD04,JDataFileInfo->ErcEvt.NorEvent[curpoint2].Err1.Occur_Time.BCD03,JDataFileInfo->ErcEvt.NorEvent[curpoint2].Err1.Occur_Time.BCD02,JDataFileInfo->ErcEvt.NorEvent[curpoint2].Err1.Occur_Time.BCD01);
		GUI_DispStringAt((INT8U *) tmpstr, 8, 119);

		Status_Bar();
		keysele = KeySeleflag;
		KeySeleflag = 0;
		if (keysele != 0)
			DelayTime = 0;
		else
			DelayTime++;
		if (DelayTime >= PageDelayTime) {
			OldLevel = 0;
			return 0;
		}
		switch (keysele)
		{
			case 6:
				OldLevel = 0;
				return 0;
				break; //ȡ����
			case 1: //up
				for(i=0;i<256;i++)
				{
					curpoint2 = (curpoint2 + 1)%256;
					if (JDataFileInfo->ErcEvt.NorEvent[curpoint2].Buff[0]>0 && JDataFileInfo->ErcEvt.NorEvent[curpoint2].Buff[0]<EVENCOUNT)
						break;
				}
				for(i=0;i<256;i++)
				{
					curpoint1 = (curpoint1 + 1)%256;
					if (JDataFileInfo->ErcEvt.ImpEvent[curpoint2].Buff[0]>0 && JDataFileInfo->ErcEvt.ImpEvent[curpoint2].Buff[0]<EVENCOUNT)
						break;
				}
				break;
			case 2: //down
				for(i=0;i<256;i++)
				{
					curpoint2 = (curpoint2 - 1)%256;
					if (JDataFileInfo->ErcEvt.NorEvent[curpoint2].Buff[0]>0 && JDataFileInfo->ErcEvt.NorEvent[curpoint2].Buff[0]<EVENCOUNT)
						break;
				}
				for(i=0;i<256;i++)
				{
					curpoint1 = (curpoint1 - 1)%256;
					if (JDataFileInfo->ErcEvt.ImpEvent[curpoint2].Buff[0]>0 && JDataFileInfo->ErcEvt.ImpEvent[curpoint2].Buff[0]<EVENCOUNT)
						break;
				}
				break;
			default:
				break;
		}
		Lcmfull();
	}
	return 1;
}
extern INT8U MaiChongStat;
int ShowYxState(INT8U SeleMenu)//�ն����ݰ���   1 ң��״̬
{
	//gaidongjiangsu
	INT8U keysele;
	unsigned int DelayTime;
	INT8U yxstat1[2],yxstat2[2],yxstat3[2];
	memset(yxstat1, 0, 2);
	memset(yxstat2, 0, 2);
	memset(yxstat3, 0, 2);
	DelayTime = 0;
	INT8U yx1_attrib,yx2_attrib;
	yx1_attrib = JParamInfo3761->group2.f12.Attr & 0x01;//ң������
	yx2_attrib = (JParamInfo3761->group2.f12.Attr & 0x02)>>1;//ң������
	static int maichong_count=0;
	INT8U scount[10];

	while(1)
	{
		ClearThreadTimes(ProjectNo);
		delay(100);
		GUI_Clear();
		GUI_DispStringAt((INT8U *) "����״̬", 32, 20);
		GUI_DispStringAt((INT8U *) "���� 1��", 8, 48);
		if(JProgramInfo->currYXSTAT&0x01)
			GUI_DispStringAt((INT8U *) "��", 72, 48);
		else
			GUI_DispStringAt((INT8U *) "��", 72, 48);
		if(yx1_attrib==1)
			GUI_DispStringAt((INT8U *) "����", 110, 48);
		else
			GUI_DispStringAt((INT8U *) "����", 110, 48);
//------------------------------------
		if((JProgramInfo->currYXSTAT&0x02) != MaiChongStat)
		{
			if(maichong_count>0xfffffffe)
				maichong_count = 0;
			if((JProgramInfo->currYXSTAT&0x02) == 0x02)
				maichong_count++;
			MaiChongStat = JProgramInfo->currYXSTAT&0x02;
		}
		GUI_DispStringAt((INT8U *) "����2������", 8, 108);
		sprintf((char*)scount, "%d",maichong_count);
		GUI_DispStringAt(scount, 110, 108);
//------------------------------------------------------
		GUI_DispStringAt((INT8U *) "���� 2��", 8, 68);
		if(JProgramInfo->currYXSTAT&0x02)
			GUI_DispStringAt((INT8U *)  "��", 72, 68);
		else
			GUI_DispStringAt((INT8U *)  "��", 72, 68);

		if(yx2_attrib==1)
			GUI_DispStringAt((INT8U *) "����", 110, 68);
		else
			GUI_DispStringAt((INT8U *) "����", 110, 68);

		GUI_DispStringAt((INT8U *) "�Žӵ㣺", 8, 88);
		if(JProgramInfo->currYXSTAT&0x04)
			GUI_DispStringAt((INT8U *) "��", 72, 88);
		else
			GUI_DispStringAt((INT8U *) "��", 72, 88);


		Status_Bar();
		keysele = KeySeleflag;
		KeySeleflag = 0;

		if (keysele != 0)
			DelayTime = 0;
		else
			DelayTime++;
		if (DelayTime >= PageDelayTime) {
			OldLevel = 0;
			return 0;
		}
		switch (keysele) {
		case 5:
			printf("\n maichong_count==%d",maichong_count);
			maichong_count = 0;
			break;
		case 6:
			OldLevel = 0;
			return 0;
			break; //ȡ����
		default:
			break;
		}
		Lcmfull();
	}
	return 1;
}
int Show_TestSelf(INT8U SeleMenu)
{
    unsigned char keysele;
    unsigned int DelayTime;
    int menuitem_top=16;
    int menuitem_lef=16;
	int memused;
	int cpuload;
	int nandused;
	int norused;

	norused = getNorInfo();
	nandused =getNandInfo();
	memused = getMemInfo();
	cpuload = getCpuInfo();

    DelayTime=0;
	GUI_Clear();
	GUI_DispStringAt((INT8U *)"ϵͳ��ʹ����:",menuitem_lef+0,menuitem_top+16);
	GUI_DispDecShiftAt(menuitem_lef+104,menuitem_top+16,3,0,norused);
	GUI_DispStringAt((INT8U *)"%",menuitem_lef+128,menuitem_top+16);

	GUI_DispStringAt((INT8U *)"������ʹ����:",menuitem_lef+0,menuitem_top+36);
	GUI_DispDecShiftAt(menuitem_lef+104,menuitem_top+36,3,0,nandused);
	GUI_DispStringAt((INT8U *)"%",menuitem_lef+128,menuitem_top+36);


	GUI_DispStringAt((INT8U *)"�ڴ�ʹ����: ",menuitem_lef+0,menuitem_top+56);
	GUI_DispDecShiftAt(menuitem_lef+88,menuitem_top+56,3,0,memused);
	GUI_DispStringAt((INT8U *)"%",menuitem_lef+112,menuitem_top+56);


	GUI_DispStringAt((INT8U *)"CPU����: ",menuitem_lef+0,menuitem_top+76);
	GUI_DispDecShiftAt(menuitem_lef+64,menuitem_top+76,3,0,cpuload);
	GUI_DispStringAt((INT8U *)"%",menuitem_lef+88,menuitem_top+76);

    while(1)
    {
    	memused = getMemInfo();
    	cpuload = getCpuInfo();
    	delay(200);
    	//Lcmpower();
    	GUI_DispDecShiftAt(menuitem_lef+104,menuitem_top+16,3,0,norused);
    	GUI_DispDecShiftAt(menuitem_lef+104,menuitem_top+36,3,0,nandused);
    	//GUI_DispDecShiftAt(88,72,2,0,32);
    	GUI_DispDecShiftAt(menuitem_lef+88,menuitem_top+56,3,0,memused);
    	GUI_DispDecShiftAt(menuitem_lef+64,menuitem_top+76,3,0,cpuload);

	     keysele=KeySeleflag;
	     KeySeleflag =0;
	     if(keysele!=0)
	    	 DelayTime=0;
	     else
	    	 DelayTime++;
		 if(DelayTime>=PageDelayTime*4)
		   {
			OldLevel=0;
			return 0;
			}
	     if(keysele == 6)//ȡ����
	     {
		    OldLevel = 0;
		    return 0;
	     }
        Status_Bar();
		Lcmfull();
    }
	return 0;
}
//xiaowuxian
int Modify_YJ_Contrast(INT8U SeleMenu)
{
	INT8U keysele,sj;
	unsigned int DelayTime;
	INT8U Command[120];
	int contrast_value_old;
	sj=0;
	memset(Command,0,120);
	char showstr[100],flag_yjchanged=0;
	//int contrast_value;
	int fd=-1,fdyj=-1;
	fd=open("/nand/bin/yejingliang.info",O_RDWR|O_CREAT);
	if(fd>0)
	{
		read(fd,&contrast_value,sizeof(int));
		//printf("\ncontrast_value = %d\n", contrast_value);
		if( contrast_value<YJ_BOTTOMLIMIT1 || (contrast_value>YJ_TOPLIMIT1 && contrast_value<YJ_BOTTOMLIMIT2) )
			contrast_value=YJ_DEFAULTLIMIT1;
		if( contrast_value>YJ_TOPLIMIT2 )
			contrast_value=YJ_DEFAULTLIMIT2;
	}else{
		contrast_value=YJ_DEFAULTLIMIT1;
	}
	close(fd);
	if((fdyj = open("/dev/fb0", O_RDWR | O_NDELAY)) >0)
		ioctl(fdyj,LCD_IOC_CONTRAST,&contrast_value);
	close(fdyj);

	delay(500);
	DelayTime = 0;
	contrast_value_old = contrast_value;
	while (1) {
		ClearThreadTimes(ProjectNo);
		delay(300);
		GUI_Clear();
		if(flag_yjchanged)
		{
			flag_yjchanged=0;
			if((fdyj = open("/dev/fb0", O_RDWR | O_NDELAY)) >0)
				ioctl(fdyj,LCD_IOC_CONTRAST,&contrast_value);
			close(fdyj);
			fd=open("/nand/bin/yejingliang.info",O_RDWR|O_CREAT);
			if(fd>0)
			{
				write(fd,&contrast_value,sizeof(int));
			}
			close(fd);
		}
		sprintf(showstr,"Һ���Աȶ�: %d",contrast_value);
		GUI_DispStringAt((INT8U *)showstr,16,72);
		keysele = KeySeleflag;
		KeySeleflag = 0;
		if (keysele != 0)
			DelayTime = 0;
		else
			DelayTime++;
		if (DelayTime >= PageDelayTime)
		{
			OldLevel = 0;
			return 0;
		}
		switch (keysele)
		{
		case 0:
			break;
		case 1:
			contrast_value = contrast_value + 2;
			if( contrast_value_old<=YJ_TOPLIMIT1 && contrast_value>=YJ_TOPLIMIT1 )
				contrast_value=YJ_BOTTOMLIMIT2;
			if( contrast_value_old<=YJ_TOPLIMIT2 && contrast_value>=YJ_TOPLIMIT2 )
				contrast_value=YJ_BOTTOMLIMIT1;
			printf("\nup contrast_value = %d\n", contrast_value);
			flag_yjchanged = 1;
			contrast_value_old = contrast_value;
			break;//���ϼ�
		case 2:
			contrast_value = contrast_value - 2;
			if( contrast_value_old>=YJ_BOTTOMLIMIT2 && contrast_value<=YJ_BOTTOMLIMIT2 )
				contrast_value=YJ_TOPLIMIT1;
			if( contrast_value_old>=YJ_BOTTOMLIMIT1 && contrast_value<=YJ_BOTTOMLIMIT1 )
				contrast_value=YJ_TOPLIMIT2;
			printf("\ndown contrast_value = %d\n", contrast_value);
			flag_yjchanged = 1;
			contrast_value_old = contrast_value;
			break;//���¼�
		case 3:
			break;
		case 4:
			break;
		case 5:
			break;//ȷ�ϼ�
		case 6:
			OldLevel = 0;
			return 1;
			break;
		default:
			break;
		}
		Lcmfull();
	}
	return 1;
}

int Update_Soft(unsigned char SeleMenu) {
	INT8U keysele,sj;
	unsigned int DelayTime;
	INT8U Command[120];

	sj=0;
	memset(Command,0,120);
	sprintf((char *)Command,"%s/",_USBDIR_);
	if (access((char *)Command, 0) == 0)
	{
		ClearThreadTimes(ProjectNo);
		GUI_Clear();
		GUI_DispStringAt((INT8U *)"���������Ժ�...",8,24);
		Status_Bar();
		memset(Command,0,120);
		sprintf((char *)Command,"%s %s/updgwusb.sh",_CMDRM_,_USERDIR_);
		system((char *)Command);
		delay(100);
		memset(Command,0,120);
		sprintf((char *)Command,"%s %s/gprs/updgwusb.sh %s/updgwusb.sh",_CMDCP_,_USBDIR_,_USERDIR_);
		system((char *)Command);
		delay(100);
		memset(Command,0,120);
		sprintf((char *)Command,"chmod +x %s/updgwusb.sh",_USERDIR_);
		system((char *)Command);
		delay(100);
		memset(Command,0,120);
		sprintf((char *)Command,"%s/updgwusb.sh",_USERDIR_);
		system((char *)Command);
		ClearThreadTimes(ProjectNo);
		sj=1;
	}
	else
	{
		GUI_Clear();
		GUI_DispStringAt((INT8U *)"δ����U��",8,24);
		Status_Bar();
		delay(2000);
		OldLevel = 0;
		delay(2000);
	}
	delay(2000);
	DelayTime = 0;
	while (1) {
		ClearThreadTimes(ProjectNo);
		delay(300);
		GUI_Clear();
		if (sj==1)
		{
			GUI_DispStringAt((INT8U *)"�������!!!",8,24);
			system("erm -f /user/updgwusb.sh");
		}
		else GUI_DispStringAt((INT8U *)"����ʧ��!!!",8,24);
		Status_Bar();

		keysele = KeySeleflag;
		KeySeleflag = 0;
		if (keysele != 0)
			DelayTime = 0;
		else
			DelayTime++;
		if (DelayTime >= PageDelayTime) {
			OldLevel = 0;
			return 0;
		}
		switch (keysele) {
		case 0:
			break;
		case 1:
			break;//���ϼ�
		case 2:
			break;//���¼�
		case 3:
			break;
		case 4:
			break;
		case 5:
			break;//ȷ�ϼ�
		case 6:
			OldLevel = 0;
			return 1;
			break;
		default:
			break;
		}
		 Lcmfull();
	}

	return 1;
}

int tryifconfig(char *ETH_NAME,INT8U *ip)
{
	  int   sock;
	  struct   sockaddr_in   sin;
	  struct   ifreq   ifr;
	  sock   =   socket(AF_INET,   SOCK_DGRAM,   0);
	  if   (sock   ==   -1)
	  {
		  SdPrint("socket error\n\r");
		  return   -1;
	  }
	  strncpy(ifr.ifr_name,   ETH_NAME,   IFNAMSIZ);
	  ifr.ifr_name[IFNAMSIZ   -   1]   =   0;
	  if (ioctl(sock,   SIOCGIFADDR,   &ifr)   <   0)
	  {
		  SdPrint("ioctl error\n\r");
		  return   -1;
	  }
	  memcpy(&sin,   &ifr.ifr_addr,   sizeof(sin));
	  SdPrint("\n\r %s   ip%d:   %s\n",   ETH_NAME, sin.sin_addr.s_addr,  inet_ntoa(sin.sin_addr));
	  sprintf((char *)ip,"%s",inet_ntoa(sin.sin_addr));
	  if (sin.sin_addr.s_addr >0)
	  {
		  return 1;
	  }
	  return 0;
}

int getIp(unsigned char SeleMenu) {
	INT8U ip1[100],ip2[100];
	INT8U keysele;
	unsigned int DelayTime;

	memset(ip1,0,100);
	memset(ip2,0,100);
#ifdef __linux__
	tryifconfig("eth0",ip1);
#else
	tryifconfig("en0",ip1);
#endif
	tryifconfig("ppp0",ip2);
	DelayTime = 0;
	while (1) {
		ClearThreadTimes(ProjectNo);
		delay(300);
		GUI_Clear();
		GUI_DispStringAt((INT8U *)"����-IP:",8,24);
		GUI_DispStringAt((INT8U *) ip1, 16, 40);
		GUI_DispStringAt((INT8U *)"GPRS-IP:",8,56);
		GUI_DispStringAt((INT8U *) ip2, 16, 72);
		Status_Bar();

		keysele = KeySeleflag;
		KeySeleflag = 0;
		if (keysele != 0)
			DelayTime = 0;
		else
			DelayTime++;
		if (DelayTime >= PageDelayTime) {
			OldLevel = 0;
			return 0;
		}
		switch (keysele) {
		case 0:
			break;
		case 1:
			break;//���ϼ�
		case 2:
			break;//���¼�
		case 3:
			break;
		case 4:
			break;
		case 5:
			break;//ȷ�ϼ�
		case 6:
			OldLevel = 0;
			return 1;
			break;
		default:
			break;
		}
		 Lcmfull();
	}
	return 1;
}
