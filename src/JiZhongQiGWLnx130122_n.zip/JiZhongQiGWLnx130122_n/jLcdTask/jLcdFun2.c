/*
 * jLcdFun.h
 *  jLcdTask�漰������Ҫ����
 *  Created on: 2009-9-12
 *      Author: ZhuRui
 */

#include <string.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include "time.h"
#include "PrintData.h"
#include "jLcdFun.h"
#include "jLcdTask.h"
#include <ctype.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <net/if.h>

extern void Print_sel_data(INT8U *date,INT8U *flag,INT8U x ,INT8U y,INT8U GuiYue);
extern void ClearThreadTimes(unsigned char ProjectID);
INT8U CjqnInf[PointMax][7];
extern INT8U MenuNums;
extern INT16U MeterNo;
extern INT8U gpioPROG_KEY_new, gpioPROG_KEY_old, gpioPROG_KEY_count;
int getNoLineCjq(unsigned char SeleMenu)
{
	INT8U keysele;
	char showstr[50];
	unsigned int DelayTime;
	int autoChaobiao_flag=0;
	DelayTime = 0;
	autoChaobiao_flag = JProgramInfo->BeginSouBiao & 0x01;
	while (1) {
		ClearThreadTimes(ProjectNo);
		delay(500);
		GUI_Clear();
		switch(autoChaobiao_flag)
		{
		case 0:
			memset(showstr, 0, 50);
			sprintf(showstr,"�����ѱ�: %s", "�ر�");
			break;
		case 1:
			memset(showstr, 0, 50);
			sprintf(showstr,"�����ѱ�: %s","��ʼ");
			break;
		default:
			memset(showstr, 0, 50);
			sprintf(showstr,"�����ѱ�: %s", "�ر�");
			break;
		}
		GUI_DispStringAt((INT8U *)showstr,16,72);
		keysele = KeySeleflag;
		KeySeleflag = 0;
		if (keysele != 0)
			DelayTime = 0;
		else
			DelayTime++;
		if (DelayTime >= PageDelayTime)
		{
			OldLevel = 0;
			return 0;
		}
		switch (keysele)
		{
		case 0:
			break;
		case 1:
			autoChaobiao_flag--;
			if(autoChaobiao_flag<0)
				autoChaobiao_flag = 1;
			break;//���ϼ�
		case 2:
			autoChaobiao_flag ++;
			if(autoChaobiao_flag>2)
				autoChaobiao_flag = 0;
			break;//���¼�
		case 3:
			break;
		case 4:
			break;
		case 5:
			JProgramInfo->BeginSouBiao = autoChaobiao_flag;
			GUI_DispStringAt((INT8U *)"�޸ĳɹ�",54,108);
			printf("\nJProgramInfo->BeginSouBiao =%d\n",JProgramInfo->BeginSouBiao);
//			memset(TempBuf,0,60);
//			sprintf((char*)TempBuf,"%s/JzhqPara.par",_PARADIR_);
//			NormalSaveFile((char*)TempBuf, &Jmemory->jzq, sizeof(Jmemory->jzq));
			break;//ȷ�ϼ�
		case 6:
			OldLevel = 0;
			return 1;
			break;
		default:
			break;
		}
		Lcmfull();
	}
	return 1;
}
int getNoNetCjq(unsigned char SeleMenu) {
	unsigned int DelayTime;
	INT8U cjqaddr[13],tj;
	INT16U i,keysele,page,j;
	char ln[256],tmp[256];
	int allnum=0,wxnum=0,jwxn=0;

	DelayTime=0;
	JProgramInfo->WirlessCrt=1;
	j=0;
	page=0;
	tj=0;
	memset(tmp,0,256);
	sprintf((char *)tmp,"%s/wx.txt",_USERDIR_);
    struct timespec tsspec;
    if (clock_gettime(CLOCK_REALTIME, &tsspec)==-1)
    	printf("clock_gettime error\n\r");
    tsspec.tv_sec += 3;
	sem_timedwait(&JProgramInfo->mainData.UseFileFlg,&tsspec);
	fp = fopen((char *)tmp,"r");
	if(fp!=NULL)
	{
		memset(ln,0,sizeof(ln));
		fscanf(fp,"%s",ln);
		if(strlen(ln)<5)
		{

		}
		else
		{
			if (sscanf(ln, "%d-%d-%d",&allnum, &wxnum,&jwxn))
			{

			}
		}
		fclose(fp);
		fp=NULL;
		sem_post(&JProgramInfo->mainData.UseFileFlg);
	}
	else sem_post(&JProgramInfo->mainData.UseFileFlg);
	while (1) {
		ClearThreadTimes(ProjectNo);
		delay(100);
		GUI_Clear();
		GUI_DispStringAt((INT8U *) "��:", 0, 144);
		GUI_DispDecAt(jwxn,24,144,2);
		GUI_DispStringAt((INT8U *) "-", 40, 144);
		GUI_DispDecAt(allnum,48,144,2);
		if (JProgramInfo->WirlessCrt==1)
			GUI_DispStringAt((INT8U *) "����ͳ����....!", 8, 24);
		else if ((JProgramInfo->WirlessCrt==0x10)||(tj==1))
		{
			tj=1;
			JProgramInfo->WirlessCrt=0;
			GUI_DispStringAt((INT8U *) "������ģ�鲻��ͳ��!", 8, 24);
		}
		else if (JProgramInfo->WirlessBuff[0]==0)
			GUI_DispStringAt((INT8U *) "û��δ�����Ĳɼ���!", 8, 24);
		else
		{
			if (JProgramInfo->WirlessBuff[0]%8==0)
				page=(JProgramInfo->WirlessBuff[0]/8);
			else page=(JProgramInfo->WirlessBuff[0]/8)+1;
			for (i=0;i<8;i++)
			{
				if (i+j*8<JProgramInfo->WirlessBuff[0])
				{
					memset(cjqaddr,0,13);
					sprintf((char *)cjqaddr,"%02x%02x%02x%02x%02x%02x",
							JProgramInfo->WirlessBuff[(i+j*8)*6+6],
							JProgramInfo->WirlessBuff[(i+j*8)*6+5],
							JProgramInfo->WirlessBuff[(i+j*8)*6+4],
							JProgramInfo->WirlessBuff[(i+j*8)*6+3],
							JProgramInfo->WirlessBuff[(i+j*8)*6+2],
							JProgramInfo->WirlessBuff[(i+j*8)*6+1]);
					GUI_DispStringAt((INT8U *) cjqaddr, 8, 16+16*i);
				}
			}
			GUI_DispStringAt((INT8U *) "δ������:", 64, 144);
			GUI_DispDecAt(JProgramInfo->WirlessBuff[0],136,144,2);
		}
		Status_Bar();

		keysele = KeySeleflag;
		KeySeleflag = 0;
		if (keysele != 0)
			DelayTime = 0;
		else
			DelayTime++;
		if (DelayTime >= PageDelayTime) {
			OldLevel = 0;
			return 0;
		}
		switch (keysele) {
		case 1:
			if (j == 0)
				j = page - 1;
			else
				j--;
			DelayTime = 0;
			break;//���ϼ�
		case 2:
			if (j == page - 1)
				j = 0;
			else
				j++;
			DelayTime = 0;
			break;//���¼�
		case 6:
			OldLevel = 0;
			return 0;
			break; //ȡ����
		default:
			break;
		}
		Lcmfull();
	}

	return 1;
}
/******************************************************************************************************************
 * �������ƣ�Bottom_Bar()
 * ��    �ܣ���������ʾͨѶ״̬ͼ��
 * ��ڲ�������
 * ���ڲ�������
 ******************************************************************************************************************/
void telephone1(int y,int x)//��ʾ�绰1
{
	unsigned char str[3];
	if (JProgramInfo->stateflags.work_zb == 1)
	{
		work_zb_delay = (work_zb_delay + 1)%4;
		if (work_zb_delay < 2)
		{
			memset(str,0,sizeof(str));
			str[0]=0x01;
		    GUI_DispStringAt(str, x, y);
		    str[0]=0x02;
		    GUI_DispStringAt(str, x+8, y);
		}
	}
    return ;
}
void telephone2(int y,int x)//��ʾ�绰2
{
	unsigned char str[3];
	if (JProgramInfo->stateflags.work_485I == 1)
	{
		work_485I_delay = (work_485I_delay + 1)%4;
		if (work_485I_delay<2)
		{
			memset(str,0,sizeof(str));
			str[0]=0x01;
			GUI_DispStringAt(str, x, y);
			str[0]=0x03;
			GUI_DispStringAt(str, x+8, y);
		}
	}
	return ;
}
void telephone3(int y,int x)//��ʾ�绰3
{
	unsigned char str[3];
	if (JProgramInfo->stateflags.work_485II == 1)
	{
		work_485II_delay = (work_485II_delay + 1)%4;
		if (work_485II_delay<2)
		{
			memset(str,0,sizeof(str));
			str[0]=0x01;
			GUI_DispStringAt(str, x, y);
			str[0]=0x04;
			GUI_DispStringAt(str, x+8, y);
		}
	}
	return ;
}
void telephone4(int y,int x )//��ʾ�绰4
{
	unsigned char str[3];
	if (JProgramInfo->stateflags.work_485III == 1)
	{
		work_485III_delay = (work_485III_delay + 1)%4;
		if (work_485III_delay<2)
		{
			memset(str,0,sizeof(str));
			str[0]=0x01;
			GUI_DispStringAt(str, x, y);
			str[0]=0x05;
			GUI_DispStringAt(str, x+8, y);
		}
	}
	return ;
}
void ethernetwork(int y,int x)//��ʾ��̫��ͨѶ
{
	unsigned char str[3];
	if (JProgramInfo->stateflags.work_ethernet == 1)
	{
		work_ethernet_delay = (work_ethernet_delay + 1)%4;
		if (work_ethernet_delay<2)
		{
			memset(str,0,sizeof(str));
			str[0]=0x06;
			GUI_DispStringAt(str, x, y);
			str[0]=0x07;
			GUI_DispStringAt(str, x+8, y);
		}
	}
	return ;
}
void weihuwork(int y,int x)//ά����ͨѶ
{
	unsigned char str[3];
	if (JProgramInfo->stateflags.work_weihu==1)
	{
		work_weihu_delay = (work_weihu_delay + 1)%4;
		if (work_weihu_delay<2)
		{
			memset(str,0,sizeof(str));
			str[0]=0x08;
			GUI_DispStringAt(str, x, y);
			str[0]=0x09;
			GUI_DispStringAt(str, x+8, y);
		}
	}
	return ;
}
void usbwork(int y,int x)//USB
{
	unsigned char str[3];
	if (JProgramInfo->stateflags.work_usb==1)
	{
		work_usb_delay = (work_usb_delay + 1)%4;
		if (work_usb_delay<2)
		{
			memset(str,0,sizeof(str));
			str[0]=0x0C;
			GUI_DispStringAt(str, x, y);
			str[0]=0x12;
			GUI_DispStringAt(str, x+8, y);
		}
	}
	return ;
}
void sdcwork(int y,int x)//��ʾSD��
{
	unsigned char str[3];
	if (JProgramInfo->stateflags.work_sdc==1)
	{
		work_sdc_delay = (work_sdc_delay + 1)%4;
		if (work_sdc_delay<2)
		{
			memset(str,0,sizeof(str));
			str[0]=0x0E;
			GUI_DispStringAt(str, x, y);
			str[0]=0x0F;
			GUI_DispStringAt(str, x+8, y);
		}
	}
	return;
}
void gprswork(int y,int x)
{
	unsigned char str[3];
	if (JProgramInfo->stateflags.work_gprs==1)
	{
		work_gprs_delay = (work_gprs_delay + 1)%4;
		if (work_gprs_delay<2)
		{
			memset(str,0,sizeof(str));
			str[0]=0x11;
			GUI_DispStringAt(str, x, y);
			str[0]=0x0B;
			GUI_DispStringAt(str, x+8, y);
		}
	}
	return;
}


void ProgramButtonShow(int y,int x)//��̼���ʾ
{
	int i;
	gpioPROG_KEY_new = gpio_read("gpiPROG_KEY");
	TS program_ts;

	if(gpioPROG_KEY_new != gpioPROG_KEY_old)
	{
		if(gpioPROG_KEY_new == 1)
		{
			gpioPROG_KEY_count++;
			JProgramInfo->stateflags.ProgramButton = 1;
			if(gpioPROG_KEY_count%2==0)
			{
				fprintf(stderr,"\ngpioPROG_KEY_count =%d", gpioPROG_KEY_count);
				gpioPROG_KEY_count = 0;
				JProgramInfo->stateflags.ProgramButton = 0;
				if(access("/nand/para/f165.par",0)!=0)
				{
					//NormalSaveFile("/nand/para/f165.par", &f165, sizeof(F165_t));
					if(JProgramInfo->FileSaveFlag.level1flag==0)
						JProgramInfo->FileSaveFlag.level1flag=1;

				}
				NormalReadFile("/nand/para/f165.par", &f165, sizeof(F165_t),JProgramInfo);
				f165.program_count++;
				if(f165.program_count > 65535)
					f165.program_count = 0;
				TSGet(&program_ts);
				f165.program_ts = program_ts;
//				NormalSaveFile("/nand/para/f165.par", &f165, sizeof(F165_t));
				if(JProgramInfo->FileSaveFlag.level1flag==0)
					JProgramInfo->FileSaveFlag.level1flag=1;

			}
		}
		gpioPROG_KEY_old = gpioPROG_KEY_new;

	}

	if (JProgramInfo->stateflags.ProgramButton ==1)
	{
		{
			int jiao = y*160 + 128;
			int nn = 0;
			int j;
			for (j=0;j<3;j++)
			{
				nn = jiao + 160*j;
				for(i=nn;i<nn+15;i++)
					LcdBuf[i] = 0x1;
			}
			nn = nn + 160 + 160;
			LcdBuf[nn+0] = 0x0;
			LcdBuf[nn+1] = 0x1;
			LcdBuf[nn+2] = 0x1;
			LcdBuf[nn+3] = 0x1;
			LcdBuf[nn+4] = 0x0;

			LcdBuf[nn+160+0] = 0x1;
			LcdBuf[nn+160+1] = 0x1;
			LcdBuf[nn+160+2] = 0x1;
			LcdBuf[nn+160+3] = 0x1;
			LcdBuf[nn+160+4] = 0x1;

			LcdBuf[nn+160+160+0] = 0x1;
			LcdBuf[nn+160+160+1] = 0x1;
			LcdBuf[nn+160+160+2] = 0x1;
			LcdBuf[nn+160+160+3] = 0x1;
			LcdBuf[nn+160+160+4] = 0x1;

			LcdBuf[nn+160+160+160+0] = 0x0;
			LcdBuf[nn+160+160+160+1] = 0x1;
			LcdBuf[nn+160+160+160+2] = 0x1;
			LcdBuf[nn+160+160+160+3] = 0x1;
			LcdBuf[nn+160+160+160+4] = 0x0;
//-----------------------------------------
			nn = nn +10;
			LcdBuf[nn+0] = 0x0;
			LcdBuf[nn+1] = 0x1;
			LcdBuf[nn+2] = 0x1;
			LcdBuf[nn+3] = 0x1;
			LcdBuf[nn+4] = 0x0;

			LcdBuf[nn+160+0] = 0x1;
			LcdBuf[nn+160+1] = 0x1;
			LcdBuf[nn+160+2] = 0x1;
			LcdBuf[nn+160+3] = 0x1;
			LcdBuf[nn+160+4] = 0x1;

			LcdBuf[nn+160+160+0] = 0x1;
			LcdBuf[nn+160+160+1] = 0x1;
			LcdBuf[nn+160+160+2] = 0x1;
			LcdBuf[nn+160+160+3] = 0x1;
			LcdBuf[nn+160+160+4] = 0x1;

			LcdBuf[nn+160+160+160+0] = 0x0;
			LcdBuf[nn+160+160+160+1] = 0x1;
			LcdBuf[nn+160+160+160+2] = 0x1;
			LcdBuf[nn+160+160+160+3] = 0x1;
			LcdBuf[nn+160+160+160+4] = 0x0;

		}
	}
	return ;
}
extern INT8U MaiChongStat;
void WeiGai_show()
{
	TS weigai_ts;
	TSGet(&weigai_ts);
	F165_t f165;
	if((JProgramInfo->currYXSTAT&0x04) !=  MaiChongStat)
	{
		if((JProgramInfo->currYXSTAT&0x04) == 0x04)
		{
			memset(&f165, 0, sizeof(F165_t));
			if(access("/nand/para/f165.par",0)!=0)
			{
				//NormalSaveFile("/nand/para/f165.par", &f165, sizeof(F165_t));
				if(JProgramInfo->FileSaveFlag.level1flag==0)
					JProgramInfo->FileSaveFlag.level1flag=1;
			}
			NormalReadFile("/nand/para/f165.par", &f165, sizeof(F165_t),JProgramInfo);
			f165.weigai_count++;
			if(f165.weigai_count>65535)
				f165.weigai_count = 0;
			f165.weigai_ts = weigai_ts;
//			NormalSaveFile("/nand/para/f165.par", &f165, sizeof(F165_t));
			if(JProgramInfo->FileSaveFlag.level1flag==0)
				JProgramInfo->FileSaveFlag.level1flag=1;
		}
		MaiChongStat = JProgramInfo->currYXSTAT&0x04;
	}
}
void Bottom_Bar(void)
{
	int stepx=0;

	unsigned int i;
		for (i = 23040; i < 25600; i++) 	LcdBuf[i] = 0x0;

	ethernetwork(145,stepx);//��̫��
	stepx = stepx + 16;

	weihuwork(145,stepx);	//ά���ڹ���
	stepx = stepx + 16;

	gprswork(145,stepx);	//GPRS�շ�
	stepx = stepx + 16;

	telephone1(145,stepx);	//�ز�ͨѶ
	stepx = stepx + 16;

	telephone2(145,stepx);	//485 I  ͨѶ
	stepx = stepx + 16;

	telephone3(145,stepx);	//485 II ͨѶ
	stepx = stepx + 16;

	telephone4(145,stepx);	//485 IIIͨѶ
	stepx = stepx + 16;

	usbwork(145,stepx);		//USB�ڲ���
	stepx = stepx + 16;

	sdcwork(145,stepx);		//SD������
	ProgramButtonShow(150,stepx);//��̼�

	WeiGai_show();
}

/******************************************************************************************************************
 * �������ƣ�Status_Bar()
 * ��    �ܣ�״̬������Ϊ��������ʾ�ź�ǿ�ȣ�ͨѶ��ʽ���澯�¼��빦�������ԣ�ʱ�䣫����
 * ��ڲ������ޡ�����������������ʾ���˵�ѡ��Ĳ˵�������ҳ��־
 * ���ڲ�������
 ******************************************************************************************************************/
void Status_Bar(void) {
	unsigned char str[3];
	INT8U TERC[64];
	INT8U Warning, Warn[64];//�澯�¼���־
	INT16U MeterNum;
	TS ts;
	//delay(500);
	TSGet(&ts);
	if (JProgramInfo->LunFlg == 1) {
		initMeterPare();
		LunXunFlag=0;
		if (initHisDate() == 1)
			LunXunFlag = 1;
		JProgramInfo->LunFlg = 0;
	}
	memset(str, 0, sizeof(str));
	memset(TERC, 0, sizeof(TERC));
	memset(Warn, 0, sizeof(Warn));
	Warning = 0;
	/*************************��ʾʱ��***************************��ʼ**/
	GUI_DispDecAt(ts.Hour, 120, 0, 2); //96
	GUI_DispDecAt(ts.Minute, 144, 0, 2);//120
	//GUI_DispDecAt(ts.Sec, 144, 0, 2);
	//GUI_DispStringAt((INT8U *) ":", 112, 0);
	GUI_DispStringAt((INT8U *) ":", 136, 0);

#if 0
	JDataFileInfo->DayRunTj.GprsCSQ=20;
	JProgramInfo->Gprs_ok=1;
	JProgramInfo->stateflags.ErcFlg=23;
	JProgramInfo->CurrErc.Buff[0]=23;
#endif
	/*************************��ʾʱ��***************************����**/

	/*************************��ʾ�ź�ǿ��************************��ʼ**/

	//str[0] = 0x1c;
	//GUI_DispStringAt(str, 0, 0);//��ʾ����
	if (JDataFileInfo->DayRunTj.GprsCSQ >= 24) {
		GUI_DrawVLine(18, 2, 13);
		GUI_DrawVLine(17, 2, 13);
	}
	if (JDataFileInfo->DayRunTj.GprsCSQ >= 16) {
		GUI_DrawVLine(15, 5, 13);
		GUI_DrawVLine(14, 5, 13);
	}
	if (JDataFileInfo->DayRunTj.GprsCSQ >= 8) {
		GUI_DrawVLine(12, 8, 13);
		GUI_DrawVLine(11, 8, 13);
	}
	if (JDataFileInfo->DayRunTj.GprsCSQ > 0) {
		GUI_DrawVLine(9, 10, 13);
		GUI_DrawVLine(8, 10, 13);
	}
	if (MeterNo>=meterCount)
		MeterNum=0;
	else
		MeterNum=getPoint(TempMeterPara[MeterNo].CJQ_hao-1, TempMeterPara[MeterNo].DNB_hao);

	if (MeterNum>999)
	{
		GUI_DispDecAt(MeterNum, 80, 0, 4);
		GUI_DrawVLine(79, 0, 14);
		GUI_DrawHLine(79, 0, 112);

		GUI_DrawVLine(112, 0, 14);
		GUI_DrawHLine(79, 14, 112);
	}
	else if (MeterNum>99)
	{
		GUI_DispDecAt(MeterNum, 87, 0, 3);
		GUI_DrawVLine(86, 0, 14);
		GUI_DrawHLine(86, 0, 112);

		GUI_DrawVLine(112, 0, 14);
		GUI_DrawHLine(86, 14, 112);
	}
	else
	{
		GUI_DispDecAt(MeterNum, 95, 0, 2);
		GUI_DrawVLine(94, 0, 14);
		GUI_DrawHLine(94, 0, 112);

		GUI_DrawVLine(112, 0, 14);
		GUI_DrawHLine(94, 14, 112);
	}

	/*************************��ʾ�ź�ǿ��*************** *********����**/
	/*************************��ʾͨ�ŷ�ʽ GPRS TCp CDMA *********��ʼ**/
	//��ʾGΪGprs ͨѶ��ʽ
	if (JProgramInfo->stateflags.LoginOk == GPRS_COM) {
		memset(str, 0, sizeof(str));
		str[0] = 0x1e;
		GUI_DispStringAt(str, 25, 0);//x+8
	}
//	if (JProgramInfo->jzq_login == GPRS_COM) {
//		memset(str, 0, sizeof(str));
//		str[0] = 0x1e;
//		GUI_DispStringAt(str, 25, 0);//x+8
//	}
//	else if (JProgramInfo->jzq_login == NET_COM) {
//		memset(str, 0, sizeof(str));
//		str[0] = 0x1f;
//		GUI_DispStringAt(str, 25, 0);//x+8
//	}
//	else if (JProgramInfo->jzq_login == SER_COM) {
//		memset(str, 0, sizeof(str));
//		str[0] = 0x53;
//		GUI_DispStringAt(str, 25, 0);//x+8
//	}
	//GUI_DrawHLine( 22, 0, 34);//
	//GUI_DrawVLine( 22, 0, 14);//
	//GUI_DrawVLine( 34, 0, 14);//
	/*************************��ʾͨ�ŷ�ʽ��� GPRS PSDN CDMA *********����**/
	/*************************��ʾ**�澯�¼���̾�ţ��루�¼������룩����***��ʼ**/
	if (JProgramInfo->stateflags.ErcFlg >= 1) {
		//GUI_DispStringAt((INT8U *)"  ", 39, 0);
		//��ʾ̾��
		if (ts.Sec % 4 == 0) {
			GUI_DispDecAt(JProgramInfo->stateflags.ErcFlg, 39, 0, 2);
		}
		else if (ts.Sec % 2 == 0) {
			memset(str, 0, sizeof(str));
			str[0] = 0x7b;
			str[1] = 0x7c;
			GUI_DispStringAt(str, 39, 0);
		}
	}
	/*************************��ʾ**�澯�¼���̾�ţ��루�¼������룩����***����**/
	/*************************��ʾ**������̾�ţ��루�¼������룩����***��ʼ**/
	if (JProgramInfo->Para.State485_3 > 0 && JProgramInfo->Para.State485_2 > 0 && JProgramInfo->Para.State485_1 > 0)//Com485����ָʾ����
	{
		//��ʾ̾��
		//GUI_DispDecAt(485, 55, 0, 3);

	}

	GUI_DrawHLine(0, 15, 159); //(x,y,y1)��������
	GUI_DrawHLine(0, 143, 159); //��������
	if(Status_bar_style==0)
		Bottom_Bar();
}
/******************************************************************************************************************
 * �������ƣ�Modify_TxCanShu()�����ڵڶ����˵�
 * ��    �ܣ����޸ġ����ġ���ͨ�Ų�����������ͨѶIP��˿ڣ�APN�������룬��������ַ
 * ��ڲ�������
 * ���ڲ�������
 *******************************************************************************************************************/
int Modify_TxCanShu(INT8U SeleMenu)
{
	INT8U keysele, i, j = 0, flag255 = 0;
	unsigned char TempBuf1[32], TempBuf[6];
	unsigned char temp[16];
	unsigned int DelayTime;
	unsigned char IPport[3], tempIPadd[8];
	unsigned char IPport1[3],tempIPadd1[8],typeTmp;
	INT8U modetype;

	memset(TempBuf1, 0, 32);
	GUI_Clear();
	DelayTime = 0;
	GUI_DispStringAt((INT8U *) "��IP��˿�", 0, 16);
	GUI_DispStringAt((INT8U *) "�����APN", 0, 48);
	GUI_DispStringAt((INT8U *) "��IP��˿�", 0, 80);
	GUI_DispStringAt((INT8U *) "ͨ��ģʽ", 0, 112);
	GUI_DispCharAt('.', 24, 32);
	GUI_DispCharAt('.', 52, 32);
	GUI_DispCharAt('.', 80, 32);
	GUI_DispStringAt((INT8U *) ":", 112, 32);
	GUI_DispCharAt('.', 24, 96);
	GUI_DispCharAt('.', 52, 96);
	GUI_DispCharAt('.', 80, 96);
	GUI_DispStringAt((INT8U *) ":", 112, 96);

	while (1) {
		ClearThreadTimes(ProjectNo);
		Status_Bar();
		//��ʾ��ͨѶIP��˿�
		GUI_DispDecAt(JParamInfo3761->group1.f3.IP[3], 0, 32, 3);
		GUI_DispDecAt(JParamInfo3761->group1.f3.IP[2], 28, 32, 3);
		GUI_DispDecAt(JParamInfo3761->group1.f3.IP[1], 56, 32, 3);
		GUI_DispDecAt(JParamInfo3761->group1.f3.IP[0], 84, 32, 3);
		memset(TempBuf, 0, 6);
		sprintf((char *) TempBuf, "%05d",((JParamInfo3761->group1.f3.PortAddress[1] << 8)+ JParamInfo3761->group1.f3.PortAddress[0]));
		GUI_DispStringAt(TempBuf, 120, 32);
		//��ʾ��ͨѶIP��˿�
		GUI_DispDecAt(JParamInfo3761->group1.f3.IP1[3], 0, 96, 3);
		GUI_DispDecAt(JParamInfo3761->group1.f3.IP1[2], 28, 96, 3);
		GUI_DispDecAt(JParamInfo3761->group1.f3.IP1[1], 56, 96, 3);
		GUI_DispDecAt(JParamInfo3761->group1.f3.IP1[0], 84, 96, 3);
		memset(TempBuf, 0, 6);
		sprintf((char *) TempBuf, "%05d",((JParamInfo3761->group1.f3.PortAddress1[1] << 8)+ JParamInfo3761->group1.f3.PortAddress1[0]));
		GUI_DispStringAt(TempBuf, 120, 96);
		//��ʾAPN
		j=0;
		memset(temp, 0x00, 16);
		for (i = 0; i < 16; i++) {
			if ((JParamInfo3761->group1.f3.APN[15 - i] != 0xff)&&(JParamInfo3761->group1.f3.APN[15 - i] != 0x00))
				temp[j++] = JParamInfo3761->group1.f3.APN[15 - i];
		}
		j=0;
		GUI_DispStringAt(temp, 0, 64);
		//��ʾͨ��ģʽ
		{
			modetype = (JParamInfo3761->group1.f8.Type & 0b00110000)>>4;
			if (modetype == 0)
				GUI_DispStringAt((INT8U *) "ͨ�����ͣ����ģʽ", 0, 112);
			else if (modetype == 1)
				GUI_DispStringAt((INT8U *) "ͨ�����ͣ��ͻ�ģʽ", 0, 112);
			else
				GUI_DispStringAt((INT8U *) "ͨ�����ͣ�����ģʽ", 0, 112);
			GUI_DispDecAt(modetype, 120, 126, 1);//ģʽ��ʶ  0  1  2
		}
		keysele = KeySeleflag;
		KeySeleflag = 0;
		if (keysele != 0)
			DelayTime = 0;
		else
			DelayTime++;
		if (DelayTime >= PageDelayTime) {
			OldLevel = 0;
			return 0;
		}
		switch (keysele) {
		case 5: //ȷ����
		{
			memset(NowInput.buf, 0, 128);
			sprintf((char*) NowInput.buf, "%03d%03d%03d%03d%05d",JParamInfo3761->group1.f3.IP[3], JParamInfo3761->group1.f3.IP[2],JParamInfo3761->group1.f3.IP[1], JParamInfo3761->group1.f3.IP[0],((JParamInfo3761->group1.f3.PortAddress[1] << 8)+ JParamInfo3761->group1.f3.PortAddress[0]));
			memcpy(&NowInput.buf[17], temp, 16);
			sprintf((char*) &NowInput.buf[33], "%03d%03d%03d%03d%05d",JParamInfo3761->group1.f3.IP1[3], JParamInfo3761->group1.f3.IP1[2],JParamInfo3761->group1.f3.IP1[1], JParamInfo3761->group1.f3.IP1[0],((JParamInfo3761->group1.f3.PortAddress1[1] << 8)+ JParamInfo3761->group1.f3.PortAddress1[0]));
			sprintf((char*) &NowInput.buf[50],"%d",modetype);
			i = 0;
			while (i < 3) {//ip-1
				NowInput.col[i] = 32;
				NowInput.row[i] = 0 + i * 8;//56
				NowInput.set[i] = 1;
				i++;
			}
			i = 0;
			while (i < 3) {//ip-2
				NowInput.col[i + 3] = 32;
				NowInput.row[i + 3] = 28 + i * 8;//84
				NowInput.set[i + 3] = 1;
				i++;
			}
			i = 0;
			while (i < 3) {//ip-3
				NowInput.col[i + 6] = 32;
				NowInput.row[i + 6] = 56 + i * 8;//112
				NowInput.set[i + 6] = 1;
				i++;
			}
			i = 0;
			while (i < 3) {//ip-4
				NowInput.col[i + 9] = 32;
				NowInput.row[i + 9] = 84 + i * 8;//140
				NowInput.set[i + 9] = 1;
				i++;
			}
			i = 0;
			while (i < 5) {//port
				NowInput.col[i + 12] = 32;
				NowInput.row[i + 12] = 120 + i * 8;
				NowInput.set[i + 12] = 1;
				i++;
			}
			i = 0;
			j = 2;
			for (i = 0; i < 16; i++) {//APN
				if (temp[i] != 0)
					j++;
				else
					break;
			}
			if (j < 16) {
				for (i = 1; i <= 17 - j; i++) //���ַ������һ���ַ��̶�Ϊ\0��NowInput.buf[15]=0��
				{
					NowInput.buf[32 - i] = 32; //���ַ�������Ķ���ʱ�ÿո�32������
				}
			}
			i = 0;
			while (i < 16) {

				NowInput.col[i + 17] = 64;
				NowInput.row[i + 17] = 0 + i * 8;
				NowInput.set[i + 17] = 3;
				i++;
			}
			//-----------------
			i = 0;
			while (i < 3) {//ip2-1
				NowInput.col[i+33] = 96;
				NowInput.row[i+33] = 0 + i * 8;//56
				NowInput.set[i+33] = 1;
				i++;
			}
			i = 0;
			while (i < 3) {//ip2-2
				NowInput.col[i + 36] = 96;
				NowInput.row[i + 36] = 28 + i * 8;//84
				NowInput.set[i + 36] = 1;
				i++;
			}
			i = 0;
			while (i < 3) {//ip2-3
				NowInput.col[i + 39] = 96;
				NowInput.row[i + 39] = 56 + i * 8;//84
				NowInput.set[i + 39] = 1;
				i++;
			}
			i = 0;
			while (i < 3) {//ip2-4
				NowInput.col[i + 42] = 96;
				NowInput.row[i + 42] = 84 + i * 8;//84
				NowInput.set[i + 42] = 1;
				i++;
			}
			i = 0;
			while (i < 5) {//port2
				NowInput.col[i + 45] = 96;
				NowInput.row[i + 45] = 120 + i * 8;
				NowInput.set[i + 45] = 1;
				i++;
			}
			NowInput.col[50] = 126;//ģʽ����   0 ���   1�ͻ�   2����
			NowInput.row[50] = 120;
			NowInput.set[50] = 1;

			NowInput.AllNum = 52;//17+16+17+1+1
			if (ScreenInput() == 1)//�в����޸���
			{
				memset(tempIPadd, 0, 8);
				memset(tempIPadd1, 0, 8);
				for (i = 0; i < 4; i++)
				{
					tempIPadd[3 - i] = GetNum(&NowInput.buf[3* i ], 3, 1)& 0xff;
					if (GetNum(&NowInput.buf[3* i ], 3, 1) > 255)
						flag255 = 1;
				}
				for (i = 0; i < 4; i++)
				{
					tempIPadd1[3 - i] = GetNum(&NowInput.buf[3* i +33], 3, 1)& 0xff;
					if (GetNum(&NowInput.buf[3* i +33], 3, 1) > 255)
						flag255 = 1;
				}
				if (flag255 == 0)
				{
					IPport[0] = GetNum(&NowInput.buf[12], 5, 1) & 0xff;
					IPport[1] = (GetNum(&NowInput.buf[12], 5, 1) >> 8) & 0xff;
					IPport1[0] = GetNum(&NowInput.buf[45], 5, 1) & 0xff;
					IPport1[1] = (GetNum(&NowInput.buf[45], 5, 1) >> 8) & 0xff;

					memcpy(TempBuf1, &NowInput.buf[17], 16);//apn
					typeTmp = GetNum(&NowInput.buf[50],1,1) ; //ģʽ����
					//printf("\n========typeTmp=%d",typeTmp);
					if ((typeTmp==0)||(typeTmp==1)||(typeTmp==2))
					{
						modetype = typeTmp;
					}

					memset(NowInput.buf, 0, 128);
					memcpy(&NowInput.buf[0], "N", 1); //��ʼ��ԭʼֵ
					i = 0;
					GUI_DispStringAt((INT8U *) "�����Ƿ񱣴�?Y/N", 0, 144);
					while (i < 1) {
						NowInput.col[i] = 144;
						NowInput.row[i] = 136 + i * 8;
						NowInput.set[i] = 4;
						i++;
					}
					NowInput.AllNum = 1;
					if (ScreenInput() == 1)//��������
					{
						if (NowInput.buf[0] == 'Y') {

							for (i = 0; i < 4; i++) {
								//printf("%d--\n\r",tempIPadd[3 - i]);
								if (JParamInfo3761->group1.f3.IP[i] != tempIPadd[i]) {
									flag255 = 1;
									break;
								}
							}

							memcpy(&JParamInfo3761->group1.f3.IP[0], &tempIPadd[0], 4);
							memcpy(&JParamInfo3761->group1.f3.PortAddress[0],&IPport[0], 2);

							memcpy(&JParamInfo3761->group1.f3.IP1[0], &tempIPadd1[0], 4);
							memcpy(&JParamInfo3761->group1.f3.PortAddress1[0],&IPport1[0], 2);

							if (strcmp((char *) JParamInfo3761->group1.f3.APN,(char *) TempBuf1) != 0)
								flag255 = 1;

							for (i = 0; i < 16; i++) {
								JParamInfo3761->group1.f3.APN[i] = TempBuf1[15 - i];
								if (TempBuf1[15 - i] == 32) {
									JParamInfo3761->group1.f3.APN[i] = 0;
								}
							}

							modetype = (modetype << 4);
							printf("\n save mode=%02x  Type=%02x",modetype,JParamInfo3761->group1.f8.Type);
							JParamInfo3761->group1.f8.Type = (JParamInfo3761->group1.f8.Type & 0b11001111) | modetype;
							printf("\n save mode=%02x  Type=%02x",modetype,JParamInfo3761->group1.f8.Type);
							printf("\n");
							if (flag255 == 1)
							{
								write_apn();
								JProgramInfo->Gprs_ok = 0;
							}
//							memset(TempBufn,0,60);
//							sprintf((char*)TempBufn,"%s/JzhqParaN.par",_PARADIR_);
//							NormalSaveFile((char*)TempBufn, &Jmemory->jzq, sizeof(Jmemory->jzq));
							if(JProgramInfo->FileSaveFlag.g1flag==0)
								JProgramInfo->FileSaveFlag.g1flag=1;
							delay(100);
							//JProgramInfo->Para.ChangedJiZhongQiInfo = 2;//lcy2013.1.11
							//ˢ����ʾ�Ĳ���
							//��ʾ��ͨѶIP��˿�
							GUI_DispDecAt(JParamInfo3761->group1.f3.IP[3], 0, 32, 3);
							GUI_DispDecAt(JParamInfo3761->group1.f3.IP[2], 28, 32, 3);
							GUI_DispDecAt(JParamInfo3761->group1.f3.IP[1], 56, 32, 3);
							GUI_DispDecAt(JParamInfo3761->group1.f3.IP[0], 84, 32, 3);
							sprintf((char*) TempBuf, "%05d", ((IPport[1] << 8) + IPport[0])); //����ת����Ϊ�ַ���
							GUI_DispStringAt(TempBuf, 120, 32);
							//��ʾ��ͨѶIP��˿�
							GUI_DispDecAt(JParamInfo3761->group1.f3.IP1[3], 0, 96, 3);
							GUI_DispDecAt(JParamInfo3761->group1.f3.IP1[2], 28, 96, 3);
							GUI_DispDecAt(JParamInfo3761->group1.f3.IP1[1], 56, 96, 3);
							GUI_DispDecAt(JParamInfo3761->group1.f3.IP1[0], 84, 96, 3);
							memset(TempBuf, 0, 6);
							sprintf((char *) TempBuf, "%05d",((JParamInfo3761->group1.f3.PortAddress1[1] << 8)+ JParamInfo3761->group1.f3.PortAddress[0]));
							GUI_DispStringAt(TempBuf, 120, 96);
							//��ʾAPN
							j=0;
							memset(temp, 0x00, 16);
							for (i = 0; i < 16; i++) {
								if ((JParamInfo3761->group1.f3.APN[15 - i] != 0xff)&&(JParamInfo3761->group1.f3.APN[15 - i] != 0x00))
									temp[j++] = JParamInfo3761->group1.f3.APN[15 - i];
							}
							j=0;
							GUI_DispStringAt(temp, 0, 64);//��ʾAPN

							{
								modetype = (JParamInfo3761->group1.f8.Type & 0b00110000)>>4;
								if (modetype == 0)
									GUI_DispStringAt((INT8U *) "ͨ�����ͣ����ģʽ", 0, 112);
								else if (modetype == 1)
									GUI_DispStringAt((INT8U *) "ͨ�����ͣ��ͻ�ģʽ", 0, 112);
								else
									GUI_DispStringAt((INT8U *) "ͨ�����ͣ�����ģʽ", 0, 112);
							}

							GUI_DispStringAt((INT8U *) "                  ", 0,	144);
							GUI_DispStringAt((INT8U *) "��������ɹ�!", 32, 144);
						}
					} else {
						GUI_DispStringAt((INT8U *) "                  ", 0, 144);
					}
				} else
				{
					GUI_DispStringAt((INT8U *) "IP��ַ��ʽ����!", 0, 144);
				}

			}
		}
			break;
		case 6: //ȡ����
		{
			OldLevel = 0;
			return 0;
		}
			break;
		default:
			break;
		}
		Lcmfull();
		flag255 = 0;
	}
	return 0;
}
/******************************************************************************************************************
 * �������ƣ�Set_TX_Para()�����ڵڶ����˵�
 * ��    �ܣ����޸Ĳ�����������������������룬��֤�ɹ��󣬽����޸Ĳ˵�
 * ��ڲ�������
 * ���ڲ�������
 *******************************************************************************************************************/
int Set_TX_Para(INT8U SeleMenu) {
	INT8U i, j, flag;
	unsigned char TempPass[7], SavePass[4], JmPass[7];
	memset(NowInput.buf, 0, 128);
	sprintf((char*) NowInput.buf, "%06d", 0); //����ת����Ϊ�ַ���
	i = 0;
	GUI_Clear();
	GUI_DrawHLine(24, 32, 132);
	GUI_DrawVLine(24, 32, 96);
	GUI_DrawVLine(132, 32, 96);
	GUI_DrawHLine(24, 96, 132);
	GUI_DispStringAt((INT8U *) "����������", 36, 48);

	while (i < 6) {
		NowInput.col[i] = 64;
		NowInput.row[i] = 56 + i * 8;
		NowInput.set[i] = 1;
		i++;
	}
	NowInput.AllNum = 7;
	flag = ScreenInput();
	if (flag == 1 || flag == 0)
	{
		//�ж������Ƿ���ȷ����ȷ�Ļ����������޸�ҳ��
		//printf( "\n\rThe ssssssssssssss is %d:\n\r",GetNum(NowInput.buf,6,1));
		memcpy(TempPass, &NowInput.buf[0], 6);
		for (i = 0; i < 3; i++) {
			SavePass[i] = JParamInfo3761->group1.f7.PassWords[2 - i];
		}
		BCDToASC(SavePass, 3, &JmPass[0]);
		printf( "\n\rThe TempPass  %s  JmPass %s\n\r",TempPass,JmPass);
		if (memcmp(TempPass, JmPass, 6) == 0) {
			MenuSele = 9;
		} else if (memcmp(TempPass, "666666", 6) == 0) {
			memset(JParamInfo3761->group1.f7.PassWords,0x00,20);			//����
		    //JParamInfo3761->group1.f7.PassWords[2]=0x10;			    //�Ϻ���������ʼ����Ϊ000000 //lcy2013
			//lcy2013.1.11
			//JProgramInfo->Para.ChangedJiZhongQiInfo=2;
			if(JProgramInfo->FileSaveFlag.g1flag==0)
				JProgramInfo->FileSaveFlag.g1flag=1;
			delay(3000);
			MenuSele = 9;
		} else {
			MenuSele = 1;
		}
		GUI_Clear();
		if (MenuSele == 1) {
			GUI_DrawHLine(24, 92, 132);
			GUI_DrawVLine(24, 92, 122);
			GUI_DrawVLine(132, 92, 122);
			GUI_DrawHLine(24, 122, 132);
			GUI_DispStringAt((INT8U *) "�������!", 45, 100);
			delay(1000);
		}
		delay(300);
		GUI_Clear();
		for (j = 0; j < MenuNums; j++) {
			if (Menu[j].level == Menu[MenuSele].level) {
				GUI_DispStringAt((INT8U *) Menu[j].Str, Menu[j].row,
						Menu[j].col);
			}
		}

	} else {
		MenuSele = 1;
		GUI_Clear();
		for (j = 0; j < MenuNums; j++) {

			if (Menu[j].level == Menu[MenuSele].level) {
				GUI_DispStringAt((INT8U *) Menu[j].Str, Menu[j].row,
						Menu[j].col);
			}
		}
	}
	return 0;

}
/******************************************************************************************************************
 * �������ƣ�Modify_TxCanShu()�����ڵ������˵�
 * ��    �ܣ����޸ġ����ġ����������������ʱ���������
 * ��ڲ�������
 * ���ڲ�������
 *******************************************************************************************************************/
void Modify_DBCanShu(INT8U CJQ_hao, INT8U DNB_hao) {
	INT8U keysele, i, DelayTime, GuiYueHao = 0;
	unsigned char tempAdd[13], Badd[7], tempMadd[7];
	unsigned char tempAddc[13], Baddc[7], tempMaddc[7];
	INT8U P_Type, DuanKou, BoTe, JiaoYan, ShuJu, GuiYue;

	DelayTime = 0;
	GUI_Clear();
	GUI_DispStringAt((INT8U *) "������:", 0, 16);
	GUI_DispStringAt((INT8U *) "�˿ں�:", 0, 32);
	GUI_DispStringAt((INT8U *) "������:", 0, 48);
	GUI_DispStringAt((INT8U *) "У��λ:", 0, 64);
	GUI_DispStringAt((INT8U *) "����λ:", 0, 80);
	GUI_DispStringAt((INT8U *) "��Լ��:", 0, 96);
	GUI_DispStringAt((INT8U *) "����ַ:", 0, 112);
	GUI_DispStringAt((INT8U *) "�ɵ�ַ:", 0, 128);
	for (i = 0; i < 6; i++) {
		Badd[5 - i]
				= JParamInfo3761->group2.f10[getPoint(CJQ_hao, DNB_hao)].Address[i];
	}
	BCDToASC(&Badd[0], 6, tempAdd);
	for (i = 0; i < 4; i++) {
		Baddc[3 - i]
				= JParamInfo3761->group2.f10[getPoint(CJQ_hao, DNB_hao)].CaijiqiAddress[i];
	}
	BCDToASC(&Baddc[0], 4, tempAddc);
	switch (JParamInfo3761->group2.f10[getPoint(CJQ_hao, DNB_hao)].Type) {
	/*case 1:
		GUI_DispStringAt((INT8U *) "�й���", 96, 16);
		break;
	case 2:
		GUI_DispStringAt((INT8U *) "�����ʱ�", 96, 16);
		break;*/
	case 3:
		GUI_DispStringAt((INT8U *) "�๦�ܱ�", 96, 16);
		break;
	/*case 4:
		GUI_DispStringAt((INT8U *) "�޹���", 96, 16);
		break;
	case 5:
		GUI_DispStringAt((INT8U *) "������", 96, 16);
		break;
	case 6:
		GUI_DispStringAt((INT8U *) "Ԥ���ѱ�", 96, 16);
		break;
	case 7:
		GUI_DispStringAt((INT8U *) "CPU����", 96, 16);
		break;
	case 8:
		GUI_DispStringAt((INT8U *) "IC����", 96, 16);
		break;*/
	case 9:
		GUI_DispStringAt((INT8U *) "�����", 96, 16);
		break;
	default:
		GUI_DispStringAt((INT8U *) "�ɼ���", 96, 16);
		break;
	}
	GUI_DispDecAt(JParamInfo3761->group2.f10[getPoint(CJQ_hao, DNB_hao)].port, 80, 32, 2);
	GUI_DispDecAt(JParamInfo3761->group2.f10[getPoint(CJQ_hao, DNB_hao)].baudrate * 300, 80, 48, 4);
	switch (JParamInfo3761->group2.f10[getPoint(CJQ_hao, DNB_hao)].jiao_yan_wei)
	{
	case 0x00:
		GUI_DispStringAt((INT8U *) "��У��", 96, 64);
		break;
	case 0x01:
		GUI_DispStringAt((INT8U *) "żУ��", 96, 64);
		break;
	case 0x02:
		GUI_DispStringAt((INT8U *) "��У��", 96, 64);
		break;
	default:
		break;
	}
	switch (JParamInfo3761->group2.f10[getPoint(CJQ_hao, DNB_hao)].ConnectType)
	{
	case 1:
		GUI_DispStringAt((INT8U *) "T645-97", 96, 96);
		break;
	case 30:
		GUI_DispStringAt((INT8U *) "T645-07", 96, 96);
		break;
	default:
		GUI_DispStringAt((INT8U *) "����   ", 96, 96);
		break;
	}
	GUI_DispDecAt(JParamInfo3761->group2.f10[getPoint(CJQ_hao, DNB_hao)].shu_ju_wei, 80, 80, 3);
	//GUI_DispDecAt(JParamInfo3761->group2.f10[getPoint(CJQ_hao, DNB_hao)].ting_zhi_wei, 80, 96, 1); //LQQ ping
	GUI_DispStringAt(tempAdd, 64, 112);
	GUI_DispStringAt(tempAddc, 64, 128);
	//GUI_Clear();//20100402
	while (1) {
		ClearThreadTimes(ProjectNo);
		Status_Bar();
		keysele = KeySeleflag;
		KeySeleflag = 0;
		if (keysele != 0)
			DelayTime = 0;
		else
			DelayTime++;
		if (DelayTime >= PageDelayTime) {
			OldLevel = 0;
			return;
		}
		switch (keysele) {
		case 5: //ȷ����
		{
			memset(tempAdd,0,13);
			memset(tempAddc,0,13);
			for (i = 0; i < 6; i++)
			{
				Badd[5 - i]	= JParamInfo3761->group2.f10[getPoint(CJQ_hao, DNB_hao)].Address[i];
			}
			BCDToASC(&Badd[0], 6, tempAdd);
			for (i = 0; i < 4; i++)
			{
				Baddc[3 - i] = JParamInfo3761->group2.f10[getPoint(CJQ_hao, DNB_hao)].CaijiqiAddress[i];
			}
			BCDToASC(&Baddc[0], 4, tempAddc);
			GUI_DispDecAt(0, 96, 48, 2);
			memset(NowInput.buf, 0, 128);
			switch (JParamInfo3761->group2.f10[getPoint(CJQ_hao, DNB_hao)].ConnectType)
			{
			case 1:
				GuiYueHao = 0;
				break;
			case 30:
				GuiYueHao = 1;
				break;
			default:
				GuiYueHao = 2;
				break;
			}
			//printf("ConnectType=%d--%d\n\r",JParamInfo3761->group2.f10[getPoint(CJQ_hao, DNB_hao)].ConnectType,GuiYueHao);
			sprintf((char*) NowInput.buf, "%01d%02d%02d%01d%03d%01d",
					JParamInfo3761->group2.f10[getPoint(CJQ_hao, DNB_hao)].Type,
					JParamInfo3761->group2.f10[getPoint(CJQ_hao, DNB_hao)].port,
					JParamInfo3761->group2.f10[getPoint(CJQ_hao, DNB_hao)].baudrate	* 3,
					JParamInfo3761->group2.f10[getPoint(CJQ_hao, DNB_hao)].jiao_yan_wei,
					JParamInfo3761->group2.f10[getPoint(CJQ_hao, DNB_hao)].shu_ju_wei, GuiYueHao);

			memcpy(&NowInput.buf[10], tempAdd, 12);
			memcpy(&NowInput.buf[22], tempAddc, 8);
			i = 0;
			while (i < 1) {
				NowInput.col[i] = 16;
				NowInput.row[i] = 80 + i * 8;//������
				NowInput.set[i] = 5;
				i++;
			}
			i = 0;
			while (i < 2) {
				NowInput.col[i + 1] = 32;
				NowInput.row[i + 1] = 80 + i * 8;//�˿ں�
				NowInput.set[i + 1] = 1;
				i++;
			}
			i = 0;
			while (i < 2) {
				NowInput.col[i + 3] = 48;
				NowInput.row[i + 3] = 80 + i * 8;//������
				NowInput.set[i + 3] = 1;
				i++;
			}
			i = 0;
			while (i < 1) {
				NowInput.col[i + 5] = 64;
				NowInput.row[i + 5] = 80 + i * 8;//У��λ
				NowInput.set[i + 5] = 6;
				i++;
			}
			i = 0;
			while (i < 3) {
				NowInput.col[i + 6] = 80;
				NowInput.row[i + 6] = 80 + i * 8;//����λ
				NowInput.set[i + 6] = 1;
				i++;
			}
			i = 0;
			while (i < 1) {
				NowInput.col[i + 9] = 96;
				NowInput.row[i + 9] = 80 + i * 8;//ͨѶ��Լ
				NowInput.set[i + 9] = 7;
				i++;
			}
			i = 0;
			while (i < 12) {
				NowInput.col[i + 10] = 112;
				NowInput.row[i + 10] = 64 + i * 8;//����ַ
				NowInput.set[i + 10] = 2;
				i++;
			}
			i = 0;
			while (i < 8) {
				NowInput.col[i + 22] = 128;
				NowInput.row[i + 22] = 64 + i * 8;//�ɵ�ַ
				NowInput.set[i + 22] = 2;
				i++;
			}

			NowInput.AllNum = 31;//1+2+2+1+1+1+1+12+8
			if (ScreenInput_Dnb() == 1)//�в����޸���
			{
				P_Type = GetNum(&NowInput.buf[0], 1, 1);
				DuanKou = GetNum(&NowInput.buf[1], 2, 1);
				BoTe = GetNum(&NowInput.buf[3], 2, 1);
				JiaoYan = GetNum(&NowInput.buf[5], 1, 1);
				ShuJu = GetNum(&NowInput.buf[6], 3, 1);
				GuiYue = GetNum(&NowInput.buf[9], 1, 1);
				memset(tempAdd,0,13);
				memset(tempAddc,0,13);
				memcpy(tempAdd, &NowInput.buf[10], 12);
				memcpy(tempAddc, &NowInput.buf[22], 8);
				memset(NowInput.buf, 0, 128);
				memcpy(&NowInput.buf[0], "N", 1); //��ʼ��ԭʼֵ
				i = 0;
				GUI_DispStringAt((INT8U *) "�����Ƿ񱣴�?Y/N", 0, 144);
				while (i < 1) {
					NowInput.col[i] = 144;
					NowInput.row[i] = 136 + i * 8;
					NowInput.set[i] = 4;
					i++;
				}
				NowInput.AllNum = 1;
				if (ScreenInput() == 1)//��������
				{
					if (NowInput.buf[0] == 'Y') {
						JParamInfo3761->group2.f10[getPoint(CJQ_hao, DNB_hao)].Type= P_Type;
						JParamInfo3761->group2.f10[getPoint(CJQ_hao, DNB_hao)].port= DuanKou;
						JParamInfo3761->group2.f10[getPoint(CJQ_hao, DNB_hao)].baudrate= BoTe / 3;
						JParamInfo3761->group2.f10[getPoint(CJQ_hao, DNB_hao)].jiao_yan_wei= JiaoYan;
						JParamInfo3761->group2.f10[getPoint(CJQ_hao, DNB_hao)].shu_ju_wei= ShuJu;
						if (GuiYue == 0)
							JParamInfo3761->group2.f10[getPoint(CJQ_hao, DNB_hao)].ConnectType= 1;
						else if (GuiYue == 1)
							JParamInfo3761->group2.f10[getPoint(CJQ_hao, DNB_hao)].ConnectType= 30;
						else if (GuiYue == 2)
							JParamInfo3761->group2.f10[getPoint(CJQ_hao, DNB_hao)].ConnectType= 2;

						memset(tempMadd,0,7);
						ASCToBCD(tempAdd, 12, &tempMadd[0]);
						for (i = 0; i < 6; i++) {
							JParamInfo3761->group2.f10[getPoint(CJQ_hao, DNB_hao)].Address[i]
									= tempMadd[5 - i];
						}
						memset(tempMaddc,0,7);
						ASCToBCD(tempAddc, 8, &tempMaddc[0]);
						for (i = 0; i < 4; i++) {
							JParamInfo3761->group2.f10[getPoint(CJQ_hao, DNB_hao)].CaijiqiAddress[i]
									= tempMaddc[3 - i];
						}
						JParamInfo3761->group2.f10[getPoint(CJQ_hao, DNB_hao)].CaijiqiAddress[4]=0x00;
						JParamInfo3761->group2.f10[getPoint(CJQ_hao, DNB_hao)].CaijiqiAddress[5]=0x00;
						JParamInfo3761->group2.f10[getPoint(CJQ_hao, DNB_hao)].FirRead=2;
						
//                		memset(TempBufn,0,60);
//                		sprintf((char*)TempBufn,"%s/AmmeterN.par",_PARADIR_);
//                		NormalSaveFile((char*)TempBufn,(INT8U *)&Jmemory->Points,sizeof(Jmemory->Points));
						if(JProgramInfo->FileSaveFlag.F10_ChangedSave[getPoint(CJQ_hao, DNB_hao)]==0)
							JProgramInfo->FileSaveFlag.F10_ChangedSave[getPoint(CJQ_hao, DNB_hao)]=1;
                		delay(100);
                		JProgramInfo->Para.ChangedPointInfo = getPoint(CJQ_hao, DNB_hao)+1;
						GUI_DispStringAt((INT8U *) "                  ", 0, 144);
						GUI_DispStringAt((INT8U *) "��������ɹ�!", 32, 144);
					} else {
						GUI_DispStringAt((INT8U *) "                  ", 0, 144);
					}

				} else {
					GUI_DispStringAt((INT8U *) "                  ", 0, 144);
				}
			}
		}
			break;
		case 6: //ȡ����
			return;
			break;
		default:
			break;
		}
		Lcmfull();
		delay(100);
	}
}
/******************************************************************************************************************
 * �������ƣ�Modify_JZQ_dz()�����ڵڶ����˵�
 * ��    �ܣ����޸ġ��������ġ�����ַ�����Լ�������ַ��������
 * ��ڲ�������
 * ���ڲ�������
 *******************************************************************************************************************/
void Disp10format(INT8U *dizhi)
{
	char buf[5];
	int id;
	//id =( JConfigInfo->jzqpara.Address_8017.JZ_di_zhi[0]<<8 )|JConfigInfo->jzqpara.Address_8017.JZ_di_zhi[1];
	id =( dizhi[0]<<8 )|dizhi[1];
	sprintf(buf,"(%05d)",id);
	GUI_DispStringAt((INT8U *)buf, 96, 96);
}
int Modify_JZQ_dz(INT8U SeleMenu) {
	INT8U keysele, i, DelayTime;
	int HDFlag,DId,IDtemp;
	unsigned char tempQuYuMa[3], tempDiZhuMa[3], tempid[4];
	unsigned char tempNum[5], tempNum2[5],tempNum3[6];
	INT8U tmpbuf[50];
	DelayTime = 0;
	GUI_Clear();
	memset(tempid,0,4);
	memset(tmpbuf, 0, 50);
	memcpy(tmpbuf, "��������ַ",10);
	GUI_DispStringAt(tmpbuf , 32, 32);
	memset(tmpbuf, 0, 50);
	memcpy(tmpbuf, "������",6);
	GUI_DispStringAt(tmpbuf, 16, 64);

	for (i = 0; i < 2; i++) {
		tempQuYuMa[i] = JConfigInfo->jzqpara.Area_8016.JZ_XingZhuangQuHaoMa[i];
		tempDiZhuMa[i] = JConfigInfo->jzqpara.Address_8017.JZ_di_zhi[i];
	}
	memset(tempNum, 0, 5);
	memset(tempNum2, 0, 5);
	BCDToASC(&tempQuYuMa[0], 2, &tempNum[0]);
	BCDToASC(&tempDiZhuMa[0], 2, &tempNum2[0]);
	//if(Jmemory->XinJiang || Jmemory->JiangXi ||Jmemory->TianJing)
	if(((JProgramInfo->zone&0x7f) == XINJIANG)||((JProgramInfo->zone&0x7f) == JIANGXI)||((JProgramInfo->zone&0x7f) == TIANJIN))
	{
		GUI_DispStringAt((INT8U *) "��ַ��(D)", 90, 64);
		HDFlag = 10;
	}
	else
	{
		GUI_DispStringAt((INT8U *) "��ַ��(H)", 90, 64);
		HDFlag = 16;
	}
	while (1) {
		ClearThreadTimes(ProjectNo);
		GUI_DispStringAt(&tempNum[0], 24, 80);
		GUI_DispStringAt(&tempNum2[0], 104, 80);
		Disp10format(&tempDiZhuMa[0]);
		Status_Bar();
		keysele = KeySeleflag;
		KeySeleflag = 0;
		if (keysele != 0)
			DelayTime = 0;
		else
			DelayTime++;
		if (DelayTime >= PageDelayTime) {
			OldLevel = 0;
			return 0;
		}
		switch (keysele) {
		case 5: //ȷ����
		{
			//--�������ݽ���-----------------------
			if (HDFlag==16)
				memcpy(&NowInput.buf[0],"H",1);
			else
				memcpy(&NowInput.buf[0],"D",1);
			//if(Jmemory->XinJiang || Jmemory->JiangXi ||Jmemory->TianJing)
			if(((JProgramInfo->zone&0x7f) == XINJIANG)||((JProgramInfo->zone&0x7f) == JIANGXI)||((JProgramInfo->zone&0x7f) == TIANJIN))
				HDFlag = 10;
			else
				HDFlag = 16;
			NowInput.col[0] = 64;
			NowInput.row[0] = 146;//
			NowInput.set[0] = 5;
			NowInput.AllNum = 2;
			ScreenInput();
			if ( NowInput.buf[0]=='D')
				HDFlag = 10;
			else if(NowInput.buf[0]=='H')
				HDFlag = 16;
			//------------------------------------
			memset(NowInput.buf, 0, 128);
			memcpy(&NowInput.buf[0], &tempNum[0], 4);
			if(HDFlag == 16)
				memcpy(&NowInput.buf[4], &tempNum2[0], 4);
			else
			{
				DId =( tempDiZhuMa[0]<<8 )|tempDiZhuMa[1];
				sprintf((char *)&NowInput.buf[4],"%05d",DId);
			}
			i = 0;
			while (i < 4) {
				NowInput.col[i] = 80;
				NowInput.row[i] = 24 + i * 8;
				NowInput.set[i] = 2;
				i++;
			}
			i = 0;
			if(HDFlag==16)
			{
				while (i < 4) {
					NowInput.col[i + 4] = 80;
					NowInput.row[i + 4] = 104 + i * 8;
					NowInput.set[i + 4] = 2;
					i++;
				}
				NowInput.AllNum = 9;
			}else
			{
				while (i < 5) {
					NowInput.col[i + 4] = 96;
					NowInput.row[i + 4] = 104 + i * 8;
					NowInput.set[i + 4] = 1;
					i++;
				}
				NowInput.AllNum = 10;
			}

			if (ScreenInput() == 1)//�в����޸���
			{
				memcpy(&tempNum[0], &NowInput.buf[0], 4);
				memset(tempNum2, 0, 5);
				if(HDFlag==16)
				{
					memcpy(&tempNum2[0], &NowInput.buf[4], 4);
				}else{
					memset(tempNum3, 0, 6);
					memcpy(&tempNum3[0], &NowInput.buf[4], 5);
				}
				memset(NowInput.buf, 0, 128);
				memcpy(&NowInput.buf[0], "N", 1); //��ʼ��ԭʼֵ
				i = 0;
				GUI_DispStringAt((INT8U *) "�����Ƿ񱣴�?Y/N", 0, 144);
				while (i < 1) {
					NowInput.col[i] = 144;
					NowInput.row[i] = 136 + i * 8;
					NowInput.set[i] = 4;
					i++;
				}
				NowInput.AllNum = 1;
				if (ScreenInput() == 1)//��������
				{
					if (NowInput.buf[0] == 'Y')
					{
						if (HDFlag == 16)
						{
							ASCToBCD(&tempNum2[0], 4, &tempDiZhuMa[0]);
							ASCToBCD(&tempNum[0], 4, &tempQuYuMa[0]);
							memset(tempid,0,4);
							for (i = 0; i < 2; i++) {
								JConfigInfo->jzqpara.Area_8016.JZ_XingZhuangQuHaoMa[i]= tempQuYuMa[i];
								tempid[i] = tempDiZhuMa[i];
							}
							printf("\n16��������\n");
							JConfigInfo->jzqpara.Address_8017.JZ_di_zhi[0] = tempid[0];
							JConfigInfo->jzqpara.Address_8017.JZ_di_zhi[1] = tempid[1];
//							memset(TempBufn,0,60);
//							sprintf((char*)TempBufn,"%s/JzhqParaN.par",_PARADIR_);
//							NormalSaveFile((char*)TempBufn, &Jmemory->jzq, sizeof(Jmemory->jzq));
							if(JProgramInfo->FileSaveFlag.jzqflag==0)
								JProgramInfo->FileSaveFlag.jzqflag=1;
							delay(100);
							//JProgramInfo->Para.ChangedJiZhongQiInfo = 2;//lcy2013.1.11
							GUI_DispStringAt((INT8U *) "                  ", 0, 144);
							GUI_DispStringAt((INT8U *) "��������ɹ�!", 32, 144);

							memset(tempNum, 0, 5);
							memset(tempNum2, 0, 5);
							BCDToASC(&tempQuYuMa[0], 2, &tempNum[0]);
							BCDToASC(&tempDiZhuMa[0], 2, &tempNum2[0]);



							GUI_DispStringAt(&tempNum[0], 24, 80);
							Disp10format(&tempDiZhuMa[0]);
						}else
						{
							ASCToBCD(&tempNum[0], 4, &tempQuYuMa[0]);
							for (i = 0; i < 2; i++)
								JConfigInfo->jzqpara.Area_8016.JZ_XingZhuangQuHaoMa[i]= tempQuYuMa[i];
							IDtemp = atoi((char *)tempNum3);
							tempDiZhuMa[0]=(IDtemp>>8)&0xff;
							tempDiZhuMa[1]=IDtemp&0xff;

							printf("\n====== IDtemp = %d\n",IDtemp);
							JConfigInfo->jzqpara.Address_8017.JZ_di_zhi[0]=(IDtemp>>8)&0xff;
							JConfigInfo->jzqpara.Address_8017.JZ_di_zhi[1]=IDtemp&0xff;
//							memset(TempBufn,0,60);
//							sprintf((char*)TempBufn,"%s/JzhqParaN.par",_PARADIR_);
//							NormalSaveFile((char*)TempBufn, &Jmemory->jzq, sizeof(Jmemory->jzq));
							if(JProgramInfo->FileSaveFlag.jzqflag==0)
								JProgramInfo->FileSaveFlag.jzqflag=1;
							delay(100);
							//JProgramInfo->Para.ChangedJiZhongQiInfo = 2;//lcy2013.1.11
							GUI_DispStringAt((INT8U *) "                  ", 0, 144);
							GUI_DispStringAt((INT8U *) "��������ɹ�!", 32, 144);

							//BCDToASC(tempDiZhuMa, 2, &tempNum2[0]);
							memset(tempNum, 0, 5);
							memset(tempNum2, 0, 5);
							BCDToASC(&tempQuYuMa[0], 2, &tempNum[0]);
							BCDToASC(&tempDiZhuMa[0], 2, &tempNum2[0]);
							GUI_DispStringAt(&tempNum[0], 24, 80);
							GUI_DispStringAt(&tempNum2[0], 104, 80);
						}
					} else {
						OldLevel = 0;
					}

				} else {
					GUI_DispStringAt((INT8U *) "                  ", 0, 144);
				}
			}
		}
			break;
		case 6: //ȡ����
			OldLevel = 0;
			return 0;
			break;
		default:
			break;
		}
		Lcmfull();
	}
	return 0;
}

//RJ45��GPRSͨ���л�
int Modify_TD_QieHuan(INT8U SeleMenu)
{
	INT8U keysele;
	char showstr[50];
	unsigned int DelayTime;
	int comm_style;
	//INT8U TempBuf[60];
	//int contrast_value;
	DelayTime = 0;
	comm_style = JConfigInfo->jzqpara.CommType;
	while (1) {
		ClearThreadTimes(ProjectNo);
		delay(500);
		GUI_Clear();
		switch(comm_style)
		{
		case GPRS_COM:
			memset(showstr, 0, 50);
			sprintf(showstr,"ͨ������: %s", "GPRS");
			break;
		case NET_COM:
			memset(showstr, 0, 50);
			sprintf(showstr,"ͨ������: %s","RJ45");
			break;
		case SER_COM:
			memset(showstr, 0, 50);
			sprintf(showstr,"ͨ������: %s","����");
			break;
		default:
			memset(showstr, 0, 50);
			sprintf(showstr,"ͨ������: %s","GPRS" );
			break;
		}
		GUI_DispStringAt((INT8U *)showstr,16,72);
		keysele = KeySeleflag;
		KeySeleflag = 0;
		if (keysele != 0)
			DelayTime = 0;
		else
			DelayTime++;
		if (DelayTime >= PageDelayTime)
		{
			OldLevel = 0;
			return 0;
		}
		switch (keysele)
		{
		case 0:
			break;
		case 1:
			comm_style--;
			if(comm_style<1)
				comm_style = 3;
			break;//���ϼ�
		case 2:
			comm_style ++;
			if(comm_style>3)
				comm_style = 1;
			break;//���¼�
		case 3:
			break;
		case 4:
			break;
		case 5:
			JConfigInfo->jzqpara.CommType = comm_style;
			GUI_DispStringAt((INT8U *)"�޸ĳɹ�",54,108);
			fprintf(stderr,"\nJConfigInfo->jzqpara.CommType == %d ",JConfigInfo->jzqpara.CommType);
//			memset(TempBuf,0,60);
//			sprintf((char*)TempBuf,"%s/JzhqPara.par",_PARADIR_);
//			NormalSaveFile((char*)TempBuf, &Jmemory->jzq, sizeof(Jmemory->jzq));
//			memset(TempBuf,0,60);
//			sprintf((char*)TempBuf,"%s/JzhqParaN.par",_PARADIR_);
//			NormalSaveFile((char*)TempBuf, &Jmemory->jzq, sizeof(Jmemory->jzq));
			if(JProgramInfo->FileSaveFlag.jzqflag==0)
				JProgramInfo->FileSaveFlag.jzqflag=1;
			break;//ȷ�ϼ�
		case 6:
			OldLevel = 0;
			return 1;
			break;
		default:
			break;
		}
		Lcmfull();
	}
	return 1;
}

int Modify_AutoSouBiao(INT8U SeleMenu)
{
	INT8U keysele;
	char showstr[50];
	unsigned int DelayTime;
	int autoChaobiao_flag=0;
	//INT8U TempBuf[60];
	//int contrast_value;
	DelayTime = 0;
	autoChaobiao_flag = JParamInfo3761->group11.f111.Enable&0x01;
	while (1) {
		ClearThreadTimes(ProjectNo);
		delay(500);
		GUI_Clear();
		switch(autoChaobiao_flag)
		{
		case 0:
			memset(showstr, 0, 50);
			sprintf(showstr,"�Զ��ѱ�: %s", "��ֹ");
			break;
		case 1:
			memset(showstr, 0, 50);
			sprintf(showstr,"�Զ��ѱ�: %s","ʹ��");
			break;
		default:
			memset(showstr, 0, 50);
			sprintf(showstr,"�Զ��ѱ�: %s", "��ֹ");
			break;
		}
		GUI_DispStringAt((INT8U *)showstr,16,72);
		keysele = KeySeleflag;
		KeySeleflag = 0;
		if (keysele != 0)
			DelayTime = 0;
		else
			DelayTime++;
		if (DelayTime >= PageDelayTime)
		{
			OldLevel = 0;
			return 0;
		}
		switch (keysele)
		{
		case 0:
			break;
		case 1:
			autoChaobiao_flag--;
			if(autoChaobiao_flag<0)
				autoChaobiao_flag = 1;
			break;//���ϼ�
		case 2:
			autoChaobiao_flag ++;
			if(autoChaobiao_flag>2)
				autoChaobiao_flag = 0;
			break;//���¼�
		case 3:
			break;
		case 4:
			break;
		case 5:
			JParamInfo3761->group11.f111.Enable = autoChaobiao_flag;
			GUI_DispStringAt((INT8U *)"�޸ĳɹ�",54,108);

//			memset(TempBuf,0,60);
//			sprintf((char*)TempBuf,"%s/JzhqPara.par",_PARADIR_);
//			NormalSaveFile((char*)TempBuf, &Jmemory->jzq, sizeof(Jmemory->jzq));
			if(JProgramInfo->FileSaveFlag.g11flag==0)
				JProgramInfo->FileSaveFlag.g11flag=1;
			break;//ȷ�ϼ�
		case 6:
			OldLevel = 0;
			return 1;
			break;
		default:
			break;
		}
		Lcmfull();
	}
	return 1;
}
int SetZaiboType(INT8U SeleMenu)
{
	return 1;
}
int SetHeartBeat(INT8U SeleMenu)
{
	//INT8U TempBuf[60];
	INT8U i,keysele,xintiao;
    INT16U DelayTime;
    DelayTime=0;
    xintiao=5;
    GUI_Clear();
    GUI_DispStringAt((INT8U *)"��������:",0,44);
    GUI_DispStringAt((INT8U *)"���ڷ�Χ:(1-60min)",0,64);

	while(1)
	{
		xintiao=JParamInfo3761->group1.f1.HeartInterval;
		memset(NowInput.buf,0,sizeof(NowInput.buf));
		sprintf((char *)NowInput.buf,"%02d",xintiao);
		GUI_DispStringAt(NowInput.buf,80,44);

		Status_Bar();
		  i=0;
		  keysele=KeySeleflag;
		  KeySeleflag =0;
		  if(keysele!=0)DelayTime=0;else DelayTime++;
			 if(DelayTime>=PageDelayTime)
			{
				OldLevel=0;
				return 0;
			}
		switch(keysele)
		{
			case 5:    //ȷ����
			  {
				  memset(NowInput.buf,0,128);
				  sprintf((char *)NowInput.buf,"%02d",xintiao);  //����ת����Ϊ�ַ���
					i=0;
				  while(i<2)
					{
						NowInput.col[i]=44;//y��
						NowInput.row[i]=80+i*8;//x��
						NowInput.set[i]=1;
						i++;
					}
					NowInput.AllNum=3;

					if(ScreenInput()==1)
					{
						xintiao=GetNum(&NowInput.buf[0],2,1);
						JParamInfo3761->group1.f1.HeartInterval=xintiao;
//						memset(TempBuf,0,60);
//						sprintf((char*)TempBuf,"%s/JzhqPara.par",_PARADIR_);
//						NormalSaveFile((char*)TempBuf, &Jmemory->jzq, sizeof(Jmemory->jzq));
						if(JProgramInfo->FileSaveFlag.g1flag==0)
							JProgramInfo->FileSaveFlag.g1flag=1;
					}
			}
		   break;
		   case 6:  //ȡ����
			{
				 OldLevel=0;
				 return 0;
			 }
			break;
			default : break;
		}
		  Lcmfull();
	}
	return 0;
}

int SetSIMNo(INT8U SeleMenu)
{
	INT8U keysele;
	unsigned int DelayTime;
	DelayTime = 0;
	int left = 8;

	GUI_Clear();
	GUI_DispStringAt((INT8U *) "������SIM���ֻ���", left, 32);
	while (1)
	{
		ClearThreadTimes(ProjectNo);
		Status_Bar();
		GUI_DispDecAt(JConfigInfo->jzqpara.SIMCard[0]-48, left+0, 50, 1);
		GUI_DispDecAt(JConfigInfo->jzqpara.SIMCard[1]-48, left+8, 50, 1);
		GUI_DispDecAt(JConfigInfo->jzqpara.SIMCard[2]-48, left+16, 50, 1);
		GUI_DispDecAt(JConfigInfo->jzqpara.SIMCard[3]-48, left+24, 50, 1);
		GUI_DispDecAt(JConfigInfo->jzqpara.SIMCard[4]-48, left+32, 50, 1);
		GUI_DispDecAt(JConfigInfo->jzqpara.SIMCard[5]-48, left+40, 50, 1);
		GUI_DispDecAt(JConfigInfo->jzqpara.SIMCard[6]-48, left+48, 50, 1);
		GUI_DispDecAt(JConfigInfo->jzqpara.SIMCard[7]-48, left+56, 50, 1);
		GUI_DispDecAt(JConfigInfo->jzqpara.SIMCard[8]-48, left+64, 50, 1);
		GUI_DispDecAt(JConfigInfo->jzqpara.SIMCard[9]-48, left+72, 50, 1);
		GUI_DispDecAt(JConfigInfo->jzqpara.SIMCard[10]-48, left+80, 50, 1);

		keysele = KeySeleflag;
		KeySeleflag = 0;
		if (keysele != 0)
			DelayTime = 0;
		else
			DelayTime++;
		if (DelayTime >= PageDelayTime) {
			OldLevel = 0;
			return 0;
		}
		if (keysele== 6)
		{
			OldLevel = 0;
			return 0;
		}
		Lcmfull();
		delay(500);
	}

	return 0;
}

int SetJZQIP(INT8U SeleMenu)
{
	INT8U keysele, i=0, flag255 = 0;
	unsigned char TempBuf1[32];
	INT8U cmd[100];
	INT8U strIP[100];
	F3 jzqip;
	int iIP[4];
	memset(iIP, 0, 4);
	unsigned int DelayTime;
	unsigned char tempIPadd[8];
	memset(TempBuf1, 0, 32);
	memset(&jzqip, 0, sizeof(F3));
	INT8U str0[20],str1[20],str2[20],str3[20];
	memset(str0,0,20);memset(str1,0,20);memset(str2,0,20);memset(str3,0,20);
	FILE *fp;
	fp=fopen("/nor/rc.d/ip.sh", "r");
	fscanf(fp,"%s %s %s %s",str0,str1,str2,str3);
	fclose(fp);
	printf("\n?��?D?��ip:");
	while(str2[i]!=0)
	{
		printf("%c",str2[i]);
		i++;
	}
	sscanf((char*)str2, "%d.%d.%d.%d",&iIP[3],&iIP[2],&iIP[1],&iIP[0]);
	jzqip.IP[3] = iIP[3]&0xff;
	jzqip.IP[2] = iIP[2]&0xff;
	jzqip.IP[1] = iIP[1]&0xff;
	jzqip.IP[0] = iIP[0]&0xff;
	printf("\n?��?D?��ip==%d.%d.%d.%d",jzqip.IP[3],jzqip.IP[2],jzqip.IP[1],jzqip.IP[0]);

	GUI_Clear();
	DelayTime = 0;
	GUI_DispStringAt((INT8U *) "����������IP", 0, 16);
	GUI_DispCharAt('.', 24, 32);
	GUI_DispCharAt('.', 52, 32);
	GUI_DispCharAt('.', 80, 32);

	GUI_DispStringAt((INT8U *) "SIM���ţ�", 0, 32);
	while (1) {
		ClearThreadTimes(ProjectNo);
		Status_Bar();
		GUI_DispDecAt(jzqip.IP[3], 0, 32, 3);
		GUI_DispDecAt(jzqip.IP[2], 28, 32, 3);
		GUI_DispDecAt(jzqip.IP[1], 56, 32, 3);
		GUI_DispDecAt(jzqip.IP[0], 84, 32, 3);

		keysele = KeySeleflag;
		KeySeleflag = 0;
		if (keysele != 0)
			DelayTime = 0;
		else
			DelayTime++;
		if (DelayTime >= PageDelayTime) {
			OldLevel = 0;
			return 0;
		}
		switch (keysele) {
		case 5: //����?��?��
		{
			memset(NowInput.buf, 0, 128);
			sprintf((char*) NowInput.buf, "%03d%03d%03d%03d",jzqip.IP[3],
					jzqip.IP[2],jzqip.IP[1], jzqip.IP[0]);
			i = 0;
			while (i < 3) {//ip-1
				NowInput.col[i] = 32;
				NowInput.row[i] = 0 + i * 8;//56
				NowInput.set[i] = 1;
				i++;
			}
			i = 0;
			while (i < 3) {//ip-2
				NowInput.col[i + 3] = 32;
				NowInput.row[i + 3] = 28 + i * 8;//84
				NowInput.set[i + 3] = 1;
				i++;
			}
			i = 0;
			while (i < 3) {//ip-3
				NowInput.col[i + 6] = 32;
				NowInput.row[i + 6] = 56 + i * 8;//112
				NowInput.set[i + 6] = 1;
				i++;
			}
			i = 0;
			while (i < 3) {//ip-4
				NowInput.col[i + 9] = 32;
				NowInput.row[i + 9] = 84 + i * 8;//140
				NowInput.set[i + 9] = 1;
				i++;
			}
			NowInput.AllNum = 13;//52;//17+16+17+1+1
			if (ScreenInput() == 1)
			{
				memset(tempIPadd, 0, 8);
				for (i = 0; i < 4; i++)
				{
					tempIPadd[3 - i] = GetNum(&NowInput.buf[3* i ], 3, 1)& 0xff;
				}
				memset(NowInput.buf, 0, 128);
				memcpy(&NowInput.buf[0], "N", 1);
				i = 0;
				GUI_DispStringAt((INT8U *) "�����Ƿ񱣴�?Y/N", 0, 144);
				while (i < 1) {
					NowInput.col[i] = 144;
					NowInput.row[i] = 136 + i * 8;
					NowInput.set[i] = 4;
					i++;
				}
				NowInput.AllNum = 1;
				if (ScreenInput() == 1)
				{
					if (NowInput.buf[0] == 'Y') {

						for (i = 0; i < 4; i++) {
							//printf("%d--\n\r",tempIPadd[3 - i]);
							if (jzqip.IP[i] != tempIPadd[i]) {
								flag255 = 1;
								break;
							}
						}
						memcpy(&jzqip.IP[0], &tempIPadd[0], 4);

						GUI_DispDecAt(jzqip.IP[3], 0, 32, 3);
						GUI_DispDecAt(jzqip.IP[2], 28, 32, 3);
						GUI_DispDecAt(jzqip.IP[1], 56, 32, 3);
						GUI_DispDecAt(jzqip.IP[0], 84, 32, 3);
						memset(cmd, 0, 100);
						memset(strIP, 0, 100);
						sprintf((char*)strIP, "ifconfig eth0 %d.%d.%d.%d up",jzqip.IP[3],jzqip.IP[2],jzqip.IP[1],jzqip.IP[0]);
						sprintf((char*)cmd, "echo %s > /nor/rc.d/ip.sh", strIP);
						system((char*)cmd);
						system((char*)strIP);//lcy2013.1.11
						GUI_DispStringAt((INT8U *) "                  ", 0,	144);
						GUI_DispStringAt((INT8U *) "��������ɹ�!", 32, 144);
					}
				} else {
					GUI_DispStringAt((INT8U *) "                  ", 0, 144);
				}

			}
		}
			break;
		case 6: //��????��
		{
			OldLevel = 0;
			return 0;
		}
			break;
		default:
			break;
		}
		Lcmfull();
		flag255 = 0;
	}
	return 0;
}
int SetDongJieType(INT8U SeleMenu)
{//JConfigInfo->jzqpara.ChaoBiaoDongJieType
	INT8U keysele;
	char showstr[50];
	unsigned int DelayTime;
	int ChaoBiaoDongJieType=0;
	//INT8U TempBuf[60];
	//int contrast_value;
	DelayTime = 0;
	ChaoBiaoDongJieType = JConfigInfo->jzqpara.ChaoBiaoDongJieType&0x01;
	while (1) {
		ClearThreadTimes(ProjectNo);
		delay(500);
		GUI_Clear();
		switch(ChaoBiaoDongJieType)
		{
		case 0:
			memset(showstr, 0, 50);
			sprintf(showstr,"���᷽ʽ: %s", "������");
			break;
		case 1:
			memset(showstr, 0, 50);
			sprintf(showstr,"���᷽ʽ: %s","���");
			break;
		default:
			memset(showstr, 0, 50);
			sprintf(showstr,"���᷽ʽ: %s", "������");
			break;
		}
		GUI_DispStringAt((INT8U *)showstr,16,72);
		keysele = KeySeleflag;
		KeySeleflag = 0;
		if (keysele != 0)
			DelayTime = 0;
		else
			DelayTime++;
		if (DelayTime >= PageDelayTime)
		{
			OldLevel = 0;
			return 0;
		}
		switch (keysele)
		{
		case 0:
			break;
		case 1:
			ChaoBiaoDongJieType--;
			if(ChaoBiaoDongJieType<0)
				ChaoBiaoDongJieType = 1;
			break;//���ϼ�
		case 2:
			ChaoBiaoDongJieType ++;
			if(ChaoBiaoDongJieType>2)
				ChaoBiaoDongJieType = 0;
			break;//���¼�
		case 3:
			break;
		case 4:
			break;
		case 5:
			JConfigInfo->jzqpara.ChaoBiaoDongJieType = ChaoBiaoDongJieType;
			GUI_DispStringAt((INT8U *)"�޸ĳɹ�",54,108);

//			memset(TempBuf,0,60);
//			sprintf((char*)TempBuf,"%s/JzhqPara.par",_PARADIR_);
//			NormalSaveFile((char*)TempBuf, &Jmemory->jzq, sizeof(Jmemory->jzq));
			if(JProgramInfo->FileSaveFlag.jzqflag==0)
				JProgramInfo->FileSaveFlag.jzqflag=1;
			break;//ȷ�ϼ�
		case 6:
			OldLevel = 0;
			return 1;
			break;
		default:
			break;
		}
		Lcmfull();
	}
	return 1;
}

int Modify_InitMeterType(INT8U SeleMenu)
{
	INT8U keysele;
	char showstr[50];
	unsigned int DelayTime;
	int initmetertype=0;
	//INT8U TempBuf[60];
	//int contrast_value;
	DelayTime = 0;
	initmetertype = JConfigInfo->jzqpara.HeBei_ReadLevelOne;
	while (1) {
		ClearThreadTimes(ProjectNo);
		delay(500);
		GUI_Clear();
		switch(initmetertype)
		{
		case 0:
			memset(showstr, 0, 50);
			sprintf(showstr,"��ʽ: %s", "�㳭");
			break;
		case 1:
			memset(showstr, 0, 50);
			sprintf(showstr,"��ʽ: %s", "�ֳ�");
			break;
		default:
			memset(showstr, 0, 50);
			sprintf(showstr,"��ʽ: %s", "�㳭");
			break;
		}
		GUI_DispStringAt((INT8U *)showstr,16,72);
		keysele = KeySeleflag;
		KeySeleflag = 0;
		if (keysele != 0)
			DelayTime = 0;
		else
			DelayTime++;
		if (DelayTime >= PageDelayTime)
		{
			OldLevel = 0;
			return 0;
		}
		switch (keysele)
		{
		case 0:
			break;
		case 1:
			initmetertype--;
			if(initmetertype<0)
				initmetertype = 1;
			break;//���ϼ�
		case 2:
			initmetertype ++;
			if(initmetertype>=2)
				initmetertype = 0;
			break;//���¼�
		case 3:
			break;
		case 4:
			break;
		case 5:
			JConfigInfo->jzqpara.HeBei_ReadLevelOne = initmetertype;
			GUI_DispStringAt((INT8U *)"�޸ĳɹ�",54,108);
			GUI_DispStringAt((INT8U *)"F129 F167",54,130);
//			memset(TempBuf,0,60);
//			sprintf((char*)TempBuf,"%s/JzhqPara.par",_PARADIR_);
//			NormalSaveFile((char*)TempBuf, &Jmemory->jzq, sizeof(Jmemory->jzq));
			if(JProgramInfo->FileSaveFlag.jzqflag==0)
				JProgramInfo->FileSaveFlag.jzqflag=1;
			break;//ȷ�ϼ�
		case 6:
			OldLevel = 0;
			return 1;
			break;
		default:
			break;
		}
		Lcmfull();
	}
	return 1;
}
/******************************************************************************************************************
 * �������ƣ�Modify_Password()�����ڵڶ����˵�
 * ��    �ܣ����޸ġ����ġ����������롿���������������
 * ��ڲ�������
 * ���ڲ�������
 *******************************************************************************************************************/
int Modify_Password(INT8U SeleMenu)
{
	INT8U keysele, i, DelayTime;
	unsigned char tempPass[7], SavePass[4], tempPass2[7];
	DelayTime = 0;
	GUI_Clear();
	for (i = 0; i < 3; i++)
		SavePass[i] = JParamInfo3761->group1.f7.PassWords[2 - i];
	BCDToASC(SavePass, 3, &tempPass[0]);
	GUI_DispStringAt((INT8U *) "��������", 48, 32);
	GUI_DispStringAt((INT8U *) "ԭʼ����", 16, 64);
	GUI_DispStringAt((INT8U *) "�½�����", 16, 96);
	GUI_DispStringAt(tempPass, 96, 64);
	while (1) {
		ClearThreadTimes(ProjectNo);
		Status_Bar();
		keysele = KeySeleflag;
		KeySeleflag = 0;
		if (keysele != 0)
			DelayTime = 0;
		else
			DelayTime++;
		if (DelayTime >= PageDelayTime) {
			OldLevel = 0;
			return 0;
		}
		switch (keysele) {
		case 5: //ȷ����
		{

			memset(NowInput.buf, 0, 128);
			memcpy(&NowInput.buf[0], &tempPass[0], 6);
			i = 0;
			while (i < 6) {
				NowInput.col[i] = 96;
				NowInput.row[i] = 96 + i * 8;//����
				NowInput.set[i] = 1;
				i++;
			}
			NowInput.AllNum = 7;
			if (ScreenInput() == 1)//�в����޸���
			{
				memcpy(&tempPass2[0], &NowInput.buf[0], 6);
				memset(NowInput.buf, 0, 128);
				memcpy(&NowInput.buf[0], "N", 1); //��ʼ��ԭʼֵ
				i = 0;
				GUI_DispStringAt((INT8U *) "�����Ƿ񱣴�?Y/N", 0, 144);
				while (i < 1) {
					NowInput.col[i] = 144;
					NowInput.row[i] = 136 + i * 8;
					NowInput.set[i] = 4;
					i++;
				}
				NowInput.AllNum = 1;
				if (ScreenInput() == 1)//��������
				{
					if (NowInput.buf[0] == 'Y') {
						ASCToBCD(&tempPass2[0], 6, &SavePass[0]);
						for (i = 0; i < 3; i++)
							JParamInfo3761->group1.f7.PassWords[2 - i] = SavePass[i];
						//lcy2013.1.11
						//JProgramInfo->Para.ChangedJiZhongQiInfo = 2;
						if(JProgramInfo->FileSaveFlag.g1flag==0)
							JProgramInfo->FileSaveFlag.g1flag=1;
						GUI_DispStringAt((INT8U *) "                  ", 0, 144);
						GUI_DispStringAt((INT8U *) "���뱣��ɹ�!", 32, 144);
						//delay(2000);
					} else {
						OldLevel = 0;
					}

				} else {
					GUI_DispStringAt((INT8U *) "                  ", 0, 144);
				}
			}
		}
			break;
		case 6: //ȡ����
			OldLevel = 0;
			return 0;
			break;
		default:
			break;
		}
		Lcmfull();
	}
	return 0;
}

/******************************************************************************************************************
 * �������ƣ�Modify_TxCanShu()�����ڵڶ����˵�
 * ��    �ܣ����޸ġ����ġ���ʱ�����������ʱ���������
 * ��ڲ�������
 * ���ڲ�������
 *******************************************************************************************************************/
int Modify_SjCanShu(INT8U SeleMenu) {
	TS ts;
	INT8U keysele, i, DelayTime;
	unsigned char tempTime[50] = "date ",tmp2[2]=" ";
	DelayTime = 0;
	GUI_Clear();
	GUI_DispStringAt((INT8U *) "������ʱ��", 32, 32);
	GUI_DispStringAt((INT8U *) "��", 48, 48);
	GUI_DispStringAt((INT8U *) "��", 80, 48);
	GUI_DispStringAt((INT8U *) "��", 112, 48);
	GUI_DispStringAt((INT8U *) "ʱ", 48, 64);
	GUI_DispStringAt((INT8U *) "��", 80, 64);
	GUI_DispStringAt((INT8U *) "��", 112, 64);
	TSGet(&ts);
	while (1) {
		ClearThreadTimes(ProjectNo);
		Status_Bar();
		GUI_DispDecAt(ts.Year, 16, 48, 4);
		GUI_DispDecAt(ts.Month, 64, 48, 2);
		GUI_DispDecAt(ts.Day, 96, 48, 2);
		GUI_DispDecAt(ts.Hour, 32, 64, 2);
		GUI_DispDecAt(ts.Minute, 64, 64, 2);
		GUI_DispDecAt(ts.Sec, 96, 64, 2);
		keysele = KeySeleflag;
		KeySeleflag = 0;
		if (keysele != 0)
			DelayTime = 0;
		else
			DelayTime++;
		if (DelayTime >= PageDelayTime) {
			OldLevel = 0;
			return 0;
		}
		switch (keysele) {
		case 5: //ȷ����
		{

			memset(NowInput.buf, 0, 128);
			sprintf((char*) NowInput.buf, "%04d%02d%02d%02d%02d%02d", ts.Year,
					ts.Month, ts.Day, ts.Hour, ts.Minute, ts.Sec);
			i = 0;
			while (i < 4) {
				NowInput.col[i] = 48;
				NowInput.row[i] = 16 + i * 8;//��
				NowInput.set[i] = 1;
				i++;
			}
			i = 0;
			while (i < 2) {
				NowInput.col[i + 4] = 48;
				NowInput.row[i + 4] = 64 + i * 8;//��
				NowInput.set[i + 4] = 1;
				i++;
			}
			i = 0;
			while (i < 2) {
				NowInput.col[i + 6] = 48;
				NowInput.row[i + 6] = 96 + i * 8;//��
				NowInput.set[i + 6] = 1;
				i++;
			}
			i = 0;
			while (i < 2) {
				NowInput.col[i + 8] = 64;
				NowInput.row[i + 8] = 32 + i * 8;//ʱ
				NowInput.set[i + 8] = 1;
				i++;
			}
			i = 0;
			while (i < 2) {
				NowInput.col[i + 10] = 64;
				NowInput.row[i + 10] = 64 + i * 8;//��
				NowInput.set[i + 10] = 1;
				i++;
			}
			i = 0;
			while (i < 2) {
				NowInput.col[i + 12] = 64;
				NowInput.row[i + 12] = 96 + i * 8;//��
				NowInput.set[i + 12] = 1;
				i++;
			}
			i = 0;
			NowInput.AllNum = 15;//4+2+2+2+2+2
			if (ScreenInput() == 1)//�в����޸���
			{
				#ifdef __linux__
					memcpy(&tempTime[5], &NowInput.buf[0], 4);
					tmp2[0]='.';
					memcpy(&tempTime[9],&tmp2[0],1);
					memcpy(&tempTime[10], &NowInput.buf[4], 2);
					tmp2[0]='.';
					memcpy(&tempTime[12],&tmp2[0],1);
					memcpy(&tempTime[13], &NowInput.buf[6], 2);
					tmp2[0]='-';
					memcpy(&tempTime[15],&tmp2[0],1);
					memcpy(&tempTime[16], &NowInput.buf[8], 2);
					tmp2[0]=':';
					memcpy(&tempTime[18],&tmp2[0],1);
					memcpy(&tempTime[19], &NowInput.buf[10], 2);
					tmp2[0]=':';
					memcpy(&tempTime[21],&tmp2[0],1);
					memcpy(&tempTime[22], &NowInput.buf[12], 2);
					tmp2[0]=' ';
					memcpy(&tempTime[24],&tmp2[0],1);
				#else
					memcpy(&tempTime[5], &NowInput.buf[6], 2);
					memcpy(&tempTime[7],&tmp2[0],1);
					memcpy(&tempTime[8], &NowInput.buf[4], 2);
					memcpy(&tempTime[10],&tmp2[0],1);
					memcpy(&tempTime[11], &NowInput.buf[0], 4);
					memcpy(&tempTime[15],&tmp2[0],1);
					memcpy(&tempTime[16], &NowInput.buf[8], 2);
					memcpy(&tempTime[18],&tmp2[0],1);
					memcpy(&tempTime[19], &NowInput.buf[10], 2);
					memcpy(&tempTime[21],&tmp2[0],1);
					memcpy(&tempTime[22], &NowInput.buf[12], 2);
					memcpy(&tempTime[24],&tmp2[0],1);
				#endif

				memset(NowInput.buf, 0, 128);
				memcpy(&NowInput.buf[0], "N", 1); //��ʼ��ԭʼֵ
				i = 0;
				GUI_DispStringAt((INT8U *) "ʱ���Ƿ񱣴�?Y/N", 0, 144);
				while (i < 1) {
					NowInput.col[i] = 144;
					NowInput.row[i] = 136 + i * 8;
					NowInput.set[i] = 4;
					i++;
				}
				NowInput.AllNum = 1;
				if (ScreenInput() == 1)//��������
				{
					if (NowInput.buf[0] == 'Y') {
						SdPrint("tempTime=%s\n\r",tempTime);
						syscmd((char*) tempTime,JProgramInfo);
						delay(100);
						syscmd(_SETCLK_,JProgramInfo);
						GUI_DispStringAt((INT8U *) "                  ", 0, 144);
						GUI_DispStringAt((INT8U *) "ʱ�䱣��ɹ�!", 32, 144);
						delay(2000);
						TSGet(&ts);
					} else {
						OldLevel = 0;
					}

				} else {
					GUI_DispStringAt((INT8U *) "                  ", 0, 144);
				}
			}
		}
			break;
		case 6: //ȡ����
			OldLevel = 0;
			return 0;
			break;
		default:
			break;
		}
		Lcmfull();
	}
	return 0;
}

int Modify_DB_para(INT8U SeleMenu) {
	unsigned int DelayTime;
	INT8U keysele;
	INT16U i,  j, k;
	unsigned char tempAdd[32];
	i = 0;
	DelayTime = 0;

	while (1) {
		ClearThreadTimes(ProjectNo);
		initMeterPare();
		GUI_Clear();
		Status_Bar();//Ȼ��״̬����Ȼ������ʾ�����ı��ţ����ǵ�һ���˵�����
		if (meterCount > 0) {
			GUI_DispStringAt((INT8U *) "����      ����ַ", 0, 16);
			GUI_SetTextMode(GUI_TM_REV);
			GUI_DispDecAt(getPoint(TempMeterPara[i].CJQ_hao - 1,
					TempMeterPara[i].DNB_hao), 0, 32, 4);
			/*GUI_DispDecAt(TempMeterPara[i].CJQ_hao-1,0,32,3);
			 GUI_DispStringAt((INT8U *)" ",24,32);
			 GUI_DispDecAt(TempMeterPara[i].DNB_hao,32,32,2);
			 GUI_DispStringAt((INT8U *)"  ",48,32);*/
			GUI_DispStringAt((INT8U *) "   ", 32, 32);
			BCDToASC(&TempMeterPara[i].p_8902.address[0], 6, tempAdd);
			GUI_DispStringAt(tempAdd, 56, 32);
			GUI_SetTextMode(GUI_TM_NORMAL);
			if (meterCount - i >= 6)
				k = 5;
			else
				k = meterCount - i - 1;
			for (j = 0; j < k; j++) {
				GUI_DispDecAt(getPoint(TempMeterPara[i + j + 1].CJQ_hao - 1,
						TempMeterPara[i + j + 1].DNB_hao), 0, 48 + j * 16, 4);
				//GUI_DispDecAt(TempMeterPara[i+j+1].CJQ_hao-1,0,48+j*16,3);
				//GUI_DispDecAt(TempMeterPara[i+j+1].DNB_hao,32,48+j*16,2);
				BCDToASC(&TempMeterPara[i + j + 1].p_8902.address[0], 6,
						tempAdd);
				GUI_DispStringAt(tempAdd, 56, 48 + j * 16);
			}
			//���������������ڱ���ַ��������ʾ
			Lcmfull();
			keysele = KeySeleflag;
			KeySeleflag = 0;
			if (DelayTime >= PageDelayTime) {
				OldLevel = 0;
				return 0;
			}
			switch (keysele) {
			case 0:
				DelayTime++;
				break;
			case 1:
				if (i == 0)
					i = meterCount - 1;
				else
					i--;
				DelayTime = 0;
				break;//���ϼ�
			case 2:
				if (i == meterCount - 1)
					i = 0;
				else
					i++;
				DelayTime = 0;
				break;//���¼�
			case 3:
				if (i>=6)
					i=i-6;
				else i = meterCount - 1;
				DelayTime = 0;
				break;
			case 4:
				if (i<=meterCount - 6)
					i=i+6;
				else i=0;
				DelayTime = 0;
				break;
			case 5:
				Modify_DBCanShu(TempMeterPara[i].CJQ_hao - 1,
						TempMeterPara[i].DNB_hao - 1);
				break;//ȷ�ϼ�
			case 6:
				OldLevel = 0;
				return 0;
				break;
			default:
				break;
			}
		} else {
			GUI_DispStringAt((INT8U *) "�޿��ò�����!", 32, 64);
			Lcmfull();
			keysele = KeySeleflag;
			KeySeleflag = 0;
			if (DelayTime >= PageDelayTime) {
				OldLevel = 0;
				return 0;
			}
			switch (keysele) {
			case 0:
				DelayTime++;
				break;
			case 1:
				break;//���ϼ�
			case 2:
				break;//���¼�
			case 3:
				break;
			case 4:
				break;
			case 5:
				break;//ȷ�ϼ�
			case 6:
				OldLevel = 0;
				return 0;
				break;
			default:
				break;
			}
		}
		delay(100);
	}
	return 0;
}
void SetDataFlag97(unsigned char DI1, unsigned char DI0, unsigned char *flags) {
	flags[1] = DI1;
	flags[0] = DI0;
}

/******************************************************************************************************************
 * �������ƣ�show_realData()�����ڵڶ����˵�
 * ��    �ܣ��ɼ�ʵʱ���ݲ���ʾ����Ļ��
 * ��ڲ�������
 * ���ڲ�������
 *******************************************************************************************************************/
//����ǰ������
void GetCurMeterData(unsigned char i, unsigned char j)//��������
{
	unsigned char flgCount = 0, metertype;
	//1��ȡ��Ч������Ϣ����CurMeters
	//printf("\n\r  ReadDataDay...............\n\r");
	JProgramInfo->RealData.CurFlgCount = 0;
	metertype = JParamInfo3761->group2.f10[getPoint(i, j)].Type;
	if (metertype == 6 || metertype == 9) {
		SetDataFlag97(0x90, 0x10, JProgramInfo->RealData.flg97[0].flg.Dataflag);
		JProgramInfo->RealData.CurFlgCount = 1;
		//GetRealTimeDatas(100,10);
	}//��ͨ���ļ���Ԥ���ѱ��ļ�
	else if (metertype == 2)//�����ʱ��ļ�
	{
		SetDataFlag97(0x90, 0x10, JProgramInfo->RealData.flg97[0].flg.Dataflag);
		SetDataFlag97(0x90, 0x11, JProgramInfo->RealData.flg97[1].flg.Dataflag);
		SetDataFlag97(0x90, 0x12, JProgramInfo->RealData.flg97[2].flg.Dataflag);
		SetDataFlag97(0x90, 0x13, JProgramInfo->RealData.flg97[3].flg.Dataflag);
		SetDataFlag97(0x90, 0x14, JProgramInfo->RealData.flg97[4].flg.Dataflag);
		JProgramInfo->RealData.CurFlgCount = 5;
		//GetRealTimeDatas(100,20);
	} else {
		for (flgCount = 0; flgCount < JProgramInfo->Para.meterFlags.ManyDayFlagsCount; flgCount++) {
			JProgramInfo->RealData.flg97[flgCount].flg.Dataflag[0]
					= JProgramInfo->Para.meterFlags.ManyDayFlags[flgCount].Dataflag[0];
			JProgramInfo->RealData.flg97[flgCount].flg.Dataflag[1]
					= JProgramInfo->Para.meterFlags.ManyDayFlags[flgCount].Dataflag[1];
		}
		JProgramInfo->RealData.CurFlgCount = flgCount;
		//GetRealTimeDatas(100,50);
	}
}

int GetManyData0ld(DataFlg *data,INT8U *reslutBuf,INT8U DI1,INT8U DI0)				//9.23
{
	INT8U i,isFlag=0;
	for(i=0;i<ManyFlagsCount;i++)
	{
		if(data[i].flg.Dataflag[0]==DI0 && data[i].flg.Dataflag[1]==DI1){
            memcpy(reslutBuf,&data[i].datas[0],sizeof(data[i].datas));
            isFlag=1;
            break;
		}
	}
	if(isFlag==0) {
		for(i=0;i<ManyFlagsCount;i++) {
			if(data[i].flg.Dataflag[0]==(DI0|0x0f)&&data[i].flg.Dataflag[1]==DI1){
				memcpy(reslutBuf,&data[i].datas[0],sizeof(data[i].datas));
				isFlag=1;
				break;
			}
		}
	}

	if(isFlag==0){
		memset(reslutBuf,0x00,sizeof(data[0].datas));
		return 0;
	}
	return 1;
}
void readjiaocaiYue(INT8U *buf, INT8U da1,INT8U da0)
{
	TS ts;
	INT8U TempBuf[60];
	SMFiles smfile;
	memset(&ts,0,sizeof(TS));
	TSGet(&ts);
	TimeDecrease(&ts, 5, 1);
	memset(TempBuf,0,60);
	sprintf((char*)TempBuf,"/nand/DataMonth/%04d/%02d.dat",1,ts.Month);
	if(access((char*)TempBuf,0)==0)
	{
		memset(&smfile,0,sizeof(SMFiles));
		ReadFile((char *)TempBuf, &smfile,sizeof(SMFiles),JProgramInfo);
		GetManyData0ld(smfile.sm.datas, buf, da1, da0);
	}else
		memset(buf,0,DataLenMax);
}
int show_realData(INT8U CJQno, INT8U BDZno, INT8U p_flag, unsigned char *MeterAdd)
{
	int jcindex=0;
	int flag, count, i = 0, j = 0, DataCount = 0,DelayTime=0,dly;
	INT8U keysele;
	unsigned char temp[32], DBadd[13];
	count = 0;
	memset(DBadd, 0, 13);
	BCDToASC(MeterAdd, 6, &DBadd[0]);

	while (1)
	{
		ClearThreadTimes(ProjectNo);
		if (JProgramInfo->RealData.ReadFlg == 0)
			break;
		JProgramInfo->RealData.ReadFlg=0;
		delay(100);
		GUI_Clear();
		Status_Bar();
		GUI_DispStringAt((INT8U *) "���δ����", 32, 64);
		keysele = KeySeleflag;
		KeySeleflag = 0;
		if (DelayTime >= PageDelayTime) {
			OldLevel = 0;
			return 2;
		}
		delay(100);
		switch (keysele) {
		case 0:
			DelayTime++;
			break;
		case 1:
			break;
		case 2:
			break;
		case 3:
			break;
		case 4:
			break;
		case 5:
			break;
		case 6:
			return 0;
			break;
		default:
			break;
		}
		Lcmfull();
	}
	JProgramInfo->RealData.CaijiqiNo = CJQno;
	JProgramInfo->RealData.MeterNo = BDZno;
	//��ȡ��ʼ
//	fprintf(stderr,"           CJQno=%d,BDZno=%d\n",JProgramInfo->RealData.CaijiqiNo,JProgramInfo->RealData.MeterNo);
	if (p_flag == 0)
	{
		GUI_Clear();
		Status_Bar();
		GUI_DispStringAt((INT8U *) "��Ϊ�ɼ�����", 32, 64);
		Lcmfull();
		delay(1000);
		return 0;
	}
	else if ((p_flag == 3 && getPoint(CJQno,BDZno)!=0 )||p_flag == 6 || p_flag == 9) {//֮ǰ��֧��������ĵ㳭���㳭�ϲ�������lcy2013
		SetDataFlag97(0x90, 0x10, JProgramInfo->RealData.flg97[0].flg.Dataflag);
		JProgramInfo->RealData.CurFlgCount = 1;
	}else {
		if (JParamInfo3761->group2.f10[getPoint(JProgramInfo->RealData.CaijiqiNo,JProgramInfo->RealData.MeterNo)].ConnectType==2)
		{//����
			jcindex = 0;
			SetDataFlag97(0x90, 0x10, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0x90, 0x11, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0x90, 0x12, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0x90, 0x13, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0x90, 0x14, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);

			SetDataFlag97(0x90, 0x20, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0x90, 0x21, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0x90, 0x22, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0x90, 0x23, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0x90, 0x24, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);

			SetDataFlag97(0x91, 0x10, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0x91, 0x11, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0x91, 0x12, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0x91, 0x13, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0x91, 0x14, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);

			SetDataFlag97(0x91, 0x20, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0x91, 0x21, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0x91, 0x22, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0x91, 0x23, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0x91, 0x24, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);

			SetDataFlag97(0xa0, 0x10, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0xb0, 0x10, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0xa0, 0x20, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0xb0, 0x20, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0xa1, 0x10, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0xb1, 0x10, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0xa1, 0x20, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0xb1, 0x20, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0xb6, 0x11, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0xb6, 0x12, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0xb6, 0x13, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0xb6, 0x21, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0xb6, 0x22, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0xb6, 0x23, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0xb6, 0x30, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0xb6, 0x31, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0xb6, 0x32, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0xb6, 0x33, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0xb6, 0x40, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0xb6, 0x41, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0xb6, 0x42, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0xb6, 0x43, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0xb6, 0x50, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0xb6, 0x51, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0xb6, 0x52, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0xb6, 0x53, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0x94, 0x10, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0x94, 0x20, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0x95, 0x10, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0x95, 0x20, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0xa4, 0x10, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0xb4, 0x10, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0xa4, 0x20, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0xb4, 0x20, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0xa5, 0x10, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0xb5, 0x10, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0xa5, 0x20, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			SetDataFlag97(0xb5, 0x20, JProgramInfo->RealData.flg97[jcindex++].flg.Dataflag);
			JProgramInfo->RealData.CurFlgCount = jcindex;//LQQ
		}else
		{
			SetDataFlag97(0x90, 0x10, JProgramInfo->RealData.flg97[0].flg.Dataflag);
			SetDataFlag97(0x90, 0x11, JProgramInfo->RealData.flg97[1].flg.Dataflag);
			SetDataFlag97(0x90, 0x12, JProgramInfo->RealData.flg97[2].flg.Dataflag);
			SetDataFlag97(0x90, 0x13, JProgramInfo->RealData.flg97[3].flg.Dataflag);
			SetDataFlag97(0x90, 0x14, JProgramInfo->RealData.flg97[4].flg.Dataflag);
			JProgramInfo->RealData.CurFlgCount = 5;
		}
		dly=20;
	}

	//GetCurMeterData(CJQno, BDZno);
	if (JParamInfo3761->group2.f10[getPoint(JProgramInfo->RealData.CaijiqiNo,JProgramInfo->RealData.MeterNo)].ConnectType==2)
	{
		JProgramInfo->RealData.ReadFlg = 3;
	}else
	{
		for (i = 0; i < CurrentflgCount; i++)
			memset(JProgramInfo->RealData.flg97[i].datas, OxXX, sizeof(JProgramInfo->RealData.flg97[i].datas));

//		if ((JParamInfo3761->group2.f10[getPoint(JProgramInfo->RealData.CaijiqiNo,JProgramInfo->RealData.MeterNo)].port!=CarrWavePort) &&
//			(JParamInfo3761->group2.f10[getPoint(JProgramInfo->RealData.CaijiqiNo,JProgramInfo->RealData.MeterNo)].port!=LocalCommPort))
		{
			JProgramInfo->RealData.ReadFlg = 1;
		}
	}
	//��ȡ���
	flag = 0;
	i = 0;
	while (1) {
		ClearThreadTimes(ProjectNo);
//		delay(100);
//		GUI_Clear();
//		Status_Bar();
		if (JParamInfo3761->group2.f10[getPoint(JProgramInfo->RealData.CaijiqiNo,JProgramInfo->RealData.MeterNo)].ConnectType==2)
		{
//			printf("\njiacai-------------------------------------------------------------------1\n");
			jcindex = 0;
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.Z_P_All/64,	&JProgramInfo->RealData.flg97[jcindex++].datas[0],4);
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.Z_P_F[0]/64,&JProgramInfo->RealData.flg97[jcindex++].datas[0],4);
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.Z_P_F[1]/64,&JProgramInfo->RealData.flg97[jcindex++].datas[0],4);
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.Z_P_F[2]/64,&JProgramInfo->RealData.flg97[jcindex++].datas[0],4);
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.Z_P_F[3]/64,&JProgramInfo->RealData.flg97[jcindex++].datas[0],4);

			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.F_P_All/64,	&JProgramInfo->RealData.flg97[jcindex++].datas[0],4);
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.F_P_F[0]/64,&JProgramInfo->RealData.flg97[jcindex++].datas[0],4);
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.F_P_F[1]/64,&JProgramInfo->RealData.flg97[jcindex++].datas[0],4);
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.F_P_F[2]/64,&JProgramInfo->RealData.flg97[jcindex++].datas[0],4);
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.F_P_F[3]/64,&JProgramInfo->RealData.flg97[jcindex++].datas[0],4);

			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.Z_Q_All/64,	&JProgramInfo->RealData.flg97[jcindex++].datas[0],4);
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.Z_Q_F[0]/64,&JProgramInfo->RealData.flg97[jcindex++].datas[0],4);
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.Z_Q_F[1]/64,&JProgramInfo->RealData.flg97[jcindex++].datas[0],4);
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.Z_Q_F[2]/64,&JProgramInfo->RealData.flg97[jcindex++].datas[0],4);
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.Z_Q_F[3]/64,&JProgramInfo->RealData.flg97[jcindex++].datas[0],4);

			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.F_Q_All/64,	&JProgramInfo->RealData.flg97[jcindex++].datas[0],4);
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.F_Q_F[0]/64,&JProgramInfo->RealData.flg97[jcindex++].datas[0],4);
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.F_Q_F[1]/64,&JProgramInfo->RealData.flg97[jcindex++].datas[0],4);
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.F_Q_F[2]/64,&JProgramInfo->RealData.flg97[jcindex++].datas[0],4);
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.F_Q_F[3]/64,&JProgramInfo->RealData.flg97[jcindex++].datas[0],4);

			INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.Z_P_X_All,	&JProgramInfo->RealData.flg97[jcindex++].datas[0],4);
			memcpy(&JProgramInfo->RealData.flg97[jcindex++].datas[0], JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_All_645, 4);
			INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.F_P_X_All,	&JProgramInfo->RealData.flg97[jcindex++].datas[0],4);
			memcpy(&JProgramInfo->RealData.flg97[jcindex++].datas[0], JDataFileInfo->jc.JcMaxXuliang.Time_F_P_X_All_645, 4);

			INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.Z_Q_X_All,	&JProgramInfo->RealData.flg97[jcindex++].datas[0],4);
			memcpy(&JProgramInfo->RealData.flg97[jcindex++].datas[0], JDataFileInfo->jc.JcMaxXuliang.Time_Z_Q_X_All_645, 4);
			INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.F_Q_X_All,	&JProgramInfo->RealData.flg97[jcindex++].datas[0],4);
			memcpy(&JProgramInfo->RealData.flg97[jcindex++].datas[0], JDataFileInfo->jc.JcMaxXuliang.Time_F_Q_X_All_645, 4);
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.VA,&JProgramInfo->RealData.flg97[jcindex++].datas[0],2);
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.VB,&JProgramInfo->RealData.flg97[jcindex++].datas[0],2);
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.VC,&JProgramInfo->RealData.flg97[jcindex++].datas[0],2);
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.IA,&JProgramInfo->RealData.flg97[jcindex++].datas[0],3);
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.IB,&JProgramInfo->RealData.flg97[jcindex++].datas[0],3);
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.IC,&JProgramInfo->RealData.flg97[jcindex++].datas[0],3);
//			fprintf(stderr,"Ua=%d,Ub=%d,Uc=%d\n",JDataFileInfo->jc.JcDdRealData.VA,JDataFileInfo->jc.JcDdRealData.VB,JDataFileInfo->jc.JcDdRealData.VC);
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.P,&JProgramInfo->RealData.flg97[jcindex++].datas[0],3);
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.PA,&JProgramInfo->RealData.flg97[jcindex++].datas[0],3);
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.PB,&JProgramInfo->RealData.flg97[jcindex++].datas[0],3);
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.PC,&JProgramInfo->RealData.flg97[jcindex++].datas[0],3);

			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.Q,&JProgramInfo->RealData.flg97[jcindex++].datas[0],3);
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.QA,&JProgramInfo->RealData.flg97[jcindex++].datas[0],3);
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.QB,&JProgramInfo->RealData.flg97[jcindex++].datas[0],3);
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.QC,&JProgramInfo->RealData.flg97[jcindex++].datas[0],3);

			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.Cos,&JProgramInfo->RealData.flg97[jcindex++].datas[0],2);
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.CosA,&JProgramInfo->RealData.flg97[jcindex++].datas[0],2);
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.CosB,&JProgramInfo->RealData.flg97[jcindex++].datas[0],2);
			INT32U_BCD(JDataFileInfo->jc.JcDdRealData.CosC,&JProgramInfo->RealData.flg97[jcindex++].datas[0],2);

			readjiaocaiYue(&JProgramInfo->RealData.flg97[jcindex++].datas[0], 0x90, 0x10);
			readjiaocaiYue(&JProgramInfo->RealData.flg97[jcindex++].datas[0], 0x90, 0x20);
			readjiaocaiYue(&JProgramInfo->RealData.flg97[jcindex++].datas[0], 0x91, 0x10);
			readjiaocaiYue(&JProgramInfo->RealData.flg97[jcindex++].datas[0], 0x91, 0x20);

			readjiaocaiYue(&JProgramInfo->RealData.flg97[jcindex++].datas[0], 0xa0, 0x10);
			readjiaocaiYue(&JProgramInfo->RealData.flg97[jcindex++].datas[0], 0xb0, 0x10);
			readjiaocaiYue(&JProgramInfo->RealData.flg97[jcindex++].datas[0], 0xa0, 0x20);
			readjiaocaiYue(&JProgramInfo->RealData.flg97[jcindex++].datas[0], 0xb0, 0x20);

			readjiaocaiYue(&JProgramInfo->RealData.flg97[jcindex++].datas[0], 0xa1, 0x10);
			readjiaocaiYue(&JProgramInfo->RealData.flg97[jcindex++].datas[0], 0xb1, 0x10);
			readjiaocaiYue(&JProgramInfo->RealData.flg97[jcindex++].datas[0], 0xa1, 0x20);
			readjiaocaiYue(&JProgramInfo->RealData.flg97[jcindex++].datas[0], 0xb1, 0x20);
		}

//		if (JParamInfo3761->group2.f10[getPoint(JProgramInfo->RealData.CaijiqiNo,JProgramInfo->RealData.MeterNo)].ConnectType==2)
//		{
//			DataCount = JProgramInfo->RealData.CurFlgCount;
//			if (JProgramInfo->RealData.CurFlgCount % 4 == 0)
//				count = JProgramInfo->RealData.CurFlgCount / 4;
//			else
//				count = JProgramInfo->RealData.CurFlgCount / 4 + 1;
//			memcpy(tmeprelData.tempRelTimeDate, JProgramInfo->RealData.flg97, sizeof(JProgramInfo->RealData.flg97));
//
//			for (j = 0; j < DataCount; j++) {
//				memset(&tmeprelData.ChNm[j][0], 0, 30);
//				returnChNm(&tmeprelData.tempRelTimeDate[j].flg.Dataflag[0],	&tmeprelData.ChNm[j][0]);
//			}
//		}
//		if(KeySeleflag!=0)	fprintf(stderr," KeySeleflag=%d                    ",KeySeleflag);
		keysele = KeySeleflag;
//		if(keysele!=0)		fprintf(stderr," keysele=%d\n",keysele);
		KeySeleflag = 0;
		switch (keysele) {
		case 0:
			DelayTime++;
			break;
		case 1:
			if (i == 0)
				i = 0;
			else
				i--;
			break;
		case 2:
			if (i == count - 1)
				i = count - 1;
			else
				i++;
			break;
		case 3:
			break;
		case 4:
			break;
		case 5:
			break;
		case 6:
			JProgramInfo->RealData.ReadFlg = 0;
			return 0;
			break;
		default:
			break;
		}
		if(keysele!=0)	{
			DelayTime=0;
			Lcmfull();
		}
		if (DelayTime >= PageDelayTime*2) {
			OldLevel = 0;
			if (flag == 0)
				JProgramInfo->RealData.ReadFlg = 0;
			return 0;
		}

		if (flag == 0)
		{
			if (JParamInfo3761->group2.f10[getPoint(JProgramInfo->RealData.CaijiqiNo,JProgramInfo->RealData.MeterNo)].ConnectType==2)
			{

				JProgramInfo->RealData.ReadFlg = 9;
//				fprintf(stderr,"ReadFlg=%d\n",JProgramInfo->RealData.ReadFlg);

			}else
			{
//				printf("\nJProgramInfo->RealData.ReadFlg=%d",JProgramInfo->RealData.ReadFlg);
				if (JProgramInfo->RealData.ReadFlg!=9)
				{
					GUI_Clear();
					Status_Bar();
					GUI_DispStringAt((INT8U *) "��ȡ������", 32, 64);
					GUI_DispStringAt((INT8U *) ".", 112, 64);
					if (j == 1) {
						GUI_DispStringAt((INT8U *) ".", 116, 64);
					}
					if (j == 2) {
						GUI_DispStringAt((INT8U *) ".", 116, 64);
						GUI_DispStringAt((INT8U *) ".", 120, 64);
					}
					if (j == 3) {
						GUI_DispStringAt((INT8U *) ".", 116, 64);
						GUI_DispStringAt((INT8U *) ".", 120, 64);
						GUI_DispStringAt((INT8U *) ".", 124, 64);
					}
					Lcmfull();
				}
			}
//			fprintf(stderr,"JProgramInfo->RealData.ReadFlg=%d\n",JProgramInfo->RealData.ReadFlg);
			if (JProgramInfo->RealData.ReadFlg == 9)//��ȡ�ɹ�
			{
				fprintf(stderr,"JProgramInfo->RealData.ReadFlg1111=%d\n",JProgramInfo->RealData.ReadFlg);
				GUI_Clear();
				Status_Bar();
				flag = 1;
				DataCount = JProgramInfo->RealData.CurFlgCount;
				if (JProgramInfo->RealData.CurFlgCount % 4 == 0)
					count = JProgramInfo->RealData.CurFlgCount / 4;
				else
					count = JProgramInfo->RealData.CurFlgCount / 4 + 1;

				memcpy(tmeprelData.tempRelTimeDate, JProgramInfo->RealData.flg97, sizeof(JProgramInfo->RealData.flg97));
				for (j = 0; j < DataCount; j++) {
					memset(&tmeprelData.ChNm[j][0], 0, 30);
					returnChNm(&tmeprelData.tempRelTimeDate[j].flg.Dataflag[0],	&tmeprelData.ChNm[j][0]);
				}
				JProgramInfo->RealData.ReadFlg = 0;
			}
			if (JProgramInfo->RealData.ReadFlg == 4)
			{
				flag = 2;//��ȡ�ɹ�
				JProgramInfo->RealData.ReadFlg = 0;
			}
			if (j != 3)
				j++;
			else
				j = 0;
//			switch (keysele) {
//			case 0:
//				DelayTime++;
//				break;
//			case 1:
//				break;
//			case 2:
//				break;
//			case 3:
//				break;
//			case 4:
//				break;
//			case 5:
//				break;
//			case 6:
//				JProgramInfo->RealData.ReadFlg = 0;
//				return 0;
//				break;
//			default:
//				break;
//
//			}
//			Lcmfull();
//			delay(50);
		} else if (flag == 1) {//��ȡ�ɹ�����ʾ����
			if (JParamInfo3761->group2.f10[getPoint(JProgramInfo->RealData.CaijiqiNo,JProgramInfo->RealData.MeterNo)].ConnectType==2)
				flag = 0;
			GUI_Clear();
			Status_Bar();
			if (count > 1) {
				if (i == 0)
					RunArrow(2);
				else if (i == count-1)
					RunArrow(1);
				else
					RunArrow(3);
			}

			//ÿҳ��ʾ�ĸ�������
			GUI_DispStringAt(tmeprelData.ChNm[i * 4], 0, 16);
			Print_sel_data(tmeprelData.tempRelTimeDate[i * 4].datas,
							tmeprelData.tempRelTimeDate[i * 4].flg.Dataflag,8, 32,
							JParamInfo3761->group2.f10[getPoint(CJQno, BDZno)].ConnectType);
			if (DataCount > i * 4 + 1) {
				GUI_DispStringAt(tmeprelData.ChNm[i * 4 + 1], 0, 48);
				Print_sel_data(
						tmeprelData.tempRelTimeDate[i * 4 + 1].datas,
						tmeprelData.tempRelTimeDate[i * 4 + 1].flg.Dataflag,
						8,
						64,
						JParamInfo3761->group2.f10[getPoint(CJQno, BDZno)].ConnectType);
			}
			if (DataCount > i * 4 + 2) {
				memset(temp, 0, 16);
				GUI_DispStringAt(tmeprelData.ChNm[i * 4 + 2], 0, 80);
				Print_sel_data(
						tmeprelData.tempRelTimeDate[i * 4 + 2].datas,
						tmeprelData.tempRelTimeDate[i * 4 + 2].flg.Dataflag,
						8,
						96,
						JParamInfo3761->group2.f10[getPoint(CJQno, BDZno)].ConnectType);
			}

			if (DataCount > i * 4 + 3) {
				memset(temp, 0, 16);
				GUI_DispStringAt(tmeprelData.ChNm[i * 4 + 3], 0, 112);
				Print_sel_data(
						tmeprelData.tempRelTimeDate[i * 4 + 3].datas,
						tmeprelData.tempRelTimeDate[i * 4 + 3].flg.Dataflag,
						8,
						127,
						JParamInfo3761->group2.f10[getPoint(CJQno, BDZno)].ConnectType);
			}
			//GUI_DispStringAt(tempRelTimeDate[i*4].datas,8,32);
			keysele = KeySeleflag;
//			if(keysele!=0)		fprintf(stderr," keysele22222=%d\n",keysele);
			KeySeleflag =0;
			switch (keysele) {
			case 0:
				DelayTime++;
				break;
			case 1:
				if (i == 0)
					i = 0;
				else
					i--;
				break;
			case 2:
				if (i == count - 1)
					i = count - 1;
				else
					i++;
				break;
			case 3:
				break;
			case 4:
				break;
			case 5:
				break;
			case 6:
				JProgramInfo->RealData.ReadFlg = 0;
				return 0;
				break;
			default:
				break;
			}
			Lcmfull();
		} else {//��ȡʧ��
			GUI_Clear();
			Status_Bar();
			GUI_DispStringAt((INT8U *) "��ȡ����ʧ��!", 30, 64);

			switch (keysele) {
			case 0:
				DelayTime++;
				break;
			case 1:
				break;
			case 2:
				break;
			case 3:
				break;
			case 4:
				break;
			case 5:
				break;
			case 6:
				return 0;
				break;
			default:
				break;
			}
			Lcmfull();
		}
//		Lcmfull();
		delay(50);
	}
	return 1;
}

/******************************************************************************************************************
 * �������ƣ�Show_RealTimeData()�����ڵڶ����˵�
 * ��    �ܣ����鿴��ʵʱ����
 * ��ڲ�������
 * ���ڲ�������
 *******************************************************************************************************************/
int Show_RealTimeData(INT8U SeleMenu) {
	unsigned int DelayTime;
	INT8U keysele;
	INT16U i, j, k=0;
	unsigned char tempAdd[13];
	i = 0;
	int i_begin=0;
	DelayTime = 0;
	initMeterPare();
	while (1) {
		ClearThreadTimes(ProjectNo);
		delay(100);
		GUI_Clear();
		//Status_Bar();//Ȼ��״̬����Ȼ������ʾ�����ı��ţ����ǵ�һ���˵�����
		if (meterCount > 0)
		{
			GUI_DispStringAt((INT8U *) "����      ����ַ", 0, 16);
			i_begin = (i/6)*6;
			k = (meterCount-i_begin>=6 ) ? 6 : meterCount-i_begin;
			//printf("\n i = %d i_begin=%d k=%d meterCount=%d",i, i_begin, k, meterCount);
			for (j = 0; j < k; j++) {
				if((i-i_begin)==j)
					GUI_SetTextMode(GUI_TM_REV);
				GUI_DispDecAt(getPoint(TempMeterPara[i_begin+j].CJQ_hao - 1,
						TempMeterPara[i_begin+j].DNB_hao), 0, 32+j*16, 4);
				GUI_DispStringAt((INT8U *) "   ", 32, 32+j*16);
				BCDToASC(&TempMeterPara[i_begin+j].p_8902.address[0], 6,
						tempAdd);
				GUI_DispStringAt(tempAdd, 56, 32+j*16);//64
				if((i-i_begin)==j)
					GUI_SetTextMode(GUI_TM_NORMAL);
			}
			Status_Bar();//Ȼ��״̬����Ȼ������ʾ�����ı��ţ����ǵ�һ���˵�����
			//���������������ڱ���ַ��������ʾ
			Lcmfull();
			keysele = KeySeleflag;
			KeySeleflag = 0;
			if (DelayTime >= PageDelayTime) {
				OldLevel = 0;
				return 0;
			}
			switch (keysele) {
			case 0:
				DelayTime++;
				break;
			case 1:
				if (i == 0)
					i = meterCount - 1;
				else
					i--;
				DelayTime = 0;
				break;//���ϼ�
			case 2:
				if (i == meterCount - 1)
					i = 0;
				else
					i++;
				DelayTime = 0;
				break;//���¼�
			case 3:
				if (i>=6)
					i=i-6;
				else i = meterCount - 1;
				DelayTime = 0;
				break;
			case 4:
				if (i<=meterCount - 6)
					i=i+6;
				else i=0;
				DelayTime = 0;
				break;
			case 5:
				if (show_realData(TempMeterPara[i].CJQ_hao - 1,
						TempMeterPara[i].DNB_hao - 1, TempMeterPara[i].p_flag,
						TempMeterPara[i].p_8902.address)==2)
				{

				}
				break;//ȷ�ϼ�
			case 6:
				OldLevel = 0;
				return 0;
				break;
			default:
				break;
			}
		} else {
			GUI_DispStringAt((INT8U *) "�޿��ò�����!", 32, 64);
			Lcmfull();
			keysele = KeySeleflag;
			KeySeleflag = 0;
			if (DelayTime >= PageDelayTime) {
				OldLevel = 0;
				return 0;
			}
			switch (keysele) {
			case 0:
				DelayTime++;
				break;
			case 1:
				break;//���ϼ�
			case 2:
				break;//���¼�
			case 3:
				break;
			case 4:
				break;
			case 5:
				break;//ȷ�ϼ�
			case 6:
				OldLevel = 0;
				return 0;
				break;
			default:
				break;
			}
		}
	}
	return 0;
}
int Show_RealTimeData1(INT8U SeleMenu) {
	unsigned int DelayTime;
	INT8U keysele;
	INT16U i, j, k=0;
	unsigned char tempAdd[13];
	unsigned char address[3];
	unsigned char flag=0;
	i = 0;
	int i_begin=0;
	DelayTime = 0;
	memset(address,0,3);
	GUI_Clear();
	GUI_DispStringAt((INT8U *) "���������ַ����λ:", 0, 32);
	memset(NowInput.buf,0,128);
	sprintf((char *)NowInput.buf,"%02x%02x%02x",address[2],address[1],address[0]);
	GUI_DispStringAt((INT8U *)NowInput.buf, 56, 80);
 	while(1)
	{
		ClearThreadTimes(ProjectNo);
		delay(100);
		Status_Bar();
		keysele=KeySeleflag;
		KeySeleflag =0;
		if(keysele!=0)
			DelayTime=0;
		else
			DelayTime++;
		if(DelayTime>=PageDelayTime)
        {
  			OldLevel=0;
			return 0;
		}
		memset(NowInput.buf,0,128);
		sprintf((char *)NowInput.buf,"%02x%02x%02x",address[2],address[1],address[0]);
		i=0;
		while(i<6)
		{
		     NowInput.col[i]=80;
		     NowInput.row[i]=56+i*8;
		     NowInput.set[i]=1;
		     i++;
		}
	   NowInput.AllNum=7;
       switch(keysele)
       {
          	case 5:
            {
				 if(ScreenInput()==1){
					   address[2] = GetNum(&NowInput.buf[0], 2, 3);
					   address[1] = GetNum(&NowInput.buf[2], 2, 3);
					   address[0] = GetNum(&NowInput.buf[4], 2, 3);
					   flag=1;
					   fprintf(stderr,"\n%02x%02x%02x",address[2],address[1],address[0]);
				  }else{
					   address[2] = GetNum(&NowInput.buf[0], 2, 3);
					   address[1] = GetNum(&NowInput.buf[2], 2, 3);
					   address[0] = GetNum(&NowInput.buf[4], 2, 3);
					   if((address[2]==0)&&(address[1]==0)&&(address[0]==0))
						   flag=1;
					   fprintf(stderr,"\n%02x%02x%02x",address[2],address[1],address[0]);
				  }
			 }
			 break;
			 case 6:
			 {
				   OldLevel=0;
				   return 0;
			 }
             break;
             default : break;
       }
    	if(flag==1){
    		initMeterPare_addr(address);
    		fprintf(stderr,"\nmeterCount=%d",meterCount);
    		if (meterCount > 0){
    			break;
    		}else{
    		GUI_Clear();
   			GUI_DispStringAt((INT8U *) "�޿��ò�����!", 32, 64);
   			Lcmfull();
   			keysele = KeySeleflag;
   			KeySeleflag = 0;
   			if (DelayTime >= PageDelayTime) {
   				OldLevel = 0;
   				return 0;
   			}
   			switch (keysele) {
   			case 0:
   				DelayTime++;
   				break;
   			case 1:
   				break;//���ϼ�
   			case 2:
   				break;//���¼�
   			case 3:
   				break;
   			case 4:
   				break;
   			case 5:
   				break;//ȷ�ϼ�
   			case 6:
   				OldLevel = 0;
   				return 0;
   				break;
   			default:
   				break;
   			}
    		}
    	}
       Lcmfull();
	}
 	i=0;
	while (1) {
		ClearThreadTimes(ProjectNo);
		delay(100);
		GUI_Clear();
		//Status_Bar();//Ȼ��״̬����Ȼ������ʾ�����ı��ţ����ǵ�һ���˵�����
		if (meterCount > 0)
		{
			GUI_DispStringAt((INT8U *) "����      ����ַ", 0, 16);
			i_begin = (i/6)*6;
			k = (meterCount-i_begin>=6 ) ? 6 : meterCount-i_begin;
			//printf("\n i = %d i_begin=%d k=%d meterCount=%d",i, i_begin, k, meterCount);
			for (j = 0; j < k; j++) {
				if((i-i_begin)==j)
					GUI_SetTextMode(GUI_TM_REV);
				GUI_DispDecAt(getPoint(TempMeterPara[i_begin+j].CJQ_hao - 1,TempMeterPara[i_begin+j].DNB_hao), 0, 32+j*16, 4);
				GUI_DispStringAt((INT8U *) "   ", 32, 32+j*16);
				BCDToASC(&TempMeterPara[i_begin+j].p_8902.address[0], 6,tempAdd);
				GUI_DispStringAt(tempAdd, 56, 32+j*16);//64
				if((i-i_begin)==j)
					GUI_SetTextMode(GUI_TM_NORMAL);
			}
			Status_Bar();//Ȼ��״̬����Ȼ������ʾ�����ı��ţ����ǵ�һ���˵�����
			//���������������ڱ���ַ��������ʾ
			Lcmfull();
			keysele = KeySeleflag;
			KeySeleflag = 0;
			if (DelayTime >= PageDelayTime) {
				OldLevel = 0;
				return 0;
			}
			switch (keysele) {
			case 0:
				DelayTime++;
				break;
			case 1:
				if (i == 0)
					i = meterCount - 1;
				else
					i--;
				DelayTime = 0;
				break;//���ϼ�
			case 2:
				if (i == meterCount - 1)
					i = 0;
				else
					i++;
				DelayTime = 0;
				break;//���¼�
			case 3:
				if (i>=6)
					i=i-6;
				else i = meterCount - 1;
				DelayTime = 0;
				break;
			case 4:
				if (i<=meterCount - 6)
					i=i+6;
				else i=0;
				DelayTime = 0;
				break;
			case 5:
				if (show_realData(TempMeterPara[i].CJQ_hao - 1,
						TempMeterPara[i].DNB_hao - 1, TempMeterPara[i].p_flag,
						TempMeterPara[i].p_8902.address)==2)
				{

				}
				break;//ȷ�ϼ�
			case 6:
				OldLevel = 0;
				return 0;
				break;
			default:
				break;
			}
		} else {
			GUI_Clear();
			GUI_DispStringAt((INT8U *) "�޿��ò�����!", 32, 64);
			Lcmfull();
			keysele = KeySeleflag;
			KeySeleflag = 0;
			if (DelayTime >= PageDelayTime) {
				OldLevel = 0;
				return 0;
			}
			switch (keysele) {
			case 0:
				DelayTime++;
				break;
			case 1:
				break;//���ϼ�
			case 2:
				break;//���¼�
			case 3:
				break;
			case 4:
				break;
			case 5:
				break;//ȷ�ϼ�
			case 6:
				OldLevel = 0;
				return 0;
				break;
			default:
				break;
			}
		}
	}
	return 0;
}
int Show_RealTimeData2(INT8U SeleMenu) {
	unsigned int DelayTime;
	INT8U keysele;
	INT16U i, j, k=0;
	unsigned char tempAdd[13];
	unsigned char clno=0;
	unsigned char flag=0;
	i = 0;
	int i_begin=0;
	DelayTime = 0;
	GUI_Clear();
	GUI_DispStringAt((INT8U *) "������������:", 0, 32);
	memset(NowInput.buf,0,128);
	sprintf((char *)NowInput.buf,"%04d",clno);
	GUI_DispStringAt((INT8U *)NowInput.buf, 56, 80);
 	while(1)
	{
		ClearThreadTimes(ProjectNo);
		delay(100);
		Status_Bar();
		keysele=KeySeleflag;
		KeySeleflag =0;
		if(keysele!=0)
			DelayTime=0;
		else
			DelayTime++;
		if(DelayTime>=PageDelayTime)
        {
  			OldLevel=0;
			return 0;
		}
		memset(NowInput.buf,0,128);
		sprintf((char *)NowInput.buf,"%04d",clno);
		i=0;
		while(i<4)
		{
		     NowInput.col[i]=80;
		     NowInput.row[i]=56+i*8;
		     NowInput.set[i]=1;
		     i++;
		}
	   NowInput.AllNum=5;
       switch(keysele)
       {
          	case 5:
            {
				 if(ScreenInput()==1){
					 clno = GetNum(&NowInput.buf[0], 4, 1);
					 flag=1;
					 fprintf(stderr,"\n%04d",clno);
				  }
			 }
			 break;
			 case 6:
			 {
				   OldLevel=0;
				   return 0;
			 }
             break;
             default : break;
       }
    	if(flag==1){
    		initMeterPare_clno(clno);
    		fprintf(stderr,"\nmeterCount=%d",meterCount);
    		if (meterCount > 0){
    			break;
    		}else{
    		GUI_Clear();
   			GUI_DispStringAt((INT8U *) "�޿��ò�����!", 32, 64);
   			Lcmfull();
   			keysele = KeySeleflag;
   			KeySeleflag = 0;
   			if (DelayTime >= PageDelayTime) {
   				OldLevel = 0;
   				return 0;
   			}
   			switch (keysele) {
   			case 0:
   				DelayTime++;
   				break;
   			case 1:
   				break;//���ϼ�
   			case 2:
   				break;//���¼�
   			case 3:
   				break;
   			case 4:
   				break;
   			case 5:
   				break;//ȷ�ϼ�
   			case 6:
   				OldLevel = 0;
   				return 0;
   				break;
   			default:
   				break;
   			}
    		}
    	}
       Lcmfull();
	}
 	i=0;
	while (1) {
		ClearThreadTimes(ProjectNo);
		delay(100);
		GUI_Clear();
		//Status_Bar();//Ȼ��״̬����Ȼ������ʾ�����ı��ţ����ǵ�һ���˵�����
		if (meterCount > 0)
		{
			GUI_DispStringAt((INT8U *) "����      ����ַ", 0, 16);
			i_begin = (i/6)*6;
			k = (meterCount-i_begin>=6 ) ? 6 : meterCount-i_begin;
			//printf("\n i = %d i_begin=%d k=%d meterCount=%d",i, i_begin, k, meterCount);
			for (j = 0; j < k; j++) {
				if((i-i_begin)==j)
					GUI_SetTextMode(GUI_TM_REV);
				GUI_DispDecAt(getPoint(TempMeterPara[i_begin+j].CJQ_hao - 1,TempMeterPara[i_begin+j].DNB_hao), 0, 32+j*16, 4);
				GUI_DispStringAt((INT8U *) "   ", 32, 32+j*16);
				BCDToASC(&TempMeterPara[i_begin+j].p_8902.address[0], 6,tempAdd);
				GUI_DispStringAt(tempAdd, 56, 32+j*16);//64
				if((i-i_begin)==j)
					GUI_SetTextMode(GUI_TM_NORMAL);
			}
			Status_Bar();//Ȼ��״̬����Ȼ������ʾ�����ı��ţ����ǵ�һ���˵�����
			//���������������ڱ���ַ��������ʾ
			Lcmfull();
			keysele = KeySeleflag;
			KeySeleflag = 0;
			if (DelayTime >= PageDelayTime) {
				OldLevel = 0;
				return 0;
			}
			switch (keysele) {
			case 0:
				DelayTime++;
				break;
			case 1:
				if (i == 0)
					i = meterCount - 1;
				else
					i--;
				DelayTime = 0;
				break;//���ϼ�
			case 2:
				if (i == meterCount - 1)
					i = 0;
				else
					i++;
				DelayTime = 0;
				break;//���¼�
			case 3:
				if (i>=6)
					i=i-6;
				else i = meterCount - 1;
				DelayTime = 0;
				break;
			case 4:
				if (i<=meterCount - 6)
					i=i+6;
				else i=0;
				DelayTime = 0;
				break;
			case 5:
				if (show_realData(TempMeterPara[i].CJQ_hao - 1,
						TempMeterPara[i].DNB_hao - 1, TempMeterPara[i].p_flag,
						TempMeterPara[i].p_8902.address)==2)
				{

				}
				break;//ȷ�ϼ�
			case 6:
				OldLevel = 0;
				return 0;
				break;
			default:
				break;
			}
		} else {
			GUI_Clear();
			GUI_DispStringAt((INT8U *) "�޿��ò�����!", 32, 64);
			Lcmfull();
			keysele = KeySeleflag;
			KeySeleflag = 0;
			if (DelayTime >= PageDelayTime) {
				OldLevel = 0;
				return 0;
			}
			switch (keysele) {
			case 0:
				DelayTime++;
				break;
			case 1:
				break;//���ϼ�
			case 2:
				break;//���¼�
			case 3:
				break;
			case 4:
				break;
			case 5:
				break;//ȷ�ϼ�
			case 6:
				OldLevel = 0;
				return 0;
				break;
			default:
				break;
			}
		}
	}
	return 0;
}
/******************************************************************************************************************
 * �������ƣ�Show_allRealData()�����ڵڶ����˵�
 * ��    �ܣ���ʾ���в���������
 * ��ڲ�������
 * ���ڲ�������
 *******************************************************************************************************************/
int Show_allRealData(INT8U SeleMenu)
{
	return 0;
}

/******************************************************************************************************************
 * �������ƣ�Show_HisData_Day()�����ڵ������˵�
 * ��    �ܣ����鿴����ʾ����ʷ����
 * ��ڲ�������
 * ���ڲ�������
 *******************************************************************************************************************/
int Show_HisData_Day(INT8U SeleMenu) {
	unsigned int DelayTime;
	TS ts;
	INT8U keysele;
	unsigned char tempAdd[13];
	DelayTime = 0;
	INT16U TempBufY[1],i, j, k, flag = 0;
	unsigned char TempBuf[8], temp_time[16];
	memset(temp_time, 0, 16);
	GUI_Clear();
	GUI_DrawHLine(16, 32, 140);
	GUI_DrawVLine(16, 32, 96);
	GUI_DrawVLine(140, 32, 96);
	GUI_DrawHLine(16, 96, 140);
	GUI_DispStringAt((INT8U *) "��ѡ������", 44, 40);
	GUI_DispStringAt((INT8U *) "��", 56, 56);
	GUI_DispStringAt((INT8U *) "��", 88, 56);
	GUI_DispStringAt((INT8U *) "��", 120, 56);
	TSGet(&ts);
	Status_Bar();
	GUI_DispDecAt(0, 24, 56, 4);
	GUI_DispDecAt(0, 72, 56, 2);
	GUI_DispDecAt(0, 104, 56, 2);
	memset(NowInput.buf, 0, 128);
	sprintf((char*) NowInput.buf, "%04d%02d%02d", ts.Year, ts.Month, ts.Day); //����ת����Ϊ�ַ���
	i = 0;
	while (i < 4) {
		NowInput.col[i] = 56;
		NowInput.row[i] = 24 + i * 8;
		NowInput.set[i] = 1;
		i++;
	}
	i = 0;
	while (i < 2) {
		NowInput.col[i + 4] = 56;
		NowInput.row[i + 4] = 72 + i * 8;
		NowInput.set[i + 4] = 1;
		i++;
	}
	i = 0;
	while (i < 2) {
		NowInput.col[i + 6] = 56;
		NowInput.row[i + 6] = 104 + i * 8;
		NowInput.set[i + 6] = 1;
		i++;
	}
	NowInput.AllNum = 9;
	flag = ScreenInput();
	if (flag == 1 || flag == 0) {
		TempBufY[0] = GetNum(&NowInput.buf[0], 4, 1);//��������е�������
		for (i = 1; i < 3; i++) {
			TempBuf[i] = GetNum(&NowInput.buf[2* i + 2], 2, 1);//��������е��º�������
		}
		sprintf((char*) temp_time, "%02d", TempBuf[2]); //����ת����Ϊ�ַ���
		//fprintf( stderr, "The aaaaaaaaaaaaaaaaaaaaaaaaaddddddddd    Begin read day date: %s\n",temp_time);
		initMeterPare();
		//fprintf( stderr, "The step1\n");
		i = 0;
		while (1) {
			ClearThreadTimes(ProjectNo);
			GUI_Clear();
			Status_Bar();//Ȼ��״̬����Ȼ������ʾ�����ı��ţ����ǵ�һ���˵�����
			// fprintf( stderr, "The aaaaaaaaaaaaaaaaaaaaaaaaa the COunt %d\n",meterCount);
			if (meterCount > 0) {
				GUI_DispStringAt((INT8U *) "����      ����ַ", 0, 16);
				GUI_SetTextMode(GUI_TM_REV);
				GUI_DispDecAt(getPoint(TempMeterPara[i].CJQ_hao - 1,
						TempMeterPara[i].DNB_hao), 0, 32, 4);
				GUI_DispStringAt((INT8U *) "   ", 32, 32);
				BCDToASC(&TempMeterPara[i].p_8902.address[0], 6, tempAdd);
				GUI_DispStringAt(tempAdd, 56, 32);
				GUI_SetTextMode(GUI_TM_NORMAL);
				k = 0;
				if (meterCount - i >= 6)
					k = 5;
				else
					k = meterCount - i - 1;
				for (j = 0; j < k; j++) {
					GUI_DispDecAt(getPoint(
							TempMeterPara[i + j + 1].CJQ_hao - 1,
							TempMeterPara[i + j + 1].DNB_hao), 0, 48 + j * 16,
							4);
					//GUI_DispDecAt(TempMeterPara[i+j+1].CJQ_hao-1,0,48+j*16,3);
					//GUI_DispDecAt(TempMeterPara[i+j+1].DNB_hao,32,48+j*16,2);
					BCDToASC(&TempMeterPara[i + j + 1].p_8902.address[0], 6,
							tempAdd);
					GUI_DispStringAt(tempAdd, 56, 48 + j * 16);
				}
				//���������������ڱ���ַ��������ʾ
				Lcmfull();
				keysele = KeySeleflag;
				KeySeleflag = 0;
				if (DelayTime >= PageDelayTime) {
					OldLevel = 0;
					return 0;
				}
				switch (keysele) {
				case 0:
					DelayTime++;
					break;
				case 1:
					if (i == 0)
						i = meterCount - 1;
					else
						i--;
					DelayTime = 0;
					break;//���ϼ�
				case 2:
					if (i == meterCount - 1)
						i = 0;
					else
						i++;
					DelayTime = 0;
					break;//���¼�
				case 3:
					if (i>=6)
						i=i-6;
					else i = meterCount - 1;
					DelayTime = 0;
					break;
				case 4:
					if (i<=meterCount - 6)
						i=i+6;
					else i=0;
					DelayTime = 0;
					break;
				case 5:
					ShowHisData(TempMeterPara[i].CJQ_hao - 1,
							TempMeterPara[i].DNB_hao-1, (INT8U *) temp_time,
							1, TempMeterPara[i].p_flag,
							TempMeterPara[i].p_8902.address);
					break;//ȷ�ϼ�
				case 6:
					OldLevel = 0;//
					return 0;
					break;
				default:
					break;
				}
			} else {
				GUI_DispStringAt((INT8U *) "�޿��ò�����!", 32, 64);
				Lcmfull();
				keysele = KeySeleflag;
				KeySeleflag = 0;
				if (DelayTime >= PageDelayTime) {
					OldLevel = 0;
					return 0;
				}
				switch (keysele) {
				case 0:
					DelayTime++;
					break;
				case 1:
					break;//���ϼ�
				case 2:
					break;//���¼�
				case 3:
					break;
				case 4:
					break;
				case 5:
					break;//ȷ�ϼ�
				case 6:
					OldLevel = 0;
					return 0;
					break;
				default:
					break;
				}
			}
			delay(100);
		}
	} else {
		MenuSele = 15;
		GUI_Clear();
		Status_Bar();
		//GUI_DispStringAt((INT8U *)"���ڸ�ʽ����!",32,96);
		for (j = 0; j < MenuNums; j++) {
			if (Menu[j].level == Menu[MenuSele].level) {
				GUI_DispStringAt((INT8U *) Menu[j].Str, Menu[j].row,
						Menu[j].col);
			}
		}
		Lcmfull();
	}
	return 0;
}
/******************************************************************************************************************
 * �������ƣ�Show_HisData_Month()�����ڵ������˵�
 * ��    �ܣ����鿴����ʾ����ʷ����
 * ��ڲ�������
 * ���ڲ�������
 *******************************************************************************************************************/
int Show_HisData_Month(INT8U SeleMenu) {
	unsigned int DelayTime;
	TS ts;
	INT8U keysele;
	unsigned char tempAdd[13];
	DelayTime = 0;
	INT16U TempBufY[1],i, j, k, flag = 0;
	unsigned char TempBuf[8], temp_time[16];
	memset(temp_time, 0, 16);
	GUI_Clear();
	TSGet(&ts);
	GUI_DrawHLine(16, 32, 140);
	GUI_DrawVLine(16, 32, 96);
	GUI_DrawVLine(140, 32, 96);
	GUI_DrawHLine(16, 96, 140);
	GUI_DispStringAt((INT8U *) "��ѡ������", 44, 40);
	GUI_DispStringAt((INT8U *) "��", 76, 56);
	GUI_DispStringAt((INT8U *) "��", 108, 56);
	Status_Bar();
	memset(NowInput.buf, 0, 128);
	sprintf((char*) NowInput.buf, "%04d%02d", ts.Year, ts.Month); //����ת����Ϊ�ַ���
	i = 0;
	while (i < 4) {
		NowInput.col[i] = 56;
		NowInput.row[i] = 44 + i * 8;
		NowInput.set[i] = 1;
		i++;
	}
	i = 0;
	while (i < 2) {
		NowInput.col[i + 4] = 56;
		NowInput.row[i + 4] = 92 + i * 8;
		NowInput.set[i + 4] = 1;
		i++;
	}
	NowInput.AllNum = 7;
	flag = ScreenInput();
	if (flag == 1 || flag == 0) {
		TempBufY[0] = GetNum(&NowInput.buf[0], 4, 1);//��������е�������
		for (i = 1; i < 3; i++) {
			TempBuf[i] = GetNum(&NowInput.buf[2* i + 2], 2, 1);//��������е��º�������
		}

		sprintf((char*) temp_time, "%02d", TempBuf[1]); //����ת����Ϊ�ַ���
		//fprintf( stderr, "The aaaaaaaaaaaaaaaaaaaaaaaaaddddddddd    Begin read month date: %s\n",temp_time);
		initMeterPare();
		//fprintf( stderr, "The step1\n");
		i = 0;
		while (1) {
			ClearThreadTimes(ProjectNo);
			delay(100);
			GUI_Clear();
			Status_Bar();//Ȼ��״̬����Ȼ������ʾ�����ı��ţ����ǵ�һ���˵�����
			// fprintf( stderr, "The aaaaaaaaaaaaaaaaaaaaaaaaa the COunt %d\n",meterCount);
			if (meterCount > 0) {
				GUI_DispStringAt((INT8U *) "����      ����ַ", 0, 16);
				GUI_SetTextMode(GUI_TM_REV);
				GUI_DispDecAt(getPoint(TempMeterPara[i].CJQ_hao - 1,
						TempMeterPara[i].DNB_hao), 0, 32, 4);
				/*GUI_DispDecAt(TempMeterPara[i].CJQ_hao-1,0,32,3);
				 GUI_DispStringAt((INT8U *)" ",24,32);
				 GUI_DispDecAt(TempMeterPara[i].DNB_hao,32,32,2);
				 GUI_DispStringAt((INT8U *)"  ",48,32);*/
				GUI_DispStringAt((INT8U *) "   ", 32, 32);
				BCDToASC(&TempMeterPara[i].p_8902.address[0], 6, tempAdd);
				GUI_DispStringAt(tempAdd, 56, 32);
				GUI_SetTextMode(GUI_TM_NORMAL);
				k = 0;
				if (meterCount - i >= 6)
					k = 5;
				else
					k = meterCount - i - 1;
				for (j = 0; j < k; j++) {
					GUI_DispDecAt(getPoint(
							TempMeterPara[i + j + 1].CJQ_hao - 1,
							TempMeterPara[i + j + 1].DNB_hao), 0, 48 + j * 16,
							4);
					//GUI_DispDecAt(TempMeterPara[i+j+1].CJQ_hao-1,0,48+j*16,3);
					// GUI_DispDecAt(TempMeterPara[i+j+1].DNB_hao,32,48+j*16,2);
					BCDToASC(&TempMeterPara[i + j + 1].p_8902.address[0], 6,
							tempAdd);
					GUI_DispStringAt(tempAdd, 56, 48 + j * 16);
				}
				//���������������ڱ���ַ��������ʾ
				Lcmfull();
				keysele = KeySeleflag;
				KeySeleflag = 0;
				if (DelayTime >= PageDelayTime) {
					OldLevel = 0;
					return 0;
				}
				switch (keysele) {
				case 0:
					DelayTime++;
					break;
				case 1:
					if (i == 0)
						i = meterCount - 1;
					else
						i--;
					DelayTime = 0;
					break;//���ϼ�
				case 2:
					if (i == meterCount - 1)
						i = 0;
					else
						i++;
					DelayTime = 0;
					break;//���¼�
				case 3:
					if (i>=6)
						i=i-6;
					else i = meterCount - 1;
					DelayTime = 0;
					break;
				case 4:
					if (i<=meterCount - 6)
						i=i+6;
					else i=0;
					DelayTime = 0;
					break;
				case 5:
					ShowHisData(TempMeterPara[i].CJQ_hao - 1,
							TempMeterPara[i].DNB_hao-1, (INT8U *) temp_time,
							2, TempMeterPara[i].p_flag,
							TempMeterPara[i].p_8902.address);
					break;//ȷ�ϼ�
				case 6:
					OldLevel = 0;
					return 0;
					break;
				default:
					break;
				}
			} else {
				GUI_DispStringAt((INT8U *) "�޿��ò�����!", 32, 64);
				Lcmfull();
				keysele = KeySeleflag;
				KeySeleflag = 0;
				if (DelayTime >= PageDelayTime) {
					OldLevel = 0;
					return 0;
				}
				switch (keysele) {
				case 0:
					DelayTime++;
					break;
				case 1:
					break;//���ϼ�
				case 2:
					break;//���¼�
				case 3:
					break;
				case 4:
					break;
				case 5:
					break;//ȷ�ϼ�
				case 6:
					OldLevel = 0;
					return 0;
					break;
				default:
					break;
				}
			}

		}
	} else {
		MenuSele = 15;
		GUI_Clear();
		Status_Bar();
		//GUI_DispStringAt((INT8U *)"���ڸ�ʽ����!",32,96);
		for (j = 0; j < MenuNums; j++) {
			if (Menu[j].level == Menu[MenuSele].level) {
				GUI_DispStringAt((INT8U *) Menu[j].Str, Menu[j].row,
						Menu[j].col);
			}
		}
	}
	return 0;
}
/******************************************************************************************************************
 * �������ƣ�ShowHisData()�����ڵ������˵�
 * ��    �ܣ��������ַ-����������-����ʾ�ɼ�������ʷ����
 * ��ڲ�����CJQno�ɼ������,BDZnoΪ�������ַ,flagΪ���ݱ�־λ(1Ϊ�����ݣ�2Ϊ������),
 *          temp_time����(��ʽ:������yyyymmdd,������yyyymm),DBaddΪ���ܱ���ַ,P_typeΪ����������
 * ���ڲ�������
 ******************************************************************************************************************/
void ShowHisData(INT8U CJQno, INT8U BDZno, INT8U* temp_time, int flag,
		INT8U P_type, unsigned char *MeterAdd) {
	INT8U CZflag2, count, DataCount, tempData[DataLenMax];//CZflag��ʶ�ò������Ƿ����
	INT16U i;
	unsigned int DelayTime = 0;
	//FILE *fp;
	INT8U keysele;
	unsigned char TempPath[60], temp[16], BZW[2], temp_fileName[16], DBadd[13];
	memset(DBadd, 0, 13);
	BCDToASC(MeterAdd, 6, &DBadd[0]);
	memset(TempPath, 0, 60);
	memset(temp_fileName, 0, 16);
	memset(BZW, 0, 2);
	DataCount = 0;
	//printf( "\n\rThe Step1   Show History data %d--%d\n\r",CJQno,BDZno);
	if (flag == 1) {
		memcpy(&temp_fileName[0], temp_time, 2);
		memcpy(&temp_fileName[2], ".dat", 4);
		sprintf((char*) TempPath, "/nand/DataDay/%04d/",getPoint(CJQno, BDZno+1));
	} else {
		memcpy(&temp_fileName[0], temp_time, 2);
		memcpy(&temp_fileName[2], ".dat", 4);
		sprintf((char*) TempPath, "/nand/DataMonth/%04d/",getPoint(CJQno, BDZno+1));
	}
	i = 0;
	CZflag2 = 0;
	if (P_type == 0)
	{
		GUI_Clear();
		Status_Bar();
		GUI_DispStringAt((INT8U *) "��Ϊ�ɼ�����", 32, 64);
		Lcmfull();
		delay(1000);
		return;
	}
	else if ((P_type == 6) || (P_type == 9)) {//�����
		memset(&smfile, 0, sizeof(SMFiles));
		for (i = 0; i < 60; i++) {
			if (TempPath[i] == 0)
				break;
		}
		memcpy(&TempPath[i], temp_fileName, 16);
		//fp=gzopen(TempPath,"r");
		//if(fp!=NULL)
		SdPrint("TempPath=%s\n\r",TempPath);
		if (access((char*) TempPath, 0) == 0) {
			ReadFile((char*) TempPath, &smfile, sizeof(SMFiles),JProgramInfo);//��ȡ���ݵ�������

			SdPrint("CaijiQiNo=%d--%d--%d--%d\n\r",smfile.sm.CaijiQiNo,CJQno,smfile.sm.MeterNo,BDZno);
			if (smfile.sm.CaijiQiNo == CJQno && smfile.sm.MeterNo == BDZno) {
				memset(tempData, 0, sizeof(tempData));
				GetSingleData(smfile.sm.datas, &tempData[0], 0x90,
						0x10);
				memcpy(tmephelData.tempRelTimeDate[0].datas, &tempData[0],
						4);
				SetDataFlag97(0x90, 0x10,
						tmephelData.tempRelTimeDate[0].flg.Dataflag);
				returnChNm(tmephelData.tempRelTimeDate[0].flg.Dataflag,
						tmephelData.ChNm[0]);

				DataCount = 1;
				CZflag2 = 1;
			}
		} else {
			//gzclose(fp);
		}
	} else {//�๦�ܱ�
		memset(&smfile, 0, sizeof(SMFiles));
		for (i = 0; i < 60; i++) {
			if (TempPath[i] == 0)
				break;
		}
		memcpy(&TempPath[i], temp_fileName, 16);
		SdPrint("mTempPath=%s\n\r",TempPath);
		//fp=gzopen(TempPath,"r");
		//if(fp!=NULL)
		if (access((char*) TempPath, 0) == 0) {
			//gzclose(fp);
			ReadFile((char*) TempPath, &smfile, sizeof(SMFiles),JProgramInfo);//��ȡ���ݵ�������
			SdPrint("mCaijiQiNo=%d--%d--%d--%d\n\r",smfile.sm.CaijiQiNo,CJQno,smfile.sm.MeterNo,BDZno);
			if (smfile.sm.CaijiQiNo == CJQno && smfile.sm.MeterNo == BDZno) {
				memset(tmephelData.ChNm, 0, sizeof(tmephelData.ChNm));

				SetDataFlag97(0x90, 0x10,
						tmephelData.tempRelTimeDate[0].flg.Dataflag);
				returnChNm(tmephelData.tempRelTimeDate[0].flg.Dataflag,
						tmephelData.ChNm[0]);

				SetDataFlag97(0x90, 0x11,
						tmephelData.tempRelTimeDate[1].flg.Dataflag);
				returnChNm(tmephelData.tempRelTimeDate[1].flg.Dataflag,
						tmephelData.ChNm[1]);

				SetDataFlag97(0x90, 0x12,
						tmephelData.tempRelTimeDate[2].flg.Dataflag);
				returnChNm(tmephelData.tempRelTimeDate[2].flg.Dataflag,
						tmephelData.ChNm[2]);

				SetDataFlag97(0x90, 0x13,
						tmephelData.tempRelTimeDate[3].flg.Dataflag);
				returnChNm(tmephelData.tempRelTimeDate[3].flg.Dataflag,
						tmephelData.ChNm[3]);

				SetDataFlag97(0x90, 0x14,
						tmephelData.tempRelTimeDate[4].flg.Dataflag);
				returnChNm(tmephelData.tempRelTimeDate[4].flg.Dataflag,
						tmephelData.ChNm[4]);

				SetDataFlag97(0xb6, 0x11,
						tmephelData.tempRelTimeDate[5].flg.Dataflag);
				returnChNm(tmephelData.tempRelTimeDate[5].flg.Dataflag,
						tmephelData.ChNm[5]);

				SetDataFlag97(0xb6, 0x12,
						tmephelData.tempRelTimeDate[6].flg.Dataflag);
				returnChNm(tmephelData.tempRelTimeDate[6].flg.Dataflag,
						tmephelData.ChNm[6]);

				SetDataFlag97(0xb6, 0x13,
						tmephelData.tempRelTimeDate[7].flg.Dataflag);
				returnChNm(tmephelData.tempRelTimeDate[7].flg.Dataflag,
						tmephelData.ChNm[7]);

				SetDataFlag97(0xb6, 0x21,
						tmephelData.tempRelTimeDate[8].flg.Dataflag);
				returnChNm(tmephelData.tempRelTimeDate[8].flg.Dataflag,
						tmephelData.ChNm[8]);

				SetDataFlag97(0xb6, 0x22,
						tmephelData.tempRelTimeDate[9].flg.Dataflag);
				returnChNm(tmephelData.tempRelTimeDate[9].flg.Dataflag,
						tmephelData.ChNm[9]);

				SetDataFlag97(0xb6, 0x23,
						tmephelData.tempRelTimeDate[10].flg.Dataflag);
				returnChNm(tmephelData.tempRelTimeDate[10].flg.Dataflag,
						tmephelData.ChNm[10]);

				DataCount = 11;
				transManyData(&tmephelData, smfile.sm.datas, 11);
				//fprintf( stderr, "The cccccccccccccccccccccccccccc the Page %d\n",DataCount);
				CZflag2 = 1;
			}
		} else {
			//gzclose(fp);
		}
	}

	if (DataCount % 4 == 0) {
		count = DataCount / 4;
	} else {
		count = DataCount / 4 + 1;
	}
	//fprintf( stderr, "The aaaaaaaaaaaaaaaaaaaaaaaaa the Page %d\n",count);
	if (CZflag2 == 1) {//��ȡ����֮���ٴ��жϸò������ڱ�����������Ƿ����
		i = 0;
		while (1) {//�ֵ����������
			ClearThreadTimes(ProjectNo);
			GUI_Clear();
			Status_Bar();
			//ÿҳ��ʾ�ĸ�������
			GUI_DispStringAt(tmephelData.ChNm[i * 4], 0, 16);
			Print_sel_data(tmephelData.tempRelTimeDate[i * 4].datas,
					tmephelData.tempRelTimeDate[i * 4].flg.Dataflag, 8, 32,
					JParamInfo3761->group2.f10[getPoint(CJQno, BDZno)].ConnectType);
			//fprintf( stderr, "The step1");
			if (DataCount > i * 4 + 1) {
				GUI_DispStringAt(tmephelData.ChNm[i * 4 + 1], 0, 48);
				Print_sel_data(
						tmephelData.tempRelTimeDate[i * 4 + 1].datas,
						tmephelData.tempRelTimeDate[i * 4 + 1].flg.Dataflag,
						8,
						64,
						JParamInfo3761->group2.f10[getPoint(CJQno, BDZno)].ConnectType);
			}
			if (DataCount > i * 4 + 2) {
				memset(temp, 0, 16);
				GUI_DispStringAt(tmephelData.ChNm[i * 4 + 2], 0, 80);
				Print_sel_data(
						tmephelData.tempRelTimeDate[i * 4 + 2].datas,
						tmephelData.tempRelTimeDate[i * 4 + 2].flg.Dataflag,
						8,
						96,
						JParamInfo3761->group2.f10[getPoint(CJQno, BDZno)].ConnectType);
			}
			if (DataCount > i * 4 + 3) {
				memset(temp, 0, 16);
				GUI_DispStringAt(tmephelData.ChNm[i * 4 + 3], 0, 112);
				Print_sel_data(
						tmephelData.tempRelTimeDate[i * 4 + 3].datas,
						tmephelData.tempRelTimeDate[i * 4 + 3].flg.Dataflag,
						8,
						127,
						JParamInfo3761->group2.f10[getPoint(CJQno, BDZno)].ConnectType);
			}
			//fprintf( stderr, "The step4");
			//GUI_DispStringAt(tempRelTimeDate[i*4].datas,8,32);
			keysele = KeySeleflag;
			KeySeleflag = 0;
			if (DelayTime >= PageDelayTime) {
				return;
			}
			switch (keysele) {
			case 0:
				DelayTime++;
				break;
			case 1:
				if (i == 0)
					i = 0;
				else
					i--;
				break;
			case 2:
				if (i == count - 1)
					i = count - 1;
				else
					i++;
				break;
			case 3:
				break;
			case 4:
				break;
			case 5:
				break;
			case 6:
				SdPrint("return----\n\r");
				return;
				break;
			default:
				break;
			}
			GUI_DispStringAt((INT8U *) "(", 0, 144);
			GUI_DispStringAt((INT8U *) ") ", 40, 144);
			GUI_DispDecAt(getPoint(CJQno, BDZno + 1), 8, 144, 4);
			GUI_DispStringAt(DBadd, 56, 144);
			Lcmfull();
			delay(100);
		}
	} else {
		while (1) {//�ֵ����������
			ClearThreadTimes(ProjectNo);
			GUI_Clear();
			Status_Bar();
			GUI_DispStringAt((INT8U *) "����ʷ����!", 32, 64);
			Lcmfull();
			delay(100);
			keysele = KeySeleflag;
			KeySeleflag = 0;
			if (DelayTime >= PageDelayTime) {
				return;
			}
			switch (keysele) {
			case 0:
				DelayTime++;
				break;
			case 1:
				break;//���ϼ�
			case 2:
				break;//���¼�
			case 3:
				break;
			case 4:
				break;
			case 5:
				break;//ȷ�ϼ�
			case 6:
				return;
				break;
			default:
				break;
			}
		}
	}
}
