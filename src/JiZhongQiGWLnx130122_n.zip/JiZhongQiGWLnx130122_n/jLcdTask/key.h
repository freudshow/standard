#ifndef _KEYMCB_H
#define _KEYMCB_H
enum KEY_STATUS
{
    KEY_WAIT,
    KEY_HOLD,
    KEY_DOWN,
    KEY_RIGHT,
    KEY_ENTER,
	KEY_RECALL


};
extern enum KEY_STATUS key_Status;
void key_Scan(void);
#endif
