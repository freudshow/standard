
typedef struct
{
	int memused;
	int cpuload;
	int nandused;
	int norused;
}JzqLoadInfo_t;


int SearchProcFile(char *filename, char *name, char *ret, char flag_serarch);
int getMemInfo();
int getNandInfo();
int getNorInfo();
int getCpuInfo();
