/**********************************************************************/
//Copyright ��Ȩ����
// �ļ�����jIfrcom.c
//
// �޸ı�ʶ��
// �޸�������
/**********************************************************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <inc/CVariable.h>
#include <inc/pubfunction.h>
#include <signal.h>
#include <pthread.h>
#include "jIfr.h"
#include "../j3761_2009/j3761_2009.h"

/*
 * ���ô��ڲ���
 */
int Init_port_parm(INT8U port, int baud, char *par, unsigned char stopb, INT8U bits)
{
	struct termios old_termi,new_termi;
	int baud_lnx=0;
	unsigned char tmp[128];
	memset(tmp,0,128);
    if(ComPort>0)
    	close(ComPort);
    sprintf((char *)tmp,"/dev/ttyS%d",port);
    ComPort = open((char *)tmp, O_RDWR|O_NOCTTY);/* �򿪴����ļ� */
    if( ComPort<0 )
    {
    	printf("open the serial port fail! errno is: %d\n", errno);
    	return 0; /*�򿪴���ʧ��*/
    }
    if ( tcgetattr( ComPort, &old_termi) != 0) /*�洢ԭ��������*/
    {
    	printf("get the terminal parameter error when set baudrate! errno is: %d\n", errno);
    	/*��ȡ�ն���ز���ʱ����*/
    	return 0;
    }
    bzero(&new_termi,sizeof(new_termi));    				/*���ṹ������*/
    new_termi.c_cflag|= (CLOCAL|CREAD); 					/*���Ե��ƽ����״̬�У�����ʹ��*/
    new_termi.c_lflag&=~(ICANON|ECHO|ECHOE);				/*ѡ��Ϊԭʼ����ģʽ*/
    new_termi.c_oflag&=~OPOST; 								/*ѡ��Ϊԭʼ���ģʽ*/
    new_termi.c_cc[VTIME] = 1; 								/*���ó�ʱʱ��Ϊ0.1 s*/
    new_termi.c_cc[VMIN] = 0;								/*���ٷ��ص��ֽ����� 7*/
    new_termi.c_cflag &= ~CSIZE;
    //new_termi.c_iflag &= ~INPCK;     /* Enable parity checking */
    new_termi.c_iflag &=~ ISTRIP;
    switch(baud)
    {
    	case 1200:
    		baud_lnx = B1200;
    		break;
    	case 2400:
    		baud_lnx = B2400;
    		break;
    	case 4800:
    		baud_lnx = B4800;
    		break;
    	case 9600:
    		baud_lnx = B9600;
    		break;
    	case 19200:
    		baud_lnx = B19200;
    		break;
    	case 38400:
    		baud_lnx = B38400;
    		break;
    	case 115200:
    		baud_lnx = B115200;
    		break;
    	default:
    		baud_lnx = B9600;
    		printf("\nSerial COM%d do not setup baud, default baud is 9600!!!", port);
    		break;
    }

    switch( bits )
	{
		case 5:
			new_termi.c_cflag |= CS5;
			break;
		case 6:
			new_termi.c_cflag |= CS6;
			break;
		case 7:
			new_termi.c_cflag |= CS7;
			break;
		case 8:
			new_termi.c_cflag |= CS8;
			break;
		default:
			new_termi.c_cflag |= CS8;
			break;
	}

    if(strncmp((char *)par,"even",4)==0)//������żУ��ΪżУ��
    {
		//new_termi.c_iflag |= (INPCK | ISTRIP);
    	new_termi.c_cflag |= PARENB;
    	new_termi.c_cflag &= ~PARODD;

    }
    else if(strncmp((char *)par,"odd",3)==0)  //������żУ��Ϊ��У��
	{
		new_termi.c_cflag |= PARENB;
		new_termi.c_cflag |= PARODD;
		//new_termi.c_iflag |= (INPCK | ISTRIP);
	}else
	{
    	new_termi.c_cflag &= ~PARENB; 	//������żУ��Ϊ��У��
    	//new_termi.c_iflag &=~ ISTRIP;
    }


	if(stopb==1)//ֹͣλ
	{
		new_termi.c_cflag&= ~CSTOPB; //����ֹͣλΪ:һλֹͣλ
	}
	else if(stopb==2)
	{
		new_termi.c_cflag |= CSTOPB; //����ֹͣλΪ:��λֹͣλ
	}
	else
	{
		new_termi.c_cflag&= ~CSTOPB; //����ֹͣλΪ:һλֹͣλ
	}

	cfsetispeed(&new_termi, baud_lnx); 							/* �������벦���� */
    cfsetospeed(&new_termi, baud_lnx); 							/* ������������� */

    tcflush(ComPort, TCIOFLUSH); 								/* ˢ����������� */
    if(tcsetattr(ComPort,TCSANOW,&new_termi)!= 0)				/* ��������� */
    {
    	printf("Set serial port parameter error!\n");
    	return 0;
    }
    return ComPort;
}

//**************************************************
//�������ܣ��رմ���
//**************************************************
void CloseCom()
{
	ComParaIfr.State=0;
	if(ComPort>0)
		close(ComPort);
}

//**************************************************
//�������ܣ�ȥ�������ļ���ע�Ͳ���
//**************************************************
char* skip_unwanted(char *ptr)
{
	int i = 0;
	static char buf[256];
	while (*ptr != '\0') {
//		if (*ptr == ' ' || *ptr == '\t' || *ptr == '\n') {
		if (*ptr == '\t' || *ptr == '\n') {
			ptr++;
			continue;
		}
		if (*ptr == '#')
			break;
		buf[i++] = *ptr;
		ptr++;
	}
	buf[i] = 0;
	return (buf);
}

//**************************************************
//�������ܣ����������ļ��ľ������
//**************************************************
int parse_options(char *buf)
{
	char 	*str,*str1;
	static char buf1[256];
	INT8U	i,j;

	str = strstr(buf, "end");
	if (str != NULL) {
		return 100;
	}
	str = strstr(buf,"Ifr");
	if(str!=NULL) {
		str = index(buf, '=');
		if (str != NULL) {
			str1 = str;
			str++;
			if (*str != '\0') {
				for(j=0;j<4;j++) {
					str1++;
					i=0;
					while ((*str1 != ' ') && (*str1 != '\0')) {
						buf1[i++] = *str1;
						str1++;
					}
					buf1[i] = 0;
					switch(j) {
						case 0:	ComParaIfr.Baud = strtol(buf1, NULL, 10);  break;
						case 1:	strncpy((char *)ComParaIfr.Parity,buf1,12);	break;
						case 2:	ComParaIfr.Bits = strtol(buf1, NULL, 10);  break;
						case 3:	ComParaIfr.Stopb = strtol(buf1, NULL, 10);  break;
					}
				}
				return (0);
			}
		}
		return (0);
	}
	return (0);
}

//**************************************************
//�������ܣ������ڲ��������ļ�(/nor/config/ttyS.cfg)
//**************************************************
int parse_ttyS_file()
{
	FILE *fp;
	char line[256];
	char TempBuf[64];
	int  end;
	char *ptr;

	sprintf((char *) TempBuf, "%s/ttyS.cfg", _CFGDIR_);
	fp = fopen(TempBuf, "r");
	if (fp == NULL) {			//�������ļ�,��ʼ������Ĭ��ֵ
		ComParaIfr.Baud=2400;
		strncpy((char *)ComParaIfr.Parity,"even",sizeof(ComParaIfr.Parity));
		ComParaIfr.Bits=8;
		ComParaIfr.Stopb=1;
//		fprintf(stderr,"(Ifr initpara)ttyS%d:%d_%s_%d_%d\n",ComParaIfr.ComPortNo,ComParaIfr.Baud,ComParaIfr.Parity,ComParaIfr.Stopb,ComParaIfr.Bits);

	}else {
		while (fgets(line, 256, fp) != NULL) {
			ptr = skip_unwanted(line);
//			fprintf(stderr,"ptr:%s\n",ptr);
			end = parse_options(ptr);
			if (end == 100) {
//				fprintf(stderr,"(Ifr readfile)ttyS%d:%d_%s_%d_%d\n",ComParaIfr.ComPortNo,ComParaIfr.Baud,ComParaIfr.Parity,ComParaIfr.Stopb,ComParaIfr.Bits);
			}
    	}
	 	fclose(fp);
	 	return (0);
	}
	return (0);
}

//**************************************************
//�������ܣ����մ�������
//**************************************************
void* ReceProc()
{
	INT8U 	TmpBuf[256];
	INT8U	len,i;

	memset(TmpBuf,0,256);
	while(1) {
		len = read(ComPort,TmpBuf,255);
		if(len>0) {
			SdPrint("\nIfr:R(%d)=",len);
			for(i=0;i<len;i++) {
				ReceBuf[RHead]=TmpBuf[i];
				SdPrint("%02x ",TmpBuf[i]);
				RHead = (RHead+1) % BUFLEN;
			}
		}
		delay(300);
		ClearWaitTimes(ProjectNo,JProgramInfo);
	}
	return (0);
}


//**************************************************
//�������ܣ���ʼ���������в���
//**************************************************
void initProcPara()
{
	markver();
	parse_ttyS_file();
	RHead = 0;
	RTail = 0;
	SHead = 0;
	STail = 0;
}

//name_attach_t  *attach;
//����ע��,��ȡ����źͳ�������
INT8U GetProjects(INT32S argc, char * argv[]) {
	char proc_name[32] = "";

	if (argc < 2)
		return (FALSE);
	ProjectNo = atoi(argv[1]);
#ifdef __linux__
	sprintf(proc_name, "%s", argv[0]);
#else
	sprintf(proc_name, "%s %d", argv[0], ProjectNo);
	if((attach=name_attach(NULL, proc_name,0))  == NULL)
	{
	   printf( "ERR:'%s' runed,cann't regist\n\r", proc_name);
	   return (FALSE);
	}
#endif

	return (TRUE);
}

//�˳�����
void QuitProcess(int signo)
{
	delay(100);
	CloseCom();
	SdPrint("\n\r jIfrcom quit \n\r");
	JProgramInfo->Projects[ProjectNo].ProjectID=0;
//	name_detach(attach, 0);
    if (jIfrPrint==2)
    {
       //SdPrint("\n\r prtfp close");
 	   fclose(prtfp);
 	   prtfp=NULL;
    }
	exit(0);
}

void  net_send(INT8U * buffer,INT16U len)
{
	int i;
	SdPrint("Ifr Send(%d):",len);
	for(i=0;i<len;i++){
		SdPrint("%02x ",buffer[i]);
//		if(i!=0 && i%16==0) SdPrint("\n ");
	}
	write(ComPort,buffer,len);
	return;
}

//������
int main(int argc, char *argv[])
{
	struct sigaction sa1;//�ź�
//	int		i;

	if (getenv("jIfrcom")==NULL)
	{
		jIfrPrint = 0;
		if (getenv("jAllProgPrt")!=NULL)
		jIfrPrint = atoi(getenv("jAllProgPrt"));
	}
	else jIfrPrint = atoi(getenv("jIfrcom"));

	if (jIfrPrint==2)
	{
		INT8U TempBuf[60];
		memset(TempBuf, 0, 60);
		sprintf((char *) TempBuf, "%s/jIfr_log.txt", _USERDIR_);
		prtfp=fopen((char *) TempBuf,"a+");
	}

	JParamInfo3761 = Open1ShMem("ParamInfo3761",sizeof(ParamInfo3761),NULL);
	JDataFileInfo = Open1ShMem("DataFileInfo",sizeof(DataFileInfo),NULL);
	JConfigInfo = Open1ShMem("ConfigInfo",sizeof(ConfigInfo),NULL);
	JProgramInfo = Open1ShMem("ProgramInfo",sizeof(ProgramInfo),NULL);

	if(JProgramInfo->mainData.MemoryLength!=sizeof(ProgramInfo))
	{
		fprintf( stderr, "jIfrcom base mem uncompared prog will exit %d :\n",sizeof(ProgramInfo));
		return EXIT_FAILURE;
	}

	if(!GetProjects(argc, argv))
	{
		fprintf(stderr,"\njIfrcom Bad command format. Type 'use exe_name' for help!\n\r");
		return (EXIT_FAILURE);
	}
	JProgramInfo->Projects[ProjectNo].ProjectID=getpid();//����������Ϣ
	if (ProjectNo < TCP_IP_Start) {
		ComParaIfr.ComPortNo = TCP_IP_Start - ProjectNo + SER_Start;
	}else {
		fprintf(stderr,"ProjectNo=%d error! return;\n",ProjectNo);
		return (EXIT_FAILURE);
	}
	initProcPara();
	ComPort = Init_port_parm(ComParaIfr.ComPortNo,ComParaIfr.Baud,(char *)ComParaIfr.Parity,ComParaIfr.Stopb,ComParaIfr.Bits);
	if(ComPort==0)  {
		fprintf(stderr,"IfrCom init error\n");
		return (0);
	}
	fprintf(stderr,"Starting jIfrcom %d........open ttyS%d:%d_%s_%d_%d\n\r",ProjectNo,ComParaIfr.ComPortNo,ComParaIfr.Baud,ComParaIfr.Parity,ComParaIfr.Stopb,ComParaIfr.Bits);
	fprintf(stderr,"Starting jIfrcom ..........%d",ProjectNo);
	delay(1000);
	pthread_create(&pthread, NULL, &ReceProc, NULL);

	ClearWaitTimes(ProjectNo,JProgramInfo);
	//��ʼ������
	sa1.sa_handler = QuitProcess;
	sigemptyset(&sa1.sa_mask);
	sa1.sa_flags = 0;
	sigaction(SIGTERM, &sa1,NULL);
	sigaction(SIGSYS, &sa1,NULL);
	sigaction(SIGPWR, &sa1,NULL);
	sigaction(SIGKILL, &sa1,NULL);
	sigaction(SIGQUIT, &sa1,NULL);
	sigaction(SIGILL, &sa1,NULL);
	sigaction(SIGINT, &sa1,NULL);
	sigaction(SIGHUP, &sa1,NULL);
	sigaction(SIGABRT, &sa1,NULL);
	sigaction(SIGBUS, &sa1,NULL);
	sendfunp = net_send;
	while(1) {
		if (jIfrPrint == 0) {
		   if ((JProgramInfo->mainData.Prt_Flag==5) || (JProgramInfo->mainData.Prt_Flag==50))
			   jIfrPrint = 3;
		}
		else {
		   if ((JProgramInfo->mainData.Prt_Flag==105) || (JProgramInfo->mainData.Prt_Flag==150))
			   jIfrPrint = 0;
		}

		//״̬��
		deallen = StateProcess(&step,&rev_delay,10,&RTail,&RHead,ReceBuf,dealbuf);
		SdPrint("\n***************jIfrRHead=%d,RTail=%d\n",RHead,RTail);
		if(deallen>0){	//��Լ���أ���Ҫ����
			SdPrint("\nIfr DealBuf(%d):",deallen);
//			SdPrint("\nIfr DealBuf(%d):",deallen);
//			for(i=0;i<deallen;i++){
//				SdPrint("%02x ",dealbuf[i]);
//				if(i!=0 && i%16==0) fprintf(stderr,"\n");
//			}
			ret_AFN_FN = processData(JProgramInfo->zone,						/*����*/
						(ParamInfo3761*)JParamInfo3761,   /*������ָ��*/
						(ProgramInfo*)JProgramInfo,
						(ConfigInfo*)JConfigInfo,
						(DataFileInfo*)JDataFileInfo,
						dealbuf,						/*��Ҫ�����ı���*/
						deallen,							/*���ĳ���*/
						SendBuf,							/*��Լ�ⷵ����Ҫ���ͱ��Ļ�����*/
						&SendLen,							/*���͵ĳ���*/
														   /*���������漰��������*/
						sendfunp);								/*�ص�����*/
					/*�ص�����*/
			if(ret_AFN_FN<0){
				switch(ret_AFN_FN){
					case ERR_RCVD_TOOLONG:			fprintf(stderr,"���ձ��Ĺ���\n");	break;
					case ERR_CRC_ERROR:				fprintf(stderr,"����У�����\n");	break;
					case ERR_RCVD_LOST:				fprintf(stderr,"���ձ��Ĳ�����\n");	break;
					case ERR_HEART_BEAT:			fprintf(stderr,"����δ��Ӧ������������\n");	break;
					case ERR_DIFF_ADDR:				fprintf(stderr,"�����ն˵�ַ���ն˲�һ��\n");	break;
					case ERR_AUTO_INTERVAL_ZERO:	fprintf(stderr,"��ʱ�ϱ�����Ϊ0\n");	break;
					case ERR_AUTO_WRONG_AFN:		fprintf(stderr,"�����˴����AFN\n");	break;
					case ERR_AUTO_WRONG_FN:			fprintf(stderr,"�����˴����Fn\n");	break;
				}
			}
		}//end ״̬�������ɹ�

		ClearWaitTimes(ProjectNo,JProgramInfo);
		delay(1000);
	}
	QuitProcess(0);
 	return EXIT_SUCCESS;
}



