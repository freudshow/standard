/*
 * ���ݴ洢���������
 * */
#include "jSaveTask.h"

//name_attach_t  *attach;
FILE *fp;
int 		jDataSavePrint;		 //��ӡ���
INT8U		CheckFreshFlag;		 //���curr����ˢ�±��
unsigned char ProjectNo; //�ӳ�������е�����빲���ڴ��е�ProjectID��ͬ ProjectID��ϵͳ������߼����̺�
INT8U Day[PointMax],Month[PointMax];		//��¼�����������ն��ᣬ�¶�����
SMFiles 	smfile_tmp;						//���ڶ�ȡ��ʱ��������Ϊ�գ��¶�������
INT8U		BatOffTime;						//������ع���ʱ��
INT8U		PowerSta,poweroff_min=0;		//��ع���״̬�жϼ���ص���ʱ�����
//����ע��,��ȡ����źͳ�������
INT8U GetProjects(INT32S argc, char * argv[]) {
	char proc_name[32] = "";

	if (argc < 2)
		return (FALSE);
	ProjectNo = atoi(argv[1]);
#ifdef __linux__
	sprintf(proc_name, "%s", argv[0]);
#else
	sprintf(proc_name, "%s %d", argv[0], ProjectNo);
#endif
//   if((attach=name_attach(NULL, proc_name,0))  == NULL)
//   {
//	   printf( "ERR:'%s' runed,cann't regist\n\r", proc_name);
//	   return (FALSE);
//   }
	return (TRUE);
}

///////////////////////////////////////////
//�������ܣ������˳�ǰ����
//���ã�ϵͳ����
//������sa����
//�˳���
///////////////////////////////////////////
void QuitProcess(int signo)
{
	delay(100);
	JProgramInfo->Projects[ProjectNo].ProjectID=0;
   	fprintf(stderr,"jSaveTask quit\n\r");
   	if (jDataSavePrint==2)
	{
	   fclose(fp);
	   fp=NULL;
	}
//   	name_detach(attach, 0);
	exit(0);
}


/**************************************/
//�������ܣ������洢Ŀ¼
// /nand/DataCurr:ʵʱ����Ŀ¼
// /nand/DataHour
/**************************************/
void MakeFolden()
{
	INT8U TempBuf[128];
	DIR *dir=NULL;
    struct timespec tsspec;
    if (clock_gettime(CLOCK_REALTIME, &tsspec)==-1)
    	printf("clock_gettime error\n\r");
    tsspec.tv_sec += 3;
	sem_timedwait(&JProgramInfo->mainData.UseFileFlg,&tsspec);
	dir = opendir(_CURRDIR_);
	if(dir==NULL) {
	    sem_post(&JProgramInfo->mainData.UseFileFlg);
		mkdir(_CURRDIR_,0666);
	 }
	else
	{
	    sem_post(&JProgramInfo->mainData.UseFileFlg);
		closedir(dir);
	}
	sem_timedwait(&JProgramInfo->mainData.UseFileFlg,&tsspec);
	dir = opendir(_HOURDIR_);
	if(dir==NULL) {
	    sem_post(&JProgramInfo->mainData.UseFileFlg);
		mkdir(_HOURDIR_,0666);
	}
	else
	{
	    sem_post(&JProgramInfo->mainData.UseFileFlg);
		closedir(dir);
	}
	sem_timedwait(&JProgramInfo->mainData.UseFileFlg,&tsspec);
	dir = opendir(_DAYDIR_);
	if(dir==NULL) {
	    sem_post(&JProgramInfo->mainData.UseFileFlg);
		mkdir(_DAYDIR_,0666);
	 }
	else
	{
	    sem_post(&JProgramInfo->mainData.UseFileFlg);
		closedir(dir);
	}
	sem_timedwait(&JProgramInfo->mainData.UseFileFlg,&tsspec);
	dir = opendir(_MONTHDIR_);
	if(dir==NULL) {
	    sem_post(&JProgramInfo->mainData.UseFileFlg);
		mkdir(_MONTHDIR_,0666);
	 }
	else
	{
	    sem_post(&JProgramInfo->mainData.UseFileFlg);
		closedir(dir);
	}

	sem_timedwait(&JProgramInfo->mainData.UseFileFlg,&tsspec);
	dir = opendir(_ALARMDIR_);
	if(dir==NULL) {
	    sem_post(&JProgramInfo->mainData.UseFileFlg);
		mkdir(_ALARMDIR_,0666);
	 }
	else
	{
	    sem_post(&JProgramInfo->mainData.UseFileFlg);
		closedir(dir);
	}

	sem_timedwait(&JProgramInfo->mainData.UseFileFlg,&tsspec);
	dir = opendir(_DAYTJDIR_);
	if(dir==NULL) {
	    sem_post(&JProgramInfo->mainData.UseFileFlg);
		mkdir(_DAYTJDIR_,0666);
	 }
	else
	{
	    sem_post(&JProgramInfo->mainData.UseFileFlg);
		closedir(dir);
	}

	sem_timedwait(&JProgramInfo->mainData.UseFileFlg,&tsspec);
	dir = opendir(_MONTJDIR_);
	if(dir==NULL) {
	    sem_post(&JProgramInfo->mainData.UseFileFlg);
		mkdir(_MONTJDIR_,0666);
	}
	else
	{
	    sem_post(&JProgramInfo->mainData.UseFileFlg);
		closedir(dir);
	}

	sem_timedwait(&JProgramInfo->mainData.UseFileFlg,&tsspec);
	dir = opendir( (char*)TempBuf );
	if(dir==NULL) {
	    sem_post(&JProgramInfo->mainData.UseFileFlg);
		mkdir(_PARADIR_,0666);
	 }
	else
	{
	    sem_post(&JProgramInfo->mainData.UseFileFlg);
		closedir(dir);
	}
}

/*************************************************************************/
//�������ܣ�
//	1. ÿ�� 0:40 ɾ���ĳ���31�����������,�Ϻ�Ҫ�󱣴�31����������
//	2. ÿ��6:03 �ж����в�����curr.dat�洢ʱ��2���޸��£�ɾ��curr�ļ�,
//									��ֹ��ʱ�䳭�����ɹ��������Բ���
//	3. ÿ��6:03 �ж��Ƿ�����һ�յ��ն������ݣ���ֻ�������һ���µ��ն�������
//  4. ÿ��6:03ɾ��һ��/nand/dbglog.log�ļ�
/***********************************************************************/
void delAllCurrHourdat(TS ts,ProgramInfo *proginfo,ParamInfo3761 *paraminfo)
{
	static INT8U	firstflag=1;
	static TS		lastts;
	TS				newts;
	int i;
	char 	cmdstr[100],filename[100];
	SMFiles tempdata;
	struct 	tm file_tm;
	struct 	tm filetm,pnowtm;
    struct 	dirent *next;
	time_t 	file_time, curr_time,nowtimes;
    DIR 	*dir;
    INT32U 	filetm_value=0;

    if(firstflag==1) {
    	lastts.Hour = ts.Hour;
    	lastts.Minute = ts.Minute;
    	firstflag=0;
    }
	if(lastts.Hour != ts.Hour && ts.Hour==0 && ts.Minute ==40) {			//ÿ��0��40��ɾ������31���Сʱ����
		lastts.Hour = ts.Hour;
		dir = opendir(_HOURDIR_);
	    if (!dir)
	        printf("\nCannot open /nand/DataHour! error!  error! error! \n");

	    while ((next = readdir(dir)) != NULL)
	    {
	        if (strcmp(next->d_name, "..") == 0)
	            continue;
	        if (!isdigit(*next->d_name))
	            continue;
	        filetm_value = atoi(next->d_name);
	        memset(&filetm, 0, sizeof(struct tm));
	        filetm.tm_year = filetm_value/10000-1900;
	        filetm.tm_mon = (filetm_value%10000)/100-1;
	        filetm.tm_mday = filetm_value%100;
	        //printf("\n  filename: %s == %d %d %d  ",next->d_name,filetm.tm_year,filetm.tm_mon,filetm.tm_mday);
	        file_time = mktime(&filetm);
	        nowtimes = time(NULL);
	        //printf("\n nowtimes %d  file_times %d    now-file = %d \n",(int)nowtimes, (int)file_times, (int)(nowtimes-file_times));
	        if((nowtimes-file_time > 86400*31) || (nowtimes-file_time <0)) //����31����ɾ�������Сʱ�����ļ�
	        {
	        	memset(filename,0,100);
	        	sprintf((char*)filename,"%s/%s",_HOURDIR_,next->d_name);
	        	localtime_r(&nowtimes,&pnowtm);
				fprintf(stderr,"\n %04d-%02d-%02d %02d:%02d:%02d delhourdata %s\n",pnowtm.tm_year+1900,pnowtm.tm_mon+1,
						pnowtm.tm_mday,pnowtm.tm_hour,pnowtm.tm_min,pnowtm.tm_sec,filename);
	 			syslog(LOG_NOTICE,"\n<jSaveMain 00:40 ɾ��  %s Сʱ��������>\n",filename);
	 			memset(cmdstr,0,100);
				sprintf((char*)cmdstr,"%s %s", _CMDRMDIR_, filename);
				syscmd((char*)cmdstr,proginfo);
	        }
	    }
	    closedir(dir);
	}
	///////////ɾ��curr.dat
	if ((ts.Hour == 6) && (ts.Minute==3) && (lastts.Minute!= ts.Minute)) {// ÿ��6:03��������Ƿ�ˢ��
		lastts.Minute = ts.Minute;
		for(i=0;i<PointMax;i++)
		{
			ClearWaitTimes(ProjectNo,JProgramInfo);
			if(paraminfo->group2.f10[i].Status == 1)
			{
				memset(filename,0,100);
				memset(cmdstr,0,100);
				sprintf(filename,"/nand/DataCurr/%04d/curr.dat",i+1);
				if(access((char*)filename,0)==0)
				{
					ReadFile(filename,&tempdata,sizeof(SMFiles),proginfo);
					file_tm.tm_year = tempdata.ts.Year - 1900;
					file_tm.tm_mon  = tempdata.ts.Month - 1;
					file_tm.tm_mday = tempdata.ts.Day;
					file_tm.tm_hour = tempdata.ts.Hour;
					file_tm.tm_min  = tempdata.ts.Minute;
					file_tm.tm_sec  = 0;
					file_tm.tm_isdst = 0;
					file_time = mktime(&file_tm);
					curr_time = time(NULL);
					fprintf(stderr,"\n\rfilename : %s  file_time %d  curr_time %d",filename, (int)file_time,(int)curr_time);
					//Ĭ����2 ����ÿ��������һ�²������Ƿ���������
					if(curr_time-file_time > 2*24*3600)			//����2��curr�޸��£�ɾ��curr�ļ�
					{
						fprintf(stderr,"\nɾ���ļ�  %d\n",i+1);
						memset(cmdstr,0,100);
						sprintf(cmdstr,"/nand/DataCurr/%04d/curr.dat",i+1);
						syslog(LOG_NOTICE,"%04d-%02d-%02d %02d:%02d:%02d<jSaveTask:ɾ�������� %d curr.dat�����ļ�>\n ",ts.Year,ts.Month,ts.Day,ts.Hour,ts.Minute,ts.Sec,i+1);
						unlink(cmdstr);
					}
				}
				//ɾ����һ��������
				memset(filename,0,100);
				memset(cmdstr,0,100);
				TSGet(&newts);
				TimeAdd(&newts, 4, 1);
				sprintf(filename,"/nand/DataDay/%04d/%02d.dat",i+1, newts.Day);
				if(access((char*)filename,0)==0)
				{
					memset(cmdstr,0,100);
					sprintf(cmdstr, "rm -f %s", filename);
					syslog(LOG_NOTICE,"%04d-%02d-%02d %02d:%02d:%02d<jSaveTask:ɾ�������� %d �ն����ļ� %s>\n ",ts.Year,ts.Month,ts.Day,ts.Hour,ts.Minute,ts.Sec,i+1,filename);
					system(cmdstr);
				}
			}
		}
		fprintf(stderr,"\n\n***********ɾ��/nand/dbglog.log*****************\n\n");
		//system("rm -r /nand/dbglog.log");
		unlink("/nand/dbglog.log");
		syslog(LOG_NOTICE,"***********6:03ɾ��/nand/dbglog.log*****************");
	}

}

/**************************************/
//�������ܣ�����һ������
//			�����������·������־����Ҫ�������ļ�
// FileSaveFlag.*flag = 1: �����ļ�
// FileSaveFlag.*flag = 2: ɾ���ļ�
// FileSaveFlag.*flag = 3: �����ļ������������
// FileSaveFlag.*flag = 0: �ļ�����ɹ�
/**************************************/
void Class1DataProc(ProgramInfo *proginfo,ParamInfo3761 *paraminfo,DataFileInfo *datainfo,ConfigInfo *cfginfo)
{
	char  	TempBuf[128];
	int		savelen;
	TS	  	ts;

	memset(TempBuf,0,128);
	TSGet(&ts);
	switch(proginfo->FileSaveFlag.g1flag){
		case 1:
			sprintf((char*)TempBuf,"%s/group1.par",_PARADIR_);
			NormalSaveFile((char*)TempBuf,(INT8U *)&paraminfo->group1,sizeof(paraminfo->group1),proginfo);
			proginfo->FileSaveFlag.g1flag = 0;
			break;
		case 2:
			sprintf((char*)TempBuf,"%s/group1.par",_PARADIR_);
			unlink(TempBuf);
			proginfo->FileSaveFlag.g1flag = 0;
			break;
	}
	switch(proginfo->FileSaveFlag.g2flag){		//����group2�е�f9,f11,f12,f13,f14,f15,f16����������
		case 1:
			savelen = sizeof(paraminfo->group2.f9)+sizeof(paraminfo->group2.f11)+sizeof(paraminfo->group2.f12)
					+sizeof(paraminfo->group2.f13)+sizeof(paraminfo->group2.f14)+sizeof(paraminfo->group2.f15)
					+sizeof(paraminfo->group2.f16);
			sprintf((char*)TempBuf,"%s/group2.par",_PARADIR_);
			NormalSaveFile((char*)TempBuf,(INT8U *)&paraminfo->group2.f9,savelen,proginfo);
			proginfo->FileSaveFlag.g2flag = 0;
			break;
		case 2:
			sprintf((char*)TempBuf,"%s/group2.par",_PARADIR_);
			unlink(TempBuf);
			proginfo->FileSaveFlag.g2flag = 0;
			break;
	}
	switch(proginfo->FileSaveFlag.g3flag){
		case 1:
			sprintf((char*)TempBuf,"%s/group3.par",_PARADIR_);
			NormalSaveFile((char*)TempBuf,(INT8U *)&paraminfo->group3,sizeof(paraminfo->group3),proginfo);
			proginfo->FileSaveFlag.g3flag = 0;
			break;
		case 2:
			sprintf((char*)TempBuf,"%s/group3.par",_PARADIR_);
			unlink(TempBuf);
			proginfo->FileSaveFlag.g3flag = 0;
			break;
	}
	switch(proginfo->FileSaveFlag.g4flag){
		case 1:
			sprintf((char*)TempBuf,"%s/group4_point.par",_PARADIR_);
			NormalSaveFile((char*)TempBuf,(INT8U *)&paraminfo->Point,sizeof(paraminfo->Point),proginfo);
			proginfo->FileSaveFlag.g4flag = 0;
			break;
		case 2:
			sprintf((char*)TempBuf,"%s/group4_point.par",_PARADIR_);
			unlink(TempBuf);
			proginfo->FileSaveFlag.g4flag = 0;
			break;
	}
	switch(proginfo->FileSaveFlag.g5flag){
		case 1:
			sprintf((char*)TempBuf,"%s/group5.par",_PARADIR_);
			NormalSaveFile((char*)TempBuf,(INT8U *)&paraminfo->group5,sizeof(paraminfo->group5),proginfo);
			proginfo->FileSaveFlag.g5flag = 0;
			break;
		case 2:
			sprintf((char*)TempBuf,"%s/group5.par",_PARADIR_);
			unlink(TempBuf);
			proginfo->FileSaveFlag.g5flag = 0;
			break;
	}
	switch(proginfo->FileSaveFlag.g8flag){
		case 1:
			sprintf((char*)TempBuf,"%s/group8.par",_PARADIR_);
			NormalSaveFile((char*)TempBuf,(INT8U *)&paraminfo->group8,sizeof(paraminfo->group8),proginfo);
			proginfo->FileSaveFlag.g8flag = 0;
			break;
		case 2:
			sprintf((char*)TempBuf,"%s/group8.par",_PARADIR_);
			unlink(TempBuf);
			proginfo->FileSaveFlag.g8flag = 0;
			break;
	}
	switch(proginfo->FileSaveFlag.g9flag){
		case 1:
//			SdPrint("proginfo->FileSaveFlag.g9flag=%d\n",proginfo->FileSaveFlag.g9flag);
			sprintf((char*)TempBuf,"%s/group9_task.par",_PARADIR_);
			NormalSaveFile((char*)TempBuf,(INT8U *)&paraminfo->group9,sizeof(paraminfo->group9),proginfo);
			proginfo->FileSaveFlag.g9flag = 0;
			break;
		case 2:
			sprintf((char*)TempBuf,"%s/group9_task.par",_PARADIR_);
			unlink(TempBuf);
			proginfo->FileSaveFlag.g9flag = 0;
			break;
	}
	switch(proginfo->FileSaveFlag.g11flag){
		case 1:
			sprintf((char*)TempBuf,"%s/group11.par",_PARADIR_);
			NormalSaveFile((char*)TempBuf,(INT8U *)&paraminfo->group11,sizeof(paraminfo->group11),proginfo);
			proginfo->FileSaveFlag.g11flag = 0;
			break;
		case 2:
			sprintf((char*)TempBuf,"%s/group11.par",_PARADIR_);
			unlink(TempBuf);
			proginfo->FileSaveFlag.g11flag = 0;
			break;
	}
	switch(proginfo->FileSaveFlag.g31flag){
		case 1:
			sprintf((char*)TempBuf,"%s/group31.par",_PARADIR_);
			NormalSaveFile((char*)TempBuf,(INT8U *)&paraminfo->group31,sizeof(paraminfo->group31),proginfo);
			proginfo->FileSaveFlag.g31flag = 0;
			break;
		case 2:
			sprintf((char*)TempBuf,"%s/group31.par",_PARADIR_);
			unlink(TempBuf);
			proginfo->FileSaveFlag.g31flag = 0;
			break;
	}
	switch(proginfo->FileSaveFlag.level1flag){
		case 1:
			sprintf((char*)TempBuf,"%s/f165.par",_PARADIR_);
			NormalSaveFile((char*)TempBuf,(INT8U *)&paraminfo->level1.f165,sizeof(paraminfo->level1.f165),proginfo);
			proginfo->FileSaveFlag.level1flag = 0;
			break;
		case 2:
			sprintf((char*)TempBuf,"%s/f165.par",_PARADIR_);
			unlink(TempBuf);
			proginfo->FileSaveFlag.level1flag = 0;
			break;
	}
	switch(proginfo->FileSaveFlag.ercflag){
		case 1:
//			fprintf(stderr,"###################SAVE ERC1=%d,ERC2=%d,ERC1Old=%d,ERC2Old=%d\n",datainfo->ErcEvt.EC1,datainfo->ErcEvt.EC2,datainfo->ErcEvt.EC1old,datainfo->ErcEvt.EC2old);
			sprintf((char*)TempBuf,"%s/ercevent.par",_PARADIR_);
			NormalSaveFile((char*)TempBuf,(INT8U *)&datainfo->ErcEvt,sizeof(datainfo->ErcEvt),proginfo);
			proginfo->FileSaveFlag.ercflag = 0;
			break;
		case 2:
			sprintf((char*)TempBuf,"%s/ercevent.par",_PARADIR_);
			unlink(TempBuf);
			proginfo->FileSaveFlag.ercflag = 0;
			break;
	}
	switch(proginfo->FileSaveFlag.jzqflag){
		case 1:
			sprintf((char*)TempBuf,"%s/jzqpara.par",_PARADIR_);
			NormalSaveFile((char*)TempBuf,(INT8U *)&cfginfo->jzqpara,sizeof(cfginfo->jzqpara),proginfo);
			proginfo->FileSaveFlag.jzqflag = 0;
			break;
		case 2:
			sprintf((char*)TempBuf,"%s/jzqpara.par",_PARADIR_);
			unlink(TempBuf);
			proginfo->FileSaveFlag.jzqflag = 0;
			break;
	}
	switch(proginfo->FileSaveFlag.jc645flag){
		case 1:
			sprintf((char*)TempBuf,"%s/jc645.par",_PARADIR_);
			NormalSaveFile((char*)TempBuf,(INT8U *)&datainfo->JcPara_645,sizeof(datainfo->JcPara_645),proginfo);
			proginfo->FileSaveFlag.jc645flag = 0;
			break;
		case 2:
			sprintf((char*)TempBuf,"%s/jc645.par",_PARADIR_);
			unlink(TempBuf);
			proginfo->FileSaveFlag.jc645flag = 0;
			break;
	}
	switch(proginfo->FileSaveFlag.jcxsflag){
		case 1:
			sprintf((char*)TempBuf,"%s/JcXiu.par",_PARADIR_);
			NormalSaveFile((char*)TempBuf,(INT8U *)&cfginfo->jcxs,sizeof(cfginfo->jcxs),proginfo);
			proginfo->FileSaveFlag.jcxsflag = 0;
			break;
//		case 2:
//			sprintf((char*)TempBuf,"%s/JcXiu.par",_PARADIR_);
//			unlink(TempBuf);
//			proginfo->FileSaveFlag.jcxsflag = 0;
//			break;
	}
	switch(proginfo->FileSaveFlag.loginflag){		//�����ն˵�¼ʱ��
		case 1:
			sprintf((char*)TempBuf,"%s/login.dat",_ALARMDIR_);
			fp = fopen(TempBuf, "a+");
			fprintf(fp,"%s\n",datainfo->logininfo.timestr);
			fflush(fp);
			fclose(fp);
			proginfo->FileSaveFlag.loginflag = 0;
			break;
	}
	switch(proginfo->FileSaveFlag.drunflag){
		case 1:
			sprintf((char*)TempBuf,"%s/d%02d.dat",_ALARMDIR_,ts.Day);
			SaveFile((char*)TempBuf,(INT8U *)&datainfo->DayRunTj,sizeof(datainfo->DayRunTj),proginfo);
			proginfo->FileSaveFlag.drunflag = 0;
			break;
		case 2:
			sprintf((char*)TempBuf,"%s/d%02d.dat",_ALARMDIR_,ts.Day);
			unlink(TempBuf);
			proginfo->FileSaveFlag.drunflag = 0;
			break;
		case 3:	//�����ļ��������ڴ�����ͳ��
			sprintf((char*)TempBuf,"%s/d%02d.dat",_ALARMDIR_,ts.Day);
			SaveFile((char*)TempBuf,(INT8U *)&datainfo->DayRunTj,sizeof(datainfo->DayRunTj),proginfo);
			datainfo->DayRunTj.ts = ts;
			datainfo->DayRunTj.LiuLiang = 0;
			datainfo->DayRunTj.ResetTime = 0;
			datainfo->DayRunTj.GdTime = 0;
			datainfo->DayRunTj.Ys1Time = 0;
			datainfo->DayRunTj.Ys2Time = 0;
			datainfo->DayRunTj.Ys3Time = 0;
			datainfo->DayRunTj.LoginNum = 0;
			proginfo->FileSaveFlag.drunflag = 0;
			break;
	}
	switch(proginfo->FileSaveFlag.mrunflag){
		case 1:
			sprintf((char*)TempBuf,"%s/m%02d.dat",_ALARMDIR_,ts.Month);
			SaveFile((char*)TempBuf,(INT8U *)&datainfo->YueRunTj,sizeof(datainfo->YueRunTj),proginfo);
			proginfo->FileSaveFlag.mrunflag = 0;
			break;
		case 2:
			sprintf((char*)TempBuf,"%s/m%02d.dat",_ALARMDIR_,ts.Month);
			unlink(TempBuf);
			proginfo->FileSaveFlag.mrunflag = 0;
			break;
		case 3:
			sprintf((char*)TempBuf,"%s/m%02d.dat",_ALARMDIR_,ts.Month);
			SaveFile((char*)TempBuf,(INT8U *)&datainfo->YueRunTj,sizeof(datainfo->YueRunTj),proginfo);
			datainfo->YueRunTj.ts=ts;
			datainfo->YueRunTj.LiuLiang=0;
			datainfo->YueRunTj.Ys1Time=0;
			datainfo->YueRunTj.Ys2Time=0;
			datainfo->YueRunTj.Ys3Time=0;
			datainfo->YueRunTj.GdTime=0;
			datainfo->YueRunTj.ResetTime=0;
			datainfo->YueRunTj.LoginNum=0;
			proginfo->FileSaveFlag.mrunflag = 0;
			break;
	}
	switch(proginfo->FileSaveFlag.ptinfoflag){
		case 1:
			sprintf((char*)TempBuf,"%s/ptinfo.dat",_ALARMDIR_);
			SaveFile((char*)TempBuf,(INT8U *)&datainfo->ptinfo,sizeof(datainfo->ptinfo),proginfo);
			proginfo->FileSaveFlag.ptinfoflag = 0;
			break;
		case 2:
			sprintf((char*)TempBuf,"%s/ptinfo.dat",_ALARMDIR_);
			unlink(TempBuf);
			proginfo->FileSaveFlag.ptinfoflag = 0;
			break;
	}
	switch(proginfo->FileSaveFlag.data485flag){
		case 1:
			sprintf((char*)TempBuf,"%s/data485.dat",_ALARMDIR_);
			SaveFile((char*)TempBuf,(INT8U *)&datainfo->data485,sizeof(datainfo->data485),proginfo);
			proginfo->FileSaveFlag.data485flag = 0;
			break;
		case 2:
			sprintf((char*)TempBuf,"%s/data485.dat",_ALARMDIR_);
			unlink(TempBuf);
			proginfo->FileSaveFlag.data485flag = 0;
			break;
	}
	switch(proginfo->FileSaveFlag.jcflag){
		case 1:
			sprintf((char*)TempBuf,"%s/JcData.dat",_CURRDIR_);
			NormalSaveFile((char*)TempBuf,(INT8U *)&datainfo->jc,sizeof(datainfo->jc),proginfo);
			proginfo->FileSaveFlag.jcflag = 0;
			break;
		case 2:
			sprintf((char*)TempBuf,"%s/JcData.dat",_CURRDIR_);
			unlink(TempBuf);
			proginfo->FileSaveFlag.jcflag = 0;
			break;
	}
}

/************************************************/
//�������ܣ�����������,����������Ϊ���£�������������
/************************************************/
void saveMonthData(INT8U *monflag,TS nowts,ParamInfo3761 *parainfo,ProgramInfo *proginfo)
{
	char SourceBuf[60];
	char DesBuf[60];
	char Command[120];
	int  i;
	TS	 lastts;

	lastts = nowts;
	TimeDecrease(&lastts,4,1);
	if (nowts.Day == 1) {
		for (i = 0; i < PointMax; i++)	{
			if (monflag[i]==nowts.Month)		continue;		//���»�û����������涳��
			if (parainfo->group2.f10[i].Status != 1)		//��������Ч������
				continue;
			if ((parainfo->group2.f10[i].ConnectType!=1)&&(parainfo->group2.f10[i].ConnectType!=30)&&(parainfo->group2.f10[i].ConnectType!=21))//��Լ���Ͳ���07��97,�Ϻ���������
				continue;
//			fprintf(stderr,"monflg[%d]=%d\n",i,monflag[i]);
			ClearWaitTimes(ProjectNo,proginfo);
			memset(DesBuf,0,60);
			sprintf((char*)DesBuf,"%s/%04d",_MONTHDIR_,i+1);
			if (access((char*)DesBuf,0)!=0) {		//  ����DataMonth�²�����Ŀ¼
				mkdir((char*)DesBuf,0666);
			}
			memset(SourceBuf,0,60);
			memset(DesBuf,0,60);
			sprintf((char*)SourceBuf,"%s/%04d/curr.dat",_CURRDIR_,i+1);
			sprintf((char*)DesBuf,"%s/%04d/%02d.dat",_MONTHDIR_,i+1,nowts.Month);
			if (access((char*)SourceBuf,0)==0)		//�е�ǰʵʱ����
			{
				if (ReadFile((char *)SourceBuf, &smfile_tmp,sizeof(SMFiles),proginfo)==0) {
					monflag[i] = nowts.Month;
//					fprintf(stderr,"get file\n");
					SaveFile((char*)DesBuf,&smfile_tmp,sizeof(SMFiles),proginfo);
				}
			}else  if(nowts.Minute>5){		//1�չ�5���Ӳ�������Ȼû�ж���������ʱ�����������ݴ�����
				//ɾ������������
				memset(SourceBuf,0,60);
				sprintf((char*)SourceBuf,"%s/%04d/%02d.dat",_MONTHDIR_,i+1,nowts.Month);
				if (access((char*)SourceBuf,0)==0)
				{
					memset(Command,0,120);
					sprintf((char*)Command,"%s/%04d/%02d.dat",_MONTHDIR_,i+1,nowts.Month);
					unlink((char*)Command);
				}
				//�ϴγ�������ʱ��Ϊ����ʱ�䣬��Ϊ���������ݴ洢
				memset(SourceBuf,0,60);
				sprintf((char*)SourceBuf,"%s/%04d/last.dat",_CURRDIR_,i+1);
				if (access((char*)SourceBuf,0)==0)
				{
					memset(&smfile_tmp,0,sizeof(SMFiles));
					ReadFile((char *) SourceBuf, &smfile_tmp,sizeof(SMFiles),proginfo);
					if ((smfile_tmp.ts.Year==lastts.Year)&&(smfile_tmp.ts.Month==lastts.Month)&&(smfile_tmp.ts.Day==lastts.Day))
					{
						SaveFile((char*)DesBuf,&smfile_tmp,sizeof(SMFiles),proginfo);
						monflag[i]=nowts.Month;
					}
				}
			}
		}
	}else {
		if ((nowts.Day == 2) && (nowts.Minute == 3))    {		//�¶������ɺ�����±��
			for (i = 0; i < PointMax; i++)	{
				monflag[i] = 0;
			}
		}
	}
}


/************************************************/
//�������ܣ�����������,����������Ϊ���գ�������������
/************************************************/
void saveDayData(INT8U *dayflag,TS nowts,ParamInfo3761 *parainfo,ProgramInfo *proginfo)
{
	char SourceBuf[60];
	char DesBuf[60];
	char Command[120];
	int  i;
	TS	 lastts;

	lastts = nowts;
	TimeDecrease(&lastts,4,1);
	if (nowts.Hour == 0) {
		for (i = 0; i < PointMax; i++)	{
			if (dayflag[i]==nowts.Day)  continue;				//���ջ�û����������洦��
			if (parainfo->group2.f10[i].Status != 1)			//��������Ч������
				continue;
//			if ((parainfo->group2.f10[i].ConnectType!=1)&&(parainfo->group2.f10[i].ConnectType!=30)&&(parainfo->group2.f10[i].ConnectType!=21))//��Լ���Ͳ���07��97������
//				continue;
			if ((parainfo->group2.f10[i].ConnectType==2)||(parainfo->group2.f10[i].ConnectType==1)||(parainfo->group2.f10[i].ConnectType==21)) {//��Լ���ͽ��ɣ�97���Ϻ���������
				SdPrint("jSaveTask:%04d-%02d-%02d %02d:%02d:%02d��������� %d �� %02d ��������\n",nowts.Year,nowts.Month,nowts.Day,nowts.Hour,nowts.Minute,nowts.Sec,i+1,nowts.Day);
				ClearWaitTimes(ProjectNo,proginfo);
				memset(DesBuf,0,60);
				sprintf((char*)DesBuf,"%s/%04d",_DAYDIR_,i+1);
				if (access((char*)DesBuf,0)!=0) {		//  ����DataDay�²�����Ŀ¼
					mkdir((char*)DesBuf,0666);
				}
				memset(SourceBuf,0,60);
				memset(DesBuf,0,60);
				sprintf((char*)SourceBuf,"%s/%04d/curr.dat",_CURRDIR_,i+1);
				sprintf((char*)DesBuf,"%s/%04d/%02d.dat",_DAYDIR_,i+1,nowts.Day);

				if (access((char*)SourceBuf,0)==0)		//�е�ǰʵʱ����
				{
					if (ReadFile((char *)SourceBuf, &smfile_tmp,sizeof(SMFiles),proginfo)==0) {
						dayflag[i] = nowts.Day;
						SaveFile((char*)DesBuf,&smfile_tmp,sizeof(SMFiles),proginfo);
					}
				}else  if(nowts.Minute>5){		//0���5���Ӳ�������Ȼû�ж���������ʱ�����������ݴ�����
					//ɾ����������,��ֹ�������ɹ����Ὣ���µ���������Ϊ����������
					memset(SourceBuf,0,60);
					sprintf((char*)SourceBuf,"%s/%04d/%02d.dat",_DAYDIR_,i+1,nowts.Day);
					if (access((char*)SourceBuf,0)==0)
					{
						memset(Command,0,120);
						sprintf((char*)Command,"%s/%04d/%02d.dat",_DAYDIR_,i+1,nowts.Day);
						unlink((char*)Command);
					}
					//�ϴγ�������ʱ��Ϊ����ʱ�䣬��Ϊ���������ݴ洢
					memset(SourceBuf,0,60);
					sprintf((char*)SourceBuf,"%s/%04d/last.dat",_CURRDIR_,i+1);
					if (access((char*)SourceBuf,0)==0)
					{
						memset(&smfile_tmp,0,sizeof(SMFiles));
						ReadFile((char *) SourceBuf, &smfile_tmp,sizeof(SMFiles),proginfo);
						if ((smfile_tmp.ts.Year==lastts.Year)&&(smfile_tmp.ts.Month==lastts.Month)&&(smfile_tmp.ts.Day==lastts.Day))
						{
							dayflag[i] = nowts.Day;
							SaveFile((char*)DesBuf,&smfile_tmp,sizeof(SMFiles),proginfo);
						}
					}
				}
			}
		}
	}else 	{
		if ((nowts.Hour == 1) && (nowts.Minute == 3))    {		//�ն������ɺ�����ձ��
			for (i = 0; i < PointMax; i++)	{
				dayflag[i] = 0;
			}
		}
	}
}

/**************************************/
//�������ܣ��ж��Ƿ����ص��û�, ����Ĭ�ϱ���Сʱ����
/**************************************/
int IsZhongDianUser(int cldno,ParamInfo3761 *parainfo)
{
	int k=0;
	INT8U zdflg=0;
	for(k=0;k<parainfo->group5.f35.Count;k++)
	{
		if (parainfo->group5.f35.Index[k]==(cldno+1))//�ص��û�
		{
			zdflg=1;
			SdPrint("�����ص��û���zdflag=%d,cldno=%d\n",zdflg,cldno);
			break;
		}
	}
	return zdflg;
}
/**************************************/
//�������ܣ������ص��û�Сʱ����
/**************************************/
void saveHourData(TS nowts,ParamInfo3761 *parainfo,ProgramInfo *proginfo)
{
	char 	SourceBuf[60];
	char 	DesBuf[60];
	int 	i=0;
	static TS	lastts;
	static INT8U	firstflag=1;

	if(firstflag) {
		lastts.Minute = nowts.Minute;
		firstflag = 0;
	}
	if(nowts.Minute != lastts.Minute) {					//ÿ�����ж�һ������
		lastts.Minute = nowts.Minute;
		if ((nowts.Minute==0) || (nowts.Minute==15) || (nowts.Minute==30) || (nowts.Minute==45)) {
//			fprintf(stderr,"\nlastmin=%d  nowmin=%d",lastts.Minute,nowts.Minute);
			for (i = 0; i < PointMax; i++) {
				if (parainfo->group2.f10[i].Status != 1)	continue;
				if ((IsZhongDianUser(i,parainfo)==1) ||  parainfo->group2.f10[i].ConnectType==2){	//���ɻ��ص��û�����Сʱ����
					memset(DesBuf,0,60);
					sprintf((char*)DesBuf,"%s/%04d/curr.dat",_CURRDIR_,i+1);
					if (access((char*)DesBuf,0)==0)
					{
						memset(DesBuf,0,60);
						sprintf((char*)DesBuf,"%s/%04d%02d%02d/",_HOURDIR_,nowts.Year,nowts.Month,nowts.Day);
						if (access((char*)DesBuf,0)!=0)	//��������Ŀ¼
						{
							mkdir((char*)DesBuf,0666);
						}
						memset(DesBuf,0,60);
						sprintf((char*)DesBuf,"%s/%04d%02d%02d/%04d/",_HOURDIR_,nowts.Year,nowts.Month,nowts.Day,i+1);
						if (access((char*)DesBuf,0)!=0)	//����������Ŀ¼
						{
							mkdir((char*)DesBuf,0666);
						}
						memset(DesBuf,0,60);
						sprintf((char*)DesBuf,"%s/%04d%02d%02d/%04d/%04d%02d%02d%02d%02d.dat",
								_HOURDIR_,nowts.Year,nowts.Month,nowts.Day,i+1,nowts.Year,nowts.Month,nowts.Day,nowts.Hour,nowts.Minute);
						if (access((char*)DesBuf,0)!=0)//�洢������
						{
							sprintf((char*)SourceBuf,"%s/%04d/curr.dat",_CURRDIR_,i+1);
							if (ReadFile((char *)SourceBuf, &smfile_tmp,sizeof(SMFiles),proginfo)==0) {
								SaveFile((char*)DesBuf,&smfile_tmp,sizeof(SMFiles),proginfo);
							}
						}
						ClearWaitTimes(ProjectNo,proginfo);
					}
				}
			}
		}
	}
}

/**************************************/
//�������ܣ�����ͳ������
/**************************************/
void saveTjData(TS nowts,DataFileInfo *datainfo,ParamInfo3761 *parainfo,ProgramInfo *proginfo)
{
	char   TempBuf[128];
	int		i;
	static TS	lastts;
	static INT8U	firstflag=1;

	if(firstflag) {
		lastts.Month = nowts.Month;
		lastts.Day = nowts.Day;
		lastts.Hour = nowts.Hour;
		lastts.Minute = nowts.Minute;
		firstflag = 0;
	}
	if((nowts.Minute % 5 == 0 && nowts.Minute!=lastts.Minute) || proginfo->PowerOFFMessage==1){	//5���� �� �жϵ��� ����ձ���һ����ͳ������
		lastts.Minute = nowts.Minute;
		for (i = 0; i < PointMax; i++) {
			if (parainfo->group2.f10[i].Status != 1)	continue;
			ClearWaitTimes(ProjectNo,JProgramInfo);
			//������ͳ������
			memset(TempBuf,0,128);
			sprintf((char*)TempBuf,"%s/%04d",_DAYTJDIR_,i+1);
			if (access((char*)TempBuf,0)!=0)	//����������Ŀ¼
			{
				mkdir((char*)TempBuf,0666);
			}
			sprintf((char*)TempBuf,"%s/%04d/d%02d.dat",_DAYTJDIR_,i+1,nowts.Day);
			SaveFile((char*)TempBuf,(INT8U *)&datainfo->DayTjValue[i],sizeof(ExdTongJi),proginfo);
			//������ͳ������
			memset(TempBuf,0,128);
			sprintf((char*)TempBuf,"%s/%04d",_MONTJDIR_,i+1);
			if (access((char*)TempBuf,0)!=0)	//����������Ŀ¼
			{
				mkdir((char*)TempBuf,0666);
			}
			sprintf((char*)TempBuf,"%s/%04d/m%02d.dat",_MONTJDIR_,i+1,nowts.Month);
			SaveFile((char*)TempBuf,(INT8U *)&datainfo->YueTjValue[i],sizeof(ExdTongJi),proginfo);
		}
	}
	if((nowts.Day !=lastts.Day )){	//���ձ�����ͳ������
		lastts.Day = nowts.Day;
		for (i = 0; i < PointMax; i++) {
			if (parainfo->group2.f10[i].Status != 1)	continue;
			ClearWaitTimes(ProjectNo,JProgramInfo);
			//������ͳ������
			memset(TempBuf,0,128);
			sprintf((char*)TempBuf,"%s/%04d",_DAYTJDIR_,i+1);
			if (access((char*)TempBuf,0)!=0)	//����������Ŀ¼
			{
				mkdir((char*)TempBuf,0666);
			}
			sprintf((char*)TempBuf,"%s/%04d/d%02d.dat",_DAYTJDIR_,i+1,nowts.Day);
			SaveFile((char*)TempBuf,(INT8U *)&datainfo->DayTjValue[i],sizeof(ExdTongJi),proginfo);
		}
	}
	if((nowts.Month !=lastts.Month )){	//���±���һ����ͳ������
		lastts.Month = nowts.Month;
		for (i = 0; i < PointMax; i++) {
			if (parainfo->group2.f10[i].Status != 1)	continue;
			ClearWaitTimes(ProjectNo,JProgramInfo);
			//������ͳ������
			memset(TempBuf,0,128);
			sprintf((char*)TempBuf,"%s/%04d",_MONTJDIR_,i+1);
			if (access((char*)TempBuf,0)!=0)	//����������Ŀ¼
			{
				mkdir((char*)TempBuf,0666);
			}
			sprintf((char*)TempBuf,"%s/%04d/m%02d.dat",_MONTJDIR_,i+1,nowts.Month);
			SaveFile((char*)TempBuf,(INT8U *)&datainfo->YueTjValue[i],sizeof(ExdTongJi),proginfo);
		}
	}
}

/**************************************/
//�������ܣ���ص������ݱ��洦��
/**************************************/
void powerOffDataSave(TS nowts,ProgramInfo *proginfo,ParamInfo3761 *paraminfo,DataFileInfo *datainfo)
{
	static INT8U powersta=0;
	static INT8U batoffime;

	if(proginfo->PowerOFFMessage!=powersta && proginfo->PowerOFFMessage==1) {	//�ն˵��磬���е���ǰ���ݴ洢
		poweroff_min = nowts.Minute;
		saveTjData(nowts,datainfo,paraminfo,proginfo);							//ͳ������
		powersta = 2;
		batoffime = 0;
	}else if(powersta==2) {
		batoffime+=((nowts.Minute+60-poweroff_min)%60);
		if (batoffime>=3)		 //3���Ӻ�رյ��
		{
			syslog(LOG_NOTICE,"�رյ��\n\r");
			batoffime=0;
			system("killall &");
			gpio_write("gpoBAT_SWITCH", 0);
			delay(10);
			system("gpo /dev/gpoBAT_SWITCH 0");
		}
		if(proginfo->PowerOnMessage == 1){		//�����ϵ�
			batoffime = 0;
			powersta = proginfo->PowerOFFMessage;
		}
	}
}

/*************************************************************/
//�������ܣ��ز�����������Ҫ�����µ������
//			����������ԭ�ļ����У�����������
//			����������ԭ�ļ���û�У���ѵ��ļ���󣬽��б���
/************************************************************/
void findSaveDataFlag(ProgramInfo *proginfo,ParamInfo3761 *paraminfo,DataFileInfo *datainfo)
{
	//--------------------------------------
	SMFiles		curFiles;
	char		filename[128];
	INT8U		Dataflag[2];
	int			filelen;
	INT8U 		findflag=0;
	int 		findi=0, i, flg_num=0;

	strcpy(filename,proginfo->sm[proginfo->sm_tail].filename);
	Dataflag[0] = proginfo->sm[proginfo->sm_tail].manyFiles.sm.datas[0].flg.Dataflag[0];
	Dataflag[1] = proginfo->sm[proginfo->sm_tail].manyFiles.sm.datas[0].flg.Dataflag[1];
	SdPrint("jSaveTask:��ȡ��filename=%s,[%02x%02x]\n",filename,Dataflag[1],Dataflag[0]);
	if(access((char*)filename,0)==0)		//�и��ļ�
	{
		memset(&curFiles, 0, sizeof(SMFiles));
		ReadFile((char*)filename, &curFiles, sizeof(SMFiles),proginfo);
		for (i=0;i<ManyFlagsCount;i++)
		{
			if (curFiles.sm.datas[i].flg.Dataflag[1]==0x00 && curFiles.sm.datas[i].flg.Dataflag[0]==0x00)
				continue;
			if (curFiles.sm.datas[i].flg.Dataflag[1]==0xff && curFiles.sm.datas[i].flg.Dataflag[0]==0xff)
				continue;
			if (curFiles.sm.datas[i].flg.Dataflag[1]==OxXX && curFiles.sm.datas[i].flg.Dataflag[0]==OxXX)
				continue;
			if(( Dataflag[0] == curFiles.sm.datas[i].flg.Dataflag[0])&&(Dataflag[1] == curFiles.sm.datas[i].flg.Dataflag[1]))
			{
				findi = i;					//Ҫ�洢��������λ��
				findflag = 1;				//�ļ����ҵ�������
			}
			flg_num++;						//��¼�ļ������������
		}
		SdPrint("jSaveTask:flg_num=%d\n",flg_num);
		if(findflag==1)
		{
			SdPrint("\n jSaveTask:�����ļ�%s,λ��:%d-------[%02x%02x]---------\n",filename,findi,Dataflag[1],Dataflag[0]);
			curFiles.sm.datas[findi].flg.Dataflag[0] = Dataflag[0];
			curFiles.sm.datas[findi].flg.Dataflag[1] = Dataflag[1];
			memcpy(&curFiles.sm.datas[findi].datas[0], &proginfo->sm[proginfo->sm_tail].manyFiles.sm.datas[0].datas[0],DataLenMax);
			SdPrint("jSaveTask����: sm.datas=");
			for(i=0;i<16;i++){
				SdPrint("%02x ",curFiles.sm.datas[findi].datas[i]);
			}
			filelen = FILEHEADSIZE+flg_num*sizeof(DataFlg);
			SaveFile((char*)filename, &curFiles,filelen,proginfo);
		}else
		{
			SdPrint("\n jSaveTask:׷���ļ�%s,λ��:%d-------[%02x%02x]---------\n",filename,flg_num,Dataflag[1],Dataflag[0]);
			curFiles.sm.datas[flg_num].flg.Dataflag[0] = Dataflag[0];
			curFiles.sm.datas[flg_num].flg.Dataflag[1] = Dataflag[1];
			memcpy(&curFiles.sm.datas[flg_num].datas[0], &proginfo->sm[proginfo->sm_tail].manyFiles.sm.datas[0].datas[0],DataLenMax);
			SdPrint("jSaveTask׷��: sm.datas=");
			for(i=0;i<16;i++){
				SdPrint("%02x ",curFiles.sm.datas[flg_num].datas[i]);
			}
			filelen = FILEHEADSIZE+ (flg_num+1)*sizeof(DataFlg);
			SaveFile((char*)filename, &curFiles,filelen,proginfo);
		}
	}else {		//�޸��ļ���ֱ�ӱ��洫���µ�����
		SdPrint("\n jSaveTask:�´����ļ�%s-------[%02x%02x]---------\n",filename,Dataflag[1],Dataflag[0]);
		SdPrint("jSaveTask�½�: sm.datas=");
		for(i=0;i<16;i++){
			SdPrint("%02x ",proginfo->sm[proginfo->sm_tail].manyFiles.sm.datas[0].datas[i]);
		}
		filelen = FILEHEADSIZE+ sizeof(DataFlg);
		SaveFile(filename,&proginfo->sm[proginfo->sm_tail].manyFiles,filelen,proginfo);
	}
	return;
}

/**************************************/
//�������ܣ����ݱ�־����������ʵʱ����
//			�ز�ͨѶ�ڣ�sm�ṹ��ÿ�θ���һ�����������ݣ���ԭ�ļ����Ҹ�������,���в�ͬ����
/**************************************/
void savePointCurrData(ProgramInfo *proginfo,ParamInfo3761 *paraminfo,DataFileInfo *datainfo)
{
	struct timespec 	tsspec;
	char 	SourceBuf[60];
	char 	DesBuf[60];

	if(proginfo->sm_head == proginfo->sm_tail)	return;
	SdPrint("***jSaveTask:sm_tail=%d,filetype=%d,filename=%s,filelen=%d,filets=%04d-%02d-%02d %02d:%02d:%02d\n",proginfo->sm_tail,
			proginfo->sm[proginfo->sm_tail].fileinfo.filetype,proginfo->sm[proginfo->sm_tail].filename,
			proginfo->sm[proginfo->sm_tail].filelen,proginfo->sm[proginfo->sm_tail].manyFiles.ts.Year,
			proginfo->sm[proginfo->sm_tail].manyFiles.ts.Month,proginfo->sm[proginfo->sm_tail].manyFiles.ts.Day,
			proginfo->sm[proginfo->sm_tail].manyFiles.ts.Hour,proginfo->sm[proginfo->sm_tail].manyFiles.ts.Minute,
			proginfo->sm[proginfo->sm_tail].manyFiles.ts.Sec);
	switch(proginfo->sm[proginfo->sm_tail].fileinfo.filetype) {
	case FILECURR:			//����curr.dat
		memset(SourceBuf,0,60);
		memset(DesBuf,0,60);
		sprintf((char*)SourceBuf,"%s/%04d",_CURRDIR_,proginfo->sm[proginfo->sm_tail].fileinfo.cldno);
		if (access((char*)SourceBuf,0)!=0)					//�ж�û�иò���������������Ŀ¼
		{
			mkdir((char*)SourceBuf,0666);
		}
		if(paraminfo->group2.f10[proginfo->sm[proginfo->sm_tail].fileinfo.cldno-1].port == 31) {		//�ز�ģ��
			findSaveDataFlag(proginfo,paraminfo,datainfo);
		}else {
			sprintf((char*)SourceBuf,"%s/%04d/curr.dat",_CURRDIR_,proginfo->sm[proginfo->sm_tail].fileinfo.cldno);
			sprintf((char*)DesBuf,"%s/%04d/last.dat",_CURRDIR_,proginfo->sm[proginfo->sm_tail].fileinfo.cldno);
			if (access((char*)SourceBuf,0)==0)					//�е�ǰʵʱ����,�Ƚ�curr.dat���ݱ��浽last.dat����������һ������
			{
				if (ReadFile((char *)SourceBuf, &smfile_tmp,sizeof(SMFiles),proginfo)==0) {
					SaveFile((char*)DesBuf,&smfile_tmp,sizeof(SMFiles),proginfo);
				}
			}
			SaveFile((char*)proginfo->sm[proginfo->sm_tail].filename,&proginfo->sm[proginfo->sm_tail].manyFiles,proginfo->sm[proginfo->sm_tail].filelen,proginfo);
		}
		if(paraminfo->group2.f10[proginfo->sm[proginfo->sm_tail].fileinfo.cldno-1].ConnectType==30){	//07������DataDay�ļ�
			SdPrint("jSaveTask:���������%02d, ʱ�� %02d �ն���",proginfo->sm[proginfo->sm_tail].fileinfo.cldno,proginfo->sm[proginfo->sm_tail].manyFiles.ts.Day);
			memset(DesBuf,0,60);
			sprintf((char*)DesBuf,"%s/%04d",_DAYDIR_,proginfo->sm[proginfo->sm_tail].fileinfo.cldno);
			if (access((char*)DesBuf,0)!=0)					//�ж�û�иò���������������Ŀ¼
			{
				mkdir((char*)DesBuf,0666);
			}
			memset(SourceBuf,0,60);
			memset(DesBuf,0,60);
			sprintf((char*)SourceBuf,"%s/%04d/curr.dat",_CURRDIR_,proginfo->sm[proginfo->sm_tail].fileinfo.cldno);
			sprintf((char*)DesBuf,"%s/%04d/%02d.dat",_DAYDIR_,proginfo->sm[proginfo->sm_tail].fileinfo.cldno,proginfo->sm[proginfo->sm_tail].manyFiles.ts.Day);
			if (ReadFile((char *)SourceBuf, &smfile_tmp,sizeof(SMFiles),proginfo)==0) {
				SaveFile((char*)DesBuf,&smfile_tmp,sizeof(SMFiles),proginfo);
			}
		}
		break;
	case FILEDAY:			//�����ն�������
		memset(SourceBuf,0,60);
		sprintf((char*)SourceBuf,"%s/%04d",_DAYDIR_,proginfo->sm[proginfo->sm_tail].fileinfo.cldno);
		if (access((char*)SourceBuf,0)!=0)					//�ж�û�иò���������������Ŀ¼
		{
			mkdir((char*)SourceBuf,0666);
		}
		if(paraminfo->group2.f10[proginfo->sm[proginfo->sm_tail].fileinfo.cldno-1].port == 31) {		//�ز�ģ��
			findSaveDataFlag(proginfo,paraminfo,datainfo);
		}else {
			SaveFile((char*)proginfo->sm[proginfo->sm_tail].filename,&proginfo->sm[proginfo->sm_tail].manyFiles,proginfo->sm[proginfo->sm_tail].filelen,proginfo);
		}break;
	case FILEMONTH:			//�����¶�������
		memset(SourceBuf,0,60);
		sprintf((char*)SourceBuf,"%s/%04d",_MONTHDIR_,proginfo->sm[proginfo->sm_tail].fileinfo.cldno);
		if (access((char*)SourceBuf,0)!=0)					//�ж�û�иò���������������Ŀ¼
		{
			mkdir((char*)SourceBuf,0666);
		}
		if(paraminfo->group2.f10[proginfo->sm[proginfo->sm_tail].fileinfo.cldno-1].port == 31) {		//�ز�ģ��
			findSaveDataFlag(proginfo,paraminfo,datainfo);
		}else {
			SaveFile((char*)proginfo->sm[proginfo->sm_tail].filename,&proginfo->sm[proginfo->sm_tail].manyFiles,proginfo->sm[proginfo->sm_tail].filelen,proginfo);
		}
		break;
	case FILEHOUR:			//����Сʱ��������
		memset(DesBuf,0,60);
		sprintf((char*)DesBuf,"%s/%04d%02d%02d/",_HOURDIR_,proginfo->sm[proginfo->sm_tail].fileinfo.ts.Year,proginfo->sm[proginfo->sm_tail].fileinfo.ts.Month,proginfo->sm[proginfo->sm_tail].fileinfo.ts.Day);
		if (access((char*)DesBuf,0)!=0)	//��������Ŀ¼
		{
			mkdir((char*)DesBuf,0666);
		}
		memset(DesBuf,0,60);
		sprintf((char*)DesBuf,"%s/%04d%02d%02d/%04d/",_HOURDIR_,proginfo->sm[proginfo->sm_tail].fileinfo.ts.Year,proginfo->sm[proginfo->sm_tail].fileinfo.ts.Month,proginfo->sm[proginfo->sm_tail].fileinfo.ts.Day,proginfo->sm[proginfo->sm_tail].fileinfo.cldno);
		if (access((char*)DesBuf,0)!=0)	//����������Ŀ¼
		{
			mkdir((char*)DesBuf,0666);
		}
		if(paraminfo->group2.f10[proginfo->sm[proginfo->sm_tail].fileinfo.cldno-1].port == 31) {		//�ز�ģ��
			findSaveDataFlag(proginfo,paraminfo,datainfo);
		}else {
			SaveFile((char*)proginfo->sm[proginfo->sm_tail].filename,&proginfo->sm[proginfo->sm_tail].manyFiles,proginfo->sm[proginfo->sm_tail].filelen,proginfo);
		}
		break;
	}
	tsspec.tv_sec=time(NULL)+3;
	sem_timedwait(&proginfo->mainData.UseCycleFlg,&tsspec);
	proginfo->sm[proginfo->sm_tail].dataChanged=0;
	proginfo->sm_tail = (proginfo->sm_tail+1)%SMBUFLEN;
	sem_post(&proginfo->mainData.UseCycleFlg);
}

/**************************************/
//�������ܣ����ݱ�־����������ʵʱ����
/**************************************/
#if 0
void savePointCurrData(ProgramInfo *proginfo,ParamInfo3761 *paraminfo,DataFileInfo *datainfo)
{
	struct timespec 	tsspec;
	char 	SourceBuf[60];
	char 	DesBuf[60];

	if(proginfo->sm_head == proginfo->sm_tail)	return;
//	tsspec.tv_sec=time(NULL)+3;
//	sem_timedwait(&proginfo->mainData.UseCycleFlg,&tsspec);
//	datachanged = proginfo->sm[proginfo->sm_tail].dataChanged;
//	sem_post(&proginfo->mainData.UseCycleFlg);
//	if(datachanged) {
		SdPrint("***jSaveTask:sm_tail=%d,filetype=%d,filename=%s,filelen=%d,filets=%04d-%02d-%02d %02d:%02d:%02d\n",proginfo->sm_tail,
				proginfo->sm[proginfo->sm_tail].fileinfo.filetype,proginfo->sm[proginfo->sm_tail].filename,
				proginfo->sm[proginfo->sm_tail].filelen,proginfo->sm[proginfo->sm_tail].manyFiles.ts.Year,
				proginfo->sm[proginfo->sm_tail].manyFiles.ts.Month,proginfo->sm[proginfo->sm_tail].manyFiles.ts.Day,
				proginfo->sm[proginfo->sm_tail].manyFiles.ts.Hour,proginfo->sm[proginfo->sm_tail].manyFiles.ts.Minute,
				proginfo->sm[proginfo->sm_tail].manyFiles.ts.Sec);
		switch(proginfo->sm[proginfo->sm_tail].fileinfo.filetype) {
		case FILECURR:			//����curr.dat
			memset(SourceBuf,0,60);
			memset(DesBuf,0,60);
			sprintf((char*)SourceBuf,"%s/%04d",_CURRDIR_,proginfo->sm[proginfo->sm_tail].fileinfo.cldno);
			if (access((char*)SourceBuf,0)!=0)					//�ж�û�иò���������������Ŀ¼
			{
				mkdir((char*)SourceBuf,0666);
			}
			sprintf((char*)SourceBuf,"%s/%04d/curr.dat",_CURRDIR_,proginfo->sm[proginfo->sm_tail].fileinfo.cldno);
			sprintf((char*)DesBuf,"%s/%04d/last.dat",_CURRDIR_,proginfo->sm[proginfo->sm_tail].fileinfo.cldno);
			if (access((char*)SourceBuf,0)==0)					//�е�ǰʵʱ����,�Ƚ�curr.dat���ݱ��浽last.dat����������һ������
			{
				if (ReadFile((char *)SourceBuf, &smfile_tmp,sizeof(SMFiles),proginfo)==0) {
					SaveFile((char*)DesBuf,&smfile_tmp,sizeof(SMFiles),proginfo);
				}
			}
			SaveFile((char*)proginfo->sm[proginfo->sm_tail].filename,&proginfo->sm[proginfo->sm_tail].manyFiles,proginfo->sm[proginfo->sm_tail].filelen,proginfo);
			break;
		case FILEDAY:			//�����ն�������
			memset(SourceBuf,0,60);
			sprintf((char*)SourceBuf,"%s/%04d",_DAYDIR_,proginfo->sm[proginfo->sm_tail].fileinfo.cldno);
			if (access((char*)SourceBuf,0)!=0)					//�ж�û�иò���������������Ŀ¼
			{
				mkdir((char*)SourceBuf,0666);
			}
			SaveFile((char*)proginfo->sm[proginfo->sm_tail].filename,&proginfo->sm[proginfo->sm_tail].manyFiles,proginfo->sm[proginfo->sm_tail].filelen,proginfo);
			break;
		case FILEMONTH:			//�����¶�������
			memset(SourceBuf,0,60);
			sprintf((char*)SourceBuf,"%s/%04d",_MONTHDIR_,proginfo->sm[proginfo->sm_tail].fileinfo.cldno);
			if (access((char*)SourceBuf,0)!=0)					//�ж�û�иò���������������Ŀ¼
			{
				mkdir((char*)SourceBuf,0666);
			}
			SaveFile((char*)proginfo->sm[proginfo->sm_tail].filename,&proginfo->sm[proginfo->sm_tail].manyFiles,proginfo->sm[proginfo->sm_tail].filelen,proginfo);
			break;
		case FILEHOUR:			//����Сʱ��������
			memset(DesBuf,0,60);
			sprintf((char*)DesBuf,"%s/%04d%02d%02d/",_HOURDIR_,proginfo->sm[proginfo->sm_tail].fileinfo.ts.Year,proginfo->sm[proginfo->sm_tail].fileinfo.ts.Month,proginfo->sm[proginfo->sm_tail].fileinfo.ts.Day);
			if (access((char*)DesBuf,0)!=0)	//��������Ŀ¼
			{
				mkdir((char*)DesBuf,0666);
			}
			memset(DesBuf,0,60);
			sprintf((char*)DesBuf,"%s/%04d%02d%02d/%04d/",_HOURDIR_,proginfo->sm[proginfo->sm_tail].fileinfo.ts.Year,proginfo->sm[proginfo->sm_tail].fileinfo.ts.Month,proginfo->sm[proginfo->sm_tail].fileinfo.ts.Day,proginfo->sm[proginfo->sm_tail].fileinfo.cldno);
			if (access((char*)DesBuf,0)!=0)	//����������Ŀ¼
			{
				mkdir((char*)DesBuf,0666);
			}
			SaveFile((char*)proginfo->sm[proginfo->sm_tail].filename,&proginfo->sm[proginfo->sm_tail].manyFiles,proginfo->sm[proginfo->sm_tail].filelen,proginfo);
			break;
		}
		tsspec.tv_sec=time(NULL)+3;
		sem_timedwait(&proginfo->mainData.UseCycleFlg,&tsspec);
		proginfo->sm[proginfo->sm_tail].dataChanged=0;
		proginfo->sm_tail = (proginfo->sm_tail+1)%SMBUFLEN;
		sem_post(&proginfo->mainData.UseCycleFlg);
//	}
}
#endif

/**************************************/
//�������ܣ�1���ӽ���һ�β����㱣������
//		  �����㱣��Ϊ�˱�֤�ļ��ȶ��ԣ�
//		  ��ÿ20����������з��鱣��һ���ļ�Ammeter%04d_%04d.par
//	 	  �ļ����ֺ��壺Ammeter%04d_%04d.par:�����㿪ʼ��_������.par
//		  �������1-2040�� Ammeter0001-0020.par,Ammeter0021-0040.par,�Դ�����
//		  F10_ChangedSave[0]-F10_ChangedSave[2039]:�������1-2040�������־
/**************************************/
void savePointConfig(TS nowts,ProgramInfo *proginfo,ParamInfo3761 *paraminfo,DataFileInfo *datainfo)
{
//	static TS	lastts;
//	static INT8U 	firstflag=1;
	char   	TempBuf[128];
	int		groupno,j;
	int		total_group;		//���㹲��Ҫ��������
	INT8U	findsave=0;

//	if(firstflag) {
//		lastts.Sec = nowts.Sec;
//		firstflag = 0;
//	}
	if(SaveNum!=0)	total_group = ((int)PointMax)/SaveNum;
//	if(nowts.Sec != lastts.Sec) {					//ÿ���ж�һ�����ݴ洢һ�β���������
//		lastts.Sec = nowts.Sec;
		for(groupno=0;groupno<total_group;groupno++) {
			ClearWaitTimes(ProjectNo,JProgramInfo);
			findsave = 0;
			for(j=0;j<SaveNum;j++) {				//20�����������һ���ж�
				if(proginfo->FileSaveFlag.F10_ChangedSave[groupno*SaveNum+j]==1) {	//��i�����������Ҫ�������ݣ������i������㱣��
					findsave=1;
					fprintf(stderr,"jSaveTask:F10------------j=%d,group=%d,groupno*SaveNum+j=%d",j,groupno,groupno*SaveNum+j);
					break;
				}
			}
			if(findsave==1) {		//�����i�����������
				fprintf(stderr,"jSaveTask:groupno=%d,status=%d,point=%d\n",groupno,paraminfo->group2.f10[groupno*SaveNum+j].Status,paraminfo->group2.f10[groupno*SaveNum+j].MeterNo);
				memset(TempBuf,0,128);
				sprintf((char*)TempBuf,"%s/Ammeter%04d_%04d.par",_PARADIR_,groupno*SaveNum+1,(groupno+1)*SaveNum);
				NormalSaveFile(TempBuf,&paraminfo->group2.f10[groupno*SaveNum],sizeof(F10)*SaveNum,proginfo);
				fprintf(stderr,"jSaveTask:FileName=%s\n",TempBuf);
				for(j=0;j<SaveNum;j++) {				//wyq �������������־
					proginfo->FileSaveFlag.F10_ChangedSave[groupno*SaveNum+j]=0;
				}
			}
		}
//	}
}

/**************************************/
//�������ܣ��������
/**************************************/
void cleanData(TS nowts,ProgramInfo *proginfo,ParamInfo3761 *paraminfo,DataFileInfo *datainfo,ConfigInfo *cfginfo)
{
	int 	i,j;
	TS		lastts;
	char	Command[60];

	memset(&datainfo->jc.JcDdRealData,0,sizeof(datainfo->jc.JcDdRealData));
	unlink("/nand/DataCurr/JcData.dat");
	unlink("/nand/DataCurr/JcData.dat.bak");
	//---------------------------
	proginfo->YxChange = 0;
	memset(Command, 0, 60);
	sprintf((char *) Command, "%s /nand/DataRiTongJi &", _CMDRMDIR_);
	syscmd((char *) Command,proginfo);
	memset(Command, 0, 60);
	sprintf((char *) Command, "%s /nand/DataYueTongJi &", _CMDRMDIR_);
	syscmd((char *) Command,proginfo);

	memset(Command, 0, 60);
	sprintf((char *) Command, "%s /nand/DataAlarm/* &", _CMDRMDIR_);
	syscmd((char *) Command,proginfo);
	memset(Command, 0, 60);
	sprintf((char *) Command, "%s /nand/DataHour/%04d%02d* &", _CMDRMDIR_,nowts.Year,nowts.Month);
	syscmd((char *) Command,proginfo);
	TimeDecrease(&lastts,5,1);
	memset(Command, 0, 60);
	sprintf((char *) Command, "%s /nand/DataHour/%04d%02d* &", _CMDRMDIR_,lastts.Year,lastts.Month);
	syscmd((char *) Command,proginfo);
	for (i = 0; i < PointMax; i++) {
		ClearWaitTimes(ProjectNo,JProgramInfo);
		memset(Command, 0, 60);
		sprintf((char *) Command, "/nand/DataCurr/%04d/", i + 1);
		if (access((char*) Command, 0) == 0) {
			memset(Command, 0, 60);
			sprintf((char *) Command, "%s /nand/DataCurr/%04d/* &",_CMDRM_, i + 1);
			syscmd((char *) Command,proginfo);
		}
		memset(Command, 0, 60);
		sprintf((char *) Command, "/nand/DataDay/%04d/", i + 1);
		if (access((char*) Command, 0) == 0) {
			memset(Command, 0, 60);
			sprintf((char *) Command, "%s /nand/DataDay/%04d/* &", _CMDRM_,i + 1);
			syscmd((char *) Command,proginfo);
		}
		memset(Command, 0, 60);
		sprintf((char *) Command, "/nand/DataMonth/%04d/", i + 1);
		if (access((char*) Command, 0) == 0) {
			memset(Command, 0, 60);
			sprintf((char *) Command, "%s /nand/DataMonth/%04d/* &", _CMDRM_,i + 1);
			syscmd((char *) Command,proginfo);
		}
	}

	memset(&datainfo->ErcEvt, 0, sizeof(datainfo->ErcEvt));
	for (i = 0; i < 8; i++)
		datainfo->ErcEvt.ERCBiaoZhi[i] = 0x00;
	for (i = 0; i < PointMax; i++) {
		for (j = 0; j < 64; j++)
			paraminfo->group2.f10[i].AlarmFlg[j] = 0x00;
	}
	proginfo->CurrErc.Buff[0] = 0;
	datainfo->ErcEvt.EC1 = 0;
	datainfo->ErcEvt.EC2 = 0;
	datainfo->ErcEvt.EC1old = 0;
	datainfo->ErcEvt.EC2old = 0;

}
/**************************************/
//�������ܣ��ն˸�λ����ǰ�������ݱ��洦��
/**************************************/
void rebootSaveProc(TS nowts,ProgramInfo *proginfo,ParamInfo3761 *paraminfo,DataFileInfo *datainfo,ConfigInfo *cfginfo)
{
	char	Command[60];

	switch(proginfo->stateflags.RebootFlag)
	{
	case F1_NO_INIT:				//�����ݳ�ʼ������������
		fprintf(stderr,"\njSaveTask:��վ���Ӳ����λ");
		datainfo->YueRunTj.ResetTime++;
		datainfo->YueRunTj.GdTime++;
		datainfo->DayRunTj.ResetTime++;
		datainfo->DayRunTj.GdTime++;
		proginfo->FileSaveFlag.drunflag = 1;
		proginfo->FileSaveFlag.mrunflag = 1;
		Class1DataProc(proginfo,paraminfo,datainfo,cfginfo);
		savePointConfig(nowts,proginfo,paraminfo,datainfo);
		sleep(3);
		memset(Command, 0, 60);
		sprintf((char *) Command, "%s/rebtsys &", _USERDIR_);
		system(Command);
		break;
	case F2_DATA_INIT:				//��������ʼ��������
		printf("\njSaveTask:��վ�����������λ");
		cleanData(nowts,proginfo,paraminfo,datainfo,cfginfo);	//���������
		datainfo->DayRunTj.ts = nowts;
		datainfo->DayRunTj.ResetTime=0;
		datainfo->YueRunTj.ts = nowts;
		datainfo->YueRunTj.ResetTime=0;
		proginfo->FileSaveFlag.drunflag = 1;
		proginfo->FileSaveFlag.mrunflag = 1;
		proginfo->FileSaveFlag.ercflag = 1;
		Class1DataProc(proginfo,paraminfo,datainfo,cfginfo);
		savePointConfig(nowts,proginfo,paraminfo,datainfo);
		sleep(1);
		memset(Command, 0, 60);
		sprintf((char *) Command, "%s/rebtsys &", _USERDIR_);
		system(Command);
		break;
	case F3_PARA_INIT:				//��������ȫ����������ʼ��,��������
		fprintf(stderr,"\r\n%s","��վ���������ȫ����������ʼ�����ָ��������ã�");
		cleanData(nowts,proginfo,paraminfo,datainfo,cfginfo);   //���������
		datainfo->DayRunTj.ResetTime = 0;
		datainfo->DayRunTj.GdTime = 0;
		datainfo->YueRunTj.ResetTime = 0;
		datainfo->YueRunTj.GdTime = 0;
		//---------------------------�������
		InitjzqInfo(0,paraminfo,proginfo,cfginfo,datainfo);		//0:ȫ�����
		InitMeterInfo(paraminfo);
		InitTaskInfo(paraminfo,proginfo);
		proginfo->stateflags.Reset_Changed= 1;

		savePointConfig(nowts,proginfo,paraminfo,datainfo);
		proginfo->FileSaveFlag.g1flag = 1;
		proginfo->FileSaveFlag.g2flag = 1;
		proginfo->FileSaveFlag.g4flag = 1;
		proginfo->FileSaveFlag.g5flag = 1;
		proginfo->FileSaveFlag.g9flag = 1;
		proginfo->FileSaveFlag.jzqflag = 1;
		proginfo->FileSaveFlag.ercflag = 1;
		Class1DataProc(proginfo,paraminfo,datainfo,cfginfo);
		break;
	case F4_PARA_DATA_INIT:				//����(����ϵͳ��վͨ���йص�)��ȫ����������ʼ������������
		fprintf(stderr,"\r\n%s","��վ�����������������λ(ͨ�ų���)");
		cleanData(nowts,proginfo,paraminfo,datainfo,cfginfo);	//���������
		datainfo->DayRunTj.ResetTime = 0;						//9.23
		datainfo->DayRunTj.GdTime = 0;
		datainfo->YueRunTj.ResetTime = 0;
		datainfo->YueRunTj.GdTime = 0;
		//---------------------------�������
		InitjzqInfo(1,paraminfo,proginfo,cfginfo,datainfo);		//1:��ͨ�Ų������������
		InitMeterInfo(paraminfo);
		InitTaskInfo(paraminfo,proginfo);
		//---------------------------��������
		proginfo->FileSaveFlag.g1flag = 1;
		proginfo->FileSaveFlag.g2flag = 1;
		proginfo->FileSaveFlag.g4flag = 1;
		proginfo->FileSaveFlag.g5flag = 1;
		proginfo->FileSaveFlag.g9flag = 1;
		proginfo->FileSaveFlag.jzqflag = 1;
		proginfo->FileSaveFlag.ercflag = 1;
		Class1DataProc(proginfo,paraminfo,datainfo,cfginfo);
		proginfo->stateflags.Reset_Changed = 1;
		break;
	}
}

/**************************************/
//�������ܣ�ÿ��3��20����һ����Ҫ�����ļ�
//			�����������ͨѶ����
/**************************************/
void copyParaFile(TS nowts,ProgramInfo *proginfo,ParamInfo3761 *paraminfo,DataFileInfo *datainfo,ConfigInfo *cfginfo)
{
	static TS	lastts;
	static INT8U	firstflag=1;

	if(firstflag == 1) {
		lastts.Hour = nowts.Hour;
		lastts.Minute = nowts.Minute;
		firstflag = 0;
	}
	//ÿ��3��20�ֱ���һ����Ҫ�����ļ�
	if(nowts.Hour==3 && nowts.Minute == 20 && nowts.Hour!=lastts.Hour && nowts.Minute != lastts.Minute) {
		lastts.Hour = 0;
		lastts.Minute = 0;

	}
}

/**************************************/
//�������ܣ���Сʱ2���Ӻ�洢һ��CSQ�ź�
/**************************************/
void saveCSQ(TS nowts,ProgramInfo *proginfo,ParamInfo3761 *paraminfo,DataFileInfo *datainfo)
{
	static INT8U	firstflag=1;
	static TS	lastts;
	char		TempBuf[128];
	INT8U		i;

	if(firstflag == 1) {
		lastts.Day = nowts.Day;
		lastts.Hour = nowts.Hour;
		lastts.Minute = nowts.Minute;
		firstflag = 0;
//		fprintf(stderr,"       >>>>>>>>>>>>>>>>>>>last.Hour=%d,last.Min=%d\n",lastts.Hour,lastts.Minute);
	}
	if(lastts.Day != nowts.Day) {
		lastts.Day = nowts.Day;
		for(i=0;i<24;i++){
			JDataFileInfo->logininfo.GprsCSQ[i]=0xEE;
		}
		memset(TempBuf,0,128);
		sprintf((char*)TempBuf,"%s/csq.dat",_ALARMDIR_);
		SaveFile(TempBuf,&datainfo->logininfo.GprsCSQ,sizeof(datainfo->logininfo.GprsCSQ),proginfo);
	}
	if((lastts.Hour!=nowts.Hour)&&(nowts.Minute==1)) {
		if(nowts.Hour>23) return;
		datainfo->logininfo.GprsCSQ[nowts.Hour] = datainfo->DayRunTj.GprsCSQ;
		fprintf(stderr,"save Hour=%d,Min=%d CSQ[%d]=%d\n",nowts.Hour,nowts.Minute,nowts.Hour,datainfo->logininfo.GprsCSQ[nowts.Hour]);
		memset(TempBuf,0,128);
		sprintf((char*)TempBuf,"%s/csq.dat",_ALARMDIR_);
		SaveFile(TempBuf,&datainfo->logininfo.GprsCSQ[0],sizeof(datainfo->logininfo.GprsCSQ),proginfo);
		lastts.Hour = nowts.Hour;
	}
}

