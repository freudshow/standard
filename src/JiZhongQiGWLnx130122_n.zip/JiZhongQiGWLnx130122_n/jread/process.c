/*
 * process.c
 *
 *  Created on: 2013-1-11
 *      Author: Administrator
 */
#include "jread.h"

void ProcessGroup1(char argc, char *argv[])
{
	int i;
	char 	TempBuf[128];
	if (strcmp("f1", argv[1])==0)
	{
		Group1 g1;
		memset(TempBuf,0,128);
		sprintf((char*)TempBuf,"%s/group1.par",_PARADIR_);
		NormalReadFile((char*)TempBuf,(INT8U *)&g1,sizeof(Group1),JProgramInfo);

		printf("RTS = %d\n", g1.f1.RTS);
		printf("Allow_Delay = %d\n", g1.f1.Allow_Delay);
		printf("DelayTime_AgainNum = %d\n", g1.f1.DelayTime_AgainNum);
		printf("NeedAllow = %d\n", g1.f1.NeedAllow);
		printf("%s = %d\n", "��������",g1.f1.HeartInterval);
		return;
	}
	if (strcmp("f2", argv[1])==0)
	{
		Group1 g1;
		memset(TempBuf,0,128);
		sprintf((char*)TempBuf,"%s/group1.par",_PARADIR_);
		NormalReadFile((char*)TempBuf,(INT8U *)&g1,sizeof(Group1),JProgramInfo);

		printf("Flag_AddrNum = %d\n", g1.f2.Flag_AddrNum);
		for(i=0;i<g1.f2.Flag_AddrNum;i++)
		{
			printf("Addr[%d] = %d\n", i, (g1.f2.Addr[i][1]<<8) + g1.f2.Addr[i][0]);
		}
		return;
	}
	if (strcmp("f3", argv[1])==0)
	{
		Group1 g1;
		char TmpAPN[17];
		memset(TmpAPN, 0x00, sizeof(TmpAPN));

		memset(TempBuf,0,128);
		sprintf((char*)TempBuf,"%s/group1.par",_PARADIR_);
		NormalReadFile((char*)TempBuf,(INT8U *)&g1,sizeof(Group1),JProgramInfo);

		printf("%s = %d.%d.%d.%d\n", "��վip�����ã�",g1.f3.IP[3],g1.f3.IP[2],g1.f3.IP[1],g1.f3.IP[0]);
		printf("%s = %d\n", "��վport�����ã�",(g1.f3.PortAddress[1]<<8) + g1.f3.PortAddress[0]);
		printf("%s = %d.%d.%d.%d\n", "��վip�����ã�",g1.f3.IP1[3],g1.f3.IP1[2],g1.f3.IP1[1],g1.f3.IP1[0]);
		printf("%s = %d\n", "��վport�����ã�", (g1.f3.PortAddress1[1]<<8) + g1.f3.PortAddress1[0]);
		printf("APN = ");

		for (i = 0; i < 16; i++)
		{
			if (TmpAPN[i] != 0xff)
				TmpAPN[i] = g1.f3.APN[15 - i];
			if (TmpAPN[i] != 0xff)
				printf("%c", TmpAPN[i]);
		}
		printf("\n");
		return;
	}
	if (strcmp("f4", argv[1])==0)
	{
		Group1 g1;
		char TmpZZ[17],TmpSM[17];
		memset(TmpZZ, 0x00, sizeof(TmpZZ));
		memset(TmpSM, 0x00, sizeof(TmpSM));

		memset(TempBuf,0,128);
		sprintf((char*)TempBuf,"%s/group1.par",_PARADIR_);
		NormalReadFile((char*)TempBuf,(INT8U *)&g1,sizeof(Group1),JProgramInfo);

		for(i=0;i<8;i++)
		{
			TmpZZ[i*2] = (g1.f4.ZZ[i]>>4) & 0x0f;
			TmpZZ[i*2+1] = g1.f4.ZZ[i] & 0x0f;

			TmpSM[i*2] = (g1.f4.SM[i]>>4) & 0x0f;
			TmpSM[i*2+1] = g1.f4.SM[i] & 0x0f;
		}
		printf("ZZ = ");
		for(i=0;i<16;i++)
			printf("%x",TmpZZ[i]);
		printf("\n");

		printf("SM = ");
		for(i=0;i<16;i++)
			printf("%x",TmpSM[i]);
		printf("\n");
		return;
	}
	if (strcmp("f5", argv[1])==0)
	{
		Group1 g1;
		memset(TempBuf,0,128);
		sprintf((char*)TempBuf,"%s/group1.par",_PARADIR_);
		NormalReadFile((char*)TempBuf,(INT8U *)&g1,sizeof(Group1),JProgramInfo);

		printf("XiaoXi_Renzheng_FangAN = %d\n", g1.f5.XiaoXi_Renzheng_FangAN);
		printf("CanShu = %d\n", (g1.f5.CanShu[1]<<8) + g1.f5.CanShu[0]);
		return;
	}
	if (strcmp("f6", argv[1])==0)
	{
		Group1 g1;
		memset(TempBuf,0,128);
		sprintf((char*)TempBuf,"%s/group1.par",_PARADIR_);
		NormalReadFile((char*)TempBuf,(INT8U *)&g1,sizeof(Group1),JProgramInfo);

		printf("GroupAdress0 = %d\n", (g1.f6.GroupAdress0[1]<<8) + g1.f6.GroupAdress0[0]);
		printf("GroupAdress1 = %d\n", (g1.f6.GroupAdress1[1]<<8) + g1.f6.GroupAdress1[0]);
		printf("GroupAdress2 = %d\n", (g1.f6.GroupAdress2[1]<<8) + g1.f6.GroupAdress2[0]);
		printf("GroupAdress3 = %d\n", (g1.f6.GroupAdress3[1]<<8) + g1.f6.GroupAdress3[0]);
		printf("GroupAdress4 = %d\n", (g1.f6.GroupAdress4[1]<<8) + g1.f6.GroupAdress4[0]);
		printf("GroupAdress5 = %d\n", (g1.f6.GroupAdress5[1]<<8) + g1.f6.GroupAdress5[0]);
		printf("GroupAdress6 = %d\n", (g1.f6.GroupAdress6[1]<<8) + g1.f6.GroupAdress6[0]);
		printf("GroupAdress7 = %d\n", (g1.f6.GroupAdress7[1]<<8) + g1.f6.GroupAdress7[0]);
		return;
	}
	if (strcmp("f7", argv[1])==0)
	{
		Group1 g1;
		memset(TempBuf,0,128);
		sprintf((char*)TempBuf,"%s/group1.par",_PARADIR_);
		NormalReadFile((char*)TempBuf,(INT8U *)&g1,sizeof(Group1),JProgramInfo);

		printf("%s = %d.%d.%d.%d\n", "�ն�IP", g1.f7.IP[3],g1.f7.IP[2],g1.f7.IP[1],g1.f7.IP[0]);
		printf("%s = %d.%d.%d.%d\n", "�ն���������",g1.f7.SubnetAddresses[3],g1.f7.SubnetAddresses[2],g1.f7.SubnetAddresses[1],g1.f7.SubnetAddresses[0]);
		printf("%s = %d.%d.%d.%d\n", "�ն�����",g1.f7.GateWay[3],g1.f7.GateWay[2],g1.f7.GateWay[1],g1.f7.GateWay[0]);
		printf("SubstituteType = %d\n", g1.f7.SubstituteType);
		printf("%s = %d.%d.%d.%d\n", "������������ַ",g1.f7.SubstituteIP[3],g1.f7.SubstituteIP[2],g1.f7.SubstituteIP[1],g1.f7.SubstituteIP[0]);
		printf("%s = %d\n", "�����������˿�",(g1.f7.SubstitutePort[1]<<8) + g1.f7.SubstitutePort[0]);
		printf("SubstituteConnetType = %d\n", g1.f7.SubstituteConnetType);

		printf("%s = %d\n", "�û�������",g1.f7.UserLen);
		printf("%s = ", "�û���");
		for(i=0;i<g1.f7.UserLen;i++)
			printf("%c",g1.f7.UserName[i]);
		printf("\n");

		printf("%s = %d\n", "���볤��",g1.f7.PassLen);
		printf("%s = ","����");
		for(i=0;i<g1.f7.PassLen;i++)
			printf("%c",g1.f7.PassWords[i]);
		printf("\n");
		printf("%s = %d\n", "�ն������˿�",(g1.f7.WatchPort[1]<<8) + g1.f7.WatchPort[0]);
		return;
	}
	if (strcmp("f8", argv[1])==0)
	{
		Group1 g1;
		memset(TempBuf,0,128);
		sprintf((char*)TempBuf,"%s/group1.par",_PARADIR_);
		NormalReadFile((char*)TempBuf,(INT8U *)&g1,sizeof(Group1),JProgramInfo);

		printf("Type = %d\n", g1.f8.Type);
		printf("Interval = %d\n", (g1.f8.Interval[1]<<8) + g1.f8.Interval[0]);
		printf("Num = %d\n", g1.f8.Num);
		printf("ShutDown = %d\n", g1.f8.ShutDown);
		printf("Flag[0-2] = %02x %02x %02x\n", g1.f8.Flag[0], g1.f8.Flag[1], g1.f8.Flag[2]);
		return;
	}
	if (strcmp("g1", argv[1])==0 || strcmp("group1", argv[1])==0)
	{
		char *argvPrt[9] = {"null","f1","f2","f3","f4","f5","f6","f7","f8"};

		printf("F1:\n");
		ProcessGroup1(argc, &argvPrt[0]);
		printf("\nF2:\n");
		ProcessGroup1(argc, &argvPrt[1]);
		printf("\nF3:\n");
		ProcessGroup1(argc, &argvPrt[2]);
		printf("\nF4:\n");
		ProcessGroup1(argc, &argvPrt[3]);
		printf("\nF5:\n");
		ProcessGroup1(argc, &argvPrt[4]);
		printf("\nF6:\n");
		ProcessGroup1(argc, &argvPrt[5]);
		printf("\nF7:\n");
		ProcessGroup1(argc, &argvPrt[6]);
		printf("\nF8:\n");
		ProcessGroup1(argc, &argvPrt[7]);
		return;
	}
}

void ProcessGroup2(char argc, char *argv[])
{
	int i,j;
	char TempBuf[128];
	if (strcmp("f9", argv[1])==0)
	{
		Group2 g2;
		memset(TempBuf,0,128);
		sprintf((char*)TempBuf,"%s/group2.par",_PARADIR_);
		if(NormalReadFile((char*)TempBuf,(INT8U *)&g2,sizeof(Group2),JProgramInfo)==0) {
			INT8U flag1[64],flag2[64];
			for(i=0;i<8;i++)
			{
				for(j=0;j<8;j++)
				{
					flag1[i*8+j] = (g2.f9.Flag[i]>>j) & 0x01;
					flag2[i*8+j] = (g2.f9.FlagStep[i]>>j) & 0x01;
				}
			}
			printf("%s = ", "�¼���¼��Ч��־λ[D0-D63]");
			for(i=0;i<64;i++)
			{
				printf("%d",flag1[i]);
				if ((i+1)%8==0)
					printf("  ");
			}
			printf("\n");

			printf("%s = ", "�¼���Ҫ�Եȼ���־λ[D0-D63]");
			for(i=0;i<64;i++)
			{
				printf("%d",flag2[i]);
				if ((i+1)%8==0)
					printf("  ");
			}
			printf("\n");
		}
		return;
	}
	if (strcmp("f11", argv[1])==0)
	{
		Group2 g2;
		memset(TempBuf,0,128);
		sprintf((char*)TempBuf,"%s/group2.par",_PARADIR_);
		if(NormalReadFile((char*)TempBuf,(INT8U *)&g2,sizeof(Group2),JProgramInfo)==0) {
			printf("%s\n", "�����������	��������	�������k");
			for(i=0;i<MaichongInputMax;i++)
			{
				printf("[%d]: %d	%d		%d\n",i, g2.f11.MaiChong[i].CeLiangNo,g2.f11.MaiChong[i].Stat,
										(g2.f11.MaiChong[i].ChangShu[1]<<8) + g2.f11.MaiChong[i].ChangShu[0]);
			}
		}
		return;
	}
	if (strcmp("f12", argv[1])==0)
	{
		Group2 g2;
		memset(TempBuf,0,128);
		sprintf((char*)TempBuf,"%s/group2.par",_PARADIR_);
		if(NormalReadFile((char*)TempBuf,(INT8U *)&g2,sizeof(Group2),JProgramInfo)==0){
			printf("Flag = %d\n", g2.f12.Flag);
			printf("Attr = %d\n", g2.f12.Attr);
		}
		return;
	}
	if (strcmp("f13", argv[1])==0)
	{
		Group2 g2;
		memset(TempBuf,0,128);
		sprintf((char*)TempBuf,"%s/group2.par",_PARADIR_);
		if(NormalReadFile((char*)TempBuf,(INT8U *)&g2,sizeof(Group2),JProgramInfo)==0) {

			printf("%s\n", "    �������	����");
			for(i=0;i<ZhiliuInputMax;i++)
			{
				printf("[%d]:	%d	 %d\n", i, g2.f13.VI[i].CeLiangNo, g2.f13.VI[i].Stat);
			}
		}
		return;
	}
	if (strcmp("g2", argv[1])==0 || strcmp("group2", argv[1])==0)
	{
		char *argvPrt[8] = {"null","f9","f11","f12","f13","f14","f15","f16"};

		printf("F9:\n");
		ProcessGroup2(argc, &argvPrt[0]);
		printf("\nF11:\n");
		ProcessGroup2(argc, &argvPrt[1]);
		printf("\nF12:\n");
		ProcessGroup2(argc, &argvPrt[2]);
		printf("\nF13:\n");
		ProcessGroup2(argc, &argvPrt[3]);
		return;
	}
}


void ProcessTask(char argc, char *argv[])
{
	int i;
	char TempBuf[128];

	Group9 g9;
	memset(TempBuf,0,128);
	sprintf((char*)TempBuf,"%s/group9_task.par",_PARADIR_);
	NormalReadFile((char*)TempBuf,(INT8U *)&g9,sizeof(Group9),JProgramInfo);

	if (argc==2 || strcmp("-h", argv[2])==0)
	{
		printf("example: jtask1 1	  %s\n","��ʾ���Ϊ1��һ������");
		printf("         jtask1 all	  %s\n","��ʾ����һ������");
		printf("         jtask1 running	  %s\n","��ʾ�����е�һ������");
		return;
	}
	if (strcmp("task1", argv[1])==0)
	{
		if (strcmp("all", argv[2])==0)	//��ʾ����һ������
		{
			printf("   ����״̬      ��׼ʱ��    ���ݵ�Ԫ����\n");
			for(i=0;i<Task1_Max;i++)
			{
				printf("[%02d]: %02x    %02d-%02d-%02d %02d:%02d:%02d	  %d\n",i, g9.f67[i].IsRun,
						g9.f65[i].Post_Time[5],g9.f65[i].Post_Time[4],g9.f65[i].Post_Time[3],
						g9.f65[i].Post_Time[2],g9.f65[i].Post_Time[1],g9.f65[i].Post_Time[0],
						g9.f65[i].Count);
			}
		}
		else if (strcmp("running", argv[2])==0)	//��ʾ�����е�һ������
		{
			printf("         ��׼ʱ��        ���ݵ�Ԫ����\n");
			for(i=0;i<Task1_Max;i++)
			{
				if (g9.f67[i].IsRun == 0x55)
				{
					printf("[%02d]: %02d-%02d-%02d %02d:%02d:%02d	      %d\n",i,
							g9.f65[i].Post_Time[5],g9.f65[i].Post_Time[4],g9.f65[i].Post_Time[3],
							g9.f65[i].Post_Time[2],g9.f65[i].Post_Time[1],g9.f65[i].Post_Time[0],
							g9.f65[i].Count);
				}
			}
		}
		else	//��ʾĳ��һ������
		{
			i = atoi(argv[2]);
			if (i>=1 && i<=Task1_Max)
			{
				printf("����״̬      ��׼ʱ��     ���ݵ�Ԫ����\n");
				printf("  %02x      %02d-%02d-%02d %02d:%02d:%02d     %d\n",g9.f67[i-1].IsRun,
						g9.f65[i-1].Post_Time[5],g9.f65[i-1].Post_Time[4],g9.f65[i-1].Post_Time[3],
						g9.f65[i-1].Post_Time[2],g9.f65[i-1].Post_Time[1],g9.f65[i-1].Post_Time[0],
						g9.f65[i-1].Count);
			}
			else
			{
				printf("%s\n","����Ŵ��󣡣���");
			}
		}
	}
	if (strcmp("task2", argv[1])==0)
	{
		if (strcmp("all", argv[2])==0)	//��ʾ����һ������
		{
			printf("   ����״̬      ��׼ʱ��    ���ݵ�Ԫ����\n");
			for(i=0;i<Task1_Max;i++)
			{
				printf("[%02d]: %02x    %02d-%02d-%02d %02d:%02d:%02d	  %d\n",i, g9.f68[i].IsRun,
						g9.f66[i].Post_Time[5],g9.f66[i].Post_Time[4],g9.f66[i].Post_Time[3],
						g9.f66[i].Post_Time[2],g9.f66[i].Post_Time[1],g9.f66[i].Post_Time[0],
						g9.f66[i].Count);
			}
		}
		else if (strcmp("running", argv[2])==0)	//��ʾ�����е�һ������
		{
			printf("         ��׼ʱ��        ���ݵ�Ԫ����\n");
			for(i=0;i<Task1_Max;i++)
			{
				if (g9.f68[i].IsRun == 0x55)
				{
					printf("[%02d]: %02d-%02d-%02d %02d:%02d:%02d	      %d\n",i,
							g9.f66[i].Post_Time[5],g9.f66[i].Post_Time[4],g9.f66[i].Post_Time[3],
							g9.f66[i].Post_Time[2],g9.f66[i].Post_Time[1],g9.f66[i].Post_Time[0],
							g9.f66[i].Count);
				}
			}
		}
		else	//��ʾĳ��һ������
		{
			i = atoi(argv[2]);
			if (i>=1 && i<=Task1_Max)
			{
				printf("����״̬      ��׼ʱ��     ���ݵ�Ԫ����\n");
				printf("  %02x      %02d-%02d-%02d %02d:%02d:%02d     %d\n",g9.f68[i-1].IsRun,
						g9.f66[i-1].Post_Time[5],g9.f66[i-1].Post_Time[4],g9.f66[i-1].Post_Time[3],
						g9.f66[i-1].Post_Time[2],g9.f66[i-1].Post_Time[1],g9.f66[i-1].Post_Time[0],
						g9.f66[i-1].Count);
			}
			else
			{
				printf("%s\n","����Ŵ��󣡣���");
			}
		}
	}
}

void ProcessPoint(char argc, char *argv[])
{
	char TempBuf[128];
	int i, num, groupNum;
	num = 0;
	groupNum = ((int)PointMax)/SaveNum;
	Group2 g2;

	for(i=0;i<groupNum;i++)	//��ȡ������
	{
		memset(TempBuf,0,128);
		sprintf((char*)TempBuf,"%s/Ammeter%04d_%04d.par",_PARADIR_,i*SaveNum+1,(i+1)*SaveNum);
		NormalReadFile((char*)TempBuf,(INT8U *)&g2.f10[i*SaveNum],sizeof(F10)*SaveNum, JProgramInfo);
	}
	printf("״̬  ��ѯ���  �������  ͨ��Э��  ��������ַ  �������  �������  �ɼ�����  �ɼ�����ַ  �����  С���  �˿ں�\n");
	for(i=0;i<PointMax;i++)
	{
		if (g2.f10[i].Status==1)
		{
			printf("%d	  [%02d]:      %d       %02d    %02x%02x%02x%02x%02x%02x      %d		%d	%d    %02x%02x%02x%02x%02x%02x     %d      %d       %d\n",
					g2.f10[i].Status,i+1,
					(g2.f10[i].PointIndex[1]<<8) + g2.f10[i].PointIndex[0],
					g2.f10[i].ConnectType,
					g2.f10[i].Address[5],
					g2.f10[i].Address[4],
					g2.f10[i].Address[3],
					g2.f10[i].Address[2],
					g2.f10[i].Address[1],
					g2.f10[i].Address[0],
					g2.f10[i].MeterNo,
					g2.f10[i].Type,
					g2.f10[i].CjqNo,
					g2.f10[i].CaijiqiAddress[5],
					g2.f10[i].CaijiqiAddress[4],
					g2.f10[i].CaijiqiAddress[3],
					g2.f10[i].CaijiqiAddress[2],
					g2.f10[i].CaijiqiAddress[1],
					g2.f10[i].CaijiqiAddress[0],
					g2.f10[i].UserType & 0x0f,
					(g2.f10[i].UserType>>4) & 0x0f,
					g2.f10[i].port);
		}
	}
}

void ProcessJzqPara(char argc, char *argv[])
{
	char TempBuf[128];
	JZQPara jzqpara;
	memset(TempBuf,0,128);
	sprintf((char*)TempBuf,"%s/jzqpara.par",_PARADIR_);
	NormalReadFile((char*)TempBuf,(INT8U *)&jzqpara,sizeof(JZQPara),JProgramInfo);

	printf("%s = %02x%02x\n","����������",jzqpara.Area_8016.JZ_XingZhuangQuHaoMa[0],jzqpara.Area_8016.JZ_XingZhuangQuHaoMa[1]);
	printf("%s = %d\n","��������ַ",(jzqpara.Address_8017.JZ_di_zhi[0]<<8) + jzqpara.Address_8017.JZ_di_zhi[1]);
	printf("%s = %s\n","���̴���",jzqpara.ver.FactNo);
	printf("%s = %s\n","�豸���",jzqpara.ver.DevNo);
	printf("%s = %s\n","�����汾��",jzqpara.ver.SoftVer);
	printf("%s = %02x-%02x-%02x\n","������������",jzqpara.ver.SoftDate[2],jzqpara.ver.SoftDate[1],jzqpara.ver.SoftDate[0]);
	printf("%s = %s\n","������Ϣ��",jzqpara.ver.SetInf);
	printf("%s = %s\n","��Լ�汾��",jzqpara.ver.ProtVer);
	printf("%s = %s\n","Ӳ���汾��",jzqpara.ver.HardVer);
	printf("%s = %02x-%02x-%02x\n","Ӳ����������",jzqpara.ver.HardDate[2],jzqpara.ver.HardDate[1],jzqpara.ver.HardDate[0]);
	printf("%s = %d\n","ͨѶ����",jzqpara.DevFlg & 0x0f);
	printf("%s = %d\n","����ͨ���ŵ�",(jzqpara.DevFlg>>4)&0x0f);
	printf("%s = %d\n","����ͨѶ״̬",jzqpara.CommStat);
	printf("%s = %d\n","RJ45��GPRS�л�",jzqpara.CommType);
	printf("%s = %d\n","������������",jzqpara.ChaoBiaoDongJieType);
	printf("%s = %s\n","�㳭or�ֳ�",(jzqpara.HeBei_ReadLevelOne==0)?("�㳭"):("�ֳ�"));
	printf("%s = %s\n,","�ֻ�����",(jzqpara.SIMCard));
//	for(i=0;i<R485Max;i++) {
//		printf(" = %s\n,","",(jzqpara.data485.ts));
//	}
}

void ProcessErcPara(char argc, char *argv[])
{
	char TempBuf[128];
	ErcSave    ErcEvt;

	memset(TempBuf,0,128);
	sprintf((char*)TempBuf,"%s/ercevent.par",_PARADIR_);
	NormalReadFile((char*)TempBuf,(INT8U *)&ErcEvt,sizeof(ErcSave),JProgramInfo);
	printf("EC1 = %d, EC1Old = %d \n",ErcEvt.EC1,ErcEvt.EC1old);
	printf("EC2 = %d, EC2Old = %d \n",ErcEvt.EC2,ErcEvt.EC2old);
}

void ProcessAlarmPara(char argc, char *argv[])
{
	char TempBuf[128];
	TongJi	tongji;

	memset(TempBuf,0,128);
	sprintf((char*)TempBuf,"%s/%s",_ALARMDIR_,argv[2]);
	if (access((char*)TempBuf, 0) == 0)
	ReadFile((char*)TempBuf,(INT8U *)&tongji,sizeof(tongji),JProgramInfo);
	fprintf(stderr,"TS: %d-%d-%d %d:%d:%d\n",tongji.ts.Year,tongji.ts.Month,tongji.ts.Day,tongji.ts.Hour,tongji.ts.Minute,tongji.ts.Sec);
	fprintf(stderr,"����ʱ��=%d, ���� =%d,��λ����=%d\n",tongji.GdTime,tongji.LiuLiang,tongji.ResetTime);
	fprintf(stderr,"������������1�ۼ�ʱ��=%d, ������������2�ۼ�ʱ�� =%d,������������3�ۼ�ʱ��=%d\n",tongji.Ys1Time,tongji.Ys2Time,tongji.Ys3Time);
	fprintf(stderr,"�ź�ǿ��=%d,��½����=%d\n",tongji.GprsCSQ,tongji.ResetTime);
//	JParamInfo3761->group5.f35.Count =1;
//	JParamInfo3761->group5.f35.Index[0]=1;		//�����ص��û�����
}

void ProcessCSQAlarm(char argc, char *argv[])
{
	char 	TempBuf[128];
	INT32S	csq[24];
	INT8U	i;

	for(i=0;i<24;i++){
		fprintf(stderr,"Hour%02d: csq=%d\n",i,JDataFileInfo->logininfo.GprsCSQ[i]);
	}

	memset(TempBuf,0,128);
	sprintf((char*)TempBuf,"%s/csq.dat",_ALARMDIR_);
	if (access((char*)TempBuf, 0) == 0) {
		ReadFile((char*)TempBuf,&csq[0],sizeof(csq),JProgramInfo);
		fprintf(stderr,"csq.dat value\n");
		for(i=0;i<24;i++){
			fprintf(stderr,"Hour%02d: csq=%d\n",i,csq[i]);
		}
	}else fprintf(stderr,"no csq.dat\n");
//	printf("Err4:ERCNo=%d,\n",JDataFileInfo.ErcEvt.ImpEvent[4].Err4.ERCNo);
	//,JDataFileInfo.ErcEvt.ImpEvent[0].Err4.Occur_Time);
}

