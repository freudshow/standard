/*
 * jread.h
 *
 *  Created on: 2013-1-11
 *      Author: Administrator
 */

#ifndef JREAD_H_
#define JREAD_H_

#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <dirent.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <arpa/inet.h>
#include <ctype.h>
#include <time.h>
#include <signal.h>
#include <semaphore.h>
#include <errno.h>
#include <netdb.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <math.h>
#include <inc/jMemory.h>
#include <inc/pubfunction.h>
//#include <inc/at91sam9260_pio.h>
#include <pthread.h>
#include <math.h>


ParamInfo3761* JParamInfo3761;
DataFileInfo*  JDataFileInfo;
ConfigInfo*    JConfigInfo;
ProgramInfo* 	JProgramInfo;

int ProjectNo;

#endif /* JREAD_H_ */
