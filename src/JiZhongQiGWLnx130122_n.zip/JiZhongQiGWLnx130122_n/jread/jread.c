/*
 * jread.c
 *
 *  Created on: 2013-1-11
 *      Author: Administrator
 */

#include "jread.h"

extern void ProcessGroup1(int argc, char *argv[]);
extern void ProcessGroup2(int argc, char *argv[]);
extern void ProcessTask(int argc, char *argv[]);
extern void ProcessPoint(int argc, char *argv[]);
extern void ProcessJzqPara(int argc, char *argv[]);
extern void ProcessErcPara(int argc, char *argv[]);
extern void ProcessAlarmPara(int argc, char *argv[]);
extern void ProcessCSQAlarm(char argc, char *argv[]);

void CommandProcess(int argc, char *argv[])
{
	if (strcmp("f1", argv[1])==0 || strcmp("f2", argv[1])==0 ||
		strcmp("f3", argv[1])==0 || strcmp("f4", argv[1])==0 ||
		strcmp("f5", argv[1])==0 || strcmp("f6", argv[1])==0 ||
		strcmp("f7", argv[1])==0 || strcmp("f8", argv[1])==0 ||
		strcmp("g1", argv[1])==0 || strcmp("group1", argv[1])==0)
	{
		ProcessGroup1(argc, argv);
		return;
	}
	else if (strcmp("f9", argv[1])==0 || strcmp("f11", argv[1])==0 ||
			strcmp("f12", argv[1])==0 || strcmp("f13", argv[1])==0 ||
			strcmp("f14", argv[1])==0 || strcmp("f15", argv[1])==0 || strcmp("f16", argv[1])==0 ||
			strcmp("g2", argv[1])==0 || strcmp("group2", argv[1])==0)
	{
		ProcessGroup2(argc, argv);
		return;
	}
	else if (strcmp("task1", argv[1])==0 || strcmp("task2", argv[1])==0)
	{
		ProcessTask(argc, argv);
		return;
	}
	else if (strcmp("point", argv[1])==0)
	{
		ProcessPoint(argc, argv);
		return;
	}
	else if (strcmp("jzqpara", argv[1])==0)
	{
		ProcessJzqPara(argc, argv);
		return;
	}
	else if (strcmp("ercpara", argv[1])==0)
	{
		ProcessErcPara(argc, argv);
		return;
	}
	else if (strcmp("alarm", argv[1])==0)
	{
		ProcessAlarmPara(argc, argv);
		return;
	}
	else if (strcmp("csq", argv[1])==0)
	{
		ProcessCSQAlarm(argc, argv);
		return;
	}
}

int main(int argc, char *argv[])
{
	JParamInfo3761 = Open1ShMem("ParamInfo3761",sizeof(ParamInfo3761),NULL);
	JDataFileInfo = Open1ShMem("DataFileInfo",sizeof(DataFileInfo),NULL);
	JConfigInfo = Open1ShMem("ConfigInfo",sizeof(ConfigInfo),NULL);
	JProgramInfo = Open1ShMem("ProgramInfo",sizeof(ProgramInfo),NULL);

	if(JProgramInfo->mainData.MemoryLength!=sizeof(ProgramInfo))
	{
		fprintf(stderr,"\nShare mem uncompared!\n");
		return EXIT_FAILURE;
	}

	sem_init(&JProgramInfo->mainData.UseFMFileFlg,1,1);//����д������Ϣ��������ͻ
	sem_init(&JProgramInfo->mainData.UseCycleFlg,1,1);//����д������Ϣ��������ͻ
	sem_init(&JProgramInfo->mainData.UseFileFlg,1,1);//�����ļ�������ͻ
	sem_init(&JProgramInfo->mainData.Gprs_Data_Flag,1,1);//��������ģ�黺������ͻ

	if (argc==1)
	{
		printf("jread [Command] [options]\n");
		printf("Command:\n");
		printf("f1(f1-f8)	example:jread f1(f1-f8)		print f1-f8\n");
		printf("g1			example:jread g1		printf group1\n");
		printf("g2			example:jread g2		printf group2\n");
		printf("task1 [1 all running]		example:jread task1 all		printf task1 info\n");
		printf("point		example:jread point		printf point info\n");
		printf("jzqpara		example:jread jzqpara		printf jzqpara info\n");
		printf("alarm  �ļ���  example:jread alarm d25.par	printf Alarm info\n");
		printf("csq     example:jread csq		printf csq info\n");
	}
	else
	{
		CommandProcess(argc, argv);
	}

	return 0;
}
