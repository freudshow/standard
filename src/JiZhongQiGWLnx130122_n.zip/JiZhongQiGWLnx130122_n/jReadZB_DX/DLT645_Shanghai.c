#ifndef DLT645_SHANGHAI_C_
#define DLT645_SHANGHAI_C_
#include <strings.h>
#include <inc/DataGroups.h>
#include <inc/jMemory.h>
#include "inc/pubfunction.h"
#include "jReadZB.h"
#include "ReadMeter.h"

extern void SendStrToCarr(unsigned char *str, unsigned short Len);
extern unsigned char ReceiveFromCarr(unsigned char *str);


//��ʼ�����ݱ�ʶ�Ϻ���97��Ӧ��ϵ
unsigned char InitParaDataFlags_ShangHai_97(DataFlags *flg)   //��ʼ��97���Ϻ���Լ��ʶ����ձ�
{
	FILE *fp;
	char ln[50], tmp[3], TempBuf[60];
	int i=0;
	unsigned int iflg_sh=0, iflg_97=0;
	memset(TempBuf,0,60);
	sprintf((char *)TempBuf,"%s/Flags_ShangHai_97.cfg",_CFGDIR_);
	memset(tmp, 0, 3);
	fp = fopen((char *)TempBuf,"r");
	if(fp==NULL)
		return 0;
	for(;;)
	{
		memset(ln,0,50);
		fscanf(fp,"%s",ln);//��һ����fd��ִ�и�ʽ������
		if(strncmp(ln,"begin",5)==0){continue;}//����������������������ȡ
		if(strncmp(ln,"end",sizeof(ln))==0)break;
		if(strncmp(ln,"//",2)==0){continue;}//����ע��������������
		memset(flg[i].flagSH.Dataflag,0xff,1);//��ʼ��
		memset(flg[i].flag97.Dataflag,0xff,2);//��ʼ��
		sscanf(ln, "%x=%x", &iflg_sh, &iflg_97);
		memcpy(flg[i].flagSH.Dataflag, &iflg_sh, 1);
		memcpy(flg[i].flag97.Dataflag, &iflg_97, 2);
		printf("\n ********* %s ��%x=%x%x",ln, flg[i].flagSH.Dataflag[0], flg[i].flag97.Dataflag[0],flg[i].flag97.Dataflag[1]);
		i++;
	}//end while1
	fclose(fp);
	fp=NULL;
	return i;
}

//FlagSHת��97
int GetDataFlag97BySH(DataFlagSH *flagsSH,DataFlag97 *flags97)
{
	int i;
	for(i=0;i<FlagsCount;i++)
	{
		if(flagsSH->Dataflag[0]==JProgramInfo->Para.meterFlags.dataFlags[1][i].flagSH.Dataflag[0])
		{
			memcpy(flags97->Dataflag,JProgramInfo->Para.meterFlags.dataFlags[1][i].flag97.Dataflag,2);
			if(flags97->Dataflag[0]==0xff && flags97->Dataflag[1]==0xff)
				return 0;
			return 1;
		}
	}
	return 0;
}

//Flag97ת��SH
int GetDataFlagSHBy97(DataFlag97 *flags97,DataFlagSH *flagsSH)
{
	int i;
	for(i=0;i<FlagsCount;i++)
	{
		if(flags97->Dataflag[0]==JProgramInfo->Para.meterFlags.dataFlags[1][i].flag97.Dataflag[0] &&
			flags97->Dataflag[1]==JProgramInfo->Para.meterFlags.dataFlags[1][i].flag97.Dataflag[1])
		{
			memcpy(flagsSH->Dataflag,JProgramInfo->Para.meterFlags.dataFlags[1][i].flagSH.Dataflag,1);
			if(flagsSH->Dataflag[0]==0xff)
				return 0;
			return 1;
		}
	}
	return 0;
}

//���ɱ��ģ����س���
unsigned char GetDlt645_SHChars(unsigned char *Trn645Buff,
		unsigned char *Addr, unsigned char CtlCode)
{
	//����
	unsigned char Check = 0, len, i = 0;
	len = 0;
	Check = 0;
	//Trn645Buff[len++] = 0xfe;
	Trn645Buff[len++] = 0x68;
	for (i = 0; i < 5; i++) {
		Trn645Buff[len++] = Addr[i];
	}
	Trn645Buff[len++]=0xff;
	Trn645Buff[len++] = 0x68;
	Trn645Buff[len++] = CtlCode | 0x80;
	Trn645Buff[len++] = 0x00;
	for (i = 0; i < 10; i++)
		Check += Trn645Buff[i];
	Trn645Buff[len++] = (unsigned char) (Check & 0xff);
	Trn645Buff[len++] = 0x16;
	//-----------����--------------------------
	SdPrint("\n Dlt645_SHGetVlue send DataNum = %d .............\n\r",len);
	for (i = 0; i < len; i++)
		SdPrint("%02x ",Trn645Buff[i]); //����
	SdPrint("\n\r");
	return len;
	//-------------------------------------
}

//��������
unsigned char GetDlt645_SHdests(unsigned char *Rec645Buff, unsigned char len,
		unsigned char CtlCode, unsigned char *Dest)
{
	unsigned char GetLen, Check;
	int i=0,j;
//	for (i = 0; i < len; i++)
//		SdPrint("%x ",Rec645Buff[i]); //��ӡ
	for (i = 0; i < len; i++) {
		if (Rec645Buff[i] == 0x68)
			break;
	}
	//68 31 0 81 5 0 40 0 0 0 20 0 0 0 0 0 64 18 0 a0 0 0 2 1 0 2 14 68 20 0 0 0 0 0 68 91 8 33 33 34 33 97 67 33 33 ba 16 a5 16
	if (CarrierWaveaddr[5] != Rec645Buff[i + 16] || CarrierWaveaddr[4]
			!= Rec645Buff[i + 17] || CarrierWaveaddr[3] != Rec645Buff[i + 18]
			|| CarrierWaveaddr[2] != Rec645Buff[i + 19] || CarrierWaveaddr[1]
			!= Rec645Buff[i + 20] || CarrierWaveaddr[0] != Rec645Buff[i + 21]) {
		return 0;
	}
	if (Rec645Buff[i+27] != 0x68)
		return 0;
	len = Rec645Buff[i+26];
	for (j = i+27; j < len; j++) {
		if (Rec645Buff[j] == 0x68)
			break;
	}
	if (len < (i + 9))
		return 0;
	if ((Rec645Buff[j + 8] & 0x40) == 0x40)//�쳣֡
	{
		SdPrint("\n GetDlt645_SHdests error frame = %x ............\n\r",Rec645Buff[j+8]);
		return 0;
	}
	GetLen = Rec645Buff[j + 9];
	if (GetLen > 230)
		return 0;
	i=j;

	Check = 0x00;
	for (j = 0; j < (GetLen + 10); j++) {
		Check = Check + Rec645Buff[i + j];
		SdPrint("%x ",Rec645Buff[i+j]); //����
	}
	if (Check != Rec645Buff[i + GetLen + 10])
		return 0;
	SdPrint("\n\r GetDlt645_SHdests Result  ....................\n\r");
	for (j = 0; j < GetLen; j++) {
		JProgramInfo->dataTransgw.f9.len++;
		Rec645Buff[i+10+j] = Rec645Buff[i + 10 + j] - 0x33;
		Dest[j] = Rec645Buff[i+10+j];//��������ֵ��bcd�룩
		if (j > 100)
			break;
		SdPrint("%x ",Dest[j]); //����
	}
	return 1;
}

unsigned char Dlt645TranSHbyCarrierWave(unsigned char *Addr,
		unsigned char CtlCode, unsigned char *Dest, int cldno)
{
	INT8U Trn645Buff[1024], TempBuf[1024];
	INT8U Rec645Buff[1024];

	INT8U GetLen;
	INT8U i, Check = 0, len,bflg;
	INT32U bauds,tmps;
	len = 0;
	Check = 0;
	memset(Rec645Buff, 0, 1024);
	//memset(RecBuf, 0, 1024);
	memset(Trn645Buff, 0, 1024);
	memset(TempBuf, 0, 1024);
//68 31 00 41 04 00 80
//00 00 00
//87 96 17 01 00 00
//73 43 98 20 01 12
//13 01 00 02 00 13 fe fe fe 68 73 43 98 20 01 12 68 11 04 33 33 34 33 93 16 7a 16
	///CleardeadCount();
	//��֯���ͱ���
	//��֯���ͱ���
	Trn645Buff[len++] = 0x68; //����ͷ
	Trn645Buff[len++] = 0x2e;//����
	Trn645Buff[len++] = 0x00;

	Trn645Buff[len++] = 0x41;// ������C

	Trn645Buff[len++] = 0x04;// ��Ϣ��
	Trn645Buff[len++] = 0x00;//���������ʶ	�ŵ���ʶ
	Trn645Buff[len++] = 0x28;//Ԥ��Ӧ���ֽ���
	memcpy(&bauds,&JParamInfo3761->group5.f34.Module[4].BPS[0],4);
	tmps=bauds/1000;
	bflg=0;
	if (((tmps*1000) == bauds)&&(bauds!=0))
	{
		bauds=tmps;
		bflg=0x80;
	}
	Trn645Buff[len++] = 0x64;//(bauds&0xff);//���ʵ�λ��ʶ	ͨ������//???????
	Trn645Buff[len++] = 0x00;//(((bauds>>8)&0xff)|bflg);//���ʵ�λ��ʶ	ͨ������
	Trn645Buff[len++] = 0x00;//Ԥ��
	for (i = 0; i < 6; i++)//Դ��ַ(���ڴ��л�ȡ�������ز�ģ��ĵ�ַ)
	{
		Trn645Buff[len++] = CarrierWaveaddr[5 - i];
	}

	for (i = 0; i < 6; i++)//�ز���Ŀ�ĵ�ַ
	{
		Trn645Buff[len++] = Addr[i];
	}
	Trn645Buff[len++] = 0x13;//������ ����ת��
	Trn645Buff[len++] = 0x01;//���ݵ�Ԫ
	Trn645Buff[len++] = 0x00;//���ݵ�Ԫ
	//shanghai
	if(JParamInfo3761->group2.f10[cldno].ConnectType==21)
		Trn645Buff[len++] = 0x00;//��Լ����
	else if(JParamInfo3761->group2.f10[cldno].ConnectType==1)
		Trn645Buff[len++] = 0x01;//��Լ����
	else
		Trn645Buff[len++] = 0x02;//��Լ����
	Trn645Buff[len++] = 0x00;
	//Trn645Buff[len++] = 0x0E;

	//Ҫת��������
	GetLen = GetDlt645_SHChars(TempBuf, Addr, CtlCode);
	Trn645Buff[len++] = GetLen;//���ĳ���

	for (i = 0; i < GetLen; i++)//Ҫת��������
	{
		Trn645Buff[len++] = TempBuf[i];
	}

	//У����
	for (i = 3; i < len; i++)
		Check += Trn645Buff[i];
	Trn645Buff[len++] = (unsigned char) (Check & 0xff);

	Trn645Buff[len++] = 0x16;//������
	Trn645Buff[1]=len;

	SdPrint("\n Dlt645TranSHbyCarrierWave send=%d",len);
	for (i = 0; i < len; i++)
		SdPrint("%02x ",Trn645Buff[i]);
	SdPrint("\n\r");
	SendStrToCarr(Trn645Buff, len);
	i = 0;
	delay(3000);
	while (i < 90) {
		len = ReceiveFromCarr(Rec645Buff);
		if (len > 8) {
			SdPrint("delay i=%d\n\r",i+3);
			break;
		}
		delay(1000);
		i++;
	}
	SdPrint("\n Dlt645TranSHbyCarrierWave recv=%d ",len);
	for (i = 0; i < len; i++)
		SdPrint("%02x ",Rec645Buff[i]);
	SdPrint("\n\r");
	if (GetDlt645_SHdests(Rec645Buff, len, CtlCode, Dest)==0)
		return 0;
	return 1;
}
//�����Ϻ������Ľ��
unsigned char Dlt645SHGet97Vlue(DataFlag97 *flg, unsigned char *Dest)//����
{
	unsigned char DestSH[DataLenMax];
	SetCharVaule(Dest, &DestSH[0], 0, 60, 0);
	memset((char *) Dest, 0x00, 60);//��ʼ��
	if (flg->Dataflag[0] == 0x1F && flg->Dataflag[1] == 0xA0) {
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
		SetCharVaule(&DestSH[0], Dest, 8, 3, 3);
		SetCharVaule(&DestSH[0], Dest, 16, 3, 6);
		SetCharVaule(&DestSH[0], Dest, 24, 3, 9);
		SetCharVaule(&DestSH[0], Dest, 32, 3, 12);
	} else if (flg->Dataflag[0] == 0x10 && flg->Dataflag[1] == 0xA0)
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x11 && flg->Dataflag[1] == 0xA0)
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x12 && flg->Dataflag[1] == 0xA0)
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x13 && flg->Dataflag[1] == 0xA0)
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x14 && flg->Dataflag[1] == 0xA0)
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x1F && flg->Dataflag[1] == 0xA1) {
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
		SetCharVaule(&DestSH[0], Dest, 8, 3, 3);
		SetCharVaule(&DestSH[0], Dest, 16, 3, 6);
		SetCharVaule(&DestSH[0], Dest, 24, 3, 9);
		SetCharVaule(&DestSH[0], Dest, 32, 3, 12);
	} else if (flg->Dataflag[0] == 0x10 && flg->Dataflag[1] == 0xA1)
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x11 && flg->Dataflag[1] == 0xA1)
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x12 && flg->Dataflag[1] == 0xA1)
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x13 && flg->Dataflag[1] == 0xA1)
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x14 && flg->Dataflag[1] == 0xA1)
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x2F && flg->Dataflag[1] == 0xA0) {
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
		SetCharVaule(&DestSH[0], Dest, 8, 3, 3);
		SetCharVaule(&DestSH[0], Dest, 16, 3, 6);
		SetCharVaule(&DestSH[0], Dest, 24, 3, 9);
		SetCharVaule(&DestSH[0], Dest, 32, 3, 12);
	} else if (flg->Dataflag[0] == 0x20 && flg->Dataflag[1] == 0xA0)
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x21 && flg->Dataflag[1] == 0xA0)
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x22 && flg->Dataflag[1] == 0xA0)
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x23 && flg->Dataflag[1] == 0xA0)
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x24 && flg->Dataflag[1] == 0xA0)
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x2F && flg->Dataflag[1] == 0xA1) {
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
		SetCharVaule(&DestSH[0], Dest, 8, 3, 3);
		SetCharVaule(&DestSH[0], Dest, 16, 3, 6);
		SetCharVaule(&DestSH[0], Dest, 24, 3, 9);
		SetCharVaule(&DestSH[0], Dest, 32, 3, 12);
	} else if (flg->Dataflag[0] == 0x20 && flg->Dataflag[1] == 0xA1)
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x21 && flg->Dataflag[1] == 0xA1)
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x22 && flg->Dataflag[1] == 0xA1)
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x23 && flg->Dataflag[1] == 0xA1)
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x24 && flg->Dataflag[1] == 0xA1)
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x1F && flg->Dataflag[1] == 0xA4) {
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
		SetCharVaule(&DestSH[0], Dest, 8, 3, 3);
		SetCharVaule(&DestSH[0], Dest, 16, 3, 6);
		SetCharVaule(&DestSH[0], Dest, 24, 3, 9);
		SetCharVaule(&DestSH[0], Dest, 32, 3, 12);
	} else if (flg->Dataflag[0] == 0x10 && flg->Dataflag[1] == 0xA4)
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x11 && flg->Dataflag[1] == 0xA4)
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x12 && flg->Dataflag[1] == 0xA4)
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x13 && flg->Dataflag[1] == 0xA4)
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x14 && flg->Dataflag[1] == 0xA4)
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x1F && flg->Dataflag[1] == 0xA5) {
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
		SetCharVaule(&DestSH[0], Dest, 8, 3, 3);
		SetCharVaule(&DestSH[0], Dest, 16, 3, 6);
		SetCharVaule(&DestSH[0], Dest, 24, 3, 9);
		SetCharVaule(&DestSH[0], Dest, 32, 3, 12);
	} else if (flg->Dataflag[0] == 0x10 && flg->Dataflag[1] == 0xA5)
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x11 && flg->Dataflag[1] == 0xA5)
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x12 && flg->Dataflag[1] == 0xA5)
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x13 && flg->Dataflag[1] == 0xA5)
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x14 && flg->Dataflag[1] == 0xA5)
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x2F && flg->Dataflag[1] == 0xA4) {
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
		SetCharVaule(&DestSH[0], Dest, 8, 3, 3);
		SetCharVaule(&DestSH[0], Dest, 16, 3, 6);
		SetCharVaule(&DestSH[0], Dest, 24, 3, 9);
		SetCharVaule(&DestSH[0], Dest, 32, 3, 12);
	} else if (flg->Dataflag[0] == 0x20 && flg->Dataflag[1] == 0xA4)
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x21 && flg->Dataflag[1] == 0xA4)
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x22 && flg->Dataflag[1] == 0xA4)
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x23 && flg->Dataflag[1] == 0xA4)
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x24 && flg->Dataflag[1] == 0xA4)
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x2F && flg->Dataflag[1] == 0xA5) {
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
		SetCharVaule(&DestSH[0], Dest, 8, 3, 3);
		SetCharVaule(&DestSH[0], Dest, 16, 3, 6);
		SetCharVaule(&DestSH[0], Dest, 24, 3, 9);
		SetCharVaule(&DestSH[0], Dest, 32, 3, 12);
	} else if (flg->Dataflag[0] == 0x20 && flg->Dataflag[1] == 0xA5)
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x21 && flg->Dataflag[1] == 0xA5)
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x22 && flg->Dataflag[1] == 0xA5)
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x23 && flg->Dataflag[1] == 0xA5)
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x24 && flg->Dataflag[1] == 0xA5)
		SetCharVaule(&DestSH[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x1F && flg->Dataflag[1] == 0xB0) {
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
		SetCharVaule(&DestSH[0], Dest, 11, 4, 4);
		SetCharVaule(&DestSH[0], Dest, 19, 4, 8);
		SetCharVaule(&DestSH[0], Dest, 27, 4, 12);
		SetCharVaule(&DestSH[0], Dest, 35, 4, 16);
	} else if (flg->Dataflag[0] == 0x10 && flg->Dataflag[1] == 0xB0)
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x11 && flg->Dataflag[1] == 0xB0)
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x12 && flg->Dataflag[1] == 0xB0)
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x13 && flg->Dataflag[1] == 0xB0)
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x14 && flg->Dataflag[1] == 0xB0)
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x2F && flg->Dataflag[1] == 0xB0) {
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
		SetCharVaule(&DestSH[0], Dest, 11, 4, 4);
		SetCharVaule(&DestSH[0], Dest, 19, 4, 8);
		SetCharVaule(&DestSH[0], Dest, 27, 4, 12);
		SetCharVaule(&DestSH[0], Dest, 35, 4, 16);
	} else if (flg->Dataflag[0] == 0x20 && flg->Dataflag[1] == 0xB0)
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x21 && flg->Dataflag[1] == 0xB0)
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x22 && flg->Dataflag[1] == 0xB0)
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x23 && flg->Dataflag[1] == 0xB0)
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x24 && flg->Dataflag[1] == 0xB0)
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x1F && flg->Dataflag[1] == 0xB1) {
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
		SetCharVaule(&DestSH[0], Dest, 11, 4, 4);
		SetCharVaule(&DestSH[0], Dest, 19, 4, 8);
		SetCharVaule(&DestSH[0], Dest, 27, 4, 12);
		SetCharVaule(&DestSH[0], Dest, 35, 4, 16);
	} else if (flg->Dataflag[0] == 0x10 && flg->Dataflag[1] == 0xB1)
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x11 && flg->Dataflag[1] == 0xB1)
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x12 && flg->Dataflag[1] == 0xB1)
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x13 && flg->Dataflag[1] == 0xB1)
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x14 && flg->Dataflag[1] == 0xB1)
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x2F && flg->Dataflag[1] == 0xB1) {
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
		SetCharVaule(&DestSH[0], Dest, 11, 4, 4);
		SetCharVaule(&DestSH[0], Dest, 19, 4, 8);
		SetCharVaule(&DestSH[0], Dest, 27, 4, 12);
		SetCharVaule(&DestSH[0], Dest, 35, 4, 16);
	} else if (flg->Dataflag[0] == 0x20 && flg->Dataflag[1] == 0xB1)
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x21 && flg->Dataflag[1] == 0xB1)
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x22 && flg->Dataflag[1] == 0xB1)
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x23 && flg->Dataflag[1] == 0xB1)
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x24 && flg->Dataflag[1] == 0xB1)
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x1F && flg->Dataflag[1] == 0xB4) {
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
		SetCharVaule(&DestSH[0], Dest, 11, 4, 4);
		SetCharVaule(&DestSH[0], Dest, 19, 4, 8);
		SetCharVaule(&DestSH[0], Dest, 27, 4, 12);
		SetCharVaule(&DestSH[0], Dest, 35, 4, 16);
	} else if (flg->Dataflag[0] == 0x10 && flg->Dataflag[1] == 0xB4)
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x11 && flg->Dataflag[1] == 0xB4)
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x12 && flg->Dataflag[1] == 0xB4)
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x13 && flg->Dataflag[1] == 0xB4)
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x14 && flg->Dataflag[1] == 0xB4)
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x2F && flg->Dataflag[1] == 0xB4) {
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
		SetCharVaule(&DestSH[0], Dest, 11, 4, 4);
		SetCharVaule(&DestSH[0], Dest, 19, 4, 8);
		SetCharVaule(&DestSH[0], Dest, 27, 4, 12);
		SetCharVaule(&DestSH[0], Dest, 35, 4, 16);
	} else if (flg->Dataflag[0] == 0x20 && flg->Dataflag[1] == 0xB4)
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x21 && flg->Dataflag[1] == 0xB4)
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x22 && flg->Dataflag[1] == 0xB4)
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x23 && flg->Dataflag[1] == 0xB4)
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x24 && flg->Dataflag[1] == 0xB4)
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x1F && flg->Dataflag[1] == 0xB5) {
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
		SetCharVaule(&DestSH[0], Dest, 11, 4, 4);
		SetCharVaule(&DestSH[0], Dest, 19, 4, 8);
		SetCharVaule(&DestSH[0], Dest, 27, 4, 12);
		SetCharVaule(&DestSH[0], Dest, 35, 4, 16);
	} else if (flg->Dataflag[0] == 0x10 && flg->Dataflag[1] == 0xB5)
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x11 && flg->Dataflag[1] == 0xB5)
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x12 && flg->Dataflag[1] == 0xB5)
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x13 && flg->Dataflag[1] == 0xB5)
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x14 && flg->Dataflag[1] == 0xB5)
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x2F && flg->Dataflag[1] == 0xB5) {
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
		SetCharVaule(&DestSH[0], Dest, 11, 4, 4);
		SetCharVaule(&DestSH[0], Dest, 19, 4, 8);
		SetCharVaule(&DestSH[0], Dest, 27, 4, 12);
		SetCharVaule(&DestSH[0], Dest, 35, 4, 16);
	} else if (flg->Dataflag[0] == 0x20 && flg->Dataflag[1] == 0xB5)
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x21 && flg->Dataflag[1] == 0xB5)
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x22 && flg->Dataflag[1] == 0xB5)
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x23 && flg->Dataflag[1] == 0xB5)
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x24 && flg->Dataflag[1] == 0xB5)
		SetCharVaule(&DestSH[0], Dest, 3, 4, 0);
	else {
		SetCharVaule(&DestSH[0], Dest, 0, 60, 0);
	}
	return 1;
}
//�����
unsigned char Dlt645SHGetValueBy97(unsigned char *Addr, DataFlag97 *flg, unsigned char *Dest, int cldno)//����
{
	DataFlagSH flgSH;
	if (GetDataFlagSHBy97(flg, &flgSH) == 1)
	{
		if (flgSH.Dataflag[0] == 0xff)
			return 0;
		if (Dlt645TranSHbyCarrierWave(Addr, flgSH.Dataflag[0], Dest, cldno) == 1) {
			return Dlt645SHGet97Vlue(flg, Dest);
		}
	}
	return 0;
}
#endif /*DLT645_SH_C_*/
