//Copyright ��Ȩ����  2009�ൺ�߿�ͨ�Źɷ����޹�˾
// �ļ�����ComCarr.c
// �ļ������������Զ���������
// ������ʶ��20090901 Ray
//
// �޸ı�ʶ��
// �޸�������
//
// �޸ı�ʶ��
// �޸�������

#include <inc/pubfunction.h>
#include "DataFlags.h"
#include "jReadZB.h"
#include <stdlib.h>

void SetDataFlag2007(unsigned char DI3,unsigned char DI2,unsigned char DI1,unsigned char DI0,unsigned char *flags);
void SetDataFlag97(unsigned char DI1,unsigned char DI0,unsigned char *flags);
int GetDataFlag97By07(DataFlag2007 *flags20007,DataFlag97 *flags97);
int GetDataFlag07By97(DataFlag97 *flags97,DataFlag2007 *flags20007);

extern void InitFnDltDataFlags();
//Flag07��ֵ
void SetDataFlag2007(unsigned char DI3,unsigned char DI2,unsigned char DI1,unsigned char DI0,unsigned char *flags)
{
	flags[3]=DI3;
	flags[2]=DI2;
	flags[1]=DI1;
	flags[0]=DI0;
}
//Flag97��ֵ
void SetDataFlag97(unsigned char DI1,unsigned char DI0,unsigned char *flags)
{
	flags[1]=DI1;
	flags[0]=DI0;
}
//Flag97ת��07
int GetDataFlag97By07(DataFlag2007 *flags20007,DataFlag97 *flags97)
{
	int i;
	for(i=0;i<FlagsCount;i++)
	{
		//if(strncmp((char *)flags20007->Dataflag,(char *)JProgramInfo->Para.meterFlags.dataFlags[0][i].flagOth.Dataflag,4)==0)
		if(flags20007->Dataflag[0]==JProgramInfo->Para.meterFlags.dataFlags[0][i].flagOth.Dataflag[0] &&
			flags20007->Dataflag[1]==JProgramInfo->Para.meterFlags.dataFlags[0][i].flagOth.Dataflag[1] &&
			flags20007->Dataflag[2]==JProgramInfo->Para.meterFlags.dataFlags[0][i].flagOth.Dataflag[2]&&
			flags20007->Dataflag[3]==JProgramInfo->Para.meterFlags.dataFlags[0][i].flagOth.Dataflag[3])
		{
			memcpy(flags97->Dataflag,JProgramInfo->Para.meterFlags.dataFlags[0][i].flag97.Dataflag,2);
			if(flags97->Dataflag[0]==0xff && flags97->Dataflag[1]==0xff)
				return 0;
			return 1;
		}
	}
	return 0;
}
//Flag07ת��97
int GetDataFlag07By97(DataFlag97 *flags97,DataFlag2007 *flags20007)
{
	int i;
	for(i=0;i<FlagsCount;i++)
	{
		if(flags97->Dataflag[0]==JProgramInfo->Para.meterFlags.dataFlags[0][i].flag97.Dataflag[0])
		{
			if(flags97->Dataflag[1]==JProgramInfo->Para.meterFlags.dataFlags[0][i].flag97.Dataflag[1])
			{
				memcpy(flags20007->Dataflag,JProgramInfo->Para.meterFlags.dataFlags[0][i].flagOth.Dataflag,4);
				if(flags20007->Dataflag[0]==0xff&&flags20007->Dataflag[1]==0xff&&flags20007->Dataflag[2]==0xff&&flags20007->Dataflag[3]==0xff)
					return 0;
				return 1;
			}
		}
	}
	return 0;
}

//��ʼ�����ݱ�ʶ 2007��97��Ӧ��ϵ
unsigned char InitParaDataFlagss(DataFlags *flg)   //��ʼ��97��07��Լ��ʶ����ձ�
{
    FILE    *fp;
   char ln[300];
   char tmp[3];
   int i=0;
	unsigned char TempBuf[60];
	memset(TempBuf,0,60);
	sprintf((char *)TempBuf,"%s/Flags.cfg",_CFGDIR_);
   sprintf(tmp,"sss");
    struct timespec tsspec;
    if (clock_gettime(CLOCK_REALTIME, &tsspec)==-1)
    	printf("clock_gettime error\n\r");
    tsspec.tv_sec += 3;
	sem_timedwait(&JProgramInfo->mainData.UseFileFlg,&tsspec);
   fp = fopen((char *)TempBuf,"r");
   if(fp==NULL){
	sem_post(&JProgramInfo->mainData.UseFileFlg);
     return 0;
    }
   //printf("......................\n\r");
   for(;;)
	{
		memset(ln,0,sizeof(ln));
		fscanf(fp,"%s",ln);//��һ����fd��ִ�и�ʽ������
		if(strncmp(ln,"begin",5)==0){continue;}//����������������������ȡ
		if(strncmp(ln,"end",sizeof(ln))==0)break;
		if(strncmp(ln,"//",2)==0){continue;}//����ע��������������
		if(sizeof(ln)<8){continue;}
		memset(flg[i].flagOth.Dataflag,0xff,4);//��ʼ��
		memset(flg[i].flag97.Dataflag,0xff,2);//��ʼ��
		if(strncmp(ln,"ffffffff",8)!=0)
		{
			tmp[0]=ln[0]; tmp[1]=ln[1];
			flg[i].flagOth.Dataflag[3]=strtol(tmp,NULL,16);

			tmp[0]=ln[2]; tmp[1]=ln[3];
			flg[i].flagOth.Dataflag[2]=strtol(tmp,NULL,16);

			tmp[0]=ln[4]; tmp[1]=ln[5];
			flg[i].flagOth.Dataflag[1]=strtol(tmp,NULL,16);

			tmp[0]=ln[6]; tmp[1]=ln[7];
			flg[i].flagOth.Dataflag[0]=strtol(tmp,NULL,16);
		}
		if(ln[8]=='=')
		{
			if(ln[9]=='f'&&ln[10]=='f'&&ln[11]=='f'&&ln[12]=='f')continue;
			if(sizeof(ln)<13)continue;
			tmp[0]=ln[9]; tmp[1]=ln[10];
			flg[i].flag97.Dataflag[1]=strtol(tmp,NULL,16);

			tmp[0]=ln[11]; tmp[1]=ln[12];
			flg[i].flag97.Dataflag[0]=strtol(tmp,NULL,16);
			//printf("%02x--%02x\n\r",flg[i].flag97.Dataflag[1],flg[i].flag97.Dataflag[0]);
		}
		//printString2(&flg[i].flag2007.Dataflag,4,2);
		//printf("...");
		//printString2(&flg[i].flag97.Dataflag,2,2);
		i++;
	}//end while1
  // printf("InitParaDataFlagss %d\n\r",i);
   fclose(fp);
   fp=NULL;
	sem_post(&JProgramInfo->mainData.UseFileFlg);
   return i;
}
//��ʼ���๦�ܱ������ݱ�ʶ
unsigned char InitManyDayFlags(DataFlag97 *flg97)
{
    FILE    *fp;
   char ln[100];
   char tmp[3];
   int i=0;
	unsigned char TempBuf[60];
	memset(TempBuf,0,60);
	sprintf((char *)TempBuf,"%s/ManyDayFlags.cfg",_CFGDIR_);
   sprintf(tmp,"sss");
    struct timespec tsspec;
    if (clock_gettime(CLOCK_REALTIME, &tsspec)==-1)
    	printf("clock_gettime error\n\r");
    tsspec.tv_sec += 3;
	sem_timedwait(&JProgramInfo->mainData.UseFileFlg,&tsspec);
   fp = fopen((char *)TempBuf,"r");
   if(fp==NULL){
	sem_post(&JProgramInfo->mainData.UseFileFlg);
     return 0;
    }
   //printf("......................\n\r");
   for(;;)
	{
		memset(ln,0,sizeof(ln));
		fscanf(fp,"%s",ln);//��һ����fd��ִ�и�ʽ������
		if(strncmp(ln,"begin",5)==0)continue;//����������������������ȡ
		if(strncmp(ln,"end",sizeof(ln))==0)break;
		if(strncmp(ln,"//",2)==0)continue;//����ע��������������
		if(strlen(ln)<4)continue;
		tmp[0]=ln[0]; tmp[1]=ln[1];
		flg97[i].Dataflag[1]=strtol(tmp,NULL,16);
		tmp[0]=ln[2]; tmp[1]=ln[3];
		flg97[i].Dataflag[0]=strtol(tmp,NULL,16);
		flg97[i].ReadFlg=1;
		if(strlen(ln)>5)
			if (ln[4]==',')
				flg97[i].ReadFlg=ln[5]-'0';
		//printf("%02x--%02x\n\r",flg97[i].Dataflag[1],flg97[i].Dataflag[0]);
		//printString2(&flg97[i],2,2);
		if (i>=ManyFlagsCount)
			break;
		i++;
	}//end while1
  // printf("InitManyDayFlags %d\n\r",i);
   fclose(fp);
   fp=NULL;
	sem_post(&JProgramInfo->mainData.UseFileFlg);
   return i;
}


//��ʼ������������ݱ�ʶ
unsigned char InitCommonDayFlags(DataFlag97 *flg97)
{
    FILE    *fp;
   char ln[100];
   char tmp[3];
   int i=0;
	unsigned char TempBuf[60];
	memset(TempBuf,0,60);
	sprintf((char *)TempBuf,"%s/CommonDayFlags.cfg",_CFGDIR_);
   sprintf(tmp,"sss");
    struct timespec tsspec;
    if (clock_gettime(CLOCK_REALTIME, &tsspec)==-1)
    	printf("clock_gettime error\n\r");
    tsspec.tv_sec += 3;
	sem_timedwait(&JProgramInfo->mainData.UseFileFlg,&tsspec);
   fp = fopen((char *)TempBuf,"r");
   if(fp==NULL)
   {
	sem_post(&JProgramInfo->mainData.UseFileFlg);
     return 0;
    }
  // printf("......................\n\r");
   for(;;)
	{
		memset(ln,0,sizeof(ln));
		fscanf(fp,"%s",ln);//��һ����fd��ִ�и�ʽ������
		if(strncmp(ln,"begin",5)==0)continue;//����������������������ȡ
		if(strncmp(ln,"end",sizeof(ln))==0)break;
		if(strncmp(ln,"//",2)==0)continue;//����ע��������������
		if(strlen(ln)<4)continue;
		tmp[0]=ln[0]; tmp[1]=ln[1];
		flg97[i].Dataflag[1]=strtol(tmp,NULL,16);
		tmp[0]=ln[2]; tmp[1]=ln[3];
		flg97[i].Dataflag[0]=strtol(tmp,NULL,16);
		flg97[i].ReadFlg=1;
		if(strlen(ln)>5)
		{
			if (ln[4]==',')
			{
					flg97[i].ReadFlg=ln[5]-'0';
			}
		}
		//printf("%02x--%02x\n\r",flg97[i].Dataflag[1],flg97[i].Dataflag[0]);
	//	printString2(&flg97[i],2,2);
		i++;
		if (i>=AgFlagsCount)
			break;
	}//end while1
   fclose(fp);
   fp=NULL;
	sem_post(&JProgramInfo->mainData.UseFileFlg);
   return i;
}

//��ʼ�����ݱ�ʶ
void InitMeterFlags()   //��ʼ��97��07��Լ��ʶ����ձ�
{
	InitFnDltDataFlags();
	//��ʼ�����ݱ�ʶ 2007��97��Ӧ��ϵ
	JProgramInfo->Para.meterFlags.dataFlagsCount = InitParaDataFlagss(JProgramInfo->Para.meterFlags.dataFlags[0]);
    delay(100);
    //shanghai
    dataFlagsCount_SH = InitParaDataFlags_ShangHai_97(JProgramInfo->Para.meterFlags.dataFlags[1]);
    delay(100);
	//��ʼ������������ݱ�ʶ
//    JProgramInfo->Para.meterFlags.CommDayFlagsCount = 0;
//    JProgramInfo->Para.meterFlags.ManyDayFlagsCount = 0;
	JProgramInfo->Para.meterFlags.CommDayFlagsCount=InitCommonDayFlags(&JProgramInfo->Para.meterFlags.CommDayFlags[0]);
	delay(100);
	//��ʼ���๦�ܱ������ݱ�ʶ
	JProgramInfo->Para.meterFlags.ManyDayFlagsCount=InitManyDayFlags(&JProgramInfo->Para.meterFlags.ManyDayFlags[0]);
	delay(100);
	return;
}

