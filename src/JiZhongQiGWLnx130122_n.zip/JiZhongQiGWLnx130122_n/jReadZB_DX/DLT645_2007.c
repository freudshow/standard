#ifndef DLT645_2007_C_
#define DLT645_2007_C_
#include <strings.h>
#include <inc/DataGroups.h>
#include <inc/jMemory.h>
#include "inc/pubfunction.h"
#include "jReadZB.h"
#include "ReadMeter.h"

extern void SendStrToCarr(unsigned char *str, unsigned short Len);
extern unsigned char ReceiveFromCarr(unsigned char *str);
extern int getCld(INT8U *adr);
//���ɱ��ģ����س���
unsigned char GetDlt645_2007Chars(unsigned char *Trn645Buff,
		unsigned char *Addr, unsigned char DI0, unsigned char DI1,
		unsigned char DI2, unsigned char DI3) {
	//����
	unsigned char Check = 0, len, i = 0;
	DI0 = 0x33 + DI0;
	DI1 = 0x33 + DI1;
	DI2 = 0x33 + DI2;
	DI3 = 0x33 + DI3;

	len = 0;
	Check = 0;

	///CleardeadCount();
	//��֯���ͱ���
	//Trn645Buff[len++] = 0xFE;
//	Trn645Buff[len++] = 0xFE;
//	Trn645Buff[len++] = 0xFE;
//	Trn645Buff[len++] = 0xFE;
	Trn645Buff[len++] = 0x68;
	for (i = 0; i < 6; i++) {
		Trn645Buff[len++] = Addr[i];
	}
	Trn645Buff[len++] = 0x68;
	Trn645Buff[len++] = 0x11;
	Trn645Buff[len++] = 0x04;
	Trn645Buff[len++] = DI0;
	Trn645Buff[len++] = DI1;
	Trn645Buff[len++] = DI2;
	Trn645Buff[len++] = DI3;
	for (i = 0; i < 14; i++)
		Check += Trn645Buff[i];
	Trn645Buff[len++] = (unsigned char) (Check & 0xff);
	Trn645Buff[len++] = 0x16;
	//-----------����--------------------------
	SdPrint("\n Dlt645_2007GetVlue send DataNum = %d .............\n\r",len);
	for (i = 0; i < len; i++)
		SdPrint("%x ",Trn645Buff[i]); //����
	SdPrint("\n\r");
	return len;
	//-------------------------------------
}

//��������
unsigned char GetDlt645_2007dests(unsigned char *Rec645Buff, unsigned char len,
		unsigned char DI0, unsigned char DI1, unsigned char DI2,
		unsigned char DI3, unsigned char *Dest) {
	unsigned char GetLen, Check;
	int i=0,j;
	for (i = 0; i < len; i++)
		SdPrint("%x ",Rec645Buff[i]); //��ӡ
	for (i = 0; i < len; i++) {
		if (Rec645Buff[i] == 0x68)
			break;
	}
	//68 31 0 81 5 0 40 0 0 0 20 0 0 0 0 0 64 18 0 a0 0 0 2 1 0 2 14 68 20 0 0 0 0 0 68 91 8 33 33 34 33 97 67 33 33 ba 16 a5 16
	if (CarrierWaveaddr[5] != Rec645Buff[i + 16] || CarrierWaveaddr[4]
			!= Rec645Buff[i + 17] || CarrierWaveaddr[3] != Rec645Buff[i + 18]
			|| CarrierWaveaddr[2] != Rec645Buff[i + 19] || CarrierWaveaddr[1]
			!= Rec645Buff[i + 20] || CarrierWaveaddr[0] != Rec645Buff[i + 21]) {
		return 0;
	}
	if (Rec645Buff[i+27] != 0x68)
		return 0;
	len = Rec645Buff[i+26];
	for (j = i+27; j < len; j++) {
		if (Rec645Buff[j] == 0x68)
			break;
	}
	if (len < (i + 9))
		return 0;
	if ((Rec645Buff[j + 8] & 0x40) == 0x40)//�쳣֡
	{
		SdPrint("\n GetDlt645_2007dests error frame = %x ............\n\r",Rec645Buff[j+8]);
		return 0;
	}
	GetLen = Rec645Buff[j + 9];
	if (GetLen > 230)
		return 0;
	if (len <= (GetLen + 10))
		return 0;
	i=j;

	Check = 0x00;
	for (j = 0; j < (GetLen + 10); j++) {
		Check = Check + Rec645Buff[i + j];
		SdPrint("%x ",Rec645Buff[i+j]); //����
	}
	if (Check != Rec645Buff[i + GetLen + 10])
		return 0;

	SdPrint("%x ",Rec645Buff[i+10]); //����
	SdPrint("%x ",Rec645Buff[i+11]); //����
	SdPrint("%x ",Rec645Buff[i+12]); //����
	SdPrint("%x ",Rec645Buff[i+13]); //����
	DI0=0x33 +DI0;
	DI1=0x33 +DI1;
	DI2=0x33 +DI2;
	DI3=0x33 +DI3;
	SdPrint("\n\r%x ",DI0); //����
	SdPrint("%x ",DI1); //����
	SdPrint("%x ",DI2); //����
	SdPrint("%x ",DI3); //����
	if ((Rec645Buff[i + 10] != (DI0)) || (Rec645Buff[i + 11] != (DI1))
			|| (Rec645Buff[i + 12] != (DI2)) || (Rec645Buff[i + 13] != (DI3))) {
		return 0;
	}
	SdPrint("\n\r GetDlt645_2007dests Result  ....................\n\r");
	for (j = 0; j < GetLen - 4; j++) {
		JProgramInfo->dataTransgw.f9.len++;
		Rec645Buff[i + 14 + j] = Rec645Buff[i + 14 + j] - 0x33;
		Dest[j] = Rec645Buff[i + 14 + j];//��������ֵ��bcd�룩
		if (j > 49)
			break;
		SdPrint("%x ",Dest[j]); //����
	}
	return 1;
}

unsigned char Dlt645Tran07byCarrierWave(unsigned char *Addr,    //dingxin
		unsigned char DI0, unsigned char DI1, unsigned char DI2,
		unsigned char DI3, unsigned char *Dest) {
	INT8U Trn645Buff[1024], TempBuf[1024];
	INT8U Rec645Buff[1024];
	int cldno=0;
	INT8U GetLen;
	INT8U i, Check = 0, len,bflg;
	INT32U bauds,tmps;
	len = 0;
	Check = 0;
	memset(Rec645Buff, 0, 1024);
	//memset(RecBuf, 0, 1024);
	memset(Trn645Buff, 0, 1024);
	memset(TempBuf, 0, 1024);
//68 31 00 41 04 00 80
//00 00 00
//87 96 17 01 00 00
//73 43 98 20 01 12
//13 01 00 02 00 13 fe fe fe 68 73 43 98 20 01 12 68 11 04 33 33 34 33 93 16 7a 16
	///CleardeadCount();
	//��֯���ͱ���
	//��֯���ͱ���
	Trn645Buff[len++] = 0x68; //����ͷ
	Trn645Buff[len++] = 0x2e;//����
	Trn645Buff[len++] = 0x00;

	Trn645Buff[len++] = 0x41;// ������C

	Trn645Buff[len++] = 0x04;// ��Ϣ��
	Trn645Buff[len++] = 0x00;//���������ʶ	�ŵ���ʶ
	Trn645Buff[len++] = 0x28;//Ԥ��Ӧ���ֽ���
	memcpy(&bauds,&JParamInfo3761->group5.f34.Module[4].BPS[0],4);
	tmps=bauds/1000;
	bflg=0;
	if (((tmps*1000) == bauds)&&(bauds!=0))
	{
		bauds=tmps;
		bflg=0x80;
	}
	Trn645Buff[len++] = 0x64;//(bauds&0xff);//���ʵ�λ��ʶ	ͨ������//???????
	Trn645Buff[len++] = 0x00;//(((bauds>>8)&0xff)|bflg);//���ʵ�λ��ʶ	ͨ������
	Trn645Buff[len++] = 0x00;//Ԥ��
	for (i = 0; i < 6; i++)//Դ��ַ(���ڴ��л�ȡ�������ز�ģ��ĵ�ַ)
	{
		Trn645Buff[len++] = CarrierWaveaddr[5 - i];
	}

	for (i = 0; i < 6; i++)//�ز���Ŀ�ĵ�ַ
	{
		Trn645Buff[len++] = Addr[i];
	}
	Trn645Buff[len++] = 0x13;//������ ����ת��
	Trn645Buff[len++] = 0x01;//���ݵ�Ԫ
	Trn645Buff[len++] = 0x00;//���ݵ�Ԫ
	cldno=getCld(Addr);
	if(JParamInfo3761->group2.f10[cldno].ConnectType==1)
		Trn645Buff[len++] = 0x01;//��Լ����
	else if(JParamInfo3761->group2.f10[cldno].ConnectType==30)
		Trn645Buff[len++] = 0x02;//��Լ����
	else
		Trn645Buff[len++] = 0x00;
	Trn645Buff[len++] = 0x00;
	//Trn645Buff[len++] = 0x0E;

	//Ҫת��������
	GetLen = GetDlt645_2007Chars(TempBuf, Addr,	DI0, DI1, DI2, DI3);
	Trn645Buff[len++] = GetLen;//���ĳ���

	for (i = 0; i < GetLen; i++)//Ҫת��������
	{
		Trn645Buff[len++] = TempBuf[i];
	}

	//У����
	for (i = 3; i < len; i++)
		Check += Trn645Buff[i];
	Trn645Buff[len++] = (unsigned char) (Check & 0xff);

	Trn645Buff[len++] = 0x16;//������
	Trn645Buff[1]=len;

	SdPrint("send pack%d = ",len);
	for (i = 0; i < len; i++)
		SdPrint("%02x ",Trn645Buff[i]);
	SdPrint("\n\r");
	SendStrToCarr(Trn645Buff, len);
	i = 0;
	delay(3000);
	while (i < 90) {
		len = ReceiveFromCarr(Rec645Buff);
		if (len > 8) {
			SdPrint("delay i=%d\n\r",i+3);
			break;
		}
		delay(1000);
		i++;
	}
	SdPrint("rec pack%d = ",len);
	for (i = 0; i < len; i++)
		SdPrint("%02x ",Rec645Buff[i]);
	SdPrint("\n\r");
	if (GetDlt645_2007dests(Rec645Buff, len, DI0, DI1, DI2, DI3, Dest)==0)
		return 0;
	return 1;
}
void SetCharVaule(unsigned char *Source, unsigned char *Target,
		unsigned char Begin, int Len, unsigned char From)
{
	while (Len >= 1)
	{
		Target[From] = Source[Begin];
		From++;
		Len--;
		Begin++;
	}
}

//����2007�����Ľ��
unsigned char Dlt6452007Get97Vlue(DataFlag97 *flg, unsigned char *Dest)//����
{
	unsigned char Dest07[DataLenMax];
	SetCharVaule(Dest, &Dest07[0], 0, 60, 0);
	memset((char *) Dest, 0x00, 60);//��ʼ��
	if (flg->Dataflag[0] == 0x1F && flg->Dataflag[1] == 0xA0) {
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
		SetCharVaule(&Dest07[0], Dest, 8, 3, 3);
		SetCharVaule(&Dest07[0], Dest, 16, 3, 6);
		SetCharVaule(&Dest07[0], Dest, 24, 3, 9);
		SetCharVaule(&Dest07[0], Dest, 32, 3, 12);
	} else if (flg->Dataflag[0] == 0x10 && flg->Dataflag[1] == 0xA0)
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x11 && flg->Dataflag[1] == 0xA0)
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x12 && flg->Dataflag[1] == 0xA0)
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x13 && flg->Dataflag[1] == 0xA0)
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x14 && flg->Dataflag[1] == 0xA0)
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x1F && flg->Dataflag[1] == 0xA1) {
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
		SetCharVaule(&Dest07[0], Dest, 8, 3, 3);
		SetCharVaule(&Dest07[0], Dest, 16, 3, 6);
		SetCharVaule(&Dest07[0], Dest, 24, 3, 9);
		SetCharVaule(&Dest07[0], Dest, 32, 3, 12);
	} else if (flg->Dataflag[0] == 0x10 && flg->Dataflag[1] == 0xA1)
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x11 && flg->Dataflag[1] == 0xA1)
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x12 && flg->Dataflag[1] == 0xA1)
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x13 && flg->Dataflag[1] == 0xA1)
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x14 && flg->Dataflag[1] == 0xA1)
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x2F && flg->Dataflag[1] == 0xA0) {
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
		SetCharVaule(&Dest07[0], Dest, 8, 3, 3);
		SetCharVaule(&Dest07[0], Dest, 16, 3, 6);
		SetCharVaule(&Dest07[0], Dest, 24, 3, 9);
		SetCharVaule(&Dest07[0], Dest, 32, 3, 12);
	} else if (flg->Dataflag[0] == 0x20 && flg->Dataflag[1] == 0xA0)
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x21 && flg->Dataflag[1] == 0xA0)
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x22 && flg->Dataflag[1] == 0xA0)
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x23 && flg->Dataflag[1] == 0xA0)
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x24 && flg->Dataflag[1] == 0xA0)
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x2F && flg->Dataflag[1] == 0xA1) {
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
		SetCharVaule(&Dest07[0], Dest, 8, 3, 3);
		SetCharVaule(&Dest07[0], Dest, 16, 3, 6);
		SetCharVaule(&Dest07[0], Dest, 24, 3, 9);
		SetCharVaule(&Dest07[0], Dest, 32, 3, 12);
	} else if (flg->Dataflag[0] == 0x20 && flg->Dataflag[1] == 0xA1)
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x21 && flg->Dataflag[1] == 0xA1)
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x22 && flg->Dataflag[1] == 0xA1)
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x23 && flg->Dataflag[1] == 0xA1)
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x24 && flg->Dataflag[1] == 0xA1)
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x1F && flg->Dataflag[1] == 0xA4) {
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
		SetCharVaule(&Dest07[0], Dest, 8, 3, 3);
		SetCharVaule(&Dest07[0], Dest, 16, 3, 6);
		SetCharVaule(&Dest07[0], Dest, 24, 3, 9);
		SetCharVaule(&Dest07[0], Dest, 32, 3, 12);
	} else if (flg->Dataflag[0] == 0x10 && flg->Dataflag[1] == 0xA4)
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x11 && flg->Dataflag[1] == 0xA4)
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x12 && flg->Dataflag[1] == 0xA4)
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x13 && flg->Dataflag[1] == 0xA4)
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x14 && flg->Dataflag[1] == 0xA4)
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x1F && flg->Dataflag[1] == 0xA5) {
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
		SetCharVaule(&Dest07[0], Dest, 8, 3, 3);
		SetCharVaule(&Dest07[0], Dest, 16, 3, 6);
		SetCharVaule(&Dest07[0], Dest, 24, 3, 9);
		SetCharVaule(&Dest07[0], Dest, 32, 3, 12);
	} else if (flg->Dataflag[0] == 0x10 && flg->Dataflag[1] == 0xA5)
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x11 && flg->Dataflag[1] == 0xA5)
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x12 && flg->Dataflag[1] == 0xA5)
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x13 && flg->Dataflag[1] == 0xA5)
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x14 && flg->Dataflag[1] == 0xA5)
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x2F && flg->Dataflag[1] == 0xA4) {
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
		SetCharVaule(&Dest07[0], Dest, 8, 3, 3);
		SetCharVaule(&Dest07[0], Dest, 16, 3, 6);
		SetCharVaule(&Dest07[0], Dest, 24, 3, 9);
		SetCharVaule(&Dest07[0], Dest, 32, 3, 12);
	} else if (flg->Dataflag[0] == 0x20 && flg->Dataflag[1] == 0xA4)
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x21 && flg->Dataflag[1] == 0xA4)
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x22 && flg->Dataflag[1] == 0xA4)
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x23 && flg->Dataflag[1] == 0xA4)
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x24 && flg->Dataflag[1] == 0xA4)
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x2F && flg->Dataflag[1] == 0xA5) {
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
		SetCharVaule(&Dest07[0], Dest, 8, 3, 3);
		SetCharVaule(&Dest07[0], Dest, 16, 3, 6);
		SetCharVaule(&Dest07[0], Dest, 24, 3, 9);
		SetCharVaule(&Dest07[0], Dest, 32, 3, 12);
	} else if (flg->Dataflag[0] == 0x20 && flg->Dataflag[1] == 0xA5)
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x21 && flg->Dataflag[1] == 0xA5)
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x22 && flg->Dataflag[1] == 0xA5)
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x23 && flg->Dataflag[1] == 0xA5)
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x24 && flg->Dataflag[1] == 0xA5)
		SetCharVaule(&Dest07[0], Dest, 0, 3, 0);
	else if (flg->Dataflag[0] == 0x1F && flg->Dataflag[1] == 0xB0) {
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
		SetCharVaule(&Dest07[0], Dest, 11, 4, 4);
		SetCharVaule(&Dest07[0], Dest, 19, 4, 8);
		SetCharVaule(&Dest07[0], Dest, 27, 4, 12);
		SetCharVaule(&Dest07[0], Dest, 35, 4, 16);
	} else if (flg->Dataflag[0] == 0x10 && flg->Dataflag[1] == 0xB0)
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x11 && flg->Dataflag[1] == 0xB0)
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x12 && flg->Dataflag[1] == 0xB0)
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x13 && flg->Dataflag[1] == 0xB0)
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x14 && flg->Dataflag[1] == 0xB0)
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x2F && flg->Dataflag[1] == 0xB0) {
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
		SetCharVaule(&Dest07[0], Dest, 11, 4, 4);
		SetCharVaule(&Dest07[0], Dest, 19, 4, 8);
		SetCharVaule(&Dest07[0], Dest, 27, 4, 12);
		SetCharVaule(&Dest07[0], Dest, 35, 4, 16);
	} else if (flg->Dataflag[0] == 0x20 && flg->Dataflag[1] == 0xB0)
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x21 && flg->Dataflag[1] == 0xB0)
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x22 && flg->Dataflag[1] == 0xB0)
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x23 && flg->Dataflag[1] == 0xB0)
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x24 && flg->Dataflag[1] == 0xB0)
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x1F && flg->Dataflag[1] == 0xB1) {
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
		SetCharVaule(&Dest07[0], Dest, 11, 4, 4);
		SetCharVaule(&Dest07[0], Dest, 19, 4, 8);
		SetCharVaule(&Dest07[0], Dest, 27, 4, 12);
		SetCharVaule(&Dest07[0], Dest, 35, 4, 16);
	} else if (flg->Dataflag[0] == 0x10 && flg->Dataflag[1] == 0xB1)
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x11 && flg->Dataflag[1] == 0xB1)
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x12 && flg->Dataflag[1] == 0xB1)
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x13 && flg->Dataflag[1] == 0xB1)
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x14 && flg->Dataflag[1] == 0xB1)
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x2F && flg->Dataflag[1] == 0xB1) {
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
		SetCharVaule(&Dest07[0], Dest, 11, 4, 4);
		SetCharVaule(&Dest07[0], Dest, 19, 4, 8);
		SetCharVaule(&Dest07[0], Dest, 27, 4, 12);
		SetCharVaule(&Dest07[0], Dest, 35, 4, 16);
	} else if (flg->Dataflag[0] == 0x20 && flg->Dataflag[1] == 0xB1)
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x21 && flg->Dataflag[1] == 0xB1)
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x22 && flg->Dataflag[1] == 0xB1)
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x23 && flg->Dataflag[1] == 0xB1)
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x24 && flg->Dataflag[1] == 0xB1)
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x1F && flg->Dataflag[1] == 0xB4) {
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
		SetCharVaule(&Dest07[0], Dest, 11, 4, 4);
		SetCharVaule(&Dest07[0], Dest, 19, 4, 8);
		SetCharVaule(&Dest07[0], Dest, 27, 4, 12);
		SetCharVaule(&Dest07[0], Dest, 35, 4, 16);
	} else if (flg->Dataflag[0] == 0x10 && flg->Dataflag[1] == 0xB4)
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x11 && flg->Dataflag[1] == 0xB4)
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x12 && flg->Dataflag[1] == 0xB4)
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x13 && flg->Dataflag[1] == 0xB4)
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x14 && flg->Dataflag[1] == 0xB4)
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x2F && flg->Dataflag[1] == 0xB4) {
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
		SetCharVaule(&Dest07[0], Dest, 11, 4, 4);
		SetCharVaule(&Dest07[0], Dest, 19, 4, 8);
		SetCharVaule(&Dest07[0], Dest, 27, 4, 12);
		SetCharVaule(&Dest07[0], Dest, 35, 4, 16);
	} else if (flg->Dataflag[0] == 0x20 && flg->Dataflag[1] == 0xB4)
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x21 && flg->Dataflag[1] == 0xB4)
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x22 && flg->Dataflag[1] == 0xB4)
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x23 && flg->Dataflag[1] == 0xB4)
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x24 && flg->Dataflag[1] == 0xB4)
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x1F && flg->Dataflag[1] == 0xB5) {
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
		SetCharVaule(&Dest07[0], Dest, 11, 4, 4);
		SetCharVaule(&Dest07[0], Dest, 19, 4, 8);
		SetCharVaule(&Dest07[0], Dest, 27, 4, 12);
		SetCharVaule(&Dest07[0], Dest, 35, 4, 16);
	} else if (flg->Dataflag[0] == 0x10 && flg->Dataflag[1] == 0xB5)
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x11 && flg->Dataflag[1] == 0xB5)
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x12 && flg->Dataflag[1] == 0xB5)
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x13 && flg->Dataflag[1] == 0xB5)
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x14 && flg->Dataflag[1] == 0xB5)
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x2F && flg->Dataflag[1] == 0xB5) {
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
		SetCharVaule(&Dest07[0], Dest, 11, 4, 4);
		SetCharVaule(&Dest07[0], Dest, 19, 4, 8);
		SetCharVaule(&Dest07[0], Dest, 27, 4, 12);
		SetCharVaule(&Dest07[0], Dest, 35, 4, 16);
	} else if (flg->Dataflag[0] == 0x20 && flg->Dataflag[1] == 0xB5)
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x21 && flg->Dataflag[1] == 0xB5)
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x22 && flg->Dataflag[1] == 0xB5)
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x23 && flg->Dataflag[1] == 0xB5)
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
	else if (flg->Dataflag[0] == 0x24 && flg->Dataflag[1] == 0xB5)
		SetCharVaule(&Dest07[0], Dest, 3, 4, 0);
	else {
		SetCharVaule(&Dest07[0], Dest, 0, 60, 0);
	}
	return 1;
}
void testDlt6452007Get97Vlue() {
	DataFlag97 flg;
	unsigned char Dest[100];
	int i = 0;
	for (i = 0; i < 80; i++) {
		Dest[i] = i;
	}
	flg.Dataflag[0] = 0x1F;
	flg.Dataflag[1] = 0xA0;
	Dlt6452007Get97Vlue(&flg, &Dest[0]);
}
unsigned char Dlt6452007GetValueBy97(unsigned char *Addr, DataFlag97 *flg,
		unsigned char *Dest)//����
{
	DataFlag2007 flg07;
	if (GetDataFlag07By97(flg, &flg07) == 1) {
		if ((flg07.Dataflag[0] == 0xff) && (flg07.Dataflag[1] == 0xff)
				&& (flg07.Dataflag[2] == 0xff) && (flg07.Dataflag[3] == 0xff))
			return 0;
		if (Dlt645Tran07byCarrierWave(Addr, flg07.Dataflag[0], flg07.Dataflag[1],
				flg07.Dataflag[2], flg07.Dataflag[3], Dest) == 1) {
			return Dlt6452007Get97Vlue(flg, Dest);
		}
	}
	return 0;
}


unsigned char GetDlt645_2007CarrCjq(INT16U P,unsigned char *Trn645Buff,
		unsigned char *Addr, unsigned char DI0, unsigned char DI1,
		unsigned char DI2, unsigned char DI3) {
	//����
	unsigned char Check = 0, len, i = 0;
	INT16U tmp;
	TS ts;
	DI0 = 0x33 + DI0;
	DI1 = 0x33 + DI1;
	DI2 = 0x33 + DI2;
	DI3 = 0x33 + DI3;

	len = 0;
	Check = 0;

	///CleardeadCount();
	//��֯���ͱ���
	Trn645Buff[len++] = 0x68;
	Trn645Buff[len++] = 0x00;
	Trn645Buff[len++] = 0x00;
	Trn645Buff[len++] = 0x00;
	Trn645Buff[len++] = 0x00;
	Trn645Buff[len++] = 0x68;
	Trn645Buff[len++] = 0x4a;
	for (i = 0; i < 4; i++)//�ɼ�����ַ
	{
		Trn645Buff[len++] = Addr[i];//�ɼ�����ַ
	}
	Trn645Buff[len++] = 0x00;//��վ��ַ
	Trn645Buff[len++] = 0x10;

	Trn645Buff[len++] = 0x00;
	Trn645Buff[len++] = 0x00;
	Trn645Buff[len++] = 0x01;
	Trn645Buff[len++] = 0x00;//F1 ���ݵ�Ԫ��ʶ

	Trn645Buff[len++] = JParamInfo3761->group2.f10[P].port;
	Trn645Buff[len] = 0x00;
	switch (JParamInfo3761->group2.f10[P].jiao_yan_wei) {
	case 0:
		Trn645Buff[len] |= 0x00;
		break;
	case 1:
		Trn645Buff[len] |= 0x08;
		break;
	case 2:
		Trn645Buff[len] |= 0x0C;
		break;
	default:
		Trn645Buff[len] |= 0x08;
		break;
	}
	switch (JParamInfo3761->group2.f10[P].ting_zhi_wei) {
	case 2:
		Trn645Buff[len] |= 0x10;
		break;
	default:
		Trn645Buff[len] |= 0x00;
		break;
	}
	switch (JParamInfo3761->group2.f10[P].shu_ju_wei) {
	case 5:
		Trn645Buff[len] |= 0x00;
		break;
	case 6:
		Trn645Buff[len] |= 0x01;
		break;
	case 7:
		Trn645Buff[len] |= 0x02;
		break;
	default:
		Trn645Buff[len] |= 0x03;
		break;
	}
	switch (JParamInfo3761->group2.f10[P].baudrate) {
	case 1:
		Trn645Buff[len] |= 0x00;
		break;
	case 2:
		Trn645Buff[len] |= 0x20;
		break;
	case 4:
		Trn645Buff[len] |= 0x40;
		break;
	case 8:
		Trn645Buff[len] |= 0x60;
		break;
	case 16:
		Trn645Buff[len] |= 0x80;
		break;
	case 24:
		Trn645Buff[len] |= 0xA0;
		break;
	case 32:
		Trn645Buff[len] |= 0xC0;
		break;
	case 64:
		Trn645Buff[len] |= 0xE0;
		break;
	default:
		Trn645Buff[len] |= 0x40;
		break;

	}
	len++;
	Trn645Buff[len++] = 0x81;//1��
	Trn645Buff[len++] = 5;//�ֽڳ�ʱʱ��
	tmp = len;//����
	Trn645Buff[len++] = 0;
	Trn645Buff[len++] = 0;
	Trn645Buff[len++] = 0xFE;
	Trn645Buff[len++] = 0xFE;
	Trn645Buff[len++] = 0xFE;
	Trn645Buff[len++] = 0xFE;
	Trn645Buff[len++] = 0x68;
	for (i = 0; i < 6; i++) {
		Trn645Buff[len++] = JParamInfo3761->group2.f10[P].Address[i];
	}
	Trn645Buff[len++] = 0x68;
	Trn645Buff[len++] = 0x11;
	Trn645Buff[len++] = 0x04;
	Trn645Buff[len++] = DI0;
	Trn645Buff[len++] = DI1;
	Trn645Buff[len++] = DI2;
	Trn645Buff[len++] = DI3;
	//SdPrint("biao=",tmp,len);
	for (i = tmp + 6; i < len; i++) {
		Check += Trn645Buff[i];
		//SdPrint("%02x ",Trn645Buff[i]);
	}
	//SdPrint("\n\r");
	Trn645Buff[len++] = (INT8U) (Check & 0xff);
	Trn645Buff[len++] = 0x16;

	Trn645Buff[tmp] = (len - tmp - 2) & 0xff;//ת�����ĵĳ���
	Trn645Buff[tmp + 1] = ((len - tmp - 2) >> 8) & 0xff;
	for (i = 0; i < 16; i++)
		Trn645Buff[len++] = 0x00;//pwd���� ����
	TSGet(&ts);
	Trn645Buff[len++] = JProgramInfo->PFC;//ʱ���
	INT32U_BCD(ts.Sec, &Trn645Buff[len++], 1);
	INT32U_BCD(ts.Minute, &Trn645Buff[len++], 1);
	INT32U_BCD(ts.Hour, &Trn645Buff[len++], 1);
	INT32U_BCD(ts.Day, &Trn645Buff[len++], 1);
	Trn645Buff[len++] = 0;
	tmp = len - 6;//���㱨�ĳ���
	tmp = (tmp << 2) | 1;
	Trn645Buff[1] = tmp & 0xff;
	Trn645Buff[2] = (tmp >> 8) & 0xff;
	Trn645Buff[3] = tmp & 0xff;
	Trn645Buff[4] = (tmp >> 8) & 0xff;//���㱨�ĳ���
	Check = 0;
	//SdPrint("pack=");
	for (i = 6; i < len; i++)//У��λ
	{
		//SdPrint("%02x ",Trn645Buff[i]);
		Check += Trn645Buff[i];
	}
	//SdPrint("\n\r");
	Trn645Buff[len++] = (INT8U) (Check & 0xff);
	Trn645Buff[len++] = 0x16;//����
	//-----------����--------------------------
	SdPrint("\n GetDlt645_2007CarrCjq send DataNum = %d .............\n\r",len);
	for (i = 0; i < len; i++)
		SdPrint("%x ",Trn645Buff[i]); //����
	return len;
	//-------------------------------------
}

unsigned char GetDlt645_2007Cjqdests(unsigned char *Rec645Buff, unsigned char len,
		unsigned char DI0, unsigned char DI1, unsigned char DI2,
		unsigned char DI3, unsigned char *Dest) {
	unsigned char GetLen, Check, desttmp[256];
	int i=0,j;
	INT8U  RecBuf[1024],TempBuf[1024];
	INT8U flg,res;
	INT16U tmp;
	memset(RecBuf,0,1024);
	memset(TempBuf,0,1024);

	memset(desttmp,0,256);
	for (i = 0; i < len; i++)
		SdPrint("%x ",Rec645Buff[i]); //��ӡ
	for (i = 0; i < len; i++) {
		if (Rec645Buff[i] == 0x68)
			break;
	}
	if (CarrierWaveaddr[5] != Rec645Buff[i + 16] || CarrierWaveaddr[4]
			!= Rec645Buff[i + 17] || CarrierWaveaddr[3] != Rec645Buff[i + 18]
			|| CarrierWaveaddr[2] != Rec645Buff[i + 19] || CarrierWaveaddr[1]
			!= Rec645Buff[i + 20] || CarrierWaveaddr[1] != Rec645Buff[i + 21]) {
		return 0;
	}
	if (Rec645Buff[27] == 0x68)
		return 0;
	len = Rec645Buff[26];
	for (i = 0; i < len; i++) {
		if (Rec645Buff[i] == 0x68)
			break;
	}
	if (len < (i + 9))
		return 0;
	if ((Rec645Buff[i + 8] & 0x40) == 0x40)//�쳣֡
	{
		SdPrint("\n GetDlt645_2007dests error frame = %x ............\n\r",Rec645Buff[i+8]);
		return 0;
	}

	GetLen = Rec645Buff[i + 9];
	if (GetLen > 230)
		return 0;
	if (len <= (i + GetLen + 10))
		return 0;

	Check = 0x00;
	for (j = 0; j < (GetLen + 10); j++) {
		Check = Check + Rec645Buff[i + j];
		SdPrint("%x ",Rec645Buff[i+j]); //����
	}
	if (Check != Rec645Buff[i + GetLen + 10])
		return 0;

	SdPrint("%x ",Rec645Buff[i+10]); //����
	SdPrint("%x ",Rec645Buff[i+11]); //����
	if ((Rec645Buff[i + 10] != (DI0)) || (Rec645Buff[i + 11] != (DI1))
			|| (Rec645Buff[i + 12] != (DI2)) || (Rec645Buff[i + 13] != (DI3))) {
		return 0;
	}
	SdPrint("\n GetDlt645_2007dests Result  ....................\n\r");
	for (j = 0; j < GetLen - 4; j++) {
		Rec645Buff[i + 14 + j] = Rec645Buff[i + 14 + j] - 0x33;
		desttmp[j] = Rec645Buff[i + 14 + j];//��������ֵ��bcd�룩
		if (j > 49)
			break;
		SdPrint("%x ",desttmp[j]); //����
	}


	tmp = 0;
	flg = 0;
	res = 0;
	for (i = 0; i < len; i++) {
		if ((desttmp[i] == 0x68) && (desttmp[i + 5] == 0x68)) {
			if (len > 14) {
				tmp = desttmp[i + 2];//���㱨�ĳ���
				tmp = (tmp << 8) + desttmp[i + 1];
				tmp = tmp >> 2;
				if (len >= (tmp + 8)) {
					for (j = 0; j < tmp + 8; j++) {
						TempBuf[j] = desttmp[i];
						i = i + 1;
					}
					Check = 0;
					for (j = 0; j < tmp; j++)
						Check += TempBuf[j + 6];
					SdPrint("Check = %x-%x\n\r",Check,TempBuf[tmp+6]);
					SdPrint("rec biao = ");
					if (Check == TempBuf[tmp + 6]) {
						res = 1;
						tmp = TempBuf[18] + (TempBuf[19] << 8);
						for (j = 0; j < tmp; j++)//��ȡ����
						{
							RecBuf[flg++] = TempBuf[j + 20];
							SdPrint("%02x ",TempBuf[j+20]);
						}
					}
					SdPrint("\n\r");
				}
			}
		}
	}
	if (res == 0) {
		return 0;
	}

	if (flg > 0) {
		for (i = 0; i < tmp; i++) {
			if (RecBuf[i] == 0x68)
				break;
		}
		if (tmp < (i + 9))
			return 0;
		if ((RecBuf[i + 8] & 0x40) == 0x40)//�쳣֡
		{
			SdPrint("\n Dlt645Tran07 error frame = %x ............\n\r",RecBuf[i+8]);
			return 0;
		}
		/*if(RecBuf[i+8]!=0x91)
		 {
		 SdPrint("\n\r�����ݻ�Ӧ");
		 return 0;
		 }*/
		GetLen = RecBuf[i + 9];
		if (GetLen > 230)
			return 0;
		if (tmp <= (i + GetLen + 10))
			return 0;
		SdPrint("\n Dlt645Tran07 Result  33333333333333333333333333333\n\r");
		Check = 0x00;
		for (j = 0; j < (GetLen + 10); j++) {
			Check = Check + RecBuf[i + j];
			SdPrint("%x ",RecBuf[i+j]); //����
		}
		if (Check != RecBuf[i + GetLen + 10])
			return 0;
		SdPrint("\n Dlt645Tran07 Result  99999999999999999999999999999\n\r");
		SdPrint("%x ",RecBuf[i+10]); //����
		SdPrint("%x ",RecBuf[i+11]); //����
		if ((RecBuf[i + 10] != (DI0)) || (RecBuf[i + 11] != (DI1)) || (RecBuf[i
				+ 12] != (DI2)) || (RecBuf[i + 13] != (DI3))) {
			return 0;
		}
		SdPrint("\n Dlt645Tran07 Result  ....................\n\r");

		for (j = 0; j < GetLen - 4; j++) {
			RecBuf[i + 14 + j] = RecBuf[i + 14 + j] - 0x33;
			Dest[j] = RecBuf[i + 14 + j];//��������ֵ��bcd�룩
			if (j > 49)
				break;
			SdPrint("%x ",Dest[j]); //����
		}
		SdPrint("\n\r");
	} else {
		return 0;
	}
	return 1;
}

unsigned char Dlt645Tran07byCarrCJQ(INT16U P,unsigned char *Addr,
		unsigned char DI0, unsigned char DI1, unsigned char DI2,
		unsigned char DI3, unsigned char *Dest)
{
	INT8U Trn645Buff[1024], TempBuf[1024];
	INT8U Rec645Buff[1024];

	INT8U GetLen;
	INT8U i, Check = 0, len;
	len = 0;
	Check = 0;
	memset(Rec645Buff, 0, 1024);
	//memset(RecBuf, 0, 1024);
	memset(Trn645Buff, 0, 1024);
	memset(TempBuf, 0, 1024);

	///CleardeadCount();
	//��֯���ͱ���
	//��֯���ͱ���
	Trn645Buff[len++] = 0x68; //����ͷ
	Trn645Buff[len++] = 0x2d;//����
	Trn645Buff[len++] = 0x00;

	Trn645Buff[len++] = 0x41;// ������C

	Trn645Buff[len++] = 0x05;// ��Ϣ��
	Trn645Buff[len++] = 0x00;//���������ʶ	�ŵ���ʶ
	Trn645Buff[len++] = 0x50;//Ԥ��Ӧ���ֽ���
	Trn645Buff[len++] = 0x00;//���ʵ�λ��ʶ	ͨ������
	Trn645Buff[len++] = 0x00;//���ʵ�λ��ʶ	ͨ������
	Trn645Buff[len++] = 0x00;//Ԥ��
	for (i = 0; i < 6; i++)//Դ��ַ(���ڴ��л�ȡ�������ز�ģ��ĵ�ַ)
	{
		Trn645Buff[len++] = CarrierWaveaddr[5 - i];
	}

	for (i = 0; i < 6; i++)//�ز���Ŀ�ĵ�ַ
	{
		Trn645Buff[len++] = Addr[i];
	}

	Trn645Buff[len++] = 0x02;//������ ����ת��
	Trn645Buff[len++] = 0x01;//���ݵ�Ԫ
	Trn645Buff[len++] = 0x00;//���ݵ�Ԫ
	Trn645Buff[len++] = 0x02;//��Լ����

	//Ҫת��������
	GetLen = GetDlt645_2007CarrCjq(P,TempBuf, Addr,
			DI0, DI1, DI2, DI3);
	Trn645Buff[len++] = GetLen;//���ĳ���

	for (i = 0; i < GetLen; i++)//Ҫת��������
	{
		Trn645Buff[len++] = TempBuf[i++];
	}

	//У����
	for (i = 0; i < len; i++)
		Check += Trn645Buff[i];
	Trn645Buff[len++] = (unsigned char) (Check & 0xff);

	Trn645Buff[len++] = 0x16;//������


	SendStrToCarr(Trn645Buff, len);
	i = 0;
	delay(3000);
	while (i < 10) {
		len = ReceiveFromCarr(Rec645Buff);
		if (len > 8) {
			SdPrint("delay i=%d\n\r",i+3);
			break;
		}
		delay(1000);
		i++;
	}
	GetDlt645_2007Cjqdests(Rec645Buff, len, DI0, DI1, DI2, DI3, Dest);
	SdPrint("rec pack%d = ",len);
	for (i = 0; i < len; i++)
		SdPrint("%x ",Rec645Buff[i]);
	SdPrint("\n\r");
	return 1;
}
unsigned char DltTran07GetValueBy97(INT16U P, unsigned char *Addr,
		DataFlag97 *flg, unsigned char *Dest)//ͨ���ɼ�������
{
	DataFlag2007 flg07;
	if (GetDataFlag07By97(flg, &flg07) == 1) {
		if ((flg07.Dataflag[0] == 0xff) && (flg07.Dataflag[1] == 0xff)
				&& (flg07.Dataflag[2] == 0xff) && (flg07.Dataflag[3] == 0xff))
			return 0;
		if (Dlt645Tran07byCarrCJQ(P, Addr, flg07.Dataflag[0], flg07.Dataflag[1],
				flg07.Dataflag[2], flg07.Dataflag[3], Dest) == 1) {
			return Dlt6452007Get97Vlue(flg, Dest);
		}
	}
	return 0;
}

#endif /*DLT645_2007_C_*/
