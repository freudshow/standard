#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <inc/CVariable.h>
#include <inc/pubfunction.h>
#include "jReadZB.h"
#include "ReadMeter.h"
#include <signal.h>
extern DataFlag97 Le1flgComm[250][20];
extern DataFlag97 Le1flgMany[250][20];
void initLe1flgComm()
{
	memset(Le1flgComm,0,sizeof(Le1flgComm));
	Le1flgComm[0][0].Dataflag[0]=0x1f;//2-F1
	Le1flgComm[0][0].Dataflag[1]=0x90;
	Le1flgComm[0][0].ReadFlg=2;
	Le1flgComm[0][1].Dataflag[0]=0x1f;
	Le1flgComm[0][1].Dataflag[1]=0x91;
	Le1flgComm[0][1].ReadFlg=2;
	Le1flgComm[0][2].Dataflag[0]=0x3f;
	Le1flgComm[0][2].Dataflag[1]=0x91;
	Le1flgComm[0][2].ReadFlg=2;
	Le1flgComm[0][3].Dataflag[0]=0x4f;
	Le1flgComm[0][3].Dataflag[1]=0x91;
	Le1flgComm[0][3].ReadFlg=2;
	Le1flgComm[1][0].Dataflag[0]=0x2f;//2-F2
	Le1flgComm[1][0].Dataflag[1]=0x90;
	Le1flgComm[1][0].ReadFlg=2;
	Le1flgComm[1][1].Dataflag[0]=0x2f;
	Le1flgComm[1][1].Dataflag[1]=0x91;
	Le1flgComm[1][1].ReadFlg=2;
	Le1flgComm[1][2].Dataflag[0]=0x5f;
	Le1flgComm[1][2].Dataflag[1]=0x91;
	Le1flgComm[1][2].ReadFlg=2;
	Le1flgComm[1][3].Dataflag[0]=0x6f;
	Le1flgComm[1][3].Dataflag[1]=0x91;
	Le1flgComm[1][3].ReadFlg=2;
	Le1flgComm[4][0].Dataflag[0]=0x1f;//2-F5
	Le1flgComm[4][0].Dataflag[1]=0x90;
	Le1flgComm[4][0].ReadFlg=2;
	Le1flgComm[5][0].Dataflag[0]=0x1f;//2-F6
	Le1flgComm[5][0].Dataflag[1]=0x91;
	Le1flgComm[5][0].ReadFlg=2;
	Le1flgComm[6][0].Dataflag[0]=0x2f;//2-F7
	Le1flgComm[6][0].Dataflag[1]=0x90;
	Le1flgComm[6][0].ReadFlg=2;
	Le1flgComm[7][0].Dataflag[0]=0x2f;//2-F8
	Le1flgComm[7][0].Dataflag[1]=0x91;
	Le1flgComm[7][0].ReadFlg=2;
	Le1flgComm[16][0].Dataflag[0]=0x30;//F17
	Le1flgComm[16][0].Dataflag[1]=0xb6;
	Le1flgComm[16][0].ReadFlg=1;
	Le1flgComm[16][1].Dataflag[0]=0x1f;//2-F17
	Le1flgComm[16][1].Dataflag[1]=0x90;
	Le1flgComm[16][1].ReadFlg=2;
	Le1flgComm[16][2].Dataflag[0]=0x1f;
	Le1flgComm[16][2].Dataflag[1]=0x91;
	Le1flgComm[16][2].ReadFlg=2;
	Le1flgComm[16][3].Dataflag[0]=0x3f;
	Le1flgComm[16][3].Dataflag[1]=0x91;
	Le1flgComm[16][3].ReadFlg=2;
	Le1flgComm[16][4].Dataflag[0]=0x4f;
	Le1flgComm[16][4].Dataflag[1]=0x91;
	Le1flgComm[16][4].ReadFlg=2;
	Le1flgComm[17][0].Dataflag[0]=0x40;//F18
	Le1flgComm[17][0].Dataflag[1]=0xb6;
	Le1flgComm[17][0].ReadFlg=1;
	Le1flgComm[17][1].Dataflag[0]=0x2f;//2-F18
	Le1flgComm[17][1].Dataflag[1]=0x90;
	Le1flgComm[17][1].ReadFlg=2;
	Le1flgComm[17][2].Dataflag[0]=0x2f;
	Le1flgComm[17][2].Dataflag[1]=0x91;
	Le1flgComm[17][2].ReadFlg=2;
	Le1flgComm[17][3].Dataflag[0]=0x5f;
	Le1flgComm[17][3].Dataflag[1]=0x91;
	Le1flgComm[17][3].ReadFlg=2;
	Le1flgComm[17][4].Dataflag[0]=0x6f;
	Le1flgComm[17][4].Dataflag[1]=0x91;
	Le1flgComm[17][4].ReadFlg=2;
	Le1flgComm[20][1].Dataflag[0]=0x1f;//2-F21
	Le1flgComm[20][1].Dataflag[1]=0x90;
	Le1flgComm[20][1].ReadFlg=2;
	Le1flgComm[21][1].Dataflag[0]=0x1f;//2-F22
	Le1flgComm[21][1].Dataflag[1]=0x91;
	Le1flgComm[21][1].ReadFlg=2;
	Le1flgComm[22][1].Dataflag[0]=0x2f;//2-F23
	Le1flgComm[22][1].Dataflag[1]=0x90;
	Le1flgComm[22][1].ReadFlg=2;
	Le1flgComm[23][1].Dataflag[0]=0x2f;//2-F24
	Le1flgComm[24][1].Dataflag[1]=0x91;
	Le1flgComm[24][1].ReadFlg=2;
	Le1flgComm[24][0].Dataflag[0]=0x11;//F25
	Le1flgComm[24][0].Dataflag[1]=0xb6;
	Le1flgComm[24][0].ReadFlg=1;
	Le1flgComm[24][1].Dataflag[0]=0x21;
	Le1flgComm[24][1].Dataflag[1]=0xb6;
	Le1flgComm[24][1].ReadFlg=1;
	Le1flgComm[24][2].Dataflag[0]=0x30;
	Le1flgComm[24][2].Dataflag[1]=0xb6;
	Le1flgComm[24][2].ReadFlg=1;
	Le1flgComm[24][3].Dataflag[0]=0x40;
	Le1flgComm[24][3].Dataflag[1]=0xb6;
	Le1flgComm[24][3].ReadFlg=1;
	Le1flgComm[24][4].Dataflag[0]=0x50;
	Le1flgComm[24][4].Dataflag[1]=0xb6;
	Le1flgComm[24][4].ReadFlg=1;
	Le1flgComm[32][0].Dataflag[0]=0x1f;//F33
	Le1flgComm[32][0].Dataflag[1]=0x90;
	Le1flgComm[32][0].ReadFlg=1;
	Le1flgComm[32][1].Dataflag[0]=0x1f;
	Le1flgComm[32][1].Dataflag[1]=0x91;
	Le1flgComm[32][1].ReadFlg=1;
	Le1flgComm[33][0].Dataflag[0]=0x2f;//F34
	Le1flgComm[33][0].Dataflag[1]=0x90;
	Le1flgComm[33][0].ReadFlg=1;
	Le1flgComm[33][1].Dataflag[0]=0x2f;
	Le1flgComm[33][1].Dataflag[1]=0x91;
	Le1flgComm[33][1].ReadFlg=1;
	Le1flgComm[72][0].Dataflag[0]=0x30;//2-F73
	Le1flgComm[72][0].Dataflag[1]=0xb6;
	Le1flgComm[72][0].ReadFlg=2;
	Le1flgComm[73][0].Dataflag[0]=0x40;//2-F74
	Le1flgComm[73][0].Dataflag[1]=0xb6;
	Le1flgComm[73][0].ReadFlg=2;
	Le1flgComm[74][0].Dataflag[0]=0x1f;//2-F75
	Le1flgComm[74][0].Dataflag[1]=0x90;
	Le1flgComm[74][0].ReadFlg=2;
	Le1flgComm[74][1].Dataflag[0]=0x1f;
	Le1flgComm[74][1].Dataflag[1]=0x91;
	Le1flgComm[74][1].ReadFlg=2;
	Le1flgComm[75][0].Dataflag[0]=0x2f;//2-F76
	Le1flgComm[75][0].Dataflag[1]=0x90;
	Le1flgComm[75][0].ReadFlg=2;
	Le1flgComm[75][1].Dataflag[0]=0x2f;
	Le1flgComm[75][1].Dataflag[1]=0x91;
	Le1flgComm[75][1].ReadFlg=2;
	Le1flgComm[80][0].Dataflag[0]=0x30;//2-F81
	Le1flgComm[80][0].Dataflag[1]=0xb6;
	Le1flgComm[80][0].ReadFlg=2;
	Le1flgComm[81][0].Dataflag[0]=0x31;//2-F82
	Le1flgComm[81][0].Dataflag[1]=0xb6;
	Le1flgComm[81][0].ReadFlg=2;
	Le1flgComm[82][0].Dataflag[0]=0x31;//2-F83
	Le1flgComm[82][0].Dataflag[1]=0xb6;
	Le1flgComm[82][0].ReadFlg=2;
	Le1flgComm[83][0].Dataflag[0]=0x31;//2-F84
	Le1flgComm[83][0].Dataflag[1]=0xb6;
	Le1flgComm[83][0].ReadFlg=2;
	Le1flgComm[84][0].Dataflag[0]=0x40;//2-F85
	Le1flgComm[84][0].Dataflag[1]=0xb6;
	Le1flgComm[84][0].ReadFlg=2;
	Le1flgComm[85][0].Dataflag[0]=0x41;//2-F86
	Le1flgComm[85][0].Dataflag[1]=0xb6;
	Le1flgComm[85][0].ReadFlg=2;
	Le1flgComm[86][0].Dataflag[0]=0x41;//2-F87
	Le1flgComm[86][0].Dataflag[1]=0xb6;
	Le1flgComm[86][0].ReadFlg=2;
	Le1flgComm[87][0].Dataflag[0]=0x41;//2-F88
	Le1flgComm[87][0].Dataflag[1]=0xb6;
	Le1flgComm[87][0].ReadFlg=2;
	Le1flgComm[88][0].Dataflag[0]=0x11;//2-F89
	Le1flgComm[88][0].Dataflag[1]=0xb6;
	Le1flgComm[88][0].ReadFlg=2;
	Le1flgComm[89][0].Dataflag[0]=0x12;//2-F90
	Le1flgComm[89][0].Dataflag[1]=0xb6;
	Le1flgComm[89][0].ReadFlg=2;
	Le1flgComm[90][0].Dataflag[0]=0x13;//2-F91
	Le1flgComm[90][0].Dataflag[1]=0xb6;
	Le1flgComm[90][0].ReadFlg=2;
	Le1flgComm[91][0].Dataflag[0]=0x21;//2-F92
	Le1flgComm[91][0].Dataflag[1]=0xb6;
	Le1flgComm[91][0].ReadFlg=2;
	Le1flgComm[92][0].Dataflag[0]=0x22;//2-F93
	Le1flgComm[92][0].Dataflag[1]=0xb6;
	Le1flgComm[92][0].ReadFlg=2;
	Le1flgComm[93][0].Dataflag[0]=0x23;//2-F94
	Le1flgComm[93][0].Dataflag[1]=0xb6;
	Le1flgComm[93][0].ReadFlg=2;
	Le1flgComm[96][0].Dataflag[0]=0x1f;//2-F97
	Le1flgComm[96][0].Dataflag[1]=0x90;
	Le1flgComm[96][0].ReadFlg=2;
	Le1flgComm[97][0].Dataflag[0]=0x1f;//2-F98
	Le1flgComm[97][0].Dataflag[1]=0x91;
	Le1flgComm[97][0].ReadFlg=2;
	Le1flgComm[98][0].Dataflag[0]=0x2f;//2-F99
	Le1flgComm[98][0].Dataflag[1]=0x90;
	Le1flgComm[98][0].ReadFlg=2;
	Le1flgComm[99][0].Dataflag[0]=0x2f;//2-F100
	Le1flgComm[99][0].Dataflag[1]=0x91;
	Le1flgComm[99][0].ReadFlg=2;
	Le1flgComm[100][0].Dataflag[0]=0x1f;//2-F101

	Le1flgComm[100][0].Dataflag[1]=0x90;
	Le1flgComm[100][0].ReadFlg=2;
	Le1flgComm[101][0].Dataflag[0]=0x1f;//2-F102
	Le1flgComm[101][0].Dataflag[1]=0x91;
	Le1flgComm[101][0].ReadFlg=2;
	Le1flgComm[102][0].Dataflag[0]=0x2f;//2-F103
	Le1flgComm[102][0].Dataflag[1]=0x90;
	Le1flgComm[102][0].ReadFlg=2;
	Le1flgComm[103][0].Dataflag[0]=0x2f;//2-F104
	Le1flgComm[103][0].Dataflag[1]=0x91;
	Le1flgComm[103][0].ReadFlg=2;
	Le1flgComm[104][0].Dataflag[0]=0x50;//2-F105
	Le1flgComm[104][0].Dataflag[1]=0xb6;
	Le1flgComm[104][0].ReadFlg=2;
	Le1flgComm[105][0].Dataflag[0]=0x50;//2-F106
	Le1flgComm[105][0].Dataflag[1]=0xb6;
	Le1flgComm[105][0].ReadFlg=2;
	Le1flgComm[106][0].Dataflag[0]=0x50;//2-F107
	Le1flgComm[106][0].Dataflag[1]=0xb6;
	Le1flgComm[106][0].ReadFlg=2;
	Le1flgComm[107][0].Dataflag[0]=0x50;//2-F108
	Le1flgComm[107][0].Dataflag[1]=0xb6;
	Le1flgComm[107][0].ReadFlg=2;
	Le1flgComm[128][0].Dataflag[0]=0x1f;//F129
	Le1flgComm[128][0].Dataflag[1]=0x90;
	Le1flgComm[128][0].ReadFlg=1;
	Le1flgComm[129][0].Dataflag[0]=0x1f;//F130
	Le1flgComm[129][0].Dataflag[1]=0x91;
	Le1flgComm[129][0].ReadFlg=1;
	Le1flgComm[130][0].Dataflag[0]=0x2f;//F131
	Le1flgComm[130][0].Dataflag[1]=0x90;
	Le1flgComm[130][0].ReadFlg=1;
	Le1flgComm[131][0].Dataflag[0]=0x2f;//F132
	Le1flgComm[131][0].Dataflag[1]=0x91;
	Le1flgComm[131][0].ReadFlg=1;
	Le1flgComm[160][0].Dataflag[0]=0x1f;//2-F161
	Le1flgComm[160][0].Dataflag[1]=0x90;
	Le1flgComm[160][0].ReadFlg=2;
	Le1flgComm[161][0].Dataflag[0]=0x1f;//2-F162
	Le1flgComm[161][0].Dataflag[1]=0x91;
	Le1flgComm[161][0].ReadFlg=2;
	Le1flgComm[162][0].Dataflag[0]=0x2f;//2-F163
	Le1flgComm[162][0].Dataflag[1]=0x90;
	Le1flgComm[162][0].ReadFlg=2;
	Le1flgComm[163][0].Dataflag[0]=0x2f;//2-F164
	Le1flgComm[163][0].Dataflag[1]=0x91;
	Le1flgComm[163][0].ReadFlg=2;
	Le1flgComm[164][0].Dataflag[0]=0x3f;//2-F165
	Le1flgComm[164][0].Dataflag[1]=0x91;
	Le1flgComm[164][0].ReadFlg=2;
	Le1flgComm[165][0].Dataflag[0]=0x5f;//2-F166
	Le1flgComm[165][0].Dataflag[1]=0x91;
	Le1flgComm[165][0].ReadFlg=2;
	Le1flgComm[166][0].Dataflag[0]=0x94;//F167
	Le1flgComm[166][0].Dataflag[1]=0x00;
	Le1flgComm[136][0].ReadFlg=1;
	Le1flgComm[166][1].Dataflag[0]=0x6f;//2-F167
	Le1flgComm[166][1].Dataflag[1]=0x91;
	Le1flgComm[166][1].ReadFlg=2;
	Le1flgComm[167][0].Dataflag[0]=0x4f;//2-F168
	Le1flgComm[167][0].Dataflag[1]=0x91;
	Le1flgComm[167][0].ReadFlg=2;
	Le1flgComm[168][0].Dataflag[0]=0x1f;//2-F169
	Le1flgComm[168][0].Dataflag[1]=0x90;
	Le1flgComm[168][0].ReadFlg=2;
	Le1flgComm[169][0].Dataflag[0]=0x1f;//2-F170
	Le1flgComm[169][0].Dataflag[1]=0x91;
	Le1flgComm[169][0].ReadFlg=2;
	Le1flgComm[176][0].Dataflag[0]=0x1f;//2-F177
	Le1flgComm[176][0].Dataflag[1]=0x90;
	Le1flgComm[176][0].ReadFlg=2;
	Le1flgComm[177][0].Dataflag[0]=0x1f;//2-F178
	Le1flgComm[177][0].Dataflag[1]=0x91;
	Le1flgComm[177][0].ReadFlg=2;
	Le1flgComm[178][0].Dataflag[0]=0x2f;//2-F179
	Le1flgComm[178][0].Dataflag[1]=0x90;
	Le1flgComm[178][0].ReadFlg=2;
	Le1flgComm[179][0].Dataflag[0]=0x2f;//2-F180
	Le1flgComm[179][0].Dataflag[1]=0x91;
	Le1flgComm[179][0].ReadFlg=2;
	Le1flgComm[180][0].Dataflag[0]=0x3f;//2-F181
	Le1flgComm[180][0].Dataflag[1]=0x91;
	Le1flgComm[180][0].ReadFlg=2;
	Le1flgComm[181][0].Dataflag[0]=0x5f;//2-F182
	Le1flgComm[181][0].Dataflag[1]=0x91;
	Le1flgComm[181][0].ReadFlg=2;
	Le1flgComm[182][0].Dataflag[0]=0x6f;//2-F183
	Le1flgComm[182][0].Dataflag[1]=0x91;
	Le1flgComm[182][0].ReadFlg=2;
	Le1flgComm[183][0].Dataflag[0]=0x4f;//2-F184
	Le1flgComm[183][0].Dataflag[1]=0x91;
	Le1flgComm[183][0].ReadFlg=2;

	memset(Le1flgMany,0,sizeof(Le1flgMany));
	Le1flgMany[0][0].Dataflag[0]=0x1f;//2-F1
	Le1flgMany[0][0].Dataflag[1]=0x90;
	Le1flgMany[0][0].ReadFlg=2;
	Le1flgMany[0][1].Dataflag[0]=0x1f;
	Le1flgMany[0][1].Dataflag[1]=0x91;
	Le1flgMany[0][1].ReadFlg=2;
	Le1flgMany[0][2].Dataflag[0]=0x3f;
	Le1flgMany[0][2].Dataflag[1]=0x91;
	Le1flgMany[0][2].ReadFlg=2;
	Le1flgMany[0][3].Dataflag[0]=0x4f;
	Le1flgMany[0][3].Dataflag[1]=0x91;
	Le1flgMany[0][3].ReadFlg=2;
	Le1flgMany[1][0].Dataflag[0]=0x2f;//2-F2
	Le1flgMany[1][0].Dataflag[1]=0x90;
	Le1flgMany[1][0].ReadFlg=2;
	Le1flgMany[1][1].Dataflag[0]=0x2f;
	Le1flgMany[1][1].Dataflag[1]=0x91;
	Le1flgMany[1][1].ReadFlg=2;
	Le1flgMany[1][2].Dataflag[0]=0x5f;
	Le1flgMany[1][2].Dataflag[1]=0x91;
	Le1flgMany[1][2].ReadFlg=2;
	Le1flgMany[1][3].Dataflag[0]=0x6f;
	Le1flgMany[1][3].Dataflag[1]=0x91;
	Le1flgMany[1][3].ReadFlg=2;
	Le1flgMany[2][0].Dataflag[0]=0x1f;//2-F3
	Le1flgMany[2][0].Dataflag[1]=0xa0;
	Le1flgMany[2][0].ReadFlg=2;
	Le1flgMany[2][1].Dataflag[0]=0x1f;
	Le1flgMany[2][1].Dataflag[1]=0xb0;
	Le1flgMany[2][1].ReadFlg=2;
	Le1flgMany[2][2].Dataflag[0]=0x1f;
	Le1flgMany[2][2].Dataflag[1]=0xa1;
	Le1flgMany[2][2].ReadFlg=2;
	Le1flgMany[2][3].Dataflag[0]=0x1f;
	Le1flgMany[2][3].Dataflag[1]=0xb1;
	Le1flgMany[2][3].ReadFlg=2;
	Le1flgMany[3][0].Dataflag[0]=0x2f;//2-F4
	Le1flgMany[3][0].Dataflag[1]=0xa0;
	Le1flgMany[3][0].ReadFlg=2;
	Le1flgMany[3][1].Dataflag[0]=0x2f;
	Le1flgMany[3][1].Dataflag[1]=0xb0;
	Le1flgMany[3][1].ReadFlg=2;
	Le1flgMany[3][2].Dataflag[0]=0x2f;
	Le1flgMany[3][2].Dataflag[1]=0xa1;
	Le1flgMany[3][2].ReadFlg=2;
	Le1flgMany[3][3].Dataflag[0]=0x2f;
	Le1flgMany[3][3].Dataflag[1]=0xb1;
	Le1flgMany[3][3].ReadFlg=2;
	Le1flgMany[4][0].Dataflag[0]=0x1f;//2-F5
	Le1flgMany[4][0].Dataflag[1]=0x90;
	Le1flgMany[4][0].ReadFlg=2;
	Le1flgMany[5][0].Dataflag[0]=0x1f;//2-F6
	Le1flgMany[5][0].Dataflag[1]=0x91;
	Le1flgMany[5][0].ReadFlg=2;
	Le1flgMany[6][0].Dataflag[0]=0x2f;//2-F7
	Le1flgMany[6][0].Dataflag[1]=0x90;
	Le1flgMany[6][0].ReadFlg=2;
	Le1flgMany[7][0].Dataflag[0]=0x2f;//2-F8
	Le1flgMany[7][0].Dataflag[1]=0x91;
	Le1flgMany[7][0].ReadFlg=2;
	Le1flgMany[16][0].Dataflag[0]=0x3f;//F17
	Le1flgMany[16][0].Dataflag[1]=0xb6;
	Le1flgMany[16][0].ReadFlg=1;
	Le1flgMany[16][1].Dataflag[0]=0x1f;//2-F17
	Le1flgMany[16][1].Dataflag[1]=0x90;
	Le1flgMany[16][1].ReadFlg=2;
	Le1flgMany[16][2].Dataflag[0]=0x1f;
	Le1flgMany[16][2].Dataflag[1]=0x91;
	Le1flgMany[16][2].ReadFlg=2;
	Le1flgMany[16][3].Dataflag[0]=0x3f;
	Le1flgMany[16][3].Dataflag[1]=0x91;
	Le1flgMany[16][3].ReadFlg=2;
	Le1flgMany[16][4].Dataflag[0]=0x4f;
	Le1flgMany[16][4].Dataflag[1]=0x91;
	Le1flgMany[16][4].ReadFlg=2;
	Le1flgMany[17][0].Dataflag[0]=0x4f;//F18
	Le1flgMany[17][0].Dataflag[1]=0xb6;
	Le1flgMany[17][0].ReadFlg=1;
	Le1flgMany[17][1].Dataflag[0]=0x2f;//2-F18
	Le1flgMany[17][1].Dataflag[1]=0x90;
	Le1flgMany[17][1].ReadFlg=2;
	Le1flgMany[17][2].Dataflag[0]=0x2f;
	Le1flgMany[17][2].Dataflag[1]=0x91;
	Le1flgMany[17][2].ReadFlg=2;
	Le1flgMany[17][3].Dataflag[0]=0x5f;
	Le1flgMany[17][3].Dataflag[1]=0x91;
	Le1flgMany[17][3].ReadFlg=2;
	Le1flgMany[17][4].Dataflag[0]=0x6f;
	Le1flgMany[17][4].Dataflag[1]=0x91;
	Le1flgMany[17][4].ReadFlg=2;
	Le1flgMany[18][0].Dataflag[0]=0x1f;//2-F19
	Le1flgMany[18][0].Dataflag[1]=0xa0;
	Le1flgMany[18][0].ReadFlg=2;
	Le1flgMany[18][1].Dataflag[0]=0x1f;
	Le1flgMany[18][1].Dataflag[1]=0xb0;
	Le1flgMany[18][1].ReadFlg=2;
	Le1flgMany[18][2].Dataflag[0]=0x1f;
	Le1flgMany[18][2].Dataflag[1]=0xa1;
	Le1flgMany[18][2].ReadFlg=2;
	Le1flgMany[18][3].Dataflag[0]=0x1f;
	Le1flgMany[18][3].Dataflag[1]=0xb1;
	Le1flgMany[18][3].ReadFlg=2;
	Le1flgMany[19][0].Dataflag[0]=0x2f;//2-F20
	Le1flgMany[19][0].Dataflag[1]=0xa0;
	Le1flgMany[19][0].ReadFlg=2;
	Le1flgMany[19][1].Dataflag[0]=0x2f;
	Le1flgMany[19][1].Dataflag[1]=0xb0;
	Le1flgMany[19][1].ReadFlg=2;
	Le1flgMany[19][2].Dataflag[0]=0x2f;
	Le1flgMany[19][2].Dataflag[1]=0xa1;
	Le1flgMany[19][2].ReadFlg=2;
	Le1flgMany[19][3].Dataflag[0]=0x2f;
	Le1flgMany[19][3].Dataflag[1]=0xb1;
	Le1flgMany[19][3].ReadFlg=2;
	Le1flgMany[20][1].Dataflag[0]=0x1f;//2-F21
	Le1flgMany[20][1].Dataflag[1]=0x90;
	Le1flgMany[20][1].ReadFlg=2;
	Le1flgMany[21][1].Dataflag[0]=0x1f;//2-F22
	Le1flgMany[21][1].Dataflag[1]=0x91;
	Le1flgMany[21][1].ReadFlg=2;
	Le1flgMany[22][1].Dataflag[0]=0x2f;//2-F23
	Le1flgMany[22][1].Dataflag[1]=0x90;
	Le1flgMany[22][1].ReadFlg=2;
	Le1flgMany[23][1].Dataflag[0]=0x2f;//2-F24
	Le1flgMany[24][1].Dataflag[1]=0x91;
	Le1flgMany[24][1].ReadFlg=2;
	Le1flgMany[24][0].Dataflag[0]=0x1f;//F25
	Le1flgMany[24][0].Dataflag[1]=0xb6;
	Le1flgMany[24][0].ReadFlg=1;
	Le1flgMany[24][1].Dataflag[0]=0x2f;
	Le1flgMany[24][1].Dataflag[1]=0xb6;
	Le1flgMany[24][1].ReadFlg=1;
	Le1flgMany[24][2].Dataflag[0]=0x3f;
	Le1flgMany[24][2].Dataflag[1]=0xb6;
	Le1flgMany[24][2].ReadFlg=1;
	Le1flgMany[24][3].Dataflag[0]=0x4f;
	Le1flgMany[24][3].Dataflag[1]=0xb6;
	Le1flgMany[24][3].ReadFlg=1;
	Le1flgMany[24][4].Dataflag[0]=0x5f;
	Le1flgMany[24][4].Dataflag[1]=0xb6;
	Le1flgMany[24][4].ReadFlg=1;
	Le1flgMany[25][0].Dataflag[0]=0x10;//F26
	Le1flgMany[25][0].Dataflag[1]=0xb3;
	Le1flgMany[25][0].ReadFlg=1;
	Le1flgMany[25][1].Dataflag[0]=0x11;
	Le1flgMany[25][1].Dataflag[1]=0xb3;
	Le1flgMany[25][1].ReadFlg=1;
	Le1flgMany[25][2].Dataflag[0]=0x12;
	Le1flgMany[25][2].Dataflag[1]=0xb3;
	Le1flgMany[25][2].ReadFlg=1;
	Le1flgMany[25][3].Dataflag[0]=0x13;
	Le1flgMany[25][3].Dataflag[1]=0xb3;
	Le1flgMany[25][3].ReadFlg=1;
	Le1flgMany[25][4].Dataflag[0]=0x20;
	Le1flgMany[25][4].Dataflag[1]=0xb3;
	Le1flgMany[25][4].ReadFlg=1;
	Le1flgMany[25][5].Dataflag[0]=0x21;
	Le1flgMany[25][5].Dataflag[1]=0xb3;
	Le1flgMany[25][5].ReadFlg=1;
	Le1flgMany[25][6].Dataflag[0]=0x22;
	Le1flgMany[25][6].Dataflag[1]=0xb3;
	Le1flgMany[25][6].ReadFlg=1;
	Le1flgMany[25][7].Dataflag[0]=0x23;
	Le1flgMany[25][7].Dataflag[1]=0xb3;
	Le1flgMany[25][7].ReadFlg=1;
	Le1flgMany[25][8].Dataflag[0]=0x30;
	Le1flgMany[25][8].Dataflag[1]=0xb3;
	Le1flgMany[25][8].ReadFlg=1;
	Le1flgMany[25][9].Dataflag[0]=0x31;
	Le1flgMany[25][9].Dataflag[1]=0xb3;
	Le1flgMany[25][9].ReadFlg=1;
	Le1flgMany[25][10].Dataflag[0]=0x32;
	Le1flgMany[25][10].Dataflag[1]=0xb3;
	Le1flgMany[25][10].ReadFlg=1;
	Le1flgMany[25][11].Dataflag[0]=0x33;
	Le1flgMany[25][11].Dataflag[1]=0xb3;
	Le1flgMany[25][11].ReadFlg=1;
	Le1flgMany[25][12].Dataflag[0]=0x40;
	Le1flgMany[25][12].Dataflag[1]=0xb3;
	Le1flgMany[25][12].ReadFlg=1;
	Le1flgMany[25][13].Dataflag[0]=0x41;
	Le1flgMany[25][13].Dataflag[1]=0xb3;
	Le1flgMany[25][13].ReadFlg=1;
	Le1flgMany[25][14].Dataflag[0]=0x42;
	Le1flgMany[25][14].Dataflag[1]=0xb3;
	Le1flgMany[25][14].ReadFlg=1;
	Le1flgMany[25][15].Dataflag[0]=0x43;
	Le1flgMany[25][15].Dataflag[1]=0xb3;
	Le1flgMany[25][15].ReadFlg=1;
	Le1flgMany[32][0].Dataflag[0]=0x1f;//F33
	Le1flgMany[32][0].Dataflag[1]=0x90;
	Le1flgMany[32][0].ReadFlg=1;
	Le1flgMany[32][1].Dataflag[0]=0x1f;
	Le1flgMany[32][1].Dataflag[1]=0x91;
	Le1flgMany[32][1].ReadFlg=1;
	Le1flgMany[32][2].Dataflag[0]=0x3f;
	Le1flgMany[32][2].Dataflag[1]=0x91;
	Le1flgMany[32][2].ReadFlg=1;
	Le1flgMany[32][3].Dataflag[0]=0x4f;
	Le1flgMany[32][3].Dataflag[1]=0x91;
	Le1flgMany[32][3].ReadFlg=1;
	Le1flgMany[33][0].Dataflag[0]=0x2f;//F34
	Le1flgMany[33][0].Dataflag[1]=0x90;
	Le1flgMany[33][0].ReadFlg=1;
	Le1flgMany[33][1].Dataflag[0]=0x2f;
	Le1flgMany[33][1].Dataflag[1]=0x91;
	Le1flgMany[33][1].ReadFlg=1;
	Le1flgMany[33][2].Dataflag[0]=0x5f;
	Le1flgMany[33][2].Dataflag[1]=0x91;
	Le1flgMany[33][2].ReadFlg=1;
	Le1flgMany[33][3].Dataflag[0]=0x6f;
	Le1flgMany[33][3].Dataflag[1]=0x91;
	Le1flgMany[33][3].ReadFlg=1;
	Le1flgMany[34][0].Dataflag[0]=0x1f;//F35
	Le1flgMany[34][0].Dataflag[1]=0xa0;
	Le1flgMany[34][0].ReadFlg=1;
	Le1flgMany[34][1].Dataflag[0]=0x1f;
	Le1flgMany[34][1].Dataflag[1]=0xb0;
	Le1flgMany[34][1].ReadFlg=1;
	Le1flgMany[34][2].Dataflag[0]=0x1f;
	Le1flgMany[34][2].Dataflag[1]=0xa1;
	Le1flgMany[34][2].ReadFlg=1;
	Le1flgMany[34][3].Dataflag[0]=0x1f;
	Le1flgMany[34][3].Dataflag[1]=0xb1;
	Le1flgMany[34][3].ReadFlg=1;
	Le1flgMany[35][0].Dataflag[0]=0x2f;//F36
	Le1flgMany[35][0].Dataflag[1]=0xa0;
	Le1flgMany[35][0].ReadFlg=1;
	Le1flgMany[35][1].Dataflag[0]=0x2f;
	Le1flgMany[35][1].Dataflag[1]=0xb0;
	Le1flgMany[35][1].ReadFlg=1;
	Le1flgMany[35][2].Dataflag[0]=0x2f;
	Le1flgMany[35][2].Dataflag[1]=0xa1;
	Le1flgMany[35][2].ReadFlg=1;
	Le1flgMany[35][3].Dataflag[0]=0x2f;
	Le1flgMany[35][3].Dataflag[1]=0xb1;
	Le1flgMany[35][3].ReadFlg=1;
	Le1flgMany[72][0].Dataflag[0]=0x30;//2-F73
	Le1flgMany[72][0].Dataflag[1]=0xb6;
	Le1flgMany[72][0].ReadFlg=2;
	Le1flgMany[73][0].Dataflag[0]=0x40;//2-F74
	Le1flgMany[73][0].Dataflag[1]=0xb6;
	Le1flgMany[73][0].ReadFlg=2;
	Le1flgMany[74][0].Dataflag[0]=0x1f;//2-F75
	Le1flgMany[74][0].Dataflag[1]=0x90;
	Le1flgMany[74][0].ReadFlg=2;
	Le1flgMany[74][1].Dataflag[0]=0x1f;
	Le1flgMany[74][1].Dataflag[1]=0x91;
	Le1flgMany[74][1].ReadFlg=2;
	Le1flgMany[75][0].Dataflag[0]=0x2f;//2-F76
	Le1flgMany[75][0].Dataflag[1]=0x90;
	Le1flgMany[75][0].ReadFlg=2;
	Le1flgMany[75][1].Dataflag[0]=0x2f;
	Le1flgMany[75][1].Dataflag[1]=0x91;
	Le1flgMany[75][1].ReadFlg=2;
	Le1flgMany[80][0].Dataflag[0]=0x3f;//2-F81
	Le1flgMany[80][0].Dataflag[1]=0xb6;
	Le1flgMany[80][0].ReadFlg=2;
	Le1flgMany[81][0].Dataflag[0]=0x3f;//2-F82
	Le1flgMany[81][0].Dataflag[1]=0xb6;
	Le1flgMany[81][0].ReadFlg=2;
	Le1flgMany[82][0].Dataflag[0]=0x3f;//2-F83
	Le1flgMany[82][0].Dataflag[1]=0xb6;
	Le1flgMany[82][0].ReadFlg=2;
	Le1flgMany[83][0].Dataflag[0]=0x3f;//2-F84
	Le1flgMany[83][0].Dataflag[1]=0xb6;
	Le1flgMany[83][0].ReadFlg=2;
	Le1flgMany[84][0].Dataflag[0]=0x4f;//2-F85
	Le1flgMany[84][0].Dataflag[1]=0xb6;
	Le1flgMany[84][0].ReadFlg=2;
	Le1flgMany[85][0].Dataflag[0]=0x4f;//2-F86
	Le1flgMany[85][0].Dataflag[1]=0xb6;
	Le1flgMany[85][0].ReadFlg=2;
	Le1flgMany[86][0].Dataflag[0]=0x4f;//2-F87
	Le1flgMany[86][0].Dataflag[1]=0xb6;
	Le1flgMany[86][0].ReadFlg=2;
	Le1flgMany[87][0].Dataflag[0]=0x4f;//2-F88
	Le1flgMany[87][0].Dataflag[1]=0xb6;
	Le1flgMany[87][0].ReadFlg=2;
	Le1flgMany[88][0].Dataflag[0]=0x1f;//2-F89
	Le1flgMany[88][0].Dataflag[1]=0xb6;
	Le1flgMany[88][0].ReadFlg=2;
	Le1flgMany[89][0].Dataflag[0]=0x1f;//2-F90
	Le1flgMany[89][0].Dataflag[1]=0xb6;
	Le1flgMany[89][0].ReadFlg=2;
	Le1flgMany[90][0].Dataflag[0]=0x1f;//2-F91
	Le1flgMany[90][0].Dataflag[1]=0xb6;
	Le1flgMany[90][0].ReadFlg=2;
	Le1flgMany[91][0].Dataflag[0]=0x2f;//2-F92
	Le1flgMany[91][0].Dataflag[1]=0xb6;
	Le1flgMany[91][0].ReadFlg=2;
	Le1flgMany[92][0].Dataflag[0]=0x2f;//2-F93
	Le1flgMany[92][0].Dataflag[1]=0xb6;
	Le1flgMany[92][0].ReadFlg=2;
	Le1flgMany[93][0].Dataflag[0]=0x2f;//2-F94
	Le1flgMany[93][0].Dataflag[1]=0xb6;
	Le1flgMany[93][0].ReadFlg=2;
	Le1flgMany[96][0].Dataflag[0]=0x1f;//2-F97
	Le1flgMany[96][0].Dataflag[1]=0x90;
	Le1flgMany[96][0].ReadFlg=2;
	Le1flgMany[97][0].Dataflag[0]=0x1f;//2-F98
	Le1flgMany[97][0].Dataflag[1]=0x91;
	Le1flgMany[97][0].ReadFlg=2;
	Le1flgMany[98][0].Dataflag[0]=0x2f;//2-F99
	Le1flgMany[98][0].Dataflag[1]=0x90;
	Le1flgMany[98][0].ReadFlg=2;
	Le1flgMany[99][0].Dataflag[0]=0x2f;//2-F100
	Le1flgMany[99][0].Dataflag[1]=0x91;
	Le1flgMany[99][0].ReadFlg=2;
	Le1flgMany[100][0].Dataflag[0]=0x1f;//2-F101
	Le1flgMany[100][0].Dataflag[1]=0x90;
	Le1flgMany[100][0].ReadFlg=2;
	Le1flgMany[101][0].Dataflag[0]=0x1f;//2-F102
	Le1flgMany[101][0].Dataflag[1]=0x91;
	Le1flgMany[101][0].ReadFlg=2;
	Le1flgMany[102][0].Dataflag[0]=0x2f;//2-F103
	Le1flgMany[102][0].Dataflag[1]=0x90;
	Le1flgMany[102][0].ReadFlg=2;
	Le1flgMany[103][0].Dataflag[0]=0x2f;//2-F104
	Le1flgMany[103][0].Dataflag[1]=0x91;
	Le1flgMany[103][0].ReadFlg=2;
	Le1flgMany[104][0].Dataflag[0]=0x5f;//2-F105
	Le1flgMany[104][0].Dataflag[1]=0xb6;
	Le1flgMany[104][0].ReadFlg=2;
	Le1flgMany[105][0].Dataflag[0]=0x5f;//2-F106
	Le1flgMany[105][0].Dataflag[1]=0xb6;
	Le1flgMany[105][0].ReadFlg=2;
	Le1flgMany[106][0].Dataflag[0]=0x5f;//2-F107
	Le1flgMany[106][0].Dataflag[1]=0xb6;
	Le1flgMany[106][0].ReadFlg=2;
	Le1flgMany[107][0].Dataflag[0]=0x5f;//2-F108
	Le1flgMany[107][0].Dataflag[1]=0xb6;
	Le1flgMany[107][0].ReadFlg=2;
	Le1flgMany[128][0].Dataflag[0]=0x1f;//F129
	Le1flgMany[128][0].Dataflag[1]=0x90;
	Le1flgMany[128][0].ReadFlg=1;
	Le1flgMany[129][0].Dataflag[0]=0x1f;//F130
	Le1flgMany[129][0].Dataflag[1]=0x91;
	Le1flgMany[129][0].ReadFlg=1;
	Le1flgMany[130][0].Dataflag[0]=0x2f;//F131
	Le1flgMany[130][0].Dataflag[1]=0x90;
	Le1flgMany[130][0].ReadFlg=1;
	Le1flgMany[131][0].Dataflag[0]=0x2f;//F132
	Le1flgMany[131][0].Dataflag[1]=0x91;
	Le1flgMany[131][0].ReadFlg=1;
	Le1flgMany[132][0].Dataflag[0]=0x3f;//F133
	Le1flgMany[132][0].Dataflag[1]=0x91;
	Le1flgMany[132][0].ReadFlg=1;
	Le1flgMany[133][0].Dataflag[0]=0x5f;//F134
	Le1flgMany[133][0].Dataflag[1]=0x91;
	Le1flgMany[133][0].ReadFlg=1;
	Le1flgMany[134][0].Dataflag[0]=0x6f;//F135
	Le1flgMany[134][0].Dataflag[1]=0x91;
	Le1flgMany[134][0].ReadFlg=1;
	Le1flgMany[135][0].Dataflag[0]=0x4f;//F136
	Le1flgMany[135][0].Dataflag[1]=0x91;
	Le1flgMany[135][0].ReadFlg=1;
	Le1flgMany[144][0].Dataflag[0]=0x1f;//F145
	Le1flgMany[144][0].Dataflag[1]=0xa0;
	Le1flgMany[144][0].ReadFlg=1;
	Le1flgMany[144][1].Dataflag[0]=0x1f;
	Le1flgMany[144][1].Dataflag[1]=0xb0;
	Le1flgMany[144][1].ReadFlg=1;
	Le1flgMany[145][0].Dataflag[0]=0x1f;//F146
	Le1flgMany[145][0].Dataflag[1]=0xa1;
	Le1flgMany[145][0].ReadFlg=1;
	Le1flgMany[145][1].Dataflag[0]=0x1f;
	Le1flgMany[145][1].Dataflag[1]=0xb1;
	Le1flgMany[145][1].ReadFlg=1;
	Le1flgMany[146][0].Dataflag[0]=0x2f;//F147
	Le1flgMany[146][0].Dataflag[1]=0xa0;
	Le1flgMany[146][0].ReadFlg=1;
	Le1flgMany[146][1].Dataflag[0]=0x2f;
	Le1flgMany[146][1].Dataflag[1]=0xb0;
	Le1flgMany[146][1].ReadFlg=1;
	Le1flgMany[147][0].Dataflag[0]=0x2f;//F148
	Le1flgMany[147][0].Dataflag[1]=0xa1;
	Le1flgMany[147][0].ReadFlg=1;
	Le1flgMany[147][1].Dataflag[0]=0x2f;
	Le1flgMany[147][1].Dataflag[1]=0xb1;
	Le1flgMany[147][1].ReadFlg=1;
	Le1flgMany[160][0].Dataflag[0]=0x1f;//2-F161
	Le1flgMany[160][0].Dataflag[1]=0x90;
	Le1flgMany[160][0].ReadFlg=2;
	Le1flgMany[161][0].Dataflag[0]=0x1f;//2-F162
	Le1flgMany[161][0].Dataflag[1]=0x91;
	Le1flgMany[161][0].ReadFlg=2;
	Le1flgMany[162][0].Dataflag[0]=0x2f;//2-F163
	Le1flgMany[162][0].Dataflag[1]=0x90;
	Le1flgMany[162][0].ReadFlg=2;
	Le1flgMany[163][0].Dataflag[0]=0x2f;//2-F164
	Le1flgMany[163][0].Dataflag[1]=0x91;
	Le1flgMany[163][0].ReadFlg=2;
	Le1flgMany[164][0].Dataflag[0]=0x3f;//2-F165
	Le1flgMany[164][0].Dataflag[1]=0x91;
	Le1flgMany[164][0].ReadFlg=2;
	Le1flgMany[165][0].Dataflag[0]=0x5f;//2-F166
	Le1flgMany[165][0].Dataflag[1]=0x91;
	Le1flgMany[165][0].ReadFlg=2;
	Le1flgMany[166][0].Dataflag[0]=0x94;//F167
	Le1flgMany[166][0].Dataflag[1]=0x00;
	Le1flgMany[166][0].ReadFlg=1;
	Le1flgMany[166][1].Dataflag[0]=0x6f;//2-F167
	Le1flgMany[166][1].Dataflag[1]=0x91;
	Le1flgMany[166][1].ReadFlg=2;
	Le1flgMany[167][0].Dataflag[0]=0x4f;//2-F168
	Le1flgMany[167][0].Dataflag[1]=0x91;
	Le1flgMany[167][0].ReadFlg=2;
	Le1flgMany[168][0].Dataflag[0]=0x1f;//2-F169
	Le1flgMany[168][0].Dataflag[1]=0x90;
	Le1flgMany[168][0].ReadFlg=2;
	Le1flgMany[169][0].Dataflag[0]=0x1f;//2-F170
	Le1flgMany[169][0].Dataflag[1]=0x91;
	Le1flgMany[169][0].ReadFlg=2;
	Le1flgMany[176][0].Dataflag[0]=0x1f;//2-F177
	Le1flgMany[176][0].Dataflag[1]=0x90;
	Le1flgMany[176][0].ReadFlg=2;
	Le1flgMany[177][0].Dataflag[0]=0x1f;//2-F178
	Le1flgMany[177][0].Dataflag[1]=0x91;
	Le1flgMany[177][0].ReadFlg=2;
	Le1flgMany[178][0].Dataflag[0]=0x2f;//2-F179
	Le1flgMany[178][0].Dataflag[1]=0x90;
	Le1flgMany[178][0].ReadFlg=2;
	Le1flgMany[179][0].Dataflag[0]=0x2f;//2-F180
	Le1flgMany[179][0].Dataflag[1]=0x91;
	Le1flgMany[179][0].ReadFlg=2;
	Le1flgMany[180][0].Dataflag[0]=0x3f;//2-F181
	Le1flgMany[180][0].Dataflag[1]=0x91;
	Le1flgMany[180][0].ReadFlg=2;
	Le1flgMany[181][0].Dataflag[0]=0x5f;//2-F182
	Le1flgMany[181][0].Dataflag[1]=0x91;
	Le1flgMany[181][0].ReadFlg=2;
	Le1flgMany[182][0].Dataflag[0]=0x6f;//2-F183
	Le1flgMany[182][0].Dataflag[1]=0x91;
	Le1flgMany[182][0].ReadFlg=2;
	Le1flgMany[183][0].Dataflag[0]=0x4f;//2-F184
	Le1flgMany[183][0].Dataflag[1]=0x91;
	Le1flgMany[183][0].ReadFlg=2;
	Le1flgMany[184][0].Dataflag[0]=0x1f;//2-F185
	Le1flgMany[184][0].Dataflag[1]=0xa0;
	Le1flgMany[184][0].ReadFlg=2;
	Le1flgMany[184][1].Dataflag[0]=0x1f;
	Le1flgMany[184][1].Dataflag[1]=0xb0;
	Le1flgMany[184][1].ReadFlg=2;
	Le1flgMany[185][0].Dataflag[0]=0x1f;//2-F186
	Le1flgMany[185][0].Dataflag[1]=0xa1;
	Le1flgMany[185][0].ReadFlg=2;
	Le1flgMany[185][1].Dataflag[0]=0x1f;
	Le1flgMany[185][1].Dataflag[1]=0xb1;
	Le1flgMany[185][1].ReadFlg=2;
	Le1flgMany[186][0].Dataflag[0]=0x2f;//2-F187
	Le1flgMany[186][0].Dataflag[1]=0xa0;
	Le1flgMany[186][0].ReadFlg=2;
	Le1flgMany[186][1].Dataflag[0]=0x2f;
	Le1flgMany[186][1].Dataflag[1]=0xb0;
	Le1flgMany[186][1].ReadFlg=2;
	Le1flgMany[187][0].Dataflag[0]=0x2f;//2-F188
	Le1flgMany[187][0].Dataflag[1]=0xa1;
	Le1flgMany[187][0].ReadFlg=2;
	Le1flgMany[187][1].Dataflag[0]=0x2f;
	Le1flgMany[187][1].Dataflag[1]=0xb1;
	Le1flgMany[187][1].ReadFlg=2;
	Le1flgMany[188][0].Dataflag[0]=0x1f;//2-F189
	Le1flgMany[188][0].Dataflag[1]=0xa0;
	Le1flgMany[188][0].ReadFlg=2;
	Le1flgMany[188][1].Dataflag[0]=0x1f;
	Le1flgMany[188][1].Dataflag[1]=0xb0;
	Le1flgMany[188][1].ReadFlg=2;
	Le1flgMany[189][0].Dataflag[0]=0x1f;//2-F190
	Le1flgMany[189][0].Dataflag[1]=0xa1;
	Le1flgMany[189][0].ReadFlg=2;
	Le1flgMany[189][1].Dataflag[0]=0x1f;
	Le1flgMany[189][1].Dataflag[1]=0xb1;
	Le1flgMany[189][1].ReadFlg=2;
	Le1flgMany[190][0].Dataflag[0]=0x2f;//2-F191
	Le1flgMany[190][0].Dataflag[1]=0xa0;
	Le1flgMany[190][0].ReadFlg=2;
	Le1flgMany[190][1].Dataflag[0]=0x2f;
	Le1flgMany[190][1].Dataflag[1]=0xb0;
	Le1flgMany[190][1].ReadFlg=2;
	Le1flgMany[191][0].Dataflag[0]=0x2f;//2-F192
	Le1flgMany[191][0].Dataflag[1]=0xa1;
	Le1flgMany[191][0].ReadFlg=2;
	Le1flgMany[191][1].Dataflag[0]=0x2f;
	Le1flgMany[191][1].Dataflag[1]=0xb1;
	Le1flgMany[191][1].ReadFlg=2;
}
void fuzhi_5_1(Fn_DLT *fn_dlt_5_1)
{
	int i = 0;

	//f97 0x90,0x10
	fn_dlt_5_1[i].Fn = 97;
	fn_dlt_5_1[i].DLT[0].Dataflag[1] = 0x90;
	fn_dlt_5_1[i].DLT[0].Dataflag[0] = 0x1f;

	fn_dlt_5_1[i].dltnum = 1;
	fn_dlt_5_1[i].status = 2;
	i++;

	//f99 0x90,0x20
	fn_dlt_5_1[i].Fn = 99;
	fn_dlt_5_1[i].DLT[0].Dataflag[1] = 0x90;
	fn_dlt_5_1[i].DLT[0].Dataflag[0] = 0x2f;

	fn_dlt_5_1[i].dltnum = 1;
	fn_dlt_5_1[i].status = 2;
	i++;

	//f101 0x90,0x10
	fn_dlt_5_1[i].Fn = 101;

	fn_dlt_5_1[i].DLT[0].Dataflag[1] = 0x90;
	fn_dlt_5_1[i].DLT[0].Dataflag[0] = 0x1f;

	fn_dlt_5_1[i].dltnum = 1;
	fn_dlt_5_1[i].status = 2;
	i++;

	//f103 0x90,0x20
	fn_dlt_5_1[i].Fn = 103;
	fn_dlt_5_1[i].DLT[0].Dataflag[1] = 0x90;
	fn_dlt_5_1[i].DLT[0].Dataflag[0] = 0x2f;
	fn_dlt_5_1[i].dltnum = 1;
	fn_dlt_5_1[i].status = 2;
	i++;

	//////////////////////////////////////////////////////////////////////////////////
	//f161
	fn_dlt_5_1[i].Fn = 161;
	fn_dlt_5_1[i].DLT[0].Dataflag[1] = 0xfb;
	fn_dlt_5_1[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_5_1[i].DLT[1].Dataflag[1] = 0xfb;
	fn_dlt_5_1[i].DLT[1].Dataflag[0] = 0x02;
	fn_dlt_5_1[i].DLT[2].Dataflag[1] = 0x90;
	fn_dlt_5_1[i].DLT[2].Dataflag[0] = 0x1f;
	fn_dlt_5_1[i].dltnum = 3;
	fn_dlt_5_1[i].status = 1;
	i++;
	//f163
	fn_dlt_5_1[i].Fn = 163;
	fn_dlt_5_1[i].DLT[0].Dataflag[1] = 0xfb;
	fn_dlt_5_1[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_5_1[i].DLT[1].Dataflag[1] = 0xfb;
	fn_dlt_5_1[i].DLT[1].Dataflag[0] = 0x03;
	fn_dlt_5_1[i].DLT[2].Dataflag[1] = 0x90;
	fn_dlt_5_1[i].DLT[2].Dataflag[0] = 0x2f;
	fn_dlt_5_1[i].dltnum = 3;
	fn_dlt_5_1[i].status = 1;

	i++;
	//f177
	fn_dlt_5_1[i].Fn = 177;
	fn_dlt_5_1[i].DLT[0].Dataflag[1] = 0xfb;
	fn_dlt_5_1[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_5_1[i].DLT[1].Dataflag[1] = 0xfb;
	fn_dlt_5_1[i].DLT[1].Dataflag[0] = 0x02;
	fn_dlt_5_1[i].DLT[2].Dataflag[1] = 0x90;
	fn_dlt_5_1[i].DLT[2].Dataflag[0] = 0x1f;
	fn_dlt_5_1[i].dltnum = 3;
	fn_dlt_5_1[i].status = 1;
	i++;
	fprintf(stderr,"\n------fuzhi_5_1-------all  %d-----------------\n",i);
	return;
}
void fuzhi_5_2(Fn_DLT *fn_dlt_5_2)
{
	int i=0;
	fn_dlt_5_2[i].Fn = 97;
	fn_dlt_5_2[i].DLT[0].Dataflag[1] = 0x90;
	fn_dlt_5_2[i].DLT[0].Dataflag[0] = 0x1f;

	fn_dlt_5_2[i].dltnum = 1;
	fn_dlt_5_2[i].status = 2;
	i++;

	//f99 0x90,0x20
	fn_dlt_5_2[i].Fn = 99;
	fn_dlt_5_2[i].DLT[0].Dataflag[1] = 0x90;
	fn_dlt_5_2[i].DLT[0].Dataflag[0] = 0x2f;

	fn_dlt_5_2[i].dltnum = 1;
	fn_dlt_5_2[i].status = 2;
	i++;

	//f101 0x90,0x10
	fn_dlt_5_2[i].Fn = 101;

	fn_dlt_5_2[i].DLT[0].Dataflag[1] = 0x90;
	fn_dlt_5_2[i].DLT[0].Dataflag[0] = 0x1f;

	fn_dlt_5_2[i].dltnum = 1;
	fn_dlt_5_2[i].status = 2;
	i++;

	//f103 0x90,0x20
	fn_dlt_5_2[i].Fn = 103;
	fn_dlt_5_2[i].DLT[0].Dataflag[1] = 0x90;
	fn_dlt_5_2[i].DLT[0].Dataflag[0] = 0x2f;
	fn_dlt_5_2[i].dltnum = 1;
	fn_dlt_5_2[i].status = 2;
	i++;

	///////////////////////////F///////////////////////////////////////////////////////
	//f161
	fn_dlt_5_2[i].Fn = 161;
	fn_dlt_5_2[i].DLT[0].Dataflag[1] = 0xfb;
	fn_dlt_5_2[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_5_2[i].DLT[1].Dataflag[1] = 0xfb;
	fn_dlt_5_2[i].DLT[1].Dataflag[0] = 0x02;
	fn_dlt_5_2[i].DLT[2].Dataflag[1] = 0x90;
	fn_dlt_5_2[i].DLT[2].Dataflag[0] = 0x1f;
	fn_dlt_5_2[i].dltnum = 3;
	fn_dlt_5_2[i].status = 1;
	i++;
	//f163
	fn_dlt_5_2[i].Fn = 163;
	fn_dlt_5_2[i].DLT[0].Dataflag[1] = 0xfb;
	fn_dlt_5_2[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_5_2[i].DLT[1].Dataflag[1] = 0xfb;
	fn_dlt_5_2[i].DLT[1].Dataflag[0] = 0x03;
	fn_dlt_5_2[i].DLT[2].Dataflag[1] = 0x90;
	fn_dlt_5_2[i].DLT[2].Dataflag[0] = 0x2f;
	fn_dlt_5_2[i].dltnum = 3;
	fn_dlt_5_2[i].status = 1;

	////////////////////////////////////////
	i++;
	//f177
	fn_dlt_5_2[i].Fn = 177;
	fn_dlt_5_2[i].DLT[0].Dataflag[1] = 0xfb;
	fn_dlt_5_2[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_5_2[i].DLT[1].Dataflag[1] = 0xfb;
	fn_dlt_5_2[i].DLT[1].Dataflag[0] = 0x02;
	fn_dlt_5_2[i].DLT[2].Dataflag[1] = 0x90;
	fn_dlt_5_2[i].DLT[2].Dataflag[0] = 0x1f;
	fn_dlt_5_2[i].dltnum = 3;
	fn_dlt_5_2[i].status = 1;
	i++;
	fprintf(stderr,"\n------fuzhi_5_2-------all  %d-----------------\n",i);
	return;
}
void fuzhi_7_1(Fn_DLT *fn_dlt_7_1)
{
	int i = 0;

	fn_dlt_7_1[i].Fn = 97;
	fn_dlt_7_1[i].DLT[0].Dataflag[1] = 0x90;
	fn_dlt_7_1[i].DLT[0].Dataflag[0] = 0x1f;

	fn_dlt_7_1[i].dltnum = 1;
	fn_dlt_7_1[i].status = 2;
	i++;

	//f99 0x90,0x20
	fn_dlt_7_1[i].Fn = 99;
	fn_dlt_7_1[i].DLT[0].Dataflag[1] = 0x90;
	fn_dlt_7_1[i].DLT[0].Dataflag[0] = 0x2f;

	fn_dlt_7_1[i].dltnum = 1;
	fn_dlt_7_1[i].status = 2;
	i++;

	//f101 0x90,0x10
	fn_dlt_7_1[i].Fn = 101;

	fn_dlt_7_1[i].DLT[0].Dataflag[1] = 0x90;
	fn_dlt_7_1[i].DLT[0].Dataflag[0] = 0x1f;

	fn_dlt_7_1[i].dltnum = 1;
	fn_dlt_7_1[i].status = 2;
	i++;

	//f103 0x90,0x20
	fn_dlt_7_1[i].Fn = 103;
	fn_dlt_7_1[i].DLT[0].Dataflag[1] = 0x90;
	fn_dlt_7_1[i].DLT[0].Dataflag[0] = 0x2f;
	fn_dlt_7_1[i].dltnum = 1;
	fn_dlt_7_1[i].status = 2;
	i++;

	//////////////////////////////////////////////////////////////////////////////////
	//f161
	fn_dlt_7_1[i].Fn = 161;
	fn_dlt_7_1[i].DLT[0].Dataflag[1] = 0xfb;
	fn_dlt_7_1[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_7_1[i].DLT[1].Dataflag[1] = 0xfb;
	fn_dlt_7_1[i].DLT[1].Dataflag[0] = 0x02;
	fn_dlt_7_1[i].DLT[2].Dataflag[1] = 0x90;
	fn_dlt_7_1[i].DLT[2].Dataflag[0] = 0x1f;
	fn_dlt_7_1[i].dltnum = 3;
	fn_dlt_7_1[i].status = 1;
	i++;
	//f163
	fn_dlt_7_1[i].Fn = 163;
	fn_dlt_7_1[i].DLT[0].Dataflag[1] = 0xfb;
	fn_dlt_7_1[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_7_1[i].DLT[1].Dataflag[1] = 0xfb;
	fn_dlt_7_1[i].DLT[1].Dataflag[0] = 0x03;
	fn_dlt_7_1[i].DLT[2].Dataflag[1] = 0x90;
	fn_dlt_7_1[i].DLT[2].Dataflag[0] = 0x2f;
	fn_dlt_7_1[i].dltnum = 3;
	fn_dlt_7_1[i].status = 1;

	i++;
	//f177
	fn_dlt_7_1[i].Fn = 177;
	fn_dlt_7_1[i].DLT[0].Dataflag[1] = 0xfb;
	fn_dlt_7_1[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_7_1[i].DLT[1].Dataflag[1] = 0xfb;
	fn_dlt_7_1[i].DLT[1].Dataflag[0] = 0x02;
	fn_dlt_7_1[i].DLT[2].Dataflag[1] = 0x90;
	fn_dlt_7_1[i].DLT[2].Dataflag[0] = 0x1f;
	fn_dlt_7_1[i].dltnum = 3;
	fn_dlt_7_1[i].status = 1;

	i++;
	//f179

	fn_dlt_7_1[i].Fn = 179;
	fn_dlt_7_1[i].DLT[0].Dataflag[1] = 0xfc;
	fn_dlt_7_1[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_7_1[i].DLT[1].Dataflag[1] = 0xfc;
	fn_dlt_7_1[i].DLT[1].Dataflag[0] = 0x03;
	fn_dlt_7_1[i].DLT[2].Dataflag[1] = 0x90;
	fn_dlt_7_1[i].DLT[2].Dataflag[0] = 0x2f;
	fn_dlt_7_1[i].dltnum = 3;
	fn_dlt_7_1[i].status = 1;
	i++;
	fprintf(stderr,"\n------fuzhi_7_1-------all  %d-----------------\n",i);
	return;
}
void fuzhi_7_2(Fn_DLT *fn_dlt_7_2)
{
	int i = 0;


	//f97 0x90,0x10
	fn_dlt_7_2[i].Fn = 97;
	fn_dlt_7_2[i].DLT[0].Dataflag[1] = 0x90;
	fn_dlt_7_2[i].DLT[0].Dataflag[0] = 0x1f;

	fn_dlt_7_2[i].dltnum = 1;
	fn_dlt_7_2[i].status = 2;
	i++;

	//f99 0x90,0x20
	fn_dlt_7_2[i].Fn = 99;
	fn_dlt_7_2[i].DLT[0].Dataflag[1] = 0x90;
	fn_dlt_7_2[i].DLT[0].Dataflag[0] = 0x2f;

	fn_dlt_7_2[i].dltnum = 1;
	fn_dlt_7_2[i].status = 2;
	i++;

	//f101 0x90,0x10
	fn_dlt_7_2[i].Fn = 101;

	fn_dlt_7_2[i].DLT[0].Dataflag[1] = 0x90;
	fn_dlt_7_2[i].DLT[0].Dataflag[0] = 0x1f;

	fn_dlt_7_2[i].dltnum = 1;
	fn_dlt_7_2[i].status = 2;
	i++;

	//f103 0x90,0x20
	fn_dlt_7_2[i].Fn = 103;
	fn_dlt_7_2[i].DLT[0].Dataflag[1] = 0x90;
	fn_dlt_7_2[i].DLT[0].Dataflag[0] = 0x2f;
	fn_dlt_7_2[i].dltnum = 1;
	fn_dlt_7_2[i].status = 2;
	i++;

	//////////////////////////////////////////////////////////////////////////////////
	//f7_2
	fn_dlt_7_2[i].Fn = 161;
	fn_dlt_7_2[i].DLT[0].Dataflag[1] = 0xfb;
	fn_dlt_7_2[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_7_2[i].DLT[1].Dataflag[1] = 0xfb;
	fn_dlt_7_2[i].DLT[1].Dataflag[0] = 0x02;
	fn_dlt_7_2[i].DLT[2].Dataflag[1] = 0x90;
	fn_dlt_7_2[i].DLT[2].Dataflag[0] = 0x1f;
	fn_dlt_7_2[i].dltnum = 3;
	fn_dlt_7_2[i].status = 1;
	i++;
	//f163
	fn_dlt_7_2[i].Fn = 163;
	fn_dlt_7_2[i].DLT[0].Dataflag[1] = 0xfb;
	fn_dlt_7_2[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_7_2[i].DLT[1].Dataflag[1] = 0xfb;
	fn_dlt_7_2[i].DLT[1].Dataflag[0] = 0x03;
	fn_dlt_7_2[i].DLT[2].Dataflag[1] = 0x90;
	fn_dlt_7_2[i].DLT[2].Dataflag[0] = 0x2f;
	fn_dlt_7_2[i].dltnum = 3;
	fn_dlt_7_2[i].status = 1;

	////////////////////////////////////////

	i++;
	//f177
	fn_dlt_7_2[i].Fn = 177;
	fn_dlt_7_2[i].DLT[0].Dataflag[1] = 0xfb;
	fn_dlt_7_2[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_7_2[i].DLT[1].Dataflag[1] = 0xfb;
	fn_dlt_7_2[i].DLT[1].Dataflag[0] = 0x02;
	fn_dlt_7_2[i].DLT[2].Dataflag[1] = 0x90;
	fn_dlt_7_2[i].DLT[2].Dataflag[0] = 0x1f;
	fn_dlt_7_2[i].dltnum = 3;
	fn_dlt_7_2[i].status = 1;

	i++;
	//f179

	fn_dlt_7_2[i].Fn = 179;
	fn_dlt_7_2[i].DLT[0].Dataflag[1] = 0xfc;
	fn_dlt_7_2[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_7_2[i].DLT[1].Dataflag[1] = 0xfc;
	fn_dlt_7_2[i].DLT[1].Dataflag[0] = 0x03;
	fn_dlt_7_2[i].DLT[2].Dataflag[1] = 0x90;
	fn_dlt_7_2[i].DLT[2].Dataflag[0] = 0x2f;
	fn_dlt_7_2[i].dltnum = 3;
	fn_dlt_7_2[i].status = 1;
	i++;
	fprintf(stderr,"\n------fuzhi_7_2-------all  %d-----------------\n",i);
	return;
}
void fuzhi_0_2(Fn_DLT *fn_dlt_0_2)
{
	int i = 0;

	//f81 0xb6,0x30
	fn_dlt_0_2[i].Fn = 81;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x30;
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0xb6;

	fn_dlt_0_2[i].dltnum = 1;
	fn_dlt_0_2[i].status = 2;
	i++;
	//f82 0xb6,0x31
	fn_dlt_0_2[i].Fn = 82;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x31;
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0xb6;

	fn_dlt_0_2[i].dltnum = 1;
	fn_dlt_0_2[i].status = 2;
	i++;
	//f83 0xb6,0x32
	fn_dlt_0_2[i].Fn = 83;
	//	fn_dlt_0_2[i].DLT[0].Dataflag[0]=0x31;
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0xb6;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x32;
	fn_dlt_0_2[i].dltnum = 1;
	fn_dlt_0_2[i].status = 2;
	i++;
	//f84 0xb6,0x33
	fn_dlt_0_2[i].Fn = 84;
	//	fn_dlt_0_2[i].DLT[0].Dataflag[0]=0x31;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x33;
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0xb6;

	fn_dlt_0_2[i].dltnum = 1;
	fn_dlt_0_2[i].status = 2;
	i++;
	//f85 0xb6,0x40
	fn_dlt_0_2[i].Fn = 85;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x40;
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0xb6;

	fn_dlt_0_2[i].dltnum = 1;
	fn_dlt_0_2[i].status = 2;
	i++;
	//f86 0xb6,0x41
	fn_dlt_0_2[i].Fn = 86;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x41;
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0xb6;

	fn_dlt_0_2[i].dltnum = 1;
	fn_dlt_0_2[i].status = 2;
	i++;
	//f87 0xb6,0x42
	fn_dlt_0_2[i].Fn = 87;
	//	fn_dlt_0_2[i].DLT[0].Dataflag[1]=0x41;
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0xb6;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x42;
	fn_dlt_0_2[i].dltnum = 1;
	fn_dlt_0_2[i].status = 2;
	i++;
	//f88 0xb6,0x43
	fn_dlt_0_2[i].Fn = 88;
	//	fn_dlt_0_2[i].DLT[0].Dataflag[0]=0x41;
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0xb6;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x43;
	fn_dlt_0_2[i].dltnum = 1;
	fn_dlt_0_2[i].status = 2;
	i++;
	//f89 0xb6,0x11
	fn_dlt_0_2[i].Fn = 89;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x11;
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0xb6;

	fn_dlt_0_2[i].dltnum = 1;
	fn_dlt_0_2[i].status = 2;
	i++;
	//f90 0xb6,0x12
	fn_dlt_0_2[i].Fn = 90;
	//	fn_dlt_0_2[i].DLT[0].Dataflag[0]=0x11;
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0xb6;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x12;
	fn_dlt_0_2[i].dltnum = 1;
	fn_dlt_0_2[i].status = 2;
	i++;
	//f91 0xb6,0x13
	fn_dlt_0_2[i].Fn = 91;
	//	fn_dlt_0_2[i].DLT[0].Dataflag[0]=0x11;
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0xb6;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x13;
	fn_dlt_0_2[i].dltnum = 1;
	fn_dlt_0_2[i].status = 2;
	i++;
	//f92 0xb6,0x21
	fn_dlt_0_2[i].Fn = 92;
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0xb6;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x21;
	fn_dlt_0_2[i].dltnum = 1;
	fn_dlt_0_2[i].status = 2;
	i++;
	//f93 0xb6,0x22
	fn_dlt_0_2[i].Fn = 93;
	//	fn_dlt_0_2[i].DLT[0].Dataflag[0]=0x21;
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0xb6;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x22;
	fn_dlt_0_2[i].dltnum = 1;
	fn_dlt_0_2[i].status = 2;
	i++;
	//f94 0xb6,0x23
	fn_dlt_0_2[i].Fn = 94;
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0xb6;
	//	fn_dlt_0_2[i].DLT[0].Dataflag[0]=0x21;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x23;
	fn_dlt_0_2[i].dltnum = 1;
	fn_dlt_0_2[i].status = 2;
	i++;
	//f95 0xb6,0x24
	fn_dlt_0_2[i].Fn = 95;
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0xb6;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x24;
	fn_dlt_0_2[i].dltnum = 1;
	fn_dlt_0_2[i].status = 2;
	i++;
	//f97 0x90,0x10
	fn_dlt_0_2[i].Fn = 97;
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0x90;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x1f;

	fn_dlt_0_2[i].dltnum = 1;
	fn_dlt_0_2[i].status = 2;
	i++;
	//f98 0x91,0x10
	fn_dlt_0_2[i].Fn = 98;
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0x91;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x1f;

	fn_dlt_0_2[i].dltnum = 1;
	fn_dlt_0_2[i].status = 2;
	i++;
	//f99 0x90,0x20
	fn_dlt_0_2[i].Fn = 99;
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0x90;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x2f;

	fn_dlt_0_2[i].dltnum = 1;
	fn_dlt_0_2[i].status = 2;
	i++;
	//f100 0x91,0x20
	fn_dlt_0_2[i].Fn = 100;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x2f;

	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0x91;

	fn_dlt_0_2[i].dltnum = 1;
	fn_dlt_0_2[i].status = 2;
	i++;
	//f101 0x90,0x10
	fn_dlt_0_2[i].Fn = 101;

	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0x90;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x1f;

	fn_dlt_0_2[i].dltnum = 1;
	fn_dlt_0_2[i].status = 2;
	i++;
	//f102 0x91,0x10
	fn_dlt_0_2[i].Fn = 102;
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0x91;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x1f;

	fn_dlt_0_2[i].dltnum = 1;
	fn_dlt_0_2[i].status = 2;
	i++;
	//f103 0x90,0x20
	fn_dlt_0_2[i].Fn = 103;
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0x90;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x2f;
	fn_dlt_0_2[i].dltnum = 1;
	fn_dlt_0_2[i].status = 2;
	i++;
	//f104  0x91,0x20
	fn_dlt_0_2[i].Fn = 104;
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0x91;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x2f;

	fn_dlt_0_2[i].dltnum = 1;
	fn_dlt_0_2[i].status = 2;
	i++;
	//f105 0xb6,0x50
	fn_dlt_0_2[i].Fn = 105;
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0xb6;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x50;

	fn_dlt_0_2[i].dltnum = 1;
	fn_dlt_0_2[i].status = 2;
	i++;
	//f106 0xb6,0x51
	fn_dlt_0_2[i].Fn = 106;
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0xb6;
	//fn_dlt_0_2[i].DLT[0].Dataflag[0]=0x50;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x51;
	fn_dlt_0_2[i].dltnum = 1;
	fn_dlt_0_2[i].status = 2;
	i++;
	////////////////////////////////////////////////////////////////////////


	//////////////////////////////////////////////////////////////////////////////////
	//f107   0xB6 0x52
	fn_dlt_0_2[i].Fn = 107;
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0xB6;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x52;
	fn_dlt_0_2[i].dltnum = 1;
	fn_dlt_0_2[i].status = 2;

	i++; //f108 b6 53
	fn_dlt_0_2[i].Fn = 108;
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0xB6;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x53;
	fn_dlt_0_2[i].dltnum = 1;
	fn_dlt_0_2[i].status = 2;

	i++;
	fn_dlt_0_2[i].Fn = 109;//����
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0x2F;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x00;
	fn_dlt_0_2[i].dltnum = 1;

	fn_dlt_0_2[i].status = 2;

	i++;
	fn_dlt_0_2[i].Fn = 110;//����
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0x0F;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x00;
	fn_dlt_0_2[i].dltnum = 1;
	fn_dlt_0_2[i].status = 2;

	i++;
	fn_dlt_0_2[i].Fn = 145; //0x91,0x30
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x30;
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0x91;
	fn_dlt_0_2[i].dltnum = 1;
	fn_dlt_0_2[i].status = 2;
	i++;
	fn_dlt_0_2[i].Fn = 146; //0x91,0x40
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x40;
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0x91;
	fn_dlt_0_2[i].dltnum = 1;
	fn_dlt_0_2[i].status = 2;
	i++;
	fn_dlt_0_2[i].Fn = 147; //0x91,0x50
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x50;
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0x91;
	fn_dlt_0_2[i].dltnum = 1;
	fn_dlt_0_2[i].status = 2;
	i++;
	fn_dlt_0_2[i].Fn = 148; //0x91,0x60
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x60;
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0x91;
	fn_dlt_0_2[i].dltnum = 1;
	fn_dlt_0_2[i].status = 2;

	i++; //fb 01   fb 02   90 1f
	fn_dlt_0_2[i].Fn = 161;
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0xfb;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_0_2[i].DLT[1].Dataflag[1] = 0xfb;
	fn_dlt_0_2[i].DLT[1].Dataflag[0] = 0x02;
	fn_dlt_0_2[i].DLT[2].Dataflag[1] = 0x90;
	fn_dlt_0_2[i].DLT[2].Dataflag[0] = 0x1f;
	fn_dlt_0_2[i].dltnum = 3;
	fn_dlt_0_2[i].status = 1;
	i++; // fb 01   fb 04   91 1f
	fn_dlt_0_2[i].Fn = 162;
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0xfb;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_0_2[i].DLT[1].Dataflag[1] = 0xfb;
	fn_dlt_0_2[i].DLT[1].Dataflag[0] = 0x04;
	fn_dlt_0_2[i].DLT[2].Dataflag[1] = 0x91;
	fn_dlt_0_2[i].DLT[2].Dataflag[0] = 0x1f;
	fn_dlt_0_2[i].dltnum = 3;
	fn_dlt_0_2[i].status = 1;
	i++; //fb 01    fb 03   90 2f
	fn_dlt_0_2[i].Fn = 163;
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0xfb;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_0_2[i].DLT[1].Dataflag[1] = 0xfb;
	fn_dlt_0_2[i].DLT[1].Dataflag[0] = 0x03;
	fn_dlt_0_2[i].DLT[2].Dataflag[1] = 0x90;
	fn_dlt_0_2[i].DLT[2].Dataflag[0] = 0x2f;
	fn_dlt_0_2[i].dltnum = 3;
	fn_dlt_0_2[i].status = 1;
	i++; //fb  01     fb  05     91  2f
	fn_dlt_0_2[i].Fn = 164;
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0xfb;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_0_2[i].DLT[1].Dataflag[1] = 0xfb;
	fn_dlt_0_2[i].DLT[1].Dataflag[0] = 0x05;
	fn_dlt_0_2[i].DLT[2].Dataflag[1] = 0x91;
	fn_dlt_0_2[i].DLT[2].Dataflag[0] = 0x2f;
	fn_dlt_0_2[i].dltnum = 3;
	fn_dlt_0_2[i].status = 1;


	i++;// fc 01   fc 02   90 1f
	fn_dlt_0_2[i].Fn = 177;
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0xfb;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_0_2[i].DLT[1].Dataflag[1] = 0xfb;
	fn_dlt_0_2[i].DLT[1].Dataflag[0] = 0x02;
	fn_dlt_0_2[i].DLT[2].Dataflag[1] = 0x90;
	fn_dlt_0_2[i].DLT[2].Dataflag[0] = 0x1f;
	fn_dlt_0_2[i].dltnum = 3;
	fn_dlt_0_2[i].status = 1;
	i++;// fc 01  fc 04  91 1f
	fn_dlt_0_2[i].Fn = 178;
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0xfc;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_0_2[i].DLT[1].Dataflag[1] = 0xfc;
	fn_dlt_0_2[i].DLT[1].Dataflag[0] = 0x04;
	fn_dlt_0_2[i].DLT[2].Dataflag[1] = 0x91;
	fn_dlt_0_2[i].DLT[2].Dataflag[0] = 0x1f;
	fn_dlt_0_2[i].dltnum = 3;
	fn_dlt_0_2[i].status = 1;
	i++;// fc 01   fc 03   90 2f
	fn_dlt_0_2[i].Fn = 179;
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0xfc;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_0_2[i].DLT[1].Dataflag[1] = 0xfc;
	fn_dlt_0_2[i].DLT[1].Dataflag[0] = 0x03;
	fn_dlt_0_2[i].DLT[2].Dataflag[1] = 0x90;
	fn_dlt_0_2[i].DLT[2].Dataflag[0] = 0x2f;
	fn_dlt_0_2[i].dltnum = 3;
	fn_dlt_0_2[i].status = 1;
	i++;//fc 01  fc 05   91 2f
	fn_dlt_0_2[i].Fn = 180;
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0xfc;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_0_2[i].DLT[1].Dataflag[1] = 0xfc;
	fn_dlt_0_2[i].DLT[1].Dataflag[0] = 0x05;
	fn_dlt_0_2[i].DLT[2].Dataflag[1] = 0x91;
	fn_dlt_0_2[i].DLT[2].Dataflag[0] = 0x2f;
	fn_dlt_0_2[i].dltnum = 3;
	fn_dlt_0_2[i].status = 1;

	i++;// fb 01   fb 10   a0 10   b0 10
	fn_dlt_0_2[i].Fn = 185;
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0xfb;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_0_2[i].DLT[1].Dataflag[1] = 0xfb;
	fn_dlt_0_2[i].DLT[1].Dataflag[0] = 0x10;
	fn_dlt_0_2[i].DLT[2].Dataflag[1] = 0xa0;
	fn_dlt_0_2[i].DLT[2].Dataflag[0] = 0x1f;
	fn_dlt_0_2[i].DLT[3].Dataflag[1] = 0xb0;
	fn_dlt_0_2[i].DLT[3].Dataflag[0] = 0x1f;
	fn_dlt_0_2[i].dltnum = 4;
	fn_dlt_0_2[i].status = 1;
	i++;// a0 20+j   b0 20+j
	fn_dlt_0_2[i].Fn = 187;
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0xa0;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x2f;
	fn_dlt_0_2[i].DLT[1].Dataflag[1] = 0xb0;
	fn_dlt_0_2[i].DLT[1].Dataflag[0] = 0x2f;
	fn_dlt_0_2[i].dltnum = 2;
	fn_dlt_0_2[i].status = 1;
	i++;


	fn_dlt_0_2[i].Fn = 193;
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0xFc;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_0_2[i].DLT[1].Dataflag[1] = 0xfc;
	fn_dlt_0_2[i].DLT[1].Dataflag[0] = 0x10;
	fn_dlt_0_2[i].DLT[2].Dataflag[1] = 0xA0;
	fn_dlt_0_2[i].DLT[2].Dataflag[0] = 0x10;
	fn_dlt_0_2[i].DLT[3].Dataflag[1] = 0xB0;
	fn_dlt_0_2[i].DLT[3].Dataflag[0] = 0x10;
	fn_dlt_0_2[i].dltnum = 4;
	fn_dlt_0_2[i].status = 1;
	i++;// a0 10   b0 10
	fn_dlt_0_2[i].Fn = 195; //meiyou
	fn_dlt_0_2[i].DLT[0].Dataflag[1] = 0xa0;
	fn_dlt_0_2[i].DLT[0].Dataflag[0] = 0x10;
	fn_dlt_0_2[i].DLT[1].Dataflag[1] = 0xb0;
	fn_dlt_0_2[i].DLT[1].Dataflag[0] = 0x10;
	fn_dlt_0_2[i].dltnum = 2;
	fn_dlt_0_2[i].status = 1;
	i++;
	fprintf(stderr,"\n------fn_dlt_0_2-------all  %d-----------------\n",i);
	return;
}
void fuzhi_6_2(Fn_DLT *fn_dlt_6_2) {
	int i = 0;
	//f1 0xFB,0x01 0xFB,0x02 0xFB,0x04 0xFB,0x05 0xFB,0x06 0x90,0x10 0x91,0x10
	//0x91,0x30 0x91,0x40
	fn_dlt_6_2[i].Fn = 1;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xFB;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_6_2[i].DLT[1].Dataflag[1] = 0xFB;
	fn_dlt_6_2[i].DLT[1].Dataflag[0] = 0x02;
	fn_dlt_6_2[i].DLT[2].Dataflag[1] = 0xFB;
	fn_dlt_6_2[i].DLT[2].Dataflag[0] = 0x04;
	fn_dlt_6_2[i].DLT[3].Dataflag[1] = 0xFB;
	fn_dlt_6_2[i].DLT[3].Dataflag[0] = 0x05;
	fn_dlt_6_2[i].DLT[4].Dataflag[1] = 0xFB;
	fn_dlt_6_2[i].DLT[4].Dataflag[0] = 0x06;
	fn_dlt_6_2[i].DLT[5].Dataflag[1] = 0x90;
	fn_dlt_6_2[i].DLT[5].Dataflag[0] = 0x1f;
	fn_dlt_6_2[i].DLT[6].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[6].Dataflag[0] = 0x1f;
	fn_dlt_6_2[i].DLT[7].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[7].Dataflag[0] = 0x3f;
	fn_dlt_6_2[i].DLT[8].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[8].Dataflag[0] = 0x4f;
	fn_dlt_6_2[i].dltnum = 9;
	fn_dlt_6_2[i].status = 0;

	i++;
	//f2 0x90,0x20 0x91,0x20 0x91,0x50 0x91,0x60

	fn_dlt_6_2[i].Fn = 2;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0x90;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x2F;
	fn_dlt_6_2[i].DLT[1].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[1].Dataflag[0] = 0x2F;
	fn_dlt_6_2[i].DLT[2].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[2].Dataflag[0] = 0x5F;
	fn_dlt_6_2[i].DLT[3].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[3].Dataflag[0] = 0x6F;
	fn_dlt_6_2[i].dltnum = 4;
	fn_dlt_6_2[i].status = 0;
	i++;
	//f5 0x90,0x10
	fn_dlt_6_2[i].Fn = 5;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0x90;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x1F;

	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 0;
	i++;
	//f6 0x91,0x10
	fn_dlt_6_2[i].Fn = 6;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x1F;

	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 0;
	i++;
	//f7 0x90,0x20
	fn_dlt_6_2[i].Fn = 7;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0x90;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x2F;

	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 0;
	i++;
	//f8 0x91,0x20
	fn_dlt_6_2[i].Fn = 8;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x2F;

	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 0;
	i++;
	//f9 0xFB,0x01 0xFB,0x02 0xFB,0x04 0xFB,0x05 0xFB,0x06 0x90,0x10 0x91,0x10
	//0x91,0x30 0x91,0x40
	fn_dlt_6_2[i].Fn = 9;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xFB;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_6_2[i].DLT[1].Dataflag[1] = 0xFB;
	fn_dlt_6_2[i].DLT[1].Dataflag[0] = 0x02;
	fn_dlt_6_2[i].DLT[2].Dataflag[1] = 0xFB;
	fn_dlt_6_2[i].DLT[2].Dataflag[0] = 0x04;
	fn_dlt_6_2[i].DLT[3].Dataflag[1] = 0xFB;
	fn_dlt_6_2[i].DLT[3].Dataflag[0] = 0x05;
	fn_dlt_6_2[i].DLT[4].Dataflag[1] = 0xFB;
	fn_dlt_6_2[i].DLT[4].Dataflag[0] = 0x06;
	fn_dlt_6_2[i].DLT[5].Dataflag[1] = 0x90;
	fn_dlt_6_2[i].DLT[5].Dataflag[0] = 0x1f;
	fn_dlt_6_2[i].DLT[6].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[6].Dataflag[0] = 0x1f;
	fn_dlt_6_2[i].DLT[7].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[7].Dataflag[0] = 0x3f;
	fn_dlt_6_2[i].DLT[8].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[8].Dataflag[0] = 0x4f;
	fn_dlt_6_2[i].dltnum = 9;
	fn_dlt_6_2[i].status = 0;
	i++;
	//f10 0x90,0x20 0x91,0x20 0x91,0x50 0x91,0x60
	fn_dlt_6_2[i].Fn = 10;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0x90;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x2f;
	fn_dlt_6_2[i].DLT[1].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[1].Dataflag[0] = 0x2f;
	fn_dlt_6_2[i].DLT[2].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[2].Dataflag[0] = 0x5f;
	fn_dlt_6_2[i].DLT[3].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[3].Dataflag[0] = 0x6f;
	fn_dlt_6_2[i].dltnum = 4;
	fn_dlt_6_2[i].status = 0;
	i++;
	//f17 0x90,0x10 0x91,0x10 0x91,0x30 0x91,0x40
	fn_dlt_6_2[i].Fn = 17;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0x90;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x1f;
	fn_dlt_6_2[i].DLT[1].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[1].Dataflag[0] = 0x1f;
	fn_dlt_6_2[i].DLT[2].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[2].Dataflag[0] = 0x3f;
	fn_dlt_6_2[i].DLT[3].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[3].Dataflag[0] = 0x4f;
	fn_dlt_6_2[i].dltnum = 4;
	fn_dlt_6_2[i].status = 0;
	i++;
	//f18 0x90,0x20 0x91,0x20 0x91,0x50 0x91,0x60
	fn_dlt_6_2[i].Fn = 18;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0x90;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x2f;
	fn_dlt_6_2[i].DLT[1].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[1].Dataflag[0] = 0x2f;
	fn_dlt_6_2[i].DLT[2].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[2].Dataflag[0] = 0x5f;
	fn_dlt_6_2[i].DLT[3].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[3].Dataflag[0] = 0x6f;

	fn_dlt_6_2[i].dltnum = 4;
	fn_dlt_6_2[i].status = 0;
	i++;
	//f21 0x90,0x10
	fn_dlt_6_2[i].Fn = 21;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0x90;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x1f;

	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 0;
	i++;
	//f22 0x91,0x10
	fn_dlt_6_2[i].Fn = 22;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x1f;

	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 0;
	i++;
	//f23 0x90,0x20
	fn_dlt_6_2[i].Fn = 23;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0x90;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x2f;

	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 0;
	i++;
	//f24  0x91,0x20
	fn_dlt_6_2[i].Fn = 24;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x2f;

	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 0;
	i++;

	//f81 0xb6,0x30
	fn_dlt_6_2[i].Fn = 81;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x30;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xb6;

	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 1;
	i++;
	//f82 0xb6,0x31
	fn_dlt_6_2[i].Fn = 82;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x31;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xb6;

	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 1;
	i++;
	//f83 0xb6,0x32
	fn_dlt_6_2[i].Fn = 83;
	//	fn_dlt_6_2[i].DLT[0].Dataflag[0]=0x31;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xb6;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x32;
	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 1;
	i++;
	//f84 0xb6,0x33
	fn_dlt_6_2[i].Fn = 84;
	//	fn_dlt_6_2[i].DLT[0].Dataflag[0]=0x31;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x33;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xb6;

	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 1;
	i++;
	//f85 0xb6,0x40
	fn_dlt_6_2[i].Fn = 85;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x40;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xb6;

	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 1;
	i++;
	//f86 0xb6,0x41
	fn_dlt_6_2[i].Fn = 86;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x41;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xb6;

	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 1;
	i++;
	//f87 0xb6,0x42
	fn_dlt_6_2[i].Fn = 87;
	//	fn_dlt_6_2[i].DLT[0].Dataflag[1]=0x41;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xb6;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x42;
	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 1;
	i++;
	//f88 0xb6,0x43
	fn_dlt_6_2[i].Fn = 88;
	//	fn_dlt_6_2[i].DLT[0].Dataflag[0]=0x41;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xb6;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x43;
	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 1;
	i++;
	//f89 0xb6,0x11
	fn_dlt_6_2[i].Fn = 89;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x11;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xb6;

	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 1;
	i++;
	//f90 0xb6,0x12
	fn_dlt_6_2[i].Fn = 90;
	//	fn_dlt_6_2[i].DLT[0].Dataflag[0]=0x11;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xb6;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x12;
	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 1;
	i++;
	//f91 0xb6,0x13
	fn_dlt_6_2[i].Fn = 91;
	//	fn_dlt_6_2[i].DLT[0].Dataflag[0]=0x11;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xb6;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x13;
	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 1;
	i++;
	//f92 0xb6,0x21
	fn_dlt_6_2[i].Fn = 92;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xb6;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x21;
	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 1;
	i++;
	//f93 0xb6,0x22
	fn_dlt_6_2[i].Fn = 93;
	//	fn_dlt_6_2[i].DLT[0].Dataflag[0]=0x21;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xb6;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x22;
	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 1;
	i++;
	//f94 0xb6,0x23
	fn_dlt_6_2[i].Fn = 94;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xb6;
	//	fn_dlt_6_2[i].DLT[0].Dataflag[0]=0x21;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x23;
	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 1;
	i++;
	//f95 0xb6,0x24
	fn_dlt_6_2[i].Fn = 95;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xb6;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x24;
	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 1;
	i++;
	//f97 0x90,0x10
	fn_dlt_6_2[i].Fn = 97;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0x90;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x1f;

	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 0;
	i++;
	//f98 0x91,0x10
	fn_dlt_6_2[i].Fn = 98;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x1f;

	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 0;
	i++;
	//f99 0x90,0x20
	fn_dlt_6_2[i].Fn = 99;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0x90;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x2f;

	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 0;
	i++;
	//f100 0x91,0x20
	fn_dlt_6_2[i].Fn = 100;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x2f;

	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0x91;

	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 0;
	i++;
	//f101 0x90,0x10
	fn_dlt_6_2[i].Fn = 101;

	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0x90;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x1f;

	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 1;
	i++;
	//f102 0x91,0x10
	fn_dlt_6_2[i].Fn = 102;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x1f;

	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 1;
	i++;
	//f103 0x90,0x20
	fn_dlt_6_2[i].Fn = 103;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0x90;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x2f;
	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 1;
	i++;
	//f104  0x91,0x20
	fn_dlt_6_2[i].Fn = 104;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x2f;

	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 1;
	i++;
	//f105 0xb6,0x50
	fn_dlt_6_2[i].Fn = 105;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xb6;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x5f;

	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 1;
	i++;
	//f106 0xb6,0x51
	fn_dlt_6_2[i].Fn = 106;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xb6;
	//fn_dlt_6_2[i].DLT[0].Dataflag[0]=0x50;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x51;
	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 1;
	i++;

	//////////////////////////////////////////////////////////////////////////////////


	//////////////////////////////////////////////////////////////////////////////////
	//f107   0xB6 0x52
	fn_dlt_6_2[i].Fn = 107;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xB6;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x52;
	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 1;

	i++; //f108 b6 53
	fn_dlt_6_2[i].Fn = 108;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xB6;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x53;
	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 1;

	i++;
	fn_dlt_6_2[i].Fn = 109;//
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0x2F;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x00;
	fn_dlt_6_2[i].dltnum = 1;

	fn_dlt_6_2[i].status = 1;

	i++;
	fn_dlt_6_2[i].Fn = 110;//
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0x0F;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x00;
	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 1;

	i++;
	fn_dlt_6_2[i].Fn = 145; //0x91,0x30
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x3f;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 1;
	i++;
	fn_dlt_6_2[i].Fn = 146; //0x91,0x40
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x4f;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 1;
	i++;
	fn_dlt_6_2[i].Fn = 147; //0x91,0x50
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x5f;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 1;
	i++;
	fn_dlt_6_2[i].Fn = 148; //0x91,0x60
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x6f;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 1;
	i++;
	fn_dlt_6_2[i].Fn = 153; //0xFF,0xC0 0xFF,0xC4 0xFF,0xC8
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xc0;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0xff;
	fn_dlt_6_2[i].DLT[1].Dataflag[1] = 0xc4;
	fn_dlt_6_2[i].DLT[1].Dataflag[0] = 0xff;
	fn_dlt_6_2[i].DLT[2].Dataflag[1] = 0xc8;
	fn_dlt_6_2[i].DLT[2].Dataflag[0] = 0xff;
	fn_dlt_6_2[i].dltnum = 3;
	fn_dlt_6_2[i].status = 1;
	i++;
	fn_dlt_6_2[i].Fn = 154; //0xFF,0xC2 0xFF,0xC6 0xFF,0xCA
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xc2;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0xff;
	fn_dlt_6_2[i].DLT[1].Dataflag[1] = 0xc6;
	fn_dlt_6_2[i].DLT[1].Dataflag[0] = 0xff;
	fn_dlt_6_2[i].DLT[2].Dataflag[1] = 0xca;
	fn_dlt_6_2[i].DLT[2].Dataflag[0] = 0xff;
	fn_dlt_6_2[i].dltnum = 3;
	fn_dlt_6_2[i].status = 1;
	i++;
	fn_dlt_6_2[i].Fn = 155; //0xFF,0xC1 0xFF,0xC5 0xFF,0xC9
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xc1;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0xff;
	fn_dlt_6_2[i].DLT[1].Dataflag[1] = 0xc5;
	fn_dlt_6_2[i].DLT[1].Dataflag[0] = 0xff;
	fn_dlt_6_2[i].DLT[2].Dataflag[1] = 0xc9;
	fn_dlt_6_2[i].DLT[2].Dataflag[0] = 0xff;
	fn_dlt_6_2[i].dltnum = 3;
	fn_dlt_6_2[i].status = 1;
	i++;
	fn_dlt_6_2[i].Fn = 156; //0xFF,0xC3 0xFF,0xC7 0xFF,0xCB
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xc3;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0xff;
	fn_dlt_6_2[i].DLT[1].Dataflag[1] = 0xc7;
	fn_dlt_6_2[i].DLT[1].Dataflag[0] = 0xff;
	fn_dlt_6_2[i].DLT[2].Dataflag[1] = 0xcb;
	fn_dlt_6_2[i].DLT[2].Dataflag[0] = 0xff;
	fn_dlt_6_2[i].dltnum = 3;
	fn_dlt_6_2[i].status = 1;
	i++;
	fn_dlt_6_2[i].Fn = 157; //0xff,0xc0 0xff,0xc4 0xff,0xc8
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xc0;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0xff;
	fn_dlt_6_2[i].DLT[1].Dataflag[1] = 0xc4;
	fn_dlt_6_2[i].DLT[1].Dataflag[0] = 0xff;
	fn_dlt_6_2[i].DLT[2].Dataflag[1] = 0xc8;
	fn_dlt_6_2[i].DLT[2].Dataflag[0] = 0xff;
	fn_dlt_6_2[i].dltnum = 3;
	fn_dlt_6_2[i].status = 1;
	i++;
	fn_dlt_6_2[i].Fn = 158; //0xff,0xc2 0xff,0xc6 0xff,0xca
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xc2;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0xff;
	fn_dlt_6_2[i].DLT[1].Dataflag[1] = 0xc6;
	fn_dlt_6_2[i].DLT[1].Dataflag[0] = 0xff;
	fn_dlt_6_2[i].DLT[2].Dataflag[1] = 0xca;
	fn_dlt_6_2[i].DLT[2].Dataflag[0] = 0xff;
	fn_dlt_6_2[i].dltnum = 3;
	fn_dlt_6_2[i].status = 1;
	i++;
	fn_dlt_6_2[i].Fn = 159; //0xff,0xc1 0xff,0xc5 0xff,0xc9
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xc1;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0xff;
	fn_dlt_6_2[i].DLT[1].Dataflag[1] = 0xc5;
	fn_dlt_6_2[i].DLT[1].Dataflag[0] = 0xff;
	fn_dlt_6_2[i].DLT[2].Dataflag[1] = 0xc9;
	fn_dlt_6_2[i].DLT[2].Dataflag[0] = 0xff;
	fn_dlt_6_2[i].dltnum = 3;
	fn_dlt_6_2[i].status = 1;
	i++;
	fn_dlt_6_2[i].Fn = 160; //0xff,0xc3 0xff,0xc7 0xff,0xcb
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xc3;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0xff;
	fn_dlt_6_2[i].DLT[1].Dataflag[1] = 0xc7;
	fn_dlt_6_2[i].DLT[1].Dataflag[0] = 0xff;
	fn_dlt_6_2[i].DLT[2].Dataflag[1] = 0xcb;
	fn_dlt_6_2[i].DLT[2].Dataflag[0] = 0xff;
	fn_dlt_6_2[i].dltnum = 3;
	fn_dlt_6_2[i].status = 1;
	i++; //fb 01   fb 02   90 1f
	fn_dlt_6_2[i].Fn = 161;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xfb;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_6_2[i].DLT[1].Dataflag[1] = 0xfb;
	fn_dlt_6_2[i].DLT[1].Dataflag[0] = 0x02;
	fn_dlt_6_2[i].DLT[2].Dataflag[1] = 0x90;
	fn_dlt_6_2[i].DLT[2].Dataflag[0] = 0x1f;
	fn_dlt_6_2[i].dltnum = 3;
	fn_dlt_6_2[i].status = 1;
	i++; // fb 01   fb 04   91 1f
	fn_dlt_6_2[i].Fn = 162;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xfb;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_6_2[i].DLT[1].Dataflag[1] = 0xfb;
	fn_dlt_6_2[i].DLT[1].Dataflag[0] = 0x04;
	fn_dlt_6_2[i].DLT[2].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[2].Dataflag[0] = 0x1f;
	fn_dlt_6_2[i].dltnum = 3;
	fn_dlt_6_2[i].status = 1;
	i++; //fb 01    fb 03   90 2f
	fn_dlt_6_2[i].Fn = 163;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xfb;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_6_2[i].DLT[1].Dataflag[1] = 0xfb;
	fn_dlt_6_2[i].DLT[1].Dataflag[0] = 0x03;
	fn_dlt_6_2[i].DLT[2].Dataflag[1] = 0x90;
	fn_dlt_6_2[i].DLT[2].Dataflag[0] = 0x2f;
	fn_dlt_6_2[i].dltnum = 3;
	fn_dlt_6_2[i].status = 1;
	i++; //fb  01     fb  05     91  2f
	fn_dlt_6_2[i].Fn = 164;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xfb;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_6_2[i].DLT[1].Dataflag[1] = 0xfb;
	fn_dlt_6_2[i].DLT[1].Dataflag[0] = 0x05;
	fn_dlt_6_2[i].DLT[2].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[2].Dataflag[0] = 0x2f;
	fn_dlt_6_2[i].dltnum = 3;
	fn_dlt_6_2[i].status = 1;
	i++;// fb 01  fb 06  91 3f
	fn_dlt_6_2[i].Fn = 165;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xfb;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_6_2[i].DLT[1].Dataflag[1] = 0xfb;
	fn_dlt_6_2[i].DLT[1].Dataflag[0] = 0x06;
	fn_dlt_6_2[i].DLT[2].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[2].Dataflag[0] = 0x3f;
	fn_dlt_6_2[i].dltnum = 3;
	fn_dlt_6_2[i].status = 1;
	i++; // fb 01 fb 07 91 5f
	fn_dlt_6_2[i].Fn = 166;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xfb;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_6_2[i].DLT[1].Dataflag[1] = 0xfb;
	fn_dlt_6_2[i].DLT[1].Dataflag[0] = 0x07;
	fn_dlt_6_2[i].DLT[2].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[2].Dataflag[0] = 0x5f;
	fn_dlt_6_2[i].dltnum = 3;
	fn_dlt_6_2[i].status = 1;
	i++; //fb 01   fb 08   91 6f
	fn_dlt_6_2[i].Fn = 167;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xfb;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_6_2[i].DLT[1].Dataflag[1] = 0xfb;
	fn_dlt_6_2[i].DLT[1].Dataflag[0] = 0x08;
	fn_dlt_6_2[i].DLT[2].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[2].Dataflag[0] = 0x6f;
	fn_dlt_6_2[i].dltnum = 3;
	fn_dlt_6_2[i].status = 1;
	i++;// fb 01   fb 09   91 4f
	fn_dlt_6_2[i].Fn = 168;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xfb;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_6_2[i].DLT[1].Dataflag[1] = 0xfb;
	fn_dlt_6_2[i].DLT[1].Dataflag[0] = 0x09;
	fn_dlt_6_2[i].DLT[2].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[2].Dataflag[0] = 0x4f;
	fn_dlt_6_2[i].dltnum = 3;
	fn_dlt_6_2[i].status = 1;
	i++;// fb 01   94 1f   90 1f
	fn_dlt_6_2[i].Fn = 169;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xfb;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_6_2[i].DLT[1].Dataflag[1] = 0x94;
	fn_dlt_6_2[i].DLT[1].Dataflag[0] = 0x1f;
	fn_dlt_6_2[i].DLT[2].Dataflag[1] = 0x90;
	fn_dlt_6_2[i].DLT[2].Dataflag[0] = 0x1f;
	fn_dlt_6_2[i].dltnum = 3;
	fn_dlt_6_2[i].status = 0;
	i++;// fb 01   95 1f   91 10
	fn_dlt_6_2[i].Fn = 170;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xfb;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_6_2[i].DLT[1].Dataflag[1] = 0x95;
	fn_dlt_6_2[i].DLT[1].Dataflag[0] = 0x1f;
	fn_dlt_6_2[i].DLT[2].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[2].Dataflag[0] = 0x1f;
	fn_dlt_6_2[i].dltnum = 3;
	fn_dlt_6_2[i].status = 0;
	i++;
	fn_dlt_6_2[i].Fn = 171;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0x90;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x2f;
	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 0;
	i++;
	fn_dlt_6_2[i].Fn = 172;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x2f;
	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 0;
	i++;
	fn_dlt_6_2[i].Fn = 173;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x3f;
	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 0;
	i++;
	fn_dlt_6_2[i].Fn = 174;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x5f;
	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 0;
	i++;
	fn_dlt_6_2[i].Fn = 175;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x6f;
	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 0;
	i++;
	fn_dlt_6_2[i].Fn = 176;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x4f;
	fn_dlt_6_2[i].dltnum = 1;
	fn_dlt_6_2[i].status = 0;
	i++;// fc 01   fc 02   90 1f
	fn_dlt_6_2[i].Fn = 177;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xfb;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_6_2[i].DLT[1].Dataflag[1] = 0xfb;
	fn_dlt_6_2[i].DLT[1].Dataflag[0] = 0x02;
	fn_dlt_6_2[i].DLT[2].Dataflag[1] = 0x90;
	fn_dlt_6_2[i].DLT[2].Dataflag[0] = 0x1f;
	fn_dlt_6_2[i].dltnum = 3;
	fn_dlt_6_2[i].status = 1;
	i++;// fc 01  fc 04  91 1f
	fn_dlt_6_2[i].Fn = 178;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xfc;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_6_2[i].DLT[1].Dataflag[1] = 0xfc;
	fn_dlt_6_2[i].DLT[1].Dataflag[0] = 0x04;
	fn_dlt_6_2[i].DLT[2].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[2].Dataflag[0] = 0x1f;
	fn_dlt_6_2[i].dltnum = 3;
	fn_dlt_6_2[i].status = 1;
	i++;// fc 01   fc 03   90 2f
	fn_dlt_6_2[i].Fn = 179;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xfc;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_6_2[i].DLT[1].Dataflag[1] = 0xfc;
	fn_dlt_6_2[i].DLT[1].Dataflag[0] = 0x03;
	fn_dlt_6_2[i].DLT[2].Dataflag[1] = 0x90;
	fn_dlt_6_2[i].DLT[2].Dataflag[0] = 0x2f;
	fn_dlt_6_2[i].dltnum = 3;
	fn_dlt_6_2[i].status = 1;
	i++;//fc 01  fc 05   91 2f
	fn_dlt_6_2[i].Fn = 180;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xfc;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_6_2[i].DLT[1].Dataflag[1] = 0xfc;
	fn_dlt_6_2[i].DLT[1].Dataflag[0] = 0x05;
	fn_dlt_6_2[i].DLT[2].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[2].Dataflag[0] = 0x2f;
	fn_dlt_6_2[i].dltnum = 3;
	fn_dlt_6_2[i].status = 1;
	i++;// fc 01   fc 06   91 3f
	fn_dlt_6_2[i].Fn = 181;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xfc;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_6_2[i].DLT[1].Dataflag[1] = 0xfc;
	fn_dlt_6_2[i].DLT[1].Dataflag[0] = 0x06;
	fn_dlt_6_2[i].DLT[2].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[2].Dataflag[0] = 0x3f;
	fn_dlt_6_2[i].dltnum = 3;
	fn_dlt_6_2[i].status = 1;
	i++;// fc 01   fc 07   91 5f
	fn_dlt_6_2[i].Fn = 182;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xfc;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_6_2[i].DLT[1].Dataflag[1] = 0xfc;
	fn_dlt_6_2[i].DLT[1].Dataflag[0] = 0x07;
	fn_dlt_6_2[i].DLT[2].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[2].Dataflag[0] = 0x5f;
	fn_dlt_6_2[i].dltnum = 3;
	fn_dlt_6_2[i].status = 1;
	i++;// fc 01   fc 08   91 6f
	fn_dlt_6_2[i].Fn = 183;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xfc;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_6_2[i].DLT[1].Dataflag[1] = 0xfc;
	fn_dlt_6_2[i].DLT[1].Dataflag[0] = 0x08;
	fn_dlt_6_2[i].DLT[2].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[2].Dataflag[0] = 0x6f;
	fn_dlt_6_2[i].dltnum = 3;
	fn_dlt_6_2[i].status = 1;
	i++;// fc 01   fc 09   91 4f
	fn_dlt_6_2[i].Fn = 184;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xfc;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_6_2[i].DLT[1].Dataflag[1] = 0xfc;
	fn_dlt_6_2[i].DLT[1].Dataflag[0] = 0x09;
	fn_dlt_6_2[i].DLT[2].Dataflag[1] = 0x91;
	fn_dlt_6_2[i].DLT[2].Dataflag[0] = 0x4f;
	fn_dlt_6_2[i].dltnum = 3;
	fn_dlt_6_2[i].status = 1;
	i++;// fb 01   fb 10   a0 10   b0 10
	fn_dlt_6_2[i].Fn = 185;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xfb;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_6_2[i].DLT[1].Dataflag[1] = 0xfb;
	fn_dlt_6_2[i].DLT[1].Dataflag[0] = 0x10;
	fn_dlt_6_2[i].DLT[2].Dataflag[1] = 0xa0;
	fn_dlt_6_2[i].DLT[2].Dataflag[0] = 0x1f;
	fn_dlt_6_2[i].DLT[3].Dataflag[1] = 0xb0;
	fn_dlt_6_2[i].DLT[3].Dataflag[0] = 0x1f;
	fn_dlt_6_2[i].dltnum = 4;
	fn_dlt_6_2[i].status = 1;
	i++;// a0 20+j   b0 20+j
	fn_dlt_6_2[i].Fn = 187;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xa0;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x2f;
	fn_dlt_6_2[i].DLT[1].Dataflag[1] = 0xb0;
	fn_dlt_6_2[i].DLT[1].Dataflag[0] = 0x2f;
	fn_dlt_6_2[i].dltnum = 12;
	fn_dlt_6_2[i].status = 1;
	i++;// a0 10+j   b0 10+j
	fn_dlt_6_2[i].Fn = 189;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xa0;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x1f;
	fn_dlt_6_2[i].DLT[1].Dataflag[1] = 0xb0;
	fn_dlt_6_2[i].DLT[1].Dataflag[0] = 0x1f;
	fn_dlt_6_2[i].dltnum = 12;
	fn_dlt_6_2[i].status = 0;
	i++;// a0 20+j   b0 20+j
	fn_dlt_6_2[i].Fn = 191;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xa0;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x2f;
	fn_dlt_6_2[i].DLT[1].Dataflag[1] = 0xb0;
	fn_dlt_6_2[i].DLT[1].Dataflag[0] = 0x2f;
	fn_dlt_6_2[i].dltnum = 12;
	fn_dlt_6_2[i].status = 0;
	i++;//fc 01   fc 10   a0 10   b0 10
	fn_dlt_6_2[i].Fn = 193;
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xFc;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x01;
	fn_dlt_6_2[i].DLT[1].Dataflag[1] = 0xfc;
	fn_dlt_6_2[i].DLT[1].Dataflag[0] = 0x10;
	fn_dlt_6_2[i].DLT[2].Dataflag[1] = 0xA0;
	fn_dlt_6_2[i].DLT[2].Dataflag[0] = 0x10;
	fn_dlt_6_2[i].DLT[3].Dataflag[1] = 0xB0;
	fn_dlt_6_2[i].DLT[3].Dataflag[0] = 0x10;
	fn_dlt_6_2[i].dltnum = 4;
	fn_dlt_6_2[i].status = 1;
	i++;// a0 10   b0 10
	fn_dlt_6_2[i].Fn = 195; //meiyou
	fn_dlt_6_2[i].DLT[0].Dataflag[1] = 0xa0;
	fn_dlt_6_2[i].DLT[0].Dataflag[0] = 0x10;
	fn_dlt_6_2[i].DLT[1].Dataflag[1] = 0xb0;
	fn_dlt_6_2[i].DLT[1].Dataflag[0] = 0x10;
	fn_dlt_6_2[i].dltnum = 2;
	fn_dlt_6_2[i].status = 1;
	i++;
	fprintf(stderr,"\n-------fn_dlt_6_2------all  %d-----------------\n",i);
}
