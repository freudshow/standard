#include <stdlib.h>
#include "DataFlags.h"
#include "jReadZB.h"
#include "ReadMeter.h"
#include <time.h>

#define  ERR0     0x00   //ͨѶ��ʱ
#define  ERR1     0x01	 //��Ч���ݵ�Ԫ
#define  ERR2     0x02   //���ȴ���
#define  ERR3     0x03	 //У�����
#define  ERR4     0x04	 //��Ϣ�಻����
#define  ERR5     0x05   //��ʽ����
#define  ERR6     0x06	 //�����ظ�
#define  ERR7     0x07   //���Ų���
#define  ERR8     0x08   //���Ӧ�ò���Ӧ��

CurMeters curMeters;
//CurMeters curMeters2;
DataFlag97 cflgn[ManyFlagsCount];
DataFlag97 mflgn[ManyFlagsCount];
DataFlag97 Le1flgComm[250][20];
DataFlag97 Le1flgMany[250][20];
INT8U reflg;
DataFiles df;
//DataFiles df2;
int gflgCount; //shanghai
void GetDt(INT8U Dt1, INT8U Dt2);
void GetDa(INT8U Da1, INT8U Da2);
extern unsigned char Dlt645GetVlueBy07(unsigned char *Addr,unsigned char DI0,unsigned char DI1,unsigned char *Dest);
extern unsigned char Dlt645GetVlue(unsigned char *Addr,unsigned char DI0,unsigned char DI1,unsigned char *Dest);
extern unsigned char Dlt6452007GetValueBy97(unsigned char *Addr,DataFlag97 *flg,unsigned char *Dest);//����
extern unsigned char Dlt645SHGetValueBy97(unsigned char *Addr,DataFlag97 *flg,unsigned char *Dest, int cldno);//����
extern unsigned char DltTran07GetValueBy97(INT16U P,unsigned char *Addr,DataFlag97 *flg,unsigned char *Dest);//shanghai
extern unsigned char DltTranGetVlueBy07(INT16U P,unsigned char *Addr,unsigned char DI0,unsigned char DI1,unsigned char *Dest);
extern unsigned char GetDlt645_2007Chars(unsigned char *,unsigned char *, unsigned char , unsigned char ,unsigned char , unsigned char );
extern unsigned char GetDlt645_97Chars(unsigned char *,unsigned char *, unsigned char , unsigned char );
extern unsigned char ReceiveFromCarr(unsigned char *);
extern void SendStrToCarr(unsigned char *,unsigned short );
extern void DataTrans();
extern unsigned char Dlt6452007Get97Vlue(DataFlag97 *flg, unsigned char *Dest);
extern INT8U Dlt645Get07Vlue(INT8U DI0,INT8U DI1,INT8U *Dest);//����
const INT8U CMP8U[9] = { 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80 };
INT8U	  DA[PointMax],DT[255];
int rset_read_ab_flg=0;					//�ϵ������ز���ʱ����

extern INT8U ZBMeterInf[PointMax][6];
extern void update485info();
extern void GetPtsfromZB();
extern void UpdateZBMeterInfo();
extern void RepMeter_auto(INT8U autoregtime);
extern void SearchMeterMain_auto(int autoregtime, int time1, int time2, int time3);
extern void update485info();
extern void MyAddZbPts();
extern void SearchMeterMain_autotime(int autoregtime, int time1);
//extern void AddZBPoints(int num);
unsigned char reboot_read(void);
fileinfo smfileinfo;
TS oldts_buchao,currts_buchao;//�����Ϻ�1�㵽4�㲹��

extern int GetDataFlagsbyLeihao(int cldno, DataFlag97 *flg97);
extern int RepeatDataflag_GuoLv(DataFlag97 *flg97, int num);
extern int dealGuiyueDataFlag(int cldno, DataFlag97 *flg97, int num);
extern void dealdataflag(DataFlag97 *flg97, int num);

INT8U mySaveFile(char *FileName, void *source, int size,ProgramInfo* JProgramInfo, fileinfo *fileinfo)
{
	DataFiles datafile;
	struct timespec tsspec;
	if (clock_gettime(CLOCK_REALTIME, &tsspec)==-1)
		printf("clock_gettime error\n\r");
	tsspec.tv_sec += 2;
	datafile.dataChanged = 1;
	memcpy(&datafile.filename, FileName, 128);
	datafile.filelen = size;
	datafile.fileinfo.cldno = fileinfo->cldno;
	datafile.fileinfo.ts = fileinfo->ts;
	datafile.fileinfo.filetype = fileinfo->filetype;
	memcpy(&datafile.manyFiles, (INT8U *)source, size);
	sem_timedwait(&JProgramInfo->mainData.UseCycleFlg, &tsspec);
	if((JProgramInfo->sm_tail-JProgramInfo->sm_head-1+SMBUFLEN)%SMBUFLEN>0)//�п�
	{
		fprintf(stderr,"\nmySaveFile = %s  datafile.fileinfo.cldno==%d  datafile.fileinfo.filetype==%d",
				FileName,datafile.fileinfo.cldno,datafile.fileinfo.filetype);
		memcpy(&JProgramInfo->sm[JProgramInfo->sm_head], &datafile, sizeof(DataFiles));
		JProgramInfo->sm_head = (JProgramInfo->sm_head+1)%SMBUFLEN;
		fprintf(stderr,"     JProgramInfo->sm_head==%d   JProgramInfo->sm_tail==%d\n",
				JProgramInfo->sm_head,JProgramInfo->sm_tail);
	}
	sem_post(&JProgramInfo->mainData.UseCycleFlg);
	return 1;
}

int getpt(int cjqno, int meterno)
{
	int k=0;
	for(k=0;k<PointMax;k++)
	{
		if( (JParamInfo3761->group2.f10[k].CjqNo==cjqno) &&
			(JParamInfo3761->group2.f10[k].MeterNo==meterno))
		{
			return k;
		}
	}
	return -1;
}
//���ݲ������ַ�ҵ��������
int getCld(INT8U *adr)
{
	int m,cldno=0;
	for(m=0; m<PointMax; m++)
	{
		ClearWaitTimes(ProjectNo,JProgramInfo);
		if(JParamInfo3761->group2.f10[m].Status!=1)
			continue;
		if ((JParamInfo3761->group2.f10[m].ConnectType!=1) &&
				(JParamInfo3761->group2.f10[m].ConnectType!=30)&&
				(JParamInfo3761->group2.f10[m].ConnectType!=21))     //1Ϊ97    30 Ϊ07
			continue;
		if ((JParamInfo3761->group2.f10[m].port!=CarrWavePort)&&(JParamInfo3761->group2.f10[m].port!=LocalCommPort))//
			continue;
		if(JParamInfo3761->group2.f10[m].ConnectType==21)
		{
			if(JParamInfo3761->group2.f10[m].Address[0]==adr[0] &&
				JParamInfo3761->group2.f10[m].Address[1]==adr[1] &&
				JParamInfo3761->group2.f10[m].Address[2]==adr[2] &&
				JParamInfo3761->group2.f10[m].Address[3]==adr[3] &&
				JParamInfo3761->group2.f10[m].Address[4]==adr[4])
			{
				cldno = m;
				break;
			}
		}else
		{
			if(JParamInfo3761->group2.f10[m].Address[0]==adr[0] &&
				JParamInfo3761->group2.f10[m].Address[1]==adr[1] &&
				JParamInfo3761->group2.f10[m].Address[2]==adr[2] &&
				JParamInfo3761->group2.f10[m].Address[3]==adr[3] &&
				JParamInfo3761->group2.f10[m].Address[4]==adr[4] &&
				JParamInfo3761->group2.f10[m].Address[5]==adr[5])
			{
				cldno = m;
				break;
			}
		}
	}
	return cldno;
}
//�Ƚϱ���ַ�Ƿ����
int cmpCldAdr(INT8U *adr1, INT8U *adr2, int guiyue)
{
	int ret=0;
	if(guiyue==21)
	{
		if(adr1[0]==adr2[0] &&adr1[1]==adr2[1] && adr1[2]==adr2[2] &&
			adr1[3]==adr2[3] &&	adr1[4]==adr2[4])
			ret = 1;
	}else
	{
		if(adr1[0]==adr2[0] &&adr1[1]==adr2[1] && adr1[2]==adr2[2] &&
			adr1[3]==adr2[3] &&	adr1[4]==adr2[4] &&	adr1[5]==adr2[5])
			ret = 1;
	}
	return ret;
}

int GetManyData(DataFlg *data,INT8U *reslutBuf,INT8U DI1,INT8U DI0)
{
	INT8U i,isFlag=0;
	for(i=0;i<ManyFlagsCount;i++)
	{
		if(data[i].flg.Dataflag[0]==DI0 && data[i].flg.Dataflag[1]==DI1){
            memcpy(reslutBuf,&data[i].datas[0],sizeof(data[i].datas));
            isFlag=1;
            break;
		}
	}
	if(isFlag==0)
	{
		for(i=0;i<ManyFlagsCount;i++)
		{
			if(data[i].flg.Dataflag[0]==(DI0|0x0f)&&data[i].flg.Dataflag[1]==DI1){
				memcpy(reslutBuf,&data[i].datas[0],sizeof(data[i].datas));
				isFlag=1;
				break;
			}
		}
	}
	if(isFlag==0){
		memset(reslutBuf,0xee,sizeof(data[0].datas));
		return 0;
	}
	return 1;
}
//��ʼ�������Ϣ
void InitMeterInfozb()
{
	int j = 0,i=0,tmp=0;
	INT8U TempFile[60];
	//memset(Jmemory->Points.f10.Count,0x00,2);
	//memset(&Jmemory->Points,0x00,sizeof(Jmemory->Points));

	for (j = 0; j < PointMax; j++)//��������Ϣ
	{
		if((JParamInfo3761->group2.f10[j].port==LocalCommPort||JParamInfo3761->group2.f10[j].port==CarrWavePort) && JParamInfo3761->group2.f10[j].Status==1)	//��ʼ��ָ���Ķ˿ں��²�����
		{
			JParamInfo3761->group2.f10[j].ConnectType=30;			//ͨ��Э������ 1 97 30 2007
			memset(JParamInfo3761->group2.f10[j].Address,0x00,6);			//ͨ�ŵ�ַ
			memset(JParamInfo3761->group2.f10[j].PassWord,0x00,6);			//ͨ������
			JParamInfo3761->group2.f10[j].FeiLvCnt=4;				//���ܷ��ʸ���
			JParamInfo3761->group2.f10[j].DecimalDigits=1;		//�й�����ʾֵ����λ��С��λ����
			memset(JParamInfo3761->group2.f10[j].CaijiqiAddress,0x00,6);	//�����ɼ���ͨ�ŵ�ַ
			JParamInfo3761->group2.f10[j].UserType=0;				//�û�����ż��û�С���
			JParamInfo3761->group2.f10[j].baudrate=0x08;				//SD������
			if(j == 0)
				JParamInfo3761->group2.f10[j].port=1;	//����  yangdong
			else
				JParamInfo3761->group2.f10[j].port=1+PortBegNum;					//SD�˿ں�
			JParamInfo3761->group2.f10[j].jiao_yan_wei=0x01;			//SDУ��λ
			JParamInfo3761->group2.f10[j].shu_ju_wei=0x08;			//SD����λ
			JParamInfo3761->group2.f10[j].ting_zhi_wei=0x01;			//SDֹͣλ
			for(i=0;i<64;i++)
				JParamInfo3761->group2.f10[j].AlarmFlg[i]=0x00;
			JParamInfo3761->group2.f10[j].Status=0;				//SD״̬

			JParamInfo3761->group2.f10[j].CjqNo=j/64+1;				//SD�ɼ���
			JParamInfo3761->group2.f10[j].MeterNo=j%64;			//SD�������
			JParamInfo3761->group2.f10[j].FirRead=0;
			JParamInfo3761->group2.f10[i].Type=9;
			tmp=1;
			JParamInfo3761->Point[i].f25.V_BeiLv[0]=1;
			JParamInfo3761->Point[i].f25.I_BeiLv[0]=1;

			memset(JParamInfo3761->group2.f10[i].PointIndex,0x00,2);

			JParamInfo3761->group2.f10[i].PointIndex[0]=(j+1)&0xff;
			JParamInfo3761->group2.f10[i].PointIndex[1]=((j+1)>>8)&0xff;
			memset(TempFile,0,60);
			sprintf((char*)TempFile,"%s/Ammeter%04d.par",_PARADIR_,j/SaveNum+1);
			fprintf(stderr,"TempFile=%s,j=%d\n\r",TempFile,j);
			NormalSaveFile((char*)TempFile,(INT8U *)&JParamInfo3761->group2.f10[j-(j%SaveNum)],
					sizeof(JParamInfo3761->group2.f10[j-(j%SaveNum)])*SaveNum,JProgramInfo);
		}
	}

//	memset(TempFile,0,60);
//	sprintf((char*)TempFile,"%s/AmmeterN.par",_PARADIR_);

	JProgramInfo->FileSaveFlag.g2flag = 1;
	//NormalSaveFile((char*)TempFile,(INT8U *)&Jmemory->Points,sizeof(Jmemory->Points),JProgramInfo);
}
//�������Ĳ���
void SaveMeterParazb(int flg){
	int i;
	INT8U TempBuf[60];
//	memset(TempBuf,0,60);
//	sprintf((char*)TempBuf,"%s/AmmeterOth.par",_PARADIR_);
	//NormalSaveFile((char*)TempBuf,(INT8U *)&JParamInfo3761->group5.f34,sizeof(JParamInfo3761->group5.f34)+sizeof(Jmemory->Points.f35),JProgramInfo);
	JProgramInfo->FileSaveFlag.g5flag = 1;
//	memset(TempBuf,0,60);
//	sprintf((char*)TempBuf,"%s/AmmeterN.par",_PARADIR_);
//	NormalSaveFile((char*)TempBuf,(INT8U *)&Jmemory->Points,sizeof(Jmemory->Points),JProgramInfo);
	JProgramInfo->FileSaveFlag.g2flag = 1;
	if (flg>PointMax)
	{
		for(i=0;i<PointMax;i++)
		{
//			if (JParamInfo3761->group2.f10[i].Status!=1)
//				continue;
			if ((i%SaveNum)==0)
			{
				memset(TempBuf,0,60);
				sprintf((char*)TempBuf,"%s/Ammeter%04d.par",_PARADIR_,(i/SaveNum)+1);
				NormalSaveFile((char*)TempBuf,(INT8U *)&JParamInfo3761->group2.f10[i-(i%SaveNum)],sizeof(JParamInfo3761->group2.f10[i-(i%SaveNum)])*SaveNum,JProgramInfo);
				delay(10);
			}
		}
	}
	else
	{
			memset(TempBuf,0,60);
			sprintf((char*)TempBuf,"%s/Ammeter%04d.par",_PARADIR_,((flg-1)/SaveNum)+1);

			NormalSaveFile((char*)TempBuf,(INT8U *)&JParamInfo3761->group2.f10[flg-1-((flg-1)%SaveNum)],sizeof(JParamInfo3761->group2.f10[flg-1-((flg-1)%SaveNum)])*SaveNum,JProgramInfo);
			delay(10);
	}
	delay(50);
}
void UpdateJZQMeterInfo()
{
	int i=0, k=0;
	int cldxuhao = 0;
	InitMeterInfozb();
	for(i=0; i<PointMax; i++)
	{
		if(JParamInfo3761->group2.f10[i].Status==1)
		printf("\n JZQ�� %d ����ַ��%02x%02x%02x%02x%02x%02x �ɼ�����ַ %02x%02x%02x%02x%02x%02x ��Լ:%d",
				i,
				JParamInfo3761->group2.f10[i].Address[5],JParamInfo3761->group2.f10[i].Address[4],
				JParamInfo3761->group2.f10[i].Address[3],JParamInfo3761->group2.f10[i].Address[2],
				JParamInfo3761->group2.f10[i].Address[1],JParamInfo3761->group2.f10[i].Address[0],
				JParamInfo3761->group2.f10[i].CaijiqiAddress[5],JParamInfo3761->group2.f10[i].CaijiqiAddress[4],
				JParamInfo3761->group2.f10[i].CaijiqiAddress[3],JParamInfo3761->group2.f10[i].CaijiqiAddress[2],
				JParamInfo3761->group2.f10[i].CaijiqiAddress[1],JParamInfo3761->group2.f10[i].CaijiqiAddress[0],
				JParamInfo3761->group2.f10[i].ConnectType);
	}
	printf("\ntmpCldIndex ==%d\n", tmpCldIndex);
	k=0;
	for(k=0;k<tmpCldIndex;k++)
	{
		if((Pt_AutoRep[k].port==CarrWavePort || Pt_AutoRep[k].port==LocalCommPort) && Pt_AutoRep[k].Status==1)
		{
			for(i=cldxuhao+1; i<PointMax; i++) //���ݼ������еĲ����� ��ZB������Ӧ�Ĳ����� �ҵ��Ļ��ͽ�����һ��
			{
				if((JParamInfo3761->group2.f10[i].port==2||JParamInfo3761->group2.f10[i].port==3||JParamInfo3761->group2.f10[i].port==1)
						&& JParamInfo3761->group2.f10[i].Status==1)
				{
					printf("\n continue�� %d ����ַ��%02x%02x%02x%02x%02x%02x �ɼ�����ַ %02x%02x%02x%02x%02x%02x ��Լ:%d ",
										i,
										JParamInfo3761->group2.f10[i].Address[5],JParamInfo3761->group2.f10[i].Address[4],
										JParamInfo3761->group2.f10[i].Address[3],JParamInfo3761->group2.f10[i].Address[2],
										JParamInfo3761->group2.f10[i].Address[1],JParamInfo3761->group2.f10[i].Address[0],
										JParamInfo3761->group2.f10[i].CaijiqiAddress[5],JParamInfo3761->group2.f10[i].CaijiqiAddress[4],
										JParamInfo3761->group2.f10[i].CaijiqiAddress[3],JParamInfo3761->group2.f10[i].CaijiqiAddress[2],
										JParamInfo3761->group2.f10[i].CaijiqiAddress[1],JParamInfo3761->group2.f10[i].CaijiqiAddress[0],
										JParamInfo3761->group2.f10[i].ConnectType);
				}else
				{
					printf("\n�ҵ��� %d ����ַ��%02x%02x%02x%02x%02x%02x �ɼ�����ַ %02x%02x%02x%02x%02x%02x ��Լ:%d <<<<----- �ҵ��� %d ����ַ��%02x%02x%02x%02x%02x%02x �ɼ�����ַ %02x%02x%02x%02x%02x%02x ��Լ:%d",
							i,
							JParamInfo3761->group2.f10[i].Address[5],JParamInfo3761->group2.f10[i].Address[4],
							JParamInfo3761->group2.f10[i].Address[3],JParamInfo3761->group2.f10[i].Address[2],
							JParamInfo3761->group2.f10[i].Address[1],JParamInfo3761->group2.f10[i].Address[0],
							JParamInfo3761->group2.f10[i].CaijiqiAddress[5],JParamInfo3761->group2.f10[i].CaijiqiAddress[4],
							JParamInfo3761->group2.f10[i].CaijiqiAddress[3],JParamInfo3761->group2.f10[i].CaijiqiAddress[2],
							JParamInfo3761->group2.f10[i].CaijiqiAddress[1],JParamInfo3761->group2.f10[i].CaijiqiAddress[0],
							JParamInfo3761->group2.f10[i].ConnectType,
							k,
							Pt_AutoRep[k].Address[5],Pt_AutoRep[k].Address[4],
							Pt_AutoRep[k].Address[3],Pt_AutoRep[k].Address[2],
							Pt_AutoRep[k].Address[1],Pt_AutoRep[k].Address[0],
							Pt_AutoRep[k].CaijiqiAddress[5],Pt_AutoRep[k].CaijiqiAddress[4],
							Pt_AutoRep[k].CaijiqiAddress[3],Pt_AutoRep[k].CaijiqiAddress[2],
							Pt_AutoRep[k].CaijiqiAddress[1],Pt_AutoRep[k].CaijiqiAddress[0],
							Pt_AutoRep[k].ConnectType);

					JParamInfo3761->group2.f10[i].Address[5]=Pt_AutoRep[k].Address[5];
					JParamInfo3761->group2.f10[i].Address[4]=Pt_AutoRep[k].Address[4];
					JParamInfo3761->group2.f10[i].Address[3]=Pt_AutoRep[k].Address[3];
					JParamInfo3761->group2.f10[i].Address[2]=Pt_AutoRep[k].Address[2];
					JParamInfo3761->group2.f10[i].Address[1]=Pt_AutoRep[k].Address[1];
					JParamInfo3761->group2.f10[i].Address[0]=Pt_AutoRep[k].Address[0];
					JParamInfo3761->group2.f10[i].ConnectType = Pt_AutoRep[k].ConnectType;
					memcpy(JParamInfo3761->group2.f10[i].CaijiqiAddress, Pt_AutoRep[k].CaijiqiAddress, 6);
					JParamInfo3761->group2.f10[i].port = Pt_AutoRep[k].port;
					JParamInfo3761->group2.f10[i].baudrate = Pt_AutoRep[k].baudrate;
					JParamInfo3761->group2.f10[i].Type = Pt_AutoRep[k].Type;
					JParamInfo3761->group2.f10[i].Status = 1;
					cldxuhao = i;
					printf("\n cldxuhao==%d \n", cldxuhao);
					break;
				}
			}
		}
	}
	SaveMeterParazb(PointMax+1);
}

//INT8U updatebiaoed_flag = 0;//ÿ�쳭һ�α�

void submain()
{
	TS ts, ts_soubiao;
	TS tmpts;
	XinDaoBiaoShi = 0;
	INT8U tasksoubiao_flag = 0;//��վ�·��Զ������������ ʱ�䵽��־
	int soubiao_allowtime=0;
	TSGet(&ts);
	if (jReadZBPrint == 0){
	   if ((JProgramInfo->mainData.Prt_Flag==16) || (JProgramInfo->mainData.Prt_Flag==50))
		   jReadZBPrint = 3;
	}else{
	   if ((JProgramInfo->mainData.Prt_Flag==116) || (JProgramInfo->mainData.Prt_Flag==150))
		   jReadZBPrint = 0;
	}
	TSGet(&ts);
	ts.Year = 0; ts.Month = 0;  ts.Sec = 0;  ts.Week= 0;
	//�ѱ��ж�
	memset(&ts_soubiao, 0, sizeof(TS));
	ts_soubiao.Minute = BCD_INT32(&JParamInfo3761->group11.f111.StartTime[0],1);
	ts_soubiao.Hour = BCD_INT32(&JParamInfo3761->group11.f111.StartTime[1],1);
	ts_soubiao.Day = BCD_INT32(&JParamInfo3761->group11.f111.StartTime[2],1);
	soubiao_allowtime = JParamInfo3761->group11.f111.AllowTime;
//	SdPrint("\n---- soubiao_allowtime =%d ts_soubiao.Day =%d ts_soubiao.Hour=%d ts_soubiao.Minute=%d",
//			soubiao_allowtime, ts_soubiao.Day, ts_soubiao.Hour, ts_soubiao.Minute);
	if(ts_soubiao.Day==0 && ts_soubiao.Hour==0)//Ĭ��ʱ��20:00 ʱ��3��Сʱ
	{
		ts_soubiao.Day = 0;
		ts_soubiao.Hour = 20;
		ts_soubiao.Minute = 0;
		soubiao_allowtime = 3*60;
	}
	if(soubiao_allowtime ==0)
		soubiao_allowtime = 3*60;
//	SdPrint("\n soubiao_allowtime =%d ts.Day =%d ts.Hour=%d ts.Minute=%d",
//			soubiao_allowtime, ts.Day, ts.Hour, ts.Minute);
	if(ts_soubiao.Day!=0)
	{
		//if(!IsEqual(&ts_soubiao, &ts))
		if(ts_soubiao.Day==ts.Day && ts_soubiao.Hour==ts.Hour && ts_soubiao.Minute==ts.Minute)
		{
			fprintf(stderr,"\n�Զ��ѱ����� ��ʼ�ѱ�  0");
			tasksoubiao_flag = 1;
		}
		memset(&tmpts, 0, sizeof(TS));
		tmpts = ts_soubiao;
		TimeAdd(&tmpts, 2, 1);
		if(tmpts.Day==ts.Day && tmpts.Hour==ts.Hour && tmpts.Minute==ts.Minute)
		{
			fprintf(stderr,"\n�Զ��ѱ����� ��ʼ�ѱ�  0");
			tasksoubiao_flag = 1;
		}
	}else
	{
		if(ts_soubiao.Hour==ts.Hour && ts_soubiao.Minute==ts.Minute)
		{
			fprintf(stderr,"\n�Զ��ѱ����� ��ʼ�ѱ�  1");
			tasksoubiao_flag = 1;
		}
		memset(&tmpts, 0, sizeof(TS));
		tmpts = ts_soubiao;
		TimeAdd(&tmpts, 2, 1);
		if(tmpts.Hour==ts.Hour && tmpts.Minute==ts.Minute)
		{
			fprintf(stderr,"\n�Զ��ѱ����� ��ʼ�ѱ�  1");
			tasksoubiao_flag = 1;
		}
	}
#ifdef BIDUIDANGAN
	if(JProgramInfo->stateflags.F10_Changed==1 || isCLDChanged==1 || (((JParamInfo3761->group11.f111.Enable&0x01)==MANUAL)&&
		(ts.Hour==23 && ts.Minute>50 && ts.Minute<52)))//������ı�
#else
	if(JProgramInfo->stateflags.F10_Changed==1 || isCLDChanged==1 ||(ts.Hour==23 && ts.Minute>50 && ts.Minute<52))//������ı�
#endif
	{
		update485info();			//����485������Ϣ
		pause_read();
		SdPrint("\n\n\n\n-------------update  meter info----%d-----%d------begin\n",SlavePoint_TotalNum,JDataFileInfo->data485[29+PortBegNum].MeterNum);
		GetPtsfromZB();				//��ZBģ���л�ò�������Ϣ
		if(SlavePoint_TotalNum != 0)
			UpdateZBMeterInfo();
		else
			MyAddZbPts();
		GetPtsfromZB();				//��ZBģ���л�ò�������Ϣ
		SdPrint("\n-------------update  meter info-----------------------------end\n\n\n\n");
		//updatebiaoed_flag = 1;
		isCLDChanged = 0;
		Flag_MeterChange = 1;
		JProgramInfo->stateflags.F10_Changed = 0;
		update485info();			//����485������Ϣ
		if(resume_read()==0)
			reboot_read();
	}
	if( (((JProgramInfo->zone)>>7)&0x01) == SHANGHAI)
		JParamInfo3761->group11.f111.Enable = MANUAL;
	if((JParamInfo3761->group11.f111.Enable&0x01)==AUTO)//�����ѱ�
	{//�ж�if(JProgramInfo->BeginSouBiao!=1) ��ֹ�������ѱ��������ֶ��ѱ�
		if(tasksoubiao_flag == 1)
		{
			tmpCldIndex = 0;
			CldIndex= 0;//���ڴ洢�ѱ�����������
			memset(Pt_AutoRep, 0, sizeof(F10)*PointMax);
			DbgPrintToFile("\n�Զ���ʼ�ѱ�����������\n");
			SearchMeterMain_autotime(soubiao_allowtime/3, (soubiao_allowtime*2)/3);
			JProgramInfo->BeginSouBiao = 0;
			tasksoubiao_flag = 0;
			fprintf(stderr, "\n�Զ��ѱ���ϣ�----!!!\n");
#ifdef BIDUIDANGAN
			UpdateJZQMeterInfo();
			update485info();		//����485������Ϣ
			JProgramInfo->stateflags.F10_ChangedSave = 1;
			mydelay(5,ProjectNo,JProgramInfo);

			if(JProgramInfo->BeginSouBiao!=1)
			{
				pause_read();
				GetPtsfromZB();		//��ZBģ���л�ò�������Ϣ
				if(SlavePoint_TotalNum != 0)
					UpdateZBMeterInfo();
				else
					MyAddZbPts();
				GetPtsfromZB();		//��ZBģ���л�ò�������Ϣ
				update485info();	//����485������Ϣ
				resume_read();
			}
#else
			NormalSaveFile("/nand/para/SouBiaoPt.par",(INT8U *)Pt_AutoRep,sizeof(F10)*PointMax,JProgramInfo);
			resume_read();
#endif
			SouBiaoWanbi = 1;
		}
	}
	if(JProgramInfo->BeginSouBiao==1)
	{
		tmpCldIndex = 0;
		CldIndex= 0;//���ڴ洢�ѱ�����������
		memset(Pt_AutoRep, 0, sizeof(F10)*PointMax);
		JProgramInfo->Para.ChangedJiZhongQiInfo = 2;
		DbgPrintToFile("\n�ֶ���ʼ�ѱ�����������\n");
		SearchMeterMain_auto(3, 10, 20, 0);
		JProgramInfo->BeginSouBiao = 0;
		tasksoubiao_flag = 0;
		DbgPrintToFile("\n�ֶ������ѱ�����������\n");
		fprintf(stderr, "\n�ֶ������ѱ�����������\n");
#ifdef BIDUIDANGAN
		UpdateJZQMeterInfo(); //���¼������еı���Ϣ
		update485info();		//����485������Ϣ
		JProgramInfo->stateflags.F10_ChangedSave = 1;
		mydelay(5,ProjectNo,JProgramInfo);
		pause_read();
		GetPtsfromZB();			//��ZBģ���л�ò�������Ϣ
		if(SlavePoint_TotalNum != 0)
			UpdateZBMeterInfo();
		else
			MyAddZbPts();
		GetPtsfromZB();			//��ZBģ���л�ò�������Ϣ
		update485info();		//����485������Ϣ
		resume_read();
#else
		NormalSaveFile("/nand/para/SouBiaoPt.par",(INT8U *)Pt_AutoRep,sizeof(F10)*PointMax,JProgramInfo);
		resume_read();
#endif
		SouBiaoWanbi = 1;
	}
	ClearWaitTimes(ProjectNo,JProgramInfo);
}

/****************************************
 * ���������ʼ��
 ***************************************/
unsigned char clear_datas(void )
{
	unsigned char  Rec645Buff[512];
	unsigned char  Trn645Buff[512];
	unsigned char Check=0;
	int i,len=0;
	Trn645Buff[len++]=0x68;	//����ͷ
	Trn645Buff[len++]=0x0f;
	Trn645Buff[len++]=0x00;
	//-----------------------
	Trn645Buff[len++]=0x41;//������
	//-----------------------
	Trn645Buff[len++]=0x00;//�û�����
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x5f;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//

	Trn645Buff[len++]=0x01;//AFN
	Trn645Buff[len++]=0x04;//
	Trn645Buff[len++]=0x00;//

	for (i = 3; i < len; i++)
		Check += Trn645Buff[i];
	Trn645Buff[len++]=Check;//У����
	Trn645Buff[len++]=0x16;//������
	//delay(50);
	SdPrint("\n clear_datas len = %d .............\n\r",len);
	for(i=0;i<len;i++)
		SdPrint("%02x ",Trn645Buff[i]);
	SdPrint("\n\r");
	SendStrToCarr(Trn645Buff,len);//���ͱ���
	for(i=0;i<30;i++)
	{
		ClearWaitTimes(ProjectNo,JProgramInfo);
		len=ReceiveFromCarr(Rec645Buff);
		if(len>13)break;
		delay(1000);

	}
	SdPrint("\n clear_datas receive len = %d .............\n\r",len);
	for(i=0;i<len;i++)
		SdPrint("%02x ",Rec645Buff[i]);
	SdPrint("\n\r");
	return 1;
}
/***************************************************
 *����ȷ��֡��dateΪ��������ݣ�
 * 68 13 00 01 00 00 00 00 00 00 00 01 00 01 00 05 00 08 16
 ***************************************************/
//68 13 00 01 00 00 00 00 00 00 00 01 00 00 00 00 00 02 16
int send_ack(unsigned char *date, unsigned char xiangwei)
{
	unsigned char  Trn645Buff[30];
	unsigned char Check=0;
	int i,len=0;
	memset(Trn645Buff,0,30);
	Trn645Buff[len++]=0x68;	//����ͷ
	Trn645Buff[len++]=0x13;
	Trn645Buff[len++]=0x00;
	//-----------------------
	Trn645Buff[len++]=0x01;//������

	Trn645Buff[len++]=0x00;//��Ϣ��
	Trn645Buff[len++]=xiangwei;//0x01;
	Trn645Buff[len++]=0x28;
	Trn645Buff[len++]=0x64;
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x00;
	//-----------------------
	Trn645Buff[len++]=0x00;//AFN
	Trn645Buff[len++]=0x01;//���ݱ�ʶ
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=date[0];//��������
	Trn645Buff[len++]=date[1];//
	Trn645Buff[len++]=date[2];//
	Trn645Buff[len++]=date[3];
	for (i = 3; i < len; i++)
		Check += Trn645Buff[i];
	Trn645Buff[len++]=Check;//У����
	Trn645Buff[len++]=0x16;//������

	SdPrint("  send_ack len= %d \n\r",len);
	for(i=0;i<len;i++)
		SdPrint("%02x ",Trn645Buff[i]);
	SdPrint("\n\r");
	SendStrToCarr(Trn645Buff,len);//���ͱ���
	return  1;
}
/****************************************************
 * ���ͷ���֡��err_noΪ������룩
 ****************************************************/
int send_nack(unsigned char err_no, unsigned char xiangwei)
{
	unsigned char  Trn645Buff[30];
	unsigned char Check=0;
	int i,len=0;
	memset(Trn645Buff,0,30);
	Trn645Buff[len++]=0x68;	//����ͷ
	Trn645Buff[len++]=0x10;
	Trn645Buff[len++]=0x00;
	//-----------------------
	Trn645Buff[len++]=0x01;//������

	Trn645Buff[len++]=0x00;//��Ϣ��
	Trn645Buff[len++]=xiangwei;
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x00;
	//-----------------------
	Trn645Buff[len++]=0x00;//AFN
	Trn645Buff[len++]=0x02;//���ݱ�ʶ
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=err_no;//��������

	for (i = 3; i < len; i++)
		Check += Trn645Buff[i];
	Trn645Buff[len++]=Check;//У����
	Trn645Buff[len++]=0x16;//������

	SdPrint("\n send_nack = %d \n\r",err_no);
	for(i=0;i<len;i++)
		SdPrint("%02x ",Trn645Buff[i]);
	SdPrint("\n\r");
	SendStrToCarr(Trn645Buff,len);//���ͱ���
	return  1;
}
/****************************************************
 * ���ͳ����ɹ�����
 * 68 12 00 01 00 00 5F 00 00 00 14 01 00 01 00 00 76 16
 ***************************************************/
int send_meter_success_empty(INT8U *adr, unsigned char xiangwei)//dingxin
{
	unsigned char  Trn645Buff[30];
	int i,len=0;
	INT8U Check=0;
	memset(Trn645Buff,0,30);
	Trn645Buff[len++]=0x68;	//����ͷ
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x00;
		//-----------------------
	Trn645Buff[len++]=0x01;//������

	Trn645Buff[len++]=0x04;//��Ϣ��
	Trn645Buff[len++]=xiangwei;//0x01;
	Trn645Buff[len++]=0x28;
	Trn645Buff[len++]=0x64;
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x00;
	//-----------------------
	Trn645Buff[len++] = CarrierWaveaddr[5];
	Trn645Buff[len++] = CarrierWaveaddr[4];
	Trn645Buff[len++] = CarrierWaveaddr[3];
	Trn645Buff[len++] = CarrierWaveaddr[2];
	Trn645Buff[len++] = CarrierWaveaddr[1];
	Trn645Buff[len++] = CarrierWaveaddr[0];
	Trn645Buff[len++] = adr[0];
	Trn645Buff[len++] = adr[1];
	Trn645Buff[len++] = adr[2];
	Trn645Buff[len++] = adr[3];
	Trn645Buff[len++] = adr[4];
	Trn645Buff[len++] = adr[5];

	Trn645Buff[len++]=0x14;//AFN
	Trn645Buff[len++]=0x01;//���ݱ�ʶ
	Trn645Buff[len++]=0x00;

	Trn645Buff[len++]=0x01;  //���ݵ�Ԫ   ������־
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x00;

	//У����
	for (i = 3; i < len; i++)
		Check += Trn645Buff[i];
	Trn645Buff[len++] = (unsigned char) (Check & 0xff);
	Trn645Buff[len++]=0x16;//������
	Trn645Buff[1]=len & 0xff;
	Trn645Buff[2]= (len>>8) &0xff;
	SdPrint("\n ������ -->>ZBģ��    ����������� send_meter_sucess.............\n\r");
	for(i=0;i<len;i++)
		SdPrint("%02x ",Trn645Buff[i]);
	SdPrint("\n\r");
	SendStrToCarr(Trn645Buff,len);//���ͱ���
	return  1;
}
int send_meter_success(unsigned int num, unsigned char xiangwei)//dingxin
{
	unsigned char  Trn645Buff[30];
	int i,len=0;
	INT8U Check=0;
	memset(Trn645Buff,0,30);
	Trn645Buff[len++]=0x68;	//����ͷ
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x00;
		//-----------------------
	Trn645Buff[len++]=0x01;//������

	Trn645Buff[len++]=0x04;//��Ϣ��
	Trn645Buff[len++]=xiangwei;//0x01;
	Trn645Buff[len++]=0x28;
	Trn645Buff[len++]=0x64;
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x00;
	//-----------------------
	Trn645Buff[len++] = CarrierWaveaddr[5];
	Trn645Buff[len++] = CarrierWaveaddr[4];
	Trn645Buff[len++] = CarrierWaveaddr[3];
	Trn645Buff[len++] = CarrierWaveaddr[2];
	Trn645Buff[len++] = CarrierWaveaddr[1];
	Trn645Buff[len++] = CarrierWaveaddr[0];
	Trn645Buff[len++] = JParamInfo3761->group2.f10[num].Address[0];
	Trn645Buff[len++] = JParamInfo3761->group2.f10[num].Address[1];
	Trn645Buff[len++] = JParamInfo3761->group2.f10[num].Address[2];
	Trn645Buff[len++] = JParamInfo3761->group2.f10[num].Address[3];
	Trn645Buff[len++] = JParamInfo3761->group2.f10[num].Address[4];
	Trn645Buff[len++] = JParamInfo3761->group2.f10[num].Address[5];

	Trn645Buff[len++]=0x14;//AFN
	Trn645Buff[len++]=0x01;//���ݱ�ʶ
	Trn645Buff[len++]=0x00;

	Trn645Buff[len++]=0x01;  //���ݵ�Ԫ   ������־
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x00;

	//У����
	for (i = 3; i < len; i++)
		Check += Trn645Buff[i];
	Trn645Buff[len++] = (unsigned char) (Check & 0xff);
	Trn645Buff[len++]=0x16;//������
	Trn645Buff[1]=len & 0xff;
	Trn645Buff[2]= (len>>8) &0xff;
	SdPrint("\n ������ -->>ZBģ��    ����������� send_meter_sucess.............\n\r");
	for(i=0;i<len;i++)
		SdPrint("%02x ",Trn645Buff[i]);
	SdPrint("\n\r");
	SendStrToCarr(Trn645Buff,len);//���ͱ���
	return  1;
}
/****************************************************
 * ���ͳ���ʧ�ܱ���
 * 68 12 00 01 00 00 5F 00 00 00 14 01 00 00 00 00 75 16
 ***************************************************/
int send_meter_fail(unsigned int num)//dingxin
{
	unsigned char  Trn645Buff[30];
	int i,len=0;
	INT8U Check=0;
	memset(Trn645Buff,0,30);
	Trn645Buff[len++]=0x68;	//����ͷ
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x00;
	//-----------------------
	Trn645Buff[len++]=0x01;//������

	Trn645Buff[len++]=0x04;//��Ϣ��
	Trn645Buff[len++]=0x01;
	Trn645Buff[len++]=0x28;
	Trn645Buff[len++]=0x64;
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x00;
	//-----------------------
	Trn645Buff[len++] = CarrierWaveaddr[5];
	Trn645Buff[len++] = CarrierWaveaddr[4];
	Trn645Buff[len++] = CarrierWaveaddr[3];
	Trn645Buff[len++] = CarrierWaveaddr[2];
	Trn645Buff[len++] = CarrierWaveaddr[1];
	Trn645Buff[len++] = CarrierWaveaddr[0];
	Trn645Buff[len++] = JParamInfo3761->group2.f10[num].Address[0];
	Trn645Buff[len++] = JParamInfo3761->group2.f10[num].Address[1];
	Trn645Buff[len++] = JParamInfo3761->group2.f10[num].Address[2];
	Trn645Buff[len++] = JParamInfo3761->group2.f10[num].Address[3];
	Trn645Buff[len++] = JParamInfo3761->group2.f10[num].Address[4];
	Trn645Buff[len++] = JParamInfo3761->group2.f10[num].Address[5];

	Trn645Buff[len++]=0x14;//AFN
	Trn645Buff[len++]=0x01;//���ݱ�ʶ
	Trn645Buff[len++]=0x00;

	Trn645Buff[len++]=0x00;  //���ݵ�Ԫ
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x00;

	//У����
	for (i = 3; i < len; i++)
		Check += Trn645Buff[i];
	Trn645Buff[len++] = (unsigned char) (Check & 0xff);
	Trn645Buff[len++]=0x16;//������
	Trn645Buff[1]=len & 0xff;
	Trn645Buff[2]= (len>>8) &0xff;
	SdPrint("\n send_meter_fail(ask meter num don't exist!).............\n\r");
	for(i=0;i<len;i++)
		SdPrint("%02x ",Trn645Buff[i]);
	SdPrint("\n\r");
	SendStrToCarr(Trn645Buff,len);//���ͱ���
	return 1;
}
/*******************************************
 *�ָ���������
 *******************************************/
unsigned char resume_read(void)
{
  unsigned char  Rec645Buff[512];
  unsigned char  Trn645Buff[512];
  INT8U retflag=0;
	unsigned char Check=0;
	int i,len=0,k=0;
	memset(Rec645Buff,0,512);
	memset(Trn645Buff,0,512);
  Trn645Buff[len++]=0x68;	//����ͷ
  Trn645Buff[len++]=0x0f;
  Trn645Buff[len++]=0x00;
  //-----------------------
  Trn645Buff[len++]=0x41;//������
  //-----------------------
  Trn645Buff[len++]=0x00;//�û�����
  Trn645Buff[len++]=0x00;//
  Trn645Buff[len++]=0x28;//
  Trn645Buff[len++]=0x64;//
  Trn645Buff[len++]=0x00;//
  Trn645Buff[len++]=0x00;//

  Trn645Buff[len++]=0x12;//AFN
  Trn645Buff[len++]=0x04;//
  Trn645Buff[len++]=0x00;//
  for (i = 3; i < len; i++)
    Check += Trn645Buff[i];
  Trn645Buff[len++]=Check;//У����
  Trn645Buff[len++]=0x16;//������
  //delay(50);
  SdPrint("\n resume_read send DataNum = %d .............\n\r",len);
  for(i=0;i<len;i++)
    SdPrint("%02x ",Trn645Buff[i]);
  SdPrint("\n\r");
  SendStrToCarr(Trn645Buff,len);//���ͱ���
  delay(1300);
  //68 13 00 81 00 00 40 00 00 00 00 01 00 ff ff 02 00 c2 16
  while(k<3)
  	{
  		ClearWaitTimes(ProjectNo,JProgramInfo);
  		delay(1300);
  		len=ReceiveFromCarr(Rec645Buff);
  		k++;
  		if(len>0)
  		{
  			for(i=0; i<len; i++)
  			{
  				if(Rec645Buff[i]==0x68 && Rec645Buff[i+10]==0x00 &&
  					Rec645Buff[i+11]==0x01 &&Rec645Buff[i+12]==0x00)
  				{
  					retflag = 1; //�յ�ȷ��
  				}
  				if(Rec645Buff[i]==0x68 && Rec645Buff[i+10]==0x00 &&
  					Rec645Buff[i+11]==0x02 &&Rec645Buff[i+12]==0x00)
  				{
  					retflag = 2; //�յ�����
  				}
  			}
  			if(retflag!=0)
  				break;
  		}
  	}
  	SdPrint("\n resume_read Receive DataNum = %d ............\n\r",len);
  	for(i=0;i<len;i++)
  		SdPrint("%02x ",Rec645Buff[i]);	//����
  	SdPrint("\n\r");
  	if(retflag==1)
  	{
  		SdPrint("\n �ز�ģ��ָ�·��  �ɹ�! \n");
  		return 1;
  	}
  		else
  	{
  		SdPrint("\n �ز�ģ��ָ�·��  ʧ�ܣ�! \n");
  		return 0;
  	}
}
//��ͣ����  ����1 ȷ�� ����0 ����
unsigned char pause_read(void)//dingxin
{
	unsigned char  Rec645Buff[512];
	unsigned char  Trn645Buff[34];
	unsigned char Check=0;
	int i,k=0,len=0;
	INT8U retflag=0;
	Trn645Buff[len++]=0x68;	//����ͷ
	Trn645Buff[len++]=0x0f;
	Trn645Buff[len++]=0x00;
	//-----------------------
	Trn645Buff[len++]=0x41;//������
	//-----------------------
	Trn645Buff[len++]=0x00;//�û�����
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x28;//
	Trn645Buff[len++]=0x64;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//

	Trn645Buff[len++]=0x12;//AFN
	Trn645Buff[len++]=0x02;//
	Trn645Buff[len++]=0x00;//

	for (i = 3; i < len; i++)
		Check += Trn645Buff[i];
	Trn645Buff[len++]=Check;//У����
	Trn645Buff[len++]=0x16;//������
	delay(50);
	SdPrint("\n �ز�ģ����ͣ·�� send DataNum = %d .............\n\r",len);
	for(i=0;i<len;i++)
		SdPrint("%02x ",Trn645Buff[i]);
	SdPrint("\n\r");
	SendStrToCarr(Trn645Buff,len);//���ͱ���
	delay(1300);
	memset(Rec645Buff,0,512);
	while(k<3)
	{
		ClearWaitTimes(ProjectNo,JProgramInfo);
		delay(1300);
		len=ReceiveFromCarr(Rec645Buff);
		k++;
		if(len>0)
		{
			for(i=0; i<len; i++)//512
			{
				if(Rec645Buff[i]==0x68 && Rec645Buff[i+10]==0x00 &&
					Rec645Buff[i+11]==0x01 &&Rec645Buff[i+12]==0x00)
				{
					retflag = 1; //�յ�ȷ��
				}
				if(Rec645Buff[i]==0x68 && Rec645Buff[i+10]==0x00 &&
					Rec645Buff[i+11]==0x02 &&Rec645Buff[i+12]==0x00)
				{
					retflag = 2; //�յ�����
				}
			}
			if(retflag!=0)
				break;
		}
	}
	SdPrint("\n pause_read Receive DataNum = %d ............\n\r",len);
	for(i=0;i<len;i++)
		SdPrint("%02x ",Rec645Buff[i]);	//����
	SdPrint("\n\r");
	if(retflag==1)
	{
		SdPrint("\n �ز�ģ����ͣ·��  �ɹ�! \n");
		return 1;
	}
	else
	{
		SdPrint("\n �ز�ģ����ͣ·��  ʧ�ܣ�! \n");
		return 0;
	}
}
///*******************************************
// *��ͣ��������
// *68 0F 00 41 00 00 5F 00 00 00 12 02 00 B4 16
// *******************************************/
//unsigned char  pause_read(void)
//{
//  unsigned char  Rec645Buff[34];
//  unsigned char  Trn645Buff[34];
//  unsigned char i,len=0,Check=0;
//  Trn645Buff[len++]=0x68;	//����ͷ
//  Trn645Buff[len++]=0x0f;
//  Trn645Buff[len++]=0x00;
//  //-----------------------
//  Trn645Buff[len++]=0x41;//������
//  //-----------------------
//  Trn645Buff[len++]=0x00;//�û�����
//  Trn645Buff[len++]=0x00;//
//  Trn645Buff[len++]=0x5f;//
//  /*
//   * �����ĵ�������04����50
//   */
//
//  Trn645Buff[len++]=0x00;//
//  Trn645Buff[len++]=0x00;//
//  Trn645Buff[len++]=0x00;//
//
//  Trn645Buff[len++]=0x12;//AFN
//  Trn645Buff[len++]=0x02;//
//  Trn645Buff[len++]=0x00;//
//
//  for (i = 3; i < len; i++)
//    Check += Trn645Buff[i];
//  Trn645Buff[len++]=Check;//У����
//  Trn645Buff[len++]=0x16;//������
//  //delay(50);
//  SdPrint("\n PAUSE_READ send DataNum = %d .............\n\r",len);
//  for(i=0;i<len;i++)
//    SdPrint("%02x ",Trn645Buff[i]);
//  SdPrint("\n\r");
//  SendStrToCarr(Trn645Buff,len);//���ͱ���
//  delay(1300);
//  //68 13 00 81 00 00 40 00 00 00 00 01 00 ff ff 02 00 c2 16
//  for(i=0;i<3;i++)
//  {
//	  ClearWaitTimes(ProjectNo,JProgramInfo);
//      len=ReceiveFromCarr(Rec645Buff);
//      if(len>13)break;
//      delay(1000);
//  }
//  SdPrint("\n PAUSE_READ Receive DataNum = %d ............\n\r",len);
//  for(i=0;i<len;i++)
//    SdPrint("%02x ",Rec645Buff[i]);	//����
//  SdPrint("\n\r");
//  ClearWaitTimes(ProjectNo,JProgramInfo);
//  if((Rec645Buff[0]!=0x68) && (Rec645Buff[Rec645Buff[1]-1]!=0x16))     //��ͷ��β���
//  {
//	  SdPrint("pasue_read ��ͷ����\n\r");
//	  return 0;
//  }
//  Check=0;
//  for (i = 3; i < Rec645Buff[1]-2; i++)		//У��ͼ��
//  {
//	  Check+=Rec645Buff[i];
//  }
//  SdPrint("pasue_read len-5=%d  Check=%02x\n\r",len-5,Check);
//  //SdPrint( "Rec645Buff[Rec645Buff[1]-2]=%d\n\r",Rec645Buff[Rec645Buff[1]-2]);
//  if(Check!=Rec645Buff[Rec645Buff[1]-2])
//  {
//	  SdPrint("pasue_read У��ʹ���\n\r");
//	  return 0;
//  }
//  ClearWaitTimes(ProjectNo,JProgramInfo);
//  return 1;
//}

//�Ѽ��������߼���ַ�赽ZBģ����
unsigned char SetupZBAdress()
{
	unsigned char  Rec645Buff[256];
	unsigned char  Trn645Buff[34];
	int i,k=0,len=0;
	int iDizhi;
	unsigned char sDizhi[4];
	unsigned char Check=0;
	INT8U retflag=0;
	Trn645Buff[len++]=0x68;	//����ͷ
	Trn645Buff[len++]=0x15;
	Trn645Buff[len++]=0x00;
	//-----------------------
	Trn645Buff[len++]=0x41;//������
	//-----------------------
	Trn645Buff[len++]=0x00;//�û�����
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x28;//
	Trn645Buff[len++]=0x64;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//

	Trn645Buff[len++]=0x05;//AFN
	Trn645Buff[len++]=0x01;//
	Trn645Buff[len++]=0x00;//
	//	if(GetCarrierWaveAddress(0))//ʧ����
	//	{
	//		if(CarrierWaveaddr[3]!=JConfigInfo->jzqpara.Area_8016.JZ_XingZhuangQuHaoMa[1] ||
	//				CarrierWaveaddr[2]!=JConfigInfo->jzqpara.Area_8016.JZ_XingZhuangQuHaoMa[0]||
	//				CarrierWaveaddr[1]!=JConfigInfo->jzqpara.Address_8017.JZ_di_zhi[1] ||
	//				CarrierWaveaddr[0]!=JConfigInfo->jzqpara.Address_8017.JZ_di_zhi[1] )
	//		{
	//
	//		}
	//	}

	memset(sDizhi,0,4);

	iDizhi =(JConfigInfo->jzqpara.Address_8017.JZ_di_zhi[0]<<8)+ JConfigInfo->jzqpara.Address_8017.JZ_di_zhi[1];
	INT32U_BCD(iDizhi,sDizhi,3);
	Trn645Buff[len++]=sDizhi[0];//
	Trn645Buff[len++]=sDizhi[1];//
	Trn645Buff[len++]=sDizhi[2];//JConfigInfo->jzqpara.Area_8016.JZ_XingZhuangQuHaoMa[1];
	Trn645Buff[len++]=0x00;//JConfigInfo->jzqpara.Area_8016.JZ_XingZhuangQuHaoMa[0];//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//

	for (i = 3; i < len; i++)
		Check += Trn645Buff[i];
	Trn645Buff[len++]=Check;//У����
	Trn645Buff[len++]=0x16;//������
	Trn645Buff[1] = len;
	delay(50);
	SdPrint("\n �����ز�ģ���ַ send DataNum = %d .............\n\r",len);
	for(i=0;i<len;i++)
		SdPrint("%02x ",Trn645Buff[i]);
	SdPrint("\n\r");
	SendStrToCarr(Trn645Buff,len);//���ͱ���
	delay(1300);
	while(k<3)
	{
		ClearWaitTimes(ProjectNo,JProgramInfo);
		delay(1300);
		len=ReceiveFromCarr(Rec645Buff);
		k++;
		if(len>0)
		{
			for(i=0; i<len; i++)
			{
				if(Rec645Buff[i]==0x68 && Rec645Buff[i+10]==0x00 &&
					Rec645Buff[i+11]==0x01 &&Rec645Buff[i+12]==0x00)
				{
					retflag = 1; //�յ�ȷ��
				}
				if(Rec645Buff[i]==0x68 && Rec645Buff[i+10]==0x00 &&
					Rec645Buff[i+11]==0x02 &&Rec645Buff[i+12]==0x00)
				{
					retflag = 2; //�յ�����
				}
			}
			if(retflag!=0)
				break;
		}
	}
	SdPrint("\n SetupZBAdress Receive DataNum = %d ............\n\r",len);
	for(i=0;i<len;i++)
		SdPrint("%02x ",Rec645Buff[i]);	//����
	SdPrint("\n\r");
	if(retflag==1)
	{
		SdPrint("\n �����ز�ģ���ַ  �ɹ�! \n");
		return 1;
	}
		else
	{
		SdPrint("\n �����ز�ģ���ַ  ʧ�ܣ�! \n");
		return 0;
	}
}
//��������  �������κα���
unsigned char BeginSearchMeter_auto(INT8U time)//dingxin
{
	unsigned char  Rec645Buff[256];
	unsigned char  Trn645Buff[34];
	int i,k=0,len=0;
	unsigned char Check=0;
	INT8U retflag=0;
	Trn645Buff[len++]=0x68;	//����ͷ
	Trn645Buff[len++]=0x1f;
	Trn645Buff[len++]=0x00;
	//-----------------------
	Trn645Buff[len++]=0x41;//������
	//-----------------------
	Trn645Buff[len++]=0x00;//�û�����
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x28;//
	Trn645Buff[len++]=0x64;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//

	Trn645Buff[len++]=0x05;//AFN
	Trn645Buff[len++]=0x04;//
	Trn645Buff[len++]=0x00;//

	Trn645Buff[len++]=0x02;////��Լ����
	Trn645Buff[len++]=0x0E;//
	Trn645Buff[len++]=0x68;//
	Trn645Buff[len++]=0xAA;//
	Trn645Buff[len++]=0xAA;//
	Trn645Buff[len++]=0xAA;//
	Trn645Buff[len++]=0xAA;//
	Trn645Buff[len++]=0xAA;//
	Trn645Buff[len++]=0xAA;//
	Trn645Buff[len++]=0x68;//
	Trn645Buff[len++]=0x13;//
	Trn645Buff[len++]=0x02;//
	Trn645Buff[len++]=time + 0x33;//
	Trn645Buff[len++]=0x33;//
	Trn645Buff[len++]=0x4A;//
	Trn645Buff[len++]=0x16;//

	for (i = 3; i < len; i++)
		Check += Trn645Buff[i];
	Trn645Buff[len++]=Check;//У����
	Trn645Buff[len++]=0x16;//������
	delay(50);
	SdPrint("\n �������Ź㲥 send DataNum = %d .............\n\r",len);
	for(i=0;i<len;i++)
		SdPrint("%02x ",Trn645Buff[i]);
	SdPrint("\n\r");
	SendStrToCarr(Trn645Buff,len);//���ͱ���
	while(k<10)
	{
		ClearWaitTimes(ProjectNo,JProgramInfo);
		delay(500);
		len=ReceiveFromCarr(Rec645Buff);
		k++;
		if(len>0)
		{
			SdPrint("\n SearchMeter Receive DataNum = %d ,,,,,,,,,,,,,\n\r",len);
			for(i=0;i<len;i++)
				SdPrint("%02x ",Rec645Buff[i]);	//����
			SdPrint("\n\r");
			for(i=0; i<len; i++)
			{
				if(Rec645Buff[i]==0x68 && Rec645Buff[i+10]==0x00 &&
					Rec645Buff[i+11]==0x01 &&Rec645Buff[i+12]==0x00)
				{
					retflag = 1; //�յ�ȷ��
				}
				if(Rec645Buff[i]==0x68 && Rec645Buff[i+10]==0x00 &&
					Rec645Buff[i+11]==0x02 &&Rec645Buff[i+12]==0x00)
				{
					retflag = 2; //�յ�����
				}
			}
			if(retflag!=0)
				break;
		}
	}
	SdPrint("\n SearchMeter Receive DataNum = %d ............\n\r",len);
	for(i=0;i<len;i++)
		SdPrint("%02x ",Rec645Buff[i]);	//����
	SdPrint("\n\r");
	if(retflag==1)
	{
		SdPrint("\n �������Ź㲥  �ɹ�! \n");
		return 1;
	}
		else
	{
		SdPrint("\n �������Ź㲥  ʧ�ܣ�! \n");
		return 0;
	}
}


//�����ز��ӽڵ�����ע��  ����1 ȷ�� ����0 ����
unsigned char EnReg_auto(INT8U time)//dingxin
{
	unsigned char  Rec645Buff[256];
	unsigned char  Trn645Buff[34];
	int i,k=0,len=0;
	unsigned char Check=0;
	INT8U retflag=0;
	Trn645Buff[len++]=0x68;	//����ͷ
	Trn645Buff[len++]=0x19;
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x41;//������

	Trn645Buff[len++]=0x00;//�û�����
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x28;//
	Trn645Buff[len++]=0x64;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//

	Trn645Buff[len++]=0x11;//
	Trn645Buff[len++]=0x10;//
	Trn645Buff[len++]=0x00;//

	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=time;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//
	for (i = 3; i < len; i++)
		Check += Trn645Buff[i];
	Trn645Buff[len++]=Check;//У����
	Trn645Buff[len++]=0x16;//������
	delay(50);
	SdPrint("\n �����ز��ӽڵ�����ע��(ʱ��%d����) send DataNum = %d .............\n\r",time,len);
	for(i=0;i<len;i++)
		SdPrint("%02x ",Trn645Buff[i]);
	SdPrint("\n\r");
	SendStrToCarr(Trn645Buff,len);//���ͱ���
	while(k<10)
	{
		ClearWaitTimes(ProjectNo,JProgramInfo);
		delay(500);
		len=ReceiveFromCarr(Rec645Buff);
		k++;
		if(len>0)
		{
			for(i=0; i<len; i++)
			{
				if(Rec645Buff[i]==0x68 && Rec645Buff[i+10]==0x00 &&
					Rec645Buff[i+11]==0x01 &&Rec645Buff[i+12]==0x00)
				{
					retflag = 1; //�յ�ȷ��
				}
				if(Rec645Buff[i]==0x68 && Rec645Buff[i+10]==0x00 &&
					Rec645Buff[i+11]==0x02 &&Rec645Buff[i+12]==0x00)
				{
					retflag = 2; //�յ�����
				}
			}
			if(retflag!=0)
				break;
		}
	}
	SdPrint("\n EnAutoReg Receive DataNum = %d ............\n\r",len);
	for(i=0;i<len;i++)
		SdPrint("%02x ",Rec645Buff[i]);	//����
	SdPrint("\n\r");
	if(retflag==1)
	{
		SdPrint("\n �����ز��ӽڵ�����ע��  �ɹ�! \n");
		return 1;
	}
		else
	{
		SdPrint("\n �����ز��ӽڵ�����ע��  ʧ�ܣ�! \n");
		return 0;
	}
}

//��ѯ����ע����ز��ӽڵ���Ϣ  ����1 ȷ�� ����0 ����
unsigned char LookupSlaveInfo_auto(INT16U startno, INT8U num)//dingxin
{
	unsigned char  Rec645Buff[256];
	unsigned char  Trn645Buff[34];
	int i,j=0,k=0,len=0;
	unsigned char Check=0;
	INT8U retflag=0;
	static int cldidex_meter=0;
	Trn645Buff[len++]=0x68;	//����ͷ
	Trn645Buff[len++]=0x12;
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x41;//������

	Trn645Buff[len++]=0x00;//�û�����
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x28;//
	Trn645Buff[len++]=0x64;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//

	Trn645Buff[len++]=0x10;//
	Trn645Buff[len++]=0x20;//
	Trn645Buff[len++]=0x00;//

	Trn645Buff[len++]=startno & 0xff;//
	Trn645Buff[len++]=(startno>>8) & 0xff;//
	Trn645Buff[len++]=num;//
	for (i = 3; i < len; i++)
		Check += Trn645Buff[i];
	Trn645Buff[len++]=Check;//У����
	Trn645Buff[len++]=0x16;//

	SdPrint("\n ��ѯ����ע����ز��ӽڵ���Ϣ  send DataNum = %d .............\n\r",len);
	for(i=0;i<len;i++)
		SdPrint("%02x ",Trn645Buff[i]);
	SdPrint("\n\r");
	SendStrToCarr(Trn645Buff,len);//���ͱ���
	while(k<10)
	{
		ClearWaitTimes(ProjectNo,JProgramInfo);
		delay(500);
		len=ReceiveFromCarr(Rec645Buff);
		k++;
		for(i=0; i<len; i++)
		{
			if(Rec645Buff[i]==0x68 && Rec645Buff[i+10]==0x10 &&
				Rec645Buff[i+11]==0x20 && Rec645Buff[i+12]==0x00)
			{
				for(j=0; j<Rec645Buff[i+15]; j++)
				{
					memcpy(&ZBMeterInf[cldidex_meter][0], &Rec645Buff[i+16+j*7], 6);
					SdPrint("\n��ȡ������ZBMeterInf %02x%02x%02x%02x%02x%02x �±�� %d",
							ZBMeterInf[cldidex_meter][5],ZBMeterInf[cldidex_meter][4],ZBMeterInf[cldidex_meter][3],
							ZBMeterInf[cldidex_meter][2],ZBMeterInf[cldidex_meter][1],ZBMeterInf[cldidex_meter][0],
							cldidex_meter);
					cldidex_meter++;
				}
				retflag = 1;
			}
		}
		if(retflag!=0)
			break;
	}
	SdPrint("\n LookupSlaveInfo_auto Receive DataNum = %d ............\n\r",len);
	for(i=0;i<len;i++)
		SdPrint("%02x ",Rec645Buff[i]);	//����
	SdPrint("\n\r");
	if(retflag==1)
		return 1;
	else
		return 0;
}
/*******************************************
 *��ѯ·�ɹ���ģʽ
 *******************************************/
unsigned char ZBStatus_read(void)
{
  unsigned char  Rec645Buff[512];
  unsigned char  Trn645Buff[512];
	int i,k=0,len=0,j=0;
	unsigned char Check=0;
  unsigned char flag=0;
	memset(Rec645Buff,0,512);
	memset(Trn645Buff,0,512);
  Trn645Buff[len++]=0x68;	//����ͷ
  Trn645Buff[len++]=0x0f;
  Trn645Buff[len++]=0x00;
  //-----------------------
  Trn645Buff[len++]=0x41;//������
  //-----------------------
  Trn645Buff[len++]=0x00;//�û�����
  Trn645Buff[len++]=0x00;//
  Trn645Buff[len++]=0x00;//
  Trn645Buff[len++]=0x00;//
  Trn645Buff[len++]=0x00;//
  Trn645Buff[len++]=0x00;//

  Trn645Buff[len++]=0x10;//AFN
  Trn645Buff[len++]=0x08;//
  Trn645Buff[len++]=0x00;//
  for (i = 3; i < len; i++)
    Check += Trn645Buff[i];
  Trn645Buff[len++]=Check;//У����
  Trn645Buff[len++]=0x16;//������
  //delay(50);
  SdPrint("\n ��ѯ·��״̬ send DataNum = %d .............\n\r",len);
  for(i=0;i<len;i++)
    SdPrint("%02x ",Trn645Buff[i]);
  SdPrint("\n\r");
  SendStrToCarr(Trn645Buff,len);//���ͱ���
  delay(1300);
  //68 13 00 81 00 00 40 00 00 00 00 01 00 ff ff 02 00 c2 16
  for(i=0;i<10;i++)
  {
	  ClearWaitTimes(ProjectNo,JProgramInfo);
      len=ReceiveFromCarr(Rec645Buff);
      for(k=0;k<len;k++)
      {//68 1F 00 81 00 00 00 00 00 00 10 08 00 01 00 00 00 00 00 00 00 58 02 00 00 00 08 08 08 0C 16
    	  if(Rec645Buff[k]==0x68 && Rec645Buff[k+10]==0x10 && Rec645Buff[k+11]==0x08 &&
    			  Rec645Buff[k+12]==0x00)
    	  {
    		  memset(&rtStatus, 0, sizeof(RTStatus_t));
    		  rtStatus.islearn = Rec645Buff[k+13] & 0x01;
    		  rtStatus.iswork = Rec645Buff[k+13] & 0x02;
    		  rtStatus.allpoint_num = Rec645Buff[k+14] | (Rec645Buff[k+15]<<8);
    		  rtStatus.okpoint_num = Rec645Buff[k+16] | (Rec645Buff[k+17]<<8);
    		  rtStatus.zjokpoint_num = Rec645Buff[k+18] | (Rec645Buff[k+19]<<8);
    		  SlavePoint_TotalNum = rtStatus.allpoint_num;
    		  if(Rec645Buff[k+26]==0x08 && Rec645Buff[k+27]==0x08 && Rec645Buff[k+28]==0x08)
    			  rtStatus.isSanXiangIdle = 1;
    		  SdPrint("\n ZBStatus_read  Receive DataNum = %d ............\n\r",len);
    		  for(j=0;j<len;j++)
    		    SdPrint("%02x ",Rec645Buff[j]);	//����
    		  SdPrint("\n\r");
    		  flag = 1;
    		  break;
    	  }
      }
      if(flag==1)
    	  break;
      delay(1000);
  }
  return len;
}
//��ZB���͵ı�����Ϣ�з���������ַ
INT8U RTMeterProcess_auto(INT8U *buf, INT16U len)
{
	int i, k=0,m=0;//cjq_start �ز��ӽڵ�1ͨ�ŵ�ַ���ڵı���λ�� 1����14
	unsigned char ackbuf[4];
	INT8U chongfu_flag=0;
	INT8U xiangwei=0;
	F10 pt_f10;
//	INT8U TempBuf[60];
	memset(&pt_f10, 0, sizeof(F10));
	for(i=0; i<len; i++)
	{
//		68 3f 00 c1 00 01 31 ff 00 00 [0-9]
//		06 08 00   [10-12]
//		01 02 00 00 00 00 11 00 ff ff 00 05 05 [13-25]
//		09 00 00 00 00 00 02 [26-32]
//		04 00 00 00 00 00 02
//		05 00 00 00 00 00 02
//		10 00 00 00 00 00 02
//		12 00 00 00 00 00 02
//		5a 16

		if(buf[i]==0x68 && buf[i+10]==0x06 && buf[i+11]==0x08 && buf[i+12]==0x00)
		{
			xiangwei= buf[i+5];
			//for(j=0; j<buf[i+13]; j++)//�ϱ��ɼ���������
			{
				printf("\n buf[i+13]==%2x buf[25]=%02x", buf[i+13],  buf[i+25]);
				for(k=0;k<buf[i+25]; k++) //ѭ�������� buf[cjq_start+11]=5  cjq_start=14
				{
					memset(&pt_f10, 0, sizeof(pt_f10));
					memcpy(pt_f10.Address, &buf[i+26+k*7], 6);
					if(buf[i+26+k*7+6]==0x01)
						pt_f10.ConnectType = 1;
					else if(buf[i+26+k*7+6]==0x02)
						pt_f10.ConnectType = 30;
					memcpy(pt_f10.CaijiqiAddress, &buf[i+14], 6);

					//Pt_AutoRep
					chongfu_flag=0;
					for(m=0; m<PointMax; m++)//����ַ�ظ��Ĳ�������˵�
					{
						if(Pt_AutoRep[m].Address[5]==pt_f10.Address[5] &&
							Pt_AutoRep[m].Address[4]==pt_f10.Address[4] &&
							Pt_AutoRep[m].Address[3]==pt_f10.Address[3] &&
							Pt_AutoRep[m].Address[2]==pt_f10.Address[2] &&
							Pt_AutoRep[m].Address[1]==pt_f10.Address[1] &&
							Pt_AutoRep[m].Address[0]==pt_f10.Address[0] )
						{
							SdPrint("\n �ظ��ı���(��ʱ)�� pt[%d].Address  %02x%02x%02x%02x%02x%02x====�ظ��Ĳ������ ������\n",
									m,Pt_AutoRep[m].Address[5],Pt_AutoRep[m].Address[4],
									Pt_AutoRep[m].Address[3],Pt_AutoRep[m].Address[2],
									Pt_AutoRep[m].Address[1],Pt_AutoRep[m].Address[0]);
							chongfu_flag = 1;
							break;
						}
					}//end of for(m=0; m<PointMax; m++)
					if(chongfu_flag==0)
					{
						memcpy(Pt_AutoRep[tmpCldIndex].Address, &buf[i+26+k*7], 6);
						if(buf[i+26+k*7+6]==0x01)
							Pt_AutoRep[tmpCldIndex].ConnectType = 1;
						else if(buf[i+26+k*7+6]==0x02)
							Pt_AutoRep[tmpCldIndex].ConnectType = 30;
						memcpy(Pt_AutoRep[tmpCldIndex].CaijiqiAddress, &buf[i+14], 6);
						Pt_AutoRep[tmpCldIndex].port = 31;
						Pt_AutoRep[tmpCldIndex].baudrate = 9600/300;
						Pt_AutoRep[tmpCldIndex].Type = 9;
						Pt_AutoRep[tmpCldIndex].Status = 1;
						printf("\n ���ͱ���(��ʱ)�� %d ����ַ��%02x%02x%02x%02x%02x%02x �ɼ�����ַ %02x%02x%02x%02x%02x%02x ��Լ:%d\n",
								tmpCldIndex,
								Pt_AutoRep[tmpCldIndex].Address[5],Pt_AutoRep[tmpCldIndex].Address[4],
								Pt_AutoRep[tmpCldIndex].Address[3],Pt_AutoRep[tmpCldIndex].Address[2],
								Pt_AutoRep[tmpCldIndex].Address[1],Pt_AutoRep[tmpCldIndex].Address[0],
								Pt_AutoRep[tmpCldIndex].CaijiqiAddress[5],Pt_AutoRep[tmpCldIndex].CaijiqiAddress[4],
								Pt_AutoRep[tmpCldIndex].CaijiqiAddress[3],Pt_AutoRep[tmpCldIndex].CaijiqiAddress[2],
								Pt_AutoRep[tmpCldIndex].CaijiqiAddress[1],Pt_AutoRep[tmpCldIndex].CaijiqiAddress[0],
								Pt_AutoRep[tmpCldIndex].ConnectType);
						tmpCldIndex++;
					}

//�������������Ӳ������
//					chongfu_flag=0;
//					for(m=0; m<PointMax; m++)//����ַ�ظ��Ĳ�������˵�
//					{
//						if(((JParamInfo3761->group2.f10[m].f10.port==CarrWavePort)||(JParamInfo3761->group2.f10[i].port==LocalCommPort)) &&
//								JParamInfo3761->group2.f10[i].Status==1)
//						{
//							if(Jmemory->Points.pt[m].Address[5]==pt_Address[5] &&Jmemory->Points.pt[m].Address[4]==pt_Address[4] &&
//								Jmemory->Points.pt[m].Address[3]==pt_Address[3] &&Jmemory->Points.pt[m].Address[2]==pt_Address[2] &&
//								Jmemory->Points.pt[m].Address[1]==pt_Address[1] &&Jmemory->Points.pt[m].Address[0]==pt_Address[0] )
//							{
//								SdPrint("\n �ظ��ı��ţ� pt[%d].Address  %02x%02x%02x%02x%02x%02x====�ظ��Ĳ������ ������\n",
//										m,Jmemory->Points.pt[m].Address[5],Jmemory->Points.pt[m].Address[4],
//										Jmemory->Points.pt[m].Address[3],Jmemory->Points.pt[m].Address[2],
//										Jmemory->Points.pt[m].Address[1],Jmemory->Points.pt[m].Address[0]);
//								chongfu_flag = 1;
//								break;
//							}
//						}
//					}//end of for(m=0; m<PointMax; m++)
//					if(chongfu_flag==0)
//					{
//						CldIndex++;
//						memcpy(JParamInfo3761->group2.f10[CldIndex].Address, &buf[i+26+k*7], 6);
//						if(buf[i+26+k*7+6]==0x01)
//							JParamInfo3761->group2.f10[CldIndex].ConnectType = 1;
//						else if(buf[i+26+k*7+6]==0x02)
//							JParamInfo3761->group2.f10[CldIndex].ConnectType = 30;
//						memcpy(JParamInfo3761->group2.f10[CldIndex].CaijiqiAddress, &buf[i+14], 6);
//						JParamInfo3761->group2.f10[CldIndex].port = 31;
//						JParamInfo3761->group2.f10[CldIndex].baudrate = 9600/300;
//						Jmemory->Points.pt[CldIndex].f25.Type = 9;
//						JParamInfo3761->group2.f10[CldIndex].Status = 1;
//						printf("\n ���ͱ��ţ� %d ����ַ��%02x%02x%02x%02x%02x%02x �ɼ�����ַ %02x%02x%02x%02x%02x%02x ��Լ:%d\n",
//								CldIndex,
//								JParamInfo3761->group2.f10[CldIndex].Address[5],JParamInfo3761->group2.f10[CldIndex].Address[4],
//								JParamInfo3761->group2.f10[CldIndex].Address[3],JParamInfo3761->group2.f10[CldIndex].Address[2],
//								JParamInfo3761->group2.f10[CldIndex].Address[1],JParamInfo3761->group2.f10[CldIndex].Address[0],
//								JParamInfo3761->group2.f10[CldIndex].CaijiqiAddress[5],	JParamInfo3761->group2.f10[CldIndex].CaijiqiAddress[4],
//								JParamInfo3761->group2.f10[CldIndex].CaijiqiAddress[3], JParamInfo3761->group2.f10[CldIndex].CaijiqiAddress[2],
//								JParamInfo3761->group2.f10[CldIndex].CaijiqiAddress[1],	JParamInfo3761->group2.f10[CldIndex].CaijiqiAddress[0],
//								JParamInfo3761->group2.f10[CldIndex].ConnectType);
//						memset(TempBuf,0,60);
//						sprintf((char*)TempBuf,"%s/Ammeter%04d.par",_PARADIR_,(CldIndex)/SaveNum+1);
//						NormalSaveFile((char*)TempBuf,(INT8U *)&Jmemory->Points.pt[CldIndex-(CldIndex%SaveNum)],
//								sizeof(Jmemory->Points.pt[CldIndex-(CldIndex%SaveNum)])*SaveNum);
//					}
				}//end of for(k=0;k<buf[cjq_start+11]; k++)
			}//end of �ϱ��ɼ���������
			memset(ackbuf, 0, 4);
			ackbuf[0]=0xff;
			ackbuf[1]=0xff;
			ackbuf[2]=0x02;
			ackbuf[3]=0x00;
			SdPrint("����ȷ��֡:");
			send_ack(ackbuf, xiangwei);  //����ȷ������

//			memset(TempBuf,0,60);
//			sprintf((char*)TempBuf,"%s/AmmeterN.par",_PARADIR_);
//			NormalSaveFile((char*)TempBuf,(INT8U *)&Jmemory->Points,sizeof(Jmemory->Points));
//			delay(50);
		}
	}
	return 1;
}

/**************************************************
 *�����Ϻ���Լ����
 *����˵����datasԭ���ݣ�DestĿ�����ݣ�Ҫ���������ݱ�ʶflgSH
***************************************************/
//shanghai
int  deal_SHmsg(unsigned char *datas,DataFlag97 *flg97,unsigned char *Dest)
{
	DataFlagSH flgSH;
	unsigned char i,Rec645Buff[200],check;
	INT8U DI0, DI1;

	if(datas[0]!= 0x68 || datas[7] != 0x68)  //��ͷ���
	{
		return 5;
	}
	if(datas[datas[9]+11]!=0x16)	//��β���
	{
		return 5;
	}
	//У��ͼ��
	check=0;
	for(i=0;i<(datas[9]+10);i++)
	{
		check+=datas[i];    //����У���
	}
	if(check!=datas[datas[9]+10])
	{
		return 3;
	}
	DI0=flg97->Dataflag[0] + 0x33;
	DI1=flg97->Dataflag[1] + 0x33;
	//���ݱ�ʶ�ж�
	memset(&flgSH, 0, sizeof(DataFlagSH));
	GetDataFlagSHBy97(flg97,&flgSH);
	if(flgSH.Dataflag[0] != (datas[8]&0x7f))
		return 1;
	//SdPrint("\n\r GetDlt645_2007dests Result  ....................\n\r");
	memset(Rec645Buff,0,200);
	memset(Dest,OxXX,DataLenMax);//��ʼ��

	for (i = 0; i < datas[9]; i++)
	{
		Dest[i] = datas[i+10] - 0x33;

		SdPrint("%x ",Dest[i]); //����
	}
	// ����Ч�����ݸ�ֵ��Dest
	Dlt645Get07Vlue(DI0,DI1,Dest); // �����������
	return -1;
}
/**************************************************
 *����97��Լ����
 *����˵����datasԭ���ݣ�DestĿ�����ݣ�Ҫ���������ݱ�ʶflg97
***************************************************/
int  deal_97msg(unsigned char *datas,DataFlag97 *flg97,unsigned char *Dest)
{
	unsigned char i,Rec645Buff[200],check;
		INT8U DI0, DI1;

		if(datas[0]!= 0x68 || datas[7] != 0x68)  //��ͷ���
		{
			return 5;
		}
		if(datas[datas[9]+11]!=0x16)	//��β���
		{
			return 5;
		}
		//У��ͼ��
		check=0;
		for(i=0;i<(datas[9]+10);i++)
		{
			check+=datas[i];    //����У���
		}
		if(check!=datas[datas[9]+10])
		{
			return 3;
		}
		if((datas[8]&0x1f)!=0x01)             //�������ж�0x01������
		{
			return 0;
		}
		if((datas[8]&0x40)==0x40)			//��վ�쳣֡������쳣
			return 6;
		if((datas[8]&0x40)==0x40)			//��վ�쳣֡������쳣
		{
			memset(Dest,OxXX,DataLenMax);//��Ч����
			Dlt645Get07Vlue(flg97->Dataflag[0],flg97->Dataflag[1],Dest);     //����97�������
			return -1;
		}
		DI0=flg97->Dataflag[0] + 0x33;
		DI1=flg97->Dataflag[1] + 0x33;
		//���ݱ�ʶ�ж�
		if((DI0!= datas[10]) || (DI1!= datas[11]))
		  {
		    return 1;
		  }
		//SdPrint("\n\r GetDlt645_2007dests Result  ....................\n\r");
		memset(Rec645Buff,0,200);
		memset(Dest,OxXX,DataLenMax);//��ʼ��

		for (i = 0; i < (datas[9] - 2); i++)
		{
			Dest[i] = datas[i+12] - 0x33;

			SdPrint("%x ",Dest[i]); //����
		}
		// ����Ч�����ݸ�ֵ��Dest
		Dlt645Get07Vlue(DI0,DI1,Dest); // �����������
		return -1;
}
/**************************************************
 *����07��Լ����
 *����˵����datasԭ���ݣ�DestĿ�����ݣ�Ҫ���������ݱ�ʶflg97
 *68 19 00 00 00 00 00 68 91 18 33 32 34 33 33 33 33 33 33 33 33 33 33 33 33 33 33 33 33 33 33 33 33 33 5a 16
***************************************************/
int  deal_07msg(unsigned char *datas,DataFlag97 *flg97,unsigned char *Dest)
{
	unsigned char i,check,DI0=0,DI1=0,DI2=0,DI3=0;
	DataFlag2007 flg07;
	memset(&flg07,0,sizeof(DataFlag2007));
	if(datas[0]!=0x68 || datas[7]!=0x68)  //��ͷ���
	{
		SdPrint("07��ͷ����\n\r");
		return 5;    //��ʽ����
	}
	if(datas[datas[9]+11]!=0x16)	//��β���
	{
		SdPrint("07��β����\n\r");
		return 5;
	}
	//У��ͼ��
	check=0;
	for(i=0;i<(datas[9]+10);i++)
	{
		check+=datas[i];    //����У���
	}
	if(check!=datas[datas[9]+10])
	{
		SdPrint("07У��ʹ���\n\r");
		return 3;			//У�����
	}
	if((datas[8]&0x1f)!=0x11)             //�������ж�0x11������
	{
		SdPrint("07���������\n\r");
		return 0;
	}
	if((datas[8]&0x40)==0x40)			//��վ�쳣֡������쳣
	{
		SdPrint("07�����������\n\r");
		return 6;
	}
	if((datas[8]&0x40)==0x40)			//��վ�쳣֡������쳣
	{
		memset(Dest,OxXX,DataLenMax);//��Ч����
		Dlt6452007Get97Vlue(flg97, Dest);     //����07�������
		return -1;
	}
	else        //��ȷӦ��֡
	{
		if (GetDataFlag07By97(flg97, &flg07) != 1)
		{
				/*if (Dlt645Tran07byCarrierWave(Addr, flg07.Dataflag[0], flg07.Dataflag[1],
							flg07.Dataflag[2], flg07.Dataflag[3], Dest) == 1)
				{
						return Dlt6452007Get97Vlue(flg, Dest);
				}*/
			return 1;
		}
		//���ݱ�ʶ�ж�
		DI0=flg07.Dataflag[0]+0x33;
		DI1=flg07.Dataflag[1]+0x33;
		DI2=flg07.Dataflag[2]+0x33;
		DI3=flg07.Dataflag[3]+0x33;
		SdPrint("07���ݱ�ʶ    DI0=%02x DI1=%02x DI2=%02x DI3=%02x  ",DI0,DI1,DI2,DI3);
		if((DI0!=datas[10]) || (DI1!=datas[11])	|| (DI2!=datas[12]) || (DI3!=datas[13]))
		{
			SdPrint("07��Ч�����ݵ�Ԫ\n\r");
			return 1;         //��Ч�����ݵ�Ԫ
		}
		//SdPrint("\n\r GetDlt645_2007dests Result  ....................\n\r");
		//memset(Rec645Buff,0,200);
		memset(Dest,OxXX,DataLenMax);//��ʼ��
		SdPrint("����ʾֵ��");
		for (i = 0; i < (datas[9] - 4); i++)
		{
			Dest[i] = datas[i+14] - 0x33;

			/*if (i > 49)
				break;*/
			SdPrint("%02x ",Dest[i]); //����
		}
		SdPrint("\n\r");
		Dlt6452007Get97Vlue(flg97, Dest);     //����07�������
		return -1;
	}
}
int findflg(DataFiles *fl, INT8U DI0, INT8U DI1)
{
	int i, ret=0;
	for (i=0;i<ManyFlagsCount;i++)
	{
		if(fl->manyFiles.sm.datas[i].flg.Dataflag[1]==DI1 &&
				fl->manyFiles.sm.datas[i].flg.Dataflag[0]==DI0)
		{
			ret = i;
			break;
		}
	}
	return ret;
}
int getEmptyflg(DataFiles *fl)
{
	int i, ret=0;
	for (i=0;i<ManyFlagsCount;i++)
	{
		if ((fl->manyFiles.sm.datas[i].flg.Dataflag[1]==0x00 && fl->manyFiles.sm.datas[i].flg.Dataflag[0]==0x00)||
		 (fl->manyFiles.sm.datas[i].flg.Dataflag[1]==0xff && fl->manyFiles.sm.datas[i].flg.Dataflag[0]==0xff)||
		 (fl->manyFiles.sm.datas[i].flg.Dataflag[1]==OxXX && fl->manyFiles.sm.datas[i].flg.Dataflag[0]==OxXX))
		{
			ret = i;
			break;
		}
	}
	return ret;
}

DataFlag97 destflg97[5];
//�ҵ��ض����������ֳ������򼸸���������ǻ�׷�Ӵ洢
int Dlt645_ShangHai(int cldno, DataFiles *fl, CurMeterInfo *curMeters, DataFlag97 *srcflg97)
{
	int count=0;
	int index_flg=0;
	INT8U dest[DataLenMax];
	gflgCount = 0;
	//memset(destflg97, 0, sizeof(DataFlag97));
	if(JParamInfo3761->group2.f10[cldno].ConnectType==21)
	{
		if(srcflg97->Dataflag[0]==0x10 && srcflg97->Dataflag[1]==0xc0)//ʱ��
		{
			memset(dest,0xee,DataLenMax);
			index_flg = findflg(fl, 0x10, 0xc0);
			memcpy(dest,fl->manyFiles.sm.datas[index_flg].datas,DataLenMax);

			memset(fl->manyFiles.sm.datas[index_flg].datas, 0xee, DataLenMax);
			fl->manyFiles.sm.datas[index_flg].flg.Dataflag[0] = srcflg97->Dataflag[0];
			fl->manyFiles.sm.datas[index_flg].flg.Dataflag[1] = srcflg97->Dataflag[1];
			memcpy(fl->manyFiles.sm.datas[index_flg].datas, &dest[0], 3);
			index_flg = findflg(fl, 0x11, 0xc0);
			if(index_flg>0)
			{
				memset(fl->manyFiles.sm.datas[index_flg].datas, 0xee, DataLenMax);
				fl->manyFiles.sm.datas[index_flg].flg.Dataflag[0]=0x11;
				fl->manyFiles.sm.datas[index_flg].flg.Dataflag[1]=0xc0;
				memcpy(fl->manyFiles.sm.datas[index_flg].datas,&dest[3],3);
			}else
			{
				gflgCount = getEmptyflg(fl);
				memset(fl->manyFiles.sm.datas[gflgCount].datas, 0xee, DataLenMax);
				fl->manyFiles.sm.datas[gflgCount].flg.Dataflag[0]=0x11;
				fl->manyFiles.sm.datas[gflgCount].flg.Dataflag[1]=0xc0;
				memcpy(fl->manyFiles.sm.datas[gflgCount].datas,&dest[3],3);
				destflg97[count].Dataflag[1] = 0xc0;
				destflg97[count].Dataflag[0] = 0x11;
				count++;
			}
		}
		if((srcflg97->Dataflag[0]|0x2f)==0x2f && srcflg97->Dataflag[1]==0x90)
		{
			memset(dest,0xee,DataLenMax);
			index_flg = findflg(fl, 0x2f, 0x90);
			memcpy(dest,fl->manyFiles.sm.datas[index_flg].datas,DataLenMax);

			memset(fl->manyFiles.sm.datas[index_flg].datas, 0xee, DataLenMax);
			memcpy(fl->manyFiles.sm.datas[index_flg].datas,&dest[0],4);
			fl->manyFiles.sm.datas[index_flg].flg.Dataflag[0]=srcflg97->Dataflag[0];
			fl->manyFiles.sm.datas[index_flg].flg.Dataflag[1]=srcflg97->Dataflag[1];
		}
		if((srcflg97->Dataflag[0]|0x1f)==0x1f && srcflg97->Dataflag[1]==0x94)//������
		{
			memset(dest,0xee,DataLenMax);
			index_flg = findflg(fl, 0x1f, 0x94);
			memcpy(dest,fl->manyFiles.sm.datas[index_flg].datas,DataLenMax);

			memset(fl->manyFiles.sm.datas[index_flg].datas, 0xee, DataLenMax);
			fl->manyFiles.sm.datas[index_flg].flg.Dataflag[0]=srcflg97->Dataflag[0];
			fl->manyFiles.sm.datas[index_flg].flg.Dataflag[1]=srcflg97->Dataflag[1];
			memcpy(fl->manyFiles.sm.datas[index_flg].datas,&dest[5],12);

			index_flg = findflg(fl, 0x1f, 0x98);
			if(index_flg>0)
			{
				memset(fl->manyFiles.sm.datas[index_flg].datas, 0xee, DataLenMax);
				fl->manyFiles.sm.datas[index_flg].flg.Dataflag[0]=0x1f;
				fl->manyFiles.sm.datas[index_flg].flg.Dataflag[1]=0x98;
				memcpy(fl->manyFiles.sm.datas[index_flg].datas,&dest[22],12);
			}else
			{
				gflgCount = getEmptyflg(fl);
				memset(fl->manyFiles.sm.datas[gflgCount].datas, 0xee, DataLenMax);
				fl->manyFiles.sm.datas[gflgCount].flg.Dataflag[0]=0x1f;
				fl->manyFiles.sm.datas[gflgCount].flg.Dataflag[1]=0x98;
				memcpy(fl->manyFiles.sm.datas[gflgCount].datas,&dest[22],12);
				destflg97[count].Dataflag[1] = 0x98;
				destflg97[count].Dataflag[0] = 0x1f;
				count++;
			}
		}
	}
	return count;
}

int isDataFlagValued_Shanghai(DataFlag97 *flg97)//�ж�������������Ч 0 ��Ч  1 ��Ч
{
	INT8U tmpflg=0;
	int indexid=0;
	for(indexid=0; indexid<FlagsCount; indexid++)
	{
		if(JProgramInfo->Para.meterFlags.dataFlags[1][indexid].flag97.Dataflag[0]==flg97->Dataflag[0]&&
			JProgramInfo->Para.meterFlags.dataFlags[1][indexid].flag97.Dataflag[1]==flg97->Dataflag[1])
		{
			//printf("\n isDataFlagValued_Shanghai flg97->Dataflag : %02x%02x\n",flg97->Dataflag[1],flg97->Dataflag[0]);
			tmpflg = 1;
			break;
		}
	}
	return tmpflg;
}

int isDataFlagValued_97(DataFlag97 *flg97)//�ж�������������Ч 0 ��Ч  1 ��Ч
{
	INT8U tmpflg=0;
	int indexid=0;
	for(indexid=0; indexid<FlagsCount; indexid++)
	{
		if((JProgramInfo->Para.meterFlags.dataFlags[0][indexid].flag97.Dataflag[1]&0xf0)==0x00)
			continue;
		if((JProgramInfo->Para.meterFlags.dataFlags[0][indexid].flag97.Dataflag[1]&0xf0)==0xf0)
			continue;
		if(JProgramInfo->Para.meterFlags.dataFlags[0][indexid].flag97.Dataflag[0]==flg97->Dataflag[0]&&
			JProgramInfo->Para.meterFlags.dataFlags[0][indexid].flag97.Dataflag[1]==flg97->Dataflag[1])
		{
			//printf("\n isDataFlagValued_97 flg97->Dataflag : %02x%02x\n",flg97->Dataflag[1],flg97->Dataflag[0]);
			tmpflg = 1;
			break;
		}
	}
	return tmpflg;
}
/***************************************************
 * �����͵ĳ������Ľ��н���
 * 68 19 00 00 00 00 00 68 91 18 33 32 34 33 33 33 33 33 33 33 33 33 33 33 33 33 33 33 33 33 33 33 33 33 5a 16
 ***************************************************/
int deal_meter_datas(unsigned  char *datas,CurMeterInfo curr_meter,DataFiles *fl,unsigned char flgID)
{
	int success=0;
	unsigned char Dest[DataLenMax];
	if(curr_meter.flType==common)//��ͨ���ļ�
	{
		if(curr_meter.GyType==1)			//97 ��Լ���
		{
			SdPrint("\n��ͨ��----����97��Լ���");
			success=deal_97msg(datas,&curr_meter.flg[flgID],Dest);
		}
		else if(curr_meter.GyType==30)				//07 ��Լ���
		{
			SdPrint("\n��ͨ��----����07��Լ���");
			success=deal_07msg(datas,&curr_meter.flg[flgID],Dest);
		}else if(curr_meter.GyType==21)
		{
			SdPrint("\n��ͨ��----�����Ϻ���Լ���");
			success=deal_SHmsg(datas,&curr_meter.flg[flgID],Dest);
		}
		//SdPrint("��ͨ�� success=%d\n\r",success);
		if(success==-1)
		{
			memcpy(fl->manyFiles.sm.datas[flgID].datas,&Dest[0],DataLenMax);
			fl->manyFiles.sm.datas[flgID].flg.Dataflag[0]=curr_meter.flg[flgID].Dataflag[0];
			fl->manyFiles.sm.datas[flgID].flg.Dataflag[1]=curr_meter.flg[flgID].Dataflag[1];
			SdPrint("\n�����ɹ�!!!  success=%d  flgID=%d OK\n", success,flgID);
		}
	}
	else if(curr_meter.flType==many)     //�๦�ܵ��
	{
		SdPrint("\n�����๦�ܵ��\n\r");
		if(curr_meter.GyType==1)			//97 ��Լ���
		{
			success=deal_97msg(datas,&curr_meter.flg[flgID],Dest);
		}
		else if(curr_meter.GyType==30)				//07 ��Լ���
		{
			SdPrint("\n�๦�ܱ�----����07��Լ���\n\r");
			success=deal_07msg(datas,&curr_meter.flg[flgID],Dest);
		}else if(curr_meter.GyType==21)
		{
			SdPrint("\n�๦�ܱ�----�����Ϻ���Լ���");
			success=deal_SHmsg(datas,&curr_meter.flg[flgID],Dest);
		}
		SdPrint("\n�๦�ܱ� success=%d\n\r",success);
		if(success==-1)
		{
			memcpy(fl->manyFiles.sm.datas[flgID].datas,&Dest[0],DataLenMax);
			fl->manyFiles.sm.datas[flgID].flg.Dataflag[0]=curr_meter.flg[flgID].Dataflag[0];
			fl->manyFiles.sm.datas[flgID].flg.Dataflag[1]=curr_meter.flg[flgID].Dataflag[1];
			SdPrint("\n�����ɹ�!!!  success=%d  OK\n", success);
		}
	}
   return success;
}
/***************************************************
 * �������������㵥���ݱ�ʶ(�����󳭶����ݵĻظ�)
 ***************************************************/
unsigned char get_value(unsigned int num,DataFlag97 *flg)//����
{
	INT8U Trn645Buff[1024], TempBuf[1024];
	INT8U GetLen=0,Check = 0;
	INT16U len,i, len_pos=0;
	len = 0;
	Check = 0;
	ClearWaitTimes(ProjectNo,JProgramInfo);
	SdPrint("\n get_value ���������    %02x%02x%02x%02x%02x%02x  ���ݱ�ʶ Ϊ  %02x%02x ",
			JParamInfo3761->group2.f10[num].Address[5],JParamInfo3761->group2.f10[num].Address[4],JParamInfo3761->group2.f10[num].Address[3],
			JParamInfo3761->group2.f10[num].Address[2],JParamInfo3761->group2.f10[num].Address[1],JParamInfo3761->group2.f10[num].Address[0],
			flg->Dataflag[1],flg->Dataflag[0]);
	//flg->Dataflag[0] = 0x10;
	if ((flg->Dataflag[1]!=0x00) && (flg->Dataflag[1]!=0xEE)  && (flg->Dataflag[1]!=0xFF))
		if(!((flg->Dataflag[0]==0x00 && flg->Dataflag[0]==0x00) ||
			(flg->Dataflag[0]==0xee && flg->Dataflag[0]==0xee) ||
			(flg->Dataflag[0]==0xff && flg->Dataflag[0]==0xff)))
	{
		memset(Trn645Buff, 0, 1024);
		memset(TempBuf, 0, 1024);
		//��֯���ͱ���
		Trn645Buff[len++] = 0x68; //����ͷ
		len_pos = len;
		Trn645Buff[len++] = 0x2c;//����
		Trn645Buff[len++] = 0x00;

		Trn645Buff[len++] = 0x01;// ������C

		Trn645Buff[len++] = 0x04;// ��Ϣ��
		Trn645Buff[len++] = XinDaoBiaoShi;//���������ʶ	�ŵ���ʶ
		Trn645Buff[len++] = 0x28;

		Trn645Buff[len++] = 0x64;//(bauds&0xff);//���ʵ�λ��ʶ	ͨ������
		Trn645Buff[len++] = 0x00;//(((bauds>>8)&0xff)|bflg);//���ʵ�λ��ʶ	ͨ������
		Trn645Buff[len++] = 0x00;//Ԥ��
		Trn645Buff[len++] = CarrierWaveaddr[5];
		Trn645Buff[len++] = CarrierWaveaddr[4];
		Trn645Buff[len++] = CarrierWaveaddr[3];
		Trn645Buff[len++] = CarrierWaveaddr[2];
		Trn645Buff[len++] = CarrierWaveaddr[1];
		Trn645Buff[len++] = CarrierWaveaddr[0];
		Trn645Buff[len++] = JParamInfo3761->group2.f10[num].Address[0];
		Trn645Buff[len++] = JParamInfo3761->group2.f10[num].Address[1];
		Trn645Buff[len++] = JParamInfo3761->group2.f10[num].Address[2];
		Trn645Buff[len++] = JParamInfo3761->group2.f10[num].Address[3];
		Trn645Buff[len++] = JParamInfo3761->group2.f10[num].Address[4];
//		if(JParamInfo3761->group2.f10[num].ConnectType==21)
//		{
//			//if(JParamInfo3761->group2.f10[num].Address[5]==0)
//				Trn645Buff[len++] = 0x00;
//		}else
			Trn645Buff[len++] = JParamInfo3761->group2.f10[num].Address[5];
		Trn645Buff[len++] = 0x14;//·������
		Trn645Buff[len++] = 0x01;//���ݵ�Ԫ
		Trn645Buff[len++] = 0x00;//���ݵ�Ԫ
		Trn645Buff[len++] = 0x02;//������־
		//Ҫת��������
		if(JParamInfo3761->group2.f10[num].ConnectType==1)     //97��Լ���
		{
			GetLen = GetDlt645_97Chars(TempBuf, JParamInfo3761->group2.f10[num].Address,flg->Dataflag[0],flg->Dataflag[1]);
		}else if(JParamInfo3761->group2.f10[num].ConnectType==30)     //07��Լ���
		{
			DataFlag2007 flg07;
			if (GetDataFlag07By97(flg, &flg07) == 1)
			{
				if ((flg07.Dataflag[0] == 0xff) && (flg07.Dataflag[1] == 0xff)&& (flg07.Dataflag[2] == 0xff) && (flg07.Dataflag[3] == 0xff))
					return 0;
				GetLen = GetDlt645_2007Chars(TempBuf, JParamInfo3761->group2.f10[num].Address,flg07.Dataflag[0], flg07.Dataflag[1],flg07.Dataflag[2], flg07.Dataflag[3]);
			}
			else
			{
				return 0;
			}
		}else if(JParamInfo3761->group2.f10[num].ConnectType==21)//shanghai
		{
			DataFlagSH flgSH;
			if (GetDataFlagSHBy97(flg, &flgSH) == 1)
			{
				if (flgSH.Dataflag[0] == 0xff)
					return 0;
				GetLen = GetDlt645_SHChars(TempBuf, JParamInfo3761->group2.f10[num].Address,flgSH.Dataflag[0]);
			}
			else
			{
				return 0;
			}
		}
		Trn645Buff[len++] = GetLen;//���ĳ���

		for (i = 0; i < GetLen; i++)//Ҫת��������
		{
			Trn645Buff[len++] = TempBuf[i];
		}
		Trn645Buff[len++] = 0x00;//�����ڵ�����0
		//У����
		for (i = 3; i < len; i++)
			Check += Trn645Buff[i];
		Trn645Buff[len++] = (unsigned char) (Check & 0xff);
		Trn645Buff[len++] = 0x16;//������
		Trn645Buff[len_pos++]=len & 0xff;
		Trn645Buff[len_pos]= (len>>8) &0xff;
		SdPrint("�ظ���������   len=%d ",len);
		for (i = 0; i < len; i++)
			SdPrint("%02x ",Trn645Buff[i]);
		SdPrint("\n\r");
		SendStrToCarr(Trn645Buff, len);
		return 1;
	}
	return 0;
}

//��ʼ��ZB������
unsigned int InitZBPointInfo()
{
	unsigned char  Rec645Buff[256];
	unsigned char  Trn645Buff[34];
	int i,k=0,len=0;
	unsigned char Check=0;
	Trn645Buff[len++]=0x68;	//����ͷ
	Trn645Buff[len++]=0x0f;
	Trn645Buff[len++]=0x00;
	//-----------------------
	Trn645Buff[len++]=0x41;//������
	//-----------------------
	Trn645Buff[len++]=0x00;//�û�����
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x04;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//

	Trn645Buff[len++]=0x01;//AFN
	Trn645Buff[len++]=0x02;//
	Trn645Buff[len++]=0x00;//

	for (i = 3; i < len; i++)
		Check += Trn645Buff[i];
	Trn645Buff[len++]=Check;//У����
	Trn645Buff[len++]=0x16;//������
	delay(50);
	SdPrint("\n ��ʼ���ز�ģ���������Ϣ send DataNum = %d .............\n\r",len);
	for(i=0;i<len;i++)
		SdPrint("%02x ",Trn645Buff[i]);
	SdPrint("\n\r");
	SendStrToCarr(Trn645Buff,len);//���ͱ���
	delay(1300);
	while(k<3)
	{
		ClearWaitTimes(ProjectNo,JProgramInfo);
		delay(1300);
		len=ReceiveFromCarr(Rec645Buff);
		k++;
		if(len>0)
			break;
	}
	SdPrint("\n InitZBPointInfo Receive DataNum = %d ............\n\r",len);
	for(i=0;i<len;i++)
		SdPrint("%02x ",Rec645Buff[i]);	//����
	SdPrint("\n\r");
	return 1;
}
/**********************************************
 * ��������
   AFN = 12H - F1
 *********************************************/

unsigned char reboot_read1(void)
{
	unsigned char  Trn645Buff[34];
	int i,len=0;
	unsigned char Check=0;
	Trn645Buff[len++]=0x68;	//����ͷ
	Trn645Buff[len++]=0x0f;
	Trn645Buff[len++]=0x00;
	//-----------------------
	Trn645Buff[len++]=0x41;//������
	//-----------------------
	Trn645Buff[len++]=0x00;//�û�����
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x28;//
	Trn645Buff[len++]=0x64;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//

	Trn645Buff[len++]=0x12;//AFN
	Trn645Buff[len++]=0x01;//
	Trn645Buff[len++]=0x00;//

	for (i = 3; i < len; i++)
		Check += Trn645Buff[i];
	Trn645Buff[len++]=Check;//У����
	Trn645Buff[len++]=0x16;//������
	delay(50);
	SdPrint("\n �ز�ģ������ send DataNum = %d .............\n\r",len);
	for(i=0;i<len;i++)
		SdPrint("%02x ",Trn645Buff[i]);
	SdPrint("\n\r");
	SendStrToCarr(Trn645Buff,len);//���ͱ���
	return 1;
}
/**********************************************
 * ��������
   AFN = 12H - F1
 *********************************************/

unsigned char reboot_read(void)
{
	unsigned char  Rec645Buff[256];
	unsigned char  Trn645Buff[34];
	int i,k=0,len=0;
	unsigned char Check=0;
	Trn645Buff[len++]=0x68;	//����ͷ
	Trn645Buff[len++]=0x0f;
	Trn645Buff[len++]=0x00;
	//-----------------------
	Trn645Buff[len++]=0x41;//������
	//-----------------------
	Trn645Buff[len++]=0x00;//�û�����
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x28;//
	Trn645Buff[len++]=0x64;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//

	Trn645Buff[len++]=0x12;//AFN
	Trn645Buff[len++]=0x01;//
	Trn645Buff[len++]=0x00;//

	for (i = 3; i < len; i++)
		Check += Trn645Buff[i];
	Trn645Buff[len++]=Check;//У����
	Trn645Buff[len++]=0x16;//������
	delay(50);
	SdPrint("\n �ز�ģ������ send DataNum = %d .............\n\r",len);
	for(i=0;i<len;i++)
		SdPrint("%02x ",Trn645Buff[i]);
	SdPrint("\n\r");
	SendStrToCarr(Trn645Buff,len);//���ͱ���
	while(k<5)
	{
		ClearWaitTimes(ProjectNo,JProgramInfo);
		len=ReceiveFromCarr(Rec645Buff);
		k++;
		if(len>0)
			break;
		delay(500);
	}
	SdPrint("\n reboot_read Receive DataNum = %d ............\n\r",len);
	for(i=0;i<len;i++)
		SdPrint("%02x ",Rec645Buff[i]);	//����
	SdPrint("\n\r");
	return 1;
}


/**************************************************
 * �����ɹ���Ա�����Ϣ�Ĵ���
 *************************************************/
void meter_success_alarm(unsigned char cjqNo,unsigned char  MeterNo)
{
	unsigned int ret=0;
	if (JParamInfo3761->group2.f9.Flag[3] & 0x40)
	{
		ret=getPoint(cjqNo,MeterNo);
		if(JParamInfo3761->group2.f10[ret].AlarmFlg[30]&0x40)
		{
			ret=0;
			while(ret<100)
			{
				if(JProgramInfo->stateflags.ErcFlg==0)
					break;
				delay(50);
				ret++;
			}
			memset(&JProgramInfo->CurrErc,0,sizeof(ERC));
			ret=getPoint(cjqNo,MeterNo)+1;
			JProgramInfo->CurrErc.Err31.ERCNo=31;
			JProgramInfo->CurrErc.Err31.len=21;
			JProgramInfo->CurrErc.Err31.ClNo[0]=ret&0xff;
			JProgramInfo->CurrErc.Err31.ClNo[1]=(ret>>8)&0xff;
			JProgramInfo->CurrErc.Err31.ClNo[1]&=0x7F;
			JProgramInfo->stateflags.ErcFlg=31;
			JParamInfo3761->group2.f10[ret].AlarmFlg[30]&=0b10111111;
		}
	}
}
/**************************************************
 * ����ʧ�ܶԱ�����Ϣ�Ĵ���
 *************************************************/
void meter_fail_alarm(unsigned char cjqNo,unsigned char MeterNo)
{
	unsigned int ret=0;

	if (JParamInfo3761->group2.f9.Flag[3] & 0x40)
	{
		ret=getPoint(cjqNo,MeterNo);
		if(!(JParamInfo3761->group2.f10[ret].AlarmFlg[30]&0x40))
		{
			ret=0;
			while(ret<100)
			{
				if(JProgramInfo->stateflags.ErcFlg==0)
					break;
				delay(50);
				ret++;
			}
			memset(&JProgramInfo->CurrErc,0,sizeof(ERC));
			ret=getPoint(cjqNo,MeterNo)+1;
			JProgramInfo->CurrErc.Err31.ERCNo=31;
			JProgramInfo->CurrErc.Err31.len=21;
			JProgramInfo->CurrErc.Err31.ClNo[0]=ret&0xff;
			JProgramInfo->CurrErc.Err31.ClNo[1]=(ret>>8)&0xff;
			JProgramInfo->CurrErc.Err31.ClNo[1]|=0x80;
			JProgramInfo->stateflags.ErcFlg=31;
			JParamInfo3761->group2.f10[ret].AlarmFlg[30]|=0b01000000;
		}
	}
	if (JParamInfo3761->group2.f9.Flag[2] & 0x10)
	{
		ret=getPoint(cjqNo,MeterNo);
		if(!(JParamInfo3761->group2.f10[ret].AlarmFlg[20]&0x10))
		{
			ret=0;
			while(ret<100)
			{
				if(JProgramInfo->stateflags.ErcFlg==0)
					break;
				delay(50);
				ret++;
			}
			memset(&JProgramInfo->CurrErc,0,sizeof(ERC));
			ret=getPoint(cjqNo,MeterNo)+1;
			JProgramInfo->CurrErc.Err21.ERCNo=21;
			JProgramInfo->CurrErc.Err21.len=6;
			JProgramInfo->stateflags.ErcFlg=21;
			JParamInfo3761->group2.f10[ret].AlarmFlg[20]|=0b00010000;
		}
	}
}
void initsmFile(SMFiles *smfiles, int cjqno, int meterno, DataFlag97 *flg97)
{
	TS curts;
	TSGet(&curts);
	memcpy(&smfiles->ts, &curts, sizeof(TS));
	smfiles->sm.CaijiQiNo = cjqno;
	smfiles->sm.MeterNo = meterno;
	ClearWaitTimes(ProjectNo,JProgramInfo);
	if(flg97 != (DataFlag97 *)NULL)
	{
		if((flg97->Dataflag[0]==0x10 && flg97->Dataflag[1]==0xc0)||
			(flg97->Dataflag[0]==0x11 && flg97->Dataflag[1]==0xc0))
		{
			smfiles->systime = time(NULL);
		}
	}
	return;
}
//���������������
void saveZBData(INT8U *filename, DataFlg *datas, fileinfo *fileinfo)
{
	int cjqno, meterno;
	SMFiles	curFiles;
	memset(&curFiles, 0, sizeof(SMFiles));
	SdPrint("\n saveZBData  filename=%s  %02x%02x\n",
			filename,datas->flg.Dataflag[1],datas->flg.Dataflag[0]);
	curFiles.sm.datas[0].flg.Dataflag[0] = datas->flg.Dataflag[0];
	curFiles.sm.datas[0].flg.Dataflag[1] = datas->flg.Dataflag[1];
	memcpy(&curFiles.sm.datas[0].datas[0], &datas->datas[0], DataLenMax);
	cjqno = fileinfo->cldno/64;
	meterno = fileinfo->cldno%64-1;
	initsmFile(&curFiles, cjqno, meterno, &curFiles.sm.datas[0].flg);
	mySaveFile((char*)filename,(INT8U *)&curFiles,FILEHEADSIZE+sizeof(DataFlg),JProgramInfo,fileinfo);
	return;
}
void saveFilebyDataflag(INT8U *filename, DataFiles *fl, DataFlag97 *flg97, int cjqno, int meterno, fileinfo *fileinfo)
{
	int i;
	INT8U reslutBuf[DataLenMax];
	TS ts_dongjie;
	DataFlg datas;
	if(flg97->Dataflag[1]==0xfb && flg97->Dataflag[0]==0x01)
	{
		memset(reslutBuf, 0xee, DataLenMax);
		if(GetManyData(fl->manyFiles.sm.datas, reslutBuf, 0xFB, 0x01)!=0)
		{
			TSGet(&ts_dongjie);
			if((BCD_INT32(&reslutBuf[2],1)!=ts_dongjie.Day) ||
				(BCD_INT32(&reslutBuf[3],1)!=ts_dongjie.Month) ||
				(BCD_INT32(&reslutBuf[4],1)!=(ts_dongjie.Year-2000)))
			{
				syslog(LOG_NOTICE,"\nFB01 ���ڣ�%02x%02x%02x Systime:%02x%02x%02x\n",
						reslutBuf[2],reslutBuf[3],reslutBuf[4],
						ts_dongjie.Day,ts_dongjie.Month, ts_dongjie.Year);
				printf("\nFB01 ���ڣ�%02x%02x%02x Systime:%d %d %d\n",
						reslutBuf[2],reslutBuf[3],reslutBuf[4],
						ts_dongjie.Day,ts_dongjie.Month, ts_dongjie.Year-2000);
				return;
			}
		}
	}

	for (i=0;i<ManyFlagsCount;i++)
	{
		if (fl->manyFiles.sm.datas[i].flg.Dataflag[1]==0x00 && fl->manyFiles.sm.datas[i].flg.Dataflag[0]==0x00)
			continue;
		if (fl->manyFiles.sm.datas[i].flg.Dataflag[1]==0xff && fl->manyFiles.sm.datas[i].flg.Dataflag[0]==0xff)
			continue;
		if (fl->manyFiles.sm.datas[i].flg.Dataflag[1]==OxXX && fl->manyFiles.sm.datas[i].flg.Dataflag[0]==OxXX)
			continue;
		if((flg97->Dataflag[0] == fl->manyFiles.sm.datas[i].flg.Dataflag[0])&&
				(flg97->Dataflag[1] == fl->manyFiles.sm.datas[i].flg.Dataflag[1]))
		{
			datas.flg.Dataflag[0] = flg97->Dataflag[0];
			datas.flg.Dataflag[1] = flg97->Dataflag[1];
			memcpy(&datas.datas[0], &fl->manyFiles.sm.datas[i].datas[0], DataLenMax);
			saveZBData(filename, &datas, &smfileinfo);
		}
	}
}

//void saveHourDongJie_ShangHai(DataFiles *fl, int cjqno, int meterno)
//{
//	//����洢
//	INT8U TempBuf[60];
//	TS ts,curts;
//	int hour=0;
//	int ret = getPoint(cjqno,meterno);
//	SMFiles	dataFiles;
//	INT8U tmpbuf[DataLenMax];
//	TSGet(&curts);
//	for(hour=curts.Hour; hour>=0; hour--)
//	{
//		memset(&dataFiles, 0xee, sizeof(SMFiles));
//		if(GetManyData(fl->manyFiles.sm.datas, dataFiles.sm.datas[0].datas, 0xFD, curts.Hour-hour+1)==0)
//			continue;
//		printf("\n-------------------saveHourDongJie_ShangHai-----------%d-----\n",ret);
//		printf("\n [FD%02x]\n",curts.Hour-hour+1);
//		ts.Minute = 0;
////		ts.Hour = BCD_INT32(&dataFiles.sm.datas[0].datas[1],1);
////		ts.Day = BCD_INT32(&dataFiles.sm.datas[0].datas[2],1);
////		ts.Month = BCD_INT32(&dataFiles.sm.datas[0].datas[3],1);
////		ts.Year = BCD_INT32(&dataFiles.sm.datas[0].datas[4],1)+2000;
//		ts.Hour = hour;
//		ts.Day = curts.Day;
//		ts.Month = curts.Month;
//		ts.Year = curts.Year;
//		memset(TempBuf,0,60);
//		sprintf((char*)TempBuf,"/nand/DataHour/%04d%02d%02d",ts.Year,ts.Month,ts.Day);
//		if (access((char*)TempBuf,0)!=0)//����������Ŀ¼
//		{
//			memset(TempBuf,0,60);
//			sprintf((char*)TempBuf,"%s /nand/DataHour/%04d%02d%02d/",_CMDMKDIR_,ts.Year,ts.Month,ts.Day);
//			system((char*)TempBuf);
//			delay(50);
//		}
//		memset(TempBuf,0,60);
//		sprintf((char*)TempBuf,"/nand/DataHour/%04d%02d%02d/%04d/",ts.Year,ts.Month,ts.Day,ret+1);
//		if (access((char*)TempBuf,0)!=0)//����������Ŀ¼
//		{
//			memset(TempBuf,0,60);
//			sprintf((char*)TempBuf,"%s /nand/DataHour/%04d%02d%02d/%04d/",_CMDMKDIR_,ts.Year,ts.Month,ts.Day,ret+1);
//			system((char*)TempBuf);
//			delay(50);
//		}
//		memset(TempBuf,0,60);
//		sprintf((char*)TempBuf,"/nand/DataHour/%04d%02d%02d/%04d/%04d%02d%02d%02d%02d.dat",
//				ts.Year,ts.Month,ts.Day,ret+1,ts.Year,ts.Month,ts.Day,ts.Hour,ts.Minute);
//		smfileinfo.cldno = getPoint(cjqno,meterno)+1;
//		smfileinfo.ts = ts;
//		smfileinfo.filetype = FILEHOUR;
//		memset(tmpbuf, 0xee, DataLenMax);
//		memcpy(tmpbuf,&dataFiles.sm.datas[0].datas[6],4);
//		memcpy(&dataFiles.sm.datas[0].datas[0], tmpbuf, DataLenMax);
//		dataFiles.sm.datas[0].flg.Dataflag[0] = 0x1f;
//		dataFiles.sm.datas[0].flg.Dataflag[1] = 0x90;
//		saveZBData(TempBuf, &dataFiles.sm.datas[0], &smfileinfo);
//		delay(100);
//
//		memset(tmpbuf, 0xee, DataLenMax);
//		memcpy(tmpbuf,&dataFiles.sm.datas[0].datas[11],4);
//		memcpy(&dataFiles.sm.datas[0].datas[0], tmpbuf, DataLenMax);
//		dataFiles.sm.datas[0].flg.Dataflag[0] = 0x2f;
//		dataFiles.sm.datas[0].flg.Dataflag[1] = 0x90;
//		saveZBData(TempBuf, &dataFiles.sm.datas[0], &smfileinfo);
//		delay(50);
//	}
//	return;
//}
void saveHourDongJie_ShangHai(DataFiles *fl, int cjqno, int meterno, DataFlag97 *flg97)
{
	//����洢
	INT8U TempBuf[60];
	TS ts,curts;
	int ret = getPoint(cjqno,meterno);
	SMFiles	dataFiles;
	INT8U tmpbuf[DataLenMax];
	TSGet(&curts);
	if(flg97->Dataflag[1]==0xFD)
	{
		memset(&dataFiles, 0xee, sizeof(SMFiles));
		if(GetManyData(fl->manyFiles.sm.datas, dataFiles.sm.datas[0].datas, flg97->Dataflag[1], flg97->Dataflag[0])==0)
			return;
		printf("\n-------------------saveHourDongJie_ShangHai-----------%d--%02x%02x----%02x%02x-\n",
				ret,flg97->Dataflag[1],flg97->Dataflag[0],
				dataFiles.sm.datas[0].datas[6],dataFiles.sm.datas[0].datas[11]);
		printf("\n [FD%02x]\n",flg97->Dataflag[0]);
		ts.Minute = 0;
//		ts.Hour = BCD_INT32(&dataFiles.sm.datas[0].datas[1],1);
//		ts.Day = BCD_INT32(&dataFiles.sm.datas[0].datas[2],1);
//		ts.Month = BCD_INT32(&dataFiles.sm.datas[0].datas[3],1);
//		ts.Year = BCD_INT32(&dataFiles.sm.datas[0].datas[4],1)+2000;
		TimeDecrease(&curts,3,flg97->Dataflag[0]-1);
		ts.Hour = curts.Hour;
		ts.Day = curts.Day;
		ts.Month = curts.Month;
		ts.Year = curts.Year;
		memset(TempBuf,0,60);
		sprintf((char*)TempBuf,"/nand/DataHour/%04d%02d%02d",ts.Year,ts.Month,ts.Day);
		if (access((char*)TempBuf,0)!=0)//����������Ŀ¼
		{
			memset(TempBuf,0,60);
			sprintf((char*)TempBuf,"%s /nand/DataHour/%04d%02d%02d/",_CMDMKDIR_,ts.Year,ts.Month,ts.Day);
			system((char*)TempBuf);
			delay(50);
		}
		memset(TempBuf,0,60);
		sprintf((char*)TempBuf,"/nand/DataHour/%04d%02d%02d/%04d/",ts.Year,ts.Month,ts.Day,ret+1);
		if (access((char*)TempBuf,0)!=0)//����������Ŀ¼
		{
			memset(TempBuf,0,60);
			sprintf((char*)TempBuf,"%s /nand/DataHour/%04d%02d%02d/%04d/",_CMDMKDIR_,ts.Year,ts.Month,ts.Day,ret+1);
			system((char*)TempBuf);
			delay(50);
		}
		memset(TempBuf,0,60);
		sprintf((char*)TempBuf,"/nand/DataHour/%04d%02d%02d/%04d/%04d%02d%02d%02d%02d.dat",
				ts.Year,ts.Month,ts.Day,ret+1,ts.Year,ts.Month,ts.Day,ts.Hour,ts.Minute);
		smfileinfo.cldno = getPoint(cjqno,meterno)+1;
		smfileinfo.ts = ts;
		smfileinfo.filetype = FILEHOUR;
		memcpy(tmpbuf, &dataFiles.sm.datas[0].datas[0], DataLenMax);

		memset(&dataFiles.sm.datas[0].datas[0], 0xee, DataLenMax);
		memcpy(&dataFiles.sm.datas[0].datas[0], &tmpbuf[6], 4);
		dataFiles.sm.datas[0].flg.Dataflag[0] = 0x1f;
		dataFiles.sm.datas[0].flg.Dataflag[1] = 0x90;
		saveZBData(TempBuf, &dataFiles.sm.datas[0], &smfileinfo);
		delay(100);

		memset(&dataFiles.sm.datas[0].datas[0], 0xee, DataLenMax);
		memcpy(&dataFiles.sm.datas[0].datas[0], &tmpbuf[11], 4);
		dataFiles.sm.datas[0].flg.Dataflag[0] = 0x2f;
		dataFiles.sm.datas[0].flg.Dataflag[1] = 0x90;
		saveZBData(TempBuf, &dataFiles.sm.datas[0], &smfileinfo);
		delay(50);
	}
	return;
}
void saveDayDongJie_ShangHai(DataFiles *fl, int cjqno, int meterno, DataFlag97 *flg97)
{
	//����洢
	INT8U TempBuf[60];
	TS ts,curts;
	int i=0;
	int ret = getPoint(cjqno,meterno);
	SMFiles	tmpFiles;
	TSGet(&curts);
	if(flg97->Dataflag[1]!=0xFB)
		return;
	for(i=0; i<3; i++)
	{
		memset(&tmpFiles, 0xee, sizeof(SMFiles));
		if(!GetManyData(fl->manyFiles.sm.datas, tmpFiles.sm.datas[0].datas, 0xFB, 16*i+1))
			continue;
		if(!GetManyData(fl->manyFiles.sm.datas, tmpFiles.sm.datas[1].datas, 0xFB, 16*i+2))
			continue;
		if(!GetManyData(fl->manyFiles.sm.datas, tmpFiles.sm.datas[2].datas, 0xFB, 16*i+3))
			continue;
		printf("\n-------------------saveDayDongJie_ShangHai----------------\n");
		ts.Minute = 0;
		ts.Hour	  =	0;
		ts.Day	  = BCD_INT32(&tmpFiles.sm.datas[0].datas[2],1);
		ts.Month  = BCD_INT32(&tmpFiles.sm.datas[0].datas[3],1);
		ts.Year   = BCD_INT32(&tmpFiles.sm.datas[0].datas[4],1);
		memset(TempBuf,0,60);
		sprintf((char*)TempBuf,"/nand/DataDay/%04d",ret+1);
		if (access((char*)TempBuf,0)!=0)//����������Ŀ¼
		{
			memset(TempBuf,0,60);
			sprintf((char*)TempBuf,"%s /nand/DataDay/%04d",_CMDMKDIR_, ret+1);
			system((char*)TempBuf);
			delay(50);
		}
		memset(TempBuf,0,60);
		sprintf((char*)TempBuf,"/nand/DataDay/%04d/%02d.dat", ret+1, ts.Day);
		smfileinfo.cldno = ret+1;
		smfileinfo.ts = ts;
		smfileinfo.filetype = FILEDAY;
		tmpFiles.sm.datas[0].flg.Dataflag[0] = 0x01;
		tmpFiles.sm.datas[0].flg.Dataflag[1] = 0xFB;
		saveZBData(TempBuf, &tmpFiles.sm.datas[0], &smfileinfo);
		delay(100);
		tmpFiles.sm.datas[1].flg.Dataflag[0] = 0x02;
		tmpFiles.sm.datas[1].flg.Dataflag[1] = 0xFB;
		saveZBData(TempBuf, &tmpFiles.sm.datas[1], &smfileinfo);
		delay(100);
		tmpFiles.sm.datas[1].flg.Dataflag[0] = 0x1f;
		tmpFiles.sm.datas[1].flg.Dataflag[1] = 0x90;
		saveZBData(TempBuf, &tmpFiles.sm.datas[1], &smfileinfo);
		delay(100);
		tmpFiles.sm.datas[2].flg.Dataflag[0] = 0x03;
		tmpFiles.sm.datas[2].flg.Dataflag[1] = 0xFB;
		saveZBData(TempBuf, &tmpFiles.sm.datas[2], &smfileinfo);
		delay(100);
		tmpFiles.sm.datas[2].flg.Dataflag[0] = 0x2f;
		tmpFiles.sm.datas[2].flg.Dataflag[1] = 0x90;
		saveZBData(TempBuf, &tmpFiles.sm.datas[2], &smfileinfo);
	}
	return;
}


void saveMonthDongJie_ShangHai(DataFiles *fl, int cjqno, int meterno, DataFlag97 *flg97)
{
	//���´洢
	INT8U TempBuf[60];
	TS ts,curts;
	int ret = getPoint(cjqno,meterno);
	SMFiles	dataFiles;
	INT8U flag_1f=0,flag_2f=0;
	//for(i=0; i<2; i++)
	if(flg97->Dataflag[1]==0x94 || flg97->Dataflag[1]==0x98)
	{
		memset(&dataFiles, 0xee, sizeof(SMFiles));
		fprintf(stderr,"\n-------------------saveMonthDongJie_ShangHai----------------begin\n");
		if(flg97->Dataflag[0]==0x1f)
		{
			if(GetManyData(fl->manyFiles.sm.datas, dataFiles.sm.datas[0].datas, flg97->Dataflag[1], 0x1f)!=0)
				flag_1f = 1;
			else
			{
				fprintf(stderr,"\n saveMonthDongJie_ShangHai 1f��%02x%02x\n",flg97->Dataflag[1],flg97->Dataflag[0]);
				return;
			}
		}
		if(flg97->Dataflag[0]==0x2f)
		{
			if(GetManyData(fl->manyFiles.sm.datas, dataFiles.sm.datas[1].datas, flg97->Dataflag[1], 0x2f)!=0)
				flag_2f = 1;
			else
			{
				fprintf(stderr,"\n saveMonthDongJie_ShangHai 2f��%02x%02x\n",flg97->Dataflag[1],flg97->Dataflag[0]);
				return;
			}
		}
	}
	TSGet(&curts);
	if(flg97->Dataflag[1]==0x98)
		TimeDecrease(&curts, 5, 1);
	ts.Minute = 0;
	ts.Hour	  =	0;
	ts.Day	  = 1;
	ts.Month  = curts.Month;
	ts.Year   = curts.Year;

	memset(TempBuf,0,60);
	sprintf((char*)TempBuf,"/nand/DataMonth/%04d",ret+1);
	if (access((char*)TempBuf,0)!=0)//����������Ŀ¼
	{
		memset(TempBuf,0,60);
		sprintf((char*)TempBuf,"%s /nand/DataMonth/%04d",_CMDMKDIR_, ret+1);
		system((char*)TempBuf);
		delay(50);
	}
	memset(TempBuf,0,60);
	sprintf((char*)TempBuf,"/nand/DataMonth/%04d/%02d.dat", ret+1, ts.Month);
	sprintf((char*)TempBuf,"/nand/DataMonth/%04d/%02d.dat", ret+1, ts.Month);
	smfileinfo.cldno = ret+1;
	smfileinfo.ts = ts;
	smfileinfo.filetype = FILEMONTH;
	if(flag_1f == 1)
	{
		dataFiles.sm.datas[0].flg.Dataflag[0] = 0x1f;
		dataFiles.sm.datas[0].flg.Dataflag[1] = 0x90;
		saveZBData(TempBuf, &dataFiles.sm.datas[0], &smfileinfo);
		delay(100);
	}
	if(flag_2f == 1)
	{
		dataFiles.sm.datas[1].flg.Dataflag[0] = 0x2f;
		dataFiles.sm.datas[1].flg.Dataflag[1] = 0x90;
		saveZBData(TempBuf, &dataFiles.sm.datas[1], &smfileinfo);
		delay(100);
	}
	if(flag_1f == 1 || flag_2f == 1)
	{
		dataFiles.sm.datas[2].flg.Dataflag[0] = 0x01;
		dataFiles.sm.datas[2].flg.Dataflag[1] = 0xFB;
		dataFiles.sm.datas[2].datas[0]=0;
		dataFiles.sm.datas[2].datas[1]=0;
		dataFiles.sm.datas[2].datas[2]=1;
		INT32U_BCD(ts.Month, &dataFiles.sm.datas[2].datas[3], 1);
		INT32U_BCD(ts.Year-2000,&dataFiles.sm.datas[2].datas[4],1);
		saveZBData(TempBuf, &dataFiles.sm.datas[2], &smfileinfo);
		delay(100);
	}
	if(flag_1f == 1)
	{
		dataFiles.sm.datas[0].flg.Dataflag[0] = 0x02;
		dataFiles.sm.datas[0].flg.Dataflag[1] = 0xFB;
		saveZBData(TempBuf, &dataFiles.sm.datas[0], &smfileinfo);
		delay(100);
	}
	if(flag_2f == 1)
	{
		dataFiles.sm.datas[1].flg.Dataflag[0] = 0x03;
		dataFiles.sm.datas[1].flg.Dataflag[1] = 0xFB;
		saveZBData(TempBuf, &dataFiles.sm.datas[1], &smfileinfo);
		delay(100);
	}
	fprintf(stderr,"\n-------------------saveMonthDongJie_ShangHai----------------end\n");
	return;
}

/**************************************************
 * �����ɹ������ݵĴ洢
 *************************************************/
void meter_success_curr(CurMeterInfo *curMeters, DataFiles *fl, TS ts, DataFlag97 *flg97)
{
	int dest_flgcount=0,i=0, ret_flgcount=0;
	unsigned char TempBuf[120];
	unsigned char Command[120];
	unsigned int ret=0;
	ret=getPoint(curMeters->cjqNo,curMeters->MeterNo)+1;
	SdPrint("enter save currData meter=%d******************************!\n\r",ret);
	memset(TempBuf,0,60);
	sprintf((char*)TempBuf,"/nand/DataCurr/%04d/",ret);
	if (access((char*)TempBuf,0)!=0)//��Ŀ¼�����ڣ��ȴ���
	{
		memset(Command,0,60);
		sprintf((char*)Command,"%s /nand/DataCurr/%04d/",_CMDMKDIR_,ret);
		system((char*)Command);
		delay(100);
	 }
	memset(TempBuf,0,60);
	sprintf((char*)TempBuf,"/nand/DataDay/%04d/",ret);//��Ŀ¼�����ڣ��ȴ���
	if (access((char*)TempBuf,0)!=0)
	{
		memset(Command,0,60);
		sprintf((char*)Command,"%s /nand/DataDay/%04d/",_CMDMKDIR_,ret);
		system((char*)Command);
		delay(100);
	}
	memset(TempBuf,0,60);
	sprintf((char*)TempBuf,"/nand/DataMonth/%04d/",ret);//��Ŀ¼�����ڣ��ȴ���
	if (access((char*)TempBuf,0)!=0)
	{
		memset(Command,0,60);
		sprintf((char*)Command,"%s /nand/DataMonth/%04d/",_CMDMKDIR_,ret);
		system((char*)Command);
		delay(100);
	}
	memset(TempBuf,0,60);
	sprintf((char*)TempBuf,"/nand/DataCurr/%04d/curr.dat",ret);
	if (access((char*)TempBuf,0)==0)//��curr.dat����last.dat
	{
		memset(Command,0,120);
		sprintf((char*)Command,"%s /nand/DataCurr/%04d/curr.dat /nand/DataCurr/%04d/last.dat", _CMDCP_,ret,ret);
		system((char*)Command);
		delay(50);
	}
	fl->manyFiles.ts=ts;
	fl->manyFiles.sm.CaijiQiNo=curMeters->cjqNo;
	fl->manyFiles.sm.MeterNo=curMeters->MeterNo;
	//shanghai------------------->>//�Ϻ���Լ������ʱ����һ���������Ҫ�ֳ������򼸸�������洢
	ret=getPoint(curMeters->cjqNo,curMeters->MeterNo);
	destflg97[dest_flgcount].Dataflag[0] = flg97->Dataflag[0];
	destflg97[dest_flgcount].Dataflag[1] = flg97->Dataflag[1];
	dest_flgcount++;
	ret_flgcount= Dlt645_ShangHai(ret, fl, curMeters, flg97);
	//printf("\ndest_flgcount=%d  ret_flgcount=%d\n",dest_flgcount, ret_flgcount);
	dest_flgcount = dest_flgcount + ret_flgcount;
	memset(TempBuf,0,60);
	sprintf((char*)TempBuf,"/nand/DataCurr/%04d/curr.dat",ret+1);
	smfileinfo.cldno = ret+1;
	smfileinfo.ts = ts;
	smfileinfo.filetype = FILECURR;
	for(i=0; i<dest_flgcount; i++)
	{
		printf("\n saveFilebyDataflag dest_flgcount = %d  %s  [%02x%02x]\n",dest_flgcount, TempBuf, destflg97[i].Dataflag[1],destflg97[i].Dataflag[0]);
		saveFilebyDataflag(TempBuf, fl, &destflg97[i],curMeters->cjqNo,curMeters->MeterNo, &smfileinfo);
	}
//void initsmFile(DataFiles *fl, int cjqno, int meterno)
	fprintf(stderr,"\n++++++++currts_buchao.Hour=%d+++++++++++++++++++++++%02x%02x\n",currts_buchao.Hour,flg97->Dataflag[1],flg97->Dataflag[0]);
	if(currts_buchao.Hour>=BUCHAO_BEGIN_TIME && currts_buchao.Hour<BUCHAO_END_TIME)//һ�㵽4�㲹��
	{
		if(JParamInfo3761->group2.f10[ret].ConnectType==21)
		{
			saveMonthDongJie_ShangHai(fl, curMeters->cjqNo, curMeters->MeterNo,flg97);
		}else
		{
			if(curMeters->flType == common)
			{
				saveDayDongJie_ShangHai(fl, curMeters->cjqNo,curMeters->MeterNo,flg97);
				saveMonthDongJie_ShangHai(fl, curMeters->cjqNo,curMeters->MeterNo,flg97);
			}else if(curMeters->flType == many)//fl ret
			{
				saveDayDongJie_ShangHai(fl, curMeters->cjqNo,curMeters->MeterNo,flg97);
				saveMonthDongJie_ShangHai(fl, curMeters->cjqNo,curMeters->MeterNo,flg97);
				saveHourDongJie_ShangHai(fl, curMeters->cjqNo,curMeters->MeterNo,flg97);
			}
		}
	}
	//-------------------------------------------------------------<<
//	fl->manyFiles.ts=ts;
//	fl->manyFiles.sm.CaijiQiNo=curMeters->cjqNo;
//	fl->manyFiles.sm.MeterNo=curMeters->MeterNo;
//
//	SdPrint("exece save currData meter=%d******************************!\n\r",ret);
//	mySaveFile((char*)TempBuf,(INT8U *)&fl->manyFiles,FILEHEADSIZE+curMeters->flgCount*sizeof(DataFlg));
//	delay(50);
//	//9.28
//	if(JProgramInfo->zone) {
//		memset(Command,0,120);
//		sprintf((char*)Command,"%s -rf %s /nand/DataDay/%04d/%02d.dat",_CMDCP_, TempBuf, ret, ts.Day);
//		system((char*)Command);
//	}
}

/**************************************************
 * ����ʧ�ܶ����ݵĴ洢
 *************************************************/
void meter_fail_curr(unsigned char cjqNo,unsigned char MeterNo,TS ts)
{
	unsigned char TempBuf[60];
	unsigned char Command[120];
	unsigned int ret=0;
	ret=getPoint(cjqNo,MeterNo)+1;
	SdPrint(" meter_fail_curr  enter rm currData meter=%d******************************!\n\r",ret);
	memset(TempBuf,0,60);
	sprintf((char*)TempBuf,"/nand/DataCurr/%04d/",ret);
	if (access((char*)TempBuf,0)!=0)//��Ŀ¼�����ڣ�����Ŀ¼
	{
		memset(Command,0,60);
		sprintf((char*)Command,"%s /nand/DataCurr/%04d/",_CMDMKDIR_,ret);
		system((char*)Command);
		delay(100);
	 }

	memset(TempBuf,0,60);
	sprintf((char*)TempBuf,"/nand/DataCurr/%04d/curr.dat",ret);
	if (access((char*)TempBuf,0)==0)//��ǰʧ�ܣ�������last.dat�� ɾ��curr.dat
	{
		memset(Command,0,120);
		sprintf((char*)Command,"%s /nand/DataCurr/%04d/curr.dat /nand/DataCurr/%04d/last.dat",
				_CMDCP_,ret,ret);
		system((char*)Command);
		delay(50);
		if ((reflg==0)&&(ts.Hour>5))
		{
			memset(Command,0,120);
			SdPrint("exec rm currData meter=%d******************************!\n\r",ret);
			sprintf((char*)Command,"%s /nand/DataCurr/%04d/curr.dat",_CMDRM_,ret);
			//system((char*)Command);  //������
			delay(50);
		}
	}
}
//��������Ϣ�ı��־ ������ֵ 0 �ޱ仯     1 �б仯
INT8U CeLingDianChange_Check()
{
	int i,ret_flag=0,j=0;
	ClearWaitTimes(ProjectNo,JProgramInfo);
	for(i=0;i<PointMax;i++)
	{
		if((JParamInfo3761->group2.f10[i].port==CarrWavePort)||(JParamInfo3761->group2.f10[i].port==LocalCommPort))
		{
//			printf("\n i OldPoints[%d] %02x%02x%02x%02x%02x%02x �Ƚϲ�����  pt[%d].Address  %02x%02x%02x%02x%02x%02x\n",
//					i,
//					OldPoints[i].Address[5],OldPoints[i].Address[4],OldPoints[i].Address[3],
//					OldPoints[i].Address[2],OldPoints[i].Address[1],OldPoints[i].Address[0],
//					i,
//					JParamInfo3761->group2.f10[i].Address[5],
//					JParamInfo3761->group2.f10[i].Address[4],
//					JParamInfo3761->group2.f10[i].Address[3],
//					JParamInfo3761->group2.f10[i].Address[2],
//					JParamInfo3761->group2.f10[i].Address[1],
//					JParamInfo3761->group2.f10[i].Address[0]);
			ClearWaitTimes(ProjectNo,JProgramInfo);
			if ((JParamInfo3761->group2.f10[i].Address[0]==0xff) && (JParamInfo3761->group2.f10[i].Address[1]==0xff) &&
				(JParamInfo3761->group2.f10[i].Address[2]==0xff) &&	(JParamInfo3761->group2.f10[i].Address[3]==0xff) &&
				(JParamInfo3761->group2.f10[i].Address[4]==0xff) && (JParamInfo3761->group2.f10[i].Address[5]==0xff))
				continue;
			if ((JParamInfo3761->group2.f10[i].Address[0]==0x00) && (JParamInfo3761->group2.f10[i].Address[1]==0x00) &&
				(JParamInfo3761->group2.f10[i].Address[2]==0x00) &&	(JParamInfo3761->group2.f10[i].Address[3]==0x00) &&
				(JParamInfo3761->group2.f10[i].Address[4]==0x00) && (JParamInfo3761->group2.f10[i].Address[5]==0x00))
				continue;
			if( (OldPoints[i].ConnectType != JParamInfo3761->group2.f10[i].ConnectType)	||
				(OldPoints[i].Status != JParamInfo3761->group2.f10[i].Status)			||
				(OldPoints[i].baudrate != JParamInfo3761->group2.f10[i].baudrate)		||
				(OldPoints[i].port != JParamInfo3761->group2.f10[i].port)				||
				(memcmp(&OldPoints[i].Address[0], &JParamInfo3761->group2.f10[i].Address[0],6)!=0)||
				(memcmp(&OldPoints[i].CaijiqiAddress[0], &JParamInfo3761->group2.f10[i].CaijiqiAddress[0],6)!=0))
			{
				ClearWaitTimes(ProjectNo,JProgramInfo);
				Flag_MeterChange = 1;
				ret_flag = 1;
				printf("\n������ı�-----------------------��ʼ�ȶԼ������ز����� i %d\n",i);
				for(j=0;j<PointMax;j++)
				{
					if((JParamInfo3761->group2.f10[j].port==CarrWavePort)||(JParamInfo3761->group2.f10[j].port==LocalCommPort))
					{
						if ((JParamInfo3761->group2.f10[j].Address[0]==0xff) && (JParamInfo3761->group2.f10[j].Address[1]==0xff) &&
							(JParamInfo3761->group2.f10[j].Address[2]==0xff) &&	(JParamInfo3761->group2.f10[j].Address[3]==0xff) &&
							(JParamInfo3761->group2.f10[j].Address[4]==0xff) && (JParamInfo3761->group2.f10[j].Address[5]==0xff))
							continue;
						if ((JParamInfo3761->group2.f10[j].Address[0]==0x00) && (JParamInfo3761->group2.f10[j].Address[1]==0x00) &&
							(JParamInfo3761->group2.f10[j].Address[2]==0x00) &&	(JParamInfo3761->group2.f10[j].Address[3]==0x00) &&
							(JParamInfo3761->group2.f10[j].Address[4]==0x00) && (JParamInfo3761->group2.f10[j].Address[5]==0x00))
							continue;
						memcpy(&OldPoints[j].Address[0], &JParamInfo3761->group2.f10[j].Address[0],6);
						memcpy(&OldPoints[j].CaijiqiAddress[0], &JParamInfo3761->group2.f10[j].CaijiqiAddress[0],6);
						OldPoints[j].ConnectType = JParamInfo3761->group2.f10[j].ConnectType;
						OldPoints[j].Status = JParamInfo3761->group2.f10[j].Status;
						OldPoints[j].baudrate = JParamInfo3761->group2.f10[j].baudrate;
						OldPoints[j].port = JParamInfo3761->group2.f10[j].port;
					}
					ClearWaitTimes(ProjectNo,JProgramInfo);
				}
			}
		}
	}
	return ret_flag;
}
//shanghai
//���Ϻ��Ķ����������
unsigned char ReadshanghaiFlags(unsigned char *filename, DataFlag97 *flg97)   //��ʼ��97��07��Լ��ʶ����ձ�
{
	FILE    *fp;
	char ln[100];
	char tmp[3];
	int i=0;
	unsigned char TempBuf[60];
	memset(TempBuf,0,60);
	sprintf((char *)TempBuf,"%s/%s",_CFGDIR_, filename);
	//sprintf((char *)TempBuf,"%s/AddtionalFlags.cfg",_CFGDIR_);
	sprintf(tmp,"sss");
	struct timespec tsspec;
	if (clock_gettime(CLOCK_REALTIME, &tsspec)==-1)
		printf("clock_gettime error\n\r");
	tsspec.tv_sec += 3;
	sem_timedwait(&JProgramInfo->mainData.UseFileFlg,&tsspec);
	fp = fopen((char *)TempBuf,"r");
	if(fp==NULL)
	{
	   sem_post(&JProgramInfo->mainData.UseFileFlg);
	   return 0;
	}
	for(;;)
	{
		memset(ln,0,sizeof(ln));
		fscanf(fp,"%s",ln);//��һ����fd��ִ�и�ʽ������
		if(strncmp(ln,"begin",5)==0)continue;//����������������������ȡ
		if(strncmp(ln,"end",sizeof(ln))==0)break;
		if(strncmp(ln,"//",2)==0)continue;//����ע��������������
		if(strlen(ln)<4)continue;
		tmp[0]=ln[0]; tmp[1]=ln[1];
		flg97[i].Dataflag[1]=strtol(tmp,NULL,16);
		tmp[0]=ln[2]; tmp[1]=ln[3];
		flg97[i].Dataflag[0]=strtol(tmp,NULL,16);
		flg97[i].ReadFlg=1;
		if(strlen(ln)>5)
		{
			if (ln[4]==',')
			{
				flg97[i].ReadFlg=ln[5]-'0';
			}
		}
		//printf("%02x--%02x\n\r",flg97[i].Dataflag[1],flg97[i].Dataflag[0]);
	//	printString2(&flg97[i],2,2);
		i++;
		if (i>=200)
			break;
	}//end while1
   fclose(fp);
   fp=NULL;
	sem_post(&JProgramInfo->mainData.UseFileFlg);
   return i;
}
int IsDayDongJieFile(int cldno)//���ĳ���������ǰ������ն����ļ��Ƿ���� ����һ�� �����ڷ���0 ���򷵻�1
{
	INT8U TempBuf[60], retflg=0, retflg1=0, retflg2=0, retflg3=0;
	TS curts;
	TSGet(&curts);
	memset(TempBuf,0,60);
	sprintf((char*)TempBuf,"/nand/DataDay/%04d/%02d.dat", cldno, curts.Day);
	if(access((char*)TempBuf,0)==0)
		retflg1 = 1;
	TimeDecrease(&curts, 4, 1);
	sprintf((char*)TempBuf,"/nand/DataDay/%04d/%02d.dat", cldno, curts.Day);
	if(access((char*)TempBuf,0)==0)
		retflg2 = 1;
	TimeDecrease(&curts, 4, 1);
	sprintf((char*)TempBuf,"/nand/DataDay/%04d/%02d.dat", cldno, curts.Day);
	if(access((char*)TempBuf,0)==0)
		retflg3 = 1;
	if(retflg1==0 || retflg2==0 || retflg3==0)
		retflg = 0;
	else
		retflg = 1;
	return retflg;
}
int IsMonthDongJieFile(int cldno)//���ĳ���������ǰ�������¶����ļ��Ƿ���� ����һ�� �����ڷ���0 ���򷵻�1
{
	INT8U TempBuf[60], retflg=0, retflg1=0, retflg2=0;
	TS curts;
	TSGet(&curts);
	memset(TempBuf,0,60);
	sprintf((char*)TempBuf,"/nand/DataMonth/%04d/%02d.dat", cldno, curts.Month);
	if(access((char*)TempBuf,0)==0)
		retflg1 = 1;
	TimeDecrease(&curts, 5, 1);
	sprintf((char*)TempBuf,"/nand/DataMonth/%04d/%02d.dat", cldno, curts.Month);
	if(access((char*)TempBuf,0)==0)
		retflg2 = 1;
	if(retflg1==0 || retflg2==0)
		retflg = 0;
	else
		retflg = 1;
	return retflg;
}

/***************************************************
 * ��ʱ��������
 ***************************************************/
void time_read_dates(void) //���з���firflg 5�ı��6
{
	int kk=0;
	TS ts;
	TSGet(&ts);
	DataFlag2007 flg07;
	unsigned char Rec645Buff[512];
	int firflg=0,tmp=0;
	int mm=0, mm_flndflg=0;
	update485info();//����485������Ϣ
	int flg_index=0;
	if((JParamInfo3761->group11.f111.Enable&0x01)==MANUAL)
	{
		if(CeLingDianChange_Check()==1)
		{
			isCLDChanged = 1;
			return;
		}
	}
	if((tmp=ReadHaved(ts,3))>=1)                //����Ƿ��˳���ʱ�䣬���˳���ʱ�䷵��5��û������ʱ�䷵��0
		firflg=tmp;
	if(JDataFileInfo->data485[29+PortBegNum].ChaobiaoSta==2)
	{
		//printf("\nChaobiaoSta==2  �ָ����� \n");
		firflg = CarrWavePort;
	}
	if(JDataFileInfo->data485[29+PortBegNum].ChaobiaoSta==1)
	{
	///	printf("\nChaobiaoSta==1 ��ͣ����i\n");
		return;
	}
	if((rset_read_ab_flg==0) && (firflg==0))			//�ϵ����������ж�
	{
		SdPrint("\n �ϵ���������...........\n");
		rset_read_ab_flg=1;
		firflg=CarrWavePort;
	}
	if((Flag_MeterChange==1) && (firflg==0))			//ZBtiaoshi + ������ı��ж�
	{
		SdPrint("Meter is changed          firflg=%d\n\r",firflg);
		firflg=CarrWavePort;
		Flag_MeterChange = 0;
	}
	//if(Jmemory->GuoWangSoftTest==1)
	firflg = CarrWavePort;//ʼ�ճ���
	SdPrint("\nfirflg=%d   rset_read_ab_flg %d  Flag_MeterChange %d JDataFileInfo->data485[29+PortBegNum].MeterNum=%d\n\r",
			firflg,rset_read_ab_flg,Flag_MeterChange,JDataFileInfo->data485[29+PortBegNum].MeterNum);
    //��ʼ��������Ϣ
    memset(&JDataFileInfo->data485[CarrWavePort-PortBegNum].ts, 0, sizeof(TS));
    memset(&JDataFileInfo->data485[CarrWavePort-PortBegNum].ts_begin, 0, sizeof(TS));
    JDataFileInfo->data485[CarrWavePort-PortBegNum].MeterNum_CBSucc = 0;
    JDataFileInfo->data485[CarrWavePort-PortBegNum].ZhongDianMeterNum_CBOK = 0;
    memset(&JDataFileInfo->data485[31-PortBegNum].ts, 0, sizeof(TS));
    memset(&JDataFileInfo->data485[31-PortBegNum].ts_begin, 0, sizeof(TS));
    JDataFileInfo->data485[31-PortBegNum].MeterNum_CBSucc = 0;
    JDataFileInfo->data485[31-PortBegNum].ZhongDianMeterNum_CBOK = 0;
    if(firflg ==0)
    	return;
    if(JDataFileInfo->data485[CarrWavePort-PortBegNum].MeterNum==0 && JDataFileInfo->data485[29+PortBegNum].MeterNum==0)//9.4gai
    {
    	SdPrint("\n---------JDataFileInfo->data485[CarrWavePort-PortBegNum].MeterNum==0 && JDataFileInfo->data485[29+PortBegNum].MeterNum==0--------------------------3\n\r");
    //	return;
    }
    JDataFileInfo->data485[CarrWavePort-PortBegNum].Flag = 2; //���ڳ���
    JDataFileInfo->data485[CarrWavePort-PortBegNum].ts_begin = ts;
    JDataFileInfo->data485[31-PortBegNum].Flag = 2; //���ڳ���
    JDataFileInfo->data485[31-PortBegNum].ts_begin = ts;
   // memcpy(&JDataFileInfo->data485[31-PortBegNum], &JDataFileInfo->data485[ CarrWavePort-PortBegNum],sizeof(Data485));
	unsigned char flgCount=0,flgcnt=0,cmflg=0,mmflg=0;
	unsigned int i=0,j=0,k=0,nn,l=0,n=0;
	int result;

	fprintf(stderr,"\n-----%d  %d-----\n",JProgramInfo->Para.meterFlags.CommDayFlagsCount,
		JProgramInfo->Para.meterFlags.ManyDayFlagsCount);
	//1��ȡ��Ч������Ϣ����CurMeters
	//CurMeters curMeters;//��ǰҪ����һ��������Ϣ

	memset(&cflgn,0,sizeof(cflgn));
	for(flgCount=0;flgCount<JProgramInfo->Para.meterFlags.CommDayFlagsCount;flgCount++)
	{
		if (!((JProgramInfo->Para.meterFlags.CommDayFlags[flgCount].ReadFlg&0x02)==0x02))   //0x02Ϊ���߳���
			continue;
		cflgn[cmflg].Dataflag[0]=JProgramInfo->Para.meterFlags.CommDayFlags[flgCount].Dataflag[0];             //��ȡ���Գ����ı�ʾ
		cflgn[cmflg].Dataflag[1]=JProgramInfo->Para.meterFlags.CommDayFlags[flgCount].Dataflag[1];
		cmflg++; //�����ز������˿ڵĵ��������ݱ�ʶ����
	}
	memset(&mflgn,0,sizeof(mflgn));
	for(flgCount=0;flgCount<JProgramInfo->Para.meterFlags.ManyDayFlagsCount;flgCount++)   //JProgramInfo->Para.meterFlags.ManyDayFlagsCount����CommonDayFlags.cfg��ֵ
	{
		if (!((JProgramInfo->Para.meterFlags.ManyDayFlags[flgCount].ReadFlg&0x02)==0x02))
			continue;
		mflgn[mmflg].Dataflag[0]=JProgramInfo->Para.meterFlags.ManyDayFlags[flgCount].Dataflag[0];
		mflgn[mmflg].Dataflag[1]=JProgramInfo->Para.meterFlags.ManyDayFlags[flgCount].Dataflag[1];
		mmflg++;    //�����ز������˿ڵĶ๦�ܵ�����ݱ�ʶ����
	}
    //shanghai?  �ص��û��ͷ��ص��û������Ķ����������--------------------->>
	unsigned char name[60];
    DataFlag97	shanghaiCommFlags[50],shanghaiManyFlags[50];//shanghai �����Ϻ��ص��û� ���ص��û����Ⳮ����������
    int shanghai_commcount=0,shanghai_manycount=0;
	if(currts_buchao.Hour>=BUCHAO_BEGIN_TIME && currts_buchao.Hour<BUCHAO_END_TIME)//һ�㵽4�㲹��
    {//�Ϻ����Ჹ��Ҫ����������
		printf("\nһ�㵽4�㲹��\n");
		memset(shanghaiCommFlags, 0, 50*sizeof(DataFlag97));
		memset(name, 0, 60);
		sprintf((char*)name, "%s", "AddtionalCommFlags.cfg");
		shanghai_commcount = ReadshanghaiFlags(name, shanghaiCommFlags);

		memset(shanghaiManyFlags, 0, 50*sizeof(DataFlag97));
		memset(name, 0, 60);
		sprintf((char*)name, "%s", "AddtionalManyFlags.cfg");
		shanghai_manycount = ReadshanghaiFlags(name, shanghaiManyFlags);
    }
    //--------------------------------------------------------<<
	for(i=0;i<Task1_Max;i++)
	{
		flgCount=0;
		if (JParamInfo3761->group9.f67[i].IsRun == 0x55)
		{
			for (j = 0; j < JParamInfo3761->group9.f65[i].Count; j++)       //����i�����ݱ�ʶ����
			{
				GetDa(JParamInfo3761->group9.f65[i].Flag[j][0], JParamInfo3761->group9.f65[i].Flag[j][1]);
				GetDt(JParamInfo3761->group9.f65[i].Flag[j][2], JParamInfo3761->group9.f65[i].Flag[j][3]);
				for (k = 0; k < PointMax; k++)
				{
					if (DA[k] == 1)
					{
						if(JParamInfo3761->group2.f10[k-1].Status!=1){continue;}
						if ((JParamInfo3761->group2.f10[k-1].port!=CarrWavePort) && (JParamInfo3761->group2.f10[k-1].port!=LocalCommPort))
							continue;
						for (l = 0; l < 255; l++)
						{
							if (DT[l] == 1)
							{
								printf("\n task1  k=%d,l=%d\n\r",k,l);
								if(JParamInfo3761->group2.f10[k-1].Type!=3)
								{
									//Le1flgComm[l-1].Dataflag
									flgcnt=0;
									for(n=0;n<20;n++)
									{
										if ((Le1flgComm[l-1][n].Dataflag[0]==0x00) && (Le1flgComm[l-1][n].Dataflag[0]==0x00))
											continue;
										if (Le1flgComm[l-1][n].ReadFlg!=1)
											continue;
										for(nn=0;nn<cmflg;nn++)
										{
											if (((Le1flgComm[l-1][n].Dataflag[0]|0x0F)==cflgn[nn].Dataflag[0]) &&
												(Le1flgComm[l-1][n].Dataflag[1]==cflgn[nn].Dataflag[1]))
											{
												cflgn[nn].Dataflag[0]=Le1flgComm[l-1][n].Dataflag[0];
												flgcnt=1;
												break;
											}
										}
//										if (flgcnt==0)
//										{
//											cflgn[cmflg].Dataflag[0]=Le1flgComm[l-1][n].Dataflag[0];
//											cflgn[cmflg].Dataflag[1]=Le1flgComm[l-1][n].Dataflag[1];
//											cmflg++;
//										}
										if (flgcnt==0)
										{
											mm_flndflg=0;//guangrao
											for(mm=0; mm<ManyFlagsCount; mm++)
											{
												if(cflgn[mm].Dataflag[0]==Le1flgComm[l-1][n].Dataflag[0] &&
														cflgn[mm].Dataflag[1]==Le1flgComm[l-1][n].Dataflag[1])
												{
													printf("\n %02x %02x \n",cflgn[mm].Dataflag[0],cflgn[mm].Dataflag[1]);
													mm_flndflg = 1;
													break;
												}
											}
											if(mm_flndflg==0)
											{
												cflgn[cmflg].Dataflag[0]=Le1flgComm[l-1][n].Dataflag[0];
												cflgn[cmflg].Dataflag[1]=Le1flgComm[l-1][n].Dataflag[1];
												printf("\n -------%02x %02x------ \n",cflgn[cmflg].Dataflag[0],cflgn[cmflg].Dataflag[1]);
												cmflg++;
											}
										}
									}
								}
								else
								{
									flgcnt=0;
									for(n=0;n<20;n++)
									{
										if ((Le1flgMany[l-1][n].Dataflag[0]==0x00) && (Le1flgMany[l-1][n].Dataflag[0]==0x00))
											continue;
										if (Le1flgMany[l-1][n].ReadFlg!=1)
											continue;
										for(nn=0;nn<mmflg;nn++)
										{
											if (((Le1flgMany[l-1][n].Dataflag[0]|0x0F)==mflgn[nn].Dataflag[0]) &&
												(Le1flgMany[l-1][n].Dataflag[1]==mflgn[nn].Dataflag[1]))
											{
												//printf("Le1flgMany=%02x%02x\n\r",Le1flgMany[l-1][n].Dataflag[1],Le1flgMany[l-1][n].Dataflag[0]);
												mflgn[nn].Dataflag[0]=Le1flgMany[l-1][n].Dataflag[0];
												flgcnt=1;
												break;
											}
										}
//										if (flgcnt==0)
//										{
//											mflgn[mmflg].Dataflag[0]=Le1flgMany[l-1][n].Dataflag[0];
//											mflgn[mmflg].Dataflag[1]=Le1flgMany[l-1][n].Dataflag[1];
//											mmflg++;
//										}
										if (flgcnt==0)
										{
											mm_flndflg=0;//guangrao
											for(mm=0; mm<ManyFlagsCount; mm++)
											{
												if(mflgn[mm].Dataflag[0]==Le1flgMany[l-1][n].Dataflag[0] &&
														mflgn[mm].Dataflag[1]==Le1flgMany[l-1][n].Dataflag[1])
												{
													printf("\n %02x %02x \n",mflgn[mm].Dataflag[0],mflgn[mm].Dataflag[1]);
													mm_flndflg = 1;
													break;
												}
											}
											if(mm_flndflg==0)
											{
												mflgn[mmflg].Dataflag[0]=Le1flgMany[l-1][n].Dataflag[0];
												mflgn[mmflg].Dataflag[1]=Le1flgMany[l-1][n].Dataflag[1];
												printf("\n -------%02x %02x------ \n",mflgn[mmflg].Dataflag[0],mflgn[mmflg].Dataflag[1]);
												mmflg++;
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	for (i=0;i<Task2_Max;i++)
	{
		flgCount=0;
		if (JParamInfo3761->group9.f68[i].IsRun == 0x55)
		{
			for (j = 0; j < JParamInfo3761->group9.f66[i].Count; j++)
			{
				GetDa(JParamInfo3761->group9.f66[i].Flag[j][0],
						JParamInfo3761->group9.f66[i].Flag[j][1]);
				GetDt(JParamInfo3761->group9.f66[i].Flag[j][2],
						JParamInfo3761->group9.f66[i].Flag[j][3]);
				for (k = 0; k < PointMax; k++)
				{
					if (DA[k] == 1)
					{
						if(JParamInfo3761->group2.f10[k-1].Status!=1){continue;}
						if ((JParamInfo3761->group2.f10[k-1].port!=CarrWavePort)&&(JParamInfo3761->group2.f10[k-1].port!=LocalCommPort))
							continue;
						for (l = 0; l < 255; l++)
						{
							if (DT[l] == 1)
							{
								printf("\ntask2 k=%d,l=%d\n\r",k,l);
								if(JParamInfo3761->group2.f10[k-1].Type!=3)
								{
									//Le1flgComm[l-1].Dataflag
									flgcnt=0;
									for(n=0;n<20;n++)
									{
										if ((Le1flgComm[l-1][n].Dataflag[0]==0x00) && (Le1flgComm[l-1][n].Dataflag[0]==0x00))
											continue;
										if (Le1flgComm[l-1][n].ReadFlg!=2)
											continue;
										for(nn=0;nn<cmflg;nn++)
										{
											if (((Le1flgComm[l-1][n].Dataflag[0]|0x0F)==cflgn[nn].Dataflag[0]) &&
												(Le1flgComm[l-1][n].Dataflag[1]==cflgn[nn].Dataflag[1]))
											{
												cflgn[nn].Dataflag[0]=Le1flgComm[l-1][n].Dataflag[0];
												flgcnt=1;
												break;
											}
										}
//										if (flgcnt==0)
//										{
//											cflgn[cmflg].Dataflag[0]=Le1flgComm[l-1][n].Dataflag[0];
//											cflgn[cmflg].Dataflag[1]=Le1flgComm[l-1][n].Dataflag[1];
//											cmflg++;
//										}
										if (flgcnt==0)
										{
											mm_flndflg=0;//guangrao
											for(mm=0; mm<ManyFlagsCount; mm++)
											{
												if(cflgn[mm].Dataflag[0]==Le1flgComm[l-1][n].Dataflag[0] &&
														cflgn[mm].Dataflag[1]==Le1flgComm[l-1][n].Dataflag[1])
												{
													printf("\n %02x %02x \n",cflgn[mm].Dataflag[0],cflgn[mm].Dataflag[1]);
													mm_flndflg = 1;
													break;
												}
											}
											if(mm_flndflg==0)
											{
												cflgn[cmflg].Dataflag[0]=Le1flgComm[l-1][n].Dataflag[0];
												cflgn[cmflg].Dataflag[1]=Le1flgComm[l-1][n].Dataflag[1];
												printf("\n -------%02x %02x------ \n",cflgn[cmflg].Dataflag[0],cflgn[cmflg].Dataflag[1]);
												cmflg++;
											}
										}
									}
								}
								else
								{
									flgcnt=0;
									for(n=0;n<20;n++)
									{
										if ((Le1flgMany[l-1][n].Dataflag[0]==0x00) && (Le1flgMany[l-1][n].Dataflag[0]==0x00))
											continue;
										if (Le1flgMany[l-1][n].ReadFlg!=2)
											continue;
										for(nn=0;nn<mmflg;nn++)
										{
											if (((Le1flgMany[l-1][n].Dataflag[0]|0x0F)==mflgn[nn].Dataflag[0]) &&
												(Le1flgMany[l-1][n].Dataflag[1]==mflgn[nn].Dataflag[1]))
											{
												//printf("Le1flgMany=%02x%02x\n\r",Le1flgMany[l-1][n].Dataflag[1],Le1flgMany[l-1][n].Dataflag[0]);
												mflgn[nn].Dataflag[0]=Le1flgMany[l-1][n].Dataflag[0];
												flgcnt=1;
												break;
											}
										}
//										if (flgcnt==0)
//										{
//											mflgn[mmflg].Dataflag[0]=Le1flgMany[l-1][n].Dataflag[0];
//											mflgn[mmflg].Dataflag[1]=Le1flgMany[l-1][n].Dataflag[1];
//											mmflg++;
//										}
										if (flgcnt==0)
										{
											mm_flndflg=0;//guangrao
											for(mm=0; mm<ManyFlagsCount; mm++)
											{
												if(mflgn[mm].Dataflag[0]==Le1flgMany[l-1][n].Dataflag[0] &&
														mflgn[mm].Dataflag[1]==Le1flgMany[l-1][n].Dataflag[1])
												{
													printf("\n %02x %02x \n",mflgn[mm].Dataflag[0],mflgn[mm].Dataflag[1]);
													mm_flndflg = 1;
													break;
												}
											}
											if(mm_flndflg==0)
											{
												mflgn[mmflg].Dataflag[0]=Le1flgMany[l-1][n].Dataflag[0];
												mflgn[mmflg].Dataflag[1]=Le1flgMany[l-1][n].Dataflag[1];
												printf("\n -------%02x %02x------ \n",mflgn[mmflg].Dataflag[0],mflgn[mmflg].Dataflag[1]);
												mmflg++;
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	memset(&curMeters,0,sizeof(CurMeters));
	curMeters.MeterCount=0;

	for(i=0;((i<PointMax)&&(firflg>0));i++)        //���������ж�
	{
		//SdPrint("start time_read_dates.....................!\n\r");
		ClearWaitTimes(ProjectNo,JProgramInfo);
		if(JParamInfo3761->group2.f10[i].Status!=1)
			continue;
		if ((JParamInfo3761->group2.f10[i].ConnectType!=1) &&
				(JParamInfo3761->group2.f10[i].ConnectType!=30)&&
				(JParamInfo3761->group2.f10[i].ConnectType!=21))
			continue;
		if ((JParamInfo3761->group2.f10[i].port!=CarrWavePort)&&(JParamInfo3761->group2.f10[i].port!=LocalCommPort))//
			continue;
		ClearWaitTimes(ProjectNo,JProgramInfo);
		if(JParamInfo3761->group2.f10[i].Type==0)       //������  �๦�ܱ�   ��ͨ���������ϵı������˳�
		{
			continue;
		}
		else if(JParamInfo3761->group2.f10[i].Type!=3)   //��ͨ��
		{
			curMeters.CurMeter[curMeters.MeterCount].flType=common;          //��ͨ��
			flgcnt=0;
			for(flgCount=0;flgCount<cmflg;flgCount++)      //���ݱ�ʾ�ж�
			{
				if(JParamInfo3761->group2.f10[i].ConnectType==1)//97��Լ
				{
					if ((cflgn[flgCount].Dataflag[1]==0x00)|| (cflgn[flgCount].Dataflag[1]==0xEE)|| (cflgn[flgCount].Dataflag[1]==0xFF))
						continue;
					if(cflgn[flgCount].Dataflag[1]==0xFB) //10.7
						continue;
					SdPrint("flgcnt=%d\n\r",flgcnt);
				}
				if(JParamInfo3761->group2.f10[i].ConnectType==30)    //07��Լ
				{
					if(GetDataFlag07By97( &cflgn[flgCount],&flg07)==1)
					{
						if ((flg07.Dataflag[0]==0xff)&&(flg07.Dataflag[1]==0xff)&&(flg07.Dataflag[2]==0xff)&&(flg07.Dataflag[3]==0xff))
							continue;
					}
					else
						continue;
				}
				//shanghai-------------------------------------->>
				if(JParamInfo3761->group2.f10[i].ConnectType==21)
				{
					if(isDataFlagValued_Shanghai(&JProgramInfo->Para.meterFlags.CommDayFlags[flgCount])==0)
						continue;
				}
				//----------------------------------------------------------<<
				curMeters.CurMeter[curMeters.MeterCount].flg[flgcnt].Dataflag[0]=cflgn[flgCount].Dataflag[0];      //���ݱ�ʾ��cflgn��������curMeters
				curMeters.CurMeter[curMeters.MeterCount].flg[flgcnt].Dataflag[1]=cflgn[flgCount].Dataflag[1];
				flgcnt++;

			}
			//shanghai---------------------------------------->>
			fprintf(stderr,"\n\n\ncldno %d flgcnt===%d--------------------0\n",i+1,flgcnt);
			for(kk=0; kk<flgcnt;kk++)
			{
				fprintf(stderr,"  [%d] %02x%02x \n",
						kk,
						curMeters.CurMeter[curMeters.MeterCount].flg[kk].Dataflag[1],
						curMeters.CurMeter[curMeters.MeterCount].flg[kk].Dataflag[0]);
			}
			//�����û������ С�������������������
			flgcnt += GetDataFlagsbyLeihao(i, &curMeters.CurMeter[curMeters.MeterCount].flg[flgcnt]);

			if(IsDayDongJieFile(i+1)==0 || IsMonthDongJieFile(i+1)==0)//�ҵ��Ƿ�������¶����ļ�
			{
				if(JParamInfo3761->group2.f10[i].ConnectType==30)
				{
					for(flg_index=0; flg_index<shanghai_commcount; flg_index++)
					{
						curMeters.CurMeter[curMeters.MeterCount].flg[flgcnt].Dataflag[0]=shanghaiCommFlags[flg_index].Dataflag[0];
						curMeters.CurMeter[curMeters.MeterCount].flg[flgcnt].Dataflag[1]=shanghaiCommFlags[flg_index].Dataflag[1];
						flgcnt++;
					}
				}else if(JParamInfo3761->group2.f10[i].ConnectType==1)
				{
					for(flg_index=0; flg_index<shanghai_commcount; flg_index++)
					{
						if(isDataFlagValued_97(&shanghaiCommFlags[flg_index])==0)
							continue;
						curMeters.CurMeter[curMeters.MeterCount].flg[flgcnt].Dataflag[0]=shanghaiCommFlags[flg_index].Dataflag[0];
						curMeters.CurMeter[curMeters.MeterCount].flg[flgcnt].Dataflag[1]=shanghaiCommFlags[flg_index].Dataflag[1];
						flgcnt++;
					}
				}else if(JParamInfo3761->group2.f10[i].ConnectType==21)
				{
					for(flg_index=0; flg_index<shanghai_commcount; flg_index++)
					{
						if(isDataFlagValued_Shanghai(&shanghaiCommFlags[flg_index])==0)
							continue;
						curMeters.CurMeter[curMeters.MeterCount].flg[flgcnt].Dataflag[0]=shanghaiCommFlags[flg_index].Dataflag[0];
						curMeters.CurMeter[curMeters.MeterCount].flg[flgcnt].Dataflag[1]=shanghaiCommFlags[flg_index].Dataflag[1];
						flgcnt++;
					}
				}
			}

			dealdataflag(&curMeters.CurMeter[curMeters.MeterCount].flg[0], flgcnt);

			flgcnt = RepeatDataflag_GuoLv(&curMeters.CurMeter[curMeters.MeterCount].flg[0], flgcnt);

			if(JParamInfo3761->group2.f10[i].ConnectType==1 || JParamInfo3761->group2.f10[i].ConnectType==21)
				flgcnt = dealGuiyueDataFlag(i,&curMeters.CurMeter[curMeters.MeterCount].flg[0], flgcnt);

			//-------------------------------------------------<<
		    curMeters.CurMeter[curMeters.MeterCount].flgCount=flgcnt;

			fprintf(stderr,"\n\n\ncldno %d flgcnt===%d ----------------------5\n",i+1,flgcnt);
			for(kk=0; kk<flgcnt;kk++)
			{
				fprintf(stderr,"  [%d] %02x%02x \n",
						kk,
						curMeters.CurMeter[curMeters.MeterCount].flg[kk].Dataflag[1],
						curMeters.CurMeter[curMeters.MeterCount].flg[kk].Dataflag[0]);
			}
		}
		else
		{
			curMeters.CurMeter[curMeters.MeterCount].flType=many;      // 3Ϊ�๦�ܱ�
			flgcnt=0;
			for(flgCount=0;flgCount<mmflg;flgCount++)
			{
				if(JParamInfo3761->group2.f10[i].ConnectType==1)     //07��Լ���
				{
					if ((mflgn[flgCount].Dataflag[1]==0x00)|| (mflgn[flgCount].Dataflag[1]==0xEE)|| (mflgn[flgCount].Dataflag[1]==0xFF))
						continue;
				}
				if(JParamInfo3761->group2.f10[i].ConnectType==30) //07��Լ���
				{
					if(GetDataFlag07By97( &mflgn[flgCount],&flg07)==1)
					{
						if ((flg07.Dataflag[0]==0xff)&&(flg07.Dataflag[1]==0xff)&&(flg07.Dataflag[2]==0xff)&&(flg07.Dataflag[3]==0xff))
							continue;
					}
					else
						continue;
				}
				//shanghai-------->>
				if(JParamInfo3761->group2.f10[i].ConnectType==21)
				{
					if(isDataFlagValued_Shanghai(&JProgramInfo->Para.meterFlags.ManyDayFlags[flgCount])==0)
						continue;
				}
				//----------------<<
				curMeters.CurMeter[curMeters.MeterCount].flg[flgcnt].Dataflag[0]=mflgn[flgCount].Dataflag[0];
				curMeters.CurMeter[curMeters.MeterCount].flg[flgcnt].Dataflag[1]=mflgn[flgCount].Dataflag[1];
				flgcnt++;
			}
			//shanghai--------------------------------->>
			fprintf(stderr,"\n\n\ncldno %d flgcnt===%d ------------------many----0\n",i+1,flgcnt);
			for(kk=0; kk<flgcnt;kk++)
			{
				fprintf(stderr,"  [%d] %02x%02x \n",
						kk,
						curMeters.CurMeter[curMeters.MeterCount].flg[kk].Dataflag[1],
						curMeters.CurMeter[curMeters.MeterCount].flg[kk].Dataflag[0]);
			}
			//�����û������ С�������������������
			flgcnt += GetDataFlagsbyLeihao(i, &curMeters.CurMeter[curMeters.MeterCount].flg[flgcnt]);

			if(IsDayDongJieFile(i+1)==0 || IsMonthDongJieFile(i+1)==0)//�ҵ��Ƿ�������¶����ļ�
			{
				if(JParamInfo3761->group2.f10[i].ConnectType==30)
				{
					for(flg_index=0; flg_index<shanghai_manycount; flg_index++)
					{
						curMeters.CurMeter[curMeters.MeterCount].flg[flgcnt].Dataflag[0]=shanghaiManyFlags[flg_index].Dataflag[0];
						curMeters.CurMeter[curMeters.MeterCount].flg[flgcnt].Dataflag[1]=shanghaiManyFlags[flg_index].Dataflag[1];
						flgcnt++;
					}
				}else if(JParamInfo3761->group2.f10[i].ConnectType==1)
				{
					for(flg_index=0; flg_index<shanghai_manycount; flg_index++)
					{
						if(isDataFlagValued_97(&shanghaiManyFlags[flg_index])==0)
							continue;
						curMeters.CurMeter[curMeters.MeterCount].flg[flgcnt].Dataflag[0]=shanghaiManyFlags[flg_index].Dataflag[0];
						curMeters.CurMeter[curMeters.MeterCount].flg[flgcnt].Dataflag[1]=shanghaiManyFlags[flg_index].Dataflag[1];
						flgcnt++;
					}
				}else if(JParamInfo3761->group2.f10[i].ConnectType==21)
				{
					for(flg_index=0; flg_index<shanghai_manycount; flg_index++)
					{
						if(isDataFlagValued_Shanghai(&shanghaiManyFlags[flg_index])==0)
							continue;
						curMeters.CurMeter[curMeters.MeterCount].flg[flgcnt].Dataflag[0]=shanghaiManyFlags[flg_index].Dataflag[0];
						curMeters.CurMeter[curMeters.MeterCount].flg[flgcnt].Dataflag[1]=shanghaiManyFlags[flg_index].Dataflag[1];
						flgcnt++;
					}
				}
			}

			dealdataflag(&curMeters.CurMeter[curMeters.MeterCount].flg[0], flgcnt);

			flgcnt = RepeatDataflag_GuoLv(&curMeters.CurMeter[curMeters.MeterCount].flg[0], flgcnt);
			if(JParamInfo3761->group2.f10[i].ConnectType==1 || JParamInfo3761->group2.f10[i].ConnectType==21)
				flgcnt = dealGuiyueDataFlag(i,&curMeters.CurMeter[curMeters.MeterCount].flg[0], flgcnt);
			//-----------------------------------------<<
			curMeters.CurMeter[curMeters.MeterCount].flgCount=flgcnt;

			fprintf(stderr,"\n\n\ncldno %d flgcnt===%d-------------------many--------5\n",i+1,flgcnt);
			for(kk=0; kk<flgcnt;kk++)
			{
				fprintf(stderr,"  [%d] %02x%02x \n",
						kk,
						curMeters.CurMeter[curMeters.MeterCount].flg[kk].Dataflag[1],
						curMeters.CurMeter[curMeters.MeterCount].flg[kk].Dataflag[0]);
			}
		}
		curMeters.CurMeter[curMeters.MeterCount].cjqNo=JParamInfo3761->group2.f10[i].CjqNo-1;
		curMeters.CurMeter[curMeters.MeterCount].MeterNo=JParamInfo3761->group2.f10[i].MeterNo;
		curMeters.CurMeter[curMeters.MeterCount].GyType=JParamInfo3761->group2.f10[i].ConnectType;
		memcpy(curMeters.CurMeter[curMeters.MeterCount].Addr,&JParamInfo3761->group2.f10[i].Address[0],6);
		curMeters.MeterCount++;   //ͳ�����еķ����ز��˿ڳ���������
	}//�����еĳ����й���Ϣת�浽curMeters�е��˽���
	memset(&df,0,sizeof(DataFiles));
	//df.fileType=3;
	SdPrint("\n curMeters.MeterCount=%d",curMeters.MeterCount);
	for(i=0;i<curMeters.MeterCount;i++)
	{
		SdPrint( "\n\r������ţ�%d �������ַ��",getPoint(curMeters.CurMeter[i].cjqNo,curMeters.CurMeter[i].MeterNo));
		for(j=0;j<6;j++)
			SdPrint( "%02x ",curMeters.CurMeter[i].Addr[5-j]);
		SdPrint("\n\r");
	}

	SdPrint("***********************************************************************************");
	SdPrint("\n\n��ʼ����    ---  ��ʼ����       ---   ��ʼ����     ---  �ָ�����\n\n");
	SdPrint("***********************************************************************************");
	fflush(stdout);//ˢ�µ��Կ������������ʹ֮��������ӡ

	unsigned int m=0, cldno=0;
	unsigned int len,point_adr;    //�ز��ӽڵ��ַҲ���Ǳ���ַ
	unsigned char read_end_flg=0; //����������־
	unsigned char rec_meter[6];
	TS currts,oldts;
	TSGet(&currts);
	TSGet(&oldts);
	memset(rec_meter,0,6);
	read_end_flg=0;
	INT8U temp=0;
	DataFlag97 tmpflg97;
	DataFlag2007 tmpflg07;
	DataFlagSH tmpflgSH; //shanghai
	int flgid=0;
	int rebootflg=0;
	INT8U bootflg=0;
	INT8U errflgcount=0;
	int poin_no=0;//dingxing
	JProgramInfo->stateflags.UpdateZB_flag = 0;
	time_t lastframe_time_t;//���һ���յ����ĵ�ʱ��
	time_t curr_time_t;    //���ڱȶԵ�ǰʱ�� ȷ���Ƿ��·��״̬ ����10����û���κα��Ķ�·��״̬
	curr_time_t = lastframe_time_t = time(NULL);
	while(!read_end_flg)
	{
		TSGet(&currts);
		delay(10);
		ClearWaitTimes(ProjectNo,JProgramInfo);
		//����·��
		//printf("\n--ZB--JProgramInfo->RealData.ReadFlg=%d------------------1",JProgramInfo->RealData.ReadFlg);
		if(JProgramInfo->dataTransgw.f1.ASK_Stat==1 || JProgramInfo->RealData.ReadFlg==1)
		{
			printf("\n JProgramInfo->dataTransgw.f1.ASK_Stat =%d  JProgramInfo->RealData.ReadFlg==%d\n",
					JProgramInfo->dataTransgw.f1.ASK_Stat,JProgramInfo->RealData.ReadFlg);
			pause_read();
			while(1)
			{
				GetRealTimeData();
				ClearWaitTimes(ProjectNo,JProgramInfo);
				DataTrans();
				Current_time = time(NULL);
				//if(abs(Current_time - Update_current_time)%10==0 && Current_time != Update_current_time)
				//	printf("\n �Ѿ��� %d ��û���յ��������ġ�\n",abs(Current_time - Update_current_time));
				if(abs(Current_time - Update_current_time)>=100) //����100��
				{
					printf("\n**************����100�� û���յ��������� ---�������**********************\n");
					if(JProgramInfo->stateflags.UpdateZB_flag==1)
					{
						JProgramInfo->stateflags.UpdateZB_flag = 0;
						GetPtsfromZB();//��ZBģ���л�ò�������Ϣ
						if(SlavePoint_TotalNum != 0)
							UpdateZBMeterInfo();
						else
							MyAddZbPts();
						GetPtsfromZB();//��ZBģ���л�ò�������Ϣ
						return;
					}else
						break;
				}
				delay(100);
			}
			if(JProgramInfo->stateflags.UpdateZB_flag!=1)
				resume_read();
		}

		if(JDataFileInfo->data485[29+PortBegNum].ChaobiaoSta==1)
		{
			pause_read();
			read_end_flg = 1;
			//JDataFileInfo->data485[29+PortBegNum].ChaobiaoSta = 0;
			printf("\nJDataFileInfo->data485[29+PortBegNum].ChaobiaoSta==1\n");
			continue;
		}

		if(currts.Day != oldts.Day)
		{
			rebootflg = 1;
			//oldts  = currts;
			memcpy(&oldts, &currts, sizeof(TS));
			for(i=0;i<PointMax;i++)
				JDataFileInfo->ptinfo[i].FirRead=0;
		}
		if(rebootflg==1)
		{
			if(currts.Hour==0 && (currts.Minute>=5 && rebootflg==1))
			{
				DbgPrintToFile("\n%d�� 0��5�����³���\n",currts.Day);
				rebootflg = 0;
				return;
			}
		}

		//1�㵽4�㲹��
		memcpy(&currts_buchao, &currts, sizeof(TS));
		if(oldts_buchao.Hour!=currts_buchao.Hour)
		{
			memcpy(&oldts_buchao, &currts_buchao, sizeof(TS));
			if(currts_buchao.Hour==BUCHAO_BEGIN_TIME || currts_buchao.Hour==BUCHAO_END_TIME)
			{
				printf("\n(currts_buchao.Hour==1 || currts_buchao.Hour==4)\n");
				return;
			}
		}
		if(currts.Hour==0 && (currts.Minute>=0 && currts.Minute<4))
		{
			printf("\n(currts.Hour==0 && (currts.Minute>=0 && currts.Minute<5))\n");
			return;
		}

		if(JProgramInfo->stateflags.Reset_Changed==1)
		{
			InitZBPointInfo();
			JProgramInfo->stateflags.Reset_Changed = 0;
			printf("\nJProgramInfo->stateflags.Reset_Changed==1\n");
			return;
		}
		submain(); //��������main��ĺ����Ƶ���������
		//�����й����в�������Ϣһ�ı䣬������ѭ��
		if((JParamInfo3761->group11.f111.Enable&0x01)==MANUAL)
		{
			if(CeLingDianChange_Check()==1)
			{
				SdPrint( "\n\r������ı���");
				isCLDChanged = 1;
				break;
			}
		}
#ifdef BIDUIDANGAN
		if(SouBiaoWanbi==1)
		{
			SouBiaoWanbi = 0;
			return;
		}
#endif
		if(JProgramInfo->stateflags.F65_Changed==1 || JProgramInfo->stateflags.F66_Changed==1)//�������·����³���
		{
			JProgramInfo->stateflags.F65_Changed = 0;
			JProgramInfo->stateflags.F66_Changed = 0;
			return;
		}
		if((JParamInfo3761->group11.f111.Enable&0x01)==AUTO)
		{
			if(JProgramInfo->BeginSouBiao==1)
			{
				printf("\nJProgramInfo->BeginSouBiao==1\n");
				break;
			}
		}
		if(bootflg==0)
		{
			bootflg = 1;
			reboot_read();
		}
	    if(JDataFileInfo->data485[CarrWavePort-PortBegNum].MeterNum==0 && JDataFileInfo->data485[29+PortBegNum].MeterNum==0)//9.4gai
	    	continue;

	    curr_time_t =  time(NULL);
		//if(currts.Minute%10==0 && currts.Sec%30==0)
	    if(abs(curr_time_t-lastframe_time_t)>10*60)//�ز�10������û���Ĳ�ѯ·��״̬
		{
	    	fprintf(stderr,"\n  �ز�10������û���Ĳ�ѯ·��״̬!! curr_time_t=%d  lastframe_time_t=%d\n",
	    			(int)curr_time_t, (int)lastframe_time_t);
			if(ZBStatus_read()>0)
			{
				if(rtStatus.iswork==0){
					if(resume_read()==0)
						reboot_read1();
				}
				update485info();
				if(rtStatus.allpoint_num != JDataFileInfo->data485[29+PortBegNum].MeterNum)
				{
					printf("\n��ѯ�����㲻��� ͬ��������");
					isCLDChanged = 1;
					return;
				}
			}else
			{
				gpio_write("gpoZAIBO_RST", 0);
				delay(50);
				gpio_write("gpoZAIBO_RST", 1);
			}
		}
		len = 0;
		memset(Rec645Buff, 0, 512);
		len = ReceiveFromCarr(Rec645Buff);//����
		ClearWaitTimes(ProjectNo,JProgramInfo);
		if(len>0)
		{
			lastframe_time_t = time(NULL);
			//���ķ���
			SdPrint( "\n\r���յ��ز�����  len=%d :", len);
			for (i = 0; i < len; i++)
				SdPrint( "%02x ",Rec645Buff[i]);
			SdPrint( "\n\r");

			for (i = 0; i < len; i++)    //��ͷ���
			{
				ClearWaitTimes(ProjectNo,JProgramInfo);
				if (Rec645Buff[i] == 0x68)
				{
					//·�����󳭶�����
					//68 18 00 c1 00 01 00 00 00 00 14 01 00 01 ||62 99 34 03 00 18 02 00 24 16
					if((Rec645Buff[i+10]==0x14) && (Rec645Buff[i+11]==0x01) && (Rec645Buff[i+12]==0x00))       //���������ݱ�ʶ�ж�
					{
						SdPrint("	���յ� ·�����󳭶� ����\n");
						//�ز��ӽڵ���š���ַ�ж�
						memset(rec_meter,0,6);
						point_adr=Rec645Buff[i+20]+(((unsigned int)Rec645Buff[i+21])<<8);   //�ز��ӽڵ�ţ���Ӧ�Ų������
						memcpy(rec_meter,&Rec645Buff[i+14],6);
						cldno = 0;
						XinDaoBiaoShi = Rec645Buff[i+5];
						cldno = getCld(rec_meter);
						for(j=0; j<curMeters.MeterCount; j++)   //�Ƚ�����Ĳ������Ƿ����
						{
							if( memcmp(rec_meter,&curMeters.CurMeter[j].Addr,6)==0)  //�ҵ�����ַ
							{
								XinDaoBiaoShi = Rec645Buff[i+13];
								//��flg���ҵ�Ϊ0�������� �·���ȥ
								temp = 1;
								errflgcount = 0;
								for(m=0; m<curMeters.CurMeter[j].flgCount; m++)
								{
									if(curMeters.CurMeter[j].isFlgSucc[m]==0)
									{
										errflgcount++;
										temp = 0;
									}
								}
								if(curMeters.CurMeter[j].errFlgCount>=errflgcount)
								{
									SdPrint("\n ��%d��������ص��쳣   %dʧ��\n", curMeters.CurMeter[j].errFlgCount,errflgcount);
									curMeters.CurMeter[j].errFlgCount = 0;
									temp = 1;
								}
								if(temp == 0)
								{
									if(curMeters.CurMeter[j].data_flg >= curMeters.CurMeter[j].flgCount)
										curMeters.CurMeter[j].data_flg=curMeters.CurMeter[j].data_flg % curMeters.CurMeter[j].flgCount;
									SdPrint("\n �ظ������ĵ��Ϊ  %02x%02x%02x%02x%02x%02x �������ʶΪ��%d��/��%d  %02x%02x",
											curMeters.CurMeter[j].Addr[5],curMeters.CurMeter[j].Addr[4],curMeters.CurMeter[j].Addr[3],
											curMeters.CurMeter[j].Addr[2],curMeters.CurMeter[j].Addr[1],curMeters.CurMeter[j].Addr[0],
											curMeters.CurMeter[j].data_flg,curMeters.CurMeter[j].flgCount,
											curMeters.CurMeter[j].flg[curMeters.CurMeter[j].data_flg].Dataflag[1],
											curMeters.CurMeter[j].flg[curMeters.CurMeter[j].data_flg].Dataflag[0]);
									get_value(cldno, &curMeters.CurMeter[j].flg[curMeters.CurMeter[j].data_flg]);
									curMeters.CurMeter[j].data_flg++;
								}else{
									send_meter_success(cldno,XinDaoBiaoShi);     //���ͳ����ɹ���������һ�����������
									curMeters.CurMeter[j].Succ = 1;
								}
								break;
							}
						}
						if(curMeters.MeterCount==j)
						{//rec_meter
							send_meter_success_empty(rec_meter,XinDaoBiaoShi);
							//send_meter_fail(cldno);             //û���ҵ�����Ĳ����㣬���ͳ���ʧ��
							SdPrint("\nû���ҵ�����Ĳ����� %02x%02x%02x%02x%02x%02x\n",
									rec_meter[5],rec_meter[4],rec_meter[3],rec_meter[2],rec_meter[1],rec_meter[0]);
						//return;
							//break; //ZBtiaoshi +
						}
					}//end of ·�����󳭶�����
					//68 33 00 c1 04 01 31 13 00 00 07 00 00 00 00 00 87 96 17 01 00 00 06 02 00 01 00 02 14 //28
					//68 07 00 00 00 00 00 68 91 08 33 33 34 33 37 33 33 33 0d 16 95 16
					else if(Rec645Buff[i+22]==0x06 && (Rec645Buff[i+23]==0x02) && (Rec645Buff[i+24]==0x00))    //�ϱ�·�ɳ�������   F2 //dingxin
					{
						//���Ľ���
						point_adr=Rec645Buff[i+25]+(((unsigned int)Rec645Buff[i+26])<<8);
						XinDaoBiaoShi = Rec645Buff[i+5];
						memset(rec_meter,0,6);
						memcpy(rec_meter,&Rec645Buff[i+30],6);
						SdPrint( "���ķ����� �յ�·�ɳ�������  �������Ϊ %d ����ַ   %02x%02x%02x%02x%02x%02x \n\r",
								point_adr,
								Rec645Buff[i+15],Rec645Buff[i+14],Rec645Buff[i+13],
								Rec645Buff[i+12],Rec645Buff[i+11],Rec645Buff[i+10]);

						for(j=0;j<curMeters.MeterCount;j++)   //�Ƚ�����Ĳ������Ƿ����
						{
							ClearWaitTimes(ProjectNo,JProgramInfo);
							//�����������ݣ��������ŵ�df�У��˺���ֻ�浥�����ݱ�ʶ�����ݣ�
//							if(curMeters.CurMeter[j].Addr[0]==Rec645Buff[i+30] && curMeters.CurMeter[j].Addr[1]==Rec645Buff[i+31] &&
//							  curMeters.CurMeter[j].Addr[2]==Rec645Buff[i+32] && curMeters.CurMeter[j].Addr[3]==Rec645Buff[i+33] &&
//							  curMeters.CurMeter[j].Addr[4]==Rec645Buff[i+34] && curMeters.CurMeter[j].Addr[5]==Rec645Buff[i+35])

							//if( memcmp(rec_meter,&curMeters.CurMeter[j].Addr,6)==0)  //�ҵ�����ַ
							poin_no = getCld(curMeters.CurMeter[j].Addr);
							if(cmpCldAdr(rec_meter, curMeters.CurMeter[j].Addr, JParamInfo3761->group2.f10[poin_no].ConnectType)==1)
							{
								//dingxing------------------>>>>>>
								//if(Rec645Buff[i+27]==0x02)
								if(JParamInfo3761->group2.f10[poin_no].ConnectType==30)
								{
									memset(&tmpflg97, 0, sizeof(DataFlag97));
									memset(&tmpflg07, 0, sizeof(DataFlag2007));
									tmpflg07.Dataflag[0] = Rec645Buff[i+39]-0x33;
									tmpflg07.Dataflag[1] = Rec645Buff[i+40]-0x33;
									tmpflg07.Dataflag[2] = Rec645Buff[i+41]-0x33;
									tmpflg07.Dataflag[3] = Rec645Buff[i+42]-0x33;
									//SdPrint("\n �������ʶΪ07  %02x%02x%02x%02x",tmpflg07.Dataflag[3], tmpflg07.Dataflag[2],tmpflg07.Dataflag[1], tmpflg07.Dataflag[0]);
									GetDataFlag97By07(&tmpflg07, &tmpflg97);
									//SdPrint("\n �������ʶΪ97  %02x%02x",tmpflg97.Dataflag[1], tmpflg97.Dataflag[0]);
								}else if(JParamInfo3761->group2.f10[poin_no].ConnectType==1)//(Rec645Buff[i+27]==0x01)
								{
									memset(&tmpflg97, 0, sizeof(DataFlag97));
									tmpflg97.Dataflag[0] = Rec645Buff[i+39]-0x33;
									tmpflg97.Dataflag[1] = Rec645Buff[i+40]-0x33;
								}else if(JParamInfo3761->group2.f10[poin_no].ConnectType==21)//(Rec645Buff[i+27]==21)//shanghai?
								{
									tmpflgSH.Dataflag[0] = (Rec645Buff[i+37]&0x7f);
									GetDataFlag97BySH(&tmpflgSH, &tmpflg97);
								}
								//---------------------------------------------------<<
								//SdPrint("\n 1111�������ʶΪ  %02x%02x",tmpflg97.Dataflag[1], tmpflg97.Dataflag[0]);
								for(m=0; m<ManyFlagsCount; m++)
								{
									if(tmpflg97.Dataflag[0]==curMeters.CurMeter[j].flg[m].Dataflag[0] &&
											tmpflg97.Dataflag[1]==curMeters.CurMeter[j].flg[m].Dataflag[1])
									{
									//	SdPrint("\n�ҵ�������\n");
										flgid = m;
										//curMeters.CurMeter[j].errFlgCount = m; //jsgai
										break;
									}
								}
								SdPrint("\n ��������  ���Ϊ  %02x%02x%02x%02x%02x%02x �������ʶΪ��%d��/��%d  %02x%02x",
										curMeters.CurMeter[j].Addr[5],curMeters.CurMeter[j].Addr[4],curMeters.CurMeter[j].Addr[3],
										curMeters.CurMeter[j].Addr[2],curMeters.CurMeter[j].Addr[1],curMeters.CurMeter[j].Addr[0],
										flgid,curMeters.CurMeter[j].flgCount,
										tmpflg97.Dataflag[1], tmpflg97.Dataflag[0]);
								result = deal_meter_datas(&Rec645Buff[i+29], curMeters.CurMeter[j], &df, flgid);
								if(result==-1)   //�յ��ĳ�������
								{
									unsigned char buf[4];
									buf[0]=0xff; 	buf[1]=0xff; 	buf[2]=0x02; 	buf[3]=0x00;
									SdPrint("����ȷ��֡:");
									send_ack(buf,XinDaoBiaoShi);  //����ȷ������
									curMeters.CurMeter[j].isFlgSucc[flgid] = 1;
									//��������ɹ� �洢
									SdPrint("�����ɹ�����\n");
									//�洢���� curr.dat
									meter_success_alarm(curMeters.CurMeter[j].cjqNo,curMeters.CurMeter[j].MeterNo);
									meter_success_curr(&curMeters.CurMeter[j],&df,ts, &tmpflg97);//10.8
									//df.fileType=3;
									//curMeters.CurMeter[j].isChaobiao = 1; errFlgCount
								}else if(result == 6) //10.8-1
								{
									unsigned char buf[4];
									buf[0]=0xff; 	buf[1]=0xff; 	buf[2]=0x02; 	buf[3]=0x00;
									SdPrint("����ȷ��֡:");
									send_ack(buf,XinDaoBiaoShi);  //����ȷ������
									//curMeters.CurMeter[j].isFlgSucc[flgid] = 1;
									curMeters.CurMeter[j].errFlgCount++;
									//curMeters.CurMeter[j].isFlgSucc[curMeters.CurMeter[j].errFlgCount] = 1;//jsgai
									//curMeters.CurMeter[j].isFlgSucc[curMeters.CurMeter[j].data_flg-1] = 1;
									SdPrint("�����޴������� ��������쳣֡ ����%d\n",curMeters.CurMeter[j].data_flg-1);
								}
								else		//���͵ĳ������ݴ��ڴ���
								  send_nack(result, XinDaoBiaoShi);		//resultΪ�������
								break;
							}/////////
						}
						if(curMeters.MeterCount==j)
						{
							printf("\n���Ų�����\n");
							//return;
						}
						//	send_nack(ERR7,XinDaoBiaoShi);      //���Ų�����
					}
					else  if(Rec645Buff[i+10]==0x00 && (Rec645Buff[i+11]==0x01) && (Rec645Buff[i+12]==0x00))    //ȷ�ϱ���
					{
						SdPrint("���յ�ȷ�ϱ���\n\r");
					}
				}//end 0x68
			}//end for 0x68
		}
		if((JParamInfo3761->group11.f111.Enable&0x01)==MANUAL)     //+++++++++++++++++++++++++++++++++
		{
			if(SlavePoint_TotalNum<=0)//ZBtiaoshi ��ֹZBģ����һ�������㶼û�У���������time_read_dates();��ѭ��
				break;
		}
		//9.29
		JDataFileInfo->data485[CarrWavePort-PortBegNum].MeterNum_CBSucc = 0;
		JDataFileInfo->data485[31-PortBegNum].MeterNum_CBSucc = 0;
		for(m=0;m<curMeters.MeterCount;m++)//�ж�ĳ���������µ�������������ɹ����ʾ �˵�������ɹ�
		{
			temp = 0;
			for(k=0;k<curMeters.CurMeter[m].flgCount;k++)
			{
				if(curMeters.CurMeter[m].isFlgSucc[k]==0)
				{
					temp = 1;
				}
			}
			if(temp==0)
			{
				curMeters.CurMeter[m].Succ = 1;
				JDataFileInfo->data485[CarrWavePort-PortBegNum].MeterNum_CBSucc++;
				JDataFileInfo->data485[31-PortBegNum].MeterNum_CBSucc++;
				JDataFileInfo->ptinfo[getpt(curMeters.CurMeter[m].cjqNo,curMeters.CurMeter[m].MeterNo)].FirRead=1;
				JProgramInfo->FileSaveFlag.ptinfoflag= 1;
			}
		}
		TSGet(&ts);
		JDataFileInfo->data485[firflg-PortBegNum].ts=ts;            //�����´γ���ʱ��
		JDataFileInfo->data485[firflg-PortBegNum].Flag=1;
		JDataFileInfo->data485[31-PortBegNum].ts=ts;            //�����´γ���ʱ��
		JDataFileInfo->data485[31-PortBegNum].Flag=1;
		if (JProgramInfo->Para.ChangedJiZhongQiInfo==0)
			JProgramInfo->Para.ChangedJiZhongQiInfo = 2;
		//TimeAdd(&ts,3,1);
	}
	SdPrint("***********************************************************************************");
	SdPrint("\n\n��������    ---  ��������       ---   ��������     ---  ֹͣ����\n\n");
	SdPrint("***********************************************************************************");




//	pause_read();

//	//ʧ�ܵĵ�����õ㳭�س�һ��
//	for (i = 0; i<curMeters.MeterCount; i++)
//	{
//		if(isCLDChanged ==1)//ZBtiaoshi +  ������ı���ֹͣ����������ZBģ��
//		{
//			pause_read();
//			reboot_read();
//			ClearWaitTimes(ProjectNo,JProgramInfo);
//			break;
//		}
//		GetRealTimeData();
//		if (firflg!=CarrWavePort)
//			break;
//		memset(&df,0,sizeof(DataFiles));
//		df.fileType=3;
//		ClearWaitTimes(ProjectNo,JProgramInfo);
//		if (curMeters.CurMeter[i].Succ==0)
//		{
//			SdPrint("----------chaobiao shibai retry-------\n\r");
//			if (GetMeterData(firflg,&curMeters.CurMeter[i],&df,ts)==1)
//			{
//				Jmemory->Points.pt[getPoint(curMeters.CurMeter[i].cjqNo,curMeters.CurMeter[i].MeterNo)].f10.FirRead=1;
//				curMeters.CurMeter[curMeters.MeterCount].Succ=1;
//			}
//		}
//	}

}
/*--------------------------------------------------*/
void printString2(unsigned char *str,unsigned char Count,unsigned char flg)
{
	int i;
	SdPrint("\n\r");
	for(i=0;i<Count;i++)
	{

		if(flg==1)	{SdPrint(" %d",str[i]);}
		else if(flg==2)	{SdPrint(" %x",str[i]);}
		else	{SdPrint(" %c",str[i]);}
	}
	SdPrint("\n\r");
}

//���ݲɼ�
unsigned char GetValue(unsigned char cNO,unsigned char mNo,DataFlag97 *flg,unsigned char *Dest)//����
{
	INT16U i=0;
	ClearWaitTimes(ProjectNo,JProgramInfo);
	memset(Dest,OxXX,DataLenMax);//��ʼ��
	GetRealTimeData();//��ȡʵʱ����
	SdPrint("GetValue ������ �� %d ����ַ  %02x%02x%02x%02x%02x%02x  ��Լ %d �������ʶ %02x%02x\n\r",
			getPoint(cNO,mNo)+1,
			JParamInfo3761->group2.f10[getPoint(cNO,mNo)].Address[5],
			JParamInfo3761->group2.f10[getPoint(cNO,mNo)].Address[4],
			JParamInfo3761->group2.f10[getPoint(cNO,mNo)].Address[3],
			JParamInfo3761->group2.f10[getPoint(cNO,mNo)].Address[2],
			JParamInfo3761->group2.f10[getPoint(cNO,mNo)].Address[1],
			JParamInfo3761->group2.f10[getPoint(cNO,mNo)].Address[0],
			JParamInfo3761->group2.f10[getPoint(cNO,mNo)].ConnectType,
			flg->Dataflag[1],flg->Dataflag[0]);
	if(JParamInfo3761->group2.f10[getPoint(cNO,mNo)].ConnectType==1)
	{
		if ((flg->Dataflag[1]==0x00)||(flg->Dataflag[1]==0xEE)||(flg->Dataflag[1]==0xFF))
			return 2;
		Update_current_time = time(NULL);
		for (i=0;i<1;i++)  //ʧ�ܺ����һ���س�
		{
			if(	Dlt645GetVlueBy07(JParamInfo3761->group2.f10[getPoint(cNO,mNo)].Address,flg->Dataflag[0],flg->Dataflag[1],Dest)==1)
				return 1;
		}
	}
	else if(JParamInfo3761->group2.f10[getPoint(cNO,mNo)].ConnectType==30)
	{
		Update_current_time = time(NULL);
		for (i=0;i<1;i++)  //ʧ�ܺ����һ���س�
		{
			if(Dlt6452007GetValueBy97(JParamInfo3761->group2.f10[getPoint(cNO,mNo)].Address,flg,Dest)==1)
				return 1;
		}
	}else if(JParamInfo3761->group2.f10[getPoint(cNO,mNo)].ConnectType==21)//shanghai
	{
		Update_current_time = time(NULL);
		for (i=0;i<1;i++)  //ʧ�ܺ����һ���س�
		{
			if(Dlt645SHGetValueBy97(JParamInfo3761->group2.f10[getPoint(cNO,mNo)].Address,flg,Dest,getPoint(cNO,mNo))==1)
				return 1;
		}
	}
	return 0;
}

//�Ƿ��Ѿ�������
unsigned char  ReadHaved(TS ts,unsigned char flg)//������������Ƿ��Ѿ���ȡ����
{
	int i;
	if(JProgramInfo->inChaoBiao==1)
		return CarrWavePort;
	reflg=0;
	if(flg==3)
    {
    	if((JDataFileInfo->data485[CarrWavePort-1].ts.Year!=ts.Year) || (JDataFileInfo->data485[CarrWavePort-1].ts.Month!=ts.Month)
    		 || (JDataFileInfo->data485[CarrWavePort-1].ts.Day!=ts.Day))
    	{
    		for(i=0;i<PointMax;i++)
			{
				ClearWaitTimes(ProjectNo,JProgramInfo);
				if(JParamInfo3761->group2.f10[i].Status!=1){continue;}
				if ((JParamInfo3761->group2.f10[i].port!=CarrWavePort)&&(JParamInfo3761->group2.f10[i].port!=LocalCommPort))
					continue;
			}
    		reflg=1;      //��ʼ����,���ڳ���
    		return CarrWavePort;
    	}else
    	{
    		if (JDataFileInfo->data485[CarrWavePort-1].ts.Hour!=ts.Hour)
    			return CarrWavePort;
    		if ((JParamInfo3761->group5.f33.f33[4].CbInter<=0) || (JParamInfo3761->group5.f33.f33[4].CbInter>60))
					JParamInfo3761->group5.f33.f33[4].CbInter=60;
				//if (JParamInfo3761->group5.f33.f33[4].CbInter<10)
				//	JParamInfo3761->group5.f33.f33[4].CbInter=10;
    		if (((ts.Hour-JDataFileInfo->data485[CarrWavePort-1].ts.Hour)*60+ts.Minute-JDataFileInfo->data485[CarrWavePort-1].ts.Minute)>=JParamInfo3761->group5.f33.f33[4].CbInter)
			{
        		for(i=0;i<PointMax;i++)
    			{
    				ClearWaitTimes(ProjectNo,JProgramInfo);
    				if(JParamInfo3761->group2.f10[i].Status!=1){continue;}
    				if ((JParamInfo3761->group2.f10[i].port!=CarrWavePort)&&(JParamInfo3761->group2.f10[i].port!=LocalCommPort))
    					continue;
    			}
        		printf("\n\n");
        		return CarrWavePort;
			}
    	}
    }
   return 0;
}
//���ݴ�ӡ
void PrintMeterData(DataFiles *fl)
{

}
//���ݲɼ�
INT8U GetMeterData(INT8U FirFlg,CurMeterInfo *curMeters ,DataFiles *fl,TS ts)
{
	int flgID,succ,ret,i=0,result=0;
	INT8U dayflg=0,monflg=0,hourflg=0,TempBuf[60],Command[120];
	TS ts2;
	unsigned char rt=1;
	unsigned char  Dest[DataLenMax];
	succ=1;
	rt=1;
	delay(100);
	ClearWaitTimes(ProjectNo,JProgramInfo);
	//if(fl->fileType<2)	ReadDataTasks();//����ִ�ж���������
	succ=0;
	result=0;
	for(i=0;((((i<1) && (succ==0) && (ts.Hour==0) && (FirFlg>=1))) || ((i<1) && (succ==0)));i++)
	{//0��ʱ����δ�ɹ����س�һ��
		if(curMeters->flType==common)//��ͨ���ļ���
		{
			succ=0;
			for(flgID=0;flgID<curMeters->flgCount;flgID++)
			{
				ClearWaitTimes(ProjectNo,JProgramInfo);
				ret=GetValue(curMeters->cjqNo,curMeters->MeterNo,&curMeters->flg[flgID],&Dest[0]);
				if (ret==1 )
				{
					succ=1;
					rt=0;//�޹���

					memcpy(fl->manyFiles.sm.datas[flgID].datas,&Dest[0],DataLenMax);
					fl->manyFiles.sm.datas[flgID].flg.Dataflag[0]=curMeters->flg[flgID].Dataflag[0];
					fl->manyFiles.sm.datas[flgID].flg.Dataflag[1]=curMeters->flg[flgID].Dataflag[1];
				}
			}
		}
		else //�๦�ܱ�
		{
			succ=0;
			for(flgID=0;flgID<curMeters->flgCount;flgID++)//�๦�ܱ��������õĲɼ���ɼ�
			{
				ClearWaitTimes(ProjectNo,JProgramInfo);
				ret=GetValue(curMeters->cjqNo,curMeters->MeterNo,&curMeters->flg[flgID],&Dest[0]);
				if (ret==1 )
				{
					succ=1;
					rt=0;//�޹���
					memcpy(fl->manyFiles.sm.datas[flgID].datas,&Dest[0],DataLenMax);
					fl->manyFiles.sm.datas[flgID].flg.Dataflag[0]=curMeters->flg[flgID].Dataflag[0];
					fl->manyFiles.sm.datas[flgID].flg.Dataflag[1]=curMeters->flg[flgID].Dataflag[1];
				}
				if(flgID%10==0)
				{
					 //if(fl->fileType<2)	ReadDataTasks();//����ִ�ж���������
				}
			}

		}
	}

	if (succ==1)      //�����ɹ�
	{
		result=1;
		fl->manyFiles.sm.CaijiQiNo=curMeters->cjqNo;
		fl->manyFiles.sm.MeterNo=curMeters->MeterNo;
		if (JParamInfo3761->group2.f9.Flag[3] & 0x40)
		{
			ret=getPoint(curMeters->cjqNo,curMeters->MeterNo);
			if(JParamInfo3761->group2.f10[ret].AlarmFlg[30]&0x40)
			{
				ret=0;
				while(ret<100)
				{
					if(JProgramInfo->stateflags.ErcFlg==0)
						break;
					delay(50);
					ret++;
				}
				memset(&JProgramInfo->CurrErc,0,sizeof(ERC));
				ret=getPoint(curMeters->cjqNo,curMeters->MeterNo)+1;
				JProgramInfo->CurrErc.Err31.ERCNo=31;
				JProgramInfo->CurrErc.Err31.len=21;
				JProgramInfo->CurrErc.Err31.ClNo[0]=ret&0xff;
				JProgramInfo->CurrErc.Err31.ClNo[1]=(ret>>8)&0xff;
				JProgramInfo->CurrErc.Err31.ClNo[1]&=0x7F;
				JProgramInfo->stateflags.ErcFlg=31;
				JParamInfo3761->group2.f10[ret].AlarmFlg[30]&=0b10111111;
			}
		}
	}
	else
	{
		if (FirFlg != 0)
		{
			if (JParamInfo3761->group2.f9.Flag[3] & 0x40)
			{
				ret=getPoint(curMeters->cjqNo,curMeters->MeterNo);
				if(!(JParamInfo3761->group2.f10[ret].AlarmFlg[30]&0x40))
				{
					ret=0;
					while(ret<100)
					{
						if(JProgramInfo->stateflags.ErcFlg==0)
							break;
						delay(50);
						ret++;
					}
					memset(&JProgramInfo->CurrErc,0,sizeof(ERC));
					ret=getPoint(curMeters->cjqNo,curMeters->MeterNo)+1;
					JProgramInfo->CurrErc.Err31.ERCNo=31;
					JProgramInfo->CurrErc.Err31.len=21;
					JProgramInfo->CurrErc.Err31.ClNo[0]=ret&0xff;
					JProgramInfo->CurrErc.Err31.ClNo[1]=(ret>>8)&0xff;
					JProgramInfo->CurrErc.Err31.ClNo[1]|=0x80;
					JProgramInfo->stateflags.ErcFlg=31;
					JParamInfo3761->group2.f10[ret].AlarmFlg[30]|=0b01000000;
				}
			}
			if (JParamInfo3761->group2.f9.Flag[2] & 0x10)
			{
				ret=getPoint(curMeters->cjqNo,curMeters->MeterNo);
				if(!(JParamInfo3761->group2.f10[ret].AlarmFlg[20]&0x10))
				{
					ret=0;
					while(ret<100)
					{
						if(JProgramInfo->stateflags.ErcFlg==0)
							break;
						delay(50);
						ret++;
					}
					memset(&JProgramInfo->CurrErc,0,sizeof(ERC));
					ret=getPoint(curMeters->cjqNo,curMeters->MeterNo)+1;
					JProgramInfo->CurrErc.Err21.ERCNo=21;
					JProgramInfo->CurrErc.Err21.len=6;
					JProgramInfo->stateflags.ErcFlg=21;
					JParamInfo3761->group2.f10[ret].AlarmFlg[20]|=0b00010000;
				}
			}
		}
	}

	ret=getPoint(curMeters->cjqNo,curMeters->MeterNo)+1;
	SdPrint("ret====point===%d---%d--%d\n\r",ret,succ,FirFlg);
	if (FirFlg == 0)
	{
		hourflg=1;
		dayflg=1;
		monflg=1;
	}
	else
	{
	}
	if (succ==1)
	{
		memset(TempBuf,0,60);
		sprintf((char*)TempBuf,"/nand/DataCurr/%04d/",ret);
		if (access((char*)TempBuf,0)!=0)//��Ŀ¼�����ڣ��ȴ���
		{
			memset(Command,0,60);
			sprintf((char*)Command,"%s /nand/DataCurr/%04d/",_CMDMKDIR_,ret);
			 system((char*)Command);
			 delay(100);
		 }
		memset(TempBuf,0,60);
		sprintf((char*)TempBuf,"/nand/DataDay/%04d/",ret);//��Ŀ¼�����ڣ��ȴ���
		if (access((char*)TempBuf,0)!=0)
		{
			memset(Command,0,60);
			sprintf((char*)Command,"%s /nand/DataDay/%04d/",_CMDMKDIR_,ret);
			 system((char*)Command);
			 delay(100);
		 }
		memset(TempBuf,0,60);
		sprintf((char*)TempBuf,"/nand/DataMonth/%04d/",ret);//��Ŀ¼�����ڣ��ȴ���
		if (access((char*)TempBuf,0)!=0)
		{
			memset(Command,0,60);
			sprintf((char*)Command,"%s /nand/DataMonth/%04d/",_CMDMKDIR_,ret);
			 system((char*)Command);
			 delay(100);
		 }
		ts2=ts;
		/*TimeDecrease(&ts2,4,1);
		if (ts.Month==1)
			ts2.Month=12;
		else
			ts2.Month=ts.Month-1;*/
		//if (hourflg==1)
		//{
		//}

		memset(TempBuf,0,60);
		sprintf((char*)TempBuf,"/nand/DataCurr/%04d/curr.dat",ret);
		if (access((char*)TempBuf,0)==0)//��curr.dat����last.dat
		{
			memset(Command,0,120);
			sprintf((char*)Command,"%s /nand/DataCurr/%04d/curr.dat /nand/DataCurr/%04d/last.dat",
					_CMDCP_,ret,ret);
			system((char*)Command);
			delay(50);
		}
		fl->manyFiles.ts=ts;
		fl->manyFiles.sm.CaijiQiNo=curMeters->cjqNo;
		fl->manyFiles.sm.MeterNo=curMeters->MeterNo;
		smfileinfo.cldno = getPoint(curMeters->cjqNo,curMeters->MeterNo)+1;
		smfileinfo.ts = ts;
		smfileinfo.filetype = FILECURR;
		mySaveFile((char*)TempBuf,(INT8U *)&fl->manyFiles,FILEHEADSIZE+curMeters->flgCount*sizeof(DataFlg),
				JProgramInfo,&smfileinfo);
		delay(50);
	}
	else
	{
		memset(TempBuf,0,60);
		sprintf((char*)TempBuf,"/nand/DataCurr/%04d/",ret);
		if (access((char*)TempBuf,0)!=0)//��Ŀ¼�����ڣ�����Ŀ¼
		{
			memset(Command,0,60);
			sprintf((char*)Command,"%s /nand/DataCurr/%04d/",_CMDMKDIR_,ret);
			 system((char*)Command);
			 delay(100);
		 }

		memset(TempBuf,0,60);
		sprintf((char*)TempBuf,"/nand/DataCurr/%04d/curr.dat",ret);
		if (access((char*)TempBuf,0)==0)//��ǰʧ�ܣ�������last.dat�� ɾ��curr.dat
		{
			memset(Command,0,120);
			sprintf((char*)Command,"%s /nand/DataCurr/%04d/curr.dat /nand/DataCurr/%04d/last.dat",
					_CMDCP_,ret,ret);
			system((char*)Command);
			delay(50);
			if ((reflg==0)&&(ts.Hour>5))
			{
				memset(Command,0,120);
				sprintf((char*)Command,"%s /nand/DataCurr/%04d/curr.dat",_CMDRM_,ret);
				system((char*)Command);
				delay(50);
			}
		}
	}
	return result;
}

//��ȡʵʱ����
void GetRealTimeData(void)
{
	ClearWaitTimes(ProjectNo,JProgramInfo);
	DataTrans();
	if(JProgramInfo->RealData.ReadFlg!=1)return;
	F10 *Meter;
	F25 *f25;
	unsigned char  Dest[DataLenMax];
	unsigned char rt=1,sc,succ=0;
	int i,ret=0;

	if ((JParamInfo3761->group2.f10[getPoint(JProgramInfo->RealData.CaijiqiNo,JProgramInfo->RealData.MeterNo)].port!=CarrWavePort) &&
	    (JParamInfo3761->group2.f10[getPoint(JProgramInfo->RealData.CaijiqiNo,JProgramInfo->RealData.MeterNo)].port!=LocalCommPort))
		return;
	Meter=&JParamInfo3761->group2.f10[getPoint(JProgramInfo->RealData.CaijiqiNo,JProgramInfo->RealData.MeterNo)];
	f25 =&JParamInfo3761->Point[getPoint(JProgramInfo->RealData.CaijiqiNo,JProgramInfo->RealData.MeterNo)].f25;
	if ((Meter->ConnectType!=1) && (Meter->ConnectType!=30)&& (Meter->ConnectType!=21))
	{
		JProgramInfo->RealData.ReadFlg=9;
		return;
	}
	//1������ڳ�����¼�ϵ���������
	JProgramInfo->RealData.ReadFlg=3;
	delay(100);
	sc=1;
	succ=0;
	delay(1000);
	for(i=0;i<JProgramInfo->RealData.CurFlgCount;i++)
	{
		SdPrint("\n JProgramInfo->RealData.ReadFlg = %d  i==%d\n", JProgramInfo->RealData.ReadFlg, i);
		ClearWaitTimes(ProjectNo,JProgramInfo);
		if(JProgramInfo->RealData.ReadFlg==0)break;
		if(JProgramInfo->RealData.ReadFlg==4) break;
		if(JProgramInfo->RealData.ReadFlg==3)
		{
			SdPrint("\n\r GetRealTimeData   GetRealTimeDataGetRealTimeDataGetRealTimeDataGetRealTimeDataGetRealTimeData   \n\r");
            if (sc==1)
            {
            	ret=GetValue(JProgramInfo->RealData.CaijiqiNo,JProgramInfo->RealData.MeterNo,&JProgramInfo->RealData.flg97[i].flg,&Dest[0]);
	            if(ret==1)
				{
	            	succ=1;
					memcpy(JProgramInfo->RealData.flg97[i].datas,&Dest[0],DataLenMax);
					rt=0;
				}
			}
		}
	}
	if (succ==1)
	{
		if (JParamInfo3761->group2.f9.Flag[3] & 0x40)
		{
			ret=getPoint(JProgramInfo->RealData.CaijiqiNo,JProgramInfo->RealData.MeterNo);
			if(JParamInfo3761->group2.f10[ret].AlarmFlg[30]&0x40)
			{
				ret=0;
				while(ret<100)
				{
					if(JProgramInfo->stateflags.ErcFlg==0)
						break;
					delay(50);
					ret++;
				}
				memset(&JProgramInfo->CurrErc,0,sizeof(ERC));
				ret=getPoint(JProgramInfo->RealData.CaijiqiNo,JProgramInfo->RealData.MeterNo)+1;
				JProgramInfo->CurrErc.Err31.ERCNo=31;
				JProgramInfo->CurrErc.Err31.len=21;
				JProgramInfo->CurrErc.Err31.ClNo[0]=ret&0xff;
				JProgramInfo->CurrErc.Err31.ClNo[1]=(ret>>8)&0xff;
				JProgramInfo->CurrErc.Err31.ClNo[1]&=0x7F;
				JProgramInfo->stateflags.ErcFlg=31;
				JParamInfo3761->group2.f10[ret].AlarmFlg[30]&=0b10111111;
			}
		}
	}
	else
	{
		if (JParamInfo3761->group2.f9.Flag[3] & 0x40)
		{
			ret=getPoint(JProgramInfo->RealData.CaijiqiNo,JProgramInfo->RealData.MeterNo);
			if(!(JParamInfo3761->group2.f10[ret].AlarmFlg[30]&0x40))
			{
				ret=0;
				while(ret<100)
				{
					if(JProgramInfo->stateflags.ErcFlg==0)
						break;
					delay(50);
					ret++;
				}
				memset(&JProgramInfo->CurrErc,0,sizeof(ERC));
				ret=getPoint(JProgramInfo->RealData.CaijiqiNo,JProgramInfo->RealData.MeterNo)+1;
				JProgramInfo->CurrErc.Err31.ERCNo=31;
				JProgramInfo->CurrErc.Err31.len=21;
				JProgramInfo->CurrErc.Err31.ClNo[0]=ret&0xff;
				JProgramInfo->CurrErc.Err31.ClNo[1]=(ret>>8)&0xff;
				JProgramInfo->CurrErc.Err31.ClNo[1]|=0x80;
				JProgramInfo->stateflags.ErcFlg=31;
				JParamInfo3761->group2.f10[ret].AlarmFlg[30]|=0b01000000;
			}
		}

		if (JParamInfo3761->group2.f9.Flag[2] & 0x10)
		{
			ret=getPoint(JProgramInfo->RealData.CaijiqiNo,JProgramInfo->RealData.MeterNo);
			if(!(JParamInfo3761->group2.f10[ret].AlarmFlg[20]&0x10))
			{
				ret=0;
				while(ret<100)
				{
					if(JProgramInfo->stateflags.ErcFlg==0)
						break;
					delay(50);
					ret++;
				}
				memset(&JProgramInfo->CurrErc,0,sizeof(ERC));
				ret=getPoint(JProgramInfo->RealData.CaijiqiNo,JProgramInfo->RealData.MeterNo)+1;
				JProgramInfo->CurrErc.Err21.ERCNo=21;
				JProgramInfo->CurrErc.Err21.len=6;
				JProgramInfo->stateflags.ErcFlg=21;
				JParamInfo3761->group2.f10[ret].AlarmFlg[20]|=0b00010000;
			}
		}
	}
//	if(resume_read()==0) //zbtiaoshi + �ָ�ʧ��������ZBģ��
//		reboot_read();
	SdPrint("\n\r  GetRealTimeData  end aaaaaaaaaaaaaaaaaaaaaa\n\r");
	if(JProgramInfo->RealData.ReadFlg==3)
	{
		JProgramInfo->RealData.ReadFlg=9;
		//WatchConnectionAlarm(JProgramInfo->RealData.CaijiqiNo,JProgramInfo->RealData.MeterNo,rt);
	}
	//3�ָ��ϵ��������ü�������
}

void GetDt(INT8U Dt1, INT8U Dt2)//�õ���Ϣ��DT��
{
	INT8U i;
	memset(DT, 0, 255);
	for (i = 0; i < 8; i++) {
		if (Dt1 & CMP8U[i]) {
			DT[Dt2 * 8 + i + 1] = 1;
		}
	}
}


void GetDa(INT8U Da1, INT8U Da2)
{
	INT8U i;
	memset(DA, 0, PointMax);//DAֻʹ�ú�64λ
	if ((Da1 == 0) && (Da2 == 0)) {
		DA[0] = 1;
		return;
	}
	if (Da2 == 0) {
		memset(DA, 0, PointMax);
		return;
	}
	if ((Da1 == 0xff) && (Da2 == 0xff)) {
		memset(DA, 1, PointMax);
	}
	for (i = 0; i < 8; i++)
	{
		if (Da1 & CMP8U[i])
		{
			DA[(Da2-1) * 8 + i + 1] = 1;
		}
	}
}


