#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <inc/CVariable.h>
#include <inc/pubfunction.h>
#include "jReadZB.h"
#include "ReadMeter.h"
#include <signal.h>

Fn_DLT fn_dlt_5_1[Fn_DLT_NUM];
Fn_DLT fn_dlt_5_2[Fn_DLT_NUM];
Fn_DLT fn_dlt_7_1[Fn_DLT_NUM];
Fn_DLT fn_dlt_7_2[Fn_DLT_NUM];
Fn_DLT fn_dlt_0_2[Fn_DLT_NUM];
Fn_DLT fn_dlt_6_2[Fn_DLT_NUM];
extern int isDataFlagValued_Shanghai(DataFlag97 *flg97);//�ж�������������Ч 0 ��Ч  1 ��Ч
extern int isDataFlagValued_97(DataFlag97 *flg97);//�ж�������������Ч 0 ��Ч  1 ��Ч

extern void fuzhi_5_1(Fn_DLT *fn_dlt_5_1);
extern void fuzhi_5_2(Fn_DLT *fn_dlt_5_2);
extern void fuzhi_7_1(Fn_DLT *fn_dlt_7_1);
extern void fuzhi_7_2(Fn_DLT *fn_dlt_7_2);
extern void fuzhi_0_2(Fn_DLT *fn_dlt_0_2);
extern void fuzhi_6_2(Fn_DLT *fn_dlt_6_2);

int init_fn_dlt(INT8U *filename, Fn_DLT *fn_dlt)
{
	int count=0,i=0;
	if(access((char*)filename,0)==0)
	{
		ReadFile((char*)filename, &fn_dlt[0], Fn_DLT_NUM*sizeof(Fn_DLT), JProgramInfo);
		for(i=0;i<Fn_DLT_NUM;i++)
		{
			if(fn_dlt[i].status!=0)
				count++;
		}
	}
	return count;
}


int GetDaLei(int cldno)
{
	INT8U DaNo;
	DaNo = (JParamInfo3761->group2.f10[cldno].UserType & 0xf0) >>4;		//�����
	return DaNo;
}
int GetXiaoLei(int cldno)
{
	INT8U XiaoNo;
	XiaoNo = JParamInfo3761->group2.f10[cldno].UserType & 0x0f;			//С���
	return XiaoNo;
}
int IsZhongDianUser(int cldno)
{
	//JParamInfo3761->group5.f35.index
	//JParamInfo3761->group5.f35.Count
	int k=0;
	INT8U zdflg=0;
	for(k=0;k<JParamInfo3761->group5.f35.Count;k++)
	{
		if (JParamInfo3761->group5.f35.Index[k]==(cldno+1))//�ص��û�
		{
			zdflg=1;
			fprintf(stderr,"�����ص��û���zdflag=%d,cldno=%d\n",zdflg,cldno);
			break;
		}
	}
	return zdflg;
}
//��9010ת��901f
void dealdataflag(DataFlag97 *flg97, int num)
{
	int i=0;
	for(i=0; i<num; i++)
	{
		if(flg97[i].Dataflag[0]==0x10 && flg97[i].Dataflag[1]==0x90)
			flg97[i].Dataflag[0]=0x1f;
		else if(flg97[i].Dataflag[0]==0x20 && flg97[i].Dataflag[1]==0x90)
			flg97[i].Dataflag[0]=0x2f;
		else if(flg97[i].Dataflag[0]==0x30 && flg97[i].Dataflag[1]==0x90)
			flg97[i].Dataflag[0]=0x3f;
		else if(flg97[i].Dataflag[0]==0x40 && flg97[i].Dataflag[1]==0x90)
			flg97[i].Dataflag[0]=0x4f;
		else if(flg97[i].Dataflag[0]==0x10 && flg97[i].Dataflag[1]==0xa0)
			flg97[i].Dataflag[0]=0x1f;
		else if(flg97[i].Dataflag[0]==0x20 && flg97[i].Dataflag[1]==0xa0)
			flg97[i].Dataflag[0]=0x2f;
		else if(flg97[i].Dataflag[0]==0x30 && flg97[i].Dataflag[1]==0xa0)
			flg97[i].Dataflag[0]=0x3f;
		else if(flg97[i].Dataflag[0]==0x40 && flg97[i].Dataflag[1]==0xa0)
			flg97[i].Dataflag[0]=0x4f;
	}
	return;
}
//���˵����Ǵ˹�Լ��������
int dealGuiyueDataFlag(int cldno, DataFlag97 *flg97, int num)
{
	int i,indexflg=0;
	DataFlag97 tmpflg[512];
	INT8U guiyue;
	guiyue = JParamInfo3761->group2.f10[cldno].ConnectType;
	printf("\n\ndealGuiyueDataFlag  cldno %d\n",cldno);
	memset(tmpflg, 0, 512*sizeof(DataFlag97));
	for(i=0;i<num;i++)
	{
		if((guiyue==1) && (isDataFlagValued_97(&flg97[i])==1))
		{
			memcpy(&tmpflg[indexflg], &flg97[i], sizeof(DataFlag97));
			indexflg++;
		}else if((guiyue==21) && (isDataFlagValued_Shanghai(&flg97[i])==1))
		{
			memcpy(&tmpflg[indexflg], &flg97[i], sizeof(DataFlag97));
			indexflg++;
		}
	}
	memset(&flg97[0], 0, num*sizeof(DataFlag97));
	for(i=0; i<indexflg; i++)
		memcpy(&flg97[i], &tmpflg[i], sizeof(DataFlag97));
	return indexflg;
}
//Ҫ���˵��ظ���������  һ��num��������
int RepeatDataflag_GuoLv(DataFlag97 *flg97, int num)
{
	DataFlag97 tmpflg[512];
	int i=0, j=0, indexflg=0;
	INT8U repeat_flg=0; //0 �ظ�  1 ���ظ�
	if(num>511)
		return 0;
	memset(tmpflg, 0, sizeof(DataFlag97));
	for(i=0;i<num;i++)
	{
		repeat_flg = 1;
		if(!((flg97[i].Dataflag[0]==0x00 && flg97[i].Dataflag[1]==0x00)||
			(flg97[i].Dataflag[0]==0xee && flg97[i].Dataflag[1]==0xee)||
			(flg97[i].Dataflag[0]==0xFF && flg97[i].Dataflag[1]==0xff)))
		{
			if(indexflg==0)
				repeat_flg = 1;
			for(j=0; j<indexflg; j++)
			{
				if((tmpflg[j].Dataflag[0]==flg97[i].Dataflag[0])&&
					(tmpflg[j].Dataflag[1]==flg97[i].Dataflag[1]))
					repeat_flg = 0; //�ظ�
			}
			if(repeat_flg==1)
			{
				memcpy(&tmpflg[indexflg], &flg97[i], sizeof(DataFlag97));
				indexflg++;
			}
		}
	}
	memset(&flg97[0], 0, num*sizeof(DataFlag97));
	for(i=0; i<indexflg; i++)
		memcpy(&flg97[i], &tmpflg[i], sizeof(DataFlag97));
	return indexflg;
}

int Getleidataflag(int cldno, Fn_DLT *fn_dlt, DataFlag97 *flg97)
{
	int fn_dlt_index=0,	flgcount=0;
	int m=0;
	for(fn_dlt_index=0; fn_dlt_index<Fn_DLT_NUM; fn_dlt_index++)      //���ݱ�ʾ�ж�
	{
		if(fn_dlt[fn_dlt_index].status==1 ||
			(fn_dlt[fn_dlt_index].status==2 && (IsZhongDianUser(cldno)==1)))
		{
			for(m=0;m<10;m++)
			{
//				fprintf(stderr, "\n-----------------------------------%02x%02x--",
//						fn_dlt[fn_dlt_index].DLT[m].Dataflag[1],fn_dlt[fn_dlt_index].DLT[m].Dataflag[0]);
				if(!((fn_dlt[fn_dlt_index].DLT[m].Dataflag[0]==0x00 && fn_dlt[fn_dlt_index].DLT[m].Dataflag[1]==0x00)||
					(fn_dlt[fn_dlt_index].DLT[m].Dataflag[0]==0xee && fn_dlt[fn_dlt_index].DLT[m].Dataflag[1]==0xee)||
					(fn_dlt[fn_dlt_index].DLT[m].Dataflag[0]==0xFF && fn_dlt[fn_dlt_index].DLT[m].Dataflag[1]==0xff)))
				{
					flg97[flgcount].Dataflag[0]=fn_dlt[fn_dlt_index].DLT[m].Dataflag[0];
					flg97[flgcount].Dataflag[1]=fn_dlt[fn_dlt_index].DLT[m].Dataflag[1];
					flgcount++;
//					fprintf(stderr,"\n[%02x%02x]\n",flg97[flgcount].Dataflag[1],flg97[flgcount].Dataflag[0]);
				}
			}
		}
	}
	flgcount = RepeatDataflag_GuoLv(&flg97[0], flgcount);
	return flgcount;
}

int GetDataFlagsbyLeihao(int cldno, DataFlag97 *flg97)
{
	int daleihao=0,xiaoleihao=0, count=0;
	daleihao = GetDaLei(cldno);
	xiaoleihao = GetXiaoLei(cldno);
	if(daleihao==5 && xiaoleihao==1)
		count = Getleidataflag(cldno, &fn_dlt_5_1[0], flg97);
	else if(daleihao==5 && xiaoleihao==2)
		count = Getleidataflag(cldno, &fn_dlt_5_2[0], flg97);
	else if(daleihao==7 && xiaoleihao==1)
		count = Getleidataflag(cldno, &fn_dlt_7_1[0], flg97);
	else if(daleihao==7 && xiaoleihao==2)
		count = Getleidataflag(cldno, &fn_dlt_7_2[0], flg97);
	else if(daleihao==0 && xiaoleihao==2)
		count = Getleidataflag(cldno, &fn_dlt_0_2[0], flg97);
	else if(daleihao==6 && xiaoleihao==2)
		count = Getleidataflag(cldno, &fn_dlt_6_2[0], flg97);
	else
		count = Getleidataflag(cldno, &fn_dlt_5_1[0], flg97);
	return count;
}

void InitFnDltDataFlags()
{
//	JParamInfo3761->group2.f10[1].UserType = 0x62;
//	fprintf(stderr, "\nDalei===%d  Xiaolei====%d\n", GetDaLei(1),GetXiaoLei(1));
	INT8U name[60];
	memset(name,0,60);
	memset(fn_dlt_5_1, 0, Fn_DLT_NUM*sizeof(Fn_DLT));
	memset(fn_dlt_5_2, 0, Fn_DLT_NUM*sizeof(Fn_DLT));
	memset(fn_dlt_7_1, 0, Fn_DLT_NUM*sizeof(Fn_DLT));
	memset(fn_dlt_7_2, 0, Fn_DLT_NUM*sizeof(Fn_DLT));
	memset(fn_dlt_0_2, 0, Fn_DLT_NUM*sizeof(Fn_DLT));
	memset(fn_dlt_6_2, 0, Fn_DLT_NUM*sizeof(Fn_DLT));

	sprintf((char*)name,"%s","/nor/config/fn_dlt_5_1.par");
	if(access((char*)name,0)==0)
		init_fn_dlt(name,&fn_dlt_5_1[0]);
	else
		fuzhi_5_1(fn_dlt_5_1);

	memset(name,0,60);
	sprintf((char*)name,"%s","/nor/config/fn_dlt_5_2.par");
	if(access((char*)name,0)==0)
		init_fn_dlt(name,&fn_dlt_5_2[0]);
	else
		fuzhi_5_2(fn_dlt_5_2);

	memset(name,0,60);
	sprintf((char*)name,"%s","/nor/config/fn_dlt_7_1.par");
	if(access((char*)name,0)==0)
		init_fn_dlt(name,&fn_dlt_7_1[0]);
	else
		fuzhi_7_1(fn_dlt_7_1);

	memset(name,0,60);
	sprintf((char*)name,"%s","/nor/config/fn_dlt_7_2.par");
	if(access((char*)name,0)==0)
		init_fn_dlt(name,&fn_dlt_7_2[0]);
	else
		fuzhi_7_2(fn_dlt_7_2);

	memset(name,0,60);
	sprintf((char*)name,"%s","/nor/config/fn_dlt_0_2.par");
	if(access((char*)name,0)==0)
		init_fn_dlt(name,&fn_dlt_0_2[0]);
	else
		fuzhi_0_2(fn_dlt_0_2);

	memset(name,0,60);
	sprintf((char*)name,"%s","/nor/config/fn_dlt_6_2.par");
	if(access((char*)name,0)==0)
		init_fn_dlt(name,&fn_dlt_6_2[0]);
	else
		fuzhi_6_2(&fn_dlt_6_2[0]);
}
