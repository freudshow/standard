//Copyright ��Ȩ����  2009�ൺ�߿�ͨ�Źɷ����޹�˾
// �ļ�����jReadCarr.c
// �ļ������������Զ���������
// ������ʶ��20090901 Ray
//9.27
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <inc/CVariable.h>
#include <inc/pubfunction.h>
#include "jReadZB.h"
#include "ReadMeter.h"
#include <signal.h>
#include <pthread.h>
unsigned char   GetProjects(int argc, char * argv[]);//����ע��,��ȡ����źͳ�������
void QuitProcess(int signo);//�˳�����
extern void CloseComCarrZB();
extern int OpenComCarrZB(unsigned short baud,unsigned char *par,unsigned char stopb,unsigned char bits,unsigned char ComPortNo);

extern unsigned int AddPoint(INT16U MeterNo);
extern void AddAllPoints();
extern void RemovePoint(unsigned char MetAddr[6]);
extern INT8U InitWaveData();
extern INT8U ResetWave();
extern void SendTestCarrierWave(INT8U comp);
extern INT8U GetCarrierWaveAddress(INT8U flag);
extern DataFlag97 Le1flgComm[250][20];
extern DataFlag97 Le1flgMany[250][20];
extern unsigned char reboot_read(void);
extern unsigned char ReceiveFromCarr(unsigned char *str);
extern unsigned int InitZBPointInfo();
extern int GetZBSlavePoint();
extern int GetZBSlavePointNum();
//extern void AddZBPoints(int num);
extern void initLe1flgComm();

extern unsigned char BeginSearchMeter_auto(INT8U time);//�㲥��������
extern unsigned char EnReg_auto(INT8U time);//����ӽڵ�����ע��
extern unsigned char LookupSlaveInfo_auto(INT16U startno, INT8U num);
extern INT8U RTMeterProcess_auto(INT8U *buf, INT16U len);//�������͵ı���
extern void RepMeter_auto(INT8U autoregtime);//���������ѵ��ı���
extern unsigned char ZBStatus_read();
extern unsigned char SetupZBAdress();
//���Ӳ�����ʱ���õ�(һ�����Ӷ���������õ�)
INT8U MeterInf[PointMax][6];
INT8U ZBMeterInf[PointMax][6];
INT16U meter_info[PointMax];    //������� ,����getPointת���������
INT8U gui_yue[PointMax];		//��Ź�Լ 1=97 30=07



void GetPtsfromZB()//ZBtiaoshi
{
	int i,count=1,curnum=0;
	//��ZBģ����ȡ�����в�������Ϣ��ŵ�MeterInf������
	SlavePoint_TotalNum=0;
//	if(GetZBSlavePoint(1,1)==-1)//���ZBģ��ӽڵ�����
//	{//���û���յ������ٷ�����
//		GetZBSlavePoint(1,1);
//		GetZBSlavePoint(1,1);
//	}
	if(GetZBSlavePointNum()==-1)//cuowu
	{
		GetZBSlavePointNum();
		GetZBSlavePointNum();
	}
	ClearWaitTimes(ProjectNo,JProgramInfo);
	memset(ZBMeterInf,0xff,PointMax*6);
	while(count<=SlavePoint_TotalNum)
	{
		ClearWaitTimes(ProjectNo,JProgramInfo);
		memset(Ret_TmpPonint, 0xff, POINT_COUNT*6);
		curnum=GetZBSlavePoint(count,POINT_COUNT);//dingxin
		if(curnum == 0)
			break;
		for(i=0; i<curnum; i++)
		{
			memcpy(&ZBMeterInf[i+count-1][0],&Ret_TmpPonint[i][0],6);
			SdPrint("\n count=%d curnum=%d   [%d]  From ZB: %02x%02x%02x%02x%02x%02x\n",
					count,curnum,
					i+count-1,
					Ret_TmpPonint[i][5],Ret_TmpPonint[i][4],Ret_TmpPonint[i][3],
					Ret_TmpPonint[i][2],Ret_TmpPonint[i][1],Ret_TmpPonint[i][0]);
		}
		count += curnum;
	}
	SdPrint("\nZBģ������������� SlavePoint_TotalNum: %d\n",SlavePoint_TotalNum);
	//DelRepeatZBPoint();
}
void InitPtInfo(int ptno)
{
	int j = 0,i=0;
//	memset(&Jmemory->Points,0x00,sizeof(Jmemory->Points));
	j = ptno;
	JParamInfo3761->group2.f10[j].ConnectType=30;			//ͨ��Э������ 1 97 30 2007
	memset(JParamInfo3761->group2.f10[j].Address,0x00,6);			//ͨ�ŵ�ַ
	memset(JParamInfo3761->group2.f10[j].PassWord,0x00,6);			//ͨ������
	JParamInfo3761->group2.f10[j].FeiLvCnt=4;				//���ܷ��ʸ���
	JParamInfo3761->group2.f10[j].DecimalDigits=1;		//�й�����ʾֵ����λ��С��λ����
	memset(JParamInfo3761->group2.f10[j].CaijiqiAddress,0x00,6);	//�����ɼ���ͨ�ŵ�ַ
	JParamInfo3761->group2.f10[j].UserType=0;				//�û�����ż��û�С���
	JParamInfo3761->group2.f10[j].baudrate=0x08;				//SD������
	if(j == 0)
		JParamInfo3761->group2.f10[j].port=1;	//����  yangdong
	else
		JParamInfo3761->group2.f10[j].port=1+PortBegNum;					//SD�˿ں�
	JParamInfo3761->group2.f10[j].jiao_yan_wei=0x01;			//SDУ��λ
	JParamInfo3761->group2.f10[j].shu_ju_wei=0x08;			//SD����λ
	JParamInfo3761->group2.f10[j].ting_zhi_wei=0x01;			//SDֹͣλ
	for(i=0;i<64;i++)
		JParamInfo3761->group2.f10[j].AlarmFlg[i]=0x00;
	JParamInfo3761->group2.f10[j].Status=0;				//SD״̬

	JParamInfo3761->group2.f10[j].CjqNo=j/64+1;				//SD�ɼ���
	JParamInfo3761->group2.f10[j].MeterNo=j%64;			//SD�������
	JParamInfo3761->group2.f10[j].FirRead=0;
	JParamInfo3761->group2.f10[j].Type=9;
	JParamInfo3761->Point[j].f25.V_BeiLv[0] = 1;
	JParamInfo3761->Point[j].f25.I_BeiLv[0] = 1;
	memset(JParamInfo3761->group2.f10[j].PointIndex,0x00,2);
	JParamInfo3761->group2.f10[j].PointIndex[0]=(j+1)&0xff;
	JParamInfo3761->group2.f10[j].PointIndex[1]=((j+1)>>8)&0xff;
}
void UpdateZBMeterInfo() //ZBtiaoshi
{
	int i=0,j=0,k=0,num=0;//,min=0;
	INT8U find_flag=0, chongfu_flag=0;
	INT16U index[PointMax];
	memset(MeterInf,0xff,PointMax*6);
	memset(index,0,PointMax*sizeof(INT16U));
	for (i = 0; i < PointMax; i++)
	{
		ClearWaitTimes(ProjectNo,JProgramInfo);
		if(((JParamInfo3761->group2.f10[i].port==CarrWavePort)|| (JParamInfo3761->group2.f10[i].port==LocalCommPort)) &&
				JParamInfo3761->group2.f10[i].Status==1)
		{
			chongfu_flag = 0;
			for(j=i+1; j<PointMax; j++)//����ַ�ظ��Ĳ�������˵�
			{
				if(((JParamInfo3761->group2.f10[j].port==CarrWavePort)||(JParamInfo3761->group2.f10[j].port==LocalCommPort)) &&
						JParamInfo3761->group2.f10[j].Status==1)
				{
					if(JParamInfo3761->group2.f10[i].Address[5]==JParamInfo3761->group2.f10[j].Address[5] &&
						JParamInfo3761->group2.f10[i].Address[4]==JParamInfo3761->group2.f10[j].Address[4] &&
						JParamInfo3761->group2.f10[i].Address[3]==JParamInfo3761->group2.f10[j].Address[3] &&
						JParamInfo3761->group2.f10[i].Address[2]==JParamInfo3761->group2.f10[j].Address[2] &&
						JParamInfo3761->group2.f10[i].Address[1]==JParamInfo3761->group2.f10[j].Address[1] &&
						JParamInfo3761->group2.f10[i].Address[0]==JParamInfo3761->group2.f10[j].Address[0] )
					{
						SdPrint("\n �ظ��ı��ţ� pt[%d].f10.Address  %02x%02x%02x%02x%02x%02x====�ظ��Ĳ�����ţ�%d",
								i,
								JParamInfo3761->group2.f10[i].Address[5],
								JParamInfo3761->group2.f10[i].Address[4],
								JParamInfo3761->group2.f10[i].Address[3],
								JParamInfo3761->group2.f10[i].Address[2],
								JParamInfo3761->group2.f10[i].Address[1],
								JParamInfo3761->group2.f10[i].Address[0],
								j);
						InitPtInfo(j);
						chongfu_flag = 1;
						break;
					}
				}
			}
			if(chongfu_flag==1)
				continue;
			memcpy(&MeterInf[k][0],&JParamInfo3761->group2.f10[i].Address[0],6);
			index[k]=i;  //MeterInf������±�k��Jmemory->Points.pt[i]������±�Ķ�Ӧ��ϵ
			//SdPrint("index[%d]==%d\n",k,index[k]);
//			printf("\n MeterInf[%d] %02x%02x%02x%02x%02x%02x  <--->  pt[%d].f10.Address  %02x%02x%02x%02x%02x%02x",
//					k,MeterInf[k][5],MeterInf[k][4],MeterInf[k][3],MeterInf[k][2],MeterInf[k][1],MeterInf[k][0],
//					i,
//					JParamInfo3761->group2.f10[i].Address[5],
//					JParamInfo3761->group2.f10[i].Address[4],
//					JParamInfo3761->group2.f10[i].Address[3],
//					JParamInfo3761->group2.f10[i].Address[2],
//					JParamInfo3761->group2.f10[i].Address[1],
//					JParamInfo3761->group2.f10[i].Address[0]);
			k++;
		}
	}
	num=k;
	//cuowu
	SdPrint("\n-------------------------------------------\n");
	for(k=0; k<num;k++)
		SdPrint("\n  MeterInf[%d] %02x%02x%02x%02x%02x%02x", k,
				MeterInf[k][5],MeterInf[k][4],MeterInf[k][3],
				MeterInf[k][2],MeterInf[k][1],MeterInf[k][0]);
	SdPrint("\n-------------------------------------------\n");
	for(k=0; k<SlavePoint_TotalNum;k++)
		SdPrint("\n ZBMeterInf[%d] %02x%02x%02x%02x%02x%02x",
			k,
			ZBMeterInf[k][5],ZBMeterInf[k][4],ZBMeterInf[k][3],
			ZBMeterInf[k][2],ZBMeterInf[k][1],ZBMeterInf[k][0]);

	for(k=0; k<SlavePoint_TotalNum; k++) //����ZB�еĲ����� �Ӽ�����������Ӧ�Ĳ����� �ҵ��Ļ��ͽ�����һ����û�ҵĻ���ɾ����
	{
		CHECKPOINT(ZBMeterInf,k);
		find_flag = 0;
		for(i=0; i<PointMax; i++)
		{
			CHECKPTVALUED(i);
			//if(memcmp(&MeterInf[i][0],&ZBMeterInf[k][0], 6)==0) //
			if((JParamInfo3761->group2.f10[i].Address[5]== ZBMeterInf[k][5]) && (JParamInfo3761->group2.f10[i].Address[4]==ZBMeterInf[k][4]) &&
					(JParamInfo3761->group2.f10[i].Address[3]==ZBMeterInf[k][3])&&(JParamInfo3761->group2.f10[i].Address[2]==ZBMeterInf[k][2]) &&
					(JParamInfo3761->group2.f10[i].Address[1]==ZBMeterInf[k][1]) && (JParamInfo3761->group2.f10[i].Address[0]==ZBMeterInf[k][0]))
			{
				find_flag = 1;
				break;
			}
		}
		if(find_flag==0)//û�ҵ��Ļ��ʹ�ZB��ɾ����
		{
			SdPrint("\n ɾ�� ZBMeterInf[%d] %02x%02x%02x%02x%02x%02x",
					k,
					ZBMeterInf[k][5],ZBMeterInf[k][4],ZBMeterInf[k][3],
					ZBMeterInf[k][2],ZBMeterInf[k][1],ZBMeterInf[k][0]);
			RemovePoint(&ZBMeterInf[k][0]);
			memset(&ZBMeterInf[k][0], 0, 6);
		}
	}
	SdPrint("\n num =====%d SlavePoint_TotalNum==%d\n",num,SlavePoint_TotalNum);
	for(i=0; i<PointMax; i++) //���ݼ������еĲ����� ��ZB������Ӧ�Ĳ����� �ҵ��Ļ��ͽ�����һ����û�ҵĻ�������һ��
	{
		CHECKPTVALUED(i);
		find_flag = 0;
		for(k=0; k<SlavePoint_TotalNum; k++)
		{
			CHECKPOINT(ZBMeterInf,k);
			//if(memcmp(&MeterInf[i][0],&ZBMeterInf[k][0], 6)==0) //
			if((JParamInfo3761->group2.f10[i].Address[5]== ZBMeterInf[k][5]) &&
				(JParamInfo3761->group2.f10[i].Address[4]==ZBMeterInf[k][4]) &&
				(JParamInfo3761->group2.f10[i].Address[3]==ZBMeterInf[k][3]) &&
				(JParamInfo3761->group2.f10[i].Address[2]==ZBMeterInf[k][2]) &&
				(JParamInfo3761->group2.f10[i].Address[1]==ZBMeterInf[k][1]) &&
				(JParamInfo3761->group2.f10[i].Address[0]==ZBMeterInf[k][0]))
			{
				find_flag = 1;
				break;
			}
		}
		if(find_flag==0)//û�ҵ��Ļ���ZB������һ��
		{
			SdPrint("\n ����  MeterInf[%d].f10.Address  %02x%02x%02x%02x%02x%02x",
					i,
					JParamInfo3761->group2.f10[i].Address[5],
					JParamInfo3761->group2.f10[i].Address[4],
					JParamInfo3761->group2.f10[i].Address[3],
					JParamInfo3761->group2.f10[i].Address[2],
					JParamInfo3761->group2.f10[i].Address[1],
					JParamInfo3761->group2.f10[i].Address[0]);

			if(AddPoint(i)==0)
			{
				if(AddPoint(i)==0)
				{
					InitZBPointInfo();
					memset(OldPoints, 0xff, PointMax*sizeof(CLD));
					return;
				}
			}
		}
	}
}

void RepMeter_auto(INT8U autoregtime)
{
	int i=0, j=0, len, k=0;
	INT8U Rec645Buff[512];
	memset(Rec645Buff, 0, 512);

	EnReg_auto(autoregtime);
	while(1)
	{
		ClearWaitTimes(ProjectNo,JProgramInfo);
		i++;
		if(autoregtime!=0)
		{
			if(i>60*autoregtime)
				break;
		}
		len=ReceiveFromCarr(Rec645Buff);
		if(len>0)
		{
			SdPrint("\n �������ͱ��ţ�  Receive len=%d:\n",len);
			for(j=0;j<len;j++)
				SdPrint("%02x ",Rec645Buff[j]);	//����
			RTMeterProcess_auto(Rec645Buff, len);
			memset(Rec645Buff, 0, 512);
			k = 0;
		}
		k++;
		if(k%60==0)
		{
			k = 0;
			ZBStatus_read();
			if(rtStatus.isSanXiangIdle==1)
			{
				mydelay(60*autoregtime,ProjectNo,JProgramInfo);
				break;
			}
		}
		delay(1000);
	}
}

void mydelay_atuotime(int seccount,INT8U ProjectNo,ProgramInfo* JProgramInfo)
{
	int i=0;
	for(i=0;i<seccount;i++)
	{
		ClearWaitTimes(ProjectNo,JProgramInfo);
		delay(1000);
		if(JProgramInfo->BeginSouBiao==1)
			return;
	}
}
void SearchMeterMain_autotime(int autoregtime, int time1)
{
	int i=0, j=0, len, k=0;
	TS ts;
	INT8U Rec645Buff[512];
	memset(Rec645Buff, 0, 512);
	pause_read();
	BeginSearchMeter_auto(autoregtime);
	mydelay_atuotime(autoregtime*60,ProjectNo,JProgramInfo);
	ClearWaitTimes(ProjectNo,JProgramInfo);
	EnReg_auto(time1);
	while(1)
	{
		if(JProgramInfo->BeginSouBiao==1)
			return;
		TSGet(&ts);
		if(ts.Hour==23 && ts.Minute==25)
			break;
		ClearWaitTimes(ProjectNo,JProgramInfo);
		i++;
//		if(i>60*time1)
//			break;
		len=ReceiveFromCarr(Rec645Buff);
		if(len>0)
		{
			SdPrint("\n �������ͱ��ţ�  Receive len=%d:\n",len);
			for(j=0;j<len;j++)
				SdPrint("%02x ",Rec645Buff[j]);	//����
			RTMeterProcess_auto(Rec645Buff, len);
			memset(Rec645Buff, 0, 512);
			k = 0;
		}
		k++;
		if(k%60==0)
		{
			k = 0;
			ZBStatus_read();
			if(rtStatus.isSanXiangIdle==1)
				break;
		}
		delay(1000);
	}
}
//autoregtime �Զ�ע��ʱ�� ��λ����
void SearchMeterMain_auto(int autoregtime, int time1, int time2, int time3)
{
	int i=0, count=0;
	CldIndex= 0;//���ڴ洢�ѱ�����������
	pause_read();
	BeginSearchMeter_auto(autoregtime);
	//delay(autoregtime*60*1000);
	mydelay(autoregtime*60,ProjectNo,JProgramInfo);
	count =3;
	if(time2==0)
		count = 1;
	for(i=0; i<count; i++)
	{
		if(JProgramInfo->BeginSouBiao == 0)
			return;
		if(i==0)
		{
			ClearWaitTimes(ProjectNo,JProgramInfo);
			RepMeter_auto(time1);
		}
		else if(i==1)
		{
			ClearWaitTimes(ProjectNo,JProgramInfo);
			RepMeter_auto(time2);
		}
		else if(i==2)
		{
			ClearWaitTimes(ProjectNo,JProgramInfo);
			RepMeter_auto(time3);
		}
	}
}

void update485info()
{
	int i=0;
	//������Ϣ for 376.1
	memset(&JDataFileInfo->data485[CarrWavePort-PortBegNum], 0, sizeof(Data485));
	for(i=0;i<PointMax;i++)
	{
		ClearWaitTimes(ProjectNo,JProgramInfo);
		if(JParamInfo3761->group2.f10[i].Status!=1){continue;}
		if ((JParamInfo3761->group2.f10[i].ConnectType!=1) &&
				(JParamInfo3761->group2.f10[i].ConnectType!=30)&&
				(JParamInfo3761->group2.f10[i].ConnectType!=21))
			continue;
		if (JParamInfo3761->group2.f10[i].port!=(5+PortBegNum))
			continue;
		JDataFileInfo->data485[CarrWavePort-PortBegNum].MeterNum++;
	}
	//������Ϣ
	memset(&JDataFileInfo->data485[29+PortBegNum], 0, sizeof(Data485));
	for(i=0;i<PointMax;i++)
	{
		ClearWaitTimes(ProjectNo,JProgramInfo);
		if(JParamInfo3761->group2.f10[i].Status!=1){continue;}
		if ((JParamInfo3761->group2.f10[i].ConnectType!=1) &&
				(JParamInfo3761->group2.f10[i].ConnectType!=30)&&
				(JParamInfo3761->group2.f10[i].ConnectType!=21))
			continue;
		if (JParamInfo3761->group2.f10[i].port!=(30+PortBegNum))
			continue;
		JDataFileInfo->data485[29+PortBegNum].MeterNum++;
	}
}
void MyAddZbPts()
{
	int k=0,i=0, j=0, metertotalnum=0;
	INT8U chongfu_flag=0;
	memset(MeterInf,0xff,PointMax*6);
	memset(gui_yue,0xff,sizeof(gui_yue));
	for (i = 0; i < PointMax; i++)
	{
		ClearWaitTimes(ProjectNo,JProgramInfo);
		if(((JParamInfo3761->group2.f10[i].port==CarrWavePort)||(JParamInfo3761->group2.f10[i].port==LocalCommPort)) &&
				JParamInfo3761->group2.f10[i].Status==1)
		{
			chongfu_flag = 0;
			for(j=i+1; j<PointMax; j++)//����ַ�ظ��Ĳ�������˵�
			{
				if(((JParamInfo3761->group2.f10[j].port==CarrWavePort)||(JParamInfo3761->group2.f10[j].port==LocalCommPort)) &&
						JParamInfo3761->group2.f10[j].Status==1)
				{
					if(JParamInfo3761->group2.f10[i].Address[5]==JParamInfo3761->group2.f10[j].Address[5] &&
						JParamInfo3761->group2.f10[i].Address[4]==JParamInfo3761->group2.f10[j].Address[4] &&
						JParamInfo3761->group2.f10[i].Address[3]==JParamInfo3761->group2.f10[j].Address[3] &&
						JParamInfo3761->group2.f10[i].Address[2]==JParamInfo3761->group2.f10[j].Address[2] &&
						JParamInfo3761->group2.f10[i].Address[1]==JParamInfo3761->group2.f10[j].Address[1] &&
						JParamInfo3761->group2.f10[i].Address[0]==JParamInfo3761->group2.f10[j].Address[0] )
					{
//						SdPrint("\n �ظ��ı��ţ� pt[%d].f10.Address  %02x%02x%02x%02x%02x%02x ===������ţ�%d",
//								i,
//								JParamInfo3761->group2.f10[i].Address[5],
//								JParamInfo3761->group2.f10[i].Address[4],
//								JParamInfo3761->group2.f10[i].Address[3],
//								JParamInfo3761->group2.f10[i].Address[2],
//								JParamInfo3761->group2.f10[i].Address[1],
//								JParamInfo3761->group2.f10[i].Address[0],
//								j);
						chongfu_flag = 1;
						break;
					}
				}
			}
			if(chongfu_flag==1)
				continue;
			memcpy(&MeterInf[k][0],&JParamInfo3761->group2.f10[i].Address[0],6);
			gui_yue[k]=JParamInfo3761->group2.f10[i].ConnectType;
			k++;
			metertotalnum = k;
		}
	}
	printf("\nmetertotalnum ===%d\n",metertotalnum);
	AddZBPoints(metertotalnum); //���ز�ģ���ڼ��������
}

/****************************************************************************/
void *SevPro(void* param)
{
	int len=0;
//	INT8U TmpBuf[256];
	memset(RecvBuf,0,RECVLEN);
	RecvHead = 0;
	RecvTail = 0;
	printf("\n-----------------SevProSevProSevPro---------------------\n");
	while(param_run)
	{
		delay(500);
	//	len = read(ComPort,TmpBuf,255);//200

//		if(len>0)
//			printf("\n SevPro recv len=%d:  ",len);
//		for(i=0;i<len;i++)
//		{
//			//printf("[%02x] ",TmpBuf[i]);
////			if((RecvTail-RecvHead+1)%RECVLEN==0)
////				continue;
//			RecvBuf[RecvHead]=TmpBuf[i];
//			RecvHead = (RecvHead+1)%RECVLEN;
//
//		}
		if (len>0)
		{
			if(CurComCarr.ComPortNo==1)
				JProgramInfo->Para.State485_1=2; //��ʾ����
			if(CurComCarr.ComPortNo==2)
				JProgramInfo->Para.State485_2=2; //��ʾ����
			if(CurComCarr.ComPortNo==3)
				JProgramInfo->Para.State485_3=2; //��ʾ����
		}
	}
	exit(EXIT_SUCCESS);
}
//������
int main(int argc, char *argv[])
{
	int i,num;
	INT8U addr[6];
	INT8U TempBuf[60];
	int zbbaud=9600;
	FILE *fpzb = NULL;
	char ReadString[50];
	int numstr;
	int MeterNum=0;
	INT8U initzbinfo=0;

	if (getenv("jReadZBPrt")==NULL)
	{
		jReadZBPrint = 0;
		if (getenv("jAllProgPrt")!=NULL)
			jReadZBPrint = atoi(getenv("jAllProgPrt"));
	}
	else jReadZBPrint = atoi(getenv("jReadZBPrt"));
	markver();
	struct sigaction sa1;//�ź�

    JParamInfo3761 = NULL;
    JDataFileInfo = NULL;
    JConfigInfo = NULL;
    JProgramInfo = NULL;

    JParamInfo3761 = Create1ShMem("ParamInfo3761",sizeof(ParamInfo3761),NULL);
    JDataFileInfo = Create1ShMem("DataFileInfo",sizeof(DataFileInfo),NULL);
    JConfigInfo = Create1ShMem("ConfigInfo",sizeof(ConfigInfo),NULL);
    JProgramInfo = Create1ShMem("ProgramInfo",sizeof(ProgramInfo),NULL);

    if (JParamInfo3761 ==NULL || JDataFileInfo == NULL ||JConfigInfo == NULL ||JProgramInfo == NULL)
    {
 		printf("\n\r  jmain chuan jian gong xiang mei buchenggong");
   		return EXIT_FAILURE;//���������ڴ�
    }

	if(JProgramInfo->mainData.MemoryLength!=sizeof(ProgramInfo))
	{
		SdPrint( "jReadZB base mem uncompared prog will exit %d  %d :\n",sizeof(ProgramInfo),JProgramInfo->mainData.MemoryLength);
		return EXIT_FAILURE;
	}
	if(!GetProjects(argc, argv))
	{
		SdPrint("\njReadZB Bad command format. Type 'use exe_name' for help!\n\r");
		return EXIT_FAILURE;
	}
	//JProgramInfo->mainData.Prt_Flag=200;
   if (jReadZBPrint==2)
   {
		INT8U TempBuf[60];
		memset(TempBuf, 0, 60);
		sprintf((char *) TempBuf, "%s/jreadZB_log.txt", _USERDIR_);
	    fp=fopen((char *) TempBuf,"a+");
   }
   JProgramInfo->Projects[ProjectNo].ProjectID=getpid();//����������Ϣ
	printf("Starting jReadZB_DX ..........%d\n\r",ProjectNo);
	DbgPrintToFile("Starting jReadZB_DX ..........%d",ProjectNo);
	ClearWaitTimes(ProjectNo,JProgramInfo);

	//��ʼ������
	sa1.sa_handler = QuitProcess;
	sigemptyset(&sa1.sa_mask);
	sa1.sa_flags = 0;
	sigaction(SIGTERM, &sa1,NULL);
	sigaction(SIGSYS, &sa1,NULL);
	sigaction(SIGPWR, &sa1,NULL);
	sigaction(SIGKILL, &sa1,NULL);
	sigaction(SIGQUIT, &sa1,NULL);
	sigaction(SIGILL, &sa1,NULL);
	sigaction(SIGINT, &sa1,NULL);
	sigaction(SIGHUP, &sa1,NULL);
	sigaction(SIGABRT, &sa1,NULL);
	sigaction(SIGBUS, &sa1,NULL);
	InitMeterFlags();
	delay(1000);
	num=0;
	memset(addr,0,6);
	while(num<15)
	{
		ClearWaitTimes(ProjectNo,JProgramInfo);
		num++;
		delay(1000);
	}
	unsigned char Parity[20];
	sprintf((char*)Parity,"even");
	if (jReadZBPrint == 0)
	{
	   if ((JProgramInfo->mainData.Prt_Flag==16) || (JProgramInfo->mainData.Prt_Flag==50))
		   jReadZBPrint = 3;
	}
	else
	{
	   if ((JProgramInfo->mainData.Prt_Flag==116) || (JProgramInfo->mainData.Prt_Flag==150))
		   jReadZBPrint = 0;
	}

	zbbaud=9600;
	memset(TempBuf, 0, 60);
	sprintf((char *) TempBuf, "%s/localbaud.txt", _USERDIR_);
	if (access((char *)TempBuf,0)==0)
	{
		struct timespec tsspec;
		if (clock_gettime(CLOCK_REALTIME, &tsspec)==-1)
			printf("clock_gettime error\n\r");
		tsspec.tv_sec += 3;
		sem_timedwait(&JProgramInfo->mainData.UseFileFlg,&tsspec);
		fpzb = fopen((char *)TempBuf,"r");
		memset(ReadString,0,50);
		numstr  = fscanf(fpzb, "%s", ReadString);
		if (numstr<=0)
		{
			zbbaud=0;
		}
		else{
			sscanf(ReadString,"%d",&zbbaud);
		}
		printf("zbbaud=%d\n\r",zbbaud);
		fclose(fpzb);
		fpzb=NULL;
		sem_post(&JProgramInfo->mainData.UseFileFlg);
	}
	delay(500);
	printf("\n zbbaud=%d Parity=%s  CarrWavePort=%d\n",zbbaud,Parity,CarrWavePort);
	if (OpenComCarrZB(zbbaud,Parity,1,8,CarrWavePort)<1)
	{
		delay(1000);
		printf("OpenComZB ERRO ........................\n");
		return 0;
	}
	 //PA29 RST  PA25 SET
	int fd=-1,on=1;
	if((fd = open("/dev/gpoZAIBO_RST", O_RDWR | O_NDELAY)) > 0) //gpoZAIBO_SET
	{
		write(fd,&on,sizeof(int));
		close(fd);
	}
	delay(500);
	param_run = 1;
	thread_rev_id = 0;
	//thread_rev_id = pthread_create(&thread_sev,NULL, SevPro,NULL);	    /*�������ݽ����߳�*/
	delay(1000);
	//��ͣ����
	pause_read();
	SetupZBAdress();
	delay(500);
	GetCarrierWaveAddress(0);
	delay(500);
	CheckZBversion();

	//yangdonggai---->>>
	for(i=0;i<PointMax;i++)
	{
		if((JParamInfo3761->group2.f10[i].port==CarrWavePort)||(JParamInfo3761->group2.f10[i].port==LocalCommPort))
		{
			if ((JParamInfo3761->group2.f10[i].Address[0]==0xff) && (JParamInfo3761->group2.f10[i].Address[1]==0xff) &&
				(JParamInfo3761->group2.f10[i].Address[2]==0xff) &&	(JParamInfo3761->group2.f10[i].Address[3]==0xff) &&
				(JParamInfo3761->group2.f10[i].Address[4]==0xff) && (JParamInfo3761->group2.f10[i].Address[5]==0xff))
				continue;
			if ((JParamInfo3761->group2.f10[i].Address[0]==0x00) && (JParamInfo3761->group2.f10[i].Address[1]==0x00) &&
				(JParamInfo3761->group2.f10[i].Address[2]==0x00) &&	(JParamInfo3761->group2.f10[i].Address[3]==0x00) &&
				(JParamInfo3761->group2.f10[i].Address[4]==0x00) && (JParamInfo3761->group2.f10[i].Address[5]==0x00))
				continue;
			if(JParamInfo3761->group2.f10[i].Status!=1){continue;}
			if ((JParamInfo3761->group2.f10[i].ConnectType!=1) &&
				(JParamInfo3761->group2.f10[i].ConnectType!=30)&&
				(JParamInfo3761->group2.f10[i].ConnectType!=21))
				continue;
			MeterNum++;
		}
		ClearWaitTimes(ProjectNo,JProgramInfo);
	}
	printf("\n MeterNum = %d \n",MeterNum);
	if(GetZBSlavePointNum()==-1)//cuowu
	{
		GetZBSlavePointNum();
		GetZBSlavePointNum();
	}
	if(SlavePoint_TotalNum!=MeterNum)
	{
		InitZBPointInfo();
		MyAddZbPts();
		initzbinfo = 1;
	}

	if((JParamInfo3761->group11.f111.Enable&0x01)==MANUAL)
	{
		Flag_MeterChange=0;
		memset(OldPoints, 0xff, PointMax*sizeof(CLD));

		ClearWaitTimes(ProjectNo,JProgramInfo);
		for(i=0;i<PointMax;i++)
		{
			if((JParamInfo3761->group2.f10[i].port==CarrWavePort)||(JParamInfo3761->group2.f10[i].port==LocalCommPort))
			{
				if ((JParamInfo3761->group2.f10[i].Address[0]==0xff) && (JParamInfo3761->group2.f10[i].Address[1]==0xff) &&
					(JParamInfo3761->group2.f10[i].Address[2]==0xff) &&	(JParamInfo3761->group2.f10[i].Address[3]==0xff) &&
					(JParamInfo3761->group2.f10[i].Address[4]==0xff) && (JParamInfo3761->group2.f10[i].Address[5]==0xff))
					continue;
				if ((JParamInfo3761->group2.f10[i].Address[0]==0x00) && (JParamInfo3761->group2.f10[i].Address[1]==0x00) &&
					(JParamInfo3761->group2.f10[i].Address[2]==0x00) &&	(JParamInfo3761->group2.f10[i].Address[3]==0x00) &&
					(JParamInfo3761->group2.f10[i].Address[4]==0x00) && (JParamInfo3761->group2.f10[i].Address[5]==0x00))
					continue;
				memcpy(&OldPoints[i].Address[0], &JParamInfo3761->group2.f10[i].Address[0],6);
				memcpy(&OldPoints[i].CaijiqiAddress[0], &JParamInfo3761->group2.f10[i].CaijiqiAddress[0],6);
				OldPoints[i].ConnectType = JParamInfo3761->group2.f10[i].ConnectType;
				OldPoints[i].Status = JParamInfo3761->group2.f10[i].Status;
				OldPoints[i].baudrate = JParamInfo3761->group2.f10[i].baudrate;
				OldPoints[i].port = JParamInfo3761->group2.f10[i].port;
			}
			ClearWaitTimes(ProjectNo,JProgramInfo);
		}

		GetPtsfromZB();//��ZBģ���л�ò�������Ϣ
		UpdateZBMeterInfo();
		GetPtsfromZB();////��ZBģ���л�ò�������Ϣ
		//GetZBSlavePoint(1,1);//���ZBģ��ӽڵ�����
		if(GetZBSlavePointNum()==-1)//cuowu
		{
			GetZBSlavePointNum();
			GetZBSlavePointNum();
		}
		for(i=10;i<51;i++)
		{
			ClearWaitTimes(ProjectNo,JProgramInfo);
			delay(1000);
			if(GetCarrierWaveAddress(0)==1)
				break;
		}
		initLe1flgComm();

		isCLDChanged = 0;
		SouBiaoWanbi = 0;
	}
//������
//	else// if(Jmemory->jzq.f111.Enable==MANUAL) ����
//	{
//		InitMeterInfo();
//		//��ʼ�����ѱ�
//		SearchMeterMain_auto(1, 1, 2, 3);
//	}
	//reboot_read();
	delay(2000);
	JDataFileInfo->data485[29+PortBegNum].ChaobiaoSta = 0;
	JDataFileInfo->data485[CarrWavePort-PortBegNum].ChaobiaoSta = 0;

	while(1)
	{
		SdPrint("jReadZB start circle .................................................\n");
		time_read_dates();//�Զ���ʱ���� //��һ�ֳ�����������ɹ���һ�ξͲ���ɾ��curr.dat
		delay(50);
		//ReadDataTasks();//����������
//		for(i=0;i<100;i++)
//		{
//			GetRealTimeData();//��ȡʵʱ����
//			ClearWaitTimes(ProjectNo,JProgramInfo);
//			delay(100);
//		}
		ClearWaitTimes(ProjectNo,JProgramInfo);
		//delay(1000);
	}
	QuitProcess(0);
 	return EXIT_SUCCESS;
}
name_attach_t  *attach;
//����ע��,��ȡ����źͳ�������
INT8U GetProjects(INT32S argc, char * argv[]) {
	char proc_name[32] = "";

	if (argc < 2)
		return (FALSE);
	ProjectNo = atoi(argv[1]);
#ifdef __linux__
	sprintf(proc_name, "%s", argv[0]);
#else
	sprintf(proc_name, "%s %d", argv[0], ProjectNo);
#endif
//   if((attach=name_attach(NULL, proc_name,0))  == NULL)
//   {
//	   printf( "ERR:'%s' runed,cann't regist\n\r", proc_name);
//	   return (FALSE);
//   }
	return (TRUE);
}
//�˳�����
void QuitProcess(int signo)
{
	delay(100);
	CloseComCarrZB();
	SdPrint("\n\r jReadZB quit xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n\r");
	JProgramInfo->Projects[ProjectNo].ProjectID=0;
//	name_detach(attach, 0);
    if (jReadZBPrint==2)
    {
       //SdPrint("\n\r fp close");
 	   fclose(fp);
 	   fp=NULL;
    }
   // name_detach(attach, 0);
	param_run = 0;

	if (thread_rev_id>=0)
	{
		pthread_exit(&thread_sev);
		fprintf(stderr,"\n  thread_sev quit\n");
	}
	fprintf(stderr,"\n  jNetcom quit \n");
	exit(0);
}
