//Copyright ��Ȩ����  2009�ൺ�߿�ͨ�Źɷ����޹�˾
// �ļ�����ComCarr.c
// �ļ������������Զ���������
// ������ʶ��20090901 Ray
//
// �޸ı�ʶ��
// �޸�������
//
// �޸ı�ʶ��
// �޸�������
#ifndef ComCarrC
#define ComCarrC
#include <stdio.h>
#include <string.h>
#include <termios.h>
#include <fcntl.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <ctype.h>
#include <time.h>
#include <signal.h>
#include <semaphore.h>
#include <errno.h>
#include <fcntl.h>
#include <termios.h>
#include <inc/CVariable.h>
#include "jReadZB.h"
#include "inc/pubfunction.h"

void CloseComCarrZB();//�رմ���

int OpenComCarrZB(int baud, unsigned char *par, unsigned char stopb, INT8U bits, INT8U port)
{
	struct termios old_termi,new_termi;
	int baud_lnx=0;
	unsigned char tmp[128];
	memset(tmp,0,128);
    if(ComPort>0)
    	close(ComPort);
    sprintf((char *)tmp,"/dev/ttyS%d",port);
    ComPort = open((char *)tmp, O_RDWR|O_NOCTTY);/* �򿪴����ļ� */
    SdPrint("\n opencomcarr port %d ComPort %d ", port, ComPort);
    if( ComPort<0 )
    {
    	printf("open the serial port fail! errno is: %d\n", errno);
    	return 0; /*�򿪴���ʧ��*/
    }
    if ( tcgetattr( ComPort, &old_termi) != 0) /*�洢ԭ��������*/
    {
    	printf("get the terminal parameter error when set baudrate! errno is: %d\n", errno);
    	/*��ȡ�ն���ز���ʱ����*/
    	return 0;
    }
    //printf("\n\r c_ispeed == %d old_termi  c_ospeed == %d",old_termi.c_ispeed, old_termi.c_ospeed);
    bzero(&new_termi,sizeof(new_termi));    				/*���ṹ������*/
    new_termi.c_cflag|= (CLOCAL|CREAD); 					/*���Ե��ƽ����״̬�У�����ʹ��*/
    new_termi.c_lflag&=~(ICANON|ECHO|ECHOE);				/*ѡ��Ϊԭʼ����ģʽ*/
    new_termi.c_oflag&=~OPOST; 								/*ѡ��Ϊԭʼ���ģʽ*/
    new_termi.c_cc[VTIME] = 5; 								/*���ó�ʱʱ��Ϊ0.5 s*/
    new_termi.c_cc[VMIN] = 0;								/*���ٷ��ص��ֽ����� 7*/
    new_termi.c_cflag &= ~CSIZE;
    //new_termi.c_iflag &= ~INPCK;     /* Enable parity checking */
    new_termi.c_iflag &=~ ISTRIP;
    switch(baud)
    {
    	case 1200:
    		baud_lnx = B1200;
    		break;
    	case 2400:
    		baud_lnx = B2400;
    		break;
    	case 4800:
    		baud_lnx = B4800;
    		break;
    	case 9600:
    		baud_lnx = B9600;
    		break;
    	case 19200:
    		baud_lnx = B19200;
    		break;
    	case 38400:
    		baud_lnx = B38400;
    		break;
    	case 115200:
    		baud_lnx = B115200;
    		break;
    	default:
    		baud_lnx = B9600;
    		printf("\nSerial COM%d do not setup baud, default baud is 9600!!!", port);
    		break;
    }

    switch( bits )
	{
		case 5:
			new_termi.c_cflag |= CS5;
			break;
		case 6:
			new_termi.c_cflag |= CS6;
			break;
		case 7:
			new_termi.c_cflag |= CS7;
			break;
		case 8:
			new_termi.c_cflag |= CS8;
			break;
		default:
			new_termi.c_cflag |= CS8;
			break;
	}

    if(strncmp((char *)par,"even",4)==0)//������żУ��ΪżУ��
    {
		//new_termi.c_iflag |= (INPCK | ISTRIP);
    	new_termi.c_cflag |= PARENB;
    	new_termi.c_cflag &= ~PARODD;

    }
    else if(strncmp((char *)par,"odd",3)==0)  //������żУ��Ϊ��У��
	{
		new_termi.c_cflag |= PARENB;
		new_termi.c_cflag |= PARODD;
		//new_termi.c_iflag |= (INPCK | ISTRIP);
	}else
	{
    	new_termi.c_cflag &= ~PARENB; 	//������żУ��Ϊ��У��
    	//new_termi.c_iflag &=~ ISTRIP;
    }


	if(stopb==1)//ֹͣλ
	{
		new_termi.c_cflag&= ~CSTOPB; //����ֹͣλΪ:һλֹͣλ
	}
	else if(stopb==2)
	{
		new_termi.c_cflag |= CSTOPB; //����ֹͣλΪ:��λֹͣλ
	}
	else
	{
		new_termi.c_cflag&= ~CSTOPB; //����ֹͣλΪ:һλֹͣλ
	}

	cfsetispeed(&new_termi, baud_lnx); 							/* �������벦���� */
    cfsetospeed(&new_termi, baud_lnx); 							/* ������������� */

    tcflush(ComPort, TCIOFLUSH); 								/* ˢ����������� */
    if(tcsetattr(ComPort,TCSANOW,&new_termi)!= 0)				/* ��������� */
    {
    	printf("Set serial port parameter error!\n");
    	return 0;
    }
    return ComPort;
}


//�رմ���
void CloseComCarrZB()
{
	if(ComPort>0)
	{
		CurComCarr.State=0;
		close( ComPort );
	}
	return;
}


//���Ӵ򿪺����ַ���
void SendStrToCarr(unsigned char *str,unsigned short Len)
{
	if(CurComCarr.ComPortNo==1)
	JProgramInfo->Para.State485_1=1; //��ʾ����
	if(CurComCarr.ComPortNo==2)
	JProgramInfo->Para.State485_2=1; //��ʾ����
	if(CurComCarr.ComPortNo==3)
	JProgramInfo->Para.State485_3=1; //��ʾ����
	ClearWaitTimes(ProjectNo,JProgramInfo);
	write(ComPort,str,Len);
	DbPrt("ZB����:", (char *)str, Len, NULL);
}
//�����ַ���
unsigned char ReceiveFromCarr(unsigned char *str)
{
	int rec_head,rec_tail,rec_step,DataLen;
	time_t oldtime=0;
	time_t newtime=0;
	INT16U tmptail=0;
	INT8U TmpBuf[256];
	int i,j,len=0;
	memset(TmpBuf,0,256);
	rec_head=rec_tail= rec_step = DataLen =0;
	RecvHead = RecvTail = 0;
	delay(300);
	for(j=0;j<20;j++)									//9��14��
	{
		memset(TmpBuf,0,256);
		len = read(ComPort,TmpBuf,255);//200
		if(len<=0)
			delay(50);
//		if(j==0 && len==0)
//			return 0;
//		if(len>0)
//			fprintf(stderr,"\n SevPro recv[%d] len=%d:  ",j,len);
		for(i=0;i<len;i++)
		{
//			fprintf(stderr,"%02x ",TmpBuf[i]);
	//			if((RecvTail-RecvHead+1)%RECVLEN==0)
	//				continue;
			RecvBuf[RecvHead]=TmpBuf[i];
			RecvHead = (RecvHead+1)%RECVLEN;

		}

		//fprintf(stderr,"step=%d head=%d tail=%d len=%d\n",rec_step,RecvHead,RecvTail,DataLen);
		switch (rec_step)
		{
		case 0:
			while (RecvTail != RecvHead)
			{
				if(RecvBuf[RecvTail] == 0x68)
				{
					rec_step = 1;
					break;
				}else {
					RecvTail = (RecvTail+1)%RECVLEN;
				}
			}
			break;
		case 1:
			if(((RecvHead - RecvTail+RECVLEN)%RECVLEN)>=3)
			{
				tmptail=RecvTail;
				tmptail = (tmptail+1)%RECVLEN;
				DataLen = RecvBuf[tmptail];
				tmptail = (tmptail+1)%RECVLEN;
				DataLen |= (RecvBuf[tmptail]<<8);
				if (DataLen !=0)
				{
					rec_step = 2;
					oldtime = time(NULL);
				}else
				{
					RecvTail = (RecvTail+1)%RECVLEN;
					rec_step = 0;
				}
				break;
			}
			break;
		case 2:
			if(((RecvHead - RecvTail+RECVLEN)%RECVLEN)>=DataLen)
			{
				if (RecvBuf[(RecvTail+DataLen-1)%RECVLEN] == 0x16)
				{
					//fprintf(stderr,"\nReceiveFromCarr OK: len = %d\n",DataLen);
					for(i=0; i<DataLen; i++)
					{
						str[i] = RecvBuf[RecvTail];
						RecvTail = (RecvTail+1)%RECVLEN;
					//	fprintf(stderr,"%02x ", str[i]);
					}
					rec_step = 0;
					return DataLen;
				}else {
					RecvTail = (RecvTail+1)%RECVLEN;
					rec_step = 0;
				}
			}else
			{
				newtime = time(NULL);
				if ((newtime-oldtime)> 2)
				{
					RecvTail = (RecvTail+1)%RECVLEN;
					rec_step = 0;
				}
			}
			break;
		default:
			break;
		}
	}
	return (0);

	//---------------------------------------
//	static int DataLen=0;
//	static int rec_step=0;
//	static time_t oldtime;
//	time_t newtime;
//	int i;
//	//fprintf(stderr,"step=%d head=%d tail=%d len=%d\n",rec_step,RecvHead,RecvTail,DataLen);
//	switch (rec_step)
//	{
//	case 0:
//		while (RecvTail != RecvHead)
//		{
//			if(RecvBuf[RecvTail] == 0x68)
//			{
//				rec_step = 1;
//				break;
//			}else {
//				RecvTail = (RecvTail+1)%RECVLEN;
//			}
//		}
//		break;
//	case 1:
//		if(((RecvHead - RecvTail+RECVLEN)%RECVLEN)>=3)
//		{
//			INT16U tmptail=RecvTail;
//			tmptail = (tmptail+1)%RECVLEN;
//			DataLen = RecvBuf[tmptail];
//			tmptail = (tmptail+1)%RECVLEN;
//			DataLen |= (RecvBuf[tmptail]<<8);
//			if (DataLen !=0)
//			{
//				rec_step = 2;
//				oldtime = time(NULL);
//			}else
//			{
//				RecvTail = (RecvTail+1)%RECVLEN;
//				rec_step = 0;
//			}
//			break;
//		}
//		break;
//	case 2:
//		if(((RecvHead - RecvTail+RECVLEN)%RECVLEN)>=DataLen)
//		{
//			if (RecvBuf[(RecvTail+DataLen-1)%RECVLEN] == 0x16)
//			{
//				fprintf(stderr,"\nReceiveFromCarr OK: len = %d\n",DataLen);
//				for(i=0; i<DataLen; i++)
//				{
//					str[i] = RecvBuf[RecvTail];
//					RecvTail = (RecvTail+1)%RECVLEN;
//					fprintf(stderr,"%02x ", str[i]);
//				}
//				rec_step = 0;
//				return DataLen;
//			}else {
//				RecvTail = (RecvTail+1)%RECVLEN;
//				rec_step = 0;
//			}
//		}else
//		{
//			newtime = time(NULL);
//			if ((newtime-oldtime)> 2)
//			{
//				RecvTail = (RecvTail+1)%RECVLEN;
//				rec_step = 0;
//			}
//		}
//		break;
//	default:
//		break;
//	}
//	return (0);
}

INT8U TransWirelessCarrierWave(INT16U PtNo,INT8U *Trn645Buff,INT8U Lens)
{
//����
	unsigned char  	SendBuff[1024];     /* 645��Լ���ͱ��Ļ�����     */
	unsigned char	Check=0; //����Ҳ��Ҫ��
	int i=0,len=0;//����Ҳ��Ҫ��
	///CleardeadCount();
	//68 2D 00 41 04 00 50 03 00 00 64 18 00 A0 00 00 19 00 00 00 00 00
	//02 01 00 00 10
	//68 19 00 00 00 00 00 68 11 04 33 33 34 33 CB 16 8C 16
	memset(SendBuff,0,1024);
	//��֯���ͱ���
	SendBuff[len++]=0x68;	//����ͷ
	SendBuff[len++]=0x2d;//����
	SendBuff[len++]=0x00;

	SendBuff[len++]=0x41;// ������C

	SendBuff[len++] = 0x04;// ��Ϣ��
	SendBuff[len++] = 0x00;//���������ʶ	�ŵ���ʶ
	SendBuff[len++] = 0x28;//Ԥ��Ӧ���ֽ���
	SendBuff[len++] = 0x58;//(bauds&0xff);//���ʵ�λ��ʶ	ͨ������//???????
	SendBuff[len++] = 0x02;//(((bauds>>8)&0xff)|bflg);//���ʵ�λ��ʶ	ͨ������
	SendBuff[len++] = 0x00;//Ԥ��
	fprintf(stderr, "\n���ڴ��л�ȡ�������ز�ģ��ĵ�ַ: ");
	for (i = 0; i < 6; i++)//Դ��ַ(���ڴ��л�ȡ�������ز�ģ��ĵ�ַ)
	{
		SendBuff[len++] = CarrierWaveaddr[5 - i];
		fprintf(stderr, "%02x ",CarrierWaveaddr[5 - i]);
	}
	fprintf(stderr, "\n�ز���Ŀ�ĵ�ַ: ");
	for (i = 0; i < 6; i++)//�ز���Ŀ�ĵ�ַ
	{
		SendBuff[len++] = JParamInfo3761->group2.f10[PtNo].Address[i];
		fprintf(stderr, "%02x ",JParamInfo3761->group2.f10[PtNo].Address[i]);
	}
	SendBuff[len++] = 0x13;//������ ����ת��
	SendBuff[len++] = 0x01;//���ݵ�Ԫ
	SendBuff[len++] = 0x00;//���ݵ�Ԫ
	if(JParamInfo3761->group2.f10[PtNo].ConnectType==30)
		SendBuff[len++]=0x02;//00HΪ͸�����䣻01HΪ DL/T645-1997��02HΪ DL/T645-2007��03H-FFH����
	else if(JParamInfo3761->group2.f10[PtNo].ConnectType==1)
		SendBuff[len++]=0x01;
	else
		SendBuff[len++]=0x00;
	SendBuff[len++] = 0x00;

	SendBuff[len++]=Lens;
	//���ݵ�Ԫ
	fprintf(stderr, "\nҪת����645���ģ�%d \n", Lens);
	for(i=0;i<Lens;i++)
	{
		SendBuff[len++]=Trn645Buff[i];
		printf("%02x ",Trn645Buff[i]);
	}
	for (i = 3; i < len; i++)
		Check += SendBuff[i];
	SendBuff[len++]=(unsigned char)(Check & 0xff);
	SendBuff[len++]=0x16;//������
	SendBuff[1]=len&0xff;//����Ҳ��Ҫ��
	SendBuff[2]=(len>>8)&0xff;//����Ҳ��Ҫ��
	//delay(50);
	memset(JProgramInfo->dataTransgw.f1.ANSWER_Buf,0,256);
	for(i=0;i<len;i++)
	{
		JProgramInfo->dataTransgw.f1.ANSWER_Buf[i]=SendBuff[i];
	}
	fprintf(stderr, "\nת�����ز���376.2����:  len= %d \n", len);
	for(i=0;i<len;i++)
		fprintf(stderr, "%02x ",JProgramInfo->dataTransgw.f1.ANSWER_Buf[i]);
	fprintf(stderr, "\n");
	return len;
}

void DataTrans()
{
	int res,stop,bits,dely,len,i,j;
	//int ANSWER_Buf_head=0;
	unsigned char Parity[12];
	INT8U transRecCarr[1024];
	int Answerlen=0, tmplen=0;
	INT8U idd[6], check=0;
	int seconds=0;
	INT8U dataflag=0;//�յ������ݵı���
	INT8U reckok=0;
	int len1=0;
	int k=0;
	INT8U BaoWenType=0;//ת���� 1 645 ����  2 367.2����
	if (JProgramInfo->dataTransgw.f1.ASK_Stat==1 &&
		(JProgramInfo->dataTransgw.f1.ASK_Port==31 ||JProgramInfo->dataTransgw.f1.ASK_Port==6))
	{
		if ((JProgramInfo->dataTransgw.f1.ASK_Port!=CarrWavePort)&&(JProgramInfo->dataTransgw.f1.ASK_Port!=LocalCommPort))
		{
			return;
		}
		stop=1;
		if(JProgramInfo->dataTransgw.f1.ASK_Control&0x10)
			stop=2;
		sprintf((char*)Parity,"none");
		if(JProgramInfo->dataTransgw.f1.ASK_Control&0x08)
		{
			memset(Parity,0,12);
			if(JProgramInfo->dataTransgw.f1.ASK_Control&0x04)
				sprintf((char*)Parity,"odd");
			else
				sprintf((char*)Parity,"even");
		}
		bits=(JProgramInfo->dataTransgw.f1.ASK_Control&0x03)+5;
//		CloseComCarr();
		res=1;//OpenComCarr(baud,Parity,stop,bits,JProgramInfo->dataTransgw.f1.ASK_Port);//��ʼ���˿�
//		res=OpenComCarr(baud,Parity,stop,bits,JProgramInfo->dataTransgw.f1.ASK_Port);
		fprintf(stderr,"\n res---------=%d \n",res);
		if(res<1)
		{
			JProgramInfo->dataTransgw.f1.len[0]=0;
			JProgramInfo->dataTransgw.f1.len[1]=0;
		}
		else
		{
			CurComCarr.State=1;
			if (JProgramInfo->dataTransgw.f1.WaitTime&0x80)
				dely=(JProgramInfo->dataTransgw.f1.WaitTime&0x7F)*1000;
			else
				dely=(JProgramInfo->dataTransgw.f1.WaitTime&0x7F)*10;
			len=JProgramInfo->dataTransgw.f1.len[0]+(JProgramInfo->dataTransgw.f1.len[1]<<8); //----ת��--  zhuanfa  <<8)+4
			for (i=0;i<len;i++)
				SdPrint("%02x ",JProgramInfo->dataTransgw.f1.ANSWER_Buf[i]);
			SdPrint("\n\r");
			//---ת��----begin 68 31 44 36 00 00 00 68
			//����վ�·��ĳ����������ҵ�����ַ
			INT8U tmepcldAdress[6];
			for(i=0; i<len; i++)
			{
				if(JProgramInfo->dataTransgw.f1.ANSWER_Buf[i]==0x68 && JProgramInfo->dataTransgw.f1.ANSWER_Buf[i+7]==0x68)
				{
					tmepcldAdress[0] = JProgramInfo->dataTransgw.f1.ANSWER_Buf[i+1];
					tmepcldAdress[1] = JProgramInfo->dataTransgw.f1.ANSWER_Buf[i+2];
					tmepcldAdress[2] = JProgramInfo->dataTransgw.f1.ANSWER_Buf[i+3];
					tmepcldAdress[3] = JProgramInfo->dataTransgw.f1.ANSWER_Buf[i+4];
					tmepcldAdress[4] = JProgramInfo->dataTransgw.f1.ANSWER_Buf[i+5];
					tmepcldAdress[5] = JProgramInfo->dataTransgw.f1.ANSWER_Buf[i+6];

					printf("\n��վ�·�����ַ�� %2x %2x %2x %2x %2x %2x\n",JProgramInfo->dataTransgw.f1.ANSWER_Buf[i+1],
							JProgramInfo->dataTransgw.f1.ANSWER_Buf[i+2],
							JProgramInfo->dataTransgw.f1.ANSWER_Buf[i+3],
							JProgramInfo->dataTransgw.f1.ANSWER_Buf[i+4],
							JProgramInfo->dataTransgw.f1.ANSWER_Buf[i+5],
							JProgramInfo->dataTransgw.f1.ANSWER_Buf[i+6]);
					BaoWenType = 1;
				}
			}
			if(BaoWenType == 1)
			{
				//���ݱ���ַ�ҵ��������
				int cldNo=-1;
				for(i=0; i<PointMax; i++){
					if(!memcmp(tmepcldAdress, JParamInfo3761->group2.f10[i].Address, 6))
						cldNo = i;
				}
				printf("\ncldNo == %d\n", cldNo);
				len1 = len = TransWirelessCarrierWave(cldNo, JProgramInfo->dataTransgw.f1.ANSWER_Buf,len);
				SendStrToCarr(JProgramInfo->dataTransgw.f1.ANSWER_Buf,len);
				//���ͱ���
				//����
				printf("\ndely == %d   JProgramInfo->dataTransgw.f1.WaitTime==%02x\n", dely,JProgramInfo->dataTransgw.f1.WaitTime);
				ClearWaitTimes(ProjectNo,JProgramInfo);
				delay(100);
				memset(transRecCarr,0,1024);
				//--ת��-�Ѹ�

				for(i=0;i<60;i++)
				{
					ClearWaitTimes(ProjectNo,JProgramInfo);
					if(JProgramInfo->BeiYong[10]==1)//weifang
					{
						JProgramInfo->BeiYong[10] = 0;
						printf("\n readcarr Jmemory->BeiYong[0] = 0  timeout first \n");
						break;
					}
					len=ReceiveFromCarr(transRecCarr);
					printf("\n---------ReceiveFromZB----------len=%d------\n",len);
					for (j=0;j<len;j++)
						printf("%02x ",transRecCarr[j]);
					printf("\n");
					if(len>13)
					{
						//seconds = time((time_t*)NULL);
						printf("\n comcarr recv ok seconds =%d len=%d\n",seconds, len);
						for(j=0;j<len;j++)
						{
							ClearWaitTimes(ProjectNo,JProgramInfo);
							if(transRecCarr[j]==0x68 )//weifang //�ж��յ���һ��376.2�ı���
							{
								tmplen = transRecCarr[j+1] | (transRecCarr[j+2]<<8);
								if(transRecCarr[j+tmplen-1]==0x16 && transRecCarr[j+22]==0x13 &&
									transRecCarr[j+23]==0x01 && transRecCarr[j+24]==0x00)
								{
									ClearWaitTimes(ProjectNo,JProgramInfo);
									for(k=j+3; k<j+tmplen-2; k++)
										check += transRecCarr[k];
									check = check & 0xff;
									printf("\n recv... check == %02x transRecCarr[j+%d-2] =%02x\n",check,tmplen, transRecCarr[j+tmplen-2]);
									//if(check == transRecCarr[j+tmplen-2])
									{
										reckok = 1;
										break;
									}
								}
							}
						}
						for (j=0;j<len;j++)
							printf("%02x ",transRecCarr[j]);
						printf("\n");
						if(reckok == 1)
						{
							Update_current_time = time(NULL);
							reckok = 0;
							break;
						}
					}
					ClearWaitTimes(ProjectNo,JProgramInfo);
					delay(1000);
				}
				//�����Ǳ��Ĵ���
				memset(JProgramInfo->dataTransgw.f1.ANSWER_Buf,0,256);
				ClearWaitTimes(ProjectNo,JProgramInfo);//weifang
	//
				printf("Trans recv from carr: len=%d\n\r",len);
				for (i=0;i<len;i++)
					printf("%02x ",transRecCarr[i]);
				printf("\n\r");
				//�ӽ��յ��ı�������ȡ�������صı���
				ClearWaitTimes(ProjectNo,JProgramInfo);
				Answerlen =0;
				printf("\n\r ��ʼ����͸������---------");
				for(i=0;i<len;i++)
				{
					if((transRecCarr[i]==0x68)&& (transRecCarr[i+7]==0x68))
					{
						memset(idd, 0, 6);
						idd[0] = transRecCarr[i+1];
						idd[1] = transRecCarr[i+2];
						idd[2] = transRecCarr[i+3];
						idd[3] = transRecCarr[i+4];
						idd[4] = transRecCarr[i+5];
						idd[5] = transRecCarr[i+6];
						Answerlen = transRecCarr[i+9];   //�������ֽ���
						Answerlen = Answerlen + 10 + 2;//ת������=�������ֽ��� + 4��FE + 0x68 ��L + У��� 0x16
						JProgramInfo->dataTransgw.f1.len[0]=Answerlen&0xff;
						JProgramInfo->dataTransgw.f1.len[1]=(Answerlen>>8)&0xff;
						for(j=0;j<Answerlen;j++)
							JProgramInfo->dataTransgw.f1.ANSWER_Buf[j] = transRecCarr[i+j];

						dataflag = 1;
						ClearWaitTimes(ProjectNo,JProgramInfo);
						//JProgramInfo->dataTransgw.f1.ASK_Stat=2;
						printf("\n\r ͸�����Ľ����ɹ�--------- �����ַ��%02x%02x%02x%02x%02x%02x\n",idd[5],idd[4],idd[3],idd[2],idd[1],idd[0]);
						break;
					}
				}
				if(dataflag == 0)//�յ�376.2���ĵ�����û���κ�645��������
				{
					JProgramInfo->dataTransgw.f1.len[0]= 0;
					JProgramInfo->dataTransgw.f1.len[1]= 0;
					memset(JProgramInfo->dataTransgw.f1.ANSWER_Buf,0,256);
					printf("\n�յ�376.2���ĵ�����û���κ�645�������ݣ�\n");
				}
				printf("Trans recv from 485: len=%d  tmplen=%d Answerlen(485) =%d\n\r",len,tmplen,Answerlen);
				for (i=0;i<Answerlen;i++)
					printf("%02x ",JProgramInfo->dataTransgw.f1.ANSWER_Buf[i]);
				printf("\n\r");
			}else//376.2����
			{
				//���ݱ���ַ�ҵ��������
				SendStrToCarr(JProgramInfo->dataTransgw.f1.ANSWER_Buf,len);
				//���ͱ���
				//����
				printf("\ndely == %d   JProgramInfo->dataTransgw.f1.WaitTime==%02x\n", dely,JProgramInfo->dataTransgw.f1.WaitTime);
				ClearWaitTimes(ProjectNo,JProgramInfo);
				delay(100);
				memset(transRecCarr,0,1024);
				memset(JProgramInfo->dataTransgw.f1.ANSWER_Buf,0,256);
				//--ת��-�Ѹ�
				for(i=0;i<10;i++)
				{
					ClearWaitTimes(ProjectNo,JProgramInfo);
					if(JProgramInfo->BeiYong[10]==1)	{
						JProgramInfo->BeiYong[10] = 0;
						printf("\n readcarr Jmemory->BeiYong[0] = 0  timeout first \n");
						break;
					}
					len=ReceiveFromCarr(transRecCarr);
					if(len>0)
					{
						for (i=0; i<len; i++)
							JProgramInfo->dataTransgw.f1.ANSWER_Buf[i] = transRecCarr[i];
						JProgramInfo->dataTransgw.f1.len[0]=len&0xff;
						JProgramInfo->dataTransgw.f1.len[1]=(len>>8)&0xff;
						dataflag= 1;
						printf("\n͸�����գ�len=%d\n",len);
						for (i=0;i<len;i++)
							printf("%02x ",transRecCarr[i]);
						printf("\n");
						Update_current_time = time(NULL);

					}
					ClearWaitTimes(ProjectNo,JProgramInfo);
					delay(1000);
				}
				if(dataflag == 0)//û���κ�376.2�������ݷ���
				{
					JProgramInfo->dataTransgw.f1.len[0]= 0;
					JProgramInfo->dataTransgw.f1.len[1]= 0;
					memset(JProgramInfo->dataTransgw.f1.ANSWER_Buf,0,256);
					printf("\n�յ�376.2���ĵ�����û���κ�645�������ݣ�\n");
				}
			}
		}
		JProgramInfo->dataTransgw.f1.ASK_Stat=2;
	}
}
#endif /*ComCarrC*/

