
#ifndef CarrierWave
#define CarrierWave
#include <stdio.h>
#include <string.h>
#include <termios.h>
#include <fcntl.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <ctype.h>
#include <time.h>
#include <signal.h>
#include <semaphore.h>
#include <errno.h>
#include <fcntl.h>
#include <termios.h>
#include <inc/CVariable.h>
#include "jReadZB.h"
#include "inc/pubfunction.h"
extern unsigned char ReceiveFromCarr(unsigned char *str);
extern void SendStrToCarr(unsigned char *str,unsigned short Len);
void SendTestCarrierWave(INT8U comp);
void SendTestCarrierWave1(INT8U comp,INT8U addr[6]);
INT8U GetCarrierWaveAddress(INT8U flag);
void GetCarrierWaveAddress1();

extern INT8U MeterInf[PointMax][6];		//����ز��ӽڵ��ַ
extern INT16U meter_info[PointMax];
extern INT8U gui_yue[PointMax];


int GetZBSlavePointNum()//cuowu
{
	unsigned char  Rec645Buff[256];     /* 645��Լ���ձ��Ļ�����     */
	unsigned char  Trn645Buff[256];     /* 645��Լ���ͱ��Ļ�����     */
	unsigned int i,k=0,len=0;
	unsigned char Check=0;
	memset(Rec645Buff, 0, 256);
	memset(Trn645Buff, 0, 256);
	//CleardeadCount();  point_adr=Rec645Buff[i+20]+(((unsigned int)Rec645Buff[i+21])<<8);
//	��ѯ�ز��ӵ�ַ
//	68 12 00
//	41
//	00 00 00 00 00 00
//	10 02 00
//	00 00       //�ӽڵ���ʼ���
//	05           //�ӽڵ�����
//	58 16
	Trn645Buff[len++]=0x68;	//����ͷ
	Trn645Buff[len++]=0x0f;
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x41;
	//-----------------------��Ϣ��
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//
	//--------------------AFN
	Trn645Buff[len++]=0x10;//
	Trn645Buff[len++]=0x01;//
	Trn645Buff[len++]=0x00;//

	for (i = 3; i < len; i++)
			Check += Trn645Buff[i];
	Trn645Buff[len++]=Check;//
	Trn645Buff[len++]=0x16;//
	delay(50);
	SdPrint("\n GetZBSlavePointNum send DataNum = %d \n\r",len);
	for(i=0;i<len;i++)
		SdPrint("%02x ",Trn645Buff[i]);
	SdPrint("\n\r");
	SendStrToCarr(Trn645Buff,len);//���ͱ���

	//68 12 00 81 00 00 00 00 00 00 10 02 00 03 00 00 96 16
	//68 22 00 81 00 00 00 00 00 00 10 02 00 (<13>02 00) (<15>02) (<16+8*i>39 00 00 00 00 00) 00 00 (38 00 00 00 00 00) 00 00 08 16
	while(k<3)
	{
		ClearWaitTimes(ProjectNo,JProgramInfo);
		delay(1300);
		len=ReceiveFromCarr(Rec645Buff);
		k++;
		if(len>0)
			break;
	}
	SdPrint("\n GetZBSlavePointNum Receive DataNum = %d \n\r",len);
	for(i=0;i<len;i++)
		SdPrint("%02x ",Rec645Buff[i]);	//����
	SdPrint("\n\r");
	if(len==0)
		return -1;
	//�������� �ҵ�ZB�ӽڵ����ַ
	for(i=0;i<len;i++)
	{
		if(!(Rec645Buff[i]==0x68 && Rec645Buff[i+10]==0x10 && Rec645Buff[i+11]==0x01 && Rec645Buff[i+12]==0x00))
			continue;
		SlavePoint_TotalNum = Rec645Buff[i+13] + (Rec645Buff[i+14]<<8);
		SdPrint("\nSlavePoint_TotalNum = %d\n", SlavePoint_TotalNum);
	}
	return SlavePoint_TotalNum;
}
int GetZBSlavePoint(unsigned int begin, unsigned int count)
{
	unsigned char  Rec645Buff[256];     /* 645��Լ���ձ��Ļ�����     */
	unsigned char  Trn645Buff[256];     /* 645��Լ���ͱ��Ļ�����     */
	unsigned int i,j,k=0,len=0;
	unsigned int currentnum=0;
	unsigned char Check=0;
	memset(Rec645Buff, 0, 256);
	memset(Trn645Buff, 0, 256);
	//CleardeadCount();  point_adr=Rec645Buff[i+20]+(((unsigned int)Rec645Buff[i+21])<<8);
//	��ѯ�ز��ӵ�ַ
//	68 12 00
//	41
//	00 00 00 00 00 00
//	10 02 00
//	00 00       //�ӽڵ���ʼ���
//	05           //�ӽڵ�����
//	58 16
	Trn645Buff[len++]=0x68;	//����ͷ
	Trn645Buff[len++]=0x12;
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x41;
	//-----------------------��Ϣ��
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//
	//--------------------AFN
	Trn645Buff[len++]=0x10;//
	Trn645Buff[len++]=0x02;//
	Trn645Buff[len++]=0x00;//
	//-------------------�ڵ���Ϣ
	Trn645Buff[len++]=begin&0xff;// //cuowu
	Trn645Buff[len++]=(begin>>8)&0xff;////cuowu
	Trn645Buff[len++]=count;//

	for (i = 3; i < len; i++)
			Check += Trn645Buff[i];
	Trn645Buff[len++]=Check;//
	Trn645Buff[len++]=0x16;//
	delay(50);
	SdPrint("\n GetZBSlavePoint send DataNum = %d \n\r",len);
	for(i=0;i<len;i++)
		SdPrint("%02x ",Trn645Buff[i]);
	SdPrint("\n\r");
	SendStrToCarr(Trn645Buff,len);//���ͱ���

	//68 12 00 81 00 00 00 00 00 00 10 02 00 03 00 00 96 16
	//68 22 00 81 00 00 00 00 00 00 10 02 00 (<13>02 00) (<15>02) (<16+8*i>39 00 00 00 00 00) 00 00 (38 00 00 00 00 00) 00 00 08 16
	while(k<3)
	{
		ClearWaitTimes(ProjectNo,JProgramInfo);
		delay(1300);
		len=ReceiveFromCarr(Rec645Buff);
		k++;
		if(len>0)
			break;
	}
	SdPrint("\n GetZBSlavePoint Receive DataNum = %d \n\r",len);
	for(i=0;i<len;i++)
		SdPrint("%02x ",Rec645Buff[i]);	//����
	SdPrint("\n\r");
	if(len==0)
		return -1;
	//�������� �ҵ�ZB�ӽڵ����ַ
	for(i=0;i<len;i++)
	{
		if(!(Rec645Buff[i]==0x68 && Rec645Buff[i+10]==0x10 && Rec645Buff[i+11]==0x02 && Rec645Buff[i+12]==0x00))
			continue;
		SlavePoint_TotalNum = Rec645Buff[i+13] + (Rec645Buff[i+14]<<8);
		SdPrint("\nSlavePoint_TotalNum = %d\n", SlavePoint_TotalNum);
		if(SlavePoint_TotalNum>1024)
			SlavePoint_TotalNum = 1024;
		currentnum = Rec645Buff[i+15];
		for(j=0; j<currentnum; j++)
		{
			memcpy(&Ret_TmpPonint[j][0],&Rec645Buff[16+j*8],6);
		}
	}
	return currentnum;
}

void RemovePoint(unsigned char *MetAddr)  //ZBtiaoshi
{

	unsigned char  Rec645Buff[256];     /* 645��Լ���ձ��Ļ�����     */
	unsigned char  Trn645Buff[256];     /* 645��Լ���ͱ��Ļ�����     */
	unsigned int i,len=0;
	unsigned int k=0;
	unsigned char Check=0;
	Trn645Buff[len++]=0x68;	//����ͷ
	Trn645Buff[len++]=0x16;
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x41;
	//-----------------------
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x50;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//

	Trn645Buff[len++]=0x11;//
	Trn645Buff[len++]=0x02;//
	Trn645Buff[len++]=0x00;//

	Trn645Buff[len++]=0x01;//
	Trn645Buff[len++]=MetAddr[0];//
	Trn645Buff[len++]=MetAddr[1];//
	Trn645Buff[len++]=MetAddr[2];//
	Trn645Buff[len++]=MetAddr[3];//
	Trn645Buff[len++]=MetAddr[4];//
	Trn645Buff[len++]=MetAddr[5];//

	for (i = 3; i < len; i++)
			Check += Trn645Buff[i];
	Trn645Buff[len++]=Check;//
	Trn645Buff[len++]=0x16;//
	delay(50);
	SdPrint("\n RemovePoint send DataNum = %d .............\n\r",len);
	for(i=0;i<len;i++)
		SdPrint("%02x ",Trn645Buff[i]);
	SdPrint("\n\r");
	SendStrToCarr(Trn645Buff,len);//���ͱ���
	while(k<3)
	{
		ClearWaitTimes(ProjectNo,JProgramInfo);
		delay(1300);
		len=ReceiveFromCarr(Rec645Buff);
		k++;
		if(len>0)
			break;
	}
	SdPrint("\n RemovePoint Receive DataNum = %d ............\n\r",len);
	for(i=0;i<len;i++)
		SdPrint("%02x ",Rec645Buff[i]);	//����
	SdPrint("\n\r");
}

//ZBtiaoshi
unsigned int AddPoint(INT16U PtNo)
{

	unsigned char  Rec645Buff[256];     /* 645��Լ���ձ��Ļ�����     */
	unsigned char  Trn645Buff[256];     /* 645��Լ���ͱ��Ļ�����     */
	unsigned int i,k=0,len=0;
	unsigned char Check=0;
	///CleardeadCount();
	//68 0F 00 41 01 00 50 00 00 00 03 08 00 9D 16
	//68 15 00 81 00 00 40 00 00 00 03 08 00 64 18 00 a0 00 00 e8 16���صı���
	Trn645Buff[len++]=0x68;	//����ͷ
	Trn645Buff[len++]=0x19;
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x41;
	//-----------------------
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x50;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//
	//-----------------------
	Trn645Buff[len++]=0x11;//AFN
	Trn645Buff[len++]=0x01;//
	Trn645Buff[len++]=0x00;//

	Trn645Buff[len++]=0x01;//�ӽڵ�����

	Trn645Buff[len++]=JParamInfo3761->group2.f10[PtNo].Address[0];//
	Trn645Buff[len++]=JParamInfo3761->group2.f10[PtNo].Address[1];//
	Trn645Buff[len++]=JParamInfo3761->group2.f10[PtNo].Address[2];//
	Trn645Buff[len++]=JParamInfo3761->group2.f10[PtNo].Address[3];//
	Trn645Buff[len++]=JParamInfo3761->group2.f10[PtNo].Address[4];//
	Trn645Buff[len++]=JParamInfo3761->group2.f10[PtNo].Address[5];//
	//num=getPoint(JParamInfo3761->group2.f10[PtNo].CjqNo-1,JParamInfo3761->group2.f10[PtNo].MeterNo);
	//num = num+1; //ZBtiaoshi +
	PtNo = PtNo + 1;//dingxin
	Trn645Buff[len++]=PtNo&0xff;//
	Trn645Buff[len++]=(PtNo>>8)&0xff;//
	if (JParamInfo3761->group2.f10[PtNo].ConnectType==1)
		Trn645Buff[len++]=0x01;//
	else if(JParamInfo3761->group2.f10[PtNo].ConnectType==30)
		Trn645Buff[len++]=0x02;
	else
		Trn645Buff[len++]=0;

	for (i = 3; i < len; i++)
			Check += Trn645Buff[i];
	Trn645Buff[len++]=Check;//
	Trn645Buff[len++]=0x16;//
	delay(50);
	SdPrint("\n AddPoint send DataNum = %d .............\n\r",len);
	for(i=0;i<len;i++)
		SdPrint("%02x ",Trn645Buff[i]);
	SdPrint("\n\r");
	SendStrToCarr(Trn645Buff,len);//���ͱ���
	while(k<8)    //dingxin
	{
		ClearWaitTimes(ProjectNo,JProgramInfo);
		len=ReceiveFromCarr(Rec645Buff);

		k++;
		if(len>0)
			break;
		delay(500);
	}
	SdPrint("\n AddPoint Receive DataNum = %d ............\n\r",len);
	for(i=0;i<len;i++)
		SdPrint("%02x ",Rec645Buff[i]);	//����
	SdPrint("\n\r");
	//�������� �ҵ�ZB�ӽڵ����ַ
	for(i=0;i<len;i++)
	{
		if(Rec645Buff[i]==0x68 && Rec645Buff[i+10]==0x00 && Rec645Buff[i+11]==0x01 && Rec645Buff[i+12]==0x00)
			return 1;
	}
	return 0;
}

//ZBtiaohsi
//68 0F 00 41 00 00 5F 00 00 00 03 01 00 A4 16
//68 18 00 81 00 00 00 00 00 00 (03 01 00) (53 45 54 52)(03 06 11 13 00) F0 16
unsigned int CheckZBversion()
{
	unsigned char  Rec645Buff[256];
	unsigned char  Trn645Buff[256];
	unsigned int i,k=0,len=0;
	unsigned char Check=0,tmpversion[100];
	char zb_version[100],cmd[100];
	memset(zb_version,0,100);
	memset(cmd,0,100);
	memset(tmpversion,0,100);
	Trn645Buff[len++]=0x68;	//����ͷ
	Trn645Buff[len++]=0x0F;
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x41;
	//-----------------------
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x5F;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//
	//-----------------------
	Trn645Buff[len++]=0x03;//AFN
	Trn645Buff[len++]=0x01;//
	Trn645Buff[len++]=0x00;//
	for (i = 3; i < len; i++)
			Check += Trn645Buff[i];
	Trn645Buff[len++]=Check;//
	Trn645Buff[len++]=0x16;//
	delay(50);
	SdPrint("\n CheckZBversion send DataNum = %d .............\n\r",len);
	for(i=0;i<len;i++)
		SdPrint("%02x ",Trn645Buff[i]);
	SdPrint("\n\r");
	SendStrToCarr(Trn645Buff,len);//���ͱ���
	while(k<3)
	{
		ClearWaitTimes(ProjectNo,JProgramInfo);
		delay(500);
		len=ReceiveFromCarr(Rec645Buff);
		k++;
		if(len>0)
			break;
	}
	SdPrint("\n CheckZBversion Receive DataNum = %d ............\n\r",len);
	for(i=0;i<len;i++)
		SdPrint("%02x ",Rec645Buff[i]);	//����
	SdPrint("\n\r");
	for(i=0;i<len;i++)
	{
		if(Rec645Buff[i]==0x68 && Rec645Buff[i+10]==0x03 && Rec645Buff[i+11]==0x01 &&
				Rec645Buff[i+12]==0x00)
		{
			BCDToASC(&Rec645Buff[i+17],5,tmpversion);
			sprintf(zb_version,"%c%c%c%c%s",Rec645Buff[i+14],Rec645Buff[i+13],Rec645Buff[i+16],Rec645Buff[i+15],
					tmpversion);
			sprintf(cmd,"echo %s > /nand/bin/zbversion", zb_version);
			SdPrint("\n�ز��汾�ţ� %s\n",zb_version);
			system(cmd);
		}
	}
	return 1;
}
void AddZBPoints2(INT16U FirstIdx,INT16U NextIdx)    //һ�����Ӷ���ڵ�
{
	int len=0,i;
	unsigned char  Rec645Buff[256];     /* 645��Լ���ձ��Ļ�����     */
	unsigned char  Trn645Buff[512];     /* 645��Լ���ͱ��Ļ�����     */
	unsigned char Check=0;
	///CleardeadCount();
	//68 0F 00 41 01 00 50 00 00 00 03 08 00 9D 16
	//68 15 00 81 00 00 40 00 00 00 03 08 00 64 18 00 a0 00 00 e8 16���صı���
	Trn645Buff[len++]=0x68;	//����ͷ
	Trn645Buff[len++]=0x19;
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x41;
	Trn645Buff[len++]=0x00;
	//-----------------------
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x50;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x11;//

	Trn645Buff[len++]=0x01;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//

	for (i = FirstIdx; i < NextIdx; i++)
	{
		if ((MeterInf[i][0]!=0xff) ||
			(MeterInf[i][1]!=0xff) ||
			(MeterInf[i][2]!=0xff) ||
			(MeterInf[i][3]!=0xff) ||
			(MeterInf[i][4]!=0xff) ||
			(MeterInf[i][5]!=0xff))
		{
			Trn645Buff[13]++;              //�ز��ӽڵ���������һ
			Trn645Buff[len++]=MeterInf[i][0];//
			Trn645Buff[len++]=MeterInf[i][1];//
			Trn645Buff[len++]=MeterInf[i][2];//
			Trn645Buff[len++]=MeterInf[i][3];//
			Trn645Buff[len++]=MeterInf[i][4];//
			Trn645Buff[len++]=MeterInf[i][5];//

			//SdPrint("meter_info[%d(�ӽڵ����)] = %d��������ţ�\n\r",i,meter_info[i]);
			SdPrint("\n��������� %02x%02x%02x%02x%02x%02x �±�� %d",
					MeterInf[i][5],MeterInf[i][4],MeterInf[i][3],
					MeterInf[i][2],MeterInf[i][1],MeterInf[i][0],
					FirstIdx+1);
			Trn645Buff[len++] = (FirstIdx+1)&0xff;//meterinf�±��
			Trn645Buff[len++] =((FirstIdx+1)>>8)&0xff;//
			if(gui_yue[i]==1)   //97
				Trn645Buff[len++] = 0x01;//97
			else if(gui_yue[i]==30)
				Trn645Buff[len++] = 0x02;//07
			else
				Trn645Buff[len++] = 0;
		}
	}
	if(Trn645Buff[13]==0)return;
	for (i = 3; i < len; i++)
			Check += Trn645Buff[i];
	Trn645Buff[len++]=Check;//
	Trn645Buff[len++]=0x16;//

	//INT32U_BCD(len, lengthChar, 2);
	Trn645Buff[1]=len;
	Trn645Buff[2]=0;

	delay(50);
	SdPrint("\n ���ز�ģ�������Ӳ������ַ send DataNum = %d .............\n\r",len);
	for(i=0;i<len;i++)
		SdPrint("%02x ",Trn645Buff[i]);
	SdPrint("\n\r");
	SendStrToCarr(Trn645Buff,len);//���ͱ���
	delay(1300);
	len=ReceiveFromCarr(Rec645Buff);
	SdPrint("\n AddPoints Receive DataNum = %d ............\n\r",len);
	for(i=0;i<len;i++)
		SdPrint("%02X ",Rec645Buff[i]);	//����
	SdPrint("\n\r");

}
void AddPoints2(INT16U FirstIdx,INT16U NextIdx)    //һ�����Ӷ���ڵ�
{
	int len=0,i;

	unsigned char  Rec645Buff[256];     /* 645��Լ���ձ��Ļ�����     */
	unsigned char  Trn645Buff[512];     /* 645��Լ���ͱ��Ļ�����     */
	unsigned char Check=0;
	///CleardeadCount();
	//68 0F 00 41 01 00 50 00 00 00 03 08 00 9D 16
	//68 15 00 81 00 00 40 00 00 00 03 08 00 64 18 00 a0 00 00 e8 16���صı���
	Trn645Buff[len++]=0x68;	//����ͷ
	Trn645Buff[len++]=0x19;
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x41;
	Trn645Buff[len++]=0x00;
	//-----------------------
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x50;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x11;//

	Trn645Buff[len++]=0x01;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//

	for (i = FirstIdx; i < NextIdx; i++)
	{
		if ((MeterInf[i][0]!=0xff) ||
			(MeterInf[i][1]!=0xff) ||
			(MeterInf[i][2]!=0xff) ||
			(MeterInf[i][3]!=0xff) ||
			(MeterInf[i][4]!=0xff) ||
			(MeterInf[i][5]!=0xff))
		{
			Trn645Buff[13]++;              //�ز��ӽڵ���������һ
			Trn645Buff[len++]=MeterInf[i][0];//
			Trn645Buff[len++]=MeterInf[i][1];//
			Trn645Buff[len++]=MeterInf[i][2];//
			Trn645Buff[len++]=MeterInf[i][3];//
			Trn645Buff[len++]=MeterInf[i][4];//
			Trn645Buff[len++]=MeterInf[i][5];//

			SdPrint("meter_info[%d(�ӽڵ����)] = %d��������ţ�\n\r",i,meter_info[i]);
			meter_info[i]++;//ZBtiaoshi +
			Trn645Buff[len++]=meter_info[i]&0xff;//�ز��ӽڵ����Ӧ�������
			Trn645Buff[len++]=(meter_info[i]>>8)&0xff;//
			if(gui_yue[i]==1)   //97
			{
				Trn645Buff[len++]=0x01;//97
			}
			else if(gui_yue[i]==30)
			{
				Trn645Buff[len++]=0x02;//07
			}else
				Trn645Buff[len++]=0;
		}
	}
	if(Trn645Buff[13]==0)return;
	for (i = 3; i < len; i++)
			Check += Trn645Buff[i];
	Trn645Buff[len++]=Check;//
	Trn645Buff[len++]=0x16;//

	//INT32U_BCD(len, lengthChar, 2);
	Trn645Buff[1]=len;
	Trn645Buff[2]=0;

	delay(50);
	SdPrint("\n ���ز�ģ�������Ӳ������ַ send DataNum = %d .............\n\r",len);
	for(i=0;i<len;i++)
		SdPrint("%02x ",Trn645Buff[i]);
	SdPrint("\n\r");
	SendStrToCarr(Trn645Buff,len);//���ͱ���
	delay(1300);
	len=ReceiveFromCarr(Rec645Buff);
	SdPrint("\n AddPoints Receive DataNum = %d ............\n\r",len);
	for(i=0;i<len;i++)
		SdPrint("%02X ",Rec645Buff[i]);	//����
	SdPrint("\n\r");
}
void AddZBPoints(int num)
{
	INT16U i,firstIdx,nextIdx;
	firstIdx=0;
	for (i = 0; i <= num; i++)
	{
		nextIdx=i;
		if(nextIdx-firstIdx==15||nextIdx==num)//dingxin
		{
			//SdPrint("\n AddAllPoints .....firstIdx %d nextIdx %d  ...\n\r",firstIdx,nextIdx);
			ClearWaitTimes(ProjectNo,JProgramInfo);
			AddZBPoints2(firstIdx,nextIdx);
			firstIdx=nextIdx;
		}
	}
}
void AddAllPoints() //���ز�ģ���ڼ��������
{
	INT16U i,firstIdx,nextIdx;
	firstIdx=0;
	for (i = 0; i < PointMax; i++)
	{
		nextIdx=i;
		if(nextIdx-firstIdx==17||nextIdx==PointMax-1)
		{
			//SdPrint("\n AddAllPoints .....firstIdx %d nextIdx %d  ...\n\r",firstIdx,nextIdx);
			ClearWaitTimes(ProjectNo,JProgramInfo);
			AddPoints2(firstIdx,nextIdx);
			firstIdx=nextIdx;
		}
	}
}
void GetCarrierWaveAddress1()
{

	unsigned char  Rec645Buff[512];     /* 645��Լ���ձ��Ļ�����     */
	unsigned char  Trn645Buff[512];     /* 645��Լ���ͱ��Ļ�����     */
	unsigned int i,len=0;
	memset(Rec645Buff,0,512);
	memset(Trn645Buff,0,512);
	///CleardeadCount();
	//68 19 00 00 00 00 00 68 11 04 33 33 34 33 CB 16

	Trn645Buff[len++]=0x68;	//����ͷ
	Trn645Buff[len++]=0x19;
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x68;//

	Trn645Buff[len++]=0x11;//
	Trn645Buff[len++]=0x04;//
	Trn645Buff[len++]=0x33;//
	Trn645Buff[len++]=0x33;//
	Trn645Buff[len++]=0x34;//
	Trn645Buff[len++]=0x33;//
	Trn645Buff[len++]=0xCB;//
	Trn645Buff[len++]=0x16;//
	delay(50);
	SdPrint("\n GetCarrierWaveAddress send DataNum = %d .............\n\r",len);
	for(i=0;i<len;i++)
		SdPrint("%02x ",Trn645Buff[i]);
	SendStrToCarr(Trn645Buff,len);//���ͱ���
	delay(1000);
	len=ReceiveFromCarr(Rec645Buff);
	SdPrint("\n GetCarrierWaveAddress Receive DataNum = %d ............\n\r",len);
	for(i=0;i<len;i++)
		SdPrint("%02x ",Rec645Buff[i]);	//����
}

INT8U ResetWave()
{
	unsigned char  Rec645Buff[512];
	unsigned char  Trn645Buff[512];
	unsigned char i,len=0;
	Trn645Buff[len++]=0x68;	//����ͷ
	Trn645Buff[len++]=0x0f;
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x41;
	//-----------------------
	Trn645Buff[len++]=0x01;
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x50;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//

	Trn645Buff[len++]=0x01;//AFN
	Trn645Buff[len++]=0x01;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x94;//
	Trn645Buff[len++]=0x16;//
	delay(50);
	SdPrint("\n ResetWave send DataNum = %d .............\n\r",len);
	for(i=0;i<len;i++)
		SdPrint("%02x ",Trn645Buff[i]);
	SdPrint("\n\r");
	SendStrToCarr(Trn645Buff,len);//���ͱ���
	delay(1300);
	for(i=0;i<30;i++)
	{
	    len=ReceiveFromCarr(Rec645Buff);
		if(len>13)break;
		delay(1000);

	}
	SdPrint("\n ResetWave Receive DataNum = %d ............\n\r",len);
	for(i=0;i<len;i++)
		SdPrint("%02x ",Rec645Buff[i]);	//����
	SdPrint("\n\r");
	for (i = 0; i < len; i++)
	{
		if (Rec645Buff[i] == 0x68)
			break;
	}
	if(len<i+16)
	{
		return 0;
	}

	return 1;
}

INT8U InitWaveData()
{
	unsigned char  Rec645Buff[512];
	unsigned char  Trn645Buff[512];
	unsigned int i,len=0;
	Trn645Buff[len++]=0x68;	//����ͷ
	Trn645Buff[len++]=0x0f;
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x41;
	//-----------------------
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x50;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//

	Trn645Buff[len++]=0x01;//AFN
	Trn645Buff[len++]=0x04;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x96;//
	Trn645Buff[len++]=0x16;//
	delay(50);
	SdPrint("\n InitWaveData send DataNum = %d .............\n\r",len);
	for(i=0;i<len;i++)
		SdPrint("%02x ",Trn645Buff[i]);
	SdPrint("\n\r");
	SendStrToCarr(Trn645Buff,len);//���ͱ���
	delay(1300);
	for(i=0;i<30;i++)
	{
	    len=ReceiveFromCarr(Rec645Buff);
		if(len>13)break;
		delay(1000);

	}
	SdPrint("\n InitWaveData Receive DataNum = %d ............\n\r",len);
	for(i=0;i<len;i++)
		SdPrint("%02x ",Rec645Buff[i]);	//����
	SdPrint("\n\r");


	for (i = 0; i < len; i++)
	{
		if (Rec645Buff[i] == 0x68)
			break;
	}
	if(len<i+19)
	{
		return 0;
	}

	if ((Rec645Buff[i+13]==0xff) && (Rec645Buff[i+14]==0xff))
	{

	}
	else
	{
		return 0;
	}

	return 1;
}

INT8U GetCarrierWaveAddress(INT8U flag)//dingxin
{
//����
	unsigned char  Rec645Buff[512];     /* 645��Լ���ձ��Ļ�����     */
	unsigned char  Trn645Buff[512];     /* 645��Լ���ͱ��Ļ�����     */
	unsigned int i,len=0,k,resp_flg=0;
	unsigned char Check=0;
	memset(Rec645Buff,0,512);
	memset(Trn645Buff,0,512);
	///CleardeadCount();
	//68 0F 00 41 01 00 50 00 00 00 03 08 00 9D 16
	//68 15 00 81 00 00 40 00 00 00 03 08 00 64 18 00 a0 00 00 e8 16���صı���
	Trn645Buff[len++]=0x68;	//����ͷ
	Trn645Buff[len++]=0x0F;
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x41;
	//-----------------------
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x28;//
	Trn645Buff[len++]=0x64;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0x00;//

	Trn645Buff[len++]=0x03;//AFN
	Trn645Buff[len++]=0x08;//
	Trn645Buff[len++]=0x00;//
	Trn645Buff[len++]=0xD8;//
	Trn645Buff[len++]=0x16;//
	delay(50);
	if (flag==0)
	{
		SdPrint("\n ����ز�ģ���ַ send DataNum = %d .............\n\r",len);
		for(i=0;i<len;i++)
			SdPrint("%02x ",Trn645Buff[i]);
		SdPrint("\n\r");
	}
	SendStrToCarr(Trn645Buff,len);//���ͱ���
	//return;
	delay(1300);
	for(i=0;i<30;i++)
	{
		ClearWaitTimes(ProjectNo,JProgramInfo);
	    len=ReceiveFromCarr(Rec645Buff);
		if(len>13)break;
		delay(1000);

	}
	if (flag==0)
	{
		SdPrint("\n GetCarrierWaveAddress Receive DataNum = %d ............\n\r",len);
		for(i=0;i<len;i++)
			SdPrint("%02x ",Rec645Buff[i]);	//����
		SdPrint("\n\r");
	}
	for(i=0;i<len;i++)		//���������ĵļ��
	{
		if((Rec645Buff[i]==0x68) && (Rec645Buff[Rec645Buff[i+1]-1]==0x16))     //��ͷ��β���
		{
			if(Rec645Buff[i+10]==0x03)//��������
			{
				Check=0;
				for (k = i+3; k < Rec645Buff[i+1]-2; k++)		//У��ͼ��
				{
					  Check+=Rec645Buff[k];
				}
				if(Check!=Rec645Buff[Rec645Buff[i+1]-2])
				{
					SdPrint("���¼��\n\r");
				}
				else
				{
					resp_flg=1;
					break; //�������Ľ���
				}
			}
		}
	}

	if(resp_flg==0)
	{
		return 0;
	}
    CarrierWaveaddr[5]=Rec645Buff[i+13];
    CarrierWaveaddr[4]=Rec645Buff[i+14];
    CarrierWaveaddr[3]=Rec645Buff[i+15];
    CarrierWaveaddr[2]=Rec645Buff[i+16];
    CarrierWaveaddr[1]=Rec645Buff[i+17];
    CarrierWaveaddr[0]=Rec645Buff[i+18];
	if (flag==0)
	{
		SdPrint("����ز�ģ��ĵ�ַΪ��");
		for(i=0;i<6;i++)
    		SdPrint("%02x ",CarrierWaveaddr[i]);	//����
		SdPrint("\n\r");
	}
	return 1;
}

#endif /*CarrierWave*/

