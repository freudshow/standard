
#ifndef FKUPDATE_H_
#define FKUPDATE_H_
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <ctype.h>
#include <time.h>
#include <stdint.h>
#include <signal.h>
#include <semaphore.h>
#include <errno.h>
#include <netdb.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <math.h>
#include <termios.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/mman.h>
#include <sys/io.h>
#include <pthread.h>
#ifdef __linux__
#include <sys/msg.h>
#else
#include <hw/inout.h>
#include <sys/neutrino.h>
#endif

typedef struct
{
	char filename[20];
	char version[20];
	long size;
	char path[100];
	int  fltype;
	int  okflag;
}CONFIGTYPE;
int filenum;
CONFIGTYPE fileconfig[50];

ParamInfo3761* JParamInfo3761;
DataFileInfo*  JDataFileInfo;
ConfigInfo*    JConfigInfo;
ProgramInfo* JProgramInfo;

int jUpdatePrint;
FILE *fp;

#endif /* FKUPDATE_H_ */
