#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <inc/pubfunction.h>
#include <inc/Options.h>
#include "inc/init.h"
#include <signal.h>
#include <pthread.h>
#ifdef __linux__
#include <wait.h>
#endif
#include "jUpdate.h"

int mainflg,updflg;
INT8U ProjectNo;
#define AT91C_PIO_PB17        (1 <<  17)
uintptr_t Memories_RSTC,PBIO;
#define MY_PULSE_CODE   _PULSE_CODE_MINAVAIL
name_attach_t *attach;


void *watchdog()//Ӳ�����Ź�
{
	//���ø����ȼ�
	int dogdata=2;
	int fd = -1;
	struct sched_param param;
	sched_getparam(0, &param);
	param.sched_priority = 200;
	pthread_setschedparam(pthread_self( ),SCHED_FIFO,&param);
	if((fd = open("/dev/watchdog", O_RDWR | O_NDELAY)) == -1)
	{
		fprintf(stderr, "\n\r open /dev/watchdog error!!!");
		return (void *)1;
	}
	while(1)
	{
		delay(100);
		dogdata = 5;
		write(fd,&dogdata,sizeof(int));
		if (JProgramInfo->Projects[ProjectCount-1].WaitTimes > ProjectWaitMaxCount)
		{
			JProgramInfo->Projects[ProjectCount-1].WaitTimes=0;
			delay(5000);
		}
		JProgramInfo->Projects[ProjectCount-1].WaitTimes++;
	}
	close(fd);
	return (void *)0;
}

void QuitProcess(int signo)
{
	delay(100);
	if (jUpdatePrint==2)
	{
		fclose(fp);
		fp=NULL;
	}
	
	printf("\n\r jUpdate quit xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n\r");
    exit(0);
}

//usb�����߳�
void *usb_update( )
{
    //usb�������     �����ļ���U�̵�gprsgwĿ¼�� �ű�Ϊupdate.sh
	FILE *fd, *fd_mount;
	int  partion_flag=0, mount_flag=0, update_flag=0; //update_flag ����U��һ�α�ֻ֤����һ��
	char usbTemp[100];
	char *pdest=NULL;
	while(1)
	{
		sleep(5);			//��ʱ5s
	    fd=fopen("/proc/partitions","r");
	    fd_mount=fopen("/proc/mounts","r");
//	    SdPrint("\n partion_flag %d mount_flag %d\n",partion_flag,mount_flag);

	    if(fd!=NULL) //�Ƿ��⵽USB�Ѿ�����
	    {
			while(!feof(fd))
			{
				memset(usbTemp,0,sizeof(usbTemp));
				if(fgets(usbTemp,200,fd) != NULL )
				{
					pdest = strstr( usbTemp, "sda1" );
					if( pdest != NULL )
					{
	//					SdPrint("\nUSB check OK!!!\n");
						partion_flag = 1;
						break;
					}
				}
	    	}
			if( pdest == NULL)
				partion_flag = 0;
	    	fclose(fd);
	    }
	    if(fd_mount!=NULL) //�Ƿ�USB�Ѿ�����mount�ɹ�
	    {
			while(!feof(fd_mount))
			{
				memset(usbTemp,0,sizeof(usbTemp));
				if(fgets(usbTemp,200,fd_mount) != NULL )
				{
					pdest = strstr( usbTemp, "sda1" );
					if( pdest != NULL )
					{
//						SdPrint("\nUSB mount OK!!!\n");
						mount_flag = 1;
						break;
					}
				}
	    	}
			if( pdest == NULL)
				mount_flag = 0;
	    	fclose(fd_mount);
	    }

		if(partion_flag!=1 && mount_flag!=1) //���USBû������ʹ������־Ϊ0
			 update_flag = 0;

	    if(partion_flag==1 && mount_flag!=1)//�����⵽USB��û���� �����
	    {
			memset(usbTemp,0,sizeof(usbTemp));
			sprintf(usbTemp,"mount -t vfat /dev/sda1 /dos");
			syscmd((char *)usbTemp,JProgramInfo);
	    }
		if(partion_flag==1 && mount_flag==1) //�����⵽USB ���ҹ��سɹ���ʼ���� �������Ҫ�ǵ�ж��
		{
			JProgramInfo->stateflags.work_usb = 1;//lqq ifwork
			memset(usbTemp,0,sizeof(usbTemp));
			sprintf(usbTemp,"/dos/gprsgw");
			if(access(usbTemp,0)==0)
			{
				 memset(usbTemp,0,sizeof(usbTemp));
				 sprintf(usbTemp,"/dos/gprsgw/update.sh");
				 if(access(usbTemp,0)==0 && update_flag==0 )
				 {
					update_flag = 1;
					printf("\nBeginning update.......\n");
					memset(usbTemp,0,sizeof(usbTemp));
					syscmd("chmod +x /dos/gprsgw/update.sh",JProgramInfo);
					sprintf(usbTemp,"/dos/gprsgw/update.sh");
					syscmd((char *)usbTemp,JProgramInfo);
				 }
			}
		}
		if(partion_flag!=1 && mount_flag==1) //���û����������;�ε�USB����ж��USB
		{
			JProgramInfo->stateflags.work_usb = 0;//lqq ifwork
			 syscmd("cd /",JProgramInfo);
			 syscmd("umount /dos",JProgramInfo);
			 printf("\numount USB\n");
			 update_flag = 0;
		}
	}
	return NULL;
}
/*-------------------------------------------------*/
int main(int argc, char *argv[])
{
    char buf[128],command[80];
    INT8U TempBuf[60];
	struct tm tmp_tm;
	time_t time_of_day;
	struct sigaction sa1;//����ָ��
	pthread_t thread,thread_usb;
	int temp;
	TS ts,tsn;
	memset(&thread, 0, sizeof(thread));
	memset(&thread_usb, 0, sizeof(thread_usb));
    printf("Welcome to the myserver -[jzqupdate] \n\r");
    DbgPrintToFile("Starting jUpdate ..........");


	JParamInfo3761 = Open1ShMem("ParamInfo3761",sizeof(ParamInfo3761),NULL);
	JDataFileInfo = Open1ShMem("DataFileInfo",sizeof(DataFileInfo),NULL);
	JConfigInfo = Open1ShMem("ConfigInfo",sizeof(ConfigInfo),NULL);
	JProgramInfo = Open1ShMem("ProgramInfo",sizeof(ProgramInfo),NULL);

    if ((attach=name_attach(NULL, "jUpdate", 0,JProgramInfo)) == NULL)//����һ���ռ䲢�Ҵ���һ���ŵ�
	{
    	printf( "ERR:'%s' runed,cann't regist\n\r", argv[0]);
		return EXIT_FAILURE;
   	}

    sa1.sa_handler = QuitProcess;//�������˳�ʱɱ�������ӽ��̣���չ����ڴ�
	sigemptyset(&sa1.sa_mask);//���������� �źż���ʼ������ա�

	sa1.sa_flags = 0;
	sigaction(SIGTERM, &sa1,NULL);
	sigaction(SIGSYS, &sa1,NULL);
	sigaction(SIGPWR, &sa1,NULL);
	sigaction(SIGKILL,&sa1,NULL);
	sigaction(SIGQUIT, &sa1,NULL);
	sigaction(SIGILL, &sa1,NULL);
	sigaction(SIGINT, &sa1,NULL);
	sigaction(SIGHUP, &sa1,NULL);
	sigaction(SIGABRT, &sa1,NULL);
	sigaction(SIGBUS, &sa1,NULL);
	Memories_RSTC = mmap_device_io(16, 0xFFFFFD00);
	out32(Memories_RSTC + 0x08, 0xA5000000);
	delay(3000);
	markver();

	memset(buf,0,128);
	memset(command,0,80);
	sprintf((char*)command,"%s/setupx &",_USERDIR_);
	syscmd((char*)command,JProgramInfo);
	delay(100);

	//�����߳�
	if((temp = pthread_create(&thread, NULL, watchdog, NULL)) != 0) //�������߳�
	{
		printf("thread watchdog create fail!\n");
	}

	if((temp = pthread_create(&thread_usb, NULL, usb_update, NULL)) != 0) //�������߳�
	{
		printf("thread usb_update create fail!\n");
		JProgramInfo->stateflags.work_usb = 0;//lqq ifwork
	}

	mainflg=0;
	updflg=0;
	time_of_day = time(NULL);
	localtime_r(&time_of_day, &tmp_tm);
	printf("jUpdate start .................\n\r");

    TSGet(&tsn);
    while(1)
    {
        delay(1000);
	    TSGet(&ts);
	    if (JProgramInfo->Gprs_ok == 1)
	    {
	    	tsn=ts;
	    }
	    else
	    {
	    	if(((JProgramInfo->zone)&0x7f)==JIANGXI)									//9.26����Ҫ�����������ÿ�����������
			{
				if((ts.Hour==23)&&(ts.Minute==0)&&(ts.Sec>0)&&(ts.Sec<5))
				{	printf("\nJIANGXI  reboot jDataSaveTask ------\n\r");
					DbgPrintToFile("\njUpdate jiangxi 23������ reboot\n");//9.27
					memset(TempBuf, 0, 60);
					sprintf((char *) TempBuf, "%s/rebtsys &", _USERDIR_);
					syscmd((char *) TempBuf,JProgramInfo);
					syscmd("reboot",JProgramInfo);
				}
			}
        }
    }

    return EXIT_SUCCESS;
}
