 /* �ļ�����jSet.c
 * �ļ������������������ù���ģ�飨�����ն��޸Ĳ�����
 * ������ʶ��20090916 xuxinhui
 * �޸ı�ʶ��
 * �޸�������
 */
#include "unistd.h"
#include <stdlib.h>
#include <stdio.h>
#include "inc/pubfunction.h"
#include "inc/init.h"
#include <signal.h>
#include <semaphore.h>
#include <sys/ioctl.h>
#include <stdarg.h>
#include <../jBase/inc/jMemory.h>


ParamInfo3761* JParamInfo3761;
DataFileInfo*  JDataFileInfo;		//������Ϣ�ṹ
ConfigInfo*    JConfigInfo;
ProgramInfo* JProgramInfo;		//������Ϣ�ṹ

int dayin_count;
INT8U ProjectNo;
INT8U memflg;
SMFiles smfile;
int on=1, off=0, fd=-1;

INT8U SetDa1(INT16U Value) {
	INT8U Result = 1;
	if (Value == 0)
		return 0;
	Value = Value - 1;
	Result = Result << (Value % 8);
	return Result;
}
INT8U SetDa2(INT16U Value) {
	if (Value == 0)
		return 0;
	Value = Value - 1;
	return (Value / 8) + 1;
}
int checkkey(char *dev_filename)
{
	int data=0, fd =-1;
	if((fd = open(dev_filename, O_RDWR | O_NDELAY)) > 0)  //rst 30
	{
		read(fd,&data,sizeof(int));
		close(fd);
	}
	if(data >0)
	fprintf(stderr, "\ndev_filename==%s  data===%d\n", dev_filename, data);
	return data;
}
void savejzqmeter(int meterno)
{
	if (JParamInfo3761->group2.f10[meterno-1].ConnectType==2)
	{
		FILE *fpcomm = NULL;
		INT8U TempBuf[60];
		memset(TempBuf, 0, 60);
		sprintf((char *) TempBuf, "%s/jzqmeter.cfg", _CFGDIR_);
		fpcomm = fopen((char *) TempBuf, "w");
		if (fpcomm!=NULL)
		{
			fprintf(fpcomm, " %02x-%02x-%02x-%02x-%02x-%02x",
					 JParamInfo3761->group2.f10[meterno-1].Address[5]
					,JParamInfo3761->group2.f10[meterno-1].Address[4]
					,JParamInfo3761->group2.f10[meterno-1].Address[3]
					,JParamInfo3761->group2.f10[meterno-1].Address[2]
					,JParamInfo3761->group2.f10[meterno-1].Address[1]
					,JParamInfo3761->group2.f10[meterno-1].Address[0]);
			fclose(fpcomm);
			fpcomm = NULL;
		}
	}
}
void PrintHisData(int myear,int mmonth,int mday)
{
	int point,oknum,allnum;
	SMFiles tempdata;
	int re;
	char filename[100];
	oknum = allnum = 0;
	printf("\n\r*************   %d-%d-%d  **************\n\r",myear,mmonth,mday);
	memset(filename,0,100);

	{
		for(point=0;point<PointMax;point++)
		{
			if (JParamInfo3761->group2.f10[point].Status==1)
			{
				allnum++;
				if ((myear ==0 )&&(mmonth==0)&&(mday==0))
					sprintf(filename,"/nand/DataCurr/%04d/curr.dat",point+1);
				else if(mday != 0)
					sprintf(filename,"/nand/DataDay/%04d/%02d.dat",point+1,mday);
				else if(mmonth != 0)
					sprintf(filename,"/nand/DataMonth/%04d/%02d.dat",point+1,mmonth);
				printf("\n\rfilename : %s",filename);
				if(access((char*)filename,0)==0)
				{
					re = ReadFile(filename,&tempdata,sizeof(SMFiles),JProgramInfo);
					if (re !=0){
						printf("	    NO point %d data\n\r",point+1);
						continue;
					}else{
						oknum++;
						printf("		time:[%d-%d-%d %d-%d]",tempdata.ts.Year,tempdata.ts.Month,tempdata.ts.Day,
																tempdata.ts.Hour,tempdata.ts.Minute);
						printf("   %d  %02x %02x",tempdata.sm.MeterNo,tempdata.sm.datas[0].flg.Dataflag[0],
													tempdata.sm.datas[0].flg.Dataflag[1]);
						printf("   %02x%02x%02x.%02x",tempdata.sm.datas[0].datas[3],tempdata.sm.datas[0].datas[2],
													  tempdata.sm.datas[0].datas[1],tempdata.sm.datas[0].datas[0]);
						printf("   meteradr  %02x%02x%02x%02x%02x%02x",JParamInfo3761->group2.f10[point].Address[5],
								JParamInfo3761->group2.f10[point].Address[4],JParamInfo3761->group2.f10[point].Address[3],
								JParamInfo3761->group2.f10[point].Address[2],JParamInfo3761->group2.f10[point].Address[1],
								JParamInfo3761->group2.f10[point].Address[0]);
						printf(" cjqadr  %02x%02x%02x%02x",JParamInfo3761->group2.f10[point].CaijiqiAddress[3],
								JParamInfo3761->group2.f10[point].CaijiqiAddress[2],
								JParamInfo3761->group2.f10[point].CaijiqiAddress[1],
								JParamInfo3761->group2.f10[point].CaijiqiAddress[0]);
					}
				}else
				{
					printf("		No curr.dat  ************************** ");
					printf("   meteradr  %02x%02x%02x%02x%02x%02x",JParamInfo3761->group2.f10[point].Address[5],
							JParamInfo3761->group2.f10[point].Address[4],JParamInfo3761->group2.f10[point].Address[3],
							JParamInfo3761->group2.f10[point].Address[2],JParamInfo3761->group2.f10[point].Address[1],
							JParamInfo3761->group2.f10[point].Address[0]);
					printf(" cjqadr  %02x%02x%02x%02x",JParamInfo3761->group2.f10[point].CaijiqiAddress[3],
							JParamInfo3761->group2.f10[point].CaijiqiAddress[2],
							JParamInfo3761->group2.f10[point].CaijiqiAddress[1],
							JParamInfo3761->group2.f10[point].CaijiqiAddress[0]);
				}
			}
		}
	}
	printf("\n\r\n\r------- ALLPoint %d     OkPoint %d\n\r\n\r",allnum,oknum);
}
void PrintHisHourData(int mmonth,int mday,int mhour)
{
	int point,oknum,allnum;
	TS ts;
	int i,j;
	char filename[100];
	oknum = allnum = 0;
	printf("\n\r*************   %d-%d-%d  **************\n\r",mmonth,mday,mhour);
	memset(filename,0,100);
	point=0;
	TSGet(&ts);
	{
		//for(point=0;point<PointMax;point++)
		{
			if (JParamInfo3761->group2.f10[point].Status==1)
			{
				allnum++;
				sprintf(filename,"/nand/DataHour/%04d%02d%02d/%04d/%04d%02d%02d%02d%02d.dat"
						,ts.Year,mmonth,mday,point+1,ts.Year,mmonth,mday,mhour,0);
				printf("\n\rfilename : %s",filename);
				if (access((char *) filename, 0) != 0)
					return;
				ReadFile((char *) filename, &smfile,sizeof(SMFiles),JProgramInfo);
				printf("ts=%02d-%02d-%02d %02d:%02d:%02d\n\r",smfile.ts.Year,smfile.ts.Month,
						smfile.ts.Day,smfile.ts.Hour,smfile.ts.Minute,smfile.ts.Sec);
				printf("pt=%d,CaijiQiNo=%d,MeterNo=%d\n\r",getPoint(smfile.sm.CaijiQiNo,smfile.sm.MeterNo)+1,smfile.sm.CaijiQiNo,smfile.sm.MeterNo);
				for (i=0;i<ManyFlagsCount;i++)
				{
					if (smfile.sm.datas[i].flg.Dataflag[1]==0x00 && smfile.sm.datas[i].flg.Dataflag[0]==0x00)
						continue;
					if (smfile.sm.datas[i].flg.Dataflag[1]==0xff && smfile.sm.datas[i].flg.Dataflag[0]==0xff)
						continue;
					if (smfile.sm.datas[i].flg.Dataflag[1]==OxXX && smfile.sm.datas[i].flg.Dataflag[0]==OxXX)
						continue;
					printf("flag%d  %d=%02x%02x---", smfile.sm.datas[i].flg.ReadFlg, i, smfile.sm.datas[i].flg.Dataflag[1], smfile.sm.datas[i].flg.Dataflag[0]);
					for(j=0;(j<DataLenMax && j<30);j++)
					{
						printf("%02x ",smfile.sm.datas[i].datas[j]);
					}
					printf("\n\r");
				}
			}
		}
	}
	printf("\n\r\n\r------- ALLPoint %d     OkPoint %d\n\r\n\r",allnum,oknum);
}
static int i2c_read(int fd, unsigned char reg, unsigned char *val, unsigned char num)
{
	int retries;
	for(retries=5; retries; retries--)
		if(write(fd, &reg, 1)==1)
			if(read(fd, val, 1)==1)
				return 0;
	return -1;
//	printf("\nread  i2cfd ===%d", i2cfd);
//	val[0]=i2c_smbus_read_byte_data(i2cfd,AT24ADDR+reg);
//	return 1;

}
void CommandProcess(int argc, char *argv[])
{
	int i, temp1, temp2, temp3, temp4, temp5;
	float p,q;float u,ii;
	unsigned char TmpAPN[17],TempBuf[60];
	if (memflg==0)
	{
		//printf("1111\n\r");
		memset(TempBuf,0,60);
		sprintf((char*)TempBuf,"%s/JzhqPara.par",_PARADIR_);
		if (access((char*)TempBuf, 0) == 0) {
	//		if (NormalReadFile((char*)TempBuf, &Jmemory->jzq, sizeof(Jmemory->jzq),JProgramInfo)==1)
			{
				printf("set failed,please reset!!!");
				return;
			}
		} else {
			JProgramInfo->ExcuteNo = 0;
		}
		memset(TempBuf,0,60);
		sprintf((char*)TempBuf,"%s/AmmeterOth.par",_PARADIR_);
		if (access((char*)TempBuf, 0) == 0)
		{
			delay(100);
			if (NormalReadFile((char*)(char*)TempBuf, &JParamInfo3761->group5.f34, sizeof(JParamInfo3761->group5.f34)+sizeof(JParamInfo3761->group5.f35),JProgramInfo)==1)
			{
				delay(100);
				if (NormalReadFile((char*)(char*)TempBuf, &JParamInfo3761->group5.f34, sizeof(JParamInfo3761->group5.f34)+sizeof(JParamInfo3761->group5.f35),JProgramInfo)==1)
				{
					delay(100);
					if (NormalReadFile((char*)(char*)TempBuf, &JParamInfo3761->group5.f34, sizeof(JParamInfo3761->group5.f34)+sizeof(JParamInfo3761->group5.f35),JProgramInfo)==1)
					{
					}
				}
			}
		}
		for(i=0;i<PointMax;i++)
		{
			if ((i%SaveNum)==0)
			{
				memset(TempBuf,0,60);
				sprintf((char*)TempBuf,"%s/Ammeter%04d.par",_PARADIR_,(i/SaveNum)+1);
				if (access((char*)TempBuf, 0) == 0)
				{
					delay(100);
					if (NormalReadFile((char*)TempBuf, &JParamInfo3761->Point[i], sizeof(JParamInfo3761->Point[i])*SaveNum,JProgramInfo)==1)
					{
						delay(100);
						if (NormalReadFile((char*)TempBuf, &JParamInfo3761->Point[i], sizeof(JParamInfo3761->Point[i])*SaveNum,JProgramInfo)==1)
						{
							delay(100);
							if (NormalReadFile((char*)TempBuf, &JParamInfo3761->Point[i], sizeof(JParamInfo3761->Point[i])*SaveNum,JProgramInfo)==1)
							{
							}
						}
					}
				}
			}
		}
		memset(TempBuf,0,60);
		sprintf((char*)TempBuf,"%s/TaskPara.par",_PARADIR_);
		if (access((char*)TempBuf, 0) == 0) {
		}
		if (JProgramInfo->ExcuteNo == 0) {
			JProgramInfo->ExcuteNo = 1;
			//wyq
			JProgramInfo->FileSaveFlag.g4flag = 1;
//			memset(TempBuf,0,60);
//			sprintf((char*)TempBuf,"%s/JzhqPara.par",_PARADIR_);
//			NormalSaveFile((char*)TempBuf, &Jmemory->jzq, sizeof(Jmemory->jzq),JProgramInfo);
//			memset(TempBuf,0,60);
//			sprintf((char*)TempBuf,"%s/AmmeterOth.par",_PARADIR_);
//			NormalSaveFile((char*)TempBuf,(INT8U *)&JParamInfo3761->group5.f34,sizeof(JParamInfo3761->group5.f34)+sizeof(JParamInfo3761->group5.f35),JProgramInfo);
//			delay(100);
//			memset(TempBuf,0,60);
//			sprintf((char*)TempBuf,"%s/AmmeterN.par",_PARADIR_);
//			NormalSaveFile((char*)TempBuf,(INT8U *)&Jmemory->Points,sizeof(Jmemory->Points),JProgramInfo);
//			delay(100);
			for(i=0;i<PointMax;i++)
			{
				JProgramInfo->FileSaveFlag.F10_ChangedSave[i] = 1;
//				if (JParamInfo3761->Point[i].f10.Status!=1)
//					continue;
//				if ((i%SaveNum)==0)
//				{
//					memset(TempBuf,0,60);
//					sprintf((char*)TempBuf,"%s/Ammeter%04d.par",_PARADIR_,(i/SaveNum)+1);
//					NormalSaveFile((char*)TempBuf,(INT8U *)&Jmemory->Points.pt[i-(i%SaveNum)],sizeof(Jmemory->Points.pt[i-(i%SaveNum)])*SaveNum,JProgramInfo);
//					delay(10);
//				}
			}
		}
	}

	if (strcmp("jcdata", argv[1]) == 0) {
		FILE *fp;
		INT8U res;
		int num,size;

		fp = fopen("/nand/DataCurr/JcData.dat", "r");
		if (fp != NULL) {
			fseek(fp, 0, SEEK_SET);
			res = 0;
			size = sizeof(JDataFileInfo->jc);
			num=fread((void *)&JDataFileInfo->jc, size,1,fp);
			if (num==-1)
			{
				fprintf(stderr,"read fail\n\r");
				res = 1;
			}else {
				fprintf(stderr,"read num=%d,size=%d\n",num,size);
				fprintf(stderr,"Z_P_All=%d\n,Z1=%d,Z2=%d,Z3=%d,Z4=%d\n",JDataFileInfo->jc.JcDdRealData.Z_P_All,
						JDataFileInfo->jc.JcDdRealData.Z_P_F[0],JDataFileInfo->jc.JcDdRealData.Z_P_F[1],
						JDataFileInfo->jc.JcDdRealData.Z_P_F[2],JDataFileInfo->jc.JcDdRealData.Z_P_F[3]);
			}
			fclose(fp);
			fp=NULL;
		}
		return;
	}
//_POSIX_C_SOURCE
	if (strcmp("macro", argv[1]) == 0) {
		printf("\n_POSIX_C_SOURCE==%ld\n", _POSIX_C_SOURCE);
		printf("\nJParamInfo3761->group1.f1.DelayTime_AgainNum = %x\n",JParamInfo3761->group1.f1.DelayTime_AgainNum);
		return;
	}

	if (strcmp("ip", argv[1]) == 0)
	{
		if (argc == 2)
		{
			temp1 = JParamInfo3761->group1.f3.IP[3];
			temp2 = JParamInfo3761->group1.f3.IP[2];
			temp3 = JParamInfo3761->group1.f3.IP[1];
			temp4 = JParamInfo3761->group1.f3.IP[0];
			temp5 = JParamInfo3761->group1.f3.PortAddress[1];
			temp5 = (temp5 << 8) + JParamInfo3761->group1.f3.PortAddress[0];
			fprintf(stderr, "\n���� ip %d.%d.%d.%d:%d\n\r", temp1, temp2, temp3, temp4, temp5);
			temp1 = JParamInfo3761->group1.f3.IP1[3];
			temp2 = JParamInfo3761->group1.f3.IP1[2];
			temp3 = JParamInfo3761->group1.f3.IP1[1];
			temp4 = JParamInfo3761->group1.f3.IP1[0];
			temp5 = JParamInfo3761->group1.f3.PortAddress1[1];
			temp5 = (temp5 << 8) + JParamInfo3761->group1.f3.PortAddress1[0];
			fprintf(stderr, "\n���� ip %d.%d.%d.%d:%d\n\r", temp1, temp2, temp3, temp4, temp5);
		} else
		{
			if (argc == 3)
			{
				if (sscanf(argv[2], "%d.%d.%d.%d:%d", &temp1, &temp2, &temp3, &temp4, &temp5) == 5)
				{
					fprintf(stderr, "\n\rset ip %d.%d.%d.%d:%d\n\r", temp1, temp2, temp3, temp4, temp5);
					JParamInfo3761->group1.f3.IP[3] = temp1;
					JParamInfo3761->group1.f3.IP[2] = temp2;
					JParamInfo3761->group1.f3.IP[1] = temp3;
					JParamInfo3761->group1.f3.IP[0] = temp4;
					JParamInfo3761->group1.f3.PortAddress[1] = temp5 >> 8;
					JParamInfo3761->group1.f3.PortAddress[0] = temp5 & 0xff;
				}
			}
			if (argc == 4)
			{
				if (sscanf(argv[2], "%d.%d.%d.%d:%d", &temp1, &temp2, &temp3, &temp4, &temp5) == 5)
				{
					fprintf(stderr, "\n\r���� ip %d.%d.%d.%d:%d\n\r", temp1, temp2, temp3, temp4, temp5);
					JParamInfo3761->group1.f3.IP[3] = temp1;
					JParamInfo3761->group1.f3.IP[2] = temp2;
					JParamInfo3761->group1.f3.IP[1] = temp3;
					JParamInfo3761->group1.f3.IP[0] = temp4;
					JParamInfo3761->group1.f3.PortAddress[1] = temp5 >> 8;
					JParamInfo3761->group1.f3.PortAddress[0] = temp5 & 0xff;
				}
				if (sscanf(argv[3], "%d.%d.%d.%d:%d", &temp1, &temp2, &temp3, &temp4, &temp5) == 5)
				{
					fprintf(stderr, "\n\r���� ip %d.%d.%d.%d:%d\n\r", temp1, temp2, temp3, temp4, temp5);
					JParamInfo3761->group1.f3.IP1[3] = temp1;
					JParamInfo3761->group1.f3.IP1[2] = temp2;
					JParamInfo3761->group1.f3.IP1[1] = temp3;
					JParamInfo3761->group1.f3.IP1[0] = temp4;
					JParamInfo3761->group1.f3.PortAddress1[1] = temp5 >> 8;
					JParamInfo3761->group1.f3.PortAddress1[0] = temp5 & 0xff;
				}
			}
			JProgramInfo->FileSaveFlag.g1flag = 1;
//			memset(TempBuf,0,60);
//			sprintf((char*)TempBuf,"%s/JzhqParaN.par",_PARADIR_);
//			NormalSaveFile((char*)TempBuf, &Jmemory->jzq, sizeof(Jmemory->jzq),JProgramInfo);
//			delay(100);
//			memset(TempBuf,0,60);
//			sprintf((char*)TempBuf,"%s/JzhqPara.par",_PARADIR_);
//			NormalSaveFile((char*)TempBuf, &Jmemory->jzq, sizeof(Jmemory->jzq),JProgramInfo);
			JProgramInfo->Gprs_ok=0;
		}
		return;
	}
	if (strcmp("gprs", argv[1]) == 0) {
		if(argc ==2)
			printf("JProgramInfo->Gprs_ok=%d\n\r",JProgramInfo->Gprs_ok);
		if(argc==3)
		{
			JProgramInfo->Gprs_ok = atoi(argv[2]);
			printf("JProgramInfo->Gprs_ok=%d\n\r",JProgramInfo->Gprs_ok);
		}
		return;
	}
	if (strcmp("id", argv[1]) == 0) {
		if (argc == 2) {
			temp1 = JConfigInfo->jzqpara.Area_8016.JZ_XingZhuangQuHaoMa[0];
			temp2 = JConfigInfo->jzqpara.Area_8016.JZ_XingZhuangQuHaoMa[1];
			temp3 = JConfigInfo->jzqpara.Address_8017.JZ_di_zhi[0];
			temp4 = JConfigInfo->jzqpara.Address_8017.JZ_di_zhi[1];
			fprintf(stderr, "id %02x%02x-%02x%02x(%05d)\n\r", temp1, temp2, temp3, temp4,((temp3<<8)+temp4));
		} else {
			//fprintf(stderr, "%s ", argv[2]);
			if (argc == 3)//Ĭ�����ø�ʽΪ16����
			{
					if (sscanf(argv[2], "%x-%x", &temp1, &temp2) == 2)
					{
						printf("\n��ַʮ�����Ʒ�ʽ���� ��\n");
						JConfigInfo->jzqpara.Area_8016.JZ_XingZhuangQuHaoMa[0]=(temp1>>8)&0xff;
						JConfigInfo->jzqpara.Area_8016.JZ_XingZhuangQuHaoMa[1]=temp1&0xff;
						JConfigInfo->jzqpara.Address_8017.JZ_di_zhi[0]=(temp2>>8)&0xff;
						JConfigInfo->jzqpara.Address_8017.JZ_di_zhi[1]=temp2&0xff;
						JProgramInfo->FileSaveFlag.jzqflag = 1;
//						memset(TempBuf,0,60);
//						sprintf((char*)TempBuf,"%s/JzhqParaN.par",_PARADIR_);
//						NormalSaveFile((char*)TempBuf, &Jmemory->jzq, sizeof(Jmemory->jzq),JProgramInfo);
//						delay(100);
//						memset(TempBuf,0,60);
//						sprintf((char*)TempBuf,"%s/JzhqPara.par",_PARADIR_);
//						NormalSaveFile((char*)TempBuf, &Jmemory->jzq, sizeof(Jmemory->jzq),JProgramInfo);
						JProgramInfo->Gprs_ok=0;
					}
			}
			if (argc == 4)// �ж������������Ƿ���ʮ���Ʊ�ʶ
			{
					char dflag;
					sscanf(argv[3],"%c",&dflag);
					if (dflag == 'd')
					{
						if (sscanf(argv[2], "%x-%05d", &temp1, &temp2) == 2)
						{
							printf("\n��ַʮ���Ʒ�ʽ���� ��\n");
							JConfigInfo->jzqpara.Area_8016.JZ_XingZhuangQuHaoMa[0]=(temp1>>8)&0xff;
							JConfigInfo->jzqpara.Area_8016.JZ_XingZhuangQuHaoMa[1]=temp1&0xff;
							JConfigInfo->jzqpara.Address_8017.JZ_di_zhi[0]=(temp2>>8)&0xff;
							JConfigInfo->jzqpara.Address_8017.JZ_di_zhi[1]=temp2&0xff;
							JProgramInfo->FileSaveFlag.jzqflag = 1;
//							memset(TempBuf,0,60);
//							sprintf((char*)TempBuf,"%s/JzhqParaN.par",_PARADIR_);
//							NormalSaveFile((char*)TempBuf, &Jmemory->jzq, sizeof(Jmemory->jzq),JProgramInfo);
//							delay(100);
//							memset(TempBuf,0,60);
//							sprintf((char*)TempBuf,"%s/JzhqPara.par",_PARADIR_);
//							NormalSaveFile((char*)TempBuf, &Jmemory->jzq, sizeof(Jmemory->jzq),JProgramInfo);
							JProgramInfo->Gprs_ok=0;
						}
					}
			}
			//--------------------------------------------------------------------
			//�ٴ�ӡһ��
			temp1 = JConfigInfo->jzqpara.Area_8016.JZ_XingZhuangQuHaoMa[0];
			temp2 = JConfigInfo->jzqpara.Area_8016.JZ_XingZhuangQuHaoMa[1];
			temp3 = JConfigInfo->jzqpara.Address_8017.JZ_di_zhi[0];
			temp4 = JConfigInfo->jzqpara.Address_8017.JZ_di_zhi[1];
			fprintf(stderr, "\n\rid %02x%02x-%02x%02x(%05d)\n\r", temp1, temp2, temp3, temp4,((temp3<<8)+temp4));
			//--------------------------------------------------------------------

		}
		return;
	}

	if (strcmp("his", argv[1]) == 0)
	{
		if (argc == 2) {
			printf("\n\rretry");
		} else {
			if (sscanf(argv[2], "%d-%d-%d", &temp1, &temp2, &temp3) == 3)
			{
				PrintHisData(temp1,temp2,temp3);
			}
		}
		return;
	}
	if (strcmp("hishour", argv[1]) == 0)
	{
		if (argc == 2) {
		} else {
			if (sscanf(argv[2], "%d-%d-%d", &temp1, &temp2, &temp3) == 3)
			{
				PrintHisHourData(temp1,temp2,temp3);
			}
		}
		return;
	}
	if (strcmp("ls", argv[1]) == 0) {
		if (argc == 2) {
			int ww;
			char cmdstr[50];
			for (ww = 0; ww <PointMax; ww++)//��������Ϣ
			{
				if (JParamInfo3761->group2.f10[ww].Status==1)
				{
					fprintf(stderr,"\n\r ------------------------------------------------------------- [ %d ]\n\r",ww+1);
					sprintf(cmdstr,"ls -l /nand/DataCurr/%04d",ww+1);
					system(cmdstr);
				}
			}
		}
		return;
	}
	if (strcmp("idn", argv[1]) == 0) {
		if (argc == 2) {
			temp1 = JConfigInfo->jzqpara.Area_8016.JZ_XingZhuangQuHaoMa[0];
			temp2 = JConfigInfo->jzqpara.Area_8016.JZ_XingZhuangQuHaoMa[1];
			temp3 = JConfigInfo->jzqpara.Address_8017.JZ_di_zhi[0];
			temp4 = JConfigInfo->jzqpara.Address_8017.JZ_di_zhi[1];
			fprintf(stderr, "\n\rid %02x%02x-%05d\n\r", temp1, temp2, ((temp3<<8)+temp4));
		} else {
			fprintf(stderr, "%s ", argv[2]);
			if (sscanf(argv[2], "%x-%d", &temp1, &temp2) == 2) {
				fprintf(stderr, "\n\rset id %04x-%05d\n\r", temp1, temp2);
				JConfigInfo->jzqpara.Area_8016.JZ_XingZhuangQuHaoMa[0]=(temp1>>8)&0xff;
				JConfigInfo->jzqpara.Area_8016.JZ_XingZhuangQuHaoMa[1]=temp1&0xff;
				JConfigInfo->jzqpara.Address_8017.JZ_di_zhi[0]=(temp2>>8)&0xff;
				JConfigInfo->jzqpara.Address_8017.JZ_di_zhi[1]=temp2&0xff;
				JProgramInfo->FileSaveFlag.jzqflag = 1;
//				memset(TempBuf,0,60);
//				sprintf((char*)TempBuf,"%s/JzhqParaN.par",_PARADIR_);
//				NormalSaveFile((char*)TempBuf, &Jmemory->jzq, sizeof(Jmemory->jzq),JProgramInfo);
//				delay(100);
//				memset(TempBuf,0,60);
//				sprintf((char*)TempBuf,"%s/JzhqPara.par",_PARADIR_);
//				NormalSaveFile((char*)TempBuf, &Jmemory->jzq, sizeof(Jmemory->jzq),JProgramInfo);
				JProgramInfo->Gprs_ok=0;
			}
		}
		return;
	}
	if (strcmp("apn", argv[1]) == 0) {
		if (argc == 2) {
			memset(TmpAPN, 0x00, sizeof(TmpAPN));
			for (i = 0; i < 16; i++) {
				if (TmpAPN[i] != 0xff)
					TmpAPN[i] = JParamInfo3761->group1.f3.APN[15 - i];
				if (TmpAPN[i] != 0xff)
					printf("%c", TmpAPN[i]);
			}
			printf("\n\r");
		} else {
			memset(TmpAPN, 0x00, sizeof(TmpAPN));
			memset(JParamInfo3761->group1.f3.APN, 0, sizeof(JParamInfo3761->group1.f3.APN));
			if (sscanf(argv[2], "%s", TmpAPN)) {
				printf("\n\r");
				for (i = 0; i < 16; i++) {
					JParamInfo3761->group1.f3.APN[15 - i] = TmpAPN[i];
					if (TmpAPN[i] != 0xff)
						printf("%c", TmpAPN[i]);
				}
				write_apn(JParamInfo3761,JProgramInfo);
				printf("\n\r");
				JProgramInfo->FileSaveFlag.g1flag = 1;
//				memset(TempBuf,0,60);
//				sprintf((char*)TempBuf,"%s/JzhqParaN.par",_PARADIR_);
//				NormalSaveFile((char*)TempBuf, &Jmemory->jzq, sizeof(Jmemory->jzq),JProgramInfo);
//				delay(100);
//				memset(TempBuf,0,60);
//				sprintf((char*)TempBuf,"%s/JzhqPara.par",_PARADIR_);
//				NormalSaveFile((char*)TempBuf, &Jmemory->jzq, sizeof(Jmemory->jzq),JProgramInfo);
				JProgramInfo->Gprs_ok=0;
				//syscmd("slay pppd > /dev/null");
			}
		}
		return;
	}
	if (strcmp("look", argv[1]) == 0)
	{
		int i;
		printf("\n�¼���Чλ��־��");
		for(i=0;i<8;i++)
		{
			printf("%02x ",JParamInfo3761->group2.f9.Flag[i]);
		}
		return;
	}
	if (strcmp("passwd", argv[1]) == 0) {
		if (argc == 2) {
		} else
		{
			JParamInfo3761->group1.f7.PassLen=6;					        //���볤��
			if(((JProgramInfo->zone)&0x7f) == TIANJIN)
			{
				JParamInfo3761->group1.f7.PassWords[0]=0x11;
				JParamInfo3761->group1.f7.PassWords[1]=0x11;
				JParamInfo3761->group1.f7.PassWords[2]=0x11;
			}else
			{
				memset(JParamInfo3761->group1.f7.PassWords,0x00,20);			//����
//				JParamInfo3761->group1.f7.PassWords[2]=0x00;
			}
		}
		printf("passwd=%02x%02x%02x\n\r",JParamInfo3761->group1.f7.PassWords[2],JParamInfo3761->group1.f7.PassWords[1],JParamInfo3761->group1.f7.PassWords[0]);
		return;
	}
	if (strcmp("hrt", argv[1]) == 0) {
		int HeartBeat;
		if (argc == 2) {
			printf("\n\r");
			HeartBeat = JParamInfo3761->group1.f1.HeartInterval;
			fprintf(stderr, "\n\rHeart %d\n\r", HeartBeat);
		} else {
			if (sscanf(argv[2], "%d", &HeartBeat)) {

				JParamInfo3761->group1.f1.HeartInterval=HeartBeat;
				printf("\n\r");
				printf("Heart %d", HeartBeat);
				printf("\n\r");
				JProgramInfo->FileSaveFlag.g1flag = 1;
//				memset(TempBuf,0,60);
//				sprintf((char*)TempBuf,"%s/JzhqPara.par",_PARADIR_);
//				NormalSaveFile((char*)TempBuf, &Jmemory->jzq, sizeof(Jmemory->jzq),JProgramInfo);
			}
		}
		return;
	}
	if (strcmp("local", argv[1]) == 0) {
		INT32U local;
		if (argc == 2) {
			local=0;
		} else {
			local=atoi(argv[2]);
		}
		JProgramInfo->CurrErc.Err60.ERCNo=60;
		JProgramInfo->CurrErc.Err60.len=9;
		memcpy(&JProgramInfo->CurrErc.Err60.Local[0],&local,4);
		JProgramInfo->stateflags.ErcFlg=60;
		return;
	}
	if (strcmp("mettm", argv[1]) == 0) {
		int MeterTime,prt;
		if (argc == 2) {
			printf("\n\r");
			MeterTime = JParamInfo3761->group5.f33.f33[0].CbInter;
			fprintf(stderr, "\n\rRead Time1 %d\n\r", MeterTime);
			MeterTime = JParamInfo3761->group5.f33.f33[1].CbInter;
			fprintf(stderr, "\n\rRead Time2 %d\n\r", MeterTime);
			MeterTime = JParamInfo3761->group5.f33.f33[2].CbInter;
			fprintf(stderr, "\n\rRead Time3 %d\n\r", MeterTime);
			MeterTime = JParamInfo3761->group5.f33.f33[3].CbInter;
			fprintf(stderr, "\n\rRead Time4 %d\n\r", MeterTime);
			MeterTime = JParamInfo3761->group5.f33.f33[4].CbInter;
			fprintf(stderr, "\n\rRead Time5 %d\n\r", MeterTime);
			MeterTime = JParamInfo3761->group5.f33.f33[5].CbInter;
			fprintf(stderr, "\n\rRead Time6 %d\n\r", MeterTime);
			MeterTime = JParamInfo3761->group5.f33.f33[30].CbInter;
			fprintf(stderr, "\n\rRead Time31 %d\n\r", MeterTime);
		} else {
			if (sscanf(argv[2], "%d-%d", &prt,&MeterTime)) {

				JParamInfo3761->group5.f33.f33[prt-1].CbInter=MeterTime;
				printf("\n\r");
				printf("Read Time %d", MeterTime);
				printf("\n\r");
				JProgramInfo->FileSaveFlag.g5flag = 1;
//				memset(TempBuf,0,60);
//				sprintf((char*)TempBuf,"%s/JzhqPara.par",_PARADIR_);
//				NormalSaveFile((char*)TempBuf, &Jmemory->jzq, sizeof(Jmemory->jzq),JProgramInfo);
			}
		}
		return;
	}
	if (strcmp("event", argv[1]) == 0) {
		int kk=0;
		for(kk=0; kk<JDataFileInfo->ErcEvt.EC1; kk++)
		printf("\n��Ҫ�¼�������%d ERC1:%d �¼�����: %d  ʱ�䣺%02x��%02x��%02x��%02xʱ%02x��",
						kk,JDataFileInfo->ErcEvt.EC1,JDataFileInfo->ErcEvt.ImpEvent[kk].Buff[0],
						JDataFileInfo->ErcEvt.ImpEvent[kk].Err4.Occur_Time.BCD05,
						JDataFileInfo->ErcEvt.ImpEvent[kk].Err4.Occur_Time.BCD04,
						JDataFileInfo->ErcEvt.ImpEvent[kk].Err4.Occur_Time.BCD03,
						JDataFileInfo->ErcEvt.ImpEvent[kk].Err4.Occur_Time.BCD02,
						JDataFileInfo->ErcEvt.ImpEvent[kk].Err4.Occur_Time.BCD01);
		for(kk=0; kk<JDataFileInfo->ErcEvt.EC2; kk++)
		printf("\nһ���¼�������%d ERC2:%d �¼�����: %d  ʱ�䣺%02x��%02x��%02x��%02xʱ%02x��",
						kk,JDataFileInfo->ErcEvt.EC2,JDataFileInfo->ErcEvt.NorEvent[kk].Buff[0],
						JDataFileInfo->ErcEvt.NorEvent[kk].Err4.Occur_Time.BCD05,
						JDataFileInfo->ErcEvt.NorEvent[kk].Err4.Occur_Time.BCD04,
						JDataFileInfo->ErcEvt.NorEvent[kk].Err4.Occur_Time.BCD03,
						JDataFileInfo->ErcEvt.NorEvent[kk].Err4.Occur_Time.BCD02,
						JDataFileInfo->ErcEvt.NorEvent[kk].Err4.Occur_Time.BCD01);

		return;
	}

	if (strcmp("batt", argv[1]) == 0)
	{
		INT8U batt_state;
		if(argc == 3)
		{
			batt_state=atoi(argv[2]);
			gpio_write("gpoBAT_SWITCH",batt_state);
			if(batt_state == 1)
				printf("\n Battery is ON.");
			if(batt_state == 0)
				printf("\n Battery is OFF.");
		}
		else
		{
			printf("Example : jSet batt 1 or 0");
		}
		return;
	}


	if(strcmp("bg", argv[1])==0)
	{
		int on=1, off=0, fd=-1;
		if((fd = open("/dev/gpoLCD_LIGHT", O_RDWR | O_NDELAY)) > 0)
		{
			write(fd,&on,sizeof(int));
			close(fd);
		}
		system("sleep 5");
		if((fd = open("/dev/gpoLCD_LIGHT", O_RDWR | O_NDELAY)) > 0)
		{
			write(fd,&off,sizeof(int));
			close(fd);
		}
	return ;
	}

	if(strcmp("gprsled", argv[1])==0)
	{

		int fd=0,data, stat;
		sscanf(argv[2], "%d", &stat);
		if((fd = open("/dev/gpoGPRS_POWER", O_RDWR | O_NDELAY)) == -1)
		{
			switch(stat)
			{
				case 1://��ʾ��

					data = 0;
					write(fd,&data,sizeof(int));
					break;
				default://��

					data = 1;
					write(fd,&data,sizeof(int));
					break;
			}
			close(fd);
		}
		return;
	}
	if (strcmp("tst", argv[1]) == 0) {
		if (argc == 2) {
			printf("JProgramInfo->mainData.Prt_Flag=%d\n",JProgramInfo->mainData.Prt_Flag);
			printf("Print Set On\n\r");
			printf("3:jEvent	5:jIfrcom	6:jSaveTask	7:jLedTask	8:jRead485\n\r");
			printf("9:jWeihu	15:jACSampling  16:jReadZB_DX	50:all\n\r\n");
			printf("Print Set Off\n\r");
			printf("103:jEvent	105:jIfrcom	106:jSaveTask 	107:jLedTask	108:jRead485\n\r");
			printf("109:jWeihu	115:jACSampling  116:jReadZB_DX		150:all\n\r");
		} else {
			int st;
			if (sscanf(argv[2], "%d", &st)) {
				JProgramInfo->mainData.Prt_Flag = st;
			}
		}
		return;
	}
	typedef struct
	{
		F65 f65;
		F66 f66;
		F67 f67;
		F68 f68;
	}OneTaskInf;
	int  CreateTskFile(int tskn)//type 1�ն���    2Сʱ����
	{
		INT8U MCMP8U[8] = { 0xff, 0x01, 0x03, 0x07, 0x0f, 0x1f, 0x3f, 0x7f };
		OneTaskInf onetsk;
		TS ts;
		int i,pncount=0,itemcount;
		if ((tskn<=0)||(tskn>=Task2_Max) )
			return 0;
		for(i=0;i<PointMax;i++)
		{
			if(JParamInfo3761->group2.f10[i].Status==1)
				pncount++;
		}
		itemcount = pncount/8;
		if (pncount%8>0)
			itemcount = itemcount + 1;
		TSGet(&ts);
		memset(&onetsk,0,sizeof(OneTaskInf));

		onetsk.f66.Interval = 0x81;

		onetsk.f66.Post_Time[0] = 0x00;//��
		onetsk.f66.Post_Time[1] = 0x00;//��
		onetsk.f66.Post_Time[2] = 0x01;//ʱ
		onetsk.f66.Post_Time[3] = ((ts.Day%10)) |((ts.Day/10)<<4)  ;//��
		onetsk.f66.Post_Time[4] = ((ts.Month %10)) |((ts.Month /10)<<4)  ;//��
		onetsk.f66.Post_Time[5] = (((ts.Year-2000)%10)) |(((ts.Year-2000)/10)<<4)  ;//��
		onetsk.f66.R = 0x60;
		onetsk.f66.Count = itemcount;
		printf("%d %d %d  ----- %02x %02x %02x     itemcount=%d",
				ts.Day,ts.Month,ts.Year,
				onetsk.f66.Post_Time[3],
				onetsk.f66.Post_Time[4],
				onetsk.f66.Post_Time[5],
				itemcount);
		for(i=1;i<itemcount;i++)//if itemcount = 5  then   1 ,2 ,3 ,4
		{
			onetsk.f66.Flag[i-1][0] = 0xff;
			onetsk.f66.Flag[i-1][1] = i;
			onetsk.f66.Flag[i-1][2] = 0x01;
			onetsk.f66.Flag[i-1][3] = 0x14;
		}

		if (pncount>0)
		{
			onetsk.f66.Flag[itemcount-1][0] = MCMP8U[pncount%8];
			onetsk.f66.Flag[itemcount-1][1] = itemcount;
			onetsk.f66.Flag[itemcount-1][2] = 0x01;
			onetsk.f66.Flag[itemcount-1][3] = 0x14;
		}
		onetsk.f68.IsRun=0x55;
		onetsk.f67.IsRun=0xAA;
		memset(&onetsk.f65,0,sizeof(F65));
		JParamInfo3761->group9.f68[tskn-1] = onetsk.f68;
		JParamInfo3761->group9.f67[tskn-1] = onetsk.f67;
		JParamInfo3761->group9.f66[tskn-1] = onetsk.f66;
		JParamInfo3761->group9.f65[tskn-1] = onetsk.f65;
		JProgramInfo->FileSaveFlag.g9flag = 1;
//		memset(filename,0,50);
//		sprintf(filename,"/nor/para/TaskPara.par");
//		NormalSaveFile(filename,(INT8U *)&onetsk,sizeof(OneTaskInf),JProgramInfo);
		return 1;
	}
  	if (strcmp("setsk", argv[1]) == 0) {
		if (argc == 2) {
			return;
		} else
		{
			int tsk;
			int tsktype;
			if (sscanf(argv[2], "%d", &tsk))
			{
				if (sscanf(argv[3],"%d",&tsktype))
				{
  					if (tsktype == 1)// 1 	�ն�������	F161�ն��������й�����ʾֵ
						CreateTskFile(tsk);
				}
			}
		}
		return;
	}

	if (strcmp("task", argv[1]) == 0)
	{
		int tsk, i;
		if (sscanf(argv[2], "%d", &tsk))
		{
			for (i = 0; i < Task1_Max; i++)
			{
				if (JParamInfo3761->group9.f67[i].IsRun!=0x55)
					continue;
				if (i != tsk - 1)
					continue;
				printf("\n\rjTaskPrt INT-QI %d-%d",JParamInfo3761->group9.f65[i].Interval>>6,JParamInfo3761->group9.f65[i].Interval&0x3f);
				printf("\n\rjTaskPrt R-Cnt %d-%d\n\r",JParamInfo3761->group9.f65[i].R,JParamInfo3761->group9.f65[i].Count);
			}
			for (i = 0; i < Task2_Max; i++)
			{
				if (JParamInfo3761->group9.f68[i].IsRun!=0x55) {
					continue;
				}

				if (i != tsk - 1) {
					continue;
				}
				printf("\n\rjTaskPrt2 ��ʱ�ϱ����ڵ�λ��%d(0~3 ��ʱ����)  ��ʱ�ϱ����ڣ�%d",
						JParamInfo3761->group9.f66[i].Interval>>6,
						JParamInfo3761->group9.f66[i].Interval&0x3f);
				printf("\n\rjTaskPrt2 R-Cnt %d-%d\n\r",JParamInfo3761->group9.f66[i].R,JParamInfo3761->group9.f66[i].Count);
				printf("\n �����Ƿ���Ч = %02x (0x55 ��Ч   0xaa ��Ч)",JParamInfo3761->group9.f68[i].IsRun);
				printf("\n\r���ͻ�׼ʱ�� = %02x %02x %02x %02x %02x %02x",JParamInfo3761->group9.f66[i].Post_Time[0],
																	   JParamInfo3761->group9.f66[i].Post_Time[1],
																	   JParamInfo3761->group9.f66[i].Post_Time[2],
																	   JParamInfo3761->group9.f66[i].Post_Time[3],
																	   JParamInfo3761->group9.f66[i].Post_Time[4],
																	   JParamInfo3761->group9.f66[i].Post_Time[5]);
				//printf("\n\ri=%d",i);

			}
		}

		return;
	}
	if (strcmp("taskset", argv[1]) == 0) {
		int i;
		if (argc == 2) {
			for (i = 0; i < Task2_Max; i++) {
				printf("\nJProgramInfo->task2_Delay_Count[%d]=%d",i,JProgramInfo->task2_Delay_Count[i]);
				//JParamInfo3761->group9.f68[i].IsRun=0x55;
			}
		} else {
			for (i = 0; i < Task1_Max; i++) {
				JProgramInfo->task1_Delay_Count[i]=atoi(argv[2]);
			}
			for (i = 0; i < Task2_Max; i++) {
				JProgramInfo->task2_Delay_Count[i]=atoi(argv[2]);
				//JParamInfo3761->group9.f68[i].IsRun=0x55;
			}
		}
		return;
	}

	if (strcmp("tasken", argv[1]) == 0) {
		int i;
		if (argc == 2) {
			for (i = 0; i < Task1_Max; i++) {
				JParamInfo3761->group9.f67[i].IsRun=0x55;
			}
			for (i = 0; i < Task2_Max; i++) {
				JParamInfo3761->group9.f68[i].IsRun=0x55;
			}
		} else {
			int tsk;
			if (sscanf(argv[2], "%d", &tsk)) {
				JParamInfo3761->group9.f67[tsk-1].IsRun=0x55;
				JParamInfo3761->group9.f68[tsk-1].IsRun=0x55;
			}
		}
		JProgramInfo->FileSaveFlag.g9flag = 1;
//		memset(TempBuf,0,60);
//		sprintf((char*)TempBuf,"%s/TaskPara.par",_PARADIR_);
//		NormalSaveFile((char*)TempBuf, &Jmemory->jzq.Task, sizeof(Jmemory->jzq.Task),JProgramInfo);
		return;
	}

	if (strcmp("taskdisen", argv[1]) == 0) {
		int i;
		if (argc == 2) {
			for (i = 0; i < Task1_Max; i++) {
				JParamInfo3761->group9.f67[i].IsRun=0xaa;
			}
			for (i = 0; i < Task2_Max; i++) {
				JParamInfo3761->group9.f68[i].IsRun=0xaa;
			}
		} else {
			int tsk;
			if (sscanf(argv[2], "%d", &tsk)) {
				JParamInfo3761->group9.f67[tsk-1].IsRun=0xaa;
				JParamInfo3761->group9.f68[tsk-1].IsRun=0xaa;
			}
		}
		JProgramInfo->FileSaveFlag.g9flag = 1;
//		memset(TempBuf,0,60);
//		sprintf((char*)TempBuf,"%s/TaskPara.par",_PARADIR_);
//		NormalSaveFile((char*)TempBuf, &Jmemory->jzq.Task, sizeof(Jmemory->jzq.Task),JProgramInfo);
		return;
	}

	if (strcmp("dataset", argv[1]) == 0) {
		int i,j;
		if (argc == 2) {

		} else {
			TS ts;
			TSGet(&ts);
			for(i=0;i<atoi(argv[2]);i++)
			{
				memset(TempBuf,0,60);
				sprintf((char*)TempBuf,"/nand/DataCurr/%04d/",i+1);
				if (access((char*)TempBuf,0)!=0)//��Ŀ¼�����ڣ��ȴ���
				{
					memset(TempBuf,0,60);
					sprintf((char*)TempBuf,"%s /nand/DataCurr/%04d/",_CMDMKDIR_,i+1);
					syscmd((char*)TempBuf,JProgramInfo);
					delay(10);
				}
				memset(TempBuf,0,60);
				sprintf((char*)TempBuf,"/nand/DataDay/%04d/",i+1);//��Ŀ¼�����ڣ��ȴ���
				if (access((char*)TempBuf,0)!=0)
				{
					memset(TempBuf,0,60);
					sprintf((char*)TempBuf,"%s /nand/DataDay/%04d/",_CMDMKDIR_,i+1);
					syscmd((char*)TempBuf,JProgramInfo);
					delay(10);
				 }
				memset(TempBuf,0,60);
				sprintf((char*)TempBuf,"/nand/DataMonth/%04d/",i+1);//��Ŀ¼�����ڣ��ȴ���
				if (access((char*)TempBuf,0)!=0)
				{
					memset(TempBuf,0,60);
					sprintf((char*)TempBuf,"%s /nand/DataMonth/%04d/",_CMDMKDIR_,i+1);
					syscmd((char*)TempBuf,JProgramInfo);
					delay(10);
				 }
				memset(&smfile,0,sizeof(smfile));
				smfile.ts=ts;
				smfile.sm.CaijiQiNo=JParamInfo3761->group2.f10[i].CjqNo-1;
				smfile.sm.MeterNo=JParamInfo3761->group2.f10[i].MeterNo;
				smfile.sm.datas[0].flg.Dataflag[0]=0x1f;
				smfile.sm.datas[0].flg.Dataflag[1]=0x90;
				smfile.sm.datas[0].flg.ReadFlg=1;
				smfile.sm.datas[0].flg.DataLen=25;
				memset(&smfile.sm.datas[0].datas[0],0,DataLenMax);
				for(j=0;j<20;j++)
				{
					if ((j+1)%4==1)
						smfile.sm.datas[0].datas[j]=0x00;
					else if ((j+1)%4==0)
						smfile.sm.datas[0].datas[j]=0x00;
					else smfile.sm.datas[0].datas[j]=0x02;
				}
				//wyq
//				memset(TempBuf,0,60);
//				sprintf((char*)TempBuf,"/nand/DataCurr/%04d/curr.dat",i+1);
//				SaveFile((char*)TempBuf,(INT8U *)&smfile,sizeof(TS)+sizeof(INT8U)*2+1*sizeof(DataFlg),JProgramInfo);
			}
		}
		printf("end\n\r");
		return;
	}

	if (strcmp("year", argv[1]) == 0) {
		TS ts;
		TSGet(&ts);
		JDataFileInfo->data485[0+PortBegNum].ts=ts;
		JDataFileInfo->data485[1+PortBegNum].ts=ts;
		JDataFileInfo->data485[2+PortBegNum].ts=ts;
		JDataFileInfo->data485[4].ts=ts;
		//wyq
//		memset(TempBuf,0,60);
//		sprintf((char*)TempBuf,"%s/JzhqPara.par",_PARADIR_);
//		NormalSaveFile((char*)TempBuf, &Jmemory->jzq, sizeof(Jmemory->jzq),JProgramInfo);

		return;
	}
	if (strcmp("mon1", argv[1]) == 0) {
		if (argc == 2) {
			printf("\n\rJDataFileInfo->data485[0].ts=%02d-%02d-%02d %02d:%02d\n\r", JDataFileInfo->data485[0].ts.Year,JDataFileInfo->data485[0].ts.Month,
					JDataFileInfo->data485[0].ts.Day,JDataFileInfo->data485[0].ts.Hour,JDataFileInfo->data485[0].ts.Minute);
			printf("\n\rJDataFileInfo->data485[1].ts=%02d-%02d-%02d %02d:%02d\n\r", JDataFileInfo->data485[1].ts.Year,JDataFileInfo->data485[1].ts.Month,
					JDataFileInfo->data485[1].ts.Day,JDataFileInfo->data485[1].ts.Hour,JDataFileInfo->data485[1].ts.Minute);
			printf("\n\rJDataFileInfo->data485[2].ts=%02d-%02d-%02d %02d:%02d\n\r", JDataFileInfo->data485[2].ts.Year,JDataFileInfo->data485[2].ts.Month,
					JDataFileInfo->data485[2].ts.Day,JDataFileInfo->data485[2].ts.Hour,JDataFileInfo->data485[2].ts.Minute);
			printf("\n\rJDataFileInfo->data485[3].ts=%02d-%02d-%02d %02d:%02d\n\r", JDataFileInfo->data485[3].ts.Year,JDataFileInfo->data485[3].ts.Month,
					JDataFileInfo->data485[3].ts.Day,JDataFileInfo->data485[3].ts.Hour,JDataFileInfo->data485[3].ts.Minute);
			printf("\n\rJDataFileInfo->data485[4].ts=%02d-%02d-%02d %02d:%02d\n\r", JDataFileInfo->data485[4].ts.Year,JDataFileInfo->data485[4].ts.Month,
					JDataFileInfo->data485[4].ts.Day,JDataFileInfo->data485[4].ts.Hour,JDataFileInfo->data485[4].ts.Minute);
			printf("\n\rJDataFileInfo->data485[5].ts=%02d-%02d-%02d %02d:%02d\n\r", JDataFileInfo->data485[5].ts.Year,JDataFileInfo->data485[5].ts.Month,
					JDataFileInfo->data485[5].ts.Day,JDataFileInfo->data485[5].ts.Hour,JDataFileInfo->data485[5].ts.Minute);
		} else {
			int mon,prot;
			if (sscanf(argv[2], "%d-%d",&prot, &mon)) {
				JDataFileInfo->data485[prot-1].ts.Month = mon;
				//wyq
//				memset(TempBuf,0,60);
//				sprintf((char*)TempBuf,"%s/JzhqPara.par",_PARADIR_);
//				NormalSaveFile((char*)TempBuf, &Jmemory->jzq, sizeof(Jmemory->jzq),JProgramInfo);
			}
		}
		return;
	}
	if (strcmp("485info", argv[1]) == 0)
	{
		printf("\n485I����������: %d",JDataFileInfo->data485[0+PortBegNum].MeterNum);
		printf("  %02d-%02d-%02d %02d:%02d\n\r",
				JDataFileInfo->data485[0+PortBegNum].ts.Year,
				JDataFileInfo->data485[0+PortBegNum].ts.Month,
				JDataFileInfo->data485[0+PortBegNum].ts.Day,
				JDataFileInfo->data485[0+PortBegNum].ts.Hour,
				JDataFileInfo->data485[0+PortBegNum].ts.Minute);
		printf("\n485II����������: %d",JDataFileInfo->data485[1+PortBegNum].MeterNum);
		printf("  %02d-%02d-%02d %02d:%02d\n\r",
				JDataFileInfo->data485[1+PortBegNum].ts.Year,
				JDataFileInfo->data485[1+PortBegNum].ts.Month,
				JDataFileInfo->data485[1+PortBegNum].ts.Day,
				JDataFileInfo->data485[1+PortBegNum].ts.Hour,
				JDataFileInfo->data485[1+PortBegNum].ts.Minute);
		printf("\nZB����������: %d",JDataFileInfo->data485[29+PortBegNum].MeterNum);
		printf(" %02d-%02d-%02d %02d:%02d\n\r",
				JDataFileInfo->data485[2+PortBegNum].ts.Year,
				JDataFileInfo->data485[2+PortBegNum].ts.Month,
				JDataFileInfo->data485[29+PortBegNum].ts.Day,
				JDataFileInfo->data485[29+PortBegNum].ts.Hour,
				JDataFileInfo->data485[29+PortBegNum].ts.Minute);
		return;
	}
	if (strcmp("mon2", argv[1]) == 0) {
		if (argc == 2) {
			printf("\n\rJDataFileInfo->data485[0+PortBegNum].ts=%02d-%02d-%02d %02d:%02d\n\r", JDataFileInfo->data485[0+PortBegNum].ts.Year,JDataFileInfo->data485[0+PortBegNum].ts.Month,
					JDataFileInfo->data485[0+PortBegNum].ts.Day,JDataFileInfo->data485[0+PortBegNum].ts.Hour,JDataFileInfo->data485[0+PortBegNum].ts.Minute);
			printf("\n\rJDataFileInfo->data485[1+PortBegNum].ts=%02d-%02d-%02d %02d:%02d\n\r", JDataFileInfo->data485[1+PortBegNum].ts.Year,JDataFileInfo->data485[1+PortBegNum].ts.Month,
					JDataFileInfo->data485[1+PortBegNum].ts.Day,JDataFileInfo->data485[1+PortBegNum].ts.Hour,JDataFileInfo->data485[1+PortBegNum].ts.Minute);
			printf("\n\rJDataFileInfo->data485[2+PortBegNum].ts=%02d-%02d-%02d %02d:%02d\n\r", JDataFileInfo->data485[2+PortBegNum].ts.Year,JDataFileInfo->data485[2+PortBegNum].ts.Month,
					JDataFileInfo->data485[2+PortBegNum].ts.Day,JDataFileInfo->data485[2+PortBegNum].ts.Hour,JDataFileInfo->data485[2+PortBegNum].ts.Minute);
			printf("\n\rJDataFileInfo->data485[3+PortBegNum].ts=%02d-%02d-%02d %02d:%02d\n\r", JDataFileInfo->data485[3+PortBegNum].ts.Year,JDataFileInfo->data485[3+PortBegNum].ts.Month,
					JDataFileInfo->data485[3+PortBegNum].ts.Day,JDataFileInfo->data485[3+PortBegNum].ts.Hour,JDataFileInfo->data485[3+PortBegNum].ts.Minute);
			printf("\n\rJDataFileInfo->data485[4+PortBegNum].ts=%02d-%02d-%02d %02d:%02d\n\r", JDataFileInfo->data485[4+PortBegNum].ts.Year,JDataFileInfo->data485[4+PortBegNum].ts.Month,
					JDataFileInfo->data485[4+PortBegNum].ts.Day,JDataFileInfo->data485[4+PortBegNum].ts.Hour,JDataFileInfo->data485[4+PortBegNum].ts.Minute);
		} else {
			int mon;
			if (sscanf(argv[2], "%d", &mon)) {
				JDataFileInfo->data485[1+PortBegNum].ts.Month = mon;
				//wyq
//				memset(TempBuf,0,60);
//				sprintf((char*)TempBuf,"%s/JzhqPara.par",_PARADIR_);
//				NormalSaveFile((char*)TempBuf, &Jmemory->jzq, sizeof(Jmemory->jzq),JProgramInfo);
			}
		}
		return;
	}

	if (strcmp("mon3", argv[1]) == 0) {
		if (argc == 2) {
			printf("\n\rJDataFileInfo->data485[0+PortBegNum].ts=%02d-%02d-%02d %02d:%02d\n\r", JDataFileInfo->data485[0+PortBegNum].ts.Year,JDataFileInfo->data485[0+PortBegNum].ts.Month,
					JDataFileInfo->data485[0+PortBegNum].ts.Day,JDataFileInfo->data485[0+PortBegNum].ts.Hour,JDataFileInfo->data485[0+PortBegNum].ts.Minute);
			printf("\n\rJDataFileInfo->data485[1+PortBegNum].ts=%02d-%02d-%02d %02d:%02d\n\r", JDataFileInfo->data485[1+PortBegNum].ts.Year,JDataFileInfo->data485[1+PortBegNum].ts.Month,
					JDataFileInfo->data485[1+PortBegNum].ts.Day,JDataFileInfo->data485[1+PortBegNum].ts.Hour,JDataFileInfo->data485[1+PortBegNum].ts.Minute);
			printf("\n\rJDataFileInfo->data485[2+PortBegNum].ts=%02d-%02d-%02d %02d:%02d\n\r", JDataFileInfo->data485[2+PortBegNum].ts.Year,JDataFileInfo->data485[2+PortBegNum].ts.Month,
					JDataFileInfo->data485[2+PortBegNum].ts.Day,JDataFileInfo->data485[2+PortBegNum].ts.Hour,JDataFileInfo->data485[2+PortBegNum].ts.Minute);
		} else {
			int mon;
			if (sscanf(argv[2], "%d", &mon)) {
				JDataFileInfo->data485[2+PortBegNum].ts.Month = mon;
				//wyq
//				memset(TempBuf,0,60);
//				sprintf((char*)TempBuf,"%s/JzhqPara.par",_PARADIR_);
//				NormalSaveFile((char*)TempBuf, &Jmemory->jzq, sizeof(Jmemory->jzq),JProgramInfo);
			}
		}
		return;
	}

	if (strcmp("day", argv[1]) == 0) {
		if (argc == 2) {
			printf("\n\rJDataFileInfo->data485[0+PortBegNum].ts=%02d-%02d-%02d %02d:%02d\n\r", JDataFileInfo->data485[0+PortBegNum].ts.Year,JDataFileInfo->data485[0+PortBegNum].ts.Month,
					JDataFileInfo->data485[0+PortBegNum].ts.Day,JDataFileInfo->data485[0+PortBegNum].ts.Hour,JDataFileInfo->data485[0+PortBegNum].ts.Minute);
			printf("\n\rJDataFileInfo->data485[1+PortBegNum].ts=%02d-%02d-%02d %02d:%02d\n\r", JDataFileInfo->data485[1+PortBegNum].ts.Year,JDataFileInfo->data485[1+PortBegNum].ts.Month,
					JDataFileInfo->data485[1+PortBegNum].ts.Day,JDataFileInfo->data485[1+PortBegNum].ts.Hour,JDataFileInfo->data485[1+PortBegNum].ts.Minute);
			printf("\n\rJDataFileInfo->data485[2+PortBegNum].ts=%02d-%02d-%02d %02d:%02d\n\r", JDataFileInfo->data485[2+PortBegNum].ts.Year,JDataFileInfo->data485[2+PortBegNum].ts.Month,
					JDataFileInfo->data485[2+PortBegNum].ts.Day,JDataFileInfo->data485[2+PortBegNum].ts.Hour,JDataFileInfo->data485[2+PortBegNum].ts.Minute);
			printf("\n\rJDataFileInfo->data485[4].ts=%02d-%02d-%02d %02d:%02d\n\r", JDataFileInfo->data485[4].ts.Year,JDataFileInfo->data485[4].ts.Month,
					JDataFileInfo->data485[4].ts.Day,JDataFileInfo->data485[4].ts.Hour,JDataFileInfo->data485[4].ts.Minute);
			printf("\n\rJDataFileInfo->data485[5].ts=%02d-%02d-%02d %02d:%02d\n\r", JDataFileInfo->data485[5].ts.Year,JDataFileInfo->data485[5].ts.Month,
					JDataFileInfo->data485[5].ts.Day,JDataFileInfo->data485[5].ts.Hour,JDataFileInfo->data485[5].ts.Minute);
		} else {
			int day;
			if (sscanf(argv[2], "%d", &day)) {
				JDataFileInfo->data485[0+PortBegNum].ts.Day = day;
				JDataFileInfo->data485[1+PortBegNum].ts.Day = day;
				JDataFileInfo->data485[2+PortBegNum].ts.Day = day;
				JDataFileInfo->data485[4].ts.Day = day;
				//wyq
//				memset(TempBuf,0,60);
//				sprintf((char*)TempBuf,"%s/JzhqPara.par",_PARADIR_);
//				NormalSaveFile((char*)TempBuf, &Jmemory->jzq, sizeof(Jmemory->jzq),JProgramInfo);
			}
		}
		return;
	}

	if (strcmp("hour", argv[1]) == 0) {
		if (argc == 2) {
			printf("\n\rJDataFileInfo->data485[0+PortBegNum].ts=%02d-%02d-%02d %02d:%02d\n\r", JDataFileInfo->data485[0+PortBegNum].ts.Year,JDataFileInfo->data485[0+PortBegNum].ts.Month,
					JDataFileInfo->data485[0+PortBegNum].ts.Day,JDataFileInfo->data485[0+PortBegNum].ts.Hour,JDataFileInfo->data485[0+PortBegNum].ts.Minute);
			printf("\n\rJDataFileInfo->data485[1+PortBegNum].ts=%02d-%02d-%02d %02d:%02d\n\r", JDataFileInfo->data485[1+PortBegNum].ts.Year,JDataFileInfo->data485[1+PortBegNum].ts.Month,
					JDataFileInfo->data485[1+PortBegNum].ts.Day,JDataFileInfo->data485[1+PortBegNum].ts.Hour,JDataFileInfo->data485[1+PortBegNum].ts.Minute);
			printf("\n\rJDataFileInfo->data485[2+PortBegNum].ts=%02d-%02d-%02d %02d:%02d\n\r", JDataFileInfo->data485[2+PortBegNum].ts.Year,JDataFileInfo->data485[2+PortBegNum].ts.Month,
					JDataFileInfo->data485[2+PortBegNum].ts.Day,JDataFileInfo->data485[2+PortBegNum].ts.Hour,JDataFileInfo->data485[2+PortBegNum].ts.Minute);
			printf("\n\rJDataFileInfo->data485[3+PortBegNum].ts=%02d-%02d-%02d %02d:%02d\n\r", JDataFileInfo->data485[3+PortBegNum].ts.Year,JDataFileInfo->data485[3+PortBegNum].ts.Month,
					JDataFileInfo->data485[3+PortBegNum].ts.Day,JDataFileInfo->data485[3+PortBegNum].ts.Hour,JDataFileInfo->data485[3+PortBegNum].ts.Minute);
			printf("\n\rJDataFileInfo->data485[4+PortBegNum].ts=%02d-%02d-%02d %02d:%02d\n\r", JDataFileInfo->data485[4+PortBegNum].ts.Year,JDataFileInfo->data485[4+PortBegNum].ts.Month,
					JDataFileInfo->data485[4+PortBegNum].ts.Day,JDataFileInfo->data485[4+PortBegNum].ts.Hour,JDataFileInfo->data485[4+PortBegNum].ts.Minute);
		} else {
			int hour;
			if (sscanf(argv[2], "%d", &hour)) {
				JDataFileInfo->data485[0+PortBegNum].ts.Hour = hour;
				JDataFileInfo->data485[1+PortBegNum].ts.Hour = hour;
				JDataFileInfo->data485[2+PortBegNum].ts.Hour = hour;
				//wyq
//				memset(TempBuf,0,60);
//				sprintf((char*)TempBuf,"%s/JzhqPara.par",_PARADIR_);
//				NormalSaveFile((char*)TempBuf, &Jmemory->jzq, sizeof(Jmemory->jzq),JProgramInfo);
			}
		}
		return;
	}

	if (strcmp("tj", argv[1]) == 0) {
		if (argc == 2) {
			printf("\n\relcbrd=%02d\n\r", JProgramInfo->BoardElecState);
			printf("poweon=%02d\n\r", JProgramInfo->PowerOnMessage);
			printf("powoff=%02d\n\r", JProgramInfo->PowerOFFMessage);
			printf("dgdtim=%02d\n\r", JDataFileInfo->DayRunTj.GdTime);
			printf("ygdtim=%02d\n\r", JDataFileInfo->YueRunTj.GdTime);
			printf("drstim=%02d\n\r", JDataFileInfo->DayRunTj.ResetTime);
			printf("yrstim=%02d\n\r", JDataFileInfo->YueRunTj.ResetTime);
			printf("dliang=%02d\n\r", JDataFileInfo->DayRunTj.LiuLiang);
			printf("yliang=%02d\n\r", JDataFileInfo->YueRunTj.LiuLiang);
		}
		else
		{
			JDataFileInfo->DayRunTj.GdTime=0;
			JDataFileInfo->YueRunTj.GdTime=0;
			JDataFileInfo->DayRunTj.ResetTime=0;
			JDataFileInfo->YueRunTj.ResetTime=0;
			JDataFileInfo->DayRunTj.LiuLiang=0;
			JDataFileInfo->YueRunTj.LiuLiang=0;

		}
		return;
	}

	if (strcmp("exeno", argv[1]) == 0) {
		if (argc == 2) {

		} else {
			int no;
			if (sscanf(argv[2], "%d", &no)) {
				JProgramInfo->ExcuteNo = no;
				//wyq
//				memset(TempBuf,0,60);
//				sprintf((char*)TempBuf,"%s/JzhqPara.par",_PARADIR_);
//				NormalSaveFile((char*)TempBuf, &Jmemory->jzq, sizeof(Jmemory->jzq),JProgramInfo);
			}
		}
		return;
	}

	if (strcmp("dev", argv[1]) == 0) {
		if (argc == 2) {
			printf("\n\rJConfigInfo->jzqpara.DevFlg=%d\n\r", JConfigInfo->jzqpara.DevFlg);
		} else {
			int devflg;
			if (sscanf(argv[2], "%d", &devflg)) {
				JConfigInfo->jzqpara.DevFlg = devflg;
				JProgramInfo->FileSaveFlag.jzqflag = 1;
//				memset(TempBuf,0,60);
//				sprintf((char*)TempBuf,"%s/JzhqPara.par",_PARADIR_);
//				NormalSaveFile((char*)TempBuf, &Jmemory->jzq, sizeof(Jmemory->jzq),JProgramInfo);
			}
		}
		return;
	}

	if (strcmp("wircha", argv[1]) == 0) {
		if (argc == 2) {
			printf("\n\rwirchannel=%d\n\r", (JConfigInfo->jzqpara.DevFlg>>4)&0x0f);
		} else {
			int devflg;
			if (sscanf(argv[2], "%d", &devflg)) {
				JConfigInfo->jzqpara.DevFlg = (devflg<<4);
				JProgramInfo->FileSaveFlag.jzqflag = 1;
//				memset(TempBuf,0,60);
//				sprintf((char*)TempBuf,"%s/JzhqPara.par",_PARADIR_);
//				NormalSaveFile((char*)TempBuf, &Jmemory->jzq, sizeof(Jmemory->jzq),JProgramInfo);
			}
		}
		return;
	}

	if (strcmp("baud", argv[1]) == 0) {
		//jSet meter �������-״̬ ��ַ �˿� ��Լ ������ �ɼ�����ַ �澯��
		INT32U bauds,port;
		if (argc == 2) {
			printf("jSet baud %s\n\r","�˿ں�-�ز�������");

		} else {
			if (sscanf(argv[2], "%d-%d", &port,&bauds)) {
				memcpy(&JParamInfo3761->group5.f34.Module[port-1].BPS[0],&bauds,4);
			}
		}
		return;
	}

	if (strcmp("metupd", argv[1]) == 0) {
		int j;
		i=0;
		for (j = 0; j <PointMax; j++)//��������Ϣ
		{
			JParamInfo3761->group2.f10[j].Type=atoi(argv[2]);
			JProgramInfo->FileSaveFlag.F10_ChangedSave[j] = 1;
//			if (((j%SaveNum)==0)&&(j>0))
//			{
//				memset(TempBuf,0,60);
//				sprintf((char*)TempBuf,"%s/Ammeter%04d.par",_PARADIR_,((j-SaveNum)/SaveNum)+1);
//				NormalSaveFile((char*)TempBuf,(INT8U *)&Jmemory->Points.pt[j-SaveNum-(j%SaveNum)],sizeof(Jmemory->Points.pt[j-SaveNum-(j%SaveNum)])*SaveNum,JProgramInfo);
//				delay(10);
//			}
		}
		return;
	}
	if (strcmp("feilv", argv[1]) == 0) {
		int j;
		i=0;
		for (j = 0; j <48; j++)//��������Ϣ
			printf("\nJmemory->jzq.f21.FLTime[%d] = %d",j,JParamInfo3761->group3.f21.FLTime[j]);
		return;
	}
	if (strcmp("addmeter", argv[1]) == 0)
	{
		int k, metertotalnum=0;
		char cmd[100];
		memset(cmd,0,100);
		if (argc == 3)
		{
			sscanf(argv[2], "%d", &metertotalnum);
			for(k=0;k<metertotalnum;k++)
			{
				//jSet meter �������-״̬ [����ַ �˿� ��Լ ������ �ɼ�����ַ ������ �澯��]
				sprintf(cmd,"jSet meter %d-1 %012d 6 30 9600 00000000 9 0",k+1,k+1);
				system(cmd);
			}
		}
		return;
	}
	if (strcmp("meter", argv[1]) == 0) {
		//jSet meter �������-״̬ ��ַ �˿� ��Լ ������ �ɼ�����ַ �澯��
		INT8U dizhi[12]={0},metaddr[6];
		if (argc == 2) {
			printf("jSet meter %s\n\r","�������-״̬ [����ַ �˿� ��Լ ������ �ɼ�����ַ ������ �澯��]");

		} else {
			int meter,stat,alrm=31;
			if (sscanf(argv[2], "%d-%d", &meter,&stat)) {
				if (meter==0)
				{
					meter=1;
				}
				memset(metaddr,0,6);
				if (argc>=4)
				{
					for(i=0;i<12;i++)
						dizhi[i]='0';
					for(i=0;i<strlen(argv[3]);i++)
						dizhi[11-i]=argv[3][strlen(argv[3])-i-1];
					ASCToBCD(dizhi,12,&metaddr[0]);
					for(i=0;i<6;i++)
						JParamInfo3761->group2.f10[meter-1].Address[i]=metaddr[5-i];
				}

				if (argc>=5)
					JParamInfo3761->group2.f10[meter-1].port=atoi(argv[4]);
				if (argc>=6)
					JParamInfo3761->group2.f10[meter-1].ConnectType=atoi(argv[5]);
				if (argc>=7)
					JParamInfo3761->group2.f10[meter-1].baudrate=atoi(argv[6])/300;
				memset(metaddr,0,6);
				if (argc>=8)
				{
					for(i=0;i<12;i++)
						dizhi[i]='0';
					for(i=0;i<strlen(argv[7]);i++)
						dizhi[11-i]=argv[7][strlen(argv[7])-i-1];
					ASCToBCD(dizhi,12,&metaddr[0]);
					for(i=0;i<6;i++)
						JParamInfo3761->group2.f10[meter-1].CaijiqiAddress[i]=metaddr[5-i];
				}

				if (argc>=9)
					JParamInfo3761->group2.f10[meter-1].Type=atoi(argv[8]);
				if (argc>=10)
					alrm=atoi(argv[9]);
				JParamInfo3761->group2.f10[meter-1].Status=stat;
				printf("point cjqno=%d,meterno=%d,type=%d,alrm=%02x,addr=%02x%02x%02x%02x%02x%02x\n\r",JParamInfo3761->group2.f10[meter-1].CjqNo,
							JParamInfo3761->group2.f10[meter-1].MeterNo,JParamInfo3761->group2.f10[meter-1].Type,
							JParamInfo3761->group2.f10[meter-1].AlarmFlg[alrm],
							JParamInfo3761->group2.f10[meter-1].Address[5],
							JParamInfo3761->group2.f10[meter-1].Address[4],
							JParamInfo3761->group2.f10[meter-1].Address[3],
							JParamInfo3761->group2.f10[meter-1].Address[2],
							JParamInfo3761->group2.f10[meter-1].Address[1],
							JParamInfo3761->group2.f10[meter-1].Address[0]);
				//--------------------------
				savejzqmeter(meter);//������1����ǽ������ͣ����ı���ַ���뱣�浽�ļ���  jzqmeter.cfg����
				//--------------------------
				JProgramInfo->FileSaveFlag.g5flag = 1;
				JProgramInfo->FileSaveFlag.F10_ChangedSave[meter-1] = 1;
				//wyq
//				memset(TempBuf,0,60);
//				sprintf((char*)TempBuf,"%s/AmmeterN.par",_PARADIR_);
//				NormalSaveFile((char*)TempBuf,(INT8U *)&Jmemory->Points,sizeof(Jmemory->Points),JProgramInfo);
//				delay(100);
//
//				//printf("count=%d\n\r",JParamInfo3761->group5.f35.Count);
//				memset(TempBuf,0,60);
//				sprintf((char*)TempBuf,"%s/AmmeterOth.par",_PARADIR_);
//				NormalSaveFile((char*)TempBuf,(INT8U *)&JParamInfo3761->group5.f34,sizeof(JParamInfo3761->group5.f34)+sizeof(JParamInfo3761->group5.f35),JProgramInfo);
//
//				memset(TempBuf,0,60);
//				sprintf((char*)TempBuf,"%s/Ammeter%04d.par",_PARADIR_,(meter-1)/SaveNum+1);
//				//printf("TempBuf=%s\n\r",TempBuf);
//				NormalSaveFile((char*)TempBuf,(INT8U *)&Jmemory->Points.pt[meter-1-((meter-1)%SaveNum)],sizeof(Jmemory->Points.pt[meter-1-((meter-1)%SaveNum)])*SaveNum,JProgramInfo);
			}
		}
		return;
	}

	if (strcmp("real", argv[1]) == 0) {
		if (argc == 2) {
		} else {
			int meter;
			if (sscanf(argv[2], "%d",&meter)) {
				JProgramInfo->RealData.CaijiqiNo = (meter-1)/64+1;
				JProgramInfo->RealData.MeterNo = (meter-1)%64;
				JProgramInfo->RealData.flg97[0].flg.Dataflag[1]=0x90;
				JProgramInfo->RealData.flg97[0].flg.Dataflag[0]=0x10;
				JProgramInfo->RealData.CurFlgCount = 1;
				JProgramInfo->RealData.ReadFlg = 1;
				delay(2000);
				JProgramInfo->RealData.ReadFlg = 0;
			}
		}
		return;
	}
//	if (strcmp("gprstest", argv[1]) == 0)
//	{
//		char mybuf[1024],mybuf1[1024],mybuf2[1024];
//		int i,j,k=0,len=0;
//		int frame_len, pos_start=0;
//		memset(mybuf, 0, 1024);
//		memset(JProgramInfo->gprsData.RecBuf, 0, 8192);
//
//		JProgramInfo->gprsData.RecHead=0;
//		JProgramInfo->gprsData.RecTail=0;
//		FILE *fp;
//		fp=fopen("/dev/shm/frame.log", "r");
//		if(fp==NULL)
//			printf("\nfile open fail!!!\n");
//
//		//printf("\n-----------------1\n");
//		while(fgets(mybuf, 500, fp) != NULL)
//		{
//			//printf("\n--%d---%s------2\n",strlen(mybuf),mybuf);
//			for(i=0; i<strlen(mybuf); i++)
//			{
//				//�����ص��û��ı���
////68 86 00 86 00 68 4A 02 35 01 00 02 04 76 00 00 04 04 02 05 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 0D 16
////				for(j=0;j<strlen(mybuf);j++)
////					printf("[%02x] ",mybuf[j]);
//				if(mybuf[i]>= '0' && mybuf[i] <= '9')
//				{
//					mybuf1[k]=mybuf[i]-'0';
//					//printf("(%d:%02x %d:%02x) ",i, mybuf[i],k,mybuf1[k]);
//					k++;
//				}
//				if(mybuf[i]>= 'A' && mybuf[i] <= 'F')
//				{
//					mybuf1[k]=mybuf[i]-55;
//					//printf("(%d:%02x %d:%02x) ",i, mybuf[i],k,mybuf1[k]);
//					k++;
//				}
//				if(mybuf[i]>= 'a' && mybuf[i] <= 'f')
//				{
//					mybuf1[k]=mybuf[i]-87;
//					//printf("(%d:%02x %d:%02x) ",i, mybuf[i],k,mybuf1[k]);
//					k++;
//				}
//			}
//			len=k;
//			k=0;
//			printf("\n�յ��ı��ģ�len===%d\n",len);
//			for(i=0;i<len;i=i+2)
//			{
//				mybuf2[k]=(mybuf1[i]-'0')<<4 | mybuf1[i+1];
//				printf("\[%02x] ",mybuf2[k]);
//				k++;
//			}
//			len=k;
//			for(i=0;i<len;i++)
//			{
//				if(mybuf2[i]==0x68 && mybuf2[i+5]==0x68)//�ҵ�����
//				{
//					printf("\n�ҵ�376.1����\n");
//					pos_start =i;
//					frame_len = ((mybuf2[i+2]<<8 | mybuf2[i+1])>>2) + 8;
//					printf("\n frame_len = %d\n", frame_len);
//					for(j=0; j<frame_len; j++)
//					{
//						JProgramInfo->gprsData.RecBuf[j] = mybuf2[pos_start+j];
//						printf("%02x ",JProgramInfo->gprsData.RecBuf[j]);
//					}
//					JProgramInfo->gprsData.RecHead = (JProgramInfo->gprsData.RecHead + frame_len) % Data_BUF_LEN;
//				}
//			}
//		}
//		return;
//	}
	void DbgPrintToFile1(const char *format,...)
	{
		char str[50];
		time_t cur_time;
		struct tm cur_tm;
		FILE *fp = NULL;
		memset(str,0,50);
		cur_time=time(NULL);
		localtime_r(&cur_time,&cur_tm);
		sprintf(str, "\n[%04d-%02d-%02d %02d:%02d:%02d]",
				cur_tm.tm_year+1900, cur_tm.tm_mon+1, cur_tm.tm_mday,
				cur_tm.tm_hour, cur_tm.tm_min, cur_tm.tm_sec);
	    va_list ap;
		//���ļ�
		if(!fp)
			fp = fopen("/nand/dbglog.log", "a+");
		//��ʼ��ӡ
	    va_start(ap,format);
	    //vprintf(format,ap);
		vfprintf(fp,str,ap);
	    if(fp)
			vfprintf(fp,format,ap); // д�ļ�
	    va_end(ap);

	    fflush(fp);
		//�ر��ļ�
		if(fp)
	    {
	        fclose(fp);
	        fp = NULL;
	    }
	}

	void myBCDtoASC1(char val, char dest[2])
	{
		int i=0;
		char c[2];
		c[0]=0; c[1]=0;
		c[0] = (val>>4) & 0x0f;
		c[1] = val & 0x0f;
		for(i=0; i<2; i++)
		{
			if(c[i]>=0 && c[i]<=9)
				dest[i] = c[i] + '0';
			if(c[i]==10)
				dest[i] = 'a';
			if(c[i]==11)
				dest[i] = 'b';
			if(c[i]==12)
				dest[i] = 'c';
			if(c[i]==13)
				dest[i] = 'd';
			if(c[i]==14)
				dest[i] = 'e';
			if(c[i]==15)
				dest[i] = 'f';
		}
	}
	//prefix ǰ׺   buf ��ӡ������ buf ���� len  suffix ��׺
	// DbPrt("GPRS����", buf, 12, "ȷ��")   //[April 7-2 2012] GPRS����(12): 68 00 00 00 12 34 56 68 11 04 32 16 ȷ��

	void DbPrt1(char *prefix, char *buf, int len, char *suffix)
	{
		char str[50], tmpbuf[2048], c[2], c1[2], c2[2];
		int i=0;
		int count= 0;
		int prtlen=0;
		int k=0;
		memset(c, 0, 2);
		memset(str, 0, 50);
		memset(tmpbuf, 0, 2048);
		//if(len>512)
		//	len=512;
		while(1)
		{
			memset(c, 0, 2);
			memset(str, 0, 50);
			memset(tmpbuf, 0, 2048);
			if(len<=512)
			{
				prtlen = len;
			}else
			{
				if(k<len/512)
				{
					k++;
					prtlen = 512;
				}else
				{
					prtlen = len%512;
				}
			}
			if(prefix!=NULL)
			{
				sprintf(str, "%s[%d] ", prefix,prtlen);
				strcat(tmpbuf, str);
			}
			for(i=0; i<prtlen; i++)
			{
				memset(c, 0, 2);
				memset(c1, 0, 2);
				memset(c2, 0, 2);
				myBCDtoASC1(buf[i+count], c);

				c1[0] = c[0];
				c2[0] = c[1];
				strcat(tmpbuf, c1);
				strcat(tmpbuf, c2);
				strcat(tmpbuf, " ");
			}
			if(suffix!=NULL)
				strcat(tmpbuf, suffix);
			DbgPrintToFile1(tmpbuf);
	///		Jmemory->jzq.Print_rowCount++;
			count += prtlen;
			if(count>=len)
				break;
		}
//		if(Jmemory->jzq.Print_rowCount>5000)
//		{
//			syscmd("rm /nand/dbglog.log",JProgramInfo);
//			printf("\nrm /nand/dbglog.log\n");
//			Jmemory->jzq.Print_rowCount=0;
//		}
	}

	if (strcmp("renzhenghao", argv[1]) == 0)
	{
		if(argc==3)
			JParamInfo3761->group1.f5.XiaoXi_Renzheng_FangAN = atoi(argv[2]);
		else
			printf("\n�����ţ�%d\n",JParamInfo3761->group1.f5.XiaoXi_Renzheng_FangAN);

			fprintf(stderr,"SMFile=%d",sizeof(SMFiles));

		return;
	}

	if (strcmp("mytest", argv[1]) == 0)
	{
		printf("\n�����ţ�%d\n",JParamInfo3761->group1.f5.XiaoXi_Renzheng_FangAN);
		return;
	}

	if (strcmp("test1", argv[1]) == 0)
	{
		char buf[1200]={0x0,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
				0x01,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
				0x02,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
				0x03,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
				0x04,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
				0x05,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
				0x06,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
				0x07,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
				0x08,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
				0x09,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
				0x0a,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
				0x0b,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
				0x0c,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
				0x0d,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
				0x0e,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
				0x0f,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
				0x10,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
				0x11,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
				0x12,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
				0x13,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
				0x14,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
				0x15,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
				0x16,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
				0x17,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
				0x18,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
				0x19,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
				0x1a,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
				0x1b,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
				0x1c,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
				0x1d,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
				0x0,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
								0x01,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
								0x02,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
								0x03,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
								0x04,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
								0x05,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
								0x06,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
								0x07,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
								0x08,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
								0x09,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
								0x0a,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
								0x0b,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
								0x0c,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
								0x0d,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
								0x0e,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
								0x0f,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
								0x10,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
								0x11,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
								0x12,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
								0x13,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
								0x14,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
								0x15,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
								0x16,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
								0x17,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
								0x18,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
								0x19,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
								0x1a,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
								0x1b,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
								0x1c,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,
								0x1d,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34,0x34,0x16,0x68,0x32,0x31,0xa4,0x0,0x34,0x34,0x68,0x34
		};
		DbPrt1("GPRS1111111����", buf,1200,NULL);
		return;
	}
	if (strcmp("prtnum", argv[1]) == 0)
	{
//		if(argc==3)
//			Jmemory->jzq.Print_rowCount = atoi(argv[2]);
//		else
//			printf("\n��ӡ������%d\n",Jmemory->jzq.Print_rowCount);
		return;
	}

  	if (strcmp("test2",argv[1])==0)
	{
		int ik;
		INT8U flag[2];
		struct timespec tsspec;

		if (argc == 3)
		{
			if (clock_gettime(CLOCK_REALTIME, &tsspec)==-1)
				printf("clock_gettime error\n\r");
			tsspec.tv_sec += 2;
			sem_timedwait(&JProgramInfo->mainData.UseCycleFlg, &tsspec);
			flag[0] = atoi(argv[2]);
			flag[1] = atoi(argv[3]);
			strcpy(JProgramInfo->sm[JProgramInfo->sm_head].filename,"/nand/DataDay/0013/12.dat");
			JProgramInfo->sm[JProgramInfo->sm_head].manyFiles.sm.MeterNo = 13;
			JProgramInfo->sm[JProgramInfo->sm_head].manyFiles.sm.datas[0].flg.Dataflag[0] = flag[0];
			JProgramInfo->sm[JProgramInfo->sm_head].manyFiles.sm.datas[0].flg.Dataflag[1] = flag[1];
			for(ik=0;ik<20;ik++)
				JProgramInfo->sm[JProgramInfo->sm_head].manyFiles.sm.datas[0].datas[ik] = ik;
			JProgramInfo->sm[JProgramInfo->sm_head].fileinfo.filetype = FILEDAY;
			TSGet(&JProgramInfo->sm[JProgramInfo->sm_head].fileinfo.ts);
			JProgramInfo->sm[JProgramInfo->sm_head].fileinfo.cldno = 13;
			JProgramInfo->sm[JProgramInfo->sm_head].dataChanged = 1;
			JProgramInfo->sm_head=(JProgramInfo->sm_head+1)%SMBUFLEN;
			sem_post(&JProgramInfo->mainData.UseCycleFlg);
		}
		return ;
	}

	if (strcmp("chaobiao", argv[1]) == 0)
	{
		if(argc==2)
			printf("\n Jmemory->inChaoBiao == %d\n",JProgramInfo->inChaoBiao);
		if(argc==3)
		{
			JProgramInfo->inChaoBiao = atoi(argv[2]);
			printf("\n JProgramInfo->inChaoBiao == %d\n",JProgramInfo->inChaoBiao);
		}
		return;
	}
	//JParamInfo3761->group2.f9.Flag[2]
	if (strcmp("eventflag", argv[1]) == 0) {
		int i=0;
		printf("\n�¼���Ч��־λ��\n");
		for(i=0;i<8;i++)
		{
			printf("[%d-%d]%02x ", i*8+1, (i+1)*8, JParamInfo3761->group2.f9.Flag[i]);
		}
		printf("\n�¼��澯��־λ��\n");
		for(i=0;i<64;i++)
		{
				printf("[%d]%02x ",i,JParamInfo3761->group2.f10[1].AlarmFlg[20]);
		}
		printf("\n");
		return;
	}
	if (strcmp("init", argv[1]) == 0) {
		if (argc == 2) {
		} else {
		}
		InitjzqInfo(1,JParamInfo3761,JProgramInfo,JConfigInfo,JDataFileInfo);
		InitMeterInfo(JParamInfo3761);
		InitTaskInfo(JParamInfo3761, JProgramInfo);

		JProgramInfo->FileSaveFlag.g1flag = 1;
		JProgramInfo->FileSaveFlag.g2flag = 1;
		JProgramInfo->FileSaveFlag.g3flag = 1;
		JProgramInfo->FileSaveFlag.g4flag = 1;
		JProgramInfo->FileSaveFlag.g5flag = 1;
		JProgramInfo->FileSaveFlag.g8flag = 1;
		JProgramInfo->FileSaveFlag.g9flag = 1;
		JProgramInfo->FileSaveFlag.jzqflag = 1;

//		memset(TempBuf,0,60);
//		sprintf((char*)TempBuf,"%s/JzhqPara.par",_PARADIR_);
//		NormalSaveFile((char*)TempBuf, &Jmemory->jzq, sizeof(Jmemory->jzq),JProgramInfo);
		return;
	}
	if (strcmp("pttest", argv[1]) == 0) {
		int j=0,zdflg=0;
		for(j=100;j<102;j++)
		{
			printf("point pointno=%d,cjqno=%d,meterno=%d,type=%d,ConnectType=%d,port=%d,Import=%d,addr=%02x%02x%02x%02x%02x%02x,cjq=%02x%02x%02x%02x%02x%02x\n\r",
						j+1,
						JParamInfo3761->group2.f10[j].CjqNo,
						JParamInfo3761->group2.f10[j].MeterNo,
						JParamInfo3761->group2.f10[j].Type,
						JParamInfo3761->group2.f10[j].ConnectType,
						JParamInfo3761->group2.f10[j].port,
						zdflg,
						JParamInfo3761->group2.f10[j].Address[5],
						JParamInfo3761->group2.f10[j].Address[4],
						JParamInfo3761->group2.f10[j].Address[3],
						JParamInfo3761->group2.f10[j].Address[2],
						JParamInfo3761->group2.f10[j].Address[1],
						JParamInfo3761->group2.f10[j].Address[0],
						JParamInfo3761->group2.f10[j].CaijiqiAddress[5],
						JParamInfo3761->group2.f10[j].CaijiqiAddress[4],
						JParamInfo3761->group2.f10[j].CaijiqiAddress[3],
						JParamInfo3761->group2.f10[j].CaijiqiAddress[2],
						JParamInfo3761->group2.f10[j].CaijiqiAddress[1],
						JParamInfo3761->group2.f10[j].CaijiqiAddress[0]);
		}
		return;
	}
	if (strcmp("prtmet", argv[1]) == 0)
	{
		int counttt=0;
		int j=0,k,zdflg,ptind;
		for (j = 0; j <PointMax; j++)//��������Ϣ
		{
//			fprintf(stderr,"status[%d]=%d\n",j,JParamInfo3761->group2.f10[j].Status);
			if (JParamInfo3761->group2.f10[j].Status==1)
			{   counttt++;
				zdflg=0;
				for(k=0;k<JParamInfo3761->group5.f35.Count;k++)
				{
					ptind=JParamInfo3761->group5.f35.Index[k];
					if (ptind==(j+1))
					{
						zdflg=1;
						fprintf(stderr,"ptind=%d\n",ptind);
						break;
					}
				}
				fprintf(stderr,"point pointno=%d,cjqno=%d,meterno=%d,type=%d,ConnectType=%d,port=%d,Import=%d,addr=%02x%02x%02x%02x%02x%02x,cjq=%02x%02x%02x%02x%02x%02x\n\r",
						    j+1,
						    JParamInfo3761->group2.f10[j].CjqNo,
							JParamInfo3761->group2.f10[j].MeterNo,
							JParamInfo3761->group2.f10[j].Type,
							JParamInfo3761->group2.f10[j].ConnectType,
							JParamInfo3761->group2.f10[j].port,
							zdflg,
							JParamInfo3761->group2.f10[j].Address[5],
							JParamInfo3761->group2.f10[j].Address[4],
							JParamInfo3761->group2.f10[j].Address[3],
							JParamInfo3761->group2.f10[j].Address[2],
							JParamInfo3761->group2.f10[j].Address[1],
							JParamInfo3761->group2.f10[j].Address[0],
							JParamInfo3761->group2.f10[j].CaijiqiAddress[5],
							JParamInfo3761->group2.f10[j].CaijiqiAddress[4],
							JParamInfo3761->group2.f10[j].CaijiqiAddress[3],
							JParamInfo3761->group2.f10[j].CaijiqiAddress[2],
							JParamInfo3761->group2.f10[j].CaijiqiAddress[1],
							JParamInfo3761->group2.f10[j].CaijiqiAddress[0]);
			}
		}
		fprintf(stderr,"\ncounttt=%d\n",counttt);
		return;
	}

	if (strcmp("prtcjq", argv[1]) == 0) {
		if (argc == 2) {

		} else {
		}
		INT8U CjqInf[100][20],Temp_FilePath[60],cjqnum,CjqnInf[100][7];
		INT16U i,j,fd,num;

	   for (i = 0; i < 100; i++)
	   {
		   memset(CjqnInf[i],0,7);
	   }
	   num=0;
		for (i = 0; i < PointMax; i++)
		{
			fd=0;
			if(((JParamInfo3761->group2.f10[i].port==CarrWavePort) || (JParamInfo3761->group2.f10[i].port==LocalCommPort)) &&JParamInfo3761->group2.f10[i].Status==1)
			{
				if ((JParamInfo3761->group2.f10[i].CaijiqiAddress[0]!=0x00) ||
					(JParamInfo3761->group2.f10[i].CaijiqiAddress[1]!=0x00) ||
					(JParamInfo3761->group2.f10[i].CaijiqiAddress[2]!=0x00) ||
					(JParamInfo3761->group2.f10[i].CaijiqiAddress[3]!=0x00) ||
					(JParamInfo3761->group2.f10[i].CaijiqiAddress[4]!=0x00) ||
					(JParamInfo3761->group2.f10[i].CaijiqiAddress[5]!=0x00))
				{

					for (j = 0; j < 100; j++)
						if (memcmp(&JParamInfo3761->group2.f10[i].CaijiqiAddress[0],&CjqnInf[j][0],6)==0)
						{
							if (CjqnInf[j][6]==0)
							{
								memset(Temp_FilePath,0,60);
								sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",i+1);
								//printf("%s\n\r",(char *) Temp_FilePath);
								if (access((char *) Temp_FilePath, 0) == 0)
								{
									CjqnInf[j][6]=1;
								}
							}
							fd=1;
							break;
						}
					if (fd==0)
					{
						memset(Temp_FilePath,0,60);
						sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",i+1);
						//printf("%s\n\r",(char *) Temp_FilePath);
						if (access((char *) Temp_FilePath, 0) == 0)
						{
							CjqnInf[num][6]=1;
						}
						memcpy(&CjqnInf[num][0],&JParamInfo3761->group2.f10[i].CaijiqiAddress[0],6);
						num++;
						if (num>=100)
							break;
					}
				}
			}
		}
		printf("%s%d:\n\r","Ŀǰ���вɼ���",num);
		for(i=0;i<num;i++)
		{
			printf("%02x%02x%02x%02x%02x%02x\n\r",CjqnInf[i][5],CjqnInf[i][4],
					CjqnInf[i][3],CjqnInf[i][2],CjqnInf[i][1],CjqnInf[i][0]);
		}
		printf("\n\r");

		cjqnum=0;
		for(i=0;i<num;i++)
		{
			if (CjqnInf[i][6]==0)
			{
				memcpy(&CjqInf[cjqnum][0],&CjqnInf[i],6);
				cjqnum++;
				if(cjqnum>=100)
					break;
			}
		}
		printf("%s%d:\n\r","δ�����ɼ���",cjqnum);
		for(i=0;i<cjqnum;i++)
		{
			printf("%02x%02x%02x%02x%02x%02x\n\r",CjqInf[i][5],CjqInf[i][4],
					CjqInf[i][3],CjqInf[i][2],CjqInf[i][1],CjqInf[i][0]);
		}
		printf("\n\r");
		return;
	}

	if (strcmp("nonetcjq", argv[1]) == 0) {
		if (argc == 2) {

		} else {
		}
		JProgramInfo->WirlessCrt=1;
		for(i=0;i<30;i++)
		{
			if ((JProgramInfo->WirlessCrt==0)||(JProgramInfo->WirlessCrt==0x10))
				break;
			delay(1000);
		}
		if (JProgramInfo->WirlessCrt==0x10)
		{
			JProgramInfo->WirlessCrt=0;
			printf("%s---\n\r","������ģ�鲻��ͳ��");
		}
		else
		{
			printf("%s---%d\n\r","δ�����ɼ�������",JProgramInfo->WirlessBuff[0]);
			for(i=0;i<JProgramInfo->WirlessBuff[0];i++)
			{
				printf("%02x%02x%02x%02x%02x%02x\n\r",JProgramInfo->WirlessBuff[i*6+6],
						JProgramInfo->WirlessBuff[i*6+5],
						JProgramInfo->WirlessBuff[i*6+4],
						JProgramInfo->WirlessBuff[i*6+3],
						JProgramInfo->WirlessBuff[i*6+2],
						JProgramInfo->WirlessBuff[i*6+1]);
			}
		}
		return;
	}

	if (strcmp("prtcb", argv[1]) == 0) {
		INT8U Temp_FilePath[60];
		INT16U j;
		if (argc == 2) {

		} else {
		}
		printf("%s\n\r","δ���������");
		for (j = 0; j < PointMax; j++)
		{
			if(JParamInfo3761->group2.f10[j].Status==1)
			{
				memset(Temp_FilePath,0,60);
				sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",j+1);
				if (access((char *) Temp_FilePath, 0) != 0)
				{
					printf("addr=%02x%02x%02x%02x%02x%02x,cjq=%02x%02x%02x%02x%02x%02x\n\r",
							JParamInfo3761->group2.f10[j].Address[5],
							JParamInfo3761->group2.f10[j].Address[4],
							JParamInfo3761->group2.f10[j].Address[3],
							JParamInfo3761->group2.f10[j].Address[2],
							JParamInfo3761->group2.f10[j].Address[1],
							JParamInfo3761->group2.f10[j].Address[0],
							JParamInfo3761->group2.f10[j].CaijiqiAddress[5],
							JParamInfo3761->group2.f10[j].CaijiqiAddress[4],
							JParamInfo3761->group2.f10[j].CaijiqiAddress[3],
							JParamInfo3761->group2.f10[j].CaijiqiAddress[2],
							JParamInfo3761->group2.f10[j].CaijiqiAddress[1],
							JParamInfo3761->group2.f10[j].CaijiqiAddress[0]);
				}
			}
		}
		printf("\n\r");
		return;
	}

	if (strcmp("lev1", argv[1]) == 0) {
		if (argc == 2) {
			if (JProgramInfo->mainData.Time_Flag!=100)
				printf("\n\rcurr data\n\r");
			else if (JProgramInfo->mainData.Time_Flag==100)
				printf("\n\rreal data\n\r");
			else printf("\n\rnot read biao\n\r");

		} else {
			int lev;
			if (sscanf(argv[2], "%d", &lev)) {
				JProgramInfo->mainData.Time_Flag=lev;
				if (JProgramInfo->mainData.Time_Flag!=100)
					printf("\n\rcurr data\n\r");
				else if (JProgramInfo->mainData.Time_Flag==100)
					printf("\n\rreal data\n\r");
				else printf("\n\rnot read biao\n\r");
			}
		}
		return;
	}

	if (strcmp("updtime", argv[1]) == 0) {
		if (argc == 2) {
			printf("Jmemory->jzq.Update_Time=%d\n\r",JProgramInfo->Update_Time);
			JProgramInfo->Update_Time=80;

		} else {
			int lev;
			if (sscanf(argv[2], "%d", &lev)) {
				JProgramInfo->Update_Time=lev;
			}
		}
		return;
	}
//	if (strcmp("jiangxiliantiao", argv[1]) == 0) {
//		if (argc == 2) {
//			printf("\n������վ����(1��ʹ��      0����ֹ)��%d \n",Jmemory->jzq.JiangXiZhuzhanliantiao);
//		}else
//		{
//			if(Jmemory->JiangXi)
//			{
//				Jmemory->jzq.JiangXiZhuzhanliantiao = atoi(argv[2]);
//				printf("\n������վ����(1��ʹ��      0����ֹ)��%d \n",Jmemory->jzq.JiangXiZhuzhanliantiao);
//			}else
//				printf("\n�˼��������ò��ǽ������ã�����������Ч \n");
//		}
//		return;
//	}
	if (strcmp("alrcl", argv[1]) == 0) {
		int j=0;
		if (argc == 2) {
			for(i=0;i<8;i++)
				JDataFileInfo->ErcEvt.ERCBiaoZhi[i]=0x00;
			for(i=0;i<PointMax;i++)
			{
				for(j=0;j<64;j++)
					JParamInfo3761->group2.f10[i].AlarmFlg[j]=0x00;
			}
			printf("ERCBiaoZhi clear\n\r");
		}
		return;
	}

	if (strcmp("ver", argv[1]) == 0)
	{
		if (argc==2)
		{
			fprintf(stderr,"\n�汾��Ϣ\n");

			printf("\n����  %c%c",JConfigInfo->jzqpara.ver.FactNo[0],JConfigInfo->jzqpara.ver.FactNo[1]);
			printf("\n����  %c%c%c%c",JConfigInfo->jzqpara.ver.SoftVer[0],JConfigInfo->jzqpara.ver.SoftVer[1],
					JConfigInfo->jzqpara.ver.SoftVer[2],JConfigInfo->jzqpara.ver.SoftVer[3]);
			printf("\nӲ��  %c%c%c%c",JConfigInfo->jzqpara.ver.HardVer[0],JConfigInfo->jzqpara.ver.HardVer[1],
					JConfigInfo->jzqpara.ver.HardVer[2],JConfigInfo->jzqpara.ver.HardVer[3]);
			printf("\n������������ 20%02x-%02x-%02x",JConfigInfo->jzqpara.ver.SoftDate[2],JConfigInfo->jzqpara.ver.SoftDate[1],JConfigInfo->jzqpara.ver.SoftDate[0]);
			printf("\nӲ���������� 20%02x-%02x-%02x",JConfigInfo->jzqpara.ver.HardDate[2],JConfigInfo->jzqpara.ver.HardDate[1],JConfigInfo->jzqpara.ver.HardDate[0]);
			printf("\n��Լ %c%c%c%c\r\n",JConfigInfo->jzqpara.ver.ProtVer[0],JConfigInfo->jzqpara.ver.ProtVer[1],JConfigInfo->jzqpara.ver.ProtVer[2],JConfigInfo->jzqpara.ver.ProtVer[3]);
		}
		return;
	}
	if (strcmp("shutnum", argv[1]) == 0) {
		if (argc == 2) {
			//Jmemory->dataFiles.fileType=3;
			printf("JProgramInfo->ShutNum=%02x\n\r",JProgramInfo->ShutNum);
			JProgramInfo->ShutNum=0;
		}
		return;
	}

	if (strcmp("alrst", argv[1]) == 0) {
		if (argc == 3) {
			if (atoi(argv[2])==1)
				printf("import event set\n\r");
			else
				printf("normal event set\n\r");
			for(i=0;i<8;i++)
			{
				JParamInfo3761->group2.f9.Flag[i]=0xFF;
				JParamInfo3761->group2.f9.FlagStep[i]=0x00;
				if (atoi(argv[2])==1)
					JParamInfo3761->group2.f9.FlagStep[i]=0xFF;
			}
		}
		return;
	}

	if (strcmp("stalrm", argv[1]) == 0) {
		if (argc == 3) {
			JProgramInfo->stateflags.ErcFlg=atoi(argv[2]);
		}
		return;
	}
	if (strcmp("date", argv[1]) == 0) {
		if (argc == 2) {
			syscmd("date",JProgramInfo);

		} else {

			int year,mon,day,hour,min,sec;
			char command[50];
			if (sscanf(argv[2], "%d-%d-%d-%d-%d-%d", &year,&mon,&day,&hour,&min,&sec)) {
				#ifdef __linux__
					sprintf(command,"date %04d.%02d.%02d-%02d:%02d:%02d", year,mon,day,hour,min,sec);
				#else
					sprintf(command,"date %02d %02d %02d %02d %02d %02d", day,mon,year,hour,min,sec);
				#endif

				printf("%s\n\r",command);
				syscmd(command,JProgramInfo);
				delay(100);
				syscmd(_SETCLK_,JProgramInfo);
				delay(100);
				syscmd(_GETCLK_,JProgramInfo);
				syscmd("date",JProgramInfo);
			}
		}
		return;
	}

	if (strcmp("factno", argv[1]) == 0) {
			INT8U FactNo[5];
		if (argc == 2) {
			memset(FactNo,0,5);
			memcpy(FactNo,JConfigInfo->jzqpara.ver.FactNo,4);
			printf("FactNo=%s\n\r",FactNo);

		} else {
			memset(JConfigInfo->jzqpara.ver.FactNo,0x00,4);
			memcpy(JConfigInfo->jzqpara.ver.FactNo,argv[2],strlen(argv[2]));
			memset(FactNo,0,5);
			memcpy(FactNo,JConfigInfo->jzqpara.ver.FactNo,4);
			printf("FactNo=%s\n\r",FactNo);
			JProgramInfo->FileSaveFlag.jzqflag = 1;
//			memset(TempBuf,0,60);
//			sprintf((char*)TempBuf,"%s/JzhqPara.par",_PARADIR_);
//			NormalSaveFile((char*)TempBuf, &Jmemory->jzq, sizeof(Jmemory->jzq),JProgramInfo);
		}
		return;
	}

	if (strcmp("devno", argv[1]) == 0) {
		INT8U DevNo[9];
		if (argc == 2) {
			memset(DevNo,0,9);
			memcpy(DevNo,JConfigInfo->jzqpara.ver.DevNo,8);
			printf("DevNo=%s\n\r",DevNo);

		} else {
			memset(JConfigInfo->jzqpara.ver.DevNo,0x00,8);
			memcpy(JConfigInfo->jzqpara.ver.DevNo,argv[2],strlen(argv[2]));
			memset(DevNo,0,9);
			memcpy(DevNo,JConfigInfo->jzqpara.ver.DevNo,8);
			printf("DevNo=%s\n\r",DevNo);
			JProgramInfo->FileSaveFlag.jzqflag = 1;
//			memset(TempBuf,0,60);
//			sprintf((char*)TempBuf,"%s/JzhqPara.par",_PARADIR_);
//			NormalSaveFile((char*)TempBuf, &Jmemory->jzq, sizeof(Jmemory->jzq),JProgramInfo);
		}
		return;
	}

	if (strcmp("setcomstat", argv[1]) == 0) {
		printf("\n JConfigInfo->jzqpara.Comm == %d\n",JConfigInfo->jzqpara.CommStat);
		JConfigInfo->jzqpara.CommStat=5;
		return;
	}
	if (strcmp("read", argv[1]) == 0)
	{
		int i=0,j=0;
		INT8U Temp_FilePath[60];
		if (argc >= 3)
		{
			//cl=atoi(argv[2]);
			memset(Temp_FilePath,0,60);
			//sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",cl);
			//sscanf((char*)argv[2], "%s", Temp_FilePath);
			sprintf((char*)Temp_FilePath, "%s", argv[2]);
			if (access((char *) Temp_FilePath, 0) != 0)
				return;
			ReadFile((char *) Temp_FilePath, &smfile,sizeof(SMFiles),JProgramInfo);
			printf("file = %s \nts=%02d-%02d-%02d %02d:%02d:%02d\n\r",
					Temp_FilePath,
					smfile.ts.Year,smfile.ts.Month,	smfile.ts.Day,smfile.ts.Hour,smfile.ts.Minute,smfile.ts.Sec);
			printf("pt=%d,CaijiQiNo=%d,MeterNo=%d\n\r",getPoint(smfile.sm.CaijiQiNo,smfile.sm.MeterNo)+1,smfile.sm.CaijiQiNo,smfile.sm.MeterNo);
			for (i=0;i<ManyFlagsCount;i++)
			{
				if (smfile.sm.datas[i].flg.Dataflag[1]==0x00 && smfile.sm.datas[i].flg.Dataflag[0]==0x00)
					continue;
				if (smfile.sm.datas[i].flg.Dataflag[1]==0xff && smfile.sm.datas[i].flg.Dataflag[0]==0xff)
					continue;
				if (smfile.sm.datas[i].flg.Dataflag[1]==OxXX && smfile.sm.datas[i].flg.Dataflag[0]==OxXX)
					continue;
				printf("flag%d  %d=%02x%02x---", smfile.sm.datas[i].flg.ReadFlg, i, smfile.sm.datas[i].flg.Dataflag[1], smfile.sm.datas[i].flg.Dataflag[0]);
				for(j=0;(j<DataLenMax && j<50);j++)
				{
//					if (smfile.sm.datas[i].datas[j]==OxXX)
//						break;
					printf("%02x ",smfile.sm.datas[i].datas[j]);
				}
				printf("\n\r");
			}
		}
		return;
	}

	if (strcmp("DayReset", argv[1]) == 0)
	{
		int ri=1;
		INT8U Temp_FilePath[60];
		if (argc >= 3)
		{
			ri=atoi(argv[2]);
			memset(Temp_FilePath, 0, 60);
			sprintf((char *) Temp_FilePath, "/nand/DataAlarm/d%02d.dat",ri);
			ReadFile((char *) Temp_FilePath, &JDataFileInfo->DayRunTj,sizeof(TongJi),JProgramInfo);
			fprintf(stderr,"jzq.DayTj_%02d.ResetTime=%d\n",ri,JDataFileInfo->DayRunTj.ResetTime);
			fprintf(stderr,"jzq.DayTj_%02d.GdTime=%d\n",ri,JDataFileInfo->DayRunTj.GdTime);
		}
		return;
	}

	if (strcmp("MReset", argv[1]) == 0)
	{
		int yue=1;
		INT8U Temp_FilePath[60];
		if (argc >= 3)
		{
			yue=atoi(argv[2]);
			memset(Temp_FilePath, 0, 60);
			sprintf((char *) Temp_FilePath, "/nand/DataAlarm/m%02d.dat",yue);
			ReadFile((char *) Temp_FilePath, &JDataFileInfo->YueRunTj,sizeof(TongJi),JProgramInfo);
			fprintf(stderr,"jzq.YueTj%02d.ResetTime=%d\n",yue,JDataFileInfo->YueRunTj.ResetTime);
			fprintf(stderr,"jzq.YueTj%02d.GdTime=%d\n",yue,JDataFileInfo->YueRunTj.GdTime);
		}
		return;
	}
	//jSet readcurr 2
	if (strcmp("readcurr", argv[1]) == 0)
	{
		int cl=1,i=0,j=0;
		INT8U Temp_FilePath[60];
		if (argc >= 3)
		{
			cl=atoi(argv[2]);
			memset(Temp_FilePath,0,60);
			sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",cl);

			if (access((char *) Temp_FilePath, 0) != 0)
				return;
			ReadFile((char *) Temp_FilePath, &smfile,sizeof(SMFiles),JProgramInfo);
			printf("ts=%02d-%02d-%02d %02d:%02d:%02d\n\r",smfile.ts.Year,smfile.ts.Month,
					smfile.ts.Day,smfile.ts.Hour,smfile.ts.Minute,smfile.ts.Sec);
			printf("pt=%d,CaijiQiNo=%d,MeterNo=%d\n\r",getPoint(smfile.sm.CaijiQiNo,smfile.sm.MeterNo)+1,smfile.sm.CaijiQiNo,smfile.sm.MeterNo);
			for (i=0;i<ManyFlagsCount;i++)
			{
				if (smfile.sm.datas[i].flg.Dataflag[1]==0x00 && smfile.sm.datas[i].flg.Dataflag[0]==0x00)
					continue;
				if (smfile.sm.datas[i].flg.Dataflag[1]==0xff && smfile.sm.datas[i].flg.Dataflag[0]==0xff)
					continue;
				if (smfile.sm.datas[i].flg.Dataflag[1]==OxXX && smfile.sm.datas[i].flg.Dataflag[0]==OxXX)
					continue;
				printf("flag%d  %d=%02x%02x---", smfile.sm.datas[i].flg.ReadFlg, i, smfile.sm.datas[i].flg.Dataflag[1], smfile.sm.datas[i].flg.Dataflag[0]);
				for(j=0;(j<DataLenMax && j<30);j++)
				{
//					if (smfile.sm.datas[i].datas[j]==OxXX)
//						break;
					printf("%02x ",smfile.sm.datas[i].datas[j]);
				}
				printf("\n\r");
			}
		}
		return;
	}
	int myASCToBCD(unsigned char * ASC, int Len, unsigned char *Ret) {
		int i, j, k;
		if (ASC != NULL) {
			for (i = 0; i < Len; i++) {
				if (ASC[i] <= '9' && ASC[i] >= '0')
					ASC[i] = ASC[i] - '0';
				else if(ASC[i] <= 'f' && ASC[i] >= 'a')
				{
					ASC[i] = ASC[i] - 'W';
				}
				else if(ASC[i] <= 'F' && ASC[i] >= 'A')
				{
					ASC[i] = ASC[i] - '7';
				}
			}
			if (Len % 2 == 0) {
				//unsigned char *Ret=new char[Len/2+1];
				memset(Ret, 0, Len / 2 + 1);
				for (j = 0, k = 0; j < Len / 2; j++) {
					*(Ret + j) = (ASC[k] << 4) | ASC[k + 1];
					k++;
					k++;
				}
				//return Ret;
			}
		}
		return 0;
	}

	//jSet writecurr 	3 	9010 		2546  		2
	//				������	�������ʶ	����		�ӵڼ������ݿ�ʼ�޸�
	if (strcmp("writecurr", argv[1]) == 0)
	{
		int cl=1,i=0,j=0;
		INT8U Temp_FilePath[60];
		unsigned char data[10],tempflg[2];
		int data_len=0;
		int start_pos=atoi(argv[5]);
		if (argc >= 3)
		{
			cl=atoi(argv[2]);
			memset(Temp_FilePath,0,60);
			sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",cl);
			if (access((char *) Temp_FilePath, 0) != 0)
				return;
			ReadFile((char *) Temp_FilePath, &smfile,sizeof(SMFiles),JProgramInfo);
			printf("\n argv[1]=%s argv[3] =%s\n", argv[1], argv[3]);
			myASCToBCD((unsigned char *)argv[3], strlen(argv[3]), tempflg);
			printf("\n tmepflg = %02x%02x\n",tempflg[0],tempflg[1]);
			data_len=strlen(argv[4]);
			myASCToBCD((unsigned char *)argv[4], data_len, data);
			for (i=0;i<ManyFlagsCount;i++)
			{
				if(tempflg[0]== smfile.sm.datas[i].flg.Dataflag[1] && tempflg[1]== smfile.sm.datas[i].flg.Dataflag[0])
				{
					printf("write before��\n");
					printf("flag%d=%02x%02x : ", smfile.sm.datas[i].flg.ReadFlg,
							smfile.sm.datas[i].flg.Dataflag[1], smfile.sm.datas[i].flg.Dataflag[0]);
					for(j=0;(j<DataLenMax && j<30);j++)
					{
						printf("%02x ",smfile.sm.datas[i].datas[j]);
					}
					for(j=0; j<(data_len+1)/2; j++)
					{
						smfile.sm.datas[i].datas[start_pos+j]= data[(data_len+1)/2-1-j];
					}
					//wyq
			//		SaveFile((char *) Temp_FilePath, &smfile,sizeof(SMFiles),JProgramInfo);
					ReadFile((char *) Temp_FilePath, &smfile,sizeof(SMFiles),JProgramInfo);
					printf("\nwrite after��\n");
					printf("flag%d=%02x%02x : ", smfile.sm.datas[i].flg.ReadFlg,
							smfile.sm.datas[i].flg.Dataflag[1], smfile.sm.datas[i].flg.Dataflag[0]);
					for(j=0;(j<DataLenMax && j<30);j++)
					{
						printf("%02x ",smfile.sm.datas[i].datas[j]);
					}
				}
			}
			printf("\n\r");
		}
		return;
	}
	if (strcmp("wendu", argv[1]) == 0)
	{
//		WDCANSHU = BeiYong[3];
//		WDCANSHU_SX = BeiYong[4];
//		WDXISHU = BeiYong[5]|BeiYong[6]<<8;
//		BeiYong[2] = temper;
		int wdcanshu=0, wdcansh_sx=0, wdxishu=0;
		if(argc==2)
		{
			printf("\ntemper == %d  WDXISHU=%d WDCANSHU=%d  WDCANSHU_SX=%d \n",
					JProgramInfo->BeiYong[2],JProgramInfo->BeiYong[5]|JProgramInfo->BeiYong[6]<<8, JProgramInfo->BeiYong[3],JProgramInfo->BeiYong[4]);
		}else
		{
			sscanf(argv[2], "%d", &wdxishu);
			sscanf(argv[3], "%d", &wdcanshu);
			sscanf(argv[4], "%d", &wdcansh_sx);
			JProgramInfo->BeiYong[5] = wdxishu&0xff;
			JProgramInfo->BeiYong[6] = (wdxishu>>8)&0xff;
			JProgramInfo->BeiYong[3] = wdcanshu;
			JProgramInfo->BeiYong[4] = wdcansh_sx;
			printf("\ntemper == %d  WDXISHU=%d WDCANSHU=%d  WDCANSHU_SX=%d \n",
					JProgramInfo->BeiYong[2],JProgramInfo->BeiYong[5]|JProgramInfo->BeiYong[6]<<8, JProgramInfo->BeiYong[3],JProgramInfo->BeiYong[4]);
		}
	return;
	}
  	if (strcmp("commtype", argv[1]) == 0)
	{
		if (argc == 3)
		{
			JConfigInfo->jzqpara.CommType = atoi(argv[2]);
		}
		INT8U comm_style = JConfigInfo->jzqpara.CommType;
		fprintf(stderr,"\n ͨ��:��");
		switch(comm_style)
		{
		case 0:
			fprintf(stderr," GPRS\n\n");
			break;
		case 1:
			fprintf(stderr," RJ45\n\n");
			break;
		case 2:
			fprintf(stderr," ����\n\n");
			break;
		default:
			fprintf(stderr,"\n!!! Commtype=%02x\n",comm_style);
			break;
		}
		JProgramInfo->FileSaveFlag.jzqflag = 1;
//		memset(TempBuf,0,60);
//		sprintf((char*)TempBuf,"%s/JzhqParaN.par",_PARADIR_);
//		NormalSaveFile((char*)TempBuf, &Jmemory->jzq, sizeof(Jmemory->jzq),JProgramInfo);
//		delay(100);
//		memset(TempBuf,0,60);
//		sprintf((char*)TempBuf,"%s/JzhqPara.par",_PARADIR_);
//		NormalSaveFile((char*)TempBuf, &Jmemory->jzq, sizeof(Jmemory->jzq),JProgramInfo);
		return;
	}

	if (strcmp("renzheng", argv[1]) == 0)
	{
		int hao=0;
		if(argc==2)
		{
			printf("������֤��=%d \n",JParamInfo3761->group1.f5.XiaoXi_Renzheng_FangAN);
		}else
		{
			sscanf(argv[2], "%d", &hao);
			JParamInfo3761->group1.f5.XiaoXi_Renzheng_FangAN = hao;
			printf("������֤��=%d \n",JParamInfo3761->group1.f5.XiaoXi_Renzheng_FangAN);
		}
	return;
	}
	if (strcmp("prterc", argv[1]) == 0)
	{
		int i;
		printf("\n Jmemory->Points.pt[1].f25.E_Ding_V[0]~[1] %02x %02x\n",
				JParamInfo3761->Point[1].f25.E_Ding_V[0],JParamInfo3761->Point[1].f25.E_Ding_V[1]);
		printf("\nJParamInfo3761->group2.f9.Flag[0]~[8]:");
		for(i=0;i<8;i++)
		{
			printf(" %02x ",JParamInfo3761->group2.f9.Flag[i]);
		}
		printf("\nJParamInfo3761->group2.f9.FlagStep[0]~[8]:");
		for(i=0;i<8;i++)
		{
			printf(" %02x ",JParamInfo3761->group2.f9.FlagStep[i]);
		}
		for(i=0;i<6;i++)
		{
			printf("\nJDataFileInfo->data485[%d].Flag==%d", i, JDataFileInfo->data485[i].Flag);
		}
		//		printf("\nJDataFileInfo->ErcEvt.EC2 = %d\n",JDataFileInfo->ErcEvt.EC2);
//		for(i=0;i<256;i++)
//		{
//			printf("\n JDataFileInfo->ErcEvt.NorEvent[0][1]=%02x %02x",JDataFileInfo->ErcEvt.NorEvent[i].Buff[0],JDataFileInfo->ErcEvt.NorEvent[i].Buff[1]);
//		}
	return;
	}

	if (strcmp("set485", argv[1]) == 0)
	{
		JDataFileInfo->data485[4+PortBegNum].Flag=1;
		return;
	}
	if (strcmp("metclr", argv[1]) == 0) {
		if (argc == 2) {
			int j=0;
			for (j = 0; j <PointMax; j++)//��������Ϣ
			{
				JParamInfo3761->group2.f10[j].Status=0;
				JProgramInfo->FileSaveFlag.F10_ChangedSave[j] = 1;
//				if (((j%SaveNum)==0)&&(j>0))
//				{
//					memset(TempBuf,0,60);
//					sprintf((char*)TempBuf,"%s/Ammeter%04d.par",_PARADIR_,((j-SaveNum)/SaveNum)+1);
//					NormalSaveFile((char*)TempBuf,(INT8U *)&Jmemory->Points.pt[j-SaveNum-(j%SaveNum)],
//							sizeof(Jmemory->Points.pt[j-SaveNum-(j%SaveNum)])*SaveNum,JProgramInfo);
//					delay(10);
//				}
			}
//			memset(TempBuf,0,60);
//			sprintf((char*)TempBuf,"%s/AmmeterN.par",_PARADIR_);
//			NormalSaveFile((char*)TempBuf,(INT8U *)&Jmemory->Points,sizeof(Jmemory->Points),JProgramInfo);
//			delay(100);
		}
		return;
	}


	if (strcmp("metset", argv[1]) == 0) {
		if (argc == 2) {
			int j=0;
			for (j = 0; j <PointMax; j++)//��������Ϣ
			{
				JParamInfo3761->group2.f10[j].Status=1;
				JParamInfo3761->group2.f10[j].ConnectType=1;
				JProgramInfo->FileSaveFlag.F10_ChangedSave[j] = 1;
//				if (((j%SaveNum)==0)&&(j>0))
//				{
//					memset(TempBuf,0,60);
//					sprintf((char*)TempBuf,"%s/Ammeter%04d.par",_PARADIR_,((j-SaveNum)/SaveNum)+1);
//					NormalSaveFile((char*)TempBuf,(INT8U *)&Jmemory->Points.pt[j-SaveNum-(j%SaveNum)],sizeof(Jmemory->Points.pt[j-SaveNum-(j%SaveNum)])*SaveNum,JProgramInfo);
//					delay(10);
//				}
			}
//			memset(TempBuf,0,60);
//			sprintf((char*)TempBuf,"%s/AmmeterN.par",_PARADIR_);
//			NormalSaveFile((char*)TempBuf,(INT8U *)&Jmemory->Points,sizeof(Jmemory->Points),JProgramInfo);
//			delay(100);
		}
		return;
	}

	if (strcmp("readeeprom", argv[1]) == 0)
	{
		int i2cfd =-1, i=0, j=0;
		unsigned char read_tmpbuf[7][8];
		if ((i2cfd = open("/dev/i2c-1", O_RDWR)) < 0)
		{
			printf("openi2c : %s\n", strerror(errno));
		} else {
			if (ioctl(i2cfd,0x0703,0x50)<0)
				printf("get_slave_addr : %s\n", strerror(errno));
		}
		sleep(1);
		printf("\n read eeprom:\n");
		for (i = 0; i < 7; i++)
		{
			printf("\n");
			printf("%d: ",i);
			for (j = 0; j < 8; j++)
			{
				delay(100);
				if(i2c_read(i2cfd, i*8+j, &read_tmpbuf[i][j], 1)==0)
				{
					printf("%02x ",read_tmpbuf[i][j]);
				}
				else
					printf("\n read error!!!");
			}
		}
		printf("\n");
		return;
	}

	int GetManyData(DataFlg *data,INT8U *reslutBuf,INT8U DI1,INT8U DI0)				//9.23
	{
		INT8U i,isFlag=0;
		for(i=0;i<ManyFlagsCount;i++){
			if(data[i].flg.Dataflag[0]==DI0&&data[i].flg.Dataflag[1]==DI1){
	            memcpy(reslutBuf,&data[i].datas[0],sizeof(data[i].datas));
	            isFlag=1;
	            break;
			}
		}
		if(isFlag==0) {
			for(i=0;i<ManyFlagsCount;i++){
				if(data[i].flg.Dataflag[0]==(DI0|0x0f)&&data[i].flg.Dataflag[1]==DI1){
					memcpy(reslutBuf,&data[i].datas[0],sizeof(data[i].datas));
					isFlag=1;
					break;
				}
			}
		}

		if(isFlag==0){
			memset(reslutBuf,0x00,sizeof(data[0].datas));
			return 0;
		}
		return 1;
	}
	if (strcmp("lookcurr.dat", argv[1]) == 0)
	{
		INT8U tempManyData[DataLenMax];
		int i;
		char Temp_FilePath[60];
		memset(Temp_FilePath,0,60);
		INT8U di0,di1;
		sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",atoi(argv[2]));
		if (access((char*)Temp_FilePath,0)!=0)
		{
			return;
		}
		ReadFile((char *) Temp_FilePath, &smfile, sizeof(SMFiles),JProgramInfo);
		for(i=0;i<ManyFlagsCount;i++)
		{
			if( (smfile.sm.datas[i].flg.Dataflag[0]==0x00 && smfile.sm.datas[i].flg.Dataflag[1]==0x00) ||
				(smfile.sm.datas[i].flg.Dataflag[0]==0xEE && smfile.sm.datas[i].flg.Dataflag[1]==0xEE) ||
				(smfile.sm.datas[i].flg.Dataflag[0]==0xFF && smfile.sm.datas[i].flg.Dataflag[1]==0xFF))
			{

			}else{
				di0 = smfile.sm.datas[i].flg.Dataflag[0];
				di1 = smfile.sm.datas[i].flg.Dataflag[1];
				GetManyData(smfile.sm.datas, &tempManyData[0], di1, di0);
				printf("\n%02x%02x: %02x%02x%02x%02x \n",smfile.sm.datas[i].flg.Dataflag[1],smfile.sm.datas[i].flg.Dataflag[0],
						tempManyData[3],tempManyData[2],tempManyData[1],tempManyData[0]);
			}
		}
		return;
	}

	if (strcmp("work",argv[1])==0)
	{
		int typework,ifwork;
		if (argc == 3)
		{
			if (sscanf(argv[2],"%d-%d",&typework,&ifwork)==2)
			{
				switch(typework)
				{
					case 1:
						JProgramInfo->stateflags.work_ethernet = ifwork;
						break;
					case 2:
						JProgramInfo->stateflags.work_weihu = ifwork;
						break;
					case 3:
						JProgramInfo->stateflags.work_gprs = ifwork;
						break;
					case 4:
						JProgramInfo->stateflags.work_zb = ifwork;
						break;
					case 5:
						JProgramInfo->stateflags.work_485I = ifwork;
						break;
					case 6:
						JProgramInfo->stateflags.work_485II = ifwork;
						break;
					case 7:
						JProgramInfo->stateflags.work_485III = ifwork;
						break;
					case 8:
						JProgramInfo->stateflags.work_usb = ifwork;
						break;
					case 9:
						JProgramInfo->stateflags.work_sdc = ifwork;
						break;
				}
			}
		}
		return;
	}
	if (strcmp("wg", argv[1]) == 0)
	{
		int dog_data=0;
		dog_data = atoi(argv[2]);
		if((fd = open("/dev/watchdog", O_RDWR | O_NDELAY)) == -1)
		{
			printf("\n\r open /dev/watchdog error!!!");
			return;
		}
		write(fd,&dog_data,sizeof(int));
		printf("\nwrite watchdog one mintue!!\n");
		close(fd);
		return;
	}
	if (strcmp("fangan",argv[1])==0)
	{
		fprintf(stderr,"jzq_login=%d\n",JProgramInfo->jzq_login);
		JParamInfo3761->group1.f5.XiaoXi_Renzheng_FangAN = 0;
		return;
	}
	if(strcmp("jiaocai",argv[1])==0)
	{
		printf("RES UA=%u,UB=%u,UC=%u\n\r",JDataFileInfo->jc.RES.RES_UA,JDataFileInfo->jc.RES.RES_UB,JDataFileInfo->jc.RES.RES_UC);
		printf("Jc  UA_AVG=%u,UB_AVG=%u,UC_AVG=%u\n\r",JDataFileInfo->jc.JcDdRealData.VA_AVG,JDataFileInfo->jc.JcDdRealData.VB_AVG,JDataFileInfo->jc.JcDdRealData.VC_AVG);
		printf("\n");
		printf("RES IA=%u,IB=%u,IC=%u,I0=%u\n\r",JDataFileInfo->jc.RES.RES_IA,JDataFileInfo->jc.RES.RES_IB,JDataFileInfo->jc.RES.RES_IC,JDataFileInfo->jc.RES.RES_I0);
		printf("RES PA=%d,PB=%d,PC=%d,PZ=%d\n\r",JDataFileInfo->jc.RES.RES_PA,JDataFileInfo->jc.RES.RES_PB,JDataFileInfo->jc.RES.RES_PC,JDataFileInfo->jc.RES.RES_PZ);
		printf("RES QA=%d,QB=%d,QC=%d,QZ=%d\n\r",JDataFileInfo->jc.RES.RES_QA,JDataFileInfo->jc.RES.RES_QB,JDataFileInfo->jc.RES.RES_QC,JDataFileInfo->jc.RES.RES_QZ);
		printf("RES SA=%d,SB=%d,SC=%d,SZ=%d\n\r",JDataFileInfo->jc.RES.RES_SA,JDataFileInfo->jc.RES.RES_SB,JDataFileInfo->jc.RES.RES_SC,JDataFileInfo->jc.RES.RES_SZ);
		printf("RES PFA=%d,PFB=%d,PFC=%d,PFZ=%d\n\r",JDataFileInfo->jc.RES.RES_PFA,JDataFileInfo->jc.RES.RES_PFB,JDataFileInfo->jc.RES.RES_PFC,JDataFileInfo->jc.RES.RES_PFZ);
		printf("RES UAJ=%d,UBJ=%d,UCJ=%d\n\r",JDataFileInfo->jc.RES.RES_UAJ,JDataFileInfo->jc.RES.RES_UBJ,JDataFileInfo->jc.RES.RES_UCJ);
		printf("RES IAJ=%d,IBJ=%d,ICJ=%d\n\r",JDataFileInfo->jc.RES.RES_IAJ,JDataFileInfo->jc.RES.RES_IBJ,JDataFileInfo->jc.RES.RES_ICJ);
		printf("RES RES_JXFS=%d,RES_F=%d,RES_FLAG=%d\n\r",JDataFileInfo->jc.RES.RES_JXFS,JDataFileInfo->jc.RES.RES_F,JDataFileInfo->jc.RES.RES_FLAG);
		printf("\nPga=%d,Pgb=%d,Pgc=%d,\n",JConfigInfo->jcxs.REC[0x18],JConfigInfo->jcxs.REC[0x19],JConfigInfo->jcxs.REC[0x1A]);
		printf("\nYUaUb=%d,YUaUc=%d,YUbUc=%d,\n",JConfigInfo->jcxs.REC[0x26],JConfigInfo->jcxs.REC[0x27],JConfigInfo->jcxs.REC[0x28]);
		//JConfigInfo->jcxs.REC[0x18]
		printf("\n\r");
		return;
	}
	if (strcmp("jc", argv[1]) == 0) {
		int jc=1;
		if (argc == 2)
			jc=1;
		else if (atoi(argv[2])==1)
			jc=1;
		else jc=atoi(argv[2]);
		if (jc>=1)
		{
			printf("displayA_jiaoxiu=%02x %02x %02x\n\r",JConfigInfo->jcxs.displayA_jiaoxiu[0],JConfigInfo->jcxs.displayA_jiaoxiu[1],JConfigInfo->jcxs.displayA_jiaoxiu[2]);
			printf("displayB_jiaoxiu=%02x %02x %02x\n\r",JConfigInfo->jcxs.displayB_jiaoxiu[0],JConfigInfo->jcxs.displayB_jiaoxiu[1],JConfigInfo->jcxs.displayB_jiaoxiu[2]);
			printf("displayC_jiaoxiu=%02x %02x %02x\n\r",JConfigInfo->jcxs.displayC_jiaoxiu[0],JConfigInfo->jcxs.displayC_jiaoxiu[1],JConfigInfo->jcxs.displayC_jiaoxiu[2]);
			printf("displayUA_xishu=%02x %02x %02x\n\r",JConfigInfo->jcxs.displayUA_xishu[0],JConfigInfo->jcxs.displayUA_xishu[1],JConfigInfo->jcxs.displayUA_xishu[2]);
			printf("displayUB_xishu=%02x %02x %02x\n\r",JConfigInfo->jcxs.displayUB_xishu[0],JConfigInfo->jcxs.displayUB_xishu[1],JConfigInfo->jcxs.displayUB_xishu[2]);
			printf("displayUC_xishu=%02x %02x %02x\n\r",JConfigInfo->jcxs.displayUC_xishu[0],JConfigInfo->jcxs.displayUC_xishu[1],JConfigInfo->jcxs.displayUC_xishu[2]);
			printf("displayIA_xishu=%02x %02x %02x\n\r",JConfigInfo->jcxs.displayIA_xishu[0],JConfigInfo->jcxs.displayIA_xishu[1],JConfigInfo->jcxs.displayIA_xishu[2]);
			printf("displayIB_xishu=%02x %02x %02x\n\r",JConfigInfo->jcxs.displayIB_xishu[0],JConfigInfo->jcxs.displayIB_xishu[1],JConfigInfo->jcxs.displayIB_xishu[2]);
			printf("displayIC_xishu=%02x %02x %02x\n\r",JConfigInfo->jcxs.displayIC_xishu[0],JConfigInfo->jcxs.displayIC_xishu[1],JConfigInfo->jcxs.displayIC_xishu[2]);
			printf("displayI0_xishu=%02x %02x %02x\n\r",JConfigInfo->jcxs.displayI0_xishu[0],JConfigInfo->jcxs.displayI0_xishu[1],JConfigInfo->jcxs.displayI0_xishu[2]);
			printf("displayPA_xishu=%02x %02x %02x\n\r",JConfigInfo->jcxs.displayPA_xishu[0],JConfigInfo->jcxs.displayPA_xishu[1],JConfigInfo->jcxs.displayPA_xishu[2]);
			printf("displayPB_xishu=%02x %02x %02x\n\r",JConfigInfo->jcxs.displayPB_xishu[0],JConfigInfo->jcxs.displayPB_xishu[1],JConfigInfo->jcxs.displayPB_xishu[2]);
			printf("displayPC_xishu=%02x %02x %02x\n\r",JConfigInfo->jcxs.displayPC_xishu[0],JConfigInfo->jcxs.displayPC_xishu[1],JConfigInfo->jcxs.displayPC_xishu[2]);
			printf("displayMC_out_xishu=%02x %02x %02x\n\r",JConfigInfo->jcxs.displayMC_out_xishu[0],JConfigInfo->jcxs.displayMC_out_xishu[1],JConfigInfo->jcxs.displayMC_out_xishu[2]);
			if (jc>=2)
			{
				printf("REC=");
				for(i=0;i<128;i++)
				{
					if (((i+1)%10)==0)
						printf("\n\r");
					printf("%d-%d ",i+1,JConfigInfo->jcxs.REC[i]);
				}
				printf("\n\r");
				printf("mod_uip_flag=%02x,mod_q_flag=%02x\n\r",JConfigInfo->jcxs.mod_uip_flag,JConfigInfo->jcxs.mod_q_flag);
				printf("\n\r");
			}
			else
			{
				printf("REC=");
				for(i=0;i<0x1d;i++)
				{
					if (((i+1)%10)==0)
						printf("\n\r");
					printf("%d-%d ",i+1,JConfigInfo->jcxs.REC[i]);
				}
				printf("\n\r");
				printf("mod_uip_flag=%02x,mod_q_flag=%02x\n\r",JConfigInfo->jcxs.mod_uip_flag,JConfigInfo->jcxs.mod_q_flag);
				printf("\n\r");
			}
		}
		if (jc>=2)
		{
			printf("RES UA=%u,UB=%u,UC=%u\n\r",JDataFileInfo->jc.RES.RES_UA,JDataFileInfo->jc.RES.RES_UB,JDataFileInfo->jc.RES.RES_UC);
			printf("RES IA=%u,IB=%u,IC=%u,I0=%u\n\r",JDataFileInfo->jc.RES.RES_IA,JDataFileInfo->jc.RES.RES_IB,JDataFileInfo->jc.RES.RES_IC,JDataFileInfo->jc.RES.RES_I0);
			printf("RES PA=%d,PB=%d,PC=%d,PZ=%d\n\r",JDataFileInfo->jc.RES.RES_PA,JDataFileInfo->jc.RES.RES_PB,JDataFileInfo->jc.RES.RES_PC,JDataFileInfo->jc.RES.RES_PZ);
			printf("RES QA=%d,QB=%d,QC=%d,QZ=%d\n\r",JDataFileInfo->jc.RES.RES_QA,JDataFileInfo->jc.RES.RES_QB,JDataFileInfo->jc.RES.RES_QC,JDataFileInfo->jc.RES.RES_QZ);
			printf("RES SA=%d,SB=%d,SC=%d,SZ=%d\n\r",JDataFileInfo->jc.RES.RES_SA,JDataFileInfo->jc.RES.RES_SB,JDataFileInfo->jc.RES.RES_SC,JDataFileInfo->jc.RES.RES_SZ);
			printf("RES PFA=%d,PFB=%d,PFC=%d,PFZ=%d\n\r",JDataFileInfo->jc.RES.RES_PFA,JDataFileInfo->jc.RES.RES_PFB,JDataFileInfo->jc.RES.RES_PFC,JDataFileInfo->jc.RES.RES_PFZ);
			printf("RES UAJ=%d,UBJ=%d,UCJ=%d\n\r",JDataFileInfo->jc.RES.RES_UAJ,JDataFileInfo->jc.RES.RES_UBJ,JDataFileInfo->jc.RES.RES_UCJ);
			printf("RES IAJ=%d,IBJ=%d,ICJ=%d\n\r",JDataFileInfo->jc.RES.RES_IAJ,JDataFileInfo->jc.RES.RES_IBJ,JDataFileInfo->jc.RES.RES_ICJ);
			printf("RES RES_JXFS=%d,RES_F=%d,RES_FLAG=%d\n\r",JDataFileInfo->jc.RES.RES_JXFS,JDataFileInfo->jc.RES.RES_F,JDataFileInfo->jc.RES.RES_FLAG);
			printf("\n\r");
		}

		if (jc==2)
		{
			printf("JcMaxXuliang Valid=%d,Chao_Time=%02x-%02x-%02x %02x:%02x\n\r",JDataFileInfo->jc.JcMaxXuliang.Valid,JDataFileInfo->jc.JcMaxXuliang.Chao_Time.BCD05,JDataFileInfo->jc.JcMaxXuliang.Chao_Time.BCD04,JDataFileInfo->jc.JcMaxXuliang.Chao_Time.BCD03,JDataFileInfo->jc.JcMaxXuliang.Chao_Time.BCD02,JDataFileInfo->jc.JcMaxXuliang.Chao_Time.BCD01);
			printf("JcMaxXuliang Z_P_X_All=%d",JDataFileInfo->jc.JcMaxXuliang.Z_P_X_All);
			for(i=0;i<FeiLvNum;i++)
				printf(",Z_P_X_F[%d]=%d",i,JDataFileInfo->jc.JcMaxXuliang.Z_P_X_F[i]);
			printf("\n\r");
			printf("JcMaxXuliang F_P_X_All=%d",JDataFileInfo->jc.JcMaxXuliang.F_P_X_All);
			for(i=0;i<FeiLvNum;i++)
				printf(",F_P_X_F[%d]=%d",i,JDataFileInfo->jc.JcMaxXuliang.F_P_X_F[i]);
			printf("\n\r");
			printf("JcMaxXuliang Z_Q_X_All=%d",JDataFileInfo->jc.JcMaxXuliang.Z_Q_X_All);
			for(i=0;i<FeiLvNum;i++)
				printf(",Z_Q_X_F[%d]=%d",i,JDataFileInfo->jc.JcMaxXuliang.Z_Q_X_F[i]);
			printf("\n\r");
			printf("JcMaxXuliang F_Q_X_All=%d",JDataFileInfo->jc.JcMaxXuliang.F_Q_X_All);
			for(i=0;i<FeiLvNum;i++)
				printf(",F_Q_X_F[%d]=%d",i,JDataFileInfo->jc.JcMaxXuliang.F_Q_X_F[i]);
			printf("\n\r");
			printf("JcMaxXuliang Time_Z_P_X_All=%02x %02x %02x %02x\n\r",JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_All[0],JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_All[1],JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_All[2],JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_All[3]);
			for(i=0;i<FeiLvNum;i++)
				printf("Time_Z_P_X_F[%d]=%02x %02x %02x %02x ",i,JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_F[i][0],JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_F[i][1],JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_F[i][2],JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_F[i][3]);
			printf("\n\r");
			printf("JcMaxXuliang Time_F_P_X_All=%02x %02x %02x %02x\n\r",JDataFileInfo->jc.JcMaxXuliang.Time_F_P_X_All[0],JDataFileInfo->jc.JcMaxXuliang.Time_F_P_X_All[1],JDataFileInfo->jc.JcMaxXuliang.Time_F_P_X_All[2],JDataFileInfo->jc.JcMaxXuliang.Time_F_P_X_All[3]);
			for(i=0;i<FeiLvNum;i++)
				printf("Time_F_P_X_F[%d]=%02x %02x %02x %02x ",i,JDataFileInfo->jc.JcMaxXuliang.Time_F_P_X_F[i][0],JDataFileInfo->jc.JcMaxXuliang.Time_F_P_X_F[i][1],JDataFileInfo->jc.JcMaxXuliang.Time_F_P_X_F[i][2],JDataFileInfo->jc.JcMaxXuliang.Time_F_P_X_F[i][3]);
			printf("\n\r");
			printf("JcMaxXuliang Time_Z_Q_X_All=%02x %02x %02x %02x\n\r",JDataFileInfo->jc.JcMaxXuliang.Time_Z_Q_X_All[0],JDataFileInfo->jc.JcMaxXuliang.Time_Z_Q_X_All[1],JDataFileInfo->jc.JcMaxXuliang.Time_Z_Q_X_All[2],JDataFileInfo->jc.JcMaxXuliang.Time_Z_Q_X_All[3]);
			for(i=0;i<FeiLvNum;i++)
				printf("Time_Z_Q_X_F[%d]=%02x %02x %02x %02x ",i,JDataFileInfo->jc.JcMaxXuliang.Time_Z_Q_X_F[i][0],JDataFileInfo->jc.JcMaxXuliang.Time_Z_Q_X_F[i][1],JDataFileInfo->jc.JcMaxXuliang.Time_Z_Q_X_F[i][2],JDataFileInfo->jc.JcMaxXuliang.Time_Z_Q_X_F[i][3]);
			printf("\n\r");
			printf("JcMaxXuliang Time_F_Q_X_All=%02x %02x %02x %02x\n\r",JDataFileInfo->jc.JcMaxXuliang.Time_F_Q_X_All[0],JDataFileInfo->jc.JcMaxXuliang.Time_F_Q_X_All[1],JDataFileInfo->jc.JcMaxXuliang.Time_F_Q_X_All[2],JDataFileInfo->jc.JcMaxXuliang.Time_F_Q_X_All[3]);
			for(i=0;i<FeiLvNum;i++)
				printf("Time_F_Q_X_F[%d]=%02x %02x %02x %02x ",i,JDataFileInfo->jc.JcMaxXuliang.Time_F_Q_X_F[i][0],JDataFileInfo->jc.JcMaxXuliang.Time_F_Q_X_F[i][1],JDataFileInfo->jc.JcMaxXuliang.Time_F_Q_X_F[i][2],JDataFileInfo->jc.JcMaxXuliang.Time_F_Q_X_F[i][3]);
			printf("\n\r");
			printf("JcMaxXuliang UAJ=%d,UBJ=%d,UCJ=%d\n\r",JDataFileInfo->jc.JcMaxXuliang.UAJ,JDataFileInfo->jc.JcMaxXuliang.UBJ,JDataFileInfo->jc.JcMaxXuliang.UCJ);
			printf("JcMaxXuliang IAJ=%d,IBJ=%d,ICJ=%d\n\r",JDataFileInfo->jc.JcMaxXuliang.IAJ,JDataFileInfo->jc.JcMaxXuliang.IBJ,JDataFileInfo->jc.JcMaxXuliang.ICJ);
			printf("JcMaxXuliang JcStat=%d,Check=%d\n\r",JDataFileInfo->jc.JcMaxXuliang.JcStat,JDataFileInfo->jc.JcMaxXuliang.Check);
			printf("\n\r");

			printf("JcOldXuLiang Month=%d,Z_P_Value=%d,Z_Q_Value=%d,F_P_Value=%d,F_Q_Value=%d\n\r",JDataFileInfo->jc.JcOldXuLiang.Month,JDataFileInfo->jc.JcOldXuLiang.Z_P_Value,JDataFileInfo->jc.JcOldXuLiang.Z_Q_Value,JDataFileInfo->jc.JcOldXuLiang.F_P_Value,JDataFileInfo->jc.JcOldXuLiang.F_Q_Value);
			printf("JcOldXuLiang ");
			for(i=0;i<FeiLvNum;i++)
				printf("Z_P_FL_Value[%d]=%d ",i,JDataFileInfo->jc.JcOldXuLiang.Z_P_FL_Value[i]);
			printf("\n\r");
			printf("JcOldXuLiang ");
			for(i=0;i<FeiLvNum;i++)
				printf("F_P_FL_Value[%d]=%d ",i,JDataFileInfo->jc.JcOldXuLiang.F_P_FL_Value[i]);
			printf("\n\r");
			printf("JcOldXuLiang ");
			for(i=0;i<FeiLvNum;i++)
				printf("Z_Q_FL_Value[%d]=%d ",i,JDataFileInfo->jc.JcOldXuLiang.Z_Q_FL_Value[i]);
			printf("\n\r");
			printf("JcOldXuLiang ");
			for(i=0;i<FeiLvNum;i++)
				printf("F_Q_FL_Value[%d]=%d ",i,JDataFileInfo->jc.JcOldXuLiang.F_Q_FL_Value[i]);
			printf("\n\r");
			printf("JcOldXuLiang ");
			for(i=0;i<FeiLvNum;i++)
				printf("X1_Q_FL_Value[%d]=%d ",i,JDataFileInfo->jc.JcOldXuLiang.X1_Q_FL_Value[i]);
			printf("\n\r");
			printf("JcOldXuLiang ");
			for(i=0;i<FeiLvNum;i++)
				printf("X2_Q_FL_Value[%d]=%d ",i,JDataFileInfo->jc.JcOldXuLiang.X2_Q_FL_Value[i]);
			printf("\n\r");
			printf("JcOldXuLiang ");
			for(i=0;i<FeiLvNum;i++)
				printf("X3_Q_FL_Value[%d]=%d ",i,JDataFileInfo->jc.JcOldXuLiang.X3_Q_FL_Value[i]);
			printf("\n\r");
			printf("JcOldXuLiang ");
			for(i=0;i<FeiLvNum;i++)
				printf("X4_Q_FL_Value[%d]=%d ",i,JDataFileInfo->jc.JcOldXuLiang.X4_Q_FL_Value[i]);
			printf("\n\r");
			printf("\n\r");

			printf("JcMaxXXXuliang Valid=%d,Chao_Time=%02x-%02x-%02x %02x:%02x\n\r",JDataFileInfo->jc.JcMaxXXXuliang.Valid,JDataFileInfo->jc.JcMaxXXXuliang.Chao_Time.BCD05,JDataFileInfo->jc.JcMaxXXXuliang.Chao_Time.BCD04,JDataFileInfo->jc.JcMaxXXXuliang.Chao_Time.BCD03,JDataFileInfo->jc.JcMaxXXXuliang.Chao_Time.BCD02,JDataFileInfo->jc.JcMaxXXXuliang.Chao_Time.BCD01);
			printf("JcMaxXXXuliang ");
			for(i=0;i<FeiLvNum;i++)
				printf("X1_Q_F[%d]=%d ",i,JDataFileInfo->jc.JcMaxXXXuliang.X1_Q_F[i]);
			printf("\n\r");
			printf("JcMaxXXXuliang ");
			for(i=0;i<FeiLvNum;i++)
				printf("X2_Q_F[%d]=%d ",i,JDataFileInfo->jc.JcMaxXXXuliang.X2_Q_F[i]);
			printf("\n\r");
			printf("JcMaxXXXuliang ");
			for(i=0;i<FeiLvNum;i++)
				printf("X3_Q_F[%d]=%d ",i,JDataFileInfo->jc.JcMaxXXXuliang.X3_Q_F[i]);
			printf("\n\r");
			printf("JcMaxXXXuliang ");
			for(i=0;i<FeiLvNum;i++)
				printf("X4_Q_F[%d]=%d ",i,JDataFileInfo->jc.JcMaxXXXuliang.X4_Q_F[i]);
			printf("\n\r");
			printf("JcMaxXXXuliang ");
			for(i=0;i<FeiLvNum;i++)
				printf("Time_X1_Q_F[%d]=%02x %02x %02x %02x ",i,JDataFileInfo->jc.JcMaxXXXuliang.Time_X1_Q_F[i][0],JDataFileInfo->jc.JcMaxXXXuliang.Time_X1_Q_F[i][1],JDataFileInfo->jc.JcMaxXXXuliang.Time_X1_Q_F[i][2],JDataFileInfo->jc.JcMaxXXXuliang.Time_X1_Q_F[i][3]);
			printf("\n\r");
			printf("JcMaxXXXuliang ");
			for(i=0;i<FeiLvNum;i++)
				printf("Time_X2_Q_F[%d]=%02x %02x %02x %02x ",i,JDataFileInfo->jc.JcMaxXXXuliang.Time_X2_Q_F[i][0],JDataFileInfo->jc.JcMaxXXXuliang.Time_X2_Q_F[i][1],JDataFileInfo->jc.JcMaxXXXuliang.Time_X2_Q_F[i][2],JDataFileInfo->jc.JcMaxXXXuliang.Time_X2_Q_F[i][3]);
			printf("\n\r");
			printf("JcMaxXXXuliang ");
			for(i=0;i<FeiLvNum;i++)
				printf("Time_X3_Q_F[%d]=%02x %02x %02x %02x ",i,JDataFileInfo->jc.JcMaxXXXuliang.Time_X3_Q_F[i][0],JDataFileInfo->jc.JcMaxXXXuliang.Time_X3_Q_F[i][1],JDataFileInfo->jc.JcMaxXXXuliang.Time_X3_Q_F[i][2],JDataFileInfo->jc.JcMaxXXXuliang.Time_X3_Q_F[i][3]);
			printf("\n\r");
			printf("JcMaxXXXuliang ");
			for(i=0;i<FeiLvNum;i++)
				printf("Time_X4_Q_F[%d]=%02x %02x %02x %02x ",i,JDataFileInfo->jc.JcMaxXXXuliang.Time_X4_Q_F[i][0],JDataFileInfo->jc.JcMaxXXXuliang.Time_X4_Q_F[i][1],JDataFileInfo->jc.JcMaxXXXuliang.Time_X4_Q_F[i][2],JDataFileInfo->jc.JcMaxXXXuliang.Time_X4_Q_F[i][3]);
			printf("\n\r");
			printf("JcMaxXXXuliang Q_X_1=%d,Q_X_2=%d,Q_X_3=%d,Q_X_4=%d\n\r",JDataFileInfo->jc.JcMaxXXXuliang.Q_X_1,JDataFileInfo->jc.JcMaxXXXuliang.Q_X_2,JDataFileInfo->jc.JcMaxXXXuliang.Q_X_3,JDataFileInfo->jc.JcMaxXXXuliang.Q_X_4);
			printf("\n\r");
		}

		if (jc>=1)
		{
			printf("JcDdRealData Valid=%d,Z_P_All=%d,QX_Z_P_All=%d",JDataFileInfo->jc.JcDdRealData.Valid,JDataFileInfo->jc.JcDdRealData.Z_P_All,JDataFileInfo->jc.JcDdRealData.QX_Z_P_All);
			for(i=0;i<FeiLvNum;i++)
				printf(",Z_P_F[%d]=%d",i,JDataFileInfo->jc.JcDdRealData.Z_P_F[i]);
			printf("\n\r");
			printf("JcDdRealData F_P_All=%d,QX_F_P_All=%d",JDataFileInfo->jc.JcDdRealData.F_P_All,JDataFileInfo->jc.JcDdRealData.QX_F_P_All);
			for(i=0;i<FeiLvNum;i++)
				printf(",F_P_F[%d]=%d",i,JDataFileInfo->jc.JcDdRealData.F_P_F[i]);
			printf("\n\r");
			printf("JcDdRealData Z_Q_All=%d,QX_Z_Q_All=%d",JDataFileInfo->jc.JcDdRealData.Z_Q_All,JDataFileInfo->jc.JcDdRealData.QX_Z_Q_All);
			for(i=0;i<FeiLvNum;i++)
				printf(",Z_Q_F[%d]=%d",i,JDataFileInfo->jc.JcDdRealData.Z_Q_F[i]);
			printf("\n\r");
			printf("JcDdRealData F_Q_All=%d,QX_F_Q_All=%d",JDataFileInfo->jc.JcDdRealData.F_Q_All,JDataFileInfo->jc.JcDdRealData.QX_F_Q_All);
			for(i=0;i<FeiLvNum;i++)
				printf(",F_Q_F[%d]=%d",i,JDataFileInfo->jc.JcDdRealData.F_Q_F[i]);
			printf("\n\r");
			printf("JcDdRealData X1_Q_All=%d",JDataFileInfo->jc.JcDdRealData.X1_Q_All);
			for(i=0;i<FeiLvNum;i++)
				printf(",X1_F_Q[%d]=%d",i,JDataFileInfo->jc.JcDdRealData.X1_F_Q[i]);
			printf("\n\r");
			printf("JcDdRealData X4_Q_All=%d",JDataFileInfo->jc.JcDdRealData.X4_Q_All);
			for(i=0;i<FeiLvNum;i++)
				printf(",X4_F_Q[%d]=%d",i,JDataFileInfo->jc.JcDdRealData.X4_F_Q[i]);
			printf("\n\r");
			printf("JcDdRealData X2_Q_All=%d",JDataFileInfo->jc.JcDdRealData.X2_Q_All);
			for(i=0;i<FeiLvNum;i++)
				printf(",X2_F_Q[%d]=%d",i,JDataFileInfo->jc.JcDdRealData.X2_F_Q[i]);
			printf("\n\r");
			printf("JcDdRealData X3_Q_All=%d",JDataFileInfo->jc.JcDdRealData.X3_Q_All);
			for(i=0;i<FeiLvNum;i++)
				printf(",X3_F_Q[%d]=%d",i,JDataFileInfo->jc.JcDdRealData.X3_F_Q[i]);
			printf("\n\r");
			printf("JcDdRealData UA=%u,UB=%u,UC=%u,S=%d\n\r",JDataFileInfo->jc.JcDdRealData.VA,JDataFileInfo->jc.JcDdRealData.VB,JDataFileInfo->jc.JcDdRealData.VC,JDataFileInfo->jc.JcDdRealData.S);
			printf("JcDdRealData IA=%u,IB=%u,IC=%u,IL=%u\n\r",JDataFileInfo->jc.JcDdRealData.IA,JDataFileInfo->jc.JcDdRealData.IB,JDataFileInfo->jc.JcDdRealData.IC,JDataFileInfo->jc.JcDdRealData.IL);
			printf("JcDdRealData PA=%d,PB=%d,PC=%d,PZ=%d\n\r",JDataFileInfo->jc.JcDdRealData.PA,JDataFileInfo->jc.JcDdRealData.PB,JDataFileInfo->jc.JcDdRealData.PC,JDataFileInfo->jc.JcDdRealData.P);
			printf("JcDdRealData QA=%d,QB=%d,QC=%d,QZ=%d\n\r",JDataFileInfo->jc.JcDdRealData.QA,JDataFileInfo->jc.JcDdRealData.QB,JDataFileInfo->jc.JcDdRealData.QC,JDataFileInfo->jc.JcDdRealData.Q);
			printf("JcDdRealData CosA=%d,CosB=%d,CosC=%d,Cos=%d\n\r",JDataFileInfo->jc.JcDdRealData.CosA,JDataFileInfo->jc.JcDdRealData.CosB,JDataFileInfo->jc.JcDdRealData.CosC,JDataFileInfo->jc.JcDdRealData.Cos);
			printf("JcDdRealData Check=%d,Chao_Time=%02x-%02x-%02x %02x:%02x\n\r",JDataFileInfo->jc.JcDdRealData.Check,JDataFileInfo->jc.JcDdRealData.Chao_Time.BCD05,JDataFileInfo->jc.JcDdRealData.Chao_Time.BCD04,JDataFileInfo->jc.JcDdRealData.Chao_Time.BCD03,JDataFileInfo->jc.JcDdRealData.Chao_Time.BCD02,JDataFileInfo->jc.JcDdRealData.Chao_Time.BCD01);
			printf("\n\r");
		}
		if (jc==2)
		{
			printf("JcXuLiangCalc Offset=%d\n\r",JDataFileInfo->jc.JcXuLiangCalc.Offset);
			printf("JcXuLiangCalc ");
			for(i=0;i<15;i++)
			{
				if (((i+1)%5)==0)
					printf("\n\r");
				printf("Z_P_Value[%d]=%d ",i,JDataFileInfo->jc.JcXuLiangCalc.Z_P_Value[i]);
			}
			printf("\n\r");
			printf("JcXuLiangCalc ");
			for(i=0;i<15;i++)
			{
				if (((i+1)%5)==0)
					printf("\n\r");
				printf("Z_Q_Value[%d]=%d ",i,JDataFileInfo->jc.JcXuLiangCalc.Z_Q_Value[i]);
			}
			printf("\n\r");
			printf("JcXuLiangCalc ");
			for(i=0;i<15;i++)
			{
				if (((i+1)%5)==0)
					printf("\n\r");
				printf("F_P_Value[%d]=%d ",i,JDataFileInfo->jc.JcXuLiangCalc.F_P_Value[i]);
			}
			printf("\n\r");
			printf("JcXuLiangCalc ");
			for(i=0;i<15;i++)
			{
				if (((i+1)%5)==0)
					printf("\n\r");
				printf("F_Q_Value[%d]=%d ",i,JDataFileInfo->jc.JcXuLiangCalc.F_Q_Value[i]);
			}
			printf("\n\r");
			int j=0;
			printf("JcXuLiangCalc ");
			for(j=0;j<FeiLvNum;j++)
			{
				for(i=0;i<15;i++)
				{
					if (((i+1)%5)==0)
						printf("\n\r");
					printf("Z_P_FL_Value[%d][%d]=%d ",j,i,JDataFileInfo->jc.JcXuLiangCalc.Z_P_FL_Value[j][i]);
				}
				printf("\n\r");
			}
			printf("JcXuLiangCalc ");
			for(j=0;j<FeiLvNum;j++)
			{
				for(i=0;i<15;i++)
				{
					if (((i+1)%5)==0)
						printf("\n\r");
					printf("Z_Q_FL_Value[%d][%d]=%d ",j,i,JDataFileInfo->jc.JcXuLiangCalc.Z_Q_FL_Value[j][i]);
				}
				printf("\n\r");
			}
			printf("JcXuLiangCalc ");
			for(j=0;j<FeiLvNum;j++)
			{
				for(i=0;i<15;i++)
				{
					if (((i+1)%5)==0)
						printf("\n\r");
					printf("F_P_FL_Value[%d][%d]=%d ",j,i,JDataFileInfo->jc.JcXuLiangCalc.F_P_FL_Value[j][i]);
				}
				printf("\n\r");
			}
			printf("JcXuLiangCalc ");
			for(j=0;j<FeiLvNum;j++)
			{
				for(i=0;i<15;i++)
				{
					if (((i+1)%5)==0)
						printf("\n\r");
					printf("F_Q_FL_Value[%d][%d]=%d ",j,i,JDataFileInfo->jc.JcXuLiangCalc.F_Q_FL_Value[j][i]);
				}
				printf("\n\r");
			}
			printf("JcXuLiangCalc ");
			for(j=0;j<FeiLvNum;j++)
			{
				for(i=0;i<15;i++)
				{
					if (((i+1)%5)==0)
						printf("\n\r");
					printf("X1_Q_FL_Value[%d][%d]=%d ",j,i,JDataFileInfo->jc.JcXuLiangCalc.X1_Q_FL_Value[j][i]);
				}
				printf("\n\r");
			}
			printf("JcXuLiangCalc ");
			for(j=0;j<FeiLvNum;j++)
			{
				for(i=0;i<15;i++)
				{
					if (((i+1)%5)==0)
						printf("\n\r");
					printf("X2_Q_FL_Value[%d][%d]=%d ",j,i,JDataFileInfo->jc.JcXuLiangCalc.X2_Q_FL_Value[j][i]);
				}
				printf("\n\r");
			}
			printf("JcXuLiangCalc ");
			for(j=0;j<FeiLvNum;j++)
			{
				for(i=0;i<15;i++)
				{
					if (((i+1)%5)==0)
						printf("\n\r");
					printf("X3_Q_FL_Value[%d][%d]=%d ",j,i,JDataFileInfo->jc.JcXuLiangCalc.X3_Q_FL_Value[j][i]);
				}
				printf("\n\r");
			}
			printf("JcXuLiangCalc ");
			for(j=0;j<FeiLvNum;j++)
			{
				for(i=0;i<15;i++)
				{
					if (((i+1)%5)==0)
						printf("\n\r");
					printf("X4_Q_FL_Value[%d][%d]=%d ",j,i,JDataFileInfo->jc.JcXuLiangCalc.X4_Q_FL_Value[j][i]);
				}
				printf("\n\r");
			}
			printf("\n\r");
			printf("NowFeiLvNo=%d,Setting=%d,JcXiu=%d\n\r",JDataFileInfo->jc.NowFeiLvNo,JDataFileInfo->jc.Setting,JDataFileInfo->jc.JcXiu);
		}

		return;
	}

	if (strcmp("jccheck", argv[1]) == 0)
	{
		INT16U k=0;
		printf("\n\r\n\r\n\r\n\r");

		printf("\n\r                            %s\n\r","��GPRS�װ�ң�⾫�Ȳ�����");
		printf("\n\r%s","�밴������Ҫ����в�����\n\r");
		printf("\n\r%s","1�����µ�ѹ�����������ֵʱ����(�������߼�220v��5A��0�Ȼ���90��)��������Ч��\r");
		printf("\n\r%s","2����ѹ���������ȼ�����ֵ������0.5���ȼ����ڣ�\r");
		printf("\n\r%s","3�����ʵ����ȼ�����ֵ������0.5���ȼ����ڣ�\r");


		printf("\n\r*************************************************************************");
		printf("\n\r                           %s","����������ʾ���£�");
		printf("\n\r*************************************************************************\n\r");
		if(JDataFileInfo->jc.RES.RES_UA != 0)
		{
			k = abs(JDataFileInfo->jc.RES.RES_UA-2200);
			//printf("Ua=%d---%d\n\r",JDataFileInfo->jc.RES.RES_UA,k);
			if(10*k <= 110)
			{
				if(k*1000/2200<10) printf("\n\r%s0.%d%s", "Ua�����ϸ�OK!!!   �����ȼ�С��(����)",k*1000/2200,"��\n\r");
				else printf("\n\r%s%d.%d%s", "Ua�����ϸ�OK!!!   �����ȼ�С��(����)",k*1000/2200/10,k*1000/2200%10,"��\n\r");
			}
			else
			{
				if(k*1000/2200<10)printf("\n\r%s0.%d%s", "......������!!! Ua�������ϸ�NONONO!!!  �����ȼ�����",k*1000/2200,"��\n\r");
				else printf("\n\r%s%d.%d%s", "......������!!! Ua�������ϸ�NONONO!!!!     �����ȼ�����",k*1000/2200/10,k*1000/2200%10,"��\n\r");
			}
		}

		if(JDataFileInfo->jc.RES.RES_UB != 0)
		{
			k = abs(JDataFileInfo->jc.RES.RES_UB-2200);
			if(10*k <= 110)
			{
				if(k*1000/2200<10) printf("\n\r%s0.%d%s", "Ub�����ϸ�OK!!!   �����ȼ�С��(����)",k*1000/2200,"��\n\r");
				else printf("\n\r%s%d.%d%s", "Ub�����ϸ�OK!!!   �����ȼ�С��(����)",k*1000/2200/10,k*1000/2200%10,"��\n\r");
			}
			else
			{
				if(k*1000/2200<10)printf("\n\r%s0.%d%s", "......������!!! Ub�������ϸ�NONONO!!!  �����ȼ�����",k*1000/2200,"��\n\r");
				else printf("\n\r%s%d.%d%s", "......������!!! Ub�������ϸ�NONONO!!!!     �����ȼ�����",k*1000/2200/10,k*1000/2200%10,"��\n\r");
			}
		}


		if(JDataFileInfo->jc.RES.RES_UC != 0)
		{
			k = abs(JDataFileInfo->jc.RES.RES_UC-2200);
			if(10*k <= 110)
			{
				if(k*1000/2200<10) printf("\n\r%s0.%d%s", "Uc�����ϸ�OK!!!   �����ȼ�С��(����)",k*1000/2200,"��\n\r");
				else printf("\n\r%s%d.%d%s", "Uc�����ϸ�OK!!!   �����ȼ�С��(����)",k*1000/2200/10,k*1000/2200%10,"��\n\r");
			}
			else
			{
				if(k*1000/2200<10)printf("\n\r%s0.%d%s", "......������!!! Uc�������ϸ�NONONO!!!  �����ȼ�����",k*1000/2200,"��\n\r");
				else printf("\n\r%s%d.%d%s", "......������!!! Uc�������ϸ�NONONO!!!!     �����ȼ�����",k*1000/2200/10,k*1000/2200%10,"��\n\r");
			}
		}

		printf("\n\r\n\r");

		if(JDataFileInfo->jc.RES.RES_IA != 0)
		{
			k = abs(JDataFileInfo->jc.RES.RES_IA-5000);
			//printf("Ua=%d---%d\n\r",JDataFileInfo->jc.RES.RES_IA,k);
			if(k <= 25)
			{
				if(k*1000/5000<10)printf("\n\r%s0.%d%s", "Ia�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�",k*1000/5000,"��\n\r");
				else printf("\n\r%s%d.%d%s", "Ia�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�",k*1000/5000/10,k*1000/5000%10,"��\n\r");
			}
			else
			{
				if(k*1000/5000<10)printf("\n\r%s0.%d%s", "......������!!!Ia�������ϸ�NONONO!!!!!     �����ȼ�����",k*1000/5000,"��\n\r");
				else printf("\n\r%s%d.%d%s", "......������!!!Ia�������ϸ�NONONO!!!!!     �����ȼ�����",k*1000/5000/10,k*1000/5000%10,"��\n\r");
			}
		}

		if(JDataFileInfo->jc.RES.RES_IB != 0)
		{
			if(k <= 25)
			{
				if(k*1000/5000<10)printf("\n\r%s0.%d%s", "Ib�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�",k*1000/5000,"��\n\r");
				else printf("\n\r%s%d.%d%s", "Ia�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�",k*1000/5000/10,k*1000/5000%10,"��\n\r");
			}
			else
			{
				if(k*1000/5000<10)printf("\n\r%s0.%d%s", "......������!!!Ia�������ϸ�NONONO!!!!!     �����ȼ�����",k*1000/5000,"��\n\r");
				else printf("\n\r%s%d.%d%s", "......������!!!Ib�������ϸ�NONONO!!!!!     �����ȼ�����",k*1000/5000/10,k*1000/5000%10,"��\n\r");
			}
		}

		if(JDataFileInfo->jc.RES.RES_IC != 0)
		{
			k = abs(JDataFileInfo->jc.RES.RES_IC-5000);
			if(k <= 25)
			{
				if(k*1000/5000<10)printf("\n\r%s0.%d%s", "Ic�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�",k*1000/5000,"��\n\r");
				else printf("\n\r%s%d.%d%s", "Ia�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�",k*1000/5000/10,k*1000/5000%10,"��\n\r");
			}
			else
			{
				if(k*1000/5000<10)printf("\n\r%s0.%d%s", "......������!!!Ia�������ϸ�NONONO!!!!!     �����ȼ�����",k*1000/5000,"��\n\r");
				else printf("\n\r%s%d.%d%s", "......������!!!Ic�������ϸ�NONONO!!!!!     �����ȼ�����",k*1000/5000/10,k*1000/5000%10,"��\n\r");
			}
		}
		printf("\n\r\n\r");

		if(JDataFileInfo->jc.RES.RES_PFZ > 450)
		{//yougong
			if(JDataFileInfo->jc.RES.RES_PA != 0)
			{
				k = abs(JDataFileInfo->jc.RES.RES_PA-5500);
				if(k <= 28)
				{
					if(k*1000/5500<10)printf("\n\r%s0.%d%s", "Pa�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�",k*1000/5500,"��\n\r");
					else printf("\n\r%s%d.%d%s", "Pa�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�",k*1000/5500/10,k*1000/5500%10,"��\n\r");
				}
				else
				{
					if(k*1000/5500<10)printf("\n\r%s0.%d%s", "......������!!!Pa�������ϸ�NONONO!!!!!     �����ȼ�����",k*1000/5500,"��\n\r");
					else printf("\n\r%s%d.%d%s", "......������!!!Pa�������ϸ�NONONO!!!!!     �����ȼ�����",k*1000/5500/10,k*1000/5500%10,"��\n\r");
				}
			}

			if(JDataFileInfo->jc.RES.RES_PB != 0)
			{
				k = abs(JDataFileInfo->jc.RES.RES_PB-5500);
				if(k <= 28)
				{
					if(k*1000/5500<10)printf("\n\r%s0.%d%s", "Pb�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�",k*1000/5500,"��\n\r");
					else printf("\n\r%s%d.%d%s", "Pb�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�",k*1000/5500/10,k*1000/5500%10,"��\n\r");
				}
				else
				{
					if(k*1000/5500<10)printf("\n\r%s0.%d%s", "......������!!!Pb�������ϸ�NONONO!!!!!     �����ȼ�����",k*1000/5500,"��\n\r");
					else printf("\n\r%s%d.%d%s", "......������!!!Pb�������ϸ�NONONO!!!!!     �����ȼ�����",k*1000/5500/10,k*1000/5500%10,"��\n\r");
				}
			}

			if(JDataFileInfo->jc.RES.RES_PC != 0)
			{
				k = abs(JDataFileInfo->jc.RES.RES_PC-5500);
				if(k <= 55)
				{
					if(k*1000/5500<10)printf("\n\r%s0.%d%s", "Pc�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�",k*1000/5500,"��\n\r");
					else printf("\n\r%s%d.%d%s", "Pc�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�",k*1000/5500/10,k*1000/5500%10,"��\n\r");
				}
				else
				{
					if(k*1000/5500<10)printf("\n\r%s0.%d%s", "......������!!!Pc�������ϸ�NONONO!!!!!     �����ȼ�����",k*1000/5500,"��\n\r");
					else printf("\n\r%s%d.%d%s", "......������!!!Pc�������ϸ�NONONO!!!!!     �����ȼ�����",k*1000/5500/10,k*1000/5500%10,"��\n\r");
				}
			}
		}
		else
		{//WUGONG
			if(JDataFileInfo->jc.RES.RES_QA != 0)
			{
				k = abs(JDataFileInfo->jc.RES.RES_QA-5500);
				if(k <= 55)
				{
					if(k*1000/5500<10)printf("\n\r%s0.%d%s", "Qa�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�",k*1000/5500,"��\n\r");
					else printf("\n\r%s%d.%d%s", "Qa�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�",k*1000/5500/10,k*1000/5500%10,"��\n\r");
				}
				else
				{
					if(k*1000/5500<10)printf("\n\r%s0.%d%s", "......������!!!Qa�������ϸ�NONONO!!!!!     �����ȼ�����",k*1000/5500,"��\n\r");
					else printf("\n\r%s%d.%d%s", "......������!!!Qa�������ϸ�NONONO!!!!!     �����ȼ�����",k*1000/5500/10,k*1000/5500%10,"��\n\r");
				}
			}

			if(JDataFileInfo->jc.RES.RES_QB != 0)
			{
				k = abs(JDataFileInfo->jc.RES.RES_QB-5500);
				if(k <= 55)
				{
					if(k*1000/5500<10)printf("\n\r%s0.%d%s", "Qb�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�",k*1000/5500,"��\n\r");
					else printf("\n\r%s%d.%d%s", "Qb�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�",k*1000/5500/10,k*1000/5500%10,"��\n\r");
				}
				else
				{
					if(k*1000/5500<10)printf("\n\r%s0.%d%s", "......������!!!Qb�������ϸ�NONONO!!!!!     �����ȼ�����",k*1000/5500,"��\n\r");
					else printf("\n\r%s%d.%d%s", "......������!!!Qb�������ϸ�NONONO!!!!!     �����ȼ�����",k*1000/5500/10,k*1000/5500%10,"��\n\r");
				}
			}

			if(JDataFileInfo->jc.RES.RES_QC != 0)
			{
				k = abs(JDataFileInfo->jc.RES.RES_QC-5500);
				if(k <= 55)
				{
					if(k*1000/5500<10)printf("\n\r%s0.%d%s", "Qc�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�",k*1000/5500,"��\n\r");
					else printf("\n\r%s%d.%d%s", "Qc�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�",k*1000/5500/10,k*1000/5500%10,"��\n\r");
				}
				else
				{
					if(k*1000/5500<10)printf("\n\r%s0.%d%s", "......������!!!Qc�������ϸ�NONONO!!!!!     �����ȼ�����",k*1000/5500,"��\n\r");
					else printf("\n\r%s%d.%d%s", "......������!!!Qc�������ϸ�NONONO!!!!!     �����ȼ�����",k*1000/5500/10,k*1000/5500%10,"��\n\r");
				}
			}
		}

		printf("\n\r\n\r");


		if(JDataFileInfo->jc.RES.RES_PFZ > 450)
		{//zongyougong
			if(JDataFileInfo->jc.RES.RES_PZ != 0)
			{
				k = abs(JDataFileInfo->jc.RES.RES_PZ-16500);
				if(k <= 82)
				{
					if(k*1000/16500<10)printf("\n\r%s0.%d%s","Pz�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�", k*1000/16500,"��\n\r");
					else printf("\n\r%s%d.%d%s", "Pz�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�",k*1000/16500/10,k*1000/16500%10,"��\n\r");
				}
				else
				{
					if(k*1000/16500<10)printf("\n\r%s0.%d%s", "......������!!!Pz�������ϸ�NONONO!!!!     �����ȼ�����",k*1000/16500,"��\n\r");
					else printf("\n\r%s%d.%d%s", "......������!!!Pz�������ϸ�NONONO!!!!     �����ȼ�����",k*1000/16500/10,k*1000/16500%10,"��\n\r");
				}
			}
		}
		else
		{//zongwugong
			if(JDataFileInfo->jc.RES.RES_QZ != 0)
			{
				k = abs(JDataFileInfo->jc.RES.RES_QZ-33000);
				if(k <= 165)
				{
					if(k*1000/33000<10)printf("\n\r%s0.%d%s","Qz�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�", k*1000/33000,"��\n\r");
					else printf("\n\r%s%d.%d%s", "Qz�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�",k*1000/33000/10,k*1000/33000%10,"��\n\r");
				}
				else
				{
					if(k*1000/33000<10)printf("\n\r%s0.%d%s", "......������!!!Qz�������ϸ�NONONO!!!!     �����ȼ�����",k*1000/33000,"��\n\r");
					else printf("\n\r%s%d.%d%s", "......������!!!Qz�������ϸ�NONONO!!!!     �����ȼ�����",k*1000/33000/10,k*1000/33000%10,"��\n\r");
				}
			}
		}

		printf("\n\r*************************************************************************");
		printf("\n\r              %s","���ȼ���ʾ���,�޴�ͨ�����д�����������");
		printf("\n\r*************************************************************************\n\r");

		return;
	}
		if (strcmp("jccheck7022e", argv[1]) == 0)
		{	INT16U k=0;
			if(JDataFileInfo->jc.RES.RES_UA != 0)
			{
				k = abs(JDataFileInfo->jc.RES.RES_UA-2200);
				printf("\nUa = %.2f      k = %d  ",JDataFileInfo->jc.RES.RES_UA/10.0,k);
				if(10*k <= 110)
				{
					if(k*1000/2200<10) printf("%s0.%d%s", "Ua�����ϸ�OK!!!   �����ȼ�С��(����)",k*1000/2200,"��");
					else printf("%s%d.%d%s", "Ua�����ϸ�OK!!!   �����ȼ�С��(����)",k*1000/2200/10,k*1000/2200%10,"��");
				}
				else
				{
					if(k*1000/2200<10)printf("%s0.%d%s", "......������!!! Ua�������ϸ�NONONO!!!  �����ȼ�����",k*1000/2200,"��");
					else printf("%s%d.%d%s", "......������!!! Ua�������ϸ�NONONO!!!!     �����ȼ�����",k*1000/2200/10,k*1000/2200%10,"��");
				}
			}
			else printf("\n\r......������!!! Ua=0�������ϸ�NONONO!!!!    ");

			if(JDataFileInfo->jc.RES.RES_UB != 0)
			{
				k = abs(JDataFileInfo->jc.RES.RES_UB-2200);
				printf("\nUb = %.2f      k = %d  ",JDataFileInfo->jc.RES.RES_UB/10.0,k);
				if(10*k <= 110)
				{
					if(k*1000/2200<10) printf("%s0.%d%s", "Ub�����ϸ�OK!!!   �����ȼ�С��(����)",k*1000/2200,"��");
					else printf("%s%d.%d%s", "Ub�����ϸ�OK!!!   �����ȼ�С��(����)",k*1000/2200/10,k*1000/2200%10,"��");
				}
				else
				{
					if(k*1000/2200<10)printf("%s0.%d%s", "......������!!! Ub�������ϸ�NONONO!!!  �����ȼ�����",k*1000/2200,"��");
					else printf("%s%d.%d%s", "......������!!! Ub�������ϸ�NONONO!!!!     �����ȼ�����",k*1000/2200/10,k*1000/2200%10,"��");
				}
			}
			else printf("\n\r......������!!! Ub=0�������ϸ�NONONO!!!!    ");

			if(JDataFileInfo->jc.RES.RES_UC != 0)
			{
				k = abs(JDataFileInfo->jc.RES.RES_UC-2200);
				printf("\nUc = %.2f      k = %d  ",JDataFileInfo->jc.RES.RES_UC/10.0,k);
				if(10*k <= 110)
				{
					if(k*1000/2200<10) printf("%s0.%d%s", "Uc�����ϸ�OK!!!   �����ȼ�С��(����)",k*1000/2200,"��\n\r");
					else printf("%s%d.%d%s", "Uc�����ϸ�OK!!!   �����ȼ�С��(����)",k*1000/2200/10,k*1000/2200%10,"��\n\r");
				}
				else
				{
					if(k*1000/2200<10)printf("%s0.%d%s", "......������!!! Uc�������ϸ�NONONO!!!  �����ȼ�����",k*1000/2200,"��\n\r");
					else printf("%s%d.%d%s", "......������!!! Uc�������ϸ�NONONO!!!!     �����ȼ�����",k*1000/2200/10,k*1000/2200%10,"��\n\r");
				}
			}
			else printf("\n\r......������!!! Uc=0�������ϸ�NONONO!!!!    ");

			if(JDataFileInfo->jc.RES.RES_IA != 0)
			{
				k = abs(JDataFileInfo->jc.RES.RES_IA-1500);//jiaocai
				if(k <= 7)
				{
				//	if((k/1500)<0.005)
					printf("\n\rIa�����ϸ�OK!!!!   IA=%.3f	, k=%d   �����Ϊ %f%%",JDataFileInfo->jc.RES.RES_IA/1000.0,k,k*1.0/1500*100);
				}
				else
				{
					printf("\n\r.....������      Ia�������ϸ�NONONO!!!!   IA=%.3f	, k=%d   �����Ϊ %f%%",JDataFileInfo->jc.RES.RES_IA/1000.0,k,k*1.0/1500*100);
				}
			}
			else printf("\n\r......������!!! Ia=0�������ϸ�NONONO!!!!    ");

			if(JDataFileInfo->jc.RES.RES_IB != 0)
			{
				k = abs(JDataFileInfo->jc.RES.RES_IB-1500);//jiaocai
				if(k <= 7)
				{
				//	if((k/1500)<0.005)
					printf("\n\rIb�����ϸ�OK!!!!   IB=%.3f	, k=%d   �����Ϊ %f%%",JDataFileInfo->jc.RES.RES_IB/1000.0,k,k*1.0/1500*100);
				}
				else
				{
					printf("\n\r.....������      Ib�������ϸ�NONONO!!!!   IB=%.3f	, k=%d   �����Ϊ %f%%",JDataFileInfo->jc.RES.RES_IB/1000.0,k,k*1.0/1500*100);
				}
			}
			else printf("\n\r......������!!! Ib=0�������ϸ�NONONO!!!!    ");

			if(JDataFileInfo->jc.RES.RES_IC != 0)
			{
				k = abs(JDataFileInfo->jc.RES.RES_IC-1500);//jiaocai
				if(k <= 7)
				{
				//	if((k/1500)<0.005)
					printf("\n\rIc�����ϸ�OK!!!!   IC=%.3f	, k=%d   �����Ϊ %f%%",JDataFileInfo->jc.RES.RES_IC/1000.0,k,k*1.0/1500*100);
				}
				else
				{
					printf("\n\r.....������      Ic�������ϸ�NONONO!!!!   IC=%.3f	, k=%d   �����Ϊ %f%%",JDataFileInfo->jc.RES.RES_IC/1000.0,k,k*1.0/1500*100);
				}
			}
			else printf("\n\r......������!!! Ic=0�������ϸ�NONONO!!!!    ");


			printf("\n\r\n\r");
			if(JDataFileInfo->jc.RES.RES_PFZ > 450)

			{//yougong
				if(JDataFileInfo->jc.RES.RES_PA != 0)
				{
					k = abs(JDataFileInfo->jc.RES.RES_PA-1650);
					printf("\nPA = %.2f      k = %d  ",JDataFileInfo->jc.RES.RES_PA/10.0,k);
					if(k <= 8)
					{
						if(k*1000/1650<10)printf("%s0.%d%s", "Pa�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�",k*1000/1650,"��\n\r");
						else printf("%s%d.%d%s", "Pa�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�",k*1000/1650/10,k*1000/1650%10,"��\n\r");
					}
					else
					{
						if(k*1000/1650<10)printf("%s0.%d%s", "......������!!!Pa�������ϸ�NONONO!!!!!     �����ȼ�����",k*1000/1650,"��\n\r");
						else printf("%s%d.%d%s", "......������!!!Pa�������ϸ�NONONO!!!!!     �����ȼ�����",k*1000/1650/10,k*1000/1650%10,"��\n\r");
					}
				}
				else printf("\n\r......������!!! PA=0�������ϸ�NONONO!!!!    ");


				if(JDataFileInfo->jc.RES.RES_PB != 0)
				{
					k = abs(JDataFileInfo->jc.RES.RES_PB-1650);
					printf("\nPB = %.2f      k = %d  ",JDataFileInfo->jc.RES.RES_PB/10.0,k);
					if(k <= 8)
					{
						if(k*1000/1650<10)printf("%s0.%d%s", "Pb�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�",k*1000/1650,"��\n\r");
						else printf("%s%d.%d%s", "Pb�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�",k*1000/1650/10,k*1000/1650%10,"��\n\r");
					}
					else
					{
						if(k*1000/1650<10)printf("%s0.%d%s", "......������!!!Pb�������ϸ�NONONO!!!!!     �����ȼ�����",k*1000/1650,"��\n\r");
						else printf("%s%d.%d%s", "......������!!!Pb�������ϸ�NONONO!!!!!     �����ȼ�����",k*1000/1650/10,k*1000/1650%10,"��\n\r");
					}
				}
				else printf("\n\r......������!!! PB=0�������ϸ�NONONO!!!!    ");


				if(JDataFileInfo->jc.RES.RES_PC != 0)
				{
					k = abs(JDataFileInfo->jc.RES.RES_PC-1650);
					printf("\nPC = %.2f      k = %d  ",JDataFileInfo->jc.RES.RES_PC/10.0,k);
					if(k <= 8)
					{
						if(k*1000/1650<10)printf("%s0.%d%s", "Pc�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�",k*1000/1650,"��\n\r");
						else printf("%s%d.%d%s", "Pc�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�",k*1000/1650/10,k*1000/1650%10,"��\n\r");
					}
					else
					{
						if(k*1000/1650<10)printf("%s0.%d%s", "......������!!!Pc�������ϸ�NONONO!!!!!     �����ȼ�����",k*1000/1650,"��\n\r");
						else printf("%s%d.%d%s", "......������!!!Pc�������ϸ�NONONO!!!!!     �����ȼ�����",k*1000/1650/10,k*1000/1650%10,"��\n\r");
					}
				}
				else printf("\n\r......������!!! PC=0�������ϸ�NONONO!!!!    ");

			}
	//		else printf("\n\r......������!!! Pz�������ϸ�NONONO!!!!    ");

	//		else
			{//WUGONG
				if(JDataFileInfo->jc.RES.RES_QA != 0)
				{
					k = abs(JDataFileInfo->jc.RES.RES_QA*10-28578);
					printf("\nQA = %.2f      k = %d  ",JDataFileInfo->jc.RES.RES_QA/10.0,k);
					if(k <= 142)
					{
						if(k*1000/28578<10)printf("%s0.%d%s", "Qa�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�",k*1000/28578,"��\n\r");
						else printf("%s%d.%d%s", "Qa�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�",k*1000/28578/10,k*1000/28578%10,"��\n\r");
					}
					else
					{
						if(k*1000/28578<10)printf("%s0.%d%s", "......������!!!Qa�������ϸ�NONONO!!!!!     �����ȼ�����",k*1000/28578,"��\n\r");
						else printf("%s%d.%d%s", "......������!!!Qa�������ϸ�NONONO!!!!!     �����ȼ�����",k*1000/28578/10,k*1000/28578%10,"��\n\r");
					}
				}
				else printf("\n\r......������!!! QA=0�������ϸ�NONONO!!!!    ");

				if(JDataFileInfo->jc.RES.RES_QB != 0)
				{
					k = abs(JDataFileInfo->jc.RES.RES_QB*10-28578);
					printf("\nQB = %.2f      k = %d  ",JDataFileInfo->jc.RES.RES_QB/10.0,k);
					if(k <= 142)
					{
						if(k*1000/28578<10)printf("%s0.%d%s", "Qb�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�",k*1000/28578,"��\n\r");
						else printf("%s%d.%d%s", "Qb�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�",k*1000/28578/10,k*1000/28578%10,"��\n\r");
					}
					else
					{
						if(k*1000/28578<10)printf("%s0.%d%s", "......������!!!Qb�������ϸ�NONONO!!!!!     �����ȼ�����",k*1000/28578,"��\n\r");
						else printf("%s%d.%d%s", "......������!!!Qb�������ϸ�NONONO!!!!!     �����ȼ�����",k*1000/28578/10,k*1000/28578%10,"��\n\r");
					}
				}
				else printf("\n\r......������!!! QB=0�������ϸ�NONONO!!!!    ");

				if(JDataFileInfo->jc.RES.RES_QC != 0)
				{
					k = abs(JDataFileInfo->jc.RES.RES_QC*10-28578);
					printf("\nQC = %.2f      k = %d  ",JDataFileInfo->jc.RES.RES_QC/10.0,k);
					if(k <= 142)
					{
						if(k*1000/28578<10)printf("%s0.%d%s", "Qc�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�",k*1000/28578,"��\n\r");
						else printf("%s%d.%d%s", "Qc�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�",k*1000/28578/10,k*1000/28578%10,"��\n\r");
					}
					else
					{
						if(k*1000/28578<10)printf("%s0.%d%s", "......������!!!Qc�������ϸ�NONONO!!!!!     �����ȼ�����",k*1000/28578,"��\n\r");
						else printf("%s%d.%d%s", "......������!!!Qc�������ϸ�NONONO!!!!!     �����ȼ�����",k*1000/28578/10,k*1000/28578%10,"��\n\r");
					}
				}
				else printf("\n\r......������!!! QC=0�������ϸ�NONONO!!!!    ");

			}

			printf("\n\r\n\r");


	//		if(JDataFileInfo->jc.RES.RES_PFZ > 450)
			{//zongyougong
				if(JDataFileInfo->jc.RES.RES_PZ != 0)
				{
					k = abs(JDataFileInfo->jc.RES.RES_PZ-4950);
					printf("\nPZ = %.2f      k = %d  ",JDataFileInfo->jc.RES.RES_PZ/10.0,k);
					if(k <= 24)
					{
						if(k*1000/4950<10)printf("%s0.%d%s","Pz�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�", k*1000/4950,"��\n\r");
						else printf("%s%d.%d%s", "Pz�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�",k*1000/4950/10,k*1000/4950%10,"��\n\r");
					}
					else
					{
						if(k*1000/4950<10)printf("%s0.%d%s", "......������!!!Pz�������ϸ�NONONO!!!!     �����ȼ�����",k*1000/4950,"��\n\r");
						else printf("%s%d.%d%s", "......������!!!Pz�������ϸ�NONONO!!!!     �����ȼ�����",k*1000/4950/10,k*1000/4950%10,"��\n\r");
					}
				}else printf("\n\r......������!!! PZ=0�������ϸ�NONONO!!!!    ");

			}

	//		else

			{//zongwugong
				if(JDataFileInfo->jc.RES.RES_QZ != 0)
				{
					k = abs(JDataFileInfo->jc.RES.RES_QZ-8574);
					printf("\nQZ = %.2f      k = %d  ",JDataFileInfo->jc.RES.RES_QZ/10.0,k);
					if(k <= 42)
					{
						if(k*1000/8574<10)printf("%s0.%d%s","Qz�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�", k*1000/8574,"��\n\r");
						else printf("%s%d.%d%s", "Qz�����ϸ�OK!!!!     �����ȼ�С�ڣ����ڣ�",k*1000/8574/10,k*1000/8574%10,"��\n\r");
					}
					else
					{
						if(k*1000/8574<10)printf("%s0.%d%s", "......������!!!Qz�������ϸ�NONONO!!!!     �����ȼ�����",k*1000/8574,"��\n\r");
						else printf("%s%d.%d%s", "......������!!!Qz�������ϸ�NONONO!!!!     �����ȼ�����",k*1000/8574/10,k*1000/8574%10,"��\n\r");
					}
				}
				else printf("\n\r......������!!! QZ=0�������ϸ�NONONO!!!!    ");
			}


			printf("\n\r*************************************************************************");
			printf("\n\r              %s","���ȼ���ʾ���,�޴�ͨ�����д�����������");
			printf("\n\r*************************************************************************\n\r");

			return;
		}
	if(strcmp("seton",argv[1])==0)
	{
		JDataFileInfo->jc.Setting=1;
		fprintf(stderr,"\n\rSetting = %d\n",JDataFileInfo->jc.Setting);
		fprintf(stderr,"\n\r[seton end]\n");
		return;
	}
	if(strcmp("my1",argv[1])==0)
	{
		int j=0;
		printf("\n JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_All: %02x-%02x %02x:%02x\n",
				JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_All[3],
				JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_All[2],
				JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_All[1],
				JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_All[0]);
		for(j=0;j<4;j++)
		{
			printf("\n JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_F: %02x-%02x %02x:%02x\n",
					JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_F[j][3],
					JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_F[j][2],
					JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_F[j][1],
					JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_F[j][0]);
		}
		//----------------
		printf("\n JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_All_645: %02x-%02x-%02x %02x:%02x\n",
				JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_All_645[4],
				JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_All_645[3],
				JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_All_645[2],
				JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_All_645[1],
				JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_All_645[0]);
		for(j=0;j<4;j++)
		{
			printf("\n JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_F_645: %02x-%02x-%02x %02x:%02x\n",
					JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_F_645[j][4],
					JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_F_645[j][3],
					JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_F_645[j][2],
					JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_F_645[j][1],
					JDataFileInfo->jc.JcMaxXuliang.Time_Z_P_X_F_645[j][0]);
		}
		return;
	}
	if(strcmp("setoff",argv[1])==0)
	{
		JDataFileInfo->jc.Setting=0;
		fprintf(stderr,"\n\rSetting = %d\n",JDataFileInfo->jc.Setting);
		if(access("/nor/para/",0)!=0)
			system("mkdir /nor/para");
		delay(2000);
		return;
	}

/**************<<<<<<<<<<<<<<<<<***********++++++++++*/
	if(strcmp("qing",argv[1])==0)//��ϱ��Ĵ���
	{
		JDataFileInfo->jc.JcXiu=9;
		return;
	}
	if(strcmp("pquia",argv[1])==0)//У��A��P\Q\U\I
	{
		JDataFileInfo->jc.JcXiu=2;
		return;
	}
	if(strcmp("pquib",argv[1])==0)//У��B��P\Q\U\I
	{
		JDataFileInfo->jc.JcXiu=3;
		return;
	}
	if(strcmp("pquic",argv[1])==0)//У��C��P\Q\U\I
	{
		JDataFileInfo->jc.JcXiu=4;
		return;
	}
	if(strcmp("readspi",argv[1])==0)
	{
		JDataFileInfo->jc.JcXiu=8;
		return;
	}
	if(strcmp("mc",argv[1])==0)
	{
		JDataFileInfo->jc.JcXiu=7;
		return;
	}

	if(strcmp("vala",argv[1])==0)//�����̨A�๦��Preal,Qreal��u��i
	{
		if(argc==2){
			printf("\n\rJmemory->PrealA=%4.1f",JConfigInfo->jcxs.PrealA);
			printf("\n\rJmemory->QrealA=%4.1f",JConfigInfo->jcxs.QrealA);
			printf("\n\rJmemory->UrealA=%3.1f",JConfigInfo->jcxs.UrealA);
			printf("\n\rJmemory->IrealA=%2.2f",JConfigInfo->jcxs.IrealA);

		}else{
			sscanf(argv[2],"%f",&p);
			sscanf(argv[3],"%f",&q);
			sscanf(argv[4],"%f",&u);
			sscanf(argv[5],"%f",&ii);
			JConfigInfo->jcxs.PrealA=p;
			JConfigInfo->jcxs.QrealA=q;
			JConfigInfo->jcxs.UrealA=u;
			JConfigInfo->jcxs.IrealA=ii;
		}
		return;
	}
	if(strcmp("valb",argv[1])==0)//�����̨B�๦��Preal,Qreal��u��i
	{
		if(argc==2){
			printf("\n\rJConfigInfo->jcxs.PrealB=%4.1f",JConfigInfo->jcxs.PrealB);
			printf("\n\rJConfigInfo->jcxs.QrealB=%4.1f",JConfigInfo->jcxs.QrealB);
			printf("\n\rJConfigInfo->jcxs.UrealB=%3.1f",JConfigInfo->jcxs.UrealB);
			printf("\n\rJConfigInfo->jcxs.IrealB=%2.2f",JConfigInfo->jcxs.IrealB);

		}else{
			sscanf(argv[2],"%f",&p);
			sscanf(argv[3],"%f",&q);
			sscanf(argv[4],"%f",&u);
			sscanf(argv[5],"%f",&ii);
			JConfigInfo->jcxs.PrealB=p;
			JConfigInfo->jcxs.QrealB=q;
			JConfigInfo->jcxs.UrealB=u;
			JConfigInfo->jcxs.IrealB=ii;
		}
		return;
	}
	if(strcmp("valc",argv[1])==0)//�����̨C�๦��Preal,Qreal��u��i
	{
		if(argc==2){
			printf("\n\rJConfigInfo->jcxs.PrealC=%4.1f",JConfigInfo->jcxs.PrealC);
			printf("\n\rJConfigInfo->jcxs.QrealC=%4.1f",JConfigInfo->jcxs.QrealC);
			printf("\n\rJConfigInfo->jcxs.UrealC=%3.1f",JConfigInfo->jcxs.UrealC);
			printf("\n\rJConfigInfo->jcxs.IrealC=%2.2f",JConfigInfo->jcxs.IrealC);

		}else{
			sscanf(argv[2],"%f",&p);
			sscanf(argv[3],"%f",&q);
			sscanf(argv[4],"%f",&u);
			sscanf(argv[5],"%f",&ii);
			JConfigInfo->jcxs.PrealC=p;
			JConfigInfo->jcxs.QrealC=q;
			JConfigInfo->jcxs.UrealC=u;
			JConfigInfo->jcxs.IrealC=ii;
		}
		return;
	}
	if(strcmp("val",argv[1])==0)//�����̨C�๦��Preal,Qreal��u��i
	{
		if(argc==2){
			printf("\n\rJConfigInfo->jcxs.PrealA=%4.2f",JConfigInfo->jcxs.PrealA);
			printf("\n\rJConfigInfo->jcxs.QrealA=%4.2f",JConfigInfo->jcxs.QrealA);
			printf("\n\rJConfigInfo->jcxs.UrealA=%3.2f",JConfigInfo->jcxs.UrealA);
			printf("\n\rJConfigInfo->jcxs.IrealA=%2.2f",JConfigInfo->jcxs.IrealA);
			printf("\n\rJConfigInfo->jcxs.PrealB=%4.2f",JConfigInfo->jcxs.PrealB);
			printf("\n\rJConfigInfo->jcxs.QrealB=%4.2f",JConfigInfo->jcxs.QrealB);
			printf("\n\rJConfigInfo->jcxs.UrealB=%3.2f",JConfigInfo->jcxs.UrealB);
			printf("\n\rJConfigInfo->jcxs.IrealB=%2.2f",JConfigInfo->jcxs.IrealB);
			printf("\n\rJConfigInfo->jcxs.PrealC=%4.2f",JConfigInfo->jcxs.PrealC);
			printf("\n\rJConfigInfo->jcxs.QrealC=%4.2f",JConfigInfo->jcxs.QrealC);
			printf("\n\rJConfigInfo->jcxs.UrealC=%3.1f",JConfigInfo->jcxs.UrealC);
			printf("\n\rJConfigInfo->jcxs.IrealC=%2.2f",JConfigInfo->jcxs.IrealC);

		}else{
			sscanf(argv[2],"%f",&p);
			sscanf(argv[3],"%f",&q);
			sscanf(argv[4],"%f",&u);
			sscanf(argv[5],"%f",&ii);
			JConfigInfo->jcxs.PrealA=p;
			JConfigInfo->jcxs.QrealA=q;
			JConfigInfo->jcxs.UrealA=u;
			JConfigInfo->jcxs.IrealA=ii;
			JConfigInfo->jcxs.PrealB=p;
			JConfigInfo->jcxs.QrealB=q;
			JConfigInfo->jcxs.UrealB=u;
			JConfigInfo->jcxs.IrealB=ii;
			JConfigInfo->jcxs.PrealC=p;
			JConfigInfo->jcxs.QrealC=q;
			JConfigInfo->jcxs.UrealC=u;
			JConfigInfo->jcxs.IrealC=ii;
		}
		printf("\n\r[ val end  ]");
		return;
	}

	if (strcmp("sim",argv[1])==0)
	{
		if (argc == 3)
		{
			char simtmp[20];
			memset(simtmp,0,20);
			sscanf(argv[2], "%s",simtmp);
			if (((simtmp[0]>='0') &&(simtmp[0]<='9')) &&
					((simtmp[1]>='0') &&(simtmp[1]<='9')) &&
					((simtmp[2]>='0') &&(simtmp[2]<='9')) &&
					((simtmp[3]>='0') &&(simtmp[3]<='9')) &&
					((simtmp[4]>='0') &&(simtmp[4]<='9')) &&
					((simtmp[5]>='0') &&(simtmp[5]<='9')) &&
					((simtmp[6]>='0') &&(simtmp[6]<='9')) &&
					((simtmp[7]>='0') &&(simtmp[7]<='9')) &&
					((simtmp[8]>='0') &&(simtmp[8]<='9')) &&
					((simtmp[9]>='0') &&(simtmp[9]<='9')) &&
					((simtmp[10]>='0') &&(simtmp[10]<='9')))
			{
				memcpy(JConfigInfo->jzqpara.SIMCard,simtmp,20);
				JProgramInfo->FileSaveFlag.jzqflag = 1;

			}else
				fprintf(stderr,"\n�����ʽ����\n");
		}
		fprintf(stderr,"\n�ֻ���: %s\n",JConfigInfo->jzqpara.SIMCard);
		return;
	}
/*****************>>>>>>>>>>>>>>>>>********++++++++++*/
	if (strcmp("test", argv[1]) == 0) {
		JDataFileInfo->jc.JcXiu=6;
		return;
	}
	if (strcmp("mpp", argv[1]) == 0) {
		JDataFileInfo->jc.JcXiu=1;
		return;
	}
	if (strcmp("mpa", argv[1]) == 0) {
		JDataFileInfo->jc.JcXiu=2;
		return;
	}
	if (strcmp("mpb", argv[1]) == 0) {
		JDataFileInfo->jc.JcXiu=3;
		return;
	}
	if (strcmp("mpc", argv[1]) == 0) {
		JDataFileInfo->jc.JcXiu=4;
		return;
	}
//	if (strcmp("qing1", argv[1]) == 0) {
//		JDataFileInfo->jc.JcXiu=5;
//		return;
//	}
	if (strcmp("mmc", argv[1]) == 0) {
		JDataFileInfo->jc.JcXiu=7;
		return;
	}
	if (strcmp("jclook", argv[1]) == 0) {
		JDataFileInfo->jc.JcXiu=11;
		return;
	}
	//songjian
	if (strcmp("4ma", argv[1]) == 0) {
		JDataFileInfo->jc.JcXiu=20;
		return;
	}
	if (strcmp("20ma", argv[1]) == 0) {
		JDataFileInfo->jc.JcXiu=21;
		return;
	}

	printf("error command\n\r");
	if (argc > 2) {
		//Jmemory->jzq.passPara.ChangedJiZhongQiInfo = 1;
		//SaveFKSet();
	}
}
int main(int argc, char *argv[])
{
	char pwd[50],TempBuf[60];
	memset(pwd,0,50);
	memflg=1;
	dayin_count=0;

	JParamInfo3761 = Open1ShMem("ParamInfo3761",sizeof(ParamInfo3761),NULL);
	JDataFileInfo = Open1ShMem("DataFileInfo",sizeof(DataFileInfo),NULL);
	JConfigInfo = Open1ShMem("ConfigInfo",sizeof(ConfigInfo),NULL);
	JProgramInfo = Open1ShMem("ProgramInfo",sizeof(ProgramInfo),NULL);

	if(JProgramInfo->mainData.MemoryLength!=sizeof(ProgramInfo))
	{
		fprintf(stderr,"\nShare mem uncompared!\n");
		return EXIT_FAILURE;
	}

	sem_init(&JProgramInfo->mainData.UseFMFileFlg,1,1);//����д������Ϣ��������ͻ
	sem_init(&JProgramInfo->mainData.UseCycleFlg,1,1);//����д������Ϣ��������ͻ
	sem_init(&JProgramInfo->mainData.UseFileFlg,1,1);//�����ļ�������ͻ
	sem_init(&JProgramInfo->mainData.Gprs_Data_Flag,1,1);//��������ģ�黺������ͻ

	memset(TempBuf,0,60);
	sprintf((char*)TempBuf,"%s",_PARADIR_);
	if (access((char*)TempBuf, 0) != 0) {
		memset(TempBuf,0,60);
		sprintf((char*)TempBuf,"%s %s",_CMDMKDIR_,_PARADIR_);
		syscmd((char*)TempBuf,JProgramInfo);
		delay(100);
	}
//	if (access("/nand/gprsgw", 0) != 0) {
//		memset(TempBuf,0,60);
//		sprintf((char*)TempBuf,"%s /nand/gprsgw",_CMDMKDIR_);
//		syscmd((char*)TempBuf,JProgramInfo);
//		delay(100);
//	}

	if (argc == 1) {
		printf("\n\r jSet [Command] [options]");
		printf("\n\r Command:");
		printf("\n\r ip\t\texample jSet ip 192.168.1.1:7001");
		printf("\n\r id\t\texample jSet id 5201-3578");
		printf("\n\r apn\t\texample jSet apn cmnet");
		printf("\n\r heart\t\texample jSet hrt 15");
		printf("\n\r batt\t\texample jSet batt 1");
		printf("\n\r tst\t\texample print switch");
		printf("\n\r prtmet\t\texample print meter infomation");
		printf("\n\r metclr\t\texample clear meter parameter");
		printf("\n\r jc\t\texample print jiaocai infomation");
		printf("\n\r mettm\t\texample print chaobiao shijian jiange");
		printf("\n\r meter\t\texample jSet meter �������-״̬ ��ַ �˿� ��Լ ������ �ɼ�����ַ �澯��");
		//jSet meter �������-״̬ ��ַ �˿� ��Լ ������ �ɼ�����ַ �澯��

	} else {
		if (memflg==0)
		{
			InitjzqInfo(0,JParamInfo3761,JProgramInfo,JConfigInfo,JDataFileInfo);
			InitMeterInfo(JParamInfo3761);
			InitTaskInfo(JParamInfo3761, JProgramInfo);
			//setVersion(0); //11.7
		}
		CommandProcess(argc, argv);
	}
	return EXIT_SUCCESS;
}
