#ifndef DLT645_2007_C_
#define DLT645_2007_C_
#include <strings.h>
#include <../jBase/inc/DataGroups.h>//yizhi
#include <inc/jMemory.h>
#include "inc/pubfunction.h"
#include "jRead485.h"
#include "ReadMeter.h"



extern void SendStrTo485(unsigned char *str,unsigned short Len);
extern unsigned char ReceiveFrom485(unsigned char *str);
unsigned char ReceErrFlag;

unsigned char Dlt645Tran07(INT16U P,unsigned char *Addr,unsigned char DI0,unsigned char DI1,unsigned char DI2,unsigned char DI3,unsigned char *Dest)
{
	INT8U  Rec645Buff[1024],RecBuf[1024];
	INT8U  Trn645Buff[1024],TempBuf[1024];
	INT8U  GetLen;
	INT8U i,j,Check=0,len,flg,res;
	INT16U tmp;
	TS ts;
	len=0;
	Check=0;
	DI0=DI0+0x33;
	DI1=DI1+0x33;
	DI2=DI2+0x33;
	DI3=DI3+0x33;
	memset(Rec645Buff,0,1024);
	memset(RecBuf,0,1024);
	memset(Trn645Buff,0,1024);
	memset(TempBuf,0,1024);

	///CleardeadCount();
	//��֯���ͱ���
	Trn645Buff[len++]=0x68;
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x68;
	Trn645Buff[len++]=0x4a;
	for(i=0;i<4;i++)//�ɼ�����ַ
	{
		Trn645Buff[len++]=Addr[i];//�ɼ�����ַ
	}
	Trn645Buff[len++]=0x00;//��վ��ַ
	Trn645Buff[len++]=0x10;

	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x01;
	Trn645Buff[len++]=0x00;//F1 ���ݵ�Ԫ��ʶ

	Trn645Buff[len++]=JParamInfo3761->group2.f10[P].port;
	Trn645Buff[len]=0x00;
	switch(JParamInfo3761->group2.f10[P].jiao_yan_wei)
	{
		case 0:
			Trn645Buff[len]|=0x00;
			break;
		case 1:
			Trn645Buff[len]|=0x08;
			break;
		case 2:
			Trn645Buff[len]|=0x0C;
			break;
		default:
			Trn645Buff[len]|=0x08;
			break;
	}
	switch(JParamInfo3761->group2.f10[P].ting_zhi_wei)
	{
		case 2:
			Trn645Buff[len]|=0x10;
			break;
		default:
			Trn645Buff[len]|=0x00;
			break;
	}
	switch(JParamInfo3761->group2.f10[P].shu_ju_wei)
	{
		case 5:
			Trn645Buff[len]|=0x00;
			break;
		case 6:
			Trn645Buff[len]|=0x01;
			break;
		case 7:
			Trn645Buff[len]|=0x02;
			break;
		default:
			Trn645Buff[len]|=0x03;
			break;
	}
	switch(JParamInfo3761->group2.f10[P].baudrate)
	{
		case 1:
			Trn645Buff[len]|=0x00;
			break;
		case 2:
			Trn645Buff[len]|=0x20;
			break;
		case 4:
			Trn645Buff[len]|=0x40;
			break;
		case 8:
			Trn645Buff[len]|=0x60;
			break;
		case 16:
			Trn645Buff[len]|=0x80;
			break;
		case 24:
			Trn645Buff[len]|=0xA0;
			break;
		case 32:
			Trn645Buff[len]|=0xC0;
			break;
		case 64:
			Trn645Buff[len]|=0xE0;
			break;
		default:
			Trn645Buff[len]|=0x40;
			break;

	}
	len++;
	Trn645Buff[len++]=0x81;//1��
	Trn645Buff[len++]=5;//�ֽڳ�ʱʱ��
	tmp=len;//����
	Trn645Buff[len++]=0;
	Trn645Buff[len++]=0;
	Trn645Buff[len++]=0xFE;
	Trn645Buff[len++]=0xFE;
	Trn645Buff[len++]=0xFE;
	Trn645Buff[len++]=0xFE;
	Trn645Buff[len++]=0x68;
	for(i=0;i<6;i++)
	{
		Trn645Buff[len++]=JParamInfo3761->group2.f10[P].Address[i];
	}
	Trn645Buff[len++]=0x68;
	Trn645Buff[len++]=0x11;
	Trn645Buff[len++]=0x04;
	Trn645Buff[len++]=DI0;
	Trn645Buff[len++]=DI1;
	Trn645Buff[len++]=DI2;
	Trn645Buff[len++]=DI3;
	//SdPrint("biao=",tmp,len);
	for(i=tmp+6;i<len;i++)
	{
		Check+=Trn645Buff[i];
		//SdPrint("%02x ",Trn645Buff[i]);
	}
	//SdPrint("\n\r");
	Trn645Buff[len++]=(INT8U)(Check&0xff);
	Trn645Buff[len++]=0x16;


	Trn645Buff[tmp]=(len-tmp-2)&0xff;//ת�����ĵĳ���
	Trn645Buff[tmp+1]=((len-tmp-2)>>8)&0xff;
	for(i=0;i<16;i++)
		Trn645Buff[len++]=0x00;//pwd���� ����
	TSGet(&ts);
	Trn645Buff[len++]=JProgramInfo->PFC;//ʱ���
	INT32U_BCD(ts.Sec,&Trn645Buff[len++],1);
	INT32U_BCD(ts.Minute,&Trn645Buff[len++],1);
	INT32U_BCD(ts.Hour,&Trn645Buff[len++],1);
	INT32U_BCD(ts.Day,&Trn645Buff[len++],1);
	Trn645Buff[len++]=0;
	tmp = len - 6;//���㱨�ĳ���
	tmp = (tmp << 2) | 1;
	Trn645Buff[1] = tmp & 0xff;
	Trn645Buff[2] = (tmp >> 8) & 0xff;
	Trn645Buff[3] = tmp & 0xff;
	Trn645Buff[4] = (tmp >> 8) & 0xff;//���㱨�ĳ���
	Check=0;
	//SdPrint("pack=");
	for(i=6;i<len;i++)//У��λ
	{
		//SdPrint("%02x ",Trn645Buff[i]);
		Check+=Trn645Buff[i];
	}
	//SdPrint("\n\r");
	Trn645Buff[len++]=(INT8U)(Check&0xff);
	Trn645Buff[len++]=0x16;//����

	SdPrint("Send pack = ");
	for(i=0;i<len;i++)
		SdPrint("%02x ",Trn645Buff[i]);
	SdPrint("\n\r");
	SendStrTo485(Trn645Buff,len);
	i=0;
	delay(600);
//	while(i<10)
//	{
		len=ReceiveFrom485(Rec645Buff);
//		if (len>8)
//		{
//			SdPrint("delay i=%d\n\r",i);
//			break;
//		}
//		delay(200);
//		i++;
//	}

	SdPrint("rec pack%d = ",len);
	for(i=0;i<len;i++)
		SdPrint("%x ",Rec645Buff[i]);
	SdPrint("\n\r");

	tmp=0;
	flg=0;
	res=0;
	for(i=0;i<len;i++)
	{
		if((Rec645Buff[i]==0x68)&&(Rec645Buff[i+5]==0x68))
		{
			if (len>14)
			{
			   tmp=Rec645Buff[i+2];//���㱨�ĳ���
			   tmp=(tmp<<8)+Rec645Buff[i+1];
			   tmp=tmp>>2;
			   if(len>=(tmp + 8))
			   {
				   for(j=0;j<tmp+8;j++)
				   {
					   TempBuf[j]=Rec645Buff[i];
					   i = i+1;
				   }
				   Check=0;
				   for(j=0;j<tmp;j++)
					   Check+=TempBuf[j+6];
					 //  SdPrint("rec biao = ");
				   if(Check == TempBuf[tmp+6])
				   {
					   res=1;
					   tmp=TempBuf[18]+(TempBuf[19]<<8);
					   for(j=0;j<tmp;j++)//��ȡ����
					   {
						   RecBuf[flg++]=TempBuf[j+20];
						   //SdPrint("%02x ",TempBuf[j+20]);
					   }
				   }
				   //SdPrint("\n\r");
			   }
			}
		}
	}
	if (res==0)
	{
		return 0;
	}

	if (flg>0)
	{
		for(i=0;i<tmp;i++)
		{
			if(RecBuf[i]==0x68)
				break;
		}
		if(tmp<(i+9))return 0;
		if((RecBuf[i+8]&0x40) == 0x40)//�쳣֡
		{
			SdPrint("\n Dlt645Tran07 error frame = %x ............\n\r",RecBuf[i+8]);
			return 0;
		}
		/*if(RecBuf[i+8]!=0x91)
		{
			SdPrint("\n\r�����ݻ�Ӧ");
			return 0;
		}*/
		GetLen=RecBuf[i+9];
		if(GetLen>230) return 0;
		if(tmp<=(i+GetLen+10))return 0;
		Check=0x00;
		for(j=0;j<(GetLen+10);j++)
		{
			Check=Check+RecBuf[i+j];
			SdPrint("%x ",RecBuf[i+j]);	//����
		}
		if(Check!=RecBuf[i+GetLen+10])return 0;
		SdPrint("%x ",RecBuf[i+10]);	//����
		SdPrint("%x ",RecBuf[i+11]);	//����
		if((RecBuf[i+10]!=(DI0))||(RecBuf[i+11]!=(DI1))||(RecBuf[i+12]!=(DI2))||(RecBuf[i+13]!=(DI3)))
		{
			return 0;
		}
		SdPrint("\n Dlt645Tran07 Result  ....................\n\r");

		for(j=0;j<GetLen-4;j++)
		{
			RecBuf[i+14+j]=RecBuf[i+14+j]-0x33;
			Dest[j]=RecBuf[i+14+j];//��������ֵ��bcd�룩
			if (j>49)
				break;
			SdPrint("%x ",Dest[j]);	//����
		}
		SdPrint("\n\r");
	}
	else
	{
		return 0;
	}


	return 1;
}
//9.23
unsigned char Dlt645_2007GetVlue(unsigned char *Addr,unsigned char DI0,unsigned char DI1,unsigned char DI2,unsigned char DI3,unsigned char *Dest)
{

	unsigned char  Rec645Buff[1024];     /* 645��Լ���ձ��Ļ�����     */
	unsigned char  Trn645Buff[1024];     /* 645��Լ���ͱ��Ļ�����     */
	unsigned char  GetLen;
	//����
	unsigned char Check=0;
	int i,j=0,len=0;
	DI0=0x33+DI0;
	DI1=0x33+DI1;
	DI2=0x33+DI2;
	DI3=0x33+DI3;
	memset(Rec645Buff,0,1024);
	memset(Trn645Buff,0,1024);

	len=0;
	Check=0;

	///CleardeadCount();
	//��֯���ͱ���
	Trn645Buff[len++]=0xFE;
	Trn645Buff[len++]=0xFE;
	Trn645Buff[len++]=0xFE;
	Trn645Buff[len++]=0xFE;
	Trn645Buff[len++]=0x68;
	for(i=0;i<6;i++)
	{
		Trn645Buff[len++]=Addr[i];
	}
	Trn645Buff[len++]=0x68;
	Trn645Buff[len++]=0x11;
	Trn645Buff[len++]=0x04;
	Trn645Buff[len++]=DI0;
	Trn645Buff[len++]=DI1;
	Trn645Buff[len++]=DI2;
	Trn645Buff[len++]=DI3;
	for(i=4;i<18;i++)
		Check+=Trn645Buff[i];
	Trn645Buff[len++]=(unsigned char)(Check&0xff);
	Trn645Buff[len++]=0x16;
	//-----------����--------------------------
		SdPrint("\n Dlt645_2007GetVlue send DataNum = %d .............\n\r",len);
		for(i=0;i<len;i++)
			SdPrint("%02x ",Trn645Buff[i]);	//����
	//-------------------------------------
	delay(50);
	SendStrTo485(Trn645Buff,len);

	//���ͱ���
	//����
    //delay(300);
//	int find_ok = 0;
//	for(i=0;i<50;i++)
//	{
//		delay(30);
	if(ReceErrFlag) {
//		fprintf(stderr,"       Rec485 Error!!!,re_ask\n");
		delay(50);			//��½̨����ԣ��������������ʱ�ĳ�
	}
		len=ReceiveFrom485(Rec645Buff);
//		if(len>0)
//		{
//			for(j=0;j<len;j++)
//			{
//				if(Rec645Buff[j]==0x68 && Rec645Buff[j+7]==0x68)
//				{
//					find_ok=1;
//					break;
//				}
//
//			}
//		}
//		if(find_ok==1)
//			break;
//	}
	//---------------------------------
	//len=ReceiveFrom485(Rec645Buff);
	SdPrint("\n Dlt645_2007GetVlue DataNum = %d ............\n\r",len);
	for(i=0;i<len;i++) SdPrint("%x ",Rec645Buff[i]);	//����
	for(i=0;i<len;i++)
	{
		if(Rec645Buff[i]==0x68)
			break;
	}
	if(len<(i+9))return 0;
	if((Rec645Buff[i+8]&0x40) == 0x40)//�쳣֡
	{
		SdPrint("\n Dlt645_2007GetVlue error frame = %x ............\n\r",Rec645Buff[i+8]);
		return 0;
	}
	/*if(Rec645Buff[i+8]!=0x91)
	{
		SdPrint("\n\r�����ݻ�Ӧ");
		return 0;
	}*/
	GetLen=Rec645Buff[i+9];
	if(GetLen>230) 			return 0;
	if(len<=(i+GetLen+10))	return 0;
	Check=0x00;
	for(j=0;j<(GetLen+10);j++)
	{
		Check=Check+Rec645Buff[i+j];
		//SdPrint("%x ",Rec645Buff[i+j]);	//����
	}
	if(Check!=Rec645Buff[i+GetLen+10])return 0;
	if((Rec645Buff[i+10]!=(DI0))||(Rec645Buff[i+11]!=(DI1))||(Rec645Buff[i+12]!=(DI2))||(Rec645Buff[i+13]!=(DI3)))
	{
		return 0;
	}

//	fprintf(stderr,"GetLen=%d\n",GetLen);

	for(j=0;j<GetLen-4;j++)
	{
		JProgramInfo->dataTransgw.f9.len++;
		Rec645Buff[i+14+j]=Rec645Buff[i+14+j]-0x33;
		Dest[j]=Rec645Buff[i+14+j];//��������ֵ��bcd�룩
//		if(j%8==0) 	fprintf(stderr,"\n");
//		fprintf(stderr," %02x ",Dest[j]);
		if (j>49)
			break;
		//SdPrint("%x ",Dest[j]);	//����
	}
//	fprintf(stderr,"\n");
	return 1;
}
void SetCharVaule(unsigned char *Source,unsigned char *Target,unsigned char Begin,int Len,unsigned char From)
{
	while(Len>=1)
	{
		Target[From]=Source[Begin];
		From++;
		Len--;
		Begin++;
	}
}

//����2007�����Ľ��,ת��07���������ʽ��97��Ӧ��ʽ��				9.22
unsigned char Dlt6452007Get97Vlue(DataFlag97 *flg,unsigned char *Dest)//����
{
	unsigned char  Dest07[DataLenMax];
	SetCharVaule(Dest,&Dest07[0],0,60,0);
	memset((char *)Dest,0x00,60);//��ʼ��
	if(flg->Dataflag[0]==0x1F&&flg->Dataflag[1]==0xA0)			//�����й�������
	{
		SetCharVaule(&Dest07[0],Dest,0,3,0);
		SetCharVaule(&Dest07[0],Dest,8,3,3);
		SetCharVaule(&Dest07[0],Dest,16,3,6);
		SetCharVaule(&Dest07[0],Dest,24,3,9);
		SetCharVaule(&Dest07[0],Dest,32,3,12);
	}
	else if(flg->Dataflag[0]==0x10&&flg->Dataflag[1]==0xA0)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x11&&flg->Dataflag[1]==0xA0)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x12&&flg->Dataflag[1]==0xA0)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x13&&flg->Dataflag[1]==0xA0)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x14&&flg->Dataflag[1]==0xA0)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x1F&&flg->Dataflag[1]==0xA1)		//�����޹�������
	{
		SetCharVaule(&Dest07[0],Dest,0,3,0);
		SetCharVaule(&Dest07[0],Dest,8,3,3);
		SetCharVaule(&Dest07[0],Dest,16,3,6);
		SetCharVaule(&Dest07[0],Dest,24,3,9);
		SetCharVaule(&Dest07[0],Dest,32,3,12);
	}
	else if(flg->Dataflag[0]==0x10&&flg->Dataflag[1]==0xA1)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x11&&flg->Dataflag[1]==0xA1)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x12&&flg->Dataflag[1]==0xA1)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x13&&flg->Dataflag[1]==0xA1)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x14&&flg->Dataflag[1]==0xA1)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x2F&&flg->Dataflag[1]==0xA0)		//�����й�������
	{
		SetCharVaule(&Dest07[0],Dest,0,3,0);
		SetCharVaule(&Dest07[0],Dest,8,3,3);
		SetCharVaule(&Dest07[0],Dest,16,3,6);
		SetCharVaule(&Dest07[0],Dest,24,3,9);
		SetCharVaule(&Dest07[0],Dest,32,3,12);
	}
	else if(flg->Dataflag[0]==0x20&&flg->Dataflag[1]==0xA0)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x21&&flg->Dataflag[1]==0xA0)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x22&&flg->Dataflag[1]==0xA0)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x23&&flg->Dataflag[1]==0xA0)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x24&&flg->Dataflag[1]==0xA0)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x2F&&flg->Dataflag[1]==0xA1)		//�����޹�������
	{
		SetCharVaule(&Dest07[0],Dest,0,3,0);
		SetCharVaule(&Dest07[0],Dest,8,3,3);
		SetCharVaule(&Dest07[0],Dest,16,3,6);
		SetCharVaule(&Dest07[0],Dest,24,3,9);
		SetCharVaule(&Dest07[0],Dest,32,3,12);
	}
	else if(flg->Dataflag[0]==0x20&&flg->Dataflag[1]==0xA1)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x21&&flg->Dataflag[1]==0xA1)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x22&&flg->Dataflag[1]==0xA1)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x23&&flg->Dataflag[1]==0xA1)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x24&&flg->Dataflag[1]==0xA1)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x1F&&flg->Dataflag[1]==0xA4)
	{
		SetCharVaule(&Dest07[0],Dest,0,3,0);
		SetCharVaule(&Dest07[0],Dest,8,3,3);
		SetCharVaule(&Dest07[0],Dest,16,3,6);
		SetCharVaule(&Dest07[0],Dest,24,3,9);
		SetCharVaule(&Dest07[0],Dest,32,3,12);
	}
	else if(flg->Dataflag[0]==0x10&&flg->Dataflag[1]==0xA4)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x11&&flg->Dataflag[1]==0xA4)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x12&&flg->Dataflag[1]==0xA4)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x13&&flg->Dataflag[1]==0xA4)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x14&&flg->Dataflag[1]==0xA4)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x1F&&flg->Dataflag[1]==0xA5)
	{
		SetCharVaule(&Dest07[0],Dest,0,3,0);
		SetCharVaule(&Dest07[0],Dest,8,3,3);
		SetCharVaule(&Dest07[0],Dest,16,3,6);
		SetCharVaule(&Dest07[0],Dest,24,3,9);
		SetCharVaule(&Dest07[0],Dest,32,3,12);
	}
	else if(flg->Dataflag[0]==0x10&&flg->Dataflag[1]==0xA5)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x11&&flg->Dataflag[1]==0xA5)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x12&&flg->Dataflag[1]==0xA5)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x13&&flg->Dataflag[1]==0xA5)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x14&&flg->Dataflag[1]==0xA5)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x2F&&flg->Dataflag[1]==0xA4)
	{
		SetCharVaule(&Dest07[0],Dest,0,3,0);
		SetCharVaule(&Dest07[0],Dest,8,3,3);
		SetCharVaule(&Dest07[0],Dest,16,3,6);
		SetCharVaule(&Dest07[0],Dest,24,3,9);
		SetCharVaule(&Dest07[0],Dest,32,3,12);
	}
	else if(flg->Dataflag[0]==0x20&&flg->Dataflag[1]==0xA4)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x21&&flg->Dataflag[1]==0xA4)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x22&&flg->Dataflag[1]==0xA4)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x23&&flg->Dataflag[1]==0xA4)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x24&&flg->Dataflag[1]==0xA4)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x2F&&flg->Dataflag[1]==0xA5)
	{
		SetCharVaule(&Dest07[0],Dest,0,3,0);
		SetCharVaule(&Dest07[0],Dest,8,3,3);
		SetCharVaule(&Dest07[0],Dest,16,3,6);
		SetCharVaule(&Dest07[0],Dest,24,3,9);
		SetCharVaule(&Dest07[0],Dest,32,3,12);
	}
	else if(flg->Dataflag[0]==0x20&&flg->Dataflag[1]==0xA5)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x21&&flg->Dataflag[1]==0xA5)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x22&&flg->Dataflag[1]==0xA5)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x23&&flg->Dataflag[1]==0xA5)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x24&&flg->Dataflag[1]==0xA5)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x1F&&flg->Dataflag[1]==0xB0)			//�����й���������ʱ��
	{
		SetCharVaule(&Dest07[0],Dest,3,4,0);
		SetCharVaule(&Dest07[0],Dest,11,4,4);
		SetCharVaule(&Dest07[0],Dest,19,4,8);
		SetCharVaule(&Dest07[0],Dest,27,4,12);
		SetCharVaule(&Dest07[0],Dest,35,4,16);
	}else if(flg->Dataflag[0]==0x10&&flg->Dataflag[1]==0xB0)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x11&&flg->Dataflag[1]==0xB0)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x12&&flg->Dataflag[1]==0xB0)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x13&&flg->Dataflag[1]==0xB0)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x14&&flg->Dataflag[1]==0xB0)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x2F&&flg->Dataflag[1]==0xB0)			//�����й���������ʱ��
	{
		SetCharVaule(&Dest07[0],Dest,3,4,0);
		SetCharVaule(&Dest07[0],Dest,11,4,4);
		SetCharVaule(&Dest07[0],Dest,19,4,8);
		SetCharVaule(&Dest07[0],Dest,27,4,12);
		SetCharVaule(&Dest07[0],Dest,35,4,16);
	}else if(flg->Dataflag[0]==0x20&&flg->Dataflag[1]==0xB0)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x21&&flg->Dataflag[1]==0xB0)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x22&&flg->Dataflag[1]==0xB0)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x23&&flg->Dataflag[1]==0xB0)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x24&&flg->Dataflag[1]==0xB0)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x1F&&flg->Dataflag[1]==0xB1)			//�����޹���������ʱ��
	{
		SetCharVaule(&Dest07[0],Dest,3,4,0);
		SetCharVaule(&Dest07[0],Dest,11,4,4);
		SetCharVaule(&Dest07[0],Dest,19,4,8);
		SetCharVaule(&Dest07[0],Dest,27,4,12);
		SetCharVaule(&Dest07[0],Dest,35,4,16);
	}else if(flg->Dataflag[0]==0x10&&flg->Dataflag[1]==0xB1)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x11&&flg->Dataflag[1]==0xB1)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x12&&flg->Dataflag[1]==0xB1)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x13&&flg->Dataflag[1]==0xB1)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x14&&flg->Dataflag[1]==0xB1)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x2F&&flg->Dataflag[1]==0xB1)			//�����޹���������ʱ��
	{
		SetCharVaule(&Dest07[0],Dest,3,4,0);
		SetCharVaule(&Dest07[0],Dest,11,4,4);
		SetCharVaule(&Dest07[0],Dest,19,4,8);
		SetCharVaule(&Dest07[0],Dest,27,4,12);
		SetCharVaule(&Dest07[0],Dest,35,4,16);
	}else if(flg->Dataflag[0]==0x20&&flg->Dataflag[1]==0xB1)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x21&&flg->Dataflag[1]==0xB1)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x22&&flg->Dataflag[1]==0xB1)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x23&&flg->Dataflag[1]==0xB1)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x24&&flg->Dataflag[1]==0xB1)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x1F&&flg->Dataflag[1]==0xB4)
	{
		SetCharVaule(&Dest07[0],Dest,3,4,0);
		SetCharVaule(&Dest07[0],Dest,11,4,4);
		SetCharVaule(&Dest07[0],Dest,19,4,8);
		SetCharVaule(&Dest07[0],Dest,27,4,12);
		SetCharVaule(&Dest07[0],Dest,35,4,16);
	}else if(flg->Dataflag[0]==0x10&&flg->Dataflag[1]==0xB4)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x11&&flg->Dataflag[1]==0xB4)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x12&&flg->Dataflag[1]==0xB4)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x13&&flg->Dataflag[1]==0xB4)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x14&&flg->Dataflag[1]==0xB4)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x2F&&flg->Dataflag[1]==0xB4)
	{
		SetCharVaule(&Dest07[0],Dest,3,4,0);
		SetCharVaule(&Dest07[0],Dest,11,4,4);
		SetCharVaule(&Dest07[0],Dest,19,4,8);
		SetCharVaule(&Dest07[0],Dest,27,4,12);
		SetCharVaule(&Dest07[0],Dest,35,4,16);
	}else if(flg->Dataflag[0]==0x20&&flg->Dataflag[1]==0xB4)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x21&&flg->Dataflag[1]==0xB4)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x22&&flg->Dataflag[1]==0xB4)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x23&&flg->Dataflag[1]==0xB4)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x24&&flg->Dataflag[1]==0xB4)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x1F&&flg->Dataflag[1]==0xB5)
	{
		SetCharVaule(&Dest07[0],Dest,3,4,0);
		SetCharVaule(&Dest07[0],Dest,11,4,4);
		SetCharVaule(&Dest07[0],Dest,19,4,8);
		SetCharVaule(&Dest07[0],Dest,27,4,12);
		SetCharVaule(&Dest07[0],Dest,35,4,16);
	}else if(flg->Dataflag[0]==0x10&&flg->Dataflag[1]==0xB5)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x11&&flg->Dataflag[1]==0xB5)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x12&&flg->Dataflag[1]==0xB5)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x13&&flg->Dataflag[1]==0xB5)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x14&&flg->Dataflag[1]==0xB5)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x2F&&flg->Dataflag[1]==0xB5)
	{
		SetCharVaule(&Dest07[0],Dest,3,4,0);
		SetCharVaule(&Dest07[0],Dest,11,4,4);
		SetCharVaule(&Dest07[0],Dest,19,4,8);
		SetCharVaule(&Dest07[0],Dest,27,4,12);
		SetCharVaule(&Dest07[0],Dest,35,4,16);
	}else if(flg->Dataflag[0]==0x20&&flg->Dataflag[1]==0xB5)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x21&&flg->Dataflag[1]==0xB5)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x22&&flg->Dataflag[1]==0xB5)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x23&&flg->Dataflag[1]==0xB5)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x24&&flg->Dataflag[1]==0xB5)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else
	{
		SetCharVaule(&Dest07[0],Dest,0,60,0);
	}
	return 1;
}
void testDlt6452007Get97Vlue()
{
	DataFlag97 flg;
	unsigned char Dest[100];
	int i=0;
	for(i=0;i<80;i++)
	{
		Dest[i]=i;
	}
	flg.Dataflag[0]=0x1F;
	flg.Dataflag[1]=0xA0;
	Dlt6452007Get97Vlue(&flg,&Dest[0]);
}
unsigned char Dlt6452007GetValueBy97(unsigned char *Addr,DataFlag97 *flg,unsigned char *Dest)//����
{
	DataFlag2007 flg07;
	unsigned char i;
	if(GetDataFlag07By97(flg,&flg07)==1)
	{
		if ((flg07.Dataflag[0]==0xff)&&(flg07.Dataflag[1]==0xff)&&(flg07.Dataflag[2]==0xff)&&(flg07.Dataflag[3]==0xff))
			return 0;
		ReceErrFlag = 0;
		for(i=0;i<2;i++) {			//9��14��
		//	fprintf(stderr,"      Ask %02x-%02x-%02x-%02x\n",flg07.Dataflag[0],flg07.Dataflag[1],flg07.Dataflag[2],flg07.Dataflag[3]);
			if(	Dlt645_2007GetVlue(Addr,flg07.Dataflag[0],flg07.Dataflag[1],flg07.Dataflag[2],flg07.Dataflag[3],Dest)==1)
			{
				return Dlt6452007Get97Vlue(flg,Dest);
			}else {
				ReceErrFlag=1;
		//		fprintf(stderr,"RecErrFlag=%d\n",ReceErrFlag);
			}
		}
	}

	return 0;
}
unsigned char DltTran07GetValueBy97(INT16U P,unsigned char *Addr,DataFlag97 *flg,unsigned char *Dest)//����
{
	DataFlag2007 flg07;
	if(GetDataFlag07By97(flg,&flg07)==1)
	{
		if ((flg07.Dataflag[0]==0xff)&&(flg07.Dataflag[1]==0xff)&&(flg07.Dataflag[2]==0xff)&&(flg07.Dataflag[3]==0xff))
			return 0;
		if(	Dlt645Tran07(P,Addr,flg07.Dataflag[0],flg07.Dataflag[1],flg07.Dataflag[2],flg07.Dataflag[3],Dest)==1)
		{
			return Dlt6452007Get97Vlue(flg,Dest);
		}
	}
	return 0;
}
#endif /*DLT645_2007_C_*/
