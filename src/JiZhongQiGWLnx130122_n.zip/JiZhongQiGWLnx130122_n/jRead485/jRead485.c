//Copyright ��Ȩ����  2009�ൺ�߿�ͨ�Źɷ����޹�˾
// �ļ�����jRead485.c
// �ļ������������Զ���������
// ������ʶ��20090901 Ray
//
// �޸ı�ʶ��
// �޸�������
//
// �޸ı�ʶ��
// �޸�������
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#include "jRead485.h"
#include "ReadMeter.h"
unsigned char   GetProjects(int argc, char * argv[]);//����ע��,��ȡ����źͳ�������
void QuitProcess(int signo);//�˳�����
extern void CloseCom485();
extern TS currts_buchao;
int GetMeterCountinPort(INT8U portno)
{
	int i,count=0;
	for(i=0;i<PointMax;i++)
	{
		ClearWaitTimes(ProjectNo,JProgramInfo);
		if(JParamInfo3761->group2.f10[i].Status!=1){continue;}
		if ((JParamInfo3761->group2.f10[i].ConnectType!=1) &&
			(JParamInfo3761->group2.f10[i].ConnectType!=30)&&
			(JParamInfo3761->group2.f10[i].ConnectType!=21))
			continue;
		if (JParamInfo3761->group2.f10[i].port==portno)
			count++;
	}
	return count;
}
//������
int main(int argc, char *argv[])
{
	int i,num;
	INT8U addr[6];

	if (getenv("jRead485Prt")==NULL)
	{
		jRead485Print = 0;
		if (getenv("jAllProgPrt")!=NULL)
			jRead485Print = atoi(getenv("jAllProgPrt"));
	}
	else jRead485Print = atoi(getenv("jRead485Prt"));

   if (jRead485Print==2)
   {
		INT8U TempBuf[60];
		memset(TempBuf, 0, 60);
		sprintf((char *) TempBuf, "%s/jread485_log.txt", _USERDIR_);
	    fp=fopen((char *) TempBuf,"a+");
   }
	markver();
	struct sigaction sa1;//�ź�

	//if(OpenMem())return EXIT_FAILURE;//�򿪹����ڴ�
    JParamInfo3761 = NULL;
    JDataFileInfo = NULL;
    JConfigInfo = NULL;
    JProgramInfo = NULL;

    JParamInfo3761 = Create1ShMem("ParamInfo3761",sizeof(ParamInfo3761),NULL);
    JDataFileInfo = Create1ShMem("DataFileInfo",sizeof(DataFileInfo),NULL);
    JConfigInfo = Create1ShMem("ConfigInfo",sizeof(ConfigInfo),NULL);
    JProgramInfo = Create1ShMem("ProgramInfo",sizeof(ProgramInfo),NULL);

    if (JParamInfo3761 ==NULL || JDataFileInfo == NULL ||JConfigInfo == NULL ||JProgramInfo == NULL)
    {
 		printf("\n\r  jmain chuan jian gong xiang mei buchenggong");
   		return EXIT_FAILURE;//���������ڴ�
    }
	if(JProgramInfo->mainData.MemoryLength!=sizeof(ProgramInfo))
	{
		SdPrint( "jRead485 base mem uncompared prog will exit %d  %d :\n",sizeof(JProgramInfo),JProgramInfo->mainData.MemoryLength);
		return EXIT_FAILURE;
	}
	if(!GetProjects(argc, argv))
	{
		SdPrint("\njRead485 Bad command format. Type 'use exe_name' for help!\n\r");
		return EXIT_FAILURE;
	}
	JProgramInfo->Projects[ProjectNo].ProjectID=getpid();//����������Ϣ
	printf("Starting jRead485 ..........%d\n\r",ProjectNo);
	DbgPrintToFile("Starting jRead485I ..........%d",ProjectNo);
	ClearWaitTimes(ProjectNo,JProgramInfo);
	//��ʼ������
	sa1.sa_handler = QuitProcess;
	sigemptyset(&sa1.sa_mask);
	sa1.sa_flags = 0;
	sigaction(SIGTERM, &sa1,NULL);
	sigaction(SIGSYS, &sa1,NULL);
	sigaction(SIGPWR, &sa1,NULL);
	sigaction(SIGKILL, &sa1,NULL);
	sigaction(SIGQUIT, &sa1,NULL);
	sigaction(SIGILL, &sa1,NULL);
	sigaction(SIGINT, &sa1,NULL);
	sigaction(SIGHUP, &sa1,NULL);
	sigaction(SIGABRT, &sa1,NULL);
	sigaction(SIGBUS, &sa1,NULL);
	InitMeterFlags();
	delay(1000);
	num=0;
	memset(addr,0,6);
	while(num<22)
	{
		ClearWaitTimes(ProjectNo,JProgramInfo);
		num++;
		delay(1000);
	}

	TSGet(&OldTs);  //yangdongifr
	OldTs.Hour = OldTs.Hour -1;

	//������Ϣ

	memset(&JDataFileInfo->data485[0+PortBegNum], 0, sizeof(Data485));
	JDataFileInfo->data485[0+PortBegNum].MeterNum = GetMeterCountinPort(2);

	memset(&JDataFileInfo->data485[1+PortBegNum], 0, sizeof(Data485));
	JDataFileInfo->data485[1+PortBegNum].MeterNum = GetMeterCountinPort(3);
	Rs485ErroFlag = 0;
	TSGet(&currts_buchao);
	while(1)
	{
	   if (jRead485Print == 0)
	   {
		   if ((JProgramInfo->mainData.Prt_Flag==8) || (JProgramInfo->mainData.Prt_Flag==50))
			   jRead485Print = 3;
	   } else
	   {
		   if ((JProgramInfo->mainData.Prt_Flag==108) || (JProgramInfo->mainData.Prt_Flag==150))
			   jRead485Print = 0;
	   }
	   JDataFileInfo->data485[0+PortBegNum].MeterNum = GetMeterCountinPort(2);
	   JDataFileInfo->data485[1+PortBegNum].MeterNum = GetMeterCountinPort(3);
		SdPrint("jRead485 start circle ........�˿�2 ������ %d  �˿�3 ������ %d\n",
				JDataFileInfo->data485[0+PortBegNum].MeterNum,JDataFileInfo->data485[1+PortBegNum].MeterNum);
		ReadDataHour();
		for(i=0;i<100;i++)
		{
			GetRealTimeData();//��ȡʵʱ����
			ClearWaitTimes(ProjectNo,JProgramInfo);
			delay(100);
		}
	}
	QuitProcess(0);
 	return EXIT_SUCCESS;
}
name_attach_t  *attach;
//����ע��,��ȡ����źͳ�������
INT8U GetProjects(INT32S argc, char * argv[]) {
	char proc_name[32] = "";

	if (argc < 2)
		return (FALSE);
	ProjectNo = atoi(argv[1]);
#ifdef __linux__
	sprintf(proc_name, "%s", argv[0]);
#else
	sprintf(proc_name, "%s %d", argv[0], ProjectNo);
#endif
//   if((attach=name_attach(NULL, proc_name,0))  == NULL)
//   {
//	   printf( "ERR:'%s' runed,cann't regist\n\r", proc_name);
//	   return (FALSE);
//   }
	return (TRUE);
}

//�˳�����
void QuitProcess(int signo)
{
	delay(100);
	CloseCom485();
	SdPrint("\n\r jRead485 quit xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n\r");
	JProgramInfo->Projects[ProjectNo].ProjectID=0;
//	name_detach(attach, 0);
    if (jRead485Print==2)
    {
       //SdPrint("\n\r fp close");
 	   fclose(fp);
 	   fp=NULL;
    }
	exit(0);
}



