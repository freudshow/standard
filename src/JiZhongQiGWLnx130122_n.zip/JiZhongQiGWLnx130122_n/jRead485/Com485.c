//Copyright ��Ȩ����  2009�ൺ�߿�ͨ�Źɷ����޹�˾
// �ļ�����Com485.c
// �ļ������������Զ���������
// ������ʶ��20090901 Ray
//
// �޸ı�ʶ��
// �޸�������
//
// �޸ı�ʶ��
// �޸�������
#ifndef Com485C
#define Com485C
#include <stdio.h>
#include <string.h>
#include <termios.h>
#include <fcntl.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <ctype.h>
#include <time.h>
#include <signal.h>
#include <semaphore.h>
#include <errno.h>
#include <fcntl.h>
#include <termios.h>
//#include <inc/CVariable.h>
#include "jRead485.h"
#include "inc/pubfunction.h"

void CloseCom485();//�رմ���
void SendTestString(INT8U comp,INT8U addr[6]);
int Open485Meter(unsigned char cNO,unsigned char mNo);

//int Init_port_parm(INT8U port, int baud, char *par, unsigned char stopb, INT8U bits)
int OpenCom485(int baud,unsigned char *par,unsigned char stopb,unsigned char bits,unsigned char port)
{
	struct termios old_termi,new_termi;
	int baud_lnx=0;
	unsigned char tmp[128];
	memset(tmp,0,128);
	switch(port)  //yangdong  �����������˴���ӳ�� ʵ�ʴ��� 4851--ttyS2  4852--ttyS3 4853--ttyS6
	{				//���⴮��  4851--2  4852--3 4853--4
	case 1:
		port=port+1;
		break;
	case 2:
		port=port+1;
		break;
	case 3:
		port=port+3;
		break;
	default:
		break;
	}
	if(ComPort>0)
		close(ComPort);
    sprintf((char *)tmp,"/dev/ttyS%d",port);
    ComPort = open((char *)tmp, O_RDWR);/* �򿪴����ļ� */
    fprintf(stderr, "\n485I  tmp ==%s OpenCom485 fd =%d\n",tmp, ComPort);
    if( ComPort<0 )
    {
    	fprintf(stderr,"open the serial port fail! errno is: %d\n", errno);
    	return 0; /*�򿪴���ʧ��*/
    }
    if ( tcgetattr( ComPort, &old_termi) != 0) /*�洢ԭ��������*/
    {
    	printf("get the terminal parameter error when set baudrate! errno is: %d\n", errno);
    	/*��ȡ�ն���ز���ʱ����*/
    	return 0;
    }
   // printf("\n\r c_ispeed == %d old_termi  c_ospeed == %d",old_termi.c_ispeed, old_termi.c_ospeed);
    bzero(&new_termi,sizeof(new_termi));    				/*���ṹ������*/
    new_termi.c_cflag|= (CLOCAL|CREAD); 					/*���Ե��ƽ����״̬�У�����ʹ��*/
    new_termi.c_lflag&=~(ICANON|ECHO|ECHOE);				/*ѡ��Ϊԭʼ����ģʽ*/
    new_termi.c_oflag&=~OPOST; 								/*ѡ��Ϊԭʼ���ģʽ*/
    new_termi.c_cc[VTIME] = 2; 								/*���ó�ʱʱ��Ϊ0.5 s*/
    new_termi.c_cc[VMIN] = 0;								/*���ٷ��ص��ֽ����� 7*/
    new_termi.c_cflag &= ~CSIZE;
    //new_termi.c_iflag &= ~INPCK;     /* Enable parity checking */
    new_termi.c_iflag &=~ ISTRIP;
    switch(baud)
    {
    	case 1200:
    		baud_lnx = B1200;
    		break;
    	case 2400:
    		baud_lnx = B2400;
    		break;
    	case 4800:
    		baud_lnx = B4800;
    		break;
    	case 9600:
    		baud_lnx = B9600;
    		break;
    	case 19200:
    		baud_lnx = B19200;
    		break;
    	case 38400:
    		baud_lnx = B38400;
    		break;
    	case 115200:
    		baud_lnx = B115200;
    		break;
    	default:
    		baud_lnx = B9600;
    		printf("\nSerial COM%d do not setup baud, default baud is 9600!!!", port);
    		break;
    }

    switch( bits )
		{
			case 5:
				new_termi.c_cflag |= CS5;
				break;
			case 6:
				new_termi.c_cflag |= CS6;
				break;
			case 7:
				new_termi.c_cflag |= CS7;
				break;
			case 8:
				new_termi.c_cflag |= CS8;
				break;
			default:
				new_termi.c_cflag |= CS8;
				break;
		}

    if(strncmp((char *)par,"even",4)==0)//������żУ��ΪżУ��
    {
		//new_termi.c_iflag |= (INPCK | ISTRIP);
    	new_termi.c_cflag |= PARENB;
    	new_termi.c_cflag &= ~PARODD;

    }
    else if(strncmp((char *)par,"odd",3)==0)  //������żУ��Ϊ��У��
	{
		new_termi.c_cflag |= PARENB;
		new_termi.c_cflag |= PARODD;
		//new_termi.c_iflag |= (INPCK | ISTRIP);
	}
    else
    {
    	new_termi.c_cflag &= ~PARENB; 	//������żУ��Ϊ��У��
    	//new_termi.c_iflag &=~ ISTRIP;
    }


	if(stopb==1)//ֹͣλ
	{
		new_termi.c_cflag&= ~CSTOPB; //����ֹͣλΪ:һλֹͣλ
	}
	else if(stopb==2)
	{
		new_termi.c_cflag |= CSTOPB; //����ֹͣλΪ:��λֹͣλ
	}
	else
	{
		new_termi.c_cflag&= ~CSTOPB; //����ֹͣλΪ:һλֹͣλ
	}

	cfsetispeed(&new_termi, baud_lnx); 							/* �������벦���� */
    cfsetospeed(&new_termi, baud_lnx); 							/* ������������� */

    tcflush(ComPort, TCIOFLUSH); 								/* ˢ����������� */
    if(tcsetattr(ComPort,TCSANOW,&new_termi)!= 0)				/* ��������� */
    {
    	printf("Set serial port parameter error!\n");
    	return 0;
    }
    CurCom485.State = 1;
    return ComPort;
}

//������ �ɹ�����1 ʧ��С��0
int Open485Meter(unsigned char cNO,unsigned char mNo)
{
	ClearWaitTimes(ProjectNo,JProgramInfo);
	int result;
	if ((JParamInfo3761->group2.f10[getPoint(cNO,mNo)].ConnectType!=1) &&
		(JParamInfo3761->group2.f10[getPoint(cNO,mNo)].ConnectType!=30)&&
		(JParamInfo3761->group2.f10[getPoint(cNO,mNo)].ConnectType!=21))
		return 0;
//ʹ��Ĭ�ϴ������ã�1200����У�飬8λ��ֹͣλΪ��1
	if(CurCom485.CNo==cNO && CurCom485.MeterNo==mNo && CurCom485.State==1)
		return 1;
	CurCom485.CNo=cNO;
	CurCom485.MeterNo=mNo;
	Com485 NowCom485;
	NowCom485.CNo=cNO;
	NowCom485.MeterNo=mNo;
	NowCom485.ComPortNo=JParamInfo3761->group2.f10[getPoint(cNO,mNo)].port-PortBegNum;
	NowCom485.Baud=JParamInfo3761->group2.f10[getPoint(cNO,mNo)].baudrate*300;
	if(JParamInfo3761->group2.f10[getPoint(cNO,mNo)].jiao_yan_wei==0x01)
	sprintf((char*)NowCom485.Parity,"even");
	else if(JParamInfo3761->group2.f10[getPoint(cNO,mNo)].jiao_yan_wei==0x02)
	sprintf((char*)NowCom485.Parity,"odd");
	else sprintf((char*)NowCom485.Parity,"none");
	NowCom485.Stopb=1;
	if(JParamInfo3761->group2.f10[getPoint(cNO,mNo)].ting_zhi_wei==0x00)
		NowCom485.Stopb =1;
	else if(JParamInfo3761->group2.f10[getPoint(cNO,mNo)].ting_zhi_wei==0x02)
		NowCom485.Stopb =2;
	//else NowCom485.Stopb =1.5;
	NowCom485.Bits=JParamInfo3761->group2.f10[getPoint(cNO,mNo)].shu_ju_wei;
	NowCom485.State=1;
//	if(memcmp(&CurCom485,&NowCom485,sizeof(Com485))==0) return 1;
//	else memcpy(&CurCom485,&NowCom485,sizeof(Com485));
	if(CurCom485.State==1)
	{
		if (CurCom485.Baud == NowCom485.Baud &&	CurCom485.ComPortNo == NowCom485.ComPortNo)
		{
			printf("\n�˿�%d�Ѿ���\n",CurCom485.ComPortNo);
			return 1;
		}
	}
	memcpy(&CurCom485,&NowCom485,sizeof(Com485));
	printf("\n�򿪶˿�%d\n",CurCom485.ComPortNo);
	CurCom485.State=0;
	CloseCom485();
	delay(100);
	fprintf(stderr,"\n\r 485-1 Open485Meter  CurCom485.ComPortNo ====%d ", CurCom485.ComPortNo);
	result=OpenCom485(CurCom485.Baud,CurCom485.Parity,CurCom485.Stopb,CurCom485.Bits,CurCom485.ComPortNo);//��ʼ���˿�
	if(result<1)
		return result;
	return 1;
}
//�رմ���
void CloseCom485()
{
	CurCom485.State=0;
	if(ComPort>0)
		close( ComPort );
}


//���Ӵ򿪺����ַ���
void SendStrTo485(unsigned char *str,unsigned short Len)
{
	if(CurCom485.ComPortNo==1)
		JProgramInfo->Para.State485_1 = 2; //��ʾ����
	if(CurCom485.ComPortNo==2)
		JProgramInfo->Para.State485_2 = 2;  //��ʾ����
	if(CurCom485.ComPortNo==3)
		JProgramInfo->Para.State485_3 = 2;  //��ʾ����
	ClearWaitTimes(ProjectNo,JProgramInfo);
	write(ComPort,str,Len);
}
//�����ַ���    //9.24
unsigned char ReceiveFrom485(unsigned char *str)
{
	INT8U TmpBuf[256];
	int len,rec_step;
	int rec_head,rec_tail;
	int DataLen,i;
	int j;

	memset(TmpBuf,0,256);
	rec_head=rec_tail= rec_step = DataLen =0;

	delay(500);
	for(j=0;j<15;j++)									//9��14��
	{
		len = read(ComPort,TmpBuf,255);//200
	//	printf("\n trans recv len=%d:", len);
		if(len>0)
		{
		//	printf("\n trans recv len=%d:", len);
		}

		if(j==0 && len==0)
		{
			return 0;
		}
	//	fprintf(stderr,"len=%d\n",len);

//		ClearWaitTimes(ProjectNo,JProgramInfo);
		if(len>0)
	//	fprintf(stderr,"\nstep=%d  len=%d  rec_head=%d   tail=%d\n",rec_step,len,rec_head,rec_tail);
		for(i=0;i<len;i++)
		{
			str[rec_head++]=TmpBuf[i];
			//fprintf(stderr,"%02x.", TmpBuf[i]);
		}
		if (len>0)
		{
			if(CurCom485.ComPortNo==1)
				JProgramInfo->Para.State485_1 = 2; //��ʾ����
			if(CurCom485.ComPortNo==2)
				JProgramInfo->Para.State485_2 = 2;  //��ʾ����
			if(CurCom485.ComPortNo==3)
				JProgramInfo->Para.State485_3 = 2;  //��ʾ����
		}
//		fprintf(stderr,"------ReceiveFrom485------\n");
//		for(i=0;i<rec_head;i++)
//			fprintf(stderr,"%02x ",str[i]);
//		fprintf(stderr,"------ReceiveFrom485------end\n");

		//while(rec_step)
		{
			switch (rec_step) {
			case 0:
				if (rec_tail < rec_head)
				{
					for(i=rec_tail; i<rec_head; i++)
					{
						if(str[i] == 0x68)
						{
							rec_step = 1;
							rec_tail = i;
							break;
						}else
							rec_tail++;
					}
	//				if(str[rec_tail] == 0x68)
	//				{
	//					rec_step = 1;
	//					break;
	//				}else
	//					rec_tail++;
				}
				break;
			case 1:
				if((rec_head - rec_tail)>=9)
				{
					if(str[rec_tail]==0x68 && str[rec_tail+7]==0x68 )
					{
						DataLen=str[rec_tail+9];//��ȡ�������ݿ鳤��
						rec_step = 2;
						break;
					}else
						rec_tail++;
				}
				break;
			case 2:
				if((rec_head - rec_tail)>=(DataLen+2))
				{
					if (str[rec_tail+9 +DataLen+2] == 0x16)
						return rec_head;
				}
				break;
			default:
				break;
			}
		}
	}
	return (0);
}

void DataTrans()
{
	int res,baud,stop,bits,dely,len,i;
	unsigned char Parity[12];

	if((JProgramInfo->dataTransgw.f1.ASK_Stat==1) &&
		(JProgramInfo->dataTransgw.f1.ASK_Port==2||JProgramInfo->dataTransgw.f1.ASK_Port==3))
	{
//		if (JProgramInfo->dataTransgw.f1.ASK_Stat!=(1+PortBegNum))
//			return;
		switch((JProgramInfo->dataTransgw.f1.ASK_Control&0xE0)>>5)
		{
			case 0:
				baud=300;
				break;
			case 1:
				baud=600;
				break;
			case 2:
				baud=1200;
				break;
			case 3:
				baud=2400;
				break;
			case 4:
				baud=4800;
				break;
			case 5:
				baud=7200;
				break;
			case 6:
				baud=9600;
				break;
			case 7:
				baud=19200;
				break;
			default:
				baud=1200;
				break;
		}
		stop=1;
		if(JProgramInfo->dataTransgw.f1.ASK_Control&0x10)
			stop=2;
		sprintf((char*)Parity,"even");
//		if(JProgramInfo->dataTransgw.f1.ASK_Control&0x08)
//		{
//			memset(Parity,0,12);
//			if(JProgramInfo->dataTransgw.f1.ASK_Control&0x04)
//				sprintf((char*)Parity,"odd");
//			else
//				sprintf((char*)Parity,"even");
//		}
		bits=(JProgramInfo->dataTransgw.f1.ASK_Control&0x03)+5;

		CloseCom485();
		CurCom485.Baud=baud;
		memcpy(CurCom485.Parity,Parity,12);
		CurCom485.Stopb=stop;
		CurCom485.Bits=bits;
		CurCom485.ComPortNo=JProgramInfo->dataTransgw.f1.ASK_Port-1;
		CurCom485.State=0;
		CurCom485.CNo=0;
		CurCom485.MeterNo=0;
		SdPrint("\n\rOpenCom485=%d,%d,%s,%d,%d ASK_Control=%02x\n\r",
			JProgramInfo->dataTransgw.f1.ASK_Stat,baud,Parity,stop,bits,JProgramInfo->dataTransgw.f1.ASK_Control);
		res=OpenCom485(baud,Parity,stop,bits,JProgramInfo->dataTransgw.f1.ASK_Port-1);//��ʼ���˿�
		if(res<1)
		{
			JProgramInfo->dataTransgw.f1.len[0]=0;
			JProgramInfo->dataTransgw.f1.len[1]=0;
		}
		else
		{
			CurCom485.State=1;
			if (JProgramInfo->dataTransgw.f1.WaitTime&0x80)
				dely=(JProgramInfo->dataTransgw.f1.WaitTime&0x7F)*1000;
			else
				dely=(JProgramInfo->dataTransgw.f1.WaitTime&0x7F)*10;
			len=JProgramInfo->dataTransgw.f1.len[0]+(JProgramInfo->dataTransgw.f1.len[1]<<8);//--ת��
			for (i=0;i<len;i++)
				SdPrint("%02x ",JProgramInfo->dataTransgw.f1.ANSWER_Buf[i]);
			SdPrint("\n\r");
			SendStrTo485(JProgramInfo->dataTransgw.f1.ANSWER_Buf,len);
			//���ͱ���
			//����
			ClearWaitTimes(ProjectNo,JProgramInfo);
//			delay(dely);
//			memset(JProgramInfo->dataTransgw.f1.ANSWER_Buf,0,256);
//			len=ReceiveFrom485(JProgramInfo->dataTransgw.f1.ANSWER_Buf);
			//--ת��--
			printf("\n--------------------------------------------------------1\n");
  			memset(JProgramInfo->dataTransgw.f1.ANSWER_Buf,0,256);
			for (i=0;i<30;i++)
			{
				ClearWaitTimes(ProjectNo,JProgramInfo);
				if(JProgramInfo->dataTransgw.f1.ASK_Stat==0)//weifang JProgramInfo->dataTransgw.f1.ASK_Stat=0;
				{
					printf("\n JProgramInfo->dataTransgw.f1.ASK_Stat == 0  timeout first \n");
					break;
				}
				delay(1000);
				len=ReceiveFrom485(JProgramInfo->dataTransgw.f1.ANSWER_Buf);

				if (len>=12 || len<0)
					break;
				ClearWaitTimes(ProjectNo,JProgramInfo);
			}
			//--ת��--end
			SdPrint("recv len=%d\n\r",len);
			for (i=0;i<len;i++)
				SdPrint("%02x ",JProgramInfo->dataTransgw.f1.ANSWER_Buf[i]);
			SdPrint("----\n\r");
			JProgramInfo->dataTransgw.f1.len[0]=len&0xff;
			JProgramInfo->dataTransgw.f1.len[1]=(len>>8)&0xff;
		}
		JProgramInfo->dataTransgw.f1.ASK_Stat=2;

	}
}
#endif /*Com485C*/

