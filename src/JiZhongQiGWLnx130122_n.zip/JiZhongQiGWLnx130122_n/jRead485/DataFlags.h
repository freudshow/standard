#ifndef DataFlagsH
#define DataFlagsH
#include <inc/pubfunction.h>
#include <inc/init.h>
#include "jRead485.h"
extern void SetDataFlag2007(unsigned char DI3,unsigned char DI2,unsigned char DI1,unsigned char DI0,unsigned char *flags);
extern void SetDataFlag97(unsigned char DI1,unsigned char DI0,unsigned char *flags);
extern int GetDataFlag97By07(DataFlag2007 *flags20007,DataFlag97 *flags97);
extern int GetDataFlag07By97(DataFlag97 *flags97,DataFlag2007 *flags20007);
extern unsigned char InitParaDataFlagss(DataFlags *flg);
extern unsigned char InitManyDayFlags(DataFlag97 *flg97);
extern void InitMeterFlags();
extern void SetCharVaule(unsigned char *Source, unsigned char *Target,	unsigned char Begin, int Len, unsigned char From);//shanghai

#endif

