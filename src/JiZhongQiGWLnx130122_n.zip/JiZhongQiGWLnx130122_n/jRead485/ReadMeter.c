#include <inc/pubfunction.h>
#include <stdlib.h>
#include "DataFlags.h"
#include "jRead485.h"
#include "ReadMeter.h"
#include "unistd.h"

//CurMeters curMeters2;
DataFiles df;
//DataFiles df2;
SMFiles smfile;
INT8U reflg;
extern void CloseCom485();
extern int Open485Meter(unsigned char cNO,unsigned char mNo);
extern unsigned char Dlt645GetVlueBy07(unsigned char *Addr,unsigned char DI0,unsigned char DI1,unsigned char *Dest);
extern unsigned char Dlt645GetVlue(unsigned char *Addr,unsigned char DI0,unsigned char DI1,unsigned char *Dest);
//yangdongifr
extern unsigned char Dlt645_2007GetVlue(unsigned char *Addr,unsigned char DI0,unsigned char DI1,unsigned char DI2,unsigned char DI3,unsigned char *Dest);
extern unsigned char Dlt6452007GetValueBy97(unsigned char *Addr,DataFlag97 *flg,unsigned char *Dest);//����
extern void DataTrans();
extern int OpenCom485(unsigned short baud,unsigned char *par,unsigned char stopb,unsigned char bits,unsigned char ComPortNo);
extern unsigned char DltTran07GetValueBy97(INT16U P,unsigned char *Addr,DataFlag97 *flg,unsigned char *Dest);
extern unsigned char DltTranSHGetValueBy97(INT16U P,unsigned char *Addr,DataFlag97 *flg,unsigned char *Dest);
extern unsigned char DltTranGetVlueBy07(INT16U P,unsigned char *Addr,unsigned char DI0,unsigned char DI1,unsigned char *Dest);
int gflgCount; //shanghai
fileinfo smfileinfo;

TS oldts_buchao,currts_buchao;//�����Ϻ�1�㵽4�㲹��
//INT8U mySaveFile(char *FileName, void *source, int size,ProgramInfo* JProgramInfo, fileinfo *fileinfo)
//{
//	DataFiles datafile;
//	struct timespec tsspec;
//	if (clock_gettime(CLOCK_REALTIME, &tsspec)==-1)
//		printf("clock_gettime error\n\r");
//	tsspec.tv_sec += 2;
//	datafile.dataChanged = 1;
//	memcpy(&datafile.filename, FileName, 128);
//	datafile.filelen = size;
//	datafile.fileinfo.cldno = fileinfo->cldno;
//	datafile.fileinfo.ts = fileinfo->ts;
//	datafile.fileinfo.filetype = fileinfo->filetype;
//	memcpy(&datafile.manyFiles, (INT8U *)source, size);
//	if(JProgramInfo->sm.dataChanged==0)
//	{
//		sem_timedwait(&JProgramInfo->mainData.UseCycleFlg, &tsspec);
//		memcpy(&JProgramInfo->sm,&datafile,sizeof(DataFiles));
//		sem_post(&JProgramInfo->mainData.UseCycleFlg);
//		return 1;
//	}
//	return 0;
//}

INT8U mySaveFile(char *FileName, void *source, int size,ProgramInfo* JProgramInfo, fileinfo *fileinfo)
{
	DataFiles datafile;
	struct timespec tsspec;
	if (clock_gettime(CLOCK_REALTIME, &tsspec)==-1)
		printf("clock_gettime error\n\r");
	tsspec.tv_sec += 2;
	datafile.dataChanged = 1;
	memcpy(&datafile.filename, FileName, 128);
	datafile.filelen = size;
	datafile.fileinfo.cldno = fileinfo->cldno;
	datafile.fileinfo.ts = fileinfo->ts;
	datafile.fileinfo.filetype = fileinfo->filetype;
	memcpy(&datafile.manyFiles, (INT8U *)source, size);
	sem_timedwait(&JProgramInfo->mainData.UseCycleFlg, &tsspec);
	if((JProgramInfo->sm_tail-JProgramInfo->sm_head-1+SMBUFLEN)%SMBUFLEN>0)//�п�
	{
		fprintf(stderr,"\nmySaveFile = %s  datafile.fileinfo.cldno==%d  datafile.fileinfo.filetype==%d\n",
				FileName,datafile.fileinfo.cldno,datafile.fileinfo.filetype);
		memcpy(&JProgramInfo->sm[JProgramInfo->sm_head], &datafile, sizeof(DataFiles));
		JProgramInfo->sm_head = (JProgramInfo->sm_head+1)%SMBUFLEN;
	}
	sem_post(&JProgramInfo->mainData.UseCycleFlg);
	return 1;
}
void printString2(unsigned char *str,unsigned char Count,unsigned char flg)
{
	int i;
	SdPrint("\n\r");
	for(i=0;i<Count;i++)
	{

		if(flg==1)	{SdPrint(" %d",str[i]);}
		else if(flg==2)	{SdPrint(" %x",str[i]);}
		else	{SdPrint(" %c",str[i]);}
	}
	SdPrint("\n\r");
}

unsigned char GetValue_RealTime(unsigned char cNO,unsigned char mNo,DataFlag97 *flg,unsigned char *Dest)//����
{
	INT16U i=0;//,f=0;
	ClearWaitTimes(ProjectNo,JProgramInfo);
	memset(Dest,OxXX,DataLenMax);//��ʼ��
	//GetRealTimeData();//��ȡʵʱ����
	JProgramInfo->stateflags.work_485I = 1;

	SdPrint("\n����485I*ttyS2***\nGet value �������:%d[%d]����ַ��%02x%02x%02x%02x%02x%02x  �ɼ�����ַ�� %02x%02x%02x%02x%02x%02x  ��Լ %d  ������  %02x%02x\n\r",
					getPoint(cNO,mNo),
					JParamInfo3761->group2.f10[getPoint(cNO,mNo)].MeterNo+1,
					JParamInfo3761->group2.f10[getPoint(cNO,mNo)].Address[5],
					JParamInfo3761->group2.f10[getPoint(cNO,mNo)].Address[4],
					JParamInfo3761->group2.f10[getPoint(cNO,mNo)].Address[3],
					JParamInfo3761->group2.f10[getPoint(cNO,mNo)].Address[2],
					JParamInfo3761->group2.f10[getPoint(cNO,mNo)].Address[1],
					JParamInfo3761->group2.f10[getPoint(cNO,mNo)].Address[0],
					JParamInfo3761->group2.f10[getPoint(cNO,mNo)].CaijiqiAddress[5],
					JParamInfo3761->group2.f10[getPoint(cNO,mNo)].CaijiqiAddress[4],
					JParamInfo3761->group2.f10[getPoint(cNO,mNo)].CaijiqiAddress[3],
					JParamInfo3761->group2.f10[getPoint(cNO,mNo)].CaijiqiAddress[2],
					JParamInfo3761->group2.f10[getPoint(cNO,mNo)].CaijiqiAddress[1],
					JParamInfo3761->group2.f10[getPoint(cNO,mNo)].CaijiqiAddress[0],
					JParamInfo3761->group2.f10[getPoint(cNO,mNo)].ConnectType,
					flg->Dataflag[1],flg->Dataflag[0]);

	if(JParamInfo3761->group2.f10[getPoint(cNO,mNo)].ConnectType==1)//printf("\n97��Լ\n");
	{
		if ((flg->Dataflag[1]==0x00)||(flg->Dataflag[1]==0xEE)||(flg->Dataflag[1]==0xFF))
		{
			printf("dataflag  error1!!!!!");
			JProgramInfo->stateflags.work_485I = 0;//lqq ifwork
			return 2;
		}

		for (i=0;i<1;i++)  //ʧ�ܺ����һ���س�
		{
			//printf("\n97��Լ\n");
			if(	Dlt645GetVlueBy07(JParamInfo3761->group2.f10[getPoint(cNO,mNo)].Address,flg->Dataflag[0],flg->Dataflag[1],Dest)==1)
			{
				JProgramInfo->stateflags.work_485I = 0;//lqq ifwork
				return 1;
			}
		}
	}else if(JParamInfo3761->group2.f10[getPoint(cNO,mNo)].ConnectType==30)//printf("\n07��Լ\n");
	{
		for (i=0;i<1;i++)  //ʧ�ܺ����һ���س�
		{
			//printf("\n07��Լ\n");
			if(Dlt6452007GetValueBy97(JParamInfo3761->group2.f10[getPoint(cNO,mNo)].Address,flg,Dest)==1)
			{
				JProgramInfo->stateflags.work_485I = 0;//lqq ifwork
				return 1;
			}
		}
	}else if(JParamInfo3761->group2.f10[getPoint(cNO,mNo)].ConnectType==21)
	{
		printf("\n�Ϻ���Լ\n");
		for (i=0;i<1;i++)  //ʧ�ܺ����һ���س�
		{
			if(Dlt645SHGetValueBy97(JParamInfo3761->group2.f10[getPoint(cNO,mNo)].Address,flg,Dest)==1)
			{
				JProgramInfo->stateflags.work_485I = 0;//lqq ifwork
				return 1;
			}
		}
	}
	JProgramInfo->stateflags.work_485I = 0;//lqq ifwork
	return 0;
}

//���ݲɼ�
unsigned char GetValue(unsigned char cNO,unsigned char mNo,DataFlag97 *flg,unsigned char *Dest)//����
{
	INT16U i=0;//,f=0;
	ClearWaitTimes(ProjectNo,JProgramInfo);
	memset(Dest,OxXX,DataLenMax);//��ʼ��
	GetRealTimeData();//��ȡʵʱ����
	JProgramInfo->stateflags.work_485I = 1;

	SdPrint("\n����485I*ttyS2***\nGet value �������:%d[%d]����ַ��%02x%02x%02x%02x%02x%02x  �ɼ�����ַ�� %02x%02x%02x%02x%02x%02x  ��Լ %d  ������  %02x%02x\n\r",
					getPoint(cNO,mNo),
					JParamInfo3761->group2.f10[getPoint(cNO,mNo)].MeterNo+1,
					JParamInfo3761->group2.f10[getPoint(cNO,mNo)].Address[5],
					JParamInfo3761->group2.f10[getPoint(cNO,mNo)].Address[4],
					JParamInfo3761->group2.f10[getPoint(cNO,mNo)].Address[3],
					JParamInfo3761->group2.f10[getPoint(cNO,mNo)].Address[2],
					JParamInfo3761->group2.f10[getPoint(cNO,mNo)].Address[1],
					JParamInfo3761->group2.f10[getPoint(cNO,mNo)].Address[0],
					JParamInfo3761->group2.f10[getPoint(cNO,mNo)].CaijiqiAddress[5],
					JParamInfo3761->group2.f10[getPoint(cNO,mNo)].CaijiqiAddress[4],
					JParamInfo3761->group2.f10[getPoint(cNO,mNo)].CaijiqiAddress[3],
					JParamInfo3761->group2.f10[getPoint(cNO,mNo)].CaijiqiAddress[2],
					JParamInfo3761->group2.f10[getPoint(cNO,mNo)].CaijiqiAddress[1],
					JParamInfo3761->group2.f10[getPoint(cNO,mNo)].CaijiqiAddress[0],
					JParamInfo3761->group2.f10[getPoint(cNO,mNo)].ConnectType,
					flg->Dataflag[1],flg->Dataflag[0]);

	if(JParamInfo3761->group2.f10[getPoint(cNO,mNo)].ConnectType==1)//printf("\n97��Լ\n");
	{
		if ((flg->Dataflag[1]==0x00)||(flg->Dataflag[1]==0xEE)||(flg->Dataflag[1]==0xFF))
		{
			printf("dataflag  error1!!!!!");
			JProgramInfo->stateflags.work_485I = 0;//lqq ifwork
			return 2;
		}

		for (i=0;i<1;i++)  //ʧ�ܺ����һ���س�
		{
			//printf("\n97��Լ\n");
			if(	Dlt645GetVlueBy07(JParamInfo3761->group2.f10[getPoint(cNO,mNo)].Address,flg->Dataflag[0],flg->Dataflag[1],Dest)==1)
			{
				JProgramInfo->stateflags.work_485I = 0;//lqq ifwork
				return 1;
			}
		}
	}else if(JParamInfo3761->group2.f10[getPoint(cNO,mNo)].ConnectType==30)//printf("\n07��Լ\n");
	{
		for (i=0;i<1;i++)  //ʧ�ܺ����һ���س�
		{
			//printf("\n07��Լ\n");
			if(Dlt6452007GetValueBy97(JParamInfo3761->group2.f10[getPoint(cNO,mNo)].Address,flg,Dest)==1)
			{
				JProgramInfo->stateflags.work_485I = 0;//lqq ifwork
				return 1;
			}
		}
	}else if(JParamInfo3761->group2.f10[getPoint(cNO,mNo)].ConnectType==21)
	{
		printf("\n�Ϻ���Լ\n");
		for (i=0;i<1;i++)  //ʧ�ܺ����һ���س�
		{
			if(Dlt645SHGetValueBy97(JParamInfo3761->group2.f10[getPoint(cNO,mNo)].Address,flg,Dest)==1)
			{
				JProgramInfo->stateflags.work_485I = 0;//lqq ifwork
				return 1;
			}
		}
	}
	JProgramInfo->stateflags.work_485I = 0;//lqq ifwork
	return 0;
}

//�Ƿ��Ѿ�������
unsigned char  ReadHaved(TS ts,unsigned char flg)//������������Ƿ��Ѿ���ȡ����
{
	static INT8U flag=0;
	if(JProgramInfo->inChaoBiao==1)
		return 1;
	reflg=0;
	fprintf(stderr,"ReadHaved:flag=%d\n",flag);
	if(flag==0)
	{
		SdPrint("\n �ϵ���������...........\n");
		JDataFileInfo->data485[CarrWavePort-1].ts_begin = ts;
		flag = 1;
		return 1;
	}else
    {
    	if((JDataFileInfo->data485[0+PortBegNum].ts_begin.Year!=ts.Year) || (JDataFileInfo->data485[0+PortBegNum].ts_begin.Month!=ts.Month)
    		 || (JDataFileInfo->data485[0+PortBegNum].ts_begin.Day!=ts.Day))
    	{
    		reflg=1;
    		return 1;
    	}
    	else
    	{
    		if (JDataFileInfo->data485[0+PortBegNum].ts_begin.Hour!=ts.Hour)
    			return 1;
    		if ((JParamInfo3761->group5.f33.f33[0+PortBegNum].CbInter<=0) || (JParamInfo3761->group5.f33.f33[0+PortBegNum].CbInter>60))
    			JParamInfo3761->group5.f33.f33[0+PortBegNum].CbInter=60;
    		if (((ts.Hour-JDataFileInfo->data485[0+PortBegNum].ts_begin.Hour)*60+ts.Minute-JDataFileInfo->data485[0+PortBegNum].ts_begin.Minute)>=JParamInfo3761->group5.f33.f33[0+PortBegNum].CbInter)
    		{
    			SdPrint("read time1 %d---%d\n\r",ts.Minute,JDataFileInfo->data485[0+PortBegNum].ts.Minute);
    			return 1;
    		}
    	}
    }
   return 0;
}
//���ݴ�ӡ
void PrintMeterData(DataFiles *fl)
{

}
void IfrTestReadMeter() //yangdongifr
{}

int myGetManyData(DataFlg *data,INT8U *reslutBuf,INT8U DI1,INT8U DI0)
{
	INT8U i,isFlag=0;
	for(i=0;i<ManyFlagsCount;i++)
	{
		if(data[i].flg.Dataflag[0]==DI0 && data[i].flg.Dataflag[1]==DI1){
            memcpy(reslutBuf,&data[i].datas[0],sizeof(data[i].datas));
            isFlag=1;
            break;
		}
	}
	if(isFlag==0)
	{
		for(i=0;i<ManyFlagsCount;i++)
		{
			if(data[i].flg.Dataflag[0]==(DI0|0x0f)&&data[i].flg.Dataflag[1]==DI1){
				memcpy(reslutBuf,&data[i].datas[0],sizeof(data[i].datas));
				isFlag=1;
				break;
			}
		}
	}
	if(isFlag==0){
		memset(reslutBuf,0xee,sizeof(data[0].datas));
		return 0;
	}
	return 1;
}
void Dlt645_ShangHai_ZXYG(DataFiles *fl,INT8U di0_zx, INT8U di1_zx, INT8U di0_fx, INT8U di1_fx)
{
	FP32 zhengxiang=0,fanxiang=0;
	int i=0,id=0;
	INT8U flg1=0,flg2=0;
	for (i=0;i<ManyFlagsCount;i++)
	{
		if((fl->manyFiles.sm.datas[i].flg.Dataflag[0]&0x1f)==di0_zx &&
				fl->manyFiles.sm.datas[i].flg.Dataflag[1]==di1_zx)
		{
			zhengxiang = (FP32)BCD_INT32(fl->manyFiles.sm.datas[i].datas,4)/100;
			id = i;
			flg1 = 1;
			break;
		}
	}
	for (i=0;i<ManyFlagsCount;i++)
	{
		if((fl->manyFiles.sm.datas[i].flg.Dataflag[0]&0x2f)==di0_fx &&
				fl->manyFiles.sm.datas[i].flg.Dataflag[1]==di1_fx)
		{
			fanxiang = (FP32)BCD_INT32(fl->manyFiles.sm.datas[i].datas,4)/100;
			flg2 = 1;
			break;
		}
	}
	if(flg1==1 && flg2==1)
		INT32U_BCD((int)((zhengxiang+fanxiang)*100), fl->manyFiles.sm.datas[id].datas, 4);
}
void Dlt645_ShangHai(int cldno, INT8U *Dest, CurMeterInfo *curMeters, DataFiles *fl, int flgID)
{
	if(JParamInfo3761->group2.f10[cldno].ConnectType==21)
	{
		if(curMeters->flg[flgID].Dataflag[0]==0x10 && curMeters->flg[flgID].Dataflag[1]==0xc0)
		{
			memset(fl->manyFiles.sm.datas[flgID].datas, 0xee, DataLenMax);
			memcpy(fl->manyFiles.sm.datas[flgID].datas,&Dest[0],3);
			fl->manyFiles.sm.datas[flgID].flg.Dataflag[0]=curMeters->flg[flgID].Dataflag[0];
			fl->manyFiles.sm.datas[flgID].flg.Dataflag[1]=curMeters->flg[flgID].Dataflag[1];

			memset(fl->manyFiles.sm.datas[gflgCount].datas, 0xee, DataLenMax);
			memcpy(fl->manyFiles.sm.datas[curMeters->flgCount].datas,&Dest[3],3);
			fl->manyFiles.sm.datas[gflgCount].flg.Dataflag[0]=0x11;
			fl->manyFiles.sm.datas[gflgCount].flg.Dataflag[1]=0xc0;
			gflgCount++;
		}
		if((curMeters->flg[flgID].Dataflag[0]|0x2f)==0x2f && curMeters->flg[flgID].Dataflag[1]==0x90)
		{
			memset(fl->manyFiles.sm.datas[flgID].datas, 0xee, DataLenMax);
			memcpy(fl->manyFiles.sm.datas[flgID].datas,&Dest[0],4);
			fl->manyFiles.sm.datas[flgID].flg.Dataflag[0]=curMeters->flg[flgID].Dataflag[0];
			fl->manyFiles.sm.datas[flgID].flg.Dataflag[1]=curMeters->flg[flgID].Dataflag[1];
		}
		if((curMeters->flg[flgID].Dataflag[0]|0x1f)==0x1f && curMeters->flg[flgID].Dataflag[1]==0x94)
		{
			memset(fl->manyFiles.sm.datas[flgID].datas, 0xee, DataLenMax);
			memcpy(fl->manyFiles.sm.datas[flgID].datas,&Dest[5],12);
			fl->manyFiles.sm.datas[flgID].flg.Dataflag[0]=curMeters->flg[flgID].Dataflag[0];
			fl->manyFiles.sm.datas[flgID].flg.Dataflag[1]=curMeters->flg[flgID].Dataflag[1];

			memset(fl->manyFiles.sm.datas[gflgCount].datas, 0xee, DataLenMax);
			memcpy(fl->manyFiles.sm.datas[gflgCount].datas,&Dest[22],12);
			fl->manyFiles.sm.datas[gflgCount].flg.Dataflag[0]=0x1f;
			fl->manyFiles.sm.datas[gflgCount].flg.Dataflag[1]=0x98;
			gflgCount++;
		}
	}
}

void initsmFile(SMFiles *smfiles, int cldno)
{
	TS curts;
	TSGet(&curts);
	memcpy(&smfiles->ts, &curts, sizeof(TS));
	smfiles->sm.CaijiQiNo = cldno/64;
	smfiles->sm.MeterNo = cldno%64-1;
	ClearWaitTimes(ProjectNo,JProgramInfo);
	smfiles->systime = time(NULL);
	return;
}

void saveShuJuXiang(INT8U *filename, DataFlg *datas, DataFlag97 *flg97, fileinfo *fileinfo)
{
	//--------------------------------------
	SMFiles	curFiles;
	INT8U flg1=0;
	int m1=0, i, flg_num=0;
	printf("\n filename=%s  %02x%02x \n",filename,flg97->Dataflag[1],flg97->Dataflag[0]);
	if(access((char*)filename,0)==0)
	{
		memset(&curFiles, 0, sizeof(SMFiles));
		ReadFile((char*)filename, &curFiles, sizeof(SMFiles),JProgramInfo);
		for (i=0;i<ManyFlagsCount;i++)
		{
			if (curFiles.sm.datas[i].flg.Dataflag[1]==0x00 && curFiles.sm.datas[i].flg.Dataflag[0]==0x00)
				continue;
			if (curFiles.sm.datas[i].flg.Dataflag[1]==0xff && curFiles.sm.datas[i].flg.Dataflag[0]==0xff)
				continue;
			if (curFiles.sm.datas[i].flg.Dataflag[1]==OxXX && curFiles.sm.datas[i].flg.Dataflag[0]==OxXX)
				continue;
			if((flg97->Dataflag[0] == curFiles.sm.datas[i].flg.Dataflag[0])&&
				(flg97->Dataflag[1] == curFiles.sm.datas[i].flg.Dataflag[1]))
			{
				m1 = i;
				flg1 = 1;
			}
			flg_num++;
		}
		if(flg1==1)
		{
			SdPrint("\n Fu Gai-------[%02x%02x]---------\n",flg97->Dataflag[1],flg97->Dataflag[0]);
			curFiles.sm.datas[m1].flg.Dataflag[0] = flg97->Dataflag[0];
			curFiles.sm.datas[m1].flg.Dataflag[1] = flg97->Dataflag[1];
			memcpy(&curFiles.sm.datas[m1].datas[0], &datas->datas[0], DataLenMax);
			initsmFile(&curFiles, fileinfo->cldno);
			mySaveFile((char*)filename,(INT8U *)&curFiles,FILEHEADSIZE+flg_num*sizeof(DataFlg),JProgramInfo,fileinfo);
		}else
		{
			for (i=0;i<ManyFlagsCount;i++)
			{
				if ((curFiles.sm.datas[i].flg.Dataflag[1]==0x00 && curFiles.sm.datas[i].flg.Dataflag[0]==0x00)||
				 (curFiles.sm.datas[i].flg.Dataflag[1]==0xff && curFiles.sm.datas[i].flg.Dataflag[0]==0xff)||
				 (curFiles.sm.datas[i].flg.Dataflag[1]==OxXX && curFiles.sm.datas[i].flg.Dataflag[0]==OxXX))
				{
					SdPrint("\n Zhui Jia-------[%02x%02x]------%d---\n",flg97->Dataflag[1],flg97->Dataflag[0],i);
					curFiles.sm.datas[i].flg.Dataflag[0] = flg97->Dataflag[0];
					curFiles.sm.datas[i].flg.Dataflag[1] = flg97->Dataflag[1];
					memcpy(&curFiles.sm.datas[i].datas[0], &datas->datas[0], DataLenMax);
					initsmFile(&curFiles, fileinfo->cldno);
					mySaveFile((char*)filename,(INT8U *)&curFiles,FILEHEADSIZE+(flg_num+1)*sizeof(DataFlg),JProgramInfo,fileinfo);
					break;
				}
			}
		}
	}
	return;
}
void saveHourDongJie_ShangHai(DataFiles *fl, int ret)
{
	//����洢
	DataFlag97 flg97;
	INT8U TempBuf[60];
	TS ts,curts;
	INT8U tmpbuf[DataLenMax];
	int hour=0;
	SMFiles	dataFiles;
	TSGet(&curts);
	for(hour=curts.Hour; hour>=0; hour--)
	{
		memset(&dataFiles, 0xee, sizeof(SMFiles));
		if(myGetManyData(fl->manyFiles.sm.datas, dataFiles.sm.datas[0].datas, 0xFD, curts.Hour-hour+1)==0)
			continue;
		ts.Minute = 0;
		ts.Hour = BCD_INT32(&dataFiles.sm.datas[0].datas[1],1);
		ts.Day = BCD_INT32(&dataFiles.sm.datas[0].datas[2],1);
		ts.Month = BCD_INT32(&dataFiles.sm.datas[0].datas[3],1);
		ts.Year = BCD_INT32(&dataFiles.sm.datas[0].datas[4],1)+2000;
		memset(TempBuf,0,60);
		sprintf((char*)TempBuf,"/nand/DataHour/%04d%02d%02d",ts.Year,ts.Month,ts.Day);
		if (access((char*)TempBuf,0)!=0)//����������Ŀ¼
		{
			memset(TempBuf,0,60);
			sprintf((char*)TempBuf,"%s /nand/DataHour/%04d%02d%02d/",_CMDMKDIR_,ts.Year,ts.Month,ts.Day);
			system((char*)TempBuf);
			delay(50);
		}
		memset(TempBuf,0,60);
		sprintf((char*)TempBuf,"/nand/DataHour/%04d%02d%02d/%04d/",ts.Year,ts.Month,ts.Day,ret+1);
		if (access((char*)TempBuf,0)!=0)//����������Ŀ¼
		{
			memset(TempBuf,0,60);
			sprintf((char*)TempBuf,"%s /nand/DataHour/%04d%02d%02d/%04d/",_CMDMKDIR_,ts.Year,ts.Month,ts.Day,ret+1);
			system((char*)TempBuf);
			delay(50);
		}
		memset(TempBuf,0,60);
		sprintf((char*)TempBuf,"/nand/DataHour/%04d%02d%02d/%04d/%04d%02d%02d%02d%02d.dat",
				ts.Year,ts.Month,ts.Day,ret+1,ts.Year,ts.Month,ts.Day,ts.Hour,ts.Minute);
		smfileinfo.cldno = ret+1;
		smfileinfo.ts = ts;
		smfileinfo.filetype = FILEHOUR;
		if (access((char*)TempBuf,0)!=0)
		{
			initsmFile(&dataFiles, smfileinfo.cldno);
			mySaveFile((char*)TempBuf,(INT8U *)&dataFiles,FILEHEADSIZE+sizeof(DataFlg),JProgramInfo,&smfileinfo);
		}else
		{
			memcpy(tmpbuf, &dataFiles.sm.datas[0].datas[0], DataLenMax);

			memset(&dataFiles.sm.datas[0].datas[0], 0xee, DataLenMax);
			memcpy(&dataFiles.sm.datas[0].datas[0], &tmpbuf[6], 4);
			flg97.Dataflag[0] = 0x1f;
			flg97.Dataflag[1] = 0x90;
			saveShuJuXiang(TempBuf, &dataFiles.sm.datas[0], &flg97, &smfileinfo);
			delay(100);

			memset(&dataFiles.sm.datas[0].datas[0], 0xee, DataLenMax);
			memcpy(&dataFiles.sm.datas[0].datas[0], &tmpbuf[11], 4);
			flg97.Dataflag[0] = 0x2f;
			flg97.Dataflag[1] = 0x90;
			saveShuJuXiang(TempBuf, &dataFiles.sm.datas[0], &flg97, &smfileinfo);
			delay(50);
		}
		delay(50);
	}
	return;
}
void saveDayDongJie_ShangHai(DataFiles *fl, int ret)
{
	//����洢
	INT8U TempBuf[60];
	DataFlag97 flg97;
	TS ts,curts;
	int i=0;
	SMFiles	dataFiles;
	TSGet(&curts);
	for(i=0; i<3; i++)
	{
		memset(&dataFiles, 0xee, sizeof(SMFiles));
		if(!myGetManyData(fl->manyFiles.sm.datas, dataFiles.sm.datas[0].datas, 0xFB, 16*i+1))
			continue;
		if(!myGetManyData(fl->manyFiles.sm.datas, dataFiles.sm.datas[1].datas, 0xFB, 16*i+2))
			continue;
		if(!myGetManyData(fl->manyFiles.sm.datas, dataFiles.sm.datas[2].datas, 0xFB, 16*i+3))
			continue;
		ts.Minute = 0;
		ts.Hour	  =	0;
		ts.Day	  = BCD_INT32(&dataFiles.sm.datas[0].datas[2],1);
		ts.Month  = BCD_INT32(&dataFiles.sm.datas[0].datas[3],1);
		ts.Year   = BCD_INT32(&dataFiles.sm.datas[0].datas[4],1);
		memset(TempBuf,0,60);
		sprintf((char*)TempBuf,"/nand/DataDay/%04d",ret+1);
		if (access((char*)TempBuf,0)!=0)//����������Ŀ¼
		{
			memset(TempBuf,0,60);
			sprintf((char*)TempBuf,"%s /nand/DataDay/%04d",_CMDMKDIR_, ret+1);
			system((char*)TempBuf);
			delay(50);
		}
		memset(TempBuf,0,60);
		sprintf((char*)TempBuf,"/nand/DataDay/%04d/%02d.dat", ret+1, ts.Day);
		smfileinfo.cldno = ret+1;
		smfileinfo.ts = ts;
		smfileinfo.filetype = FILEDAY;
		if (access((char*)TempBuf,0)!=0)
		{
			initsmFile(&dataFiles, smfileinfo.cldno);
			mySaveFile((char*)TempBuf,(INT8U *)&dataFiles,FILEHEADSIZE+3*sizeof(DataFlg),JProgramInfo,&smfileinfo);
		}else
		{
			flg97.Dataflag[0] = 0x01;
			flg97.Dataflag[1] = 0xFB;
			saveShuJuXiang(TempBuf, &dataFiles.sm.datas[0], &flg97,&smfileinfo);
			delay(100);
			flg97.Dataflag[0] = 0x02;
			flg97.Dataflag[1] = 0xFB;
			saveShuJuXiang(TempBuf, &dataFiles.sm.datas[1], &flg97,&smfileinfo);
			delay(100);
			flg97.Dataflag[0] = 0x1f;
			flg97.Dataflag[1] = 0x90;
			saveShuJuXiang(TempBuf, &dataFiles.sm.datas[1], &flg97, &smfileinfo);
			delay(100);
			flg97.Dataflag[0] = 0x03;
			flg97.Dataflag[1] = 0xFB;
			saveShuJuXiang(TempBuf, &dataFiles.sm.datas[2], &flg97, &smfileinfo);
			delay(100);
			flg97.Dataflag[0] = 0x2f;
			flg97.Dataflag[1] = 0x90;
			saveShuJuXiang(TempBuf, &dataFiles.sm.datas[2], &flg97, &smfileinfo);
		}
		delay(50);
	}
	return;
}


void saveMonthDongJie_ShangHai(DataFiles *fl, int ret)
{
	//���´洢
	INT8U TempBuf[60];
	DataFlag97 flg97;
	TS ts,curts;
	int i=0;
	SMFiles	dataFiles;
	INT8U flag_1f=0,flag_2f=0;
	for(i=0; i<2; i++)
	{
		memset(&dataFiles, 0xee, sizeof(SMFiles));
		flag_1f=0,flag_2f=0;
		TSGet(&curts);
		if(i==0)
		{
			if(myGetManyData(fl->manyFiles.sm.datas, dataFiles.sm.datas[0].datas, 0x94, 0x1f)!=0)
				flag_1f = 1;
			else
				printf("\n saveMonthDongJie_ShangHai 941f\n");
			if(myGetManyData(fl->manyFiles.sm.datas, dataFiles.sm.datas[1].datas, 0x94, 0x2f)!=0)
				flag_2f = 1;
			else
				printf("\n saveMonthDongJie_ShangHai 942f\n");
		}
		else if(i==1)
		{
			if(myGetManyData(fl->manyFiles.sm.datas, dataFiles.sm.datas[0].datas, 0x98, 0x1f)!=0)
				flag_1f = 1;
			else
				printf("\n saveMonthDongJie_ShangHai 981f\n");
			if(myGetManyData(fl->manyFiles.sm.datas, dataFiles.sm.datas[1].datas, 0x98, 0x2f)!=0)
				flag_2f = 1;
			else
				printf("\n saveMonthDongJie_ShangHai 982f\n");
		}
		printf("\n-------------------saveMonthDongJie_ShangHai----------------\n");
		ts.Minute = 0;
		ts.Hour	  =	0;
		ts.Day	  = 1;
		ts.Month  = curts.Month;
		ts.Year   = curts.Year;
		if(i==1)
			TimeDecrease(&ts, 5, 1);
		memset(TempBuf,0,60);
		sprintf((char*)TempBuf,"/nand/DataMonth/%04d",ret+1);
		if (access((char*)TempBuf,0)!=0)//����������Ŀ¼
		{
			memset(TempBuf,0,60);
			sprintf((char*)TempBuf,"%s /nand/DataMonth/%04d",_CMDMKDIR_, ret+1);
			system((char*)TempBuf);
			delay(50);
		}
		memset(TempBuf,0,60);
		sprintf((char*)TempBuf,"/nand/DataMonth/%04d/%02d.dat", ret+1, ts.Month);
		sprintf((char*)TempBuf,"/nand/DataMonth/%04d/%02d.dat", ret+1, ts.Month);
		smfileinfo.cldno = ret+1;
		smfileinfo.ts = ts;
		smfileinfo.filetype = FILEMONTH;
		if(flag_1f == 1)
		{
			flg97.Dataflag[0] = 0x1f;
			flg97.Dataflag[1] = 0x90;
			saveShuJuXiang(TempBuf, &dataFiles.sm.datas[0], &flg97, &smfileinfo);
			delay(100);
		}
		if(flag_2f == 1)
		{
			flg97.Dataflag[0] = 0x2f;
			flg97.Dataflag[1] = 0x90;
			saveShuJuXiang(TempBuf, &dataFiles.sm.datas[1], &flg97, &smfileinfo);
			delay(100);
		}
		if(flag_1f == 1 || flag_2f == 1)
		{
			flg97.Dataflag[0] = 0x01;
			flg97.Dataflag[1] = 0xFB;
			dataFiles.sm.datas[2].datas[0]=0;
			dataFiles.sm.datas[2].datas[1]=0;
			dataFiles.sm.datas[2].datas[2]=1;
			INT32U_BCD(ts.Month, &dataFiles.sm.datas[2].datas[3], 1);
			INT32U_BCD(ts.Year-2000,&dataFiles.sm.datas[2].datas[4],1);
			saveShuJuXiang(TempBuf, &dataFiles.sm.datas[2], &flg97, &smfileinfo);
			delay(100);
		}
		if(flag_1f == 1)
		{
			flg97.Dataflag[0] = 0x02;
			flg97.Dataflag[1] = 0xFB;
			saveShuJuXiang(TempBuf, &dataFiles.sm.datas[0], &flg97, &smfileinfo);
			delay(100);
		}
		if(flag_2f == 1)
		{
			flg97.Dataflag[0] = 0x03;
			flg97.Dataflag[1] = 0xFB;
			saveShuJuXiang(TempBuf, &dataFiles.sm.datas[1], &flg97, &smfileinfo);
			delay(100);
		}
	}
	return;
}


//void saveMonthDongJie_ShangHai(DataFiles *fl, int ret)
//{
//	//���´洢
//	INT8U TempBuf[60];
//	DataFlag97 flg97;
//	TS ts,curts;
//	int i=0;
//	SMFiles	dataFiles;
//	TSGet(&curts);
//	printf("\n saveMonthDongJie_ShangHai %d\n",ret+1);
//	memset(&dataFiles, 0xee, sizeof(SMFiles));
//	for(i=0; i<2; i++)
//	{
//		if(i==0)
//		{
//			if(myGetManyData(fl->manyFiles.sm.datas, dataFiles.sm.datas[i].datas, 0x94, 0x1f)==0)
//			{
//				printf("\n saveMonthDongJie_ShangHai 941f\n");
//				continue;
//			}
//		}
//		else if(i==1)
//		{
//			if(myGetManyData(fl->manyFiles.sm.datas, dataFiles.sm.datas[i].datas, 0x98, 0x1f)==0)
//			{
//				printf("\n saveMonthDongJie_ShangHai 981f\n");
//				continue;
//			}
//		}
//		ts.Minute = 0;
//		ts.Hour	  =	0;
//		ts.Day	  = 1;
//		ts.Month  = curts.Month;
//		ts.Year   = curts.Year;
//		if(i==1)
//			TimeDecrease(&ts, 5, 1);
//		memset(TempBuf,0,60);
//		sprintf((char*)TempBuf,"/nand/DataMonth/%04d",ret+1);
//		if (access((char*)TempBuf,0)!=0)//����������Ŀ¼
//		{
//			memset(TempBuf,0,60);
//			sprintf((char*)TempBuf,"%s /nand/DataMonth/%04d",_CMDMKDIR_, ret+1);
//			system((char*)TempBuf);
//			delay(50);
//		}
//		memset(TempBuf,0,60);
//		sprintf((char*)TempBuf,"/nand/DataMonth/%04d/%02d.dat", ret+1, ts.Month);
//		smfileinfo.cldno = ret+1;
//		smfileinfo.ts = ts;
//		smfileinfo.filetype = FILEMONTH;
//		printf("\nTempBuf==%s \n",TempBuf);
//		if (access((char*)TempBuf,0)!=0)
//		{
//			dataFiles.sm.datas[i].flg.Dataflag[0] = 0x1f;
//			dataFiles.sm.datas[i].flg.Dataflag[1] = 0x90;
//			mySaveFile((char*)TempBuf,(INT8U *)&dataFiles,FILEHEADSIZE*sizeof(DataFlg),JProgramInfo,&smfileinfo);
//		}else
//		{
//			flg97.Dataflag[0] = 0x1f;
//			flg97.Dataflag[1] = 0x90;
//			saveShuJuXiang(TempBuf, &dataFiles.sm.datas[i], &flg97,&smfileinfo);
//		}
//		delay(50);
//	}
//	return;
//}

//���ݲɼ�
int GetMeterData(INT8U FirFlg,CurMeterInfo *curMeters ,DataFiles *fl,TS ts)
{
	int flgID,succ,ret,i=0;
	INT8U dayflg=0,monflg=0,hourflg=0,TempBuf[60],Command[120];
	TS ts2;
	unsigned char rt=1,isSucc=0;
	unsigned char  Dest[DataLenMax];
	SMFiles 	smfileold;
	succ=1;
	rt=1;
	delay(100);
	ClearWaitTimes(ProjectNo,JProgramInfo);
	//if(fl->fileType<2)	ReadDataTasks();//����ִ�ж���������
	succ=0;
	ret = 0;

//	if (JProgramInfo->GuoWangSoftTest) {
		//9.24 ����ǰ�������ݣ����ã��������ʧ�ܵı�����α���ֵ�������ΪEE
		ret=getPoint(curMeters->cjqNo,curMeters->MeterNo)+1;
		memset(TempBuf,0,60);
		sprintf((char *) TempBuf, "/nand/DataCurr/%04d/curr.dat",ret);
	//	fprintf(stderr,"ReadMeter:TempBuf=%s\n",TempBuf);
		ReadFile((char *) TempBuf, &smfileold,sizeof(SMFiles),JProgramInfo);
//	}

	for(i=0;((((i<2) && (succ==0) && (ts.Hour==0) && (FirFlg>=1))) || ((i<1) && (succ==0)));i++)
	{  //0��ʱ����δ�ɹ����س�һ��
		succ=0;
		if(Open485Meter(curMeters->cjqNo,curMeters->MeterNo)>0)
		{
			gflgCount = curMeters->flgCount;
			printf("\n curMeters->flgCount ====%d \n",curMeters->flgCount);
			for(flgID=0;flgID<curMeters->flgCount;flgID++)
			{
				ClearWaitTimes(ProjectNo,JProgramInfo);
				//shanghai gai isucc
				isSucc=GetValue(curMeters->cjqNo,curMeters->MeterNo,&curMeters->flg[flgID],&Dest[0]);
				if (isSucc==1 )
				{
					succ++;//succ=1;
				//	fprintf(stderr,"\n succes = %d :   %02x %02x",succ,curMeters->flg[flgID].Dataflag[1],curMeters->flg[flgID].Dataflag[0]);
					rt=0;//�޹���
					JDataFileInfo->data485[FirFlg-1+PortBegNum].MeterNum_CBSucc++;//������Ϣ

					memcpy(fl->manyFiles.sm.datas[flgID].datas,&Dest[0],DataLenMax);
					fl->manyFiles.sm.datas[flgID].flg.Dataflag[0]=curMeters->flg[flgID].Dataflag[0];
					fl->manyFiles.sm.datas[flgID].flg.Dataflag[1]=curMeters->flg[flgID].Dataflag[1];
					//shanghai------------------->>//�Ϻ���Լ������ʱ����һ���������Ҫ�ֿ��洢 ����3���ط�  ɸѡ�����ࡢ�洢����� ��
					Dlt645_ShangHai(getPoint(curMeters->cjqNo,curMeters->MeterNo), Dest, curMeters, fl, flgID);
					//---------------------------<<
				}else {
//						if (JProgramInfo->GuoWangSoftTest) {
						//9.24 ����ʧ�ܣ�ȡcurr.datֵ
						fl->manyFiles.sm.datas[flgID].flg.Dataflag[0]=curMeters->flg[flgID].Dataflag[0];
						fl->manyFiles.sm.datas[flgID].flg.Dataflag[1]=curMeters->flg[flgID].Dataflag[1];
						myGetManyData(smfileold.sm.datas,fl->manyFiles.sm.datas[flgID].datas,curMeters->flg[flgID].Dataflag[1],curMeters->flg[flgID].Dataflag[0]);
//						}
					fprintf(stderr,"\n failed = %d :   %02x %02x",succ,curMeters->flg[flgID].Dataflag[1],curMeters->flg[flgID].Dataflag[0]);
				}
			}
		}
	}
	printf("\n������������ succ=%d",succ);
	if (succ > 0)//if (succ ==1)
	{
		fl->manyFiles.sm.CaijiQiNo=curMeters->cjqNo;
		fl->manyFiles.sm.MeterNo=curMeters->MeterNo;
		if (JParamInfo3761->group2.f9.Flag[3] & 0x40)
		{
			ret=getPoint(curMeters->cjqNo,curMeters->MeterNo);
			if(JDataFileInfo->ptinfo[ret].AlarmFlg[30]&0x40)
			{
				ret=0;
				while(ret<100)
				{
					if(JProgramInfo->stateflags.ErcFlg==0)
						break;
					delay(50);
					ret++;
				}
				memset(&JProgramInfo->CurrErc,0,sizeof(ERC));
				ret=getPoint(curMeters->cjqNo,curMeters->MeterNo);
				JProgramInfo->CurrErc.Err31.ERCNo=31;
				JProgramInfo->CurrErc.Err31.len=21;
				JProgramInfo->CurrErc.Err31.ClNo[0]=ret&0xff;
				JProgramInfo->CurrErc.Err31.ClNo[1]=(ret>>8)&0xff;
				JProgramInfo->CurrErc.Err31.ClNo[1]&=0x7F;
				JProgramInfo->stateflags.ErcFlg=31;
				JDataFileInfo->ptinfo[ret].AlarmFlg[30] = 0;
			}
		}
		if (JParamInfo3761->group2.f9.Flag[2] & 0x10)//�����ɹ����� //gaiyi
		{
			JDataFileInfo->ptinfo[ret].AlarmFlg[20]=0;
		}
	}else
	{
		printf("\n===========FirFlg=%d  succ==0��������",FirFlg);
		if (FirFlg != 0)
		{
			if (JParamInfo3761->group2.f9.Flag[3] & 0x40)
			{
				ret=getPoint(curMeters->cjqNo,curMeters->MeterNo);
				//printf("\nErr31!!!!!JParamInfo3761->Point[%d].f10.AlarmFlg[30]==%02x",ret,JDataFileInfo->ptinfo[ret].AlarmFlg[30]);
				if(!(JDataFileInfo->ptinfo[ret].AlarmFlg[30]&0x40))
				{
					printf("\nErr31!!!!!!!!����");
					ret=0;
					while(ret<100)
					{
						if(JProgramInfo->stateflags.ErcFlg==0)
							break;
						delay(50);
						ret++;
					}

					memset(&JProgramInfo->CurrErc,0,sizeof(ERC));
					ret=getPoint(curMeters->cjqNo,curMeters->MeterNo);
					printf("\nErr31!!!!!!!!����1111  ret=%d",ret);
					JProgramInfo->CurrErc.Err31.ERCNo=31;
					JProgramInfo->CurrErc.Err31.len=21;
					JProgramInfo->CurrErc.Err31.ClNo[0]=ret&0xff;
					JProgramInfo->CurrErc.Err31.ClNo[1]=(ret>>8)&0xff;
					JProgramInfo->CurrErc.Err31.ClNo[1]|=0x80;
					JProgramInfo->stateflags.ErcFlg=31;
					JDataFileInfo->ptinfo[ret].AlarmFlg[30]|=0b01000000;
				}
			}
		}
	}

	ret=getPoint(curMeters->cjqNo,curMeters->MeterNo)+1;
	SdPrint("\n     ret=%d    succ=%d   \n",ret,succ);
	if (FirFlg == 0)
	{
		hourflg=1;
		dayflg=1;
		monflg=1;
	}
	//--------------------------------------------------------
	fprintf(stderr,"\n &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& 485I�����㳭�� �� %d ��������������� %d",succ,curMeters->flgCount);
	if (succ < 10)
	{
		printf("\n ���в����㳭��ʧ�ܣ���");
		if ((JParamInfo3761->group2.f9.Flag[2] & 0x10) && (Rs485ErroFlag == 0))
		{
			Rs485ErroFlag = 1;   //����485����
			printf("\n����485���ϣ� ");
			int ret=0;
			while(ret<100)
			{
				if(JProgramInfo->stateflags.ErcFlg==0)	break;
				delay(50);
				ret++;
			}
			memset(&JProgramInfo->CurrErc,0,sizeof(ERC));
			JProgramInfo->CurrErc.Err21.ERCNo=21;
			JProgramInfo->CurrErc.Err21.len=6;
			JProgramInfo->CurrErc.Err21.Code = 4;
			JProgramInfo->stateflags.ErcFlg=21;
			fprintf(stderr,"JProgramInfo->stateflags.ErcFlg=%d,ret=%d\n",JProgramInfo->CurrErc.Err21.ERCNo,ret);
		}
	}else
	{
		if ((JParamInfo3761->group2.f9.Flag[2] & 0x10) && (Rs485ErroFlag == 1))
		{
			Rs485ErroFlag = 0;   //485���ϻָ�
			printf("\n485���ϻָ��� ");
		}
	}
	//-----------------------------------------------------------------------------------------------
	if (succ >0)//F161
	{
		for(flgID=0;flgID<curMeters->flgCount;flgID++)
		{
			if ((curMeters->flg[flgID].Dataflag[0]==0x00 )&&(curMeters->flg[flgID].Dataflag[1]==0x63))
			{
				INT8U stateTmp;
				stateTmp = fl->manyFiles.sm.datas[flgID].datas[0];
				stateTmp = (stateTmp & 0b00010000)>>4;
				if (stateTmp == 1)
					stateTmp =0x11;
				if (JDataFileInfo->ptinfo[ret].f161.F_H_State != stateTmp)
				{
					JDataFileInfo->ptinfo[ret].f161.F_H_State = stateTmp;
					if (stateTmp == 0x11)
					{//״̬�ɷֱ�ɺ�״̬
						INT32U_BCD(ts.Minute,&JDataFileInfo->ptinfo[ret].f161.HeZhatime[0],1);
						INT32U_BCD(ts.Hour,&JDataFileInfo->ptinfo[ret].f161.HeZhatime[1],1);
						INT32U_BCD(ts.Day,&JDataFileInfo->ptinfo[ret].f161.HeZhatime[2],1);
						INT32U_BCD(ts.Month,&JDataFileInfo->ptinfo[ret].f161.HeZhatime[3],1);
						INT32U_BCD(ts.Year,&JDataFileInfo->ptinfo[ret].f161.HeZhatime[4],1);
					}else
					{//״̬�ɺϱ�ɷ�״̬
						INT32U_BCD(ts.Minute,&JDataFileInfo->ptinfo[ret].f161.FenZhatime[0],1);
						INT32U_BCD(ts.Hour,&JDataFileInfo->ptinfo[ret].f161.FenZhatime[1],1);
						INT32U_BCD(ts.Day,&JDataFileInfo->ptinfo[ret].f161.FenZhatime[2],1);
						INT32U_BCD(ts.Month,&JDataFileInfo->ptinfo[ret].f161.FenZhatime[3],1);
						INT32U_BCD(ts.Year,&JDataFileInfo->ptinfo[ret].f161.FenZhatime[4],1);
					}
				}

			}
		}
	}//f161 end
	//-----------------------------------------------------------------------------------------------
	if (succ > 0 )//if (succ == 1 )
	{
		memset(TempBuf,0,60);
		sprintf((char*)TempBuf,"/nand/DataCurr/%04d/",ret);
		if (access((char*)TempBuf,0)!=0)//��Ŀ¼�����ڣ��ȴ���
		{
			memset(Command,0,60);
			sprintf((char*)Command,"%s /nand/DataCurr/%04d/",_CMDMKDIR_,ret);
			 system((char*)Command);
			 delay(100);
		 }
		memset(TempBuf,0,60);
		sprintf((char*)TempBuf,"/nand/DataDay/%04d/",ret);//��Ŀ¼�����ڣ��ȴ���
		if (access((char*)TempBuf,0)!=0)
		{
			memset(Command,0,60);
			sprintf((char*)Command,"%s /nand/DataDay/%04d/",_CMDMKDIR_,ret);
			 system((char*)Command);
			 delay(100);
		 }
		memset(TempBuf,0,60);
		sprintf((char*)TempBuf,"/nand/DataMonth/%04d/",ret);//��Ŀ¼�����ڣ��ȴ���
		if (access((char*)TempBuf,0)!=0)
		{
			memset(Command,0,60);
			sprintf((char*)Command,"%s /nand/DataMonth/%04d/",_CMDMKDIR_,ret);
			 system((char*)Command);
			 delay(100);
		 }
		ts2=ts;

		memset(TempBuf,0,60);
		sprintf((char*)TempBuf,"/nand/DataCurr/%04d/curr.dat",ret);
		if (access((char*)TempBuf,0)==0)//��curr.dat����last.dat
		{
			memset(Command,0,120);
			sprintf((char*)Command,"%s /nand/DataCurr/%04d/curr.dat /nand/DataCurr/%04d/last.dat",_CMDCP_,ret,ret);
			system((char*)Command);
			delay(50);
		}
		fl->manyFiles.ts=ts;
		fl->manyFiles.sm.CaijiQiNo=curMeters->cjqNo;
		fl->manyFiles.sm.MeterNo=curMeters->MeterNo;
		//shanghai--------------------------------------------------------------------------------->>
		ret = getPoint(curMeters->cjqNo,curMeters->MeterNo);

		fl->manyFiles.systime = time(NULL);
		smfileinfo.cldno = ret+1;
		smfileinfo.ts = ts;
		smfileinfo.filetype = FILECURR;
		if(JParamInfo3761->group2.f10[ret].ConnectType==21)
		{
			printf("\n21 gflgCount==%d\n",gflgCount);
			initsmFile(&fl->manyFiles, smfileinfo.cldno);
			mySaveFile((char*)TempBuf,(INT8U *)&fl->manyFiles,FILEHEADSIZE+gflgCount*sizeof(DataFlg),JProgramInfo,&smfileinfo);
			saveMonthDongJie_ShangHai(fl, ret);
		}
		else
		{ //�������ܱ�
//			if(curMeters->flType == common)
//			{
//				if(JParamInfo3761->group2.f10[ret].ConnectType==1)
//					Dlt645_ShangHai_ZXYG(fl, 0x1f, 0x90, 0x2f, 0x90);
//				if(JParamInfo3761->group2.f10[ret].ConnectType==30)
//					Dlt645_ShangHai_ZXYG(fl, 0x01, 0xFB, 0x02, 0xFB);
//			}
			if(JParamInfo3761->group2.f10[getPoint(curMeters->cjqNo,curMeters->MeterNo)].ConnectType==30)
			{
				for(i=0;i<ManyFlagsCount;i++)
				{
					if((fl->manyFiles.sm.datas[i].flg.Dataflag[0]==0x01) && (fl->manyFiles.sm.datas[i].flg.Dataflag[1]==0xFB))
					{
						printf("\n---%d------���ʱ��  %d %d %d %d %d------ϵͳʱ��%d %d %d\n",
								i,
								BCD_INT32(&fl->manyFiles.sm.datas[i].datas[0],1),
								BCD_INT32(&fl->manyFiles.sm.datas[i].datas[1],1),
								BCD_INT32(&fl->manyFiles.sm.datas[i].datas[2],1),
								BCD_INT32(&fl->manyFiles.sm.datas[i].datas[3],1),
								BCD_INT32(&fl->manyFiles.sm.datas[i].datas[4],1),
								fl->manyFiles.ts.Day,
								fl->manyFiles.ts.Month,
								fl->manyFiles.ts.Year);
						if((BCD_INT32(&fl->manyFiles.sm.datas[i].datas[2],1)==fl->manyFiles.ts.Day) &&
							(BCD_INT32(&fl->manyFiles.sm.datas[i].datas[3],1)==fl->manyFiles.ts.Month))
						{
							JDataFileInfo->ptinfo[getPoint(curMeters->cjqNo,curMeters->MeterNo)].FirRead=1;
							initsmFile(&fl->manyFiles, smfileinfo.cldno);
							mySaveFile((char*)TempBuf,(INT8U *)&fl->manyFiles,FILEHEADSIZE+gflgCount*sizeof(DataFlg),
									JProgramInfo, &smfileinfo);
						}else
						{
							printf("\n--- ʱ�䲻ƥ��   ������save Fail\n");
						}
					}
				}
			}else
			{
				initsmFile(&fl->manyFiles, smfileinfo.cldno);
				mySaveFile((char*)TempBuf,(INT8U *)&fl->manyFiles,FILEHEADSIZE+gflgCount*sizeof(DataFlg),
					JProgramInfo, &smfileinfo);
			}
			JProgramInfo->FileSaveFlag.ptinfoflag= 1;
			if(curMeters->flType == common)
			{
				saveDayDongJie_ShangHai(fl, ret);
				saveMonthDongJie_ShangHai(fl, ret);
			}else if(curMeters->flType == many)//fl ret
			{
				saveDayDongJie_ShangHai(fl, ret);
				saveMonthDongJie_ShangHai(fl, ret);
				saveHourDongJie_ShangHai(fl, ret);
			}
		}
		//----------------------------------------------------------------------------------<<
		delay(50);
	}
	else
	{
		memset(TempBuf,0,60);
		sprintf((char*)TempBuf,"/nand/DataCurr/%04d/",ret);
		if (access((char*)TempBuf,0)!=0)//��Ŀ¼�����ڣ�����Ŀ¼
		{
			memset(Command,0,60);
			sprintf((char*)Command,"%s /nand/DataCurr/%04d/",_CMDMKDIR_,ret);
			system((char*)Command);
			delay(100);
		 }

		memset(TempBuf,0,60);
		sprintf((char*)TempBuf,"/nand/DataCurr/%04d/curr.dat",ret);
		if (access((char*)TempBuf,0)==0)//��ǰʧ�ܣ�������last.dat�� ɾ��curr.dat
		{
			memset(Command,0,120);
			sprintf((char*)Command,"%s /nand/DataCurr/%04d/curr.dat /nand/DataCurr/%04d/last.dat",
					_CMDCP_,ret,ret);
			system((char*)Command);
			delay(50);
			if (reflg==1)
			{
				memset(Command,0,120);
				sprintf((char*)Command,"%s /nand/DataCurr/%04d/curr.dat",_CMDRM_,ret);
				system((char*)Command);
				delay(50);
			}
		}
	}
	return succ;
}

//��ȡʵʱ����
void GetRealTimeData(void)
{
	ClearWaitTimes(ProjectNo,JProgramInfo);
	if(JProgramInfo->dataTransgw.f1.ASK_Port==2||JProgramInfo->dataTransgw.f1.ASK_Port==3)//weifang JProgramInfo->dataTransgw.f1.ASK_Port
	{
		while(1)
		{
			ClearWaitTimes(ProjectNo,JProgramInfo);
			DataTrans();
			JProgramInfo->dataTransgw.f1.ASK_Port = 0;
			Current_time = time(NULL);
			if(abs(Current_time - Update_current_time)%10==0 && Current_time != Update_current_time)
			{
			//	printf("\n �Ѿ��� %d ��û���յ��������ġ�\n",abs(Current_time - Update_current_time));
			}
			if(abs(Current_time - Update_current_time)>=3*60) //����3����
			{
				printf("\n**************485����3���� û���յ�͸��ת������ ---ת�����**********************\n");
				break;
			}
		}
	}

	DataTrans();
	if(JProgramInfo->RealData.ReadFlg!=1)
		return;
	SdPrint("\n\r  4851 GetRealTimeData  begin ---------------------\n\r");
	//CeLianDian_Config *Meter;
	F10 *Meter;
	//F25 *f25;
	unsigned char  Dest[DataLenMax];
	unsigned char rt=1,sc,fd,succ=0;
	int i,j=0,ret=0;
	INT8U Temp_FilePath[60];

	Meter=&JParamInfo3761->group2.f10[getPoint(JProgramInfo->RealData.CaijiqiNo,JProgramInfo->RealData.MeterNo)];
	if (Meter->ConnectType==2)//����
	{
		printf("\n485I JProgramInfo->RealData.ReadFlg=3;--1\n");
		JProgramInfo->RealData.ReadFlg=3;
		JProgramInfo->stateflags.JCFlag=1;
		for(i=0;((i<20)&&(JProgramInfo->stateflags.JCFlag==1));i++)
		{
			ClearWaitTimes(ProjectNo,JProgramInfo);
			delay(1000);
		}
		sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",getPoint(JProgramInfo->RealData.CaijiqiNo,JProgramInfo->RealData.MeterNo)+1);
		ReadFile((char *) Temp_FilePath, &smfile,sizeof(SMFiles),JProgramInfo);
		for(i=0;i<JProgramInfo->RealData.CurFlgCount;i++)
		{
			for(j=0;j<ManyFlagsCount;j++)
			{
				if ((smfile.sm.datas[j].flg.Dataflag[0]==JProgramInfo->RealData.flg97[i].flg.Dataflag[0]) &&
						(smfile.sm.datas[j].flg.Dataflag[1]==JProgramInfo->RealData.flg97[i].flg.Dataflag[1]))
				{
					memcpy(JProgramInfo->RealData.flg97[i].datas,&smfile.sm.datas[j].datas[0],DataLenMax);
					break;
				}
			}
		}
		JProgramInfo->RealData.ReadFlg=9;
		return;
	}
//���ݹ������ᣬRS485I��Ӧ�˿�2,�˿�1Ϊ����

	if (JParamInfo3761->group2.f10[getPoint(JProgramInfo->RealData.CaijiqiNo,JProgramInfo->RealData.MeterNo)].port!=(1+PortBegNum)&&
			JParamInfo3761->group2.f10[getPoint(JProgramInfo->RealData.CaijiqiNo,JProgramInfo->RealData.MeterNo)].port!=(2+PortBegNum))
		return;
	//f25 =&JParamInfo3761->Point[getPoint(JProgramInfo->RealData.CaijiqiNo,JProgramInfo->RealData.MeterNo)].f25;
	if ((Meter->ConnectType!=1) && (Meter->ConnectType!=30)&& (Meter->ConnectType!=21))
	{
		JProgramInfo->RealData.ReadFlg=9;
		return;
	}
	//1������ڳ�����¼�ϵ���������
	//��ʵʱ����
	if(CurCom485.State==1)CloseCom485();
	printf("\n485I JProgramInfo->RealData.ReadFlg=3;--2\n");
		JProgramInfo->RealData.ReadFlg=3;
	delay(100);
	sc=1;
	succ=0;
	/*if( Open485Meter(JProgramInfo->RealData.CaijiqiNo,JProgramInfo->RealData.MeterNo)<1)
	{
		sc=0;
		JProgramInfo->RealData.ReadFlg=9;
		return;
	}*/
	for(i=0;i<JProgramInfo->RealData.CurFlgCount;i++)
	{
		if ((JProgramInfo->RealData.flg97[i].flg.Dataflag[0]==0x00) && (JProgramInfo->RealData.flg97[i].flg.Dataflag[1]==0x00))
			continue;
		ClearWaitTimes(ProjectNo,JProgramInfo);
		if(JProgramInfo->RealData.ReadFlg==0)break;
		if(JProgramInfo->RealData.ReadFlg==4) break;
		if(JProgramInfo->RealData.ReadFlg==3)
		{

//			fd=0;
//			if (Meter->Type!=3)
//			{
//				for(j=0;j<JProgramInfo->Para.meterFlags.CommDayFlagsCount;j++)
//				{
//					if (((JProgramInfo->Para.meterFlags.CommDayFlags[j].Dataflag[0]&0xf0)==(JProgramInfo->RealData.flg97[i].flg.Dataflag[0]&0xf0)) &&
//						(JProgramInfo->Para.meterFlags.CommDayFlags[j].Dataflag[1]==JProgramInfo->RealData.flg97[i].flg.Dataflag[1]))
//					{
//						fd=1;
//					}
//				}
//			}else
//			{
//				for(j=0;j<JProgramInfo->Para.meterFlags.ManyDayFlagsCount;j++)
//				{
//					if (((JProgramInfo->Para.meterFlags.ManyDayFlags[j].Dataflag[0]&0xf0)==(JProgramInfo->RealData.flg97[i].flg.Dataflag[0]&0xf0)) &&
//						(JProgramInfo->Para.meterFlags.ManyDayFlags[j].Dataflag[1]==JProgramInfo->RealData.flg97[i].flg.Dataflag[1]))
//					{
//						fd=1;
//					}
//				}
//			}

			fd=1;
			printf("\nJProgramInfo->RealData.flg97[i].flg.Dataflag %02x%02x Meter->Type =%d fd=%d  cjq %d meterno %d\n",JProgramInfo->RealData.flg97[i].flg.Dataflag[1],
					JProgramInfo->RealData.flg97[i].flg.Dataflag[0],Meter->Type,fd,
					JProgramInfo->RealData.CaijiqiNo,JProgramInfo->RealData.MeterNo);
			if (fd==0)
				continue;
            if (sc==1)
            {
            	if(Open485Meter(JProgramInfo->RealData.CaijiqiNo,JProgramInfo->RealData.MeterNo)>0)
            		ret=GetValue_RealTime(JProgramInfo->RealData.CaijiqiNo,JProgramInfo->RealData.MeterNo,&JProgramInfo->RealData.flg97[i].flg,&Dest[0]);
	            if(ret==1)
				{
	            	succ=1;
					memcpy(JProgramInfo->RealData.flg97[i].datas,&Dest[0],DataLenMax);
					rt=0;
				}
			}
		}
	}
	if (succ==1)
	{
		if (JParamInfo3761->group2.f9.Flag[3] & 0x40)
		{
			ret=getPoint(JProgramInfo->RealData.CaijiqiNo,JProgramInfo->RealData.MeterNo);
			if(JDataFileInfo->ptinfo[ret].AlarmFlg[30]&0x40)
			{
				ret=0;
				while(ret<100)
				{
					if(JProgramInfo->stateflags.ErcFlg==0)
						break;
					delay(50);
					ret++;
				}
				memset(&JProgramInfo->CurrErc,0,sizeof(ERC));
				ret=getPoint(JProgramInfo->RealData.CaijiqiNo,JProgramInfo->RealData.MeterNo)+1;
				JProgramInfo->CurrErc.Err31.ERCNo=31;
				JProgramInfo->CurrErc.Err31.len=21;
				JProgramInfo->CurrErc.Err31.ClNo[0]=ret&0xff;
				JProgramInfo->CurrErc.Err31.ClNo[1]=(ret>>8)&0xff;
				JProgramInfo->CurrErc.Err31.ClNo[1]&=0x7F;
				JProgramInfo->stateflags.ErcFlg=31;
				JDataFileInfo->ptinfo[ret].AlarmFlg[30]&=0b10111111;
			}
		}
	}
	else
	{
		if (JParamInfo3761->group2.f9.Flag[3] & 0x40)
		{
			ret=getPoint(JProgramInfo->RealData.CaijiqiNo,JProgramInfo->RealData.MeterNo);
			if(!(JDataFileInfo->ptinfo[ret].AlarmFlg[30]&0x40))
			{
				ret=0;
				while(ret<100)
				{
					if(JProgramInfo->stateflags.ErcFlg==0)
						break;
					delay(50);
					ret++;
				}
				memset(&JProgramInfo->CurrErc,0,sizeof(ERC));
				ret=getPoint(JProgramInfo->RealData.CaijiqiNo,JProgramInfo->RealData.MeterNo)+1;
				JProgramInfo->CurrErc.Err31.ERCNo=31;
				JProgramInfo->CurrErc.Err31.len=21;
				JProgramInfo->CurrErc.Err31.ClNo[0]=ret&0xff;
				JProgramInfo->CurrErc.Err31.ClNo[1]=(ret>>8)&0xff;
				JProgramInfo->CurrErc.Err31.ClNo[1]|=0x80;
				JProgramInfo->stateflags.ErcFlg=31;
				JDataFileInfo->ptinfo[ret].AlarmFlg[30]|=0b01000000;
			}
		}

		if (JParamInfo3761->group2.f9.Flag[2] & 0x10)
		{
			ret=getPoint(JProgramInfo->RealData.CaijiqiNo,JProgramInfo->RealData.MeterNo);
			if(!(JDataFileInfo->ptinfo[ret].AlarmFlg[20]&0x10))
			{
				ret=0;
				while(ret<100)
				{
					if(JProgramInfo->stateflags.ErcFlg==0)
						break;
					delay(50);
					ret++;
				}
				memset(&JProgramInfo->CurrErc,0,sizeof(ERC));
				ret=getPoint(JProgramInfo->RealData.CaijiqiNo,JProgramInfo->RealData.MeterNo)+1;
				JProgramInfo->CurrErc.Err21.ERCNo=21;
				JProgramInfo->CurrErc.Err21.len=6;
				JProgramInfo->stateflags.ErcFlg=21;
				JDataFileInfo->ptinfo[ret].AlarmFlg[20]|=0b00010000;
			}
		}
	}
	if(JProgramInfo->RealData.ReadFlg==3)
	{
		JProgramInfo->RealData.ReadFlg=9;
		//WatchConnectionAlarm(JProgramInfo->RealData.CaijiqiNo,JProgramInfo->RealData.MeterNo,rt);
	}
	//3�ָ��ϵ��������ü�������
}

//shanghai
//���Ϻ��Ķ����������
unsigned char ReadshanghaiFlags(unsigned char *filename, DataFlag97 *flg97)   //��ʼ��97��07��Լ��ʶ����ձ�
{
	FILE    *fp;
	char ln[100];
	char tmp[3];
	int i=0;
	unsigned char TempBuf[60];
	memset(TempBuf,0,60);
	sprintf((char *)TempBuf,"%s/%s",_CFGDIR_, filename);
	//sprintf((char *)TempBuf,"%s/AddtionalFlags.cfg",_CFGDIR_);
	sprintf(tmp,"sss");
	struct timespec tsspec;
	if (clock_gettime(CLOCK_REALTIME, &tsspec)==-1)
		printf("clock_gettime error\n\r");
	tsspec.tv_sec += 3;
	sem_timedwait(&JProgramInfo->mainData.UseFileFlg,&tsspec);
	fp = fopen((char *)TempBuf,"r");
	if(fp==NULL)
	{
	   sem_post(&JProgramInfo->mainData.UseFileFlg);
	   return 0;
	}
	for(;;)
	{
		memset(ln,0,sizeof(ln));
		fscanf(fp,"%s",ln);//��һ����fd��ִ�и�ʽ������
		if(strncmp(ln,"begin",5)==0)continue;//����������������������ȡ
		if(strncmp(ln,"end",sizeof(ln))==0)break;
		if(strncmp(ln,"//",2)==0)continue;//����ע��������������
		if(strlen(ln)<4)continue;
		tmp[0]=ln[0]; tmp[1]=ln[1];
		flg97[i].Dataflag[1]=strtol(tmp,NULL,16);
		tmp[0]=ln[2]; tmp[1]=ln[3];
		flg97[i].Dataflag[0]=strtol(tmp,NULL,16);
		flg97[i].ReadFlg=1;
		if(strlen(ln)>5)
		{
			if (ln[4]==',')
			{
				flg97[i].ReadFlg=ln[5]-'0';
			}
		}
		printf("%02x--%02x\n\r",flg97[i].Dataflag[1],flg97[i].Dataflag[0]);
	//	printString2(&flg97[i],2,2);
		i++;
		if (i>=200)
			break;
	}//end while1
	fclose(fp);
	fp=NULL;
	sem_post(&JProgramInfo->mainData.UseFileFlg);
	return i;
}
int IsDayDongJieFile(int cldno)//���ĳ���������ǰ������ն����ļ��Ƿ���� ����һ�� �����ڷ���0 ���򷵻�1
{
	INT8U TempBuf[60], retflg=0, retflg1=0, retflg2=0, retflg3=0;
	TS curts;
	TSGet(&curts);
	memset(TempBuf,0,60);
	sprintf((char*)TempBuf,"/nand/DataDay/%04d/%02d.dat", cldno, curts.Day);
	if(access((char*)TempBuf,1)==0)
		retflg1 = 1;
	TimeDecrease(&curts, 4, 1);
	sprintf((char*)TempBuf,"/nand/DataDay/%04d/%02d.dat", cldno, curts.Day);
	if(access((char*)TempBuf,1)==0)
		retflg2 = 1;
	TimeDecrease(&curts, 4, 1);
	sprintf((char*)TempBuf,"/nand/DataDay/%04d/%02d.dat", cldno, curts.Day);
	if(access((char*)TempBuf,1)==0)
		retflg3 = 1;
	if(retflg1==0 || retflg2==0 || retflg3==0)
		retflg = 0;
	return retflg;
}
//jiekou
typedef struct
{
	int cldno;
	TS ts;
	SMFiles *smfiles;
	DataFlag97 flg97;
}para;
int IsMonthDongJieFile(int cldno)//���ĳ���������ǰ�������¶����ļ��Ƿ���� ����һ�� �����ڷ���0 ���򷵻�1
{
	INT8U TempBuf[60], retflg=0, retflg1=0, retflg2=0;
	TS curts;
	TSGet(&curts);
	memset(TempBuf,0,60);
	sprintf((char*)TempBuf,"/nand/DataMonth/%04d/%02d.dat", cldno, curts.Month);
	if(access((char*)TempBuf,1)==0)
		retflg1 = 1;
	TimeDecrease(&curts, 5, 1);
	sprintf((char*)TempBuf,"/nand/DataMonth/%04d/%02d.dat", cldno, curts.Month);
	if(access((char*)TempBuf,1)==0)
		retflg2 = 1;
	if(retflg1==0 || retflg2==0)
		retflg = 0;
	return retflg;
}

int isDataFlagValued_Shanghai(DataFlag97 *flg97)//�ж�������������Ч 0 ��Ч  1 ��Ч
{
	INT8U tmpflg=0;
	int indexid=0;
	for(indexid=0; indexid<FlagsCount; indexid++)
	{
		if(JProgramInfo->Para.meterFlags.dataFlags[1][indexid].flag97.Dataflag[0]==flg97->Dataflag[0]&&
			JProgramInfo->Para.meterFlags.dataFlags[1][indexid].flag97.Dataflag[1]==flg97->Dataflag[1])
		{
			printf("\n isDataFlagValued_Shanghai flg97->Dataflag : %02x%02x\n",flg97->Dataflag[1],flg97->Dataflag[0]);
			tmpflg = 1;
			break;
		}
	}
	return tmpflg;
}

int isDataFlagValued_97(DataFlag97 *flg97)//�ж�������������Ч 0 ��Ч  1 ��Ч
{
	INT8U tmpflg=0;
	int indexid=0;
	for(indexid=0; indexid<FlagsCount; indexid++)
	{
		if(JProgramInfo->Para.meterFlags.dataFlags[0][indexid].flag97.Dataflag[1]==0x00)
			continue;
		if((JProgramInfo->Para.meterFlags.dataFlags[0][indexid].flag97.Dataflag[1]&0xf0)==0xf0)
			continue;
		if(JProgramInfo->Para.meterFlags.dataFlags[0][indexid].flag97.Dataflag[0]==flg97->Dataflag[0]&&
			JProgramInfo->Para.meterFlags.dataFlags[0][indexid].flag97.Dataflag[1]==flg97->Dataflag[1])
		{
			printf("\n isDataFlagValued_97 flg97->Dataflag : %02x%02x\n",flg97->Dataflag[1],flg97->Dataflag[0]);
			tmpflg = 1;
			break;
		}
	}
	return tmpflg;
}

//Ҫ���˵��ظ���������  һ��num��������
int RepeatDataflag_GuoLv(DataFlag97 *flg97, int num)
{
	DataFlag97 tmpflg[512];
	int i=0, j=0, indexflg=0;
	INT8U repeat_flg=0; //0 �ظ�  1 ���ظ�
	if(num>511)
		return 0;
	memset(tmpflg, 0, sizeof(DataFlag97));
	for(i=0;i<num;i++)
	{
		repeat_flg = 1;
		if(!((flg97[i].Dataflag[0]==0x00 && flg97[i].Dataflag[1]==0x00)||
			(flg97[i].Dataflag[0]==0xee && flg97[i].Dataflag[1]==0xee)||
			(flg97[i].Dataflag[0]==0xFF && flg97[i].Dataflag[1]==0xff)))
		{
			if(indexflg==0)
				repeat_flg = 1;
			for(j=0; j<indexflg; j++)
			{
				if((tmpflg[j].Dataflag[0]==flg97[i].Dataflag[0])&&
					(tmpflg[j].Dataflag[1]==flg97[i].Dataflag[1]))
					repeat_flg = 0; //�ظ�
			}
			if(repeat_flg==1)
			{
				memcpy(&tmpflg[indexflg], &flg97[i], sizeof(DataFlag97));
				indexflg++;
			}
		}
	}
	memset(&flg97[0], 0, num*sizeof(DataFlag97));
	for(i=0; i<indexflg; i++)
		memcpy(&flg97[i], &tmpflg[i], sizeof(DataFlag97));
	return indexflg;
}
//��Сʱ����
void ReadDataHour(void)//��Сʱ����
{
	int succc=0,kk=0;
	unsigned char flgCount=0,flgcnt=0;
	unsigned int i=0,midx=0,nn;
	TS ts;
	TSGet(&ts);
	DataFlag2007 flg07;
	int firflg=0,tmp=0;
	CurMeters curMeters;
	int flg_index=0;
	if((tmp=ReadHaved(ts,3))>=1)
	{
		firflg=tmp;
	}
	if(((JProgramInfo->zone)>>7&0x01)  == 1)
		firflg = 1; //�������+��½

	firflg = 1; //�������+��½
	if (firflg>=1)
	{
		SdPrint("\n\r  ReadDataHour Start   %d...............\n\r",firflg);
		if (jRead485Print>=1)
			system("date");
	}
    memset(&curMeters,0,sizeof(CurMeters));
    curMeters.MeterCount=0;
    midx=0;

    //��ʼ��������Ϣ
    memset(&JDataFileInfo->data485[firflg-1+PortBegNum].ts, 0, sizeof(TS));
    memset(&JDataFileInfo->data485[firflg-1+PortBegNum].ts_begin, 0, sizeof(TS));
    JDataFileInfo->data485[firflg-1+PortBegNum].MeterNum_CBSucc = 0;
    JDataFileInfo->data485[firflg-1+PortBegNum].ZhongDianMeterNum_CBOK = 0;
    if(firflg ==0)
    	return;
    if(JDataFileInfo->data485[0+PortBegNum].MeterNum==0 && JDataFileInfo->data485[1+PortBegNum].MeterNum==0)
    	return;
    JDataFileInfo->data485[firflg-1+PortBegNum].Flag = 2; //���ڳ���
    JDataFileInfo->data485[firflg-1+PortBegNum].ts_begin = ts;
    //shanghai?  �ص��û��ͷ��ص��û������Ķ����������--------------------->>
	unsigned char name[60];
    DataFlag97	shanghaiCommFlags[50],shanghaiManyFlags[50];//shanghai �����Ϻ��ص��û� ���ص��û����Ⳮ����������
    int shanghai_commcount=0,shanghai_manycount=0;
	if(currts_buchao.Hour>=BUCHAO_BEGIN_TIME && currts_buchao.Hour<BUCHAO_END_TIME)//һ�㵽4�㲹��
    {//�Ϻ����Ჹ��Ҫ����������
		memset(shanghaiCommFlags, 0, 50*sizeof(DataFlag97));
		memset(name, 0, 60);
		sprintf((char*)name, "%s", "AddtionalCommFlags.cfg");
		printf("\nAddtionalCommFlags.cfg\n");
		shanghai_commcount = ReadshanghaiFlags(name, shanghaiCommFlags);

		memset(shanghaiManyFlags, 0, 50*sizeof(DataFlag97));
		memset(name, 0, 60);
		sprintf((char*)name, "%s", "AddtionalManyFlags.cfg");
		printf("\n AddtionalManyFlags.cfg\n");
		shanghai_manycount = ReadshanghaiFlags(name, shanghaiManyFlags);
    }
    //--------------------------------------------------------<<

	for(i=0;((i<PointMax)&&(firflg>=0));i++)
	{
		//1�㵽4�㲹��
		TSGet(&currts_buchao);
		if(oldts_buchao.Hour!=currts_buchao.Hour)
		{
			memcpy(&oldts_buchao, &currts_buchao, sizeof(TS));
			if(currts_buchao.Hour==BUCHAO_BEGIN_TIME || currts_buchao.Hour==BUCHAO_END_TIME)
			{
				printf("\n(currts_buchao.Hour==1 || currts_buchao.Hour==4)\n");
				return;
			}
		}
		//0��4�ֿ�ʼ����
		if(currts_buchao.Hour==0 && (currts_buchao.Minute>=0 && currts_buchao.Minute<5))
		{
			printf("\n(currts_buchao.Hour==0 && (currts_buchao.Minute>=0 && currts_buchao.Minute<5))\n");
			return;
		}

		ClearWaitTimes(ProjectNo,JProgramInfo);
		if(JParamInfo3761->group2.f10[i].Status!=1)
			continue;
		if ((JParamInfo3761->group2.f10[i].ConnectType!=1) &&
			(JParamInfo3761->group2.f10[i].ConnectType!=30)&&
			(JParamInfo3761->group2.f10[i].ConnectType!=21))
			continue;
		if (JParamInfo3761->group2.f10[i].port!=(1+PortBegNum)&&
				JParamInfo3761->group2.f10[i].port!=(2+PortBegNum))
			continue;
		ClearWaitTimes(ProjectNo,JProgramInfo);

		if(JParamInfo3761->group2.f10[i].Type==0)
			continue;
		else if(JParamInfo3761->group2.f10[i].Type!=3)
		{
			curMeters.CurMeter[curMeters.MeterCount].flType=common;
			flgcnt=0;
			for(flgCount=0;flgCount<JProgramInfo->Para.meterFlags.CommDayFlagsCount;flgCount++)
			{
				GetRealTimeData();
				if ((JProgramInfo->Para.meterFlags.CommDayFlags[flgCount].ReadFlg& 0x01)==0)
					continue;
				if(JParamInfo3761->group2.f10[i].ConnectType==1)
				{
					if ((JProgramInfo->Para.meterFlags.CommDayFlags[flgCount].Dataflag[1]==0x00)||
						(JProgramInfo->Para.meterFlags.CommDayFlags[flgCount].Dataflag[1]==0xEE)||
						(JProgramInfo->Para.meterFlags.CommDayFlags[flgCount].Dataflag[1]==0xFF))
						continue;
					if((JProgramInfo->Para.meterFlags.CommDayFlags[flgCount].Dataflag[1]&0xf0)==0xF0)//shanghai
						continue;
				}
				if(JParamInfo3761->group2.f10[i].ConnectType==30)
				{
					if(GetDataFlag07By97( &JProgramInfo->Para.meterFlags.CommDayFlags[flgCount],&flg07)==1)
					{
						if ((flg07.Dataflag[0]==0xff)&&(flg07.Dataflag[1]==0xff)&&(flg07.Dataflag[2]==0xff)&&(flg07.Dataflag[3]==0xff))
							continue;
					}else
						continue;
				}
				//shanghai-------------------------------------->>
				if(JParamInfo3761->group2.f10[i].ConnectType==21)
				{
//					if(JProgramInfo->Para.meterFlags.CommDayFlags[flgCount].Dataflag[0]==0x11 &&
//						JProgramInfo->Para.meterFlags.CommDayFlags[flgCount].Dataflag[1]==0xc0)
//						continue;
//					if((JProgramInfo->Para.meterFlags.CommDayFlags[flgCount].Dataflag[1]&0xf0)==0xF0)
//						continue;
					printf("\n 111111 CommDayFlags->Dataflag : %02x%02x\n",JProgramInfo->Para.meterFlags.CommDayFlags[flgCount].Dataflag[1],
							JProgramInfo->Para.meterFlags.CommDayFlags[flgCount].Dataflag[0]);
					if(isDataFlagValued_Shanghai(&JProgramInfo->Para.meterFlags.CommDayFlags[flgCount])==0)
						continue;
				}
				//----------------------------------------------------------<<
				curMeters.CurMeter[curMeters.MeterCount].flg[flgcnt].Dataflag[0]=JProgramInfo->Para.meterFlags.CommDayFlags[flgCount].Dataflag[0];
				curMeters.CurMeter[curMeters.MeterCount].flg[flgcnt].Dataflag[1]=JProgramInfo->Para.meterFlags.CommDayFlags[flgCount].Dataflag[1];
				flgcnt++;
			}

			//shanghai---------------------------------------->>
			if(IsDayDongJieFile(i+1)==0 || IsMonthDongJieFile(i+1)==0)//�ҵ��Ƿ�������¶����ļ�
			{
				if(JParamInfo3761->group2.f10[i].ConnectType==30)
				{
					for(flg_index=0; flg_index<shanghai_commcount; flg_index++)
					{
						curMeters.CurMeter[curMeters.MeterCount].flg[flgcnt].Dataflag[0]=shanghaiCommFlags[flg_index].Dataflag[0];
						curMeters.CurMeter[curMeters.MeterCount].flg[flgcnt].Dataflag[1]=shanghaiCommFlags[flg_index].Dataflag[1];
						flgcnt++;
					}
				}else if(JParamInfo3761->group2.f10[i].ConnectType==1)
				{
					for(flg_index=0; flg_index<shanghai_commcount; flg_index++)
					{
						if(isDataFlagValued_97(&shanghaiCommFlags[flg_index])==0)
							continue;
						curMeters.CurMeter[curMeters.MeterCount].flg[flgcnt].Dataflag[0]=shanghaiCommFlags[flg_index].Dataflag[0];
						curMeters.CurMeter[curMeters.MeterCount].flg[flgcnt].Dataflag[1]=shanghaiCommFlags[flg_index].Dataflag[1];
						flgcnt++;
					}
				}else if(JParamInfo3761->group2.f10[i].ConnectType==21)
				{
					for(flg_index=0; flg_index<shanghai_commcount; flg_index++)
					{
						if(isDataFlagValued_Shanghai(&shanghaiCommFlags[flg_index])==0)
							continue;
						curMeters.CurMeter[curMeters.MeterCount].flg[flgcnt].Dataflag[0]=shanghaiCommFlags[flg_index].Dataflag[0];
						curMeters.CurMeter[curMeters.MeterCount].flg[flgcnt].Dataflag[1]=shanghaiCommFlags[flg_index].Dataflag[1];
						flgcnt++;
					}
				}
			}
			flgcnt = RepeatDataflag_GuoLv(&curMeters.CurMeter[curMeters.MeterCount].flg[0], flgcnt);
			//-------------------------------------------------<<
			curMeters.CurMeter[curMeters.MeterCount].flgCount=flgcnt;
			fprintf(stderr,"\n\n\ncldno %d flgcnt===%d-------------------485common--------5\n",i+1,flgcnt);
			for(kk=0; kk<flgcnt;kk++)
			{
				fprintf(stderr,"  [%d] %02x%02x \n",
						kk,
						curMeters.CurMeter[curMeters.MeterCount].flg[kk].Dataflag[1],
						curMeters.CurMeter[curMeters.MeterCount].flg[kk].Dataflag[0]);
			}
		}
		else
		{
			curMeters.CurMeter[curMeters.MeterCount].flType=many;
			flgcnt=0;
			for(flgCount=0;flgCount<JProgramInfo->Para.meterFlags.ManyDayFlagsCount;flgCount++)
			{
				GetRealTimeData();
				if ((JProgramInfo->Para.meterFlags.ManyDayFlags[flgCount].ReadFlg & 0x01)==0)
					continue;
				if(JParamInfo3761->group2.f10[i].ConnectType==1)
				{
					if ((JProgramInfo->Para.meterFlags.ManyDayFlags[flgCount].Dataflag[1]==0x00)||
							(JProgramInfo->Para.meterFlags.ManyDayFlags[flgCount].Dataflag[1]==0xEE)||
							(JProgramInfo->Para.meterFlags.ManyDayFlags[flgCount].Dataflag[1]==0xFF))
									continue;
					if((JProgramInfo->Para.meterFlags.CommDayFlags[flgCount].Dataflag[1]&0xf0)==0xF0)//shanghai
						continue;
				}
				if(JParamInfo3761->group2.f10[i].ConnectType==30)
				{
					if(GetDataFlag07By97( &JProgramInfo->Para.meterFlags.ManyDayFlags[flgCount],&flg07)==1)
					{
						if ((flg07.Dataflag[0]==0xff)&&(flg07.Dataflag[1]==0xff)&&(flg07.Dataflag[2]==0xff)&&(flg07.Dataflag[3]==0xff))
							continue;
					}
					else
						continue;
				}
				//shanghai-------->>
				if(JParamInfo3761->group2.f10[i].ConnectType==21)
				{
//					if(JProgramInfo->Para.meterFlags.CommDayFlags[flgCount].Dataflag[0]==0x11 &&
//						JProgramInfo->Para.meterFlags.CommDayFlags[flgCount].Dataflag[1]==0xc0)
//					continue;
//					if((JProgramInfo->Para.meterFlags.CommDayFlags[flgCount].Dataflag[1]&0xf0)==0xF0)
//						continue;
					if(isDataFlagValued_Shanghai(&JProgramInfo->Para.meterFlags.ManyDayFlags[flgCount])==0)
						continue;
				}
				//----------------<<
				curMeters.CurMeter[curMeters.MeterCount].flg[flgcnt].Dataflag[0]=JProgramInfo->Para.meterFlags.ManyDayFlags[flgCount].Dataflag[0];
				curMeters.CurMeter[curMeters.MeterCount].flg[flgcnt].Dataflag[1]=JProgramInfo->Para.meterFlags.ManyDayFlags[flgCount].Dataflag[1];
				flgcnt++;
			}
			//shanghai---------------------------------------->>
			if(IsDayDongJieFile(i+1)==0 || IsMonthDongJieFile(i+1)==0)//�ҵ��Ƿ�������¶����ļ�
			{
				if(JParamInfo3761->group2.f10[i].ConnectType==30)
				{
					for(flg_index=0; flg_index<shanghai_manycount; flg_index++)
					{
						curMeters.CurMeter[curMeters.MeterCount].flg[flgcnt].Dataflag[0]=shanghaiManyFlags[flg_index].Dataflag[0];
						curMeters.CurMeter[curMeters.MeterCount].flg[flgcnt].Dataflag[1]=shanghaiManyFlags[flg_index].Dataflag[1];
						flgcnt++;
					}
				}else if(JParamInfo3761->group2.f10[i].ConnectType==1)
				{
					for(flg_index=0; flg_index<shanghai_manycount; flg_index++)
					{
						if(isDataFlagValued_97(&shanghaiManyFlags[flg_index])==0)
							continue;
						curMeters.CurMeter[curMeters.MeterCount].flg[flgcnt].Dataflag[0]=shanghaiManyFlags[flg_index].Dataflag[0];
						curMeters.CurMeter[curMeters.MeterCount].flg[flgcnt].Dataflag[1]=shanghaiManyFlags[flg_index].Dataflag[1];
						flgcnt++;
					}
				}else if(JParamInfo3761->group2.f10[i].ConnectType==21)
				{
					for(flg_index=0; flg_index<shanghai_manycount; flg_index++)
					{
						if(isDataFlagValued_Shanghai(&shanghaiManyFlags[flg_index])==0)
							continue;
						curMeters.CurMeter[curMeters.MeterCount].flg[flgcnt].Dataflag[0]=shanghaiManyFlags[flg_index].Dataflag[0];
						curMeters.CurMeter[curMeters.MeterCount].flg[flgcnt].Dataflag[1]=shanghaiManyFlags[flg_index].Dataflag[1];
						flgcnt++;
					}
				}
			}
			flgcnt = RepeatDataflag_GuoLv(&curMeters.CurMeter[curMeters.MeterCount].flg[0], flgcnt);
			//----------------------------------------------------------------------<<
			curMeters.CurMeter[curMeters.MeterCount].flgCount=flgcnt;
			fprintf(stderr,"\n\n\ncldno %d flgcnt===%d-------------------485many--------5\n",i+1,flgcnt);
			for(kk=0; kk<flgcnt;kk++)
			{
				fprintf(stderr,"  [%d] %02x%02x \n",
						kk,
						curMeters.CurMeter[curMeters.MeterCount].flg[kk].Dataflag[1],
						curMeters.CurMeter[curMeters.MeterCount].flg[kk].Dataflag[0]);
			}
		}
		curMeters.CurMeter[curMeters.MeterCount].cjqNo=JParamInfo3761->group2.f10[i].CjqNo-1;
		curMeters.CurMeter[curMeters.MeterCount].MeterNo=JParamInfo3761->group2.f10[i].MeterNo;
		curMeters.CurMeter[curMeters.MeterCount].GyType=JParamInfo3761->group2.f10[i].ConnectType;
		memcpy(curMeters.CurMeter[curMeters.MeterCount].Addr,&JParamInfo3761->group2.f10[i].Address[0],6);
		memset(&df,0,sizeof(DataFiles));
		//df.fileType=3;
		struct timespec tsspec,tsspec2;
		clock_gettime(CLOCK_REALTIME, &tsspec);

		succc = GetMeterData(firflg,&curMeters.CurMeter[curMeters.MeterCount],&df,ts);

		clock_gettime(CLOCK_REALTIME, &tsspec2);;
		tsspec.tv_sec = (tsspec2.tv_sec - tsspec.tv_sec)*1000;
		tsspec.tv_nsec = (tsspec2.tv_nsec - tsspec.tv_nsec)/1000000;
		tsspec.tv_sec += tsspec.tv_nsec;
		fprintf(stderr,"\nReceiveFrom485 :%dms\n",(int)tsspec.tv_sec);
		curMeters.MeterCount++;
		JProgramInfo->Para.ChangedPointInfo = i+1;
		if ((firflg==0) && (JDataFileInfo->ptinfo[i].FirRead==2))
		{
			JDataFileInfo->ptinfo[i].FirRead=1;
			break;
		}
	}
	if (firflg>=1)
	{
		SdPrint("\n\r  ReadDataHour end...............succ=%d\n\r",succc);
		if (jRead485Print>=1)
			system("date");
	}
	TSGet(&ts);//������Ϣ
	JDataFileInfo->data485[firflg-1+PortBegNum].ts=ts;

	JProgramInfo->Para.ChangedJiZhongQiInfo = 2;
	if (curMeters.MeterCount==0)
	{
		return;
	}

	nn=0;
	while(1)
	{
		GetRealTimeData();
		delay(100); //�������ڱ����� �ȴ�
		nn++;
		if (nn>200)
			break;
	}
	//JProgramInfo->sm.fileType=3;
	JDataFileInfo->data485[firflg-1+PortBegNum].Flag=1;
}
