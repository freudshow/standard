#ifndef DLT645_C_
#define DLT645_C_
#include <strings.h>
#include <unistd.h>
#include "jRead485.h"
//#include <inc/BaseType.h>
#include <inc/DataGroups.h>
#include <inc/jMemory.h>
#include "inc/pubfunction.h"
extern void SendStrTo485(INT8U *str,unsigned short Len);
extern INT8U ReceiveFrom485(INT8U *str);
INT8U Dlt645Get07Vlue(INT8U DI0,INT8U DI1,INT8U *Dest);
INT8U Dlt645GetVlue(INT8U *Addr,INT8U DI0,INT8U DI1,INT8U *Dest);
extern void SetCharVaule(INT8U *Source,INT8U *Target,INT8U Begin,int Len,INT8U From);
extern void printString2(INT8U *str,INT8U Count,INT8U flg);
INT8U Dlt645Tran97(INT16U P,INT8U *Addr,INT8U DI0,INT8U DI1,INT8U *Dest);

INT8U DltTranGetVlueBy07(INT16U P,INT8U *Addr,INT8U DI0,INT8U DI1,INT8U *Dest)//����
{
	if(	Dlt645Tran97(P,Addr,DI0,DI1,Dest)==1)
	{
		return Dlt645Get07Vlue(DI0,DI1,Dest);
	}
	return 0;
}

INT8U Dlt645GetVlueBy07(INT8U *Addr,INT8U DI0,INT8U DI1,INT8U *Dest)//����
{
	if(	Dlt645GetVlue(Addr,DI0,DI1,Dest)==1)
	{
		return Dlt645Get07Vlue(DI0,DI1,Dest);
	}
	return 0;
}

INT8U Dlt645Get07Vlue(INT8U DI0,INT8U DI1,INT8U *Dest)//����
{
	INT8U  Dest97[DataLenMax];
	INT8U temp0[2];
	INT16U  temp1,j;
	TS ts;
	TSGet(&ts);
	//ABC����෢��ʱ�̣�07 ������
	//printString2(Dest,50,2);
	SetCharVaule(Dest,&Dest97[0],0,60,0);
	//memcpy(&Dest97,Dest,60);
	memset((char *)Dest,0x00,60);//��ʼ��
	//printString2(&Dest97[0],50,2);
	//������������ݱ�ʶ
	//	abc��ѹ
	if((DI0==0x11&&DI1==0xB6) ||(DI0==0x12&&DI1==0xB6) ||(DI0==0x13&&DI1==0xB6))
	{
		memcpy(&temp0[0],&Dest97[0],2);
		temp1=BCD_INT32(&temp0[0],2);
		temp1=temp1*10;
		INT32U_BCD(temp1,&temp0[0],2);
		memcpy(&Dest[0],&temp0[0],2);
		//printString2(&DI0,2,2);
		//printString2(Dest,2,2);
	}
	else if(DI0==0x1f&&DI1==0xB6)//��ѹ��
	{
	   for(j=0;j<3;j++)
	   {
		   memcpy(&temp0[0],&Dest97[2*j],2);
		   temp1=BCD_INT32(&temp0[0],2);
		   temp1=temp1*10;
		   INT32U_BCD(temp1,&temp0[0],2);
		   memcpy(&Dest[2*j],&temp0[0],2);
	   }
	   //printString2(&DI0,2,2);
	   //printString2(Dest,6,2);
	}
	//	abc����
	else if((DI0==0x21&&DI1==0xB6) ||(DI0==0x22&&DI1==0xB6) ||(DI0==0x23&&DI1==0xB6))
	{
		memcpy(&temp0,&Dest97[0],2);
		temp1=BCD_INT32(&temp0[0],2);
		temp1=temp1*10;
		INT32U_BCD(temp1,&temp0[0],3);
		memcpy(&Dest[0],&temp0[0],3);
	}
	else if(DI0==0x2f&&DI1==0xB6)//������
	{
	   for(j=0;j<3;j++)
	   {
		   memcpy(&temp0[0],&Dest97[2*j],2);
		   temp1=BCD_INT32(&temp0[0],2);
		   temp1=temp1*10;
		   INT32U_BCD(temp1,&temp0[0],3);
		   memcpy(&Dest[3*j],&temp0[0],3);
	   }
	}
	//�����й��������������ʱ��07
	else if(DI0==0x1F&&DI1==0xB0)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
		SetCharVaule(&Dest97[0],Dest,4,4,5);
		INT32U_BCD(ts.Year%100,&Dest[9],1);
		SetCharVaule(&Dest97[0],Dest,8,4,10);
		INT32U_BCD(ts.Year%100,&Dest[14],1);
		SetCharVaule(&Dest97[0],Dest,12,4,15);
		INT32U_BCD(ts.Year%100,&Dest[19],1);
		SetCharVaule(&Dest97[0],Dest,16,4,20);
		INT32U_BCD(ts.Year%100,&Dest[24],1);
	}
	else if(DI0==0x10&&DI1==0xB0)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
	}
	else if(DI0==0x11&&DI1==0xB0)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
	}
	else if(DI0==0x12&&DI1==0xB0)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
	}
	else if(DI0==0x13&&DI1==0xB0)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
	}
	else if(DI0==0x14&&DI1==0xB0)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
	}
	//�����й��������������ʱ��07
	else if(DI0==0x2F&&DI1==0xB0)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
		SetCharVaule(&Dest97[0],Dest,4,4,5);
		INT32U_BCD(ts.Year%100,&Dest[9],1);
		SetCharVaule(&Dest97[0],Dest,8,4,10);
		INT32U_BCD(ts.Year%100,&Dest[14],1);
		SetCharVaule(&Dest97[0],Dest,12,4,15);
		INT32U_BCD(ts.Year%100,&Dest[19],1);
		SetCharVaule(&Dest97[0],Dest,16,4,20);
		INT32U_BCD(ts.Year%100,&Dest[24],1);
	}
	else if(DI0==0x20&&DI1==0xB0)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
	}
	else if(DI0==0x21&&DI1==0xB0)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
	}
	else if(DI0==0x22&&DI1==0xB0)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
	}
	else if(DI0==0x23&&DI1==0xB0)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
	}
	else if(DI0==0x24&&DI1==0xB0)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
	}
	else if(DI0==0x1F&&DI1==0xB1)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
		SetCharVaule(&Dest97[0],Dest,4,4,5);
		INT32U_BCD(ts.Year%100,&Dest[9],1);
		SetCharVaule(&Dest97[0],Dest,8,4,10);
		INT32U_BCD(ts.Year%100,&Dest[14],1);
		SetCharVaule(&Dest97[0],Dest,12,4,15);
		INT32U_BCD(ts.Year%100,&Dest[19],1);
		SetCharVaule(&Dest97[0],Dest,16,4,20);
		INT32U_BCD(ts.Year%100,&Dest[24],1);
	}
	else if(DI0==0x10&&DI1==0xB1)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
	}
	else if(DI0==0x11&&DI1==0xB1)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
	}
	else if(DI0==0x12&&DI1==0xB1)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
	}
	else if(DI0==0x13&&DI1==0xB1)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
	}
	else if(DI0==0x14&&DI1==0xB1)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
	}
	else if(DI0==0x2F&&DI1==0xB1)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
		SetCharVaule(&Dest97[0],Dest,4,4,5);
		INT32U_BCD(ts.Year%100,&Dest[9],1);
		SetCharVaule(&Dest97[0],Dest,8,4,10);
		INT32U_BCD(ts.Year%100,&Dest[14],1);
		SetCharVaule(&Dest97[0],Dest,12,4,15);
		INT32U_BCD(ts.Year%100,&Dest[19],1);
		SetCharVaule(&Dest97[0],Dest,16,4,20);
		INT32U_BCD(ts.Year%100,&Dest[24],1);
	}
	else if(DI0==0x20&&DI1==0xB1)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
	}
	else if(DI0==0x21&&DI1==0xB1)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
	}
	else if(DI0==0x22&&DI1==0xB1)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
	}
	else if(DI0==0x23&&DI1==0xB1)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
	}
	else if(DI0==0x24&&DI1==0xB1)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
	}
	else if((DI0==0x20&&DI1==0xc0) ||(DI0==0x21&&DI1==0xc0) ||(DI0==0x22&&DI1==0xc0))
	{
		SetCharVaule(&Dest97[0],Dest,0,1,0);
		Dest[1]=0x00;
	}
	else if ((DI0==0x10&&DI1==0xb2) || (DI0==0x11&&DI1==0xb2))
	{
		Dest[0]=0x00;
		SetCharVaule(&Dest97[0],Dest,0,4,1);
		INT32U_BCD(ts.Year%100,&Dest[5],1);
	}else if ((DI0==0x12&&DI1==0xb2) || (DI0==0x13&&DI1==0xb2))
	{
		SetCharVaule(&Dest97[0],Dest,0,2,0);
		Dest[3]=0x00;
	}else if (DI0==0x14&&DI1==0xb2)
	{
		SetCharVaule(&Dest97[0],Dest,0,3,0);
		Dest[4]=0x00;
	}
	else if(DI0==0x1F&&DI1==0xB4)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
		SetCharVaule(&Dest97[0],Dest,4,4,5);
		INT32U_BCD(ts.Year%100,&Dest[9],1);
		SetCharVaule(&Dest97[0],Dest,8,4,10);
		INT32U_BCD(ts.Year%100,&Dest[14],1);
		SetCharVaule(&Dest97[0],Dest,12,4,15);
		INT32U_BCD(ts.Year%100,&Dest[19],1);
		SetCharVaule(&Dest97[0],Dest,16,4,20);
		INT32U_BCD(ts.Year%100,&Dest[24],1);
	}
	else if(DI0==0x10&&DI1==0xB4)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
	}
	else if(DI0==0x11&&DI1==0xB4)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
	}
	else if(DI0==0x12&&DI1==0xB4)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
	}
	else if(DI0==0x13&&DI1==0xB4)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
	}
	else if(DI0==0x14&&DI1==0xB4)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
	}
	else if(DI0==0x2F&&DI1==0xB4)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
		SetCharVaule(&Dest97[0],Dest,4,4,5);
		INT32U_BCD(ts.Year%100,&Dest[9],1);
		SetCharVaule(&Dest97[0],Dest,8,4,10);
		INT32U_BCD(ts.Year%100,&Dest[14],1);
		SetCharVaule(&Dest97[0],Dest,12,4,15);
		INT32U_BCD(ts.Year%100,&Dest[19],1);
		SetCharVaule(&Dest97[0],Dest,16,4,20);
		INT32U_BCD(ts.Year%100,&Dest[24],1);
	}
	else if(DI0==0x20&&DI1==0xB4)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
	}
	else if(DI0==0x21&&DI1==0xB4)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
	}
	else if(DI0==0x22&&DI1==0xB4)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
	}
	else if(DI0==0x23&&DI1==0xB4)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
	}
	else if(DI0==0x24&&DI1==0xB4)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
	}
	else if(DI0==0x1F&&DI1==0xB5)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
		SetCharVaule(&Dest97[0],Dest,4,4,5);
		INT32U_BCD(ts.Year%100,&Dest[9],1);
		SetCharVaule(&Dest97[0],Dest,8,4,10);
		INT32U_BCD(ts.Year%100,&Dest[14],1);
		SetCharVaule(&Dest97[0],Dest,12,4,15);
		INT32U_BCD(ts.Year%100,&Dest[19],1);
		SetCharVaule(&Dest97[0],Dest,16,4,20);
		INT32U_BCD(ts.Year%100,&Dest[24],1);
	}
	else if(DI0==0x10&&DI1==0xB5)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
	}
	else if(DI0==0x11&&DI1==0xB5)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
	}
	else if(DI0==0x12&&DI1==0xB5)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
	}
	else if(DI0==0x13&&DI1==0xB5)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
	}
	else if(DI0==0x14&&DI1==0xB5)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
	}
	else if(DI0==0x2F&&DI1==0xB5)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
		SetCharVaule(&Dest97[0],Dest,4,4,5);
		INT32U_BCD(ts.Year%100,&Dest[9],1);
		SetCharVaule(&Dest97[0],Dest,8,4,10);
		INT32U_BCD(ts.Year%100,&Dest[14],1);
		SetCharVaule(&Dest97[0],Dest,12,4,15);
		INT32U_BCD(ts.Year%100,&Dest[19],1);
		SetCharVaule(&Dest97[0],Dest,16,4,20);
		INT32U_BCD(ts.Year%100,&Dest[24],1);
	}
	else if(DI0==0x20&&DI1==0xB5)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
	}
	else if(DI0==0x21&&DI1==0xB5)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
	}
	else if(DI0==0x22&&DI1==0xB5)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
	}
	else if(DI0==0x23&&DI1==0xB5)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
	}
	else if(DI0==0x24&&DI1==0xB5)
	{
		SetCharVaule(&Dest97[0],Dest,0,4,0);
		INT32U_BCD(ts.Year%100,&Dest[4],1);
	}
	else if ((DI0==0x10&&DI1==0xb3) || (DI0==0x11&&DI1==0xb3) || (DI0==0x12&&DI1==0xb3) || (DI0==0x13&&DI1==0xb3))
	{
		SetCharVaule(&Dest97[0],Dest,0,2,0);
		Dest[2]=0x00;
	}else if ((DI0==0x30&&DI1==0xb3) || (DI0==0x31&&DI1==0xb3) || (DI0==0x32&&DI1==0xb3) || (DI0==0x33&&DI1==0xb3))
	{
		Dest[0]=0x00;
		SetCharVaule(&Dest97[0],Dest,0,4,1);
		INT32U_BCD(ts.Year%100,&Dest[5],1);
	}else if ((DI0==0x40&&DI1==0xb3) || (DI0==0x41&&DI1==0xb3) || (DI0==0x42&&DI1==0xb3) || (DI0==0x43&&DI1==0xb3))
	{
		Dest[0]=0x00;
		SetCharVaule(&Dest97[0],Dest,0,4,1);
		INT32U_BCD(ts.Year%100,&Dest[5],1);
	}else if ((DI0==0x40&&DI1==0xb6) || (DI0==0x41&&DI1==0xb6) || (DI0==0x42&&DI1==0xb6) || (DI0==0x43&&DI1==0xb6))
	{
		Dest[0]=0x00;
		SetCharVaule(&Dest97[0],&Dest[1],0,2,0);
	}
	else if (DI0==0x1f&&DI1==0xb3)
	{
		SetCharVaule(&Dest97[0],&Dest[0],0,2,0);
		Dest[2]=0x00;
		SetCharVaule(&Dest97[2],&Dest[3],0,2,0);
		Dest[5]=0x00;
		SetCharVaule(&Dest97[4],&Dest[6],0,2,0);
		Dest[8]=0x00;
		SetCharVaule(&Dest97[6],&Dest[9],0,2,0);
		Dest[11]=0x00;
	}
	else if (DI0==0x3f&&DI1==0xb3)
	{
		Dest[0]=0x00;
		SetCharVaule(&Dest97[0],Dest,0,4,1);
		INT32U_BCD(ts.Year%100,&Dest[5],1);

		Dest[6]=0x00;
		SetCharVaule(&Dest97[4],Dest,0,4,1);
		INT32U_BCD(ts.Year%100,&Dest[11],1);

		Dest[12]=0x00;
		SetCharVaule(&Dest97[8],Dest,0,4,1);
		INT32U_BCD(ts.Year%100,&Dest[17],1);

		Dest[18]=0x00;
		SetCharVaule(&Dest97[12],Dest,0,4,1);
		INT32U_BCD(ts.Year%100,&Dest[23],1);
	}
	else if (DI0==0x4f&&DI1==0xb3)
	{
		Dest[0]=0x00;
		SetCharVaule(&Dest97[0],Dest,0,4,1);
		INT32U_BCD(ts.Year%100,&Dest[5],1);

		Dest[6]=0x00;
		SetCharVaule(&Dest97[4],Dest,0,4,1);
		INT32U_BCD(ts.Year%100,&Dest[11],1);

		Dest[12]=0x00;
		SetCharVaule(&Dest97[8],Dest,0,4,1);
		INT32U_BCD(ts.Year%100,&Dest[17],1);

		Dest[18]=0x00;
		SetCharVaule(&Dest97[12],Dest,0,4,1);
		INT32U_BCD(ts.Year%100,&Dest[23],1);
	}
	else if  (DI0==0x4f&&DI1==0xb6)
	{
		Dest[0]=0x00;
		SetCharVaule(&Dest97[0],&Dest[1],0,2,0);
		Dest[3]=0x00;
		SetCharVaule(&Dest97[2],&Dest[4],0,2,0);
		Dest[6]=0x00;
		SetCharVaule(&Dest97[4],&Dest[7],0,2,0);
		Dest[9]=0x00;
		SetCharVaule(&Dest97[6],&Dest[10],0,2,0);
	}
	else
	{
		SetCharVaule(&Dest97[0],Dest,0,60,0);
	}
	return 1;
}

INT8U Dlt645Tran97(INT16U P,INT8U *Addr,INT8U DI0,INT8U DI1,INT8U *Dest)
{
	INT8U  Rec645Buff[1024],RecBuf[1024];
	INT8U  Trn645Buff[1024],TempBuf[1024];
	INT8U  DataLen;
	INT8U i,j,Check=0,len,flg,res;
	INT16U tmp;
	TS ts;
	len=0;
	Check=0;
	DI0=DI0+0x33;
	DI1=DI1+0x33;
	memset(Rec645Buff,0,1024);
	memset(RecBuf,0,1024);
	memset(Trn645Buff,0,1024);
	memset(TempBuf,0,1024);
	///CleardeadCount();
	//��֯���ͱ���
	Trn645Buff[len++]=0x68;
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x68;
	Trn645Buff[len++]=0x4a;
	for(i=0;i<4;i++)
	{
		Trn645Buff[len++]=Addr[i];//�ɼ�����ַ
	}
	Trn645Buff[len++]=0x00;//��վ��ַ
	Trn645Buff[len++]=0x10;

	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x00;
	Trn645Buff[len++]=0x01;
	Trn645Buff[len++]=0x00;

	Trn645Buff[len++]=JParamInfo3761->group2.f10[P].port;
	Trn645Buff[len]=0x00;
	switch(JParamInfo3761->group2.f10[P].jiao_yan_wei)
	{
		case 0:
			Trn645Buff[len]|=0x00;
			break;
		case 1:
			Trn645Buff[len]|=0x08;
			break;
		case 2:
			Trn645Buff[len]|=0x0C;
			break;
		default:
			Trn645Buff[len]|=0x08;
			break;
	}
	switch(JParamInfo3761->group2.f10[P].ting_zhi_wei)
	{
		case 2:
			Trn645Buff[len]|=0x10;
			break;
		default:
			Trn645Buff[len]|=0x00;
			break;
	}
	switch(JParamInfo3761->group2.f10[P].shu_ju_wei)
	{
		case 5:
			Trn645Buff[len]|=0x00;
			break;
		case 6:
			Trn645Buff[len]|=0x01;
			break;
		case 7:
			Trn645Buff[len]|=0x02;
			break;
		default:
			Trn645Buff[len]|=0x03;
			break;
	}
	switch(JParamInfo3761->group2.f10[P].baudrate)
	{
		case 1:
			Trn645Buff[len]|=0x00;
			break;
		case 2:
			Trn645Buff[len]|=0x20;
			break;
		case 4:
			Trn645Buff[len]|=0x40;
			break;
		case 8:
			Trn645Buff[len]|=0x60;
			break;
		case 16:
			Trn645Buff[len]|=0x80;
			break;
		case 24:
			Trn645Buff[len]|=0xA0;
			break;
		case 32:
			Trn645Buff[len]|=0xC0;
			break;
		case 64:
			Trn645Buff[len]|=0xE0;
			break;
		default:
			Trn645Buff[len]|=0x40;
			break;

	}
	len++;
	Trn645Buff[len++]=0x81;
	Trn645Buff[len++]=5;
	tmp=len;
	Trn645Buff[len++]=0;
	Trn645Buff[len++]=0;
	Trn645Buff[len++]=0xFE;
	Trn645Buff[len++]=0xFE;
	Trn645Buff[len++]=0xFE;
	Trn645Buff[len++]=0xFE;
	Trn645Buff[len++]=0x68;
	for(i=0;i<6;i++)
	{
		Trn645Buff[len++]=JParamInfo3761->group2.f10[P].Address[i];//����ַ
	}
	Trn645Buff[len++]=0x68;
	Trn645Buff[len++]=0x01;
	Trn645Buff[len++]=0x02;
	Trn645Buff[len++]=DI0;
	Trn645Buff[len++]=DI1;
	//SdPrint("biao=",tmp,len);
	for(i=tmp+6;i<len;i++)
	{
		Check+=Trn645Buff[i];
		//SdPrint("%02x ",Trn645Buff[i]);
	}
	//SdPrint("\n\r");
	Trn645Buff[len++]=(INT8U)(Check&0xff);
	Trn645Buff[len++]=0x16;

	Trn645Buff[tmp]=(len-tmp-2)&0xff;//ת�����ĵĳ���
	Trn645Buff[tmp+1]=((len-tmp-2)>>8)&0xff;
	for(i=0;i<16;i++)
		Trn645Buff[len++]=0x00;
	TSGet(&ts);
	Trn645Buff[len++]=JProgramInfo->PFC;
	INT32U_BCD(ts.Sec,&Trn645Buff[len++],1);
	INT32U_BCD(ts.Minute,&Trn645Buff[len++],1);
	INT32U_BCD(ts.Hour,&Trn645Buff[len++],1);
	INT32U_BCD(ts.Day,&Trn645Buff[len++],1);
	Trn645Buff[len++]=0;
	tmp = len - 6;
	tmp = (tmp << 2) | 1;
	Trn645Buff[1] = tmp & 0xff;
	Trn645Buff[2] = (tmp >> 8) & 0xff;
	Trn645Buff[3] = tmp & 0xff;
	Trn645Buff[4] = (tmp >> 8) & 0xff;
	Check=0;
	//SdPrint("pack=");
	for(i=6;i<len;i++)
	{
		//SdPrint("%02x ",Trn645Buff[i]);
		Check+=Trn645Buff[i];
	}
	//SdPrint("\n\r");
	Trn645Buff[len++]=(INT8U)(Check&0xff);
	Trn645Buff[len++]=0x16;

	SdPrint("Send pack = ");
	for(i=0;i<len;i++)
		SdPrint("%02x ",Trn645Buff[i]);
	SdPrint("\n\r");

	SendStrTo485(Trn645Buff,len);

	i=0;
//	delay(300);
//	while(i<10)
//	{
		len=ReceiveFrom485(Rec645Buff);
//		if (len>8)
//		{
//			SdPrint("delay i=%d\n\r",i);
//			break;
//		}
//		delay(200);
//		i++;
//	}


	SdPrint("rec pack%d = ",len);
	for(i=0;i<len;i++)
		SdPrint("%x ",Rec645Buff[i]);
	SdPrint("\n\r");

	tmp=0;
	flg=0;
	res=0;
	for(i=0;i<len;i++)
	{
		if((Rec645Buff[i]==0x68)&&(Rec645Buff[i+5]==0x68))
		{
			if (len>14)
			{
			   tmp=Rec645Buff[i+2];
			   tmp=(tmp<<8)+Rec645Buff[i+1];
			   tmp=tmp>>2;
			   if(len>=(tmp + 8))
			   {
				   for(j=0;j<tmp+8;j++)
				   {
					   TempBuf[j]=Rec645Buff[i];
					   i = i+1;
				   }
				   Check=0;
				   for(j=0;j<tmp;j++)
					   Check+=TempBuf[j+6];
				   if(Check == TempBuf[tmp+6])
				   {
					   tmp=TempBuf[18]+(TempBuf[19]<<8);
					   res=1;
					//   SdPrint("rec biao = ");
					   for(j=0;j<tmp;j++)
					   {
						   RecBuf[flg++]=TempBuf[j+20];
					//	   SdPrint("%02x ",TempBuf[j+20]);
					   }
					 //  SdPrint("\n\r");
				   }
			   }
			}
		}
	}
	if (res==0)
	{
		return 0;
	}

	if (flg>0)
	{
		for(i=0;i<tmp;i++)//i������ʼλ��
		{
			if(RecBuf[i]==0x68) break;
		}
		if(tmp<(i+8))return 0; 	//У���ܳ���
		//if(RecBuf[i+8]!=0x81)return 0; //�ӵ�һ��68����8λ��81��
		if((RecBuf[i+8]&0x40) == 0x40)//�쳣֡
		{
			SdPrint("\n ReceiveFrom485 Dlt645Tran97 error frame = %x ............\n\r",RecBuf[i+8]);
			return 0;
		}
		DataLen=RecBuf[i+9];//��ȡ�������ݿ鳤��
		if(DataLen>50) return 0;
		if(tmp<(i+DataLen+12)){return 0;}//����У���ܵĳ���
		Check=0x00;
		for(j=0;j<(DataLen+10);j++)//�������λ
		{
			Check=Check+RecBuf[i+j];
		}
		if(Check!=RecBuf[i+DataLen+10]) {return 0;}//����λ�Ƿ���ȷ
		if((RecBuf[i+10]!=DI0)||(RecBuf[i+11]!=DI1))  {return 0;}//��ʾ���Ƿ���ȷ

		memset(Dest,0x00,60);
		for(j=0;j<DataLen-2;j++)//���ݼ�ȥ33
		{
			RecBuf[i+12+j]=RecBuf[i+12+j]-0x33;
			Dest[j]=RecBuf[i+12+j];//��������ֵ��bcd�룩
			SdPrint("%x ",Dest[j]);	//����
			if (j>49)
				break;
		}
		SdPrint("\n\r");
	}
	else
	{
		return 0;
	}


	return 1;
}
//���ɱ��ģ�����
INT8U Dlt645GetVlue(INT8U *Addr,INT8U DI0,INT8U DI1,INT8U *Dest)
{

	//<summary>
	//����
	//</summary>
	//<param name="DI1">У����</param>
	//<param name="DI0">У����</param>
	//<param name="*Dest">�����������</param
	//<returns> 0������������1��������</returns>
	//SdPrint("\n\r starting Dlt645GetVlue bbbbbbbbbbbbb\n\r");
	INT8U  Rec645Buff[1024];     /* 645��Լ���ձ��Ļ�����     */
	INT8U  Trn645Buff[1024];     /* 645��Լ���ͱ��Ļ�����     */
	INT8U  DataLen;
	INT8U i,j,Check=0;

	INT8U len=0;
	Check=0;
	memset(Rec645Buff,0,1024);
	memset(Trn645Buff,0,1024);
	///CleardeadCount();
	//��֯���ͱ���
	Trn645Buff[len++]=0xFE;
	Trn645Buff[len++]=0xFE;
	Trn645Buff[len++]=0xFE;
	Trn645Buff[len++]=0xFE;
	Trn645Buff[len++]=0x68;
	for(i=0;i<6;i++)
	{
		Trn645Buff[len++]=Addr[i];//����ַ
	}
	Trn645Buff[len++]=0x68;
	Trn645Buff[len++]=0x01;
	Trn645Buff[len++]=0x02;
	Trn645Buff[len++]=0x33+DI0;
	Trn645Buff[len++]=0x33+DI1;
	for(i=4;i<16;i++)
		Check+=Trn645Buff[i];
	Trn645Buff[len++]=(INT8U)(Check&0xff);
	Trn645Buff[len++]=0x16;
	//-----------����--------------------------
	SdPrint("\n RS4851 send DataNum = %d .............\n\r",len);
	for(i=0;i<len;i++) SdPrint("%02x ",Trn645Buff[i]);	//����
	//-------------------------------------
	SendStrTo485(Trn645Buff,len);

	//���ͱ���
	//����
	len=ReceiveFrom485(Rec645Buff);

	SdPrint("\n ReceiveFrom485 DataNum = %d .......................\n\r",len);
	for(i=0;i<len;i++)	{SdPrint("%02x ",Rec645Buff[i]);	}//����
	SdPrint("\n\r");
	SdPrint("\n\r");
	for(i=0;i<len;i++)//i������ʼλ��
	{
		if(Rec645Buff[i]==0x68) break;
	}
	if(len<(i+8))
	{
		fprintf(stderr,"\n !!!!!!ReceiveFrom485 len=%d <i+8  i=%d!!!",len,i);
		return 0; 	//У���ܳ���
	}
	//if(Rec645Buff[i+8]!=0x81)return 0; //�ӵ�һ��68����8λ��81��
	if((Rec645Buff[i+8]&0x40) == 0x40)//�쳣֡
	{
		fprintf(stderr,"\n !!!!!!ReceiveFrom485 error frame = %x ............\n\r",Rec645Buff[i+8]);
		return 0;
	}
	DataLen=Rec645Buff[i+9];//��ȡ�������ݿ鳤��
	SdPrint("\n ReceiveFrom485 DataLen = %d .......................\n\r",DataLen);
	if(DataLen>50)
	{
		fprintf(stderr,"\n !!!!!!ReceiveFrom485 DataLen=%d >50!!!",DataLen);
		return 0;
	}
	if(len<(i+DataLen+12))
	{
		fprintf(stderr,"\n !!!!!!ReceiveFrom485 DataLen=%d   len =%d ���� !!!",DataLen,len);
		return 0;
	}//����У���ܵĳ���
	Check=0x00;
	for(j=0;j<(DataLen+10);j++)//�������λ
	{
		Check=Check+Rec645Buff[i+j];
	}
	if(Check!=Rec645Buff[i+DataLen+10])
	{
		fprintf(stderr,"\n!!!!!!ReceiveFrom485 check err %02x",Check);
		return 0;
	}//����λ�Ƿ���ȷ
	if((Rec645Buff[i+10]!=(DI0+0x33))||(Rec645Buff[i+11]!=(DI1+0x33)))
	{
		fprintf(stderr,"\n!!!!!!ReceiveFrom485��ʶ�룿����");
		return 0;
	}//��ʾ���Ƿ���ȷ

	memset(Dest,0x00,DataLenMax);
	for(j=0;j<DataLen-2;j++)//���ݼ�ȥ33
	{
		JProgramInfo->dataTransgw.f9.len++;
		Rec645Buff[i+12+j]=Rec645Buff[i+12+j]-0x33;
		Dest[j]=Rec645Buff[i+12+j];//��������ֵ��bcd�룩
		if (j>49)
			break;
	}
	SdPrint("Dlt645GetVlue end\n\r");
	//-----------����--------------------------

	//��������ֵ��bcd�룩
	//strcpy(Dest,&Rec645Buff[i+12],DataLen-2);

	return 1;
}
#endif /*DLT645_C_*/
