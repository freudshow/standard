#ifndef DLT645_2007_C_
#define DLT645_2007_C_
#include <strings.h>
#include <../jBase/inc/DataGroups.h>//yizhi
#include <inc/jMemory.h>
#include "inc/pubfunction.h"
#include "jRead485.h"
#include "ReadMeter.h"

extern void SendStrTo485(unsigned char *str,unsigned short Len);
extern unsigned char ReceiveFrom485(unsigned char *str);
unsigned char ReceErrFlag;
//��ʼ�����ݱ�ʶ�Ϻ���97��Ӧ��ϵ
unsigned char InitParaDataFlags_ShangHai_97(DataFlags *flg)   //��ʼ��97���Ϻ���Լ��ʶ����ձ�
{
	FILE *fp;
	char ln[50], tmp[3], TempBuf[60];
	int i=0;
	unsigned int iflg_sh=0, iflg_97=0;
	memset(TempBuf,0,60);
	sprintf((char *)TempBuf,"%s/Flags_ShangHai_97.cfg",_CFGDIR_);
	memset(tmp, 0, 3);
	fp = fopen((char *)TempBuf,"r");
	if(fp==NULL)
		return 0;
	for(;;)
	{
		memset(ln,0,50);
		fscanf(fp,"%s",ln);//��һ����fd��ִ�и�ʽ������
		if(strncmp(ln,"begin",5)==0){continue;}//����������������������ȡ
		if(strncmp(ln,"end",sizeof(ln))==0)break;
		if(strncmp(ln,"//",2)==0){continue;}//����ע��������������
		memset(flg[i].flagSH.Dataflag,0xff,1);//��ʼ��
		memset(flg[i].flag97.Dataflag,0xff,2);//��ʼ��
		sscanf(ln, "%x=%x", &iflg_sh, &iflg_97);
		memcpy(flg[i].flagSH.Dataflag, &iflg_sh, 1);
		memcpy(flg[i].flag97.Dataflag, &iflg_97, 2);
		//printf("\n ********* %s ��%x=%x%x",ln, flg[i].flagSH.Dataflag[0], flg[i].flag97.Dataflag[0],flg[i].flag97.Dataflag[1]);
		i++;
	}//end while1
	fclose(fp);
	fp=NULL;
	return i;
}
//FlagSHת��97
int GetDataFlag97BySH(DataFlagSH *flagsSH,DataFlag97 *flags97)
{
	int i;
	for(i=0;i<FlagsCount;i++)
	{
		if(flagsSH->Dataflag[0]==JProgramInfo->Para.meterFlags.dataFlags[1][i].flagSH.Dataflag[0])
		{
			memcpy(flags97->Dataflag,JProgramInfo->Para.meterFlags.dataFlags[1][i].flag97.Dataflag,2);
			if(flags97->Dataflag[0]==0xff && flags97->Dataflag[1]==0xff)
				return 0;
			return 1;
		}
	}
	return 0;
}

//Flag97ת��SH
int GetDataFlagSHBy97(DataFlag97 *flags97,DataFlagSH *flagsSH)
{
	int i;
	for(i=0;i<FlagsCount;i++)
	{
		if(flags97->Dataflag[0]==JProgramInfo->Para.meterFlags.dataFlags[1][i].flag97.Dataflag[0] &&
			flags97->Dataflag[1]==JProgramInfo->Para.meterFlags.dataFlags[1][i].flag97.Dataflag[1])
		{
			memcpy(flagsSH->Dataflag,JProgramInfo->Para.meterFlags.dataFlags[1][i].flagSH.Dataflag,1);
			if(flagsSH->Dataflag[0]==0xff)
				return 0;
			return 1;
		}
	}
	return 0;
}

unsigned char Dlt645TranSH(INT16U P, unsigned char *Addr, unsigned char CrlCode, unsigned char *Dest)
{
	return 0;
}
//9.23
unsigned char Dlt645_SHGetVlue(unsigned char *Addr,unsigned char CtlCode,unsigned char *Dest)
{

	unsigned char  Rec645Buff[1024];     /* 645��Լ���ձ��Ļ�����     */
	unsigned char  Trn645Buff[1024];     /* 645��Լ���ͱ��Ļ�����     */
	unsigned char  GetLen;
	//����
	unsigned char Check=0;
	int i,j=0,len=0;
	memset(Rec645Buff,0,1024);
	memset(Trn645Buff,0,1024);

	len=0;
	Check=0;

	///CleardeadCount();
	//��֯���ͱ���
	Trn645Buff[len++]=0xFE;
	Trn645Buff[len++]=0x68;
	for(i=0;i<5;i++)
	{
		Trn645Buff[len++]=Addr[i];
	}
	Trn645Buff[len++]=0xff;
	Trn645Buff[len++]=0x68;
	Trn645Buff[len++]= CtlCode|0x80;
	Trn645Buff[len++]=0x00;
	for(i=1;i<11;i++)
		Check+=Trn645Buff[i];
	Trn645Buff[len++]=(unsigned char)(Check&0xff);
	Trn645Buff[len++]=0x16;
	//-----------����--------------------------
		SdPrint("\n Dlt645_SHGetVlue send DataNum = %d\n\r",len);
		for(i=0;i<len;i++)
			SdPrint("%02x ",Trn645Buff[i]);	//����
	//-------------------------------------
	delay(50);
	SendStrTo485(Trn645Buff,len);

	//���ͱ���
	//����
    //delay(300);
//	int find_ok = 0;
//	for(i=0;i<50;i++)
//	{
//		delay(30);
	if(ReceErrFlag) {
//		fprintf(stderr,"       Rec485 Error!!!,re_ask\n");
		delay(50);			//��½̨����ԣ��������������ʱ�ĳ�
	}

	len=ReceiveFrom485(Rec645Buff);

	SdPrint("\n Dlt645_SHGetVlue DataNum recv= %d\n\r",len);
	for(i=0;i<len;i++) SdPrint("%02x ",Rec645Buff[i]);	//����
	for(i=0;i<len;i++)
	{
		if(Rec645Buff[i]==0x68)
			break;
	}
	if(len<(i+9))return 0;
	GetLen=Rec645Buff[i+9];
	if(GetLen>230) 			return 0;
	Check=0x00;
	for(j=0;j<(GetLen+10);j++)
	{
		Check=Check+Rec645Buff[i+j];
		//SdPrint("%x ",Rec645Buff[i+j]);	//����
	}
	if(Check!=Rec645Buff[i+GetLen+10]) return 0;
	if(CtlCode != Rec645Buff[i+8]) return 0;
	for(j=0;j<GetLen;j++)
	{
		JProgramInfo->dataTransgw.f9.len++;
		Rec645Buff[i+10+j]=Rec645Buff[i+10+j]-0x33;
		Dest[j]=Rec645Buff[i+10+j];//��������ֵ��bcd�룩
		if (j>49)
			break;
	}
	return 1;
}

//����2007�����Ľ��,ת��07���������ʽ��97��Ӧ��ʽ��				9.22
unsigned char Dlt645SHGet97Vlue(DataFlag97 *flg,unsigned char *Dest)//����
{
	unsigned char  Dest07[DataLenMax];
	SetCharVaule(Dest,&Dest07[0],0,60,0);
	memset((char *)Dest,0x00,60);//��ʼ��
	if(flg->Dataflag[0]==0x1F&&flg->Dataflag[1]==0xA0)			//�����й�������
	{
		SetCharVaule(&Dest07[0],Dest,0,3,0);
		SetCharVaule(&Dest07[0],Dest,8,3,3);
		SetCharVaule(&Dest07[0],Dest,16,3,6);
		SetCharVaule(&Dest07[0],Dest,24,3,9);
		SetCharVaule(&Dest07[0],Dest,32,3,12);
	}
	else if(flg->Dataflag[0]==0x10&&flg->Dataflag[1]==0xA0)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x11&&flg->Dataflag[1]==0xA0)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x12&&flg->Dataflag[1]==0xA0)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x13&&flg->Dataflag[1]==0xA0)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x14&&flg->Dataflag[1]==0xA0)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x1F&&flg->Dataflag[1]==0xA1)		//�����޹�������
	{
		SetCharVaule(&Dest07[0],Dest,0,3,0);
		SetCharVaule(&Dest07[0],Dest,8,3,3);
		SetCharVaule(&Dest07[0],Dest,16,3,6);
		SetCharVaule(&Dest07[0],Dest,24,3,9);
		SetCharVaule(&Dest07[0],Dest,32,3,12);
	}
	else if(flg->Dataflag[0]==0x10&&flg->Dataflag[1]==0xA1)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x11&&flg->Dataflag[1]==0xA1)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x12&&flg->Dataflag[1]==0xA1)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x13&&flg->Dataflag[1]==0xA1)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x14&&flg->Dataflag[1]==0xA1)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x2F&&flg->Dataflag[1]==0xA0)		//�����й�������
	{
		SetCharVaule(&Dest07[0],Dest,0,3,0);
		SetCharVaule(&Dest07[0],Dest,8,3,3);
		SetCharVaule(&Dest07[0],Dest,16,3,6);
		SetCharVaule(&Dest07[0],Dest,24,3,9);
		SetCharVaule(&Dest07[0],Dest,32,3,12);
	}
	else if(flg->Dataflag[0]==0x20&&flg->Dataflag[1]==0xA0)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x21&&flg->Dataflag[1]==0xA0)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x22&&flg->Dataflag[1]==0xA0)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x23&&flg->Dataflag[1]==0xA0)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x24&&flg->Dataflag[1]==0xA0)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x2F&&flg->Dataflag[1]==0xA1)		//�����޹�������
	{
		SetCharVaule(&Dest07[0],Dest,0,3,0);
		SetCharVaule(&Dest07[0],Dest,8,3,3);
		SetCharVaule(&Dest07[0],Dest,16,3,6);
		SetCharVaule(&Dest07[0],Dest,24,3,9);
		SetCharVaule(&Dest07[0],Dest,32,3,12);
	}
	else if(flg->Dataflag[0]==0x20&&flg->Dataflag[1]==0xA1)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x21&&flg->Dataflag[1]==0xA1)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x22&&flg->Dataflag[1]==0xA1)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x23&&flg->Dataflag[1]==0xA1)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x24&&flg->Dataflag[1]==0xA1)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x1F&&flg->Dataflag[1]==0xA4)
	{
		SetCharVaule(&Dest07[0],Dest,0,3,0);
		SetCharVaule(&Dest07[0],Dest,8,3,3);
		SetCharVaule(&Dest07[0],Dest,16,3,6);
		SetCharVaule(&Dest07[0],Dest,24,3,9);
		SetCharVaule(&Dest07[0],Dest,32,3,12);
	}
	else if(flg->Dataflag[0]==0x10&&flg->Dataflag[1]==0xA4)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x11&&flg->Dataflag[1]==0xA4)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x12&&flg->Dataflag[1]==0xA4)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x13&&flg->Dataflag[1]==0xA4)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x14&&flg->Dataflag[1]==0xA4)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x1F&&flg->Dataflag[1]==0xA5)
	{
		SetCharVaule(&Dest07[0],Dest,0,3,0);
		SetCharVaule(&Dest07[0],Dest,8,3,3);
		SetCharVaule(&Dest07[0],Dest,16,3,6);
		SetCharVaule(&Dest07[0],Dest,24,3,9);
		SetCharVaule(&Dest07[0],Dest,32,3,12);
	}
	else if(flg->Dataflag[0]==0x10&&flg->Dataflag[1]==0xA5)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x11&&flg->Dataflag[1]==0xA5)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x12&&flg->Dataflag[1]==0xA5)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x13&&flg->Dataflag[1]==0xA5)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x14&&flg->Dataflag[1]==0xA5)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x2F&&flg->Dataflag[1]==0xA4)
	{
		SetCharVaule(&Dest07[0],Dest,0,3,0);
		SetCharVaule(&Dest07[0],Dest,8,3,3);
		SetCharVaule(&Dest07[0],Dest,16,3,6);
		SetCharVaule(&Dest07[0],Dest,24,3,9);
		SetCharVaule(&Dest07[0],Dest,32,3,12);
	}
	else if(flg->Dataflag[0]==0x20&&flg->Dataflag[1]==0xA4)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x21&&flg->Dataflag[1]==0xA4)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x22&&flg->Dataflag[1]==0xA4)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x23&&flg->Dataflag[1]==0xA4)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x24&&flg->Dataflag[1]==0xA4)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x2F&&flg->Dataflag[1]==0xA5)
	{
		SetCharVaule(&Dest07[0],Dest,0,3,0);
		SetCharVaule(&Dest07[0],Dest,8,3,3);
		SetCharVaule(&Dest07[0],Dest,16,3,6);
		SetCharVaule(&Dest07[0],Dest,24,3,9);
		SetCharVaule(&Dest07[0],Dest,32,3,12);
	}
	else if(flg->Dataflag[0]==0x20&&flg->Dataflag[1]==0xA5)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x21&&flg->Dataflag[1]==0xA5)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x22&&flg->Dataflag[1]==0xA5)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x23&&flg->Dataflag[1]==0xA5)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x24&&flg->Dataflag[1]==0xA5)SetCharVaule(&Dest07[0],Dest,0,3,0);
	else if(flg->Dataflag[0]==0x1F&&flg->Dataflag[1]==0xB0)			//�����й���������ʱ��
	{
		SetCharVaule(&Dest07[0],Dest,3,4,0);
		SetCharVaule(&Dest07[0],Dest,11,4,4);
		SetCharVaule(&Dest07[0],Dest,19,4,8);
		SetCharVaule(&Dest07[0],Dest,27,4,12);
		SetCharVaule(&Dest07[0],Dest,35,4,16);
	}else if(flg->Dataflag[0]==0x10&&flg->Dataflag[1]==0xB0)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x11&&flg->Dataflag[1]==0xB0)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x12&&flg->Dataflag[1]==0xB0)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x13&&flg->Dataflag[1]==0xB0)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x14&&flg->Dataflag[1]==0xB0)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x2F&&flg->Dataflag[1]==0xB0)			//�����й���������ʱ��
	{
		SetCharVaule(&Dest07[0],Dest,3,4,0);
		SetCharVaule(&Dest07[0],Dest,11,4,4);
		SetCharVaule(&Dest07[0],Dest,19,4,8);
		SetCharVaule(&Dest07[0],Dest,27,4,12);
		SetCharVaule(&Dest07[0],Dest,35,4,16);
	}else if(flg->Dataflag[0]==0x20&&flg->Dataflag[1]==0xB0)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x21&&flg->Dataflag[1]==0xB0)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x22&&flg->Dataflag[1]==0xB0)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x23&&flg->Dataflag[1]==0xB0)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x24&&flg->Dataflag[1]==0xB0)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x1F&&flg->Dataflag[1]==0xB1)			//�����޹���������ʱ��
	{
		SetCharVaule(&Dest07[0],Dest,3,4,0);
		SetCharVaule(&Dest07[0],Dest,11,4,4);
		SetCharVaule(&Dest07[0],Dest,19,4,8);
		SetCharVaule(&Dest07[0],Dest,27,4,12);
		SetCharVaule(&Dest07[0],Dest,35,4,16);
	}else if(flg->Dataflag[0]==0x10&&flg->Dataflag[1]==0xB1)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x11&&flg->Dataflag[1]==0xB1)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x12&&flg->Dataflag[1]==0xB1)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x13&&flg->Dataflag[1]==0xB1)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x14&&flg->Dataflag[1]==0xB1)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x2F&&flg->Dataflag[1]==0xB1)			//�����޹���������ʱ��
	{
		SetCharVaule(&Dest07[0],Dest,3,4,0);
		SetCharVaule(&Dest07[0],Dest,11,4,4);
		SetCharVaule(&Dest07[0],Dest,19,4,8);
		SetCharVaule(&Dest07[0],Dest,27,4,12);
		SetCharVaule(&Dest07[0],Dest,35,4,16);
	}else if(flg->Dataflag[0]==0x20&&flg->Dataflag[1]==0xB1)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x21&&flg->Dataflag[1]==0xB1)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x22&&flg->Dataflag[1]==0xB1)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x23&&flg->Dataflag[1]==0xB1)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x24&&flg->Dataflag[1]==0xB1)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x1F&&flg->Dataflag[1]==0xB4)
	{
		SetCharVaule(&Dest07[0],Dest,3,4,0);
		SetCharVaule(&Dest07[0],Dest,11,4,4);
		SetCharVaule(&Dest07[0],Dest,19,4,8);
		SetCharVaule(&Dest07[0],Dest,27,4,12);
		SetCharVaule(&Dest07[0],Dest,35,4,16);
	}else if(flg->Dataflag[0]==0x10&&flg->Dataflag[1]==0xB4)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x11&&flg->Dataflag[1]==0xB4)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x12&&flg->Dataflag[1]==0xB4)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x13&&flg->Dataflag[1]==0xB4)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x14&&flg->Dataflag[1]==0xB4)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x2F&&flg->Dataflag[1]==0xB4)
	{
		SetCharVaule(&Dest07[0],Dest,3,4,0);
		SetCharVaule(&Dest07[0],Dest,11,4,4);
		SetCharVaule(&Dest07[0],Dest,19,4,8);
		SetCharVaule(&Dest07[0],Dest,27,4,12);
		SetCharVaule(&Dest07[0],Dest,35,4,16);
	}else if(flg->Dataflag[0]==0x20&&flg->Dataflag[1]==0xB4)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x21&&flg->Dataflag[1]==0xB4)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x22&&flg->Dataflag[1]==0xB4)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x23&&flg->Dataflag[1]==0xB4)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x24&&flg->Dataflag[1]==0xB4)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x1F&&flg->Dataflag[1]==0xB5)
	{
		SetCharVaule(&Dest07[0],Dest,3,4,0);
		SetCharVaule(&Dest07[0],Dest,11,4,4);
		SetCharVaule(&Dest07[0],Dest,19,4,8);
		SetCharVaule(&Dest07[0],Dest,27,4,12);
		SetCharVaule(&Dest07[0],Dest,35,4,16);
	}else if(flg->Dataflag[0]==0x10&&flg->Dataflag[1]==0xB5)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x11&&flg->Dataflag[1]==0xB5)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x12&&flg->Dataflag[1]==0xB5)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x13&&flg->Dataflag[1]==0xB5)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x14&&flg->Dataflag[1]==0xB5)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x2F&&flg->Dataflag[1]==0xB5)
	{
		SetCharVaule(&Dest07[0],Dest,3,4,0);
		SetCharVaule(&Dest07[0],Dest,11,4,4);
		SetCharVaule(&Dest07[0],Dest,19,4,8);
		SetCharVaule(&Dest07[0],Dest,27,4,12);
		SetCharVaule(&Dest07[0],Dest,35,4,16);
	}else if(flg->Dataflag[0]==0x20&&flg->Dataflag[1]==0xB5)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x21&&flg->Dataflag[1]==0xB5)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x22&&flg->Dataflag[1]==0xB5)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x23&&flg->Dataflag[1]==0xB5)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else if(flg->Dataflag[0]==0x24&&flg->Dataflag[1]==0xB5)SetCharVaule(&Dest07[0],Dest,3,4,0);
	else
	{
		SetCharVaule(&Dest07[0],Dest,0,60,0);
	}
	return 1;
}

unsigned char Dlt645SHGetValueBy97(unsigned char *Addr,DataFlag97 *flg,unsigned char *Dest)//����
{
	DataFlagSH flgSH;
	unsigned char i;
	if (GetDataFlagSHBy97(flg, &flgSH) == 1)
	{
		if (flgSH.Dataflag[0] == 0xff)
			return 0;
		ReceErrFlag = 0;
		for(i=0;i<2;i++)
		{
			if(	Dlt645_SHGetVlue(Addr,flgSH.Dataflag[0],Dest)==1)
				return Dlt645SHGet97Vlue(flg,Dest);
			else
				ReceErrFlag=1;
		}
	}
	return 0;
}
unsigned char DltTranSHGetValueBy97(INT16U P,unsigned char *Addr,DataFlag97 *flg,unsigned char *Dest)//����
{
	return 0;
}
#endif /*DLT645_2007_C_*/
