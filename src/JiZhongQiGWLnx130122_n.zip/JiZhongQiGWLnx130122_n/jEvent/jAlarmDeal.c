#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <dirent.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <ctype.h>
#include <time.h>
#include <signal.h>
#include <semaphore.h>
#include <errno.h>
#include <netdb.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <math.h>
#include <inc/jMemory.h>
#include <inc/pubfunction.h>
#include "jEvent.h"

SMFiles smfileold;
SMFiles smfile;
INT8U g_ERR11_FLAG=0;
INT8U g_ERR09_FLAG=0;
extern int metn;
extern INT8U Now_Min;
extern PDD_t err30PDD[PointMax];

int GetManyData(DataFlg *data,INT8U *reslutBuf,INT8U DI1,INT8U DI0)
{
	INT8U i,isFlag=0;
	for(i=0;i<ManyFlagsCount;i++)
	{
		if(data[i].flg.Dataflag[0]==DI0 && data[i].flg.Dataflag[1]==DI1){
            memcpy(reslutBuf,&data[i].datas[0],sizeof(data[i].datas));
            isFlag=1;
            break;
		}
	}
	if(isFlag==0)
	{
		for(i=0;i<ManyFlagsCount;i++)
		{
			if(data[i].flg.Dataflag[0]==(DI0|0x0f)&&data[i].flg.Dataflag[1]==DI1){
				memcpy(reslutBuf,&data[i].datas[0],sizeof(data[i].datas));
				isFlag=1;
				break;
			}
		}
	}
	if(isFlag==0){
		memset(reslutBuf,0x00,sizeof(data[0].datas));
		return 0;
	}
	return 1;
}


//beg ���ݴ����ʼλ�� size ��С DIN ͬ�����ݸ��� BeX������ǰ��X������AfX������ǰ��X����
//DF  ���ݿ�ģʽ 1
INT8U getManysFile(char *file)
{
	memset(&smfile,0x00,sizeof(SMFiles));
	if (access(file, 0) == 0)
	{
		ReadFile(file, &smfile,sizeof(SMFiles), JProgramInfo);//��ȡ���ݵ�������
		return 1;
	}
	return 0;
}

//���ݿ�ģʽ DIN ���ݿ������ݸ���
INT8U getManysData(INT8U *Data,INT8U CJQno,INT8U MeterNo,INT8U DI1,INT8U DI0,
	INT8U beg,INT8U size,INT8U DIN,INT8U BeX,INT8U AfX,INT8U XBe,INT8U XAf,INT8U DF)
{
	INT16U j,k;
	INT8U tempManyData[DataLenMax],ret;
	memset(Data,OxXX,size*DIN);
	memset(Data,0x00,size*DIN);
	ret=0;
	if(smfile.sm.CaijiQiNo==CJQno&&smfile.sm.MeterNo==MeterNo)
	{
		if (DF==1)
		{
			memset(tempManyData, 0, sizeof(tempManyData));
			GetManyData(smfile.sm.datas, &tempManyData[0],
				DI1, DI0|0x0F);
		}
		for(j=0;j<DIN;j++)
		{
			for(k=0;k<BeX;k++)
				*(Data+j*(size+BeX+AfX)+k)=XBe;
			if (DF==0)
			{
				memset(tempManyData, 0, sizeof(tempManyData));
				GetManyData(smfile.sm.datas, &tempManyData[0],
					DI1, DI0+j);
				memcpy(Data+j*(size+BeX+AfX)+BeX, &tempManyData[0], size);
			}
			else
				memcpy(Data+j*(size+BeX+AfX)+BeX, &tempManyData[0]+j*size, size);
			for(k=0;k<AfX;k++)
				*(Data+j*(size+BeX+AfX)+k)=XAf;
		}
		ret = 1;
	}
	return ret;
}

INT8U getMeterFile(INT8U MeterType,char *file)
{
	return getManysFile(file);
}

INT8U getMetersData(INT8U MeterType,INT8U *Data,INT8U CJQno,INT8U MeterNo,INT8U DI1,INT8U DI0,
	INT8U beg,INT8U size,INT8U DIN,INT8U BeX,INT8U AfX,INT8U XBe,INT8U XAf,INT8U DF)
{
	return getManysData(Data,CJQno,MeterNo,DI1,DI0,beg,size,DIN,BeX,AfX,XBe,XAf,DF);
}

unsigned int CalcSec(unsigned int s,unsigned int d)
{
	unsigned int  temp;
	if(s>d)
	{
		temp=s-d;
	}
	else
	{
		temp=d-s;
	}
	return temp;
}

INT32U MinValue(INT32U a,INT32U b,INT32U c)
{
	INT32U t;
	t=a;
	if(t>b)t=b;
	if(t>c)t=c;
	return t;
}

INT32U MaxValue(INT32U a,INT32U b,INT32U c)
{
	INT32U t;
	t=a;
	if(t<b)t=b;
	if(t<c)t=c;
	return t;
}

void CreateErr01(TS ts)
{//���ݳ�ʼ���Ͱ汾�����¼
	if (!(JParamInfo3761->group2.f9.Flag[0] & 0x01))
		return;
	INT32U_BCD(ts.Minute,&JProgramInfo->CurrErc.Err1.Occur_Time.BCD01,1);
	INT32U_BCD(ts.Hour,&JProgramInfo->CurrErc.Err1.Occur_Time.BCD02,1);
	INT32U_BCD(ts.Day,&JProgramInfo->CurrErc.Err1.Occur_Time.BCD03,1);
	INT32U_BCD(ts.Month,&JProgramInfo->CurrErc.Err1.Occur_Time.BCD04,1);
	INT32U_BCD(ts.Year,&JProgramInfo->CurrErc.Err1.Occur_Time.BCD05,1);
	JDataFileInfo->ErcEvt.ERCBiaoZhi[0]|=0b00000001;
	JProgramInfo->CurrErc.Buff[0]=1;
	JProgramInfo->stateflags.ErcFlg=1;
	if (JParamInfo3761->group2.f9.FlagStep[0] & 0x01)
	{
		memset(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1],0,sizeof(ERC));
		memcpy(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1],&JProgramInfo->CurrErc,sizeof(ERC));
		JDataFileInfo->ErcEvt.EC1++;
		JDataFileInfo->ErcEvt.EC1=JDataFileInfo->ErcEvt.EC1%256;
	}
	else
	{
		memset(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2],0,sizeof(ERC));
		memcpy(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2],&JProgramInfo->CurrErc,sizeof(ERC));
		JDataFileInfo->ErcEvt.EC2++;
		JDataFileInfo->ErcEvt.EC2=JDataFileInfo->ErcEvt.EC2%256;
	}
//	memset(Temp_FilePath,0,60);
//	sprintf((char*)Temp_FilePath,"/nand/DataAlarm/alarm.dat");
//	SaveFile((char*)Temp_FilePath,&JDataFileInfo->ErcEvt,sizeof(ErcSave));
//	delay(50);
	JProgramInfo->CurrErc.Buff[0]=0;
	JProgramInfo->Para.ChangedJiZhongQiInfo = 2;
//	JProgramInfo->FileSaveFlag.ercflag = 1;
	SdPrint("\n\rCreateErr01\n\r")
}

void CreateErr02(TS ts)
{//������ʧ
	if (!(JParamInfo3761->group2.f9.Flag[0] & 0x02))
		return;
	JProgramInfo->CurrErc.Err2.ERCNo=2;
	JProgramInfo->CurrErc.Err2.len=6;
	JProgramInfo->CurrErc.Err2.BiaoZhi=0x02;//0x01 �ն˲�����ʧ 0x02�����������ʧ
	INT32U_BCD(ts.Minute,&JProgramInfo->CurrErc.Err2.Occur_Time.BCD01,1);
	INT32U_BCD(ts.Hour,&JProgramInfo->CurrErc.Err2.Occur_Time.BCD02,1);
	INT32U_BCD(ts.Day,&JProgramInfo->CurrErc.Err2.Occur_Time.BCD03,1);
	INT32U_BCD(ts.Month,&JProgramInfo->CurrErc.Err2.Occur_Time.BCD04,1);
	INT32U_BCD(ts.Year,&JProgramInfo->CurrErc.Err2.Occur_Time.BCD05,1);
	JDataFileInfo->ErcEvt.ERCBiaoZhi[0]|=0b00000010;
	JProgramInfo->CurrErc.Buff[0]=2;
	JProgramInfo->stateflags.ErcFlg=2;
	if (JParamInfo3761->group2.f9.FlagStep[0] & 0x02)
	{
		memset(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1],0,sizeof(ERC));
		memcpy(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1],&JProgramInfo->CurrErc,sizeof(ERC));
		JDataFileInfo->ErcEvt.EC1++;
		JDataFileInfo->ErcEvt.EC1=JDataFileInfo->ErcEvt.EC1%256;
	}
	else
	{
		memset(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2],0,sizeof(ERC));
		memcpy(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2],&JProgramInfo->CurrErc,sizeof(ERC));
		JDataFileInfo->ErcEvt.EC2++;
		JDataFileInfo->ErcEvt.EC2=JDataFileInfo->ErcEvt.EC2%256;
	}
//	memset(Temp_FilePath,0,60);
//	sprintf((char*)Temp_FilePath,"/nand/DataAlarm/alarm.dat");
//	SaveFile((char*)Temp_FilePath,&JDataFileInfo->ErcEvt,sizeof(ErcSave));
//	delay(50);
	JProgramInfo->CurrErc.Buff[0]=0;
	JProgramInfo->Para.ChangedJiZhongQiInfo = 2;
	JProgramInfo->FileSaveFlag.ercflag = 1;
	SdPrint("\n\rCreateErr02\n\r")
}

void CreateErr03(TS ts)
{//�������
	if (!(JParamInfo3761->group2.f9.Flag[0] & 0x04))
		return;
	INT32U_BCD(ts.Minute,&JProgramInfo->CurrErc.Err3.Occur_Time.BCD01,1);
	INT32U_BCD(ts.Hour,&JProgramInfo->CurrErc.Err3.Occur_Time.BCD02,1);
	INT32U_BCD(ts.Day,&JProgramInfo->CurrErc.Err3.Occur_Time.BCD03,1);
	INT32U_BCD(ts.Month,&JProgramInfo->CurrErc.Err3.Occur_Time.BCD04,1);
	INT32U_BCD(ts.Year,&JProgramInfo->CurrErc.Err3.Occur_Time.BCD05,1);
	JDataFileInfo->ErcEvt.ERCBiaoZhi[0]|=0b00000100;
	JProgramInfo->CurrErc.Buff[0]=3;
	JProgramInfo->stateflags.ErcFlg=3;
	if (JParamInfo3761->group2.f9.FlagStep[0] & 0x04)
	{
		memset(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1],0,sizeof(ERC));
		memcpy(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1],&JProgramInfo->CurrErc,sizeof(ERC));
		JDataFileInfo->ErcEvt.EC1++;
		JDataFileInfo->ErcEvt.EC1=JDataFileInfo->ErcEvt.EC1%256;
	}
	else
	{
		memset(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2],0,sizeof(ERC));
		memcpy(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2],&JProgramInfo->CurrErc,sizeof(ERC));
		JDataFileInfo->ErcEvt.EC2++;
		JDataFileInfo->ErcEvt.EC2=JDataFileInfo->ErcEvt.EC2%256;
	}
//	memset(Temp_FilePath,0,60);
//	sprintf((char*)Temp_FilePath,"/nand/DataAlarm/alarm.dat");
//	SaveFile((char*)Temp_FilePath,&JDataFileInfo->ErcEvt,sizeof(ErcSave));
//	delay(50);
	JProgramInfo->CurrErc.Buff[0]=0;
	JProgramInfo->Para.ChangedJiZhongQiInfo = 2;
	JProgramInfo->FileSaveFlag.ercflag = 1;
	SdPrint("\n\rCreateErr03\n\r");
}
INT32U GetYxStat() {
	INT32U stat=0;
	INT8U yx1,yx2,yx3;
	INT8U stmp;
	INT8U yx1_attrib,yx2_attrib;
	yx1_attrib = JParamInfo3761->group2.f12.Attr & 0x01;
	yx2_attrib = (JParamInfo3761->group2.f12.Attr & 0x02)>>1;
	yx1 = gpio_read("gpiYX1");
	yx2 = gpio_read("gpiYX2");

	if (yx1_attrib==1){//yx1�ǳ�������
		if(yx1==1)
			yx1=0;
		else
			yx1=1;
	}

	if(yx2_attrib == 1){//yx2�ǳ�������
		if(yx2==1)
			yx2=0;
		else
			yx2=1;
	}
	yx3 = gpio_read("gpiKAIGAI");
	if(yx3==1)
		yx3=0;
	else
		yx3=1;
	stat = yx1<<0 | yx2<<1 | yx3 << 2;
	stmp=stat&0xff;
	JProgramInfo->currYXSTAT = stmp;
	if ((stmp&0x01)!=(JProgramInfo->YxStat&0x01))
		printf("YXStat01-----%d\n\r",(stmp&0x01?1:0));
	if ((stmp&0x02)!=(JProgramInfo->YxStat&0x02))
		printf("YXStat02-----%d\n\r",((stmp>>1)&0x01?1:0));
	if ((stmp&0x04)!=(JProgramInfo->YxStat&0x04))
		printf("YXStat03-----%d\n\r",((stmp>>2)&0x01?1:0));
	//SdPrint("stat=%02x\n\r",stat);
	return stat;
}

void CreateErr04(TS ts)
{
	INT8U StatTmp;
	INT16U old,i;
	INT8U NStat;
	old=GetYxStat();
	NStat = old;
	StatTmp = (~NStat) & 0x07;
	if(JProgramInfo->YxStat != NStat)
	{
		JProgramInfo->YxChange=(NStat^JProgramInfo->YxStat);
		SdPrint("YXStat=%02x--%02x\n\r",JProgramInfo->YxStat,NStat);
		//����ң��
		fprintf(stderr,"\n======== F9 Flag[0]=%02x",JParamInfo3761->group2.f9.Flag[0]);
		if (JParamInfo3761->group2.f9.Flag[0] & 0x08) //4
		{
			fprintf(stderr,"\nchange!!=%02x",JProgramInfo->YxChange);
			for(i =0;i<8;i++)
			{
				if(JProgramInfo->YxChange&(1<<i))//�ж���һ��ң���б�λ
				{

					//if(JParamInfo3761->group2.f12.Flag&(1<<i))
					{
						JDataFileInfo->ErcEvt.ERCBiaoZhi[0]|=0b00001000;
						JProgramInfo->CurrErc.Buff[0]=4;
						JProgramInfo->stateflags.ErcFlg=4;
						fprintf(stderr,"\njzq.f9.FlagStep=%x",JParamInfo3761->group2.f9.FlagStep[0]);
						if (JParamInfo3761->group2.f9.FlagStep[0] & 0x08) //��Ҫ�¼�
						{
							memset(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1],0,sizeof(ERC));
							JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err4.ERCNo=4;
							JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err4.len=7;
							INT32U_BCD(ts.Minute,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err4.Occur_Time.BCD01,1);
							INT32U_BCD(ts.Hour,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err4.Occur_Time.BCD02,1);
							INT32U_BCD(ts.Day,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err4.Occur_Time.BCD03,1);
							INT32U_BCD(ts.Month,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err4.Occur_Time.BCD04,1);
							INT32U_BCD(ts.Year,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err4.Occur_Time.BCD05,1);
							JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err4.Chg_Stat=JProgramInfo->YxChange;
							JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err4.New_Stat=NStat;
							fprintf(stderr,"\n��Ҫң�ű�λ�¼�EC1=%d\n",JDataFileInfo->ErcEvt.EC1);
							fprintf(stderr,"\nʱ�䣺%02x��%02x��%02x��%02xʱ%02x��",
									JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err4.Occur_Time.BCD05,
									JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err4.Occur_Time.BCD04,
									JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err4.Occur_Time.BCD03,
									JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err4.Occur_Time.BCD02,
									JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err4.Occur_Time.BCD01);
							fprintf(stderr,"\n��λ�ֽ�=%02x  ��λ��״̬=%02x",JProgramInfo->YxChange,StatTmp);
							JDataFileInfo->ErcEvt.EC1++;
							JDataFileInfo->ErcEvt.EC1=JDataFileInfo->ErcEvt.EC1%256;
						}
						else
						{
							memset(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2],0,sizeof(ERC));
							JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err4.ERCNo=4;
							JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err4.len=7;
							INT32U_BCD(ts.Minute,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err4.Occur_Time.BCD01,1);
							INT32U_BCD(ts.Hour,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err4.Occur_Time.BCD02,1);
							INT32U_BCD(ts.Day,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err4.Occur_Time.BCD03,1);
							INT32U_BCD(ts.Month,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err4.Occur_Time.BCD04,1);
							INT32U_BCD(ts.Year,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err4.Occur_Time.BCD05,1);
							JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err4.Chg_Stat=JProgramInfo->YxChange;
							JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err4.New_Stat=NStat;//StatTmp;
							fprintf(stderr,"\nһ��ң�ű�λ�¼�:EC2=%d\n",JDataFileInfo->ErcEvt.EC2);
							fprintf(stderr,"\nʱ�䣺%02x��%02x��%02x��%02xʱ%02x��",
									JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err4.Occur_Time.BCD05,
									JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err4.Occur_Time.BCD04,
									JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err4.Occur_Time.BCD03,
									JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err4.Occur_Time.BCD02,
									JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err4.Occur_Time.BCD01);
							fprintf(stderr,"\n��λ�ֽ�=%02x  ��λ��״̬=%02x",JProgramInfo->YxChange,StatTmp);
							JDataFileInfo->ErcEvt.EC2++;
							JDataFileInfo->ErcEvt.EC2=JDataFileInfo->ErcEvt.EC2%256;
						}
//						memset(Temp_FilePath,0,60);
//						sprintf((char*)Temp_FilePath,"/nand/DataAlarm/alarm.dat");
//						SaveFile((char*)Temp_FilePath,&JDataFileInfo->ErcEvt,sizeof(ErcSave));
//						delay(50);
						JProgramInfo->CurrErc.Buff[0]=0;
						JProgramInfo->Para.ChangedJiZhongQiInfo = 2;
//						JProgramInfo->FileSaveFlag.ercflag = 1;
						SdPrint("\n\rCreateErr04\n\r")
					}
				}
			}
		}
	}
	JProgramInfo->YxStat=NStat;
}


void CreateErr8(TS ts,int met)
{
	int re;
	INT8U biaozhi = 0;
	INT8U c117_curr[2],c117_old[2],chaobiaori;//������

	INT8U c0056_curr[DataLenMax],c0056_old[DataLenMax];		//07��ʱ�β����޸Ĵ�����ʱ��
	INT8U c331_curr[3],c331_old[3];			//97����һ��ʱ�α���1ʱ����ʼʱ�估���ʺţ��������������е��ܱ�ʱ�α���¼��ж�����

	INT8U shiduan;//ʱ�α仯��־

	INT8U c030_curr[3],c030_old[3],c031_curr[3],c031_old[3],changshu;//������
	INT8U b210_curr[50],b210_old[50],biancheng;//97���ʱ��4���ֽ� MMDDHHmm        07��̼�¼ͷ6���ֽ���ʱ��

	INT8U Temp_FilePath[60],tempManyData[DataLenMax];

	chaobiaori = shiduan = changshu = biancheng = 0;

	if (JParamInfo3761->group2.f10[met].Status!=1)
		return;
	if ((JParamInfo3761->group2.f9.Flag[0] & 0x80)==0)
		return;
	memset(Temp_FilePath,0,60);
	sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/last.dat",met+1);
	re = ReadFile((char *) Temp_FilePath, &smfileold,sizeof(SMFiles),JProgramInfo);
	if (re ==1) return;
	memset(Temp_FilePath,0,60);
	sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",met+1);
//	fprintf(stderr,"##############################Alarm8 file=%s\n",Temp_FilePath);
	re = ReadFile((char *) Temp_FilePath, &smfile,sizeof(SMFiles),JProgramInfo);
	if (re ==1) return;

	//------------------------------------

	memset(tempManyData,0,DataLenMax);
	if(GetManyData(smfileold.sm.datas,&tempManyData[0],0xb2,0x10)) {
		memcpy(b210_old,&tempManyData[0],4);
	}
	memset(tempManyData,0,DataLenMax);
	if(GetManyData(smfile.sm.datas,&tempManyData[0],0xb2,0x10)){
		memcpy(b210_curr,&tempManyData[0],4);
	}else {
		fprintf(stderr,"\n find b210_curr failed!");
		memcpy(b210_curr,b210_old,4);
	}
	//------------------------------------
	memset(tempManyData,0,DataLenMax);
	if(GetManyData(smfileold.sm.datas,&tempManyData[0],0xc3,0x31)) {
//		fprintf(stderr,"\n find c331_old");
		memcpy(c331_old,&tempManyData[0],3);
	}else {
//		fprintf(stderr,"\n c331_old:%02x %02x %02x",c331_old[0],c331_old[1],c331_old[2]);
	}

	memset(tempManyData,0,DataLenMax);
	if(GetManyData(smfile.sm.datas,&tempManyData[0],0xc3,0x31)){
//		fprintf(stderr,"\n find c331_new");
		memcpy(c331_curr,&tempManyData[0],3);
	}else {
		fprintf(stderr,"\n c331_new read failed!");
		memcpy(c331_curr,c331_old,3);
	}

	//------------------
	memset(tempManyData,0,DataLenMax);
	if(GetManyData(smfileold.sm.datas,&tempManyData[0],0xc1,0x17))
		memcpy(c117_old,&tempManyData[0],2);
	memset(tempManyData,0,DataLenMax);
	if(GetManyData(smfile.sm.datas,&tempManyData[0],0xc1,0x17)){
		memcpy(c117_curr,&tempManyData[0],2);
	}else {
		fprintf(stderr,"C117 read fail!\n");
		memcpy(c117_curr,c117_old,2);
	}
	//------------------
	memset(tempManyData,0,DataLenMax);
	if(GetManyData(smfileold.sm.datas,&tempManyData[0],0xc0,0x30))
		memcpy(c030_old,&tempManyData[0],3);
	memset(tempManyData,0,DataLenMax);
	if(GetManyData(smfile.sm.datas,&tempManyData[0],0xc0,0x30)) {
		memcpy(c030_curr,&tempManyData[0],3);
	}else {
		fprintf(stderr,"C030 read fail!\n");
		memcpy(c030_curr,c030_old,3);
	}

	memset(tempManyData,0,DataLenMax);
	if(GetManyData(smfileold.sm.datas,&tempManyData[0],0xc0,0x31))
		memcpy(c031_old,&tempManyData[0],3);

	memset(tempManyData,0,DataLenMax);
	if(GetManyData(smfile.sm.datas,&tempManyData[0],0xc0,0x31)) {
		memcpy(c031_curr,&tempManyData[0],3);
	}else {
		fprintf(stderr,"c031_curr read fail!\n");
		memcpy(c031_curr,c031_old,3);
	}


	////07��ʱ�β����޸Ĵ�����ʱ��--------------------------

	memset(tempManyData,0,DataLenMax);
	if(GetManyData(smfileold.sm.datas,&tempManyData[0],0x00,0x56)){
		memcpy(c0056_old,&tempManyData[0],42);
//		fprintf(stderr,"\nAlarmDeal 0056 old value:\n");
//		int kk;
//		for(kk=0;kk<42;kk++) {
//			fprintf(stderr,"%02x ",c0056_old[kk]);
//		}
//		fprintf(stderr,"\n");
	}else {
//		fprintf(stderr,"\n not find 0056_old");
	}

	memset(tempManyData,0,DataLenMax);
	if(GetManyData(smfile.sm.datas,&tempManyData[0],0x00,0x56)) {
		memcpy(c0056_curr,&tempManyData[0],42);
//		fprintf(stderr,"\nAlarmDeal 0056 curr value:\n");
//		int kk;
//		for(kk=0;kk<42;kk++) {
//			fprintf(stderr,"%02x ",c0056_curr[kk]);
//		}
//		fprintf(stderr,"\n");
	}else {
		memcpy(c0056_curr,c0056_old,42);
		fprintf(stderr,"\n not find 0056_curr");
	}

	if (JParamInfo3761->group2.f10[met].ConnectType == 30)	//07��Լ
	{
		fprintf(stderr,"\n07��Լ��ǰʱ��:  c04010001_curr =%02x %02x %02x ",c0056_curr[0],c0056_curr[1],c0056_curr[2]);
		fprintf(stderr,"\n07��Լ�ϴ�ʱ�� :  c04010001_oldd =%02x %02x %02x\n ",c0056_old[0],c0056_old[1],c0056_old[2]);
	}
	if (JParamInfo3761->group2.f10[met].ConnectType == 1)  { //97��Լ
		printf("\n 97��Լ��ǰʱ��   ��	 	[c331]=%02x %02x %02x    ",c331_curr[0],c331_curr[1],c331_curr[2]);
		printf("\n 97��Լ�ϴ�ʱ��   �� 		[c331]=%02x %02x %02x    ",c331_old[0],c331_old[1],c331_old[2]);
	}

	fprintf(stderr,"\n ��ǰ���ʱ��:  		b210=%02x %02x %02x %02x",b210_curr[0],b210_curr[1],b210_curr[2],b210_curr[3]);
	fprintf(stderr,"\n �ϴα��ʱ��:  		b210=%02x %02x %02x %02x",b210_old[0],b210_old[1],b210_old[2],b210_old[3]);

	fprintf(stderr,"\n ��ǰ������:  		c117=%02x %02x",c117_curr[0],c117_curr[1]);
	fprintf(stderr,"\n ��һ������:  		c117=%02x %02x",c117_old[0],c117_old[1]);

	fprintf(stderr,"\n ��ǰ�������   �� 	 �й�[c030]=%02x %02x %02x    �޹�[c031]=%02x %02x %02x",c030_curr[0],c030_curr[1],c030_curr[2],c031_curr[0],c031_curr[1],c031_curr[2]);
	fprintf(stderr,"\n �ϴε������   �� 	 �й�[c030]=%02x %02x %02x    �޹�[c031]=%02x %02x %02x",c030_old[0],c030_old[1],c030_old[2],c031_old[0],c031_old[1],c031_old[2]);
	//--------------------------
	if (memcmp(b210_old,b210_curr,2)!=0)
	{//�жϳ�����
		biancheng = 1;
	}
	//--------------------------
	if (memcmp(c117_old,c117_curr,2)!=0)
	{//�жϳ�����
		chaobiaori = 1;
	}
	if (JParamInfo3761->group2.f10[met].ConnectType == 1)   //97��Լ
	{
		if ((memcmp(c331_old,c331_curr,3)==0))
		{//�ж�ʱ��
			shiduan = 0;
		}else
			shiduan = 1;
	}
	if (JParamInfo3761->group2.f10[met].ConnectType == 30)	//07��Լ
	{
		if ((memcmp(c0056_old,c0056_curr,42)==0))
		{//�ж�ʱ��
			shiduan = 0;
		}else
			shiduan = 1;
	}

	if ((memcmp(c030_old,c030_curr,3)!=0) ||(memcmp(c031_old,c031_curr,3)!=0))
	{//�������
		changshu = 1;
	}

	if ((shiduan == 0) &&(chaobiaori == 0)&&(changshu == 0)&&(biancheng == 0))
		return;
	if (biancheng ==1)
	{
		fprintf(stderr,"\n ERC8  ���ܱ�������� !!!!!���ʱ��ı�\n");
		biaozhi = biaozhi | 0x02;
	}
	if (shiduan ==1)
	{
		fprintf(stderr,"\n ERC8  ���ܱ�������� !!!!!ʱ�α��\n");
		biaozhi = biaozhi | 0x01;
	}
	if (chaobiaori == 1)
	{
		fprintf(stderr,"\n ERC8  ���ܱ�������� !!!!!�����ձ��\n");
		biaozhi = biaozhi | 0x04;
	}
	if (changshu == 1)
	{
		fprintf(stderr,"\n ERC8  ���ܱ�������� !!!!!���������\n");
		biaozhi = biaozhi | 0x08;
	}

	JProgramInfo->stateflags.ErcFlg=8;
//	printf("\n ERC8 ��־=%02x,f9.flag=%02x\n",biaozhi,JParamInfo3761->group2.f9.FlagStep[0]);
	if (JParamInfo3761->group2.f9.FlagStep[0] & 0x80) //��Ҫ�¼�		//0x08
	{
		memset(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1],0,sizeof(ERC));
		JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err8.ERCNo=8;
		JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err8.len=8;
		INT32U_BCD(ts.Minute,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err8.Occur_Time.BCD01,1);
		INT32U_BCD(ts.Hour,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err8.Occur_Time.BCD02,1);
		INT32U_BCD(ts.Day,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err8.Occur_Time.BCD03,1);
		INT32U_BCD(ts.Month,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err8.Occur_Time.BCD04,1);
		INT32U_BCD(ts.Year,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err8.Occur_Time.BCD05,1);
		JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err8.ClNo[0]=(met+1)&0xff;
		JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err8.ClNo[1]=((met+1)>>8)&0xff;
		JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err8.BiaoZhi=biaozhi;
		JParamInfo3761->group2.f10[met].AlarmFlg[7]=JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err8.BiaoZhi;
		JDataFileInfo->ErcEvt.EC1++;
		JDataFileInfo->ErcEvt.EC1=JDataFileInfo->ErcEvt.EC1%256;
//		fprintf(stderr,"Err8 EC1=%d\n",JDataFileInfo->ErcEvt.EC1);
	}
	else
	{
		memset(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2],0,sizeof(ERC));
		JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err8.ERCNo=8;
		JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err8.len=8;
		INT32U_BCD(ts.Minute,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err8.Occur_Time.BCD01,1);
		INT32U_BCD(ts.Hour,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err8.Occur_Time.BCD02,1);
		INT32U_BCD(ts.Day,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err8.Occur_Time.BCD03,1);
		INT32U_BCD(ts.Month,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err8.Occur_Time.BCD04,1);
		INT32U_BCD(ts.Year,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err8.Occur_Time.BCD05,1);
		JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err8.ClNo[0]=(met+1)&0xff;
		JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err8.ClNo[1]=((met+1)>>8)&0xff;
		JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err8.BiaoZhi=biaozhi;
		JParamInfo3761->group2.f10[met].AlarmFlg[7]=JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err8.BiaoZhi;
		JDataFileInfo->ErcEvt.EC2++;
		JDataFileInfo->ErcEvt.EC2=JDataFileInfo->ErcEvt.EC2%256;
//		fprintf(stderr,"Err8 EC2=%d\n",JDataFileInfo->ErcEvt.EC2);
	}
}


//������·�쳣����ָ���������ģ�Err9
void CreateErr09(TS ts,int met)
{
	INT8U Flag=0;
	INT16S ICalc=0;
	int PDD=0;
	ICalc=(abs(JDataFileInfo->jc.JcDdRealData.IA)+abs(JDataFileInfo->jc.JcDdRealData.IB)+abs(JDataFileInfo->jc.JcDdRealData.IC))/3;
	PDD = JDataFileInfo->jc.RES.RES_PALLZ;
	if((JDataFileInfo->jc.JcDdRealData.IA<0)||(JDataFileInfo->jc.JcDdRealData.PA<0))
	{
		Flag=0x01;
		Flag|=0xc0;//��������
	}
	if((JDataFileInfo->jc.JcDdRealData.IB<0)||(JDataFileInfo->jc.JcDdRealData.PB<0))
	{
		Flag|=0x02;
		Flag|=0xc0;//��������
	}
	if((JDataFileInfo->jc.JcDdRealData.IC<0)||(JDataFileInfo->jc.JcDdRealData.PC<0))
	{
		Flag|=0x04;
		Flag|=0xc0;//��������
	}
	if((abs(JDataFileInfo->jc.JcDdRealData.IA)<(ICalc*0.8))||(abs(JDataFileInfo->jc.JcDdRealData.IB)<(ICalc*0.8))||(abs(JDataFileInfo->jc.JcDdRealData.IC)<(ICalc*0.8)))
	{
		if(abs(JDataFileInfo->jc.JcDdRealData.IA)<(ICalc*0.8))
		{
			Flag=0x01;
			if(abs(JDataFileInfo->jc.JcDdRealData.IA)==0)
				Flag|=0x80;//������·
			else
				Flag|=0x40;//������·
		}
		if(abs(JDataFileInfo->jc.JcDdRealData.IB)<(ICalc*0.8))
		{
			Flag|=0x02;
			if(abs(JDataFileInfo->jc.JcDdRealData.IB)==0)
				Flag|=0x80;//������·
			else
				Flag|=0x40;//������·
		}
		if(abs(JDataFileInfo->jc.JcDdRealData.IC)<(ICalc*0.8))
		{
			Flag|=0x04;
			if(abs(JDataFileInfo->jc.JcDdRealData.IC)==0)
				Flag|=0x80;//������·
			else
				Flag|=0x40;//������·
		}
		if(Flag&0x80)	Flag=Flag&0x8f;
	}
	if (JParamInfo3761->group2.f9.Flag[1] & 0x01)
	{
		if(g_ERR09_FLAG!=Flag)
		{
			printf("\n ������·�쳣 ������  err09 \n");
			JDataFileInfo->ErcEvt.ERCBiaoZhi[1]&=0b11111110;
			if(Flag!=0)
				JDataFileInfo->ErcEvt.ERCBiaoZhi[1]|=0b00000001;
			JProgramInfo->CurrErc.Buff[0]=9;
			JProgramInfo->stateflags.ErcFlg=9;
			SdPrint("ErcNo=%d\n\r",9);
			printf("\n  err09: FlagStep=%02x\n, Flag=%02X, g_ERR09_Flag=%02x\n",JParamInfo3761->group2.f9.FlagStep[1],Flag,g_ERR09_FLAG);
			if (JParamInfo3761->group2.f9.FlagStep[1] & 0x01) //��Ҫ�¼�
			{
				memset(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1],0,sizeof(ERC));
				JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err9.ERCNo=9;
				JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err9.len=28;
				INT32U_BCD(ts.Minute,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err9.Occur_Time.BCD01,1);
				INT32U_BCD(ts.Hour,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err9.Occur_Time.BCD02,1);
				INT32U_BCD(ts.Day,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err9.Occur_Time.BCD03,1);
				INT32U_BCD(ts.Month,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err9.Occur_Time.BCD04,1);
				INT32U_BCD(ts.Year,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err9.Occur_Time.BCD05,1);
				if(Flag){
					JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err9.ClNo[0]=(1)&0xff;
					JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err9.ClNo[1]=((1>>8)&0xff)|0x80;
					JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err9.BiaoZhi=Flag;
				}else {
					JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err9.ClNo[0]=(1)&0xff;
					JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err9.ClNo[1]=((1>>8)&0xff);
					JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err9.BiaoZhi=g_ERR09_FLAG;

				}
				INT32U_BCD(JDataFileInfo->jc.JcDdRealData.VA, &JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err9.UA[0],2);
				INT32U_BCD(JDataFileInfo->jc.JcDdRealData.VB, &JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err9.UB[0],2);
				INT32U_BCD(JDataFileInfo->jc.JcDdRealData.VC, &JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err9.UC[0],2);
				INT32U_BCD(JDataFileInfo->jc.JcDdRealData.IA, &JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err9.IA[0],3);
				INT32U_BCD(JDataFileInfo->jc.JcDdRealData.IB, &JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err9.IB[0],3);
				INT32U_BCD(JDataFileInfo->jc.JcDdRealData.IC, &JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err9.IC[0],3);

				JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err9.PDD[0]=0;
				INT32U_BCD(PDD,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err9.PDD[1],4);
				JDataFileInfo->ErcEvt.EC1++;
				JDataFileInfo->ErcEvt.EC1=JDataFileInfo->ErcEvt.EC1%256;
				printf("\n err09:EC1=%d \n",JDataFileInfo->ErcEvt.EC1);
			}
			else
			{
				memset(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2],0,sizeof(ERC));
				JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err9.ERCNo=9;
				JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err9.len=28;
				INT32U_BCD(ts.Minute,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err9.Occur_Time.BCD01,1);
				INT32U_BCD(ts.Hour,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err9.Occur_Time.BCD02,1);
				INT32U_BCD(ts.Day,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err9.Occur_Time.BCD03,1);
				INT32U_BCD(ts.Month,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err9.Occur_Time.BCD04,1);
				INT32U_BCD(ts.Year,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err9.Occur_Time.BCD05,1);
				if(Flag){
					JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err9.ClNo[0]=(1)&0xff;
					JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err9.ClNo[1]=((1>>8)&0xff)|0x80;
					JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err9.BiaoZhi=Flag;
				}else {
					JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err9.ClNo[0]=(1)&0xff;
					JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err9.ClNo[1]=((1>>8)&0xff);
					JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err9.BiaoZhi=g_ERR09_FLAG;
				}
				INT32U_BCD(JDataFileInfo->jc.JcDdRealData.VA,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err9.UA[0],2);
				INT32U_BCD(JDataFileInfo->jc.JcDdRealData.VB,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err9.UB[0],2);
				INT32U_BCD(JDataFileInfo->jc.JcDdRealData.VC,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err9.UC[0],2);
				INT32U_BCD(JDataFileInfo->jc.JcDdRealData.IA,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err9.IA[0],3);
				INT32U_BCD(JDataFileInfo->jc.JcDdRealData.IB,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err9.IB[0],3);
				INT32U_BCD(JDataFileInfo->jc.JcDdRealData.IC,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err9.IC[0],3);
				JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err9.PDD[0]=0;
				INT32U_BCD(PDD,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err9.PDD[1],4);
				JDataFileInfo->ErcEvt.EC2++;
				JDataFileInfo->ErcEvt.EC2=JDataFileInfo->ErcEvt.EC2%256;
				printf("\n err09:EC2=%d \n",JDataFileInfo->ErcEvt.EC2);
			}

			g_ERR09_FLAG=Flag;
			JProgramInfo->stateflags.ErcFlg=0;

//			memset(Temp_FilePath,0,60);
//			sprintf((char*)Temp_FilePath,"/nand/DataAlarm/alarm.dat");
//			SaveFile((char*)Temp_FilePath,&JDataFileInfo->ErcEvt,sizeof(ErcSave));
//			delay(50);
			JProgramInfo->CurrErc.Buff[0]=0;
			JProgramInfo->Para.ChangedJiZhongQiInfo = 2;
//			JProgramInfo->FileSaveFlag.ercflag = 1;
			SdPrint("\n\rCreateErr09\n\r");

		}
	}
}

void CreateErr10(TS ts,int met)
{
	int CjqNo,MetNo,MetType,i,Ua=0,Ub=0,Uc=0,UED=0,UMX=0;
	int Ifa=1,Ifb=1,Ifc=1,Ia=0,Ib=0,Ic=0,PDD=0;
	INT8U Temp_FilePath[60], tempManyData[DataLenMax],Flag[2],happ[2],fd=0;
	if (JParamInfo3761->group2.f10[met].Status!=1)
	{
		return;
	}
//	printf("\n ===========Err10 %02x",JParamInfo3761->group2.f9.Flag[1]);
	if (JParamInfo3761->group2.f9.Flag[1] & 0x02)
	{
		CjqNo=JParamInfo3761->group2.f10[met].CjqNo-1;
		MetNo=JParamInfo3761->group2.f10[met].MeterNo;
		MetType = JParamInfo3761->group2.f10[met].Type;

//		if (JParamInfo3761->group2.f10[met].Type==0)
//		{
//			//printf("\n  JParamInfo3761->Point.pt[%d].f25.Type==0 \n",met);
//			return;
//		}
		for(i=0;i<2;i++)
		{
			Flag[i]=0;
			happ[i]=0;
		}
		memset(Temp_FilePath,0,60);
		memset(&smfile,0,sizeof(SMFiles));

		memset(Temp_FilePath,0,60);
		sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",met+1);
		printf("\nERR10 %s",Temp_FilePath);
		if (access((char*)Temp_FilePath,0)!=0)
		{
			printf("\n  /nand/DataCurr/%04d/curr.dat  �����ڣ���\n",met+1);
			return;
		}

		ReadFile((char *) Temp_FilePath, &smfile,sizeof(SMFiles),JProgramInfo);
//		if ((MetType == 9) || (MetType == 6))
//		{
//			fd=0;
//			if(smfile.sm.CaijiQiNo==CjqNo&&smfile.sm.MeterNo==MetNo)
//			{
//				fd=1;
//				memset(tempManyData,0,sizeof(tempManyData));
//				GetManyData(smfile.sm.datas,&tempManyData[0],0xb6,0x11);
//				Ua=BCD_INT32(&tempManyData[0],2);
//
//				memset(tempManyData,0,sizeof(tempManyData));
//				GetManyData(smfile.sm.datas,&tempManyData[0],0xb6,0x21);
//				if (tempManyData[2]&0x80)
//					Ifa=-1;
//				tempManyData[2]=tempManyData[2]&0x7F;
//				Ia=BCD_INT32(&tempManyData[0],3);
//
//				memset(tempManyData,0,sizeof(tempManyData));
//				GetManyData(smfile.sm.datas,&tempManyData[0],0x90,0x10);
//				PDD=BCD_INT32(&tempManyData[0],4);
//
//				SdPrint("sing10 Ua=%d,Ifa=%d,Ia=%d,PDD=%d\n\r",Ua,Ifa,Ia,PDD);
//			}
//			printf("\n 11met = %d   AlarmFlg[4]=%02x",met,JParamInfo3761->group2.f10[met].AlarmFlg[4]);
//			UED=BCD_INT32(&JParamInfo3761->Point[met].f25.E_Ding_V[0],2);
//			printf("\n11==UED = %d   Ua=%d",UED ,Ua);
//			if (!((JParamInfo3761->group2.f10[met].AlarmFlg[4]&0x80) && (JParamInfo3761->group2.f10[met].AlarmFlg[4]&0x01)))
//			{
//				if (Ua<(UED*0.8))
//				{
//					if (Ia>0)
//					{
//						printf("\n A��ʧѹ \n");
//						Flag[1]|=0x81;//ʧѹ
//						happ[1]|=1;
//						JParamInfo3761->group2.f10[met].AlarmFlg[4]|=0x81;
//					}
//				}
//			}
//			else
//			{
//				if (Ua>=(UED*0.8))
//				{
//					printf("\n A��ʧѹ  �ָ�\n");
//					Flag[1]|=0x81;
//					happ[1]|=2;
//					JParamInfo3761->group2.f10[met].AlarmFlg[4]&=0b01111110;
//					if ((JParamInfo3761->group2.f10[met].AlarmFlg[4]&0x06)==0)//û������,���쳣�����ó�0
//						JParamInfo3761->group2.f10[met].AlarmFlg[4]&=0b01111111;
//				}
//			}
//		}
//		else
		{
			fd=0;
			printf("\n ��ʼ�ж� ��ʧѹ    ����   ����---CjqNo=%d  MetNo=%d   -- smCjqNo=%d  smMetNO=%d\n",CjqNo,MetNo,smfile.sm.CaijiQiNo,smfile.sm.MeterNo);
			if(smfile.sm.CaijiQiNo==CjqNo&&smfile.sm.MeterNo==MetNo)
			{
				fd = 1;
				memset(tempManyData,0,sizeof(tempManyData));
				GetManyData(smfile.sm.datas,&tempManyData[0],0xb6,0x1f);
				Ua=BCD_INT32(&tempManyData[0],2);  //��ѹ
				Ub=BCD_INT32(&tempManyData[0]+2,2);
				Uc=BCD_INT32(&tempManyData[0]+4,2);

				memset(tempManyData,0,sizeof(tempManyData));
				GetManyData(smfile.sm.datas,&tempManyData[0],0xb6,0x2f);
				if (tempManyData[2]&0x80)
					Ifa=-1;
				tempManyData[2]=tempManyData[2]&0x7F;
				Ia=BCD_INT32(&tempManyData[0],3);  //����
				if (tempManyData[5]&0x80)
					Ifb=-1;
				tempManyData[5]=tempManyData[5]&0x7F;
				Ib=BCD_INT32(&tempManyData[0]+3,3);
				if (tempManyData[8]&0x80)
					Ifc=-1;
				tempManyData[8]=tempManyData[8]&0x7F;
				Ic=BCD_INT32(&tempManyData[0]+6,3);

				memset(tempManyData,0,sizeof(tempManyData));
				GetManyData(smfile.sm.datas,&tempManyData[0],0x90,0x1f);
				PDD=BCD_INT32(&tempManyData[0],4); //�����й�

				printf("\nʧѹ�����ࡢ���� �жϻ������ݣ�Ua=%d,Ifa=%d,Ia=%d   Ub=%d,Ifb=%d,Ib=%d   Uc=%d,Ifc=%d,Ic=%d    PDD=%d, AlarmFlg[4]=%x\n\r",
						Ua,Ifa,Ia,Ub,Ifb,Ib,Uc,Ifc,Ic,PDD,JParamInfo3761->group2.f10[met].AlarmFlg[4]);
			}

			if (fd==1)
			{
				printf("\n====met=%d Alarm[4]=%02x",met,JParamInfo3761->group2.f10[met].AlarmFlg[4]);
				UED=BCD_INT32(&JParamInfo3761->Point[met].f25.E_Ding_V[0],2);
				printf("\n UED=%d   Ua",UED);

				if (!((JParamInfo3761->group2.f10[met].AlarmFlg[4]&0x80) && (JParamInfo3761->group2.f10[met].AlarmFlg[4]&0x01)))
				{
					if (Ua<(UED*0.8))
					{
						if (Ia>0)
						{
							printf("\n A��ʧѹ \n");
							Flag[1]|=0x81;//ʧѹ
							happ[1]|=1;
							JParamInfo3761->group2.f10[met].AlarmFlg[4]|=0x81;
						}
					}
				}
				else
				{
					if (Ua>=(UED*0.8))
					{
						printf("\n A��ʧѹ  �ָ�\n");
						Flag[1]|=0x81;
						happ[1]|=2;
						JParamInfo3761->group2.f10[met].AlarmFlg[4]&=0b01111110;
						if ((JParamInfo3761->group2.f10[met].AlarmFlg[4]&0x06)==0)//û������,���쳣�����ó�0
							JParamInfo3761->group2.f10[met].AlarmFlg[4]&=0b01111111;
					}
				}
				UED=BCD_INT32(&JParamInfo3761->Point[met].f25.E_Ding_V[0],2);
				printf("\n 22UED = %d",UED);
				if (!((JParamInfo3761->group2.f10[met].AlarmFlg[4]&0x80) && (JParamInfo3761->group2.f10[met].AlarmFlg[4]&0x02)))
				{
					if (Ub<(UED*0.8))
					{
						if (Ib>0)
						{
							printf("\n B��ʧѹ \n");
							Flag[1]|=0x82;//Bʧѹ
							happ[1]|=0b00000100;
							JParamInfo3761->group2.f10[met].AlarmFlg[4]|=0x82;
						}
					}
				}
				else
				{
					if (Ub>=(UED*0.8))
					{
						printf("\n B��ʧѹ   �ָ�\n");
						Flag[1]|=0x82;//Bʧѹ�ָ�
						happ[1]|=0b00001000;
						JParamInfo3761->group2.f10[met].AlarmFlg[4]&=0b11111101;
						if ((JParamInfo3761->group2.f10[met].AlarmFlg[4]&0x05)==0)//û������,���쳣�����ó�0
							JParamInfo3761->group2.f10[met].AlarmFlg[4]&=0b01111111;
					}
				}
				UED=BCD_INT32(&JParamInfo3761->Point[met].f25.E_Ding_V[0],2);
				if (!((JParamInfo3761->group2.f10[met].AlarmFlg[4]&0x80) && (JParamInfo3761->group2.f10[met].AlarmFlg[4]&0x04)))
				{
					if (Uc<(UED*0.8))
					{
						if (Ic>0)
						{
							printf("\n C��ʧѹ \n");
							Flag[1]|=0x84;//Cʧѹ
							happ[1]|=0b00010000;
							JParamInfo3761->group2.f10[met].AlarmFlg[4]|=0x84;
						}
					}
				}
				else
				{
					if (Uc>=(UED*0.8))
					{
						printf("\n C��ʧѹ  �ָ� \n");
						Flag[1]|=0x84;//Cʧѹ�ָ�
						happ[1]|=0b00100000;
						JParamInfo3761->group2.f10[met].AlarmFlg[4]&=0b11111011;
						if ((JParamInfo3761->group2.f10[met].AlarmFlg[4]&0x03)==0)//û������,���쳣�����ó�0
							JParamInfo3761->group2.f10[met].AlarmFlg[4]&=0b01111111;
					}
				}
				UMX=BCD_INT32(&JParamInfo3761->Point[met].f26.V_Duan_Men[0],2);
				printf("\n �������� = %d",UMX);
				if (!((JParamInfo3761->group2.f10[met].AlarmFlg[9]&0x40) && (JParamInfo3761->group2.f10[met].AlarmFlg[9]&0x01)))
				{
					if (Ua<UMX)
					{
						printf("\n IA=%d",Ia);
						if (Ia==0) //�����ʱ�� �����Ƿ���0  ???????????
						{
							printf("\n A�෢������ \n");
							Flag[0]|=0x41;//A����
							happ[0]|=0b00000001;
							JParamInfo3761->group2.f10[met].AlarmFlg[9]|=0x41;
						}
					}
				}
				else
				{
					UMX=BCD_INT32(&JParamInfo3761->Point[met].f26.V_Duan_Men[0],2);
					if (Ua>=UMX)
					{
						printf("\n A�����  �ָ� \n");
						Flag[0]|=0x41;//A����ָ�
						happ[0]|=0b00000010;
						JParamInfo3761->group2.f10[met].AlarmFlg[9]&=0b11111110;
						if ((JParamInfo3761->group2.f10[met].AlarmFlg[9]&0x06)==0)//û������,���쳣�����ó�0
							JParamInfo3761->group2.f10[met].AlarmFlg[9]&=0b10111111;
					}
				}
				UMX=BCD_INT32(&JParamInfo3761->Point[met].f26.V_Duan_Men[0],2);
				if (!((JParamInfo3761->group2.f10[met].AlarmFlg[9]&0x40) && (JParamInfo3761->group2.f10[met].AlarmFlg[9]&0x02)))
				{
					if (Ub<UMX)
					{
						printf("\n Ib=%d",Ib);
						if (Ib==0)
						{
							printf("\n B�෢������ \n");
							Flag[0]|=0x42;//B����
							happ[0]|=0b00000100;
							JParamInfo3761->group2.f10[met].AlarmFlg[9]|=0x42;
						}
					}
				}
				else
				{
					if (Ub>=UMX)
					{
						printf("\n B�����   �ָ�\n");
						Flag[0]|=0x42;//B����ָ�
						happ[0]|=0b00001000;
						JParamInfo3761->group2.f10[met].AlarmFlg[9]&=0b11111101;
						if ((JParamInfo3761->group2.f10[met].AlarmFlg[9]&0x05)==0)//û������,���쳣�����ó�0
							JParamInfo3761->group2.f10[met].AlarmFlg[9]&=0b10111111;
					}
				}
				if (!((JParamInfo3761->group2.f10[met].AlarmFlg[9]&0x40) && (JParamInfo3761->group2.f10[met].AlarmFlg[9]&0x04)))
				{
					UMX=BCD_INT32(&JParamInfo3761->Point[met].f26.V_Duan_Men[0],2);
					if (Uc<UMX)
					{
						printf("\n Ic=%d",Ic);
						if (Ic==0)
						{
							printf("\n C�෢������ \n");
							Flag[0]|=0x44;//C����
							happ[0]|=0b00010000;
							JParamInfo3761->group2.f10[met].AlarmFlg[9]|=0x44;
						}
					}
				}
				else
				{
					UMX=BCD_INT32(&JParamInfo3761->Point[met].f26.V_Duan_Men[0],2);
					if (Uc>=UMX)
					{
						printf("\n C�����  �ָ� \n");
						Flag[0]|=0x44;//C����ָ�
						happ[0]|=0b00100000;
						JParamInfo3761->group2.f10[met].AlarmFlg[9]&=0b11111011;
						if ((JParamInfo3761->group2.f10[met].AlarmFlg[9]&0x03)==0)//û������,���쳣�����ó�0
							JParamInfo3761->group2.f10[met].AlarmFlg[9]&=0b10111111;
					}
				}
			}
		}
		if (fd==1)
		{
			for(i=0;i<2;i++)
			{
				if (happ[i])  //happ[0] ����  happ[1] ʧѹ
				{
					JDataFileInfo->ErcEvt.ERCBiaoZhi[1]|=0b00000010;
					if (((JParamInfo3761->group2.f10[met].AlarmFlg[9]&0b11000000)==0x00))
						JDataFileInfo->ErcEvt.ERCBiaoZhi[1]&=0b11111101;
					JProgramInfo->CurrErc.Buff[0]=10;
					JProgramInfo->stateflags.ErcFlg=10;
					SdPrint("ErcNo=%d\n\r",10);
					printf("\n��ѹ���� ���� ʧѹ���� ������ i=%d\n",i);
					if (JParamInfo3761->group2.f9.FlagStep[1] & 0x02) //��Ҫ�¼�
					{
						memset(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1],0,sizeof(ERC));
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err10.ERCNo=10;
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err10.len=28;
						INT32U_BCD(ts.Minute,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err10.Occur_Time.BCD01,1);
						INT32U_BCD(ts.Hour,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err10.Occur_Time.BCD02,1);
						INT32U_BCD(ts.Day,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err10.Occur_Time.BCD03,1);
						INT32U_BCD(ts.Month,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err10.Occur_Time.BCD04,1);
						INT32U_BCD(ts.Year,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err10.Occur_Time.BCD05,1);
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err10.ClNo[0]=(met+1)&0xff;
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err10.ClNo[1]=((met+1)>>8)&0xff;
						if (happ[i]&0b00010101)
							JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err10.ClNo[1]|=0b10000000;
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err10.BiaoZhi=Flag[i];
						INT32U_BCD(Ua,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err10.UA[0],2);
						INT32U_BCD(Ub,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err10.UB[0],2);
						INT32U_BCD(Uc,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err10.UC[0],2);
						INT32U_BCD(Ia,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err10.IA[0],3);
						if (Ifa<0)
							JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err9.IA[0]|=0x80;
						INT32U_BCD(Ib,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err10.IB[0],3);
						if (Ifb<0)
							JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err9.IB[0]|=0x80;
						INT32U_BCD(Ic,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err10.IC[0],3);
						if (Ifc<0)
							JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err9.IC[0]|=0x80;
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err10.PDD[0]=0;
						INT32U_BCD(PDD,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err10.PDD[1],4);
						JDataFileInfo->ErcEvt.EC1++;
						JDataFileInfo->ErcEvt.EC1=JDataFileInfo->ErcEvt.EC1%256;
					}
					else
					{
						memset(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2],0,sizeof(ERC));
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err10.ERCNo=10;
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err10.len=28;
						INT32U_BCD(ts.Minute,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err10.Occur_Time.BCD01,1);
						INT32U_BCD(ts.Hour,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err10.Occur_Time.BCD02,1);
						INT32U_BCD(ts.Day,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err10.Occur_Time.BCD03,1);
						INT32U_BCD(ts.Month,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err10.Occur_Time.BCD04,1);
						INT32U_BCD(ts.Year,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err10.Occur_Time.BCD05,1);
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err10.ClNo[0]=(met+1)&0xff;
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err10.ClNo[1]=((met+1)>>8)&0xff;
						if (happ[i]&0b00010101)
							JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err10.ClNo[1]|=0b10000000;
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err10.BiaoZhi=Flag[i];
						INT32U_BCD(Ua,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err10.UA[0],2);
						INT32U_BCD(Ub,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err10.UB[0],2);
						INT32U_BCD(Uc,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err10.UC[0],2);
						INT32U_BCD(Ia,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err10.IA[0],3);
						if (Ifa<0)
							JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err9.IA[0]|=0x80;
						INT32U_BCD(Ib,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err10.IB[0],3);
						if (Ifb<0)
							JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err9.IB[0]|=0x80;
						INT32U_BCD(Ic,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err10.IC[0],3);
						if (Ifc<0)
							JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err9.IC[0]|=0x80;
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err10.PDD[0]=0;
						INT32U_BCD(PDD,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err10.PDD[1],4);
						JDataFileInfo->ErcEvt.EC2++;
						JDataFileInfo->ErcEvt.EC2=JDataFileInfo->ErcEvt.EC2%256;
					}
//					memset(Temp_FilePath,0,60);
//					sprintf((char*)Temp_FilePath,"/nand/DataAlarm/alarm.dat");
//					SaveFile((char*)Temp_FilePath,&JDataFileInfo->ErcEvt,sizeof(ErcSave));
//					delay(50);
					JProgramInfo->CurrErc.Buff[0]=0;
					JProgramInfo->Para.ChangedJiZhongQiInfo = 2;
					SdPrint("\n\rCreateErr10\n\r")
//					JProgramInfo->FileSaveFlag.ercflag = 1;
				}
			}
		}
	}
}

void CreateErr11(TS ts,int met)//�����쳣 //
{
	//������״̬�� 7022E  [2c]
//JDataFileInfo->jc.JcMaxXuliang.JcStat = JDataFileInfo->jc.RES.RES_FLAG;
	INT8U err11_state;
	int PDD=0;
	if (JParamInfo3761->group2.f9.Flag[1] & 0x04)
	{
		//printf("\n ERR11  ��%s PDD %d\n", err11_state ? "�����쳣":"����ָ�", PDD);
		PDD = JDataFileInfo->jc.RES.RES_PALLZ;
		err11_state = (JDataFileInfo->jc.JcMaxXuliang.JcStat >> 3) & 0x01;
		//printf("\n ERR11111 =%02x FLAG=%02x %02x",err11_state,g_ERR11_FLAG,JDataFileInfo->jc.JcMaxXuliang.JcStat);
		if(err11_state != g_ERR11_FLAG)
		{
			if (err11_state==1)//11 �����쳣
			{
				JDataFileInfo->ErcEvt.ERCBiaoZhi[1]|=0b00000100;
			}else {
				JDataFileInfo->ErcEvt.ERCBiaoZhi[1]&=0b11111011;
			}
//				if (err11_state==1)
//					JDataFileInfo->ErcEvt.ERCBiaoZhi[1]|=0b00000100;
//				else
//					JDataFileInfo->ErcEvt.ERCBiaoZhi[1]&=0b11111011;
				JProgramInfo->CurrErc.Buff[0]=11;
				JProgramInfo->stateflags.ErcFlg=11;
				SdPrint("ErcNo=%d\n\r",11);

				if (JParamInfo3761->group2.f9.FlagStep[1] & 0x04) //��Ҫ�¼�
				{
					memset(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1],0,sizeof(ERC));
					JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err11.ERCNo=11;
					JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err11.len=24;
					INT32U_BCD(ts.Minute,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err11.Occur_Time.BCD01,1);
					INT32U_BCD(ts.Hour,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err11.Occur_Time.BCD02,1);
					INT32U_BCD(ts.Day,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err11.Occur_Time.BCD03,1);
					INT32U_BCD(ts.Month,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err11.Occur_Time.BCD04,1);
					INT32U_BCD(ts.Year,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err11.Occur_Time.BCD05,1);
					JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err11.ClNo[0]=(1)&0xff;
					JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err11.ClNo[1]=((1>>8)&0xff);
					if(JDataFileInfo->ErcEvt.ERCBiaoZhi[1]& 0b00000100) {
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err11.ClNo[1]=((1>>8)&0xff)|0x80;
					}
					INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.UAJ,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err11.UAj[0],2);
					INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.UBJ,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err11.UBj[0],2);
					INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.UCJ,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err11.UCj[0],2);
					INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.IAJ,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err11.IAj[0],2);
					INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.IBJ,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err11.IBj[0],2);
					INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.ICJ,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err11.ICj[0],2);
					JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err11.PDD[0]=0;
					INT32U_BCD(PDD,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err11.PDD[1],4);
					JDataFileInfo->ErcEvt.EC1++;
					JDataFileInfo->ErcEvt.EC1=JDataFileInfo->ErcEvt.EC1%256;
				}
				else
				{
					memset(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2],0,sizeof(ERC));
					JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err11.ERCNo=11;
					JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err11.len=24;
					INT32U_BCD(ts.Minute,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err11.Occur_Time.BCD01,1);
					INT32U_BCD(ts.Hour,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err11.Occur_Time.BCD02,1);
					INT32U_BCD(ts.Day,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err11.Occur_Time.BCD03,1);
					INT32U_BCD(ts.Month,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err11.Occur_Time.BCD04,1);
					INT32U_BCD(ts.Year,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err11.Occur_Time.BCD05,1);
					JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err11.ClNo[0]=(1)&0xff;
					JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err11.ClNo[1]=(1>>8)&0xff;
					if(JDataFileInfo->ErcEvt.ERCBiaoZhi[1]& 0b00000100) {
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err11.ClNo[1]=((1>>8)&0xff)|0x80;
					}

					INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.UAJ,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err11.UAj[0],2);
					INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.UBJ,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err11.UBj[0],2);
					INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.UCJ,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err11.UCj[0],2);
					INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.IAJ,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err11.IAj[0],2);
					INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.IBJ,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err11.IBj[0],2);
					INT32U_BCD(JDataFileInfo->jc.JcMaxXuliang.ICJ,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err11.ICj[0],2);
					JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err11.PDD[0]=0;
					INT32U_BCD(PDD,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err11.PDD[1],4);
					JDataFileInfo->ErcEvt.EC2++;
					JDataFileInfo->ErcEvt.EC2=JDataFileInfo->ErcEvt.EC2%256;
				}
//				memset(Temp_FilePath,0,60);
//				sprintf((char*)Temp_FilePath,"/nand/DataAlarm/alarm.dat");
//				SaveFile((char*)Temp_FilePath,&JDataFileInfo->ErcEvt,sizeof(ErcSave));
//				delay(50);
				JProgramInfo->CurrErc.Buff[0]=0;
				JProgramInfo->Para.ChangedJiZhongQiInfo = 2;
				SdPrint("\n\rCreateErr11\n\r")
//				JProgramInfo->FileSaveFlag.ercflag = 1;
			}
			g_ERR11_FLAG = err11_state;
	}
}

void CreateErr14(TS ts)
{
	INT8U powerflag=0;//ͣ�ϵ�
	INT32U stat;

	int fd=-1;
	if((fd = open("/dev/gpiV5FROUNT_TST", O_RDWR | O_NDELAY)) > 0) //yangdong
	{
		read(fd,&stat,1);
		close(fd);
	}
	if((stat&0x01)==1)
	{
		powerflag = 1;	//�е�
	}
	else
	{
		powerflag = 0;	//ͣ��
	}
	//printf("batflag=%d\n\r",batflag);
	//printf("\n ---JParameterInfo->jzq.BoardElecState=%d batflag=%d\n",JParameterInfo->jzq.BoardElecState,batflag);
	if (JProgramInfo->BoardElecState!=powerflag)
	{
		JProgramInfo->BoardElecState=powerflag;
	}
	else
		return;

	if (powerflag)
	{
		printf("\n�ն��ϵ�");
		printf("\n");
		JProgramInfo->PowerOnMessage = 1;
		JProgramInfo->PowerOFFMessage = 0;
	//	JParameterInfo->jzq.YueTj.ResetTime++;
	//	JParameterInfo->jzq.DayTj.ResetTime++;
		//--------------------------------//�ն��ϵ���Ҫ��¼�ϵ�ʱ��
		INT32U_BCD(ts.Minute,&JProgramInfo->CurrErc.Err14.Shang_Time.BCD01,1);
		INT32U_BCD(ts.Hour,&JProgramInfo->CurrErc.Err14.Shang_Time.BCD02,1);
		INT32U_BCD(ts.Day,&JProgramInfo->CurrErc.Err14.Shang_Time.BCD03,1);
		INT32U_BCD(ts.Month,&JProgramInfo->CurrErc.Err14.Shang_Time.BCD04,1);
		INT32U_BCD(ts.Year,&JProgramInfo->CurrErc.Err14.Shang_Time.BCD05,1);
		//--------------------------------
	}
	else
	{
		printf("\n�ն�ͣ��");
		printf("\n");
		JProgramInfo->PowerOFFMessage = 1;
		JProgramInfo->stateflags.JCFlag=1;
		JProgramInfo->PowerOnMessage = 0;
		Now_Min=ts.Minute;
		//---------------------------------//�ն�ͣ����Ҫ��¼ͣ��ʱ��
		INT32U_BCD(ts.Minute,&JProgramInfo->CurrErc.Err14.Ting_Time.BCD01,1);
		INT32U_BCD(ts.Hour,&JProgramInfo->CurrErc.Err14.Ting_Time.BCD02,1);
		INT32U_BCD(ts.Day,&JProgramInfo->CurrErc.Err14.Ting_Time.BCD03,1);
		INT32U_BCD(ts.Month,&JProgramInfo->CurrErc.Err14.Ting_Time.BCD04,1);
		INT32U_BCD(ts.Year,&JProgramInfo->CurrErc.Err14.Ting_Time.BCD05,1);
		//--------------------------------
	}
	fprintf(stderr,"\nFlag[1]=%x",JParamInfo3761->group2.f9.Flag[1]);
	if (!(JParamInfo3761->group2.f9.Flag[1] & 0x20))
		return;

	JProgramInfo->CurrErc.Err14.ERCNo=14;
	JProgramInfo->CurrErc.Err14.len=10;
	JDataFileInfo->ErcEvt.ERCBiaoZhi[1]|=0b00100000;
	JProgramInfo->CurrErc.Buff[0]=14;
	JProgramInfo->stateflags.ErcFlg=14;
	if (JParamInfo3761->group2.f9.FlagStep[1] & 0x20)
	{
		printf("\n��ͣ���ϵ���Ҫ�¼���");
		printf("\n�ϵ磺%02x��%02x��%02x��%02xʱ%02x�� ",JProgramInfo->CurrErc.Err14.Shang_Time.BCD05,JProgramInfo->CurrErc.Err14.Shang_Time.BCD04,JProgramInfo->CurrErc.Err14.Shang_Time.BCD03,JProgramInfo->CurrErc.Err14.Shang_Time.BCD02,JProgramInfo->CurrErc.Err14.Shang_Time.BCD01);
		printf("\nͣ�磺%02x��%02x��%02x��%02xʱ%02x�� ",JProgramInfo->CurrErc.Err14.Ting_Time.BCD05,JProgramInfo->CurrErc.Err14.Ting_Time.BCD04,JProgramInfo->CurrErc.Err14.Ting_Time.BCD03,JProgramInfo->CurrErc.Err14.Ting_Time.BCD02,JProgramInfo->CurrErc.Err14.Ting_Time.BCD01);
		printf("\n");
		memset(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1],0,sizeof(ERC));
		memcpy(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1],&JProgramInfo->CurrErc,sizeof(ERC));
		JDataFileInfo->ErcEvt.EC1++;
		JDataFileInfo->ErcEvt.EC1=JDataFileInfo->ErcEvt.EC1%256;
	}
	else
	{
		printf("\nͣ���ϵ���ͨ�¼�");
		printf("\n�ϵ磺%02x��%02x��%02x��%02xʱ%02x�� ",JProgramInfo->CurrErc.Err14.Shang_Time.BCD05,JProgramInfo->CurrErc.Err14.Shang_Time.BCD04,JProgramInfo->CurrErc.Err14.Shang_Time.BCD03,JProgramInfo->CurrErc.Err14.Shang_Time.BCD02,JProgramInfo->CurrErc.Err14.Shang_Time.BCD01);
		printf("\nͣ�磺%02x��%02x��%02x��%02xʱ%02x�� ",JProgramInfo->CurrErc.Err14.Ting_Time.BCD05,JProgramInfo->CurrErc.Err14.Ting_Time.BCD04,JProgramInfo->CurrErc.Err14.Ting_Time.BCD03,JProgramInfo->CurrErc.Err14.Ting_Time.BCD02,JProgramInfo->CurrErc.Err14.Ting_Time.BCD01);
		printf("\n");
		memset(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2],0,sizeof(ERC));
		memcpy(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2],&JProgramInfo->CurrErc,sizeof(ERC));
		JDataFileInfo->ErcEvt.EC2++;
		JDataFileInfo->ErcEvt.EC2=JDataFileInfo->ErcEvt.EC2%256;
	}

//	memset(Temp_FilePath,0,60);
//	sprintf((char*)Temp_FilePath,"/nand/DataAlarm/alarm.dat");
//	SaveFile((char*)Temp_FilePath,&JDataFileInfo->ErcEvt,sizeof(ErcSave));
//	delay(50);
	JProgramInfo->CurrErc.Buff[0]=0;
	JProgramInfo->Para.ChangedJiZhongQiInfo = 2;
	SdPrint("\n\rCreateErr14\n\r");
//	JProgramInfo->FileSaveFlag.ercflag = 1;
}

void CreateErr17(TS ts,int met)
{
	int CjqNo,MetNo,MetType,i,Ua=0,Ub=0,Uc=0,IValue=0,UValue=0;
	int Ifa=1,Ifb=1,Ifc=1,Ia=0,Ib=0,Ic=0;
	int UMax=0,IMax=0,UMin=0,IMin=0;
	float Ubln=0,Ibln=0;
	INT8U Temp_FilePath[60], tempManyData[DataLenMax],Flag[2],happ[2],fd=0;
	for(i=0;i<2;i++)
	{
		Flag[i]=0;
		happ[i]=0;
	}

	if (JParamInfo3761->group2.f9.Flag[2] & 0x01)
	{
		CjqNo=JParamInfo3761->group2.f10[met].CjqNo-1;
		MetNo=JParamInfo3761->group2.f10[met].MeterNo;
		MetType = JParamInfo3761->group2.f10[met].Type;
		if (JParamInfo3761->group2.f10[met].Status!=1)
			return;
		if (JParamInfo3761->group2.f10[met].Type==0)
			return;
		memset(Temp_FilePath,0,60);
		memset(&smfile,0,sizeof(SMFiles));
		memset(Temp_FilePath,0,60);
		sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",met+1);
		if (access((char*)Temp_FilePath,0)!=0)
		{
			return;
		}
		ReadFile((char *) Temp_FilePath, &smfile,sizeof(SMFiles),JProgramInfo);
//		if ((MetType == 9) || (MetType == 6))
//		{
//
//		}
//		else
		{
			fd=0;
			if(smfile.sm.CaijiQiNo==CjqNo&&smfile.sm.MeterNo==MetNo)
			{
				fd = 1;
				memset(tempManyData,0,sizeof(tempManyData));
				GetManyData(smfile.sm.datas,&tempManyData[0],0xb6,0x1f);
				Ua=BCD_INT32(&tempManyData[0],2);  //��ѹ
				Ub=BCD_INT32(&tempManyData[0]+2,2);
				Uc=BCD_INT32(&tempManyData[0]+4,2);

				memset(tempManyData,0,sizeof(tempManyData));
				GetManyData(smfile.sm.datas,&tempManyData[0],0xb6,0x2f);
				if (tempManyData[2]&0x80)
					Ifa=-1;
				tempManyData[2]=tempManyData[2]&0x7F;
				Ia=BCD_INT32(&tempManyData[0],3);  //����
				if (tempManyData[5]&0x80)
					Ifb=-1;
				tempManyData[5]=tempManyData[5]&0x7F;
				Ib=BCD_INT32(&tempManyData[0]+3,3);
				if (tempManyData[8]&0x80)
					Ifc=-1;
				tempManyData[8]=tempManyData[8]&0x7F;
				Ic=BCD_INT32(&tempManyData[0]+6,3);

				UMax=MaxValue(Ua,Ub,Uc); //����ѹ
				IMax=MaxValue(Ia,Ib,Ic); //������
				UMin=MinValue(Ua,Ub,Uc); //��С��ѹ
				IMin=MinValue(Ia,Ib,Ic); //��С����
				if (UMax>0)
					Ubln=(((UMax-UMin)*1000)/UMax);
				if (IMax>0)
					Ibln=(((IMax-IMin)*1000)/IMax);

				SdPrint("many17 old UValue=%d,IValue=%d,Umax=%d,Umin=%d,Imax=%d,Imin=%d\n\r",
						UValue,IValue,UMax,UMin,IMax,IMin);
				SdPrint("many17 Ua=%d,Ifa=%d,Ia=%d,Ub=%d,Ifb=%d,Ib=%d,Uc=%d,Ifc=%d,Ic=%d,Ubln=%f--%d,Ibln=%f--%d\n\r",
						Ua,Ifa,Ia,Ub,Ifb,Ib,Uc,Ifc,Ic,Ubln,BCD_INT32(&JParamInfo3761->Point[met].f26.U3_Unbalance_Value[0],2),
						Ibln,BCD_INT32(&JParamInfo3761->Point[met].f26.I3_Unbalance_Value[0],2));
			}

			if(fd==1)
			{
				if (!(JParamInfo3761->group2.f10[met].AlarmFlg[16]&0x01))
				{
					if (Ubln>BCD_INT32(&JParamInfo3761->Point[met].f26.U3_Unbalance_Value[0],2))
					{
						Flag[0]|=0x01;
						happ[0]=1;
						JParamInfo3761->group2.f10[met].AlarmFlg[16]|=0x01;
					}
				}
				else
				{
					if (Ubln<BCD_INT32(&JParamInfo3761->Point[met].f26.U3_Unbalance_Value[0],2))
					{
						Flag[0]|=0x01;
						happ[0]=2;
						JParamInfo3761->group2.f10[met].AlarmFlg[16]&=0xFE;
					}
				}
				if (!(JParamInfo3761->group2.f10[met].AlarmFlg[16]&0x02))
				{
					if (Ibln>BCD_INT32(&JParamInfo3761->Point[met].f26.I3_Unbalance_Value[0],2))
					{
						Flag[1]|=0x02;
						happ[1]=1;
						JParamInfo3761->group2.f10[met].AlarmFlg[16]|=0x02;
					}
				}
				else
				{
					if (Ibln<BCD_INT32(&JParamInfo3761->Point[met].f26.I3_Unbalance_Value[0],2))
					{
						Flag[1]|=0x02;
						happ[1]=2;
						JParamInfo3761->group2.f10[met].AlarmFlg[16]&=0xFD;
					}
				}
			}
		}
		if (fd==1)
		{
			for(i=0;i<2;i++)
			if (happ[i])
			{
				JDataFileInfo->ErcEvt.ERCBiaoZhi[2]|=0b00000001;
				if ((JParamInfo3761->group2.f10[met].AlarmFlg[16]&0b00000011)==0x00)
					JDataFileInfo->ErcEvt.ERCBiaoZhi[2]&=0b11111110;
				JProgramInfo->CurrErc.Buff[0]=17;
				JProgramInfo->stateflags.ErcFlg=17;
				SdPrint("ErcNo=%d\n\r",17);

				if (JParamInfo3761->group2.f9.FlagStep[2] & 0x01) //��Ҫ�¼�
				{
					memset(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1],0,sizeof(ERC));
					JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err17.ERCNo=17;
					JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err17.len=27;
					INT32U_BCD(ts.Minute,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err17.Occur_Time.BCD01,1);
					INT32U_BCD(ts.Hour,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err17.Occur_Time.BCD02,1);
					INT32U_BCD(ts.Day,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err17.Occur_Time.BCD03,1);
					INT32U_BCD(ts.Month,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err17.Occur_Time.BCD04,1);
					INT32U_BCD(ts.Year,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err17.Occur_Time.BCD05,1);
					JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err17.ClNo[0]=(met+1)&0xff;
					JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err17.ClNo[1]=((met+1)>>8)&0xff;
					if (happ[i]==1)
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err17.ClNo[1]|=0b10000000;
					JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err17.Flag=Flag[i];
					INT32U_BCD(Ubln,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err17.UBalance[0],2);
					INT32U_BCD(Ibln,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err17.IBalance[0],2);
					INT32U_BCD(Ua,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err17.UA[0],2);
					INT32U_BCD(Ub,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err17.UB[0],2);
					INT32U_BCD(Uc,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err17.UC[0],2);
					INT32U_BCD(Ia,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err17.IA[0],3);
					if (Ifa<0)
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err9.IA[0]|=0x80;
					INT32U_BCD(Ib,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err17.IB[0],3);
					if (Ifb<0)
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err9.IB[0]|=0x80;
					INT32U_BCD(Ic,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err17.IC[0],3);
					if (Ifc<0)
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err9.IC[0]|=0x80;
					JDataFileInfo->ErcEvt.EC1++;
					JDataFileInfo->ErcEvt.EC1=JDataFileInfo->ErcEvt.EC1%256;
				}
				else
				{
					memset(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2],0,sizeof(ERC));
					JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err17.ERCNo=17;
					JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err17.len=27;
					INT32U_BCD(ts.Minute,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err17.Occur_Time.BCD01,1);
					INT32U_BCD(ts.Hour,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err17.Occur_Time.BCD02,1);
					INT32U_BCD(ts.Day,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err17.Occur_Time.BCD03,1);
					INT32U_BCD(ts.Month,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err17.Occur_Time.BCD04,1);
					INT32U_BCD(ts.Year,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err17.Occur_Time.BCD05,1);
					JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err17.ClNo[0]=(met+1)&0xff;
					JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err17.ClNo[1]=((met+1)>>8)&0xff;
					if (happ[i]==1)
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err17.ClNo[1]|=0b10000000;
					JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err17.Flag=Flag[i];
					INT32U_BCD(Ubln,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err17.UBalance[0],2);
					INT32U_BCD(Ibln,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err17.IBalance[0],2);
					INT32U_BCD(Ua,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err17.UA[0],2);
					INT32U_BCD(Ub,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err17.UB[0],2);
					INT32U_BCD(Uc,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err17.UC[0],2);
					INT32U_BCD(Ia,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err17.IA[0],3);
					if (Ifa<0)
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err9.IA[0]|=0x80;
					INT32U_BCD(Ib,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err17.IB[0],3);
					if (Ifb<0)
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err9.IB[0]|=0x80;
					INT32U_BCD(Ic,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err17.IC[0],3);
					if (Ifc<0)
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err9.IC[0]|=0x80;
					JDataFileInfo->ErcEvt.EC2++;
					JDataFileInfo->ErcEvt.EC2=JDataFileInfo->ErcEvt.EC2%256;
				}
//				memset(Temp_FilePath,0,60);
//				sprintf((char*)Temp_FilePath,"/nand/DataAlarm/alarm.dat");
//				SaveFile((char*)Temp_FilePath,&JDataFileInfo->ErcEvt,sizeof(ErcSave));
//				delay(50);
				JProgramInfo->CurrErc.Buff[0]=0;
				JProgramInfo->Para.ChangedJiZhongQiInfo = 2;
				SdPrint("\n\rCreateErr17\n\r")
//				JProgramInfo->FileSaveFlag.ercflag = 1;
			}
		}
	}
}

void CreateErr20(TS ts)
{//��Ϣ��֤����
	if (!(JParamInfo3761->group2.f9.Flag[2] & 0x08))
		return;
	INT32U_BCD(ts.Minute,&JProgramInfo->CurrErc.Err20.Occur_Time.BCD01,1);
	INT32U_BCD(ts.Hour,&JProgramInfo->CurrErc.Err20.Occur_Time.BCD02,1);
	INT32U_BCD(ts.Day,&JProgramInfo->CurrErc.Err20.Occur_Time.BCD03,1);
	INT32U_BCD(ts.Month,&JProgramInfo->CurrErc.Err20.Occur_Time.BCD04,1);
	INT32U_BCD(ts.Year,&JProgramInfo->CurrErc.Err20.Occur_Time.BCD05,1);
	JDataFileInfo->ErcEvt.ERCBiaoZhi[2]|=0b00001000;
	JProgramInfo->CurrErc.Buff[0]=20;
	JProgramInfo->stateflags.ErcFlg=20;
	if (JParamInfo3761->group2.f9.FlagStep[2] & 0x08)
	{
		memset(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1],0,sizeof(ERC));
		memcpy(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1],&JProgramInfo->CurrErc,sizeof(ERC));
		JDataFileInfo->ErcEvt.EC1++;
		JDataFileInfo->ErcEvt.EC1=JDataFileInfo->ErcEvt.EC1%256;
	}
	else
	{
		memset(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2],0,sizeof(ERC));
		memcpy(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2],&JProgramInfo->CurrErc,sizeof(ERC));
		JDataFileInfo->ErcEvt.EC2++;
		JDataFileInfo->ErcEvt.EC2=JDataFileInfo->ErcEvt.EC2%256;
	}
//	memset(Temp_FilePath,0,60);
//	sprintf((char*)Temp_FilePath,"/nand/DataAlarm/alarm.dat");
//	SaveFile((char*)Temp_FilePath,&JDataFileInfo->ErcEvt,sizeof(ErcSave));
//	delay(50);
	JProgramInfo->CurrErc.Buff[0]=0;
	JProgramInfo->Para.ChangedJiZhongQiInfo = 2;
	SdPrint("\n\rCreateErr20\n\r")
//	JProgramInfo->FileSaveFlag.ercflag = 1;
}

//�ն˹��ϼ�¼��Code=4��485��������
void CreateErr21(TS ts)
{
	if (!(JParamInfo3761->group2.f9.Flag[2] & 0x10))
		return;
	JDataFileInfo->ErcEvt.ERCBiaoZhi[2]|=0b00010000;
	JProgramInfo->CurrErc.Buff[0]=21;
	JProgramInfo->stateflags.ErcFlg=21;
	if (JParamInfo3761->group2.f9.FlagStep[2] & 0x10)
	{
		printf("\n\rCreateErr21  ImpEvent\n\r");
		memset(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1],0,sizeof(ERC));
		JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err21.ERCNo=21;
		JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err21.len=6;
		INT32U_BCD(ts.Minute,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err21.Occur_Time.BCD01,1);
		INT32U_BCD(ts.Hour,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err21.Occur_Time.BCD02,1);
		INT32U_BCD(ts.Day,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err21.Occur_Time.BCD03,1);
		INT32U_BCD(ts.Month,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err21.Occur_Time.BCD04,1);
		INT32U_BCD(ts.Year,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err21.Occur_Time.BCD05,1);
		JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err21.Code=4;
		JDataFileInfo->ErcEvt.EC1++;
		JDataFileInfo->ErcEvt.EC1=JDataFileInfo->ErcEvt.EC1%256;
	}
	else
	{
		printf("\n\rCreateErr21   NorEvent\n\r");
		memset(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2],0,sizeof(ERC));
		JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err21.ERCNo=21;
		JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err21.len=6;
		INT32U_BCD(ts.Minute,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err21.Occur_Time.BCD01,1);
		INT32U_BCD(ts.Hour,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err21.Occur_Time.BCD02,1);
		INT32U_BCD(ts.Day,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err21.Occur_Time.BCD03,1);
		INT32U_BCD(ts.Month,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err21.Occur_Time.BCD04,1);
		INT32U_BCD(ts.Year,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err21.Occur_Time.BCD05,1);
		JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err21.Code=4;
		JDataFileInfo->ErcEvt.EC2++;
		JDataFileInfo->ErcEvt.EC2=JDataFileInfo->ErcEvt.EC2%256;
	}
//	memset(Temp_FilePath,0,60);
//	sprintf((char*)Temp_FilePath,"/nand/DataAlarm/alarm.dat");
//	SaveFile((char*)Temp_FilePath,&JDataFileInfo->ErcEvt,sizeof(ErcSave));
//	delay(100);
	JProgramInfo->CurrErc.Buff[0]=0;
	JProgramInfo->Para.ChangedJiZhongQiInfo = 2;
//	JProgramInfo->FileSaveFlag.ercflag = 1;

}
void CreateErr22(TS ts)  //�������Խ��
{
	INT8U i=0,j=0,DGrpNo=0,CGrpNO=0,flag=0,XdVal=0,fh=0,jdv[4],tmpmet;
	INT8U CJQno,MeterNo,MeterType,MeterFlgD6,MeterFlgD7,MulPointNum;
	INT8U Temp_FilePath[60],tempManyData[50],IsDataFlag,dftype,ff;
	INT32S JdVal=0,Delc=0,Celc=0,tmp=0;
	INT8U DNum=0,CNum=0,DZ[64][4],CZ[64][4];

	for(i=0;i<64;i++)
	{
		memset(DZ[i],0,4);
		memset(CZ[i],0,4);
	}
	for(i=0;i<GroupMax;i++)
	{
		if ((JParamInfo3761->group2.f15.Group[i].GroupIndex==0) ||
			(JParamInfo3761->group2.f15.Group[i].CmpGrpNo==0) ||
			(JParamInfo3761->group2.f15.Group[i].CanGrpNo==0))
		{
			continue;
		}
		DGrpNo=JParamInfo3761->group2.f15.Group[i].CmpGrpNo;
		CGrpNO=JParamInfo3761->group2.f15.Group[i].CanGrpNo;
		flag=(JParamInfo3761->group2.f15.Group[i].Flag>>7)&0x01;
		XdVal=JParamInfo3761->group2.f15.Group[i].XdVal;
		fh=(JParamInfo3761->group2.f15.Group[i].JdVal[4]>>4)&0x01;
		memcpy(&jdv[0],&JParamInfo3761->group2.f15.Group[i].JdVal[0],4);
		jdv[3]=jdv[3]&0x0F;
		JdVal=BCD_INT32(&jdv[0],4);
		if (fh==1)
			JdVal=JdVal*(-1);
		MulPointNum=JParamInfo3761->group2.f14.Group[DGrpNo-1].PointNum;
		for(j=0;j<MulPointNum;j++)
		{
			tmpmet=JParamInfo3761->group2.f14.Group[DGrpNo-1].Index_Flag[j]&0x3f;//������ D0~D5
			MeterFlgD6=(JParamInfo3761->group2.f14.Group[DGrpNo-1].Index_Flag[j]>>6)&0x01;//D6 0����1����
			MeterFlgD7=(JParamInfo3761->group2.f14.Group[DGrpNo-1].Index_Flag[j]>>7)&0x01;//D7 0��1��
			MeterType=JParamInfo3761->group2.f10[tmpmet].Type;//������
			CJQno=JParamInfo3761->group2.f10[tmpmet].CjqNo-1;//�ɼ�����
			MeterNo=JParamInfo3761->group2.f10[tmpmet].MeterNo;
			IsDataFlag=0;
			memset(Temp_FilePath,0x00,60);
			sprintf((char *)Temp_FilePath,"/nand/DataCurr/%04d/curr.dat",tmpmet+1);
			if ((MeterType == 9) || (MeterType == 6))
			{
				dftype=0;
			}
			else
			{
				dftype=1;
			}

			IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath);
			if(IsDataFlag==1)
			{
				if (MeterFlgD6)
				IsDataFlag=getMetersData(MeterType,&tempManyData[0],CJQno,MeterNo,0x90,0x20,0,3,1,0,0,0,0,dftype);
				else
				IsDataFlag=getMetersData(MeterType,&tempManyData[0],CJQno,MeterNo,0x90,0x10,0,3,1,0,0,0,0,dftype);
				if (IsDataFlag == 0)
				{
					ff=0;
					break;
				}
				memcpy(&DZ[DNum][0],&tempManyData[0],4);
				tmp=BCD_INT32(&tempManyData[0], 4);
				DNum++;
			}
			else
			{
				ff=0;
				break;
			}
			IsDataFlag=0;
			memset(Temp_FilePath,0x00,60);
			sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/last.dat",tmpmet+1);
			if ((MeterType == 9) || (MeterType == 6))
			{
				dftype=0;
			}
			else
			{
				dftype=1;
			}

			IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath);
			if(IsDataFlag==1)
			{
				if (MeterFlgD6)
				IsDataFlag=getMetersData(MeterType,&tempManyData[0],CJQno,MeterNo,0x90,0x20,0,3,1,0,0,0,0,dftype);
				else
				IsDataFlag=getMetersData(MeterType,&tempManyData[0],CJQno,MeterNo,0x90,0x10,0,3,1,0,0,0,0,dftype);
				if (IsDataFlag == 0)
				{
					ff=0;
					break;
				}
				tmp=tmp-BCD_INT32(&tempManyData[0], 4);
			}
			else
			{
				ff=0;
				break;
			}

			if(!MeterFlgD7)
			{
				Delc+=tmp;
			}
			else
			{
				Delc-=tmp;

			}
		}
		tmp=0;
		MulPointNum=JParamInfo3761->group2.f14.Group[CGrpNO-1].PointNum;
		for(j=0;j<MulPointNum;j++)
		{
			tmpmet=JParamInfo3761->group2.f14.Group[CGrpNO-1].Index_Flag[j]&0x3f;//������ D0~D5
			MeterFlgD6=(JParamInfo3761->group2.f14.Group[CGrpNO-1].Index_Flag[j]>>6)&0x01;//D6 0����1����
			MeterFlgD7=(JParamInfo3761->group2.f14.Group[CGrpNO-1].Index_Flag[j]>>7)&0x01;//D7 0��1��
			MeterType=JParamInfo3761->group2.f10[tmpmet].Type;//������
			CJQno=JParamInfo3761->group2.f10[tmpmet].CjqNo-1;//�ɼ�����
			MeterNo=JParamInfo3761->group2.f10[tmpmet].MeterNo;
			IsDataFlag=0;
			memset(Temp_FilePath,0x00,60);
			sprintf((char *)Temp_FilePath,"/nand/DataCurr/%04d/curr.dat",tmpmet+1);
			if ((MeterType == 9) || (MeterType == 6))
			{
				dftype=0;
			}
			else
			{
				dftype=1;
			}

			IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath);
			if(IsDataFlag==1)
			{
				if (MeterFlgD6)
				IsDataFlag=getMetersData(MeterType,&tempManyData[0],CJQno,MeterNo,0x90,0x20,0,3,1,0,0,0,0,dftype);
				else
				IsDataFlag=getMetersData(MeterType,&tempManyData[0],CJQno,MeterNo,0x90,0x10,0,3,1,0,0,0,0,dftype);
				if (IsDataFlag == 0)
				{
					ff=0;
					break;
				}
				memcpy(&CZ[CNum][0],&tempManyData[0],4);
				tmp=BCD_INT32(&tempManyData[0], 4);
				CNum++;
			}
			else
			{
				ff=0;
				break;
			}
			IsDataFlag=0;
			memset(Temp_FilePath,0x00,60);
			sprintf((char *)Temp_FilePath,"/nand/DataDay/%04d/last.dat",tmpmet+1);
			if ((MeterType == 9) || (MeterType == 6))
			{
				dftype=0;
			}
			else
			{
				dftype=1;
			}

			IsDataFlag=getMeterFile(MeterType,(char *) Temp_FilePath);
			if(IsDataFlag==1)
			{
				if (MeterFlgD6)
				IsDataFlag=getMetersData(MeterType,&tempManyData[0],CJQno,MeterNo,0x90,0x20,0,3,1,0,0,0,0,dftype);
				else
				IsDataFlag=getMetersData(MeterType,&tempManyData[0],CJQno,MeterNo,0x90,0x10,0,3,1,0,0,0,0,dftype);
				if (IsDataFlag == 0)
				{
					ff=0;
					break;
				}
				tmp=tmp-BCD_INT32(&tempManyData[0], 4);
			}
			else
			{
				ff=0;
				break;
			}

			if(!MeterFlgD7)
			{
				Celc+=tmp;
			}
			else
			{
				Celc-=tmp;

			}
		}

		if (flag==0)
		{
			if ((((Delc-Celc)*100)/Celc) >= XdVal)
			{
			}
		}
		else
		{
			if (fh==0)
			{
				if ((Delc-Celc)>=JdVal)
				{
				}
			}
			else
			{
				if (((Delc-Celc)*(-1))>=JdVal)
				{
				}
			}
		}
	}
}

void CreateErr24(TS ts,int met)
{
	int CjqNo,MetNo,MetType,i,Ua=0,Ub=0,Uc=0,USS=0,UXX=0;
	INT8U Temp_FilePath[60], tempManyData[DataLenMax],Flag[2],happ[2],fd=0;
	for(i=0;i<2;i++)
	{
		Flag[i]=0;
		happ[i]=0;
	}

	if (JParamInfo3761->group2.f9.Flag[2] & 0x80)
	{
		CjqNo=JParamInfo3761->group2.f10[met].CjqNo-1;
		MetNo=JParamInfo3761->group2.f10[met].MeterNo;
		MetType = JParamInfo3761->group2.f10[met].Type;
		if (JParamInfo3761->group2.f10[met].Status!=1)
			return;
		if (JParamInfo3761->group2.f10[met].Type==0)
			return;
		memset(&smfile,0,sizeof(SMFiles));
		memset(Temp_FilePath,0,60);
		sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",met+1);
		if (access((char*)Temp_FilePath,0)!=0)
		{
			return;
		}
		ReadFile((char *) Temp_FilePath, &smfile,sizeof(SMFiles),JProgramInfo);
//		if ((MetType == 9) || (MetType == 6))
//		{
//			fd=0;
//			if(smfile.sm.CaijiQiNo==CjqNo&&smfile.sm.MeterNo==MetNo)
//			{
//				fd=1;
//				memset(tempManyData,0,sizeof(tempManyData));
//				GetManyData(smfile.sm.datas,&tempManyData[0],0xb6,0x11);
//				Ua=BCD_INT32(&tempManyData[0],2);
//
//				USS=BCD_INT32(&JParamInfo3761->Point[met].f26.V_He_ge_SS[0],2);
//				UXX=BCD_INT32(&JParamInfo3761->Point[met].f26.V_He_ge_XX[0],2);
//				SdPrint("sing24 Ua=%d,USS=%d,UXX=%d\n\r",Ua,USS,UXX);
//
//				if (!(JParamInfo3761->group2.f10[met].AlarmFlg[5]&0b01000001))
//				{
//					Ua=1000;USS=80;
//					if ((Ua>USS) && (USS!=0))
//					{
//						Flag[0]|=0b01000001;
//						happ[0]=1;
//						JParamInfo3761->group2.f10[met].AlarmFlg[5]|=0b01000001;
//					}
//				}
//				else
//				{
//					if ((Ua<=USS) && (USS!=0))
//						if ((USS-Ua)*1000/USS >= BCD_INT32(&JParamInfo3761->Point[met].f26.V_He_ge_SS_Renew[0],2))
//						{
//							Flag[0]|=0b01000001;
//							happ[0]=2;
//							JParamInfo3761->group2.f10[met].AlarmFlg[5]&=0b10111110;
//						}
//				}
//				if (!(JParamInfo3761->group2.f10[met].AlarmFlg[23]&0b10000001))
//				{
//					if ((Ua<UXX) && (UXX!=0))
//					{
//						Flag[1]|=0b10000001;
//						happ[1]=1;
//						JParamInfo3761->group2.f10[met].AlarmFlg[23]|=0b10000001;
//					}
//				}
//				else
//				{
//					if ((Ua>=UXX) && (UXX != 0))
//						if ((Ua-UXX)*1000/UXX >= BCD_INT32(&JParamInfo3761->Point[met].f26.V_He_ge_XX_Renew[0],2)) //��ѹ�ڷ�Χ�ڻָ�
//						{
//							Flag[1]|=0b01000001;
//							happ[1]=2;
//							JParamInfo3761->group2.f10[met].AlarmFlg[23]&=0b01111110;
//						}
//				}
//			}
//		}
//		else
		{
			fd=0;
			if(smfile.sm.CaijiQiNo==CjqNo && smfile.sm.MeterNo==MetNo)
			{
				fd=1;
				memset(tempManyData,0,sizeof(tempManyData));
				GetManyData(smfile.sm.datas,&tempManyData[0],0xb6,0x1f);
				Ua=BCD_INT32(&tempManyData[0],2);  //��ѹ
				Ub=BCD_INT32(&tempManyData[0]+2,2);
				Uc=BCD_INT32(&tempManyData[0]+4,2);

				USS=BCD_INT32(&JParamInfo3761->Point[met].f26.V_He_ge_SS[0],2);
				UXX=BCD_INT32(&JParamInfo3761->Point[met].f26.V_He_ge_XX[0],2);
				fprintf(stderr,"many24 Ua=%d,Ub=%d,Uc=%d,USS=%d,UXX=%d\n\r",Ua,Ub,Uc,USS,UXX);

				//Ua=Ub=Uc=1000;USS=800;UXX=1200;
				if (!((JParamInfo3761->group2.f10[met].AlarmFlg[5]&0b01000001)==0b01000001))
				{
					if ((Ua>USS) && (USS!=0))
					{
						Flag[0]|=0b01000001;
						happ[0]=1;
						JParamInfo3761->group2.f10[met].AlarmFlg[5]|=0b01000001;
					}
				}
				else
				{
					if ((Ua<=USS) && (USS!=0))
						if ((USS-Ua)*1000/USS >= BCD_INT32(&JParamInfo3761->Point[met].f26.V_He_ge_SS_Renew[0],2))
						{
							Flag[0]|=0b01000001;
							happ[0]=2;
							JParamInfo3761->group2.f10[met].AlarmFlg[5]&=0b10111110;
						}
				}
				if (!((JParamInfo3761->group2.f10[met].AlarmFlg[23]&0b10000001)==0b10000001))
				{
					if ((Ua<UXX) && (UXX!=0))
					{
						Flag[1]|=0b10000001;
						happ[1]=1;
						JParamInfo3761->group2.f10[met].AlarmFlg[23]|=0b10000001;
					}
				}
				else
				{
					if ((Ua>=UXX) && (UXX != 0))
						if ((Ua-UXX)*1000/UXX >= BCD_INT32(&JParamInfo3761->Point[met].f26.V_He_ge_XX_Renew[0],2)) //��ѹ�ڷ�Χ�ڻָ�
						{
							Flag[1]|=0b01000001;
							happ[1]=2;
							JParamInfo3761->group2.f10[met].AlarmFlg[23]&=0b01111110;
						}
				}

				if (!((JParamInfo3761->group2.f10[met].AlarmFlg[5]&0b01000010)==0b01000010))
				{
					if ((Ub>USS) && (USS!=0))
					{
						Flag[0]|=0b01000010;
						happ[0]|=0b00000100;
						JParamInfo3761->group2.f10[met].AlarmFlg[5]|=0b01000010;
					}
				}
				else
				{
					if ((Ub<=USS) && (USS!=0))
						if ((USS-Ub)*1000/USS >= BCD_INT32(&JParamInfo3761->Point[met].f26.V_He_ge_SS_Renew[0],2))
						{
							Flag[0]|=0b01000010;
							happ[0]|=0b00001000;
							JParamInfo3761->group2.f10[met].AlarmFlg[5]&=0b10111101;
						}
				}
				if (!((JParamInfo3761->group2.f10[met].AlarmFlg[23]&0b10000010)==0b10000010))
				{
					if ((Ub<UXX) && (UXX!=0))
					{
						Flag[1]|=0b10000010;
						happ[1]|=0b00000100;
						JParamInfo3761->group2.f10[met].AlarmFlg[23]|=0b10000010;
					}
				}
				else
				{
					if ((Ub>=UXX) && (UXX != 0))
						if ((Ub-UXX)*1000/UXX >= BCD_INT32(&JParamInfo3761->Point[met].f26.V_He_ge_XX_Renew[0],2)) //��ѹ�ڷ�Χ�ڻָ�
						{
							Flag[1]|=0b01000010;
							happ[1]|=0b00001000;
							JParamInfo3761->group2.f10[met].AlarmFlg[23]&=0b01111101;
						}
				}

				if (!((JParamInfo3761->group2.f10[met].AlarmFlg[5]&0b01000100)==0b01000100))
				{
					if ((Uc>USS) && (USS!=0))
					{
						Flag[0]|=0b01000100;
						happ[0]|=0b00010000;
						JParamInfo3761->group2.f10[met].AlarmFlg[5]|=0b01000100;
					}
				}
				else
				{
					if ((Uc<=USS) && (USS!=0))
						if ((USS-Uc)*1000/USS >= BCD_INT32(&JParamInfo3761->Point[met].f26.V_He_ge_SS_Renew[0],2))
						{
							Flag[0]|=0b01000100;
							happ[0]|=0b00100000;
							JParamInfo3761->group2.f10[met].AlarmFlg[5]&=0b10111011;
						}
				}
				if (!((JParamInfo3761->group2.f10[met].AlarmFlg[23]&0b10000100)==0b10000100))
				{
					if ((Uc<UXX) && (UXX!=0))
					{
						Flag[1]|=0b10000100;
						happ[1]|=0b00010000;
						JParamInfo3761->group2.f10[met].AlarmFlg[23]|=0b10000100;
					}
				}
				else
				{
					if ((Uc>=UXX) && (UXX != 0))
						if ((Uc-UXX)*1000/UXX >= BCD_INT32(&JParamInfo3761->Point[met].f26.V_He_ge_XX_Renew[0],2)) //��ѹ�ڷ�Χ�ڻָ�
						{
							Flag[1]|=0b01000100;
							happ[1]|=0b00100000;
							JParamInfo3761->group2.f10[met].AlarmFlg[23]&=0b01111011;
						}
				}
			}
		}
		if (fd==1)
		{
			for(i=0;i<2;i++)
			if (happ[i])
			{
				JDataFileInfo->ErcEvt.ERCBiaoZhi[2]|=0b10000000;
				if (((JParamInfo3761->group2.f10[met].AlarmFlg[5]&0b11000000)==0x00) &&
						((JParamInfo3761->group2.f10[met].AlarmFlg[23]&0b11000000)==0x00))
					JDataFileInfo->ErcEvt.ERCBiaoZhi[2]&=0b01111111;
				JProgramInfo->CurrErc.Buff[0]=24;
				JProgramInfo->stateflags.ErcFlg=24;
				SdPrint("ErcNo=%d\n\r",24);
				if (JParamInfo3761->group2.f9.FlagStep[2] & 0x80) //��Ҫ�¼�
				{
					memset(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1],0,sizeof(ERC));
					JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err24.ERCNo=24;
					JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err24.len=14;
					INT32U_BCD(ts.Minute,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err24.Occur_Time.BCD01,1);
					INT32U_BCD(ts.Hour,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err24.Occur_Time.BCD02,1);
					INT32U_BCD(ts.Day,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err24.Occur_Time.BCD03,1);
					INT32U_BCD(ts.Month,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err24.Occur_Time.BCD04,1);
					INT32U_BCD(ts.Year,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err24.Occur_Time.BCD05,1);
					JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err24.ClNo[0]=(met+1)&0xff;
					JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err24.ClNo[1]=((met+1)>>8)&0xff;
					if (happ[i]&0b00010101)
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err24.ClNo[1]|=0b10000000;
					JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err24.Flag=Flag[i];
					INT32U_BCD(Ua,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err24.UA[0],2);
					INT32U_BCD(Ub,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err24.UB[0],2);
					INT32U_BCD(Uc,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err24.UC[0],2);
					JDataFileInfo->ErcEvt.EC1++;
					JDataFileInfo->ErcEvt.EC1=JDataFileInfo->ErcEvt.EC1%256;
				}
				else
				{
					memset(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2],0,sizeof(ERC));
					JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err24.ERCNo=24;
					JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err24.len=14;
					INT32U_BCD(ts.Minute,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err24.Occur_Time.BCD01,1);
					INT32U_BCD(ts.Hour,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err24.Occur_Time.BCD02,1);
					INT32U_BCD(ts.Day,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err24.Occur_Time.BCD03,1);
					INT32U_BCD(ts.Month,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err24.Occur_Time.BCD04,1);
					INT32U_BCD(ts.Year,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err24.Occur_Time.BCD05,1);
					JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err24.ClNo[0]=(met+1)&0xff;
					JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err24.ClNo[1]=((met+1)>>8)&0xff;
					if (happ[i]&0b00010101)
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err24.ClNo[1]|=0b10000000;
					JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err24.Flag=Flag[i];
					INT32U_BCD(Ua,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err24.UA[0],2);
					INT32U_BCD(Ub,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err24.UB[0],2);
					INT32U_BCD(Uc,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err24.UC[0],2);
					JDataFileInfo->ErcEvt.EC2++;
					JDataFileInfo->ErcEvt.EC2=JDataFileInfo->ErcEvt.EC2%256;
				}
//				memset(Temp_FilePath,0,60);
//				sprintf((char*)Temp_FilePath,"/nand/DataAlarm/alarm.dat");
//				SaveFile((char*)Temp_FilePath,&JDataFileInfo->ErcEvt,sizeof(ErcSave));
//				delay(50);
				JProgramInfo->CurrErc.Buff[0]=0;
				JProgramInfo->Para.ChangedJiZhongQiInfo = 2;
				SdPrint("\n\rCreateErr24\n\r")
//				JProgramInfo->FileSaveFlag.ercflag = 1;
			}
		}
	}
}

void CreateErr25(TS ts,int met)
{
	int CjqNo,MetNo,MetType,i,Ia=0,Ib=0,Ic=0,ISS=0,IS=0,Ifa=1,Ifb=1,Ifc=1;
	INT8U Temp_FilePath[60], tempManyData[DataLenMax],Flag[2],happ[2],fd=0;
	for(i=0;i<2;i++)
	{
		Flag[i]=0;
		happ[i]=0;
	}
	if (JParamInfo3761->group2.f9.Flag[3] & 0x01)
	{
		CjqNo=JParamInfo3761->group2.f10[met].CjqNo-1;
		MetNo=JParamInfo3761->group2.f10[met].MeterNo;
		MetType = JParamInfo3761->group2.f10[met].Type;
		if (JParamInfo3761->group2.f10[met].Status!=1)
			return;
		if (JParamInfo3761->group2.f10[met].Type==0)
			return;
		memset(&smfile,0,sizeof(SMFiles));
		memset(Temp_FilePath,0,60);
		sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",met+1);
		if (access((char*)Temp_FilePath,0)!=0)
		{
			return;
		}
		ReadFile((char *) Temp_FilePath, &smfile,sizeof(SMFiles),JProgramInfo);
		if ((MetType == 9) || (MetType == 6))
		{
			fd=0;
			if(smfile.sm.CaijiQiNo==CjqNo&&smfile.sm.MeterNo==MetNo)
			{
				fd=1;
				memset(tempManyData,0,sizeof(tempManyData));
				GetManyData(smfile.sm.datas,&tempManyData[0],0xb6,0x21);
				if (tempManyData[2]&0x80)
					Ifa=-1;
				tempManyData[2]=tempManyData[2]&0x7F;
				Ia=BCD_INT32(&tempManyData[0],3);
				JParamInfo3761->Point[met].f26.I_SS[0]&=0x7f;
				JParamInfo3761->Point[met].f26.I_S[0]&=0x7f;
				ISS=BCD_INT32(&JParamInfo3761->Point[met].f26.I_SS[0],3);
				IS=BCD_INT32(&JParamInfo3761->Point[met].f26.I_S[0],3);
				SdPrint("Sing25 Ifa=%d,Ia=%d,ISS=%d,IS=%d\n\r",Ifa,Ia,ISS,IS);

				if (!(JParamInfo3761->group2.f10[met].AlarmFlg[6]&0b01000001))
				{
					if ((Ia>ISS) && (ISS!=0))
					{
						Flag[0]|=0b01000001;
						happ[0]=1;
						JParamInfo3761->group2.f10[met].AlarmFlg[6]|=0b01000001;
					}
				}
				else
				{
					if ((Ia<=ISS) && (ISS!=0))
						if ((ISS-Ia)*1000/ISS >= BCD_INT32(&JParamInfo3761->Point[met].f26.I_SS_Renew[0],2))
						{
							Flag[0]|=0b01000001;
							happ[0]=2;
							JParamInfo3761->group2.f10[met].AlarmFlg[6]&=0b10111110;
						}
				}
				if (!(JParamInfo3761->group2.f10[met].AlarmFlg[6]&0b01000001))
				{
					if (!(JParamInfo3761->group2.f10[met].AlarmFlg[24]&0b10000001))
					{
						if ((Ia>IS) && (IS!=0))
						{
							Flag[1]|=0b10000001;
							happ[1]=1;
							JParamInfo3761->group2.f10[met].AlarmFlg[24]|=0b10000001;
						}
					}
					else
					{
						if ((Ia<=IS) && (IS != 0))
							if ((IS-Ia)*1000/IS >= BCD_INT32(&JParamInfo3761->Point[met].f26.I_S_Renew[0],2))
							{
								Flag[1]|=0b01000001;
								happ[1]=2;
								JParamInfo3761->group2.f10[met].AlarmFlg[24]&=0b01111110;
							}
					}
				}
			}
		}
		else
		{
			fd=0;
			if(smfile.sm.CaijiQiNo==CjqNo&&smfile.sm.MeterNo==MetNo)
			{
				fd=1;
				memset(tempManyData,0,sizeof(tempManyData));
				GetManyData(smfile.sm.datas,&tempManyData[0],0xb6,0x2f);
				if (tempManyData[2]&0x80)
					Ifa=-1;
				tempManyData[2]=tempManyData[2]&0x7F;
				Ia=BCD_INT32(&tempManyData[0],3);  //����
				if (tempManyData[5]&0x80)
					Ifb=-1;
				tempManyData[5]=tempManyData[5]&0x7F;
				Ib=BCD_INT32(&tempManyData[0]+3,3);
				if (tempManyData[8]&0x80)
					Ifc=-1;
				tempManyData[8]=tempManyData[8]&0x7F;
				Ic=BCD_INT32(&tempManyData[0]+6,3);

				JParamInfo3761->Point[met].f26.I_SS[0]&=0x7f;
				JParamInfo3761->Point[met].f26.I_S[0]&=0x7f;
				ISS=BCD_INT32(&JParamInfo3761->Point[met].f26.I_SS[0],3);
				IS=BCD_INT32(&JParamInfo3761->Point[met].f26.I_S[0],3);
				SdPrint("many25 Ifa=%d,Ia=%d,Ifb=%d,Ib=%d,Ifc=%d,Ic=%d,ISS=%d,IS=%d\n\r",
						Ifa,Ia,Ifb,Ib,Ifc,Ic,ISS,IS);

				//Ia=Ib=Ic=1000;IS=800;ISS=1200;
				if (!((JParamInfo3761->group2.f10[met].AlarmFlg[6]&0b01000001)==0b01000001))
				{
					if ((Ia>ISS) && (ISS!=0))
					{
						Flag[0]|=0b01000001;
						happ[0]=1;
						JParamInfo3761->group2.f10[met].AlarmFlg[6]|=0b01000001;
					}
				}
				else
				{
					if ((Ia<=ISS) && (ISS!=0))
						if ((ISS-Ia)*1000/ISS >= BCD_INT32(&JParamInfo3761->Point[met].f26.I_SS_Renew[0],2))
						{
							Flag[0]|=0b01000001;
							happ[0]=2;
							JParamInfo3761->group2.f10[met].AlarmFlg[6]&=0b10111110;
						}
				}
				if (!((JParamInfo3761->group2.f10[met].AlarmFlg[6]&0b01000001)==0b01000001))
				{
					if (!(JParamInfo3761->group2.f10[met].AlarmFlg[24]&0b10000001))
					{
						if ((Ia>IS) && (IS!=0))
						{
							Flag[1]|=0b10000001;
							happ[1]=1;
							JParamInfo3761->group2.f10[met].AlarmFlg[24]|=0b10000001;
						}
					}
					else
					{
						if ((Ia<=IS) && (IS != 0))
							if ((IS-Ia)*1000/IS >= BCD_INT32(&JParamInfo3761->Point[met].f26.I_S_Renew[0],2))
							{
								Flag[1]|=0b01000001;
								happ[1]=2;
								JParamInfo3761->group2.f10[met].AlarmFlg[24]&=0b01111110;
							}
					}
				}

				if (!((JParamInfo3761->group2.f10[met].AlarmFlg[6]&0b01000010)==0b01000010))
				{
					if ((Ib>ISS) && (ISS!=0))
					{
						Flag[0]|=0b01000010;
						happ[0]|=0b00000100;
						JParamInfo3761->group2.f10[met].AlarmFlg[6]|=0b01000010;
					}
				}
				else
				{
					if ((Ib<=ISS) && (ISS!=0))
						if ((ISS-Ib)*1000/ISS >= BCD_INT32(&JParamInfo3761->Point[met].f26.I_SS_Renew[0],2))
						{
							Flag[0]|=0b01000010;
							happ[0]|=0b00001000;
							JParamInfo3761->group2.f10[met].AlarmFlg[6]&=0b10111101;
						}
				}
				if (!((JParamInfo3761->group2.f10[met].AlarmFlg[6]&0b01000010)==0b01000010))
				{
					if (!(JParamInfo3761->group2.f10[met].AlarmFlg[24]&0b10000010))
					{
						if ((Ib>IS) && (IS!=0))
						{
							Flag[1]|=0b10000010;
							happ[1]|=0b00000100;
							JParamInfo3761->group2.f10[met].AlarmFlg[24]|=0b10000010;
						}
					}
					else
					{
						if ((Ib<=IS) && (IS != 0))
							if ((IS-Ib)*1000/IS >= BCD_INT32(&JParamInfo3761->Point[met].f26.I_S_Renew[0],2))
							{
								Flag[1]|=0b01000001;
								happ[1]|=0b00001000;
								JParamInfo3761->group2.f10[met].AlarmFlg[24]&=0b01111101;
							}
					}
				}

				if (!((JParamInfo3761->group2.f10[met].AlarmFlg[6]&0b01000100)==0b01000100))
				{
					if ((Ic>ISS) && (ISS!=0))
					{
						Flag[0]|=0b01000100;
						happ[0]|=0b00010000;
						JParamInfo3761->group2.f10[met].AlarmFlg[6]|=0b01000100;
					}
				}
				else
				{
					if ((Ic<=ISS) && (ISS!=0))
						if ((ISS-Ic)*1000/ISS >= BCD_INT32(&JParamInfo3761->Point[met].f26.I_SS_Renew[0],2))
						{
							Flag[0]|=0b01000100;
							happ[0]|=0b00100000;
							JParamInfo3761->group2.f10[met].AlarmFlg[6]&=0b10111011;
						}
				}
				if (!((JParamInfo3761->group2.f10[met].AlarmFlg[6]&0b01000100)==0b01000100))
				{
					if (!(JParamInfo3761->group2.f10[met].AlarmFlg[24]&0b10000100))
					{
						if ((Ic>IS) && (IS!=0))
						{
							Flag[1]|=0b10000100;
							happ[1]|=0b00010000;
							JParamInfo3761->group2.f10[met].AlarmFlg[24]|=0b10000100;
						}
					}
					else
					{
						if ((Ic<=IS) && (IS != 0))
							if ((IS-Ic)*1000/IS >= BCD_INT32(&JParamInfo3761->Point[met].f26.I_S_Renew[0],2))
							{
								Flag[1]|=0b01000100;
								happ[1]|=0b00100000;
								JParamInfo3761->group2.f10[met].AlarmFlg[24]&=0b01111011;
							}
					}
				}
			}
		}

		if (fd==1)
		{
			for(i=0;i<2;i++)
			if (happ[i])
			{
				JDataFileInfo->ErcEvt.ERCBiaoZhi[3]|=0b00000001;
				if (((JParamInfo3761->group2.f10[met].AlarmFlg[6]&0b11000000)==0x00) &&
					((JParamInfo3761->group2.f10[met].AlarmFlg[24]&0b11000000)==0x00))
					JDataFileInfo->ErcEvt.ERCBiaoZhi[3]&=0b11111110;
				JProgramInfo->CurrErc.Buff[0]=25;
				JProgramInfo->stateflags.ErcFlg=25;
				SdPrint("ErcNo=%d\n\r",25);
				if (JParamInfo3761->group2.f9.FlagStep[3] & 0x01) //��Ҫ�¼�
				{
					memset(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1],0,sizeof(ERC));
					JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err25.ERCNo=25;
					JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err25.len=17;
					INT32U_BCD(ts.Minute,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err25.Occur_Time.BCD01,1);
					INT32U_BCD(ts.Hour,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err25.Occur_Time.BCD02,1);
					INT32U_BCD(ts.Day,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err25.Occur_Time.BCD03,1);
					INT32U_BCD(ts.Month,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err25.Occur_Time.BCD04,1);
					INT32U_BCD(ts.Year,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err25.Occur_Time.BCD05,1);
					JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err25.ClNo[0]=(met+1)&0xff;
					JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err25.ClNo[1]=((met+1)>>8)&0xff;
					if (happ[i]&0b00010101)
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err25.ClNo[1]|=0b10000000;
					JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err25.Flag=Flag[i];
					INT32U_BCD(Ia,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err25.IA[0],3);
					if (Ifa<0)
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err25.IA[0]|=0x80;
					INT32U_BCD(Ib,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err25.IB[0],3);
					if (Ifb<0)
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err25.IB[0]|=0x80;
					INT32U_BCD(Ic,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err25.IC[0],3);
					if (Ifc<0)
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err25.IC[0]|=0x80;
					JDataFileInfo->ErcEvt.EC1++;
					JDataFileInfo->ErcEvt.EC1=JDataFileInfo->ErcEvt.EC1%256;
				}
				else
				{
					memset(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2],0,sizeof(ERC));
					JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err25.ERCNo=25;
					JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err25.len=17;
					INT32U_BCD(ts.Minute,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err25.Occur_Time.BCD01,1);
					INT32U_BCD(ts.Hour,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err25.Occur_Time.BCD02,1);
					INT32U_BCD(ts.Day,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err25.Occur_Time.BCD03,1);
					INT32U_BCD(ts.Month,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err25.Occur_Time.BCD04,1);
					INT32U_BCD(ts.Year,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err25.Occur_Time.BCD05,1);
					JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err25.ClNo[0]=(met+1)&0xff;
					JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err25.ClNo[1]=((met+1)>>8)&0xff;
					if (happ[i]&0b00010101)
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err25.ClNo[1]|=0b10000000;
					JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err25.Flag=Flag[i];
					INT32U_BCD(Ia,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err25.IA[0],3);
					if (Ifa<0)
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err25.IA[0]|=0x80;
					INT32U_BCD(Ib,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err25.IB[0],3);
					if (Ifb<0)
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err25.IB[0]|=0x80;
					INT32U_BCD(Ic,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err25.IC[0],3);
					if (Ifc<0)
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err25.IC[0]|=0x80;
					JDataFileInfo->ErcEvt.EC2++;
					JDataFileInfo->ErcEvt.EC2=JDataFileInfo->ErcEvt.EC2%256;
				}
//				memset(Temp_FilePath,0,60);
//				sprintf((char*)Temp_FilePath,"/nand/DataAlarm/alarm.dat");
//				SaveFile((char*)Temp_FilePath,&JDataFileInfo->ErcEvt,sizeof(ErcSave));
//				delay(50);
				JProgramInfo->CurrErc.Buff[0]=0;
				JProgramInfo->Para.ChangedJiZhongQiInfo = 2;
				SdPrint("\n\rCreateErr25\n\r")
//				JProgramInfo->FileSaveFlag.ercflag = 1;
			}
		}
	}
}

void CreateErr26(TS ts,int met)
{
	int CjqNo,MetNo,MetType,i,PS=0,SSS=0,SS=0,p=0,q=0;
	float PS1;
	INT8U Temp_FilePath[60], tempManyData[DataLenMax],Flag[2],happ[2],fd=0;
	for(i=0;i<2;i++)
	{
		Flag[i]=0;
		happ[i]=0;
	}

	if (JParamInfo3761->group2.f9.Flag[3] & 0x02)
	{
		CjqNo=JParamInfo3761->group2.f10[met].CjqNo-1;
		MetNo=JParamInfo3761->group2.f10[met].MeterNo;
		MetType = JParamInfo3761->group2.f10[met].Type;
		if (JParamInfo3761->group2.f10[met].Status!=1)
			return;
		if (JParamInfo3761->group2.f10[met].Type==0)
			return;
		memset(&smfile,0,sizeof(SMFiles));
		memset(Temp_FilePath,0,60);
		sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",met+1);
		if (access((char*)Temp_FilePath,0)!=0)
		{
			return;
		}
		ReadFile((char *) Temp_FilePath, &smfile,sizeof(SMFiles),JProgramInfo);
		//̨����Գ���ע��
//		if ((MetType == 9) || (MetType == 6))
//		{
//			fd=0;
//		}
//		else
		{
			fd=0;
			if(smfile.sm.CaijiQiNo==CjqNo && smfile.sm.MeterNo==MetNo)
			{
				fd=1;
				SSS=BCD_INT32(&JParamInfo3761->Point[met].f26.S_SS[0],3);
				SS=BCD_INT32(&JParamInfo3761->Point[met].f26.S_S[0],3);

				if(JParamInfo3761->group2.f10[met].ConnectType==1)
				{
					memset(tempManyData,0,sizeof(tempManyData));
					GetManyData(smfile.sm.datas,&tempManyData[0],0xb6,0x30);
					p=BCD_INT32(&tempManyData[0],3);
					memset(tempManyData,0,sizeof(tempManyData));
					GetManyData(smfile.sm.datas,&tempManyData[0],0xb6,0x40);
					q=BCD_INT32(&tempManyData[0],3);
					PS1=sqrt((p/10)*(p/10)+(q/10)*(q/10));
					PS1=PS1*10;
					PS=(INT32U)PS1;
				}
				else
				{
					memset(tempManyData,0,sizeof(tempManyData));
					GetManyData(smfile.sm.datas,&tempManyData[0],0x00,0x5f); //���ڹ���
					PS=BCD_INT32(&tempManyData[0],3);
				}
				fprintf(stderr,"many26 SSS=%d,SS=%d,PS=%d,p=%d,q=%d\n\r",SSS,SS,PS,p,q);

				//PS=1500;SSS=1600;SS=1200;
				if (!((JParamInfo3761->group2.f10[met].AlarmFlg[25]&0b01000001)==0b01000001))
				{
					if ((PS>SSS) && (SSS!=0))
					{
						Flag[0]|=0b01000001;
						happ[0]=1;
						JParamInfo3761->group2.f10[met].AlarmFlg[25]|=0b01000001;
					}
				}
				else
				{
					if ((PS<=SSS) && (SSS!=0))
						if ((SSS-PS)*1000/SSS >= BCD_INT32(&JParamInfo3761->Point[met].f26.S_SS_Renew[0],2))
						{
							Flag[0]|=0b01000001;
							happ[0]=2;
							JParamInfo3761->group2.f10[met].AlarmFlg[25]&=0b10111110;
						}
				}
				if (!((JParamInfo3761->group2.f10[met].AlarmFlg[25]&0b01000001)==0b01000001))
				{
					if (!((JParamInfo3761->group2.f10[met].AlarmFlg[25]&0b10000001)==0b10000001))
					{
						if ((PS>SS) && (SS!=0))
						{
							Flag[1]|=0b10000001;
							happ[1]=1;
							JParamInfo3761->group2.f10[met].AlarmFlg[25]|=0b10000001;
						}
					}
					else
					{
						if ((PS<=SS) && (SS != 0))
							if ((SS-PS)*1000/SS >= BCD_INT32(&JParamInfo3761->Point[met].f26.S_S_Renew[0],2))
							{
								Flag[1]|=0b01000001;
								happ[1]=2;
								JParamInfo3761->group2.f10[met].AlarmFlg[25]&=0b01111110;
							}
					}
				}
			}
			if (fd==1)
			{
				for(i=0;i<2;i++)
				if (happ[i])
				{
					JDataFileInfo->ErcEvt.ERCBiaoZhi[3]|=0b00000010;
					if ((JParamInfo3761->group2.f10[met].AlarmFlg[25]&0b11000000)==0x00)
						JDataFileInfo->ErcEvt.ERCBiaoZhi[3]&=0b11111101;
					JProgramInfo->CurrErc.Buff[0]=26;
					JProgramInfo->stateflags.ErcFlg=26;
					SdPrint("ErcNo=%d\n\r",26);
					if (JParamInfo3761->group2.f9.FlagStep[3] & 0x02) //��Ҫ�¼�
					{
						memset(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1],0,sizeof(ERC));
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err26.ERCNo=26;
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err26.len=14;
						INT32U_BCD(ts.Minute,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err26.Occur_Time.BCD01,1);
						INT32U_BCD(ts.Hour,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err26.Occur_Time.BCD02,1);
						INT32U_BCD(ts.Day,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err26.Occur_Time.BCD03,1);
						INT32U_BCD(ts.Month,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err26.Occur_Time.BCD04,1);
						INT32U_BCD(ts.Year,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err26.Occur_Time.BCD05,1);
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err26.ClNo[0]=(met+1)&0xff;
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err26.ClNo[1]=((met+1)>>8)&0xff;
						if (happ[i]==1)
							JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err26.ClNo[1]|=0b10000000;
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err26.Flag=Flag[i];
						INT32U_BCD(PS,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err26.Curr_S[0],3);
						if (Flag[2]&0b00100000)
							memcpy(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err26.S_SS[0],&JParamInfo3761->Point[met].f26.S_SS[0],3);
						else
							memcpy(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err26.S_SS[0],&JParamInfo3761->Point[met].f26.S_S[0],3);
						JDataFileInfo->ErcEvt.EC1++;
						JDataFileInfo->ErcEvt.EC1=JDataFileInfo->ErcEvt.EC1%256;
					}
					else
					{
						memset(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2],0,sizeof(ERC));
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err26.ERCNo=26;
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err26.len=14;
						INT32U_BCD(ts.Minute,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err26.Occur_Time.BCD01,1);
						INT32U_BCD(ts.Hour,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err26.Occur_Time.BCD02,1);
						INT32U_BCD(ts.Day,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err26.Occur_Time.BCD03,1);
						INT32U_BCD(ts.Month,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err26.Occur_Time.BCD04,1);
						INT32U_BCD(ts.Year,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err26.Occur_Time.BCD05,1);
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err26.ClNo[0]=(met+1)&0xff;
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err26.ClNo[1]=((met+1)>>8)&0xff;
						if (happ[i]==1)
							JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err26.ClNo[1]|=0b10000000;
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err26.Flag=Flag[i];
						INT32U_BCD(PS,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err26.Curr_S[0],3);
						if (Flag[2]&0b00100000)
							memcpy(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err26.S_SS[0],&JParamInfo3761->Point[met].f26.S_SS[0],3);
						else
							memcpy(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err26.S_SS[0],&JParamInfo3761->Point[met].f26.S_S[0],3);
						JDataFileInfo->ErcEvt.EC2++;
						JDataFileInfo->ErcEvt.EC2=JDataFileInfo->ErcEvt.EC2%256;
					}
//					memset(Temp_FilePath,0,60);
//					sprintf((char*)Temp_FilePath,"/nand/DataAlarm/alarm.dat");
//					SaveFile((char*)Temp_FilePath,&JDataFileInfo->ErcEvt,sizeof(ErcSave));
//					delay(50);
					JProgramInfo->CurrErc.Buff[0]=0;
					JProgramInfo->Para.ChangedJiZhongQiInfo = 2;
					SdPrint("\n\rCreateErr26\n\r")
//					JProgramInfo->FileSaveFlag.ercflag = 1;
				}
			}
		}
	}
}

void CreateErrOther(TS ts,int met)
{
	int CjqNo,MetNo,MetType,i,k;
	int Old_PDD=0,PDD=0;
	int pnnum=-1,pnold=-1,xlnum=-1,xlold=-1,GetSecCount=0,SecCount=0;
	int dxnum=-1,dxold=-1,synum=-1,syold=-1,dcsy=0;
	int dxan=-1,dxanold=-1,dxbn=-1,dxbnold=-1,dxcn=-1,dxcnold=-1;
	int flnold=-1,fln=-1,cbnold=-1,cbn=-1,mcnold=-1,mcn=-1,hgnold=-1,hgn=-1;
	int fln1=-1, flnold1=-1,mcn1=-1,mcnold1=-1,hgn1=-1,hgnold1=-1;
	int tdnold=-1,tdn=-1;
	INT8U Temp_FilePath[60], tempManyData[DataLenMax],Flag[7],happ[7],ff=0,fd=0;
	INT8U FlInfOld[12][30],FlInf[12][30];
	TS ts2;
	int j,m;
	int FlInf_flg=0,FlInfOld_flg=0;
	memset(&ts2, 0, sizeof(TS));
//	if (JParamInfo3761->group2.f10[met].Type==0) //fzh �������
//	{
//		return;
//	}

	for(i=0;i<12;i++)
	{
		memset(FlInfOld[i],0,30);
		memset(FlInf[i],0,30);
	}

	for(i=0;i<7;i++)
	{
		Flag[i]=0;
		happ[i]=0;
	}
	//9��14��ȥ����Err8�¼��ó�����CreateErr8��������
//	if (((JParamInfo3761->group2.f9.Flag[0] & 0x80) || (JParamInfo3761->group2.f9.Flag[1] & 0x18) ||
//			(JParamInfo3761->group2.f9.Flag[3] & 0x1C))) //8 12 13 27-29
	if ((JParamInfo3761->group2.f9.Flag[1] & 0x18) || (JParamInfo3761->group2.f9.Flag[3] & 0x1C)) //12 13 27-29

	{
		CjqNo=JParamInfo3761->group2.f10[met].CjqNo-1;
		MetNo=JParamInfo3761->group2.f10[met].MeterNo;
		MetType = JParamInfo3761->group2.f10[met].Type;
		if (JParamInfo3761->group2.f10[met].Status!=1)
			return;
		if (JParamInfo3761->group2.f10[met].Type==0)
			return;
		memset(Temp_FilePath,0,60);
		memset(&smfileold,0,sizeof(SMFiles));
		memset(&smfile,0,sizeof(SMFiles));
		sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/last.dat",met+1);
		if (access((char*)Temp_FilePath,0)!=0)
		{
			return;
		}
		ReadFile((char *) Temp_FilePath, &smfileold,sizeof(SMFiles),JProgramInfo);
		memset(Temp_FilePath,0,60);
		sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",met+1);
		if (access((char*)Temp_FilePath,0)!=0)
		{
			return;
		}
		ReadFile((char *) Temp_FilePath, &smfile,sizeof(SMFiles),JProgramInfo);
		if ((MetType == 9) || (MetType == 6)) //fzh�������
		{
			if ((JParamInfo3761->group2.f9.Flag[0] & 0x80) ||

					(JParamInfo3761->group2.f9.Flag[1] & 0x10) ||
					(JParamInfo3761->group2.f9.Flag[3] & 0x1C))
			{
				//8 ���ܱ�������� 13 ���ܱ�������Ϣ  27 ʾ���½� 28 ����������  29 ����
				ff=0;
				if(smfileold.sm.CaijiQiNo==CjqNo&&smfileold.sm.MeterNo==MetNo)
				{
					memset(tempManyData,0,sizeof(tempManyData));
					GetManyData(smfileold.sm.datas,&tempManyData[0],0x90,0x10);//�����й�
					Old_PDD=BCD_INT32(&tempManyData[0],4);
					memset(tempManyData,0,sizeof(tempManyData));
					if (GetManyData(smfileold.sm.datas,&tempManyData[0],0xb2,0x12))//��̴���
						pnold=BCD_INT32(&tempManyData[0],3);
					if (JParamInfo3761->group2.f10[met].ConnectType==1)//97��Լ
					{
						memset(tempManyData,0,sizeof(tempManyData));
						if (GetManyData(smfileold.sm.datas,&tempManyData[0],0xc3,0x12))
							flnold=BCD_INT32(&tempManyData[0],3);
						//else flnold=0;
						memset(tempManyData,0,sizeof(tempManyData));
						if (GetManyData(smfileold.sm.datas,&tempManyData[0],0xc3,0x13))
							//flnold+=BCD_INT32(&tempManyData[0],3);
							flnold1=BCD_INT32(&tempManyData[0],3);
						memset(tempManyData,0,sizeof(tempManyData));
						if (GetManyData(smfileold.sm.datas,&tempManyData[0],0xc1,0x17))
							cbnold=BCD_INT32(&tempManyData[0],2);
					}
					else
					{
						memset(tempManyData,0,sizeof(tempManyData));
						if (GetManyData(smfileold.sm.datas,&tempManyData[0],0x00,0x56))//����ʱ�α������
							flnold=BCD_INT32(&tempManyData[0],3);
						memset(tempManyData,0,sizeof(tempManyData));
						if (GetManyData(smfileold.sm.datas,&tempManyData[0],0xff,0x74))//�����ձ������
							cbnold=BCD_INT32(&tempManyData[0],3);
					}
					memset(tempManyData,0,sizeof(tempManyData));
					if (GetManyData(smfileold.sm.datas,&tempManyData[0],0xc0,0x30))//�й�����
						mcnold=BCD_INT32(&tempManyData[0],3);
					memset(tempManyData,0,sizeof(tempManyData));
					if (GetManyData(smfileold.sm.datas,&tempManyData[0],0xc0,0x31))//�޹�����
						//mcnold+=BCD_INT32(&tempManyData[0],3);
						mcnold1=BCD_INT32(&tempManyData[0],3);
					memset(tempManyData,0,sizeof(tempManyData));
					if (GetManyData(smfileold.sm.datas,&tempManyData[0],0xff,0x76))//��ѹ����������
						hgnold=BCD_INT32(&tempManyData[0],3);
					memset(tempManyData,0,sizeof(tempManyData));
					if (GetManyData(smfileold.sm.datas,&tempManyData[0],0xff,0x77))//��������������
						//hgnold+=BCD_INT32(&tempManyData[0],3);
						hgnold1=BCD_INT32(&tempManyData[0],3);
					memset(tempManyData,0,sizeof(tempManyData));
					if (GetManyData(smfileold.sm.datas,&tempManyData[0],0xff,0x50))//ʧѹ�ܴ���
						syold=BCD_INT32(&tempManyData[0],3);
					memset(tempManyData,0,sizeof(tempManyData));
					if (GetManyData(smfileold.sm.datas,&tempManyData[0],0xff,0x70))//ͣ�����
						tdnold=BCD_INT32(&tempManyData[0],3);

					memset(tempManyData,0,sizeof(tempManyData));
					if(GetManyData(smfileold.sm.datas,&tempManyData[0],0xb2,0x13)) //�����������
						xlold=BCD_INT32(&tempManyData[0],3);
					memset(tempManyData,0,sizeof(tempManyData));
					if(GetManyData(smfileold.sm.datas,&tempManyData[0],0xb3,0x11)) //A��������
						dxanold=BCD_INT32(&tempManyData[0],3);
					memset(tempManyData,0,sizeof(tempManyData));
					if(GetManyData(smfileold.sm.datas,&tempManyData[0],0xb3,0x12)) //B��������
						dxbnold=BCD_INT32(&tempManyData[0],3);
					memset(tempManyData,0,sizeof(tempManyData));
					if(GetManyData(smfileold.sm.datas,&tempManyData[0],0xb3,0x13)) //C��������
						dxcnold=BCD_INT32(&tempManyData[0],3);
					dxold=dxanold+dxbnold+dxcnold;


					SdPrint("sigoth Old PDD=%d,pn=%d,fln=%d,cbn=%d,mcn=%d,hgn=%d,sy=%d,tdn=%d\n\r",
							Old_PDD,pnold,flnold,cbnold,mcnold,hgnold,syold,tdnold);
					ff=1;
				}
			}
			fd=0;
			if(smfile.sm.CaijiQiNo==CjqNo&&smfile.sm.MeterNo==MetNo)
			{
				fd=1;
				if (JParamInfo3761->group2.f9.Flag[1] & 0x08) //12 ���ܱ�ʱ�䳬��
				{
					memset(tempManyData,0,sizeof(tempManyData));
					GetManyData(smfile.sm.datas,&tempManyData[0],0xc0,0x10);
					ts2.Day=BCD_INT32(&tempManyData[1],1);
					ts2.Month=BCD_INT32(&tempManyData[2],1);
					ts2.Year=BCD_INT32(&tempManyData[3],1);
					memset(tempManyData,0,sizeof(tempManyData));
					GetManyData(smfile.sm.datas,&tempManyData[0],0xc0,0x11);
					ts2.Sec=BCD_INT32(&tempManyData[0],1);
					ts2.Minute=BCD_INT32(&tempManyData[1],1);
					ts2.Hour=BCD_INT32(&tempManyData[2],1);
					SecCount=((ts2.Year%100)*525600)+(ts2.Month*44640)+(ts2.Day*1440)+(ts2.Hour*60)+ts2.Minute;//���������
					GetSecCount=((smfile.ts.Year%100)*525600)+(smfile.ts.Month*44640)+(smfile.ts.Day*1440)+(smfile.ts.Hour*60)+smfile.ts.Minute;//����������
					SdPrint("metertime: %d-%d-%d %d:%d SecConut=%d, chaobiaotime(jzq biaozhun): %d-%d-%d %d:%d GetSecCount=%d\n\r",
							ts2.Year,ts2.Month,ts2.Day,ts2.Hour,ts2.Minute,SecCount,
							smfile.ts.Year,smfile.ts.Month,smfile.ts.Day,smfile.ts.Hour,smfile.ts.Minute,GetSecCount);
				}

				if ((JParamInfo3761->group2.f9.Flag[0] & 0x80) || (JParamInfo3761->group2.f9.Flag[1] & 0x10) || (JParamInfo3761->group2.f9.Flag[3] & 0x1C))
				{//8 ���ܱ��������  13 ���ܱ�����  27 ʾ���½� 28 ����������  29 ����
					memset(tempManyData,0,sizeof(tempManyData));
					GetManyData(smfile.sm.datas,&tempManyData[0],0x90,0x10); //�����й���
					PDD=BCD_INT32(&tempManyData[0],4);
					memset(tempManyData,0,sizeof(tempManyData));
					if (GetManyData(smfile.sm.datas,&tempManyData[0],0xb2,0x12)) //��̴���
						pnnum=BCD_INT32(&tempManyData[0],3);
					memset(tempManyData,0,sizeof(tempManyData));
					if (GetManyData(smfile.sm.datas,&tempManyData[0],0xc0,0x20))  //���ʧѹ
						dcsy=tempManyData[0]&0x0C;
					if (JParamInfo3761->group2.f10[met].ConnectType==1)
					{
						memset(tempManyData,0,sizeof(tempManyData));
						if (GetManyData(smfile.sm.datas,&tempManyData[0],0xc3,0x12))
							fln=BCD_INT32(&tempManyData[0],3);
						//else fln=0;
						memset(tempManyData,0,sizeof(tempManyData));
						if (GetManyData(smfile.sm.datas,&tempManyData[0],0xc3,0x13))
							//fln+=BCD_INT32(&tempManyData[0],3);
							fln1=BCD_INT32(&tempManyData[0],3);
						memset(tempManyData,0,sizeof(tempManyData));
						if (GetManyData(smfile.sm.datas,&tempManyData[0],0xc1,0x17))
							cbn=BCD_INT32(&tempManyData[0],2);
					}
					else
					{
						memset(tempManyData,0,sizeof(tempManyData));
						if (GetManyData(smfile.sm.datas,&tempManyData[0],0x00,0x56))//����ʱ�α������
							fln=BCD_INT32(&tempManyData[0],3);
						memset(tempManyData,0,sizeof(tempManyData));
						if (GetManyData(smfile.sm.datas,&tempManyData[0],0xff,0x74))//�����ձ������
							cbn=BCD_INT32(&tempManyData[0],3);
					}

					memset(tempManyData,0,sizeof(tempManyData));
					if (GetManyData(smfile.sm.datas,&tempManyData[0],0xc0,0x30))//�й�����
						mcn=BCD_INT32(&tempManyData[0],3);
					memset(tempManyData,0,sizeof(tempManyData));
					if (GetManyData(smfile.sm.datas,&tempManyData[0],0xc0,0x31))//�޹�����
						//mcn+=BCD_INT32(&tempManyData[0],3);
						mcn1=BCD_INT32(&tempManyData[0],3);
					memset(tempManyData,0,sizeof(tempManyData));
					if(GetManyData(smfile.sm.datas,&tempManyData[0],0xff,0x76))//��ѹ����������
						hgn=BCD_INT32(&tempManyData[0],3);
					memset(tempManyData,0,sizeof(tempManyData));
					if (GetManyData(smfile.sm.datas,&tempManyData[0],0xff,0x77))//��������������
						//hgn+=BCD_INT32(&tempManyData[0],3);
						hgn1=BCD_INT32(&tempManyData[0],3);
					memset(tempManyData,0,sizeof(tempManyData));
					if(GetManyData(smfile.sm.datas,&tempManyData[0],0xff,0x50))//ʧѹ�ܴ���
						synum=BCD_INT32(&tempManyData[0],3);
					memset(tempManyData,0,sizeof(tempManyData));
					if(GetManyData(smfile.sm.datas,&tempManyData[0],0xff,0x70))//ͣ�����
						tdn=BCD_INT32(&tempManyData[0],4);
					memset(tempManyData,0,sizeof(tempManyData));
					if(GetManyData(smfile.sm.datas,&tempManyData[0],0xb2,0x13))
						xlnum=BCD_INT32(&tempManyData[0],3);  //��������
					memset(tempManyData,0,sizeof(tempManyData));
					if(GetManyData(smfile.sm.datas,&tempManyData[0],0xb3,0x11))
						dxan=BCD_INT32(&tempManyData[0],3);  //A�������
					memset(tempManyData,0,sizeof(tempManyData));
					if(GetManyData(smfile.sm.datas,&tempManyData[0],0xb3,0x12))
						dxbn=BCD_INT32(&tempManyData[0],3); //B�������
					memset(tempManyData,0,sizeof(tempManyData));
					if(GetManyData(smfile.sm.datas,&tempManyData[0],0xb3,0x13))
						dxcn=BCD_INT32(&tempManyData[0],3); //C�������
					dxnum=dxan+dxbn+dxcn;
					SdPrint("sig new PDD=%d,pn=%d,fln=%d,cbn=%d,mcn=%d,hgn=%d,sy=%d,tdn=%d,dcsy=%d\n\r",
							PDD,pnnum,fln,cbn,mcn,hgn,synum,tdn,dcsy);
				}
			}
		}
		else
		{
			if ((JParamInfo3761->group2.f9.Flag[0] & 0x80) || (JParamInfo3761->group2.f9.Flag[1] & 0x10) || (JParamInfo3761->group2.f9.Flag[3] & 0x1C))
			{//8 ���ܱ�������� 13 ���ܱ�����   27 ʾ���½� 28 ����������  29 ����
				ff=0;
				if(smfileold.sm.CaijiQiNo==CjqNo&&smfileold.sm.MeterNo==MetNo)
				{
					memset(tempManyData,0,sizeof(tempManyData));
					GetManyData(smfileold.sm.datas,&tempManyData[0],0x90,0x1f); //�����й���
					Old_PDD=BCD_INT32(&tempManyData[0],4);
					memset(tempManyData,0,sizeof(tempManyData));
					if(GetManyData(smfileold.sm.datas,&tempManyData[0],0xb2,0x12)) //��̴���
						pnold=BCD_INT32(&tempManyData[0],3);
					memset(tempManyData,0,sizeof(tempManyData));
					if(GetManyData(smfileold.sm.datas,&tempManyData[0],0xb2,0x13)) //�����������
						xlold=BCD_INT32(&tempManyData[0],3);
					memset(tempManyData,0,sizeof(tempManyData));
					if(GetManyData(smfileold.sm.datas,&tempManyData[0],0xb3,0x11)) //A��������
						dxanold=BCD_INT32(&tempManyData[0],3);
					memset(tempManyData,0,sizeof(tempManyData));
					if(GetManyData(smfileold.sm.datas,&tempManyData[0],0xb3,0x12)) //B��������
						dxbnold=BCD_INT32(&tempManyData[0],3);
					memset(tempManyData,0,sizeof(tempManyData));
					if(GetManyData(smfileold.sm.datas,&tempManyData[0],0xb3,0x13)) //C��������
						dxcnold=BCD_INT32(&tempManyData[0],3);
					dxold=dxanold+dxbnold+dxcnold;
					//songjian
//					if (JParamInfo3761->group2.f10[met].ConnectType==1)
//					{
//						memset(tempManyData,0,sizeof(tempManyData));
//						if(GetManyData(smfileold.sm.datas,&tempManyData[0],0xb3,0x1f))
//						{
//							//dxold=BCD_INT32(&tempManyData[0],3);
//							dxanold=BCD_INT32(&tempManyData[0],3);
//							dxbnold=BCD_INT32(&tempManyData[2],3);
//							dxcnold=BCD_INT32(&tempManyData[4],3);
//							dxold=dxanold+dxbnold+dxcnold;
//						}
//					}
					memset(tempManyData,0,sizeof(tempManyData));
					if(GetManyData(smfileold.sm.datas,&tempManyData[0],0xff,0x50)) //ʧѹ����
						syold=BCD_INT32(&tempManyData[0],3);
					if (JParamInfo3761->group2.f10[met].ConnectType==1)
					{
						memset(tempManyData,0,sizeof(tempManyData));
						if(GetManyData(smfileold.sm.datas,&tempManyData[0],0xc3,0x1f))
							memcpy(FlInfOld[0],&tempManyData[0],30);
						memset(tempManyData,0,sizeof(tempManyData));
						if(GetManyData(smfileold.sm.datas,&tempManyData[0],0xc3,0x2f))
							memcpy(FlInfOld[1],&tempManyData[0],30);
						memset(tempManyData,0,sizeof(tempManyData));
						if(GetManyData(smfileold.sm.datas,&tempManyData[0],0xc3,0x3f))
							memcpy(FlInfOld[2],&tempManyData[0],30);
						memset(tempManyData,0,sizeof(tempManyData));
						if(GetManyData(smfileold.sm.datas,&tempManyData[0],0xc3,0x4f))
							memcpy(FlInfOld[3],&tempManyData[0],30);
						memset(tempManyData,0,sizeof(tempManyData));
						if(GetManyData(smfileold.sm.datas,&tempManyData[0],0xc3,0x5f))
							memcpy(FlInfOld[4],&tempManyData[0],30);
						memset(tempManyData,0,sizeof(tempManyData));
						if(GetManyData(smfileold.sm.datas,&tempManyData[0],0xc3,0x6f))
							memcpy(FlInfOld[5],&tempManyData[0],30);
						memset(tempManyData,0,sizeof(tempManyData));
						if(GetManyData(smfileold.sm.datas,&tempManyData[0],0xc3,0x7f))
							memcpy(FlInfOld[6],&tempManyData[0],30);
						memset(tempManyData,0,sizeof(tempManyData));
						if(GetManyData(smfileold.sm.datas,&tempManyData[0],0xc3,0x8f))
							memcpy(FlInfOld[7],&tempManyData[0],30);
						memset(tempManyData,0,sizeof(tempManyData));
						if(GetManyData(smfileold.sm.datas,&tempManyData[0],0xc3,0x9f))
							memcpy(FlInfOld[8],&tempManyData[0],30);
						memset(tempManyData,0,sizeof(tempManyData));
						if(GetManyData(smfileold.sm.datas,&tempManyData[0],0xc3,0xAf))
							memcpy(FlInfOld[9],&tempManyData[0],30);
						memset(tempManyData,0,sizeof(tempManyData));
						if(GetManyData(smfileold.sm.datas,&tempManyData[0],0xc4,0x1f))
							memcpy(FlInfOld[10],&tempManyData[0],30);
						memset(tempManyData,0,sizeof(tempManyData));
						if(GetManyData(smfileold.sm.datas,&tempManyData[0],0xc4,0x1e))
							memcpy(FlInfOld[11],&tempManyData[0],30);
						memset(tempManyData,0,sizeof(tempManyData));
						if(GetManyData(smfileold.sm.datas,&tempManyData[0],0xc1,0x17))//�����ձ������
							cbnold=BCD_INT32(&tempManyData[0],2);
						flnold=1;
					}
					else
					{
						memset(tempManyData,0,sizeof(tempManyData));
						if(GetManyData(smfileold.sm.datas,&tempManyData[0],0x00,0x56))//����ʱ�α������
							flnold=BCD_INT32(&tempManyData[0],3);
						memset(tempManyData,0,sizeof(tempManyData));
						if(GetManyData(smfileold.sm.datas,&tempManyData[0],0xff,0x74))//�����ձ������
							cbnold=BCD_INT32(&tempManyData[0],3);
					}
					memset(tempManyData,0,sizeof(tempManyData));
					if(GetManyData(smfileold.sm.datas,&tempManyData[0],0xc0,0x30))//�й�����
						mcnold=BCD_INT32(&tempManyData[0],3);
					memset(tempManyData,0,sizeof(tempManyData));
					if(GetManyData(smfileold.sm.datas,&tempManyData[0],0xc0,0x31))//�޹�����
						//mcnold+=BCD_INT32(&tempManyData[0],3);
						mcnold1=BCD_INT32(&tempManyData[0],3);
					memset(tempManyData,0,sizeof(tempManyData));
					if(GetManyData(smfileold.sm.datas,&tempManyData[0],0xff,0x76))//��ѹ����������
						hgnold=BCD_INT32(&tempManyData[0],3);
					memset(tempManyData,0,sizeof(tempManyData));
					if(GetManyData(smfileold.sm.datas,&tempManyData[0],0xff,0x77))//��������������
						//hgnold+=BCD_INT32(&tempManyData[0],3);
						hgnold1=BCD_INT32(&tempManyData[0],3);
					memset(tempManyData,0,sizeof(tempManyData));
					if(GetManyData(smfileold.sm.datas,&tempManyData[0],0xff,0x70))//�����ܴ���
						tdnold=BCD_INT32(&tempManyData[0],3);
					SdPrint("manyoth Old PDD=%d,pn=%d,xl=%d,fln=%d,cbn=%d,mcn=%d,hgn=%d,sy=%d,tdn=%d\n\r",
							Old_PDD,pnold,xlold,flnold,cbnold,mcnold,hgnold,syold,tdnold);
					SdPrint("manyoth old dxan=%d,dxbn=%d,dxcn=%d,dx=%d\n\r",
							dxanold,dxbnold,dxcnold,dxold);
					ff=1;
				}
			}
			fd=0;
			if(smfile.sm.CaijiQiNo==CjqNo&&smfile.sm.MeterNo==MetNo)
			{
				fd = 1;
				if (JParamInfo3761->group2.f9.Flag[1] & 0x08) //12 ���ܱ�ʱ�䳬��
				{
					memset(tempManyData,0,sizeof(tempManyData));
					GetManyData(smfile.sm.datas,&tempManyData[0],0xc0,0x10);
					ts2.Day=BCD_INT32(&tempManyData[1],1);
					ts2.Month=BCD_INT32(&tempManyData[2],1);
					ts2.Year=BCD_INT32(&tempManyData[3],1);
					memset(tempManyData,0,sizeof(tempManyData));
					GetManyData(smfile.sm.datas,&tempManyData[0],0xc0,0x11);
					ts2.Sec=BCD_INT32(&tempManyData[0],1);
					ts2.Minute=BCD_INT32(&tempManyData[1],1);
					ts2.Hour=BCD_INT32(&tempManyData[2],1);
					SecCount=((ts2.Year%100)*525600)+(ts2.Month*44640)+(ts2.Day*1440)+(ts2.Hour*60)+ts2.Minute; //���������
					GetSecCount=((smfile.ts.Year%100)*525600)+(smfile.ts.Month*44640)+(smfile.ts.Day*1440)+(smfile.ts.Hour*60)+smfile.ts.Minute;//����������
					printf("manyoth %d-%d-%d %d:%d SecConut=%d,%d-%d-%d %d:%d GetSecCount=%d\n\r",
							ts2.Year,ts2.Month,ts2.Day,ts2.Hour,ts2.Minute,SecCount,
							smfile.ts.Year,smfile.ts.Month,smfile.ts.Day,smfile.ts.Hour,smfile.ts.Minute,GetSecCount);
				}
				if ((JParamInfo3761->group2.f9.Flag[0] & 0x80) || (JParamInfo3761->group2.f9.Flag[1] & 0x10) || (JParamInfo3761->group2.f9.Flag[3] & 0x1C))
				{ //8 ���ܱ�������� 13 ���ܱ�����  27 ʾ���½� 28 ����������  29 ����
					memset(tempManyData,0,sizeof(tempManyData));
					GetManyData(smfile.sm.datas,&tempManyData[0],0x90,0x1f);
					PDD=BCD_INT32(&tempManyData[0],4);  //�����й���
					memset(tempManyData,0,sizeof(tempManyData));
					if(GetManyData(smfile.sm.datas,&tempManyData[0],0xb2,0x12))
						pnnum=BCD_INT32(&tempManyData[0],3);  //��̴���
					memset(tempManyData,0,sizeof(tempManyData));
					if(GetManyData(smfile.sm.datas,&tempManyData[0],0xb2,0x13))
						xlnum=BCD_INT32(&tempManyData[0],3);  //��������
					memset(tempManyData,0,sizeof(tempManyData));
					if(GetManyData(smfile.sm.datas,&tempManyData[0],0xb3,0x11))
						dxan=BCD_INT32(&tempManyData[0],3);  //A�������
					memset(tempManyData,0,sizeof(tempManyData));
					if(GetManyData(smfile.sm.datas,&tempManyData[0],0xb3,0x12))
						dxbn=BCD_INT32(&tempManyData[0],3); //B�������
					memset(tempManyData,0,sizeof(tempManyData));
					if(GetManyData(smfile.sm.datas,&tempManyData[0],0xb3,0x13))
						dxcn=BCD_INT32(&tempManyData[0],3); //C�������
					dxnum=dxan+dxbn+dxcn;
					//songjian
//					if (JParamInfo3761->group2.f10[met].ConnectType==1)
//					{
//						memset(tempManyData,0,sizeof(tempManyData));
//						if(GetManyData(smfile.sm.datas,&tempManyData[0],0xb3,0x1f))
//							dxnum=BCD_INT32(&tempManyData[0],3);
//					}
					memset(tempManyData,0,sizeof(tempManyData));
					if(GetManyData(smfile.sm.datas,&tempManyData[0],0xff,0x50))
						synum=BCD_INT32(&tempManyData[0],3);  //ʧѹ����
					memset(tempManyData,0,sizeof(tempManyData));
					if(GetManyData(smfile.sm.datas,&tempManyData[0],0xc0,0x20))
						dcsy=tempManyData[0]&0x0C;           //���ʧѹ

					if (JParamInfo3761->group2.f10[met].ConnectType==1)
					{
						memset(tempManyData,0,sizeof(tempManyData));
						if(GetManyData(smfile.sm.datas,&tempManyData[0],0xc3,0x1f))
							memcpy(FlInf[0],&tempManyData[0],30);
						memset(tempManyData,0,sizeof(tempManyData));
						if(GetManyData(smfile.sm.datas,&tempManyData[0],0xc3,0x2f))
							memcpy(FlInf[1],&tempManyData[0],30);
						memset(tempManyData,0,sizeof(tempManyData));
						if(GetManyData(smfile.sm.datas,&tempManyData[0],0xc3,0x3f))
							memcpy(FlInf[2],&tempManyData[0],30);
						memset(tempManyData,0,sizeof(tempManyData));
						if(GetManyData(smfile.sm.datas,&tempManyData[0],0xc3,0x4f))
							memcpy(FlInf[3],&tempManyData[0],30);
						memset(tempManyData,0,sizeof(tempManyData));
						if(GetManyData(smfile.sm.datas,&tempManyData[0],0xc3,0x5f))
							memcpy(FlInf[4],&tempManyData[0],30);
						memset(tempManyData,0,sizeof(tempManyData));
						if(GetManyData(smfile.sm.datas,&tempManyData[0],0xc3,0x6f))
							memcpy(FlInf[5],&tempManyData[0],30);
						memset(tempManyData,0,sizeof(tempManyData));
						if(GetManyData(smfile.sm.datas,&tempManyData[0],0xc3,0x7f))
							memcpy(FlInf[6],&tempManyData[0],30);
						memset(tempManyData,0,sizeof(tempManyData));
						if(GetManyData(smfile.sm.datas,&tempManyData[0],0xc3,0x8f))
							memcpy(FlInf[7],&tempManyData[0],30);
						memset(tempManyData,0,sizeof(tempManyData));
						if(GetManyData(smfile.sm.datas,&tempManyData[0],0xc3,0x9f))
							memcpy(FlInf[8],&tempManyData[0],30);
						memset(tempManyData,0,sizeof(tempManyData));
						if(GetManyData(smfile.sm.datas,&tempManyData[0],0xc3,0xAf))
							memcpy(FlInf[9],&tempManyData[0],30);
						memset(tempManyData,0,sizeof(tempManyData));
						if(GetManyData(smfile.sm.datas,&tempManyData[0],0xc4,0x1f))
							memcpy(FlInf[10],&tempManyData[0],30);
						memset(tempManyData,0,sizeof(tempManyData));
						if(GetManyData(smfile.sm.datas,&tempManyData[0],0xc4,0x1e))
							memcpy(FlInf[11],&tempManyData[0],30);
						fln=1;
						for(k=0;k<12;k++)
						{
							if (memcmp(FlInfOld[k],FlInf[k],30)!=0)
							{
								printf("\n FlInf_flg=%d FlInfOld_flg=%d\n",FlInf_flg, FlInfOld_flg);
								for(j=0;j<30;j++)//songjian
								{
									if(FlInf[k][j]!=0)
										FlInf_flg=1;
								}
								for(j=0;j<30;j++)
								{
									if(FlInfOld[k][j]!=0)
										FlInfOld_flg=1;
								}
								if((FlInf_flg==1) && (FlInfOld_flg==1))
								{
									printf("\n FlInf_flg= %d\n",FlInf_flg);
									for(m=0;(m<DataLenMax && m<30);m++)
									{
										printf("%02x ",FlInf[k][m]);
									}
									printf("\n FlInfOld_flg=%d \n",FlInfOld_flg);
									for(m=0;(m<DataLenMax && m<30);m++)
									{
										printf("%02x ",FlInfOld[k][m]);
									}
									FlInf_flg = 0;
									FlInfOld_flg = 0;
									fln=2;
									break;
								}
							}
						}

						memset(tempManyData,0,sizeof(tempManyData));
						if(GetManyData(smfile.sm.datas,&tempManyData[0],0xc1,0x17))//�����ձ������
							cbn=BCD_INT32(&tempManyData[0],2);
					}
					else
					{
						memset(tempManyData,0,sizeof(tempManyData));
						if(GetManyData(smfile.sm.datas,&tempManyData[0],0x00,0x56))//����ʱ�α������
							fln=BCD_INT32(&tempManyData[0],3);
						memset(tempManyData,0,sizeof(tempManyData));
						if(GetManyData(smfile.sm.datas,&tempManyData[0],0xff,0x74))//�����ձ������
							cbn=BCD_INT32(&tempManyData[0],3);
					}
					memset(tempManyData,0,sizeof(tempManyData));
					if(GetManyData(smfile.sm.datas,&tempManyData[0],0xc0,0x30))//�й�����
						mcn=BCD_INT32(&tempManyData[0],3);
					memset(tempManyData,0,sizeof(tempManyData));
					if(GetManyData(smfile.sm.datas,&tempManyData[0],0xc0,0x31))//�޹�����
						//mcn+=BCD_INT32(&tempManyData[0],3);
						mcn1=BCD_INT32(&tempManyData[0],3);
					memset(tempManyData,0,sizeof(tempManyData));
					if(GetManyData(smfile.sm.datas,&tempManyData[0],0xff,0x76))//��ѹ����������
						hgn=BCD_INT32(&tempManyData[0],3);
					memset(tempManyData,0,sizeof(tempManyData));
					if(GetManyData(smfile.sm.datas,&tempManyData[0],0xff,0x77))//��������������
						//hgn+=BCD_INT32(&tempManyData[0],3);
						hgn1=BCD_INT32(&tempManyData[0],3);
					memset(tempManyData,0,sizeof(tempManyData));
					if(GetManyData(smfile.sm.datas,&tempManyData[0],0xff,0x70))//ͣ�����
						tdn=BCD_INT32(&tempManyData[0],3);
					SdPrint("manyoth new PDD=%d,pn=%d,xl=%d,fln=%d,cbn=%d,mcn=%d,hgn=%d,sy=%d,tdn=%d,dcsy=%d\n\r",
							PDD,pnnum,xlnum,fln,cbn,mcn,hgn,synum,tdn,dcsy);
					SdPrint("manyoth new dxan=%d,dxbn=%d,dxcn=%d,dx=%d\n\r",
							dxan,dxbn,dxcn,dxnum);
				}
			}
		}
#if 0		//9��14��ȥ����Err8�¼��ó�����CreateErr8��������
		if (JParamInfo3761->group2.f9.Flag[0] & 0x80) //8 ���ܱ��������
		{
	//		printf("\nff %x fd %x pnnum %x  pnold %x xlnum %x xlold %x fln %x flnold %x cbn %x cbnold %x mcn %x mcnold %x hgn %x hgnold %x JParamInfo3761->group2.f10[met].AlarmFlg[7] %x\n",
	//				ff , fd ,pnnum, pnold, xlnum , xlold , fln , flnold , cbn , cbnold , mcn , mcnold , hgn , hgnold , JParamInfo3761->group2.f10[met].AlarmFlg[7]);
			if ((ff==1) && (fd==1))
			{
				//songjian
//				if (((pnnum>pnold) && (pnold>=0) && (!(JParamInfo3761->group2.f10[met].AlarmFlg[7]&0b00000010))) ||
//						((xlnum > xlold)&& (xlold>=0) && (!(JParamInfo3761->group2.f10[met].AlarmFlg[7]&0b00100000))) ||
//						((fln > flnold)&& (flnold>=0) && (!(JParamInfo3761->group2.f10[met].AlarmFlg[7]&0b00000001))) ||
//						((cbn > cbnold)&& (cbnold>=0) && (!(JParamInfo3761->group2.f10[met].AlarmFlg[7]&0b00000100))) ||
//						((mcn > mcnold)&& (mcnold>=0) && (!(JParamInfo3761->group2.f10[met].AlarmFlg[7]&0b00001000))) ||
//						((hgn > hgnold)&& (hgnold>=0) && (!(JParamInfo3761->group2.f10[met].AlarmFlg[7]&0b00010000))))
//				if (((pnnum != pnold) && (pnold>=0) && (pnnum>=0)) || ((xlnum != xlold)&& (xlold>=0) && (xlnum>=0)) ||
//					((fln != flnold)&& (flnold>=0) && (fln>=0)) || ((fln1 != flnold1)&& (flnold1>=0) && (fln1>=0)) ||
//					((cbn != cbnold)&& (cbnold>=0) && (cbn>=0)) ||	((mcn != mcnold)&& (mcnold>=0) && (mcn>=0)) ||
//					((mcn1 != mcnold1)&& (mcnold1>=0) && (mcn1>=0))||	((hgn != hgnold)&& (hgnold>=0) && (hgn>=0)) ||
//					((hgn1 != hgnold1)&& (hgnold1>=0) && (hgn1>=0)) )
				if (((pnnum != pnold) && (pnold>=0)) || ((xlnum != xlold)&& (xlold>=0) ) ||
					((fln != flnold)&& (flnold>=0) ) || ((fln1 != flnold1)&& (flnold1>=0) ) ||
					((cbn != cbnold)&& (cbnold>=0) ) ||	((mcn != mcnold)&& (mcnold>=0) ) ||
					((mcn1 != mcnold1)&& (mcnold1>=0))||	((hgn != hgnold)&& (hgnold>=0)) ||
					((hgn1 != hgnold1)&& (hgnold1>=0) ) )
				{
					printf("\n ERC8  ���ܱ�������� !!!!!\n");
					JDataFileInfo->ErcEvt.ERCBiaoZhi[0]|=0b10000000;
					JProgramInfo->CurrErc.Buff[0]=8;
					JProgramInfo->stateflags.ErcFlg=8;
					SdPrint("ErcNo=%d\n\r",8);
					if (JParamInfo3761->group2.f9.FlagStep[0] & 0x80) //��Ҫ�¼�	//0x08
					{
						memset(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1],0,sizeof(ERC));
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err8.ERCNo=8;
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err8.len=8;
						INT32U_BCD(ts.Minute,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err8.Occur_Time.BCD01,1);
						INT32U_BCD(ts.Hour,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err8.Occur_Time.BCD02,1);
						INT32U_BCD(ts.Day,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err8.Occur_Time.BCD03,1);
						INT32U_BCD(ts.Month,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err8.Occur_Time.BCD04,1);
						INT32U_BCD(ts.Year,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err8.Occur_Time.BCD05,1);
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err8.ClNo[0]=(met+1)&0xff;
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err8.ClNo[1]=((met+1)>>8)&0xff;
						//JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err8.ClNo[1]|=0b10000000;
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err8.BiaoZhi=0x00;
						if (((fln != flnold)&& (flnold>=0) && (fln>=0)) || ((fln1 != flnold1)&& (flnold1>=0) && (fln1>=0)))
							JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err8.BiaoZhi|=0b00000001;
						if ((pnnum!=pnold) && (pnold>=0) && (pnnum>=9)) //��̴����仯
							JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err8.BiaoZhi|=0b00000010;
						if ((cbn != cbnold)&& (cbnold>=0) && (cbn>=0))
							JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err8.BiaoZhi|=0b00000100;
						if (((mcn != mcnold)&& (mcnold>=0) && (mcn>=0)) || ((mcn1 != mcnold1)&& (mcnold1>=0)&&(mcn1>=0)))
							JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err8.BiaoZhi|=0b00001000;
						if (((hgn != hgnold)&& (hgnold>=0) && (hgn>=0)) || ((hgn1 != hgnold1)&& (hgnold1>=0) && (hgn1>=0)))
							JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err8.BiaoZhi|=0b00010000;
						if ((xlnum!=xlold) && (xlold>=0) && (xlnum>=0))  //������������仯
							JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err8.BiaoZhi|=0b00100000;
						JParamInfo3761->group2.f10[met].AlarmFlg[7]=JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err8.BiaoZhi;
						JDataFileInfo->ErcEvt.EC1++;
						JDataFileInfo->ErcEvt.EC1=JDataFileInfo->ErcEvt.EC1%256;
					}
					else
					{
						memset(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2],0,sizeof(ERC));
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err8.ERCNo=8;
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err8.len=8;
						INT32U_BCD(ts.Minute,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err8.Occur_Time.BCD01,1);
						INT32U_BCD(ts.Hour,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err8.Occur_Time.BCD02,1);
						INT32U_BCD(ts.Day,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err8.Occur_Time.BCD03,1);
						INT32U_BCD(ts.Month,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err8.Occur_Time.BCD04,1);
						INT32U_BCD(ts.Year,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err8.Occur_Time.BCD05,1);
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err8.ClNo[0]=(met+1)&0xff;
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err8.ClNo[1]=((met+1)>>8)&0xff;
						//JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err8.ClNo[1]|=0b10000000;
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err8.BiaoZhi=0x00;
						if (((fln != flnold)&& (flnold>=0)&&(fln>=0)) || ((fln1 != flnold1)&& (flnold1>=0) && (fln1>=0)))
							JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err8.BiaoZhi|=0b00000001;
						if ((pnnum!=pnold) && (pnold>=0) && (pnnum>=0))
							JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err8.BiaoZhi|=0b00000010;
						if ((cbn != cbnold)&& (cbnold>=0) && (cbn>=0))
							JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err8.BiaoZhi|=0b00000100;
						if (((mcn != mcnold)&& (mcnold>=0) && (mcn>=0)) || ((mcn1 != mcnold1)&& (mcnold1>=0) && (mcn1>=0)))
							JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err8.BiaoZhi|=0b00001000;
						if (((hgn != hgnold)&& (hgnold>=0) && (hgn>=0)) || ((hgn1 != hgnold1)&& (hgnold1>=0) && (hgn1>=0)))
							JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err8.BiaoZhi|=0b00010000;
						if ((xlnum!=xlold) && (xlold>=0) && (xlnum>=0))
							JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err8.BiaoZhi|=0b00100000;
						JParamInfo3761->group2.f10[met].AlarmFlg[7]=JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err8.BiaoZhi;
						JDataFileInfo->ErcEvt.EC2++;
						JDataFileInfo->ErcEvt.EC2=JDataFileInfo->ErcEvt.EC2%256;
					}
				}
			}
		}
#endif
		if (JParamInfo3761->group2.f9.Flag[1] & 0x08) //12 ���ܱ�ʱ�䳬��
		{
			printf("sigoth %d-%d-%d %d:%d SecConut=%d,%d-%d-%d %d:%d GetSecCount=%d JParameterInfo->jzq.f59.JiaoShi=%d\n\r",
					ts2.Year,ts2.Month,ts2.Day,ts2.Hour,ts2.Minute,SecCount,
					smfile.ts.Year,smfile.ts.Month,smfile.ts.Day,smfile.ts.Hour,smfile.ts.Minute,GetSecCount,JParamInfo3761->group8.f59.JiaoShi);
			if (!(JParamInfo3761->group2.f10[met].AlarmFlg[11]&0b00001000))
			{
				if(CalcSec(SecCount,GetSecCount) > JParamInfo3761->group8.f59.JiaoShi)
				{
					printf("\n 12 ���ܱ�ʱ�䳬�� AlarmFlg \n");
					JDataFileInfo->ErcEvt.ERCBiaoZhi[1]|=0b00001000;
					JParamInfo3761->group2.f10[met].AlarmFlg[11]|=0b00001000;
					JProgramInfo->CurrErc.Buff[0]=12;
					JProgramInfo->stateflags.ErcFlg=12;
					SdPrint("ErcNo=%d\n\r",12);
					if (JParamInfo3761->group2.f9.FlagStep[1] & 0x08) //��Ҫ�¼�
					{
						memset(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1],0,sizeof(ERC));
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err12.ERCNo=12;
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err12.len=7;
						INT32U_BCD(ts.Minute,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err12.Occur_Time.BCD01,1);
						INT32U_BCD(ts.Hour,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err12.Occur_Time.BCD02,1);
						INT32U_BCD(ts.Day,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err12.Occur_Time.BCD03,1);
						INT32U_BCD(ts.Month,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err12.Occur_Time.BCD04,1);
						INT32U_BCD(ts.Year,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err12.Occur_Time.BCD05,1);
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err12.ClNo[0]=(met+1)&0xff;
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err12.ClNo[1]=((met+1)>>8)&0xff;
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err12.ClNo[1]|=0b10000000;
						JDataFileInfo->ErcEvt.EC1++;
						JDataFileInfo->ErcEvt.EC1=JDataFileInfo->ErcEvt.EC1%256;
					}
					else
					{
						memset(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2],0,sizeof(ERC));
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err12.ERCNo=12;
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err12.len=7;
						INT32U_BCD(ts.Minute,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err12.Occur_Time.BCD01,1);
						INT32U_BCD(ts.Hour,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err12.Occur_Time.BCD02,1);
						INT32U_BCD(ts.Day,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err12.Occur_Time.BCD03,1);
						INT32U_BCD(ts.Month,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err12.Occur_Time.BCD04,1);
						INT32U_BCD(ts.Year,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err12.Occur_Time.BCD05,1);
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err12.ClNo[0]=(met+1)&0xff;
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err12.ClNo[1]=((met+1)>>8)&0xff;
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err12.ClNo[1]|=0b10000000;
						JDataFileInfo->ErcEvt.EC2++;
						JDataFileInfo->ErcEvt.EC2=JDataFileInfo->ErcEvt.EC2%256;
					}
				}
			}
			else
			{
				if(CalcSec(SecCount,GetSecCount)<=JParamInfo3761->group8.f59.JiaoShi)
				{
					printf("\n 12 ���ܱ�ʱ�䳬��  \n");
					JDataFileInfo->ErcEvt.ERCBiaoZhi[1]|=0b00001000;
					JParamInfo3761->group2.f10[met].AlarmFlg[11]&=0xF7;
					JProgramInfo->CurrErc.Buff[0]=12;
					JProgramInfo->stateflags.ErcFlg=12;
					SdPrint("ErcNo=%d\n\r",12);
					if (JParamInfo3761->group2.f9.FlagStep[1] & 0x08) //��Ҫ�¼�
					{
						memset(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1],0,sizeof(ERC));
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err12.ERCNo=12;
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err12.len=7;
						INT32U_BCD(ts.Minute,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err12.Occur_Time.BCD01,1);
						INT32U_BCD(ts.Hour,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err12.Occur_Time.BCD02,1);
						INT32U_BCD(ts.Day,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err12.Occur_Time.BCD03,1);
						INT32U_BCD(ts.Month,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err12.Occur_Time.BCD04,1);
						INT32U_BCD(ts.Year,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err12.Occur_Time.BCD05,1);
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err12.ClNo[0]=(met+1)&0xff;
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err12.ClNo[1]=((met+1)>>8)&0xff;
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err12.ClNo[1]|=0b00000000;
						JDataFileInfo->ErcEvt.EC1++;
						JDataFileInfo->ErcEvt.EC1=JDataFileInfo->ErcEvt.EC1%256;
					}
					else
					{
						memset(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2],0,sizeof(ERC));
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err12.ERCNo=12;
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err12.len=7;
						INT32U_BCD(ts.Minute,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err12.Occur_Time.BCD01,1);
						INT32U_BCD(ts.Hour,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err12.Occur_Time.BCD02,1);
						INT32U_BCD(ts.Day,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err12.Occur_Time.BCD03,1);
						INT32U_BCD(ts.Month,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err12.Occur_Time.BCD04,1);
						INT32U_BCD(ts.Year,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err12.Occur_Time.BCD05,1);
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err12.ClNo[0]=(met+1)&0xff;
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err12.ClNo[1]=((met+1)>>8)&0xff;
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err12.ClNo[1]|=0b00000000;
						JDataFileInfo->ErcEvt.EC2++;
						JDataFileInfo->ErcEvt.EC2=JDataFileInfo->ErcEvt.EC2%256;
					}
				}
			}
		}

		if (JParamInfo3761->group2.f9.Flag[1] & 0x10) //13 ���ܱ�������Ϣ
		{
//			printf("\n!!!!!!!!!!ff=%d fd=%d",ff,fd);
//			printf("\n dxnum=%x(dxan~dxcn %x %x %x) dxold=%x(dxanold~dxcnold %x %x %x) synum=%x syold=%x pnnum=%x pnold=%x xlnum=%x xlold=%x tdn=%x tdnold=%x dcsy=%x\n",
//					dxnum,dxan,dxbn,dxcn,dxold,dxanold,dxbnold,dxcnold, synum, syold, pnnum, pnold, xlnum, xlold, tdn, tdnold, dcsy);
//			printf("\n");
			if ((ff==1) && (fd==1))
			{
				//songjian
//				if(((((dxnum>dxold) && (dxold>=0) && (!(JParamInfo3761->group2.f10[met].AlarmFlg[12]&0b00000010))) ||
//						((synum>syold) && (syold>=0) && (!(JParamInfo3761->group2.f10[met].AlarmFlg[12]&0b00000100))) ||
//						((pnnum>pnold) && (pnold>=0) && (!(JParamInfo3761->group2.f10[met].AlarmFlg[12]&0b00000001))) ||
//						((xlnum>xlold) && (xlold>=0) && (!(JParamInfo3761->group2.f10[met].AlarmFlg[12]&0b00000001))) ||
//						((tdn>tdnold) && (tdnold>=0) && (!(JParamInfo3761->group2.f10[met].AlarmFlg[12]&0b00001000))))) ||
//						((dcsy>=1) && (!(JParamInfo3761->group2.f10[met].AlarmFlg[12]&0b00010000))))
				//dxan+dxbn+dxcn;
				//dxanold+dxbnold+dxcnold
//				if(((dxnum!=dxold) && (dxold>=0) && (dxnum>=0) &&(dxan>=0) &&(dxbn>=0)&&(dxcn>=0) &&(dxanold>=0) &&(dxbnold>=0)&&(dxcnold>=0)) ||
//						((synum!=syold) && (syold>=0) &&(synum>=0)) ||((pnnum!=pnold) && (pnold>=0)&&(pnnum>=0)) ||
//						((xlnum!=xlold) && (xlold>=0) && (xlnum>=0)) ||	((tdn!=tdnold) && (tdnold>=0)&&(tdn>=0)) ||
//						(dcsy>=1))
				if(((dxnum!=dxold) && (dxold>=0)) ||	((synum!=syold) && (syold>=0) ) ||
						((pnnum!=pnold) && (pnold>=0)) || ((xlnum!=xlold) && (xlold>=0)) ||
						((tdn!=tdnold) && (tdnold>=0)) || (dcsy>=1))
				{
					printf("\n 13 ���ܱ�������Ϣ \n");
					printf("\n dxnum=%x(dxan~dxcn %x %x %x) dxold=%x(dxanold~dxcnold %x %x %x) synum=%x syold=%x pnnum=%x pnold=%x xlnum=%x xlold=%x tdn=%x tdnold=%x dcsy=%x\n",
							dxnum,dxan,dxbn,dxcn,dxold,dxanold,dxbnold,dxcnold, synum, syold, pnnum, pnold, xlnum, xlold, tdn, tdnold, dcsy);
					JDataFileInfo->ErcEvt.ERCBiaoZhi[1]|=0b00010000;
					JProgramInfo->CurrErc.Buff[0]=13;
					JProgramInfo->stateflags.ErcFlg=13;
					SdPrint("ErcNo=%d\n\r",13);
					if (JParamInfo3761->group2.f9.FlagStep[1] & 0x10) //��Ҫ�¼�
					{
						memset(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1],0,sizeof(ERC));
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err13.ERCNo=13;
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err13.len=8;
						INT32U_BCD(ts.Minute,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err13.Occur_Time.BCD01,1);
						INT32U_BCD(ts.Hour,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err13.Occur_Time.BCD02,1);
						INT32U_BCD(ts.Day,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err13.Occur_Time.BCD03,1);
						INT32U_BCD(ts.Month,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err13.Occur_Time.BCD04,1);
						INT32U_BCD(ts.Year,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err13.Occur_Time.BCD05,1);
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err13.ClNo[0]=(met+1)&0xff;
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err13.ClNo[1]=((met+1)>>8)&0xff;
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err13.ClNo[1]|=0b10000000;
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err13.Biaozhi=0x00;
						if ((((pnnum!=pnold) && (pnold>=0) && (pnnum>=0)) || ((xlnum!=xlold) && (xlold>=0))) && (ff==1) && (fd==1))//��̡�������������仯
							JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err13.Biaozhi|=0b00000001;
						if ((dxnum!=dxold) && (dxold>=0) && (dxnum>=0) && (ff==1) && (fd==1)) //��������仯
							JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err13.Biaozhi|=0b00000010;
						if ((synum!=syold) && (syold>=0) && (synum>=0) && (ff==1) && (fd==1)) //ʧѹ�����仯
							JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err13.Biaozhi|=0b00000100;
						if ((tdn!=tdnold) && (tdnold>=0) && (tdn >=0) && (ff==1) && (fd==1)) //��������仯
							JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err13.Biaozhi|=0b00001000;
						if (dcsy>=1) //���ʧѹ
							JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err13.Biaozhi|=0b00010000;
						JParamInfo3761->group2.f10[met].AlarmFlg[12]=JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err13.Biaozhi;
						JDataFileInfo->ErcEvt.EC1++;
						JDataFileInfo->ErcEvt.EC1=JDataFileInfo->ErcEvt.EC1%256;
					}else
					{
						memset(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2],0,sizeof(ERC));
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err13.ERCNo=13;
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err13.len=8;
						INT32U_BCD(ts.Minute,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err13.Occur_Time.BCD01,1);
						INT32U_BCD(ts.Hour,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err13.Occur_Time.BCD02,1);
						INT32U_BCD(ts.Day,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err13.Occur_Time.BCD03,1);
						INT32U_BCD(ts.Month,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err13.Occur_Time.BCD04,1);
						INT32U_BCD(ts.Year,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err13.Occur_Time.BCD05,1);
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err13.ClNo[0]=(met+1)&0xff;
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err13.ClNo[1]=((met+1)>>8)&0xff;
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err13.ClNo[1]|=0b10000000;
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err13.Biaozhi=0x00;
						if ((((pnnum!=pnold) && (pnold>=0) && (pnnum>=0)) || ((xlnum!=xlold) && (xlold>=0))) && (ff==1) && (fd==1))
							JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err13.Biaozhi|=0b00000001;
						if ((dxnum!=dxold) && (dxold>=0) && (dxnum>=0) && (ff==1) && (fd==1))
							JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err13.Biaozhi|=0b00000010;
						if ((synum!=syold) && (syold>=0) && (synum>=0)&& (ff==1) && (fd==1))
							JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err13.Biaozhi|=0b00000100;
						if ((tdn!=tdnold) && (tdnold>=0) && ( tdn>=0)&& (ff==1) && (fd==1))
							JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err13.Biaozhi|=0b00001000;
						if (dcsy>=1)
							JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err13.Biaozhi|=0b00010000;
						JParamInfo3761->group2.f10[met].AlarmFlg[12]=JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err13.Biaozhi;
						JDataFileInfo->ErcEvt.EC2++;
						JDataFileInfo->ErcEvt.EC2=JDataFileInfo->ErcEvt.EC2%256;
					}
				}
			}
		}

		if (JParamInfo3761->group2.f9.Flag[3] & 0x04) //27 ʾ���½�
		{
			if ((!(JParamInfo3761->group2.f10[met].AlarmFlg[26]&0b00000100)) && (ff==1) && (fd==1))
			{
				if ((Old_PDD>PDD) && (PDD>0))
				{
					printf("\n 27 ʾ���½� \n");
					JDataFileInfo->ErcEvt.ERCBiaoZhi[3]|=0b00000100;
					JParamInfo3761->group2.f10[met].AlarmFlg[26]=JDataFileInfo->ErcEvt.ERCBiaoZhi[3];
					JProgramInfo->CurrErc.Buff[0]=27;
					JProgramInfo->stateflags.ErcFlg=27;
					SdPrint("ErcNo=%d\n\r",27);
					if (JParamInfo3761->group2.f9.FlagStep[3] & 0x04) //��Ҫ�¼�
					{
						memset(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1],0,sizeof(ERC));
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err27.ERCNo=27;
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err27.len=17;
						INT32U_BCD(ts.Minute,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err27.Occur_Time.BCD01,1);
						INT32U_BCD(ts.Hour,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err27.Occur_Time.BCD02,1);
						INT32U_BCD(ts.Day,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err27.Occur_Time.BCD03,1);
						INT32U_BCD(ts.Month,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err27.Occur_Time.BCD04,1);
						INT32U_BCD(ts.Year,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err27.Occur_Time.BCD05,1);
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err27.ClNo[0]=(met+1)&0xff;
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err27.ClNo[1]=((met+1)>>8)&0xff;
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err27.ClNo[1]|=0b10000000;
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err27.Old_ShiZhi[0]=0x00;
						INT32U_BCD(Old_PDD,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err27.Old_ShiZhi[1],4);
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err27.New_ShiZhi[0]=0x00;
						INT32U_BCD(PDD,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err27.New_ShiZhi[1],4);
						JDataFileInfo->ErcEvt.EC1++;
						JDataFileInfo->ErcEvt.EC1=JDataFileInfo->ErcEvt.EC1%256;
					}else
					{
						memset(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2],0,sizeof(ERC));
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err27.ERCNo=27;
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err27.len=17;
						INT32U_BCD(ts.Minute,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err27.Occur_Time.BCD01,1);
						INT32U_BCD(ts.Hour,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err27.Occur_Time.BCD02,1);
						INT32U_BCD(ts.Day,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err27.Occur_Time.BCD03,1);
						INT32U_BCD(ts.Month,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err27.Occur_Time.BCD04,1);
						INT32U_BCD(ts.Year,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err27.Occur_Time.BCD05,1);
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err27.ClNo[0]=(met+1)&0xff;
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err27.ClNo[1]=((met+1)>>8)&0xff;
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err27.ClNo[1]|=0b10000000;
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err27.Old_ShiZhi[0]=0x00;
						INT32U_BCD(Old_PDD,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err27.Old_ShiZhi[1],4);
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err27.New_ShiZhi[0]=0x00;
						INT32U_BCD(PDD,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err27.New_ShiZhi[1],4);
						JDataFileInfo->ErcEvt.EC2++;
						JDataFileInfo->ErcEvt.EC2=JDataFileInfo->ErcEvt.EC2%256;
					}
				}
			}
		}

		if (JParamInfo3761->group2.f9.Flag[3] & 0x08) //28 ����������
		{
			if ((!(JParamInfo3761->group2.f10[met].AlarmFlg[27]&0b00001000)) && (ff==1) && (fd==1))
			{
				if ((PDD>Old_PDD) && (Old_PDD>0))
				if (((PDD-Old_PDD)>=BCD_INT32(&JParamInfo3761->group8.f59.ChaoCha,1)*100) && (BCD_INT32(&JParamInfo3761->group8.f59.ChaoCha,1)>0))
				{
					printf("\n 28 ���������� \n");
					JDataFileInfo->ErcEvt.ERCBiaoZhi[3]|=0b00001000;
					JParamInfo3761->group2.f10[met].AlarmFlg[27]=JDataFileInfo->ErcEvt.ERCBiaoZhi[3];
					JProgramInfo->CurrErc.Buff[0]=28;
					JProgramInfo->stateflags.ErcFlg=28;
					SdPrint("ErcNo=%d\n\r",28);
					if (JParamInfo3761->group2.f9.FlagStep[3] & 0x08) //��Ҫ�¼�
					{
						memset(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1],0,sizeof(ERC));
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err28.ERCNo=28;
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err28.len=18;
						INT32U_BCD(ts.Minute,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err28.Occur_Time.BCD01,1);
						INT32U_BCD(ts.Hour,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err28.Occur_Time.BCD02,1);
						INT32U_BCD(ts.Day,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err28.Occur_Time.BCD03,1);
						INT32U_BCD(ts.Month,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err28.Occur_Time.BCD04,1);
						INT32U_BCD(ts.Year,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err28.Occur_Time.BCD05,1);
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err28.ClNo[0]=(met+1)&0xff;
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err28.ClNo[1]=((met+1)>>8)&0xff;
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err28.ClNo[1]|=0b10000000;
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err28.Old_ShiZhi[0]=0x00;
						INT32U_BCD(Old_PDD,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err28.Old_ShiZhi[1],4);
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err28.New_ShiZhi[0]=0x00;
						INT32U_BCD(PDD,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err28.New_ShiZhi[1],4);
						memcpy(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err28.Fazhi,&JParamInfo3761->group8.f59.ChaoCha,1);
						JDataFileInfo->ErcEvt.EC1++;
						JDataFileInfo->ErcEvt.EC1=JDataFileInfo->ErcEvt.EC1%256;
					}
					else
					{
						memset(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2],0,sizeof(ERC));
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err28.ERCNo=28;
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err28.len=18;
						INT32U_BCD(ts.Minute,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err28.Occur_Time.BCD01,1);
						INT32U_BCD(ts.Hour,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err28.Occur_Time.BCD02,1);
						INT32U_BCD(ts.Day,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err28.Occur_Time.BCD03,1);
						INT32U_BCD(ts.Month,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err28.Occur_Time.BCD04,1);
						INT32U_BCD(ts.Year,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err28.Occur_Time.BCD05,1);
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err28.ClNo[0]=(met+1)&0xff;
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err28.ClNo[1]=((met+1)>>8)&0xff;
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err28.ClNo[1]|=0b10000000;
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err28.Old_ShiZhi[0]=0x00;
						INT32U_BCD(Old_PDD,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err28.Old_ShiZhi[1],4);
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err28.New_ShiZhi[0]=0x00;
						INT32U_BCD(PDD,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err28.New_ShiZhi[1],4);
						memcpy(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err28.Fazhi,&JParamInfo3761->group8.f59.ChaoCha,1);
						JDataFileInfo->ErcEvt.EC2++;
						JDataFileInfo->ErcEvt.EC2=JDataFileInfo->ErcEvt.EC2%256;
					}
				}
			}
		}

		if (JParamInfo3761->group2.f9.Flag[3] & 0x10) //29 ����
		{
			if ((!(JParamInfo3761->group2.f10[met].AlarmFlg[28]&0b00010000)) && (ff==1) && (fd==1))
			{
				if ((PDD>Old_PDD) && (Old_PDD>0))
				if (((PDD-Old_PDD)>=BCD_INT32(&JParamInfo3761->group8.f59.FeiZou,1)*10) && (BCD_INT32(&JParamInfo3761->group8.f59.FeiZou,1)>0))
				{
					printf("\n 29 ���� \n");
					JDataFileInfo->ErcEvt.ERCBiaoZhi[3]|=0b00010000;
					JParamInfo3761->group2.f10[met].AlarmFlg[28]=JDataFileInfo->ErcEvt.ERCBiaoZhi[3];
					JProgramInfo->CurrErc.Buff[0]=29;
					JProgramInfo->stateflags.ErcFlg=29;
					SdPrint("ErcNo=%d\n\r",29);
					if (JParamInfo3761->group2.f9.FlagStep[3] & 0x10) //��Ҫ�¼�
					{
						memset(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1],0,sizeof(ERC));
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err29.ERCNo=29;
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err29.len=18;
						INT32U_BCD(ts.Minute,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err29.Occur_Time.BCD01,1);
						INT32U_BCD(ts.Hour,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err29.Occur_Time.BCD02,1);
						INT32U_BCD(ts.Day,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err29.Occur_Time.BCD03,1);
						INT32U_BCD(ts.Month,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err29.Occur_Time.BCD04,1);
						INT32U_BCD(ts.Year,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err29.Occur_Time.BCD05,1);
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err29.ClNo[0]=(met+1)&0xff;
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err29.ClNo[1]=((met+1)>>8)&0xff;
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err29.ClNo[1]|=0b10000000;
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err29.Old_ShiZhi[0]=0x00;
						INT32U_BCD(Old_PDD,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err29.Old_ShiZhi[1],4);
						JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err29.New_ShiZhi[0]=0x00;
						INT32U_BCD(PDD,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err29.New_ShiZhi[1],4);
						memcpy(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err29.Fazhi,&JParamInfo3761->group8.f59.FeiZou,1);
						JDataFileInfo->ErcEvt.EC1++;
						JDataFileInfo->ErcEvt.EC1=JDataFileInfo->ErcEvt.EC1%256;
					}
					else
					{
						memset(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2],0,sizeof(ERC));
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err29.ERCNo=29;
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err29.len=18;
						INT32U_BCD(ts.Minute,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err29.Occur_Time.BCD01,1);
						INT32U_BCD(ts.Hour,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err29.Occur_Time.BCD02,1);
						INT32U_BCD(ts.Day,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err29.Occur_Time.BCD03,1);
						INT32U_BCD(ts.Month,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err29.Occur_Time.BCD04,1);
						INT32U_BCD(ts.Year,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err29.Occur_Time.BCD05,1);
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err29.ClNo[0]=(met+1)&0xff;
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err29.ClNo[1]=((met+1)>>8)&0xff;
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err29.ClNo[1]|=0b10000000;
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err29.Old_ShiZhi[0]=0x00;
						INT32U_BCD(Old_PDD,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err29.Old_ShiZhi[1],4);
						JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err29.New_ShiZhi[0]=0x00;
						INT32U_BCD(PDD,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err29.New_ShiZhi[1],4);
						memcpy(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err29.Fazhi,&JParamInfo3761->group8.f59.FeiZou,1);
						JDataFileInfo->ErcEvt.EC2++;
						JDataFileInfo->ErcEvt.EC2=JDataFileInfo->ErcEvt.EC2%256;
					}
				}
			}
		}
		//9��14��ȥ����Err8�¼��ó�����CreateErr8��������
//		if ((JProgramInfo->stateflags.ErcFlg==8) || (JProgramInfo->stateflags.ErcFlg==12) || (JProgramInfo->stateflags.ErcFlg==13) ||
//				(JProgramInfo->stateflags.ErcFlg==27) || (JProgramInfo->stateflags.ErcFlg==28) || (JProgramInfo->stateflags.ErcFlg==29))
		if ((JProgramInfo->stateflags.ErcFlg==12) || (JProgramInfo->stateflags.ErcFlg==13) ||
				(JProgramInfo->stateflags.ErcFlg==27) || (JProgramInfo->stateflags.ErcFlg==28) || (JProgramInfo->stateflags.ErcFlg==29))

		{
//			memset(Temp_FilePath,0,60);
//			sprintf((char*)Temp_FilePath,"/nand/DataAlarm/alarm.dat");
//			SaveFile((char*)Temp_FilePath,&JDataFileInfo->ErcEvt,sizeof(ErcSave));
//			delay(50);
			JProgramInfo->CurrErc.Buff[0]=0;
			JProgramInfo->Para.ChangedJiZhongQiInfo = 2;
			SdPrint("\n\rCreateOtherErr\n\r");
//			JProgramInfo->FileSaveFlag.ercflag = 1;
		}
	}
}

void CreateErr30(TS ts,int met)//ͣ��
{
	int CjqNo,MetNo,MetType,PDD=0;
	INT8U Temp_FilePath[60], tempManyData[DataLenMax],fd=0;
	INT8U equalPDD=0;
	if (!(JParamInfo3761->group2.f9.Flag[3] & 0x20))
	{
		memset(err30PDD, 0, PointMax*sizeof(PDD_t));
		return;
	}
	CjqNo=JParamInfo3761->group2.f10[met].CjqNo-1;
	MetNo=JParamInfo3761->group2.f10[met].MeterNo;
	MetType = JParamInfo3761->group2.f10[met].Type;
	if (JParamInfo3761->group2.f10[met].Status!=1)
		return;
	if (JParamInfo3761->group2.f10[met].Type==0)
		return;
	if (JParamInfo3761->group2.f10[met].ConnectType==2 && JParamInfo3761->group2.f10[met].port==1)
		return;
	if (JParamInfo3761->group8.f59.TingZou==0)
		return;

	memset(Temp_FilePath,0,60);
	memset(&smfile,0,sizeof(SMFiles));
	sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",	met+1);//yangdong
	ReadFile((char *) Temp_FilePath, &smfile,sizeof(SMFiles),JProgramInfo);
	fd=0;
	printf("\nCaijiQiNo=%d  CjqNo=%d  MeterNo=%d  metNo=%d",smfile.sm.CaijiQiNo,CjqNo,smfile.sm.MeterNo,MetNo);
	if(smfile.sm.CaijiQiNo==CjqNo&&smfile.sm.MeterNo==MetNo)
	{
		memset(tempManyData,0,sizeof(tempManyData));
		if ((MetType == 9) || (MetType == 6))
			GetManyData(smfile.sm.datas,&tempManyData[0],0x90,0x10);
		else
			GetManyData(smfile.sm.datas,&tempManyData[0],0x90,0x1f); //�����й�
		PDD=BCD_INT32(&tempManyData[0],4);
		if((err30PDD[met].CurPDD != PDD)&&(PDD!=0))
		{
			err30PDD[met].CurPDD = PDD;
			err30PDD[met].counter = 0;
			JParamInfo3761->group2.f10[met].AlarmFlg[29] = 0;
			printf("\n 9010�仯��point=%d  PDD=%d",met,PDD);
		}else
		{
			err30PDD[met].counter ++;
			printf("\n 9010�ޱ仯��point=%d  yuzhi=%d counter=%d ",met,JParamInfo3761->group8.f59.TingZou,err30PDD[met].counter );
			if ( err30PDD[met].counter >= 15 *JParamInfo3761->group8.f59.TingZou )
			{
				equalPDD = 1;
			}
		}
		SdPrint("erc30 new PDD=%d\n\r",PDD);
		fd=1;
	}

	if ((!(JParamInfo3761->group2.f10[met].AlarmFlg[29]&0b00100000)) && (fd==1))
	{
		//if ((PDD==Old_PDD) && (Old_PDD>0))
		if(equalPDD==1)
		{
			JDataFileInfo->ErcEvt.ERCBiaoZhi[3]|=0b00100000;
			JParamInfo3761->group2.f10[met].AlarmFlg[29]=JDataFileInfo->ErcEvt.ERCBiaoZhi[3];
			JProgramInfo->CurrErc.Buff[0]=30;
			JProgramInfo->stateflags.ErcFlg=30;
			SdPrint("ErcNo=%d\n\r",30);
			if (JParamInfo3761->group2.f9.FlagStep[3] & 0x20) //��Ҫ�¼�
			{
				memset(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1],0,sizeof(ERC));
				JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err30.ERCNo=30;
				JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err30.len=13;
				INT32U_BCD(ts.Minute,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err30.Occur_Time.BCD01,1);
				INT32U_BCD(ts.Hour,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err30.Occur_Time.BCD02,1);
				INT32U_BCD(ts.Day,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err30.Occur_Time.BCD03,1);
				INT32U_BCD(ts.Month,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err30.Occur_Time.BCD04,1);
				INT32U_BCD(ts.Year,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err30.Occur_Time.BCD05,1);
				JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err30.ClNo[0]=(met+1)&0xff;
				JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err30.ClNo[1]=((met+1)>>8)&0xff;
				JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err30.ClNo[1]|=0b10000000;
				JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err30.Old_ShiZhi[0]=0x00;
				INT32U_BCD(PDD,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err30.Old_ShiZhi[1],4);
				memcpy(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err30.Fazhi,&JParamInfo3761->group8.f59.TingZou,1);
				JDataFileInfo->ErcEvt.EC1++;
				JDataFileInfo->ErcEvt.EC1=JDataFileInfo->ErcEvt.EC1%256;
			}
			else
			{
				memset(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2],0,sizeof(ERC));
				JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err30.ERCNo=30;
				JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err30.len=13;
				INT32U_BCD(ts.Minute,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err30.Occur_Time.BCD01,1);
				INT32U_BCD(ts.Hour,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err30.Occur_Time.BCD02,1);
				INT32U_BCD(ts.Day,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err30.Occur_Time.BCD03,1);
				INT32U_BCD(ts.Month,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err30.Occur_Time.BCD04,1);
				INT32U_BCD(ts.Year,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err30.Occur_Time.BCD05,1);
				JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err30.ClNo[0]=(met+1)&0xff;
				JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err30.ClNo[1]=((met+1)>>8)&0xff;
				JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err30.ClNo[1]|=0b10000000;
				JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err30.Old_ShiZhi[0]=0x00;
				INT32U_BCD(PDD,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err30.Old_ShiZhi[1],4);
				memcpy(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err30.Fazhi,&JParamInfo3761->group8.f59.TingZou,1);
				JDataFileInfo->ErcEvt.EC2++;
				JDataFileInfo->ErcEvt.EC2=JDataFileInfo->ErcEvt.EC2%256;
			}
//			memset(Temp_FilePath,0,60);
//			sprintf((char*)Temp_FilePath,"/nand/DataAlarm/alarm.dat");
//			SaveFile((char*)Temp_FilePath,&JDataFileInfo->ErcEvt,sizeof(ErcSave));
//			delay(50);
			JProgramInfo->CurrErc.Buff[0]=0;
			JProgramInfo->Para.ChangedJiZhongQiInfo = 2;
			SdPrint("\n\rCreateErr30\n\r")
//			JProgramInfo->FileSaveFlag.ercflag = 1;
		}
	}
}

void CreateErr31(TS ts)
{//����ʧ��
	int meterno=0,CjqNo,MetNo,MetType;
	INT8U Temp_FilePath[60], tempManyData[DataLenMax];

	meterno=JProgramInfo->CurrErc.Err31.ClNo[0]+((JProgramInfo->CurrErc.Err31.ClNo[1]&0x0F)<<8);

	INT32U_BCD(ts.Minute,&JProgramInfo->CurrErc.Err31.Occur_Time.BCD01,1);
	INT32U_BCD(ts.Hour,&JProgramInfo->CurrErc.Err31.Occur_Time.BCD02,1);
	INT32U_BCD(ts.Day,&JProgramInfo->CurrErc.Err31.Occur_Time.BCD03,1);
	INT32U_BCD(ts.Month,&JProgramInfo->CurrErc.Err31.Occur_Time.BCD04,1);
	INT32U_BCD(ts.Year,&JProgramInfo->CurrErc.Err31.Occur_Time.BCD05,1);
	CjqNo=JParamInfo3761->group2.f10[meterno].CjqNo;
	MetNo=JParamInfo3761->group2.f10[meterno].MeterNo;
	MetType = JParamInfo3761->group2.f10[meterno].Type;

	if (MetType==0)
		return;
	memset(Temp_FilePath,0,60);
	memset(&smfileold,0,sizeof(SMFiles));
	sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/last.dat",meterno);

	if (access((char*)Temp_FilePath,0)!=0)
	{
		//return;
	}
	else ReadFile((char *) Temp_FilePath, &smfileold,sizeof(SMFiles),JProgramInfo);

	if(smfileold.sm.CaijiQiNo==CjqNo&&smfileold.sm.MeterNo==MetNo)
	{
		memset(tempManyData, 0, sizeof(tempManyData));
		GetManyData(smfileold.sm.datas, &tempManyData[0],0x90, 0x10);
		INT32U_BCD(smfileold.ts.Minute,&JProgramInfo->CurrErc.Err31.Last_OK[0],1);
		INT32U_BCD(smfileold.ts.Hour,&JProgramInfo->CurrErc.Err31.Last_OK[1],1);
		INT32U_BCD(smfileold.ts.Day,&JProgramInfo->CurrErc.Err31.Last_OK[2],1);
		INT32U_BCD(smfileold.ts.Month,&JProgramInfo->CurrErc.Err31.Last_OK[3],1);
		INT32U_BCD(smfileold.ts.Year,&JProgramInfo->CurrErc.Err31.Last_OK[4],1);
		JProgramInfo->CurrErc.Err31.Last_Value_P[0]=0x00;
		memcpy(&JProgramInfo->CurrErc.Err31.Last_Value_P[1], &tempManyData[0], 4);
		memset(tempManyData, 0, sizeof(tempManyData));
		GetManyData(smfileold.sm.datas, &tempManyData[0],0x90, 0x20);
		memcpy(&JProgramInfo->CurrErc.Err31.Last_Value_Q[0], &tempManyData[0], 4);
	}
	else
	{
		memset(&JProgramInfo->CurrErc.Err31.Last_OK[0],0x00,5);
		memset(&JProgramInfo->CurrErc.Err31.Last_Value_P[0],0x00,5);
		memset(&JProgramInfo->CurrErc.Err31.Last_Value_Q[0],0x00,4);
	}
	JDataFileInfo->ErcEvt.ERCBiaoZhi[3]|=0b01000000;
	JProgramInfo->CurrErc.Buff[0]=31;
	JProgramInfo->stateflags.ErcFlg=31;
	printf("\n============JParamInfo3761->group2.f9.FlagStep[3] = %02x",JParamInfo3761->group2.f9.FlagStep[3]);
	if (JParamInfo3761->group2.f9.FlagStep[3] & 0x40)
	{
		memset(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1],0,sizeof(ERC));
		memcpy(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1],&JProgramInfo->CurrErc,sizeof(ERC));
		JDataFileInfo->ErcEvt.EC1++;
		JDataFileInfo->ErcEvt.EC1=JDataFileInfo->ErcEvt.EC1%256;
	}
	else
	{
		memset(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2],0,sizeof(ERC));
		memcpy(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2],&JProgramInfo->CurrErc,sizeof(ERC));
		JDataFileInfo->ErcEvt.EC2++;
		JDataFileInfo->ErcEvt.EC2=JDataFileInfo->ErcEvt.EC2%256;
	}
//	memset(Temp_FilePath,0,60);
//	sprintf((char*)Temp_FilePath,"/nand/DataAlarm/alarm.dat");
//	SaveFile((char*)Temp_FilePath,&JDataFileInfo->ErcEvt,sizeof(ErcSave));
//	delay(50);
	JProgramInfo->CurrErc.Buff[0]=0;
	JProgramInfo->Para.ChangedJiZhongQiInfo = 2;
	SdPrint("\n\rCreateErr31\n\r")
//	JProgramInfo->FileSaveFlag.ercflag = 1;
}

void CreateErr32(TS ts)
{//ͨ������Խ��
	int flow=0;
    //if (!(JParamInfo3761->group2.f9.Flag[3] & 0x80))
	if (JParamInfo3761->group2.f9.Flag[3] & 0x80)
	{
		flow=BCD_INT32(&JParamInfo3761->group5.f36.Flow[0],4);
		if (flow==0)
			return;
		if (!(JDataFileInfo->ErcEvt.ERCBiaoZhi[3]&0x80))//û�д˸澯����
		{
			if (JDataFileInfo->YueRunTj.LiuLiang>flow)
			{
				SdPrint("CreateErr32   1111\n\r");
				JDataFileInfo->ErcEvt.ERCBiaoZhi[3]|=0b10000000;
				JProgramInfo->CurrErc.Buff[0]=32;
				JProgramInfo->stateflags.ErcFlg=32;
				//if (!(JParamInfo3761->group2.f9.FlagStep[3] & 0x80))
				if (JParamInfo3761->group2.f9.FlagStep[3] & 0x80) //��Ҫ�¼�
				{
					memset(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1],0,sizeof(ERC));
					JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err32.ERCNo=32;
					JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err32.len=13;
					INT32U_BCD(ts.Minute,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err32.Occur_Time.BCD01,1);
					INT32U_BCD(ts.Hour,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err32.Occur_Time.BCD02,1);
					INT32U_BCD(ts.Day,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err32.Occur_Time.BCD03,1);
					INT32U_BCD(ts.Month,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err32.Occur_Time.BCD04,1);
					INT32U_BCD(ts.Year,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err32.Occur_Time.BCD05,1);
					INT32U_BCD(JDataFileInfo->YueRunTj.LiuLiang,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err32.Now_LiuLiang[0],4);
					memcpy(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err32.Set_LiuLiang[0],&JParamInfo3761->group5.f36.Flow[0],4);
					JDataFileInfo->ErcEvt.EC1++;
					JDataFileInfo->ErcEvt.EC1=JDataFileInfo->ErcEvt.EC1%256;
					SdPrint("EC1=%d,EC1old=%d\n\r",JDataFileInfo->ErcEvt.EC1,JDataFileInfo->ErcEvt.EC1old);
				}
				else
				{
					memset(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2],0,sizeof(ERC));
					JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err32.ERCNo=32;
					JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err32.len=13;
					INT32U_BCD(ts.Minute,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err32.Occur_Time.BCD01,1);
					INT32U_BCD(ts.Hour,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err32.Occur_Time.BCD02,1);
					INT32U_BCD(ts.Day,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err32.Occur_Time.BCD03,1);
					INT32U_BCD(ts.Month,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err32.Occur_Time.BCD04,1);
					INT32U_BCD(ts.Year,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err32.Occur_Time.BCD05,1);
					INT32U_BCD(JDataFileInfo->YueRunTj.LiuLiang,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err32.Now_LiuLiang[0],4);
					memcpy(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err32.Set_LiuLiang[0],&JParamInfo3761->group5.f36.Flow[0],4);
					JDataFileInfo->ErcEvt.EC2++;
					JDataFileInfo->ErcEvt.EC2=JDataFileInfo->ErcEvt.EC2%256;
					SdPrint("EC2=%d,EC2old=%d\n\r",JDataFileInfo->ErcEvt.EC2,JDataFileInfo->ErcEvt.EC2old);
				}
//				memset(Temp_FilePath,0,60);
//				sprintf((char*)Temp_FilePath,"/nand/DataAlarm/alarm.dat");
//				SaveFile((char*)Temp_FilePath,&JDataFileInfo->ErcEvt,sizeof(ErcSave));
//				delay(50);
				JProgramInfo->CurrErc.Buff[0]=0;
				JProgramInfo->Para.ChangedJiZhongQiInfo = 2;
				SdPrint("\n\rCreateErr32\n\r")
//				JProgramInfo->FileSaveFlag.ercflag = 1;
			}
		}
	}
}
void CreateErr33(TS ts,int met)
{//״̬λ�仯��־
	int CjqNo,MetNo,MetType,i;
	INT8U Temp_FilePath[60], tempManyData[DataLenMax],chgflg;
	INT16U StatB[7],Stat[7],StatChg[7],tmp;
	memset(StatChg,0,7*sizeof(INT16U));
	chgflg=0;
	tmp=0;
	if (JParamInfo3761->group2.f9.Flag[4] & 0x01)
	{
		CjqNo=JParamInfo3761->group2.f10[met].CjqNo-1;
		MetNo=JParamInfo3761->group2.f10[met].MeterNo;
		MetType = JParamInfo3761->group2.f10[met].Type;
		if (JParamInfo3761->group2.f10[met].Status!=1)
			return;
		if (JParamInfo3761->group2.f10[met].Type==0)
			return;
		memset(&StatB,0,sizeof(StatB));
		memset(&Stat,0,sizeof(Stat));
		memset(Temp_FilePath,0,60);
		memset(&smfileold,0,sizeof(SMFiles));
		memset(&smfile,0,sizeof(SMFiles));
		sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/last.dat",met+1);
		if (access((char*)Temp_FilePath,0)!=0)
		{
			return;
		}
		ReadFile((char *) Temp_FilePath, &smfileold,sizeof(SMFiles), JProgramInfo);
		memset(Temp_FilePath,0,60);
		sprintf((char *) Temp_FilePath, "/nand/DataCurr/%04d/curr.dat",met+1);
		if (access((char*)Temp_FilePath,0)!=0)
		{
			return;
		}
		ReadFile((char *) Temp_FilePath, &smfile,sizeof(SMFiles), JProgramInfo);
		if(smfileold.sm.CaijiQiNo==CjqNo&&smfileold.sm.MeterNo==MetNo)
		{
			memset(tempManyData,0,sizeof(tempManyData));
			GetManyData(smfileold.sm.datas,&tempManyData[0],0xc0,0x20);
			memcpy(&StatB[0],&tempManyData[0],2);
			memset(tempManyData,0,sizeof(tempManyData));
			GetManyData(smfileold.sm.datas,&tempManyData[0],0xc0,0x21);
			memcpy(&StatB[1],&tempManyData[0],2);
			memset(tempManyData,0,sizeof(tempManyData));
			GetManyData(smfileold.sm.datas,&tempManyData[0],0x00,0x63);
			memcpy(&StatB[2],&tempManyData[0],2);
			memset(tempManyData,0,sizeof(tempManyData));
			GetManyData(smfileold.sm.datas,&tempManyData[0],0x00,0x64);
			memcpy(&StatB[3],&tempManyData[0],2);
			memset(tempManyData,0,sizeof(tempManyData));
			GetManyData(smfileold.sm.datas,&tempManyData[0],0x00,0x65);
			memcpy(&StatB[4],&tempManyData[0],2);
			memset(tempManyData,0,sizeof(tempManyData));
			GetManyData(smfileold.sm.datas,&tempManyData[0],0x00,0x66);
			memcpy(&StatB[5],&tempManyData[0],2);
			memset(tempManyData,0,sizeof(tempManyData));
			GetManyData(smfileold.sm.datas,&tempManyData[0],0x00,0x67);
			memcpy(&StatB[6],&tempManyData[0],2);
		}

		if(smfile.sm.CaijiQiNo==CjqNo&&smfile.sm.MeterNo==MetNo)
		{
			memset(tempManyData,0,sizeof(tempManyData));
			GetManyData(smfile.sm.datas,&tempManyData[0],0xc0,0x20);
			memcpy(&Stat[0],&tempManyData[0],2);
			memset(tempManyData,0,sizeof(tempManyData));
			GetManyData(smfile.sm.datas,&tempManyData[0],0xc0,0x21);
			memcpy(&Stat[1],&tempManyData[0],2);
			memset(tempManyData,0,sizeof(tempManyData));
			GetManyData(smfile.sm.datas,&tempManyData[0],0x00,0x63);
			memcpy(&Stat[2],&tempManyData[0],2);
			memset(tempManyData,0,sizeof(tempManyData));
			GetManyData(smfile.sm.datas,&tempManyData[0],0x00,0x64);
			memcpy(&Stat[3],&tempManyData[0],2);
			memset(tempManyData,0,sizeof(tempManyData));
			GetManyData(smfile.sm.datas,&tempManyData[0],0x00,0x65);
			memcpy(&Stat[4],&tempManyData[0],2);
			memset(tempManyData,0,sizeof(tempManyData));
			GetManyData(smfile.sm.datas,&tempManyData[0],0x00,0x66);
			memcpy(&Stat[5],&tempManyData[0],2);
			memset(tempManyData,0,sizeof(tempManyData));
			GetManyData(smfile.sm.datas,&tempManyData[0],0x00,0x67);
			memcpy(&Stat[6],&tempManyData[0],2);
		}

		for (i=0;i<7;i++)
		{
			tmp=CmpOneByte(StatB[i]&0xff,Stat[i]&0xff);
			StatChg[i]=tmp&0xff;
			tmp=CmpOneByte((StatB[i]>>8)&0xff,(Stat[i]>>8)&0xff);
			StatChg[i]=StatChg[i]|(tmp<<8);
			if (StatChg[i])
				chgflg=1;
		}
		if (chgflg)//״̬�ֱȽ�
		{
			JDataFileInfo->ErcEvt.ERCBiaoZhi[4]|=0b00000001;
			JParamInfo3761->group2.f10[met].AlarmFlg[32]=JDataFileInfo->ErcEvt.ERCBiaoZhi[4];
			JProgramInfo->CurrErc.Buff[0]=33;
			JProgramInfo->stateflags.ErcFlg=33;
			if (JParamInfo3761->group2.f9.FlagStep[4] & 0x01) //��Ҫ�¼�
			{
				memset(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1],0,sizeof(ERC));
				JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err33.ERCNo=33;
				JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err33.len=35;
				INT32U_BCD(ts.Minute,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err33.Occur_Time.BCD01,1);
				INT32U_BCD(ts.Hour,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err33.Occur_Time.BCD02,1);
				INT32U_BCD(ts.Day,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err33.Occur_Time.BCD03,1);
				INT32U_BCD(ts.Month,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err33.Occur_Time.BCD04,1);
				INT32U_BCD(ts.Year,&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err33.Occur_Time.BCD05,1);
				JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err33.ClNo[0]=(met+1)&0xff;
				JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err33.ClNo[1]=((met+1)>>8)&0xff;
				for(i=0;i<7;i++)
				{
					memcpy(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err33.statChg[i*2],&StatChg[i],2);
					memcpy(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1].Err33.statN[i*2],&Stat[i],2);
				}
				JDataFileInfo->ErcEvt.EC1++;
				JDataFileInfo->ErcEvt.EC1=JDataFileInfo->ErcEvt.EC1%256;
			}
			else
			{
				SdPrint("CreateErr33   aannnnnn\n\r");
				memset(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2],0,sizeof(ERC));
				JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err33.ERCNo=33;
				JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err33.len=35;
				INT32U_BCD(ts.Minute,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err33.Occur_Time.BCD01,1);
				INT32U_BCD(ts.Hour,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err33.Occur_Time.BCD02,1);
				INT32U_BCD(ts.Day,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err33.Occur_Time.BCD03,1);
				INT32U_BCD(ts.Month,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err33.Occur_Time.BCD04,1);
				INT32U_BCD(ts.Year,&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err33.Occur_Time.BCD05,1);
				JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err33.ClNo[0]=(met+1)&0xff;
				JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err33.ClNo[1]=((met+1)>>8)&0xff;
				for(i=0;i<7;i++)
				{
					memcpy(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err33.statChg[i*2],&StatChg[i],2);
					memcpy(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2].Err33.statN[i*2],&Stat[i],2);
				}
				JDataFileInfo->ErcEvt.EC2++;
				JDataFileInfo->ErcEvt.EC2=JDataFileInfo->ErcEvt.EC2%256;
			}
//			memset(Temp_FilePath,0,60);
//			sprintf((char*)Temp_FilePath,"/nand/DataAlarm/alarm.dat");
//			SaveFile((char*)Temp_FilePath,&JDataFileInfo->ErcEvt,sizeof(ErcSave));
//			delay(50);
			JProgramInfo->CurrErc.Buff[0]=0;
			JProgramInfo->Para.ChangedJiZhongQiInfo = 2;
			SdPrint("\n\rCreateErr33\n\r");
//			JProgramInfo->FileSaveFlag.ercflag = 1;
		}
	}
}

void CreateErr60(TS ts)
{//ͨ�Ų���
	INT32U_BCD(ts.Minute,&JProgramInfo->CurrErc.Err60.Occur_Time.BCD01,1);
	INT32U_BCD(ts.Hour,&JProgramInfo->CurrErc.Err60.Occur_Time.BCD02,1);
	INT32U_BCD(ts.Day,&JProgramInfo->CurrErc.Err60.Occur_Time.BCD03,1);
	INT32U_BCD(ts.Month,&JProgramInfo->CurrErc.Err60.Occur_Time.BCD04,1);
	INT32U_BCD(ts.Year,&JProgramInfo->CurrErc.Err60.Occur_Time.BCD05,1);
	JDataFileInfo->ErcEvt.ERCBiaoZhi[7]|=0b00001000;
	JProgramInfo->CurrErc.Buff[0]=60;
	JProgramInfo->stateflags.ErcFlg=60;
	if (JParamInfo3761->group2.f9.FlagStep[7] & 0x08)
	{
		memset(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1],0,sizeof(ERC));
		memcpy(&JDataFileInfo->ErcEvt.ImpEvent[JDataFileInfo->ErcEvt.EC1],&JProgramInfo->CurrErc,sizeof(ERC));
		JDataFileInfo->ErcEvt.EC1++;
		JDataFileInfo->ErcEvt.EC1=JDataFileInfo->ErcEvt.EC1%256;
	}
	else
	{
		memset(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2],0,sizeof(ERC));
		memcpy(&JDataFileInfo->ErcEvt.NorEvent[JDataFileInfo->ErcEvt.EC2],&JProgramInfo->CurrErc,sizeof(ERC));
		JDataFileInfo->ErcEvt.EC2++;
		JDataFileInfo->ErcEvt.EC2=JDataFileInfo->ErcEvt.EC2%256;
	}
//	memset(Temp_FilePath,0,60);
//	sprintf((char*)Temp_FilePath,"/nand/DataAlarm/alarm.dat");
//	SaveFile((char*)Temp_FilePath,&JDataFileInfo->ErcEvt,sizeof(ErcSave));
//	delay(50);
	JProgramInfo->CurrErc.Buff[0]=0;
	JProgramInfo->Para.ChangedJiZhongQiInfo = 2;
	SdPrint("\n\rCreateErr60\n\r")
//	JProgramInfo->FileSaveFlag.ercflag = 1;
}

void SaveAlarmData(TS ts)
{//����澯��Ϣ
	//return;
	if(JProgramInfo->CurrErc.Buff[0]==1)
	{
		CreateErr01(ts);
	}
	if(JProgramInfo->CurrErc.Buff[0]==2)//10.31
	{
		CreateErr02(ts);
	}
	if(JProgramInfo->CurrErc.Buff[0]==3)
	{
		CreateErr03(ts);
	}
	if(JProgramInfo->CurrErc.Buff[0]==20)
	{
		CreateErr20(ts);
	}
	if(JProgramInfo->CurrErc.Buff[0]==31)
	{
		CreateErr31(ts);
	}
	if(JProgramInfo->CurrErc.Buff[0]==21)
	{
		CreateErr21(ts);
	}
	if(JProgramInfo->CurrErc.Buff[0]==60)
	{
		CreateErr60(ts);
	}
//	if (old_ts.Minute != ts.Minute)
//	{
//		for(metn=0;metn<PointMax;metn++)
//		{
//			CreateErr30(ts,metn);
//		}
//		old_ts = ts;
//	}

//	CreateErr14(ts);
	CreateErr32(ts);
	ClearWaitTimes(ProjectNo,JProgramInfo);
	if (JDataFileInfo->data485[0+PortBegNum].Flag==1)//���㴮�ڳ����ɹ�
	{
//		printf("\nJDataFileInfo->data485[0+PortBegNum].Flag==1\n");
		for(metn=0;metn<PointMax;metn++)
		{
			//printf("\nmetn=%d JParamInfo3761->Point.pt[metn].f10.UserType =%02x", metn, JParamInfo3761->Point.pt[metn].f10.UserType);//yangdongtype
			if (JParamInfo3761->group2.f10[metn].port!=(1+PortBegNum))
				continue;
			if ((JParamInfo3761->group2.f10[metn].UserType & 0x0f) != 2)
			{
				//JParamInfo3761->Point.pt[metn].f25.Type = 9;
//				char tmpstr[200]; //yangdongtype
//				sprintf(tmpstr,"echo \"%s %d: men = %d UserType=%d\" >> /nand/bin/mytype.tmp",
//						__FILE__, __LINE__,metn,JParamInfo3761->Point.pt[metn].f10.UserType);
//				system(tmpstr);
			}
			CreateErr09(ts,metn);
			CreateErr10(ts,metn);
			CreateErr11(ts,metn);
			CreateErr17(ts,metn);
			CreateErr24(ts,metn);
			CreateErr25(ts,metn);
			CreateErr26(ts,metn);
			CreateErr33(ts,metn);
			CreateErr8(ts,metn);
			CreateErrOther(ts,metn);
			//if (JParamInfo3761->group8.f59.TingZou>0)
			//	CreateErr30(ts,metn);//JDataFileInfo->data485[0+PortBegNum].ts
		}
		JDataFileInfo->data485[0+PortBegNum].Flag=0;
	}
	if (JDataFileInfo->data485[1+PortBegNum].Flag==1)
	{
		//printf("\nJDataFileInfo->data485[1+PortBegNum].Flag==1\n");
		for(metn=0;metn<PointMax;metn++)
		{
			if (JParamInfo3761->group2.f10[metn].port!=(2+PortBegNum))
				continue;
			if ((JParamInfo3761->group2.f10[metn].UserType & 0x0f) != 2)
			{
				//JParamInfo3761->Point.pt[metn].f25.Type = 9;
			}
			CreateErr09(ts,metn);
			CreateErr10(ts,metn);
			CreateErr11(ts,metn);
			CreateErr17(ts,metn);
			CreateErr24(ts,metn);
			CreateErr25(ts,metn);
			CreateErr26(ts,metn);
			CreateErr33(ts,metn);
			CreateErr8(ts,metn);
			CreateErrOther(ts,metn);
			//if (JParamInfo3761->group8.f59.TingZou>0)
			//	CreateErr30(ts,metn);//JDataFileInfo->data485[1+PortBegNum].ts
		}
		JDataFileInfo->data485[1+PortBegNum].Flag=0;
	}
	if (JDataFileInfo->data485[2+PortBegNum].Flag==1)
	{
		printf("\nJDataFileInfo->data485[2+PortBegNum].Flag==1\n");
		for(metn=0;metn<PointMax;metn++)
		{
			if (JParamInfo3761->group2.f10[metn].port!=(3+PortBegNum))
				continue;
			if ((JParamInfo3761->group2.f10[metn].UserType & 0x0f) != 2)
			{
				//JParamInfo3761->Point.pt[metn].f25.Type = 9;
			}
			CreateErr09(ts,metn);
			CreateErr10(ts,metn);
			CreateErr11(ts,metn);
			CreateErr17(ts,metn);
			CreateErr24(ts,metn);
			CreateErr25(ts,metn);
			CreateErr26(ts,metn);
			CreateErr33(ts,metn);
			CreateErr8(ts,metn);
			CreateErrOther(ts,metn);
			//if (JParamInfo3761->group8.f59.TingZou>0)
			//	CreateErr30(ts,metn);//JDataFileInfo->data485[2+PortBegNum].ts
		}
		JDataFileInfo->data485[2+PortBegNum].Flag=0;
	}
	//songjian
	if (JDataFileInfo->data485[4+PortBegNum].Flag==1)
	{
		for(metn=0;metn<PointMax;metn++)
		{
			if (JParamInfo3761->group2.f10[metn].port!=(5+PortBegNum))
				continue;
			//printf("\n JParamInfo3761->Point.pt[metn].f25.Type ==%d\n",JParamInfo3761->Point.pt[metn].f25.Type);
			if ((JParamInfo3761->group2.f10[metn].UserType & 0x0f) != 2)
			{
				//printf("\n JParamInfo3761->Point.pt[%d].f10.UserType =%d \n",metn, JParamInfo3761->Point.pt[metn].f10.UserType);
				//JParamInfo3761->Point.pt[metn].f25.Type = 9;
			}
			CreateErr09(ts,metn);
			CreateErr10(ts,metn);
			CreateErr11(ts,metn);
			CreateErr17(ts,metn);
			CreateErr24(ts,metn);
			CreateErr25(ts,metn);
			CreateErr26(ts,metn);
			CreateErr33(ts,metn);
			CreateErr8(ts,metn);
			CreateErrOther(ts,metn);
			//if (JParamInfo3761->group8.f59.TingZou>0)
			//	CreateErr30(ts,metn);//JDataFileInfo->data485[4+PortBegNum].ts
		}
		JDataFileInfo->data485[4+PortBegNum].Flag=0;
	}
}
