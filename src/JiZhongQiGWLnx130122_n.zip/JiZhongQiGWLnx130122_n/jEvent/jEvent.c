/*
 * jEvent.c
 *
 *  Created on: 2013-1-7
 *      Author: Administrator
 */


#include "jEvent.h"

#define READ_BUF_SIZE 		300

int jEventPrint;
int ylflg,dlflg;
int metn;
FILE *fp;
unsigned char ProjectNo; //�ӳ�������е�����빲���ڴ��е�ProjectID��ͬ ProjectID��ϵͳ������߼����̺�
int ComPort;//�򿪶˿�ʱ���ص��߼��˿ں�
int chid;
int device=0;
int ComPort;
TS old_ts;
INT8U df_flag;   //���־
INT8U mf_flag;   //�±�־
INT8U Now_Min,BatOffCount;
uintptr_t port1, port2, port3;
INT8U TempBuf[60],TempStr[60];
SMFiles smfile2;
INT8U Day[PointMax],Month[PointMax];
name_attach_t  *attach;
PDD_t err30PDD[PointMax];

ParamInfo3761* JParamInfo3761;
DataFileInfo*  JDataFileInfo;		//������Ϣ�ṹ
ConfigInfo*    JConfigInfo;
ProgramInfo* JProgramInfo;		//������Ϣ�ṹ

extern void CreateErr14(TS ts);
extern void CreateErr04(TS ts);
extern void CreateErr30(TS ts,int met);
extern void CreateErr09(TS ts);
extern void SaveAlarmData();
extern void DeleteHourData(TS *ts);

extern void DoRiYueTongJi(TS ts,INT16U i);
extern void DoRiYueTongJi1(TS ts,INT16U i);

//����ע��,��ȡ����źͳ�������
INT8U GetProjects(INT32S argc, char * argv[])
{
	char proc_name[32] = "";

	if (argc < 2)
		return (FALSE);
	ProjectNo = atoi(argv[1]);
#ifdef __linux__
	sprintf(proc_name, "%s", argv[0]);
#else
	sprintf(proc_name, "%s %d", argv[0], ProjectNo);
#endif
	return (TRUE);
}


//�������ܣ������˳�ǰ����
void QuitProcess(int signo)
{
	delay(100);
	JProgramInfo->Projects[ProjectNo].ProjectID=0;
   	printf("jEvent quit\n\r");
   	if (jEventPrint==2)
	{
	   fclose(fp);
	   fp=NULL;
	}
	exit(0);
}

void *del_data()
{
//	int delflg=0;
	int j;
	TS ts,tsn;

	TSGet(&tsn);

    while(1)
    {
 //   	fprintf(stderr,"del_data\n");
    	delay(50);
	    TSGet(&ts);
    	for (j=0;j<100;j++)
    	{
			delay(10);

			if (old_ts.Minute != ts.Minute)
			{
				for(metn=0;metn<PointMax;metn++)
				{
					CreateErr30(ts,metn);
				}
				old_ts = ts;
			}
			CreateErr14(ts);
			CreateErr04(ts);
			CreateErr09(ts);			//9.22
			if ((j+1)%10==0)
				SaveAlarmData(ts); //���ɸ澯������
			ClearWaitTimes(ProjectNo,JProgramInfo);
    	}
		if (((ts.Minute+60-Now_Min)%60) > 0)
		{
			if (JProgramInfo->PowerOFFMessage == 1)
			{
				if (BatOffCount==0)
				{
					JProgramInfo->Para.ChangedJiZhongQiInfo = 2;
					JProgramInfo->Para.ChangedPointInfo = PointMax+1;
					JProgramInfo->stateflags.JCFlag=1;

					JDataFileInfo->DayRunTj.ts = ts;			//���渴λ����9.26
					JDataFileInfo->DayRunTj.ResetTime++;
					JDataFileInfo->YueRunTj.ts = ts;
					JDataFileInfo->YueRunTj.ResetTime++;
//					memset(TempFile, 0, 60);
//					sprintf((char *) TempFile, "/nand/DataAlarm/d%02d.dat",ts.Day);
//					SaveFile((char *) TempFile, &JDataFileInfo->DayRunTj,sizeof(TongJi));
//					memset(TempFile, 0, 60);
//					sprintf((char *) TempFile, "/nand/DataAlarm/m%02d.dat",ts.Month);
//					SaveFile((char *) TempFile, &DataFileInfo->YueRunTj,sizeof(TongJi));
					JProgramInfo->FileSaveFlag.drunflag = 1;
					JProgramInfo->FileSaveFlag.mrunflag = 1;
				}
				BatOffCount+=((ts.Minute+60-Now_Min)%60);
			}
			else
			{
				BatOffCount=0;
			}
			Now_Min=ts.Minute;
		}
    }
	return (void *)0;
}


void *tongji()
{
	int i;
	TS ts,riyue_ts;
	unsigned char old_min;

	TSGet(&ts);
	old_min= ts.Minute;

	while (1)
	{
		TSGet(&riyue_ts);
		if(old_min!=riyue_ts.Minute)
		{
			if(((JProgramInfo->zone)&0x7f) == JIANGSU)
			{
				for(i=1;i<=1;i++)		//{Yue_Data_Calc(ts,i);}
				DoRiYueTongJi(ts,i);
			}
			else
			{
				for(i=1;i<PointMax;i++)		//{Yue_Data_Calc(ts,i);}
				{
					if(((JProgramInfo->zone)>>7&0x01) == 1)
						DoRiYueTongJi1(ts,i);
					else
						DoRiYueTongJi(ts,i);
				}
			}
			old_min = riyue_ts.Minute;
		}
		delay(500);
	}
	return (void *)0;
}


int main(int argc, char *argv[]) {
	struct sigaction sa1;
	int i=0,j=0;
	INT8U TempBuf[60];
	TS tsll;
	unsigned char Now_Min;

   if (getenv("jEventPrt")==NULL)
   {
	   jEventPrint = 0;
		if (getenv("jAllProgPrt")!=NULL)
			jEventPrint = atoi(getenv("jAllProgPrt"));
   }
   else jEventPrint = atoi(getenv("jEventPrt"));

   jEventPrint = 1;
   if (jEventPrint==2)
   {
		memset(TempBuf, 0, 60);
		sprintf((char *) TempBuf, "%s/dataSave_log.txt", _USERDIR_);
		fp=fopen((char *) TempBuf,"a+");
   }
   jEventPrint=0;
	markver();

	JParamInfo3761 = Open1ShMem("ParamInfo3761",sizeof(ParamInfo3761),NULL);
	JDataFileInfo = Open1ShMem("DataFileInfo",sizeof(DataFileInfo),NULL);
	JConfigInfo = Open1ShMem("ConfigInfo",sizeof(ConfigInfo),NULL);
	JProgramInfo = Open1ShMem("ProgramInfo",sizeof(ProgramInfo),NULL);

	if(JProgramInfo->mainData.MemoryLength!=sizeof(ProgramInfo))
	{
		fprintf( stderr, "jEventPrint base mem uncompared prog will exit %d :\n",sizeof(ProgramInfo));
		return EXIT_FAILURE;
	}
	if(!GetProjects(argc, argv))
	{
		printf("\n jEvent Bad command format. Type 'use exe_name' for help!\n\r");
		return EXIT_FAILURE;
	}
	JProgramInfo->Projects[ProjectNo].ProjectID=getpid();//���浱ǰ���̵Ľ��̺�
	printf("Starting jEvent ..........%d\n\r",ProjectNo);
	ClearWaitTimes(ProjectNo,JProgramInfo);
	sa1.sa_handler = QuitProcess;  //sa_handler�ֶ�ָ��һ���źŴ�������ָ�롣���������һ���źű�����Ϊ����Ψһ������
	sigemptyset(&sa1.sa_mask);    //��ʼ���հ׵��ź�������
	sa1.sa_flags = 0;
	/*�����ź����а������źŶ���*/
	sigaction(SIGTERM, &sa1,NULL);
	sigaction(SIGSYS, &sa1,NULL);
	sigaction(SIGPWR, &sa1,NULL);
	sigaction(SIGKILL, &sa1,NULL);
	sigaction(SIGQUIT, &sa1,NULL);
	sigaction(SIGILL, &sa1,NULL);
	sigaction(SIGINT, &sa1,NULL);
	sigaction(SIGHUP, &sa1,NULL);
	sigaction(SIGABRT, &sa1,NULL);
	sigaction(SIGBUS, &sa1,NULL);

 //   SdPrint("Process del_data begin\n");
	pthread_t thread_alarm;
	pthread_t thread_tongji;
	int temp;
	memset(&thread_alarm, 0, sizeof(pthread_t));
	memset(&thread_tongji, 0, sizeof(pthread_t));
	//�����߳�
	if((temp = pthread_create(&thread_alarm, NULL, del_data, NULL)) != 0) //�������߳�
	{
		SdPrint("Process del_data create fail!\n");
	}
	else
	{
	//	SdPrint("Process del_data is created\n");
	}

	//�����߳�
	if((temp = pthread_create(&thread_tongji, NULL, tongji, NULL)) != 0) //�������߳�
	{
		SdPrint("Process tongji create fail!\n");
	}
	else
	{
	//	SdPrint("Process tongji is created\n");
	}

	delay(1000);
	/*������ѭ������ʼѭ���ı���ɼ�������*/
	i=0;
	j=0;
	ylflg=0;
	dlflg=0;
	metn=0;
	BatOffCount=0;
	memset(Day,0,sizeof(Day));
	memset(Month,0,sizeof(Month));

	TSGet(&tsll);
	Now_Min = tsll.Minute;
	memset(err30PDD, 0, PointMax*sizeof(PDD_t));
  	while (1)
   	{
  		ClearWaitTimes(ProjectNo,JProgramInfo);
  		delay(1000);

 	   if (jEventPrint == 0)
 	   {
 		   if ((JProgramInfo->mainData.Prt_Flag==3) || (JProgramInfo->mainData.Prt_Flag==50))
 			  jEventPrint = 3;
 	   }
 	   else
 	   {
 		   if ((JProgramInfo->mainData.Prt_Flag==103) || (JProgramInfo->mainData.Prt_Flag==150))
 			  jEventPrint = 0;
 	   }

		TSGet(&tsll);
		if ((tsll.Minute+60-Now_Min)%60 > 0)
		{//ͳ�ƹ���ʱ��
			if(abs(tsll.Minute - Now_Min)>3){		//9.23��վ��ʱ����ʱ�����̫�󣬲�ͳ�ƹ���ʱ��
				Now_Min = tsll.Minute;
			}else {
				if (JProgramInfo->BoardElecState==1)
				{
					JDataFileInfo->YueRunTj.GdTime+=((tsll.Minute+60-Now_Min)%60);
					JDataFileInfo->DayRunTj.GdTime+=((tsll.Minute+60-Now_Min)%60);
					SdPrint("YueRunTj.GdTime=%d,ts.Min=%d,Now_Min=%d\n",JDataFileInfo->YueRunTj.GdTime,tsll.Minute,Now_Min);
				}
				Now_Min=tsll.Minute;
			}
		}
   	}

    QuitProcess(0);
 	return EXIT_SUCCESS;
}
