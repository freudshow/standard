/*
 * jTongji.c
 *
 *  Created on: 2013-1-7
 *      Author: Administrator
 */

#include "jEvent.h"

#define TONGJIMAX(RealValve, LimitValue, Time) 					\
		if(RealValve != 0xffffffff)  							\
		{														\
			if (RealValve>=LimitValue) 							\
			{													\
				LimitValue=RealValve;							\
				INT32U_BCD(ts.Minute,&Time[0],1);				\
				INT32U_BCD(ts.Hour,&Time[1],1);					\
				INT32U_BCD(ts.Day,&Time[2],1);					\
			}													\
		}

#define TONGJIMIN(RealValve, LimitValue, Time) 					\
		if(RealValve != 0xffffffff)  							\
		{														\
			if (RealValve<=LimitValue || LimitValue<2) 							\
			{													\
				LimitValue=RealValve;							\
				INT32U_BCD(ts.Minute,&Time[0],1);				\
				INT32U_BCD(ts.Hour,&Time[1],1);					\
				INT32U_BCD(ts.Day,&Time[2],1);					\
			}													\
		}

#define TONGJIMAX2(RealValve, LimitValue, Time)			\
		if(RealValve != 0xffffffff)						\
		{												\
			if(RealValve >= LimitValue){					\
				LimitValue=RealValve;					\
				TimeGetType18(Time,ts);			\
			}													\
		}

#define TONGJIMIN2(RealValve, LimitValue, Time)			\
		if(RealValve != 0xffffffff)						\
		{												\
			if(RealValve <= LimitValue || LimitValue<2){					\
				LimitValue=RealValve;					\
				TimeGetType18(Time,ts);			\
			}													\
		}

#define TONGJI1(RealValve, LimitValue) 					\
		if(RealValve != 0xffffffff)  							\
		{														\
			if (RealValve>=LimitValue) 							\
				LimitValue=RealValve;							\
		}

INT8U a_ussx_last_time[PointMax];//Խ�����޳���ʱ��,���=3���϶�ΪԽ�����ޣ���ͬ��
INT8U a_uxxx_last_time[PointMax];//Խ�����޳���ʱ��
INT8U b_ussx_last_time[PointMax];//Խ�����޳���ʱ��
INT8U b_uxxx_last_time[PointMax];//Խ�����޳���ʱ��
INT8U c_ussx_last_time[PointMax];//Խ�����޳���ʱ��
INT8U c_uxxx_last_time[PointMax];//Խ�����޳���ʱ��

INT32U MinValue2(INT32U a,INT32U b,INT32U c)
{
	INT32U t;
	if(a==0xffffffff)a=0;
	if(b==0xffffffff)b=0;
	if(c==0xffffffff)c=0;
	t=a;
	if(t>b)t=b;
	if(t>c)t=c;
	return t;
}

INT32U MaxValue2(INT32U a,INT32U b,INT32U c)
{
	INT32U t;
	if(a==0xffffffff)a=0;
	if(b==0xffffffff)b=0;
	if(c==0xffffffff)c=0;
	t=a;
	if(t<b)t=b;
	if(t<c)t=c;
	return t;
}

void TimeGetType17(INT8U *D,TS ts)
{
	D[0]=ts.Minute/10;
	D[0]=(D[0]<<4)+(ts.Minute%10);
	D[1]=ts.Hour/10;
	D[1]=(D[1]<<4)+(ts.Hour%10);
	D[2]=ts.Day/10;
	D[2]=(D[2]<<4)+(ts.Day%10);
	D[3]=ts.Month/10;
	D[3]=(D[3]<<4)+(ts.Month%10);
}

void TimeGetType18(INT8U *D,TS ts)
{
	D[0]=ts.Minute/10;
	D[0]=(D[0]<<4)+(ts.Minute%10);
	D[1]=ts.Hour/10;
	D[1]=(D[1]<<4)+(ts.Hour%10);
	D[2]=ts.Day/10;
	D[2]=(D[2]<<4)+(ts.Day%10);
}

unsigned char GetValuefromFile(INT8U DI1,INT8U DI0, unsigned char *Dest, unsigned char *buf)//����
{
	//int datalen=0;
	if(((DI0|0x0f) == 0x1f) && (DI1 == 0xB6))
		memcpy(Dest, buf+(DI0-0x10-1)*2, 2);
	else if(((DI0|0x0f) == 0x2f) && (DI1 == 0xB6))
		memcpy(Dest, buf+(DI0-0x20-1)*3, 3);
	else if(((DI0|0x0f) == 0x3f) && (DI1 == 0xB6))
		memcpy(Dest, buf+(DI0-0x30)*3, 3);
	else if(((DI0|0x0f) == 0x1f) && (DI1 == 0xA0))
		memcpy(Dest, buf+(DI0-0x30)*3, 3);
	else
	{
	}
	return 1;
}

int GetManyDataNew(DataFlg *data,INT8U *reslutBuf,INT8U DI1,INT8U DI0)				//9.23
{
	INT8U i,isFlag=0;
	for(i=0;i<ManyFlagsCount;i++)
	{
		if(data[i].flg.Dataflag[0]==DI0 && data[i].flg.Dataflag[1]==DI1){
            memcpy(reslutBuf,&data[i].datas[0],sizeof(data[i].datas));
            isFlag=1;
            break;
		}
	}
	if(isFlag==0) {
		for(i=0;i<ManyFlagsCount;i++) {
			if(data[i].flg.Dataflag[0]==(DI0|0x0f)&&data[i].flg.Dataflag[1]==DI1)
			{
				//memcpy(reslutBuf,&data[i].datas[0],sizeof(data[i].datas));
				GetValuefromFile(DI1, DI0, reslutBuf, &data[i].datas[0]);
				if(reslutBuf[0]==0xee && reslutBuf[1]==0xee)
					isFlag=0;
				else
					isFlag=1;
				break;
			}
		}
	}
	if(isFlag==0){
		memset(reslutBuf,0x00,sizeof(data[0].datas));
		return 0;
	}
	return isFlag;
}

int GetManyData0ld(DataFlg *data,INT8U *reslutBuf,INT8U DI1,INT8U DI0)				//9.23
{
	INT8U i,isFlag=0;
	for(i=0;i<ManyFlagsCount;i++)
	{
		if(data[i].flg.Dataflag[0]==DI0 && data[i].flg.Dataflag[1]==DI1){
            memcpy(reslutBuf,&data[i].datas[0],sizeof(data[i].datas));
            isFlag=1;
            break;
		}
	}
	if(isFlag==0) {
		for(i=0;i<ManyFlagsCount;i++) {
			if(data[i].flg.Dataflag[0]==(DI0|0x0f)&&data[i].flg.Dataflag[1]==DI1){
				memcpy(reslutBuf,&data[i].datas[0],sizeof(data[i].datas));
				isFlag=1;
				break;
			}
		}
	}

	if(isFlag==0){
		memset(reslutBuf,0x00,sizeof(data[0].datas));
		return 0;
	}
	return 1;
}

void DoRiYueTongJi(TS ts,INT16U P)
{
	if(JParamInfo3761->group2.f10[P-1].Status != 1)
		return;
	if((JParamInfo3761->group2.f10[P-1].port!=1)&&(JParamInfo3761->group2.f10[P-1].port!=2) && (JParamInfo3761->group2.f10[P-1].port!=3) &&
		(JParamInfo3761->group2.f10[P-1].port!=6) &&(JParamInfo3761->group2.f10[P-1].port!=31))
		return;
	INT8U TempBuf[60];
	SMFiles smfile;
	INT8U tempManyData[DataLenMax];
	Cl_Stat_Set real_cl_stat;

	memset(&real_cl_stat, 0, sizeof(Cl_Stat_Set));
	//�ѳ��������ݴ�curr.dat����real_cl_stat
	memset(TempBuf,0,60);
	sprintf((char*)TempBuf,"/nand/DataCurr/%04d/curr.dat",P);
	if (ReadFile((char *)TempBuf, &smfile,sizeof(SMFiles),JProgramInfo) == 1){
		return;
	}
	//�ѳ��������ݴ�curr.dat����real_cl_stat
	memset(tempManyData,0,sizeof(tempManyData));
	if(GetManyDataNew(smfile.sm.datas,&tempManyData[0],0xb6,0x30))
		real_cl_stat.P_All = BCD_INT32(&tempManyData[0], 3);//�й�����
	else
		real_cl_stat.P_All = 0xffffffff;
	if(GetManyDataNew(smfile.sm.datas,&tempManyData[0],0xb6,0x31))
		real_cl_stat.P_U = BCD_INT32(&tempManyData[0], 3);//A�й�����
	else
		real_cl_stat.P_U = 0xffffffff;
	if(GetManyDataNew(smfile.sm.datas,&tempManyData[0],0xb6,0x32))
		real_cl_stat.P_V = BCD_INT32(&tempManyData[0], 3);//B�й�����
	else
		real_cl_stat.P_V = 0xffffffff;
	if(GetManyDataNew(smfile.sm.datas,&tempManyData[0],0xb6,0x33))
		real_cl_stat.P_W = BCD_INT32(&tempManyData[0], 3);//C�й�����
	else
		real_cl_stat.P_W = 0xffffffff;

	memset(tempManyData,0,sizeof(tempManyData));
	GetManyData0ld(smfile.sm.datas,&tempManyData[0],0xb6,0x40);
	real_cl_stat.Q = BCD_INT32(&tempManyData[0], 2);//�޹�����
	GetManyData0ld(smfile.sm.datas,&tempManyData[0],0xb6,0x41);
	real_cl_stat.QA = BCD_INT32(&tempManyData[0], 2);//A�޹�����
	GetManyData0ld(smfile.sm.datas,&tempManyData[0],0xb6,0x42);
	real_cl_stat.QB = BCD_INT32(&tempManyData[0], 2);//B�޹�����
	GetManyData0ld(smfile.sm.datas,&tempManyData[0],0xb6,0x43);
	real_cl_stat.QC = BCD_INT32(&tempManyData[0], 2);//C�޹�����

	memset(tempManyData,0,sizeof(tempManyData));
	if(GetManyDataNew(smfile.sm.datas,&tempManyData[0],0xb6,0x11))
		real_cl_stat.VA = BCD_INT32(&tempManyData[0], 2);	//A��ѹ
	else
		real_cl_stat.VA = 0xffffffff;
	if(GetManyDataNew(smfile.sm.datas,&tempManyData[0],0xb6,0x12))
		real_cl_stat.VB = BCD_INT32(&tempManyData[0], 2);	//B��ѹ
	else
		real_cl_stat.VB = 0xffffffff;
	if(GetManyDataNew(smfile.sm.datas,&tempManyData[0],0xb6,0x13))
		real_cl_stat.VC = BCD_INT32(&tempManyData[0], 2);	//C��ѹ
	else
		real_cl_stat.VC = 0xffffffff;

	memset(tempManyData,0,sizeof(tempManyData));		//����
	if(GetManyDataNew(smfile.sm.datas,&tempManyData[0],0xb6, 0x21))
		real_cl_stat.IA = BCD_INT32(&tempManyData[0], 2);	//A����
	else
		real_cl_stat.IA = 0xffffffff;
	if(GetManyDataNew(smfile.sm.datas,&tempManyData[0],0xb6, 0x22))
		real_cl_stat.IB = BCD_INT32(&tempManyData[0], 2);	//A����
	else
		real_cl_stat.IB = 0xffffffff;
	if(GetManyDataNew(smfile.sm.datas,&tempManyData[0],0xb6, 0x23))
		real_cl_stat.IC = BCD_INT32(&tempManyData[0], 2);	//A����
	else
		real_cl_stat.IC = 0xffffffff;

	memset(tempManyData,0,sizeof(tempManyData));		//��������
	GetManyData0ld(smfile.sm.datas,&tempManyData[0],0xb6,0x5f);
	real_cl_stat.COS = BCD_INT32(&tempManyData[0], 2);		//��������
	real_cl_stat.COSA = BCD_INT32(&tempManyData[0]+2, 2);	//A��������
	real_cl_stat.COSB = BCD_INT32(&tempManyData[0]+4, 2);	//B��������
	real_cl_stat.COSC = BCD_INT32(&tempManyData[0]+6, 2);	//C��������

	memset(tempManyData,0,sizeof(tempManyData));		//���������		//9.23
	GetManyData0ld(smfile.sm.datas,&tempManyData[0],0xa0,0x10);
	real_cl_stat.P_All_XL = BCD_INT32(&tempManyData[0], 3);		//���������
	real_cl_stat.P_U_XL = BCD_INT32(&tempManyData[0]+3, 3);		//A�������   ������ȡ���Ƿ���1,2,3�ģ���A��B��C������
	real_cl_stat.P_V_XL = BCD_INT32(&tempManyData[0]+6, 3);		//B�������
	real_cl_stat.P_W_XL = BCD_INT32(&tempManyData[0]+9, 3);		//C�������

	SdPrint("\n\n������ţ� %d\n", P);
	SdPrint("\nA��ѹ :%d B��ѹ:%d C��ѹ :%d    A���� :%d B���� :%d C���� :%d \n",
			real_cl_stat.VA, real_cl_stat.VB,real_cl_stat.VC,
			real_cl_stat.IA, real_cl_stat.IB, real_cl_stat.IC);
	SdPrint("\n�й�����:%d A�й����� :%d B�й����� :%d C�й����� :%d  �޹�����:%d A�޹����� :%d B�޹����� :%d C�޹����� :%d \n",
			real_cl_stat.P_All, real_cl_stat.P_U,real_cl_stat.P_V,real_cl_stat.P_W,
			real_cl_stat.Q, real_cl_stat.QA, real_cl_stat.QB, real_cl_stat.QC);
	SdPrint("\n��������:%d A�������� :%d B�������� :%d C�������� :%d \n",
			real_cl_stat.COS, real_cl_stat.COSA,real_cl_stat.COSB,real_cl_stat.COSC);

	if(1)
	{
		ClearWaitTimes(ProjectNo,JProgramInfo);

		INT16U US,UX,UD,USS,UXX,UVWXZ=0,VCalc=0,VValue,VMax,VMin;
		INT16S ISS,IS,IValue,IMax,ICalc,ABCXZ,IMin;
		INT32U SSS,SS,PS;
		float PS1;
		TS ts;
		TSGet(&ts);
		{
		//	if(real_cl_stat.Valid!=1)continue;//������1(i=0)��Ϊ����������ѹ�ϸ���,valid����Զ��=1�� ��Ӱ��ϸ��������ɼ�
			int xian1 = BCD_INT32(&JParamInfo3761->Point[P - 1].f28.CosFenDuan_Xian1[0],2);
			int xian2 = BCD_INT32(&JParamInfo3761->Point[P - 1].f28.CosFenDuan_Xian2[0],2);
			SdPrint("\n==== xian1 =%d   xian2 =%d",xian1,xian2);
			if(real_cl_stat.COS<xian1)//�¼� ���㹦�������ۼ�ʱ��
			{
				JDataFileInfo->DayTjValue[P-1].QuDuan1_Count++;
				JDataFileInfo->YueTjValue[P-1].QuDuan1_Count++;
			}
			if((real_cl_stat.COS>=xian1)&&(real_cl_stat.COS<xian2))//�¼� ���㹦�������ۼ�ʱ��
			{
				JDataFileInfo->DayTjValue[P-1].QuDuan2_Count++;
				JDataFileInfo->YueTjValue[P-1].QuDuan2_Count++;
			}
			if(real_cl_stat.COS>=xian2)//�¼� ���㹦�������ۼ�ʱ��
			{
				JDataFileInfo->DayTjValue[P-1].QuDuan3_Count++;
				JDataFileInfo->YueTjValue[P-1].QuDuan3_Count++;
			}
			SdPrint("\n==== real_cl_stat.COS=%d  ",real_cl_stat.COS);
			SdPrint("\n==== xian1count=%d   xian2count=%d  xian3count=%d",JDataFileInfo->DayTjValue[P-1].QuDuan1_Count,JDataFileInfo->DayTjValue[P-1].QuDuan2_Count,JDataFileInfo->DayTjValue[P-1].QuDuan3_Count);
	//		if(Jmemory->F26Valid==1)   //��½�����޸�
			{
				US=((JParamInfo3761->Point[P - 1].f26.V_He_ge_S[1]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.V_He_ge_S[1]&0x0f);
				US=(US*100)+((JParamInfo3761->Point[P - 1].f26.V_He_ge_S[0]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.V_He_ge_S[0]&0x0f);

				UX=((JParamInfo3761->Point[P - 1].f26.V_He_ge_X[1]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.V_He_ge_X[1]&0x0f);
				UX=(UX*100)+((JParamInfo3761->Point[P - 1].f26.V_He_ge_X[0]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.V_He_ge_X[0]&0x0f);

				UD=((JParamInfo3761->Point[P - 1].f26.V_Duan_Men[1]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.V_Duan_Men[1]&0x0f);
				UD=(UD*100)+((JParamInfo3761->Point[P - 1].f26.V_Duan_Men[0]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.V_Duan_Men[0]&0x0f);

				USS=((JParamInfo3761->Point[P - 1].f26.V_He_ge_SS[1]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.V_He_ge_SS[1]&0x0f);
				USS=(USS*100)+((JParamInfo3761->Point[P - 1].f26.V_He_ge_SS[0]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.V_He_ge_SS[0]&0x0f);

				UXX=((JParamInfo3761->Point[P - 1].f26.V_He_ge_XX[1]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.V_He_ge_XX[1]&0x0f);
				UXX=(UXX*100)+((JParamInfo3761->Point[P - 1].f26.V_He_ge_XX[0]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.V_He_ge_XX[0]&0x0f);

				ISS=(((JParamInfo3761->Point[P - 1].f26.I_SS[2]>>4)&0x07)*10)+
					(JParamInfo3761->Point[P - 1].f26.I_SS[2]&0x0f);
				ISS=(ISS*100)+((JParamInfo3761->Point[P - 1].f26.I_SS[1]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.I_SS[1]&0x0f);
				ISS=(ISS*100)+((JParamInfo3761->Point[P - 1].f26.I_SS[0]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.I_SS[0]&0x0f);

				IS=(((JParamInfo3761->Point[P - 1].f26.I_S[2]>>4)&0x07)*10)+
					(JParamInfo3761->Point[P - 1].f26.I_S[2]&0x0f);
				IS=(IS*100)+((JParamInfo3761->Point[P - 1].f26.I_S[1]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.I_S[1]&0x0f);
				IS=(IS*100)+((JParamInfo3761->Point[P - 1].f26.I_S[0]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.I_S[0]&0x0f);
				SdPrint("US=%d,UX=%d,UD=%d,USS=%d,UXX=%d\n",US,UX,UD,US,UXX);
				SdPrint("IS=%d,ISS=%d\n",IS,ISS);
				//-------------------------------------------------------------�յ�ѹ���ֵ������ʱ��---------------
				TONGJIMAX2(real_cl_stat.VA, JDataFileInfo->DayTjValue[P-1].DUUMAX, JDataFileInfo->DayTjValue[P-1].DUUMAX_TIME);
				SdPrint("JDataFileInfo->DayTjValue[P-1].DUUMAX_TIME=%d\n",JDataFileInfo->DayTjValue[P-1].DUUMAX_TIME[0]);
				TONGJIMAX2(real_cl_stat.VB, JDataFileInfo->DayTjValue[P-1].DUVMAX, JDataFileInfo->DayTjValue[P-1].DUVMAX_TIME);
				TONGJIMAX2(real_cl_stat.VC, JDataFileInfo->DayTjValue[P-1].DUWMAX, JDataFileInfo->DayTjValue[P-1].DUWMAX_TIME);

				//-------------------------------------------------------------�µ�ѹ���ֵ������ʱ��---------------
				TONGJIMAX2(real_cl_stat.VA, JDataFileInfo->YueTjValue[P-1].DUUMAX, JDataFileInfo->YueTjValue[P-1].DUUMAX_TIME);
				TONGJIMAX2(real_cl_stat.VB, JDataFileInfo->YueTjValue[P-1].DUVMAX, JDataFileInfo->YueTjValue[P-1].DUVMAX_TIME);
				TONGJIMAX2(real_cl_stat.VC, JDataFileInfo->YueTjValue[P-1].DUWMAX, JDataFileInfo->YueTjValue[P-1].DUWMAX_TIME);

				//-------------------------------------------------------------�յ�ѹ��Сֵ������ʱ��---------------
				TONGJIMIN2(real_cl_stat.VA, JDataFileInfo->DayTjValue[P-1].DUUMIN, JDataFileInfo->DayTjValue[P-1].DUUMIN_TIME);
				TONGJIMIN2(real_cl_stat.VB, JDataFileInfo->DayTjValue[P-1].DUVMIN, JDataFileInfo->DayTjValue[P-1].DUVMIN_TIME);
				TONGJIMIN2(real_cl_stat.VC, JDataFileInfo->DayTjValue[P-1].DUWMIN, JDataFileInfo->DayTjValue[P-1].DUWMIN_TIME);

				//-------------------------------------------------------------�µ�ѹ��Сֵ������ʱ��---------------
				TONGJIMIN2(real_cl_stat.VA, JDataFileInfo->YueTjValue[P-1].DUUMIN, JDataFileInfo->YueTjValue[P-1].DUUMIN_TIME);
				TONGJIMIN2(real_cl_stat.VB, JDataFileInfo->YueTjValue[P-1].DUVMIN, JDataFileInfo->YueTjValue[P-1].DUVMIN_TIME);
				TONGJIMIN2(real_cl_stat.VC, JDataFileInfo->YueTjValue[P-1].DUWMIN, JDataFileInfo->YueTjValue[P-1].DUWMIN_TIME);

				//------------------------------------------------------------�յ������ֵ������ʱ��----------------
				TONGJIMAX2(real_cl_stat.IA, JDataFileInfo->DayTjValue[P-1].DI_U_MAX, JDataFileInfo->DayTjValue[P-1].DIUMAX_TIME);
				TONGJIMAX2(real_cl_stat.IB, JDataFileInfo->DayTjValue[P-1].DI_V_MAX, JDataFileInfo->DayTjValue[P-1].DIVMAX_TIME);
				TONGJIMAX2(real_cl_stat.IC, JDataFileInfo->DayTjValue[P-1].DI_W_MAX, JDataFileInfo->DayTjValue[P-1].DIWMAX_TIME);
				TONGJIMAX2(real_cl_stat.IL, JDataFileInfo->DayTjValue[P-1].DI_L_MAX, JDataFileInfo->DayTjValue[P-1].DILMAX_TIME);

				//--------------------------------------------------------- �µ������ֵ������ʱ��-------------------
				TONGJIMAX2(real_cl_stat.IA, JDataFileInfo->YueTjValue[P-1].DI_U_MAX, JDataFileInfo->YueTjValue[P-1].DIUMAX_TIME);
				TONGJIMAX2(real_cl_stat.IB, JDataFileInfo->YueTjValue[P-1].DI_V_MAX, JDataFileInfo->YueTjValue[P-1].DIVMAX_TIME);
				TONGJIMAX2(real_cl_stat.IC, JDataFileInfo->YueTjValue[P-1].DI_W_MAX, JDataFileInfo->YueTjValue[P-1].DIWMAX_TIME);
				TONGJIMAX2(real_cl_stat.IL, JDataFileInfo->YueTjValue[P-1].DI_L_MAX, JDataFileInfo->YueTjValue[P-1].DILMAX_TIME);

				if(real_cl_stat.VA !=0xffffffff)
				{
					if(real_cl_stat.VA>USS)//---------------------------------�ж�UAԽ�����޷���//FkDdRealData
						a_ussx_last_time[P-1]++;
					else
						a_ussx_last_time[P-1]=0;

					if(real_cl_stat.VA<UXX)//---------------------------------�ж�UAԽ�����޷���
						a_uxxx_last_time[P-1]++;
					else
						a_uxxx_last_time[P-1]=0;

					JDataFileInfo->DayTjValue[P-1].U_A_Sum += real_cl_stat.VA;
					JDataFileInfo->YueTjValue[P-1].U_A_Sum += real_cl_stat.VA;

					if((real_cl_stat.VA>USS) && (a_ussx_last_time[P-1]>=1))//3------------�ж�UAԽ������
					{
						JDataFileInfo->DayTjValue[P-1].USSU_Count += 1;//3
						JDataFileInfo->YueTjValue[P-1].USSU_Count += 1;//3
						a_ussx_last_time[P-1] = 0;
					}
					else if(real_cl_stat.VA>US)//------------�ж�UAԽ����
					{
						JDataFileInfo->DayTjValue[P-1].USU_Count++;
						JDataFileInfo->YueTjValue[P-1].USU_Count++;
					}
					if((real_cl_stat.VA<UXX) && (a_uxxx_last_time[P-1] >= 1))//3	//�ж�UAԽ������
					{
						JDataFileInfo->DayTjValue[P-1].UXXU_Count += 1;//3
						JDataFileInfo->YueTjValue[P-1].UXXU_Count += 1;//3
						a_uxxx_last_time[P-1] = 0;
					}
					else if(real_cl_stat.VA<UX)//--------�ж�UAԽ����
					{
						JDataFileInfo->DayTjValue[P-1].UXU_Count++;
						JDataFileInfo->YueTjValue[P-1].UXU_Count++;
					}
					if((real_cl_stat.VA>UX) && (real_cl_stat.VA<US))  //---------UA�ϸ��ѹ
					{
						JDataFileInfo->DayTjValue[P-1].UHGU_Count++;
						JDataFileInfo->YueTjValue[P-1].UHGU_Count++;
					}
				}
				if(real_cl_stat.VB !=0xffffffff)
				{
					if(real_cl_stat.VB>USS)//---------------------------------�ж�UAԽ�����޷���
						b_ussx_last_time[P-1]++;
					else
						b_ussx_last_time[P-1]=0;

					if(real_cl_stat.VB<UXX)//---------------------------------�ж�UAԽ�����޷���
						b_uxxx_last_time[P-1]++;
					else
						b_uxxx_last_time[P-1]=0;

					JDataFileInfo->DayTjValue[P-1].U_B_Sum += real_cl_stat.VB;
					JDataFileInfo->YueTjValue[P-1].U_B_Sum += real_cl_stat.VB;

					if((real_cl_stat.VB>USS) && (b_ussx_last_time[P-1]>=1))//3------------�ж�UBԽ������
					{
						JDataFileInfo->DayTjValue[P-1].USSV_Count += 1;//3
						JDataFileInfo->YueTjValue[P-1].USSV_Count += 1;//3
						b_ussx_last_time[P-1] = 0;
					}
					else if(real_cl_stat.VB>US)//------------�ж�UBԽ����
					{
						JDataFileInfo->DayTjValue[P-1].USV_Count++;
						JDataFileInfo->YueTjValue[P-1].USV_Count++;
					}
					if((real_cl_stat.VB<UXX) && (b_uxxx_last_time[P-1]>=1))//3	//�ж�UBԽ������
					{
						JDataFileInfo->DayTjValue[P-1].UXXV_Count += 1;//3
						JDataFileInfo->YueTjValue[P-1].UXXV_Count += 1;//3
						b_uxxx_last_time[P-1] = 0;
					}
					else if(real_cl_stat.VB<UX)//--------�ж�UBԽ����
					{
						JDataFileInfo->DayTjValue[P-1].UXV_Count++;
						JDataFileInfo->YueTjValue[P-1].UXV_Count++;
					}
					if((real_cl_stat.VB>UX) && (real_cl_stat.VB<US))  //---------UB�ϸ��ѹ
					{
						JDataFileInfo->DayTjValue[P-1].UHGV_Count++;
						JDataFileInfo->YueTjValue[P-1].UHGV_Count++;
					}
				}

				if(real_cl_stat.VC !=0xffffffff)
				{
					if(real_cl_stat.VC>USS)//---------------------------------�ж�UCԽ�����޷���
						c_ussx_last_time[P-1]++;
					else
						c_ussx_last_time[P-1]=0;

					if(real_cl_stat.VC<UXX)//---------------------------------�ж�UCԽ�����޷���
						c_uxxx_last_time[P-1]++;
					else
						c_uxxx_last_time[P-1]=0;

					JDataFileInfo->DayTjValue[P-1].U_C_Sum += real_cl_stat.VC;//FkDdRealData
					JDataFileInfo->YueTjValue[P-1].U_C_Sum += real_cl_stat.VC;

					if((real_cl_stat.VC>USS) && (c_ussx_last_time[P-1]>=1))//3------------�ж�UCԽ������
					{
						JDataFileInfo->DayTjValue[P-1].USSW_Count += 1;//3
						JDataFileInfo->YueTjValue[P-1].USSW_Count += 1;//3
						c_ussx_last_time[P-1] = 0;
					}
					else if(real_cl_stat.VC>US)//------------�ж�UCԽ����
					{
						JDataFileInfo->DayTjValue[P-1].USW_Count++;
						JDataFileInfo->YueTjValue[P-1].USW_Count++;
					}
					if((real_cl_stat.VC<UXX) && (c_uxxx_last_time[P-1]>=1))//3	//�ж�UCԽ������
					{
						JDataFileInfo->DayTjValue[P-1].UXXW_Count += 1;//3
						JDataFileInfo->YueTjValue[P-1].UXXW_Count += 1;//3
						c_uxxx_last_time[P-1] = 0;
					}
					else if(real_cl_stat.VC<UX)//--------�ж�UCԽ����
					{
						JDataFileInfo->DayTjValue[P-1].UXW_Count++;
						JDataFileInfo->YueTjValue[P-1].UXW_Count++;
					}
					if((real_cl_stat.VC>UX) && (real_cl_stat.VC<US))  //---------UC�ϸ��ѹ
					{
						JDataFileInfo->DayTjValue[P-1].UHGW_Count++;
						JDataFileInfo->YueTjValue[P-1].UHGW_Count++;
					}
				}

				if(real_cl_stat.IA != 0xffffffff)
				{
					if(abs(real_cl_stat.IA)>abs(ISS))//�ж�IAԽ�������ۼ�ʱ��
					{
						JDataFileInfo->DayTjValue[P-1].ISSU_Count++;
						JDataFileInfo->YueTjValue[P-1].ISSU_Count++;
					}
					else if(abs(real_cl_stat.IA)>abs(IS))//�ж�IAԽ�����ۼ�ʱ��
					{
						JDataFileInfo->DayTjValue[P-1].ISU_Count++;
						JDataFileInfo->YueTjValue[P-1].ISU_Count++;
					}
				}

				if(real_cl_stat.IB != 0xffffffff)
				{
					if(abs(real_cl_stat.IB)>abs(ISS))//�ж�IBԽ�������ۼ�ʱ��
					{
						JDataFileInfo->DayTjValue[P-1].ISSV_Count++;
						JDataFileInfo->YueTjValue[P-1].ISSV_Count++;
					}
					else if(abs(real_cl_stat.IB)>abs(IS))//�ж�IbԽ�����ۼ�ʱ��
					{
						JDataFileInfo->DayTjValue[P-1].ISV_Count++;
						JDataFileInfo->YueTjValue[P-1].ISV_Count++;
					}
				}

				if(real_cl_stat.IC != 0xffffffff)
				{
					if(abs(real_cl_stat.IC)>abs(ISS))//�ж�ICԽ�������ۼ�ʱ��
					{
						JDataFileInfo->DayTjValue[P-1].ISSW_Count++;
						JDataFileInfo->YueTjValue[P-1].ISSW_Count++;
					}
					else if(abs(real_cl_stat.IC)>abs(IS))//�ж�IcԽ�����ۼ�ʱ��
					{
						JDataFileInfo->DayTjValue[P-1].ISW_Count++;
						JDataFileInfo->YueTjValue[P-1].ISW_Count++;
					}
				}

				//���ڹ���������ֵ
				SSS=((JParamInfo3761->Point[P - 1].f26.S_SS[2]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.S_SS[2]&0x0f);
				SSS=(SSS*100)+((JParamInfo3761->Point[P - 1].f26.S_SS[1]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.S_SS[1]&0x0f);
				SSS=(SSS*100)+((JParamInfo3761->Point[P - 1].f26.S_SS[0]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.S_SS[0]&0x0f);

				//���ڹ�������ֵ
				SS=((JParamInfo3761->Point[P - 1].f26.S_S[2]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.S_S[2]&0x0f);
				SS=(SS*100)+((JParamInfo3761->Point[P - 1].f26.S_S[1]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.S_S[1]&0x0f);
				SS=(SS*100)+((JParamInfo3761->Point[P - 1].f26.S_S[0]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.S_S[0]&0x0f);

				SdPrint("\r\n%s%d,���ڹ��ʣ�SSS=%d SS=%d","������",P,	SSS,SS);
				PS1=sqrt((real_cl_stat.P_All/10)*(real_cl_stat.P_All/10) + (real_cl_stat.Q/10)*(real_cl_stat.Q/10));
				PS=(INT32U)PS1;
				PS=PS*10;
				SdPrint("\r\n%s%d,���ڹ��ʣ�PS1=%f,PS=%d ","������",P,PS1,PS);

				if(PS>SSS)//���ڹ���Խ�������ۼ�
				{
					JDataFileInfo->DayTjValue[P-1].S_SS_Count++;
					JDataFileInfo->YueTjValue[P-1].S_SS_Count++;
				}
				else if(PS>SS) //���ڹ���Խ�����ۼ�
				{
					JDataFileInfo->DayTjValue[P-1].S_S_Count++;
					JDataFileInfo->YueTjValue[P-1].S_S_Count++;
				}

				//������ͳ�Ƽ�����-----
				INT16U edingfuhe;//�����
				INT16U fuzailv;

				edingfuhe=((JParamInfo3761->Point[P - 1].f25.Max_Burthen[2]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f25.Max_Burthen[2]&0x0f);
				edingfuhe=(edingfuhe*100)+((JParamInfo3761->Point[P - 1].f25.Max_Burthen[1]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f25.Max_Burthen[1]&0x0f);
				edingfuhe=(edingfuhe*100)+((JParamInfo3761->Point[P - 1].f25.Max_Burthen[0]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f25.Max_Burthen[0]&0x0f);

				if (edingfuhe>0)
				{
					fuzailv = (PS*(1.0)/edingfuhe)*100;//�����ʵ��� ���ڹ���/����� //yangdonggai  10000
					if (fuzailv >= JDataFileInfo->DayTjValue[P-1].FuZaiLV_Max )//�������������
					{
						JDataFileInfo->DayTjValue[P-1].FuZaiLV_Max  = fuzailv;
						INT32U_BCD(ts.Minute,&JDataFileInfo->DayTjValue[P-1].FuZaiLV_MaxTime[0],1);
						INT32U_BCD(ts.Hour,&JDataFileInfo->DayTjValue[P-1].FuZaiLV_MaxTime[1],1);
						INT32U_BCD(ts.Day,&JDataFileInfo->DayTjValue[P-1].FuZaiLV_MaxTime[2],1);
					}
					if (fuzailv >= JDataFileInfo->YueTjValue[P-1].FuZaiLV_Max )//�������������
					{
						JDataFileInfo->YueTjValue[P-1].FuZaiLV_Max  = fuzailv;
						INT32U_BCD(ts.Minute,&JDataFileInfo->YueTjValue[P-1].FuZaiLV_MaxTime[0],1);
						INT32U_BCD(ts.Hour,&JDataFileInfo->YueTjValue[P-1].FuZaiLV_MaxTime[1],1);
						INT32U_BCD(ts.Day,&JDataFileInfo->YueTjValue[P-1].FuZaiLV_MaxTime[2],1);
						INT32U_BCD(ts.Month,&JDataFileInfo->YueTjValue[P-1].FuZaiLV_MaxTime[3],1);
					}
					if( fuzailv <= JDataFileInfo->DayTjValue[P-1].FuZaiLV_Min){//��������С������
						JDataFileInfo->DayTjValue[P-1].FuZaiLV_Min  = fuzailv;
						INT32U_BCD(ts.Minute,&JDataFileInfo->DayTjValue[P-1].FuZaiLV_MinTime[0],1);
						INT32U_BCD(ts.Hour,&JDataFileInfo->DayTjValue[P-1].FuZaiLV_MinTime[1],1);
						INT32U_BCD(ts.Day,&JDataFileInfo->DayTjValue[P-1].FuZaiLV_MinTime[2],1);
					}
					if( fuzailv <= JDataFileInfo->YueTjValue[P-1].FuZaiLV_Min){//��������С������
						JDataFileInfo->YueTjValue[P-1].FuZaiLV_Min  = fuzailv;
						INT32U_BCD(ts.Minute,&JDataFileInfo->YueTjValue[P-1].FuZaiLV_MinTime[0],1);
						INT32U_BCD(ts.Hour,&JDataFileInfo->YueTjValue[P-1].FuZaiLV_MinTime[1],1);
						INT32U_BCD(ts.Day,&JDataFileInfo->YueTjValue[P-1].FuZaiLV_MinTime[2],1);
						INT32U_BCD(ts.Month,&JDataFileInfo->YueTjValue[P-1].FuZaiLV_MinTime[3],1);//yangdongxiugai INT32U_BCD(ts.Month,&JDataFileInfo->YueTjValue[P-1].FuZaiLV_MaxTime[3],1);
					}
				}

				//������ƽ����ѹ

				INT32U sum = (JDataFileInfo->DayTjValue[P-1].USU_Count+JDataFileInfo->DayTjValue[P-1].UXU_Count+JDataFileInfo->DayTjValue[P-1].UHGU_Count);
				if (sum>0)
					JDataFileInfo->DayTjValue[P-1].DUUAVE = JDataFileInfo->DayTjValue[P-1].U_A_Sum/sum;
				sum = (JDataFileInfo->DayTjValue[P-1].USV_Count+JDataFileInfo->DayTjValue[P-1].UXV_Count+JDataFileInfo->DayTjValue[P-1].UHGV_Count);
				if (sum>0)
					JDataFileInfo->DayTjValue[P-1].DUVAVE = JDataFileInfo->DayTjValue[P-1].U_B_Sum/sum;
				sum = (JDataFileInfo->DayTjValue[P-1].USW_Count+JDataFileInfo->DayTjValue[P-1].UXW_Count+JDataFileInfo->DayTjValue[P-1].UHGW_Count);
				if (sum>0)
					JDataFileInfo->DayTjValue[P-1].DUWAVE = JDataFileInfo->DayTjValue[P-1].U_C_Sum/sum;

				//������ƽ����ѹ
				sum = (JDataFileInfo->YueTjValue[P-1].USU_Count+JDataFileInfo->YueTjValue[P-1].UXU_Count+JDataFileInfo->YueTjValue[P-1].UHGU_Count);
				if (sum>0)
					JDataFileInfo->YueTjValue[P-1].DUUAVE = JDataFileInfo->YueTjValue[P-1].U_A_Sum/sum;
				sum = (JDataFileInfo->YueTjValue[P-1].USV_Count+JDataFileInfo->YueTjValue[P-1].UXV_Count+JDataFileInfo->YueTjValue[P-1].UHGV_Count);
				if (sum>0)
					JDataFileInfo->YueTjValue[P-1].DUVAVE = JDataFileInfo->YueTjValue[P-1].U_B_Sum/ sum;
				sum = (JDataFileInfo->YueTjValue[P-1].USW_Count+JDataFileInfo->YueTjValue[P-1].UXW_Count+JDataFileInfo->YueTjValue[P-1].UHGW_Count);
				if (sum >0)
					JDataFileInfo->YueTjValue[P-1].DUWAVE = JDataFileInfo->YueTjValue[P-1].U_C_Sum/sum;

				if(real_cl_stat.VA!=0xffffffff || real_cl_stat.VB!=0xffffffff || real_cl_stat.VC!=0xffffffff)
				{
					int va=0,vb=0,vc=0;
					if(real_cl_stat.VA!=0xffffffff)
						va = real_cl_stat.VA;
					if(real_cl_stat.VB!=0xffffffff)
						vb = real_cl_stat.VB;
					if(real_cl_stat.VC!=0xffffffff)
						vc = real_cl_stat.VC;

					UVWXZ=((JParamInfo3761->Point[P - 1].f26.U3_Unbalance_Value[1]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.U3_Unbalance_Value[1]&0x0f);
					UVWXZ=(UVWXZ*100)+((JParamInfo3761->Point[P - 1].f26.U3_Unbalance_Value[0]>>4)*10)+
						(JParamInfo3761->Point[P - 1].f26.U3_Unbalance_Value[0]&0x0f);
					VCalc=(va+vb+vc)/3;
					VMax=MaxValue2(va,vb,vc);
					VMin = MinValue2(va,vb,vc);
					VValue=0;
					if(VMax!=0)
					{
						VValue = ((VMax - VMin)*1000)/VMax;//��ѹ��ƽ��ȼ���
						if(VValue>UVWXZ)
						{
							JDataFileInfo->DayTjValue[P-1].V_UNBALANCE_Count=JDataFileInfo->DayTjValue[P-1].V_UNBALANCE_Count+3;
							JDataFileInfo->YueTjValue[P-1].V_UNBALANCE_Count=JDataFileInfo->YueTjValue[P-1].V_UNBALANCE_Count+3;
						}
						if (VValue>=JDataFileInfo->DayTjValue[P-1].V_UNBALANCE_Max )
						{
							TSGet(&ts);
							JDataFileInfo->DayTjValue[P-1].V_UNBALANCE_Max = VValue;
							TimeGetType17(JDataFileInfo->DayTjValue[P-1].V_UNBALANCE_MaxTime,ts);
						}
						if (VValue>=JDataFileInfo->YueTjValue[P-1].V_UNBALANCE_Max )
						{
							TSGet(&ts);
							JDataFileInfo->YueTjValue[P-1].V_UNBALANCE_Max = VValue;
							TimeGetType17(JDataFileInfo->YueTjValue[P-1].V_UNBALANCE_MaxTime,ts);
						}
					}
				}
				if(real_cl_stat.IA!=0xffffffff || real_cl_stat.IB!=0xffffffff || real_cl_stat.IC!=0xffffffff)
				{
					int ia=0,ib=0,ic=0;
					if(real_cl_stat.IA!=0xffffffff)
						ia = real_cl_stat.IA;
					if(real_cl_stat.IB!=0xffffffff)
						ib = real_cl_stat.IB;
					if(real_cl_stat.IC!=0xffffffff)
						ic = real_cl_stat.IC;
					ABCXZ=((JParamInfo3761->Point[P - 1].f26.I3_Unbalance_Value[1]>>4)*10)+
						(JParamInfo3761->Point[P - 1].f26.I3_Unbalance_Value[1]&0x0f);
					ABCXZ=(ABCXZ*100)+((JParamInfo3761->Point[P - 1].f26.I3_Unbalance_Value[0]>>4)*10)+
						(JParamInfo3761->Point[P - 1].f26.I3_Unbalance_Value[0]&0x0f);
					ICalc=(abs(ia)+abs(ib)+abs(ic))/3;
					IMax=MaxValue2(abs(ia),abs(ib),abs(ic));
					IMin = MinValue2(abs(ia),abs(ib),abs(ic));
					SdPrint("\r\n%s%d,UVWXZ=%d ABCXZ=%d VCalc=%d,ICalc=%d",	"������",P,UVWXZ,ABCXZ,VCalc,ICalc);
					IValue=0;
					if(IMax!=0)
					{
						//IValue=((IMax-ICalc)*1000)/ICalc;
						IValue = ((IMax - IMin)*1000)/IMax;//������ƽ��ȼ���
						SdPrint("\n\rIValue=%d ABCXZ=%d ICalc=%d RtuDataAddr->F27_28_29_30_Mem.I_UNBALANCE_Max=%d",
								IValue,ABCXZ,ICalc,JDataFileInfo->DayTjValue[P-1].I_UNBALANCE_Max);

						if((IValue>ABCXZ)&&(ICalc>300))//�����*20%*1000
						{
							JDataFileInfo->DayTjValue[P-1].I_UNBALANCE_Count=JDataFileInfo->DayTjValue[P-1].I_UNBALANCE_Count+1;
							JDataFileInfo->YueTjValue[P-1].I_UNBALANCE_Count=JDataFileInfo->YueTjValue[P-1].I_UNBALANCE_Count+1;
						}
						if (IValue>=abs(JDataFileInfo->DayTjValue[P-1].I_UNBALANCE_Max ))
						{
							TSGet(&ts);
							JDataFileInfo->DayTjValue[P-1].I_UNBALANCE_Max = IValue;
							TimeGetType17(JDataFileInfo->DayTjValue[P-1].I_UNBALANCE_MaxTime,ts);
						}
						if (IValue>=abs(JDataFileInfo->YueTjValue[P-1].I_UNBALANCE_Max ))
						{
							TSGet(&ts);
							JDataFileInfo->YueTjValue[P-1].I_UNBALANCE_Max = IValue;
							TimeGetType17(JDataFileInfo->YueTjValue[P-1].I_UNBALANCE_MaxTime,ts);
						}
					}
				}
			}

			//��������ʼ�ʱ��
			TONGJIMAX(real_cl_stat.P_All, JDataFileInfo->DayTjValue[P-1].P_MAX, JDataFileInfo->DayTjValue[P-1].P_MAX_TIME);
			TONGJIMAX(real_cl_stat.P_U, JDataFileInfo->DayTjValue[P-1].PA_MAX, JDataFileInfo->DayTjValue[P-1].PA_MAX_TIME);
			TONGJIMAX(real_cl_stat.P_V, JDataFileInfo->DayTjValue[P-1].PB_MAX, JDataFileInfo->DayTjValue[P-1].PB_MAX_TIME);
			TONGJIMAX(real_cl_stat.P_W, JDataFileInfo->DayTjValue[P-1].PC_MAX, JDataFileInfo->DayTjValue[P-1].PC_MAX_TIME);

			//��������ʼ�ʱ��
			TONGJIMAX(real_cl_stat.P_All, JDataFileInfo->YueTjValue[P-1].P_MAX, JDataFileInfo->YueTjValue[P-1].P_MAX_TIME);
			TONGJIMAX(real_cl_stat.P_U, JDataFileInfo->YueTjValue[P-1].PA_MAX, JDataFileInfo->YueTjValue[P-1].PA_MAX_TIME);
			TONGJIMAX(real_cl_stat.P_V, JDataFileInfo->YueTjValue[P-1].PB_MAX, JDataFileInfo->YueTjValue[P-1].PB_MAX_TIME);
			TONGJIMAX(real_cl_stat.P_W, JDataFileInfo->YueTjValue[P-1].PC_MAX, JDataFileInfo->YueTjValue[P-1].PC_MAX_TIME);

			//������С���ʼ�ʱ��
			TONGJIMIN(real_cl_stat.P_All, JDataFileInfo->DayTjValue[P-1].P_MIN, JDataFileInfo->DayTjValue[P-1].P_MIN_TIME);
			TONGJIMIN(real_cl_stat.P_U, JDataFileInfo->DayTjValue[P-1].PA_MIN, JDataFileInfo->DayTjValue[P-1].PA_MIN_TIME);
			TONGJIMIN(real_cl_stat.P_V, JDataFileInfo->DayTjValue[P-1].PB_MIN, JDataFileInfo->DayTjValue[P-1].PB_MIN_TIME);
			TONGJIMIN(real_cl_stat.P_W, JDataFileInfo->DayTjValue[P-1].PC_MIN, JDataFileInfo->DayTjValue[P-1].PC_MIN_TIME);

			//������С���ʼ�ʱ��
			TONGJIMIN(real_cl_stat.P_All, JDataFileInfo->YueTjValue[P-1].P_MIN, JDataFileInfo->YueTjValue[P-1].P_MIN_TIME);
			TONGJIMIN(real_cl_stat.P_U, JDataFileInfo->YueTjValue[P-1].PA_MIN, JDataFileInfo->YueTjValue[P-1].PA_MIN_TIME);
			TONGJIMIN(real_cl_stat.P_V, JDataFileInfo->YueTjValue[P-1].PB_MIN, JDataFileInfo->YueTjValue[P-1].PB_MIN_TIME);
			TONGJIMIN(real_cl_stat.P_W, JDataFileInfo->YueTjValue[P-1].PC_MIN, JDataFileInfo->YueTjValue[P-1].PC_MIN_TIME);

			if((real_cl_stat.P_All)==0)
			{
				JDataFileInfo->DayTjValue[P-1].P_Zero_Time++;
			}
			if((real_cl_stat.P_U)==0)
			{
				JDataFileInfo->DayTjValue[P-1].PA_Zero_Time++;
			}
			if((real_cl_stat.P_V)==0)
			{
				JDataFileInfo->DayTjValue[P-1].PB_Zero_Time++;
			}
			if((real_cl_stat.P_W)==0)
			{
				JDataFileInfo->DayTjValue[P-1].PC_Zero_Time++;
			}

			//������������������������ʱ��
			TONGJIMAX(real_cl_stat.P_All_XL, JDataFileInfo->DayTjValue[P-1].P_All_XL, JDataFileInfo->DayTjValue[P-1].P_All_XL_Time);
			TONGJIMAX(real_cl_stat.P_U_XL, JDataFileInfo->DayTjValue[P-1].P_U_XL, JDataFileInfo->DayTjValue[P-1].P_U_XL_Time);
			TONGJIMAX(real_cl_stat.P_V_XL, JDataFileInfo->DayTjValue[P-1].P_V_XL, JDataFileInfo->DayTjValue[P-1].P_V_XL_Time);
			TONGJIMAX(real_cl_stat.P_W_XL, JDataFileInfo->DayTjValue[P-1].P_W_XL, JDataFileInfo->DayTjValue[P-1].P_W_XL_Time);

			//������������������������ʱ��
			TONGJIMAX(real_cl_stat.P_All_XL, JDataFileInfo->YueTjValue[P-1].P_All_XL, JDataFileInfo->YueTjValue[P-1].P_All_XL_Time);
			TONGJIMAX(real_cl_stat.P_U_XL, JDataFileInfo->YueTjValue[P-1].P_U_XL, JDataFileInfo->YueTjValue[P-1].P_U_XL_Time);
			TONGJIMAX(real_cl_stat.P_V_XL, JDataFileInfo->YueTjValue[P-1].P_V_XL, JDataFileInfo->YueTjValue[P-1].P_V_XL_Time);
			TONGJIMAX(real_cl_stat.P_W_XL, JDataFileInfo->YueTjValue[P-1].P_W_XL, JDataFileInfo->YueTjValue[P-1].P_W_XL_Time);
		}
	//---------------------------------------------------------------------------------------------------------
		JDataFileInfo->DayTjValue[P-1].T_time=ts;
		JDataFileInfo->YueTjValue[P-1].T_time=ts;
	}
}

void DoRiYueTongJi1(TS ts,INT16U P)
{
	if(JParamInfo3761->group2.f10[P-1].Status != 1)
		return;
	if((JParamInfo3761->group2.f10[P-1].port!=1)&&(JParamInfo3761->group2.f10[P-1].port!=2) && (JParamInfo3761->group2.f10[P-1].port!=3) &&
		(JParamInfo3761->group2.f10[P-1].port!=6) &&(JParamInfo3761->group2.f10[P-1].port!=31))
		return;

	INT8U TempBuf[60];
	SMFiles smfile;
	INT8U tempManyData[DataLenMax];
	Cl_Stat_Set real_cl_stat;

	memset(&real_cl_stat, 0, sizeof(Cl_Stat_Set));
	//�ѳ��������ݴ�curr.dat����real_cl_stat
	memset(TempBuf,0,60);
	sprintf((char*)TempBuf,"/nand/DataCurr/%04d/curr.dat",P);
	if (ReadFile((char *)TempBuf, &smfile,sizeof(SMFiles),JProgramInfo) == 1){
		return;
	}
	memset(tempManyData,0,sizeof(tempManyData));
	GetManyData0ld(smfile.sm.datas,&tempManyData[0],0xb6,0x30);
	real_cl_stat.P_All = BCD_INT32(&tempManyData[0], 3);//�й�����
	GetManyData0ld(smfile.sm.datas,&tempManyData[0],0xb6,0x31);
	real_cl_stat.P_U = BCD_INT32(&tempManyData[0], 3);//A�й�����
	GetManyData0ld(smfile.sm.datas,&tempManyData[0],0xb6,0x32);
	real_cl_stat.P_V = BCD_INT32(&tempManyData[0], 3);//B�й�����
	GetManyData0ld(smfile.sm.datas,&tempManyData[0],0xb6,0x33);
	real_cl_stat.P_W = BCD_INT32(&tempManyData[0], 3);//C�й�����

	memset(tempManyData,0,sizeof(tempManyData));
	GetManyData0ld(smfile.sm.datas,&tempManyData[0],0xb6,0x40);
	real_cl_stat.Q = BCD_INT32(&tempManyData[0], 2);	//�޹�����
	GetManyData0ld(smfile.sm.datas,&tempManyData[0],0xb6,0x41);
	real_cl_stat.QA = BCD_INT32(&tempManyData[0], 2);//A�޹�����
	GetManyData0ld(smfile.sm.datas,&tempManyData[0],0xb6,0x42);
	real_cl_stat.QB = BCD_INT32(&tempManyData[0], 2);//B�޹�����
	GetManyData0ld(smfile.sm.datas,&tempManyData[0],0xb6,0x43);
	real_cl_stat.QC = BCD_INT32(&tempManyData[0], 2);//C�޹�����

	memset(tempManyData,0,sizeof(tempManyData));
	GetManyData0ld(smfile.sm.datas,&tempManyData[0],0xb6,0x1f);
	real_cl_stat.VA = BCD_INT32(&tempManyData[0], 2);	//A��ѹ
	real_cl_stat.VB = BCD_INT32(&tempManyData[0]+2, 2);	//B��ѹ
	real_cl_stat.VC = BCD_INT32(&tempManyData[0]+4, 2);	//C��ѹ

	memset(tempManyData,0,sizeof(tempManyData));		//����
	GetManyData0ld(smfile.sm.datas,&tempManyData[0],0xb6,0x2f);
	real_cl_stat.IA = BCD_INT32(&tempManyData[0], 	2);	//A����
	real_cl_stat.IB = BCD_INT32(&tempManyData[0]+3, 2);	//B����
	real_cl_stat.IC = BCD_INT32(&tempManyData[0]+6, 2);	//C����

	memset(tempManyData,0,sizeof(tempManyData));		//��������
	GetManyData0ld(smfile.sm.datas,&tempManyData[0],0xb6,0x5f);
	real_cl_stat.COS = BCD_INT32(&tempManyData[0], 2);		//��������
	real_cl_stat.COSA = BCD_INT32(&tempManyData[0]+2, 2);	//A��������
	real_cl_stat.COSB = BCD_INT32(&tempManyData[0]+4, 2);	//B��������
	real_cl_stat.COSC = BCD_INT32(&tempManyData[0]+6, 2);	//C��������

	memset(tempManyData,0,sizeof(tempManyData));		//���������		//9.23
	GetManyData0ld(smfile.sm.datas,&tempManyData[0],0xa0,0x10);
	real_cl_stat.P_All_XL = BCD_INT32(&tempManyData[0], 3);		//���������
	real_cl_stat.P_U_XL = BCD_INT32(&tempManyData[0]+3, 3);		//A�������   ������ȡ���Ƿ���1,2,3�ģ���A��B��C������
	real_cl_stat.P_V_XL = BCD_INT32(&tempManyData[0]+6, 3);		//B�������
	real_cl_stat.P_W_XL = BCD_INT32(&tempManyData[0]+9, 3);		//C�������

	SdPrint("\n\n������ţ� %d\n", P);
	SdPrint("\nA��ѹ :%d B��ѹ:%d C��ѹ :%d    A���� :%d B���� :%d C���� :%d \n",
			real_cl_stat.VA, real_cl_stat.VB,real_cl_stat.VC,
			real_cl_stat.IA, real_cl_stat.IB, real_cl_stat.IC);
	SdPrint("\n�й�����:%d A�й����� :%d B�й����� :%d C�й����� :%d  �޹�����:%d A�޹����� :%d B�޹����� :%d C�޹����� :%d \n",
			real_cl_stat.P_All, real_cl_stat.P_U,real_cl_stat.P_V,real_cl_stat.P_W,
			real_cl_stat.Q, real_cl_stat.QA, real_cl_stat.QB, real_cl_stat.QC);
	SdPrint("\n��������:%d A�������� :%d B�������� :%d C�������� :%d \n",
			real_cl_stat.COS, real_cl_stat.COSA,real_cl_stat.COSB,real_cl_stat.COSC);

	if(1)
	{
		ClearWaitTimes(ProjectNo,JProgramInfo);

		INT16U US,UX,UD,USS,UXX,UVWXZ,VCalc,VValue,VMax,VMin;
		INT16S ISS,IS,IValue,IMax,ICalc,ABCXZ,IMin;
		INT32U SSS,SS,PS;
		float PS1;
		TS ts;
		TSGet(&ts);

		{
		//	if(real_cl_stat.Valid!=1)continue;//������1(i=0)��Ϊ����������ѹ�ϸ���,valid����Զ��=1�� ��Ӱ��ϸ��������ɼ�
			int xian1 = BCD_INT32(&JParamInfo3761->Point[P - 1].f28.CosFenDuan_Xian1[0],2);
			int xian2 = BCD_INT32(&JParamInfo3761->Point[P - 1].f28.CosFenDuan_Xian2[0],2);
			SdPrint("\n==== xian1 =%d   xian2 =%d",xian1,xian2);
			if(real_cl_stat.COS<xian1)//�¼� ���㹦�������ۼ�ʱ��
			{
				JDataFileInfo->DayTjValue[P-1].QuDuan1_Count++;
				JDataFileInfo->YueTjValue[P-1].QuDuan1_Count++;
			}
			if((real_cl_stat.COS>=xian1)&&(real_cl_stat.COS<xian2))//�¼� ���㹦�������ۼ�ʱ��
			{
				JDataFileInfo->DayTjValue[P-1].QuDuan2_Count++;
				JDataFileInfo->YueTjValue[P-1].QuDuan2_Count++;
			}
			if(real_cl_stat.COS>=xian2)//�¼� ���㹦�������ۼ�ʱ��
			{
				JDataFileInfo->DayTjValue[P-1].QuDuan3_Count++;
				JDataFileInfo->YueTjValue[P-1].QuDuan3_Count++;
			}
			SdPrint("\n==== real_cl_stat.COS=%d  ",real_cl_stat.COS);
			SdPrint("\n==== xian1count=%d   xian2count=%d  xian3count=%d",JDataFileInfo->DayTjValue[P-1].QuDuan1_Count,JDataFileInfo->DayTjValue[P-1].QuDuan2_Count,JDataFileInfo->DayTjValue[P-1].QuDuan3_Count);

	//		if(Jmemory->F26Valid==1)   //��½�����޸�
			{
				US=((JParamInfo3761->Point[P - 1].f26.V_He_ge_S[1]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.V_He_ge_S[1]&0x0f);
				US=(US*100)+((JParamInfo3761->Point[P - 1].f26.V_He_ge_S[0]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.V_He_ge_S[0]&0x0f);

				UX=((JParamInfo3761->Point[P - 1].f26.V_He_ge_X[1]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.V_He_ge_X[1]&0x0f);
				UX=(UX*100)+((JParamInfo3761->Point[P - 1].f26.V_He_ge_X[0]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.V_He_ge_X[0]&0x0f);

				UD=((JParamInfo3761->Point[P - 1].f26.V_Duan_Men[1]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.V_Duan_Men[1]&0x0f);
				UD=(UD*100)+((JParamInfo3761->Point[P - 1].f26.V_Duan_Men[0]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.V_Duan_Men[0]&0x0f);

				USS=((JParamInfo3761->Point[P - 1].f26.V_He_ge_SS[1]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.V_He_ge_SS[1]&0x0f);
				USS=(USS*100)+((JParamInfo3761->Point[P - 1].f26.V_He_ge_SS[0]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.V_He_ge_SS[0]&0x0f);

				UXX=((JParamInfo3761->Point[P - 1].f26.V_He_ge_XX[1]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.V_He_ge_XX[1]&0x0f);
				UXX=(UXX*100)+((JParamInfo3761->Point[P - 1].f26.V_He_ge_XX[0]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.V_He_ge_XX[0]&0x0f);

				ISS=(((JParamInfo3761->Point[P - 1].f26.I_SS[2]>>4)&0x07)*10)+
					(JParamInfo3761->Point[P - 1].f26.I_SS[2]&0x0f);
				ISS=(ISS*100)+((JParamInfo3761->Point[P - 1].f26.I_SS[1]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.I_SS[1]&0x0f);
				ISS=(ISS*100)+((JParamInfo3761->Point[P - 1].f26.I_SS[0]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.I_SS[0]&0x0f);

				IS=(((JParamInfo3761->Point[P - 1].f26.I_S[2]>>4)&0x07)*10)+
					(JParamInfo3761->Point[P - 1].f26.I_S[2]&0x0f);
				IS=(IS*100)+((JParamInfo3761->Point[P - 1].f26.I_S[1]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.I_S[1]&0x0f);
				IS=(IS*100)+((JParamInfo3761->Point[P - 1].f26.I_S[0]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.I_S[0]&0x0f);
				SdPrint("US=%d,USS=%d,Ua=%d,Ub=%d,Uc=%d\n",US,USS,real_cl_stat.VA,real_cl_stat.VB,real_cl_stat.VC);
				//-------------------------------------------------------------�յ�ѹ���ֵ������ʱ��---------------
				if(real_cl_stat.VA>JDataFileInfo->DayTjValue[P-1].DUUMAX)//UA���ֵ�жϣ���¼����ʱ��
				{
					JDataFileInfo->DayTjValue[P-1].DUUMAX=real_cl_stat.VA;
					TimeGetType18(JDataFileInfo->DayTjValue[P-1].DUUMAX_TIME,ts);
				}
				if(real_cl_stat.VB>JDataFileInfo->DayTjValue[P-1].DUVMAX)//Ub���ֵ�жϣ���¼����ʱ��
				{
					JDataFileInfo->DayTjValue[P-1].DUVMAX=real_cl_stat.VB;
					TimeGetType18(JDataFileInfo->DayTjValue[P-1].DUVMAX_TIME,ts);
				}
				if(real_cl_stat.VC>JDataFileInfo->DayTjValue[P-1].DUWMAX)//Uc���ֵ�жϣ���¼����ʱ��
				{
					JDataFileInfo->DayTjValue[P-1].DUWMAX=real_cl_stat.VC;
					TimeGetType18(JDataFileInfo->DayTjValue[P-1].DUWMAX_TIME,ts);
				}
				//-------------------------------------------------------------�µ�ѹ���ֵ������ʱ��---------------
				if(real_cl_stat.VA>JDataFileInfo->YueTjValue[P-1].DUUMAX)//UA���ֵ
				{
					JDataFileInfo->YueTjValue[P-1].DUUMAX=real_cl_stat.VA;
					TimeGetType18(JDataFileInfo->YueTjValue[P-1].DUUMAX_TIME,ts);
				}
				if(real_cl_stat.VB>JDataFileInfo->YueTjValue[P-1].DUVMAX) //Ub���ֵ
				{
					JDataFileInfo->YueTjValue[P-1].DUVMAX=real_cl_stat.VB;
					TimeGetType18(JDataFileInfo->YueTjValue[P-1].DUVMAX_TIME,ts);
				}
				if(real_cl_stat.VC>JDataFileInfo->YueTjValue[P-1].DUWMAX) //Uc���ֵ
				{
					JDataFileInfo->YueTjValue[P-1].DUWMAX=real_cl_stat.VC;
					TimeGetType18(JDataFileInfo->YueTjValue[P-1].DUWMAX_TIME,ts);
				}
				//-------------------------------------------------------------�յ�ѹ��Сֵ������ʱ��---------------
				if(real_cl_stat.VA<JDataFileInfo->DayTjValue[P-1].DUUMIN)//UA��Сֵ�жϣ���¼����ʱ��
				{
					JDataFileInfo->DayTjValue[P-1].DUUMIN=real_cl_stat.VA;
					TimeGetType18(JDataFileInfo->DayTjValue[P-1].DUUMIN_TIME,ts);
				}
				if(real_cl_stat.VB<JDataFileInfo->DayTjValue[P-1].DUVMIN)//Ub��Сֵ
				{
					JDataFileInfo->DayTjValue[P-1].DUVMIN=real_cl_stat.VB;
					TimeGetType18(JDataFileInfo->DayTjValue[P-1].DUVMIN_TIME,ts);
				}
				if(real_cl_stat.VC<JDataFileInfo->DayTjValue[P-1].DUWMIN)//Uc��Сֵ
				{
					JDataFileInfo->DayTjValue[P-1].DUWMIN=real_cl_stat.VC;
					TimeGetType18(JDataFileInfo->DayTjValue[P-1].DUWMIN_TIME,ts);
				}
				//-------------------------------------------------------------�µ�ѹ��Сֵ������ʱ��---------------
				if(real_cl_stat.VA<JDataFileInfo->YueTjValue[P-1].DUUMIN)//Ua��Сֵ
				{
					JDataFileInfo->YueTjValue[P-1].DUUMIN=real_cl_stat.VA;
					TimeGetType18(JDataFileInfo->YueTjValue[P-1].DUUMIN_TIME,ts);
				}
				if(real_cl_stat.VB<JDataFileInfo->YueTjValue[P-1].DUVMIN)//Ub��Сֵ
				{
					JDataFileInfo->YueTjValue[P-1].DUVMIN=real_cl_stat.VB;
					TimeGetType18(JDataFileInfo->YueTjValue[P-1].DUVMIN_TIME,ts);
				}
				if(real_cl_stat.VC<JDataFileInfo->YueTjValue[P-1].DUWMIN)//Uc��Сֵ
				{
					JDataFileInfo->YueTjValue[P-1].DUWMIN=real_cl_stat.VC;
					TimeGetType18(JDataFileInfo->YueTjValue[P-1].DUWMIN_TIME,ts);
				}
				//------------------------------------------------------------�յ������ֵ������ʱ��----------------
				if(abs(real_cl_stat.IA)>abs(JDataFileInfo->DayTjValue[P-1].DI_U_MAX))//IA���ֵ�жϣ���¼����ʱ��
				{
					JDataFileInfo->DayTjValue[P-1].DI_U_MAX=real_cl_stat.IA;
					TimeGetType18(JDataFileInfo->DayTjValue[P-1].DIUMAX_TIME,ts);
				}
				if(abs(real_cl_stat.IB)>abs(JDataFileInfo->DayTjValue[P-1].DI_V_MAX))//IB���ֵ
				{
					JDataFileInfo->DayTjValue[P-1].DI_V_MAX=real_cl_stat.IB;
					TimeGetType18(JDataFileInfo->DayTjValue[P-1].DIVMAX_TIME,ts);
				}
				if(abs(real_cl_stat.IC)>abs(JDataFileInfo->DayTjValue[P-1].DI_W_MAX))//IC���ֵ
				{
					JDataFileInfo->DayTjValue[P-1].DI_W_MAX=real_cl_stat.IC;
					TimeGetType18(JDataFileInfo->DayTjValue[P-1].DIWMAX_TIME,ts);
				}
				if(abs(real_cl_stat.IL)>abs(JDataFileInfo->DayTjValue[P-1].DI_L_MAX))//IL���ֵ
				{
					JDataFileInfo->DayTjValue[P-1].DI_L_MAX=real_cl_stat.IL;
					TimeGetType18(JDataFileInfo->DayTjValue[P-1].DILMAX_TIME,ts);
				}
				//--------------------------------------------------------- �µ������ֵ������ʱ��-------------------
				if(abs(real_cl_stat.IA)>abs(JDataFileInfo->YueTjValue[P-1].DI_U_MAX))//IA���ֵ
				{
					JDataFileInfo->YueTjValue[P-1].DI_U_MAX=real_cl_stat.IA;
					TimeGetType18(JDataFileInfo->YueTjValue[P-1].DIUMAX_TIME,ts);
				}
				if(abs(real_cl_stat.IB)>abs(JDataFileInfo->YueTjValue[P-1].DI_V_MAX))//IB���ֵ
				{
					JDataFileInfo->YueTjValue[P-1].DI_V_MAX=real_cl_stat.IB;
					TimeGetType18(JDataFileInfo->YueTjValue[P-1].DIVMAX_TIME,ts);
				}
				if(abs(real_cl_stat.IC)>abs(JDataFileInfo->YueTjValue[P-1].DI_W_MAX))//IC���ֵ
				{
					JDataFileInfo->YueTjValue[P-1].DI_W_MAX=real_cl_stat.IC;
					TimeGetType18(JDataFileInfo->YueTjValue[P-1].DIWMAX_TIME,ts);
				}
				if(abs(real_cl_stat.IL)>abs(JDataFileInfo->YueTjValue[P-1].DI_L_MAX))//IL���ֵ
				{
					JDataFileInfo->YueTjValue[P-1].DI_L_MAX=real_cl_stat.IL;
					TimeGetType18(JDataFileInfo->YueTjValue[P-1].DILMAX_TIME,ts);
				}

				//---------------------------------�ж�UAԽ�����޷���
				if(real_cl_stat.VA>USS)
					a_ussx_last_time[P-1]++;
				else
					a_ussx_last_time[P-1]=0;

				//---------------------------------�ж�UAԽ�����޷���
				if(real_cl_stat.VA<UXX)
					a_uxxx_last_time[P-1]++;
				else
					a_uxxx_last_time[P-1]=0;

				//---------------------------------�ж�UBԽ�����޷���
				if(real_cl_stat.VB>USS)
					b_ussx_last_time[P-1]++;
				else
					b_ussx_last_time[P-1]=0;

				//---------------------------------�ж�UBԽ�����޷���
				if(real_cl_stat.VB<UXX)
					b_uxxx_last_time[P-1]++;
				else
					b_uxxx_last_time[P-1]=0;

				//---------------------------------�ж�UCԽ�����޷���
				if(real_cl_stat.VC>USS)
					c_ussx_last_time[P-1]++;
				else
					c_ussx_last_time[P-1]=0;

				//---------------------------------�ж�UCԽ�����޷���
				if(real_cl_stat.VC<UXX)
					c_uxxx_last_time[P-1]++;
				else
					c_uxxx_last_time[P-1]=0;

				JDataFileInfo->DayTjValue[P-1].U_A_Sum += real_cl_stat.VA;
				JDataFileInfo->YueTjValue[P-1].U_A_Sum += real_cl_stat.VA;
				JDataFileInfo->DayTjValue[P-1].U_B_Sum += real_cl_stat.VB;
				JDataFileInfo->YueTjValue[P-1].U_B_Sum += real_cl_stat.VB;
				JDataFileInfo->DayTjValue[P-1].U_C_Sum += real_cl_stat.VC;
				JDataFileInfo->YueTjValue[P-1].U_C_Sum += real_cl_stat.VC;

			//----------------------------------UA-----------------------------
				if((real_cl_stat.VA>USS) && (a_ussx_last_time[P-1]>=1))//3------------�ж�UAԽ������
				{
					JDataFileInfo->DayTjValue[P-1].USSU_Count += 1;//3
					JDataFileInfo->YueTjValue[P-1].USSU_Count += 1;//3
					a_ussx_last_time[P-1] = 0;
				}
				if(real_cl_stat.VA>US)//------------�ж�UAԽ����
				{
					JDataFileInfo->DayTjValue[P-1].USU_Count++;
					JDataFileInfo->YueTjValue[P-1].USU_Count++;
				}
				if((real_cl_stat.VA<UXX) && (a_uxxx_last_time[P-1] >= 1))//3	//�ж�UAԽ������
				{
					JDataFileInfo->DayTjValue[P-1].UXXU_Count += 1;//3
					JDataFileInfo->YueTjValue[P-1].UXXU_Count += 1;//3
					a_uxxx_last_time[P-1] = 0;
				}
				if(real_cl_stat.VA<UX)//--------�ж�UAԽ����
				{
					JDataFileInfo->DayTjValue[P-1].UXU_Count++;
					JDataFileInfo->YueTjValue[P-1].UXU_Count++;
				}
				if((real_cl_stat.VA>UX) && (real_cl_stat.VA<US))  //---------UA�ϸ��ѹ
				{
					JDataFileInfo->DayTjValue[P-1].UHGU_Count++;
					JDataFileInfo->YueTjValue[P-1].UHGU_Count++;
				}

				//----------------------------------UB-----------------------------
				if((real_cl_stat.VB>USS) && (b_ussx_last_time[P-1]>=1))//3------------�ж�UBԽ������
				{
					JDataFileInfo->DayTjValue[P-1].USSV_Count += 1;//3
					JDataFileInfo->YueTjValue[P-1].USSV_Count += 1;//3
					b_ussx_last_time[P-1] = 0;
				}
				if(real_cl_stat.VB>US)//------------�ж�UBԽ����
				{
					JDataFileInfo->DayTjValue[P-1].USV_Count++;
					JDataFileInfo->YueTjValue[P-1].USV_Count++;
				}
				if((real_cl_stat.VB<UXX) && (b_uxxx_last_time[P-1]>=1))//3	//�ж�UBԽ������
				{
					JDataFileInfo->DayTjValue[P-1].UXXV_Count += 1;//3
					JDataFileInfo->YueTjValue[P-1].UXXV_Count += 1;//3
					b_uxxx_last_time[P-1] = 0;
				}
				if(real_cl_stat.VB<UX)//--------�ж�UBԽ����
				{
					JDataFileInfo->DayTjValue[P-1].UXV_Count++;
					JDataFileInfo->YueTjValue[P-1].UXV_Count++;
				}
				if((real_cl_stat.VB>UX) && (real_cl_stat.VB<US))  //---------UB�ϸ��ѹ
				{
					JDataFileInfo->DayTjValue[P-1].UHGV_Count++;
					JDataFileInfo->YueTjValue[P-1].UHGV_Count++;
				}

				//----------------------------------UC-----------------------------
				if((real_cl_stat.VC>USS) && (c_ussx_last_time[P-1]>=1))//3------------�ж�UCԽ������
				{
					JDataFileInfo->DayTjValue[P-1].USSW_Count += 1;//3
					JDataFileInfo->YueTjValue[P-1].USSW_Count += 1;//3
					c_ussx_last_time[P-1] = 0;
				}
				if(real_cl_stat.VC>US)//------------�ж�UCԽ����
				{
					JDataFileInfo->DayTjValue[P-1].USW_Count++;
					JDataFileInfo->YueTjValue[P-1].USW_Count++;
				}
				if((real_cl_stat.VC<UXX) && (c_uxxx_last_time[P-1]>=1))//3	//�ж�UCԽ������
				{
					JDataFileInfo->DayTjValue[P-1].UXXW_Count += 1;//3
					JDataFileInfo->YueTjValue[P-1].UXXW_Count += 1;//3
					c_uxxx_last_time[P-1] = 0;
				}
				if(real_cl_stat.VC<UX)//--------�ж�UCԽ����
				{
					JDataFileInfo->DayTjValue[P-1].UXW_Count++;
					JDataFileInfo->YueTjValue[P-1].UXW_Count++;
				}
				if((real_cl_stat.VC>UX) && (real_cl_stat.VC<US))  //---------UC�ϸ��ѹ
				{
					JDataFileInfo->DayTjValue[P-1].UHGW_Count++;
					JDataFileInfo->YueTjValue[P-1].UHGW_Count++;
				}


				if(abs(real_cl_stat.IA)>abs(ISS))//�ж�IAԽ�������ۼ�ʱ��
				{
					JDataFileInfo->DayTjValue[P-1].ISSU_Count++;
					JDataFileInfo->YueTjValue[P-1].ISSU_Count++;
				}
				else if(abs(real_cl_stat.IA)>abs(IS))//�ж�IAԽ�����ۼ�ʱ��
				{
					JDataFileInfo->DayTjValue[P-1].ISU_Count++;
					JDataFileInfo->YueTjValue[P-1].ISU_Count++;
				}
				if(abs(real_cl_stat.IB)>abs(ISS))//�ж�IBԽ�������ۼ�ʱ��
				{
					JDataFileInfo->DayTjValue[P-1].ISSV_Count++;
					JDataFileInfo->YueTjValue[P-1].ISSV_Count++;
				}
				else if(abs(real_cl_stat.IB)>abs(IS))//�ж�IbԽ�����ۼ�ʱ��
				{
					JDataFileInfo->DayTjValue[P-1].ISV_Count++;
					JDataFileInfo->YueTjValue[P-1].ISV_Count++;
				}
				if(abs(real_cl_stat.IC)>abs(ISS))//�ж�ICԽ�������ۼ�ʱ��
				{
					JDataFileInfo->DayTjValue[P-1].ISSW_Count++;
					JDataFileInfo->YueTjValue[P-1].ISSW_Count++;
				}
				else if(abs(real_cl_stat.IC)>abs(IS))//�ж�IcԽ�����ۼ�ʱ��
				{
					JDataFileInfo->DayTjValue[P-1].ISW_Count++;
					JDataFileInfo->YueTjValue[P-1].ISW_Count++;
				}

				//���ڹ���������ֵ
				SSS=((JParamInfo3761->Point[P - 1].f26.S_SS[2]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.S_SS[2]&0x0f);
				SSS=(SSS*100)+((JParamInfo3761->Point[P - 1].f26.S_SS[1]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.S_SS[1]&0x0f);
				SSS=(SSS*100)+((JParamInfo3761->Point[P - 1].f26.S_SS[0]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.S_SS[0]&0x0f);

				//���ڹ�������ֵ
				SS=((JParamInfo3761->Point[P - 1].f26.S_S[2]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.S_S[2]&0x0f);
				SS=(SS*100)+((JParamInfo3761->Point[P - 1].f26.S_S[1]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.S_S[1]&0x0f);
				SS=(SS*100)+((JParamInfo3761->Point[P - 1].f26.S_S[0]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.S_S[0]&0x0f);
				PS1=sqrt((real_cl_stat.P_All/10)*(real_cl_stat.P_All/10) + (real_cl_stat.Q/10)*(real_cl_stat.Q/10));
				PS=(INT32U)PS1;
				PS=PS*10;
				SdPrint("\r\n%s%d,S=%d SSS=%d SS=%d","������",P,PS,	SSS,SS);

				if(PS>SSS)//���ڹ���Խ�������ۼ�
				{
					JDataFileInfo->DayTjValue[P-1].S_SS_Count++;
					JDataFileInfo->YueTjValue[P-1].S_SS_Count++;
				}
				else if(PS>SS) //���ڹ���Խ�����ۼ�
				{
					JDataFileInfo->DayTjValue[P-1].S_S_Count++;
					JDataFileInfo->YueTjValue[P-1].S_S_Count++;
				}

				//������ƽ����ѹ
				if(JDataFileInfo->DayTjValue[P-1].USU_Count+JDataFileInfo->DayTjValue[P-1].UXU_Count+JDataFileInfo->DayTjValue[P-1].UHGU_Count != 0){
					JDataFileInfo->DayTjValue[P-1].DUUAVE = JDataFileInfo->DayTjValue[P-1].U_A_Sum/(JDataFileInfo->DayTjValue[P-1].USU_Count+JDataFileInfo->DayTjValue[P-1].UXU_Count+JDataFileInfo->DayTjValue[P-1].UHGU_Count);
				}
				if(JDataFileInfo->DayTjValue[P-1].USV_Count+JDataFileInfo->DayTjValue[P-1].UXV_Count+JDataFileInfo->DayTjValue[P-1].UHGV_Count != 0){
					JDataFileInfo->DayTjValue[P-1].DUVAVE = JDataFileInfo->DayTjValue[P-1].U_B_Sum/(JDataFileInfo->DayTjValue[P-1].USV_Count+JDataFileInfo->DayTjValue[P-1].UXV_Count+JDataFileInfo->DayTjValue[P-1].UHGV_Count);
				}
				if(JDataFileInfo->DayTjValue[P-1].USW_Count+JDataFileInfo->DayTjValue[P-1].UXW_Count+JDataFileInfo->DayTjValue[P-1].UHGW_Count != 0){
					JDataFileInfo->DayTjValue[P-1].DUWAVE = JDataFileInfo->DayTjValue[P-1].U_C_Sum/(JDataFileInfo->DayTjValue[P-1].USW_Count+JDataFileInfo->DayTjValue[P-1].UXW_Count+JDataFileInfo->DayTjValue[P-1].UHGW_Count);
				}
				//������ƽ����ѹ
				if((JDataFileInfo->YueTjValue[P-1].USU_Count+JDataFileInfo->YueTjValue[P-1].UXU_Count+JDataFileInfo->YueTjValue[P-1].UHGU_Count)!=0)
					JDataFileInfo->YueTjValue[P-1].DUUAVE = JDataFileInfo->YueTjValue[P-1].U_A_Sum/(JDataFileInfo->YueTjValue[P-1].USU_Count+JDataFileInfo->YueTjValue[P-1].UXU_Count+JDataFileInfo->YueTjValue[P-1].UHGU_Count);
				if((JDataFileInfo->YueTjValue[P-1].USV_Count+JDataFileInfo->YueTjValue[P-1].UXV_Count+JDataFileInfo->YueTjValue[P-1].UHGV_Count)!=0)
					JDataFileInfo->YueTjValue[P-1].DUVAVE = JDataFileInfo->YueTjValue[P-1].U_B_Sum/(JDataFileInfo->YueTjValue[P-1].USV_Count+JDataFileInfo->YueTjValue[P-1].UXV_Count+JDataFileInfo->YueTjValue[P-1].UHGV_Count);
				if((JDataFileInfo->YueTjValue[P-1].USW_Count+JDataFileInfo->YueTjValue[P-1].UXW_Count+JDataFileInfo->YueTjValue[P-1].UHGW_Count)!=0)
				JDataFileInfo->YueTjValue[P-1].DUWAVE = JDataFileInfo->YueTjValue[P-1].U_C_Sum/(JDataFileInfo->YueTjValue[P-1].USW_Count+JDataFileInfo->YueTjValue[P-1].UXW_Count+JDataFileInfo->YueTjValue[P-1].UHGW_Count);


				UVWXZ=((JParamInfo3761->Point[P - 1].f26.U3_Unbalance_Value[1]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.U3_Unbalance_Value[1]&0x0f);
				UVWXZ=(UVWXZ*100)+((JParamInfo3761->Point[P - 1].f26.U3_Unbalance_Value[0]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.U3_Unbalance_Value[0]&0x0f);
				ABCXZ=((JParamInfo3761->Point[P - 1].f26.I3_Unbalance_Value[1]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.I3_Unbalance_Value[1]&0x0f);
				ABCXZ=(ABCXZ*100)+((JParamInfo3761->Point[P - 1].f26.I3_Unbalance_Value[0]>>4)*10)+
					(JParamInfo3761->Point[P - 1].f26.I3_Unbalance_Value[0]&0x0f);

				VCalc=(real_cl_stat.VA+real_cl_stat.VB+real_cl_stat.VC)/3;
				ICalc=(abs(real_cl_stat.IA)+abs(real_cl_stat.IB)+abs(real_cl_stat.IC))/3;
				VMax=MaxValue2(real_cl_stat.VA,real_cl_stat.VB,real_cl_stat.VC);
				IMax=MaxValue2(abs(real_cl_stat.IA),abs(real_cl_stat.IB),abs(real_cl_stat.IC));
				VMin = MinValue2(real_cl_stat.VA,real_cl_stat.VB,real_cl_stat.VC);
				IMin = MinValue2(abs(real_cl_stat.IA),abs(real_cl_stat.IB),abs(real_cl_stat.IC));
				SdPrint("\r\n%s%d,UVWXZ=%d ABCXZ=%d VCalc=%d,ICalc=%d",	"������",P,UVWXZ,	ABCXZ,VCalc,ICalc);

				VValue=0;
				if(VMax!=0)
				{
					//VValue=((VMax-VCalc)*1000)/VCalc;
					VValue = ((VMax - VMin)*1000)/VMax;//��ѹ��ƽ��ȼ���

					if(VValue>UVWXZ)
					{

						JDataFileInfo->DayTjValue[P-1].V_UNBALANCE_Count=JDataFileInfo->DayTjValue[P-1].V_UNBALANCE_Count+3;
						JDataFileInfo->YueTjValue[P-1].V_UNBALANCE_Count=JDataFileInfo->YueTjValue[P-1].V_UNBALANCE_Count+3;
					}
					if (VValue>JDataFileInfo->DayTjValue[P-1].V_UNBALANCE_Max )
					{
						TSGet(&ts);
						JDataFileInfo->DayTjValue[P-1].V_UNBALANCE_Max = VValue;
						TimeGetType17(JDataFileInfo->DayTjValue[P-1].V_UNBALANCE_MaxTime,ts);
					}
					if (VValue>JDataFileInfo->YueTjValue[P-1].V_UNBALANCE_Max )
					{
						TSGet(&ts);
						JDataFileInfo->YueTjValue[P-1].V_UNBALANCE_Max = VValue;
						TimeGetType17(JDataFileInfo->YueTjValue[P-1].V_UNBALANCE_MaxTime,ts);
					}
				}
				IValue=0;
				if(IMax!=0)
				{
					//IValue=((IMax-ICalc)*1000)/ICalc;
					IValue = ((IMax - IMin)*1000)/IMax;//������ƽ��ȼ���
					SdPrint("\n\rIValue=%d ABCXZ=%d ICalc=%d RtuDataAddr->F27_28_29_30_Mem.I_UNBALANCE_Max=%d",IValue,ABCXZ,ICalc,JDataFileInfo->DayTjValue[P-1].I_UNBALANCE_Max);

					if((IValue>ABCXZ)&&(ICalc>300))//�����*20%*1000
					{
						JDataFileInfo->DayTjValue[P-1].I_UNBALANCE_Count=JDataFileInfo->DayTjValue[P-1].I_UNBALANCE_Count+1;
						JDataFileInfo->YueTjValue[P-1].I_UNBALANCE_Count=JDataFileInfo->YueTjValue[P-1].I_UNBALANCE_Count+1;
					}
					if (IValue>abs(JDataFileInfo->DayTjValue[P-1].I_UNBALANCE_Max ))
					{
						TSGet(&ts);
						JDataFileInfo->DayTjValue[P-1].I_UNBALANCE_Max = IValue;
						TimeGetType17(JDataFileInfo->DayTjValue[P-1].I_UNBALANCE_MaxTime,ts);
					}
					if (IValue>abs(JDataFileInfo->YueTjValue[P-1].I_UNBALANCE_Max ))
					{
						TSGet(&ts);
						JDataFileInfo->YueTjValue[P-1].I_UNBALANCE_Max = IValue;
						TimeGetType17(JDataFileInfo->YueTjValue[P-1].I_UNBALANCE_MaxTime,ts);
					}
				}
			}

			//������ʼ�ʱ��
			if (real_cl_stat.P_All>JDataFileInfo->DayTjValue[P-1].P_MAX)
			{
				JDataFileInfo->DayTjValue[P-1].P_MAX=real_cl_stat.P_All;
				INT32U_BCD(ts.Minute,&JDataFileInfo->DayTjValue[P-1].P_MAX_TIME[0],1);
				INT32U_BCD(ts.Hour,&JDataFileInfo->DayTjValue[P-1].P_MAX_TIME[1],1);
				INT32U_BCD(ts.Day,&JDataFileInfo->DayTjValue[P-1].P_MAX_TIME[2],1);
			}
			if (real_cl_stat.P_U>JDataFileInfo->DayTjValue[P-1].PA_MAX)
			{
				JDataFileInfo->DayTjValue[P-1].PA_MAX=real_cl_stat.P_U;
				INT32U_BCD(ts.Minute,&JDataFileInfo->DayTjValue[P-1].PA_MAX_TIME[0],1);
				INT32U_BCD(ts.Hour,&JDataFileInfo->DayTjValue[P-1].PA_MAX_TIME[1],1);
				INT32U_BCD(ts.Day,&JDataFileInfo->DayTjValue[P-1].PA_MAX_TIME[2],1);
			}
			if (real_cl_stat.P_V>JDataFileInfo->DayTjValue[P-1].PB_MAX)
			{
				JDataFileInfo->DayTjValue[P-1].PB_MAX=real_cl_stat.P_V;
				INT32U_BCD(ts.Minute,&JDataFileInfo->DayTjValue[P-1].PB_MAX_TIME[0],1);
				INT32U_BCD(ts.Hour,&JDataFileInfo->DayTjValue[P-1].PB_MAX_TIME[1],1);
				INT32U_BCD(ts.Day,&JDataFileInfo->DayTjValue[P-1].PB_MAX_TIME[2],1);
			}
			if (real_cl_stat.P_W>JDataFileInfo->DayTjValue[P-1].PC_MAX)
			{
				JDataFileInfo->DayTjValue[P-1].PC_MAX=real_cl_stat.P_W;
				INT32U_BCD(ts.Minute,&JDataFileInfo->DayTjValue[P-1].PC_MAX_TIME[0],1);
				INT32U_BCD(ts.Hour,&JDataFileInfo->DayTjValue[P-1].PC_MAX_TIME[1],1);
				INT32U_BCD(ts.Day,&JDataFileInfo->DayTjValue[P-1].PC_MAX_TIME[2],1);
			}

			//����С���ʼ�ʱ��
			if (real_cl_stat.P_All<JDataFileInfo->DayTjValue[P-1].P_MIN)
			{
				JDataFileInfo->DayTjValue[P-1].P_MIN=real_cl_stat.P_All;
				INT32U_BCD(ts.Minute,&JDataFileInfo->DayTjValue[P-1].P_MIN_TIME[0],1);
				INT32U_BCD(ts.Hour,&JDataFileInfo->DayTjValue[P-1].P_MIN_TIME[1],1);
				INT32U_BCD(ts.Day,&JDataFileInfo->DayTjValue[P-1].P_MIN_TIME[2],1);
			}
			if (real_cl_stat.P_U<JDataFileInfo->DayTjValue[P-1].PA_MIN)
			{
				JDataFileInfo->DayTjValue[P-1].PA_MIN=real_cl_stat.P_U;
				INT32U_BCD(ts.Minute,&JDataFileInfo->DayTjValue[P-1].PA_MIN_TIME[0],1);
				INT32U_BCD(ts.Hour,&JDataFileInfo->DayTjValue[P-1].PA_MIN_TIME[1],1);
				INT32U_BCD(ts.Day,&JDataFileInfo->DayTjValue[P-1].PA_MIN_TIME[2],1);
			}
			if (real_cl_stat.P_V<JDataFileInfo->DayTjValue[P-1].PB_MIN)
			{
				JDataFileInfo->DayTjValue[P-1].PB_MIN=real_cl_stat.P_V;
				INT32U_BCD(ts.Minute,&JDataFileInfo->DayTjValue[P-1].PB_MIN_TIME[0],1);
				INT32U_BCD(ts.Hour,&JDataFileInfo->DayTjValue[P-1].PB_MIN_TIME[1],1);
				INT32U_BCD(ts.Day,&JDataFileInfo->DayTjValue[P-1].PB_MIN_TIME[2],1);
			}
			if (real_cl_stat.P_W<JDataFileInfo->DayTjValue[P-1].PC_MIN)
			{
				JDataFileInfo->DayTjValue[P-1].PC_MIN=real_cl_stat.P_W;
				INT32U_BCD(ts.Minute,&JDataFileInfo->DayTjValue[P-1].PC_MIN_TIME[0],1);
				INT32U_BCD(ts.Hour,&JDataFileInfo->DayTjValue[P-1].PC_MIN_TIME[1],1);
				INT32U_BCD(ts.Day,&JDataFileInfo->DayTjValue[P-1].PC_MIN_TIME[2],1);
			}

			if((real_cl_stat.P_All)==0){JDataFileInfo->DayTjValue[P-1].P_Zero_Time++;};
			if((real_cl_stat.P_U)==0){JDataFileInfo->DayTjValue[P-1].PA_Zero_Time++;};
			if((real_cl_stat.P_V)==0){JDataFileInfo->DayTjValue[P-1].PB_Zero_Time++;};
			if((real_cl_stat.P_W)==0){JDataFileInfo->DayTjValue[P-1].PC_Zero_Time++;};

			//������ʼ�ʱ��
			if (real_cl_stat.P_All>JDataFileInfo->YueTjValue[P-1].P_MAX)
			{
				JDataFileInfo->YueTjValue[P-1].P_MAX=real_cl_stat.P_All;
				INT32U_BCD(ts.Minute,&JDataFileInfo->YueTjValue[P-1].P_MAX_TIME[0],1);
				INT32U_BCD(ts.Hour,&JDataFileInfo->YueTjValue[P-1].P_MAX_TIME[1],1);
				INT32U_BCD(ts.Day,&JDataFileInfo->YueTjValue[P-1].P_MAX_TIME[2],1);
			}
			if (real_cl_stat.P_U>JDataFileInfo->YueTjValue[P-1].PA_MAX)
			{
				JDataFileInfo->YueTjValue[P-1].PA_MAX=real_cl_stat.P_U;
				INT32U_BCD(ts.Minute,&JDataFileInfo->YueTjValue[P-1].PA_MAX_TIME[0],1);
				INT32U_BCD(ts.Hour,&JDataFileInfo->YueTjValue[P-1].PA_MAX_TIME[1],1);
				INT32U_BCD(ts.Day,&JDataFileInfo->YueTjValue[P-1].PA_MAX_TIME[2],1);
			}
			if (real_cl_stat.P_V>JDataFileInfo->YueTjValue[P-1].PB_MAX)
			{
				JDataFileInfo->YueTjValue[P-1].PB_MAX=real_cl_stat.P_V;
				INT32U_BCD(ts.Minute,&JDataFileInfo->YueTjValue[P-1].PB_MAX_TIME[0],1);
				INT32U_BCD(ts.Hour,&JDataFileInfo->YueTjValue[P-1].PB_MAX_TIME[1],1);
				INT32U_BCD(ts.Day,&JDataFileInfo->YueTjValue[P-1].PB_MAX_TIME[2],1);
			}
			if (real_cl_stat.P_W>JDataFileInfo->YueTjValue[P-1].PC_MAX)
			{
				JDataFileInfo->YueTjValue[P-1].PC_MAX=real_cl_stat.P_W;
				INT32U_BCD(ts.Minute,&JDataFileInfo->YueTjValue[P-1].PC_MAX_TIME[0],1);
				INT32U_BCD(ts.Hour,&JDataFileInfo->YueTjValue[P-1].PC_MAX_TIME[1],1);
				INT32U_BCD(ts.Day,&JDataFileInfo->YueTjValue[P-1].PC_MAX_TIME[2],1);
			}

			//����С���ʼ�ʱ��
			if (real_cl_stat.P_All<JDataFileInfo->YueTjValue[P-1].P_MIN)
			{
				JDataFileInfo->YueTjValue[P-1].P_MIN=real_cl_stat.P_All;
				INT32U_BCD(ts.Minute,&JDataFileInfo->YueTjValue[P-1].P_MIN_TIME[0],1);
				INT32U_BCD(ts.Hour,&JDataFileInfo->YueTjValue[P-1].P_MIN_TIME[1],1);
				INT32U_BCD(ts.Day,&JDataFileInfo->YueTjValue[P-1].P_MIN_TIME[2],1);
			}
			if (real_cl_stat.P_U<JDataFileInfo->YueTjValue[P-1].PA_MIN)
			{
				JDataFileInfo->YueTjValue[P-1].PA_MIN=real_cl_stat.P_U;
				INT32U_BCD(ts.Minute,&JDataFileInfo->YueTjValue[P-1].PA_MIN_TIME[0],1);
				INT32U_BCD(ts.Hour,&JDataFileInfo->YueTjValue[P-1].PA_MIN_TIME[1],1);
				INT32U_BCD(ts.Day,&JDataFileInfo->YueTjValue[P-1].PA_MIN_TIME[2],1);
			}
			if (real_cl_stat.P_V<JDataFileInfo->YueTjValue[P-1].PB_MIN)
			{
				JDataFileInfo->YueTjValue[P-1].PB_MIN=real_cl_stat.P_V;
				INT32U_BCD(ts.Minute,&JDataFileInfo->YueTjValue[P-1].PB_MIN_TIME[0],1);
				INT32U_BCD(ts.Hour,&JDataFileInfo->YueTjValue[P-1].PB_MIN_TIME[1],1);
				INT32U_BCD(ts.Day,&JDataFileInfo->YueTjValue[P-1].PB_MIN_TIME[2],1);
			}
			if (real_cl_stat.P_W<JDataFileInfo->YueTjValue[P-1].PC_MIN)
			{
				JDataFileInfo->YueTjValue[P-1].PC_MIN=real_cl_stat.P_W;
				INT32U_BCD(ts.Minute,&JDataFileInfo->YueTjValue[P-1].PC_MIN_TIME[0],1);
				INT32U_BCD(ts.Hour,&JDataFileInfo->YueTjValue[P-1].PC_MIN_TIME[1],1);
				INT32U_BCD(ts.Day,&JDataFileInfo->YueTjValue[P-1].PC_MIN_TIME[2],1);
			}

			if((real_cl_stat.P_All)==0){JDataFileInfo->YueTjValue[P-1].P_Zero_Time++;};
			if((real_cl_stat.P_U)==0){JDataFileInfo->YueTjValue[P-1].PA_Zero_Time++;};
			if((real_cl_stat.P_V)==0){JDataFileInfo->YueTjValue[P-1].PB_Zero_Time++;};
			if((real_cl_stat.P_W)==0){JDataFileInfo->YueTjValue[P-1].PC_Zero_Time++;};

			//������������������������ʱ��
			if (real_cl_stat.P_All_XL>JDataFileInfo->DayTjValue[P-1].P_All_XL)
			{
				JDataFileInfo->DayTjValue[P-1].P_All_XL=real_cl_stat.P_All_XL;
				INT32U_BCD(ts.Minute,&JDataFileInfo->DayTjValue[P-1].P_All_XL_Time[0],1);
				INT32U_BCD(ts.Hour,&JDataFileInfo->DayTjValue[P-1].P_All_XL_Time[1],1);
				INT32U_BCD(ts.Day,&JDataFileInfo->DayTjValue[P-1].P_All_XL_Time[2],1);
			}
			if (real_cl_stat.P_U_XL>JDataFileInfo->DayTjValue[P-1].P_U_XL)
			{
				JDataFileInfo->DayTjValue[P-1].P_U_XL=real_cl_stat.P_U_XL;
				INT32U_BCD(ts.Minute,&JDataFileInfo->DayTjValue[P-1].P_U_XL_Time[0],1);
				INT32U_BCD(ts.Hour,&JDataFileInfo->DayTjValue[P-1].P_U_XL_Time[1],1);
				INT32U_BCD(ts.Day,&JDataFileInfo->DayTjValue[P-1].P_U_XL_Time[2],1);
			}
			if (real_cl_stat.P_V_XL>JDataFileInfo->DayTjValue[P-1].P_V_XL)
			{
				JDataFileInfo->DayTjValue[P-1].P_V_XL=real_cl_stat.P_V_XL;
				INT32U_BCD(ts.Minute,&JDataFileInfo->DayTjValue[P-1].P_V_XL_Time[0],1);
				INT32U_BCD(ts.Hour,&JDataFileInfo->DayTjValue[P-1].P_V_XL_Time[1],1);
				INT32U_BCD(ts.Day,&JDataFileInfo->DayTjValue[P-1].P_V_XL_Time[2],1);
			}
			if (real_cl_stat.P_W_XL>JDataFileInfo->DayTjValue[P-1].P_W_XL)
			{
				JDataFileInfo->DayTjValue[P-1].P_W_XL=real_cl_stat.P_W_XL;
				INT32U_BCD(ts.Minute,&JDataFileInfo->DayTjValue[P-1].P_W_XL_Time[0],1);
				INT32U_BCD(ts.Hour,&JDataFileInfo->DayTjValue[P-1].P_W_XL_Time[1],1);
				INT32U_BCD(ts.Day,&JDataFileInfo->DayTjValue[P-1].P_W_XL_Time[2],1);
			}

			//����������������������ʱ��
			if (real_cl_stat.P_All_XL>JDataFileInfo->DayTjValue[P-1].P_All_XL)
			{
				JDataFileInfo->DayTjValue[P-1].P_All_XL=real_cl_stat.P_All_XL;
				INT32U_BCD(ts.Minute,&JDataFileInfo->DayTjValue[P-1].P_All_XL_Time[0],1);
				INT32U_BCD(ts.Hour,&JDataFileInfo->DayTjValue[P-1].P_All_XL_Time[1],1);
				INT32U_BCD(ts.Day,&JDataFileInfo->DayTjValue[P-1].P_All_XL_Time[2],1);
			}
			if (real_cl_stat.P_U_XL>JDataFileInfo->DayTjValue[P-1].P_U_XL)
			{
				JDataFileInfo->DayTjValue[P-1].P_U_XL=real_cl_stat.P_U_XL;
				INT32U_BCD(ts.Minute,&JDataFileInfo->DayTjValue[P-1].P_U_XL_Time[0],1);
				INT32U_BCD(ts.Hour,&JDataFileInfo->DayTjValue[P-1].P_U_XL_Time[1],1);
				INT32U_BCD(ts.Day,&JDataFileInfo->DayTjValue[P-1].P_U_XL_Time[2],1);
			}
			if (real_cl_stat.P_V_XL>JDataFileInfo->DayTjValue[P-1].P_V_XL)
			{
				JDataFileInfo->DayTjValue[P-1].P_V_XL=real_cl_stat.P_V_XL;
				INT32U_BCD(ts.Minute,&JDataFileInfo->DayTjValue[P-1].P_V_XL_Time[0],1);
				INT32U_BCD(ts.Hour,&JDataFileInfo->DayTjValue[P-1].P_V_XL_Time[1],1);
				INT32U_BCD(ts.Day,&JDataFileInfo->DayTjValue[P-1].P_V_XL_Time[2],1);
			}
			if (real_cl_stat.P_W_XL>JDataFileInfo->DayTjValue[P-1].P_W_XL)
			{
				JDataFileInfo->DayTjValue[P-1].P_W_XL=real_cl_stat.P_W_XL;
				INT32U_BCD(ts.Minute,&JDataFileInfo->DayTjValue[P-1].P_W_XL_Time[0],1);
				INT32U_BCD(ts.Hour,&JDataFileInfo->DayTjValue[P-1].P_W_XL_Time[1],1);
				INT32U_BCD(ts.Day,&JDataFileInfo->DayTjValue[P-1].P_W_XL_Time[2],1);
			}

			//����������������������ʱ��
			if (real_cl_stat.P_All_XL>JDataFileInfo->YueTjValue[P-1].P_All_XL)
			{
				JDataFileInfo->YueTjValue[P-1].P_All_XL=real_cl_stat.P_All_XL;
				INT32U_BCD(ts.Minute,&JDataFileInfo->YueTjValue[P-1].P_All_XL_Time[0],1);
				INT32U_BCD(ts.Hour,&JDataFileInfo->YueTjValue[P-1].P_All_XL_Time[1],1);
				INT32U_BCD(ts.Day,&JDataFileInfo->YueTjValue[P-1].P_All_XL_Time[2],1);
			}
			if (real_cl_stat.P_U_XL>JDataFileInfo->YueTjValue[P-1].P_U_XL)
			{
				JDataFileInfo->YueTjValue[P-1].P_U_XL=real_cl_stat.P_U_XL;
				INT32U_BCD(ts.Minute,&JDataFileInfo->YueTjValue[P-1].P_U_XL_Time[0],1);
				INT32U_BCD(ts.Hour,&JDataFileInfo->YueTjValue[P-1].P_U_XL_Time[1],1);
				INT32U_BCD(ts.Day,&JDataFileInfo->YueTjValue[P-1].P_U_XL_Time[2],1);
			}
			if (real_cl_stat.P_V_XL>JDataFileInfo->YueTjValue[P-1].P_V_XL)
			{
				JDataFileInfo->YueTjValue[P-1].P_V_XL=real_cl_stat.P_V_XL;
				INT32U_BCD(ts.Minute,&JDataFileInfo->YueTjValue[P-1].P_V_XL_Time[0],1);
				INT32U_BCD(ts.Hour,&JDataFileInfo->YueTjValue[P-1].P_V_XL_Time[1],1);
				INT32U_BCD(ts.Day,&JDataFileInfo->YueTjValue[P-1].P_V_XL_Time[2],1);
			}
			if (real_cl_stat.P_W_XL>JDataFileInfo->YueTjValue[P-1].P_W_XL)
			{
				JDataFileInfo->YueTjValue[P-1].P_W_XL=real_cl_stat.P_W_XL;
				INT32U_BCD(ts.Minute,&JDataFileInfo->YueTjValue[P-1].P_W_XL_Time[0],1);
				INT32U_BCD(ts.Hour,&JDataFileInfo->YueTjValue[P-1].P_W_XL_Time[1],1);
				INT32U_BCD(ts.Day,&JDataFileInfo->YueTjValue[P-1].P_W_XL_Time[2],1);
			}
		}
	//---------------------------------------------------------------------------------------------------------
		JDataFileInfo->DayTjValue[P-1].T_time=ts;
		JDataFileInfo->YueTjValue[P-1].T_time=ts;
	}
}
