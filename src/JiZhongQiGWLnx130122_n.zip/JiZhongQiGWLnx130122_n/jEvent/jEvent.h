/*
 * jEvent.h
 *
 *  Created on: 2013-1-7
 *      Author: Administrator
 */

#ifndef JEVENT_H_
#define JEVENT_H_

#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <dirent.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <ctype.h>
#include <time.h>
#include <signal.h>
#include <semaphore.h>
#include <errno.h>
#include <netdb.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <math.h>
#include <../jBase/inc/jMemory.h>
#include <../jBase/inc/pubfunction.h>
#include <pthread.h>
#include <math.h>

extern int jEventPrint;
extern FILE *fp;
extern unsigned char ProjectNo;

ParamInfo3761* JParamInfo3761;
DataFileInfo*  JDataFileInfo;		//������Ϣ�ṹ
ConfigInfo*    JConfigInfo;
ProgramInfo* JProgramInfo;		//������Ϣ�ṹ

#define SdPrint(...) if (jEventPrint==1) printf(__VA_ARGS__); \
	else if (jEventPrint==2) fprintf(fp, __VA_ARGS__); \
	else if (jEventPrint==3) fprintf(stderr,__VA_ARGS__);

typedef struct
{
	int	counter;
	int CurPDD;
}PDD_t;

#endif /* JEVENT_H_ */
