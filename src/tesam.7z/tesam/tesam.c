#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <linux/types.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <string.h>

typedef unsigned char  INT8U;                    /* Unsigned  8 bit quantity                           */
typedef  signed  char  INT8S;                          /* Signed    8 bit quantity                           */
typedef unsigned short INT16U;                   /* Unsigned 16 bit quantity                           */
typedef signed   short INT16S;                   /* Signed   16 bit quantity                           */
typedef unsigned int   INT32U;                   /* Unsigned 32 bit quantity                           */
typedef signed   int   INT32S;                   /* Signed   32 bit quantity                           */
typedef unsigned long long     	INT64U;                   /* Unsigned 64 bit quantity    */
typedef signed long long  		INT64S;                   /* Unsigned 64 bit quantity    */
typedef float          FP32;                     /* Single precision floating point                    */
typedef double       FP64;                     /* Double precision floating point      */


/*******************************
 *                                                          *
 *               SPI  DEFINEs                      *
 *                                                          *
 *******************************/
#define SPI_CPHA		0x01
#define SPI_CPOL		0x02

#define SPI_MODE_0		(0|0)
#define SPI_MODE_1		(0|SPI_CPHA)
#define SPI_MODE_2		(SPI_CPOL|0)
#define SPI_MODE_3		(SPI_CPOL|SPI_CPHA)

#define SPI_CS_HIGH		0x04
#define SPI_LSB_FIRST		0x08
#define SPI_3WIRE		    0x10
#define SPI_LOOP		    0x20


#define SPI_MODE_MASK		(SPI_CPHA | SPI_CPOL | SPI_CS_HIGH \
				| SPI_LSB_FIRST | SPI_3WIRE | SPI_LOOP)


#define SPI_IOC_MAGIC			'k'

/* Read / Write of SPI mode (SPI_MODE_0..SPI_MODE_3) */
#define SPI_IOC_RD_MODE			_IOR(SPI_IOC_MAGIC, 1, __u8)
#define SPI_IOC_WR_MODE			_IOW(SPI_IOC_MAGIC, 1, __u8)

/* Read / Write SPI bit justification */
#define SPI_IOC_RD_LSB_FIRST		_IOR(SPI_IOC_MAGIC, 2, __u8)
#define SPI_IOC_WR_LSB_FIRST		_IOW(SPI_IOC_MAGIC, 2, __u8)

/* Read / Write SPI device word length (1..N) */
#define SPI_IOC_RD_BITS_PER_WORD	_IOR(SPI_IOC_MAGIC, 3, __u8)
#define SPI_IOC_WR_BITS_PER_WORD	_IOW(SPI_IOC_MAGIC, 3, __u8)

/* Read / Write SPI device default max speed hz */
#define SPI_IOC_RD_MAX_SPEED_HZ		_IOR(SPI_IOC_MAGIC, 4, __u32)
#define SPI_IOC_WR_MAX_SPEED_HZ		_IOW(SPI_IOC_MAGIC, 4, __u32)

/*******************************
 *                                                          *
 *        GPIO  DEFINEs                           *
 *                                                          *
 *******************************/
#define GPIO_IOC_MAGIC   'G'
#define IOCTL_GPIO_SETPINMUX              _IOW(GPIO_IOC_MAGIC, 0, int)                   
#define IOCTL_GPIO_REVPINMUX              _IOW(GPIO_IOC_MAGIC, 1, int)
#define IOCTL_GPIO_SETVALUE               _IOW(GPIO_IOC_MAGIC, 2, int) 
#define IOCTL_GPIO_GETVALUE    		  _IOR(GPIO_IOC_MAGIC, 3, int)

struct as9260_gpio_arg {
	int port;
        int pin;
	int data;
	int pinmuxback;
};






int fd_gpio,fd_esam;



unsigned char esamcmd[][8] =  {
								 {0x55,0x80,0x0e,0x00,0x02,0x00,0x00,0x73}, //获取芯片序列号8字节
								 {0x55,0x80,0x0e,0x00,0x03,0x00,0x00,0x72}, //获取离线计数器4字节
								 {0x55,0x80,0x0e,0x00,0x05,0x00,0x00,0x74}, //获取芯片状态信息1字节
								 {0x55,0x80,0x0e,0x00,0x06,0x00,0x00,0x77}, //获取密钥版本：8字节
								 {0x55,0x80,0x32,0x00,0x02,0x00,0x00,0x4f}, //证书序列号：16字节 测试证书
								 {0x55,0x80,0x1A,0x10,0x00,0x00,0x00,0x00}	//取16字节随机数R5

								};


//55800E0002000073

INT32S gpio_writebyte(INT8S *devpath, INT8S data)
{
	int fd=0;
	if((fd = open((const char*)devpath, O_RDWR | O_NDELAY)) > 0)
	{
		write(fd,&data,sizeof(char));
		close(fd);
		return 1;
	}
	else
		return -1;
	return 0;
}

#define TESAM_CS_PORT   13 
#define TESAM_CS_PIN    5 
int TESAM_CS_init(void)
{       int ret;
	struct as9260_gpio_arg localArg;


	fd_gpio=open("/dev/gpio", O_RDWR);	
	if(fd_gpio<0)
	{
        perror("GPIO open error");
        printf("\n");
        return -1;
	}

	//pinmux switch tp GPIO
    localArg.port = TESAM_CS_PORT;
    localArg.pin = TESAM_CS_PIN;

    ret = ioctl(fd_gpio, IOCTL_GPIO_SETPINMUX, &localArg);
    if(ret<0)
    {
        perror("ioctl error1");
        printf("\n");
        return -1;
    }
	else
	{
		printf("pinMUX[%d][%d]: %o --> pinMUX[%d][%d]: %o\n", localArg.port, localArg.pin, localArg.pinmuxback, localArg.port, localArg.pin, 0 );
	}
	
	return 0;
}


int TESAM_CS_exit(void)
{
   int ret;

   ret = close(fd_gpio);
   if(ret!=0)
   {
		perror("GPIO close error");
        printf("\n");
        return -1;
   }
   else
   {
		return 0;
   }
   
}


int TESAM_CS_low(void)
{

	gpio_writebyte((INT8S *)"/dev/gpoESAM_CS",0);
#if 0
    struct as9260_gpio_arg localArg;
	int ret;

	localArg.port = TESAM_CS_PORT;
    localArg.pin = TESAM_CS_PIN;
   	ret = ioctl(fd_gpio, IOCTL_GPIO_GETVALUE, &localArg);
    if(ret<0)
    {
        perror("CS_low ioctl error1");
        printf("\n");
        return -1;
    }
	//printf("pinVALUE[%d][%d]: %d", localArg.port, localArg.pin, localArg.data);

    localArg.data = 0;
	ret = ioctl(fd_gpio, IOCTL_GPIO_SETVALUE, &localArg);
	if(ret<0)
	{
	   perror("CS_low ioctl error2");
	   printf("\n");
	   return -1;
	}
	//printf(" -> %d\n", localArg.data);	
#endif
	return 0;
}

int TESAM_CS_high(void)
{
	gpio_writebyte((INT8S *)"/dev/gpoESAM_CS",1);
#if 0
	struct as9260_gpio_arg localArg;
	int ret;	


	localArg.port = TESAM_CS_PORT;
    localArg.pin = TESAM_CS_PIN;
	ret = ioctl(fd_gpio, IOCTL_GPIO_GETVALUE, &localArg);
	if(ret<0)
	{
		perror("CS_high ioctl error1");
		printf("\n");
		return -1;
	}
	//printf("pinVALUE[%d][%d]: %d", localArg.port, localArg.pin, localArg.data);

	localArg.data = 1;
	ret = ioctl(fd_gpio, IOCTL_GPIO_SETVALUE, &localArg);
	if(ret<0)
	{
		perror("CS_high ioctl error2");
		printf("\n");
		return -1;
	}
	//printf(" -> %d\n", localArg.data);
#endif
	return 0;	
}




int init_esam(void)
{
unsigned char mode = SPI_MODE_3, lsb=!SPI_LSB_FIRST, bits=0x08;
unsigned int speed = 50000; //timeval between bytes, 20us, 50khz
 

    fd_esam = open("/dev/spi0.0", O_RDWR);
	if (fd_esam < 0) 
	{
		perror("open");
		return -1;
	}

	if(ioctl(fd_esam, SPI_IOC_WR_MODE, &mode)<0)
	{
		perror("can't set spi mode");
//		return -1;
    }


	if (ioctl(fd_esam, SPI_IOC_RD_MODE, &mode) < 0)
	{
		perror("SPI rd_mode");
//		return -1;
	}
	else
	{
		printf("1-- SPI mode: %02x\n", mode&SPI_MODE_3);
	}


	if(ioctl(fd_esam, SPI_IOC_WR_LSB_FIRST, &lsb)<0)
	{
			perror("bit order can't set");
//			return -1;
	}

	if (ioctl(fd_esam, SPI_IOC_RD_LSB_FIRST, &lsb) < 0)
	{
		perror("SPI rd_lsb_fist");
//		return -1;
	}
	else
	{
		printf("2-- SPI bit order: %02x\n", mode&SPI_LSB_FIRST);
	}

	if(ioctl(fd_esam, SPI_IOC_WR_BITS_PER_WORD, &bits)<0)	
	{
			perror("can't set bits per word");
//			return -1;
	}
			
	if (ioctl(fd_esam, SPI_IOC_RD_BITS_PER_WORD, &bits) < 0)
	{
		perror("SPI bits_per_word");
//		return -1;
	}
	else
	{
		printf("3-- SPI bits per word: %02x\n", bits);
	}

	if(ioctl(fd_esam, SPI_IOC_WR_MAX_SPEED_HZ, &speed)<0)
	{
	    perror("can't set max speed hz");
//	    return -1;
	}
		
	if (ioctl(fd_esam, SPI_IOC_RD_MAX_SPEED_HZ, &speed) < 0)
	{
		perror("SPI max_speed_hz");
//		return-1;
	}
	else
	{
		printf("3-- SPI clock speed: %d Hz\n", speed);
	}

		
    return 0;
	
}

int close_esam(void)
{
   int ret;

   ret = close(fd_esam);

   if(ret!=0)
   {
		perror("T_ESAM close error");
        printf("\n");
        return -1;
   }
   else
   {
		return 0;
   }

}


int TESAM_recv_data(unsigned char *rxdata, int num)
{
int checkNum,checkIndex;
unsigned char checkVal = 0x00;
int dataLength,i;

    if(rxdata[0]!=0x55)
    {
		printf("TESAM rx data format error\r\n");
		return -1;
	}

	dataLength = ((rxdata[5]<<8)+(rxdata[6]<<0));
//	fprintf(stderr,"dataLength=%d,num=%d\n",dataLength,num);
	if((num<8)||(num != (8+dataLength)))
	{
       printf("TESAM rx data length error\r\n");
	   return -2;
	}

	checkNum = 6+dataLength;
    checkIndex = 1;
	for( ; checkNum; checkNum--,checkIndex++)
	{
		checkVal ^= rxdata[checkIndex];
		//printf("rxdata[%d]: %02x, checkVal: %02x\r\n", checkIndex, rxdata[checkIndex], checkVal);
	}

	if( (unsigned char)(~checkVal)!=rxdata[num-1] )
	{
		printf("TESAM data stream verification failed!\r\n");
		return -3;
	}


#if 1
    printf("\r\nSend data to TESAM ...\r\n");
    for(i=0; i<num; i++)
    {
         printf("%02x, ", rxdata[i]);
	}
	printf("\r\n");
#endif


	usleep(20); //CS high more than 10us
    TESAM_CS_low();
	usleep(80); //delay more than 50us
	if(write(fd_esam, rxdata, 7)!=7)
	{
	    printf("TESAM reciving data format failed!\r\n");
		TESAM_CS_high();
		return -1;
	}		
	
	if(dataLength!=0)
	{
		usleep(120);//delay more than 100us
		if(write(fd_esam, rxdata+7, dataLength)!=dataLength)
		{	
		   printf("TESAM reciving data failed!\r\n");
		   TESAM_CS_high();
		   return -2;
		}
		
	}
	
	if(write(fd_esam, rxdata+(num-1), 1)!=1)
	{
 		printf("TESAM reciving data checkChar failed!\r\n");
		TESAM_CS_high();
 		return -3;
	}	
	
	
	TESAM_CS_high();
	return 0;
}




#define TempDMARxBufLen 64
unsigned char retBuf[TempDMARxBufLen]; //note: just use this TEMP buffer to check the return data. 
int TESAM_ret_data(unsigned char *retdata)
{
int dataLength,curLen, curIndex=1;
int	readLen=0;
unsigned char checkVal = 0x00;
int i,ret;


#if 1
    printf("\r\nGet data from TESAM ...\r\n");
#endif

    memset(retBuf,0,sizeof(retBuf));

	usleep(20); //CS high more than 10us	
	TESAM_CS_low();
	usleep(10);

//	if(read(fd_esam, retBuf, 64)!=64)
	if(read(fd_esam, retBuf, 8)!=8)
	{
		printf("TESAM returning data: Common area failed!\r\n");
		TESAM_CS_high();
		return -2;
	}
	else
	{
		printf("[0]:%02X, [1]:%02X, [2]: %02X, [3]: %02X, ", retBuf[0], retBuf[1], retBuf[2], retBuf[3]);
    	printf("[4]:%02X, [5]:%02X, [6]: %02X, [7]: %02X\r\n", retBuf[4], retBuf[5], retBuf[6], retBuf[7]);
//		for(i=0;i<64;i++) {
//			if(i%4==0) fprintf(stderr,"\n");
//			fprintf(stderr,"%02x ",retBuf[i]);
//
//		}
	}

	

    for(i=3; i<7; i++)
    {
		checkVal ^= retBuf[i];
	}

	dataLength = (retBuf[5]<<8)+retBuf[6];
	if(dataLength)
	{ 
		checkVal ^= retBuf[7];
	    if(retdata)
	    {
	        retdata[0] = retBuf[7];			
	    }
		
		do
		{			   
		   curLen = ((dataLength<TempDMARxBufLen)?dataLength:TempDMARxBufLen);
//		   if(curLen%4==0) readLen=curLen;
//		   else readLen = (curLen+1)*4;
		   printf("read curLen=%d\n",curLen);
		   if( (ret=read(fd_esam, retBuf, curLen))!=curLen )
		  // if( (ret=read(fd_esam, retBuf, readLen))!=readLen )
		   {
			   printf("TESAM returning data, indexed[%d], failed: %d;  ", curIndex, ret);
			   fflush(stdout);		
                           perror("errno decode");
			   printf("\n");	  			   
			   TESAM_CS_high();
			   return -3;
		   }
		   else
		   {
			   for(i=0; i<curLen; i++)
			   {
					checkVal ^= retBuf[i];		
					printf("%2x, ", retBuf[i]);
			   }
		   
		   	   if(retdata)
		   	   {
		   	   	   memcpy(retdata+curIndex, retBuf, curLen);					
			   }
               curIndex += curLen;
			   dataLength -= curLen;			   
		   }
		}
		while(dataLength>0);

		checkVal ^= retBuf[curLen-1]; //remove the checkVal form XOR sum;
		checkVal = ~checkVal;
		printf("\r\nFinal checkVal: %02x\r\n", checkVal);
		if( checkVal!=retBuf[curLen-1] )
		{
			printf("\r\nTESAM_ret_data DATA vefification failed!\r\n");
			TESAM_CS_high();
			return -4;
		}
	}
	else
	{
			if(checkVal!=retBuf[7])
			{
				printf("TESAM_ret_data NO-DATA vefification failed!\r\n");
				TESAM_CS_high();
				return -5;
			}
	}
	
	TESAM_CS_high();
	
	return 0;
}



int main(void)
{
int ret, i, j;

	printf("\r\n\r\nAlphaScale TESAM func demo entered!\r\n");
	printf("Build on %s  %s\r\n\r\n\r\n",__DATE__,__TIME__);

//	ret = TESAM_CS_init();
//	if(ret)
//	{
//		printf("TESAM_CS_init failed!\n");
//		exit(1);
//	}

	gpio_writebyte((INT8S*)"/dev/gpoATT_CS", 1);


    ret = init_esam();
	if(ret)
	{
		printf("init_esam failed!\n");
		exit(1);
	}

//for(i=0; i< 1; i++)
for(i=0; i< 5; i++)
{
    printf("\r\n\r\n");

	if(TESAM_recv_data(esamcmd[i], 8))
	{
	    printf("TESAM_get_data failed!\r\n");
		goto closeFd;
	}
        for(j=0;j<6;j++)
        {
	   usleep(500000);
        }	
    if(TESAM_ret_data( (unsigned char *)0))
    {
		printf("TESAM_ret_data failed!\r\n");
		goto closeFd;		
	}
	
}
closeFd:
//   TESAM_CS_exit();
   close_esam();

   exit(0);	
}
