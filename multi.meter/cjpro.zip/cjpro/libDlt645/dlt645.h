

#ifndef DLT645_H_
#define DLT645_H_

extern int ProcessData(unsigned char* Rcvbuf,int Rcvlen,unsigned char* addr);

#endif
