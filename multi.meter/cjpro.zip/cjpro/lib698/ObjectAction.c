/*
 * ObjectAction.c
 *
 *  Created on: Nov 12, 2016
 *      Author: ava
 */

#include <string.h>
#include <stdio.h>
#include "ObjectAction.h"
#include "StdDataType.h"

typedef struct
{
	TSA addr;
	INT8U Baud;
	INT8U protocol;
	OAD port;
	INT8U pwd[20];
	INT8U usrtype;
	INT8U connectype;
	INT16U ratedU;
	INT16U ratedI;
}BASIC_OBJECT;
typedef struct
{
	TSA cjq_addr;
	INT8U asset_code[12];
	INT16U pt;
	INT16U ct;
}EXTEND_OBJECT;
typedef struct
{
	OAD oad;
	INT8U data[10];
}ANNEX_OBJECT;

typedef struct
{
	INT8U name[50];
	INT16U sernum;
	BASIC_OBJECT basicinfo;
	EXTEND_OBJECT extinfo;
	ANNEX_OBJECT aninfo;
}CLASS_6001;//采集档案配置表对象
//typedef struct
//{
//	INT8U name[50];
//	CLASS_6001 array6001[1024];
//	INT16U count;
//	INT16U maxcount;
//}CLASS_6000;//采集档案配置表对象
void get_BasicUnit(INT8U *source,INT8U *des)
{
	int i=0;
	INT8U num=0;
	INT8U size=0;
	INT8U type = source[0];
	fprintf(stderr,"\ntype = %d\n",type);
	switch (type)
	{
		case 2: //struct
			num = source[1];
			size = 1;
			source = source + 2;

			for(i=0;i<num;i++)
				get_BasicUnit(source,des);
			break;
		case 18://long unsigned
			size = 2;
			memcpy(des,&source[1],size);
			break;
		case 85://TSA
			size = source[1];
			memcpy(des,&source[2],size);
			break;
		case 22://enum
			size = 1;
			memcpy(des,&source[1],size);
			break;
		case 17://unsigned
			size = 1;
			memcpy(des,&source[1],size);
			break;
		case 81://OAD
			size = 4;
			memcpy(des,&source[1],size);
			break;
		case 9://octet-string
			size = source[1];
			memcpy(des,&source[2],size);
			break;
	}
	source = source + 1 + size;
	des = des + size;
}
void AddBatchMeterInfo(INT8U *data)
{
	CLASS_6001 meter={};
	int i=0;
	INT8U addnum = data[1];

	fprintf(stderr,"\naddnum=%d",addnum);
	for(i=0; i<addnum; i++)
	{
		memset(&meter,0,sizeof(meter));
		get_BasicUnit(&data[2],(INT8U *)&meter.sernum);
		fprintf(stderr,"\nmeter.sernum=%d,addr=%02x%02x%02x%02x%02x%02x,baud=%d,protocol=%d",meter.sernum,
				meter.basicinfo.addr.addr[0],meter.basicinfo.addr.addr[1],meter.basicinfo.addr.addr[2],meter.basicinfo.addr.addr[3],
				meter.basicinfo.addr.addr[4],meter.basicinfo.addr.addr[5],meter.basicinfo.Baud,meter.basicinfo.protocol);
		//将meter添加到记录文件
	}
}
void MeterInfo(INT16U attr_act,INT8U *data)
{
	switch(attr_act)
	{
		case 2:	 //属性 2(配置表)∷=array 采集档案配置单元
			break;
		case 127://方法 127:Add (采集档案配置单元)
			break;
		case 128://方法 128:AddBatch(array 采集档案配置单元)
			AddBatchMeterInfo(data);
			break;
		case 129://方法 129:Update(配置序号,基本信息)
			break;
		case 130://方法 130:Update(配置序号,扩展信息,附属信息)
			break;
		case 131://方法 131:Delete(配置序号)
			break;
		case 132://方法 132:Delete(基本信息)
			break;
		case 133://方法 133:Delete(通信地址, 端口号)
			break;
		case 134://方法 134:Clear()
			break;
	}
}
int doObjectAction(OMD omd,INT8U *data)
{
	INT16U oi = omd.OI;
	INT8U attr_act = omd.method_tag;
	fprintf(stderr,"\n----------  oi =%04x",oi);
	switch(oi)
	{
		case 0x6000://采集档案配置表
			MeterInfo(attr_act,data);
			break;
		case 0x6002://搜表
			break;
		case 0x6012://任务配置表
			break;
	}
	return 1;
}
