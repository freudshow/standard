﻿#ifndef CJ485_H_
#define CJ485_H_
#include <termios.h>
#include <errno.h>
#include <wait.h>
#endif
