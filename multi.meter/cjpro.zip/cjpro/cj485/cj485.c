﻿#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#include <pthread.h>
#include <unistd.h>
#include "cj485.h"

int main(int argc, char *argv[])
{
	while(1){
		sleep(1);
	}
 	return EXIT_SUCCESS;
}

