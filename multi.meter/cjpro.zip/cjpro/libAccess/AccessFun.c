#include <stdio.h>
#include "errno.h"
#include <time.h>
#include <dirent.h>
#include <ctype.h>
#include <strings.h>
#include <termios.h>
#include <ctype.h>
#include <unistd.h>
#include <sys/mman.h>
#include <semaphore.h>
#include <stdarg.h>
#include <string.h>
#include <stdlib.h>
#include <stddef.h>
#include <fcntl.h>
#include <dirent.h>
#include <syslog.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "AccessFun.h"

#define LIB_ACCESS_VER 0x0001


/***************************************
 * 当前数据存储函数
 * mtype:	表计类型
 * id:		数据标识
 * data:	数据
 * len:		数据长度
 * 返回值: 	1
 ***************************************/
unsigned short SetMCurrentData(int mtype,int id,unsigned char* data,int len)
{
	return 0;
}
/***************************************
 * 历史数据存储函数
 * mtype:	表计类型
 * id:		数据标识
 * year,month,day 数据日期
 * data:	数据
 * len:		数据长度
 * 返回值: 	1
 ***************************************/
unsigned short SetMHisData(int mtype,int id,int year,int month,int day,unsigned char* data,int len)
{
	return 0;
}
/***************************************
 * 表计参数存储函数
 * mtype:	表计类型
 * id:		数据标识
 * data:	数据
 * len:		数据长度
 * 返回值: 	1
 ***************************************/
unsigned short SetMPara(int mtype,int id,unsigned char* data,int len)
{
	return 0;
}


/***************************************
 * 当前数据访问函数
 * mtype:	表计类型
 * id:		数据标识
 * data:	数据
 * len:		数据长度
 * 返回值: 	1
 ***************************************/
unsigned short GetMCurrentData(int mtype,int id,unsigned char* data,int len)
{
	return 0;
}
/***************************************
 * 历史数据访问函数
 * mtype:	表计类型
 * id:		数据标识
 * year,month,day 数据日期
 * data:	数据
 * len:		数据长度
 * 返回值: 	1
 ***************************************/
unsigned short GetMHisData(int mtype,int id,int year,int month,int day,unsigned char* data,int len)
{
	return 0;
}
/***************************************
 * 表计参数访问函数
 * mtype:	表计类型
 * id:		数据标识
 * data:	数据
 * len:		数据长度
 * 返回值: 	1
 ***************************************/
unsigned short GetMPara(int mtype,int id,unsigned char* data,int len)
{
	return 0;
}
