
#define LIB645_VER 	1
#include "transmit.h"
int ProcessData(unsigned char* Rcvbuf,int Rcvlen,unsigned char* addr)
{
	return 1;
}
