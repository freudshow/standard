#ifndef CJMAIN_H_
#define CJMAIN_H_

#include <stdlib.h>
#include <stdio.h>
#include <sys/mman.h>
#include <string.h>
#include <fcntl.h>
#include "PublicFunction.h"
#include "gtype.h"
#define PRO_WAIT_COUNT     60
ProgramInfo* JProgramInfo=NULL;

#endif
